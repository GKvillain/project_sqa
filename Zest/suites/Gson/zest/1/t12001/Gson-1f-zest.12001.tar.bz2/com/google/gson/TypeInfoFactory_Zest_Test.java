package com.google.gson;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeInfoFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]] |a0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 5, "\u543e", "\u513c\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u611a\u32d8", "\ud858\udec5",
        11, 12959, -1524522252, 6119542924934798548L, 18989L, true, true, (char) 60462, (char) 43192,
        Double.longBitsToDouble(0x3fe4fb363f21caebL), Double.longBitsToDouble(0x3fedd1f288032304L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]] |a0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 5, "\u543e", "\u513c\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u501d\u3d88", "\ud858\udec5",
        11, 12959, -1524522252, 6119542922824899939L, 10748L, true, true, (char) 60462, (char) 43192,
        Double.longBitsToDouble(0x3fe4fb363f21caebL), Double.longBitsToDouble(0x3fedd1f288032304L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[int, class [Ljava.lang.String;]] |a0=[Ljava.lang.reflect.Type;:[[int, class [Ljava.lang.String;]]\0121=null\012",
        Z.run(T, 2, 2, 0, 5, "\uda5f\ude02", "\u513c\u5c96\u3cc5\uc4c1\u9b0e\u3f46", "\uda1f\udc41\ud9f3\udd4f\ud867\udec5\ud85e\udc7b\uda01\udddb\ud9f6\udff7\udb20\ude88\ud9e6\udff4\ud833\udd13",
        18, 89364, -1537490956, 5028449518532703483L, 70207L, false, true, (char) 39687, (char) 49050,
        Double.longBitsToDouble(0x3fdcca6e74e940b6L), Double.longBitsToDouble(0x3fe893b0b41ad201L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.gson.TypeInfoFactory:@?\012",
        Z.run(T, 1, 6, 0, 6, "\ud8c3\udfca\ud83f\udc84\ud8c7\udc4b", "\u3cc5", "\udbb1\udf79\udb29\udce5\u7a94\uda1f\udc41",
        8, 7132, -2001142352, 6236687073863708283L, 84778L, false, false, (char) 12919, (char) 59089,
        Double.longBitsToDouble(0x3fe97b610c23e68aL), Double.longBitsToDouble(0x3fe32ab29925eacfL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 0, "\u5f7f", "\u513c", "\ud9b2\udddd\ud815\udc6c\udb9a\ude79",
        55, 52748, -1048055824, -3851984549479168036L, -100000L, true, true, (char) 31733, (char) 17106,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e47e451f8000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]] |a0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 4, "\u543e", "\u513c\u5c96\u3cc5\uc4c1\u230f\u683c\u5a19\u1edf\u6aef\ud4f0\u32d8", "\ud858\udec5",
        11, 12959, -1524522252, 6119542924934798548L, 18989L, true, true, (char) 60462, (char) 43192,
        Double.longBitsToDouble(0x3fe4fb363f21caebL), Double.longBitsToDouble(0x3fedd3aa88032304L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.lang.Object, class java.lang.Number, class java.lang.Integer]] |a0=[Ljava.lang.reflect.Type;:[[class java.lang.Object, class java.lang.Number, class java.lang.Integer]]\0121=null\012",
        Z.run(T, 2, 2, 0, 0, "\udbc6\udf9c\udbb4\ude19\ud8c7\udc4b\udbc8\udf93\uda7d\udd4d\udb05\udd04\ud9b2\udddd\ud815\udc6c\udbb1\udf79\udb29\udce5", "\u611a\u32d8\ub977\u4169\u2e62\u608c\u6c56\u3f41\u7885\u051e", "\ud9b4\uddf8\ud940\uddba\uda34\udc73\ud892\udf7e\ud874\udecd\ud916\uddca\ud9af\udeea",
        15, 17307, 365962443, 4397021880692774163L, 81777L, true, true, (char) 1904, (char) 12288,
        Double.longBitsToDouble(0x3f6bf3dc8b70b800L), Double.longBitsToDouble(0x3fef6dc749a853b1L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 5, "\udbd6\udcdf\ucc5c\ud8e9\udd3e\udbc8\udf93\uda7d\udd4d\udb05\udd04\ud9b2\udddd\ud815\udc6c\udbb1\udf79\udb29\udce5\u7a94\udad7\udc84", "\ubc77\u90c5\u2e62\u608c\u6c56\u3f41\u7885\ua447", "\ud9b4\uddf8\ud940\uddba\uda34\udc73\ud892\udf7e\ud874\udecd\ud916\uddca\udb9e\udca2",
        55, 86694, 1347906419, 2003989226254435925L, 7678L, true, true, (char) 50665, (char) 31864,
        Double.longBitsToDouble(0x3fe157d3c055c24fL), Double.longBitsToDouble(0x3fa0a6240ca7b620L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[char]] |a0=[Ljava.lang.reflect.Type;:[[char]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\u0e5c", "\u53a9\uc2d0\u3d17\uc4c1\u9b0e\u683c\u5a19\uc5e1\uc434\u75df\uc70c", "\ud858\udec5\uda07\ude60\uda3e\uddfe\ud833\udd99\ud8c4\udcdf\ud883\ude09\ud8a1\udf45\ud935\udee9\ud85c\udc0b\ud940\udd98\uda34\udc73\udb75\udf30\ud874\udeb3\ud916\uddca\ud940\udf33\uda1e\uddc0\udbbd\udfbc\udb74\udd57\ud98b\udf10\ud88a\ude02\udbc9\ude44\udbcd\udd20\udbde\ude5a\uda8f\udd11\ud971\udcfd\udb51\ude92",
        -3, 87835, 309040757, 8503346171124970975L, 6448L, true, true, (char) 52476, (char) 65305,
        Double.longBitsToDouble(0x3fc763cb54f7b090L), Double.longBitsToDouble(0x3fcf88b8a4c4aa28L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[]] |a0=[Ljava.lang.reflect.Type;:[[]]\0121=null\012",
        Z.run(T, 2, 2, 0, 5, "\u543e", "\u513c\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u611a\u32d8", "\ud858\udec5",
        52, 12959, -1524522252, -5461497603521571404L, -84541L, false, true, (char) 60462, (char) 43192,
        Double.longBitsToDouble(0x3fe4fb363f21caebL), Double.longBitsToDouble(0x3fedd1f288032304L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]] |a0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 5, "\u543e", "\u513c\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\ua858\uabb6\u327b", "\ud858\udec5",
        11, 12959, -1524522252, 6119542924934798548L, 18989L, false, true, (char) 32662, (char) 43246,
        Double.longBitsToDouble(0x3fe4fb363835caebL), Double.longBitsToDouble(0x3fe87e5fa8032304L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.lang.Object]] |a0=[Ljava.lang.reflect.Type;:[[class java.lang.Object]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 5, "\ud8e1\udd00", "\u0d88\u3adc\ud518\uc180\u607b\u5183\u5a19\u94a8\u1576\u2d83\u32d8\u9a58\ub7b7\u54c6\u608c\u6c56", "\ud883\ude09\ud8a1\udf45\ud935\udf2c\ud9b4\uddf8",
        21, 65789, -890548577, 4490483695484194746L, 20349L, true, false, (char) 547, (char) 23953,
        Double.longBitsToDouble(0x3fc425d9203b893cL), Double.longBitsToDouble(0x3fcf4d1506e169e8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[]] |a0=[Ljava.lang.reflect.Type;:[[]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 5, "\uda2d\udf38\ud83c\udc3d\ud8c7\udc4b\udbc8\udf93\uda7d\udd4d\udb05\udd04\ud9b2\udddd\udba6\udeb4\udbb1\udf79\udb29\udce5\u7a94\uda1f\udc41\ud9f3\udd4f\ud971\udfab\uda14\udcd5\ud8a3\uddce", "\u3f5e\u3f41\ud094\u051e\u2012\ub74f\u6c30\uc932\uaf8b\u7fb5\u10fd\u213b\ua442\u419b\u9a3f\ub7d7\u20fe\u1ed0", "\ud910\udc50\ud8e4\ude60\ud939\udfe7\ud8ec\uddf7\ud9f9\ude35\udbdc\ude12\u3658\ud80f\ude63\ud8b6\ude2f\ud857\udd54\ud829\udcbc",
        24, 86321, -1183233064, 9029448362401310437L, -38730L, false, false, (char) 59846, (char) 11322,
        Double.longBitsToDouble(0x3fd7e911f338dc92L), Double.longBitsToDouble(0x3feddcf216f474e4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 7, 1, "\u543e\ud83f\udc84\ud8c7\udca2\udbc8\udf93\uda7d\udd4d", "\u9b0e", "\u7a94\uda1f\udc41\ud9f3\udd4f\ud867\udec5",
        52, 60415, 2079712119, 4745398172381133815L, 97666L, false, false, (char) 12919, (char) 59089,
        Double.longBitsToDouble(0x3fe97b610ca4a78aL), Double.longBitsToDouble(0x3fe32ab29e9f66c7L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List\0121=null\012",
        Z.run(T, 2, 1, 0, 5, "\u543e", "\u699a\uc22a\u5b8a\uc868\u058a\u220b\u5a19\u1edf\u15e6\u611a\u32d8", "\ud858\udec5\uda07\ude60\uda3e\uddfe\ud833\udd99",
        18, 20620, -1115561014, 7791618225946963445L, 71339L, false, false, (char) 5994, (char) 52457,
        Double.longBitsToDouble(0x3fd34b5f95c79292L), Double.longBitsToDouble(0x3fd5707b720c936aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 5, 7, "\u5471\ud868\ude59\udb64\udcf3\ud867\ude22\ud8eb\udd35\udafd\udda1\udb09\udca3\udac3\udd48\ud9aa\udf17\ud869\ude10\ud85b\udf70\udb66\uddc3", "\ud0ad", "\ud9c9\udfe4\udbc2\uddf0\ud833\udd99\ud8c4\udcdf\uda20\udcb7\ud81a\uddc2\uda3d\udcbb\ud91b\udfca\uda50\udd02\uda90\udec3\ud84d\ude65\udb82\ude16\ud978\ude4e\ud837\udeec\udaf5\udcec\ud911\udcfb\ua177\udb4c\udd8f\uda5a\udde4\ud98d\ude5f\ud962\uded6\udb05\udee7\ud9b1\udf21\ud9dd\uddd9\uda81\udf92\ud9b5\udd75\ud813\udf29\ud943\ude26\uda49\ude35\udb5f\udee3\ud819\ude19\ud8cc\udf21\ud84f\udce0",
        38, 2208, -682813970, 7770816817952915589L, 12500L, true, true, (char) 6772, (char) 19970,
        Double.longBitsToDouble(0x3fb291b61dd79530L), Double.longBitsToDouble(0x3fe26f74f4831923L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 5, "\ud9f4\udf02", "\u50c5\u5c96\u3cc5\uc4c1\u9b0e\u3759\u18e9\u131c\u15e6\u611a\u32d8", "\ud858\udec5",
        11, 12959, -1524522252, 6119542922532416468L, -27371L, true, true, (char) 36654, (char) 55131,
        Double.longBitsToDouble(0x3fd0774afefb8806L), Double.longBitsToDouble(0x3fedd1f288032304L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]] |a0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 0, "\u543e", "\u513c\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1e49\u15e6\u611a\u8ad7", "\ud858\udec5",
        11, 12959, -1524522252, 6119542924569894100L, -46547L, true, true, (char) 60462, (char) 43192,
        Double.longBitsToDouble(0x3fc3ecd8fc872908L), Double.longBitsToDouble(0x3fedd1f28feb2904L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.gson.TypeInfoFactory:@?\0121=null\012",
        Z.run(T, 2, 6, 0, 5, "\udacc\udf0d\ud83f\udc84\ud8c7\udc4b\udbc8\udf93\uda7d\udd4d\udaf5\udc04\ud9b2\udddd\ud815\udc6c\udbb1\udf79\udb29\udce5\u7a94\uda1f\udc41\ud9f3\udd4f\ud867\udec5\ud85e\udc7b\ud8be\udf7a", "\u6c56\u3f41\u4817\u39c5\u2012\u90f5\u5e57\u2af4\u4c35\u7fb5\u10fd\u213b\u451e\uc441\u7da0\ub3f4\u2fd0\u1c4e\u207a\u2921\u3b9a\ud6c4\u9ab9\u210b\u5877\u182d\uc408\u92cb\ubb79\u5423\u4e76\u0e1d\u9f1d\ud7ee\u767b\u58f2\u8542\u25e8\u0a27\u08d6\u5bbc\u1fda\u8042\u876d", "\ud818\udfcb\udbbc\udd77\udbda\udc53\ud9b5\udfb2\uda0c\udcb7\uda0f\udce0\ud988\uddd4\udbf1\udda5\ud93a\udcea\udb39\udf54\udb72\udf53\ud838\ude54\ud835\udeee\udb95\ude06\udbeb\ude1b\udaca\ude8a\uda69\udee1\uda5c\ude0e\ud8c5\udfcb\udb6a\udf40\udac7\udf04\ud8dd\udf6f",
        7, 49781, 1582468522, -8377631446230067871L, 22987L, true, true, (char) 17955, (char) 62800,
        Double.longBitsToDouble(0x3fe6237e90020e3eL), Double.longBitsToDouble(0x3fe667f268d654deL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[]] |a0=[Ljava.lang.reflect.Type;:[[]]\0121=java.lang.Class:java.lang.Comparable\012",
        Z.run(T, 2, 2, 1, 5, "\udac1\udc53\udb66\udcd4\udbcd\udfe6\udbc8\udf97\uda7d\udd4d\udb05\udd04\ud9b2\udddd\ud8c8\ude50\udbb1\udf79\ud929\udce5\u7a94\udb7d\udeaf\udaf0\udc4f\ud80c\udd19\ud847\ude04\ud9a6\ude9c\udb24\udf0c\ud9d9\udee3", "\u7885\u8f58\u9d47\ub339\u5e57\u2af4\u4c35\u0355\u79a9\u213b\ubf9b\u5582\u3511\u6f62\u6e0a\u03da\u7a9d\u105c\u2698\u989f\u8487\ua1b6", "\udb57\udfa2\ud9ee\udfb7\ud99b\uddfb\uda0d\ude4f\udb7f\udffb\ud939\ude65\udabb\uddda\ud8b0\ude34\udbbc\ude46\ud97a\ude6b\ud962\ude08\udb21\uddf9\ud93e\udd86\udafe\udd14\udbd9\udee6\ud984\ude3c\ud82e\ude75",
        36, 93264, 199843156, -1670488965181845979L, 93826L, true, false, (char) 39721, (char) 50528,
        Double.longBitsToDouble(0x3fd941b31728443cL), Double.longBitsToDouble(0x3feb42940a631981L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class java.lang.Number, class java.lang.Thread$State]] |a0=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class java.lang.Number, class java.lang.Thread$State]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 5, 5, "\u543e", "\u513c\u0d54\u3cc5\uc4c1\u9b0e\u82ed\u59fe\u1edf\u15e6\ub6d6\u86e8", "\ud858\udec5",
        11, 2078, -1524560821, 6119542925958208724L, 18989L, true, true, (char) 60462, (char) 43192,
        Double.longBitsToDouble(0x3fe4fb363f21caebL), Double.longBitsToDouble(0x3fedd1f28d135d04L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 5, "\udb50\ude7b", "\u513c\u32d4\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u4cbf\uc763\ua571", "\uda07\ude60\udb16\udf03\udb7c\udf9b\ud8c4\udcdf\ud883\ude09\uda40\uddc1",
        38, 84245, 1448290732, 7405978705088695967L, -67000L, true, false, (char) 45766, (char) 9137,
        Double.longBitsToDouble(0x3fe74149613bd1afL), Double.longBitsToDouble(0x3fdcf26175bf1826L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]] |a0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [Ljava.lang.String;, class java.lang.Thread$State]]\0121=java.lang.Class:java.lang.Thread$State\012",
        Z.run(T, 2, 2, 1, 7, "\ud8af\udcaf", "\u513c\u0418\u3cdb\uc4c1\u9b0e\ua03c\u5a19\u1edf\ubd4c\u9df4\u325e", "\ud902\udeba",
        11, 12959, -1524522252, -5352568285031565L, 18989L, true, true, (char) 42612, (char) 58435,
        Double.longBitsToDouble(0x3fe4fb363f21caebL), Double.longBitsToDouble(0x3fedd1f288032304L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 5, "\ud81b\udde0", "\ua323\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u611a\u32d8", "\ud858\udec5",
        28, 70766, 52751006, 6119542078826241236L, 18989L, true, true, (char) 60462, (char) 43192,
        Double.longBitsToDouble(0x3fe4fb363f21caebL), Double.longBitsToDouble(0x3fec79f28a4306dbL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.google.gson.TypeInfoFactory:@?\0121=new com.google.gson.TypeInfoFactory:@?\012",
        Z.run(T, 2, 6, 6, 5, "\u543e", "\u513c\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u611a\u32d8", "\ud858\udec5",
        11, 12959, -1524522252, 6119542924934798548L, 18989L, true, true, (char) 8271, (char) 43152,
        Double.longBitsToDouble(0x3fc3ecd8fc872b90L), Double.longBitsToDouble(0x3fedd1f28d41ee04L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[]] |a0=[Ljava.lang.reflect.Type;:[[]]\0121=[Ljava.lang.reflect.Type;:[[]] |a0=[Ljava.lang.reflect.Type;:[[]]\012",
        Z.run(T, 2, 2, 2, 0, "\u543e\ud83f\udc84", "\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u611a\u32d8\ubc77\u4169\u2e62\u608c\u6c56\u3f41\u6d8e\u051e\u2012\u90f5\u5e57\u2af4\u4c35\u7fb5\u10fd\u213b\u2027\u7af3\u9bcf\u66fc\u90e5\u0219\u3b26", "\ud821\ude99\ud873\udce4\ud9c7\udc01",
        24, 70938, 1283938226, 5177955706600746876L, -31274L, true, false, (char) 8847, (char) 58520,
        Double.longBitsToDouble(0x3fd3344310c35304L), Double.longBitsToDouble(0x3fe867385075217cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.lang.Integer, class java.lang.Number, char]] |a0=[Ljava.lang.reflect.Type;:[[class java.lang.Integer, class java.lang.Number, char]]\0121=[Ljava.lang.reflect.Type;:[[class java.lang.Integer, class java.lang.Number, char]] |a0=[Ljava.lang.reflect.Type;:[[class java.lang.Integer, class java.lang.Number, char]]\012",
        Z.run(T, 2, 2, 2, 5, "\udac3\ude93", "\u513c\u078d\u1ae4\uc4c1\u9b0e\u683c\u5a19\ubbd7\u1343\u611a\u32d8", "\ud858\udec5\uda07\ude60\uda3e\uddfe\ud833\udd99\ud8c4\udcdf",
        55, 76105, 1814155469, -6374133685208005468L, -84734L, true, false, (char) 20828, (char) 20728,
        Double.longBitsToDouble(0x3fd335de4ad8783cL), Double.longBitsToDouble(0x3feff938e1b3e800L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new com.google.gson.TypeInfoFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 5, 5, "\u543e\ud83f\udc84\ud801\udce6\udafd\udd78\udac6\udf87\udb05\udd04\ua820\udb58\udd2a\udbb1\udf79\udb29\udce5\udb9c\ude92\uda1f\udc41\ud9f3\udd4f\ud867\udec5\ud85e\udc7b", "\u608c\u6c56\u7fa9\ua7ed\u04f6\u2012", "\ud940\uddba",
        17, 68423, 1045533475, 2523370089130522627L, -31073L, true, true, (char) 7568, (char) 4650,
        Double.longBitsToDouble(0x3fe713159fe9364dL), Double.longBitsToDouble(0x3fb1d1ee8a692630L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 4, 6, "\ud994\udc09\udb4e\udfda\ud9de\udca4\udbc8\udf93", "\uc4c1\u9b0e\u683c\u6920", "\ud9f3\udd4f\uda72\udf6c",
        52, 60415, 2079712119, 4096879826039782391L, 97666L, false, false, (char) 32730, (char) 59136,
        Double.longBitsToDouble(0x3fe97b610ca4a7e2L), Double.longBitsToDouble(0x3fe32ab29e9f66c7L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[]] |a0=[Ljava.lang.reflect.Type;:[[]]\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 3, 5, "\u543e", "\u513c\u5c96\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u611a\u32d8", "\udae7\udd0d",
        32, 13407, -1407142817, -2766684757413427844L, 43155L, true, true, (char) 60462, (char) 43192,
        Double.longBitsToDouble(0x3fe4fb363f21caebL), Double.longBitsToDouble(0x3fedd1f288032304L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.lang.Integer, class java.lang.Long]] |a0=[Ljava.lang.reflect.Type;:[[class java.lang.Integer, class java.lang.Long]]\0121=com.google.gson.TypeInfoArray:@?\012",
        Z.run(T, 2, 2, 4, 5, "\udaf1\uddcb", "\u513c\u5c96", "\uda9a\udc0f",
        6, 50709, -1391920448, 2830222146305057712L, 84616L, true, true, (char) 34122, (char) 34420,
        Double.longBitsToDouble(0x3fefba0edaf4de90L), Double.longBitsToDouble(0x3feef5290cd454ecL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 5, "\ub13e", "\u5089\ua75c\u1e51\u5f8e\u44c5\u683c\u371a\u1edf\u15e6\u611a\u5348", "\uc7b3",
        26, 90870, -1524522402, 6119542695758253913L, 18989L, true, true, (char) 60462, (char) 23803,
        Double.longBitsToDouble(0x3fe4fb36392849beL), Double.longBitsToDouble(0x3feaec3600032304L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Comparable\0121=java.lang.Class:java.lang.Comparable\012",
        Z.run(T, 2, 1, 1, 5, "\uda5f\ude02", "\u25a3\u5c96\u3cc5\uc4c1\u6cd6\u3f46", "\uda1f\udc41\ud9f3\udd4f\ud867\udec5\ud927\uddc0\uda01\ude7e\ud9f6\udff7\udb20\ude88\ud9e6\udff4\ud833\udd13",
        8, 89364, -1537490956, 5028449518532703483L, 14248L, true, false, (char) 12813, (char) 3595,
        Double.longBitsToDouble(0x3f69182748505200L), Double.longBitsToDouble(0x3fef656f3edf3cc8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new com.google.gson.TypeInfoFactory:@?\0121=com.google.gson.TypeInfoArray:@?\012",
        Z.run(T, 2, 6, 4, 4, "\ud91c\udd1b", "\u513c\u5c96\u3cc5\uc4c1\u230f\u5e75\ua322\u79fe\ua9f6\ud4f0\u4c3e", "\uda3e\ude39\ud98a\udee2\uda2f\ude9f\ud833\udd99\udad6\udec7\ud9be\uddcd",
        33, 93469, -1484093649, -7830839854181666375L, 4671L, false, true, (char) 39687, (char) 20602,
        Double.longBitsToDouble(0x3fe6479945baff0eL), Double.longBitsToDouble(0x3fe012454dc94698L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.google.gson.TypeInfoArray:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 1, "\ud98c\udebe\udb0d\udcf1\ud8c7\udc4b\udbc8\udf93\uda7d\udd4d\uda53\udd0b\ud9b2\udddd\ud9db\udd8e\udbb1\udf79\udb29\udce5", "\u611a\u5c08\u0fac\u5e69\u2e62\u608c\ua2d8\u19de\u7885\u051e\u3739\u40ba", "\uda34\udc73\ud892\udf7e\ud874\udecd\ud916\uddca\udab1\udc17\udb76\udc5f\udb64\udc8f\ud81d\ude14\ud906\udcfb\ud80e\ude0b\udacb\udf75\ud995\udead\uda77\udc6d\udae9\udf9e\ud946\udcbe\ud812\ude0c\u7c38\udac2\ude07\ud95b\udee1\udaee\udcaa\u1c53",
        5, 79090, -445208886, -6676133077451758631L, -1361L, false, false, (char) 65273, (char) 29972,
        Double.longBitsToDouble(0x3fdc9d6fc60d7a38L), Double.longBitsToDouble(0x3fdd43f8d3965780L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.google.gson.TypeInfoArray:@?\0121=com.google.gson.TypeInfoArray:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud868\udfa7", "\u513c\u5c96\u3cc5\uc4c1\u9ac3\ubef8\u59d1\u1edf\u3bf0\u67e6\u1d0f", "\ud858\udec5",
        5, 65847, -1524522252, 6119542924934798548L, 18989L, false, true, (char) 32662, (char) 43246,
        Double.longBitsToDouble(0x3fe4fb363835caebL), Double.longBitsToDouble(0x3fea016cf0032304L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new com.google.gson.TypeInfoFactory:@?\0121=new com.google.gson.TypeInfoFactory:@?\012",
        Z.run(T, 2, 6, 6, 5, "\udb50\ude7b", "\u513c\u32d4\u3cc5\uc4c1\u9b0e\u683c\u5a19\u1edf\u15e6\u4cbf\uc763\ua571", "\uda07\ude60\udb16\udf03\udb7c\udf9b\ud8c4\udcdf\ud883\ude09\uda40\uddc1",
        38, 84245, 1448290732, 7405978705088695967L, -67000L, true, false, (char) 45766, (char) 9137,
        Double.longBitsToDouble(0x3fe74149613bd1afL), Double.longBitsToDouble(0x3fdcf26175bf1826L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class java.lang.String, class [I]] |a0=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class java.lang.String, class [I]]\0121=null\012",
        Z.run(T, 2, 2, 0, 5, "\u543e\ud83f\udc84\ud8c7\udc4b\udbc8\udf93\uda7d\udd4d\udb05\udd04\ud9b2\udddd\ud815\udc6c\ud8df\ude7b\udb29\udce5\u7a94", "\ud188\ubcef\u4169\u2e62\u608c", "\ud8c4\udcdf\ud883\ude09\ud8a1\udf45\ud935\udf2c\ud9b4\uddf8\udb79\udc77\uda48\udf68\ud892\udf7e\ud874\udecd\ud916\uddca",
        19, 69505, -1582444780, -5889514741333533957L, 78184L, true, true, (char) 19962, (char) 54193,
        Double.longBitsToDouble(0x3fc39f48dd3de1a4L), Double.longBitsToDouble(0x3fe425113f02f005L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.TypeInfoFactory|extractTypeForHierarchy|java.lang.reflect.Type,java.lang.reflect.TypeVariable|static",
    "M|com.google.gson.TypeInfoFactory|getActualType|java.lang.reflect.Type,java.lang.reflect.Type,java.lang.Class|static",
    "M|com.google.gson.TypeInfoFactory|extractRealTypes|[Ljava.lang.reflect.Type;,java.lang.reflect.Type,java.lang.Class|static",
    "M|com.google.gson.TypeInfoFactory|getIndex|[Ljava.lang.reflect.TypeVariable;,java.lang.reflect.TypeVariable|static",
    "M|com.google.gson.TypeInfoFactory|getTypeInfoForArray|java.lang.reflect.Type|static",
    "M|com.google.gson.TypeInfoFactory|getTypeInfoForField|java.lang.reflect.Field,java.lang.reflect.Type|static",
    "C|com.google.gson.TypeInfoFactory|<init>|",
    "M|com.google.gson.TypeInfoFactory|extractTypeForHierarchy|java.lang.reflect.Type,java.lang.reflect.TypeVariable|static",
    "M|com.google.gson.TypeInfoFactory|getActualType|java.lang.reflect.Type,java.lang.reflect.Type,java.lang.Class|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
