package com.google.gson.internal.bind;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonAdapterAnnotationTypeAdapterFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:@?\012",
        Z.run(T, 1, 2, 1, 1, "\ud92c\udcdf\udaf0\ude85\ud968\udc36", "\u84e4\u9487\ubd91\ua6bd\u098d\u6a61\uc285\u1b21\u43bf", "\ud90e\ude7c\uda48\udf7f\ud84c\udc15\ud9ab\udfed\ud9a9\udf99\udb91\ude3f\ud80b\udd03",
        33, 48959, -634481578, 8988723471615980924L, 67212L, false, true, (char) 36028, (char) 38305,
        Double.longBitsToDouble(0x3fb4b573c04ed7a8L), Double.longBitsToDouble(0x3fe3e7899d9de2b0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:@?\012",
        Z.run(T, 1, 2, 1, 0, "\ud838\udd24\udaf0\udea3\ud968\udc36", "\u84e4\uaee6\u98c4\u96d4\u098d\u6a61\uc285\u1b21\u43bf", "\ud90e\ude7c\uda48\udf7f\ud84c\udc15\ud9ab\udfed\ud9a9\udf99\udb91\ude3f\ud80b\udd03",
        33, 83839, -634481578, 8988723471615980924L, -58740L, false, true, (char) 36028, (char) 38305,
        Double.longBitsToDouble(0x3fb4b573c04ed7a8L), Double.longBitsToDouble(0x3fe3e7899d9de2b0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:@?\012",
        Z.run(T, 1, 2, 1, 1, "\ud92c\udcdf\udaf0\ude85\ud968\udc36", "\u84e4\u9487\ubd91\u86bd\u3d1f\u8bee\uc285\u1b21\u43bf", "\ud90e\ude7c\uda48\udf7f\ud824\udc15\ud9ab\udfed\ud9a9\udf99\udb91\ude3f\ud80b\udd03",
        33, 82439, 1925223510, -2586606397791472260L, 67212L, false, true, (char) 36028, (char) 38305,
        Double.longBitsToDouble(0x3fb4b573c04ed7a8L), Double.longBitsToDouble(0x3fe3e7899d9de2b0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 1, "\ud92c\udcdf\udaf0\ude85\ud968\udc36", "\u1c5a\u9487\ubd91\ua6bd\u098d\u6a61\uc285\u964e\u4f64", "\ud90e\ude7c\uda48\udf7f\ud84c\udc15\ud9ab\udfed\ud8e4\udd77\uda21\udd10\u9117",
        33, 48959, -634481578, 8988723471615980924L, 67212L, false, true, (char) 36028, (char) 38305,
        Double.longBitsToDouble(0x3fb4b573c04ed6a8L), Double.longBitsToDouble(0x3fe3e7899d9de2b0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 0, "\ud92b\udfe2\udaf0\ude85\u00b8", "\u84e4\u9487\ubd91\u8e36\ucf59\000\uc285\u1b21\u43bf", "\ud90e\ude7c\uda48\udf7f\ud26a\ud9ab\udfed\ud9a9\udf99\udb91\ude3f\000",
        -5, 872, 86, 8988723471615980924L, -100000L, false, false, (char) 768, (char) 17976,
        Double.longBitsToDouble(0x3fb4b573c04807a8L), Double.longBitsToDouble(0x3fe3e7899d9de2b0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 2, "\ud92c\udcdf\udaf0\ude85\ud968\udc36", "\u84e4\u9487", "\uda10\udca6\ud8db\udd74\uda02\udf90\ud8bd\udc6f\uda55\ude4e\ud9f7\udeca\udb8b\udd0c\ud90e\ude7c\uda48\udf7f\ud84c\udc15\ud9ab\udfed\ud9a9\udf99",
        24, 24065, -477677877, 6242477089970099286L, 93916L, true, false, (char) 64730, (char) 11493,
        Double.longBitsToDouble(0x3fec3c49ae694f38L), Double.longBitsToDouble(0x3fb4b573c04ed7a8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 1, "\ud92c\udcdf\udaf0\ude85\udbc2\udf24", "\u7f6e\u9416\ubd91\ua75d\ud695", "\udb91\udd8d\uda6f\uddc2",
        41, 24424, -954921513, -7954427862630542742L, 58610L, true, true, (char) 28505, (char) 60765,
        Double.longBitsToDouble(0x3fe7d83ab57106d0L), Double.longBitsToDouble(0x3fccd697083cd6f8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:@?\0121=new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud92c\udcdf\udaf0\ude85\ud968\udc36", "\u84e4\uc74b\ubdac\u9a4b\u098d\u6a61\u0cc4\ub404\u43bf", "\ud9a5\udf6d\ud863\udfb3\ud84c\udc15\ud933\ude52\ud9a9\udf99",
        24, 24065, -477677877, 6242477089109742678L, 93916L, true, false, (char) 64730, (char) 44171,
        Double.longBitsToDouble(0x3fe66d59170f4d21L), Double.longBitsToDouble(0x3fe728422009daf5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\ud806\ude5c\uda10\udc75\udbf0\udf23", "\u1bd5\u9487\u9ab3\u7951", "\udbb1\udce8\udab0\udee9\uda21\udf5a\ud9f7\udeca\udb8b\udd0c\udb46\udcf7\uda49\udcb2\ud84c\udc15",
        57, 78818, 84625653, -951006519748675016L, -6902L, false, false, (char) 31617, (char) 15644,
        Double.longBitsToDouble(0x3fb12e9529ef24b8L), Double.longBitsToDouble(0x3fdc1e377f3ea46cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 1, "\ud92c\udcdf\udaf0\ude85\ud968\udc36", "\u84e4\u9487\ucb33\u9fff\u0968\u6a61\uc285\u1b21\u43bf", "\ud90e\ude7c\uda48\udf7f\ud84c\udc15\ud9ab\udfed\ud9a9\udf99\udb91\ude3f",
        0, 51123, 1453439959, -2725077625331622816L, 19111L, false, false, (char) 11493, (char) 36028,
        Double.longBitsToDouble(0x3fe34a79c052d5cfL), Double.longBitsToDouble(0x3f83b5eb9f3c4cc0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\ub8fd\uda10\udc75\udb7f\uddca", "\u2bd0\u45ad\ucbdb\u79dc", "\ud97d\udcee\udbaa\udd13\uda21\udf5a\u445b\ud8e0\udc0c\udbad\udeb0\uda49\udd0c\ud82e\udea9",
        57, 78818, 84625653, 4391765095004891098L, -6902L, true, false, (char) 43357, (char) 15644,
        Double.longBitsToDouble(0x3fb12e9529ea6190L), Double.longBitsToDouble(0x3fd39e377d3ea46cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory|getTypeAdapter|com.google.gson.internal.ConstructorConstructor,com.google.gson.Gson,com.google.gson.reflect.TypeToken,com.google.gson.annotations.JsonAdapter|static",
    "M|com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory|create|com.google.gson.Gson,com.google.gson.reflect.TypeToken|new:com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory:com.google.gson.internal.ConstructorConstructor",
    "C|com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory|<init>|com.google.gson.internal.ConstructorConstructor",
    "M|com.google.gson.internal.bind.JsonAdapterAnnotationTypeAdapterFactory|getTypeAdapter|com.google.gson.internal.ConstructorConstructor,com.google.gson.Gson,com.google.gson.reflect.TypeToken,com.google.gson.annotations.JsonAdapter|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
