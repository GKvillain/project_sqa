package com.google.gson.internal;
import org.junit.Test;
import static org.junit.Assert.*;
public class _Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:1802401\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[]\012",
        Z.run(T, 2, 12, 1, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 72627, 2001463390, 7528692732330079211L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:1771653\0121=void\012",
        Z.run(T, 2, 12, 2, 13, "\ud814\ude19", "\ud401\u8a4e\u9c0c\u9a29\u628b\u5fc5", "\ud951\udd6a\udb13\udd47\u78d0\udb3d\ude49\ud87c\ude3a\ud834\udeaf\ud92c\ude98\udb85\udc04\udba7\ude38\ud875\udfe3\ud99f\udd34\ud96a\udf9a\u30e6",
        35, 12860, -252013261, -2159672954571086577L, -23904L, false, true, (char) 63079, (char) 2186,
        Double.longBitsToDouble(0x3fedee6629746001L), Double.longBitsToDouble(0x3fe5cf9eee88ba1fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Class:java.util.Date\012",
        Z.run(T, 2, 4, 10, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud9c7\udc6b",
        38, 72627, 2001463390, 7528692732330079211L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f583f881cL), Double.longBitsToDouble(0x3fe799605cf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Class:int\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 13, "\ud952\udf4e\udafb\udd0d", "\u8a4e\u9c0c\u9a29\u6608", "\ud81f\udc89\u5d2e\ud854\udf65\udbf7\udf24\uda96\ude6d",
        58, 87985, 925585399, 9032457903575656542L, -4789L, false, false, (char) 60907, (char) 38080,
        Double.longBitsToDouble(0x3fcd9470f4cccba4L), Double.longBitsToDouble(0x3fcc9e1f543f881cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void\0121=java.lang.Class:[Ljava.lang.String;\012",
        Z.run(T, 2, 2, 8, 13, "\udbe5\udfe6", "\ud401\u3d46\uc30c", "\uc88e\udac4\udc2f\udbc1\udfd6\ud891\udd21\u16ee\u7934\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        33, 31462, 994830430, 7528692731990078443L, 15641L, true, false, (char) 16499, (char) 48412,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=null\012",
        Z.run(T, 2, 12, 1, 13, "\udbe5\udfe6", "\u637f\ub217\ua62a", "\ud990\uddea\ud85f\ude39\ud81f\udc89",
        25, 93588, -1132268718, -689572501501727279L, -54935L, true, false, (char) 26154, (char) 49522,
        Double.longBitsToDouble(0x3fef5b43dce2bd99L), Double.longBitsToDouble(0x3fb1fd5f330e3550L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 14, "\udbe5\udfe6\ud932\udfe8\ud987\udf01\ud8a2\udf4d\uda15\udc04", "\u1308\u3561\u32a5\u0b4c\uc271\u9d9c\ub5b4\u5ed0\u06c5\ua262\u6fcb\ud05c", "\ud8ca\udc01\ud96b\udc43\u30e6\udbcc\udced",
        6, 81739, -502838259, 3187180809191900915L, -93443L, true, false, (char) 49543, (char) 42154,
        Double.longBitsToDouble(0x3fe1d2f3ddc25452L), Double.longBitsToDouble(0x3fe127ab9dec35d7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:-1226525592\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 11, 6, "\udbe5\udfe6\ud932\udf8b\ud987\udf01\ud8a2\udf4d\ud9cc\udc1e\ud941\udf89\udb46\udeb0\udb1c\uddae\ud990\uddea\ud85f\ude39\ud830\ude5d\u5d2e\uda10\ude24\u9fa7\udbee\udc3c\ud91c\udd29\ud802\udc32\ud916\udf37\udb85\udc04\udb0b\udf65\uda5c\udd8a\udac9\udf8c\ud87a\udec7\ud8eb\ude5a\udbcc\udced\ud829\udfec\uda13\uddc9\ud89f\udcf2\ud906\udef6\ud9f4\ude92", "\u7565\u5e6f\ub0c5\u9f01\u27b7\u30ac\ua2b1\u4ca1\ud41c\u2f46\u45f3\u1677\ud4a7", "\uda59\udcce\ud8fc\udc7e\ud85d\uded4\ud9aa\udf68\ud954\udf5b\udaec\ude14\ud8b2\udd9e\ud9de\udf2c",
        37, 79673, 840892981, -8686483211234565929L, 47019L, false, true, (char) 40479, (char) 50510,
        Double.longBitsToDouble(0x3fec2fc3dbf94744L), Double.longBitsToDouble(0x3fdbf635e3381984L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[][]\012",
        Z.run(T, 1, 0, 0, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 50699, 1934330492, 7528692732330079211L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.ArrayList<int[], java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [I, class java.util.ArrayList]]\0121=java.lang.Class:int\012",
        Z.run(T, 2, 14, 6, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud8ff\udf04\uda7f\udd31\u5d2e\udaa0\ude6a\u7971\uda96\ude6d\ud8d3\udfd8\ud801\udfa9",
        19, 72627, -1437865890, 7528692732330078699L, 15641L, false, true, (char) 40103, (char) 51181,
        Double.longBitsToDouble(0x3fcc9e1f583f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 11, 5, "\udbe5\udfe6", "\uc59b\u8a82\u4d2d", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5ce6\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 72627, 2001463390, 7528693482250614507L, 15641L, true, false, (char) 9521, (char) 51121,
        Double.longBitsToDouble(0x3fc55d5f543f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 13, 5, 13, "\ua66a", "\ud401\u8a4e\u9c0c\uc24a\u6608\u58e9\u93cf\u17be", "\uda14\udcc0\uda96\ude6d\uda78\udf26\ud802\udc42\ud916\udf37\ud916\uddff\udb0b\udf65\ud866\udc4f\ud8ca\udc01\ud96b\udc43\u30e6\udbcc\udced\ud937\udf58\udad6\ude97\ud926\udc14\udaed\udffe\udb3a\udea6\ud91e\ude6d\uda81\udff9\udb6d\uddac\ud999\udfd2\ud87d\udd42\ud849\udcdc\ud874\udfaa\ud820\ude1a\ud853\ude9d\ud8f2\udd6d\udb23\uddad\uda47\udd3c\ud80e\ude0c\udb01\uddf7\udac7\ude89\udaf7\udc36\udad6\udeb4\ud82a\udff5\ud806\udf7d\ud940\udfa2\ud9dc\udc74\uda1a\udc9d\ud98b\ude57\udbd6\uddf0\ud89a\udef3\udbd3\udea3\ud80d\udebc\ud9e3\ude2a\ud993\udd16\ud8cd\udfbe\uda84\udf64\udbd8\udc91\u638d\udb97\udea6\ud825\udd84\udb49\udc4e\ud8cd\ude1a'\udaeb\udfc1\udb0f\udffc\ud864\uddf0\ud9d9\udd71\udb5f\udd80\udbb5\udef1\ud9c5\udf89\uda5d\udc78\udbd9\udf63\udaad\uddf7\udb22\udfcb\uda7b\udf69",
        42, 60734, -435332945, 2554978428486152059L, 95827L, false, false, (char) 3020, (char) 10551,
        Double.longBitsToDouble(0x3feec6733fab1c03L), Double.longBitsToDouble(0x3fd313ee848566e2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 7, 10, "\udbe5\udfe6", "\ud401\u796b\u9c15", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\ud8a6\udc06\uda96\ude6d\ud8d4\udc0d\uc080",
        2, 16847, 2001463390, 7528692733152162795L, 15581L, true, false, (char) 47952, (char) 58242,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 8, "\ud81b\udfca", "\ud401\u8a4e\u2ebb", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 1699, 2001463429, 7528692732330079211L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f543ff81cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:345483536\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String |a2=[Ljava.lang.reflect.Type;:[[]]\012",
        Z.run(T, 2, 12, 14, 2, "\udbe5\udfe6\ud932\udfe8\ud987\udf01\ud8a2\udf4d\uda4b\udd04\ud932\ude4d\ud956\udf14\udb1c\uddae\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9\ud916\udf37\udb85\udc04\udb0b\udf65", "\u206c", "\ud829\udfec\ud961\udc50\udb4a\udf1f\ud921\udfaa\udb3a\udea6\ud918\uddc9\ud92b\udeee\ud85e\udfbc\ud9c9\ude47\ud8cf\udc36\udaf8\udf38",
        28, 84798, 211043468, 5045854511344304253L, -1699L, false, false, (char) 14565, (char) 59621,
        Double.longBitsToDouble(0x3fef06fa08d8c6e5L), Double.longBitsToDouble(0x3fde66c07f1bd352L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.ArrayList\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 13, "\uda5d\udcc3\ucc7d\ud9cf\udd44\udb87\udd06", "\ua00e\u0bf7\uc2e9", "\u5d2e\uda10\ude24\u68fd\ud979\udd60\ud8ef\udea3\ud83b\udcdb\uda34\udd41\ud8a0\udcf6\udbbf\udc62\uda4d\udf0e\ud8b5\udcae\ud92a\udc23\u30e6\udbcc\udd5e\udae1\udfb1\ud97c\udda4\ud84d\udde1\uda54\udc3e\ud874\udd57\ud9ff\ude19\ud9c9\udd9c\udb63\udf28",
        -5, 45989, 1333985389, -7046954190104636795L, 37811L, true, false, (char) 7723, (char) 5777,
        Double.longBitsToDouble(0x3fd4d2099d77b704L), Double.longBitsToDouble(0x3fe95a01af3bb6ddL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:1802401\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Long<java.lang.Thread$State, java.lang.Long> |a2=[Ljava.lang.reflect.Type;:[[class java.lang.Thread$State, class java.lang.Long]]\012",
        Z.run(T, 2, 12, 14, 5, "\udbe5\udfe6", "\ud401\ud70f\u1f7c", "\ud990\uddea\udb79\udf66\uda36\udde8\u5caa\uda10\ude24\u7902\udb04\udf6b\ud8d4\udc0d\ud801\udfa9",
        25, 41914, 2001463390, 7528692732330079211L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79e69dcf73e1bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:24728\0121=java.lang.Class:java.lang.Integer\012",
        Z.run(T, 2, 12, 11, 13, "\u6098", "\u9af5\u89e5\u94d1\u9a29\u6608\u58e9\u32a5\u17be\ua834\u9d9c\ub5b4\u37a7\u06c5\ua262", "\ud8f1\udd7d\ud8ed\udc53\ud8ca\udc01",
        15, 99562, -1553658574, 3668635908644181299L, -76719L, true, false, (char) 970, (char) 37428,
        Double.longBitsToDouble(0x3fec7e3277642353L), Double.longBitsToDouble(0x3fee2e12527a723cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:1802401\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 9, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud880\ude56\ud801\udfc7",
        19, 72627, 2001463390, -2235955684739288087L, 46503L, true, false, (char) 18045, (char) 51238,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79eb9daf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.util.List<E>\0121=java.lang.Class:int\012",
        Z.run(T, 2, 11, 6, 9, "\udbe5\udfff", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 61763, -1274738132, 1517049887409665003L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 12, 12, "\udbe6\udc64\ud932\udfe8", "\u8a4e\u9c0c\u9a29\u65fc", "\ud81f\udc89\ub02e\uda10\ude24\u7902\uda96\ude6d",
        58, 87985, 925585399, 9064827525897381982L, -4789L, false, false, (char) 12740, (char) 38155,
        Double.longBitsToDouble(0x3fcd9470f4cccba4L), Double.longBitsToDouble(0x3fcc9e1f543f881cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Comparable\0121=java.lang.Class:java.lang.Comparable\012",
        Z.run(T, 2, 10, 1, 13, "\u01e7", "\ud401\u8a4e\u9e51", "\ud813\udd6b\ud85f\ude39\ud81f\udc89\uda7e\udee1\ud9f4\udc39\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9\ud99f\udee7\ud8dc\udf8d\uda98\uddca\ud8e6\udc9d",
        50, 31345, 1295492483, -5849271436958059686L, -54148L, true, true, (char) 29486, (char) 970,
        Double.longBitsToDouble(0x3fe4920173cf0983L), Double.longBitsToDouble(0x3fd0e210a8eec042L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 4, 0, "\ud8a5\udf22\ud932\udfe8\ud904\udf13\ud8a2\udf8f\ud93f\udc84", "\u48a3\u2c0e\u32a5\u17be\ua834\uad4d\u5d22\u37a7\u68da\ua262\u095a\u39b4\u15c2\u0dfc\ud181\uaeab\u2b7a\u3748\u4f34\u4e31\u19e7\ua64e\u6c5b", "\ud8d2\udebe\ud99e\udedb\ud932\udd7b\uda5a\ude20\ud98c\udf2f\ud968\udc55\uda6e\ude36\ud81a\ude9c",
        26, 69562, 604264792, -625783542447845862L, 69670L, false, true, (char) 11266, (char) 60131,
        Double.longBitsToDouble(0x3fe9d40c8ce68b12L), Double.longBitsToDouble(0x3fc16583470786e0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:1774366\0121=java.lang.Class:int\012",
        Z.run(T, 2, 12, 8, 13, "\ud872\udd50", "\ud401\u8a4e\u9c0c", "\udb7a\ude36\ud8be\uded6\ud824\ude89\uda96\ude9b\uda73\ude63\uda59\udf35\ud9d7\udc2e\ud820\udf77\ud801\udff4",
        19, 72627, 1690554056, 7527567675826857655L, -78512L, true, true, (char) 32791, (char) 62723,
        Double.longBitsToDouble(0x3fcc9e1fb43f881cL), Double.longBitsToDouble(0x3fe79961ded53ed3L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 13, "\udb5c\udc47", "\ub0ae\u5291\u41b2\u5dd1\u245b\u58e8\u2b8b\u17be\ua834\u9d9c\ub5b4\u8343\u588d\u7184\u095a\u59c8\u963e\u9b3b\u2c6e", "\udbcc\udced\ud829\udfec\ud961\udc50\udb4a\udf1f\ud921\udfaa",
        17, 67279, 611187073, -2653882429843109438L, -89682L, false, true, (char) 37220, (char) 16328,
        Double.longBitsToDouble(0x3fbb0b7095691f88L), Double.longBitsToDouble(0x3f92c59e82cb3400L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.ArrayList<int[], java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [I, class java.util.ArrayList]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.ArrayList<int[], java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [I, class java.util.ArrayList]]\012",
        Z.run(T, 2, 14, 14, 13, "\udbe5\udfe6", "\ud401\u8a4e\ub80d", "\udb4b\ude27\ud856\udcb7\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 72627, 2001463390, 7528692735212492010L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fe7f347d50fe207L), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:351590746\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 12, 13, 10, "\udbf0\ude07\udb1f\udeb1\ud97f\udf01\ud8a2\udf4d\uda4b\udd04\ud932\ude4d\ud847\udd5a\udb1a\uddd0\uda26\udd34\udbc7\udcce\ud82a\udd16\u5d2e", "\u37a7\u06c5\ua262\u79e3\u478e\ub90d", "\ud96b\udc43\ud8aa\udf14",
        11, 12860, -252013261, -2159672953422502641L, 15959L, true, false, (char) 9337, (char) 26735,
        Double.longBitsToDouble(0x3fde0239a8e8c244L), Double.longBitsToDouble(0x3fe1e26bfe19d10fL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:1705773327\0121=java.lang.Integer:1705773327\012",
        Z.run(T, 2, 12, 12, 2, "\ud839\udf72\ud932\udfe8", "\u8a4e\u9c0c\u9a29\u6608", "\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d",
        58, 87985, 925585399, 9064827524850968670L, -4787L, false, false, (char) 9048, (char) 38155,
        Double.longBitsToDouble(0x3fcd9470f4cccba4L), Double.longBitsToDouble(0x3fcc9e1f543f881cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 4, 13, "\000", "\000", "\udb46\ude9a\udb1c\uddae\ud990\uddea\udb5c\udf77",
        -5, -1000, 0, 0L, 30231L, true, true, (char) 48325, (char) 32000,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcc57b3311fd400L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 0, "\uda57\udc3f", "", "\ud932\ude1d",
        44, 48688, 230, 881917952L, -34724L, false, false, (char) 0, (char) 25920,
        Double.longBitsToDouble(0x3fea4c69b7f7c27eL), Double.longBitsToDouble(0x3f2b958000000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:1989592512\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:char<java.lang.Comparable> |a2=[Ljava.lang.reflect.Type;:[[interface java.lang.Comparable]]\012",
        Z.run(T, 2, 12, 14, 4, "\ud988\udd64\uda3b\udd8b\ud868\udf69\ud8a2\udfd5", "\u9a29\u6608\u926f\u11ea", "\uda10\ude24\u7902",
        22, 54473, -1031929015, 3975359020470680731L, -87297L, false, false, (char) 47784, (char) 15839,
        Double.longBitsToDouble(0x3fd0fe207c5c5876L), Double.longBitsToDouble(0x3fcee7da7c0194d0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[][]\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[][]\012",
        Z.run(T, 2, 0, 0, 0, "\udbe5\udfe6", "\000\000\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u00c4\ud9d0\udf28\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 72627, 94, 7493989779944505344L, 15641L, true, false, (char) 40306, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f543c0000L), Double.longBitsToDouble(0x3eadcf7000000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[]\012",
        Z.run(T, 2, 7, 1, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 72627, 2001463390, -5297559006421060532L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f51b0901cL), Double.longBitsToDouble(0x3fd323e939ee7d28L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Class:[I\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 8, 13, 14, "\udbe5\udfe6\ud932\udfe8\udad9\udca9\udab9\udf4a\ud99a\udeaa\ud932\ude4d\udb46\udf0c\udb1c\udd23\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d", "\u39b4\u15c2\u8ba6\u0cf7\u206c\ub052\u78c8\u7143\u5365\u395e", "\ud907\udcb1",
        4, 58135, 781179817, -637720417753008410L, 70359L, true, false, (char) 59871, (char) 20441,
        Double.longBitsToDouble(0x3fc267edbf1fb734L), Double.longBitsToDouble(0x3fce27629a51bb44L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:1684104751\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 2, 0, "\ud99c\udd7e\u3def\ud987\udf01\ud8a2\udf4d\uda4b\udd04\ud932\ude4d\udb6e\ude0c\ud90b\udd61\ud94f\udf0d\ud846\udda2\ud8bf\udc36\udaa7\udc4b", "\u570f", "\ud92c\ude98\udb85\udc04\udba7\ude38\ud875\udfe3\ud99f\udd34\ud96a\udf9a\u30e6\udbcc\udced\ud8c5\udeda\ud834\udd98\udb4a\ude69\ud9ce\udfa1\udba2\udce6\uda82\udde2\ud90d\udcf7\ud8e1\ude15",
        30, 95256, -859502480, 6917942156046758260L, -34088L, true, true, (char) 19811, (char) 3743,
        Double.longBitsToDouble(0x3fe96cd903bf937eL), Double.longBitsToDouble(0x3fe723456895aa11L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 12, 12, 13, "\ud814\ude19", "\u3bca\u8a4e\u9c0c\u9a29\u628b\u5fc5", "\u00c4\udb13\udd47\u78d0\udb3d\ude49\ud87c\ude3a\ud834\udeaf\ud92c\ude98\udb85\udc04\udba7\ude38\ud875\udfe3\ud99f\udd34\ud96a\udf9a\u30e6",
        35, 58060, 0, -419430400L, -23904L, false, true, (char) 63079, (char) 2186,
        Double.longBitsToDouble(0x3fedee6629746001L), Double.longBitsToDouble(0x3fe5cf9eee88ba1fL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<java.lang.Number, java.lang.Comparable, java.lang.Thread$State> |a2=[Ljava.lang.reflect.Type;:[[class java.lang.Number, interface java.lang.Comparable, class java.lang.Thread$State]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<java.lang.Number, java.lang.Comparable, java.lang.Thread$State> |a2=[Ljava.lang.reflect.Type;:[[class java.lang.Number, interface java.lang.Comparable, class java.lang.Thread$State]]\012",
        Z.run(T, 2, 14, 14, 7, "\ud814\ude19", "\ud401\u8a4e\u5935\u2cf8\u6218\u5fc5", "\ud951\udd6a\uda6a\udc61\udbb4\uddb1\udb3d\udde6\ud87c\ude3a\ud834\udeaf\ud92c\ude98\udb85\udc04\ud998\ude46\ud875\udfe3\uda5c\ude72\ud967\udf73\u30e6",
        35, 12860, -252013261, -2159672954571086577L, -23904L, false, true, (char) 63079, (char) 2186,
        Double.longBitsToDouble(0x3fedee6629746001L), Double.longBitsToDouble(0x3fe5cf9eee88ba1fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Comparable<java.lang.String>\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:java.lang.Long[]\012",
        Z.run(T, 2, 11, 0, 7, "\ud962\udf7c\udbdc\ude1a", "\u8bfd\u9c0c\ub358\ub1e7", "\uda2e\udd6e\udafd\udf57\ud936\udfc8\u4713\udb3d\ude49",
        12, 24486, 925607768, 9064827524424057950L, -49740L, true, false, (char) 12740, (char) 38155,
        Double.longBitsToDouble(0x3fc6d470f4cccba4L), Double.longBitsToDouble(0x3fcc9e1f543f881cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 10, 13, "\udac3\ude71", "\ud463\u8be2\uc04d\u9a29\u62bc\u5fc5\u153c\u8340\u5cf2\u95ba\ub582\u570f\u3bb7\ua321\u2514\u39b4\u41ad\uc4f8\ud073\u1fc3\ub052\u78c8\u7143\u5365\u395e\ua5db\u905a\u28fa\uc815\u5279\ua9d0", "\ud971\udd65\udba9\udc33",
        10, 86104, -130667628, 6424901400241252341L, 82075L, true, true, (char) 5830, (char) 42154,
        Double.longBitsToDouble(0x3f7e566440d7c100L), Double.longBitsToDouble(0x3fc0f561b8c901d0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 2, 2, 13, "\ud835\ude19", "\ud401\u8a4e", "\ud90b\uddb5\udb51\udd15\udb18\udd97\uda31\udf66\ud951\udd6a\udb13\udd47\u78d0\udb3d\ude49\ud87c\ude3a\ud834\udeaf\ud92c\ude98\udb85\udc04",
        53, -384, 121846700, -757558470207980473L, -74636L, false, true, (char) 9976, (char) 34582,
        Double.longBitsToDouble(0x3fe0973e2cfa7e59L), Double.longBitsToDouble(0x3fe07e5c5c1ad38fL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<java.lang.Thread$State>\012",
        Z.run(T, 2, 6, 11, 1, "\ud9c1\uddb2\uda1f\uddde", "\u8a4e\u9c0c\u7b9c\u62af", "\uda31\udf8f\ud951\udd6a\udb13\udd47\u78d0\udb3d\ude49",
        12, 38959, 925607768, 9064827524424057950L, -49740L, true, false, (char) 12740, (char) 38155,
        Double.longBitsToDouble(0x3fd43bf87a666592L), Double.longBitsToDouble(0x3fcc9e1f42debdf8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Long<java.lang.Number, java.lang.Long, java.lang.Object> |a2=[Ljava.lang.reflect.Type;:[[class java.lang.Number, class java.lang.Long, class java.lang.Object]]\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 14, 8, 13, "\uda07\ude9e", "\ud401\u8a4e\u9c0c\u9a29\u628b\u5fc5", "\ud951\udd6a\udb13\udd47\u78d0\udb3d\ude49\ud87c\ude3a\ud834\udeaf\ud92c\ude98\udb85\udc04\udba7\ude38\ud875\udfe3\ud99f\udd34\ud96a\udf9a\u30e6",
        35, 58308, -256132041, -2159672954571086577L, -23904L, false, true, (char) 63079, (char) 2186,
        Double.longBitsToDouble(0x3fedefd629746001L), Double.longBitsToDouble(0x3fe5cf9eee88ba1fL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 5, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c\u9a29\u932b\u22d5\uc661\ua02c\u0b4e\u9d9c\u2bed\u37a7\u06c5\uc21a\u08aa", "\ud8e6\udc4f\ud8ca\udc01\ud96b\udc43\u30e6\udbcc\udced\ud829\udfec",
        20, 10037, 1553874885, 4527039670599271671L, 67033L, false, true, (char) 42116, (char) 63071,
        Double.longBitsToDouble(0x3fe43987ef598859L), Double.longBitsToDouble(0x3fd4fcc0d8a4a4b2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Class:char\0121=java.lang.Class:char\012",
        Z.run(T, 2, 10, 10, 13, "\udbe5\udfe6", "\ud401\u8b7e\uc4cc", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud9c7\udc6b\ud916\ude87\udb85\udc04\udb0b\udf65\ud8e6\udc4f\ud8ca\udc01\ud975\udfa8\u30e3\udbcc\udced\ud829\udfec\ud961\udc50\udb4a\udf1f\ud9f0\udca7\udb3a\udea6\ud851\udda6",
        27, 29987, 1103517425, -7957952219368101247L, -93227L, true, false, (char) 9526, (char) 41272,
        Double.longBitsToDouble(0x3fdeca1a802e7460L), Double.longBitsToDouble(0x3fe28e3bdac96debL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Thread$State<java.lang.Integer, java.lang.Thread$State, java.lang.Thread$State> |a2=[Ljava.lang.reflect.Type;:[[class java.lang.Integer, class java.lang.Thread$State, class java.lang.Thread$State]]\0121=java.lang.Class:java.lang.Integer\012",
        Z.run(T, 2, 14, 11, 13, "\ud952\udf4e\udac6\udc19", "\u8a4e\u9c0c\u9a29\u6608", "\ud81f\udc89\ud87a\udc7f\ud854\udf65\udbf7\udf24\uda96\ude6d",
        29, 48857, 925585399, 9026828404041443422L, -4789L, false, false, (char) 60907, (char) 38080,
        Double.longBitsToDouble(0x3fcd9470f4ce5ed8L), Double.longBitsToDouble(0x3fcc9e1f543ed05cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.ArrayList |a2=[Ljava.lang.reflect.Type;:[[]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.ArrayList |a2=[Ljava.lang.reflect.Type;:[[]]\012",
        Z.run(T, 2, 14, 14, 7, "\uda77\udf66\udafb\udd0d\udaf4\ude8d", "\u48f4\u9a29\u6608", "\ud81f\udc89\ud804\udc41\ud854\udf65\uda5f\udcd1\uda2c\udd68\uda24\udc9f\uda15\uddf3\udb77\udfc3\uda0b\udc69",
        25, 31831, -1114016964, -5672449886739874652L, 56436L, true, false, (char) 30829, (char) 51080,
        Double.longBitsToDouble(0x3f90462483670c20L), Double.longBitsToDouble(0x3fe275656ae3e3e7L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:java.lang.String[]\0121=java.lang.Class:java.lang.Comparable\012",
        Z.run(T, 2, 1, 8, 0, "\u07a7\udafb\udc81", "", "\udb46\udf0c\udb1c\uddae\000\ud902\udec1",
        48, 3660, 65276, 0L, 30231L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3f5b4000000000L), Double.longBitsToDouble(0x3fcc57b33292c51cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Class:[Ljava.lang.String;\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 11, 13, "\udbe5\udfe6", "\ud401\u3d46\uc30c", "\uc88e\udac4\udc2f\udbc1\udfd6\ud891\udd21\udb9c\udc95\u7934\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        33, 31462, 994830430, 7528692731990078443L, 15641L, true, false, (char) 16499, (char) 48412,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Class:[Ljava.lang.String;\0121=java.lang.Class:[Ljava.lang.String;\012",
        Z.run(T, 2, 8, 8, 0, "\udbe6\udc61", "\u4307\uc819\uc30c", "\uc88e\udac4\udcbd\udbc1\udfd6\ud891\udd21\u16ee\u78d6\uda74\udd6d\ud8d4\udc0d\ud801\udfa9",
        46, 45357, 994830430, 7545487772104356843L, -4700L, false, true, (char) 54524, (char) 58888,
        Double.longBitsToDouble(0x3fee3f87d7320f07L), Double.longBitsToDouble(0x3fe5824514f73e91L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 7, 5, 0, "\ud93f\udc8a\ud8b1\udc09", "\ub217\ub50c\u5aaf\uab6e", "\udb60\udd30\u5d2e\ud8d6\udc27\ud8e7\udfc5\uda69\udd13",
        -5, 87985, 925585399, 9064827525897381982L, -4789L, false, false, (char) 12740, (char) 10764,
        Double.longBitsToDouble(0x3fe87f50b3bac747L), Double.longBitsToDouble(0x3fc28a6521ca6fd8L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 6, 6, "\ud92e\udd0b", "\u4e19\u90fd\u9ae3\u128e\u4610\u5312\uc67b", "\ud89e\udde9",
        55, 33444, -1591956015, 1056895189749993976L, -94103L, true, false, (char) 21154, (char) 12222,
        Double.longBitsToDouble(0x3fe2ca00be36c72cL), Double.longBitsToDouble(0x3fd5a75fff48bf70L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:-916814754\0121=java.lang.Class:[I\012",
        Z.run(T, 2, 12, 11, 6, "\u4658\ud904\udf8b\ud987\udf01\uda2c\udf52\u0ccc\ud941\udf89\udb46\udeb0\udb1c\uddae\ud990\uddea\ud85f\ude39\ud830\ude5d\u5d2e\uda10\ude24\u9fa7\udbee\udc3c\ud91c\udd29\ud802\udc32\ud916\udf37\udb85\udc04\udb0b\udf65\uda5c\udd8a\udac9\udf8c\ud84d\udcaf\ud8fb\udcaf\udbcc\udced\ud829\udfec\uda13\uddc9\ud89f\udcf2\ud906\udef6\ud9f4\ude92", "\u6652\u2648\ub0c5\u9f01\u27b7\u30ac\ua2b1", "\ud886\udd9e\udb9b\udcd7\udb9d\udf7c\uda8e\udff8\udab9\udf10\uda0b\udf50\uda59\udcce\ud8fc\udc7e\ud85d\uded4\udaa6\udc45\ud954\udecd\udb3e\udc5e\ud8b2\udd4c\ud9de\udf2c\udade\udf05\ud841\uddd2\ud86b\udd29\ud924\ude70\udbf1\ude6b\udb56\ude83\ud8d6\ude70\uda88\ude91\udbf4\udf28",
        33, 29622, 906751886, 1249254438784813030L, 87385L, true, true, (char) 63069, (char) 19464,
        Double.longBitsToDouble(0x3fe3bc6ce9717577L), Double.longBitsToDouble(0x3fc45a412beeb504L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.ArrayList<int[], java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [I, class java.util.ArrayList]]\0121=java.lang.Class:java.lang.Comparable\012",
        Z.run(T, 2, 14, 8, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud8ff\udf04\uda7f\udd31\u5d2e\udaa0\ude6a\u7971\uda2e\udce5\ud89c\udf97\ud801\udfa9",
        19, 72627, -1437865890, 7528692732330078699L, 15641L, false, true, (char) 40103, (char) 51181,
        Double.longBitsToDouble(0x3fcc9e1f583f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 11, 12, "\udbe5\udfe6", "\u2d84\u1f77\u4df9", "\ud990\uddea\udba3\udcef\u7a85\u5ce6\uda10\ude24\ud93d\udfb2\uda91\udd7f\ud8d4\udc0d\ud801\udfa9",
        19, 72627, 2001463390, -746389361019402216L, -44829L, false, false, (char) 49622, (char) 51234,
        Double.longBitsToDouble(0x3fdaaeafa324fd5cL), Double.longBitsToDouble(0x3feadde35ab8b4beL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.ArrayList<int[]> |a2=[Ljava.lang.reflect.Type;:[[class [I]]\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 14, 11, 5, "\uda9e\udce3", "\uc59b\u8a82\u4d2d", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5ce6\ud93a\udef9\udbd6\ude16\uda96\udda9\ud8d4\udc0d\ud801\udfa9",
        19, 72627, -842256979, -1022095759138683419L, 36430L, true, false, (char) 9521, (char) 27058,
        Double.longBitsToDouble(0x3fc55d5f543f881cL), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\012",
        Z.run(T, 2, 7, 7, 12, "\udbe5\udfe6\ud932\udfe8\ud987\udf01\ud8a2\udf4d\ud84e\ude25\ud932\ude56\udb46\udf0c\udb1c\uddae\ud990\uddea\uda1d\udeff\udbcf\ude47\uda21\udd0a", "\u37a7\u06c5\u942a\ubaec\u912a\ucf3c", "\ud965\ude7f\u3122\udb87\udf79\ud9e7\udd50\ud961\udc50\udb69\udced\uda7e\udfd9\ud813\udcb3\uda74\udc5c\udb9e\udcd6\uda7d\udc77\uda21\udf53\uda71\udfc8\udbff\udc5a",
        42, 73826, -366485850, 8819341514178662433L, -7181L, false, false, (char) 45772, (char) 11588,
        Double.longBitsToDouble(0x3fe570dcbf91c61dL), Double.longBitsToDouble(0x3fe88aea8c823467L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 11, 11, 13, "\u6098", "\ud71c\u9ea3\u5f1c", "\uda43\udc88\ud85f\ude39\ud88d\udee0\udbbb\udd17\uda61\uddf3\ud9ea\uddda\uda48\udf53",
        42, 3207, -977331947, -7655859734799003104L, 85067L, true, false, (char) 38697, (char) 16127,
        Double.longBitsToDouble(0x3fdec676fe70ecb8L), Double.longBitsToDouble(0x3fc4de1df43f8af8L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String[]<java.util.Date, java.lang.String[]> |a2=[Ljava.lang.reflect.Type;:[[class java.util.Date, class [Ljava.lang.String;]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String[]<java.util.Date, java.lang.String[]> |a2=[Ljava.lang.reflect.Type;:[[class java.util.Date, class [Ljava.lang.String;]]\012",
        Z.run(T, 2, 14, 14, 5, "\udbe5\udfe6", "\ud401\u8a4e\u7765", "\udb4b\ude27\ud856\udcb7\ud9ef\ude8d\u5d12\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud895\udd53",
        -4, 72680, 2001463390, 7516515643934872810L, 15641L, true, false, (char) 16499, (char) 1267,
        Double.longBitsToDouble(0x3fe7f342fd0fe207L), Double.longBitsToDouble(0x3fe79961dcf73ed3L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Class:[I\0121=java.lang.Class:[I\012",
        Z.run(T, 2, 11, 11, 10, "\udbf0\ude07\udb1f\udeb1\ud97f\udf01\ud89e\udc18\uda4b\udd04\ud932\ude4d\ud847\udd5a\udb1a\uddd0\uda26\udd34\udbc7\udcce\ud974\udf5a\u5d2e\uda10\ude24\ud98f\udfda\uda96\uddb4\ud8d4\udc0d\ud801\udfa9", "\ub90d\u45b0\u5e57\u206c\u142d\u7932\u7143\u5365\u395e", "\ud91f\ude74",
        19, 70013, 2136111123, 6999207212283311220L, 21335L, true, true, (char) 32920, (char) 61309,
        Double.longBitsToDouble(0x3fe122e2e00261bcL), Double.longBitsToDouble(0x3febb0eb6321df28L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 4, 13, "\000", "\000", "\udbaf\udf66\uda7d\udd72\ud870\udd1c\udabc\uded2",
        46, -1000, 1051656192, -1028775925887521024L, 30231L, true, true, (char) 48325, (char) 31659,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcc57b32387d400L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 2, 2, 13, "\000", "\000", "\udb46\ude9a\udb1c\uddae\ud990\uddea\udb5c\udf77",
        41, -975, 0, 0L, 30231L, true, true, (char) 48325, (char) 32000,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcc57b3311fd400L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 7, 13, 12, "\ud897\udd9f", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 72627, 2001463390, -5297559006421060532L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f51b0901cL), Double.longBitsToDouble(0x3fd323e939ee7d28L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\012",
        Z.run(T, 2, 7, 7, 0, "\udbe6\udca8", "\u2444\ud7f4\uc3ed\u3385\ub058\u58e9\uc21c\u2ffb\ua834\ucd63\u4302\u37a7\u06c5\ua262\u7a63\u63a8\ubdf1\u7b04\uad99", "\uda24\udf11\ud81c\ude11\ud857\udf56\uda87\udccc\ud808\udc1c\ud907\udf94\ud8ae\udee4\ud97b\uddf6\udbb0\ude36\ud93b\uddbe",
        45, 3243, -1914666792, 898052790928442639L, 12523L, true, false, (char) 7023, (char) 24355,
        Double.longBitsToDouble(0x3fcd2af8ae561d84L), Double.longBitsToDouble(0x3fe41f31fbf72e56L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Long<java.lang.String[], java.lang.Long, int[]> |a2=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class java.lang.Long, class [I]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Long<java.lang.String[], java.lang.Long, int[]> |a2=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class java.lang.Long, class [I]]\012",
        Z.run(T, 2, 14, 14, 13, "\ud814\ude19", "\u1e31\u8a4e\u709c", "\ud9b6\udd16\ud846\udda2\uda31\udf8f\ud951\udd6a\uda6a\udc61\udbb4\uddb1\udae9\udc7c\udbaa\udcb1",
        34, 42768, 2110569627, 2332891398914033698L, -87297L, false, false, (char) 51227, (char) 46046,
        Double.longBitsToDouble(0x3fd0fe207676638aL), Double.longBitsToDouble(0x3fcf4c5e983f2e2cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Comparable<java.lang.String>\0121=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Comparable<java.lang.String>\012",
        Z.run(T, 2, 11, 11, 7, "\ud962\udf7c\udbdc\ude1a", "\u5807\ud11a\ub30a\ub1e7", "\udafe\udf55\udafd\udf57\ud936\udfc8\u4713\udb3d\ude49",
        12, 24486, 925607768, 9064827524424057950L, -49740L, true, false, (char) 12740, (char) 38155,
        Double.longBitsToDouble(0x3fc6d470f4cccba4L), Double.longBitsToDouble(0x3fcc9e1f543f881cL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Comparable<E>\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<java.lang.Thread$State>\012",
        Z.run(T, 2, 8, 11, 6, "\ud9c1\uddb2\uda1f\uddde\ud97e\udee1\ud8a2\udf4d", "\u7b9c\u62af\u5fc5\u3deb", "\udb13\udd47\u78d0\udb3d\ude49",
        49, 27311, 925607768, 9064827525732663825L, -5882L, true, true, (char) 64856, (char) 38155,
        Double.longBitsToDouble(0x3feae8e9d05a3497L), Double.longBitsToDouble(0x3fcc9e1f42debdf8L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Thread$State<int[], java.lang.Thread$State, java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [I, class java.lang.Thread$State, class java.util.ArrayList]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Thread$State<int[], java.lang.Thread$State, java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [I, class java.lang.Thread$State, class java.util.ArrayList]]\012",
        Z.run(T, 2, 14, 14, 8, "\uda77\udf66\udafb\udd0d\udaf4\ude8d", "\ua74f\u99da\u45bd", "\ud97b\udcfc\ud80b\udd7e\ud854\udf65\uda5f\udcd1\ud939\udd9d\uda26\udfd7\uda15\uddf3\ud962\udf98\uda0b\udd29\udb0b\udf65\uda88\udd40\ud8d1\udc52\ud953\udc3e\u3143\udbcc\udca2",
        5, 98011, -1459724173, 3263204202156590481L, 71865L, true, false, (char) 30024, (char) 49272,
        Double.longBitsToDouble(0x3fd86fb917fbb27cL), Double.longBitsToDouble(0x3fd79f1c58dda014L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 5, 0, "\ud93f\udcd9\ud8b1\udc09\udb62\udd9d\udba1\ude4b\udb01\udd54\ud8f1\ude34\ud87d\udd6a\ud9b4\udf95\udaad\udf4f\udb54\udfd3\udae5\udc5e\u5d2e", "\u1fb0", "\udb15\udca1\udb5e\udeb8\udb0b\udf65\ud970\udf76\ud9dd\udf65\ud90f\udc7c",
        1, 96797, -951607537, 11597346322257045L, -21436L, false, true, (char) 29533, (char) 21938,
        Double.longBitsToDouble(0x3fe3ac242eb1fbadL), Double.longBitsToDouble(0x3fcbd2baa67c1038L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Integer:1802401\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[]\012",
        Z.run(T, 2, 12, 1, 13, "\udbe5\udfe6", "\ud401\u8a4e\u9c0c", "\ud990\uddea\ud85f\ude39\ud81f\udc89\u5d2e\uda10\ude24\u7902\uda96\ude6d\ud8d4\udc0d\ud801\udfa9",
        19, 72627, 2001463390, 7528692732330079211L, 15641L, true, false, (char) 16499, (char) 51227,
        Double.longBitsToDouble(0x3fcc9e1f543f881cL), Double.longBitsToDouble(0x3fe79961dcf7d2edL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Thread$State\0121=java.lang.Class:java.lang.Thread$State\012",
        Z.run(T, 2, 8, 8, 13, "\ud814\ude19", "\ud401\u8a4e\u9c0c\u9a29\u9984\ud4e6", "\ud951\udd6a\ud9d9\udd4a\u78d0\udb3d\ude49\udb05\uddfd\udbd8\uddd9\ud92c\ude58\udb02\udfc4\uda90\udf29\ud956\udf9f\ud825\udc12\ud8eb\udf13\ud940\udf63",
        1, 12860, -252013261, 81430608135693583L, -52320L, true, true, (char) 40658, (char) 8061,
        Double.longBitsToDouble(0x3fa5aaeca4c6ed60L), Double.longBitsToDouble(0x3fe5cf974e88ba1fL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:int[]<int[], int[], java.lang.Thread$State> |a2=[Ljava.lang.reflect.Type;:[[class [I, class [I, class java.lang.Thread$State]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:int[]<int[], int[], java.lang.Thread$State> |a2=[Ljava.lang.reflect.Type;:[[class [I, class [I, class java.lang.Thread$State]]\012",
        Z.run(T, 2, 14, 14, 2, "\udbe5\udff8\ud932\udfe8\ud987\udf01\ud8a2\udf4d\uda4b\udd04\ud932\ude4d\ud956\udf14\udb1c\uddae\ud990\uddea\ud85f\ude39", "\u9d9c\ub5b4", "\ud801\udfa9\ud916\udf37\udb85\udc04\udb0b\udf65\udb53\ude4b\ud8ca\udc01\ud96b\udc43\u30e6\udbcc\udced",
        5, 30595, -502924929, 3187322646191884019L, -94789L, true, false, (char) 11970, (char) 28759,
        Double.longBitsToDouble(0x3fd96ab3de5abf42L), Double.longBitsToDouble(0x3fc0c8709230151cL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 11, 11, 4, "\u6098", "\ua0e3\u6e0b\u2779\u143d\ub010", "\ud88d\udee0\udbbb\udd17\uda61\uddf3\ud9ea\uddda\uda48\udf53",
        42, 28471, -977331947, -7655859735637863904L, -22923L, true, false, (char) 38697, (char) 16127,
        Double.longBitsToDouble(0x3fdec676fe70ecb8L), Double.longBitsToDouble(0x3fc4de1df43f8af8L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 13, "\000", "\000", "\ud809\udf54\uda7d\udd71\ud870\udd1c\udabc\uded2\ud8fb\udfcc\000\udaa4\udfb1\uda55\udce7\u2f00\ud8b8\udd3c\ud801\udfa9\udbe3\udffe\ud8b0\udfda\u00b3\udbe6\udef2",
        36, 77850, -379985695, 6438731467225693983L, 33131L, true, true, (char) 9958, (char) 38915,
        Double.longBitsToDouble(0x3fee5f1159382f01L), Double.longBitsToDouble(0x3fe1a46198aba6b5L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[Ljava.lang.Object;:[[\000]]\0121=java.lang.Integer:0 |a0=[Ljava.lang.Object;:[[\000]]\012",
        Z.run(T, 2, 13, 13, 8, "\000", "\000", "\ud9ff\udc66\ud9fe\uddb4\uda4f\uddfe\ud927\udfc1",
        13, 99982, -1266024661, -7519402614035135378L, 30231L, true, true, (char) 48325, (char) 58360,
        Double.longBitsToDouble(0x3fcc97367fc8b258L), Double.longBitsToDouble(0x3fd93c20674b3418L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:int[]<int[], int[], int[]> |a2=[Ljava.lang.reflect.Type;:[[class [I, class [I, class [I]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:int[]<int[], int[], int[]> |a2=[Ljava.lang.reflect.Type;:[[class [I, class [I, class [I]]\012",
        Z.run(T, 2, 14, 14, 2, "\udbe5\udff8\ud932\udfe8\ud987\udf01\ud8a2\udf4d\uda4b\udd04\ud932\ude4d\ud956\udf14\udaeb\udcb5\ud990\uddea\ud85f\ude39", "\u9d9c\ub5b4", "\ud801\udfa9\udb2c\udf42\udb85\udc04\udb0b\udf65\udb53\ude4b\ud8ca\udc01\ud96b\udc43\u30e6\ud9a0\uddae",
        33, 30595, -1872496257, 3187189429191263987L, -73162L, false, false, (char) 48304, (char) 28759,
        Double.longBitsToDouble(0x3fd96ab3de5abf42L), Double.longBitsToDouble(0x3fc0c8709230151cL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Comparable\0121=java.lang.Class:java.lang.Comparable\012",
        Z.run(T, 2, 8, 8, 7, "\udbf0\ude05\udb1f\udeb1\ud97f\udf01\ud89e\udc18\uda4b\udd04\udb21\udc46\udafc\udeba\udb1a\uddd0\uda26\udd34\udbc7\udcce\ud974\udf5a\ud977\udffe\uda10\ude24\uda99\udd7c\uda96\ude23\ud8d4\udc0d\ud801\udfa9", "\ub90d\u45b0\u5e57\u206c\u142d\u7932\u7143\u5365\ube37", "\ud9bd\ude61",
        27, 61301, -2117064382, 8600906366425873887L, -49287L, false, true, (char) 13929, (char) 24304,
        Double.longBitsToDouble(0x3fe529ef9b417c3cL), Double.longBitsToDouble(0x3fe122e2e00261bcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.$Gson$Types|arrayOf|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|canonicalize|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|checkNotPrimitive|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|declaringClassOf|java.lang.reflect.TypeVariable|static",
    "M|com.google.gson.internal.$Gson$Types|equal|java.lang.Object,java.lang.Object|static",
    "M|com.google.gson.internal.$Gson$Types|equals|java.lang.reflect.Type,java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|getArrayComponentType|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|getCollectionElementType|java.lang.reflect.Type,java.lang.Class|static",
    "M|com.google.gson.internal.$Gson$Types|getGenericSupertype|java.lang.reflect.Type,java.lang.Class,java.lang.Class|static",
    "M|com.google.gson.internal.$Gson$Types|getMapKeyAndValueTypes|java.lang.reflect.Type,java.lang.Class|static",
    "M|com.google.gson.internal.$Gson$Types|getRawType|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|getSupertype|java.lang.reflect.Type,java.lang.Class,java.lang.Class|static",
    "M|com.google.gson.internal.$Gson$Types|hashCodeOrZero|java.lang.Object|static",
    "M|com.google.gson.internal.$Gson$Types|indexOf|[Ljava.lang.Object;,java.lang.Object|static",
    "M|com.google.gson.internal.$Gson$Types|newParameterizedTypeWithOwner|java.lang.reflect.Type,java.lang.reflect.Type,[Ljava.lang.reflect.Type;|static",
    "M|com.google.gson.internal.$Gson$Types|resolve|java.lang.reflect.Type,java.lang.Class,java.lang.reflect.Type,java.util.Collection|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
