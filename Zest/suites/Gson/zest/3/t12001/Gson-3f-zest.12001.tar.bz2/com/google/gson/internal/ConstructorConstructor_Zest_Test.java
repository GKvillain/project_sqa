package com.google.gson.internal;
import org.junit.Test;
import static org.junit.Assert.*;
public class ConstructorConstructor_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 0, "\udbf9\udd22\ud8d6\udf39\udb9c\udf12\udb9c\udea1\udbcc\udca0\uda6a\udd2f\ud841\udc12", "\u6fb0\u1437\uc0b5\u6ed2\ub314\ua268\u7324\u0eda\u08f6\u13cc\u063f", "\udb87\udeff\ud9c6\udef2\udbad\udcb8\ud881\udd75\udb26\udee9\ud8f6\udc8a\ud8bd\udcc6\ud93a\udd03\ud920\udd53\ud8d8\udefd\udb91\udee7",
        0, 43359, 671934858, -5256523112074468148L, 15366L, false, true, (char) 57057, (char) 22156,
        Double.longBitsToDouble(0x3fe22602f1c0f26eL), Double.longBitsToDouble(0x3fea139cdf9c8942L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 1, 2, 0, 0, "\udba1\udd97\ud8ce\udd81\udb9c\udf12\udb9c\udea1\ud8a4\ude20\uda6a\udd2f\ud956\udca6", "\u7636\u572d\u430b\ub595\u8a74\uc68e\uaa54\u6eda\u08f6\u15f7\u9387", "\ud824\udd82\udb50\udf1d\udbad\udcb8\ud881\udd75\udb26\udede\ud8f6\udc8a\ud8bd\udcc6\ud93a\udd03\ud920\udd53\ud8d8\udefd\uda8b\udc04",
        4, 14801, -2042799781, 390007270626559287L, 15366L, false, true, (char) 57003, (char) 22156,
        Double.longBitsToDouble(0x3fe22602f4c0f26eL), Double.longBitsToDouble(0x3fea139cdf9c8942L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.gson.internal.ConstructorConstructor$3:@? |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 1, 2, 0, 0, "\udbf9\udd22\ud8d6\udf39\udb9c\udf12\udb9c\udea1\udbcc\udca0\uda6a\udd2f\ud841\udc12", "\u6fb0\u1437\uc0b5\u6ed2\ub314\ua268\u7324\u0eda\u52f6\u13cc\u342c", "\udb87\udeff\ud9c6\udef2\udbad\udcb8\ud881\udd75\udb26\udee9\ud8f6\udc8a\ud8bd\udcc6\ud9e6\uddf8\ud920\uddbe\ud8d8\udefd\udb91\udee7",
        0, 43359, 232023434, 5095754935067976742L, 15366L, false, true, (char) 57057, (char) 22156,
        Double.longBitsToDouble(0x3fe22602f1c0f26eL), Double.longBitsToDouble(0x3fea139cdf9c8942L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\udbf9\udd22\ud8d6\udf39\udb9c\udf12\udb9c\udea1\udbcc\udca0\uda6a\udd2f\ud841\udc12", "\u6fb0\u1437\uc0b5\u6ed2\ub314\ua268\u7324\u0eda\u08f6\u13cc\u0b3f", "\udb87\udeff\ud9c6\udef2\udbad\udcb8\ud881\udd75\udb26\udee9\ud8f6\udc8a\ud8bd\udcc6\ud93a\udd03\ud920\udd53\ud8d8\udefd\udb91\udee7",
        0, 43359, 671934858, -5256523112074468148L, -79908L, false, true, (char) 57057, (char) 22156,
        Double.longBitsToDouble(0x3fe22602f11ff26eL), Double.longBitsToDouble(0x3fea139cdf9c8942L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 1, 2, 0, 2, "\udbf9\udd22", "\u6476\u6c2d\ua227\u9973\u45b6", "\ud92d\udd07\ud80e\udeed\udb4f\ude6a\udae6\udeb4\udaa8\udeb2\uda12\udc42\ud95e\udf00\ud945\udf82\ud8c7\udd21\uda7b\udf05\uda28\udfa0\uda2d\udc25\udb87\udeff\ud9c6\udef2\udbad\udcb8",
        27, 40192, 675337771, 2284163834597120954L, -13276L, true, false, (char) 62806, (char) 15392,
        Double.longBitsToDouble(0x3fc996e1b681bcacL), Double.longBitsToDouble(0x3fd5a81183d1095cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.google.gson.internal.ConstructorConstructor$3:@? |this=com.google.gson.internal.ConstructorConstructor:{}\0121=null |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 2, 0, 0, "\ud87c\uddfa\ud96c\uded1\udb6c\udd47\ud6a6\udbcc\udca0\uda6a\udd2f\ud8ac\udce7", "\u6fb0\u1437\uc0b5\u6ed2\ub314\ua268\u7324\u0eda\u08f6\u2946\ua52e", "\udb87\udeff\ud91b\uddbb",
        23, 3662, -1197914337, 2900553640730360552L, 77051L, false, true, (char) 33151, (char) 32264,
        Double.longBitsToDouble(0x3fe43ce1518a0bcdL), Double.longBitsToDouble(0x3f94280c9996e1a0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.gson.internal.ConstructorConstructor$14:@? |this=com.google.gson.internal.ConstructorConstructor:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 3, 5, "\udbf9\udd22\ud8d6\udf39\udb5c\ude32\udb5a\ude18\udbcc\udca0\uda6a\udd2f\ud841\udc12", "\u6fb0\u1437\uc0b5\u6ed2\u268b\ua2e5\u7324\u0eda\u08f6\u13cc\u063f", "\udb87\udeff\ud9c6\udef2\ud9bb\ude72\ud9e5\udfe5\udb27\udd07\ud8f6\udc8a\ud8bd\udcc6\ud93a\udd03\ud920\udd53\ud8d8\udefd\udb91\udee7",
        0, 43359, 671934858, -5256523112074468148L, 15282L, false, true, (char) 57057, (char) 22156,
        Double.longBitsToDouble(0x3fe22602f1c0f26eL), Double.longBitsToDouble(0x3fea139cdf9c8942L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 1, 5, 2, 5, "\udbf9\udd22\ud8d6\udf39\udb9c\udf12\udadf\udc2c\ud8e9\udd41\udba3\udebf\ud9c6\udcc9\uda3a\udd76\uedf2\udba8\udc91\ud92d\udd07\uda11\udf2d\u7b69\ud83b\udf97", "\u8fa2\u8fac\u3758", "\ud963\udcd9\udaf9\udd56",
        2, 21676, -516913338, -5145002900149184981L, -60134L, false, true, (char) 25969, (char) 16032,
        Double.longBitsToDouble(0x3fd9e43539eff560L), Double.longBitsToDouble(0x3fd8a0bcd4285018L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 4, "\udbf9\udd22\ud9ee\ude4c\ud875\udf0c\udb53\udfe0\uda72\udd37\uda6a\udd1c\ud841\udc12", "\u6fb0\u1437\uc30c\ud7c7\uc8c6\ud726\u54bb\u5943\u08bd\u23c6\u063f", "\udb87\udeff\udb18\udc9a\udbad\udcb8\ud881\udd75\ud940\udf75\ud8f6\udd07\ud935\udceb\ud93a\udc94\ud920\udd53\ud8d8\udefd\udb91\udee7",
        0, 43359, 671934858, -5256523115138362420L, 15366L, false, true, (char) 57073, (char) 22156,
        Double.longBitsToDouble(0x3fe22602f1c0f26eL), Double.longBitsToDouble(0x3fea139cdf9c8942L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 0, "\udbf9\udd22\ud8d6\udf39\udb9c\udf12\udb9c\udea1\udbcc\udca0\u79ca\ud832\udf9a", "\u6faf\u1437\uc0b5\u6ed2\ub86a\u53c7\u9dc9\u0eda\u08f6\u13cc\u063f", "\ud891\udf04\ud9c6\udef2\udbad\udcb8\ud881\udd75\udb26\udee9\ud8f6\udc8a\ud882\uddca\ud93a\udd03\ud920\udd53\ud8d8\udefd\udb91\udee7",
        0, 43359, 671934858, -5213457440637737780L, 15366L, false, true, (char) 23711, (char) 22156,
        Double.longBitsToDouble(0x3fe22602f1c0f26eL), Double.longBitsToDouble(0x3fea139cdf9c8942L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 1, "\ud894\udd30\ud85f\udc27\udb9c\udf12\udb9c\udea1\udbf4\udeb5", "\u45b6\u3fe3\u6fb0\u1437", "\udae6\udeb4\udaa8\udeb2\uda12\udc42\ud95e\udf00\ud945\udf82\ud8c7\udd21\uda7b\udf05\uda28\udfa0\uda2d\udc25\udb87\udeff",
        35, 99935, -751416822, -5168314745681291733L, -60134L, true, false, (char) 9259, (char) 9228,
        Double.longBitsToDouble(0x3fdf170b0d0f39f6L), Double.longBitsToDouble(0x3fd8a0bcd2306152L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:{} |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 1, 4, 0, 0, "\udbf9\udd22\ud854\udca9\ud876\udc1f\ud94c\udc36\ud9d3\udd47\uda6a\udd2f\ud841\udc12", "\u6fb0\u1437\ud27d\u6ed2\ub314\ua268\u7324\u4c2f\u08f6\u13cc\u063f", "\udb87\udeff\ud9c6\udef2\udbad\udcb8\ud881\udd75\udb64\udce8\ue8cb\ud8bd\udcc6\ud93a\udd03\ud920\udd53",
        0, 16720, -1674924740, -1291320851794909714L, -76652L, false, true, (char) 48754, (char) 44694,
        Double.longBitsToDouble(0x3fe6f6401d68e423L), Double.longBitsToDouble(0x3fe221e2f1c0f26eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=com.google.gson.internal.ConstructorConstructor:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\udbf9\udd22\ud8d6\udf39\udb9c\udf12\udb9c\udea1\udbcc\udca0\uda3e\udd39\ud841\udc12", "\u6fb0\u1437\uc0b5\u9013\ub372\ua268\ub61a\u707a\uc358\u13cc\u304f", "\udb73\ude9d\ud9c6\udef2\udbad\udcb8\ud98b\udf3a\ud8b9\udcd2\ud892\udd17\ud868\udffd\ud966\udfb3\udb96\udd4e\ud8d8\udefd\udb91\udee7",
        6, 6957, 1343023571, -2086919813606767257L, 15366L, false, true, (char) 57057, (char) 23851,
        Double.longBitsToDouble(0x3fe716076a0bf25dL), Double.longBitsToDouble(0x3fea12620f9c8942L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.gson.internal.ConstructorConstructor$3:@? |this=com.google.gson.internal.ConstructorConstructor:{}\0121=com.google.gson.internal.ConstructorConstructor$3:@? |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 2, 2, 2, "\udbf9\udd22\ud8b3\udd28\uda89\ude28\udb9c\ude75\udbcc\udca0\udab9\udc36\uda3c\udd8e", "\u6fb0\u1812\uc0b5\u6ed2\ub314\ua268\u0d83\u0e84\u08f6\u13cc", "\uda2d\udc25\udab7\udf56",
        51, 18297, 1019511886, -5145002535076964821L, 68634L, false, false, (char) 25969, (char) 37612,
        Double.longBitsToDouble(0x3fcbe2751a1e70a8L), Double.longBitsToDouble(0x3fd8a0bcd26c5018L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.gson.internal.ConstructorConstructor$8:@? |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 1, 0, 2, 4, "\uda64\ude96\ud8d6\udfc4\udb9c\udf12\udb9c\udea1\udbcc\udca0", "\ub2d9\u4a2a\u6f9f\u1437", "\udae6\udeb4\udaa8\udeb2\ud974\udfd1\ud900\udd69\ud95f\udd3a\ud86e\udd23\uda7b\udec5\ud873\udd65\udbad\udc77\udb80\udddd",
        -2, 21676, -516913338, -5145002900149184981L, -13276L, true, false, (char) 62806, (char) 15392,
        Double.longBitsToDouble(0x3fc996e1a681bcacL), Double.longBitsToDouble(0x3fd5a0b643d1095cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 0, "\ud8a3\udc9a\ud862\udccc\ud893\udec2", "\ua227\u9973\u45b6\u3fe3\u7e54\u851e\uc0b5\u6ed2\ua78d\ua268", "\ud945\udf82\ud8c7\udd21\uda7b\udf05\uda28\udfa0\uda2d\udc25\udb87\udeff\ud9c6\udef2\udbad\udcb8\ud881\udd75\uda79\udcdb\ud8eb\udda5\ud8bd\udcc6\ud93a\udd03\ud920\udd53\u505c\udb91\ude9a\udae7\udc18\udb8c\udf63\u1dee\ud9ac\udc84\ud804\udf19\ud9bd\udee2\uda05\udeb0\ud931\ude9b\uda7d\udd39\u6ea8\ud91f\udd77\ud840\udc90\uda5c\udc42",
        55, 59719, 799618183, 6435189290500992030L, -68193L, false, false, (char) 53725, (char) 61608,
        Double.longBitsToDouble(0x3fc6a85ae3979100L), Double.longBitsToDouble(0x3fda1749d174f8f0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=com.google.gson.internal.ConstructorConstructor:{}\0121=null |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 2, 0, 0, "\udb23\udf4a\ud8d6\udf39\udb9c\udf12\udb9c\udea1\udbcc\udca0\uda50\uded1\ud943\udc19\uda1e\udc88\uedf2\udba8\udc91\ud809\ude35\udb56\udfd9\udb4f\ude6a\udb0c\uddb4\uda10\udec5", "\u08f6\u13cc\u66d8\u034c\u3d67\u69f3\ua9ca\ub7a6\u8b25\uca7e\u3628\u26d2\u6cc1\u3499\u0f14", "\ue739\ud8b4\udfe6\ud9b8\udfa8",
        39, 94984, -1733411494, -1103012750067330624L, 65625L, false, true, (char) 58077, (char) 55518,
        Double.longBitsToDouble(0x3fe90a2be31dc6cbL), Double.longBitsToDouble(0x3fc34efcbd935fdcL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.gson.internal.ConstructorConstructor$14:@? |this=com.google.gson.internal.ConstructorConstructor:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\udbf9\udcf8\ud8d6\udf39\udb9c\udf12\udb9c\udea1\udbcc\udca0\uda6a\udd2f\ud841\udc12", "\u6fb0\u1437\uc0b5\u6ed2\ub314\ua268\u7324\u0eda\u08f6\u13cc\u063f", "\udb87\udeff\ud9c6\udef2\udbad\udcb8\udadb\udf63\udaaf\udceb\udba1\udf87\ud8bd\udcc6\ud93a\udd03\ud920\udd53\ud8d8\udefd\udb91\udee7",
        0, 43359, 671934858, -5256523112074468148L, 15366L, false, true, (char) 57057, (char) 22156,
        Double.longBitsToDouble(0x3fe22602f6c0f26eL), Double.longBitsToDouble(0x3fedad1b379c8942L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:{}\0121=null |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 5, 0, 0, "\udbf9\udd22\ud8d6\udf39\udb9c\udf12\ud97e\ude6c\ud952\udef6\ud939\udd70\ud8ec\ude49", "\u7a20\u8cd4\uc077\u6ed2\ub314\ua268\u6b24\u0eda", "\udbd8\udc52\ud86e\udf0f\uda2c\udfc5",
        -1, 65926, -1743138571, -2180915962738096353L, 95304L, true, false, (char) 43817, (char) 46735,
        Double.longBitsToDouble(0x3fcbe31e14f06030L), Double.longBitsToDouble(0x3fe43ce152f64dcdL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=com.google.gson.internal.ConstructorConstructor:{}\0121=null |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 0, 0, 0, "\ud8d9\udf39\ubb5c\udb6c\udd30", "\ua227\u7aa3\u45b6\u3fe3\u6fb0\u1437\uc0b5\u6ed2\ub314\ua268\u7324\u0eda", "\udbd7\ude71\ud827\udc30\uda2c\udf8f",
        3, 39099, 1791758508, 7715445933275170785L, 95304L, false, true, (char) 45244, (char) 56147,
        Double.longBitsToDouble(0x3fdb0f7cfa79a198L), Double.longBitsToDouble(0x3fe43ce1518a0bcdL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.google.gson.internal.ConstructorConstructor$8:@? |this=com.google.gson.internal.ConstructorConstructor:{}\0121=com.google.gson.internal.ConstructorConstructor$8:@? |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 0, 0, 0, "\ud87c\uddfa\udbad\udff1\000\000\000\uda34\uddb9\ud8ac\udce7", "\000\u09ae\ubf1b\u6ed2\ub314\ua268\u8407\000\u0416\u2946\ua52e", "\udb87\udeff\ud91b\uddbb",
        3, 55304, -1197914337, 2900553640730360552L, 77051L, false, true, (char) 33151, (char) 32264,
        Double.longBitsToDouble(0x3fe43ce1500000cdL), Double.longBitsToDouble(0x3e4332dc00000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:{}\0121=new com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 5, 5, 0, "\ud87c\uddfa\ud96c\uded1\udb6c\udd47\ud6a6\udbcc\udca0\uda6a\udd2f\ud8ac\udce7", "\u6fb0\ua493\uc0b5\u6ed2\ub314\ua268\u948c\u0eda\u08f6\u2946\ua52e", "\udb87\udeff\ud91b\uddbb",
        23, 3662, -1197914337, 2900553640730360552L, 77051L, false, true, (char) 3712, (char) 51146,
        Double.longBitsToDouble(0x3fc1f6c526282f34L), Double.longBitsToDouble(0x3f94280c9996e1a0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:{} |this=com.google.gson.internal.ConstructorConstructor:{}\0121=java.lang.String:{} |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 4, 4, 0, "\ud87c\uddfa\ud96c\uded1\udb6c\udd47\ud6a6\udbcc\udca0\udb5c\udc89\ud8ac\udd5c", "\u6fb0\u1437\uc0b5\u6ed2\u7815\ua268\ua27a\u6609\u08f6\u2946\ua52e", "\udb87\udeff\ud91b\uddbb",
        23, 98382, -1197914189, 2900553640730360552L, 77051L, false, true, (char) 33151, (char) 32264,
        Double.longBitsToDouble(0x3fe43ce1518a0bcdL), Double.longBitsToDouble(0x3f94280c9996e1a0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.google.gson.internal.ConstructorConstructor$14:@? |this=com.google.gson.internal.ConstructorConstructor:{}\0121=com.google.gson.internal.ConstructorConstructor$14:@? |this=com.google.gson.internal.ConstructorConstructor:{}\012",
        Z.run(T, 2, 3, 3, 5, "\ud87c\uddfa\udb03\uddfc\uda41\ude33\ud6a6\udbcc\udca0\ud96c\ude8f\ud8b5\ude55", "\uc25c\ua6a7\ubfff\u6ed2\ub314\ua268\uaaca\u0eda\ubb65\uc88d\u76b3", "\udad3\udf45",
        1, 133, -516913338, -5145002901037264085L, -28768L, true, false, (char) 12444, (char) 33197,
        Double.longBitsToDouble(0x3fe355de66879c2aL), Double.longBitsToDouble(0x3fd8a0bcd8285018L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:!toString:java.lang.NullPointerException\0121=com.google.gson.internal.ConstructorConstructor$14:@? |this=com.google.gson.internal.ConstructorConstructor:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 1, "\udbf9\udd22\ud8d6\udf39\udb5c\ude32\udb5a\ude18\udbcc\udca0\uda6a\udd2f\ud841\udc12\uda49\udd8c\udb91\uddfd\udba8\udc91\ud92d\udd07\ud80e\udeed\udb4f\ude6a\007\udaa8\udf2f\uda12\udc42", "\u13cc\u063f\u3e9d\u4f59\u521b\u51c5\u7318\u12f1\ucc9c\u5bee\uc868\u6d27\ubeab", "\udb65\udf59\ue739\ud8b4\udfe6",
        5, 64212, -2129072736, -8886097198161122840L, 60360L, false, false, (char) 25647, (char) 58077,
        Double.longBitsToDouble(0x3fece44a10ad0a6eL), Double.longBitsToDouble(0x3fe48467388833c1L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 2, "\udbf9\udd22\ud9ee\ude4c\ud875\udf0c\udb53\udfe0\uda72\udd37\uda6a\udd1c\ud841\udc12", "\u7904\u1395\uc30c\ud7c7\uc8c6\ud726\u54bb\u5943\u08bd\u483c\u063f", "\udb87\udeff\udb18\udc9a\ud883\udc62\ud881\uddf4\ud940\udf75\ud8f6\udd07\ud9bd\udecb\ud9ba\uddfd\ud941\udd6a\ud8d8\ude8b\udb91\udee7",
        0, 43359, 671934858, -5256392608262106164L, 15366L, false, true, (char) 17881, (char) 45674,
        Double.longBitsToDouble(0x3fc41e840703c9b8L), Double.longBitsToDouble(0x3fc8ae737e722508L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 4, "", "\000\u1509\u6c2d\ua227\u567d\000\000\u7bb8\u1437\uc0b5\u6ed2", "\uda12\udc42\ud95e\udf00\ud91f\udcee\000\ud9ac\udd9d\000\ud870\udf58\udb87\udeff\ud9c6\udef2\udbad\udcb8\ud881\udd75\udb26\udee9\ud8f6\udc8a\ud8bd\udcc6\udbdc\udcf4\ud920\udd53\ud8d8\udefd\udb91\udee7\udb65\udf59\ue739",
        18, 37340, 1865131212, -9144297773994197670L, -40096L, false, false, (char) 40542, (char) 25647,
        Double.longBitsToDouble(0x3fea139cdf9c8942L), Double.longBitsToDouble(0x3fe5dc31063cfb37L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:{\uda13\udceb\ud8d6\udf67\udb5c\ude32\udb5a\ude18\udb00\udc9a\uda6a\udd2f\ud841\udc12\ud9d5\udc6d\udb8e\udd66\udba8\udc91\ud92d\udd07\ud80e\udeed\udb2e\udc99=\udaa8\udf2f\uda6c\udd50\ud95e\udf00\udbe3\udf70\ud8d4\udc56}\012",
        Z.run(T, 1, 5, 3, 4, "\uda13\udceb\ud8d6\udf67\udb5c\ude32\udb5a\ude18\udb00\udc9a\uda6a\udd2f\ud841\udc12\ud9d5\udc6d\udb8e\udd66\udba8\udc91\ud92d\udd07\ud80e\udeed\udb2e\udc99,\udaa8\udf2f\uda6c\udd50\ud95e\udf00\udbe3\udf70\ud8d4\udc56", "\u4f59\uaf51", "\ud9e5\udfe5\uda92\ude85",
        46, 57303, 1667275706, -3752611085359736443L, -13276L, true, false, (char) 62702, (char) 15392,
        Double.longBitsToDouble(0x3fc996e1be81bcacL), Double.longBitsToDouble(0x3fe4999ce9e8c376L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new com.google.gson.internal.ConstructorConstructor:{\uda13\udceb\ud8d6\udf67\udb5c\ude32\udb5a\ude18\uda98\udd9d\udb9e\udc31\ud841\udc12\ud9d5\udc6d\udb8e\udd66\udba8\udc91\ud92d\udd07\ud80e\udeed\udb2e\udc99=\udaa8\udf2f\uda56\uddce\ud95e\udf00\udbe3\udf70\ud99a\uddba}\0121=com.google.gson.internal.ConstructorConstructor$14:@? |this=com.google.gson.internal.ConstructorConstructor:{\uda13\udceb\ud8d6\udf67\udb5c\ude32\udb5a\ude18\uda98\udd9d\udb9e\udc31\ud841\udc12\ud9d5\udc6d\udb8e\udd66\udba8\udc91\ud92d\udd07\ud80e\udeed\udb2e\udc99=\udaa8\udf2f\uda56\uddce\ud95e\udf00\udbe3\udf70\ud99a\uddba}\012",
        Z.run(T, 2, 5, 3, 2, "\uda13\udceb\ud8d6\udf67\udb5c\ude32\udb5a\ude18\uda98\udd9d\udb9e\udc31\ud841\udc12\ud9d5\udc6d\udb8e\udd66\udba8\udc91\ud92d\udd07\ud80e\udeed\udb2e\udc99,\udaa8\udf2f\uda56\uddce\ud95e\udf00\udbe3\udf70\ud99a\uddba", "\u4f59\uaf51", "\ud9e5\udfe5\uda92\ude85",
        46, 57303, 1667275706, -4329071837035119157L, 75420L, true, false, (char) 62702, (char) 50313,
        Double.longBitsToDouble(0x3fb3961d7d027830L), Double.longBitsToDouble(0x3fe4999ce93c0c76L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.ConstructorConstructor|newDefaultImplementationConstructor|java.lang.reflect.Type,java.lang.Class|new:com.google.gson.internal.ConstructorConstructor:java.util.Map",
    "M|com.google.gson.internal.ConstructorConstructor|get|com.google.gson.reflect.TypeToken|new:com.google.gson.internal.ConstructorConstructor:java.util.Map",
    "M|com.google.gson.internal.ConstructorConstructor|newDefaultConstructor|java.lang.Class|new:com.google.gson.internal.ConstructorConstructor:java.util.Map",
    "M|com.google.gson.internal.ConstructorConstructor|newUnsafeAllocator|java.lang.reflect.Type,java.lang.Class|new:com.google.gson.internal.ConstructorConstructor:java.util.Map",
    "M|com.google.gson.internal.ConstructorConstructor|toString||new:com.google.gson.internal.ConstructorConstructor:java.util.Map",
    "C|com.google.gson.internal.ConstructorConstructor|<init>|java.util.Map",
    "M|com.google.gson.internal.ConstructorConstructor|newDefaultImplementationConstructor|java.lang.reflect.Type,java.lang.Class|new:com.google.gson.internal.ConstructorConstructor:java.util.Map",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
