package com.google.gson.internal.bind;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonTreeWriter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 18, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ua595\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        33, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 14, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ua595\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u82bb\u131e\u2bde\u8e1a\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\uda69\udc8f\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        33, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.gson.JsonNull:null |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 18, 13, "\udba1\udf23\ud876\udc09\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\udb54\udf81", "\u1600\ucbd5\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\uc347\ua7a4\u2bde\u8e1a\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\uda45\udfd9",
        44, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 35454, (char) 53879,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 13, 13, "\udba1\udeda\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb69\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u870c\ua5ba\uc3fd\u5b4d\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a\ubc37\u6848\ua4b6\u25eb\u8b19\uc6e8\u5628", "\udbe4\uded0\ud9c7\udc57\udb25\udfbc\ud96d\udd55\ud964\uddfa\ud902\udfe2\ud889\udc81\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\uda4d\udd64\uda78\udf79\udbf0\udcc1\udb61\udf58\uda0d\udda1\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        13, 24529, 2062729600, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 18, 13, "\udb7d\udd5c\ud836\udc8a\udb98\udd3e\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\ud90b\udec7", "\u7966\u8b99\u1330\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a", "\udb44\udce2\uda93\udf31\u67b5",
        55, 39344, -275523076, -5891557750844088670L, 10079L, false, false, (char) 16224, (char) 55938,
        Double.longBitsToDouble(0x3fe0753b89d1fcbcL), Double.longBitsToDouble(0x3fcd7219ce29e368L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 18, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ua595\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde|\000\u6fb3\000\000\u2a44\uc6e8\uc1b5", "\udbe4\uded0\ud99b\udf67\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        33, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 11, 1, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\ud814\uddad\udb81\ude39\ud984\udd93\uda27\ude6c", "\u1600\ua2ea\u1ef8\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\ub157\u2c15\u8e1a\ubc37\u8df6\u7e8c\ucfe8\u8b19\uc6e8\ucced", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\uda6c\udfd0\ud94c\udd12\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\u1c2d\udac2\udf29\ud840\udd2b\udb7e\uddba\u961b\ud89b\udc82\ud99d\udf4f\ud96a\udfa8\uda65\udd70",
        36, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764991f926L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 13, 20, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\ud98c\ude03\udb64\udcd9\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u96dc\ua595\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u563f\u1332\u2bde\u8e1a\ubc37\u1786\u0c9f\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ucc7b\udbfb\ude4e\udae3\udddc\udb96\udfc8\ud94d\udfa3\uda2a\ude27\uda78\udf48\udbf0\udcc1\uda0e\ude6e\ud811\udff2\ud994\uddc5\u964f\uda7a\udc90\u9d7d\uda59\udfd1\udb7a\ude7e",
        33, 20905, -1272627370, 8551846086261007014L, 22130L, false, false, (char) 8318, (char) 56189,
        Double.longBitsToDouble(0x3fe23a764c91f926L), Double.longBitsToDouble(0x3fc3ad3dce1fc170L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.gson.JsonNull:null |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 12, 7, 19, "\udb8f\udcf8\udb58\udfc0\udb9e\udfaa\ud835\ude2c\ub714\ud898\ude70\udbef\udce2\ud992\udcd6\udb8e\udef7\ud88b\udcde\ud9f1\uddfc\uf0bc", "\u1f4a\u2f86\u21a2\u0afe\u0450\ua549\u8154\u0a46\u4d74\u9ced\u8d64\u3178\u4c96\ua4b6\u258b", "\ud997\ude54\u051a\ud9db\ude9f\udbe4\uded0\ud9c7\udc72\ud9eb\ude01",
        7, 96735, -2061031258, 2809325019656086847L, 23388L, true, true, (char) 27087, (char) 4137,
        Double.longBitsToDouble(0x3fd097c1d068c604L), Double.longBitsToDouble(0x3fe6454f8f41a0c1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 0, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\uda2c\udc87\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\000", "\udab0\udf19\udb75\udf86\uda0c\udeb8",
        9, 25567, 1944415758, 2696243241736766328L, 46308L, false, true, (char) 62829, (char) 10612,
        Double.longBitsToDouble(0x3fd1fc3781ab36d8L), Double.longBitsToDouble(0x3fd3674a9b7053dcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 13, 19, 13, "\udba1\udf23\ud876\udc0e\ud9d3\udcab\ud835\ude2c\udb52\udd26\udb64\udc65\ud9f6\udff0\ud85c\udd11\uda3f\udc1f\udb68\uddf4", "\u1600\ua595\u1f8c\ub99d\ubc57\ud034\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\u07fc\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\udac0\ude1c\udabc\udd95\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\uda7a\udc90\ud88e\ude30\ud8a4\udc5f\udb7a\uded4",
        33, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 60985, (char) 42414,
        Double.longBitsToDouble(0x3fd43e7c1e4b9c08L), Double.longBitsToDouble(0x3fe23a701c91f928L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 16, 18, 13, "\udba1\udf23\ud95f\udc01\ud863\uddcc\uda8b\ude81\ud900\udfe5\udbb6\ude8b\ud9a2\udd5d\udb9b\udc83\u88e8\uda27\ude6c\ud9f1\ude51\udb0e\udc86\uda02\udf5e", "\u5bad\ub2fb", "\ud89e\ude9f",
        12, 52049, 1808040824, -1350057870318373987L, 85581L, true, false, (char) 26211, (char) 12355,
        Double.longBitsToDouble(0x3fe9b3a54db829eeL), Double.longBitsToDouble(0x3fdfcc69e6e3df26L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 6, 18, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udd05\udb53\udf9d\udb81\udd80\ud984\udd93\udbb1\udf11", "\u1600\u2124\u1f23\u5bad\ubc57\u02fd\u043c\u9de9\u576a\u0f4a\u1332\u2bde\u83b8\ubc37\u1786\ua4b6\u25eb", "\ud91c\ude56\ud8c8\udd04",
        47, 69354, 1840993787, -7620128891839977603L, 85546L, true, false, (char) 38541, (char) 50617,
        Double.longBitsToDouble(0x3fec53c6d0a07789L), Double.longBitsToDouble(0x3fe3b168e83c9f39L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 14, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude4c\udb52\udd26\udb64\udc65\udb53\udf9d\udb37\udd7b\ud984\udd93\uda27\ude6c", "\u1600\ua595\u05f3\uceb8\ub8df\u02fd\u30f9\uae09\u4edd\u0f4a\u1332\u962b\u8e1a\ubc37\u91e0\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\u1cac\udbf6\ude6b\ud833\ude1a\udb0d\ude95\ud90d\uddc4\udbd1\udf87\ud99d\ude70\udaff\udd76\udae3\udddc\udb23\udc1f\ud8ce\udfca\ud885\udd80\ud8ba\udd0c\udbf0\udcc1\udac2\udf29\ud85c\udf06\ud994\udde1\u964f\ud9c4\ude9f\ud992\udfbb\ud88a\udc0a\ud867\udf86",
        4, 84581, -1272613034, 8551846086261007014L, -24621L, false, false, (char) 60022, (char) 64877,
        Double.longBitsToDouble(0x3fc6445992838374L), Double.longBitsToDouble(0x3fe23a764b45e534L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ua595\u1f8c\u5bad\u4a65\u4a4d\u6cfe\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        33, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 19, 2, 13, "\udba1\udf23\ud8fa\udeb1", "\uc8b5\uafa8\u2dd5\ud379\ua46a\u8f67\ub0c8\u6d79\u940f\ubf8a\u2573\u508a\u0ebd\u02fd\u043c\u9e4f\ub800\u7ada\u1332\u2bde\u8e1a\ubc37\u138d", "\u67b5\uda63\udfae\ud91c\ude56\uda2c\udff6\ud9b3\udd1e\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\uda83\udf91\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1",
        -1, 14792, 716646209, 9036876084368401249L, 30970L, false, true, (char) 31616, (char) 41434,
        Double.longBitsToDouble(0x3fe7903abab5b4d3L), Double.longBitsToDouble(0x3fe533b57009b166L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 19, 18, 4, "\ud85b\udd2e\ud92d\uddc6", "\uc8b5\ua0a8\u2dd5\ud379\ua46a\u8f67\ub0c8\u6d79\u1600\ua595\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u0d69\u2bde\u8e1a\ubc37\u1786", "\u67b5\uda63\udfae\ud91c\ude56\ud8c8\udd04\udb4a\udfa3\udbe4\uded0\ud81e\ude9e\ud8fd\udf93\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\ud824\udcde\udbf0\udc6d\udac2\udf29",
        57, 50209, 2104061675, 6341177544593602968L, 73148L, true, true, (char) 41434, (char) 28589,
        Double.longBitsToDouble(0x3fe7d2afb2a676aeL), Double.longBitsToDouble(0x3f8362cd9cdf8a40L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 14, 18, 13, "\udba1\udf23\ud876\udc0e\ud867\udc0f\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c\ud9f1\ude51\ud819\udcab", "\u1f8c\u5bad\u06ca\u60dc\ub945\ub795\u5794\u0c49\u1332\u2bde\u8e1a\u5273\u1786\ua4b6\u6cf4", "\ud919\ude72\ud8c8\udd04\ud9db\ude9f\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\ud9b8\udf7c\uda6c\uddca\uda82\udc41\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95",
        56, 82142, -1443782596, -7871756928527817485L, 900L, false, true, (char) 47804, (char) 21903,
        Double.longBitsToDouble(0x3fd7b7a05b03ecb2L), Double.longBitsToDouble(0x3feab11cee609325L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 5, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\ud9bb\udc96\udb64\udd47\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ua595\u9d2c\u320d\ubbc2\u31c3\ua664\u9e4f\u75d5\u0f4a\u8460\u2c47\u8e1a\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude22\ud8bf\udf88\udb8e\udfe6\ud8cf\udc0a\udb3c\ude9a\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\udae7\udfc8\u7f59\ud88a\udc0a\udbfe\udc8a",
        42, 54601, 1148336480, 8551846086261007014L, 42451L, true, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc64a658a838374L), Double.longBitsToDouble(0x3fd2f09c9b6106caL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 14, 10, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb75\udd14\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ua595\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a\ubc37\u1786\u669e\u25eb\u8b19\uc6e8\u59f3", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\udaa9\udddf\udaf8\udcbf\uda71\udf7c\u9d7d\ud88a\udc0a\udb7a\udf24",
        33, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=void |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 11, 8, 17, "\ud951\udf91\ud876\udfaa\ud9c5\udd3e\ud84f\ude75\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80", "\ub0c8\u6d79\u1600\ua595\u1f8c\u5bad\u2b74\u0c8e", "\ud9c7\udce2",
        59, 38824, -1325686395, 1557617082804605356L, 71819L, false, true, (char) 42918, (char) 1229,
        Double.longBitsToDouble(0x3feb8f7a8ea2ae3cL), Double.longBitsToDouble(0x3fdfbbf3da4adb76L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.google.gson.JsonNull:null |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 12, 18, 13, "\udba1\udf23\ud9f7\udeea\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\ud914\udd26\ud984\udd93\udb54\udf81", "\u1600\ucbd5\u1f8c\u2f8c\uc753\ubf5a\u043c\u9e4f", "\ud8c8\udfab\udb97\udcdc\ud83f\uddc2\udaee\udd00\uda64\udd00\udb44\udce2\uda93\udf31\u67b5\uda63\udfae\ud91c\ude56\ud8c8\udd04\ud9db\ude9f\udbe4\uded0",
        45, 96502, -523088943, -4760689041501363430L, 11495L, false, false, (char) 38541, (char) 50617,
        Double.longBitsToDouble(0x3fec53c6d5fcd623L), Double.longBitsToDouble(0x3fe3b168e83c9f39L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.google.gson.JsonNull:null |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.JsonNull:null |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 12, 12, 13, "\udaa1\udf16\ud95d\udc1a\udb8e\udc6a\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\udb54\udf81", "\u1600\u7326\u1f8c\u5bad\ubc57\uaffc\u043c\ud64a\u576a\uc347\ua7a4\u2bde\u8e1a\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud9b5\udcc5\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\uda45\udfd9",
        44, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 35454, (char) 53879,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 6, 10, 13, "\udba1\udf23\ud876\udc09\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\udb54\udf81", "\u1600\ucbd5\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\uc347\ua7a4\u2bde\u8e1a\ubc37\u1786\u0842\u25eb\u8b19\ud650\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\uda45\udfd9",
        44, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 35454, (char) 53879,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 20, 13, "\udba1\udf23\ud876\udc09\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\udb54\udf81", "\u1600\ucbd5\u1f8c\u5bad\u7284\u5b6a\u043c\u9e4f\u576a\u72af\ua406\u2bde\u8e1a\ubc37\u1786\ua4b6\u73d8\ua676\ua5ac\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\udaa5\udc68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud94a\udc08\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\uda45\udfd9",
        44, 20905, 1780825942, 8528082603144227637L, -24621L, false, false, (char) 35454, (char) 53879,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.gson.JsonNull:null |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 15, 12, "\udba1\udf23\ud876\udc09\udb9e\udfaa\ud835\ude2c\udb83\ude1d\udbe4\udd48\ud9d4\udf1f\udb81\udd80\ud984\udd93\ud873\udc91\ud9f1\ude51\ud84d\udc05\uda02\udf5e\ud850\udfe8\ud85c\udc0d", "\ud5bc\uaf0c", "\ud8e3\uddf1\udb07\udc4e\ud8a3\udeab\ud879\ude03\udaee\udd00\udb7b\udeca\uf706\udbfe\udff0\ud824\udfbb\udbd7\ude20\ud91c\ude56\ud8c8\udd04\ud9db\ude9f\udbe4\uded0\ud9c7\udc72\ud843\udc0a\ud865\udc15\udbe3\udd1c\ud831\udd58\ud9fe\udc78\udb11\udfc4\ud89c\udd60\ud9ca\udf43\udbfc\ude81\ud993\udcb8\uda78\udf48\udbf0\udcc1\uda13\udfd1\ud83a\ude7b\ud994\uddc5\u964f\uda7a\udc90",
        43, 5014, -509777500, -660116891828245631L, 13995L, false, false, (char) 41327, (char) 42140,
        Double.longBitsToDouble(0x3fe395bf292f494fL), Double.longBitsToDouble(0x3fc75db7a2c88b30L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 7, 10, 13, "\udba1\udf23\ud876\udc09\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udacb\uded9\udae7\udcca\ud984\udd93\udb54\udf81", "\u1600\ucbd5\u1f8c\u5bad\ubc57\u02fd\u043c\u04d5\u57a1\uc347\ua7a4\u2bde\u8e1a\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\u6bd8\udae3\udef1\ud990\ude32\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\ud910\udc87\uda7a\udc90\u9d7d",
        -1, 69500, -153695441, 3483441406060871510L, 89094L, true, false, (char) 42140, (char) 48727,
        Double.longBitsToDouble(0x3fd2f494f975db7aL), Double.longBitsToDouble(0x3fc644598a838374L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 18, 1, "\ud969\udd90\ud876\udc09\ud97e\udc9a\ud835\ude5f\udb72\udec2\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\udb54\udf81\ud9f1\ude51\ud84d\udc05\uda02\udf5e\udaec\ude55\ud85c\udc0a\udab0\udffa\udb75\udf86\uda87\udeb6\udbac\udfdd\udabb\udf8e\ud9c7\udce2\ud80a\udde4\ud8c8\udfab\udb97\udcdc\ud83f\uddc2\udb09\udcf7\uda64\udd00\udb44\udce2\uda93\udf31\u67b5\ud929\udd71\ud996\udeab\ud9f8\udebd\ud9db\ude9f\udbe4\uded0\ud9b9\udfac", "\u4614", "\udbfb\ude4e\ud830\udf63\ud988\udc33\ud8ce\udf50",
        33, 58090, -1623628170, 4196282038981476729L, 49449L, true, true, (char) 51773, (char) 47804,
        Double.longBitsToDouble(0x3fcabf3d53ffd720L), Double.longBitsToDouble(0x3fec0fb1dfe71457L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 17, 17, 13, "\uda6b\udc6a\ud8e7\udd62\udb9f\udc66\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud84f\udcda\udb55\udc6e", "\ua633\ucbd5\u6fee\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\uc347\ua7a4\u2bde\u8e1a\u0c75\u1774\u64b9\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udea9\ud8cf\udc0a\ud876\udecc\uda78\udf48\udbf0\udcc1",
        -1, 14792, 716646209, 9036876084368401249L, 30970L, false, true, (char) 44236, (char) 41559,
        Double.longBitsToDouble(0x3feab182bab5b425L), Double.longBitsToDouble(0x3fc4ced5c026c598L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 13, 13, "\udb84\ude2d\ud974\udde2\ud944\udc8a\ud9c2\udfba\ud8fa\udd1f\udb5a\udd84\udb69\udf9d\udb81\udd80\uda48\udd95\uda27\ude6c", "\u870c\ua5ba\uc3fd\u5b4d\ubc57\u02fd\u043c\u9e4f\u8b54\u76fe\u4b4a\uc176\u8e1a\u190b\u6848\ua4b6\u25eb\u8b19\u1d1b\u55dd", "\udbe4\uded0\ud9c7\udc57\uda48\udd61\ud8c1\udc3a\ud93a\udfeb\ud902\udfe2\ud889\udc81\udbfb\ude4e\ud917\ude14\ud9cc\udc77\ud8cf\udc0a\ud9ea\udd53\uda78\udf79\udbf0\udcc1\udb61\udf58\ud9d9\ude47\ud994\ude05\u964f\ud84e\ude5a\u9d7d\ud88a\udc0a\udb7a\uded4",
        13, 24529, 2062729600, 8551846086261007014L, 67570L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764cc70d26L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 7, 13, 13, "\udba1\udeda\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb69\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u870c\ua5ba\uc3fd\u5b4d\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a\ubc37\u6848\ua4b6\u25eb\u8b19\uc6e8\u5628", "\udbe4\uded0\ud9c7\udc57\udb99\udcd9\ud96d\udd55\ud964\uddfa\ud902\udfe2\ud889\udc81\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\uda4d\udd64\uda78\udf79\udbf0\udcc1\udb61\udf58\uda0d\udda1\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        13, 24529, 2062729600, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 6, 13, 13, "\udba1\udeda\ud852\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb69\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u870c\ua5ba\uc350\u5b4d\ubc57\u02fd\u043c\u9e4f\u576a\ud429\u1332\u2bde\u8e1a\ubc37\u6848\u943c\u25eb\u826c\uc6e8\u5628", "\udbe4\uded0\ud9c7\udc57\udb25\udfbc\ud96d\udd55\ud964\uddfa\ud902\udfe2\ud889\udc81\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\uda4d\udd64\uda78\udf79\udbf0\udcc1\udb61\udf58\uda0d\udda1\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        13, 24529, 2062729600, 8551846086261007014L, -24621L, false, false, (char) 61284, (char) 24120,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 13, 13, "\udba1\udeda\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb69\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u870c\ua5ba\uc3fd\u5b4d\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a\ubc37\u6848\ua4b6\u25eb\u8b19\uc6e8\u5628", "\udbe4\uded0\ud9c7\udc57\udb25\udfbc\ud96d\udd55\ud964\uddfa\ud902\udfe2\ud889\udc81\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\uda4d\udd64\uda78\udf79\udbf0\udcc1\udb61\udf58\uda0d\udda1\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        13, 24529, 2062729600, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 19, 9, 1, "\udba1\udeda\ud876\udc0e\udb9e\udfaa\ud835\ude2c\ud8e9\udd00\uda4a\udf26\u036c\ud8b2\udd7f\ud984\udd93\uda27\ude6c", "\u870c\ua5ba\uc3fd\ua382\ubc57\u02fd\u043c\u9e4f\u576a\uca71\u0ca7\u8b17\ub348\ubc37\u6848\ua4b6\u25eb\u61f3\uc6e8\u5628", "\udbe4\uded0\uda80\udf34\udb1e\udd99\udbe9\udcb4\ud964\uddfa\ud902\udfe2\ud889\udc81\ud874\udcd8\ud995\ude16\ud8ef\udc97\ud8ce\udf4c\uda4d\udd64\uda78\udf79\ud8d3\udd31\udb61\udf91\uda0d\udda1\ud994\uddc5\u964f\uda7a\udc90\u9d95\u3e0d\udab5\udf6c",
        24, 32519, 2062729600, 8551846086261007014L, 22130L, false, false, (char) 17278, (char) 34173,
        Double.longBitsToDouble(0x3fc2c3677de531e4L), Double.longBitsToDouble(0x3fe5f3fc2f026ebdL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 18, 2, 13, "\udba1\udeda\ud876\udc0e\udb9e\udfaa\ud9da\ude5f\ud8ba\udfe7\ud86a\udef8\udb10\ude5c\udb81\udd80\ud984\udd93\uda27\udd7d", "\u870c\u871e\uc3d1\u5b4d\ua7de\u969e\ubf8e\u7b62\u576a\u0f4a\u1332\u2bde\u8e1a\u58c8\u3c47\u9db8\u25eb\u8b19\uc6e8\u5628", "\udbe6\udd31\ud9c7\udc57\udb25\udfbc\ud96d\udd55\ud964\uddfa\ud902\udfe2\ud889\udc81\udbf0\udc59\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\uda4d\udd64\uda78\udf27\udbf0\udcc1\udb61\udf58\ud8fb\udcaa\ud994\ude69\u964f\uda7a\udc90\u9d7d\ud929\udc39\udb7a\ude73",
        13, 75345, 2062729600, 8551846085613904439L, -24621L, false, false, (char) 28368, (char) 11886,
        Double.longBitsToDouble(0x3fc644450a838374L), Double.longBitsToDouble(0x3fe23868e191f926L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 17, 13, "\udb7d\udd5c\ud836\udc8a\udb98\udd3e\ud835\ude2c\ud9dd\udf0b\udb2d\ude56\uda0c\udc9a\000\ud973\ude79\ud90b\udec7", "\u7966\uc8ee\u1330\ubc92\u8364\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\ud536", "\udb44\udce2",
        52, 78429, 703513910, -4134729178652082176L, 10079L, false, false, (char) 16224, (char) 55938,
        Double.longBitsToDouble(0x3fe0753b89d1fcbcL), Double.longBitsToDouble(0x3fcd7219ce29e368L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.JsonArray:[] |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 6, 15, 19, "\ud9d0\ude86\ud87c\udc5d\udb98\udd6e\udb26\udf22\ud8ae\udc14\udb64\udcd3\udb53\udf9d\udb81\udd80\ud984\udd93\ud90b\udec7\uda59\udfc7\u0fd9\ud899\udfcb", "\u5bad\ubbe6\uc311\u043c", "\ud9e9\udd25\uda6f\ude6d\ud942\ude72\udb9a\udf0f\uda14\udda7\udb37\udc89\udb44\udce2\uda93\udf31\u67b5\u88be\ud847\udfd4\udaee\ude76\udbcb\udd5c\uda82\udf9a\ud9c6\udf84\udb25\udfbc\ud96d\udd55\uda2f\ude66\udb92\udf46\ud876\udc8c\udbfb\ude4e\udae3\ude92\ud9ca\udf43\ud8cf\udc0a\ud865\udc6f\ud9c5\udf7a\uda2c\udc05\ud1fb\ud8bf\udce9\ud911\ude7c\udb0c\udd49\ud8df\udd08\uda4c\udc1e",
        44, 48005, -2079373847, -3896476442108471758L, 74240L, true, true, (char) 2647, (char) 43744,
        Double.longBitsToDouble(0x3f8dc8922e9c1940L), Double.longBitsToDouble(0x3fefc533e1b49288L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 10, 9, "\udb7d\udd5c\ud836\udc8a\udb98\udd3e\u407a\000\000\udb53\udf05\udb81\udd80\uda94\udf1b\000", "", "\000\000\ua100",
        57, 20289, 62415, 0L, -99966L, false, false, (char) 39935, (char) 120,
        Double.longBitsToDouble(0x3fcaa00014d9d2a4L), Double.longBitsToDouble(0x3ecdc00000000000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 7, 8, 1, "\udb7d\udd5c\ud836\udc8a\udb98\udd3e\ud835\ude2c\udb52\udd26\udb33\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\ud90b\udec7", "\u7966\u8b99\u1330\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\u8e1a", "\udb44\udce2\uda93\udf31\u67b5",
        55, 39344, -275523076, -343123009925339893L, 10079L, false, false, (char) 16224, (char) 55938,
        Double.longBitsToDouble(0x3fe0753b89d1fcbcL), Double.longBitsToDouble(0x3fcd7219ce29e368L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 9, 13, "\udb7d\udd5c\ud836\udc8a\udb98\udd3e\ud835\ude2c\udb52\udd26\udb64\udc9e\udb53\udf9d\udb65\ude80\ud984\udd93\ud90b\udec7", "\u7966\u2b70\u1330\u5bad\ubc57\u02fd\u043c\u9e4f\u367f\u0f3d\ud11d\u2bde\u8e1a", "\udb44\udce2\udb66\uddfa\u9cdb",
        55, 39344, -275523076, -5891557750844088670L, 75615L, false, false, (char) 16224, (char) 55938,
        Double.longBitsToDouble(0x3fe528bb89d1fcd2L), Double.longBitsToDouble(0x3fef5c8673f5f282L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 7, 13, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud8d6\udf8a\udb6b\udea1\udb64\udc65\udb53\udf9d\udb81\udd80\uda56\udd9c\uda27\ude6c", "\u1600\ua595\u1f8c\u5927\ubb23\u9880\u043c\u9e4f\u576a\u0f4a\u1332\u2bde|\ubc25\u709d\000\u5ae3\u3b48\uc6e8\uc1b5", "\udbe4\uded0\ud99b\udf67\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud8d3\udf4a\ud9a9\udf4c\ud84a\udce5\ud9ca\udf43\ud8cf\udc0a\udb1d\udc2b\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\uda53\udcfa\u964f\uda7a\udc90\u9d7d\udb87\udeab\ud8f0\udd88",
        33, 20905, -1272627370, 8551846086257626278L, -24621L, false, false, (char) 3804, (char) 21549,
        Double.longBitsToDouble(0x3fc65090ea838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 12, 13, "\udba1\udf23\udbc1\ude6c\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udac9\udf18\udb81\uddc5\ud984\udd93\uda27\ude6c", "\u1600\ua595\u1f8c\u5bad\ubc57\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde|\000\u6fb3\000\000\u2a44\uc6e8\uc1b5", "\udbe4\uded0\ud99b\udf67\udb25\udfbc\uda2f\uddf7\udb1c\ude66\ud815\udcf2\ud98b\udfb3\ud8f8\udc8c\udb19\udf96\ud9ca\udf43\ud966\uddf4\ud863\udce9\ued8a\u0277\uda43\udcc8\udafe\ude67\ud994\uddc5\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        33, 20905, -1272627370, 8551846086261007014L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 6, 6, "\udac1\udf41\ud875\udfd8\udb9e\udfaa\ud827\udcd9\ud9b0\uddd5\ud8e8\uddcd\ud89f\udf74\ud9e4\ude65\ud984\udd93\uda27\ude6c", "\u1600\u523c\u1f8c\u5bad\u7831\uce76\u043c\u9e4f\u8d18\u0ea7\u1332\u2bde|\000\u6fb3\ucdad\u138e\u2a9d\uc6e8\uc1b5", "\ud9a9\udf6f\ud99b\udf67\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud873\udc85\uda85\udd50\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\ud994\uddc5\u964f\udbad\ude8b\u9db1\ud88a\udc0a\udb7a\uded4",
        33, 99137, -1272627370, 6692703865087124134L, -24621L, false, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc3ed8d4a83896cL), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 6, 6, 16, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ua595\u1f8c\u6444\ua0c9\u142a\u0839\ub514\u79e6\u4b36\u1332\u2bde|\000\u6fb3\000\u93a1\u2a44\u40fc\uc1b5", "\udbc8\udce7\ud9a9\udda6\udb25\udfbc\ud928\udf14\ud891\udf32\udbf1\uddfb\ud889\udc85\udbfb\ude4e\udae3\udddc\ud9ca\udf43\ud87d\udc01\udb6b\udd13\udbbf\ude27\udbf0\udca9\udac2\udf29\ud840\udd2b\ud99e\udef3\u964f\uda7a\udc90\u9d7d\ud88a\udc0a\udb7a\uded4",
        33, 20905, -1272627370, 8551846086259761830L, -24621L, false, false, (char) 46180, (char) 64877,
        Double.longBitsToDouble(0x3fc644598a838374L), Double.longBitsToDouble(0x3fe23a764c91f926L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 8, 4, 11, "\udba1\udf23", "\u5222\uc8b5\ua178\u2dd5\ud379\u755c", "\ud84d\udc95\ud94e\udf24\ud9d7\udfcc\ud85c\udc0a\udab0\udffa\udb75\udf86\uda87\udeb6\ud8e3\uddf9\udabb\udf89\ud9c7\udce2\ud9e9\udd25\udb56\uddd1\udb97\udcdc|\000\uc139",
        -5, -1000, 1407123456, 3021511966379113912L, 97775L, false, false, (char) 49208, (char) 18981,
        Double.longBitsToDouble(0x3febed21fdff632fL), Double.longBitsToDouble(0x3fc4c87228e6149cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 6, 9, 2, "\udb8f\udcf8\udb58\udfc0\udb9e\udfaa\ud835\ude2c\ub714\ud8a5\udf92\udbef\udc9a\ud992\udcd6\udb8e\udef7\ud88b\udcde\ud9f1\uddfc\uf0bc", "\u4885\u2f86\u85d5\u7fd6\u47a0\ua549\u8154\u5078\u4cc8\ua584\u46c9\u3128\u4c96\ua4b6\u258b\u673e", "\u051a\ud9db\ude9f\udbe4\uded0\ud9c7\udc72\uda48\udf29\ud94f\udccb\udb95\uded4",
        14, 77927, 557311295, 3243611951516737895L, -8962L, false, false, (char) 50470, (char) 822,
        Double.longBitsToDouble(0x3fe5d65f8af6f866L), Double.longBitsToDouble(0x3feebdb5fdddbe54L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 4, 19, "\udb8f\udcf8\uda55\udeb5\udb02\udc1d\ud923\uddf2\ub752\udb65\uddd9\u4936\udaba\udf4d\udb6c\udfdf\udbdb\udfc8\ud9f1\uddfc\uf0bc", "\u235c\u299a\u21c2\u6b3d\u43d3\u4e1b\u7ec2\u7065\ube19\u2405\ub328\u10e9\ua49f\uc218\u258b", "\ud997\ude54\udbbf\udf57\ud9db\ude9f\udbe4\uded0\ud9c7\udc72\ud9f7\udc86\ud970\udf24\ud964\uddfa\ud971\uded8\ud88f\udd97\ud9f2\uddba\ud813\udead\ud85c\udc8c\ud995\udf7e\ud972\udea9\udaa7\udc78\ud903\udc61\ud8fc\udee9\ud9b2\uddc6\udb3c\udf5e\ud900\udc92\ud86d\udd2b",
        29, 81133, 726806235, -6213147957004288373L, -62016L, true, true, (char) 21173, (char) 13789,
        Double.longBitsToDouble(0x3fd5a10f4cc9bddcL), Double.longBitsToDouble(0x3fcd7bfe43761facL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 0, 19, "\udb8f\udcf8\udb58\udfc0\udb9e\udfaa", "\u44f9\u2b30\uba15\u2044\u67ba\ub073\u744a\u161d\u2749\u1f4a\u2f86\u21a2\u0afe", "\ud938\udfe2",
        25, 65016, 1777719128, 4265242261511325430L, 71819L, false, true, (char) 42918, (char) 49856,
        Double.longBitsToDouble(0x3feb8aa286a2ae3cL), Double.longBitsToDouble(0x3fdfbbf3d04adb76L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 14, 7, 16, "\udb8f\udcf8\udb58\udfc0\udb4e\udfa2\ud835\ude2c\ud846\udcdf\ud898\ude70\udbef\udce2\ud836\ude7e\udb18\udf92\ud88b\udc4a\ud9f1\uddfc\uf0bc\uda64\udd62\uda4c\udf77\ud980\udeb9\ud9cd\udf32\udb31\udc0c\u78cf\udacf\udcae\udbfe\udf3b\ud938\udfff\uda51\udd2f\ud841\udff9\udb79\udf0e\uda48\udffb\ud9ba\udee6\ud9dc\udc58", "\u673e\ua231\ub085\uac0f\u5a89\u81e0\u0809\u2522", "\ud94f\udfc1\ud889\udc85\ud9ed\ude99\ud813\udf42\ud8a1\ude38\ud82f\udc89\ud972\udea9\ud9c9\udff0\udabf\udede\udb0e\udd14\ud83c\udf49\udadf\udd9b\ud843\udecd\udac5\udfb9\ud895\udcd3\ud95c\udedf",
        56, 49155, 153767680, 7620555377419346452L, -74168L, true, true, (char) 41169, (char) 27847,
        Double.longBitsToDouble(0x3fe971e566298046L), Double.longBitsToDouble(0x3fdca703d70f92fcL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 16, 13, "\udba1\udfca\ud876\udc0e\udb9e\udfaa\uda2c\udc87\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\udb02\udf65\uda27\ude6c\ud82c\udf7fE\000\udae5\udfd2\ud820\udc04\udab0\udf92\udb75\udf86\ud83e\udeb1\udbac\udfdd\udabb\udf8e", "\u1332\u2bde\u8e1a\u9123\u707a\ua4b6\u25eb\u8b19\uc6e8\u64fc\u7ae4\u663d\uc738\u31dd\ua7a9\u30fe\u327e\ud3e4\uacf1\u8d7b\u4786\uc05e\u24ce\u3bfc\u81e0\u530d\u6164\u63e3\ubd2c\ub0f0\u4413\u50ca\u4d58\ub96e\u6bb2", "\ud97b\ude56\udb6c\udff5\ud894\udcd0\uda6d\udf8d\udb49\udfab\ud8dc\udd7f\udb75\udea4\udbf7\udc9b\ud829\udeff",
        49, 12908, 78172096, -6203144062537443427L, -11137L, false, false, (char) 8385, (char) 59085,
        Double.longBitsToDouble(0x3fe6937a0672b4b4L), Double.longBitsToDouble(0x3fefa006b45b0640L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 3, 6, "\udba1\udf83\ud876\udc0e\udb9e\udfaa\uda2c\udc87\udbfc\ude74\udb1d\uddb0", "\ua46a\ud093\u00ef\000\u00f1", "\ud8c4\udd1c\udb28\udc47\uda0c\udeee",
        9, 25567, 1944390061, 2696243241736766328L, 46308L, false, true, (char) 8064, (char) 26120,
        Double.longBitsToDouble(0x3fd1fc3785b536d8L), Double.longBitsToDouble(0x3fd367484b7053dcL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 19, 3, 2, "\udbab\udfd0\ud992\udf5b\uda9a\uddcb\udb54\udce4\uda9f\udfe6\ud8fa\udca8\udbf2\udfa4\udb70\uddea\u88e8\uda27\ude6c\ud9f1\ude51\udad6\udc8a\uda02\udf5e", "\u4cc8\u9c5b", "\ud89e\ude9f\uda29\udf5b\ud9e9\udc7f\ud872\udce1\udb26\ude24\uda85\udce0\ud89d\udfe9\ud888\ude96\ud836\ude8a\ud9dc\udd22",
        23, 62997, 396006836, -8912380262659237309L, -36980L, true, false, (char) 49288, (char) 23993,
        Double.longBitsToDouble(0x3fc3035d96e2c458L), Double.longBitsToDouble(0x3fbe94313c3f7008L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 7, 10, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude4c\udb52\udd26\udb64\udc65\udb53\udf9d\udb37\udd7b\udac1\udc12\uda27\ude6c\ud9f1\ude51\ud84d\udc05\uda02\udf5e\udb5e\udc6e\udafb\udcdd\ud92e\ude79\ud840\ude20", "\uae09\u4edd\u0f4a\u1332", "\udaee\udd00\udb8b\udc41\udb44\udce2\uda93\udf31\u67b5\uda63\udfae\ud91c\ude56\ud907\udf63\ud9db\ude9f\u1cac\udbf6\ude6b\ud833\ude1a\udb0d\ude95\ud90d\uddc4\udbd1\udf87",
        2, 87820, -54782450, 4044532432217191595L, 59907L, false, false, (char) 16245, (char) 8506,
        Double.longBitsToDouble(0x3fe6b1fc12dfd035L), Double.longBitsToDouble(0x3fd617d69244b1f8L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 11, "\udba1\udf23\ud876\udc0e\ud887\udde7\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80", "\u840b\u211d\u159f\ua595\u1f8c\u5bad\u4a65\u3ad3", "\ud9c7\udce2\ud9e9\udd25\uec84\udb97\udc5d\ud83f\uddc2\udaee\udd00\uda64\udd00\udb44\udce2\uda93\udf31\u67b5",
        14, 79836, -356024527, -8954005931247722846L, 10079L, false, false, (char) 34656, (char) 55726,
        Double.longBitsToDouble(0x3fe0753b8de75e85L), Double.longBitsToDouble(0x3fcd7219ce29e368L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 19, 19, 1, "\ud827\udce4\ud92d\uddc6", "\uc8b5\ua0a8\u2dd5\u9f6a\ua46a\u8f67\ub0c8\u6d79\u1600\u7b5b\u1f8c\u5bad\ubc57\u02fd\u4b5d\ucf14\u82f7\u1821\u789c\u713f\u8ded\ubc37\u9a94", "\udb3f\uddb7\ud910\udfe5\ud91c\ude56\ud8c8\udd04\udb4a\udfa3\udb7c\ude2f\ud81e\ude9e\ud8fd\udf93\ud96d\udd55\ud964\uddfa",
        47, 19953, -1485720697, -235288833010263599L, -8982L, false, false, (char) 27199, (char) 56343,
        Double.longBitsToDouble(0x3fda6576be834182L), Double.longBitsToDouble(0x3fe75955b967d877L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.JsonObject:{} |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 7, 15, 19, "\udbba\udd5b\udbae\udd9c", "\uc8b5\ua0a8\u6776\ud379\ua46a\u8f67\u9fab\ub9c6\u6394\u1207\u1f8c\ud6ac\ubc57\u02fd\u043c", "\udac6\udca6\udb56\udda7\ud9e9\udecb\ud83c\udd92\ud89d\udc19\ud913\udd76\ud96b\udc36\uda62\ude48\u67b5\uda63\udfae\ud91c\ude56\ud8c8\udd04\udb4a\udfa3\udbe4\uded0\ud81e\ude9e\ud8fd\udf93\ud96d\udd55\ud850\ude51\ud9f0\udd0a\udb13\udf80\udba1\ude61\udac9\udfb8\udbc4\udfcb\ud9f7\udf19\ud972\ude95\udabd\udfaa\udbf0\udc6d\ud9f6\udfe2\ud845\uddd1\ud907\udedf\uda57\udd32\udb24\udd23\udb99\udd14",
        55, 36767, -161939008, 3483441405705326422L, 89094L, true, true, (char) 42140, (char) 38262,
        Double.longBitsToDouble(0x3feb9c24663a4ffbL), Double.longBitsToDouble(0x3fecf9709d5d33b6L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\0121=com.google.gson.internal.bind.JsonTreeWriter:@? |this=com.google.gson.internal.bind.JsonTreeWriter:@?\012",
        Z.run(T, 2, 14, 14, 13, "\udba1\udf23\ud8bc\ude33\ud837\udc00\ud835\ude2c\udb52\udd26\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c\ud9f1\ude51\ud819\udcab", "\u1f8c\u5bad\u06ca\u60dc\ub945\ub795\u5794\u0c49\u1332\u2bde\u8e1a\u5273\u1786\ua4b6\u6cf4", "\ud919\ude72\ud8c8\udd04\ud9db\ude9f\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\ud9b8\udf7c\uda6c\uddca\uda82\udc41\udae3\udddc\ud9ca\udf43\ud8cf\udc0a\ud972\ude95",
        56, 82142, 519151676, -7871756937117752077L, 900L, false, true, (char) 47804, (char) 21903,
        Double.longBitsToDouble(0x3fd7b7a05b03ecb2L), Double.longBitsToDouble(0x3feab72cee609325L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 5, 3, "\udba1\udf23\ud876\udc0e\ud909\udd20\000\000\000\udb53\udf05\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ua595\u8152\u7ed0\ubbc2\u87fb\ua644\u9e4f\u75d5\u0f4a\u8460\u00ee\u90e3\ubc37\u1786\ua4b6\u25eb\u8b19\uc6e8\uc1b5", "\udbe4\uded0\ud9c7\udc72\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude22\016\udb8c\udd66\ud8cf\udc0a\udb3c\ude9a\uda78\udf48\udbf0\udcc1\udac2\udf29\ud840\udd2b\udb1f\udf4b\000\udae7\udf67\u7f59\ud88a\udc0a\udbfe\udc8a",
        42, 54601, 1148336480, 8551846086261007014L, 42451L, true, false, (char) 5221, (char) 64877,
        Double.longBitsToDouble(0x3fc64a658a838374L), Double.longBitsToDouble(0x3fd2f09c9b6106caL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 9, 0, "P", "\u51a8\u4df5\ua18a", "\ud984\udd93\ud93b\udd15\000\ud9ec\uddb5\u1fe2\000\000\ud822\udf17\udb75\udef1\u87fb\000\000\ud9ff\udd3f\ud9e9\udd25\udb9a\udc54",
        15, 49300, 10883328, -1015505920L, -9888L, false, true, (char) 10918, (char) 40956,
        Double.longBitsToDouble(0x3feb8f7c9ea2ae3cL), Double.longBitsToDouble(0x3fdfbbf3da4adb76L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 17, 13, "\udb7d\udd5c\udbc1\udf10\000\000\000\udb2d\ude56\uda0c\udc9a\000\ud973\ude79\ud90b\udec7", "\u7966\uc8ee\u1330\ubc92\u8364\u02fd\u043c\u9e4f\u576a\u0f4a\u1332\u2bde\ud536", "\udb44\udce2",
        52, 78429, 703513910, -4134729178652082176L, 10079L, false, false, (char) 16224, (char) 55938,
        Double.longBitsToDouble(0x3fe0753b89d1fcbcL), Double.longBitsToDouble(0x3fcd7219ce29e368L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 10, 9, "\udb7d\udd5c\ud836\udc8a\udb98\udd3e\u407a\000\000\udb53\udf05\udb81\udd80\uda94\udf1b\ud936\ude1b\000\udbfb\udf10\ud962\udc2e\ufb9d\u6238\000\ua100\uda53\udc09\udbac\udfdd\ufbcf\000\000\udbc9\udc0f", "\u0a5c\u1f75\ucc8e\000\u8b19\ud650\000\u5169\uccc0", "\ud8c6\ude3c\ud993\udec6\u091a\ud963\udfd7\ud830\udcb7\uda1c\ude17\ud87e\udf29\ud903\udede\ud8a6\ude99\ud9f7\udf9c\udacc\udfc3\udbfb\udc8f\ud99c\ude5d\ud94f\udff1",
        8, 96047, -36659444, 4812177654279656359L, 98661L, true, false, (char) 4510, (char) 61331,
        Double.longBitsToDouble(0x3fefd65ff8d503d6L), Double.longBitsToDouble(0x3fdc3a7170c4ac9cL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 10, 9, "\udb7d\udd5c\ubf08\u00ab\000\000\000\u1800\000\000\000", "", "\000\000\ua100",
        57, 20289, 62415, 0L, -99966L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fcaa0001401d2a4L), Double.longBitsToDouble(0x3ecdc00000000000L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 9, 0, "\ub8bd", "\u51a8\u4df5\ua18a", "\ud984\udd93\ud93b\udd15\u488a\ud9ec\uddb5\u1fe2\000\000\ud822\udf17\udb75\udef1\u87fb\000\000\ud9ff\udd3f\ud9e9\udd25\udb9a\udc54",
        15, 49300, 10883328, 53933367L, -9838L, false, true, (char) 52258, (char) 58002,
        Double.longBitsToDouble(0x3feb8f7c9ea2ae3cL), Double.longBitsToDouble(0x3fdfbbf3da4adb76L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 10, 9, "\uda3d\udcfe\udbc1\udf10\000\000\000\000\udb4d\udf05\ud871\udd78\000\ud936\ude1b\000\uec0f\ud8ed\udc0d\000\u6238\000\ua00d\000\000\ufbcf\000\000\udbc9\udc0f", "\u0a5ct\ucc8e\000\u8b19\ud650\000\u5169\uccc0", "\000\000\u090a\ud963\udfd7\ud830\udcb7\uda1c\ude17\ud87e\udf29\ud903\udede\u5471\000\udacc\udf7c\udbfb\udc8f\ud99c\ude5d\ud94f\udff1",
        43, -1000, -50331648, 4755882658937525159L, -36517L, true, false, (char) 6469, (char) 61331,
        Double.longBitsToDouble(0x3ecfe00000000000L), Double.longBitsToDouble(0x3fdc3a7170c4ac9cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 18, 13, "\udba1\udf23\ud876\udc0e\udb9e\udfaa\ud835\ude2c\ud8d6\udd28\udb64\udc65\udb53\udf9d\udb81\udd80\ud984\udd93\uda27\ude6c", "\u1600\ud7b2\u97d6\u0d11\ubc62\u02fd\u6a6b\u3a5b\u497d\ud780\u1332\u2bde\u8e1a\u33d2\u1787\ua4b6\u25eb\uae5a\u7c99\uc11d", "\udbe4\uded0\ud860\ude6f",
        -1, 3509, 1133620735, -8852061848489641415L, 17525L, false, true, (char) 4137, (char) 37779,
        Double.longBitsToDouble(0x3fae4f9cec8a9f10L), Double.longBitsToDouble(0x3fea0d0608a32ab7L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 10, 9, "\uda3d\udcfe\udbc1\udf10\000\000\ud9d0\ude01\000\udb4d\udf05\ud871\udd78\000\ud936\ude1b\000\uec0f\ud8ed\udc0d\000\u6238\000\ua00d\ud98e\udda6\000\ufbcf\000\000\udbc9\udc0f", "\u0a5ct\ucc8e\000\u8b19\ud650\000\u5169\uccc0", "\000\000\u090a\ud963\udfd7\ud830\udcb7\uda1c\ude17\ud87e\udf29\ud903\udede\u5471\000\udacc\udf7c\udbfb\udc8f\ud99c\ude5d\ud87d\udf44",
        27, -837, -50331648, 4755882658937525159L, -36517L, true, false, (char) 2885, (char) 10180,
        Double.longBitsToDouble(0x3ecfe00000000000L), Double.longBitsToDouble(0x3fd82a7170c4ac9cL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 17, 13, "\000\000\000\000\000\000\000\000\udaef\ude77\ud90b\udec7", "\u7966\uc8ee\u1330\ubc92\u8364\u02fd\u043c\u9e4f\u576a\u0f4a\u26d1\u2bde\ud536", "\udb44\udce2",
        52, 78429, 703513910, -4134729178652082176L, 10079L, false, false, (char) 16224, (char) 55938,
        Double.longBitsToDouble(0x3fe0753b89d1fcbcL), Double.longBitsToDouble(0x3fcd7219ce29e368L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 9, 3, "P\ud8ee\ude17l", "\ua18a\u2dd5\ud379", "\000\ud9ec\uddb5\u1fe2\000)\ud822\udf17\udb75\udef1\u87fb",
        1, 46448, -229609970, -7649815931689183096L, -100000L, false, false, (char) 32919, (char) 40100,
        Double.longBitsToDouble(0x3fce6d003c877598L), Double.longBitsToDouble(0x3fdcab7656f1dfb0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 17, 18, "\udb7d\udd5c\ud836\udc8a\udb98\udd3e\ud835\ude2c\ud9dd\udf0b\udb2d\ude56\uda0c\udc9a\000\ud973\ude79\ud90b\udec7\ud808\udec9\uda4f\udc93\ud879\udc25\ud939\udc07\uda70\udfc0\ud90b\udc07\udb67\ude93\uda87\udeb6\udbac\udfdd\udabb\udf8e\ud9c7\udce2\ud9e9\udd25\udb56\uddd1\udb97\udcdc\ud905\udc85\000\uc139\udb44\udce2\uda93\udf31\udad8\udf0e\uda63\udfae\ud91c\ude56\000\ud9db\ude2e\udb92\udf27\ud9c4\ude20\udb25\udfbc\ud96d\udd55\ud964\uddfa\uda8e\udd68\ud889\udc85\udbfb\ude4e\udae3\udddc\ue529\uda00\udc4d\uda25\udec7\udbdc\udee8\ud865\uddf9\uda4c\uddae\udb47\udc18\ud8fd\udc9d\ucc3c\udba4\uddf5\uda35\udca5\udb5f\udf99\ud8e9\udcf3\udb83\udd68\udbd6\udfa1\udb0c\udf3e\ud8d0\udc95\ud8cd\udfc6\udb16\udda3\ud8b5\udc79\uda21\udfcc\u69cc\u89d4\uda39\udfa9\ud81b\udfa2\ud96d\udd64\ud891\udcb0\udb08\udd7a\ud919\udd8f\ud8fc\udfd6\u3fe1\udb91\udc60\uda22\udf73", "\u5bc7\u3417\u3306\u5aa0\ubeca\u2bc9\u9eef", "\udbd4\uddb0\ud98c\ude20",
        34, 20965, -510578766, 4519261854715611060L, 63362L, false, true, (char) 53648, (char) 13354,
        Double.longBitsToDouble(0x3fe039c68f31fb3fL), Double.longBitsToDouble(0x3fe102fde1fc2486L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 10, 9, "\uda3d\udcfe\udbc1\udf10\000\000\000\000\udb4d\udf05\ud871\udd78\000\ud936\ude1b\000\uec0f\ud8ed\udc0d\udb3a\udd3c\u7df6\000\ua00d\000\000\uda84\udddd\000\000\udbc9\udc0f\ud950\udc28\ud81b\udfce\ud9ed\udfd8t\ud837\udc07\000\u67b5\ud80f\udd44\000\ud9c1\udee0\udab3\udd5d\udb91\udc37\u0081\000\000", "\u50c5\ucce2\u7661\u4712\u5471\000\ucbc2\ua3ba\u0843\u85d3\uca0b\000\ua471\u804e\ua92c\000\u9fa6\u3493", "\000",
        17, 24027, 1251735650, -7308710042269849570L, -29148L, false, true, (char) 9001, (char) 49563,
        Double.longBitsToDouble(0x3fc051f658335df8L), Double.longBitsToDouble(0x3fd769a49fc1194aL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 10, 9, "\uda3d\udcfe\udbc1\udf10\000\000\000\000\udb4d\udf05\ud871\udd78\000\ud936\ude1b\000\uec0f\ud8ed\udc0d\udb3a\udd3c\u7df6\000\ua00d\000\000\uda84\udddd\000\000\udbc9\udc0f\ud950\udc28\ud81b\udfce\ud9ed\udfd8t\ud837\udc07\000\u67b5\ud80f\udd44\000\ud9c1\udee0\udab9\udde1\000\000\000\000", "\u50c5\ucce2\u7661\u4712\u5471\000\ucbc2\ua3ba\u0843\u85d3\uca0b\000\ua471\025\000\000\u9fa6\u3493", "\000",
        17, 24027, 1241514082, -7308710042269849570L, 91488L, false, true, (char) 9001, (char) 17847,
        Double.longBitsToDouble(0x3fc0400018335df8L), Double.longBitsToDouble(0x3fd769a49fc1194aL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 0, 0, "\uda3d\udcfe\udbc1\udf10\000\000\000\000\udb4d\udf05\ud800\udc1f\000\ud936\ude1b\000\000\ud8ed\udc0d\000\000\000\ua00d\000\000\uda84\udddd\000\000\udbc9\udc0f\000\000\ud9ed\udfb6t\000\000\udbec\udcde\ud80f\udd0e\000\000\000\000\000\000\000", "\u50c5\ucce2\u7661\u4712\u5471\000\ucbc2\ua3ba\u0843\u85d3\uca0b\000\ua471\025\000\000\u9fa6\u1ea0", "\000",
        -5, -1000, 1241513984, -7308710042269849570L, -100000L, false, false, (char) 5120, (char) 44777,
        Double.longBitsToDouble(0x3fd45e1e30008b6eL), Double.longBitsToDouble(0x0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.stream.JsonWriter|value|boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|double|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Number|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|long|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.internal.bind.JsonTreeWriter|beginArray||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|beginObject||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|close||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|endArray||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|endObject||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|flush||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|get||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|name|java.lang.String|new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|nullValue||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.internal.bind.JsonTreeWriter|peek||new:com.google.gson.internal.bind.JsonTreeWriter:",
    "M|com.google.gson.stream.JsonWriter|value|boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|double|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Number|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|long|new:com.google.gson.stream.JsonWriter:java.io.Writer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
