package com.google.gson.stream;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonWriter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 17, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 12, 14, "\ud9d8\udfee\ud9fa\udc83\u159c\ud9a1\udcf1\uda97\udf37\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\udbb5\udd11\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\u5b93\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\uda80\udf36\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, 31459L, true, true, (char) 18325, (char) 17041,
        Double.longBitsToDouble(0x3f6d79a4e5232400L), Double.longBitsToDouble(0x3fe671c80f83df7eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 14, 17, 9, "\udb9e\udd2c\ud9fa\udc83\u159c\udb0e\udda8\udb82\udef8\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 11, 17, 9, "\udb11\ude8a\ud826\ude64\u15c8\udbe4\udfb6\ud961\udc63\ud934\ude7a\ud821\ude6f\uda04\udecf\ud81e\uddfe\udae3\udd7c", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\uda58\udcce\ud843\udc53\ud93c\udc45\ud864\uded5\ud882\udd66\udbfa\udd21\ud805\udd17\ud8b5\udc8a\ud9b2\udd60\udb63\udce3\ud8f2\ude67\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 91691, -426608368, 1089553360899379949L, -46871L, false, true, (char) 58352, (char) 34653,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 17, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\u043e\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9cd\uddb2\ud8c2\ude02\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 39097, -426608269, 1089553360899994266L, -46871L, true, true, (char) 32555, (char) 46446,
        Double.longBitsToDouble(0x3fe2f70e7574bd59L), Double.longBitsToDouble(0x3fb80473bed455b8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 9, 7, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udead\ud8ce\uddda\udac1\ude47\ud832\udc70\ud932\udf1c\uda6f\ude98\udb97\udd0d\ud9ae\udce9\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06", "\ucbb0\u7086\ud685\u6bb2\u88bd\u9bbf\u8b2d\u455c\u905f\u0baf\uc4de", "\uda87\udc33\uda65\udcc6\udaef\udd6f\ud95f\udff3",
        32, 5565, -112285502, -3088571633361089749L, -15994L, true, false, (char) 64000, (char) 56151,
        Double.longBitsToDouble(0x3fd2330464a2f0d6L), Double.longBitsToDouble(0x3fbdf6213a126330L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 16, 17, 9, "\ud835\udcb4\uda06\udda1\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\uda73\udf01", "\u04a6", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d",
        40, 22649, 388164597, -1432847621410303627L, 77406L, false, false, (char) 6036, (char) 19243,
        Double.longBitsToDouble(0x3fe07852c7b4e30dL), Double.longBitsToDouble(0x3fe0fa9f7208f89bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 0, 0, "\ud9d8\udfee", "\uae40\u6dfc\u5d75\u008f\u93d9\uca08\u7fd9\u5e57\u4124\u4fc1\u12a6\ubbdf\u899c\u9bc6\u3b2c\u00a5\u7a61\ub173\ua06b\u00a8\ucbb0\u416f\ud685\u6bb2\u88bd\u9bbf\u8b2d\u455c\u905f\u1ff6\uc4de\ud576\u9735\u89a0\u0e18\uc913\ubb4f\ua8ed\u19bf\u48d3\ucda9\u03f4\uc4d6\u4dc8\u78a6\u2939\u815e\u21ab\u5d98\u098c\ua463\u17e9\u5d3f\u5280\u72b9\uceb3\u4aad\u88ca\uc0dd\uabd8\ub9ae\ubdb1", "\uda7a\udc3b\ud915\ude1e\uda7f\udd07\ud9a2\ude0c\udbdb\udfb0\ud926\udd90\udb75\udca8\ud8bd\udd00\ud932\uddd3\udabd\udcbd\uda4c\udd19",
        13, 26489, 342780837, -7415831491396259305L, 92759L, true, false, (char) 26080, (char) 9784,
        Double.longBitsToDouble(0x3febe122da25a6ebL), Double.longBitsToDouble(0x3fe4e243f8a4e61bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 5, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud923\uddf1\udb2d\udf2f\ud9e0\udfe6\uda5f\udd06\ud920\udec5\udbc3\udd6a\udb62\udc67\ud990\ude9e\ud882\udd5a\udbfa\udd21\udb8a\udcd2\udaf8\ude39\ud8b7\udc13\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 15, 7, 17, "\ud9d8\udfee\ud9fa\udc83\u159c", "\u5d75\u2c0d\u7b0b\uca08\u7fd9\u5e57\u4124\u4fc1\u12a6\ubbdf\u899c", "\ud8d7\udc83\ud9e0\udff1\udb26\ude03\ud83e\udff9\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udf37\u8209\udb6e\udf94\udbd9\uddb6\uda65\udcc6\udaef\udd6f\ud95f\udff3\ud841\udfe6\ud835\udf55\u805d\ud93f\uddf0\ud969\ude88\ud967\udc4a\udb1d\udfe2\ua978\ud8da\udca5\uda43\udd76\udbe6\udc75\ud98d\ude6a\ud9cf\udeb7\ud860\ude94\ud866\udea1\udbe1\uddce\ud9c9\udfb8\ud91c\udded\ud8b4\udc3d\udaea\udd28",
        22, 6503, -1916267831, 5652175559658868924L, -1376L, true, false, (char) 1319, (char) 27716,
        Double.longBitsToDouble(0x3fee059429312754L), Double.longBitsToDouble(0x3fec56258ca0f483L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 10, 17, 18, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, -3889380098234191135L, -46871L, true, true, (char) 6385, (char) 62298,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 1, 17, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 13, 17, 9, "\udbdf\udf96\uda07\ude09\udba2\ude19\udbeb\uddb6\ud969\udcd6\ud8af\udc82\ud821\ude6f\udb80\udd36\ud919\udfee\udac1\ude47", "\ud7c7\u12a6\ubbdf\u899c\u132f\u1e46\u7bee\u7a61\ub173\ua06b\u00a8\u20b1\u416f\ud685\u6bb2\u73c8\u9bbf", "\ud8c2\udd27\ud9fc\uddad\udad9\udc51\ud85a\ude32\uda26\udf90\udbd9\uddb6\uda65\udcc6\udaef\udd6f\ud95f\udff3\ud841\udfe6\udafc\udf99\ud9a6\ude15\ud93f\uddf0\ud933\udda3\ud906\ude9a\uda61\udf8d\ua978\ud8da\udca5\uda43\udd76\ud85a\udf50\ud94c\ude21\ud9a5\udf33\ud90b\udf68\ud8af\udc0f\ud9d4\udd01\udaf5\udc68\ud94f\udcbc\udbb8\ude1a\udbae\udc39\udbf9\udfbb\udbde\udf63\udb8e\uddc2\uda60\udffa\ud8a8\udf90\udb0d\udf84\udab5\udf73\ub498\ud84a\udf7c\ud93a\udeec",
        16, 31600, 1642163106, -3284541972838697482L, -46209L, false, true, (char) 59742, (char) 23370,
        Double.longBitsToDouble(0x3fc22732f3fdb248L), Double.longBitsToDouble(0x3fc13f5a6b81f2ccL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 2, 15, 9, "\ud9d8\udfee\ud827\udd9b\u159c\udbeb\uddb6\ud969\udcd6\ud934\udf5f\udb5d\udf45\uda04\udecf\udb23\udc93\udac1\ude47", "\u35c1", "\udb80\ude67\ud9f8\ude5b\ud979\ude3c\udb1b\udfb8\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\u74cd\ud9d3\uddaf\ud8c2\udd27\ud96e\udeb9\ud930\udedc\u8209\udb85\ude07\udbd9\uddb6",
        28, 3118, -420578790, 1089553360899994266L, -46871L, true, true, (char) 28762, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed21e80L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 19, 17, 9, "\ud9d8\udfee\ud9fa\udc83\ud984\udcba\ud9f9\udd23\uda50\uddc6\ud8cb\uddac\udb4d\udf20\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\ud999\ude43\ud84b\ude40\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c05bffe8cL), Double.longBitsToDouble(0x3fb80516fed455b8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 9, 0, 13, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\u82d0\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\u634c\ud8d6\udfc6\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\udabe\udd25\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089308161217065626L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 6, 18, 1, "\udaa8\udfe9\ud9fa\udc83\u159c\ud849\uddc5\ud8ed\udea3\udaed\ude2a\ud848\ude65\udba6\udec7\u515d\ud991\udea5", "\u1e37", "\udb80\ude62\ud9f8\ude5b",
        38, 30734, 429403391, 1306866277488881344L, 62334L, true, false, (char) 5301, (char) 6036,
        Double.longBitsToDouble(0x3fbec7ac307852c0L), Double.longBitsToDouble(0x3feda7186e1f53eeL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 2, 19, 9, "\ud9d8\udfee", "\uae40\u6dfc\u5d75\u2c0d\u3ea2\uc9b6\u7fd9\u5e57\u4124\u4fc1\u12a6\ubbdf\u899c\u9bc6\u3b2c\u00a5\u7a61\ub173\ua06b\u00a8\ucbb0\u416f\ud685\u6bb2\u234c\u3cb7\u8b2d\u455c\u905f\u0baf\uc4de\ud5e6\u9735\u89a0\u0e18\u0315\ubb4f\ua8ed\u19bf\u48d3\ucda9\u03f4\uc4d6\u4dc8\u78a6\u2939\u815e\u039c\uc2bd\ua502\u232e\u5682\ub6cd\u9df6\u620f\u0873\u045e\u5b38\u1a34\u69ab\u8554\u7a43", "\ud9c7\ude5d\udaa6\ude76\udad3\udcc4",
        35, 88198, 1817227210, -709061463146504276L, -89533L, false, false, (char) 32067, (char) 48748,
        Double.longBitsToDouble(0x3fb6f0471d754268L), Double.longBitsToDouble(0x3fe367d2887d0998L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 8, 17, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47\uda15\udd81\ud932\udf1c\uda6f\ude98", "\u899c\u9bc6\u3b2c\u00a5\u7a61\ub173\ua06b\u00a8\ucbb0\u416f\ud685\u6bb2\u88bd\u9bbf\u8b2d\u455c\u905f\u0baf\uc4de\ud5e6\u9735\u89a0", "\ud95f\udff3\ud841\udfe6\ud835\udf55\u805d\ud93f\uddf0\ud933\udda3\ud967\udc4a\ud8b2\ude0d\ud97c\udf37\ud8da\udc2f\uda43\udd76\ud8db\udc10\ud937\ude1e\udb52\udc55\ud9c6\udc99\udbef\udcb7\ud93a\udcd4\udb93\ude63\ud8b4\udebe\udb78\udf74\ud983\uddb8\udb56\udeef\ud8ea\udf12\u4097\uda63\udd3f\ud839\udd8f\u646c\ud61f",
        16, 31941, -355363643, 1364951053606353213L, -9191L, true, true, (char) 21614, (char) 46153,
        Double.longBitsToDouble(0x3fe0a51c73bab2adL), Double.longBitsToDouble(0x3fd2c32f18e00eb8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 12, 17, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47\uda15\udd81\ud932\udf1c\uda6f\ude98\ud831\udfec\ud9c6\udc9c\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\udae8\uddf0\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6\uda65\udcc6", "\ua8ed\u19bf\u48d3\ucda9\u03f4\uc4d6\u4dc8\u78a6\u2939\u815e\ub20d", "\udb04\udd22\u968c\ud8d1\udcb1\udae1\udfdd\udaba\udca4",
        41, 11751, 128409212, 2652805596138255008L, 32087L, false, false, (char) 58875, (char) 31123,
        Double.longBitsToDouble(0x3fef73bd02863d7fL), Double.longBitsToDouble(0x3fd89fbad2a6157eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 17, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8ae\ude82\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbf9\udde8\udb4c\ude89\ud866\udd16\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 37614, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 19, 17, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud899\udf00\udaf0\udcd1", "\ub8ae\u12f3\ubbdf\u899c\u9bc6", "\udad7\udd76\ud851\udf28\udb68\udef6\ud88a\ude16\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21",
        -5, 71407, 1408122804, -532614294707238392L, -59810L, false, false, (char) 57294, (char) 29631,
        Double.longBitsToDouble(0x3fe1961c5a362bc9L), Double.longBitsToDouble(0x3fd7336bbf7a0f24L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 8, 1, "\ud971\udf66", "\u9435\u7df6\ua4c5\u896e\u265a\u194a\u7fd9\u908e\u92d9\u5ba3\u6ae6\uc24c\u0ea0\u665d\u3c4e\u8221\u9ec4\u8f0e\ud70e\u0a24\u703f\u2067\u05d0\u951e\ud5f7\u2c03\u91e7\u4913\u7c69\u0baf\uc4de\u13d5\u8662\u5899\u4b08\u6c8b\u6e13\u1487\ud3e0\u48d3\u7725\u04c5\u6614\u25f0\u8939\ud313\u54ae\u9961\uca75\ucead\u55a4\u9f41\u39b9\u10a6\u8d81\u4ffe\u399a\u0724\u60d3\u261c\ud3e7\ub3eb", "\udbd3\udf04\udaae\udc06",
        14, 7528, 495684502, -900081843318523101L, -68690L, true, true, (char) 599, (char) 54880,
        Double.longBitsToDouble(0x3fe1f9243b6baf46L), Double.longBitsToDouble(0x3fe29b234650d57fL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 17, 7, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6", "\u2c0d\u7b0b\uca08", "\ud932\udf1c\uda6f\ude98\udb97\udd0d\ud9ae\udce9\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21",
        -5, 36591, 1408122804, -532614294716937720L, -57894L, false, false, (char) 57294, (char) 29631,
        Double.longBitsToDouble(0x3fe1961c5a362bc9L), Double.longBitsToDouble(0x3fd7336bbe05cd24L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 14, 12, 14, "\ud9d8\udfee\ud975\udc5b\u159c\ud9a1\udcf1\uda97\udf37\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u6d7e", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\udb91\udf11\uda5f\ude21\u7b15\ud928\ude4a\ud98d\udd29\ud882\udd5a\u5b93\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\uda80\udf36\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, 31459L, true, true, (char) 30100, (char) 17061,
        Double.longBitsToDouble(0x3f6d79a4e5232400L), Double.longBitsToDouble(0x3fe671c80f83df7eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 17, 9, "\udb9e\udd2c\ud9fa\udc83\u159c\udb0e\udda8\udb24\udee9\000\udae5\udfd2\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u8e12", "",
        -5, 66464, -567975092, -6389436079606283591L, 68448L, true, true, (char) 7671, (char) 18262,
        Double.longBitsToDouble(0x3fe431be2f53a840L), Double.longBitsToDouble(0x3fbec7ac307852c0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 19, 9, "\ud96d\udf96\ud9fa\udc83\u159c\udb0e\udda8\000\000\ud801\udfe0\uda04\udecf\ud8ce\uddda\011", "\u8e12", "\udb80\uddb3\ud9f8\ude5b\ud8dc\udd4d\ud8cc\udf83\u0be3\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\u2c7b\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        38, 92854, -426608269, 1089553359553229466L, -46871L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd0000003bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 3, 9, "\ud936\udc79\uda5b\udeda\uda29\udea4\ud80a\ude5b\ud8c2\udc34\u9ba8\ud2ed\ud9b3\udec3\ud81e\uddfe\uda80\udd60\udb47\ude23\uda53\udcce\uda6f\ude98\udb97\udd0d\ud9ae\udce9\udb80\ude67\ud85f\udd9f\ud80f\udf81\ud864\udc09", "\ubfa5\ua243\ua77b", "\udbfa\udd21\ud805\udd17\udb50\udf98\ud83e\udf3e\udbb1\ude9a\ud8e8\ude70\ud968\udc25\ud930\udedc\uda20\ude08\udb6e\udf94\udbd9\uddb6\udaa4\udc40\ud86f\ude00\udab2\udf42\ud841\udfee\uda1b\udfa7\u805d\ud8c0\udfd1\ud968\ude14\ud9f3\ude37\udb3f\ude1d\uda8b\udfc8\udb78\udf6b\uda43\udd76\ud8ad\udfd9\ud942\udcf5\ud831\udfc5\udb17\udd4e\ud968\udedc\ud8df\udf49\udad9\udebf\ud9c6\uddf2\ud8fa\udc72\udbc8\uded8\ud96c\udfff\uda5d\udc43\ud97f\udf48",
        15, 50658, 286300055, 1401526728614941469L, -33267L, true, true, (char) 19943, (char) 18212,
        Double.longBitsToDouble(0x3feac37db6245b25L), Double.longBitsToDouble(0x3fd9064333636ea4L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 17, 0, "\udb20\ude40\udaf6\udd0f\udbf6\udcb0\udbeb\uddb6\ud969\udcd6", "\u7b0b\uca08\u7fd9\u5e57", "\udb97\udd0d\ud9ae\udce9\udb80\ude67\ud9f8\ude5b\ud98d\udd4f",
        43, 50143, 315225915, -8166874679377440395L, 26805L, false, false, (char) 12975, (char) 64486,
        Double.longBitsToDouble(0x3fe07852c7b4e30dL), Double.longBitsToDouble(0x3fe1da9f72e37eb3L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 17, 9, "\udafc\ude82\ud9fa\udc83\u159c\udacb\udfba\ud969\udcd6\ud934\ude7a\ud811\udd6f\uda04\udecf\ud8ce\uddda\udac1\ude47\uda15\udd81\ud932\udf1c\udbbe\udd58\udb98\udebc\ud9ae\udce9\udb80\ude67\ud9f8\ude5b\udaff\udcfc\udb10\udcd9\ud849\ude11\uda5f\udd06\ud840\udc12\udaf7\udee6\udab8\udc92\ud990\ude9e\ud882\udd5a\u043e\ud805\udd17\ud8e7\udc5a\udb25\udcde\ud8b9\uddea\udb86\udf01\ud967\udffa\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6\uda65\udcc6\uda9a\uddd8\ud95f\udff3\ud841\udfe6\ud835\udf55\ud9f8\udd28\ud93f\uddf0\udb83\udf8a", "\u0a58\u4e80\u815e\u2304\u928a\u1639\u609a\u1a8f\u7582\u32e3\u10b9\u3607\u573a\u7261\u2ca3\u0d43\u74ae", "\uda7f\udef4\ud8e0\udf3e",
        25, 47423, -879604802, 7922443905364988498L, -97854L, false, true, (char) 18585, (char) 32332,
        Double.longBitsToDouble(0x3fc9c66fd29e4dc8L), Double.longBitsToDouble(0x3fe13c0501a87329L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 2, 15, "\000", "\u2c72\u24c7\000\000\000\000\u8897\u5f23\000\u4faf\u57f4\ubbdf\u00b4\000\uafdf\u00a5\u7a61\u541e\000\u8732\ucbb0\u416f\ud685\u86ce\u4855\u9bbf\u8b2d\u9465\u00e3\000\u807a\ud576\u9735\u89a0\u1233\u0f5a\ubb4f\ua8ed\u216c\u311f\000\000\000\000\000\u5926\000\u885e\u5e27\u8082\u1c79\u0fb2\u2d6c\u9105\u62b9\u6ad1\u233a\u8819\u29c8\u749d", "\ud9c5\udc0c\udb8e\udd30\udbaa\udeb3\udb0a\udca9\ud8f8\udc6b\ud929\udc7f\ud8d6\udef0\ud92c\uddc8\ud8f1\ude94\ud9ca\udc56",
        6, 35569, 1919093065, 4110918669661097094L, -35269L, true, true, (char) 22572, (char) 29598,
        Double.longBitsToDouble(0x3f73883e9fc2e500L), Double.longBitsToDouble(0x3fe6a352a806633eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 19, 9, "\ud8ae\udd57T\000\000\ud969\udcd6\ud934\ude7a\u7e8f\uda04\udecf\ud8ce\uddda\udb49\udf0b", "", "\ud9ae\udce9",
        18, 20386, -570425344, 23689789769252864L, -6112L, false, false, (char) 7671, (char) 18262,
        Double.longBitsToDouble(0x3fe431be2a6fa840L), Double.longBitsToDouble(0x3ec6183c29600000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 17, 9, "\ud835\udcb4\uda06\udda1\u159c\udbeb\uddb6\ud86c\udc33\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\uda73\udf01", "\u04a6", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d",
        40, 22649, 388164597, -1432847621410303627L, 77406L, false, false, (char) 21651, (char) 19243,
        Double.longBitsToDouble(0x3fe07852c7b4e30dL), Double.longBitsToDouble(0x3fe0fa9f7208f89bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=com.google.gson.stream.JsonWriter:@?\0121=java.lang.Boolean:true |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 15, 15, 0, "\uda6c\ude36", "\ub127\ub7b4\u410a\u69b5\u06b8\uca08\u7fd9\u5e57\u4124\u660e\u1349\u7e9b\u9ade\u9bc6\u3b2c\u00a5\u865e\u4501\u650f\u5b17\ucbb0\u416f\ud685\u6bb2\u88bd\u9bbf\u8b2d\u455c\u905f\u1ff6\u87d4", "\udbd9\uddf1\uda65\udcc6\ud909\udd42\udb4e\uddae\udb7e\ude61\ud835\udf55\u805d\ud93f\uddf0\ud89d\udd5a\udb63\udf6b\udbe0\uddaf\ud828\udf36\ud918\udcb2\uda43\udd76\ud9bf\udcc2\udb4e\udea0\ud9a1\udc02\ud8b2\udc4b\uda46\udc90\udbf0\udfa8",
        0, 67269, 1679251475, -6037631668887766245L, 91171L, true, false, (char) 16705, (char) 25782,
        Double.longBitsToDouble(0x3fe2f930fa5214a1L), Double.longBitsToDouble(0x3fd91dc94a61033aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 10, 0, 0, "\ud9d9\udc00\ud959\udc16\udbf8\udf25\udbeb\uddb6\ud969\udcd6\ud8e8\udd94\u70d9\udb60\udfd0\ud8ce\uddda\udac1\ude47\uda15\udd81\ud932\udf1c\uda6f\ude98\udb97\udd0d\ud9ae\udce9", "\u3b2c\u00a5\u7a61\ub173\ua06b\u2817\u3239", "\udbfa\udd21\ud805\udd17",
        6, 80804, -124008929, -1073534531698417674L, -51360L, false, false, (char) 29631, (char) 44477,
        Double.longBitsToDouble(0x3fec015e4a16b08aL), Double.longBitsToDouble(0x3fe81736fd9a5288L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 13, 12, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\udb3a\udef5\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud923\uddf1\udb2e\udc0b\ud9e0\udfe6\uda5f\udd06\ud920\udec5\udbc3\udd6a\udb62\udc67\ud990\ude9e\ud882\udd5a\udbfa\udd21\udb8a\udcd2\udaf8\ude39\ud8b7\udc13\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, false, true, (char) 6385, (char) 44890,
        Double.longBitsToDouble(0x3fd47eec67cc7178L), Double.longBitsToDouble(0x3fc103377f6a2adcL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 10, 4, "\ud8c6\udeb8\ud9fa\udc83\ud95a\uddac\uda59\udf47\udbba\udcbd\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\ubf98", "\udb80\udde0\ud9f8\ude5b\ud923\uddf1\udb2d\udf2f\ud9e0\udfe6",
        57, 94350, -1563622679, 6389961058689609557L, -29123L, true, true, (char) 6669, (char) 676,
        Double.longBitsToDouble(0x3fefb6ae4e7a0324L), Double.longBitsToDouble(0x3fe0a6f4d985d20fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 6, 5, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud923\uddf1\udb2d\udf2f\ud9e0\udfe6\uda5f\udd06\ud920\udec5\udbc3\udd6a\udb62\udc67\ud990\ude9e\ud882\udd5a\udbfa\udd21\udb8a\udcd2\udaf8\ude39\ud8b7\udc13\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=com.google.gson.stream.JsonWriter:@?\0121=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 7, 14, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud8dd\ude6d\uda04\udecf\ud8a9\udc25\udaf1\udc7f", "\u987c", "\udb80\ude67\ud9f8\ude5b\udbf9\udedc\udb2d\udff9\ud9e0\udfe6\uda5f\udd06\ud920\udec5\udbc3\udd6a\udb62\udc67\ud990\ude9e\udaad\udd6e\ud80d\udd08\uda5b\udf7f\udaf8\uddc0\ud8b7\udc13\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899939297L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fa9fb1a7dadac60L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 0, 2, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud90a\uddc5\ud821\udde5\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud923\uddf1\udb2d\udf2f\ud9e0\udfe6\uda5f\udd06\ud920\udec5\udbc3\udd6a\udb62\udc67\ud990\ude9e\ud882\udd5a\udbfa\udd21\udb8a\udcd2\udaf8\ude39\ud8b7\udc13\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 9, "\ud88b\udf2f\ud9fa\udc83\u159c\ud86b\udd44\ud811\uddd7\ud92c\udf10\ud8eb\udc47\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b",
        46, 10201, -1930015314, 1306866280065761382L, 50738L, true, true, (char) 63749, (char) 6036,
        Double.longBitsToDouble(0x3fef20f583dc0fe6L), Double.longBitsToDouble(0x3fe90b60361f53eeL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 18, 16, "\ud9d8\udfee\uda38\udcc3\udac5\ude9b\ud925\uddc0\udb68\udd7a\ud859\udd5a\ud853\ude68\udb83\udea6\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud897\udd8a\udbcb\udc33\udb2d\udf2f\ud9e0\udfe6\udbe6\udd32\ud9cf\udf55\udbc3\udd59\udb62\udc67\ud990\ude9e\ud882\udd5a\udbfa\udd21\udb8a\udcd2\udada\udec9\ud8c3\udfb5\ud9d3\uddaf\udbdc\ude54\ud813\udf11\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        4, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6518, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 19, 3, 20, "\ud9d8\udfee\ud9fa\udc83\ud984\udcba\ud9f9\udd23\uda50\uddc6\ud8cb\uddac\udb4d\udf20\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u99ae", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\ud999\ude43\ud84b\ude40\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\u3fb4\ud9a1\udf90\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, -1000, -426608269, 1089553360899994266L, -46871L, true, true, (char) 30208, (char) 4955,
        Double.longBitsToDouble(0x3fd8300c05bffe8cL), Double.longBitsToDouble(0x3fb80516fed455b8L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 19, 19, 13, "\ud9d8\udfee\ud9fa\udc83\ud984\udcba\ud9f9\udd23\uda50\uddc6\ud8cb\uddac\udb4d\udf20\uda04\udecf\ud8ce\uddda\udb77\udf44", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud818\udd4b\ud8d7\udc83\ud9e0\udff1\ud999\ude43\ud84b\ude40\uda71\udccd\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud84d\udff8\000\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 245201029755546L, -46871L, false, false, (char) 6343, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c05bffe8cL), Double.longBitsToDouble(0x3eb6fed455b80000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 8, 9, "\ud9d8\udfee\ud9fa\udc83\ud984\udcba\ud9f9\udd23\uda50\uddc6\ud8cb\uddac\udb4d\udf20\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\ud999\ude43\udaa9\udf4f\ud941\udecc\ud990\udf09\ud990\ude9e\ud882\udd5a\udbb0\udcfd\ud87b\ude32\udac9\udf39\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\udb20\udf67\udb6e\udf80\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c05bffe8cL), Double.longBitsToDouble(0x3fb80516fed455b8L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 0, 11, 9, "\ud9d8\udfee\ud9fa\udc83\ud984\udca2\ud9f9\udd23\uda50\uddc6\ud825\udd67\udbe1\udd06\uda04\uddf4\ud8ce\uddda\udafc\udd48", "\u5f07", "\ud946\udfb5\uda70\udfce\uda86\udf3d\uda62\udf04\udb84\udd84\udb42\uddd9\ud84b\ude40\ud917\uddd6\udb1c\udd25\udb69\udcb0\ud990\ude64\udbfa\udda8\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\udb40\udd26\ufbf0\ud930\udf37\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fc06518028e0294L), Double.longBitsToDouble(0x3fb80516fed455b8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 8, 9, 11, "\ud9d8\udfee\ud9fa\udc83\ud902\ude9b\uda26\ude81\uda4d\udd9d\ud8cb\uddac\udb4d\ude37\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\ud814\udfe0\ud9b4\udecf\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\ud999\ude43\ud84b\ude40\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\ue921\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, 73825L, false, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c05bffe8cL), Double.longBitsToDouble(0x3fb80516fed455b8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 8, 11, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47\uda15\udd81\ud932\udf1c\uda6f\ude98", "\u899c\u9bc6\u3b2c\u00a5\u7a61\ub173\ua06b\u00a8\ucbb0\u416f\ud685\u6bb2\u88bd\u9bbf\u8b2d\u455c\u905f\u0baf\uc4de\ud5e6\u9735\u89a0", "\ud95f\udff3\ud841\udfe6\ud835\udf55\u805d\ud93f\uddf0\ud933\udda3\ud967\udc4a\ud8b2\ude0d\ud97c\udf37\ud8da\udc2f\uda43\udd76\ud8db\udc10\ud937\ude1e\udb52\udc55\ud9c6\udc99\udbef\udcb7\ud93a\udcd4\udb93\ude63\ud8b4\udebe\udb78\udf74\ud983\uddb8\udb56\udeef\ud8ea\udf12\u4097\uda63\udd3f\ud839\udd8f\u646c\ud61f",
        16, 31941, -355363643, 1364951053606353213L, -9191L, true, true, (char) 63597, (char) 46207,
        Double.longBitsToDouble(0x3fe0a51c73bab2adL), Double.longBitsToDouble(0x3fd2c32f18e00eb8L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 9, 11, "\ud9d8\udfee\ud9fa\udc83\ud990\udf1f\udbf1\udf2a\ud969\udcd6\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47\uda1f\udcb5\ud932\udf1c", "\ubbdf\u899c\u9bc6\u3b2c", "\ud8bd\udc15\ud83a\ude90\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbf9\udde8\udb4c\ude89\ud866\udd16\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 37614, -426608269, 1089553360899994266L, -46871L, true, true, (char) 6385, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 9, 6, 9, "\ud9d8\udfee\ud9fa\udc39\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\u95d9", "\uc1d3\u4124\u4fc1\u7629", "\ud9f8\ude5b\ud8ae\udf2b\ud82a\udfeb\ud81f\udcdf\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbf9\udde8\udb4c\ude89",
        -1, 80849, -124008929, -1073534531645726730L, -51248L, false, false, (char) 7284, (char) 21621,
        Double.longBitsToDouble(0x3fe1b15e4973aabbL), Double.longBitsToDouble(0x3fe81734929a0f1eL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 20, 6, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud821\ude6f\udb8f\udc4b", "\u25db\uad24", "\uda36\uddad\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d",
        35, 50849, 434181886, -8166874679377440395L, 26805L, false, false, (char) 5211, (char) 55338,
        Double.longBitsToDouble(0x3fb0c47cf5a2a180L), Double.longBitsToDouble(0x3fdd1307b411f198L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=com.google.gson.stream.JsonWriter:@?\0121=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 14, 14, 9, "\ud9d8\udfee\ud975\udc5b\u159c\ud9a1\udcf1\uda97\udf37\ud934\ude7a\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u6d7e", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\udb91\udf11\uda5f\ude21\u7b15\ud928\ude4a\ud98d\udd29\ud882\udd5a\u5b93\ud805\udd17\ud8e7\udc5a\ud8b7\udca6\uda80\udf36\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, 92854, -426608269, 1089553360899994266L, 31459L, true, true, (char) 30100, (char) 17061,
        Double.longBitsToDouble(0x3f6d79a4e5232400L), Double.longBitsToDouble(0x3fe671c80f83df7eL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 17, 9, "\udba2\uddc3\ud9fa\udc83\u159c\udb0e\udda8\udb24\udee9\000\udae5\udfd2\uda04\udecf\ud8ce\uddda\udac1\ude47\uda15\udd81\ud932\udf1c\u8e12\000\000\000\ud887\udec3\ud8dc\udd4d\ud8d7\udc83\uc2b9", "\u00a8", "\ud882\udd5a",
        10, 31715, 2063613455, 8085896797923411828L, -502L, false, false, (char) 50566, (char) 31921,
        Double.longBitsToDouble(0x3fdf01f6352c1a0cL), Double.longBitsToDouble(0x3fed776ca3b7de18L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 17, 10, "\udb9e\udd2c\u6354\000\000\000\000\000", "\011\000\u4124\u8e12", "",
        -5, 66464, -567975092, -6389436079606283591L, 68448L, true, true, (char) 7671, (char) 18262,
        Double.longBitsToDouble(0x3fe431be2f53a840L), Double.longBitsToDouble(0x3fbec7ac307852c0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 17, 9, "\udb9e\udd05\ud9fa\udc83\u159c\udb0e\udda8\udb7a\udef4(\udae5\udfd2\ud942\udece\ud8ce\uddda\udac1\ude47\uda15\udd81\ud932\udf1c\u8e12\000$\000\ud86a\uded4\udb34\uddf4\ud8d7\udc83\ud854\udce9", "\u00a8", "\ud882\udd5a",
        10, 31715, 188497423, 3604724627488292525L, -88934L, false, true, (char) 53534, (char) 26119,
        Double.longBitsToDouble(0x3fdc0b464ab8e330L), Double.longBitsToDouble(0x3fe23c56eec3ecebL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 19, 13, "\ud96d\udf96\ud9fa\udc83\u159c\udb0e\udda8\ua500\000\ud801\udfe0\uda04\udecf\ud8ce\uddda\011\uda15\udd81\ud932\udf1c\u8e12\udb5c\udecd\000\udb80\uddb3\ud9f8\ude5b\udb1b\udeac\u5b3a\u0be3\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\u2c7b\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6\udad2\ude88\udaef\udd6f\ud95f\udff3\ud841\udfe6\ufa9a\u7f9b\ud812\udc79\000\000\000\ua8f5\ud8da\udca5\uda43\udd76\uda8f\udd0a\ud96d\ude5b\ud937\udc2e\ud993\udf58\u4939\udac2\udfe4\uc43f\uda03\ude2d\udb7d\udcdc\udac1\udcf4\ud9de\udc7b\uda1e\uddf5\uda35\udcb4\udbdc\udfe0\ud9be\udd98\udb18\udf2e\udb87\udf0f\uda9d\udc75\udae2\udf46\udb40\udd88\ud91e\uddad\ud957\udcfd\u3795\ue9ae\udaea\udf20\ud8e7\udf0f\udbf5\udf11\uda82\udc01\ud97e\ude95\udab0\uddd6\ud909\uddd8", "\u54e2\ubde3\u8064\u6f97\u911a\u9c90\u793c\u2157\u00ae", "\uda76\ude2a",
        10, 98359, 674445888, 4490695505995507772L, -75181L, false, false, (char) 32700, (char) 21505,
        Double.longBitsToDouble(0x3fe66574a6e1db65L), Double.longBitsToDouble(0x3fe2dfaba8486f90L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 14, 0, "\ud9d9\udc00\ud959\udc16\udbf8\udf25\udbeb\uddb6\ud969\udcd6\ud8e8\udd94\u70d9\udb60\udfd0\ud8ce\uddda\udac1\ude47\uda15\udd81\ud90c\ude75\ud84a\ude0b\ud8c1\ude56\ud9ae\udce9", "\u2299\u817b\u7a61\ub173\ua06b\u2817\u3239", "\udbfa\udd21\ud805\udd17",
        6, 80804, -124008929, -1073534531698417674L, 79712L, false, false, (char) 36300, (char) 10615,
        Double.longBitsToDouble(0x3fcc81eb285ac228L), Double.longBitsToDouble(0x3fe81736fd9a5288L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 0, 0, "\ud9d9\udc00\ud959\udc16\udbf8\udf25\udbeb\uddb6\ud969\udcd6\ud8e8\udd94\u70d9\udb60\udfd0\ud8ce\uddda\udac1\ude47\uda15\udd81\ud932\udf1c\uda6f\ude98\udb97\udd0d\ud9ae\udce9", "\u3b2c\u00a5\u7a61\ub173\ua06b\u2817\u3239", "\udbfa\udd21\ud805\udd17",
        6, 80804, -124008929, -1073534531698417674L, -51360L, false, false, (char) 41002, (char) 44477,
        Double.longBitsToDouble(0x3fec015e4a16b08aL), Double.longBitsToDouble(0x3fe81736fd9a5288L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 0, 10, 16, "\ud8c6\udeb8\udb51\udd10\udb91\udd67\uda59\udf2c\udb2e\udec3\ud80c\udc92\ud990\udedc\uda04\udecf\ud92a\ude0c\udac1\ude8d\uda4d\udd7d", "\ub342\ub977\u8915\u9bc6\u9f9d", "\uda5f\udd06\ud920\udec5\udbc3\udd6a\udb62\udcf3\ud990\ude9e",
        7, 81315, -1394169885, 7784167542920986401L, 94040L, false, true, (char) 22942, (char) 10416,
        Double.longBitsToDouble(0x3fd85d20ff3b8610L), Double.longBitsToDouble(0x3fb34975bf6e6420L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 8, 8, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\ud969\udcd6\ud934\ude7a\ud989\udf24\u56b1\udbc6\udc50\uda1a\udc17\uda14\udcc5\ud932\udf1c\uda6f\ude98", "\ubd4e\ud60c\u3b2c\u2693\u67ed\ub173\ua06b\u00a8\ucbb0\u416f\ud685\u6bb2\u88bd\u9bbf\u8b2d\u455c\u905f\u0baf\uc4de\ud5e6\u9735\u89a0", "\ud95f\udff3\ud841\udfe6\ud835\udf55\u805d\ud903\udf96\uda3d\udda8\ud967\udc4a\ud8b2\ude0d\ud97c\udf37\ud8da\udc2f\uda43\udd76\u96f6\ud87a\uddfa\udb52\udc55\udaac\udd6c\udbef\udcb7\uda98\udd1e\udae9\udfb0\ud8b4\udf31\udb78\udf74\ud983\uddb8\udb56\udeef\ud8ea\udf12\u4097\uda63\udd3f\ud839\udd8f\u646c\udab8\ude1f",
        23, 27589, -355363643, 1364951053606353213L, -9191L, true, true, (char) 63597, (char) 46207,
        Double.longBitsToDouble(0x3fe0a51c73bab2adL), Double.longBitsToDouble(0x3fd2c32f18e00eb8L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 19, 13, "\ud96d\udf96\ud9fa\udc83\u159c\udb0e\udda8\000\000\ud801\udfe0\uda04\udecf\ud8ce\uddda\011\uda15\udd81\ud9a7\ude96\000\udb5c\udecd\000\udb80\uddb3\ud9f8\ude5b\udb1b\udeac\u5b3a\u0be3\uda5f\udd06\ud840\udc12\udaa6\udd7d\000\000\ud960\uded0\udbfa\udd21\u2c7b\ud8e7\udc5a\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6\udad2\ude88\udaef\udd6f\ud95f\udff3\ud841\udfe6\ufa9a\u7f9b\ud812\udc79\000\000\000\ua8f5\ud8da\udca5\uda43\udd76\uda8f\udd0a\ud96d\ude5b\ud937\udc2e\ud993\udf58\u4939\udac2\udfe4\uc43f\uda03\ude2d\udb7d\udcdc\udac1\udcf4\ud9de\udc7b\uda1e\uddf5\uda35\udcb4\udbdc\udfe0\ud9be\udd98\udb18\udf2e\udb87\udf0f\uda9d\udc75\udae2\udf46\udb40\udd88\ud91e\uddad\ud957\udcfd\u3795\ue9ae\udaea\udf20\ud8e7\udf0f\udbf5\udf11\ud8df\udf10\000\udab0\uddd6\ud909\uddd8", "\u54e2\ubde3\u8064\u6f97\u911a\u9c90\u793c\u2157\u00ae", "\uda76\ude2a",
        10, 98359, 674445888, 4490695505995507772L, -75181L, false, false, (char) 32700, (char) 21505,
        Double.longBitsToDouble(0x3fe66574a6e1db65L), Double.longBitsToDouble(0x3fe2dfaba8486f90L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 10, 0, "\ud9d9\udc00\uda7a\udc85\udbf8\udf25\udbeb\uddb6\ud969\udcd6\ud8e8\udd94\u70d9\udb60\udfd0\ud8ce\uddda\udac1\ude47\uda15\udd81\ud90c\ude75\ud84a\ude0b\ud8c1\ude56\ud9ae\udce9", "\u2299\u817b\u7a61\ub173\ua06b\u2817\u3239", "\udbfa\udd21\ud805\udd17",
        6, 3362, -124008929, -1073534531698417674L, 79712L, false, false, (char) 36300, (char) 10615,
        Double.longBitsToDouble(0x3fcc81eb285ac228L), Double.longBitsToDouble(0x3fe81736fd9a5288L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 10, 11, 0, "\ud9d9\udc00\ud959\udc16\udbf8\udf25\udbeb\uddb6\udae8\udfb5\ud8e8\udd94\uda05\udf6c\ud84a\udee6\ud8ce\uddda\udac1\ude47\uda15\udd81\uda0e\ude8b\ud84a\udd5e\ud8e5\udfbe\ud9ae\udccb", "\u2299\u817b\u7a61\ucff8\u8b6e\u2857\u3239", "\ud94b\ude98\ud805\udd17",
        6, 80804, -124008929, -1073534531698417674L, 79712L, false, false, (char) 36300, (char) 10615,
        Double.longBitsToDouble(0x3fcc81eb285ac228L), Double.longBitsToDouble(0x3fe81736fd9a5288L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 17, 9, "\ud9d8\udfee\ud9fa\udc83\u159c\udbeb\uddb6\u24c7\ud934\ude6f\ud821\ude6f\uda04\udecf\ud8ce\uddda\udac1\ude47", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\u3e0f\ud8b7\udca6\ud9d3\uddaf\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6",
        28, -946, -426608384, 1089553360899994266L, -100000L, false, false, (char) 0, (char) 4955,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd3ed455b8L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 17, 9, "\u4a8b", "\uae40", "\ud821\ude6f\uda04\udecf\ud8ce\uddda",
        49, 63331, -982686064, -9138773335082669504L, -74476L, false, true, (char) 20288, (char) 2019,
        Double.longBitsToDouble(0x3fe5cd3aa3f58cf6L), Double.longBitsToDouble(0x3fe6009111008ea9L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 17, 18, "\000\000\000\000\000\000\000\000\000\udabd\udf3e", "\u4fc1", "\udb80\ude67\ud9f8\ude5b\ud8dc\udd4d\ud8d7\udc83\ud9e0\udff1\uda5f\udd06\ud840\udc12\ud917\uddd6\udab8\udc92\ud990\ude9e\ud882\udd5a\udbfa\udd21\ud805\udd17\017\000\ud9d3\uddaf\u0a08\000\ud930\ude62\u8209\udb6e\udf94\udbd9\uddb6",
        28, 58958, -436207616, 41129953653248L, -46871L, true, true, (char) 6385, (char) 62298,
        Double.longBitsToDouble(0x3fd8328c03bffe8cL), Double.longBitsToDouble(0x3fb83acd000455b8L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 19, 13, "\ud96d\udf96\ud9fa\udc83\udafb\udd96\udb0e\udda8\000\000\ud801\udfe0\uda04\udecf\ud8ce\uddda\011\uda15\udd5e\ud9a7\ude96\000\udb5c\udecd\000\udb80\uddb3\ud9f8\ude5b\udb1b\udeac\u5b3a\u0be3\uda5f\udd06\ud840\udc12\udaa6\udd7d\000\000\ud960\uded0\udbfa\udd21\u2c7b\u3e0f\ud88b\udce4\037\ud8c2\udd1f\ud968\udc25\ud930\udedc\u8209\udb16\udd0b\udbd9\uddb6\udad2\ude88\udaef\udd6f\ud95f\udff3\ud841\udfe6\ufa9a\u7f9b\ud812\udc79\000\000\000\ua8f5\ud8d9\udfc6\uda43\udd16\uda8f\udd0a\ud96d\ude5b\ud937\udc2e\ud993\udf58\u4939\udac2\udfe4\uc43f\u1850\udb7d\udccd\udac1\udcf4\ud9de\udc7b\uda1e\uddf5\uda35\udcb4\udbdc\udfe0\ud9be\udd98\udb18\udf2e\udb87\udf0f\uda9d\udc75\udae2\udf46\udb40\udd88\ud91e\uddad\ud957\udcfd\u0ce2\ue9ae\udaea\udf20\ub1d3\000\ud8df\udf04\000\udab0\uddd6\ud909\uddd8", "\u54e2\ubde3\ub81f\u6f97\u911a\u9c90\u793c\u2157\u00ae", "\uda76\udde8",
        10, 98359, 14912, 4467570830843193404L, -75181L, false, false, (char) 32700, (char) 21505,
        Double.longBitsToDouble(0x3fe66574a6e1db65L), Double.longBitsToDouble(0x3fe2dfaba8486f90L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 4, 19, 13, "\ud96d\udf96\ud9fa\udc83\u159c\udb0e\udda8\000\000\ud801\udfe0\uda04\udecf\ud8ce\uddda\011\uda15\udd81\ud9a7\ude96\000\udb5c\udecd\000\udb80\uddb3\u538a\000\000\u0be3\uda5f\udd06\ud840\udc12\udaa6\udd7d\000\000\000\000\000\ud8e7\udc5a\ud8b7\udca6\ud885\ude28\ud8c2\udd27\ud968\udc25\ud930\udedc\u8209\udb6e\udf94\udbd9\uddb6\udad2\ude88\udaef\udd6f\ud95f\udff3\ud841\udfe6\ufa9a\u7f9b\ud812\udc79\000\000\000\u0100\ud8d9\udfc6\uda43\udd76\uda61\ude0a\ud96d\ude5b\ud937\udc2e\ud993\udf58\u4939\udac2\udfe4\uc43f\uda03\ude2d\udb7d\udcdc\udac1\udcf4\ud9de\udc7b\uda1e\uddf5\uda35\udcb4\udbdc\udfe0\ud9be\udd98\udb18\udf2e\udb87\udf0f\uda9d\udc75\udae2\udf46\udb40\udd88\ud91e\uddad\ud957\udcfd\u3795\ue9ae\udaea\udf20\ud8e7\udf0f\udbf5\udf11\ud8df\udf10\000\udab0\uddd6\ud909\uddd8", "\u54e2\ubde3\u8064\u6f97\u911a\u9c90\u793c\u2157\u00ae", "\uda76\ude2a",
        10, 98359, 671088640, 4490695505995507772L, -75181L, false, false, (char) 32700, (char) 21505,
        Double.longBitsToDouble(0x3fe66574a6e1db65L), Double.longBitsToDouble(0x3fe2dfaba8486f90L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 20, 10, 16, "\ud8c6\udeb8\udb51\udd10\udb91\udd67\uda59\udf2c\udb2e\udec3\ud80c\udc92\ud990\udedc\uda04\udecf\ud92a\ude0c\udac1\ude8d\uda4d\udd7d", "\ub342\ub977\u8915\u9bc6\u9f9d", "\uda5f\udd06\ud920\udec5\udbc3\udd6a\udb62\udcf3\ud990\ude9e",
        7, 81315, -1907693341, 7784167542920986401L, 94040L, false, false, (char) 17579, (char) 37708,
        Double.longBitsToDouble(0x3fd85d20ff3b8610L), Double.longBitsToDouble(0x3fb34975bf6e6420L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.stream.JsonWriter|value|boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|double|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Number|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|long|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|beforeName||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|beforeValue||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|beginArray||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|beginObject||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|close|int,int,java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|close||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|endArray||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|endObject||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|flush||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|getSerializeNulls||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|double|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Number|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|long|new:com.google.gson.stream.JsonWriter:java.io.Writer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
