package com.google.gson.internal.bind;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonTreeReader_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\012",
        Z.run(T, 1, 2, 10, 4, "\udbc4\udf96\udac1\udd69\udbd3\ude69\ud954\udda3\udbf4\udd0a", "\u9472\u0ce2\uc9f3\u9327\u6be5\u2d16\ub36d\u3f90\u0b94\ub58c\u212e", "\udb0a\uded2",
        23, 98008, -1787896917, 7245914510064874045L, 75340L, false, false, (char) 28933, (char) 46604,
        Double.longBitsToDouble(0x3fe8785b29c1801dL), Double.longBitsToDouble(0x3fee625c2665c31cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:$ |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\012",
        Z.run(T, 1, 6, 10, 4, "\udbfe\udf93\udac1\udd69\udb84\udcd6\ud897\udc4b\udac8\udf47", "\uaa47\u11fd\uca4b\u9dcd\uc43f\u2d16\ub36d\u3f90\u0b94\ub58c", "\ud8ff\ude5d\udb0a\uded2\udb20\udca3\uda0f\ude67\ud8e7\udd63\ud807\udec8\udb52\udcae\ud8db\udf4c\uda05\udcb8\u26c9\udad4\udd11",
        27, 9855, 1381611457, 1599922284012494814L, 99559L, true, false, (char) 49106, (char) 60918,
        Double.longBitsToDouble(0x3fbae89b29cef280L), Double.longBitsToDouble(0x3fd6fa0b74083aaeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String: at path $ |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\012",
        Z.run(T, 1, 8, 10, 4, "\udbfe\udf93\udac1\udd69\udb6f\uddd6\ud897\udc4b\udac8\udf47", "\uaa47\u11fd\uca4b\u9327\u17e5\u2d16\ub36d\u3f90\u0b94\ub58c", "\ud8ff\ude5d\udb0a\uded2\udb40\ude53\udac1\udc23\ud8e7\udcc1\ud807\udec8\udb52\udcc7\ud8db\udf4c\uda05\udcb8\u26c9\udad4\udd11",
        27, 65711, -1507230296, 6456335772717151960L, -37415L, true, false, (char) 41325, (char) 60918,
        Double.longBitsToDouble(0x3fbae89b29cef280L), Double.longBitsToDouble(0x3fd6fa0b74083aaeL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 10, 4, "\udbc4\udf96\uda7d\udee6\udbd3\ude50\ud954\udda3\udbf4\udd0a", "\u9472\u0ce2\uc9f3\u9327\u6be5\u9bba\ub2f8\u3f90\u0b94\ub58c\u212e", "\ud8f0\udf8e",
        56, 98008, -1787896917, 5516532253162122633L, 75340L, false, false, (char) 28933, (char) 46604,
        Double.longBitsToDouble(0x3fe8785b29c13e1dL), Double.longBitsToDouble(0x3fee625c2665c31cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String: at path $ |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\0121=void |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\012",
        Z.run(T, 2, 8, 2, 4, "\udbfe\udf93\udac1\udd69\udb6f\uddd6\ud93f\udc68\uda9d\udee8", "\uaa47\u11fd\uca4b\u9327\u17e5\u9d80\ub35b\u3f90\u0b94\ub58c\ubbbc\ub40e\u7204\u14e3\u5d5e\u803c\u9d08\u5009\u2cec\u53f0\uc8e0\u4829\u5fec\u41cf\u5f7d\ubb2a\u4fa1\u9f39\u4f1c\u6dfc\u2d36", "\udb0c\ude6e\ud9fd\udf9b\uda46\udcf7\ub8cf\uda1b\uddca\uda11\udee5\ud946\udce1\ud8b5\udfd6\uda47\udf5e\ud94f\ude5a\udac8\udd3e\ud86f\udc96\ua60c\ud8a1\udc69\ud8ac\udc9e",
        30, 70297, -713527761, 2810346201427276812L, 15244L, true, true, (char) 30049, (char) 19001,
        Double.longBitsToDouble(0x3feacb3a7a53c18aL), Double.longBitsToDouble(0x3fe4193b9ef949d6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String: at path $ |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\0121=java.lang.String:$ |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\012",
        Z.run(T, 2, 8, 6, 1, "\udbfe\udf93\udac1\udd69\udb6f\uddd6\ud897\udc4b\udac8\udf47", "\uaa47\u42e0\u26d5\u9327\u17e5\u9d80\ub35b\u3f90\u0b94\ub58c", "\ud8ff\ude5d\udb0a\uded2\udb20\udca3\uda0f\ude67\ud8ad\ude85\ud965\udd78\uda70\udee0\ud8db\udf4c\uda05\udcb8\u26c9",
        21, 78662, -2145532145, 5436119356538638284L, 42859L, true, true, (char) 11954, (char) 41325,
        Double.longBitsToDouble(0x3fe66b794c6ba26cL), Double.longBitsToDouble(0x3fd39de50adf416eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\0121=void |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\012",
        Z.run(T, 2, 2, 2, 13, "\ud86e\udc87\ud9cc\ude0b\ud9f7\udc22\udaca\udf6b\ud9b4\udf9e", "\u5ba8", "\ud903\udd77\ud981\ude7b\ud926\udcef\ud83f\udeb3\udb39\udfeb\ud812\udddc",
        23, 86758, -2012566020, 8509766786722423844L, -12585L, true, false, (char) 63429, (char) 22307,
        Double.longBitsToDouble(0x3fd9de7437d8c0eaL), Double.longBitsToDouble(0x3f73f00313b93f00L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String: at path $ |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\0121=java.lang.String: at path $ |this=com.google.gson.internal.bind.JsonTreeReader:JsonTreeReader\012",
        Z.run(T, 2, 8, 8, 4, "\udbfe\udf93\udac1\udd69\udb6f\uddd6\uda70\udeb7\ud97c\udead", "\u42d3\u1534\u1ff3", "\udba4\udcee",
        28, 33472, 734044089, -1243299162348063915L, -44743L, false, false, (char) 51595, (char) 31742,
        Double.longBitsToDouble(0x3fed580d00db956eL), Double.longBitsToDouble(0x3fe1eb24719de743L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.bind.JsonTreeReader|beginArray||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|beginObject||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|close||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|endArray||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|endObject||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|expect|com.google.gson.stream.JsonToken|new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|getPath||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|hasNext||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|locationString||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|nextBoolean||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|nextDouble||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|nextInt||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|nextLong||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|nextName||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|nextNull||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
    "M|com.google.gson.internal.bind.JsonTreeReader|nextString||new:com.google.gson.internal.bind.JsonTreeReader:com.google.gson.JsonElement",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
