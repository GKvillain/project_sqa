package com.google.gson.internal.bind;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeAdapters_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$27:@?\012",
        Z.run(T, 1, 1, 5, 0, "\uda3b\udef5\ud8a2\udd79\udbd0\udf6d", "\u012a\ub0b6\u3d2f", "\ud874\udf43\ud9d0\ude5b\uda50\ude99\ud90a\udd05\uda4c\ude08\udb6a\udff6\udafa\udcbe\ud98e\udeb4\ud8d6\udfaf\uda66\ude32\udbd9\udca8",
        13, 61267, 1252101009, -3450895938033332544L, -98015L, true, true, (char) 36271, (char) 11264,
        Double.longBitsToDouble(0x3fd2152b2395c0aaL), Double.longBitsToDouble(0x3fe83f2ef5a1e035L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$27:@?\012",
        Z.run(T, 1, 1, 5, 0, "\uda25\ude2d\ud8a2\udd79\udbd0\udf6d", "\u012a\ub0b6\u3d2f", "\ud874\udf43\ud9d0\ude5b\ud9f6\udd8e\uda14\udc87\uda4c\ude08\udb6a\udff6\udafa\udcbe\ud814\udeb7\ud8d6\udfaf\uda66\ude32\udbd9\udca8",
        13, 61267, 1252101009, -3450895938033332544L, -98015L, true, true, (char) 36271, (char) 13363,
        Double.longBitsToDouble(0x3fd2152b2395c0aaL), Double.longBitsToDouble(0x3fe83f2ef5a1e035L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$27:@?\012",
        Z.run(T, 1, 1, 5, 4, "\uda3b\udef5\ud8a2\udd79\ud916\udf70\ud9e0\udec4\ud87f\udf53\udbbb\ude7c\uda82\udc4f\udab3\ude35", "\u84e4\u19d7\ua47c\u37f5\u9715\u10b0\u6f6e\u0e91\uaa29\u1ad7\ucd33\u2735\u7910\u43d7\u43ab\u5a45\u6a04\ud0ed", "\uda5b\uddbd\ud882\udcd9\udbb8\ude94\ud949\udd27\uda0c\ude3a\ud84c\udd0d\ud819\udc4d\ud9bd\udccc",
        28, 73313, 1292294703, -4599015992371244698L, 92963L, false, false, (char) 35426, (char) 53144,
        Double.longBitsToDouble(0x3febb70982bfe4b5L), Double.longBitsToDouble(0x3fd37d406607aaa8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$31:Factory[typeHierarchy=java.util.Date,adapter=null]\012",
        Z.run(T, 1, 0, 5, 0, "\uda56\udd5b\ud8a2\udd79\udbca\ude82\udb13\udd6f\ud81f\uddce\ud9c3\ude69\udaf7\udfeb\udaaf\udd02\ud852\udc59\ud99d\ude70\udb22\udf3a\ud9d0\ude5b\uda50\ude99\udb8f\udc0c\ud880\ude7b\ud915\udccd\ud8a4\udddc\ud993\udcf5\udbb4\udc9e", "\ub42a\u7910\u041d\u43ab\ua5df\u938a", "\ud98d\udfea\u7b0e\ud956\udeee\udb38\udcf4\uda13\ude61\u1b02\ud95a\udfda\ud87b\udecb\u72f3",
        38, 19510, -1092326004, 3831746769770291981L, 11492L, true, true, (char) 61416, (char) 33051,
        Double.longBitsToDouble(0x3fd8d3972841a3e6L), Double.longBitsToDouble(0x3fcc785e7948f754L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 5, 0, 0, "\uda3b\udef5\ud8a2\udd79\udbd0\udf6d", "\u00d2\ub0b6\u3d2f\u8a4f\u84d5\u9408\ube57\ua47c\u0447\ua647\u57ca\u5301", "\uda66\ude32\udbd9\udca8\udb6f\udec8\ud8a0\udee1\udbcc\uddf6\ud9d8\udd9b\uda74\udc30\udad2\udf40\uda0e\udfe7\ud879\ude0f\ud98d\udfea\uda79\ude79\ud8cc\udf43\udb0e\udc3f\ud949\udd27\uda5f\udee4",
        -4, 72670, -563143849, 1688086016873104410L, -88383L, true, true, (char) 44273, (char) 53720,
        Double.longBitsToDouble(0x3fc77e807bd03b20L), Double.longBitsToDouble(0x3f8a25f6923e3440L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$29:Factory[type=java.lang.String+java.util.Date,adapter=null]\012",
        Z.run(T, 1, 3, 5, 0, "\udb01\udef9\ud8a2\udd79\udbd0\udf6d", "\u5794\u752d\ub771", "\ud80c\uddc9\ud9d0\uddae\uda50\ude99\ud90a\udd05\ud86d\udc98\udb6a\udff6\udafa\udcbe\ud98e\ude6d\ud975\udfde\uda66\uddfa\udbd9\udca8",
        52, 686, 1252101009, -3450895936875704640L, -98029L, false, true, (char) 41604, (char) 11264,
        Double.longBitsToDouble(0x3fe10a9593d8ef5bL), Double.longBitsToDouble(0x3feac943254effadL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$27:@?\0121=com.google.gson.internal.bind.TypeAdapters$30:Factory[type=java.lang.String+char,adapter=null]\012",
        Z.run(T, 2, 1, 4, 0, "\uda3b\udef5\ud8a2\udd79\udbd0\udf6d", "\u012a\ub0b6\u2155", "\udb1e\udfd6\ud9d0\ude5b\uda50\ude99\ud90a\udd05\ud822\udc53\uda44\ude61\u6d2c\udacb\ude49\ud99c\uddb2",
        56, 38849, -1940697702, 3214975269337035514L, -54624L, true, true, (char) 35453, (char) 48552,
        Double.longBitsToDouble(0x3fec4391399a4a66L), Double.longBitsToDouble(0x3fd2152b2395c0aaL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$28:Factory[type=java.lang.Integer,adapter=null]\012",
        Z.run(T, 1, 2, 5, 0, "\udab1\uddaf\udb8d\udca5\udb96\udca5", "\u012a\ubce1\uc36d\u8a4f", "\ud9d0\ude5b\uda50\ude99\ud90a\udd05\uda4c\ude08\udb6a\udff6\udafa\udcbe\ud98e\udeb4\ud8d6\udfaf\uda66\ude32\ud964\udc2e\uda92\udd0a\ud8a0\udeec\ud9d3\udc89\ud996\udc29\ud9aa\udc2b\udad2\udf40\uda0e\udfe7\ud879\ude0f\ud9a1\ude43\uda79\ude79\ud8cc\udf43\udb0e\udc3f\ud949\udd27\udada\udf20\ud84c\udfef",
        57, 70480, -979174362, 2639569774714819914L, -76652L, true, true, (char) 19161, (char) 30324,
        Double.longBitsToDouble(0x3fb3faae51dd07f8L), Double.longBitsToDouble(0x3fe4baef648679e4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 5, 0, 3, "\ud86f\udd4f\ud896\udee0\u4582\ud9e0\udf3d\ud87f\udec1\ud9a9\udf7a\uda76\udfe9\udaaf\udd02\ud852\udc59\uda74\udfbc\udb70\udd6a\ud9d0\ude19\uda50\ude99", "\u787b\u5301", "\uda8b\udf80\uda09\udd20\udb6f\udec8\ud8a0\udee1",
        36, 92870, -1867559232, -7939492380718925761L, -27007L, false, true, (char) 6479, (char) 36163,
        Double.longBitsToDouble(0x3fb53ae8c348e0c8L), Double.longBitsToDouble(0x3fe5adae6c1e1885L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$27:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 5, 2, "\uda3b\udef5\ud8a2\udd79\udbd0\udf6d", "\u012a\ua437\u02d7", "\uda76\udf44\ud9d0\ude5b\u9f33\ud90a\udd05\uda4c\ude08\udb6a\udff6",
        14, 5997, 907721292, -3273081596240142844L, 79777L, true, false, (char) 31400, (char) 36297,
        Double.longBitsToDouble(0x3fcc894cd4864428L), Double.longBitsToDouble(0x3fdcae055e0fcbbcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$29:Factory[type=java.lang.Object+char,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$28:Factory[type=char,adapter=null]\012",
        Z.run(T, 2, 3, 2, 0, "\uda3b\udef5\ud8a2\udd79\udbd0\udf6d", "\u012a\ub0b6\u3d2f", "\ud874\udf43\ud9d0\ude5b\uda50\ude99\ud808\udffd\ud881\udd7d\udb6a\udff6\udafa\udcbe\ud98e\udeb4\ud8d6\udfaf\ufdc5\udb5d\uddfe",
        13, 61267, 1252101009, -3450895935292935488L, -98015L, true, true, (char) 36271, (char) 41177,
        Double.longBitsToDouble(0x3fd2194f4221c0aaL), Double.longBitsToDouble(0x3fe83f2ef5a1e035L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$29:Factory[type=java.lang.Long+java.lang.Thread$State,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$31:Factory[typeHierarchy=java.lang.Thread$State,adapter=null]\012",
        Z.run(T, 2, 3, 0, 3, "\uda3c\udd13\udabd\udfe9", "\u89f2", "\udbe5\udcfd\uda48\udeb4\udb10\udec9\ud874\udf43\ud9d0\ude5b\uda50\ude99\ud90a\udd41\uda4c\ude08\udb6a\udff6\udafa\udcbe\ud990\udc34\ud946\uddeb\uda94\udf5f\udbd9\udca8\udb6f\udec8\ud89f\udee1",
        39, 5976, -1867559232, 1136668243316176959L, 38120L, false, false, (char) 30552, (char) 65127,
        Double.longBitsToDouble(0x3fe83f29cda1e035L), Double.longBitsToDouble(0x3fe06303c12ccc3aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$30:Factory[type=char+java.lang.Object,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$29:Factory[type=java.lang.Object+char,adapter=null]\012",
        Z.run(T, 2, 4, 3, 0, "\uda3b\udef5\ud8a2\udd79\udbd0\udf6d", "\u012a\ub0b6\u2b1c", "\ud874\udf43\ud9d0\ude5b\uda50\ude99\ud90a\udd05\uda8f\uddae\udb6b\udc47\udbba\udcbe\ud98e\udeb4\ud8d6\udfaf\uda89\udf26\udbd9\udca8",
        13, 61267, 1252101009, -3450895938033332544L, -98015L, true, true, (char) 36271, (char) 11264,
        Double.longBitsToDouble(0x3fd2152b2395c0aaL), Double.longBitsToDouble(0x3fe83f2ef5fce035L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$27:@?\0121=com.google.gson.internal.bind.TypeAdapters$27:@?\012",
        Z.run(T, 2, 1, 1, 5, "\uda25\ude2d\u0cac\udaf5\udf21", "\u012a\u5a7d\u3d2f\u8a4f\uc312\u10f4\u7c29\uba9d\ud076\u06b0\u580a\u5800\u4c89\u109f\u6c50\u58eb\u0beb\u3014\u02bc\u36fe\u0614\uc8db\ud148\u271e\u90ca\ua9f3\u8f98\u82d1\ud791\uaf04\uc2f7\ub962\u55ed\u9fbd\u5b38\u3be5\u7df3\u17c1\u9b3d\u5371\u79e2\ub5be\u0848\u78b7\u736d\u455b", "\uda25\udc38\ud954\udd4c\ud88a\uddab\udab1\udf74\uda07\ude2f\udb6a\udd38\ud958\udf48\ud8c5\udce1\ud938\udd02",
        55, 2998, -563081938, -8033635166273917722L, -6385L, false, true, (char) 10723, (char) 15248,
        Double.longBitsToDouble(0x3fef585f40fd9431L), Double.longBitsToDouble(0x3fe96b60a31fda5aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$27:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 5, 4, "\uda3b\udef5\ud8a2\udd79\ud916\udf70\ud9e0\udec4\ud87f\udf53\udbbb\ude7c\uda82\udc4f\udab3\ude35", "\u84e4\u19d7\ua47c\u37f5\u9715\u10b0\u6f6e\u0e91\uaa29\uc4b9\ucd33\u2735\u7910\u43d7\u43ab\u5a45\u6a04\ud0ed", "\uda5b\uddbd\ud882\udcd9\udbb8\ude94\ud949\udd27\uda0c\ude3a\ud84c\udd0d\ud819\udc4d\ud9bd\udccc",
        28, 73313, 1292294703, -4599015992371244698L, 92963L, false, false, (char) 35426, (char) 53144,
        Double.longBitsToDouble(0x3febb70982bfe4b5L), Double.longBitsToDouble(0x3fd37d406607aaa8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$31:Factory[typeHierarchy=int,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$31:Factory[typeHierarchy=int,adapter=null]\012",
        Z.run(T, 2, 0, 0, 4, "\udb13\udfe3", "\ua0a9\u568c\u5b06\u557e\ubefa\uaaf5\ubab7\u84e4\u19d7\ua47c\u65bb\u9e2f\ud04a\u20af\uba77\u4b6d\u1ad7\u9a02\u4b28\u7910\u43d7\u6d72\u23e2\u3d11", "\ud8c5\udeab\ud910\udcc4\ud882\udcc9\ud85e\uded7",
        44, 78361, 1061601185, -2514981974106439185L, 32599L, false, true, (char) 11767, (char) 14435,
        Double.longBitsToDouble(0x3fba45d7e3daf350L), Double.longBitsToDouble(0x3fd8bd020d867c24L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$29:Factory[type=char+java.util.Date,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$29:Factory[type=char+java.util.Date,adapter=null]\012",
        Z.run(T, 2, 3, 3, 1, "\udb01\udf2d\ud8c2\ude79\udbd0\udf6d\ud9e0\udec4\ud973\udcbc\uda04\udfd8\ud950\udc6a\udae2\udf06\ud834\udecc\uda76\ude7d", "\u8c99\u046b\u01c8\u57ca\uc9ab\ub925\u54c5\u5bf5\u08b6\u4565\u3ef4\u0405\u43ab\u0499\u2409", "\ud9bc\udcd3\uda79\ude79\udbaf\udd25\ud99a\udc4a\ud94e\udd88\uda36\udcb6\ud90a\udf0a\uda7a\udc98\udb8d\udd00\ud9c9\uddb7\ud957\udefa\ud999\udd12\ud906\udd1d\ud9ae\udf0a\ud80c\ude27\udb95\ude72",
        38, 75347, 654557800, -3605964239899547213L, -74518L, false, false, (char) 4276, (char) 43290,
        Double.longBitsToDouble(0x3fc57964091d3a7cL), Double.longBitsToDouble(0x3fc447f85e6f0c30L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$28:Factory[type=[I,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$28:Factory[type=[I,adapter=null]\012",
        Z.run(T, 2, 2, 2, 0, "\udb01\udef9\ud8a2\udd79\udbd0\udf6d\ud9e0\udec4\ud87f\udec1\uda04\udfd8\uda9d\udff1", "\u2b28\u33b0\u7a74\ua47c\u0447\u5461\u57ca\u5301\u9cc4\u54c5\u5bf5\u4afe\u1e73\u28d1\u7542\u8473\u0499\u2409\u6be6\u1996\u7bb5\ubb9d\u7267\u03b8\u12f7\u332d\u1605\ud30f\u53c8\ucd11\uac33\u22e0\ua92b\u8d49\uc2db\u4e8c\u742a\u3c26\u5cab\u4b47\u022b\uc00a\u5ce3\u5e2c\ua2e8\u1e75\ud5a2\u6ebc\uac43\ub65d\u62bb\ubf57\u7ae4\u1ac4\u81fa\ud6fa\ua4dd\u0523\u3452\u504e\u85dc\u92dc\ub1f1\uae42\ube13\ubebd", "\ud975\udf94\ud9b1\udc55\ud894\udcea\ud94a\udeed\uda82\udc17\udba9\ude61\udb41\udda9\ud900\udc5c\ud947\udcc4\u852f\udb45\udc5d\ud8d6\udd9f\ud903\udf1c\ud975\udec3\uda64\udc81\udbbf\udfa3\ud97f\ude4b\udb2c\ude3b\udbfd\udcbb\udbea\udf03\uda4d\uded2\udbdb\udf3d\ud972\ude64\ud929\udd08\uda8f\ude99",
        19, 24226, 993411054, -1987723512871393219L, -39436L, false, true, (char) 12923, (char) 37848,
        Double.longBitsToDouble(0x3fce9115a2f99838L), Double.longBitsToDouble(0x3feffe03f3f74ee3L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$30:Factory[type=int+java.lang.Number,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$30:Factory[type=int+java.lang.Number,adapter=null]\012",
        Z.run(T, 2, 4, 4, 1, "\udb8c\udcce\uda8c\ude9c\ud8d6\ude9f\ud9e0\udf92\ud87f\udec1\udbbb\ude7c\uda76\ude72\udb41\udcb8\udbcb\uddbb\ud887\udc64\udb1e\udfd6\ud9d0\ude5b\uda50\ude99\ud90c\udf6a\ud822\udc53\uda44\ude61\u6d2c\udacb\ude49\ud99c\uddb2\udaf5\udd13\udbd9\udcb3\udb6f\udec8\ud83d\udd9a", "\u7223\uc05f\u8a85\u6cd4\u37ab\u2280\u8f98\u21dc\u4106\u3691", "\ud82d\udc84\ud84f\udef8\udbed\udf20\udb96\udcb9\uda95\udc73\ud92b\ude62\udb28\ude1d\udb2d\udffa\ud978\udd1c\udb44\uddc5\udbff\udc39\uda02\ude44\udbd2\ude7b\uda9f\udea7\ud915\udf5e\udaa3\udebd\ud88e\udf5e\udb9f\udc35",
        16, 59171, -638290220, -6496911202869955551L, -599L, false, false, (char) 52866, (char) 52647,
        Double.longBitsToDouble(0x3fd4b9562dfaea62L), Double.longBitsToDouble(0x3f98537b7b22f7a0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$27:@?\012",
        Z.run(T, 1, 1, 5, 0, "\uda3b\udef5\ud8a2\udd79\udbd0\udf6d", "\u012a\ub0b6\u3d2f", "\ud874\udf43\ud9d0\ude5b\uda50\ude99\udae0\ude3e\udbcb\ude42\udb6a\udfd5\udafa\udcbe\ud98e\udeb4\ud8d6\udfaf\uda66\ude32\udbd9\udca8",
        13, 61267, 1252101009, -3450895938033332544L, -98015L, true, true, (char) 36271, (char) 11264,
        Double.longBitsToDouble(0x3fd2152b2395c0aaL), Double.longBitsToDouble(0x3fe83f2ef5a1e035L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.bind.TypeAdapters|newTypeHierarchyFactory|java.lang.Class,com.google.gson.TypeAdapter|static",
    "M|com.google.gson.internal.bind.TypeAdapters|newFactory|com.google.gson.reflect.TypeToken,com.google.gson.TypeAdapter|static",
    "M|com.google.gson.internal.bind.TypeAdapters|newFactory|java.lang.Class,com.google.gson.TypeAdapter|static",
    "M|com.google.gson.internal.bind.TypeAdapters|newFactory|java.lang.Class,java.lang.Class,com.google.gson.TypeAdapter|static",
    "M|com.google.gson.internal.bind.TypeAdapters|newFactoryForMultipleTypes|java.lang.Class,java.lang.Class,com.google.gson.TypeAdapter|static",
    "C|com.google.gson.internal.bind.TypeAdapters|<init>|",
    "M|com.google.gson.internal.bind.TypeAdapters|newTypeHierarchyFactory|java.lang.Class,com.google.gson.TypeAdapter|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
