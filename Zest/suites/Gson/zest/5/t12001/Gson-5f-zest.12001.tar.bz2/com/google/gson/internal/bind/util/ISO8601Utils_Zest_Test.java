package com.google.gson.internal.bind.util;
import org.junit.Test;
import static org.junit.Assert.*;
public class ISO8601Utils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 0, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, -2064265630, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udf03\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, -2064265630, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 7, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda4d\udeeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude42\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38717, -2064265630, -3706857312957182421L, -96882L, true, false, (char) 57778, (char) 46755,
        Double.longBitsToDouble(0x3fc600d4949cc7f8L), Double.longBitsToDouble(0x3fe91b4797024e67L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\012",
        Z.run(T, 1, 8, 0, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\ud9df\udcef\udba3\ude54\uf735\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, -2064265630, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:123141503-06-06T20:32:44.498Z\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\uda48\udcf8\udbd4\udc65\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\udd77\ud9d9\udcb1\uda4f\ude11\ud9f9\udd5e\uda08\udca4\ud856\udcc3", "\u1a4f", "\u40b8",
        28, 27292, -1997583113, -3886112417311635502L, -3550L, true, true, (char) 40857, (char) 28836,
        Double.longBitsToDouble(0x3fea7e671735ab8cL), Double.longBitsToDouble(0x3fc9fa22ce3979e4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=java.lang.String:71732589-09-28T14:11:04.159Z\012",
        Z.run(T, 2, 8, 3, 6, "\000\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\u00dc", "", "\ud9f7\udc69\ud86f\udc78\ud8e2\ude86\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45",
        55, 77141, 271013646, -2263770462995335841L, -21426L, true, false, (char) 39617, (char) 42469,
        Double.longBitsToDouble(0x3fec72f3cd555883L), Double.longBitsToDouble(0x3fdb069b8da57a76L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\012",
        Z.run(T, 1, 8, 0, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\uda7e\udc77\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\ud8c9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\ud832\udc1c\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, 1760939618, -3706857566360252885L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 0, "\udb39\udd8c\ud9e2\udff9\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\ud657\uda22\udfd7\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\ud824\udc35\ud955\ude2b\udbd8\udd45\ud965\udf8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb89\uded5\udba3\ude54\ud9ec\udf28\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        4, 38606, -2064265630, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 967,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 0, "\udb39\ude6b\ud9e3\udc55\udb5e\udcf9\udb2e\udcb0\udb30\uddd6\ud970\udccb\ud851\udca9\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\ud905\uddc9\ud856\udcc9", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\udb18\udd2c\ud9f0\uddbf\udb91\udfdc\ud887\udc12\udabe\udc01\ua6e8\udabe\udf36\udbf7\udd59\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, -2064265630, 328367953166782173L, -41868L, true, true, (char) 628, (char) 48368,
        Double.longBitsToDouble(0x3fe7c0972db531feL), Double.longBitsToDouble(0x3fecfc41520d4e67L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 0, "\udb1d\udf1b\ud9e3\udc55\ud81d\udff2\ud955\uddc7\ud888\udd99\u9665\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\ud9eb\ude3c\udac3\udc92", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, -2064265630, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=new com.google.gson.internal.bind.util.ISO8601Utils:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\ud845\ude6c\udb4c\ude8d\u78b9\ud856\udd8f", "\ubad9\u6b05\uc4d4", "\uda6a\udef2\ud8a1\udfe1\ud952\ude29\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud93a\uddc5\udbc2\udf8f\udacb\uddc0\uda02\udf7a\udaf1\udf21\udb95\udde1\ud9eb\udc86\ud909\udf55\udb29\ude2c\ud894\udd8c\uda6c\udd0f\ud818\udf09\ud8e3\udfea",
        52, 61247, 1893953282, 4074301708376605591L, 88346L, false, true, (char) 19688, (char) 3144,
        Double.longBitsToDouble(0x3fe2e1150f5ae2c4L), Double.longBitsToDouble(0x3fce1c306a3fba18L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=new com.google.gson.internal.bind.util.ISO8601Utils:@?\012",
        Z.run(T, 2, 8, 8, 3, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\udbb2\uddc9\ud9c7\udcfe\udbe7\udd47\uda18\udd9b\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb39\udc7f\ud96f\udc1d\udab1\udc7d", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\uda90\udd41\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, -2064265630, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 3, "", "\ud753\u0d95\u26b7", "\000\ud994\ude2a\ud8f9\udc52\ud94e\uddac\ud9d9\udcb1",
        49, 71838, 1886682487, 855605711216572120L, -53518L, false, false, (char) 57847, (char) 42403,
        Double.longBitsToDouble(0x3fe47cf9e4fe434bL), Double.longBitsToDouble(0x3fcda1f7e16623bcL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:177688534-05-07T11:50:16Z\0121=new com.google.gson.internal.bind.util.ISO8601Utils:@?\012",
        Z.run(T, 2, 3, 8, 0, "\udb39\ude6b\ud9e2\udd55\uda17\udcf3", "\u562d\u8e2d\u81fa\u1e89\ub119\ub266\u782d\ub776\u4c37\u9681\uad0e\u5fba\u2776\u1a4f", "\u5924\ud8e8\udf28\uda2b\uddeb\udac9\udde8\ud955\ude2b\u8bef\udb4e\udc00",
        7, 41796, -527075134, -5607485805442183860L, 42129L, false, true, (char) 62121, (char) 21241,
        Double.longBitsToDouble(0x3fe695e9de624f0bL), Double.longBitsToDouble(0x3fd9b84f561b02beL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 1, 6, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\ud8b8\ude2f\ud9a5\udd32\ud851\udce7\udb99\uddee", "\ub266\u0256\u1a99\u6e0d\u42bf", "\ud9df\ude80\ud86c\udfd1\ud9e5\udd37\ud9f7\udc69\ud86f\udc78\ud8e2\ude86\udba9\udeab\udb7d\udfa7\ud933\udc10\ud821\ude44\uabda\u8c06\ud95c\udf30\u39a3\ud9f6\udf9d\udb66\ude2d\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud88f\udf07\ud830\ude5f\udacb\uddc0\uda02\udf7a\udaf1\udf21\udb95\udde1\ud9eb\udc86\ud909\udf55\udb29\ude2c\ud894\udd8c\uda6c\udd0f\ud863\uddce\ud8b9\uddfd",
        52, 61247, -849907966, -1929488164718288427L, 8404L, true, true, (char) 51713, (char) 34640,
        Double.longBitsToDouble(0x3fdb9257c0ef1314L), Double.longBitsToDouble(0x3fe3c29f0365c611L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\u0165\uda3c\ude10\ud808\udef7\ud851\udc79", "\u31bc\ub262\u0256\u873c\ub59b\u42a8\u96ee\u8158\u2776\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\udb47\udc35\ud832\udf25\uda41\udda4\udb6c\ude0e\udae1\uddb2\ud83e\udc8e\ud91a\ude60\ud938\udcc5\uda98\udec2",
        47, 38810, -2064265630, -3874053448348426134L, -79818L, true, false, (char) 44029, (char) 50160,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 7, 7, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\ud9ed\ude58\udbe7\udd9b\uda10\ude4c\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u69c9\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        -4, 963, -2064265496, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\ud891\udd00\ud966\udef4\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, -2064265630, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc8e\ud856\udd770000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\0121=java.lang.String:117465811-09-23T17:12:48.875+05:30\012",
        Z.run(T, 2, 6, 4, 2, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc8e\ud856\udd77", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u2650\udabe\udc01\ua6e8\ud9cb\udd9d\udb34\udf9c\udb6c\ude0e\udba3\ude54\ud9a0\udd26\ud8e8\udd03\ud938\udcc5\udbc2\udf8f",
        47, 38810, -1862939038, -3707001190066631125L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fea90972d27312bL), Double.longBitsToDouble(0x3fd9f882ae049c32L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 7, 4, 3, "\udb39\ude6b", "\u0d95", "\uda12\ude41\ud888\udca6\udb83\udd5c\udae8\uddf9\udb47\ude6a\ud9d9\udc74\uda6b\udf44",
        33, 51823, 199211228, 8420595336363617479L, 35068L, true, true, (char) 50083, (char) 15464,
        Double.longBitsToDouble(0x3fcfcd0603b43efcL), Double.longBitsToDouble(0x3fc713a2d658e7dcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:32\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\ud881\ude61\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\ub967", "\udb38\udd52\udb86\udeb8\uda6b\udcc0\udbd8\udcb4\ud966\ude34",
        35, 10850, 965601832, -3088284093869802680L, -59887L, true, true, (char) 42469, (char) 9934,
        Double.longBitsToDouble(0x3fd555883360d370L), Double.longBitsToDouble(0x3fe60729de624f0bL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:114160242-12-13T18:54:14Z\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 1, 8, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\udbbb\udc11\ud849\udcda\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\ud8ba\ude1a\udb23\ude64\ud85e\udddd", "\u757d\u7e42\ud148\u59dc\u54de\ub346\ub6b0\ud0d1", "\ud966\ude8b\ud936\udc0f\udbe5\udcf4\uda96\udfb1\ud8f9\udd79\uda07\udf74\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud99b\udc14\ud987\udef3\udacb\udda4\uda02\udf7a\udaf1\udf21\udb95\udde1\ud8ee\ude44\ud9cf\uddb4\uda70\udd16",
        46, 27991, 317026796, 3602487139872854311L, 59490L, false, true, (char) 60066, (char) 17661,
        Double.longBitsToDouble(0x3fe338ffe1eff0c0L), Double.longBitsToDouble(0x3fd3417a34db4704L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 7, 7, "\udbb3\udddd\u4057\uda17\udcf3\udaf8\udc57\ud945\udf7f\uda79\udfe0\ud9c5\ude47\udb9c\udec9\udbe7\udd52\uda10\ude5a\ud8cf\udf8d\ud844\udc06\uda4f\ude1a\u61ff\uda23\udc17\udbbf\udf83", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud901\udcc1\udbd8\udd4a\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\ud9eb\ude97\ud8f5\udc45\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 38810, 1173737058, -3706876464216355285L, -41868L, true, true, (char) 474, (char) 46576,
        Double.longBitsToDouble(0x3fe7c0972faa6ffeL), Double.longBitsToDouble(0x3fda10c8ce050642L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:76695907-10-16T07:23:46Z\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 6, "\ud880\udc76\ud9e2\udff8", "\u26b7\u3306\u8dd3\u15a3", "\ud9c5\udf89",
        29, 99411, -691878304, 2420226913447426139L, 47044L, false, true, (char) 22561, (char) 35075,
        Double.longBitsToDouble(0x3fbb3ca5b47cfc38L), Double.longBitsToDouble(0x3fdb5e04b66b6788L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 1, 6, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\ud9c5\udd14\ud808\udef7\ud851\udc79\udbac\udf2f\udb3f\uded5\udb39\udc98\udac8\udd35\udbea\udc91\ud8dd\uddac\udb55\udc7f\uda23\udc17\ud856\udd8f\udbf7\udeba\ud9df\ude80\ud86c\udfd1\udba8\udeda\ud9f7\udc69\ud86f\udc78\ud8e2\ude86\uda2b\uddeb\udac9\udde8\ud958\udd14\ud8a3\udcaa\ud85c\ude30\u8c8b\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\ud892\udc0e\udba3\ude54\ud8f5\udc71\ud9e0\udd23\udb3a\udc36\udbc2\udf43\udacb\uddc0\uda02\udf7a\ud9b4\ude81\udad9\udfaf\udaa0\udfc0", "\u2b11\u44e1\u5051\ud638\u1c2d\u8358", "\udbca\udc5e\udbf5\udd9e\udb16\udfca\uda48\ude65\u621a",
        37, 39715, -913033833, -3259620634368648839L, 73187L, false, false, (char) 21339, (char) 22491,
        Double.longBitsToDouble(0x3fea54d9b9e77b24L), Double.longBitsToDouble(0x3fbaffefdef079e8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:117465539-10-16T07:36:33Z\0121=java.lang.String:117465539-10-16T07:36:33.579Z\012",
        Z.run(T, 2, 2, 3, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\ud99b\udf6c\uda47\udca2\udbcd\udf4f\ud966\ude8b\u8c06\uda01\udfe3\ua703\ud9cb\udd9d\uda41\ude03\uf07e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        6, 53370, -1440069251, -3706992604427006421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:117461252-12-01T19:26:57Z\0121=java.lang.String:117461252-12-02T05:26:57.579+10:00\012",
        Z.run(T, 2, 2, 4, 0, "\udb39\ude6b\udbf2\ude1b\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8bd0\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        48, 23710, -2064260510, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=java.lang.Integer:25\012",
        Z.run(T, 2, 8, 5, 0, "\ud987\ude51\udaa8\udc0d\ud847\udeb3\uda42\ude9f\uda3c\ude10\ud808\udef7\udb3d\uded0\ud90a\udfa6\udbeb\udc4d\uda10\ude5a\ud914\udfc5\uda66\udeb1\uda59\ude93\ud9d3\udd9e\ud999\udd2d\ud8d0\udd80", "\u924e\u24eb\u1757\u7bf8\u6651", "\ud86c\udc2c\ud809\udc3c\ud966\ude8b\u3906\udaa6\udc56\ud97f\udd9e\udb00\ude1e\u478b\udb6c\ude52\udbd0\udff6\uda8b\udf71\ud909\udd65\uda73\udf23\udadc\udff1\udacb\udd9a\uda02\udf7a\udaf1\udf21\udb9c\udd64\ud9eb\udc86\ud815\udeea\ud9c8\udd5b\ud910\udc4d\uda6c\udd28\ud818\udf09\ud9ef\udece\ud9e2\uded2\uda3a\udd38",
        25, 44880, 1989563767, -3253709550874718364L, 26759L, false, true, (char) 39855, (char) 26230,
        Double.longBitsToDouble(0x3fc57519acdf8828L), Double.longBitsToDouble(0x3fc1bb2625f9cb28L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:9456742-05-16T12:14:41Z\0121=void |a0=java.lang.StringBuilder:\udb74\ude07\ud9e1\uddce\udba3\udd53\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\ud823\udca5\ud95a\udd4a\ud9d9\udcb1\uda60\udc5a\ud9e1\udcc000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\012",
        Z.run(T, 2, 2, 6, 0, "\udb74\ude07\ud9e1\uddce\udba3\udd53\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\ud823\udca5\ud95a\udd4a\ud9d9\udcb1\uda60\udc5a\ud9e1\udcc0", "\u8158\u2776", "\ud9f7\udc69\ud86f\udc78\ud9a8\udc86\ud9e0\udf26\udac9\udde8\ud955\ude2b\udbd8\udd45\udbc1\udd79",
        47, 29810, 273209026, 298363797864881014L, -74577L, true, true, (char) 42469, (char) 31239,
        Double.longBitsToDouble(0x3fd5558832122b70L), Double.longBitsToDouble(0x3fe8eebabe624f0fL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 7, 0, "\udb39\ude6b\uda64\udd56\ud82d\udfc0\udaf8\udc06\uda3c\ude10\ud95e\uddad\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\ud955\udff4\u5eea\ud954\udf98\ud856\udd8f", "\u1a40\u6110\u4f5a", "\udbf7\udf91\udaca\udcd9\ud955\ude2b\udbd8\udd45\ud927\ude13\u8c9c\udabe\udc01\udb64\udc24\udac8\udce2\uda1a\udfe1\udb6c\ude0e\udba3\ude54",
        -5, 3556, -2053620441, -5358938611679799796L, -30959L, false, false, (char) 34233, (char) 63380,
        Double.longBitsToDouble(0x3fe8a20b28e3acccL), Double.longBitsToDouble(0x3fe8140ed16727b4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:117461252-12-02T00:56:57.579+05:30\0121=java.lang.String:117461252-12-02T00:56:57.579+05:30\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udf35\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        47, 3378, -2064282361, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 753,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=void |a0=java.lang.StringBuilder:\udb39\ude6b0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\012",
        Z.run(T, 2, 8, 6, 2, "\udb39\ude6b", "\u0d95", "\ud851\udc79\udb99\uddee\udbe7\udd52",
        23, 13179, -1465151017, 6431739290576930542L, 35068L, true, true, (char) 42403, (char) 26059,
        Double.longBitsToDouble(0x3fcfc86973b43efcL), Double.longBitsToDouble(0x3fd5988effa59422L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 7, 0, "\udb39\udf6c\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udf03\ud851\udc79\udb99\uddee\udbe7\udd52\u90a5\uda07\udc66\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110", "\uda0c\udddc\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb41\udc0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udbc2\udf8f\udacb\uddc0\ud937\udf93\uda5f\udfc0",
        21, -160, 1104614260, -5995167330454279461L, 67444L, false, false, (char) 38693, (char) 47049,
        Double.longBitsToDouble(0x3fe812733d5df518L), Double.longBitsToDouble(0x3fe978f7a25497a7L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:9458591-08-30T17:46:27Z\0121=java.lang.String:9458591-08-30T17:46:27Z\012",
        Z.run(T, 2, 4, 4, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\udbed\udd66\ud808\ude92\ud851\udc79\udb99\uddee\ud93b\udf1b\ud8fc\udc83\ud94e\udd3b\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f", "\ud86f\udc78\ud8e2\ude86\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b",
        36, 29646, -527075134, 298422155900787574L, 42129L, false, true, (char) 34264, (char) 4968,
        Double.longBitsToDouble(0x3fe695e9de624f0bL), Double.longBitsToDouble(0x3fcd509ebf654a38L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:32\0121=java.lang.Integer:32\012",
        Z.run(T, 2, 5, 5, 7, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud945\udd78\udbf5\udc04\ud826\udc99\udbfb\udd5d\ud814\udc1c\ud8a0\udda8\udb1d\udd15\ud945\udf4d\udb72\udc19\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\ube7b", "\uda4d\udeeb\udac9\udde8\udb0e\ude87\ud8e7\uddc8\ud90d\udda7",
        36, 29646, -527075134, 298422155900787574L, 42336L, false, true, (char) 34264, (char) 4968,
        Double.longBitsToDouble(0x3fe3ade9db624f0bL), Double.longBitsToDouble(0x3fcd514278af304cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:203815674-07-09T21:41:48.014-07:00\012",
        Z.run(T, 1, 4, 6, 7, "\udb39\ude6b", "\u0d95", "\ud851\udc79\udb99\uddee\udbe7\udd52",
        23, 39035, -1465151017, 6431739290570508014L, 35068L, true, true, (char) 42403, (char) 26059,
        Double.longBitsToDouble(0x3fdfe434b9da1f7eL), Double.longBitsToDouble(0x3fd5988effa59422L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:123141503-06-06T20:32:44.288Z\0121=java.lang.String:123141503-06-06T20:32:44.288Z\012",
        Z.run(T, 2, 3, 3, 1, "\udbe1\ude5f\ud9e3\udc55\ud914\udc31\ud8ab\udef4\uda3c\ude10\uda48\udcf8\udbd4\udc65\udb79\udcee\udbe7\udd52\uda10\ude5a\ud94e\udd77\ud9b4\udeda\uda4f\ude11\ud9f9\udd5e\uda08\udca4\ud856\udcc3", "\u3cbc", "\000",
        28, 27292, -1997583113, -3886112417311635712L, -100000L, true, true, (char) 1178, (char) 0,
        Double.longBitsToDouble(0x3e4cd6ac00000000L), Double.longBitsToDouble(0x3fc9fa22ce3979e4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:192631267-06-07T04:18:53-07:00\0121=java.lang.String:192631267-06-07T04:18:53-07:00\012",
        Z.run(T, 2, 4, 4, 7, "\udb4a\udd52\ud9e3\udc3b\udace\udc6e\udae8\udd9e\ud914\udc57\uda48\udef7\ud99b\udd26\udb16\udc41", "\u0a8a\u0211\u5103\uaf24\u6787", "\ud9df\ude80\ud86c\udfd1\udb1a\udd38\udb05\udd2f\u40b8\ud909\udc78\ud9d6\udd9d\ud8a7\udc6e\ue1b7\ud9fc\udd2b\udaa5\udc96\ud860\udd0a\uda64\udd73\uda25\udee5\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\uc4fc\ud8f5\udca0\ud91a\ude60\ud907\ude2d\uda37\udddb\ud9d0\uddba\ud84c\udc95\uda30\udf9b\uda1b\udfe4\udaf9\ude8e",
        37, 63920, -423585163, 6078793492869533298L, -13197L, false, true, (char) 52568, (char) 34407,
        Double.longBitsToDouble(0x3fc181acb5ad2ae8L), Double.longBitsToDouble(0x3fbc69a50e28b0b8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb39\ude6b\ud9e3\udc55\udb5e\udcf9\udb2e\udcb0\udb30\uddd6\ud970\udccb\ud851\udca9\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\u9070\ue0de\ud924\udf77\ud856\udcc9000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\0121=void |a0=java.lang.StringBuilder:\udb39\ude6b\ud9e3\udc55\udb5e\udcf9\udb2e\udcb0\udb30\uddd6\ud970\udccb\ud851\udca9\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\u9070\ue0de\ud924\udf77\ud856\udcc9000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\012",
        Z.run(T, 2, 6, 6, 4, "\udb39\ude6b\ud9e3\udc55\udb5e\udcf9\udb2e\udcb0\udb30\uddd6\ud970\udccb\ud851\udca9\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\u9070\ue0de\ud924\udf77\ud856\udcc9", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\udb18\udd2c\ud9f0\uddbf\udb91\udfdc\ud887\udc12\udabe\udc01\ud8d2\udc4c\udabe\udf36\u4328\ud940\udeea\udb2b\udf0b\ud8f0\udfa1\ud91a\ude60\ud938\udcc5\udbc2\udf8f",
        58, 27994, -924180884, 328367429180772061L, -41868L, true, true, (char) 628, (char) 48368,
        Double.longBitsToDouble(0x3fdf812e50ce50e2L), Double.longBitsToDouble(0x3fed1e6c84d5affcL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:36887495-02-14T20:50:46Z\0121=void |a0=java.lang.StringBuilder:\udb1d\udf1b\ud9e3\udc55\ud81d\udff2\ud955\uddc7\ud888\udd99\u9665\ud851\udc79\udb99\uddee\udbe7\udd52\ud91e\ude61\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\ud9eb\ude3c\udac3\udc9200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\012",
        Z.run(T, 2, 3, 6, 0, "\udb1d\udf1b\ud9e3\udc55\ud81d\udff2\ud955\uddc7\ud888\udd99\u9665\ud851\udc79\udb99\uddee\udbe7\udd52\ud91e\ude61\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\ud9eb\ude3c\udac3\udc92", "\u1a4f\u4a29\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b",
        3, 2135, 1629208141, 1163994745812646082L, 70870L, false, true, (char) 12338, (char) 39617,
        Double.longBitsToDouble(0x3fc9fa22ce3979e4L), Double.longBitsToDouble(0x3fd555883360d370L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:192833765-03-10T08:13:03+10:00\0121=void |a0=java.lang.StringBuilder:\udb1d\udf7c\ud9e3\udc55\udb67\udf99\ud97a\udd18\ud888\udd99\u9665\u0331\ud80d\udf5f\udac2\udf6c\uda41\udd5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\ud9eb\ude3c\udac3\udc9200000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000041\012",
        Z.run(T, 2, 4, 6, 0, "\udb1d\udf7c\ud9e3\udc55\udb67\udf99\ud97a\udd18\ud888\udd99\u9665\u0331\ud80d\udf5f\udac2\udf6c\uda41\udd5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\ud9eb\ude3c\udac3\udc92", "\u1a4f\u6110\u4168\u677c\u9915\ub734\u0fcf\u2f0f", "\udbf6\udf15\udacc\udc8a\ud855\ude3b",
        41, 107, -720909806, -6085432952243216331L, 11972L, false, false, (char) 10940, (char) 3150,
        Double.longBitsToDouble(0x3fe312785852d9f5L), Double.longBitsToDouble(0x3fe15e6476c4b120L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 1, 0, "\ud952\udd0e\ud989\udf22\ud81d\udff2\udb57\udcc7\ud888\udd99\u9665\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1", "\u2527\u4133\u7b77\uc53f", "\udb84\udd60\uda49\udfbf\uda1e\udf85\ud9a5\udd79\uda54\udee0\ud8cd\udd67\udbd5\ude35",
        33, 94603, 276966282, -2263770462995335841L, -21426L, true, true, (char) 39617, (char) 42469,
        Double.longBitsToDouble(0x3fec72f3cd535883L), Double.longBitsToDouble(0x3fc902091b4af4ecL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb39\udd800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 7, 3, "\udb39\udd80", "\u0d95", "\000\000\ud994\ude2a",
        54, 5816, -1465151220, 6431739291978849774L, 96608L, false, true, (char) 63788, (char) 46521,
        Double.longBitsToDouble(0x3fe1625bbe8f9f3cL), Double.longBitsToDouble(0x3fcfc86973b43efcL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 3, "", "\u68fa\u9214\u1a38", "\000\ud994\ude2a\ud86a\udf0a\udace\udf1a\ud9d9\udcb1\udaef\udc28",
        36, 1487, 199211228, 8420595336363573248L, -100000L, true, true, (char) 42403, (char) 26059,
        Double.longBitsToDouble(0x3fcfc86973b43efcL), Double.longBitsToDouble(0x3fb6623beb970f10L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:27115035-08-25T19:42:52Z\0121=java.lang.String:27115035-08-25T19:42:52Z\012",
        Z.run(T, 2, 2, 2, 4, "", "\u9cf9\u76eb\u2724", "\000\ud994\ude2a\ud8f9\udc52\ud94e\uddac\ud9d9\udcb1",
        49, 71838, 427064805, 855605711216572120L, -50839L, false, false, (char) 26059, (char) 32841,
        Double.longBitsToDouble(0x3fcda1f7e16623bcL), Double.longBitsToDouble(0x3fccf58a29d30804L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\0121=void |a0=java.lang.StringBuilder:000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\012",
        Z.run(T, 2, 6, 6, 5, "", "\ud753\u0d95\u26b7", "\000\ud994\ude2a\ud8f9\udc52\ud87a\udda2\ud9d9\udcb1",
        49, 71838, 1886682487, 855605709255999704L, -53664L, false, false, (char) 57847, (char) 119,
        Double.longBitsToDouble(0x3e43f90c00000000L), Double.longBitsToDouble(0x3fcda1f7e16623bcL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\ud8a3\udfc4\udb97\udf6d\ud851\udc9d\ud91a\udecf\ud9f9\udf03\uda10\ude4c\ud94e\uddac\ud9d9\udcb1\ud892\udf94\udb55\udc7f\uda23\udc17\ud856\udd8f0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 1, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\ud8a3\udfc4\udb97\udf6d\ud851\udc9d\ud91a\udecf\ud9f9\udf03\uda10\ude4c\ud94e\uddac\ud9d9\udcb1\ud892\udf94\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u9a28\u69c9\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c3a\udbd4\udc0c\ua6e8\ud9e1\udfe6\udbeb\udf58\ud878\ude5b\udba3\ude1e\ud8f5\udc71\ud91a\ude60\ud938\udcc5\udb1f\udfc8",
        33, 963, -1996055576, -9132997090654302791L, -41868L, true, true, (char) 474, (char) 18050,
        Double.longBitsToDouble(0x3feb0653a0eb7e82L), Double.longBitsToDouble(0x3fecfc44cf024e67L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Integer:27\0121=java.lang.Integer:27\012",
        Z.run(T, 2, 5, 5, 2, "\udb39\ude6b\ud973\uddfd\ud940\udefb\udaf8\udc57\ud891\uddc9\ud864\udda5\ud861\udedd\u0dd1\u5653\uda10\ude5a\ud9e9\udfba\udae4\udcfe\uda4f\ude11\udbc0\udd54\ud91f\udd2c\ud927\udc40", "\u1a4f\u3df7\ud3b7\ubb93", "\udac9\udde8\udafd\uddbe\udbd8\udd45\ud82f\udc25\ud938\udebf\udabe\udc83\ua6e8\ud9cb\udd9d\udb34\udfab",
        27, 37487, 553185077, 6807484897486379918L, 14588L, false, true, (char) 25361, (char) 44758,
        Double.longBitsToDouble(0x3fecd7d1f93953f4L), Double.longBitsToDouble(0x3fead0972d27312bL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 1, 6, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\ud9c5\udd14\ud80d\udde1\ud851\udc79\ud965\udd8b\udb3f\udeb9\udb39\udc98\udac8\udd35\udba2\uded0\ud866\udd31\udb30\ude92\ud8ea\udcf5\ud856\udd8f\udbf7\udeba\uda0a\udd56\ud86c\udf82\udba8\udeda\ud9f7\udc69\ud8fb\udf76\ud8e2\ude86\ud90b\ude9b\uda32\udd84\ud958\udd14\ud8a3\udcaa\ud85c\ude30\u8c8b\uda35\udf3d\udb57\udc0b\ud896\udcf0\ud90f\udc15\ud84a\ude81\udba3\ude54\ud8f5\udc71\ud9e0\udd23\ud9e5\ude8c\udb65\udde7\udacb\uddc0\uda02\udf7a\ud9b4\ude81\udad9\udfaf\uda73\udcb8", "\ubd24\u4145\u5051\u4cd2\u1b8a\u8358", "\udbca\udc5e\udbf5\udd9e\udb16\udfca\uda48\ude65",
        59, 84010, 769805577, -9131099526038737989L, -59579L, false, false, (char) 55514, (char) 37571,
        Double.longBitsToDouble(0x3fde77b248d7ff7eL), Double.longBitsToDouble(0x3fedb2b1eb3e7e2aL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.util.ISO8601Utils:@?\0121=java.lang.Integer:25\012",
        Z.run(T, 2, 8, 5, 0, "\ud987\ude51\u4782\000\uda33\udeb8\uda3c\ude10\ud808\udef7\udb37\udecd\ud90a\udfa6\udbeb\udc4d\uda10\ude5a\ud914\udfc5\uda66\udeb1\uda59\ude93\000\000\ud8d0\udc86", "\u924e\u24eb\u1757\u7bf8\u6651", "\ud86c\udc2c\ud809\udc3c\ud966\ude8b\ud98c\udd04\udaa6\udc56\ud97f\udd9e\udb00\ude1e\u478b\udb6c\ude52\udbd0\udff6\uda8b\udf71\ud909\udd65\uda73\udf232\udacb\udd10\uda02\udf7a\udaf1\udf21\udb9c\udd64\ud9eb\udc86\ud815\udeea\ud9c8\udd5b\ud910\udc4d\uda6c\udd28\ud818\udf09\ud9ef\udece\ud9e2\uded2\uda3a\udd38",
        25, 79088, 1989563648, -3253709550874718364L, 26759L, false, true, (char) 6, (char) 0,
        Double.longBitsToDouble(0x3fc575000cdf8828L), Double.longBitsToDouble(0x3fc1bb2625f9cb28L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Integer:25\0121=java.lang.Integer:25\012",
        Z.run(T, 2, 5, 5, 0, "\ud987\ude51\u4782\ud91b\udd65\uda33\udf3a\uda40\udfb1\ud82b\udcf8\udb37\udecd\ud90a\udfa6\udbeb\udc4d\uda10\ude5a\ud914\udfc5\uda66\udeb1\uda59\ude93\000\000\udaa6\udcd1", "\u0c17\u6909\u4857\u7bf8\u6651", "\udb65\udf49\ud952\udc8d\ud997\ude9a\ud98c\udd04\udbb8\ude1f\ud97f\udd9e\udb00\ude1e\u478b\udb6c\ude52\udbd0\udff6\uda8b\udf71\ud902\udf81\uda73\udf23\ud9f2\ude4a\udacb\udd10\uda02\udf7a\ud927\udfbd\ud820\udd89\ud9eb\udc86\ud815\udeea\ud81d\udda6\udb16\udee7\uda6c\udd28\ud80b\udd09\ud9ef\udece\ud9e2\uded2\uda3a\udd38",
        25, 79088, 1989563648, 8131390307117930461L, 26759L, false, true, (char) 6, (char) 64738,
        Double.longBitsToDouble(0x3fc575000cdf8828L), Double.longBitsToDouble(0x3fc1bb2625f9cb28L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 0, "\uedeb\ud9e3\udc55\uda17\udcf3\udaf8\udc57\ud969\ude87\u8490\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude24\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\ub592\000\u4071", "\ud8e7\udd09\udac9\udde8\uc100\000o\u8bb9\000\ua626\000\000\ucd12\uda7a\udefd\ud8f5\udc71\ud8e5\udd91",
        -5, 15824, -1120163408, 5695855058885135970L, -41868L, true, true, (char) 2009, (char) 37124,
        Double.longBitsToDouble(0x3e449cc400000000L), Double.longBitsToDouble(0x3fecfc4000004e67L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.String:137690395-11-13T20:54:40+11:00\0121=void |a0=java.lang.StringBuilder:\ud855\uddd7\ud881\udeb7\udb67\udf99\ud97a\udd18\ud888\udd99\u9665\u0331\ud80d\udf5f\udac2\udf6c\uda41\udd5a\ud94e\uddac\ud9d9\udcb1\udbcd\uded1\udb55\udc7f\ud801\udf92\udac3\udc3700000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000041\012",
        Z.run(T, 2, 4, 6, 5, "\ud855\uddd7\ud881\udeb7\udb67\udf99\ud97a\udd18\ud888\udd99\u9665\u0331\ud80d\udf5f\udac2\udf6c\uda41\udd5a\ud94e\uddac\ud9d9\udcb1\udbcd\uded1\udb55\udc7f\ud801\udf92\udac3\udc37", "\u137e\ubfc3\u1a67\u677c\u9915\ub72d\u0fcf\u2f0f", "\udbf6\udf15\udacc\udc8a\ud855\ude3b",
        41, 263, 1362610706, 4345027046013280309L, 11972L, false, false, (char) 22653, (char) 62752,
        Double.longBitsToDouble(0x3fe6bc9ff052d9f5L), Double.longBitsToDouble(0x3fe15e6476c4b120L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:000000000000000000000-4\012",
        Z.run(T, 1, 6, 4, 5, "", "", "",
        -4, 23, 20163687, -3835799069953752289L, 70637L, true, true, (char) 43179, (char) 0,
        Double.longBitsToDouble(0x3e188e0e80000000L), Double.longBitsToDouble(0x3f07bf31dd36c000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:24431516-07-11T14:07:27Z\0121=void |a0=java.lang.StringBuilder:\ud855\uddd7\ud881\udeb7\udb67\udf99\ud97a\udd18\ud888\udd99\ud999\udf81\u0331\ud80d\udf5f\udac2\udf6c\uda41\udd5a\ud9cf\ude87\udb07\udcb5\udaf5\udcc2\udb55\udc7f\ud801\udf92\udac3\udc37000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000057\012",
        Z.run(T, 2, 4, 6, 5, "\ud855\uddd7\ud881\udeb7\udb67\udf99\ud97a\udd18\ud888\udd99\ud999\udf81\u0331\ud80d\udf5f\udac2\udf6c\uda41\udd5a\ud9cf\ude87\udb07\udcb5\udaf5\udcc2\udb55\udc7f\ud801\udf92\udac3\udc37", "\u137e\ubfc3\u1a67\u677c\u9915\ub72d\ud6f7\ua6d9", "\udbf6\udf15\udacc\udc8a\uda26\udc23",
        57, 222, 1362610706, -771062128537952203L, 11972L, false, false, (char) 22653, (char) 62752,
        Double.longBitsToDouble(0x3fe6bc9ff052d9f5L), Double.longBitsToDouble(0x3fe15e6476c4b120L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 7, 0, 0, "\ud9f2\udd21\ud914\udf8b\uda17\udcf3\u0165\uda3c\ude10\ud8ca\udf99\u02bc\udb99\uddee\udbe7\udd52\ud88c\ude5d\ud8be\udfe1\ud91b\udfc5\ud83c\udd6e\ud976\udfe1\udbf2\udc09\ud9ff\udd38\uda78\udc2e\uda7f\udd51\ud86c\udf57\ud95b\udcd3\udba2\udc8a\ud86f\udc78\udb3b\udc34\udbb0\udeed\udac9\udde8\udb57\ude4c\udb63\udf5b\ud99d\udd88", "\u1631t\u4d8b\u487d\u08b3\u547e\u2cc8\u9c75\u123b\ubebc\u3997\u1c8e\u7131", "\udb03\udde8\udba5\udd4a\uda83\udc7a\uda05\udd5d\uda2a\udd89\ud836\udd15\udb4b\udc3d\ud9fe\udeb0\ud9f7\uded9",
        11, 18, 1114328711, 8939931686476193878L, -27276L, false, false, (char) 41483, (char) 21535,
        Double.longBitsToDouble(0x3fc9349fde6ee2e4L), Double.longBitsToDouble(0x3fe8ed16d993becdL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:11\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 5, 7, 0, "\ud9f2\udd21\ud914\udf8b\uda17\udcf3\u0165\uda3c\ude10\ud8ca\udf99\u02bc\udb99\uddee\udbe7\udd52\ud88c\ude5d\ud926\ude95\ud895\udc45\udb16\udc89\ud976\udfe1\udbf2\udc09\ud9ff\udd38\uda78\udc2e\uda7f\udd51\ud86c\udf57\ud95b\udcd3\udba2\udc8a\ud86f\udc78\udb3b\udc34\udbb0\udeed\udac9\udde8\udb57\ude4c\udb63\udf5b\ud99d\udd88", "\u1631t\u4d8b\u487d\u08b3\u547e\u2cc8\u9c75\u123b\ubebc\u3997\u1c8e\u7131", "\udb03\udde8\udba5\udd4a\uda83\udc7a\uda05\udd5d\uda2a\udd89\ud836\udd15\udb4b\udc3d\ud9fe\udeb0\ud9f7\uded9",
        11, 18, 1114328711, 8939931686476193878L, -27276L, false, false, (char) 41483, (char) 21535,
        Double.longBitsToDouble(0x3fc9349fde6ee2e4L), Double.longBitsToDouble(0x3fe8ed16d993becdL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud9f2\udd21\ud914\udf8b\uda17\udcf3\u0165\uda3c\ude10\ud8ca\udf99\u02bc\udb99\uddee\udbe7\udd52\ud88c\ude5d\ud926\ude95\ud895\udc45\udb16\udc89\ud976\udfe1\udbf2\udc09\ud9ff\udd38\uda78\udc2e\uda7f\udd51\ud86c\udf57\ud95b\udcd3\udba2\udc8a\ud86f\udc78\udb3b\udc34\udbb0\udeed\udac9\udde8\udb57\ude4c\udb63\udf5b\ud99d\udd88000000000000000011\0121=void |a0=java.lang.StringBuilder:\ud9f2\udd21\ud914\udf8b\uda17\udcf3\u0165\uda3c\ude10\ud8ca\udf99\u02bc\udb99\uddee\udbe7\udd52\ud88c\ude5d\ud926\ude95\ud895\udc45\udb16\udc89\ud976\udfe1\udbf2\udc09\ud9ff\udd38\uda78\udc2e\uda7f\udd51\ud86c\udf57\ud95b\udcd3\udba2\udc8a\ud86f\udc78\udb3b\udc34\udbb0\udeed\udac9\udde8\udb57\ude4c\udb63\udf5b\ud99d\udd88000000000000000011\012",
        Z.run(T, 2, 6, 6, 0, "\ud9f2\udd21\ud914\udf8b\uda17\udcf3\u0165\uda3c\ude10\ud8ca\udf99\u02bc\udb99\uddee\udbe7\udd52\ud88c\ude5d\ud926\ude95\ud895\udc45\udb16\udc89\ud976\udfe1\udbf2\udc09\ud9ff\udd38\uda78\udc2e\uda7f\udd51\ud86c\udf57\ud95b\udcd3\udba2\udc8a\ud86f\udc78\udb3b\udc34\udbb0\udeed\udac9\udde8\udb57\ude4c\udb63\udf5b\ud99d\udd88", "\u1631t\u3411\u58f6\u684e\u547e\u2cc8\u9c75\u123b\ubebc\u3997\u1c8e\u7131", "\udb03\udde8\udba5\udd4a\uda83\udc7a\uda05\udd5d\uda2a\udd89\ud836\udd15\udb4b\udc3d\ud9fe\udeb0\ud9f7\uded9",
        11, 18, 826101383, 8939932197577302102L, -27276L, false, false, (char) 41483, (char) 21535,
        Double.longBitsToDouble(0x3fc9349fd33557d0L), Double.longBitsToDouble(0x3fec26220993becdL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\ud808\udef7\ud851\udc79\udb99\uddee\udbe7\udd52\uda10\ude5a\ud94e\uddac\ud9d9\udcb1\uda4f\ude11\udb55\udc7f\uda23\udc17\ud856\udd8f", "\u1a4f\u6110\u4168", "\uda2b\uddeb\udac9\udde8\ud955\ude2b\udbd8\udd45\ud966\ude8b\u8c06\udabe\udc01\ua6e8\ud9cb\udd9d\uda41\ude03\udb6c\ude0e\udba3\ude54\ud8f5\udc71\ud91a\ude60\ud931\udd37\udbc2\udf8f",
        47, 38810, -2064265630, -3706857312957182421L, -41868L, true, true, (char) 474, (char) 749,
        Double.longBitsToDouble(0x3fe7c0972d2731feL), Double.longBitsToDouble(0x3fecfc4157024e67L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\000\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10g\ud851\udc12\000\000\000\ud896\udc0a\000\000\000\uda22\udfa0\ub8c40000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000...\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 6, 1, 6, "\000\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10g\ud851\udc12\000\000\000\ud896\udc0a\000\000\000\uda22\udfa0\ub8c4", "", "\ud9f7\udc69\ud86f\udc78\ud8e2\ude86\u3cfe\000\000\udba6\udd73\ud966\ude8b",
        17, 29646, -527075134, 288289058333039478L, -100000L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3d8a400000000000L), Double.longBitsToDouble(0x3f47a019893c2c00L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:18\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 5, 7, 7, "\udb53\udc2b\ud914\udf8b\uda17\udcf3\u0165\uda3c\ude10\ud8ca\udf99\u1ec0\udb99\ude75\udbe7\udd54\ud85b\ude5d\udba9\udc06\ud895\udc45\udb16\udc89\ud976\udfe1\udbf2\udc09\ud9ff\udd38\ud82c\udcff\ud941\udc79\ud818\udfd1\ud92e\udf23\udaf9\uddb6\ud861\udf36\udb3b\udc34\udb53\ude77\udac9\udde8\udb57\ude4c\udb63\udf5b\ud99d\udd88", "\u1631t\u4d8b\u487d\u08b3\ud313\u994e\u44ba\u123b\ubebc\u3997\u1c8e\u7131", "\uda90\uddf0\udba5\udd4a\uda83\udc7a\uda05\udd5d\uda2a\udd89\ud836\udde6\udb4b\udc3d\ud9fe\udeb0\ud9f7\uded9",
        18, 18, 1114328711, -4131075737823905858L, -27276L, false, false, (char) 41483, (char) 21535,
        Double.longBitsToDouble(0x3fc93d207e6ee2e4L), Double.longBitsToDouble(0x3fe8ed16d993becdL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 1, 6, "\000\ud9e3\udc55\uda17\udcf3\udaf8\udc57\uda3c\ude10\u0088\ud851\udc12\000\u2600\000\ud896\udc0a\000\000\000\uda22\udfa0\ub8c4", "", "\ud9f7\udc69\ud86f\udc78\ud8e2\ude86\u3cfe\000\000\udba6\udd73\ud966\ude8b",
        17, 29646, -527075134, 288289058333039478L, -100000L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3d8a400000000000L), Double.longBitsToDouble(0x3f47a019893c2c00L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 7, 7, 7, "\udb53\udc2b\ud914\udf8b\uda17\udcf3\u0165\uda3c\ude10\ud8ca\udf99\u1ec0\udb99\ude75\udbe7\udd54\ud85b\ude5d\udba9\udc06\ud895\udc45\udb16\udc89\ud976\udfe1\udbf2\udc09\ud9ff\udd38\ud82c\udcff\ud941\udc79\ud83d\udea3\uda56\udee9\ud895\udd81\ud861\udf36\udb3b\udc34\udb53\ude77\udac9\udde8\udb57\ude4c\udb63\udf5b\udb8f\udd81", "\u1631t\u54a3\u487d\u08b3\ud313\u994e\u44ba\u123b\ubebc\u3997\u1c8e\u7131", "\uda0f\udefb\udba5\udd07\uda83\udc7a\uda05\udd5d\uda2a\udd89\ud836\udde6\udb4b\udc3d\ud9fe\udeb0\ud9f7\uded9",
        18, 18, 1114328711, -4131075737823905858L, -27276L, false, false, (char) 41483, (char) 21535,
        Double.longBitsToDouble(0x3fc93d207e6ee2e4L), Double.longBitsToDouble(0x3fe8ed16d993becdL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:9458591-08-30T17:46:27.574Z\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 2, "\udb39\ude6b\ud9e3\udc55\uda17\udcf3\udb69\uddb0\udb3d\udca4\ud808\udef7\ud871\ude89\ud984\udde3\ud90b\udd78\udb8c\ude6b\ud94e\uddac\ud9d9\udcb1\ud8b8\udd4b\uda06\uddc3\uda23\udc24\ud856\udd8f", "\u470c", "\udbe9\udf7c\ud8e2\ude86\uda2b\uddeb\ud9a9\ude25\uda03\udd99\uda2e\udc06\ud966\ude8b",
        36, 29646, -527075134, 298422155900787574L, -38121L, true, true, (char) 22779, (char) 41571,
        Double.longBitsToDouble(0x3fe38095ee624f0bL), Double.longBitsToDouble(0x3fef9427ae01cc8eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.bind.util.ISO8601Utils|parse|java.lang.String,java.text.ParsePosition|static",
    "M|com.google.gson.internal.bind.util.ISO8601Utils|checkOffset|java.lang.String,int,char|static",
    "M|com.google.gson.internal.bind.util.ISO8601Utils|format|java.util.Date|static",
    "M|com.google.gson.internal.bind.util.ISO8601Utils|format|java.util.Date,boolean|static",
    "M|com.google.gson.internal.bind.util.ISO8601Utils|format|java.util.Date,boolean,java.util.TimeZone|static",
    "M|com.google.gson.internal.bind.util.ISO8601Utils|indexOfNonDigit|java.lang.String,int|static",
    "M|com.google.gson.internal.bind.util.ISO8601Utils|padInt|java.lang.StringBuilder,int,int|static",
    "M|com.google.gson.internal.bind.util.ISO8601Utils|parseInt|java.lang.String,int,int|static",
    "C|com.google.gson.internal.bind.util.ISO8601Utils|<init>|",
    "M|com.google.gson.internal.bind.util.ISO8601Utils|parse|java.lang.String,java.text.ParsePosition|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
