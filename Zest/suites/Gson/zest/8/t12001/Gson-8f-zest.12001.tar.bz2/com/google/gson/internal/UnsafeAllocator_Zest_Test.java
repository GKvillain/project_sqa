package com.google.gson.internal;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnsafeAllocator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.google.gson.internal.UnsafeAllocator$1:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 2, 0, "\udbf8\ude94\udaaa\udce4\udb68\udc1d\uda19\udc78", "\ud733\u09d9", "\uda20\udcff\uda50\udd1b\ud861\udcfa\uda71\udd9a\ud88f\udc69",
        34, 32725, -311715484, 1391990585483046436L, -1703L, false, true, (char) 797, (char) 25943,
        Double.longBitsToDouble(0x3fc8cbb3f71d137cL), Double.longBitsToDouble(0x3fe5793d16f5de5fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.google.gson.internal.UnsafeAllocator$1:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 2, 0, "\udbf8\ude94\udaaa\udce4\udb2a\ude1e\uda19\udc5e", "\ud733\u09d9", "\uda20\udcff\uda50\udd1b\ud861\udcfa\uda71\udd9a\ud88f\udc69",
        34, 32725, -311715484, 1391990585483021604L, 19205L, false, true, (char) 52553, (char) 14013,
        Double.longBitsToDouble(0x3fddb41422c687e8L), Double.longBitsToDouble(0x3fc8cbb3f71d137cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.gson.internal.UnsafeAllocator$1:@?\0121=java.util.ArrayList:[] |this=com.google.gson.internal.UnsafeAllocator$1:@?\012",
        Z.run(T, 2, 1, 2, 1, "\udbf8\ude94\udaaa\udce4\udb68\udc1d\uda19\udc78", "\ud733\uabea", "\uda20\udcff\uda50\udd1b\ud861\udcfa\ud9f4\ude22\ud85b\udd0f",
        51, 92569, -311715484, -4290258874181854360L, -50208L, false, true, (char) 797, (char) 25943,
        Double.longBitsToDouble(0x3fc8cbb3f71d137cL), Double.longBitsToDouble(0x3fe5793d16f5de5fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.google.gson.internal.UnsafeAllocator$1:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 0, 1, "\udabc\ude89\udba6\udd63\uda9a\ude15\uda19\udc78\uda2f\udcfb\udaaa\udfdf\udae5\udd20\ud880\udd5c\ud9f2\udd37\ud842\udcc5\udbfe\ude88\ud8d2\uddf8\uda03\udd2b\ud815\udc20\ud8a1\udce9\ud895\udd5c\ud840\udcf1", "\u4b73\ucb5d\u5ca1\ua335\u9738", "\ud993\udee7\ud89f\ude07\udabf\ude4e\ud9a6\ude1c",
        7, 4738, -1256945828, 4231528264801634245L, 47582L, false, false, (char) 18977, (char) 1696,
        Double.longBitsToDouble(0x3fca164c37cc3afcL), Double.longBitsToDouble(0x3fb6530cb5276d50L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Object:@? |this=com.google.gson.internal.UnsafeAllocator$1:@?\0121=void\012",
        Z.run(T, 2, 2, 0, 0, "\udbf8\ude94\uda9d\udf7b\udb68\udc1d\uda19\udc78\uda61\uddf4\udab4\udd39\ud92a\udc42\udaae\udcba", "\u3fa9\u6a73\u05b5\u6a19\u4261\u7f82\u3bfa\u52d6\u371b\ua344\u6f42\u7102\u2bb5\u9738\ud71c\ua265\u086a\u6a66\ua7c0\uc0d3\u3cb5\ud046\uaaba\u7ec5\u8574\u66c9\u32b3\u8bfe", "\ud81a\udfb9\ud8e5\udd85\ud88f\udd7a\uda19\ude03",
        3, 5275, -2044447492, 7851808614013641695L, 55717L, false, true, (char) 64427, (char) 31424,
        Double.longBitsToDouble(0x3fd778b0b564e96aL), Double.longBitsToDouble(0x3fe6b31b13f9df6eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void\0121=com.google.gson.internal.UnsafeAllocator$1:@?\012",
        Z.run(T, 2, 3, 1, 2, "\udbf8\ude94\udaaa\udce4\udb68\udc1d\uda19\udc78", "\ud733\u09d9\u6221\ub256\u7118\u6a73\ua337\u7907\u4261\u62e5\u6ec9\u935e\u36f5\u5782\u8584\u1b26\u2c14\u9738", "\ud993\udee7\u94d5\udbde\udc1c\udaa8\udcb3",
        23, 79645, 1426864535, 3490017323794625255L, -52834L, false, false, (char) 45988, (char) 5372,
        Double.longBitsToDouble(0x3febb43764a218adL), Double.longBitsToDouble(0x3f8bc8f9a32edc80L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.gson.internal.UnsafeAllocator$1:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 0, "\ud852\udd01\udaaa\udd09\udb68\udc1d\uda19\udc78\uda2a\udc79\udab4\udd39\ud8ec\udc62", "\u21d4\uba25\u6a73\ua337\u7907", "\ud840\udd73\ud946\ude52\ud99e\udd9b\uda43\uddcf\ud8b3\udc5c\ud8aa\udd4f\ud8d0\udea1\ud89d\udde5\udb47\udf0c\ud887\udf3d\udbc9\udca3\u94fd\udbde\udc1c\udaa8\udcb3\ud829\ude74",
        26, 79509, 2135260351, -6366528961672589246L, -3346L, true, true, (char) 45673, (char) 28997,
        Double.longBitsToDouble(0x3fdb844d0251786eL), Double.longBitsToDouble(0x3fee4286e4fff032L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 2, "\udaf1\uddcc\udaaa\udce4\udb68\udc1d\uda19\udc78\udaa9\udc38\uda92\udc1d\ud8ec\udc62\uda41\udf47\ud96c\udf40\udaec\udf2a\uda20\udcff\uda50\udd1b\ud861\udcfa\uda71\udd9a\ud88f\udc69", "\u56d4\u36f5\uc7c1\u8584", "\ud95d\udf35\ud9d6\udfa3\ud896\udf78\udacd\udc5e\u94d5\udbde\udc1c\udb69\udd74\ud956\udd1a\uda13\udf08\udba7\udef8\ud873\uddd1\udb57\udf9e\ud9f1\udf74\udb40\udd96\udb19\uded4\uda75\ude45\uda31\udf31\uda3f\udcdd\ud909\udcf2\ud94e\udf54\uda34\udc1b\ud8ce\udca7\uda0b\udc13\ud8fa\udd6b\ud847\udc6d\udb66\udc9a\ud8fb\udf55\udaa0\udc40",
        29, 53326, -119210980, -4735631746948764316L, 53466L, false, false, (char) 39799, (char) 53260,
        Double.longBitsToDouble(0x3fc5aeb8183c5e74L), Double.longBitsToDouble(0x3fe0b187e9b417f6L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "\udbf8\ude94\udaaa\udce4\udb68\udc1d\uda19\udc78", "\ud733\u09d9\u6221", "\ud945\ude43\udbb1\udf70\uda71\udd9a",
        3, 16075, -1995829143, -1338808187724146672L, 82724L, true, false, (char) 25715, (char) 54373,
        Double.longBitsToDouble(0x3fdc7598455e4f44L), Double.longBitsToDouble(0x3fe7aef2fa1522d9L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 3, 3, 0, "\udbf8\ude94\udaaa\udce4\udb68\udc1d\uda19\udc78", "\u8b5d\u09d9", "\uda20\udcff\uda50\udd1b\ud861\udcfa\uda71\udd9a\ud88f\udc69",
        34, 32725, -311715484, 1391990585483046436L, -67239L, false, true, (char) 13481, (char) 36213,
        Double.longBitsToDouble(0x3fc8cbb3f71d137cL), Double.longBitsToDouble(0x3fee913d1530f21eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 0, 2, 0, "\udbfa\udc93\uda59\udd6e\udb3f\udf47\ud85a\udc2a\uda61\uddf4", "\ub908\u0764\ub256\u7118\ucc39\ua337\u3366\ua9af\u3f83\u42bd\u935e\uc4f4\u5782", "\ud8d0\udea1\udaf8\udcd3\uda25\udd9c\ud8b5\udddc\ud993\udee7\u94d5\udbde\udc1c\udaa8\udcb3\ud9fb\udffa\ud860\ude88\udbdf\udf14\ud9d1\udffa",
        22, 1037, -205665843, -4084312016811430509L, -50703L, true, false, (char) 25065, (char) 478,
        Double.longBitsToDouble(0x3feeec089b1645c7L), Double.longBitsToDouble(0x3fe92592ecf0b351L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.gson.internal.UnsafeAllocator$1:@?\012",
        Z.run(T, 1, 1, 2, 0, "\udbf8\ude94\udaaa\udce4\ud937\udde4\udb18\udc4e", "\ud733\u09d9", "\uda20\udcff\ud949\ude38\udacf\udc36\uda78\ude7e\ud88f\udc69",
        34, 85029, 278745983, 7551039744553451196L, -1703L, false, true, (char) 31619, (char) 25943,
        Double.longBitsToDouble(0x3fe4509cfdab9039L), Double.longBitsToDouble(0x3fe5793d1196665fL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.gson.internal.UnsafeAllocator$1:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 2, 1, "\ud8ec\ude8e\udaaa\udce4\udb68\udc1d\uda19\udc78", "\u2cb9\u09d9", "\uda20\udcff\uda50\udd1b\ud861\udcfa\ud81d\udd30\udb88\ude5e",
        18, 12073, -311715484, -9185276089349984732L, -1703L, false, true, (char) 31728, (char) 3943,
        Double.longBitsToDouble(0x3fc8c6f7e5fd137cL), Double.longBitsToDouble(0x3febd0d3aac0b58fL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=com.google.gson.internal.UnsafeAllocator$1:@?\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=com.google.gson.internal.UnsafeAllocator$1:@?\012",
        Z.run(T, 2, 2, 2, 0, "\udbf8\ude94\udaaa\udce4\udb68\udc1d\uda19\udc78", "\ud733\u09d9", "\ud87c\udf91\udb8a\udcef\ud861\udcfa\ud99f\udd18\udb88\udf95\ud88d\udf61\ud820\udd4f\udab6\udc46\ud99e\udd33\uda43\uddcf\ud8b3\udc5c\ud8aa\udd4f\ud8d0\udea1\udaf8\udcd3\uda25\udd9c\ud8b5\udddc\ud993\udee7\u94d5\uda3b\udc18\udbb6\udcb2\ud8fa\ude0c\ud914\ude5c\ud962\udde8",
        24, 7329, -637393543, -5267688839367519009L, -8146L, true, true, (char) 332, (char) 38539,
        Double.longBitsToDouble(0x3fb964d2eacefca8L), Double.longBitsToDouble(0x3fd4a3596dee712cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Object:@? |this=com.google.gson.internal.UnsafeAllocator$1:@?\0121=java.lang.Object:@? |this=com.google.gson.internal.UnsafeAllocator$1:@?\012",
        Z.run(T, 2, 2, 2, 0, "\uda49\udfd0", "\u12aa\u9dae\ua71d\u6f56\u09d9\u6221\u5386\u74a2\u30ae\u241c\u6541", "\u497d\uda75\udc2b\ud99e\udd33\ud95c\udd0a\ud8b3\udc5c\udbb0\udd9e\uaf8a\ud846\udc77\uda25\udda4\ud8b5\udddc\ud993\udee7\u94d5\ud9f6\uddd2\udaa8\udcb3\ud947\udfbf",
        45, 82209, -118324044, 351871315675071459L, 71446L, true, false, (char) 7345, (char) 15981,
        Double.longBitsToDouble(0x3fecf36ada60e28aL), Double.longBitsToDouble(0x3fec5694e39d0bc5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 3, "\udb9e\udc63\udad5\udc41\udb68\udc1d\uda19\udc78\uda61\uddf4\ud960\udef0\ud8ec\udc62\ud82a\udc83\ud949\udf96\udb66\udf71\uda20\udcff\uda50\udd1b\ud861\udcfa\ud9f4\ude22\ud85b\udd0f\udacb\udcb1\ud9fe\udc46\udab6\udc4b\uda16\udc6d\ud8cc\uddc1\udb61\udc79\ud8a8\udde9\uda76\udea0\udbb8\udde2\ud951\udf13\ub2db\udac4\udd09\udb3a\ude07\udbde\udc1c\udaa8\udcb3\ud888\udc3f\udbce\udc3d\ud812\udfff\udba0\udff6\udae4\udf13\udb1a\udca7", "\ubf8a\ub7d7\u55e6\uad1a\u848e\u5bba\u6ae4\u6c0a\u6549\u931f\u1772\u3ad4\u4d20", "\udaf2\ude96\ud912\udcfe\uda65\udca1\uda58\udfda\udbd8\udd3e\udb58\ude9e",
        15, 50409, -405066156, -6971005856024082009L, 63443L, true, true, (char) 48113, (char) 22887,
        Double.longBitsToDouble(0x3fc6e39d6790d6e0L), Double.longBitsToDouble(0x3fe03fb0a6a92406L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=com.google.gson.internal.UnsafeAllocator$1:@?\0121=java.lang.Long:0 |this=com.google.gson.internal.UnsafeAllocator$1:@?\012",
        Z.run(T, 2, 2, 2, 0, "\udbf8\ude94\udaaa\udce4\udb68\udc1d\uda19\udc78", "\ud733\u09d9", "\uda20\udcff\uda50\udd1b\ud861\udcfa\uda71\udd9a\udb45\udd83",
        54, 4866, -311715484, 1391990585483046436L, -1703L, false, true, (char) 797, (char) 25943,
        Double.longBitsToDouble(0x3fc8cbb3f71d137cL), Double.longBitsToDouble(0x3fe5793d16f5de5fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.UnsafeAllocator|assertInstantiable|java.lang.Class|static",
    "M|com.google.gson.internal.UnsafeAllocator|create||static",
    "M|com.google.gson.internal.UnsafeAllocator|newInstance|java.lang.Class|fac:com.google.gson.internal.UnsafeAllocator:create:",
    "M|com.google.gson.internal.UnsafeAllocator|assertInstantiable|java.lang.Class|static",
    "M|com.google.gson.internal.UnsafeAllocator|create||static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
