package com.google.gson.internal.bind;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeAdapters_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$33:Factory[type=java.lang.Thread$State+[I,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$34:Factory[type=[I+java.lang.Thread$State,adapter=null]\012",
        Z.run(T, 2, 2, 3, 2, "\udb33\ude08\udabd\udcd7\udbb3\udf86\u19ec\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\udaeb\udfee\ud86b\udf93\ud9d6\uddbe\uda5d\udfc1\udac9\ude67\udb24\udeed\uda90\ude09\udac3\udd2b\ud838\udee5\ud898\udda9", "\u027f\u7548", "\udb5e\udf7c\ud934\ude1b\ud90b\uddea\u6318\udbdf\udf2b\uda35\udc64\ud86f\udd33\udac7\udf04\ud9ac\ude04\ud861\udcbb\udb8f\udc26\ud923\udfc9",
        19, 18155, 1621843288, 5177781316786607178L, -38804L, true, true, (char) 10234, (char) 13528,
        Double.longBitsToDouble(0x3fe12d3b11357e60L), Double.longBitsToDouble(0x3fdee068ae93e42eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$33:Factory[type=java.lang.Thread$State+[I,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$31:@?\012",
        Z.run(T, 2, 2, 0, 2, "\udb33\ude08\udabd\udcd7\udbb3\udf86\u19ec\udbcf\udc0f\ud9fb\uddef\udb32\udef5\ua767\udad5\udeaa\ud86b\udf93\ud9c9\udd84\uda5d\udfc1\udac9\ude4c\udb24\udeed\uda90\ude09\udac3\udd2b\ud838\udee5\ud898\udda9", "\u9d7e\u7548", "\udb5e\udf7c\ud934\ude1b\ud90b\uddea\u6318\udbdf\udf2b\uda35\udc64\ud86f\udd33\udac7\udf04\ud97f\udc5e\ud861\udcbb\udb8f\udc26\ud905\uddc9",
        19, 18155, 1621843288, 5177780573757264970L, -38804L, true, true, (char) 10234, (char) 22488,
        Double.longBitsToDouble(0x3fe12d3b11000000L), Double.longBitsToDouble(0x3fdee068ae93e42eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$33:Factory[type=java.lang.Object+java.util.ArrayList,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$35:Factory[typeHierarchy=java.util.ArrayList,adapter=null]\012",
        Z.run(T, 2, 2, 4, 4, "\udb33\ude08", "\u7bad\u53f3\000\000\000", "\ud9d6\uddbe\uda5d\udfc1\udac9\ude67\udb24\udeed\uda90\ude09",
        51, 61883, 2134268458, -1109686035665535840L, -76873L, false, false, (char) 58935, (char) 51448,
        Double.longBitsToDouble(0x3fa3abf1586996a0L), Double.longBitsToDouble(0x3fe69035318604a4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$34:Factory[type=[I+java.lang.Thread$State,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$34:Factory[type=[I+java.lang.Thread$State,adapter=null]\012",
        Z.run(T, 2, 3, 3, 2, "\udb33\ude08\udabd\udcd7\udbb3\udf86\u19ec\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\000\uda21\udd00\ud9c9\udd84\uda5d\udfc1\033\u0100\uda90\ude09\udac3\udd2b\ud838\udee5\ud89e\ude2d", "\u027f\u1382", "\udb5e\udf7c\ud934\uddf4\ud9f6\udc5a\u6318\u0086\udb9b\udf6c\ud86f\udd33\udac7\udf04\ud9ac\ude04\ud861\udcbb\udb8f\udc26\ud923\udfc9",
        19, 18155, 1621843288, 5177781316786607178L, -38804L, true, true, (char) 10234, (char) 13528,
        Double.longBitsToDouble(0x3fe12d3b11357e60L), Double.longBitsToDouble(0x3fdee068ae93e42eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$32:Factory[type=java.util.Date,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$32:Factory[type=java.util.Date,adapter=null]\012",
        Z.run(T, 2, 1, 1, 1, "\udb3b\udc65\udb6a\udf6d\udb36\uded0\ud864\uddd0\u27a4\uda44\udf13\ud9e8\udce5\uda56\uddfd\udaf3\uddee\ud86b\udf93\ud935\udc7c\uda74\ude01", "\ua05e\u813e\u7109\u12a1\u6d3f\u0643\u027f\u7548\u829e\u3724\u7ddf\u4085\u1edf\u12f1\u78b4", "\udac0\udd9c\ud8ac\udf3d\udbbd\ude44\udb8f\udc7e",
        24, 65709, 1778687331, 6965764520154967213L, -28800L, false, false, (char) 45359, (char) 19283,
        Double.longBitsToDouble(0x3fe75d9107fbf76dL), Double.longBitsToDouble(0x3fdea56eec4b4ec4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$33:Factory[type=java.lang.String+java.util.List,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$32:Factory[type=java.util.List,adapter=null]\012",
        Z.run(T, 2, 2, 1, 1, "\udb33\ude08\udabd\udcd7\udbde\udc3b\ud9ec\udc4b\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\udaeb\udfee\ud86b\udf93\ud9d6\uddbe\uda5d\udfc1\udac9\ude67\udb24\udeed\uda90\ude09\udac3\udd2b\ud838\udee5\ud898\udda9", "\u027f\u7548", "\udb83\ude7c\ud934\ude1b\ud90b\uddea\u6318\udbfa\udcb7\udb12\udf2c\ud872\udfd9\udac7\udf04\ud9ac\ude04\ud861\udcbb\udb8f\udc26\ud923\udfc9",
        4, 83188, -1348761628, 5177780857225106506L, -38804L, true, true, (char) 10234, (char) 13528,
        Double.longBitsToDouble(0x3fe12d3b11357e60L), Double.longBitsToDouble(0x3fdee068ae93e42eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$32:Factory[type=[I,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$31:@?\012",
        Z.run(T, 2, 1, 0, 0, "\udb33\ude08\udabd\udcd7\udbb3\udf86\u19ec\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\udaeb\udfee\ud86b\udf93\ud9d6\uddbe\uda5d\udfc1\udac9\ude67\udb24\udeed\uda90\ude09\udac3\udd2b\ud838\udee5\ud898\udda9", "\u027f\u7548", "\udb5e\udf7c\ud934\ude1b\ud90b\uddea\ud9c7\uddf1\udbdf\udf2b\uda35\udc64\ud86f\udd33\udac7\udf04\ud9ac\ude04\ud861\udcbb\udb8f\udc26\ud923\udfc9",
        19, 18155, 1621843288, 5177781316786607178L, -38804L, true, true, (char) 10234, (char) 13528,
        Double.longBitsToDouble(0x3fe12d3b11357e60L), Double.longBitsToDouble(0x3fdee068ae93e42eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$33:Factory[type=java.lang.Thread$State+[I,adapter=null]\012",
        Z.run(T, 1, 2, 3, 2, "\udb33\ude08\ud83e\udf17\ud98e\udd3c\u1a19\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\udaeb\udfee\ud86b\udf93\ud9d6\uddbe\uda5d\udfc1\ud861\udf45\udad6\udf26\uda90\ude09\udac3\udd2b\ud963\udc5b\ud898\udda9", "\u027f\u7548", "\udac3\udd6e\uda57\udd0c\ud90b\uddd1\u6318\ud91d\udd89\ud8a1\udc71\udb76\udc21\udaf7\uddff\ud9ac\ude04\ud861\udcbb\ud8a5\udc31\ud923\udfc9",
        19, 18155, 1621843288, 5177781316786607178L, -38804L, true, true, (char) 9210, (char) 46838,
        Double.longBitsToDouble(0x3fe343a12938e698L), Double.longBitsToDouble(0x3fdee068abafe42eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$33:Factory[type=java.lang.Thread$State+[I,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$33:Factory[type=java.lang.Thread$State+[I,adapter=null]\012",
        Z.run(T, 2, 2, 2, 2, "\udb33\udd5f\ud9f6\udcf4\ud93c\uddf6\u19ec\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\udaeb\udfee\ud86b\udf93\udb31\udc0b\uda7a\udf90\udac9\ude67\udb24\udeed\uda90\ude09\udac3\udd2b\ud838\udee5\ud898\udda9", "\u027f\u0fbd", "\udb5e\udf32\ud933\udf23\ud90b\uddea\u6318\udbdf\udf2b\udb63\uddfd\ud86f\udd33\udac7\udf04\ud9ac\ude04\ud861\udcbb\udb8f\udc26\ud923\udfc9",
        19, 18155, 1621843288, 5177781316786607178L, -38804L, true, true, (char) 10234, (char) 47073,
        Double.longBitsToDouble(0x3fe12cd321357e60L), Double.longBitsToDouble(0x3fdee068ae93e42eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$34:Factory[type=char+java.lang.Comparable,adapter=null]\012",
        Z.run(T, 1, 3, 2, 3, "\udb45\udc22\udabd\udcd7\udbb3\udf86\u19ec\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\udaeb\udfee\ud86b\udf93\ud9d6\uddbe\uda5d\udfc1\udac9\ude67\udb24\udeed\uda90\ude09\udac3\udd2b\ud838\udee5\ud898\udda9", "\u027f\u7548\u2143\ub6a6\uae77", "\u6318\udbdf\udf2b\uda35\udc64\ud86f\udd33\udac7\udf04",
        55, 7722, 1715797650, -3504228601315841387L, -58360L, false, true, (char) 39883, (char) 16553,
        Double.longBitsToDouble(0x3fd183e7cc804e9eL), Double.longBitsToDouble(0x3fe202df02dc9653L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$31:@?\0121=com.google.gson.internal.bind.TypeAdapters$31:@?\012",
        Z.run(T, 2, 0, 0, 2, "\udb29\udebc\udabd\udcd7\ud8a9\udd22\u198f\uda4e\udd0f\udb6f\udfe6\ud9e8\udd2c\uda56\uddfd\udaeb\udfee\ud86b\udf93\ud9d6\uddbe\uda5d\udfc1\udac9\ude67\udb24\udeed\ud98d\udd47\udae2\udde4\ud838\udee5\ud910\ude3a", "\u027f\u7548\u2143", "\ud934\ude1b\ud90b\uddea\u6318\udbdf\udf2b\uda35\udc64\ud86f\udd33\udac7\udf04\ud9ac\ude04\ud861\udcbb\udb8f\udc26\ud923\udfc9",
        -1, 18155, 1621843288, 5177781316786607178L, -38804L, true, true, (char) 49910, (char) 61808,
        Double.longBitsToDouble(0x3fe0b173179ab207L), Double.longBitsToDouble(0x3fdee4e04d2de42eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$35:Factory[typeHierarchy=[I,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$35:Factory[typeHierarchy=[I,adapter=null]\012",
        Z.run(T, 2, 4, 4, 2, "\udb49\ude34\udaf0\udded\ud8ee\udd48\u4eaa\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\udaeb\udfee\ud86b\udf93\ud877\udceb\udb99\udf94\udac9\ude67\udb24\udeed\ud9fb\udc7f\udac3\udd2b\ud838\udee5\ud898\udda9", "\u027f\u7548", "\udb5e\udf7c\ud934\ude1b\ud942\udcea\uda78\udcba\udbdf\udf2b\uda35\udc64\ud885\udf8b\ud930\udcff\ud8d5\udc71\ud861\udcbb\udb8f\udc26\ud923\udfc9",
        19, 18155, 1621843288, 5177781316786607178L, -38804L, true, true, (char) 10234, (char) 13528,
        Double.longBitsToDouble(0x3fe12d3b14feae63L), Double.longBitsToDouble(0x3fd0ca3f5e93e42eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$31:@?\012",
        Z.run(T, 1, 0, 4, 2, "\udb33\ude08\udabd\udcd7\udbb3\udf86\u19ec\udbcf\udc0f\uda4f\udf59\udb32\ude55\ua767\udad5\udeaa\ud86b\udf93\ud9c9\udd84\uda5d\udfc1\udac9\ude4c\udb24\udeed\uda90\ude09\udac3\udd2b\ud838\udee5\ud898\udda9", "\u9d7e\u7548", "\udb5e\udf7c\ud934\ude1b\ud90b\uddea\u6318\udab2\ude75\ud8a3\udd22\ud86f\udde6\udac7\udf04\ud97f\udc5e\ud861\udcbb\udb8f\udc26\ud905\uddc9",
        19, 18155, 1135304024, 1508047231997465796L, 29289L, true, false, (char) 19283, (char) 61963,
        Double.longBitsToDouble(0x3fefdc3ff8ea56eeL), Double.longBitsToDouble(0x3fe12d3b11000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.gson.internal.bind.TypeAdapters$33:Factory[type=java.lang.Thread$State+[I,adapter=null]\0121=com.google.gson.internal.bind.TypeAdapters$34:Factory[type=[I+java.lang.Thread$State,adapter=null]\012",
        Z.run(T, 2, 2, 3, 2, "\udb33\ude08\udabd\udcd7\udbb3\udf86\u19ec\udbcf\udc0f\ud9fb\uddef\ud9e8\udd8f\uda56\uddfd\udaeb\udfee\ud86b\udf93\ud9d6\uddbe\uda5d\udfc1\udac9\ude67\udb24\udeed\uda90\ude09\udac3\udd2b\ud838\udee5\ud898\udda9", "\u027f\u7548", "\ud906\ude71\ud934\udecc\ud90b\uddea\udbf9\ude08\udbdf\udf2b\uda35\udc64\ud86f\udd33\udac7\udf04\ud9ac\ude04\ud861\udcbb\udb8f\udc26\ud923\udfc9",
        19, 18155, 1621843288, 5187080217335190602L, -38804L, true, true, (char) 10234, (char) 13528,
        Double.longBitsToDouble(0x3fe12d3b11357e60L), Double.longBitsToDouble(0x3fdee068ae93e42eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.bind.TypeAdapters|newFactory|com.google.gson.reflect.TypeToken,com.google.gson.TypeAdapter|static",
    "M|com.google.gson.internal.bind.TypeAdapters|newFactory|java.lang.Class,com.google.gson.TypeAdapter|static",
    "M|com.google.gson.internal.bind.TypeAdapters|newFactory|java.lang.Class,java.lang.Class,com.google.gson.TypeAdapter|static",
    "M|com.google.gson.internal.bind.TypeAdapters|newFactoryForMultipleTypes|java.lang.Class,java.lang.Class,com.google.gson.TypeAdapter|static",
    "M|com.google.gson.internal.bind.TypeAdapters|newTypeHierarchyFactory|java.lang.Class,com.google.gson.TypeAdapter|static",
    "C|com.google.gson.internal.bind.TypeAdapters|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
