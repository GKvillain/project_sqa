package com.google.gson.stream;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonReader_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 7, 5, 10, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\udb19\udef7\udb77\udd49", "\u3585\u0d10\u4737\u8899", "\udb96\udccf\ud865\udd67",
        12, 40990, -783793630, -328009844879608237L, 56559L, true, true, (char) 58767, (char) 54673,
        Double.longBitsToDouble(0x3fe65fb58f4da785L), Double.longBitsToDouble(0x3fb83c907a0d84e8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 7, 5, 10, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\udb19\udef7\udb77\udd49", "\u3585\u0d10\u4737\u8899", "\udb96\udccf\ud865\udd67",
        12, 40990, -783793630, -328009844879608237L, -74513L, true, true, (char) 58767, (char) 54673,
        Double.longBitsToDouble(0x3fe7e7b58f4da785L), Double.longBitsToDouble(0x3fb83c907a0d84e8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 7, 5, 13, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8", "\u7fb6\u2c4a", "\ud8cc\udfdc\ud812\udc78\ud955\udd4f\udbb1\ude3c",
        40, 99007, 461412536, -23162919809525631L, 57513L, false, true, (char) 18121, (char) 47879,
        Double.longBitsToDouble(0x3fbc62f0ca7e6748L), Double.longBitsToDouble(0x3fe028b8f3231a2cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 17, 24, "\ud9d7\ude7a\uda2c\udfeb\uda70\udea7\ud914\udc2c\ud9e0\udff5\ud8b6\ude19\ud835\uddc4\udbb8\udd6e\ud853\udccd\uda4c\udf62", "\u80b7\u7279\u634f\u246d\u84e9\u498b\u650a\u99bc\uaff2\u248b\u331b\ua8d5\ub757\u57e4\u2145\u8e3e\u1fa0\ua31c\u6f2a\013\u8fed\u3efe\uaf35\u30c5\u01d3\ud369\u16d6\u6178", "\ud95e\udf27\uda2d\udc7a\ud9ce\ude6e",
        14, 10185, 1588835437, -1165173925165211240L, -45150L, true, false, (char) 21275, (char) 24763,
        Double.longBitsToDouble(0x3fd012252b3b00baL), Double.longBitsToDouble(0x3fac94e30a34a470L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 20, 14, 23, "\udac4\uddc9\uda62\ude68\uda32\uddfc\ud84c\udcf4\ud96b\udcf4\udb57\udfe2\uda5b\udea8\udb19\udef7", "\u39a4\u3585\u0d10\u4737\u8899\u246d\u59be\u1456\u650a\ucf8d", "\ud923\udc84\udbe0\uddac\ud94e\ude42",
        40, 42343, 444386930, -670549167822265653L, 40192L, true, true, (char) 4224, (char) 36800,
        Double.longBitsToDouble(0x3feebf910c6eb327L), Double.longBitsToDouble(0x3fbff868f2f0a348L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 12, 10, "\udb51\udc30\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\ud89a\udef7\udb77\udd49", "\ucbff\u873c\u4737\u8899", "\udbed\ude95\ud923\udfea\ud935\udf9f\udac2\udee8\ud88f\udf61",
        27, 563, 1707280668, -3681239210416823985L, 96380L, false, true, (char) 3855, (char) 46222,
        Double.longBitsToDouble(0x3fe2552f7a618523L), Double.longBitsToDouble(0x3f816fb2ce14c900L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 22, 4, 10, "\udadc\udc50\uda62\ude68\udacb\udfd1\uda6d\udc71\ud9e0\udff8\ud824\udeb0\uda5b\udea8\udb19\udef7\udb8e\ude15\uda4c\udfa6", "\u0d10\u4737\uca48\u6fe1\u7eb1\u6798\u71c7\u7506\u0a6e\u3b39\ub763\u6594\u481a\u11f8\u614d\ub1da\u700e\ub9ab\u44f0\ucda5\u3b8b\ua386\u72fb\ua1e0\u5cc6\u5872\ub57f\u3365", "\ud864\udf43",
        42, 20560, 341840463, 1492423514063309730L, -91601L, true, false, (char) 6638, (char) 42160,
        Double.longBitsToDouble(0x3fee3380e2bed121L), Double.longBitsToDouble(0x3fe5b75033dfdfc7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 2, 5, 10, "\000", "", "\ud824\udeb0\uda5b\udea8\udb19\udef7\udb77\udd49\uda19\udc08\000\udb11\udea4\ud810\ude27\ud955\udd4f\udbb1\ude3c\ud99b\udcd2\ud5df\000\000\000\000\ud87f\udd3f\ud923\udc84\udbe0\uddac\ud94e\ude42\ud8e2\udd6e\udb22\udeab\uda54\udc01\uda27\udf73\ud85b\udd94\uda8f\ude7d",
        18, 89865, -6467225, -4076681908500534396L, -70737L, true, true, (char) 34018, (char) 38161,
        Double.longBitsToDouble(0x3fe558d9f7a781d2L), Double.longBitsToDouble(0x3fe0bf5471eac7b7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 0, 10, "\udadc\udc50\uda62\ude68\u05e1", "\ud4a1\u3929\u1574\u404a\u8f1c\u39a2\u3585\u2638\u3e8a\u886d\u23fc\u557f\u20aa\u2512\ucfaa\u8cd7\uc3c3\u0597", "\ud8d0\udf6e\udb22\udeab\uda54\udc01\uda56\ude89",
        21, 7741, -1331879971, -1607715518632373975L, 14588L, true, true, (char) 48059, (char) 17148,
        Double.longBitsToDouble(0x3fdc88a62007a4ceL), Double.longBitsToDouble(0x3fe66d9a7faa4a5fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 19, 21, 19, "\ud9d5\udda7\uda46\udcbe\udac2\udf17\uda4f\udc9a\ud9e0\udff8\ud824\udeb0\ud857\udf87\udb19\udf09\udb77\udd49\uda38\udd57\ud9fe\udcc0\udb11\udeff\ud810\ude27\ud955\udd4f\udbb1\ude3c\ud842\udf73\ud837\ude23", "\ucfaa\u8c13\u32c3\ub763\ua8d5", "\udb22\udeab\uda54\udc01\uda56\ude89\ud85b\udd94\ud9a0\udd05\ud95b\udfb2\ud9b5\udc73\u7c4f\ud8f4\udc32\udbb9\udf2f\ud956\udf7e\udb5d\udf51\udab5\ude63\uda8e\udc8d\ud801\udcc6",
        15, 89279, -1201897255, 8751744274055988360L, -54666L, true, true, (char) 817, (char) 12987,
        Double.longBitsToDouble(0x3fb624aa2bba5c18L), Double.longBitsToDouble(0x3fa708aa9835f200L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 5, 5, 10, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\udb19\udef7\udb77\udd49", "\u3585\u0d10\u24f1\uad6f", "\udb96\udccf\ud865\udd67\ud935\udf9f\udb70\udd8c\ud88f\udf61\ud923\udc84\udbe0\uddac",
        40, 80705, 387883343, 1908627330963716886L, 49683L, false, false, (char) 61406, (char) 17553,
        Double.longBitsToDouble(0x3fd704ebf99e44a8L), Double.longBitsToDouble(0x3fde749c7b8f13b2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 17, 5, 10, "\udadc\udc50\udb9d\udc4d\ud8d1\udd61\uda5a\uddcb\ud922\uddf8\ud849\ude31\uda5b\udea8\udb19\udef7\udb77\udd49", "\u3585\ub181\u9496\u6c35", "\udb96\udccf",
        1, 94617, 315569350, -3366368007739495223L, -36796L, true, false, (char) 35384, (char) 20826,
        Double.longBitsToDouble(0x3fe8b0d3e2cb48b1L), Double.longBitsToDouble(0x3fea6d3c2c60f241L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 5, 10, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9c1\udff8\ud824\udeb0\ud9c6\udde8\udb3c\udd43\udb77\udd49", "\u3585\u0d10\u4737\u8899", "\udb96\udccf\ud865\udd67",
        12, 40990, -783793630, -328009844879608237L, 56559L, true, true, (char) 58767, (char) 54673,
        Double.longBitsToDouble(0x3fe65fb58f4da785L), Double.longBitsToDouble(0x3fb83c907a0d84e8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 12, 7, "\udadc\udc50\uda62\ude68\ud8d1\udced\ud8b4\udcd4\ud9e0\udff8\udb14\udf28\uda65\uded5\ud9df\ude14\udb77\udd49", "\u3585\u0d10\u4737\u8899", "\udb96\udccf\ud865\udd67",
        12, 40990, -783793630, -328009844879608237L, 56670L, true, true, (char) 27627, (char) 41407,
        Double.longBitsToDouble(0x3fe65fb58f4da785L), Double.longBitsToDouble(0x3fb83c907a0d84e8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 21, 5, 10, "\udadc\udc70\ud9df\udc16\udb95\ude80\ud992\uddc7\ud9e0\udff8\ud824\udeb0\uda5b\udea8\udb19\udef7\udb77\udd49", "\u3585\u0d10\u4737\uae3a", "\udb96\udccf\ud865\udd67",
        12, 40990, -783793630, -327945321585920429L, -20049L, true, true, (char) 58991, (char) 54673,
        Double.longBitsToDouble(0x3fe65fb58f4da7ccL), Double.longBitsToDouble(0x3fb83c907a0d84e8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 9, 5, 10, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\udb19\udef7\udb77\udd49", "\u3585\u0d10\u4737\u8899", "\udb96\udccf\ud865\udd67",
        12, 40990, -783793630, -328009844879608237L, 56559L, true, true, (char) 58767, (char) 54673,
        Double.longBitsToDouble(0x3fe65fb58f4da785L), Double.longBitsToDouble(0x3fb83c907a0d84e8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 5, 13, "\udac7\udfa2\ud96f\udfd6", "\u6e43", "\udb90\udde3\udb08\ude3a\ud8d3\udedc",
        51, 16768, 1587475963, -389893827312485692L, -53735L, true, true, (char) 16654, (char) 44398,
        Double.longBitsToDouble(0x3fb7dcee270c6a70L), Double.longBitsToDouble(0x3fe37a227c718bc3L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 8, 13, "\udadc\udc50\uda62\ude68\ud9f9\ude98\udafb\udd87\ud9e0\udfb5", "\u7fb6\u2c4a", "\ud8cc\udfdc\ud812\udc78\ud955\udd4f\ud987\udc87",
        40, 99007, 461412536, -23162919809525631L, 57513L, false, true, (char) 18121, (char) 47879,
        Double.longBitsToDouble(0x3fdd263f42670dccL), Double.longBitsToDouble(0x3fe028b8f3231a2cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 17, 24, "\ud9d7\ude7a\uda2c\udfeb\uda70\udea7\ud914\udc2c\ud96e\udf3c\ud8e1\udd4b\u2baf\udbde\udead\udbff\uddbe\uda4c\udf62", "\u80b7\u4658\u63de\u246d\u84e9\u498b\u650a\u99bc\uccf2\uc37c\u32d0\u0464\ub78e\u57e4\u2145\u8e3e\u1fa0\ua31c\u6f2a\013\u8fed\u3efe\uaf35\u9fdc\u01d3\u5b26\u16d6\u6178", "\ud95e\udf27\uda2d\udc7a\u1a6b",
        14, 97393, 1583283854, -1165173925165211327L, -45150L, true, false, (char) 21275, (char) 24763,
        Double.longBitsToDouble(0x3fefc112959d2976L), Double.longBitsToDouble(0x3fac94e34434a470L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 16, 10, "\udb51\udc30", "\u30ee\u09a7\u81a5\u3929\ua3aa\u2c4a\u8f1c\u39a2\ucbff\u5d75\u4298\u88b8\ub46b\u670b\u2b42\u8b6c\ucfaa\u8f02\u32c3\ub763\u7268", "\ud98f\udc04\ud81d\uddc3\udb9e\udfc5\ucce7\udaf7\udd6e\ud8d8\udefe",
        20, 28545, 1394918408, -8855885321572020656L, 34949L, true, true, (char) 24222, (char) 13858,
        Double.longBitsToDouble(0x3fd6c3e675a61ba8L), Double.longBitsToDouble(0x3feaf5b80b8f0c04L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 12, 10, "\udb51\udc30\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udf1c\000\000\ud89a\ude21\udb77\udd49", "\ucbff\u873c\u4737\u8899", "\udbed\ude95\ud923\udfea\ud935\udf9f\u7617\ud88f\udf61",
        27, 563, 12779548, -3681239695748128433L, 96380L, false, true, (char) 3855, (char) 46222,
        Double.longBitsToDouble(0x3fe2552f7a618523L), Double.longBitsToDouble(0x3f816fb200000900L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 16, 10, "\000\000\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\ud89a\udef7\udb77\udd49", "\000\u873c\u4737\u2201", "\udb14\ude88",
        38, 94617, 1371960855, 146028888064L, -100000L, false, false, (char) 52303, (char) 36863,
        Double.longBitsToDouble(0x3fe8e2e689802a56L), Double.longBitsToDouble(0x3fec52bc284ddc41L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 1, 15, "", "\u4df2", "\ud824\udeb0\ud857\udda0\000\udb77\udd49\uda4c\udf62\000\000\000\ud955\udcae\udbb1\ude3c\ud973\ude80\ud9bf\udd0b\udbed\ude95\ud90c\udd05\ud935\udf9f\u7617\000\000\udb66\ude95\ud8c1\ude1b\ud8e2\udd6e\ud8e2\udef0\000\uda74\ude79\ud953\udda8\udbaf\udd6a",
        53, -1000, -1210515456, -91881472L, -42130L, true, false, (char) 49671, (char) 34555,
        Double.longBitsToDouble(0x3fd94c2065c70760L), Double.longBitsToDouble(0x3fd8896432162b24L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 12, 10, "\udb51\udc30\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\ud89a\udef7\udb77\udd49\ud82f\ude73\uda03\udfa7\udb7f\udd05\uda87\udd07\ud955\udd4f\udb30\udf1c\ud973\uddfb\ud9bf\udd0b", "\ucfaa", "\ud923\udc84\udb66\ude95\ud8c3\udf1b\ud8e2\udd6e\ud9e7\ude6d\ud8af\udcf4",
        57, 63083, -599672950, -6489730714854778294L, -8897L, false, true, (char) 38864, (char) 22797,
        Double.longBitsToDouble(0x3fe5addf768f537aL), Double.longBitsToDouble(0x3f77e68746182e00L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 0, 10, "\udadc\udc50\uda62\ude68\udacb\udfd1\uda6d\udc71\u00dc\000\uda27\udd92\udb19\udef7\udb8e\ude15\uda4c\udfa6", "\u7080\u4737\uca48\u6fe1\u7eb1\u6798\u71c7\u7506\u0a6e\u3b39\ub763\u6594\u481a\u11f8\u614d\ub1da\u700e\ub9ab\u44f0\ucda5\u3b8b\ua386\u72fb\ua1e0\u5cc6\u5872\ub875\u3365", "\ud864\udf43",
        42, 20560, 341840463, 1492423514063309730L, -91601L, true, false, (char) 6638, (char) 42160,
        Double.longBitsToDouble(0x3fee300002bed121L), Double.longBitsToDouble(0x3fe5b75033dfdfc7L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 5, 10, "\000", "\u2fff", "\uda5b\udea8\udb19\udef7\udb77\udd49\uda19\udc08\000\udb11\udea4\ud810\ude27",
        41, 55684, -558795078, 10011568767041L, -100000L, false, false, (char) 0, (char) 32273,
        Double.longBitsToDouble(0x3fe29fdb911cb11eL), Double.longBitsToDouble(0x3fbc62f0ca7e6748L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 21, 5, 10, "\000", "", "\ud824\udeb0\uda5b\udea8\udb19\udef7\udb77\udd49\uda19\udc08\000\udb11\udea4\ud810\ude27\ud955\udd4f\udbb1\ude3c\ud99b\udcd2\ud5df\000\000\000\000\ud87f\udd3f\ud923\udc84\udbe0\uddac\ud94e\ude42\ud8e2\udd6e\udb22\udeab\uda54\udc01\uda27\udf73\ud85b\udd94\uda8f\ude7d",
        18, 89865, -6467225, -4076681908500534396L, -70737L, true, true, (char) 34018, (char) 38161,
        Double.longBitsToDouble(0x3fe558d9f7a781d2L), Double.longBitsToDouble(0x3fe0bf5471eac7b7L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 20, 1, "\udadc\udc50\udbfe\udeb8\ud88d\udd7b", "\u63be\u0ca0\u656b\ud547\u8f1c\u39a2\u3585\u2638\u9ac3\u886d\u23fc\u557f\uc270\u3f48\u5c47", "\udb9d\udd9e\udbd0\udc9b\udaee\udcbf",
        -5, 98759, 444386930, -670549167822265643L, 88451L, true, true, (char) 47833, (char) 34837,
        Double.longBitsToDouble(0x3fe9c26d6916ecb9L), Double.longBitsToDouble(0x3fe1fc8be7c81b34L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 20, 1, 15, "\udaf4\udcdd\uda62\ude68\u05e1\ud9a9\udda9\udb72\udfcd\ud8bc\udfd7\uda5b\udea8\uda51\uddb3\ud956\udd22\uda4c\udf62\uda04\udc52\udb11\udeff", "\u886d\u23fc\uc067\ua036\u600e\ucfaa\u8cd7\uc3c3", "\ud94e\ude42\ud8d0\udf6e\udb22\udeab\uda54\udc01\uda56\ude89\ud85b\udd94\uda8f\ude7d\ud92c\udf2f",
        1, 26969, 1157013477, -1388868335185385125L, 41256L, false, true, (char) 45674, (char) 61980,
        Double.longBitsToDouble(0x3fed5252f975656cL), Double.longBitsToDouble(0x3fde8ac1e8345be6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 3, 21, "\udadc\udc50\uda62\ude68\u05e1", "\u1b67\u3929\u1574\u404a\u8f1c", "\uda72\udc38\ud8d2\udec9\udbb1\ude10\ud99b\udc61\udbaf\udf7c\udaa0\udead\udb1b\ude93\ud935\udf9f\udb70\udd8c\ud8b4\udc61\udb9d\udd9e\ud957\udfe8\ud942\udd00\ud8d0\udf6e\udb22\udeab\uda54\udc52\ud8f8\ude0e\ud85b\udd82\uda8f\ude7a\ud92c\udf2f\ud9e9\udc4c\uda34\udcde\ud97f\udfef\ud890\udf39\ud9ec\udef5\ud83c\uddae\udacf\ude51\ud819\uddb5",
        29, 981, 1188798378, 8484135465432527072L, 88319L, true, false, (char) 56743, (char) 7993,
        Double.longBitsToDouble(0x3fd8e40ba0296f74L), Double.longBitsToDouble(0x3feda141480d4a7cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 20, 22, 10, "\udadc\udc74\uda62\ude68\u05e1\ud9b4\udc0c\ud969\udc68\uda69\udf43", "\u404a\u1678\u39a2\u3585\u2638\ube47\u173e\u9a73\ucf2f\u524f", "\udb70\udd8c\ud8b4\udc61\udb9d\udd9e\udbe0\uddac\ud94e\ude42\ud894\udef0\udbca\ude43\ud9f3\ude7b\uda31\udd5b\ud85b\udd94\uda8f\ude7d\uda30\udf31\ud96f\uddf0\ud87e\udced\ud98a\udff5\ud83a\udd20\udae2\uded7",
        6, 58224, -1061395000, -6822987939985801523L, 80612L, false, true, (char) 539, (char) 55132,
        Double.longBitsToDouble(0x3fd969cd8f813160L), Double.longBitsToDouble(0x3fabcdea6c91c850L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 22, 6, 2, "\uda02\udd33\uda62\ude68\u05e1", "\u6ada\u3929\u1574\ub3be\ud139\u39a2\u1004\u4e38\u3e8a", "\udbaf\udf7c\udbb7\ude4a\ud979\udf69\udb42\udf98\uda32\udc1d\ud943\udfd7\udb9d\udce3\udbe0\udd9f\ud8cc\udfb1\ud8d0\udf6e\udb08\udeab\udbdf\udc4f\uda56\ude89",
        21, 30493, -1340614725, -1607715517726404311L, 14588L, true, true, (char) 37605, (char) 17148,
        Double.longBitsToDouble(0x3fe3cc5310249b51L), Double.longBitsToDouble(0x3fe6fbda7faa4a5fL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 24, 24, 19, "\udbc3\udf19\udb9d\udc1a\ud8d1\udd61\ud82b\udce9\ud934\udd87\udae8\udc31\ud9be\udf1b\udb2c\ude18\udbff\udc6e\uda4c\udf8c\uba08\udb11\udeff\udb34\uddf9", "\u860b\u9b2f\u9a98\u96f5\ucf3b\u0311\u24d2\ub763\ua8d5\ud373\u57e4\ub3b7\u8d6e\u513e\u4955\u0103\u65f5\u9f4a", "\ud8ec\udfea\udbca\udd33\ud877\ude2b",
        2, 87302, 1594808763, -3173431053381292692L, 55L, false, true, (char) 32116, (char) 19235,
        Double.longBitsToDouble(0x3fd130df89866f8eL), Double.longBitsToDouble(0x3fe95f39f9dc1e42L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 18, 7, "\udadc\udc50\uda62\ude68\uda10\udecc\uda5a\udd0a\ud9c1\udff8\ud824\udeb0\ud9c6\udde8\udb74\uddb6\ud843\udd0d", "\u3585\u0d10\u5d37\u163b\u246d\u557f\u9a98\u650a\ucfaa\u8cd7\u32c3\ub763", "\ud8e2\udd6e\udb22\udeab\udb49\udffd\ud86b\uddae",
        21, 7806, -1331831712, 5478979968534918085L, -39168L, false, true, (char) 37388, (char) 38229,
        Double.longBitsToDouble(0x3fe378efd5d50b16L), Double.longBitsToDouble(0x3fc97c9d225fb524L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 23, 10, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9c1\udff8\u4064\ud9c6\udd8d\udb3c\udd43\udb77\udd1e", "\u3585\u0d10\u4737\u8899", "\ud9f1\udd65\ud865\uddf1",
        12, 40990, -783793630, -328009844879608237L, 56559L, true, true, (char) 58767, (char) 54673,
        Double.longBitsToDouble(0x3fe65fb58f4da785L), Double.longBitsToDouble(0x3fb83c907a0d84e8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 12, 7, "\000\000\000\ud8b4\udcd4\ud9e0\udff8\udb14\udf28\000\000\ud9e7\udd41", "\u3585\u0d10\u4737\u8899", "\udb96\udccf\ud865\udd67",
        12, 40990, -783793630, -328009844879608237L, -100000L, false, false, (char) 6525, (char) 24274,
        Double.longBitsToDouble(0x3e4d06c000000000L), Double.longBitsToDouble(0x3fd40ffc8cc82bccL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 14, 7, "\udadc\udc50\uda62\ude68\ud958\udd0f\ud8bf\udfa6\ud9e0\udff8\udb14\udf28\uda65\uded5\ud9df\ude14\udb77\udd49\uda4c\udf62\ud89d\udd9b\udb72\udf1a\udb27\udf61\udab9\udd77\udbb1\ude3c\uda69\udead\udb1a\udc2e\udad0\ude0c\ud865\udd67\ud935\udf9f\ud9ce\udc9b\ud88f\udf61\ud923\udc84\udbfa\udeb8\ud829\udd43\ud8e2\udcff\udb22\udeaf\udba2\uddd2\u5c55\ud825\udff8\uda8f\ude7d\ud8e1\udf02\ud813\udee2\udb31\ude64", "\u8aac\uc013\u6099", "\ud8c0\udffe\uda0f\udfc9",
        -1, 37845, 788259481, 7505097458120272330L, -11038L, false, true, (char) 3819, (char) 3543,
        Double.longBitsToDouble(0x3fd073d9db8c0f0cL), Double.longBitsToDouble(0x3fec192c75c24a91L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 12, 9, "\udadc\udc50\uda62\ude68\ud8d1\udced\ud96c\udcd0\ud9e0\udff8A\uda65\udeb6\ud9df\udd2b\udb77\udd49", "\u3585", "\000\ud967\udf12\udbaf\udf7c\udb96\udccf\ud865\udd67\ud935\udf9f\udb70\udd8c\ud88f\udf61\ud923\udc84\udbe0\uddac\uf51c\000\udb22\udeaf",
        5, -1000, -1484447029, -990308903036265376L, 30855L, false, false, (char) 22208, (char) 23163,
        Double.longBitsToDouble(0x3fe299c17322b2a2L), Double.longBitsToDouble(0x3fe6a8e162ed79fbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 12, 7, "\u00b5\000\000\ud8b4\udcd4\ud9e0\udff8\udb14\udf28\ud83b\udd20\000\000", "\u255b", "\udbb1\ude3c\ud967\udfcc\udbaf\udf7c\ud820\udc0f\ud865\udd67\ud935\udf9f\udb70\udd8c\ud88f\udf61\ud923\udc84\udbe0\uddac\ud83a\uddfb\udb03\udc0f\000",
        0, 93299, -1484455936, -990308901694144416L, -68886L, true, false, (char) 24132, (char) 35640,
        Double.longBitsToDouble(0x3fe1c14ba8462d00L), Double.longBitsToDouble(0x3fe895fc5fe1740aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 16, 10, "\000\000\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\ud89a\udef7\udb77\udd49\ud9dc\udf6a\uda04\udc52\000\uda87\udd07\udb21\udef5\udb1b\udec9\000\ud9bf\udc44\ud804\udc00\ud914\uddfa\ud935\udf9f\udac2\udee8\"\000\000\000", "\u4e02", "\udaf7\udd6e\ud9fc\udfe1\ud872\udc01\udb0b\ude56\ud8d5\udffb\u291b\udbd5\udd9d\ud8a9\udd45\ud998\udc6f",
        18, 15879, -874245770, -4333271384733686203L, 17539L, true, false, (char) 60642, (char) 11379,
        Double.longBitsToDouble(0x3fecd9346b27c17cL), Double.longBitsToDouble(0x3fa00a7986506db0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 1, 15, "\u1bf3", "\uacbd\u09a7\u81a5\uaf7e\000\u2c4a\u8f1c\000\000\000\u4696\u8899\ub46b\u670b", "\ud935\udf9c\ud98b\uddad\udb97\uddfd\000",
        48, 74364, -857105295, 3593028077711523840L, 66272L, true, true, (char) 46157, (char) 0,
        Double.longBitsToDouble(0x3d96fb2000000000L), Double.longBitsToDouble(0x3e4497ea18000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 1, 0, "\000\uda26\udd93\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\ud857\udda0\000\udb77\udd49\uda4c\udf62\000\000\000\ud955\udcae\udb9c\ude74\ud973\ude80\ud9bf\udd0b\udbed\ude95\ud90c\udd05\ud935\udf9f\u7617\000\000\udb66\ude95\ud8c1\ude1b\ud8e2\udd6e\ud8e2\udef0\000\uda74\ude79", "N\000\u0a7c\000\u4982\u3df7\u9464\u232e\ua90d\u637c\uabac\ubc8c\ud63e\ub590\uaf18\u4ea6\u3183\u74a2\uaa05\u0dd5\u0ec9\u24a2\u1867\u380f", "\uda93\udd4e\udaa5\ude28\uda7f\udd6e\ud86e\udc7c\ud9c0\udd18\udb22\udf4b\uda96\udc4d\udab6\udd10\ud85f\udca4\udbf0\udc91\ud83d\udfc6\udb26\udc41\ud89d\udfbf",
        9, 18265, -164538695, 1848181409748737218L, 86707L, true, true, (char) 51099, (char) 51811,
        Double.longBitsToDouble(0x3fe26406d6ba247cL), Double.longBitsToDouble(0x3fe24b587c4d2556L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 1, 15, "\udaf4\udccc\uda62\ude68\u05e1", "\ud46b\u3929\ua63e\u404a\u8f1c\u39a2\u3585\u2638\u3e8a\u886d\u23fc\uc067\ua036\u600e", "\ud8b4\udc61\udb9d\udd9e\udbe0\uddac",
        0, 62785, 387883343, 1908627330963716886L, 49683L, true, true, (char) 61406, (char) 47833,
        Double.longBitsToDouble(0x3fef2fe0479c44f6L), Double.longBitsToDouble(0x3fd5becb947f22f8L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 4, 20, 10, "\udaf4\udcdd\ud9ad\ude8c\ud8fb\udf90\udae5\ude2f\ud8d1\ude5c\ud9a2\udcad\ud8b7\uddd6\uda51\uddb3\ud956\udd22\uda4c\udf62\uda04\udc52\udb11\udeff", "\u886d\ud18d\ubfa5\u876e\u600e\u15a8\u8cd7\uc3c3", "\ud94e\ude42\ud8d0\udf6e\udb22\udeab\uda54\udc01\uda56\ude89\ud85b\udd94\uda8f\ude7d\ud92c\udf2f",
        1, 26969, 1157013477, -1388868335185385125L, 41256L, false, true, (char) 45674, (char) 61980,
        Double.longBitsToDouble(0x3fed5252f985f16cL), Double.longBitsToDouble(0x3fde8ac1e8345be6L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 1, 3, "\udb5a\udd37\udb75\uddfb\uda7a\udfef\ud908\ude80\uda61\ude36\udb20\udec5\uda6f\udeb5\udb82\udca2\uda43\ude45\ud813\udc13\udb80\udd62\ud9a5\udfa6", "\u886d\uc43c\ub214\ud261\u600e\u3494\u8c23\uc3c3", "\ud94e\ude88\ud8d0\udf6e\udac3\udc5c\ud90c\udef1\ud8aa\udddc\udabe\ude1c\uda8f\ude7d\udb33\udcc0",
        5, 21360, 234266562, -1388868332505715371L, -91811L, true, false, (char) 59975, (char) 53988,
        Double.longBitsToDouble(0x3fdd7dc8983a47e6L), Double.longBitsToDouble(0x3f77a0f829da7e80L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 20, 1, 15, "\udaf4\udcdd\uda62\ude68\u05e1\ud9a9\udda9\udb72\udfcd\ud8bc\udfd7\uda5b\udea8\uda51\uddb3\ud956\udd22\uda4c\udf62\ud812\udc56\udb11\udeff", "\u886d\u23fc\uc067\ua036\u600e\ucfaa\u8cd7\uc3c3", "\ud94e\ude42\ud8d0\udf6e\udb22\udeab\uda54\udc01\ua4b4\ud86e\ude84\uda8f\ude7f\ud851\udcc1",
        2, 34314, 1157013477, -1388868335185385125L, 41256L, false, true, (char) 45674, (char) 61980,
        Double.longBitsToDouble(0x3fed5252f975656cL), Double.longBitsToDouble(0x3fde8ac1e8345be6L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=void |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 2, 20, 1, 15, "\udaf4\udcdd\uda62\ude68\u05e1\ud9a9\udda9\udb72\udfcd\ud8bc\udfd7\udb2d\udc03\udbb9\uddca\ud956\udd22\uda4c\udf62\uda04\udc52\udb11\udf69", "\u886d\u23fc\uc067\ua036\u600e\ucfaa\u8cd7\uc3c3\u0597\ua8d5\ub757\u11e4\uacb5\u8dd6\u700e\u09ed\u1703\u29c6\ucdfa\uac75\u51a1\uc0c3\uc65f\ud27c\u8461\u8bdf\ubd1e\u5ef2\u5fdf\u660a\u305e\u24c4", "\udb5d\udf6a\udada\udd7c\u8e3e\ud8dc\udd1d\ud948\udd6e\ud9c5\udc02\ud9f1\udf70\ud832\ude96\uda95\udc5f\ud81f\udd04\udb0e\udf56\ud802\ude80\uda27\udf3d\uda8e\udf26\udbfe\ude9e\udb72\udd2b\ud986\udf9c\ud996\udc42\uda6c\udf3a\ud87c\udc67\ud8b2\udf7c\ud8d2\udc65\ud94c\udcb9\ud848\udf30\uda59\udf32\ud825\udcf4",
        4, 87445, 1647819213, -3100477130859159689L, -75801L, true, false, (char) 47814, (char) 64625,
        Double.longBitsToDouble(0x3feb2ff95914c338L), Double.longBitsToDouble(0x3fdd64721aba7e3aL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 1, 15, "\udaf4\udcdd\uda62\ude68\u05e1\ud9a9\udda9\udb72\udfcd\ud8bc\udfd7\uda5b\udea8\uda51\uddb3\ud915\udf99\ud964\udc3a\udb9a\udc22\udb46\ude48", "\u886d\u23fc\u648d\ua036\u600e\ucfaa\u8cd7\uc508", "\ud94e\ude42\ud8d0\udf6e\udb22\udeab\uda54\udc01\uda56\ude89\ud85b\udd94\u1eba\ud92c\udf2f",
        3, 74947, 1143284812, -1388868335185385125L, 41256L, true, true, (char) 45674, (char) 61980,
        Double.longBitsToDouble(0x3fed5252f975656cL), Double.longBitsToDouble(0x3fde8ac1e8345be6L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 23, 10, "\udad8\udda4\ud801\udf56\ud8dd\ude8e\udbfe\udd42\ud9be\ude8c\u4064\ud9fc\udea7\ud8fb\udc23\uda29\udd97", "\ud6c8\u3e10\u4737\u283d", "\ud9cd\udf92\ud971\udd0e",
        12, 40990, -783793630, -328009844879608237L, 45532L, false, true, (char) 58767, (char) 1988,
        Double.longBitsToDouble(0x3fe65fb71f4da785L), Double.longBitsToDouble(0x3fb83c90720d84e8L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 16, 10, "\000\000\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\ud89a\udef7\udb77\udd49\ud9dc\udf6a\uda04\udc52\000\uda87\udd07\000\000\000\ud9bf\udc44\ud804\udc00\ud914\uddfa\ud935\udf9f\000\000\000\000\000", "\u4e02", "\000\000\ud83d\udc9e\udb0b\ude56\ud8d5\udffb\u291b\udbd5\udd9d\ud8a9\udd45\ud998\udc6f",
        18, 82615, -889192448, -4333271384733686203L, 17539L, true, false, (char) 60642, (char) 11379,
        Double.longBitsToDouble(0x3fecd9346b27c17cL), Double.longBitsToDouble(0x3fa00a7986506db0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 6, 11, 10, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda11\udc80\udb19\udef7\udb77\udd49", "\u8327\u0d1f\u4737\u8899", "\udb96\udccf\ud865\udd67",
        12, 92390, -783793630, -328009844879608237L, 56559L, true, true, (char) 58767, (char) 54673,
        Double.longBitsToDouble(0x3fe65fb58f4da785L), Double.longBitsToDouble(0x3fb83c907a0d84e8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 9, 18, "\udadc\udc50\uda62\ude68\udbde\udce9\uda5a\uddcb\ud9c1\udff8\ud824\udeb0\ud9c6\udde8\udb3c\udd43\udb77\udd49", "\u3585\u0d10\u4737\u8899", "\udb96\udccf\ud865\udd67",
        12, 40852, -783793630, -328009844879608237L, 74157L, true, true, (char) 58767, (char) 54673,
        Double.longBitsToDouble(0x3fea896d574da785L), Double.longBitsToDouble(0x3fb83c906f1584e8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 24, 19, 9, "\udadc\udc70\ud9df\udc16\udb95\ude80\uda64\ude81\uda30\ude81\ud940\udd6d\ud832\udfc3\udade\udfab\ud964\udc06\ud917\udf89\ud952\udfdd\udb11\udea4\ud810\ude27\ud955\udd4f\udacf\udc1e\ud88c\udf3b\udb95\udd7c\udb96\udccf\ud865\udd67\ud935\udf9f\udb70\udd8c\ud88f\udf61\ud931\udf33\udbe0\uddac\ud822\udcde\udb40\udc78\udbe1\udf36\uda54\udc01\uda56\ude89\ud923\udd98\ud81f\udf09\ud93b\udd2f\ud985\ude0c\ud971\udde8\uda01\udf78\udbe5\udc5e\ud97e\udf6b\udbed\uddac\udbc3\udc35\udad6\udd47\u129d\ud96a\udc3d\uc657\ud8fd\udfb5\ud852\udeb5\udab4\udc87\ua630\uda5b\udd2b\udba5\uddf5\u52e9\ud9de\udd40\udbcc\udd17\u6970\ud900\ude19\udb0b\udf13\udabc\udcd1\ud88c\ude96\ud875\udd3d\ud86a\ude5c\uda69\uddbd\u507f\ud8bb\udc5a\ud8f4\ude77\ud9e3\udcf4\udb71\udde8\ud895\ude21\udb0d\uddbd\ud81f\ude85\ud9ab\uddad\u81a2\ud816\ude23", "\u29ff\u8caa\ud165\u3362", "\udaaa\udc2e\ud84e\udd24\udaa9\udf6a\ud90b\udfe4\udbfb\udf34\udb4b\udd06\ud81d\udf3f\ud937\udfe7\ud8fc\uddf5\uda65\uddf1\ud8d6\ude30\ud93c\udce4\udb7a\udc01\ud932\udfdb\udb48\udd57",
        47, 64993, 864825688, -7031204405956224517L, 44020L, true, false, (char) 47456, (char) 51855,
        Double.longBitsToDouble(0x3fd7858b4836915aL), Double.longBitsToDouble(0x3fd0a9065827bc68L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 8, 15, 0, "\udb51\udc30\uda62\ude68'\udb23\uddd1\ud9e0\udf1c\000\000\ud89a\ude21{", "\uab5b", "",
        19, 92482, -208546361, -4819341403361222939L, -69769L, false, false, (char) 32273, (char) 33445,
        Double.longBitsToDouble(0x3f9cb1b580001860L), Double.longBitsToDouble(0x3fd4fcce916a63baL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 20, 1, 21, "\udaf4\udccc\uda62\ude68\u05e1", "\u3ec6\u7ca5\u5e79\u404a\u8f1c\u39a2\u3585\u4e19\u3e8a\u8f6c\u23fc\u44c2\ua036\u2564", "\ud8b4\udc61\ud928\ude03\udbe0\uddac",
        0, 62785, 387883343, 1908627330963720726L, 49683L, true, true, (char) 61406, (char) 47833,
        Double.longBitsToDouble(0x3fe343d842e39e76L), Double.longBitsToDouble(0x3fd5bec8e67f22f8L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 7, 5, 10, "\udadc\udc50\uda62\ude68\ud8d1\udced\uda5a\uddcb\ud9e0\udff8\ud824\udeb0\uda5b\udea8\udb19\udef7\udb77\udd49", "\u3585\u0d10\u4737\u4b8f", "\udb96\udccf\ud865\udd67\ud935\udf9f\udb70\udd8c\ud88f\udf61\ud923\udc84\udbe0\uddac",
        -1, 20248, 387853110, 1908627330963716886L, 49683L, false, true, (char) 61633, (char) 40050,
        Double.longBitsToDouble(0x3fe2675fccace5e8L), Double.longBitsToDouble(0x3fdb0e8ae5cb83ecL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=com.google.gson.stream.JsonWriter:@? |this=com.google.gson.stream.JsonWriter:@?\012",
        Z.run(T, 1, 24, 14, 0, "\udadc\udc50\uda62\ude68\ud958\udce8\ud8bf\udfa6\ud9e0\udff8\udb14\udf28\uda65\uded5\ud9df\ude14{\000\udad2\ude88\udb72\udf1a\ud824\udd9f\udab9\udd77\udbb1\ude3c\uda69\udead\uda26\udd93\udad0\ude0c\ud865\udd67\ud935\udf9f\ud9ce\udc9b\ud88f\udf61\ud923\udc84S\ud829\udd43\ud8e2\udcffS\ud947\udd02\u5c55\ud825\udff8\uda8f\ude7d\ud8e1\udf02A", "\ua745\u8aac\uc013\u6099\u2388\u17d9", "\u2983\uda97\udce2\udb43\udd5d\u8481\ud80b\udfaa",
        47, 31410, 275198732, -6057343129867165209L, 50982L, true, true, (char) 20563, (char) 26110,
        Double.longBitsToDouble(0x3fd138db8a194002L), Double.longBitsToDouble(0x3fea00b6ebd26001L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.stream.JsonReader|doPeek||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonWriter|beforeValue||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|jsonValue|java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|nullValue||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|open|int,java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|double|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Number|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|long|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonReader|beginArray||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|beginObject||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|checkLenient||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|close||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|consumeNonExecutePrefix||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|endArray||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|doPeek||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonWriter|beforeValue||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|jsonValue|java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|nullValue||new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|open|int,java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|boolean|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|double|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.Number|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|java.lang.String|new:com.google.gson.stream.JsonWriter:java.io.Writer",
    "M|com.google.gson.stream.JsonWriter|value|long|new:com.google.gson.stream.JsonWriter:java.io.Writer",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
