package com.google.gson.stream;
import org.junit.Test;
import static org.junit.Assert.*;
public class JsonReader_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\uda80\udff1\udbe8\ude5f\udb86\udd1c\ud845\udd2f\uda9d\udc78\udbd9\udf03\ud893\udc73\udaba\udc85\ud96c\udd7d\udb4e\udda2\udbe2\ude6f\ud8e7\udf7c\ud841\udc91\ud9b4\udce8\u7827\u248b\ud8b2\ude0f\u184d", "\ud551\u39fa\u27f3\u8c68\u3b2b\ud5bb\u9292\u3310\ud32d\u970b\ub83c\u4022\u1132\u3502\uab2c\u6ef9\u5f5e\u998b\u8d6f\u7f53\u8970\u7654\u99e9\ub8c9\ucc2e\ud706\u07b6\uaa0e\ucc31\u4f67\u50d1\u42ef\u6bf3\u41be\u8b62\u0f10\u2a25\ub7cb\u7245\ud102", "\udb7e\udc1a\ud90d\udd7a\u585d\uda42\udcbd\ud8c8\udfc6\ud83c\udd57",
        29, -645, 1562119781, -1699994577590834779L, -29484L, false, false, (char) 21020, (char) 34395,
        Double.longBitsToDouble(0x3feb2620db02a500L), Double.longBitsToDouble(0x3fe0b42240906e9bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\uda80\udff1\u4103\udb86\udd1c\ud845\udd2f\uda9d\udc78\udbd9\udf03\ud893\udc73\udaba\udc85\ud96c\udd7d\udb4e\udda2\udbe2\ude6f\ud8e7\udf7c\ud841\udc91\ud9b4\udce8\u7827\u248b\ud8b2\ude0f\u184d", "\ud551\u39fa\u27f3\u8c68\u3b2b\ud5bb\u9292\u3310\ud32d\u970b\ub83c\u4022\u1132\u3502\uab2c\u6ef9\u5f5e\u998b\u8d6f\u7f53\u8970\u7654\u99e9\ub8c9\ucc2e\u1b2c\u5c62\u9018\u7b75\u4f67\u50d1\u42ef\u6bf3\u41be\u8b62\u0f10\u2a25\ub7cb\u7245\ud102", "\udb7e\udc1a\ud90d\udd7a\u585d\uda42\udcbd\ud8c8\udfc6\ud83c\udd57",
        29, -645, 1562119781, -1685125881848419931L, -29484L, false, false, (char) 21020, (char) 34395,
        Double.longBitsToDouble(0x3feb2620db02a500L), Double.longBitsToDouble(0x3fe0e484b8906e9bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 1, "\uda80\udff1\udbe8\ude5f\udb92\ude1c\ud845\udd2f\udb5d\udc78\udbd9\udf03\ud893\udc73\udaba\udc85\ud96c\udd7d\udb4e\udda2\udbe2\ude6f\ud8e7\udf7c\ud841\udc91\ud9b4\udce8\u7827\u248b\ud8b2\ude0f\u184d", "\u3681\u26d5\u27f3\u03d7\u3b2b\ud5bb\u9292\u3310\ud32d\u970b\ub83c\u4022\u1132\u3502\uab2c\u6ef9\u5f5e\u998b\u8d6f\u620d\u8970\u6297\uad58\ub8c9\ucc2e\ud706\u07b6\uc9c3\ucc31\u7f28\u50d1\u42ef\u2e0d\u41e6\u8b62\u0f10\u29a4\ub7cb\u5f21\ud102", "\udb7e\udc1a\ud90d\ude08\u585d\uda42\udcbd\udace\udfc9\ud83c\udd57",
        29, -645, 1562119781, -1699994577590834779L, -70838L, false, false, (char) 43641, (char) 36928,
        Double.longBitsToDouble(0x3fe61bb6cad5fb51L), Double.longBitsToDouble(0x3fed7c9fb9df575bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 1, "\uda80\udff1\udbe8\ude5f\udb2f\udd71\uda08\udf46\uda9d\udc78\udbd9\udf03\ud893\udc73\udaba\udc85\ud96c\udd7d\udb4e\udda2\udbe2\ude6f\ud8e7\udf7c\ud841\udc91\ud9b4\udce8\u7827\u248b\ud8b2\ude0f\u17d6", "\ud551\u39fa\u201a\u8c68\u3b2b\ud5bb\u9292\u3310\ud32d\u970b\u9768\u4022\u1132\u3502\uab2c\u6ef9\u5f5e\u998b\u8d6f\u2696\u5a3c\u7654\u99e9\ub8c9\ucc2e\ud706\u07b6\uaa0e\ucc31\u4f67\u50d1\u42ef\u6bf3\u41be\u8b62\u0f10\u2a25\u4009\u0945\ud102", "\udb7e\udc1a\ud90d\udd7a\u585d",
        30, 58918, 1511418888, 906112937822509619L, -73392L, true, true, (char) 8865, (char) 64189,
        Double.longBitsToDouble(0x3fd7e0aaf919399cL), Double.longBitsToDouble(0x3fa71cef0b0f96b0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 5, "\uda80\udff1\udbe8\ude5f\udb86\udd1c\ud845\udd2f\uda9d\udc78\udbd9\udf03\ud893\udc73\udaba\udc85\ud96c\udd7d\udb4e\udda2\udbe2\ude6f\ud8e7\udf7c\ud841\udc91\ud9b4\udce8\u7827\u248b\ud8b2\ude0f\u184d", "\u0b2c\ubb71\u27f3\u17ee\ub87f\uaa40\u9292\u3310\ud32d\u970b\ub83c\u4022\u7d31\u3502\uab2c\u6ef9\u5f5e\u998b\u8d6f\u7f53\u8970\u7654\u99e9\ub8c9\ucc2e\ud706\u07b6\uaa0e\ucc31\u4f67\u1201\u42ef\u6bf3\u41be\u8b62\u0f10\u2a25\ub7cb\u7245\ud102\u1cff\ucf6a\u7ea5\u6ae1\u027a\uab38\ud19f\u1c25\u4fd2\ua582\u2008\ua4b8\u0a12\ua7a3\u5ade", "\udb40\udd28\ud995\ude06\ud990\udc97",
        10, 37586, 1855688214, -8042926937815466348L, 50642L, true, false, (char) 47667, (char) 20089,
        Double.longBitsToDouble(0x3fd67a4929fe1768L), Double.longBitsToDouble(0x3fe510b6261379b0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.stream.JsonReader|nextInt||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|nextLong||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|beginArray||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|beginObject||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|checkLenient||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|close||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|consumeNonExecutePrefix||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|doPeek||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|endArray||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|endObject||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|fillBuffer|int|new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|getColumnNumber||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|getLineNumber||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|getPath||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|hasNext||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|isLenient||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|nextInt||new:com.google.gson.stream.JsonReader:java.io.Reader",
    "M|com.google.gson.stream.JsonReader|nextLong||new:com.google.gson.stream.JsonReader:java.io.Reader",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
