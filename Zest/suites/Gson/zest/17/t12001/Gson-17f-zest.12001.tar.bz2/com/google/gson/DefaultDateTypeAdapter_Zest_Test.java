package com.google.gson;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultDateTypeAdapter_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\u5f31", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\u47c0\u3a48\u32a5", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb5e\udedc\uda23\udcae\ud9ea\ude5d",
        51, 72408, 364171113, 158682066486111818L, -84087L, true, false, (char) 4989, (char) 64633,
        Double.longBitsToDouble(0x3fb45e1e6e85d440L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 9, 4, "\ue200\u5eb2", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\u411d\u3997\u4068", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\000\000\000\000\000\ud868\udf85\uda28\udfcd\ud8c8\uddfd\ud81c\uddee\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\uda1c\udf6e\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\u5e5d\000\000\ud9e4\udf91\ud9ea\ude5d",
        51, 72408, 53097, 158470961643913216L, -84087L, true, false, (char) 226, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc443000001acacL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\u5f31", "\u1ed2\u3467\u2851\u3fbc\u0bcc\u47c0\u3a48\u32a5\u9b63\u3fcb\u994f\u62db\u2121\u6991\u6121\uc140", "\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd",
        30, 11393, -1976510543, 1180908536723016742L, -71458L, true, false, (char) 35139, (char) 23497,
        Double.longBitsToDouble(0x3fe2daa76f8a7e22L), Double.longBitsToDouble(0x3fe8c8d1c91db823L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 158682066486111818L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 7, 7, "\ud84e\udc0a\u5f31", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\u9fd1\u3a48\u32a5", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\uda78\udf5f\ud85f\udf4b\ud8e8\udcfe\ud816\udf34\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\ud827\uddb1\udb5e\udf7d\uda23\udcae\ud9ea\ude5d",
        51, 72408, 364171113, -8167347744502433581L, -80138L, true, false, (char) 4989, (char) 64633,
        Double.longBitsToDouble(0x3fb45e1e6e85d440L), Double.longBitsToDouble(0x3fc4431d9715acacL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 4, 5, "\ud929\udd17\u193d\ud895\udd08\uda53\ude39\ud98a\udc23\ud954\uddd6\uda09\udc63", "\u47c0\u3a48\u32a5\u9b63\u3fcb\u994f\u62db\u2121\u6991\uc32e\u988f\u774f\u1d8b\u16e8\u0ab0\u40b1\ua950\u51b8\u1264\u2410\u77fa\u7a6e\u3953\u1c22", "\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb9b\ude2b\uda23\udcae\ud9ea\ude5d\udbc7\udfa1\uda6f\udd5a\ud9c4\udcb0\ud8b4\udca1\uda30\ude1b\uda57\udc05\ud805\udc20\udb7d\udfd7",
        35, 27754, -1165477807, 1795887112867488930L, -87265L, false, false, (char) 50309, (char) 8928,
        Double.longBitsToDouble(0x3fe0b950c5d9627bL), Double.longBitsToDouble(0x3fe758f809c99b3aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 5, 7, "\ud84e\udc0a\u5f31", "\u1ed2\u3467\u06d0\u3fcd", "\uda8e\udd74\udb86\udc82\ub9bc",
        -2, 12212, -1298254146, 802753357028373131L, 97266L, false, false, (char) 2111, (char) 6691,
        Double.longBitsToDouble(0x3fe10cca17b13638L), Double.longBitsToDouble(0x3fe07c5184261063L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 9, 7, "\ud84e\udc0a\u5f31\ud977\udfba\ud962\udfba\udb1e\udc49\ud954\uddd6\ud97a\udf1b", "\u47c0\u3a48\u32a5\u9b63\u14ab\u876d\u4382\u2121\u3ebe\u6121\u2741\u3c0d\u47ac\u1699\u0ab0\u40b1\u38ba\u6fb5\u5c04\uce57\u617b\ua999\u3953\u0a0f", "\ud996\ude61\udac0\udc30\ud850\udd6f\udb64\uddee\uda03\udc17\ud9ea\ude5d\ud922\udf54\u7694\ud9c4\udcb0\ud8b4\udca1\udb06\udd67\uda6a\udd4b\ud805\udc20\udb7e\udc0a\udaed\udc85",
        34, 37561, 418137552, 7722306266180548024L, 56089L, true, true, (char) 35962, (char) 45133,
        Double.longBitsToDouble(0x3fde1ba4c79ea1feL), Double.longBitsToDouble(0x3fb8c51090c2acd8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 4, 0, "\ud84e\udc0a\u5f31", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\u47c0\u3a48\u32a5", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud852\udf78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb5e\udedc\uda23\udcae\ud9ea\ude5d",
        51, 72408, 364171113, 158682066486111818L, -84087L, true, false, (char) 4989, (char) 64633,
        Double.longBitsToDouble(0x3fb45e1e6e85d440L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 7, "\ud84e\udc0a\u5f31", "\u1f0d\u3467\u06d0\u3fcd\u0bcc\u47c0\u3a48\u32a5", "\ud84e\udd3c\ud96a\ude2c\ud806\udc95\udb01\udfb5\ud966\udd83\udb6d\udc31\ud9e7\udfe4\udb22\udf5c\ud80f\udee6\ud85b\udf89\uda29\udc1f\ud923\udcfa\ud94a\udd45\ud80a\udda7\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\uda6e\udd15\u4b5b\ud957\udc53\ud855\udf57",
        18, 72408, 364171113, 158682069506897784L, -84087L, true, false, (char) 32926, (char) 13507,
        Double.longBitsToDouble(0x3fb45e226e85d440L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 9, 7, "\udaf9\uddfb\177", "\u7556", "\ud908\udcce\ud87c\ude56\uda82\udc34\uda8e\udd74\ud923\uddb0\ub9bc\uff34\ud84e\udd3c",
        7, 54581, -822037877, 7437112929903120677L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd0000006fb0d4cL), Double.longBitsToDouble(0x3fe10cca17b13638L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 4, 7, "\ud84e\udc0a\udbbe\uddc8\udbb6\uddd9", "\u6b45\ud1c9", "\uda82\udc34\udaa1\udd74",
        5, 2172, 353281076, -9198051964699986242L, 11243L, true, false, (char) 30810, (char) 39637,
        Double.longBitsToDouble(0x3fe85c8a4cdaaa83L), Double.longBitsToDouble(0x3fee415500924cb3L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud87c\udd06\u5f31", "\ud13e\u3467\u804a\u0bbb\u1175\u47c0\u94a7\u32e9", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda6b\udd57\ud953\uddb1\udbfb\udd52\uda92\udcbf\uda79\ude4f\ud982\udc52\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb5e\udedc\uda23\udcae\ud9ea\ude5d",
        -4, 90631, 364171113, -5757803301369323388L, -84087L, true, false, (char) 4989, (char) 64633,
        Double.longBitsToDouble(0x3fb46d276e85d440L), Double.longBitsToDouble(0x3fc4431d8cf3915cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 3, 2, "\ud975\ude7c\u5f31\ud977\udfba", "\u6c4f\u06d0", "\uda82\udc34\uda8e\udd74\ud923\uddb0\ub9bc\ud898\udf41\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\uf68b\ud9ab\udd77\udabf\udef7\ud9ff\udc8a\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\udab9\udcaf\u9deb\ud98a\udfbb\ud85a\udd78\uda90\udeb8",
        49, 44462, 1424846252, 9088913151176038282L, 32835L, true, false, (char) 59565, (char) 58242,
        Double.longBitsToDouble(0x3feb4917388015b4L), Double.longBitsToDouble(0x3fe250119836ad21L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 9, 5, "\ud829\uddb1", "\uca44\u65d3\u3467\u06d0\uab0f\u1289\u8c2f\u3a48\u32a5\u9b63\u3fcb\u51e8", "\udb01\udfb5\ud829\udce3\ud89e\ude83\udbfd\udc74\udb05\udcfd\ud80f\udee6\ud869\udc4d\udbfd\udfcd\ud8c8\ude39\ud9b6\udd25",
        38, 58457, 1885564431, -4459450057589569160L, -96577L, false, false, (char) 52440, (char) 25598,
        Double.longBitsToDouble(0x3fec53f117191a39L), Double.longBitsToDouble(0x3fd1db82353e791aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 9, 7, "\udbe4\udefb\u5f31", "\u1ed2\ubfaf\u286d\u3fbc\u0bcc\u47c0\u3a48\u32a5\u9b63\u3fcb\u994f\u62db\u2121\u6991\u6121\uc140", "\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd",
        38, 11378, -1976510543, 1180908536723016742L, -71458L, true, false, (char) 35139, (char) 23497,
        Double.longBitsToDouble(0x3fe2daa76a727e22L), Double.longBitsToDouble(0x3fe8cf4ca11db823L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 3, "\ud84e\udc0a\u5f31\udb51\ude26\ud971\udc7d\udb1e\udc49\ud954\uddd6\ud87d\ude90\ud908\udcbd\ud87c\ude56", "\u32a5", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\uda76\udc50\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\uda1f\udd32\ud85f\udd22\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb5e\udedc\udb71\udfd5\ud930\udfd1",
        10, 96110, -1102326607, 7537310204772437117L, 96216L, false, false, (char) 38415, (char) 13779,
        Double.longBitsToDouble(0x3fec4516078c4bd5L), Double.longBitsToDouble(0x3fa4a13ba546cb50L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 3, 3, "\ud84e\udc28", "\u44ef\u882e\uc124\u2851\u3fbc\u0bcc\u47c0\u3a48\u32a5\u9b63\u3fcb\u988b", "\udb29\udf25\udb3f\udf91\udb96\ude80\ud9bc\ude35\udb22\udf5c\udba3\udfa6\ud886\udf08\uda28\udfcd\ud8c8\uddfd",
        30, 46051, -1976510543, -3491484044114654170L, -71458L, true, false, (char) 35139, (char) 23497,
        Double.longBitsToDouble(0x3fe2daa76f8a7e22L), Double.longBitsToDouble(0x3fe0c8d1c91db8a6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!com.google.gson.JsonSyntaxException\012",
        Z.run(T, 1, 1, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\u5c3a\u9ad6\u06d0\u3fcd\u0bcc\u1cc9\ub208\u32a5", "\udbb8\udce6\ud9dd\udd7d\ud9f9\udd07\ud993\ude50\ud805\udcba\udb77\udf1d\ud8cc\ude5d\udb22\udee9\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\ud9ba\udf93\ud8b8\udd72\ud817\udcff\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 153334041928619766L, -84124L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 1, 7, 4, 7, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\u764a\ua59b\u32a5", "\ud904\ude40\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\ud9e7\ude68\ud9ea\ude5d",
        52, 72408, 364171113, 158682066486111818L, -84087L, true, false, (char) 63996, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1aebcL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 3, 8, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\ud90f\udeff\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud806\udc43\udba4\uded4\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\udbcb\udf43\ud810\udcf6\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 158682066486111818L, 34695L, false, false, (char) 38852, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:DefaultDateTypeAdapter(SimpleDateFormat) |this=com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 1, 2, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\u0099\u5a08\u0650\u3fcd\u0bcc\uc6db\u3a48\u4068", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd}\000\000\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 158682066486111818L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d94000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud930\ude2d\ud96a\ude2c\uda0d\udd5c\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\udab1\udc69\uda0a\udcbd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 8374092211740028490L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udb1a\udfa2\uda92\udcbf\udbc3\ude62\ud889\udef4\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udb1e\udf8d\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 167766231554797130L, -43578L, false, false, (char) 28762, (char) 31019,
        Double.longBitsToDouble(0x3fe628c764cd8bedL), Double.longBitsToDouble(0x3fbbc1707cbf4080L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 1, 8, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u7e2c\uab0b", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, -1112223895, 171252383494516298L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 9, 7, "\ud84d\udf35\udbaa\udec6\ud95a\ude48\ud962\udfba", "\u06d0\u3fcd\u0bcc\ud18e\u3a48\u32a5\u9b63\u3fcb\u994d\ub24a\u05e6", "\udb77\udfc5\udabf\udef7\udb22\udf5c\udacc\udc04\ud868\udfcd\ud972\udfd2\ud8c8\uddfd\ud9b0\udde2\ud832\udeca\uda92\udcbf\udb84\ude03\udafd\ude02\uda21\udc7c\ud969\udccb\ud849\udd71\udbab\udd83\uda0e\uddff\ud30b\uda03\ude24\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d\ud8ee\ude1c\uda24\ude76\ud9c4\udcb0\ud8b4\udca1\udb06\udd67\uda56\udf4b\ud805\udc20\udb7d\udfd7\ud969\ude8a\ud825\udf54\udb1d\udcc1\uda79\udf43\udb2c\udef2\udae2\udcf9\uda45\ude7a\udb13\udeac\udbf2\udc96",
        16, 24394, 516158583, 4873050182668123903L, 28094L, true, true, (char) 9551, (char) 62198,
        Double.longBitsToDouble(0x3fe0f1ef04916850L), Double.longBitsToDouble(0x3fd573c3e66b0ad8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 9, 7, "\udbca\udcd1\ud8ca\udebf\uda02\udc72\ud962\udfba\udb1e\udc49\ud954\uddd6\ud97a\udf1b\ud908\udcce\ud87c\ude56\ud85d\udf03\uda8e\udd74\ud923\uddb0\ub9bc\ud898\udf41", "\u2121", "\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud94f\udfab\udb7b\udfa4\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d\ud8ee\ude1c\uda24\ude76\ud9c4\udcb0\ud8b4\udca1\udb06\udd67\uda56\udf4b\ud805\udc20\udb7d\udfd7\ud969\ude8a\ud825\udf54\udb1d\udcc1\u0748\udb2c\udef2\udb84\udf3a\uda1e\ude4c\udb25\udcff\udbd6\udc96",
        11, 70542, -1367239934, 6874087922119714335L, 59414L, true, true, (char) 11216, (char) 51270,
        Double.longBitsToDouble(0x3fe487752291e6baL), Double.longBitsToDouble(0x3fd596bfb38dd674L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 2, 2, "\ud9fb\ude8f\udbaa\udec6\ud95a\ude48\ud962\udfba\ud86d\uded1\uda84\udced\udbb7\udf2b\udb3a\udee8\udba6\udeac\ud85d\udf03\uda8e\udd74\ud8ef\ude56\ub944\ud898\udf41\ud84c\udc78\ud96a\ude2c\ud8ce\udeb1\udaf7\udf9f\ud210\udb77\udf1d\ud85b\udd64\udb22\udf5c\udb02\udd3a\udb92\udc6e", "\u51b8\u1264\u2410\u617b\ua999\u3953\ub5d3\u6edf\u1679\u8019\u1937\u3bd0\u334f\u099c\ubd79", "\udb1c\udf74\ud8b4\udca1",
        5, 44366, 650625495, -1161111184047397990L, -64530L, true, true, (char) 53334, (char) 64717,
        Double.longBitsToDouble(0x3fe0a9fe7f1df358L), Double.longBitsToDouble(0x3fa410d8ba4633c0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!com.google.gson.JsonSyntaxException\012",
        Z.run(T, 1, 1, 9, 7, "\u2eaa\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud948\udefb\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\udad1\udd48\ud864\udc38\uda28\udfcd\udbc1\udc23\uda9e\ude39\u315b\uda92\udcbf\ud8cb\udf06\ud981\udfa5\udafd\udcc8\uda84\ude6e\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 158681662759185994L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 4, 5, "\ud929\udd17\u193d\ud895\udd08\uda53\ude39\ud98a\udc23\ud954\uddd6\uda09\udc63", "\u46c0\u3a48\u32a5\u9b63\u3fcb\u994f\u62db\u2121\u6991\uc32e\u988f\u774f\u1d8b\u16e8\u0ab0\u40b1\ua950\u51b8\u1264\u2410\u77fa\u7a6e\u3953\u1c22", "\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb9b\ude2b\uda23\udcae\ud9ea\ude5d\udbc7\udfa1\uda6f\udd5a\ud9c4\udcb0\ud8b4\udca1\uda30\ude1b\uda57\udc05\ud805\udc20\udb7d\udfd7",
        35, 27754, -1165477807, 1795887112867488930L, -87265L, false, false, (char) 50309, (char) 8928,
        Double.longBitsToDouble(0x3fe0b950c5d9627bL), Double.longBitsToDouble(0x3fe758f809c9fff7L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 7, "\ud84d\udfc6", "\u93cb\u1f0d\u3467\u06d0\u697f\u0c55\u47c0\u3a48\u32a5\u9b63\u3fcb\u994f", "\udb01\udfb5\ud966\udd83\udb6d\udc31\ud807\udde6\udb22\udf5c\ud80f\udee6\uda0a\udda0\udab9\uddb7\ud923\udc8d\ud94a\udd45",
        16, 58457, 274951695, -5505074238590900608L, -96577L, false, false, (char) 52440, (char) 41800,
        Double.longBitsToDouble(0x3fec53f1101de339L), Double.longBitsToDouble(0x3fc67047bae57780L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 1, 8, 8, 7, "\udaac\udceb\177\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u08e8\u408f\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\ub198\u92ca\uc0ec\u52a8\u32db\u6e52\u3125\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 48128, 1026733728, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud87c\udd06\u5f31", "\ud13e\u3467\u804a\u0bbb\u1175\u47c0\u94a7\u32e9", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda6b\udd57\ud953\uddb1\udbfb\udd52\uda92\udcbf\uda79\ude4f\ud982\udc52\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\uda6e\udcad\udb5e\udedc\uda23\udcae\ud9ea\ude5d",
        -4, 90631, 364171113, -5757803576247230332L, -84087L, true, false, (char) 4989, (char) 64633,
        Double.longBitsToDouble(0x3fb46d276e85d440L), Double.longBitsToDouble(0x3fc4431d8cf3915cL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud87c\udd06\u5f31", "\ud13e\u3467\u804a\u0bbb\u1175\u47c0\u94a7\u32e9", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda6b\udd57\ud953\uddb1\udbfb\udd52\uda92\udcbf\uda79\ude4f\ud982\udc52\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb5e\udedc\uda23\udcae\ud9ea\ude5d",
        -4, 90631, 53097, 0L, -84087L, true, false, (char) 4989, (char) 64633,
        Double.longBitsToDouble(0x3fb46d276e85d440L), Double.longBitsToDouble(0x3fc4431d8cf3915cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 9, 5, "\u7f6c", "\uc929\u75d3\u0b9c\ub699\ubb8f\u25f8\u8bf0\u4855\uccbb\u47f9\u3fcb\u5904", "\udb01\udfb5\ud829\udce3\ud9af\udc0b\ud8db\ude3d\udb14\udecc\ud881\ude1f\ud88c\udcc0\ud8e3\ude69",
        30, 75493, -329803417, -8489048140498637297L, -53191L, false, false, (char) 36976, (char) 11569,
        Double.longBitsToDouble(0x3fa8b396634884d0L), Double.longBitsToDouble(0x3fe8f3f117d60b6eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 7, "\udbe4\udefb\u5f31", "\u4ed0\u5bbd\u097c\ub483\u340b\ud03f\uc45f\u326a\u9b63\u3fcb\u994f\u62db\u2121\u6991\u6121\uc140", "\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd",
        38, 11378, -1976510543, 1180908536723016742L, -71458L, true, false, (char) 35139, (char) 23497,
        Double.longBitsToDouble(0x3fe2daa76a727e22L), Double.longBitsToDouble(0x3fe8cf4ca764bc23L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 7, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u0750\u3fcd\u0bcc\u764a\ua59b\u32a5", "\udab8\udc39\ud96a\ude52\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\ud9e7\ude68\ud9ea\ude5d",
        52, 72408, 364171113, 158682066486111818L, -43578L, false, false, (char) 28762, (char) 31019,
        Double.longBitsToDouble(0x3fc4431d96e1aebcL), Double.longBitsToDouble(0x3fe8b62af832c51eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 9, 7, "\udb53\udcba\udbaa\ude98", "\u64d1\u3467\u06d0\u3fcd\u0bcc\u764a\ua59b\u32a5", "\ud904\ude40\ud96a\ude2c\ud109\ud883\udce1\uffd2\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\udab7\udf3d\ud9bd\udecb\ud9e7\ude68\ud9ea\ude5d",
        52, 72408, 364171113, 158682069589896778L, -46466L, true, true, (char) 58962, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1aebcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 7, 8, 7, "\ud9c5\udd76\ud86b\udf05\ud95a\udddd\ud962\udfba\udb1e\udc49\ud812\uddfa\uf46b", "\u15e8\u54d9\u2b06\u7d9b\u974b\u160a\u55a5\u0def\u5e21\u6121\u55fe\u6eca\u30fb\u16e8\u0ab0\u40b1\u943d\u4c56\u499e\u2410\u617b\uc6a3\u3953\u53dd", "\ud8e0\udd42\udb78\udc22\ud83d\udc1f\uda77\udfed\ud9fe\udc88\ud9ea\ude5d\ud8ee\ude1c\uda24\ude76\ud993\udeb0\ud8b4\udca1\udb06\udd67\uda56\udfe9\u1f43\ud9b1\udf21",
        38, 30383, 871053049, 848470924950153149L, 97271L, true, true, (char) 5784, (char) 17276,
        Double.longBitsToDouble(0x3fd3486d05e5e2c6L), Double.longBitsToDouble(0x3fe9f8eb0eaff199L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 8, "\udb71\udfdc\udbaa\udec6", "\u1e58\u3467\ub7fe\u32bd\u667f\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\ud90f\udeff\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda3f\udff7\udb3f\udec9\ud97b\udd52\uda92\udcbf\ud806\udc43\udba4\uded4\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\udbcb\udf43\ud810\udcf6\ud83d\udc1f\ud99b\udeaa\uda93\udfc1\ud9ea\ude5d",
        52, 72408, 364171113, 2765894615257054357L, 27449L, false, false, (char) 28310, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369f3a066b6L), Double.longBitsToDouble(0x3fc4430dd6e1acacL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:DefaultDateTypeAdapter(SimpleDateFormat) |this=com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 7, "\ud84e\udc0a\udbaa\udec6", "\u0099\u5a08\u0650\u3fcd\u0bcc\uc6db\u3a48\u4068", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udf2d\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\u9d6c}\000\000\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud8f2\udfca\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 158682066485676874L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d94000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud930\ude2d\ud96a\ude2c\uda0d\udd5c\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\ud921\udd5a\ud80f\udee4\udab1\udc69\uda0a\udcbd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\udae5\udd22\udbe1\uddd1\ud8ed\ude50\ud8d2\udea7\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 2122269096196211763L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3feaa49f65ba1d5fL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\ubf5d\u6156\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud930\ude2d\ud96a\ude2c\uda0d\udd5c\uda2c\uddc9\udbd2\udcfb\ud9b5\uddc3\udabf\udef7\udb22\udf5c\ud80f\udee6\udaad\udd2f\uda0a\udcbd\ud843\udf5a\udae2\udd4c\ud84b\ude9b\ud896\udca0\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udb7e\udf70\ud83d\udc5e\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 95504, 364171113, 2609484688252808778L, 45852L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=java.lang.String:DefaultDateTypeAdapter(SimpleDateFormat) |this=com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 7, 2, 2, "\u2eaa\udbaa\udec6", "\u8c36\ub901\u0773\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud948\udefb\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\ud922\ude5c\udaf6\udea8\ud864\udc38\uda28\udfcd\ud8e8\ude21\uda9e\ude39\u315b\uda92\udcbf\ud8d2\udc09\ud89f\udd67\ud9a4\udebc\uda84\ude72\ud849\udd27\ud967\udfbf\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 8867798917163593290L, -84087L, true, false, (char) 4989, (char) 30489,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fe348c03db86be8L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:DefaultDateTypeAdapter(SimpleDateFormat) |this=com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=java.lang.String:DefaultDateTypeAdapter(SimpleDateFormat) |this=com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 2, 2, 4, "\ud9fa\udcb3\udb0a\udd37", "\u1ed2\u3467\u2dd0\u3fcd\u0bcc\uc6db\u3a48\ubb51", "\ud84e\udd3a\ud9db\udd20\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udb1d\ude9e\udbcc\udc7c\ud9b8\udc30\ud864\udc38\ud9ca\udc2d\ud8f9\udf91\uda9e\ude39\u315b\uda92\udcbf\udb84\ude03\udbe7\udd66\ud807\udccd\uda84\ude6e\ud849\udd27\udb5b\udfb9\ud8e0\udead\udb54\udebb\udbcb\ude15\udb5c\udd2b\uda12\udd3a\ud9ea\ude5d",
        52, 72408, 1672793961, -1104369609605557576L, 36794L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 9, 7, "\u2eaa\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud948\udefb\ud80f\udc95\ub28b\ud829\udc15\udb77\udf1d\udabf\udef7\udb22\udf5c\udad1\udd48\ud864\udc38\uda28\udfcd\udbc1\udc23\uda9e\ude39\u315b\uda92\udcbf\ud8cb\udf06\ud981\udfa5\udafd\udcc8\uda84\ude6e\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\ud83d\udc1f\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        40, -1000, 0, 144115186685521482L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 8, 8, 7, "\udaac\udceb\177\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud911\udd9c\uda69\udec8\ud88a\ude99\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u08e8\u408f\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\ub198\u92ca\uc0ec\u52a8\u32db\u6e52\u3125\ub0fd\u9c66\u8258\ub1c4\u86b5\u62a2", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\ud830\ude47\ud9f3\udf40\ud834\udd07",
        38, 48128, 1026733728, 2612010674713972346L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 1, 8, 8, 5, "\000\000\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\u411d\ud84e\ude07\ud923\uddb0\ud90b\udf79\ud9cc\udc0c\ud84e\udd3c\ud964\udda8\udbae\ude6b\000", "\000\000\u84a2\000\ub1b4\ua92f\000\000\000\u4380\ud196\ua836\u2c7b\ub0da\u415c\uac74\u2a96\ub198\u92ca\uc0ec\u52a8\u32db\u6e52\u00bb\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\000\000\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udcbc",
        38, 48128, 1026733728, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074800L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud923\udc0c\u5f31", "\u3af6\u78ca\u112e\u0bbb\u4eb6\u6ade\u7a61\u32e9", "\ud84e\udd3c\ud8ce\ude7e\ud927\udd26\udac4\udcd3\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda6b\udd57\udaa4\udf59\ud868\udd1e\uda92\udcbf\uda79\ude4f\ud982\udc52\ud856\udd76\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud98d\udcbb\ud897\ude64\uda8d\ude70\udb5e\udedc\uda23\udcae\ud9ea\ude5d",
        -4, 90588, 53097, 620167168L, -80247L, true, false, (char) 3144, (char) 64487,
        Double.longBitsToDouble(0x3fb46d277c395338L), Double.longBitsToDouble(0x3fc4431d8cf3915cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 9, 7, "\udb53\udcba\udbaa\ude98", "\u64d1\u3467\ub56b\u6468\ubd2e\u764a\ua59b\u32a5", "\ud904\ude40\ud96a\ude2c\ud91f\ude3d\ud883\udce1\uffd2\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8d0\udead\ud30b\udab7\udf3d\ud9bd\udecb\ud9e7\ude68\ud9ea\ude5d",
        52, 83504, 1709648885, 4469352491873545802L, -46380L, true, true, (char) 58962, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1aebcL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 5, 7, "\udb53\udcba\udbaa\ude98", "\u64d1\u9b6c\u4dcf\u64e4\u31af\u764a\ua59b\u32a5", "\ud91a\udfd4\ud96a\ude2c\uda46\uded1\ud883\udce1\uffd2\ud826\ude21\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\udb7f\uddf0\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\udab7\udf3d\ud9bd\udecb\ud9e7\ude68\ud9ea\ude5d",
        52, 72408, 364171113, 158682069589896778L, -46466L, true, true, (char) 58962, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369fba066b6L), Double.longBitsToDouble(0x3fc4431d96e1aebcL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 6, 0, "\ud9c5\udd76\ud86b\udf05\ud95a\udddd\ud962\udfba\udb1e\udc49\ud812\uddfa\uf417\ud908\udcce\udb46\udd3b\ud9f1\udf15\udb4f\udfe4\ud9aa\udcf4\ud8ca\ude03", "\u8262\u2eff", "\uda6d\ude19\udb4b\udfef\udb37\udc79\ud80f\udebf\udaf1\uddd2\ud939\udf9b\uda41\ude9d\ud90a\udd4d\u248d\uda92\udcbf\ud8cb\udf06\udac9\udea8\ud85a\udd78\ud8ca\udeb5\uda16\udc1f\ud8e8\udd35\uda94\udfef\uc820\udab7\udc1c\uda77\udfed\ud9fe\udc88\udbaa\ude5d\ud8ee\ude1c\uda24\ude76",
        24, 80048, -1390334390, -6010422227614925425L, -85238L, true, true, (char) 64237, (char) 60532,
        Double.longBitsToDouble(0x3fede85e4db893e6L), Double.longBitsToDouble(0x3febf048da38f45fL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!com.google.gson.JsonSyntaxException\012",
        Z.run(T, 2, 4, 1, 6, "\udb71\udfdc\udbaa\udec6", "\u1e58\u3467\ub7fe\u32bd\u667f\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\ud90f\udeff\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda3f\udff7\udb3f\udec9\ud97b\udd52\uda92\udcbf\ud806\udc43\udbae\udcb9\ud9ef\udd5d\ud9d1\udf30\uda2b\udc9e\udb5b\udfb9\udbcb\udf43\ud810\udcf6\ud83d\udc1f\ud99b\udeaa\udbdb\udec4\ud9ea\ude5d",
        52, 72408, 364171113, 2765894615257054357L, 27449L, false, false, (char) 28310, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369f3a066b6L), Double.longBitsToDouble(0x3fc4430dd6e1acacL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 8, "\udb71\udfdc\udbaa\udec6\ud95a\ude48\uda1b\ude76\ud9f7\udc3c\ud96b\udea0\ud963\udfb0\udbc2\ude3d\ud880\udd7d\udbbe\udeed\uda4b\udeb2\uda8a\udece\ud808\udf41\ud898\udf41\ud84e\udce6\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3", "\u1d9e\u16e8\u0ad9\u1ee8", "\udaf9\ude12\udb21\udc49\ud806\udc55\udbb1\ude63\ud85a\udd78\uda90\udeb8\ud870\udc1a\udb04\udde3\uda66\udd93\ud8e6\udc21\ud853\udde3\ud95b\udf2e\uda67\udf78\udb7f\udf75",
        24, 72408, -1087975575, 7979612788040534140L, -82424L, true, false, (char) 17439, (char) 54052,
        Double.longBitsToDouble(0x3fccdb5a250c6598L), Double.longBitsToDouble(0x3fc45d6ca72090acL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 3, 8, "\udb71\udfdc\udbaa\udec6", "\u1e58\u3467\ub7fe\u32bd\u667f\uc6db\u4c5b\u32a9", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\udaff\udeaf\ud860\udc1e\udb26\udf44\udbb7\udd86\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda3f\udff7\udb3f\udec9\uda74\udf6f\ud8cd\udf35\udb15\udc70\udb8e\ude00\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\udbcb\udf43\ud810\udcf6\ud83d\udc1f\ud99b\udeaa\udbc6\udd04\ud9ea\ude40",
        52, 72408, 1006441065, 2765951527868693653L, 27449L, false, false, (char) 21477, (char) 23751,
        Double.longBitsToDouble(0x3fdbb369f5a066b6L), Double.longBitsToDouble(0x3fccb78b16e3daccL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 8, "\udb71\udfdc", "\u5a8f\u1e58\u3467\ub7fe\u32bd\ubcbd\ud67b\u39b6\u32a5\u9b63\u3fcb\u994d\u62db\u2121\u6991\u6121\uc140\ub2de\u1d9e\u16e8\u0ab0", "\udb3f\udec9\ud9c7\udd58\uda92\udcbf\ud806\udc43\udba4\uded4\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\udbcb\udf43\udb30\udf1d\udaab\udce2\uda16\udf0b\ud825\udd01\ud9ea\ude5d",
        52, 72408, 352440169, 2765894616532122773L, 61885L, false, false, (char) 44475, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369f3a066b6L), Double.longBitsToDouble(0x3fc4430dd6e1acacL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 8, "\ub7fb\udbc9\udd64", "\u1e58\u3467\ub7fe\u32bd\u667f\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\ud90f\udeff\udb04\udc94\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda3f\udff7\udb3f\udec9\ud97b\udd52\uda92\udcbf\ud806\udc43\udba4\uded4\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\udbcb\udf43\ud810\udcf6\ud83d\udc1f\ud99b\udeaa\uda93\udfc1\ud9ea\ude5d",
        52, 72408, 364171113, 2241788211433908010L, 27449L, false, false, (char) 28310, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369f3a066b6L), Double.longBitsToDouble(0x3fc4430dd6e1acacL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=!com.google.gson.JsonSyntaxException\012",
        Z.run(T, 2, 8, 1, 3, "\udb71\udfdc\udbaa\udec6", "\u114a\u33e7\ub7fe\u32bd\u3280\u64e6\u3a48\u32a5", "\ud832\udf1e\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\ud90f\udeff\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8f8\udc53\ud870\udc68\uda96\udfa8\uda93\udd1b\udb84\ude03\udba4\uded4\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\udbcb\udf43\ud810\udcf6\ud83d\udc1f\uda9c\udd09\ud87c\udd68\ud9ea\ude5d",
        52, 72408, 364171113, 2765894615257054357L, 27449L, false, false, (char) 28310, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369f3a066b6L), Double.longBitsToDouble(0x3fc4430dd6e1acacL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 8, "\udb3b\udcfd\udbaa\udec6", "\u1e58\u00b4\ub7fe\u32bd\u667f\uc6db\u3a48\u32a5", "\ud84e\udd3a\ud96a\ude2c\u00ed\000\udba5\ude11\udb77\udf1d\ud90f\udeff\ue186\ud80f\ude83\ud869\udc4d\uda28\udfcd\uda3f\udff7\udb3f\udec9\ud97b\udd52\uda92\udcbf\ud806\udc43\udba4\uded4\ud85a\udd78\uda90\udeb8\ud849\udd27\udb39\uddb9\udbcb\udf43\ud810\udcf6\ud83d\udc1f\ud99b\udeaa\u00d7\000",
        -4, 72408, 53097, -1936720747L, 27449L, false, false, (char) 28310, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369f2000000L), Double.longBitsToDouble(0x3fc4430dc00000acL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 5, "\000\uda52\udc08\000\udbea\uddde\ud990\udd8a\ud8a4\udf26\ud97a\udf1b\udae3\udc58\udaf6\udd9d\udb10\uddb4\ud84e\ude07\ud923\uddb0\ud90b\udf79\ud9cc\udc0c\ud84e\udd3c\ud964\udda8\udbae\ude6b\ud9cf\uddc6", "\000\000\u9c49\000\ub1b4\ua92f\u25aa\007\000\u0fbe\ucbe7\u46e3\u2081\ub0da\u415c\uac74\u2a96\u658d\ucef1\uc05f\u52a8\u32db\u6e04\u00bb\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c2d", "\ud8ba\udf92\udba2\udcbb\u4668\ud909\udd04\uda38\udefc\uda55\udfe1\udb20\udeac\udb26\udc99\ud80c\udf76\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\udea8\ud8e3\udc5e\ud9f3\udfff\ud834\udcbc",
        43, 48128, 1026733728, 2612010676307807866L, 11978L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074800L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 7, "\000\udbaa\ude98", "\ubb55\000\000\000\ua662\u764a\ua59b\u32a5", "\ud904\ude40\ud96a\ude2c\ud91f\ude3d\000\uefdd\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8d0\udead\ud30b\udab7\udf3d\ud9bd\udecb\ud9e7\ude68\ud9ea\ude5d",
        52, 83504, 1709648885, 4469352490162269770L, -46380L, true, true, (char) 184, (char) 0,
        Double.longBitsToDouble(0x3fdbb0000ba066b6L), Double.longBitsToDouble(0x3fc4431d96e1aebcL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 5, 7, "\ud80b\udc65\udbaa\ude98", "\u64d1\u9b6c\u4dcf\u79ed\u4329\u764a\ua59b\u32a5", "\ud91a\udfd4\ud96a\ude2c\uda46\uded1\ud883\udce1\uffd2\ud826\ude21\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\ud96a\udf0d\ud8d0\udf9b\u1d6f\udbe5\udc16\udb7f\uddf0\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\ud30b\udab7\udf3d\ud9bd\udecb\ud9e7\ude68\uda65\ude5b",
        52, 72408, -1263218839, 173874111945190986L, -46466L, true, true, (char) 58962, (char) 12966,
        Double.longBitsToDouble(0x3fdbb3655ba066b6L), Double.longBitsToDouble(0x3fc4431d96e1aebcL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 5, 7, "\udb53\udcba\udbaa\ude98", "\u33d1\u9b6c\u4dcf\u50e4\u31af\u764a\ua59b\u32a5", "\ud91a\udfd4\ud96a\ude2c\uda46\uded1\ud883\udce1\uffd2\udb4e\udef6\ud969\udfab\udbde\udf7a\ud80f\udee6\ud869\udc4d\udbe1\udcc7\ud8c8\uddfd\u1d6f\udbfb\udd52\udb7f\uddf0\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\ud874\udd66\ud8e0\ude53\ud30b\udab7\udf3d\ud9bd\udecb\ud9e7\ude68\ud9ea\ude5d",
        52, 72408, 1331741397, -6916096581319954597L, -46466L, false, true, (char) 58962, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369f4198204L), Double.longBitsToDouble(0x3fc4431d96e1aebcL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:DefaultDateTypeAdapter(SimpleDateFormat) |this=com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=!com.google.gson.JsonSyntaxException\012",
        Z.run(T, 2, 2, 1, 2, "\udb71\udfdc", "\ubc48\u1e58\u3467\ub7fe\u0f65\u8f67\uacd7\u21ea\u6f29\u9b63\u3fcb\u2d30\u6ac6\u2121\ub19f\u96d6\u9ec1\ub2de\u1d9e\u16e8\u30e6", "\udb3f\udec9\ud97b\udd52\uda8c\udebf\ud806\udc43\udbae\udcb9\ud9ef\udd5d\ud9d1\udf30\uda2b\udc9e\udb54\udf52\ud9b5\udfb9\ud81b\udc9f\ud83d\udc1f\ud99b\udeaa\udbdb\udec4\ud9ea\ude5d",
        52, 72408, -212676759, 2765894615257054357L, -38857L, true, false, (char) 28310, (char) 30267,
        Double.longBitsToDouble(0x3fdbb369f3a066b6L), Double.longBitsToDouble(0x3fc4430dd6e1acacL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\u5f31", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\u47c0\u3a48\u32a5", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\u00b1\000\ud97e\udf7f\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb5e\udedc\uda23\udcae\ud9ea\ude5d",
        51, -1000, 364171113, 158682066486111818L, -84087L, true, false, (char) 4989, (char) 64633,
        Double.longBitsToDouble(0x3ebe6e85d4400000L), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 1, 8, 8, 7, "\uda6b\udc49H\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u01cc\u4089\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\ub198\u92ca\u73d8\ua5e9\u14f9\u6e52\u3125\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 48128, 1026733728, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 2, 6, "\ud873\uddf2\177f\udb2e\udfc0\udb33\ude14\ud82f\uddd6\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud80d\ude98\udae4\udcd0\udb8b\udf99", "\u5eee\u70a1\u8470\u4a85\u3c82\ua92f\u51b8\u16fb\u408f\u445f\ud196\ua836\u2c7b\ub0da\u415c\u4dc0\u09fa\ub198\u92ca\uc0ec\u52a8\u32db\u6e52\u3125\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 6512, 1026733728, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 7, "\udaac\udceb\177\000\udb2e\udfc0\uda81\udc9b\ud87e\udc1eO\000\023\ud967\udf12\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud8a6\udcc7\ud964\udda8\ud88a\ude99\u00e2", "", "",
        14, 50142, -1561238835, -8744203758797155459L, -56601L, true, false, (char) 35075, (char) 48920,
        Double.longBitsToDouble(0x3fe92e15485d6300L), Double.longBitsToDouble(0x3e3c34dd58000000L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 7, "\udaac\udceb\udabf\uddbdN\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud86d\udffd\ud9ac\udc01\ud990\ude41", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u08e8\u408f\u445f\ud196\ua836\u50ec\ub07f\u415c\u0775\u2a96\ub198\u92ca\uc0ec\u52a8\u32db\u6e52\u3125\ub0fd\u9c66\u8258\ub1c4\u59e4\uab89", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb92\uddcf\ud9c9\udf8a\ud834\udd07",
        38, 48128, 1026733728, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 9, 7, "\udb53\udcba\udbaa\ude98", "\u64d1\u3467\u06d0\u3fcd\u0bcc\000\u1a01\000", "",
        10, -1000, 0, -38862848L, -20770L, false, true, (char) 46039, (char) 39528,
        Double.longBitsToDouble(0x3fc249966492bc68L), Double.longBitsToDouble(0x3ec4c00000000000L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 8, "\udb71\udfdc\udbaa\udec6", "\u1e58\u7e59\ub80c\u32bd\u667f\uc6db\u4c5b\u32a9", "\ud84e\udd3a\ud96a\ude2c\ud80f\udc95\udb01\udfb5\udaff\udeaf\ud860\udc1e\udb26\udf44\udbb7\udd86\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda3f\udff7\udb3f\udec9\uda74\udf6f\ud966\udee0\udaa7\udf73\udb8e\ude00\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\udbcb\udf43\ud810\udcf6\ud83d\udc1f\ud99b\udeaa\udbc6\udd04\ud9ea\ude40",
        52, 72408, 1006441065, 2765951527868693653L, 27449L, false, false, (char) 11361, (char) 34689,
        Double.longBitsToDouble(0x3fde317905a066b6L), Double.longBitsToDouble(0x3fccb78b16e3daccL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 8, 8, 7, "\uda6b\udc49H\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u01cc\u4089\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\ub198\u92ca\u73d8\ua5e9\u14f9\u6e52\ua588\ub6ea\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 88480, 1026733760, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 2, 6, "\ud873\uddf2Mf\udb2e\udfc0\udb33\ude14\ud82f\uddd6\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\uda4c\udf1d\ud93e\udefa\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud80d\ude98\udae4\udcd0\udb8b\udf99", "\u5eee\u70a1\u8470\u4a85\u3c82\ua92f\u51b8\u44e8\u7636\u5c1f\ud196\ua836\u9c88\u532e\u415c\u4dc0\u09fa\ub198\u92ca\uc0ec\u52a8\u3c31\u5682\u30eb\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\uda3d\udf83\uda99\ude89\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 6512, -567101792, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 7, "\udaac\udceb\177\000\udb2e\udfc0\uda81\udc9b\000\000\000\023\ud967\udf12\ud882\udfb8\ud923\uddb0\u0094\000\ud8a6\udc03\ud964\udda8\ud88a\ude99\u00e2", "", "",
        14, 50142, -1561238835, -8744203758797155459L, -56601L, true, false, (char) 35075, (char) 48920,
        Double.longBitsToDouble(0x3fe92e15485d6300L), Double.longBitsToDouble(0x3e3c34dd58000000L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 1, 8, 2, 6, "\ud873\uddf2M\udbf0\udfe2\udb2e\udfc0\uefd9\ud823\udf95\ud82b\udf75\udac9\udd3e\uda89\udf66\ud9d8\udf6e\uda4c\udf0e\ud93e\udefa\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud80d\ude98\udae4\udcd0\udb8b\udf99", "\u5eee\u70a1\u8470\u4a85\u3c82\ua92f\u51b8\u44e8\u6ecd\u23a1\u9059\ua836\u22b2\u52cb\u415c\u4dc0\u09fa\ub198\u92ca\uc0ec\u52a8\u3c31\u5682\u30eb\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\uda3d\udf83\uda99\ude89\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 6512, -567101792, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fc2af3bce03a688L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=!com.google.gson.JsonSyntaxException\012",
        Z.run(T, 1, 1, 7, 0, "", "", "\000",
        38, 38719, -1683329352, 5211735774736236829L, -50952L, false, false, (char) 50931, (char) 39593,
        Double.longBitsToDouble(0x3fddb8000c3e7b5aL), Double.longBitsToDouble(0x3fe5ef6bcea5b4edL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 7, "\000\000\000\000\ud874\udd79\ud946\udc22\ud97a\udf1b\u00b8\ud87c\ude43\ud967\udf12\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\u00c4\000\000\ud990\uddc0", "\u5eee\u70a1\u84a2\u4a85\000\ua92c\u51b8\u08e8\u408f\u00df\000\u974c\u2c7b\ub0da\u415c\u3386\u2a96\ub198\ua6d6\000\000\u757c\u6e52\000\ub7ff\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32",
        55, 78711, 1912602624, -8456007584511815430L, 93048L, true, false, (char) 56456, (char) 11109,
        Double.longBitsToDouble(0x3fb9c98ab4bf0e88L), Double.longBitsToDouble(0x3f78fdcc3c73dc80L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud87c\udd06\u5f31", "\ud13e\u3467\u8837\u0bbb\u1175\u47c0\u94a7\u32e9", "\ud84e\udd3c\ud96a\ude2c\ud80f\udc95\udb01\udfb5\ud829\udce3\udb77\udf1d\udacf\udf4f\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\uda6b\udd57\ud953\uddb1\udbfb\udd52\uda92\udcbf\uda79\ude4f\ud982\udc52\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\udbb3\uddc9\uda6e\udd15\udb5e\udedc\uda23\udcae\ud9ea\ude5d",
        -4, 38151, -573622302, 974957576192L, -93303L, true, false, (char) 4989, (char) 64633,
        Double.longBitsToDouble(0x3fb46d276e85d440L), Double.longBitsToDouble(0x3fc4431d8cf3915cL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 2, 6, "\udbb9\udff1/f\udb2e\udfc0\udb33\ude14\ud82f\uddd6\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\uda4c\udf1d\ud93e\udefa\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud80d\ude98\udae4\udcd0\udb8b\udf99", "\u5eee\u70a1\u8470\u4a85\u3c82\ua92f\u51b8\u44e8\u7636\u5c1f\ud196\ua836\u9c88\u532e\u415c\u4dc0\u09fa\ub198\u92ca\uc0ec\u52a8\ua002\u7654\u30eb\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud954\udfd6\ud9e8\ude43\uda28\ude35\uda99\ude89\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 6512, -567101792, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 7, "\000\uda64\ude7bg\ud814\udc09\ud874\udd79\ud946\udc22\ud97a\udf1b\u00b8\ud87c\ude43\ud967\udf12\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\u00c4\000\000\ud990\uddc0", "\u594d\u70a1\u84a2\u4a85\000\ua92c\u51b8\ub2f7\u0309\u00df\000\u974c\u2c7b\ub0da\u418a\u3386\u17f5\ub198\ua6d6\u02ab\ua639\u85dd\u4aa8\000\ub7ff\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32",
        55, 78711, 1912602624, -8456007584511815430L, 93048L, true, false, (char) 59272, (char) 9185,
        Double.longBitsToDouble(0x3fecd128fc6e6720L), Double.longBitsToDouble(0x3f64e26078e7b900L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 6, 0, "\ud9c5\udd76\ud86b\udf05\ud95a\udddd\ud962\udfba\udb1e\udc49\ud812\uddfa\uf417\ud908\udcce\udb46\udd3b\ud9f1\udf15\udb4f\udfe4\ud9aa\udcf4\ud8ca\ude03", "\u8262\u2eff", "\uda6d\ude19\udb4b\udfef\udb37\udc79\ud80f\udebf\udaf1\uddd2\ud939\udf9b\uda41\ude9d\ud90a\udd4d\u248d\udacd\udd1b\ud9d6\uddf3\udb03\udd26\ud85a\udd78\ud8ca\udeb5\uda16\udc1f\ud8e8\udd35\uda94\udfef\uc820\udab7\udc1c\uda77\udfed\ud9fe\udc88\udbaa\ude5d\ud8ee\ude1c\uda24\ude76",
        24, 80048, -1388661946, -6010422227614925425L, -85238L, false, false, (char) 64206, (char) 60532,
        Double.longBitsToDouble(0x3fede85e4db893e6L), Double.longBitsToDouble(0x3febf048da38f45fL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 8, 8, 7, "\uda6b\udc49y\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u01cc\u4089\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\u38c1\u92ca\u9c87\u50e1\u14f9\u6e52\ua588\ub6ea\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud831\udfd7\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 88480, 530086336, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 7, 0, "U", "\000", "\ud97a\udf1b\ud908\udcce\udbb2\udd6a",
        54, 58218, 1504765397, -3476923413934508236L, 8069L, true, false, (char) 19005, (char) 5011,
        Double.longBitsToDouble(0x3fc0a0a16ccaeb34L), Double.longBitsToDouble(0x3f92285e30e80f00L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 8, 7, "\uda6b\udc49y\000\udb2e\udfc0\udb33\ude14\ud836\udd21\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\uda05\ude0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u5eee\u0d7f\u84a2\u4a85\u3c82\ua92f\u51b8\u01cc\u4089\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\u375a\ud3f6\u9c87\u50e1\u14f9\u6e52\ua588\ub6ea\u9c66\u8258\u4637\ua772\u7c02", "\ud877\udecb\uda10\udf3d\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\udebf\udbbf\udc44\ud831\udfd7\ud88a\ude55\ud95f\ude71\uda99\udeb7\udb4b\uddf7\ud880\udd3e\uda09\udd1b\ud834\udd07",
        28, 81967, 530086336, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 4, 5, "\ud929\udd17\u193d\ud895\udd08\uda34\udd39\ud98a\udc23\ud954\uddd6\uda09\udc63\ud908\udc8c\ud97e\ude57\uda81\udf34\uda8e\udd74\ud923\uddb0\ub9bc\ud898\udf41\ud84e\udd3c\ud96a\ude2c\udb65\udfa7\udb01\udfb5\ud9c8\udec2\udba3\ude6b\ud818\ude9f\udb18\udf84\ud882\ude59\ud97e\udda1\udba4\ude2b\udae3\udffc\ud882\udfed\u1637\uda19\ude5e\ud8d1\udd85\ud8e0\udca3\ud85a\udd78\udb41\udf4f\ud82f\udd9f\udb42\udcad\ud8e0\udead\ud88e\uddd3\uda6e\udd15\udb9b\ude2b\uda23\udcae\ud9ea\ude5d\udbc7\udfa1\uda6f\udd5a\ud9c4\udcb0\ud8b4\udca1\uda30\ude1b\uda57\udc05\ud805\udc20\udb7d\udfd7\ud958\udc20\udb79\udf78\ud855\udcb9\ud948\udd6d\udb2c\udef2\ud8d9\udc85\udac7\udd47\udb22\udef1\ud8f8\ude23\ud84a\udda6\udb7e\udedf\ud805\uddf0\udae5\udc23\ud8c8\udfe7\ud9d2\udeea\ud8f3\udc8c\u1814\ud9e0\ude10", "\ua80f\u1539\u285c\u6914\u4194\ub754\u434e\ua52e\u95e9\u0bb3", "\uda0d\udf57\uda6a\udffb\udb87\udda0\uda1c\uddf7\udb77\udc22\udb38\udece\udbaa\udccf\udbfc\udf24\udb96\ude88\ud955\ude96\ud97b\udfc1\udacc\uddb9",
        51, 99513, 343745121, -352465001226717822L, 11084L, false, true, (char) 21908, (char) 31019,
        Double.longBitsToDouble(0x3feb42212125919aL), Double.longBitsToDouble(0x3fe6f972d8a57eb3L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 5, "\000\ub6d6R\udb2e\udfc0\udb33\ude94\ud946\udc22\ud89e\udfed\ud87b\ude36\udaa3\uddb4\u411d\ud84e\ude07\ud923\uddb0\ud90b\udf79\ud835\udfb3\ud831\udfbf\ud8bb\udca5\udbae\ude6b\000", "\000\000\u84a2\u0ded\u5183\uc350\u7e0b\u84fa\u8a50\ub6f2\ud196\ua836\u2c7b\ub0da\u415c\uac74\u2a96\ub198\u92ca\uc0ec\u52a8\u8db7\u0212\u00bb\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\000\000\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud80d\udc32\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udcbc",
        38, 48128, 2106545824, -6913606822298835334L, -32778L, true, true, (char) 5388, (char) 15886,
        Double.longBitsToDouble(0x3fefbcdf5380f589L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 4, "\ud9c5\udd76\ud86b\udf05Q\ud962\udfba\udb1e\udc49\ud812\uddfa\uf417\ud908\udcce\udb46\udd3b\ud9f1\udf15\udb4f\udfe4\udab4\udd63\ud8ca\ude03\ud937\udc8f\ud97c\udc43\udb5b\udd4e\udb41\udc88\ud920\udecc\ud9b8\udd01\uda6d\ude19\udb4b\udfef\udb37\udc79", "\u5bdb\u7d6f\u4c56\u499e\u2410\u617b\uc6a3\u3953\u53dd\u636d\ud0a5", "\udab7\udc1c\uda77\udfed\ud9fe\udc88\udbaa\ude5d\ud8ee\ude1c\uda24\ude76",
        24, 80048, -1390334390, 1627682740820235603L, -85238L, true, true, (char) 64237, (char) 60532,
        Double.longBitsToDouble(0x3fede85e4db893e6L), Double.longBitsToDouble(0x3febf048da38f45fL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 7, "\ud84e\udc0a\udbaa\udec6", "\u1ed2\u3467\u06d0\u3fcd\u0bcc\uc6db\u3a48\u32a5", "\udb24\udd7f\ud984\udd50\ud80f\udc78\udb01\udfb5\ud829\udce3\udb77\udf1d\udabf\udef7\udb22\udf5c\ud80f\udee6\ud869\udc4d\uda28\udfcd\ud8c8\uddfd\u1d6f\udbfb\udd52\uda92\udcbf\ud8cb\udf06\ud981\udfa5\ud85a\udd78\uda90\udeb8\ud849\udd27\udb5b\udfb9\ud8e0\udead\uc4ea\uda0e\udd34\ud9bd\udeaa\uda23\udd68\ud9ea\ude5d",
        52, 14160, 364171113, 216102961735085642L, -84087L, true, false, (char) 4989, (char) 30267,
        Double.longBitsToDouble(0x3fec0c24fdd033bcL), Double.longBitsToDouble(0x3fc4431d96e1acacL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 8, 8, 7, "\uda6b\udc49y\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\000\000\000\000\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u7fcb\u4089\u18e0\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\u38c1\u92ca\u9c87\u50e1\u14f9\u6e52\ua588\ub6ea\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc44\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud831\udfd7\u2b57\000\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 88480, 530086336, 2612010676307807866L, 94922L, false, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 8, 7, "\uda6b\udc49y\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud8ec\ude16\ud87c\ude56\uda82\udc17\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8i\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u01cc\u4089\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\u38c1\u92ca\u9c87\u50e1\u14f9\u6e52\ua588\ub6ea\000\u448b\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud831\udfd7\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 88480, 530086336, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 27727,
        Double.longBitsToDouble(0x3e3c074800000000L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 8, 8, 7, "\uda6b\udc49y\000\000\000\ud87e\udc1e\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\uda64\udc71\ud84d\udee5\ud9da\udd0c\udbc6\udd38\ud964\udda8\ud88a\ude99\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u01cc\u4089\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\u38c1\u92ca\u9c87\u50e1\u14f9\u6e52\ua588\ub6ea\u9c66\u8258\ub1c4\u86b5\u7c02", "\000\000\ud990\udc44\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud831\udfd7\ud88a\ude55\ud9f3\udcbe\000\ud8bc\udfbd\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 88480, 530055360, 2612010676307807866L, 94922L, true, true, (char) 47883, (char) 0,
        Double.longBitsToDouble(0x3fb380001c074d10L), Double.longBitsToDouble(0x3fe00002a7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 8, 8, 7, "\uda6b\udc49y\000\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8h\000\ud9cc\udc05\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u5eee\u70a1\u84a2\u4a85\u3c82\ua92f\u51b8\u01cc\u4089\u445f\ud196\ua836\u2c7b\ub0da\u415c\u0775\u2a96\u38c1\u92ca\u9c87\u50e1\u14f9\u6e52\ua588\ub6ea\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\ud831\udfd7\ud88a\ude55\udb2d\udefb\uda99\ude9f\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 88480, 530086336, 2612010676307807866L, 31072L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 1, 8, 4, 7, "\uda6b\udc49\udbd7\udf0bX\udb2e\udfc0\udb33\ude14\ud946\udc22\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\uda2e\udf8b\uda1c\ude63", "\u58d2\u7015\u19a3\u4a85\u33f5\ua92f\u51b8\u01cc\ubd43\u926d\ud196\ua836\u2c7b\ubb5b\u2e03\u5843\ube6f\ub198\u92ca\u73d8\ua5e9\u14f9\u6e52\u0e2f\u4490\ud317\u6884\ub1c4\u8adb\u4a9a", "\udae6\ude32\uda79\udd56\ud85a\udd51\ud9fc\ude99\uda2b\udd4f\udb08\udd2e\udaea\udfce\udbbf\udc44\ud80d\udc32\u7160\udb2d\udefb\uda21\udfe2\udad4\udca6\ud8b1\ude6b\ud9f3\udf40\ud834\udd07",
        38, 48128, 1026733728, 1098801203423923834L, 94922L, true, true, (char) 36875, (char) 37618,
        Double.longBitsToDouble(0x3fdabe485287d3b4L), Double.longBitsToDouble(0x3fc1f81ea47dcec0L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 6, "\udbb9\udff1\ud88e\udd95'\udb2e\udfc0\udb33\ude14\udabb\udc0c\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\uda4c\udf1d\ud93e\udefa\ud90b\udf79\ud9da\udd0c\ud817\udf7f\udb26\udce7\udae4\udcd0\udb8b\udf99", "\u5eee\u70a1\u8470\u7071\u204e\uabe7\u9306\u44e8\u7636\u5c1f\ud196\ua836\u9c88\u5917\u415c\u4dc0\u09fa\ub198\u92ca\uc0ec\u52a8\ua002\u7654\u4801\ub0fd\u9c66\u8258\ub1c4\u86b5\u7c02", "\udae6\ude32\uda79\udd56\ud990\udc53\ud909\udd04\uda38\udefc\ud945\ude59\uda63\ude6e\udbbf\udc44\uda29\udc5c\ud9e8\ude43\uda28\ude35\uda99\ude89\ud8c6\ude54\udb13\ude97\ud9f3\udf40\ud834\udd07",
        38, 6512, -567101792, 2612010676307807866L, 94922L, true, true, (char) 36875, (char) 9807,
        Double.longBitsToDouble(0x3fb389379c074d10L), Double.longBitsToDouble(0x3fe0297aa7d95ab0L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 4, 5, "\uda6b\udc49\udbd7\udf0bX\udb2e\udfc0\udb33\ude14\ud946\udc22O\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\uda2e\udf8b\uda1c\ude63", "\ua92a\u6fc0\u19a3\u4a85\u33f5\ua92f\u51b8\u01cc\ubd43\u926d\ud196\u51b2\u2c56\u0e88\u3a98\u5843\ube6f\ub198\u92ca\u0ad8\u1cec\u14f9\u6e52\u284c\u4490\000\u67eb\ub1c4\u8adb\u4a9a", "\udae6\ude32\uda79\udd56\ud85a\udd51\ud9fc\ude99\uda2b\udd4f\udb08\udd2e\udaea\udfce\udbbf\udc44\ud80d\udc32\u7160\udb2d\udefb\uda21\udfe2\udad4\udca6\ud8b1\ude6b\ud9f3\udf40\uea4b",
        38, 48128, 1026733728, 1098801203423923834L, -99894L, true, true, (char) 36875, (char) 37618,
        Double.longBitsToDouble(0x3fdabe485287d3b4L), Double.longBitsToDouble(0x3fc1f81ea07dcec0L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 6, "\udbb9\udff1\ud88e\udd95'\udb2e\udfc0\udae2\udecb\udbbd\ude05", "\u0bcc\u47c0\u4d71\u9fef\ub342", "\udb26\udce7",
        29, 41570, 1741715022, -8550346518322982536L, -7672L, false, true, (char) 39657, (char) 22930,
        Double.longBitsToDouble(0x3fd538b1204333d0L), Double.longBitsToDouble(0x3fce38e90283ce48L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 7, "\udbef\uddd0\ud88e\udd95'\udb2e\udfc0\udb33\ude14\udabb\udc0c\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\uda4c\udf1d\ud93e\udefa\ud90b\udf79\ud9da\udd0c\ud817\udf7f\udb26\udce7\udae4\udcd0\udb8b\udf99\ud89d\udc6c\ud940\udca2\udac7\udc91", "\u7071\u204e", "\ud92d\udcc9\ud9f9\udc35\udb5b\udcc6\uda6b\uddbd\uda49\udd4c\uda75\udcb7\ud9ad\udcc0\ud93e\ude5c\udbca\udef2\udb57\udfb8\ud866\udc49\ud9fd\udc3f\ud8a3\udd9e",
        10, 1236, -521290968, 8859651701454761983L, -18643L, true, true, (char) 27890, (char) 8866,
        Double.longBitsToDouble(0x3f79ce5d42ba9b80L), Double.longBitsToDouble(0x3fc004762df182c0L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 0, "\udbb9\udff1\ud88e\udd95'\udb2e\udfc0", "\u06d0\u3fcd\u0bcc\u47c0", "\ud90b\udf79\ud9da\udd0c",
        39, 70286, -303883806, 4355451475335345742L, -7672L, false, true, (char) 39657, (char) 57393,
        Double.longBitsToDouble(0x3fc965dea0866508L), Double.longBitsToDouble(0x3fce38e90283ce48L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 6, "\udbb9\udff1\ud88e\udd95'\udb2e\udfc0\udb33\ude14\udabb\udc0c\ud97a\udf1b\ud908\udcce\ud87c\ude56", "\u9fef\ub342", "\ud8bd\ude6f",
        58, 41570, 1741715022, -599416228613959304L, -7672L, false, true, (char) 1988, (char) 20523,
        Double.longBitsToDouble(0x3fc965dea0866508L), Double.longBitsToDouble(0x3fce38e90283ce48L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 6, 5, "\ud80f\udf40\uda4c\udee0'", "\u9c61\u06d0\u3fcd", "\uda4c\udf1d",
        33, 91980, 6109447, 8229898153745007550L, 52566L, false, false, (char) 30965, (char) 18640,
        Double.longBitsToDouble(0x3fef0d66e0a800a2L), Double.longBitsToDouble(0x3fd3ee1716ad4f26L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 4, "\u7136\udb33\udd3c'\ud962\udfba\ud8ad\udd12\u1a71\ud914\uddf6\ud8d4\ude18\ud95e\udc48\ud9f1\udf15\udb4f\udfe4\udbea\udd5e\ud8ca\ude03\ud937\udc8f\ud97c\udc43\udb5b\udd4e\udb41\udc88\ud920\udecc\ud9b8\udd01\uda6d\ude19\udb4b\udfef\udb37\udc79", "\u5bdb\u7d6f\u4c56\u499e\u2410", "\ud85a\udd78",
        52, 76266, -1450949254, 2439078816006514011L, 80106L, true, false, (char) 38983, (char) 37095,
        Double.longBitsToDouble(0x3fba32d06b491738L), Double.longBitsToDouble(0x3fc002b6992808ccL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 2, "\udbb9\udff1\ud88e\udd95'\udb2e\udfc0\udb33\ude14\udabb\udc0c\ud98d\udc1b\udad7\udd63\ud964\udfaa\ud9a2\udf83\ud988\udf1b\ud93e\udefa\ud90b\udf79\ud9da\udd0c\ud817\udf7f\udb26\udce7\udae4\udcd0\udb8b\udf99\ud89d\udc6c\ud940\udca2\udbf9\udc8a\uda2f\udfea\udbff\udeda\u2c08\ud99d\udc06\ud9a1\udf04\u5ebd\ud92d\udcc9\ud9f9\udc35\udb5b\udcc6\uda6b\uddbd\uda49\udd4c\uda75\udcb7\ud9ad\udcc0\ud93e\ude5c\udbca\udef2\udb57\udfb8", "\uc0ec\u52a8\u8f8a\ud1ee\u55e3\ub0fd\u9c66\u8258\ub1c4\u86b5\u6edb", "\udaae\udec2\uda79\udd56\ud990\udc53\ud909\udd04\ufa1e\ud804\udc53\ud96c\udc85\uda37\udc21\udb5a\udff3\ud9e8\ude86\uda28\ude35\ud9f3\udc82\ud8c6\ude54\udb16\udeff\uda01\udf86\ud834\udd07\ud91b\uddf8\uda18\udf6b\udb04\udf9e\ud8b0\udff6\ud97d\udff4\ud9e1\ude11\ud939\udcc6\ud82e\udf77\ud95e\udff6\ud8c9\udd25\uda24\udefc\u6e4a",
        52, 8793, -339167076, -3968181482935902935L, 42097L, true, true, (char) 15583, (char) 58621,
        Double.longBitsToDouble(0x3fed46223f7ca7aaL), Double.longBitsToDouble(0x3fe91a8f719b3c60L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:!toString:java.lang.NullPointerException\0121=!com.google.gson.JsonSyntaxException\012",
        Z.run(T, 2, 4, 1, 0, "", "\u4097", "\udbad\udd03\udbf8\ude16",
        24, 14429, 5884043, 1503854592L, -97748L, false, true, (char) 64045, (char) 45926,
        Double.longBitsToDouble(0x3fe9f00000001bc8L), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 5, 7, "\uda68\ude00yK\udb2e\udfc0\udbbd\ude99\ud946\udc9a\ud97a\udf1b\ud908\udcce\ud87c\ude56\uda82\udc34\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u9ea3\u1839\u2342\u4a85\u3c82\ua92f\u51b8\u68ea\u4101\u445f\ud196\ua7a2\uc770\ua5df\u9633\u0775\u2a96\u38c1\u92ca\u9c87\u3682\u3945\u0935\ua588\ub6ea\u9c66\ub6ec\u0b9d\u86b5\u7c02", "\udae6\ude32\uda9e\ude01\ud9c4\udc2f\udb2c\udd68",
        -3, 39514, -2062187091, 7780265119919490156L, 77340L, true, false, (char) 2153, (char) 65400,
        Double.longBitsToDouble(0x3fbe39ee525b98d0L), Double.longBitsToDouble(0x3fef8b923d7824adL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 6, "\udbb9\udff1\udaa1\udfdf'\u7b39", "\u6329\u3fcd\u0bcc\u1045", "\ud90b\udfa2\ud9da\udd0c",
        39, 30034, 30188002, 4355451667521833587L, 12214L, false, false, (char) 33355, (char) 27304,
        Double.longBitsToDouble(0x3fef0c5890a38ce2L), Double.longBitsToDouble(0x3fce38e90283ce48L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 5, 7, "\uda68\ude00yK\udb2e\udfc0\udbbd\ude99\ud946\udc9a\ud97a\udf1b\ud908\udcce\udae0\udfe9\udbce\udf68\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u9ea3\u1839\u2342", "\ud8c8\udddc\u1d6f",
        38, 61451, 1182003423, -5895701676967784362L, 35411L, false, true, (char) 4078, (char) 28327,
        Double.longBitsToDouble(0x3fda71eccdad2d3cL), Double.longBitsToDouble(0x3f8ba82c57f521c0L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 5, 5, "\u6a00yK\udb2e\udfc0\uf499\000O\ud8d8\ude0c\udae0\udfe9\udbce\udf68\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\udba8\udc74\ud964\udda8\ud88a\ude99\udaf2\ude93", "\u9ea3\036\u90e3", "\ud8c8\udddc\u1d6f",
        28, -1000, 1181941760, -5895701676967784362L, 35411L, false, false, (char) 134, (char) 28327,
        Double.longBitsToDouble(0x3ec99b5a5a780000L), Double.longBitsToDouble(0x3f8ba82c57f521c0L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\0121=new com.google.gson.DefaultDateTypeAdapter:DefaultDateTypeAdapter(SimpleDateFormat)\012",
        Z.run(T, 2, 8, 8, 7, "\uda68\ude00yK\udb2e\udfc0\udbbd\ude99\ud946\udc9a\ud97a\udf1b\ud908\udcce\udae0\udfe9\udbce\udf68\ud882\udfb8\ud923\uddb0\ud90b\udf79\ud9da\udd0c\ud84e\udd3c\ud964\udda8\ud88a\ude99\ud990\udea2", "\u9ea3\u1839\u2342", "\ud8c8\udddc\u1d6f",
        38, 61451, 1182003423, -5895701676967784362L, 35411L, false, true, (char) 4078, (char) 28327,
        Double.longBitsToDouble(0x3fda71eccdad2d3cL), Double.longBitsToDouble(0x3f8ba82c57f521c0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.DefaultDateTypeAdapter|read|com.google.gson.stream.JsonReader|new:com.google.gson.DefaultDateTypeAdapter:java.lang.Class",
    "M|com.google.gson.DefaultDateTypeAdapter|deserializeToDate|java.lang.String|new:com.google.gson.DefaultDateTypeAdapter:java.lang.Class",
    "M|com.google.gson.DefaultDateTypeAdapter|toString||new:com.google.gson.DefaultDateTypeAdapter:java.lang.Class",
    "M|com.google.gson.DefaultDateTypeAdapter|write|com.google.gson.stream.JsonWriter,java.util.Date|new:com.google.gson.DefaultDateTypeAdapter:java.lang.Class",
    "C|com.google.gson.DefaultDateTypeAdapter|<init>|java.lang.Class,java.text.DateFormat,java.text.DateFormat",
    "C|com.google.gson.DefaultDateTypeAdapter|<init>|java.lang.Class,int,int",
    "C|com.google.gson.DefaultDateTypeAdapter|<init>|int,int",
    "C|com.google.gson.DefaultDateTypeAdapter|<init>|java.lang.Class",
    "C|com.google.gson.DefaultDateTypeAdapter|<init>|java.lang.Class,java.lang.String",
    "C|com.google.gson.DefaultDateTypeAdapter|<init>|java.lang.Class,int",
    "M|com.google.gson.DefaultDateTypeAdapter|read|com.google.gson.stream.JsonReader|new:com.google.gson.DefaultDateTypeAdapter:java.lang.Class",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
