package com.google.gson.internal;
import org.junit.Test;
import static org.junit.Assert.*;
public class _Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\u3953", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\uac28", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 7, "\u68fc\ud940\uddb8\uda46\ude89\ud862\ude6a\ud9a7\udc5f\ud986\ude83\ud9fc\udc6e", "\000", "\u03c6\ud859\ude64\000\000\000",
        -5, -1000, -536845946, 6500275379215902238L, 51299L, true, false, (char) 47266, (char) 23169,
        Double.longBitsToDouble(0x3fea14ac10f4003fL), Double.longBitsToDouble(0x3fc4353d8d9ddf0cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\u3953", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 7, "\u698d\udab4\udfd3\uda1b\udfa6\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud829\udfc8\udbb7\udfc5", "\u4d09\uc5fd", "\ud9b7\udde0\ud95e\udf4e\ud9d2\ude6a\uda05\udd0c\udb29\udfae\udbad\udfc7\ud85d\uddd2\ud985\ude5f\ud97b\udd7a\ud951\udf31\ud9a2\udfe9\ud9b0\udfb6\u6373\ud986\udfe1\udb51\udfaf\ud9ce\udd48\udae6\udf0c",
        35, 42727, -2079227732, -8107604987255900211L, 78873L, false, false, (char) 604, (char) 34208,
        Double.longBitsToDouble(0x3fbfc976ffde12a8L), Double.longBitsToDouble(0x3fd989e0c9cfdfcaL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 4, 7, "\udac2\udf60\uda11\udd9f\uda53\ude35\ud919\udd1c\ud97f\udee2\udbb3\ude6f\ud9f3\udec7\udb27\udfba\udbae\udd9f", "\ucc57\ud4d5\ub754\u79d5\u9cdf\ub12d\u51c1\u386b", "\ud85c\ude3d\udb53\udc58\ud88e\udd5d\ud811\udc5a\ud8e0\udea6\uda3e\udea8",
        27, 43613, 2009319585, -7419078512860627025L, 5273L, false, false, (char) 45745, (char) 55533,
        Double.longBitsToDouble(0x3fc7b3ac92926b2cL), Double.longBitsToDouble(0x3fe4bca086bb3f11L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u30f0\ud50d\ub720\u79d5\u9cdf\u7683\u31a2\u3953", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Class:[I\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 9, "\u698d\udb47\ude9b\uda46\udda0\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\ud953\udcc4", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\ud5de", "\ud84c\udf7d\uda7d\udd6f\ud96b\udf2a",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 5, 4, "\u138d", "\u9ac5\u2aee\u92e4\u282b\u5dd7\u514e\u934a\u57bd\u47bf\ud572\ub720\u79d5", "\udb2a\ude5b\udb5a\udcb6\ubafd\ud88b\udd83\udb38\udf03\ud972\udec6\ud95f\udc15\udb24\udef1\ud9e8\udef4\ud82f\udff0\udbee\ude81\udadb\udd8a\ud98d\udfea",
        5, 12274, -133625273, 3058636107740709036L, 30088L, true, true, (char) 63120, (char) 38807,
        Double.longBitsToDouble(0x3fe309dd92d23c75L), Double.longBitsToDouble(0x3fe5e42123c829b2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 7, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud8c4\udfa5\ud914\udf94\ud965\udf79\ud924\udf9d", "\u673e\ud4d5\ub720\u79d5\u1670\u5c80\u30de\u3953", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        19, 48000, 1643464694, 3585442077395955879L, 40135L, true, false, (char) 50272, (char) 48927,
        Double.longBitsToDouble(0x3fc5886cc0e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a", "\u2812\u5dd7\u514e", "\udac3\udfd3\u03c6\ud859\ude64\udb2d\udc0f\uda11\udc6a\ud95e\udf4e\ud9d2\ude6a\uda05\udd0c",
        20, 78300, 2019665438, -7878866329648385795L, -85832L, false, true, (char) 28868, (char) 46130,
        Double.longBitsToDouble(0x3fc4353d8d9ddf0cL), Double.longBitsToDouble(0x3fe57b70532b8835L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:-1244963487\012",
        Z.run(T, 1, 12, 2, 0, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\u326c\ud9d5\ude4a\ud83d\udfd1\udb7d\udcdf", "\u673e", "\u0081\uda11\udc6a\ud95e\udf4e\ud9d2\ude6a\uda05\udd0c\udb29\udfae\000\ud85d\udd36\ud985\ude5f\ud95f\udc15\udae6\ude5b\ud8b8\ude9c\ud99f\udfaf\u6373",
        33, 24585, 1846158183, -8631963773823311061L, -1524L, false, false, (char) 34797, (char) 0,
        Double.longBitsToDouble(0x3fe8db4e2d6b48a9L), Double.longBitsToDouble(0x3fd073bfeec61f4cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[][]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 4, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\u3953", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 7, "\udb53\udf66\ud958\udc5f\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf\ud8bb\udfda\ud841\udfc6\udac3\udfd3\u03c6\ud859\ude64", "\u7683\u31a2\u3953\u7481\u98ee\u3ccb\u6339\uc73c\u5f4f", "\u6373\ud986\udf74",
        -5, 37863, 67938812, -8414796497950710585L, 96552L, false, true, (char) 20001, (char) 22708,
        Double.longBitsToDouble(0x3fe36efa7771b4e6L), Double.longBitsToDouble(0x3f98aa2e8f17cac0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 1, 7, "\u698d\ud940\uddb8", "\ud5ce\u8984\u7f91\u015f\u507d", "\udac4\udc75\u03c6\ud859\ude64\ud812\ude0c\uda11\udc6a\ud95e\udf4e\ufdee\uda05\udd0c",
        50, 78300, 123840030, -7878866329648385795L, -85832L, false, true, (char) 3222, (char) 42857,
        Double.longBitsToDouble(0x3fc435253a3c9f0cL), Double.longBitsToDouble(0x3fe57b70532b8835L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<int[], java.lang.Comparable, java.lang.Object> |a2=[Ljava.lang.reflect.Type;:[[class [I, interface java.lang.Comparable, class java.lang.Object]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 3, "\ud95d\udf19", "\u9ac5\u9d01\u1754\u2839\u04d8\u514e\ub614\u7b37\u9a81\u2f45\ua388\u824b", "\ud8f2\udffa\uda05\udc3a\ud8e9\udfae\ud834\udc53\ud983\udfea\ud8dd\udcd0\ud8be\ude1c\uda5f\udeff\udaeb\udf08\uda65\udd96\ud8fd\udd5c\uf44f",
        47, 50772, 351485879, -7986369276494852184L, 76328L, true, true, (char) 33805, (char) 24224,
        Double.longBitsToDouble(0x3fe108c9cbaf2d0aL), Double.longBitsToDouble(0x3fe9e02540da6162L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\u3953", "\ud8b4\udd03\ud985\ude5f\ud95f\udc15",
        38, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fb30a9c81c42088L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:java.lang.String[][]\012",
        Z.run(T, 2, 2, 0, 7, "\u696e\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\u1c57\uda7b\udd51", "\u8a45\u0c89\u47eb\u4bff\u9cdf\uc636\ubb60\u8629\u7481\u98ee\u3ccb\u6339\u619b", "\ud99f\udfaf\u6373\ud986\udfe1\udb51\udfaf\udbfd\udc63\ud984\ude59\uda76\udd9a\ud95b\udf4c\ud904\udd5e\udb44\udd1a\ud934\udfd4\udaf0\udd93\ub88b\u06fd\ud8c2\ude8e\udb5b\udf66\ud892\udc96\ud9c1\ude5b\uda3b\udcb7\ud937\udcb1\ud887\udd5f\udac8\udc83\ud828\udf7b\udad5\udf2a\u7665\ud989\udffc\udae6\udc2f\uda67\ude6f\ud8db\udc67\ud841\udf46\ud919\udc9e\udb34\ude92\uda27\udcdc\udaa8\udcbf\udac2\udd1e\udbe7\udef2\udb9d\udc3c\ud93f\udcbb\udb6c\udf1f\ud95a\udd49\ud998\udd6b\ud852\ude61\udbb4\udd3d\ud95b\udec4\udb63\uddf0\udbb3\udda7\udaae\uddf1\uda6a\udf11\ud977\ude04",
        34, 57999, -1168962576, 2571591517632569154L, 70294L, true, true, (char) 24570, (char) 9852,
        Double.longBitsToDouble(0x3fe1fc62121566efL), Double.longBitsToDouble(0x3fe7d37a76974242L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.ArrayList\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 5, 7, "\uda02\uddb2\ud940\uddb8\uda46\ude89\udaa0\udd69\uda4c\udd88\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u86d5\u9cdf\u7683\u31a2\u665a", "\ud85d\udd6f\ud985\ude5f\uda5b\udc1a\ud8e6\udd5b\ud8ea\udf44",
        -5, 76546, -1444105996, 8629961906633450343L, -1586L, false, false, (char) 55533, (char) 20001,
        Double.longBitsToDouble(0x3feac5e333e802f8L), Double.longBitsToDouble(0x3fd7186955480664L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:947401568\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 12, 13, 7, "\ud9a2\udddf\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\udbfe\udec4\udb7e\udcdc\ud83d\udfd1\udb7d\udcdf", "\ub7eb\u015e\ub720\u79d5\u9cdf\u7683\u31a2\u3953", "\ud85d\udd36\ud955\udfa7\ud80e\udfba",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda487491fd94c8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date\0121=java.lang.Class:[I\012",
        Z.run(T, 2, 8, 10, 7, "\u69df\ud940\uddb8\uda46\ude89\udbd5\udeef\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\u72ef\uad84\ucab0\u5b54\u3cd4\u3892", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        19, 25344, -1786595850, -9061282850458648020L, -34196L, true, false, (char) 11104, (char) 9215,
        Double.longBitsToDouble(0x3fcaadbf00e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 7, "\u698d\ud8af\udf90\ud98d\ude78\uda1d\udc11", "\u2812\u5dd7\u514e", "\ud9e8\ude62\uc56c\ud875\udc0b\udb51\udccd\udbb3\udd5b\ud977\udf8a\ud9d2\ude6a\uda05\udd0c",
        50, 78300, 2019665438, -7878866329648385795L, -51908L, false, true, (char) 1350, (char) 4503,
        Double.longBitsToDouble(0x3fc4353d9072d284L), Double.longBitsToDouble(0x3fe5798ba32b8835L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 0, "\ud806\udc60\ud940\uddb8\ud932\ude0e\ud816\uddca", "\u2812\u5dd7\u514e\u934a\u57bd\u673e\u6d9a", "\uda42\udc43\u309d\ud948\ude0a\udaa0\uddf4\udb29\udfae\udbca\udf54\ud85d\udd36\udb8c\udddc\ucea4\ud8e9\udc9c\ud8ea\udf44\ud876\udc59\u6373\ud986\udfe1\udb51\udfaf\ud844\udde3\udae6\udf9f\ud8a5\udc49\ud95b\udf47\ud904\udd5e\udb44\udd1a\ud904\udf83\udb7d\udfe5\udb31\ude1f\uda31\udf5e\ud890\udeb4\ud8e3\udce0\udb16\udfad\ud906\udf10\ud9da\udd84\ud900\udcf1\ud8ca\udeb4\udb4d\udca1\udbae\udd42\ud8d1\udda5\ud89e\uddd7",
        27, 7994, 91543235, -3878306235564426875L, -11505L, false, true, (char) 65198, (char) 26168,
        Double.longBitsToDouble(0x3fc5ffc252ad2e84L), Double.longBitsToDouble(0x3feb200b29a21cf0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 7, 7, "\ubc6d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u02cd\u7683\u31a2\u3953", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        40, 21035, -377309706, 350499755457838558L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3f9cbb7215108100L), Double.longBitsToDouble(0x3fda48749b4b6b5eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\ud939\udcdd", "\u673e\ud4d5\ub720\u79d5", "\udb9e\udcf4\udb28\udc13\ud8af\udc94\udbca\udf54\ud85d\udd36\ud985\ude5f\udbf1\udf74\ud8e6\udd5b\ud8ea\udf44\ud99f\udfaf\u6373\ud986\udfe1\udb51\udfaf",
        9, 5763, 1377387692, -5802765870290968104L, -8003L, true, false, (char) 7928, (char) 38332,
        Double.longBitsToDouble(0x3fd4612b5c86b1f2L), Double.longBitsToDouble(0x3feda8fad7e20a31L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:int<java.lang.Integer> |a2=[Ljava.lang.reflect.Type;:[[class java.lang.Integer]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 7, "\ud92b\ude36\udad5\udfaf\udb7d\udcb8\ud88e\udea2\ud8eb\udf5c\udb81\udd84\ud830\ude7c\uda00\udfd6\udab0\udc5e", "\u673e\ud4d5\ub720\u919c\u3cb0\u6bb3\u31a2\u3953\u7481\u98ee\u3ccb", "\ud86c\udc1d\udb3e\udc70\udbc1\udf7f\udbfe\udd06\ud805\ude56\ud985\ude29\ud844\udde3\udae6\udf9f\ud8a5\udc49\uda92\udf63\ud904\udd5e\udb44\udd1a\ud934\udfd4\ud985\udca9\ud8be\ude0a\uda9b\udd50\ud990\udf0e\uda51\udf7d\uda63\udd72\ud954\udfbf\ud983\udea6\udac5\udc41\udb52\udd81\uda74\udefa\ud8e6\udee3\ud83c\uddeb\udbcc\udd96\udbbb\udc3b",
        1, 77128, -1471482963, -4585649866923201317L, 24367L, false, true, (char) 39027, (char) 17835,
        Double.longBitsToDouble(0x3fbe0d88b5137538L), Double.longBitsToDouble(0x3fea57fe7b3df2dcL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<int[], java.lang.Comparable> |a2=[Ljava.lang.reflect.Type;:[[class [I, interface java.lang.Comparable]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 7, 5, "\ud8ee\udf3d\ud9c7\udf70\ud8b2\udf21\uaf4b\uda6d\udea8\udaf3\udeec\uda69\udda7\ud863\udeb1", "\u57bd\u673e\u348a\ub6db\u2f5d\u94d9\u7683\u31a2\ub833\u7481\u98ee", "\ud95f\udc15",
        19, 48000, -1786595850, 234146780716773620L, -63339L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fe561539262f9dfL), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 4, 7, "\u68fc\ud940\uddb8\uda46\ude89\ud862\ude6a\ud9a7\udc5f\ud986\ude83\ud9fc\udc6e", "\000", "\u03c6\ud859\ude64\udb5c\udd4d\udabd\ude98\000",
        -5, -1000, -536845946, 6500275378482580766L, -85832L, false, true, (char) 28868, (char) 45362,
        Double.longBitsToDouble(0x3fc4353d8d9ddf0cL), Double.longBitsToDouble(0x3fd92360ba550120L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 8, 7, "\u68fc\ud9d6\uddc2\uda01\udec7\ud862\ude6a\ud9a7\udc5f\ud986\ude83\ud9fc\udc6e", "\u163f", "\u03c6\ud859\ude64\000\000\000",
        27, -959, -536845946, 6500275379215902238L, 51299L, true, false, (char) 47266, (char) 23169,
        Double.longBitsToDouble(0x3fea14ac10f4003fL), Double.longBitsToDouble(0x3fc4353d8d9ddf0cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Integer<java.lang.Comparable, java.lang.Integer> |a2=[Ljava.lang.reflect.Type;:[[interface java.lang.Comparable, class java.lang.Integer]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 9, 11, "\udbfb\udf86\ud940\uddb8\uda46\ude89\ud862\ude6a\ud9a7\udc5f\udb4f\udc67\ud877\udc09\u2939\000", "\u1d07\u0efc\ub720\u9ff0\ub4e9\000\u008f\000\u682e\u4b79\u3ccb\u6339\uc73c\u8905\u6d29\u9fbf\u938d\u82ef\u38fd\u080d\u91f4\u7dce\u185a", "\udb4e\udc96\ud9e4\udd96\ud977\udce4\ud82a\udc69\udb52\udcc1",
        8, 67467, 2034882830, 4907382674466914664L, 4363L, false, false, (char) 16113, (char) 62147,
        Double.longBitsToDouble(0x3fd10c680352e59cL), Double.longBitsToDouble(0x3fe76536197fdbafL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:!toString:java.lang.NullPointerException\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\u68fc\ud940\uddb8\uda46\ude89\ud862\ude6a\ud9a7\udc5f\ud986\ude83\ud9fc\udc6e", "\000", "\u03c6\ud859\ude64\000\000\000",
        -5, -1000, -536845946, 6500275379215902238L, 10592L, true, false, (char) 47266, (char) 23169,
        Double.longBitsToDouble(0x3fea14ac10f4003fL), Double.longBitsToDouble(0x3fc4353d8d9ddf0cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 12, 12, 14, "\u68fc\ud873\udeb3\ud917\ude77\ud862\ude6a\ud9a7\udc5f\ud986\ude83\uda3c\udc6e", "\u131d", "\u048e\ud859\ude64\000\000\000",
        -5, -1000, -536845946, 6500275379215902238L, 51299L, true, false, (char) 47266, (char) 23141,
        Double.longBitsToDouble(0x3fea14ac10f4003fL), Double.longBitsToDouble(0x3fc42d9d9cdbdd04L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Class:[Ljava.lang.String;\012",
        Z.run(T, 2, 5, 8, 7, "\udaec\uddfe\ud940\uddb8\u17e9\ud862\ude66\ud81b\uddcf\ud986\ude83", "\000\000\u33cd\u0164\ua57b\u110a\ub167\u869cN\000\000\u3399\u0f51\u3cd0\u6339\uca32\u5f12", "\udaef\udeef\ud986\udf58",
        10, 85215, -1200177028, 7248364276020421215L, 99045L, false, false, (char) 41017, (char) 44398,
        Double.longBitsToDouble(0x3fcdac14d9b41b3cL), Double.longBitsToDouble(0x3fb9b69340c55c50L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Class:int\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 7, "\udbd7\udcbb\udb6e\uddaf\ud8db\udf13\ud862\ude6a\ud9a7\udc5f\ud986\ude83\ud826\udcf4", "\u5fad\u249a", "\udbdf\udcbf\u75d8\u8656\000\000\000\ud907\udefd\ud951\udce4",
        58, 84969, 881176829, -3457212773805659866L, -90594L, false, false, (char) 29325, (char) 38600,
        Double.longBitsToDouble(0x3fe96aac13d44d1dL), Double.longBitsToDouble(0x3fc7584a5952b148L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 10, 5, "\u68fc\ud940\uddb8\ud96e\udc83\uda8d\udc1f\000\ud986\ude83\ud9fc\udc6e", "\000", "\u03c6\u0578\000\000\000",
        -5, -1000, 0, 6500275379215902238L, 51299L, true, false, (char) 47266, (char) 22923,
        Double.longBitsToDouble(0x3ec0400000000000L), Double.longBitsToDouble(0x3fc420000000030cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 1, 8, 7, "\u698d\udbaa\uddad\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u9cdf\ua5eb\u30e2\u3953", "\ud999\udd6e",
        46, 51829, -268819891, -6589953007633123850L, -54700L, true, false, (char) 39722, (char) 35001,
        Double.longBitsToDouble(0x3fa12eac298023f0L), Double.longBitsToDouble(0x3f64aaa038841100L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String |a2=[Ljava.lang.reflect.Type;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\uda03\udd67\ud823\uddf0\ud92f\udcd0\uecca", "\u04a0\ud4d5\ub720\u79d5\u9cdf\u0e54\u07a8\u3953\u7481\u17ef\u1052\u185c\u291d\u5f4f\u642c", "\ud986\udfe1\udb51\udfaf\ud844\udde3\udae6\udf9f\ud8a5\udc49",
        35, 58268, -2025258952, -7105464545810337603L, 84505L, false, true, (char) 11164, (char) 56041,
        Double.longBitsToDouble(0x3fcba6782ab7a45cL), Double.longBitsToDouble(0x3fe73399f552bb6eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<int[], java.lang.Comparable> |a2=[Ljava.lang.reflect.Type;:[[class [I, interface java.lang.Comparable]]\0121=java.lang.Class:java.util.Date\012",
        Z.run(T, 2, 14, 8, 7, "\ud917\udd65\ud940\udde0\uda46\ude89\ud862\ude6a\uda4c\udd12\ud879\udcc2\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\u18a3\u79d5\u9d9b\u7683\u31a2\u3953", "\ud83c\udf26\ud985\ude5f\ud95e\udfcb",
        19, 48000, -1786595850, 234146780716773620L, 40135L, false, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 2, 2, 7, "\udba8\udcf3\udb19\udee4\uda46\ude89\uda6c\udf8f\uda44\udd89\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb1a\udcfe", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\u3953\u7481\u8bc8", "\ud95f\udc15",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fdac2a72359695cL), Double.longBitsToDouble(0x3fb54a3abb3b06f0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void\0121=java.lang.Class:java.lang.Number\012",
        Z.run(T, 2, 2, 11, 7, "\u698d\ud940\uddb8\udade\udd35\ud831\ude6b\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\u3953", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        7, 27254, -1786595850, 234146780948120169L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 6, 6, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud8c8\udfb5\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e", "\udb2d\udc87\uda11\udc6a\ud95e\udf4e\ud9d2\ude6a\uda05\udd0c\udb29\udfae\udbe0\ude54\ud85d\udd36\ud977\uddcc\ud983\uddc8\ud988\ude25\ud80f\udfdd\ud980\udd72\u6373",
        31, -305, 654092941, 2994409917881295616L, -89542L, false, true, (char) 50305, (char) 63366,
        Double.longBitsToDouble(0x3fe85db01971c551L), Double.longBitsToDouble(0x3fd587b3d503e068L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<java.util.List, java.lang.Comparable, java.lang.Integer> |a2=[Ljava.lang.reflect.Type;:[[interface java.util.List, interface java.lang.Comparable, class java.lang.Integer]]\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 14, 13, 7, "\u698d\udab4\udfd3\uda1b\udfa6\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud829\udfc8\udbb7\udfc5", "\u4d09\uc5fd", "\ud9b7\udde0",
        4, 106, 1732075255, -2250566687399830012L, -57807L, false, false, (char) 50737, (char) 58170,
        Double.longBitsToDouble(0x3fdf6c6186852bf2L), Double.longBitsToDouble(0x3fce8067e286a7b0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Comparable<java.lang.Integer>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 1, "\u698d\udab4\udfd3\uda1b\udfa6\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud829\udfc8\udbb7\udfc5\ud816\udec8\udb7d\udf6e\ud8dc\udcaf\ud80a\ude26\ud9ce\udd4b\udb2d\udc0f\ud9b7\udde0\uda12\udf48\ud9d2\ude6a\uda05\udd0c\udb29\udfae", "\u7b63\u35bd\u93cb\u6ab2\ub44c\uc71b\u82ef\u2693", "\ud9ed\udc4d\ud986\udf1c\ud864\uddec\ud9fc\udd96\uda65\udcb7\udac5\udc2d\u4206\ud9c2\udce3\udaf9\udf8a\ud845\udebe\udab0\udcdc\ud8c2\ude35\ud0a5\ud07f\udb69\udfdf\ud904\udd38\ud8ed\udcc2\ud844\udc62\uda8a\udfde\uda8a\udd6f\ud89f\udfb7\ud89e\udd2e\uccd5\ud81d\ude68\uda9f\udc6b\uda97\udea7\ud985\udfe8\uda53\udc3b",
        36, 40377, -1164251318, 4034756644294673885L, -47233L, false, false, (char) 15884, (char) 53537,
        Double.longBitsToDouble(0x3fe7436fc7bbd023L), Double.longBitsToDouble(0x3fdcbd193fb955e2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 11, 3, "\u698d\udab4\udfd3\uda1b\udfa6\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud829\udfc8\udbb7\udfc5", "\u4d09\uc5fd", "\ud9b7\udde0\ud95e\udf4e\ud9d2\ude6a\u9a3b\udb1b\udd2f\udbad\udfc7\ud85d\uddd2\ud985\ude5f\ud97b\udd7a\ud951\udf31\ud9a2\udfe9\ud9b0\udfb6\u6373\ud986\udfe1\udb51\udfaf\ud9ce\udd48\udae6\udf0c",
        35, 42665, 705790124, 5667556334584552409L, 78873L, false, false, (char) 604, (char) 34208,
        Double.longBitsToDouble(0x3fbfc976ffde12a8L), Double.longBitsToDouble(0x3fd989e0c9cfdfcaL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.ArrayList\0121=java.lang.Class:java.util.ArrayList\012",
        Z.run(T, 2, 8, 8, 7, "\u698d\udab4\udfd3\uda1b\udfa6\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud829\udfc8\udbb7\udfc5", "\u4d09\u30a9\u7a11\u69b3\u454f", "\ud8bb\ude88\udb29\udfae\ud87f\udfd0\ud85d\uddf8\ud985\ude5f",
        42, 67245, -971450541, -7639862030496703678L, -85757L, true, true, (char) 30828, (char) 7246,
        Double.longBitsToDouble(0x3fc8eda382b0a9e4L), Double.longBitsToDouble(0x3fac4208ccd8f7c0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Comparable<java.util.Date>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 7, "\u698d\udb09\udd3d\uda06\ude81\ud862\ude6a\uda4c\udd12\ud993\udcef\ud883\udd60\ud95c\udc55\udbb8\udef2", "\u4d09\uc5fd", "\ud9b7\udde0\ud95e\udf4e\ud9d2\ude6a\ud8f2\udfde\udb4b\udca5\udba2\udcd7\ud85d\uddd2\ud985\ude5f\ud97b\udd7a\ud951\udf31\ud9a2\udfe9\ud9b0\udfb6\udab7\udea1\ud966\udecf\udb51\udfaf\ud9ce\udd48\udae6\udf0c\ud971\udc4f\udb1b\udf47\ud904\udd5e\ud9fc\udd96\uda65\udc25\udac5\udc2d\ud828\udc91\ud868\ude39\udaf9\udf9d\ud845\udebe\udab0\udcdc\ud8c2\ude35\ud0a5",
        27, 76002, -28015728, -1651309445376179535L, 76220L, false, true, (char) 14146, (char) 25985,
        Double.longBitsToDouble(0x3fa044574cef8d80L), Double.longBitsToDouble(0x3fe768807616b686L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Comparable\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 7, "\u698d\udab4\udfd3\uda1b\udfa6\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud829\udfc8\udbb7\udfc5", "\u4d09\uc5fd", "\ud9b7\udde0\ud95e\udf4e\ud9d2\ude6a\udb46\udcfa\udb29\udff7\udbad\udfc7\ud85d\uddd2\ud985\ude5f\ud97b\udd7a\ud951\udf31\ud9a2\udfe9\ud9b0\udfb6\u6373\ud986\udfe1\udb51\udfaf\ud9ce\udd48\udae6\udf0c",
        35, 73551, -2077719636, -8107604987255900211L, 78873L, false, false, (char) 604, (char) 34208,
        Double.longBitsToDouble(0x3fbfc976ffde12a8L), Double.longBitsToDouble(0x3fd989e0c9cfdfe4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Class:char\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 7, 9, "\udb27\ude62\uda11\udd9f\udb1c\ude48\ud919\udd1c\ud97f\udee2\udbb3\ude6f\ud9f3\udec7\udb27\udfba\udbae\udd9f", "\ucc70\u02a5\u2c91\u0a0d\u9cdf\ub12d\u46ae\uab71", "\udaa3\udfe1\udab0\udc06\ud91c\uddc3\ud811\udc5a\ud8e0\udea6\uda3e\udea8",
        27, 96149, -129372953, -7419078785133882648L, 5273L, false, false, (char) 48307, (char) 55533,
        Double.longBitsToDouble(0x3fc7b3ac96926b2cL), Double.longBitsToDouble(0x3fe4bdac46bb3f11L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Integer:2036934860\012",
        Z.run(T, 2, 5, 12, 5, "\ud9e6\udd12\ud9f2\udd82\udac4\udc93\udb58\udd4d\u91e9\udb60\udfdb\ud992\udd3a", "\u2c33\u6840\u30f0\ud50d\u9980", "\uda3e\udeb0\uda32\udf2e\ud93c\udf4b\udb6c\udf6b\uda65\udf9a\udb14\uded4\udb1a\ude6a\ud9a5\udc42\uda70\uddc2",
        7, 47817, -1568352725, -6202388022772840287L, -27633L, true, true, (char) 30345, (char) 43805,
        Double.longBitsToDouble(0x3fe6ec208d225c01L), Double.longBitsToDouble(0x3fc60d6e6f78704cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.ArrayList\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:int[]<java.util.ArrayList, int[]> |a2=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, class [I]]\012",
        Z.run(T, 2, 10, 14, 7, "\ud8ca\udcb2\ud940\uddb8\uda46\ude89\udb0a\udf13\uda44\ude3e\ud993\udcef\ud9fc\udc6e\u0e36\udb86\udedd", "\u30f0\ud50d\ub3df\u9c6a\u9cdf\u7683\u31a2\u3953", "\ud9db\uddf6\ud993\udff5\ud83f\udda1",
        23, 31981, -1786624758, 235694893184868596L, 13884L, true, false, (char) 43805, (char) 40403,
        Double.longBitsToDouble(0x3fe5243a48bd41eaL), Double.longBitsToDouble(0x3fe2df59e749dfedL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<int[], java.lang.Comparable> |a2=[Ljava.lang.reflect.Type;:[[class [I, interface java.lang.Comparable]]\012",
        Z.run(T, 2, 1, 14, 12, "\u698d\ud940\uddb8\udb8e\udd8c\ud862\ude6a\uda4c\udd12\ud993\udcef\ud801\udce9\ud83d\udfd1\udb7d\udcdf", "\u43e0\u66b4\ub720\u79d5\u9cdf\u7683\u26b0\u5c2d", "\ud85d\udd36\ud985\ude5f\uda96\udc31",
        19, 48000, -1781352970, 234146780716773620L, 63431L, true, false, (char) 18034, (char) 11264,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.Date\0121=java.lang.Class:java.util.Date\012",
        Z.run(T, 2, 8, 8, 6, "\uda31\udf9c\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fe\udc09\ud83e\udc6f\udb7d\udcdf", "\u30f0\ud50d\ub720\u79d5\u9cdf\u7683\u31a2\u3953", "\ud85d\udd36\ud985\ude5f\ud95f\udc15",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e512e1044L), Double.longBitsToDouble(0x3fda4873a17b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Class:[I\0121=java.lang.Class:[I\012",
        Z.run(T, 2, 10, 10, 9, "\u698d\udb47\ude9b\uda46\udda0\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\ud953\udcc4", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\ud5de", "\ud84c\udf7d\uda7d\udd6f\ud96b\udf2a",
        19, 48000, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[][]\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:int[][]\012",
        Z.run(T, 2, 0, 0, 9, "\u8591\udb47\ude41\uda46\udda0\ud862\ude6a\uda4c\udd12\u326c\ud9dd\ude4e\ud83d\udfd1\ud953\udcc4", "\u673e\ud4d5\ub720\u79d5\u9cdf\u7683\u31a2\ud5de", "\000\000\ud96b\udf2a",
        19, 47832, 8566262, 233905704202449140L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3ebc800000000000L), Double.longBitsToDouble(0x3e17b3a000000000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 5, 5, 4, "\udbb4\udee5", "\u9ac5\u2aee\u35da", "\udb7d\udcdf\ud8bb\udfda\ud841\udfc6\udaad\udeab\u0463\ud859\ude64\udb2d\udc0f\uda11\udc6a\udbf0\udfb7\u26ed\udb5a\udc75\ubafd\ud88b\udd83\udb38\udf03\ud972\udec6",
        23, 8409, -1535195047, 5259161628728430861L, -27678L, false, true, (char) 28171, (char) 43805,
        Double.longBitsToDouble(0x3fbd2ac44d2507d8L), Double.longBitsToDouble(0x3fa1c0b23d8b0b40L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\012",
        Z.run(T, 2, 5, 7, 4, "\u138d", "\u9515\u2aee\u92e4\u282b\u7598\u3956", "\ud904\udd9f\uda59\udc6e\ud859\ude64\ud921\udd2a\uda99\udd2e\udb4c\ude96\udbea\ude6e\udb6f\udc43\uda38\udf24\udaef\udd9a\uda71\ude77\uda29\udc20\udbc5\udd9f\ud868\uddd3\ud87a\udd5d\udabe\udd74",
        54, 65020, 678660309, 5165949706581483893L, 1034L, false, false, (char) 43909, (char) 55533,
        Double.longBitsToDouble(0x3fa1c0b259dc2b40L), Double.longBitsToDouble(0x3fd1889aff5b420eL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.Date<int[], java.util.Date, java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [I, class java.util.Date, class java.util.ArrayList]]\012",
        Z.run(T, 2, 5, 14, 9, "\u138d", "\u9ac5\u2aee\u92e4\u282b\u5dd7\u514e\u934a\u9f92\u44d2\ud572\ub720\u79d5", "\udb2a\ude5b\udb5a\udcb6\ubafd\u5caa\udb38\udf03\ud972\udec6\ud95f\udc15\udb24\udef1\ud9e8\udef4\ud82f\udff0\udbee\ude81\udadb\udd8a\ud98d\udfea",
        5, 12274, -133625273, 3058636107740709036L, 30088L, false, false, (char) 63120, (char) 38807,
        Double.longBitsToDouble(0x3fe309dd92d23c75L), Double.longBitsToDouble(0x3fe5e42123c829b2L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\012",
        Z.run(T, 2, 7, 7, 5, "\u8606\ud95b\udea8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud8c4\udfa5\ud914\udf94\ud965\udf79\ud924\udf9d\ud97a\udff3\ud841\udfc6\udac3\udfd3\u03c6\ud859\ude64", "\u5c80\u768e\ucdcf\ub19b\u98ee\u2ede\u5dcb\u880b\u6608\u3391\u5948\u278d\u88c5\ud5ec\u5dd2\u33bb\u0d3f\u09bc\ub4cd\u7925\u7808\ua68b", "\ud8d2\udf47\uda11\udc98\uda9b\uddb6\u79d6\udbf6\ude2c\ud817\udc7a\uda11\udd5a\ud831\udec0\ud907\ude10\ud9a3\udf45",
        46, 13869, 935227987, -5149903810480805836L, 98318L, true, true, (char) 55857, (char) 21910,
        Double.longBitsToDouble(0x3fb90441b347fb40L), Double.longBitsToDouble(0x3feb6b9847b67cf8L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\0121=sun.reflect.generics.reflectiveObjects.TypeVariableImpl:E\012",
        Z.run(T, 2, 7, 7, 7, "\uda88\udcd7\ud940\uddb8\uda46\ude89\ud862\ude6a", "\u00b6\u7731\u011d", "\udac3\udfd3\udbb1\uded3\ud859\ude64\udb2d\udc0f\ud9b2\ude1b\uda98\udfca\ud9bb\udcb0\uda05\udd0c",
        -2, 82212, 1348576983, -7878866497152110339L, -20296L, false, true, (char) 28296, (char) 57960,
        Double.longBitsToDouble(0x3fdada9ec0af2c32L), Double.longBitsToDouble(0x3fe03e18042b8835L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Class:[I\012",
        Z.run(T, 2, 5, 11, 10, "\u698d\udb7a\ude96\uda46\ude97\ud82e\udf90\uda4c\udced", "\u5dd7\u514e\u934a\u87c9\u6801\ud4d5\u3ebf\u0935\ua79f\u7683\u31a2\u3953\u8c28", "\ud985\ude5f\udbed\ude37\ud8e6\udd5b\udb65\udf14\udaba\udcfe\ud954\ude7b\ud8ce\udf8d\udb51\udfaf",
        33, 12319, -932011221, 8166272810622333371L, -61936L, false, true, (char) 23053, (char) 55576,
        Double.longBitsToDouble(0x3fa8d8dbc35caa40L), Double.longBitsToDouble(0x3fdeb0045262a192L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Integer:2002243147\0121=java.lang.Integer:2002243147\012",
        Z.run(T, 2, 12, 12, 7, "\udafc\udc84\ud940\uddb8\uda46\ude89\ud822\ude6a", "\u2812\u5dd7\u514e", "\ud822\udd0a\ud99a\udd6d\ud861\udeec\ud8b1\udd59\uda11\udc7c",
        45, 11178, -426313359, 7998223477493833220L, 39853L, false, false, (char) 23169, (char) 28868,
        Double.longBitsToDouble(0x3fce8067e286a7b0L), Double.longBitsToDouble(0x3feb3bbe1aaf6e0aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Thread$State<java.lang.Long> |a2=[Ljava.lang.reflect.Type;:[[class java.lang.Long]]\012",
        Z.run(T, 1, 14, 2, 0, "\udb14\udc99\uc861\ud883\udf17\ud862\ude6a\udbab\udf82\udb48\udc05\uda6a\udfd4\ud83d\udfd1\udb7d\udcdf", "\u673e", "\u00a8\uda11\udc6a\ud95e\udf4e\ud9d2\uddb9\uda05\udca7\udb29\udfae\000\ud85d\udd36\ud985\ude5f\ud95f\udc15\udae6\ude5b\ud8b8\ude9c\ud99f\udfaf\ud85c\udcd9",
        40, 16279, -211638463, -8539465378156731605L, -26860L, false, false, (char) 23030, (char) 46541,
        Double.longBitsToDouble(0x3fd230080ad60cc4L), Double.longBitsToDouble(0x3fd073bfeec61f4cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Thread$State\0121=java.lang.Class:java.lang.Thread$State\012",
        Z.run(T, 2, 8, 8, 7, "\udb53\udff5", "\u191a\ubf5e\u0414\u2812\u5dd7\u514e\u934a\u57bd\u673e\ud4d5\ub720\u79d5", "\ud9d2\ude6a\uda05\udd0c\udb29\udfae\udbca\udf54\ud868\udc36\ud985\ude5f\ud95f\udc15\ud8ff\udd5b\ud8ea\udf44\ud99f\udfaf\udb4a\ude6b\ud986\udfbc\uda88\udecb",
        8, 65812, -1959222485, 536602109392552108L, -67024L, false, false, (char) 19543, (char) 14918,
        Double.longBitsToDouble(0x3fd78be56e726028L), Double.longBitsToDouble(0x3fe446345946cfdbL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.List\0121=java.lang.Class:java.util.List\012",
        Z.run(T, 2, 8, 8, 7, "\udb53\udf66\ud958\udc5f\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf\ud8bb\udfda\ud841\udfc6\udac3\udfd3\u03c6\ud859\ude64", "\u7683\u31a2\u3953\u7481\u98ee\u3ccb\u6339\u4f88\u7426", "\u6422\ud986\udf74",
        -5, 37863, 67938812, -8414796497950710585L, 96552L, false, true, (char) 5389, (char) 22708,
        Double.longBitsToDouble(0x3fe36efa7771b4e6L), Double.longBitsToDouble(0x3f98aa2e8f17cac0L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.Date |a2=[Ljava.lang.reflect.Type;:[[]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.util.Date |a2=[Ljava.lang.reflect.Type;:[[]]\012",
        Z.run(T, 2, 14, 14, 6, "\ud869\udf72\ud958\udc5f\uda46\ude89\udbb6\udd54\uede4\ud99c\udfb5\ud9fc\udc6e\udbd4\udefe\udb7d\udcd9\udbb3\udc13\ud841\udfc6\udac3\udfd3\u03c6\ud859\ude64", "\u7683\u31a2\u3953\u7481\u7be4\ua251\u6339\uc73c\u5650", "\u6373\ud986\udf74",
        40, 59272, 67938812, 799279167859040554L, 96552L, false, true, (char) 63796, (char) 22708,
        Double.longBitsToDouble(0x3fe36efa71800a5bL), Double.longBitsToDouble(0x3f98aa798f17cac0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<int[], java.lang.Comparable, java.lang.Object> |a2=[Ljava.lang.reflect.Type;:[[class [I, interface java.lang.Comparable, class java.lang.Object]]\0121=void\012",
        Z.run(T, 2, 14, 2, 3, "\ud95d\udf19", "\ua9c7\u9d01\u155a\ud7d8\ua3a0\u11a6\uae07\u3040\u1936\u89df\u8a23\u824b", "\ud8f2\udffa\ud87c\udfbf\ud8e9\udfae\ud834\udc53\ud983\udfea\ud9ac\ude38\ud914\udea0\uda66\udf58\udaeb\udf08\uda65\udd96\uda9a\udfcc\ud819\uddd4",
        47, 50772, 351485879, -7986369276494852184L, 76367L, true, true, (char) 33805, (char) 39253,
        Double.longBitsToDouble(0x3fe73766f3af2da2L), Double.longBitsToDouble(0x3fe9e02540daeeddL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<int[], java.lang.Comparable, java.lang.Object> |a2=[Ljava.lang.reflect.Type;:[[class [I, interface java.lang.Comparable, class java.lang.Object]]\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 14, 11, 3, "\ud95d\udf19", "\u9ac5\u9d01\u1754\u2839\u04d8\u514e\ub614\u7ac7\u9a81\u2f45\ua388\u824b", "\ud8f2\udffa\uda05\udc3a\ud8e9\udfae\ud832\udd36\ud983\udfea\ud8dd\udcd0\ud8be\ude1c\uda5f\udeff\udaeb\udf08\uda65\udd96\ud8fd\udd5c\uf44f",
        47, 50772, 351485879, -7986369276494852184L, 76328L, true, true, (char) 33805, (char) 24224,
        Double.longBitsToDouble(0x3fe108c9cbaf2d0aL), Double.longBitsToDouble(0x3fe9e02540da6162L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Thread$State<java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Thread$State<java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList]]\012",
        Z.run(T, 2, 14, 14, 0, "\ud8a1\udefb", "\uca22\u067d\u9737\u2c29\u1de8\u1be7\ub614\u7b37\ub368\u2f45", "\ud96b\udc55\ud9c2\udc00\ud8f2\udffa\uda05\udc3a\uda02\ude4e\ud834\udc53\ud983\udfea\ud8dd\udc93\ud8de\uddb3\uda5f\udeff\udaeb\udf08\udb2a\ude79\ud923\udeca\uf440\udbc0\udfc2\ud958\ude05\ud80a\udcf3\udb9c\udcec\ud873\ude17\ud91d\udc1d\uda27\udd61\ud926\udeec\udae7\udd1f\uda20\udd88\ud9f8\udcc8\ud8e4\udff5\ud899\udcf9\ud808\udc9a\udbd9\ude9c\ud840\udf00\u25a6\udaa5\uddee\ud9d4\udeb1\u3a9d\ud8d2\ude1a\ud932\ude4c\udbcc\udd21\ud8f5\udec8",
        -5, 2825, 718293241, 8050054327782399881L, -40426L, false, false, (char) 37727, (char) 37908,
        Double.longBitsToDouble(0x3fdfe9c1a2b6bc92L), Double.longBitsToDouble(0x3fee13dba6da3f1bL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<java.util.ArrayList, java.lang.Comparable, java.lang.Object> |a2=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, interface java.lang.Comparable, class java.lang.Object]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.Comparable<java.util.ArrayList, java.lang.Comparable, java.lang.Object> |a2=[Ljava.lang.reflect.Type;:[[class java.util.ArrayList, interface java.lang.Comparable, class java.lang.Object]]\012",
        Z.run(T, 2, 14, 14, 3, "\ud95d\udf19", "\u9ac5\u9d01\u1754\u0925\u058d\u514e\ub614\u7b37\u9a81\u2f45\ua388\u824b", "\ud8f2\udffa\uda05\udc3a\ud8e9\udfae\ud834\udc53\ud983\udfea\ud8dd\udcd0\udb33\udd97\uda66\udf22\udbff\udc96\uda65\udd96\ud8fd\udd5c\udb57\udd92",
        23, 50772, 351485879, -7986369276494852184L, 76328L, true, true, (char) 33805, (char) 24224,
        Double.longBitsToDouble(0x3fe108c9cbaf2d0aL), Double.longBitsToDouble(0x3fe9e02540da6162L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String[]<java.lang.String[], java.lang.String[], java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class [Ljava.lang.String;, class java.util.ArrayList]]\0121=com.google.gson.internal.$Gson$Types$GenericArrayTypeImpl:java.lang.String[][]\012",
        Z.run(T, 2, 14, 0, 13, "\ud95d\udf19\ud940\ude43\uda46\ude89\ud862\ude6a", "\u2839\u04d8\u514e\ub614\u7b37\u9a81\u2f45\ua388\u2445\u7aa3\u82bc\u910a\u3881\ubc76\u7dc9\u8249\u372e\u140c\uaef2\u855a\u9e57\u6e48\u66ba\uc574\u7fb4\u788b\uac18\ub959\u0089\uba42", "\uda20\udd88\ud9f8\udcc8\ud8e4\udff5\ud899\udcf9\u2814\udb3d\udd96\udaf7\udce1\ud85a\udf72\udbdf\udd3a\ud8a8\udd0e\udbee\udf1e\uda9f\udf84\udad9\udc96\ud84f\uddd4\ud9c5\udf87\ud99d\udcea\ud995\udcfd\ud8e5\udd52\u5670\udaff\udd66\uda99\udfee",
        20, 43588, 1174816295, 6441622714652374842L, -16628L, true, true, (char) 33105, (char) 12565,
        Double.longBitsToDouble(0x3fe3d55ca28f402dL), Double.longBitsToDouble(0x3fe429a0c9b72239L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:int\012",
        Z.run(T, 2, 8, 10, 7, "\u69df", "\u9e75\u2aee\u024e\u1a54\u5dd7\u514e\u934a\u1795\u673e\ud4d5\u72ef\uad84", "\ud80c\udf0e\uda05\udc4b\udad9\udf9a\udbfd\udde5\ud85d\udd36",
        58, 12301, -268819891, -6406945585021929662L, 11471L, true, false, (char) 4452, (char) 35169,
        Double.longBitsToDouble(0x3fe95c41a8c78b38L), Double.longBitsToDouble(0x3fcaadbf0c151044L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 11, 8, 7, "\u694a\ud890\udc80\uda46\ude89\ud922\udca9\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ub8d3\uc621\u0a1d\u564a\u05a4\u3181\u3953", "\ud939\udeca\ud8e7\udf2e\ud83c\udcf1\ud8e6\udd5b\ud8ea\udf44\ud99f\udf68\u380e\ud986\udfe1",
        -5, 22743, -1239410001, 161984200152763032L, -26431L, true, true, (char) 9632, (char) 7221,
        Double.longBitsToDouble(0x3fea1ca21bffff3aL), Double.longBitsToDouble(0x3fe1a42038735d71L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 11, 8, 7, "\u698d\udbaa\uddad\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\ud4d5\ub720\u79d5\u9cdf\ua5eb\u30e2\u3953", "\ud999\udd6e",
        46, 51829, -268819891, -6589953007633123850L, -54700L, true, false, (char) 18712, (char) 37678,
        Double.longBitsToDouble(0x3fc11842ea6008fcL), Double.longBitsToDouble(0x3f64aaa038841100L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Class:[I\0121=java.lang.Class:[I\012",
        Z.run(T, 2, 11, 11, 10, "\u698d\udb7a\ude96\uda46\ude97\ud82e\udf90\uda4c\udced", "\u5dd7\u514e\u934a\u87c9\u6801\ud4d5\u3ebf\u0935\ua79f\u7683\u31a2\u3953\u8c28", "\ud985\ude5f\udbed\ude37\ud8e6\udd5b\udb65\udf14\udaba\udcfe\ud954\ude7b\ud8ce\udf8d\udb51\udfaf",
        33, 12319, -932011221, 8166272810622333371L, -61936L, false, true, (char) 23053, (char) 55576,
        Double.longBitsToDouble(0x3fa8d8dbc35caa40L), Double.longBitsToDouble(0x3fdeb00eb262a192L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String[]<java.lang.String[], java.lang.String[], java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class [Ljava.lang.String;, class java.util.ArrayList]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String[]<java.lang.String[], java.lang.String[], java.util.ArrayList> |a2=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class [Ljava.lang.String;, class java.util.ArrayList]]\012",
        Z.run(T, 2, 14, 14, 8, "\ud95d\udf19\ud940\ude43\ud812\ude8f\ud862\ude6a", "\u7d39\u04d8\u514e\ub614\u7b37\u9a81\u2f45\ua388\u2445\u7aa3\u82bc\u910a\u3881\ubc76\u7dc9\ud49a\u5fbc\u8256\u7098\u855a\u9e57\u6e48\u66ba\u04c9\u7f77\u788b\uac18\ub959\u0089\uba42", "\uda20\udd88\ud9f8\udcc8\ud8e4\udff5\ud81e\udf49\udb3d\udf09\udb3d\udd96\udaf7\udce1\ud85a\udf72\udbdf\udd3a\ud8a8\udd0e\udbee\udf1e\ud817\uddc0\udad9\udc5b\ud84f\uddd4\ud9c5\udf87\ud99d\udcea\ud995\udcfd\ud8e5\udd52\u5670\udaff\udd66\uda99\udfee",
        20, 43588, 1174816295, 6441622714652374842L, -16628L, true, true, (char) 33105, (char) 12565,
        Double.longBitsToDouble(0x3fe3d55ca28f402dL), Double.longBitsToDouble(0x3fe429a0c9b72239L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 7, "\u698d\ud940\uddb8\uda46\ude89\ud862\ude6a\uda4c\udd12\ud993\udcef\ud9fc\udc6e\ud83d\udfd1\udb7d\udcdf", "\u673e\u585b\ub720\u79d5\u0a24\u7683\u1743\u4120", "\ud85d\udd36\ud901\udd14\ud962\udd4e",
        -1, 47848, -1786595850, 234146780716773620L, 40135L, true, false, (char) 11104, (char) 61439,
        Double.longBitsToDouble(0x3fc5854e40e21044L), Double.longBitsToDouble(0x3fda4874917b3ac8L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Class:java.util.ArrayList\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 10, 4, 14, "", "", "",
        -5, 79976, 241, -1218904064L, 44640L, false, false, (char) 15202, (char) 63768,
        Double.longBitsToDouble(0x3f45001800000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Comparable<java.lang.Long>\0121=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Comparable<java.lang.Long>\012",
        Z.run(T, 2, 11, 11, 7, "\uda8c\uded4\udbc8\udc3b\udadb\uddd0", "\u047a\ucd9e\u5e49\u08a2\u634e\u0973\u6bb9\u5351\ub720\u79d5\u9cdf\u7683\u896a\uc5ab\u7481\u9e04\u3ccb\u016c\uc6e5\ub4c4\u982d\u74ab\uc6ea\u82ef\u2693\u9735\u5b35\u93c6\uc715\u1b1f\u2f1c\u04c5\ucfe2\u4797\u78ea\u02f8", "\ud93f\ude7d",
        25, 71692, 112832532, 7149647748587937345L, -39446L, true, false, (char) 23249, (char) 54188,
        Double.longBitsToDouble(0x3fec1e689ff6b990L), Double.longBitsToDouble(0x3fb27de3457bb650L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 8, 8, 7, "\u68fc\ud9d6\uddc2\uda01\udec7\ud862\ude6a\ud9a7\udc5f\udb3d\udc98\ud943\ude42", "\u5bb2\ucee0\u584f\ua07b", "\000\u0dea\ud925\ude86\ud886\udcad\ud80c\udc84\udacd\udddd\ud85d\udd36\ud985\ude5f\ud95f\udc15\ud8e6\udd5b\ud8ea\udf44\uda31\ude07\udafe\udfe6\udab1\udef5",
        31, 92087, 1484363065, 2766808848576514643L, -14990L, false, false, (char) 38581, (char) 16158,
        Double.longBitsToDouble(0x3fcf7a1a632ec770L), Double.longBitsToDouble(0x3fda26b59575839aL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Comparable\0121=java.lang.Class:java.lang.Comparable\012",
        Z.run(T, 2, 8, 8, 7, "\uce8d\udab4\udfd3\uda1b\udfa6\ud862\ude6a\uda4c\udd12\ud993\udcef\udbd5\udeda\ud829\udfc8\ud819\udfc7\ud972\udd3e\udb7d\udf6e\ud8dc\udcaf\ud896\udd0b\uda76\udfea\ud85d\uddab\udbff\udddc\ud95e\udf4e\ud9d2\ude6a", "\u7146\u3d8d", "\ud951\udf31\ud9a2\udfe9\ud9b0\udfb6\u6373\uda09\ude62\udb51\udf6b\udbeb\udcef\udae2\udcac\ud84c\uddf5\udb1b\udf47\ud904\udd5e",
        37, 78213, -661152106, 992952545979368486L, 71572L, true, false, (char) 51998, (char) 5828,
        Double.longBitsToDouble(0x3f98b72a5aab6060L), Double.longBitsToDouble(0x3fd0e9d6d18db562L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 14, "", "", "",
        5, 79976, 241, -1218904064L, 44640L, false, false, (char) 15202, (char) 63768,
        Double.longBitsToDouble(0x3f45000800000000L), Double.longBitsToDouble(0x3fd6baefb001979eL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String[]<java.lang.String[], java.lang.String[], int[]> |a2=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class [Ljava.lang.String;, class [I]]\0121=com.google.gson.internal.$Gson$Types$ParameterizedTypeImpl:java.lang.String[]<java.lang.String[], java.lang.String[], int[]> |a2=[Ljava.lang.reflect.Type;:[[class [Ljava.lang.String;, class [Ljava.lang.String;, class [I]]\012",
        Z.run(T, 2, 14, 14, 8, "\ud95d\udf19\ud940\ude43\ud812\ude8f\ud862\ude6a", "\u7d39\u04d8\u514e\ub614\u7b37\u9a81\u2f45\ua388\u2445\u7aa3\u82bc\u910a\u3881\ubc76\u7dc9\ud49a\u5fbc\u8256\u7098\u855a\u9e57\u6e48\u66ba\u04c9\u7f77\u788b\uac18\ub959\u0089\uba42", "\uda20\udd88\ud9f8\udcc8\ud8e4\udff5\ud81e\udf49\udb3d\udf09\udb3d\udd96\udaf7\udce1\ud85a\udf72\udbdf\udd3a\ud8a8\udd0e\udbee\udf1e\ud817\uddc0\udad9\udc5b\ud84f\uddd4\ud9c5\udf87\ud99d\udcea\ud995\udcfd\ud8e5\udd52\u5670\udaff\udd66\uda99\udfee",
        20, 43588, 1174839335, 6441622714652374842L, -16628L, false, true, (char) 33105, (char) 12565,
        Double.longBitsToDouble(0x3fe3d55ca28f402dL), Double.longBitsToDouble(0x3fe429a0c9b72239L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 7, "\u68fc\ud8a7\ude0d\udb7a\udd44\ud9e2\udcca,\ud986\ude83\ud9fc\udc6e", "\000", "\u03c6\u0578\000\000\ud830\udcd8",
        7, -1000, 0, 6500275377161682974L, 51299L, true, false, (char) 47266, (char) 22923,
        Double.longBitsToDouble(0x3ec0400000000000L), Double.longBitsToDouble(0x3fc42000015ddb0cL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 5, 13, 7, "\uda2c\udfa4\ud8a7\udf0f\udb7a\udd44\ud9e2\udcca,\ud986\ude83\ud9ec\ude6e", "\u00bb", "\u03c6\udb07\udcf9\ud8ba\udf4b\uda1a\udd3c\udafd\udcdd",
        7, 81416, 908453891, -590459667221882036L, 51513L, true, false, (char) 578, (char) 51928,
        Double.longBitsToDouble(0x3fe983b6c8000063L), Double.longBitsToDouble(0x3fc42000015ddb0cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.$Gson$Types|arrayOf|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|canonicalize|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|checkNotPrimitive|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|declaringClassOf|java.lang.reflect.TypeVariable|static",
    "M|com.google.gson.internal.$Gson$Types|equal|java.lang.Object,java.lang.Object|static",
    "M|com.google.gson.internal.$Gson$Types|equals|java.lang.reflect.Type,java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|getArrayComponentType|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|getCollectionElementType|java.lang.reflect.Type,java.lang.Class|static",
    "M|com.google.gson.internal.$Gson$Types|getGenericSupertype|java.lang.reflect.Type,java.lang.Class,java.lang.Class|static",
    "M|com.google.gson.internal.$Gson$Types|getMapKeyAndValueTypes|java.lang.reflect.Type,java.lang.Class|static",
    "M|com.google.gson.internal.$Gson$Types|getRawType|java.lang.reflect.Type|static",
    "M|com.google.gson.internal.$Gson$Types|getSupertype|java.lang.reflect.Type,java.lang.Class,java.lang.Class|static",
    "M|com.google.gson.internal.$Gson$Types|hashCodeOrZero|java.lang.Object|static",
    "M|com.google.gson.internal.$Gson$Types|indexOf|[Ljava.lang.Object;,java.lang.Object|static",
    "M|com.google.gson.internal.$Gson$Types|newParameterizedTypeWithOwner|java.lang.reflect.Type,java.lang.reflect.Type,[Ljava.lang.reflect.Type;|static",
    "M|com.google.gson.internal.$Gson$Types|resolve|java.lang.reflect.Type,java.lang.Class,java.lang.reflect.Type,java.util.Collection|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
