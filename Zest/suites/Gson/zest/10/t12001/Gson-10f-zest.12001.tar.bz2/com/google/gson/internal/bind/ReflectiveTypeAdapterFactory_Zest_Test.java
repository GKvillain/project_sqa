package com.google.gson.internal.bind;
import org.junit.Test;
import static org.junit.Assert.*;
public class ReflectiveTypeAdapterFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 6, 3, "\udbeb\udedd\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d\ud82f\udf62\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\ub366\u61c2\u6b2e\u3e14\u9605\u013d\u4a7a\u9781\u274f\u383f\u6537\u7178\u5f02\u946f\u20ad\u1fb0\ub4fcF\u034d\ud14f\ud346\u8553\u5ba7\ubb1b\u9ea7\u91fa\ua2e7\u3f60\u428c\u84c5\uca12\u56c2\u5c2f\u3286\u2973\u4cd1\u7ef9\u7b8d\u7fac", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\uda13\udfd2\udb90\udef6\ud82d\ude5e\uda58\ude74\ud8c5\udfc0\uda9a\ude60\ud8ed\udeb8\uac41\uda55\uddb3\ud913\udc88\udb1a\udc77\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\udb55\udc23\ud895\udc1e\ud9e7\uded5",
        41, 88194, -1203310905, -4910341161266427855L, 58082L, false, false, (char) 10613, (char) 7563,
        Double.longBitsToDouble(0x3fed537b5adb9417L), Double.longBitsToDouble(0x3fe1d7db580ab025L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 5, "\u35fb\ud9f3\udfdf\udb97\udfa8\udb5b\udc90\uda65\udf67\ud82f\udf62", "\u7afe\u3f38\u25a1\u823c\u0429\u0bd3\u846d\u7668\u2fd6\u8b03\u5a40", "\uda32\udd59\u9b25\uda23\uddfe\udab3\udc59\uda97\udd29\ud831\udc7c\udaf7\udd47\udab9\udd44\udac9\udeae\ud96a\udcf8\udbaf\udfb0\ud8b1\uddc9\ud879\udfab",
        3, 43892, -444721089, -9010302371172716022L, -70572L, false, false, (char) 50928, (char) 55265,
        Double.longBitsToDouble(0x3fd8bbda4ab8c5ccL), Double.longBitsToDouble(0x3fefacb634adc4beL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 3, "\udbeb\udedd\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d\ud82f\udf62\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\ub366\u61c2\u6b2e\u6d82\u9605\u013d\u4a7a\u9781\u274f\u383f\u6537\u7178\u5f02\u946f\u20ad\u1fb0\ub4fcF\u034d\ud14f\ud346\u8553\u5ba7\ubb1b\u9ea7\u91fa\ua2e7\u3f60\u428c\u84c5\uca12\u56c2\u5c2f\u3286\u2973\u4cd1\u7ef9\u7b8d\u7fac", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\uda13\udfd2\udb90\udef6\ud82d\ude5e\uda58\ude74\ud8c5\udfc0\uda9a\ude60\ud8ed\udeb8\uac41\ud967\ude24\ud940\udd1c\uda42\udd40\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\udb55\udc23\ud895\udc1e\ud9e7\uded5",
        41, 25170, -985207213, -4361113332003102341L, 58082L, false, false, (char) 10613, (char) 7563,
        Double.longBitsToDouble(0x3fed537b5adb9417L), Double.longBitsToDouble(0x3fe1d7db580ab025L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\012",
        Z.run(T, 1, 6, 5, 3, "\udbeb\udedd\u3a71\udbd2\udc2c\udb5b\udc90\ud8da\udc6d\ud82f\udf62\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\ub366\u61c2\u6b2e\u3e14\u9605\u013d\u4a7a\u9781\u274f\u723f\u3b72\ucbd6\u5f02\u946f\u20ad\u1fb0\ub4fcF\u034d\ud14f\ud346\u8553\u5ba7\u878d\u83bb\u8f67\ua2e7\u3f60\u198b\u84c5\uca12\u56c2\u5c2f\u3286\u2973\u4cd1\u7ef9\u42b2\u7fac", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\uda13\udfd2\udb90\udef6\ud81b\ude5e\ud946\udc4b\ud8c5\udfc0\uda9a\ude60\ud8ed\udeb8\uac41\ud97f\udc09\ud913\udc88\udb1a\udc77\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\udb55\udc23\ud895\udc1e\ud9e7\uded5",
        41, 88322, -1203310905, -4910341161266427855L, 58082L, false, false, (char) 10613, (char) 7563,
        Double.longBitsToDouble(0x3fed537b5adb9417L), Double.longBitsToDouble(0x3fe1d7db580ab025L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 6, 3, "\udbde\udf9a\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d", "\uad65", "\udb3e\udeb8",
        -3, 20293, -830374384, -7698137885731019766L, 38556L, true, true, (char) 841, (char) 44656,
        Double.longBitsToDouble(0x3fee18e748b9d71eL), Double.longBitsToDouble(0x3fd9c065973deb16L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 3, "\udbeb\udedd\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d\ud82f\udf62\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\ub366\u61c2\u6b2e\u3e14\u9605\u013d\u4a7a\u9781\u274f\u383f\u6537\u7178\u5f02\u946f\u20ad\u1fb0\ub4fcF\u3b2e\u0d91\ud346\u8553\u5ba7\ubb1b\u9ea7\u51b2\ua2e7\u3f60\u428c\u84c5\uca12\u56c2\u5c2f\u3286\u2973\u4cd1\u7ef9\u7b8d\u7fac", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\uda13\udfd2\udb90\udef6\ud82d\ude5e\uda58\ude74\ud8c5\udfc0\uda9a\ude60\ud8ed\udeb8\uac41\uda55\uddb3\ud913\udc88\udb1a\udc77\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\udb55\udc23\ud895\udc1e\ud9e7\uded5",
        41, 88194, -1203310905, -4910341161266427855L, 58082L, false, false, (char) 10613, (char) 7563,
        Double.longBitsToDouble(0x3fed537b5adb9417L), Double.longBitsToDouble(0x3fe1d7db580ab025L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\012",
        Z.run(T, 1, 6, 6, 2, "\ud948\uddad\u3a6c\udad2\udc2c\udb5b\udc90\udb1e\udfae\ud849\udd58\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\ub366\u61c2\u6b2e\u3e14\u9605\u013d\u4a7a\u9781\u274f\u383f\u6537\u7178\u5f02\u946f\u20ad\u1fb0\ub4fcF\u034d\ud14f\ud704\u0b08\u5ba7\ubb1b\u9ea7\u91fa\ua2e7\u3f60\u428c\u84c5\uca12\u56c2\u5c2f\u8ac7\u2973\u4cd1\u7ef9\u7b8d\u7fac", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\uda13\udfd2\udb06\udcaa\ud82d\uddf0\uda58\ude74\ud8c5\udfc0\udaa8\ude60\udac8\ude25\uac41\uda55\uddb3\ud913\udc88\udb1a\udc77\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\udb55\udc23\ud895\udc1e\ud9e7\uded5",
        41, 88220, 399221039, 8138628473036027179L, 58082L, false, false, (char) 10613, (char) 14166,
        Double.longBitsToDouble(0x3fed537b5adb9417L), Double.longBitsToDouble(0x3fe1d7db580ab025L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 3, 4, "\udbeb\udedd\u3a6c\udba7\udf77\ud9d4\udc7e\udb66\udf0f\ud82f\udeaf\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\ub366\u1c4d\ub748\u85da\u9605\u013d\u4a7a\u9781\u274f\u383f\u6537\u7178\u5f02\u946f\u20ad\u1fb0\ub4fcF\u034d\ud14f\ud346\u8553\u5ba7\ubb1b\u9ea7\u91fa\ua2e7\u3f60\u428c\u84c5\u3343\u87b0\u5c2f\u310b\ubaba\u4cd1\u7ef9\u7b8d\u7fac", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\uda13\udfd2\udb90\udef6\ud82d\ude5e\uda58\ude74\ud8c5\udfc0\uda9a\ude60\ud8ed\udeb8\uac41\uda55\uddb3\ud913\udc88\udb1a\udc77\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\udb55\udc23\ud895\udc1e\ud9e7\uded5",
        41, 88194, -1203310905, -4910341161266427855L, 58082L, false, false, (char) 10672, (char) 7563,
        Double.longBitsToDouble(0x3fed537b5adb9417L), Double.longBitsToDouble(0x3fa2bdb580ab0460L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 4, "\u0227\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d", "\uad65", "\udb3e\udeb8",
        12, 20293, -830374384, -7698137885731019766L, 38556L, true, true, (char) 841, (char) 44656,
        Double.longBitsToDouble(0x3fee18e748b9d71eL), Double.longBitsToDouble(0x3fd9c0659597eb16L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 3, "\udbeb\udedd\udbe6\ude6b\udbd2\udc0c\udb5b\udc90\ud9ba\udcbc\ud82f\uded4\ud924\udf5c", "\uc583\ud228\u453a\u8596\ub366\uc471\u8484\u3d88\u9605\u013d\u4a7a\u9781\u274f\u383f\u6537\u7178\u5f02\u946f\u20ad\u1fb0\ub4fcF\u034d\ud14f\ud346\u8553\u4283\u8c35\u9ea7\u7b93\u440e\u3f60\u428c\u84c5\u6213\u56c2\u5c2f\u3286\u2973\u4cd1\u7ef9\u0ace\u7fac", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\ud97f\udfc8\ud9aa\udf82\ud9ea\uddc1\uda58\ude67\ud8c5\udfc0\uda0c\ude2b",
        5, 14561, 1857820461, -1350202876650433034L, -83724L, true, false, (char) 45775, (char) 51995,
        Double.longBitsToDouble(0x3fd661631485748aL), Double.longBitsToDouble(0x3fc409b4dccb9a60L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{} |this=com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\012",
        Z.run(T, 1, 4, 1, 2, "\u35fb\ud9f3\udfdf\ud8e2\udfa7\udb75\ude8c\udb6a\udcd6\ud82f\udf06\ud9f0\udf62", "\u3f38", "\ud9a1\udeaf\ud92e\udf31\uda8b\udcde",
        32, 82834, -752197423, -8083284581141979169L, -78422L, true, false, (char) 21597, (char) 9769,
        Double.longBitsToDouble(0x3fee6425864c8f6dL), Double.longBitsToDouble(0x3fac34805cb8a430L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 3, "\udbeb\udedd\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d\ud82f\udf62\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\ub366\u0e87\uc794\uc836\u9605\u013d\u4a7a\u9781\u7280\u5aaf\u6537\u7178\u5f02\u946f\ua4d6\u1fb0\ub4fcF\u034d\ud14f\ud346\u8553\u5ba7\ubb1b\u9ea7\u91fa\ua2e7\u3f60\u428c\u84c5\uca12\u56c2\u5c2f\u3286\u2973\u4cd1\u7ef9\u7b8d\u7fac", "\ud997\udfa0\ud8f8\ude5f\ud95e\udf27\ucfb3\udacf\udf25\uda13\udfd2\udb90\udef6\ud82d\ude5e\uda58\ude74\ud8c5\udfc0\uda9a\ude60\ud8ed\udeb8\uac41\ud967\ude24\ud940\udd1c\uda42\udd40\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\ud877\udfaf\u8674\ud9e7\uded5",
        41, 25170, 172420691, -4361113611175976581L, 68209L, false, false, (char) 31179, (char) 40394,
        Double.longBitsToDouble(0x3fb3504a0bc9e090L), Double.longBitsToDouble(0x3fed537b5adba717L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{} |this=com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 4, "\udaeb\ude50\u3a6c\udbc5\udc5d\udacb\udc16\ud8dc\uddea\udae0\udc55\ud924\udf5c\ud849\udc5c\ud926\udcfb\udb37\udf01", "\u8a0f\u787b\u7c15", "\ud980\udd28\ud8a9\udc7b\udabb\udf03\ud891\udc5c\udb63\udd65",
        50, 82821, 1395848094, -5811354469709087913L, 96556L, true, true, (char) 6117, (char) 47563,
        Double.longBitsToDouble(0x3fe5f4c937f0176fL), Double.longBitsToDouble(0x3fe242b58b02a503L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\012",
        Z.run(T, 2, 6, 6, 3, "\udbeb\udedd\u3a6c\udbd2\udc2c\udb51\ude06\ud8da\udc6d\ud832\udf98\udb79\uddf0", "\u3f38\u25a1\u453a\u8596\ub366\u61c2\u6b2e\u3e14\u9605\u013d\u4a7a\u9781\u274f\u383f\u6537\u7178\u5f02\u946f\u20ad\u1fb0\ub4fcF\u3b2e\u0d91\ud346\u8553\u5ba7\ubb1b\u9ea7\u51b2\ua2e7\u3f60\u428c\u84c5\uca12\u56c2\u5c2f\u3286\u2973\u4cd1\u7ef9\u7b8d\u7fac", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\uda13\udfd2\udb90\udef6\ud82d\ude5e\uda58\ude74\ud8c5\udfc0\uda9a\ude60\ud8ed\udeb8\uac41\uda55\uddb3\ud913\udc88\udb1a\udc77\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\udb55\udc23\ud895\udc1e\ud9e7\uded5",
        41, 88194, -1203310905, -4910341161266427855L, 58082L, false, false, (char) 10613, (char) 7563,
        Double.longBitsToDouble(0x3fed537b5adb9417L), Double.longBitsToDouble(0x3fe1d7db580ab025L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 0, "\ud919\udd56\ud9e7\udcb2\ud99a\uddb1\ud8b6\udc42\udb0a\udf0b", "\u4da4\u7013\u2a74\u82ba\u6727\u3a1e\ud0c2\ub2d0\u6b9c\ubcdf\u14bb\u013d", "\ud8cd\udd5a",
        47, 10092, 1873061186, -9221023287722935333L, -74769L, true, false, (char) 31256, (char) 18306,
        Double.longBitsToDouble(0x3fe4ae6cdf50f35dL), Double.longBitsToDouble(0x3fbbfd7ad3509c68L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 5, "\u35fb\uda11\udf70\ud82d\udd54\ud9da\udd91\ud9a6\udf02\ud82f\udf06\ud84b\udd6b", "\u3f38\uaf68\u8b28\u0429\u0bd3\uadce\u6a23\u8c07\u8bad\u9a8b\u38ed\u1528\u4ff1\u77de\u2eec", "\ud831\udc7c\udaf7\udd47\udbcd\udd85\ud9ae\udc5a\udb0b\uddb2\ud97d\udc1b\uda71\udfa7\udb7e\udc19\ud92d\uddda\udbdb\udfa6\udb17\udc5a",
        5, 32224, 455675646, 3614953010699052588L, -76238L, false, true, (char) 61653, (char) 27494,
        Double.longBitsToDouble(0x3fe9e4d483a3b874L), Double.longBitsToDouble(0x3fe31a4d467daa72L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{} |this=com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 2, "\u35fb\ud9f3\udfdf\ud8e2\udfa7\udb75\ude8c\ud8bb\udde0\ud975\udc74\ud870\udf12", "\u3f38", "\ud9a1\udeaf\ud92e\udf31\uda8b\udcde",
        32, 82834, -752197423, -8083284581141979169L, -78422L, false, false, (char) 21597, (char) 9769,
        Double.longBitsToDouble(0x3fee6425864c8f6dL), Double.longBitsToDouble(0x3fac34805cb8a430L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.LinkedHashMap:{} |this=com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=java.util.LinkedHashMap:{} |this=com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\012",
        Z.run(T, 2, 4, 4, 6, "\u35fb\udafe\udce3\udb9b\udde9\udb75\udebe\udb6a\udcd6\ud998\udc19\ud810\udf18", "\u3f38", "\udb19\udd5e\udbb6\ude04\ud985\udfe4",
        32, 41792, -434673496, -8116666694759096353L, -59722L, false, false, (char) 15107, (char) 37950,
        Double.longBitsToDouble(0x3fee642585fa8f6dL), Double.longBitsToDouble(0x3fe9c547b73b0558L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 6, "\udbeb\udedd\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d\ud8e3\ude64\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\ub366\u0e87\uc794\uc836\u9605\u013d\u4a7a\u9781\u7280\u96ed\u6537\uc766\u5e3f\u946f\ub523\u1fa6\ub4fcF\u034d\ud14f\ud346\u8553\u5ba7\ubb1b\u9ea7\u91fa\ua2e7\u3f60\u385e\u73e2\u9bc2\u56c2\u5c2f\u3286\u2973\u4cd1\u7ef9\uc9c5\uc541", "\ud997\udfa0\ud8f8\ude5f\ud95e\udf27\ucfb3\udacf\udf25\uda13\udfd2\udb90\udef6\ud82d\ude5e\uda58\ude74\udb5f\udf4d\ud805\udee1\udb77\udde4\uac41\ud967\ude24\ud940\udd1c\uda42\udd40\ud8fe\ude7a\ueba8\ud8b5\udd5f\udaf6\udd26\ud8ba\udebb\uda93\udcbe\udac3\ude84",
        55, 25170, 172420691, -4361113611175976581L, -6065L, false, false, (char) 31179, (char) 40394,
        Double.longBitsToDouble(0x3fb3504a0bc9e090L), Double.longBitsToDouble(0x3fed537b5adba717L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 1, "\udbeb\udedd\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d", "\uad65", "\udb3e\udeb8",
        37, 76107, -581856429, 5271117511533850100L, 23588L, true, true, (char) 841, (char) 31600,
        Double.longBitsToDouble(0x3fe1d6476917eeaaL), Double.longBitsToDouble(0x3fd9c06af73deb16L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 6, 3, "\udbeb\udedd\u3a6c\udbd2\udc2c\udb5b\udc90\ud8da\udc6d\ud82f\udf62\ud924\udf5c", "\u3f38\u25a1\u453a\u8596\u43fe\u61c2\uc42d\u3e14\u9605\u013d\u4a7a\u9781\u274f\u383f\u6537\u7178\u5f02\u946f\u20ad\u1fb0\ub4fc\u65e8\u98f3\ud14f\ud346\u8553\u5ba7\ubb1b\u9ea7\u91fa\ua2e7\u3f60\u428c\u84c5\uca12\u56c2\u5c2f\u3286\u2973\u4cd1\u3450\ud61b\u7ec8", "\ud89e\udd83\ud81e\udc72\ud95e\udf27\ud941\udcd7\udacf\udf25\uda13\udfd2\udb90\udef6\ud82d\ude5e\uda58\ude74\ud8c5\udfc0\uda9a\ude60\ud8ed\udeb8\uac41\uda55\uddb3\ud913\udc88\udb1a\udc77\ud8fe\ude7a\ueba8\udae7\udec1\udaf6\udd26\udb55\udc23\ud895\udc1e\ud9e7\uded5",
        41, 88194, -1203310905, -4910341161266427855L, 58082L, false, false, (char) 10613, (char) 7563,
        Double.longBitsToDouble(0x3fed537b5adb9417L), Double.longBitsToDouble(0x3fe1d7db580ab025L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|com.google.gson.internal.bind.ReflectiveTypeAdapterFactory|createBoundField|com.google.gson.Gson,java.lang.reflect.Field,java.lang.String,com.google.gson.reflect.TypeToken,boolean,boolean|new:com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:com.google.gson.internal.ConstructorConstructor,com.google.gson.FieldNamingStrategy,com.google.gson.internal.Excluder",
    "M|com.google.gson.internal.bind.ReflectiveTypeAdapterFactory|create|com.google.gson.Gson,com.google.gson.reflect.TypeToken|new:com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:com.google.gson.internal.ConstructorConstructor,com.google.gson.FieldNamingStrategy,com.google.gson.internal.Excluder",
    "M|com.google.gson.internal.bind.ReflectiveTypeAdapterFactory|excludeField|java.lang.reflect.Field,boolean|new:com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:com.google.gson.internal.ConstructorConstructor,com.google.gson.FieldNamingStrategy,com.google.gson.internal.Excluder",
    "M|com.google.gson.internal.bind.ReflectiveTypeAdapterFactory|excludeField|java.lang.reflect.Field,boolean,com.google.gson.internal.Excluder|static",
    "M|com.google.gson.internal.bind.ReflectiveTypeAdapterFactory|getBoundFields|com.google.gson.Gson,com.google.gson.reflect.TypeToken,java.lang.Class|new:com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:com.google.gson.internal.ConstructorConstructor,com.google.gson.FieldNamingStrategy,com.google.gson.internal.Excluder",
    "M|com.google.gson.internal.bind.ReflectiveTypeAdapterFactory|getFieldNames|java.lang.reflect.Field|new:com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:com.google.gson.internal.ConstructorConstructor,com.google.gson.FieldNamingStrategy,com.google.gson.internal.Excluder",
    "C|com.google.gson.internal.bind.ReflectiveTypeAdapterFactory|<init>|com.google.gson.internal.ConstructorConstructor,com.google.gson.FieldNamingStrategy,com.google.gson.internal.Excluder",
    "M|com.google.gson.internal.bind.ReflectiveTypeAdapterFactory|createBoundField|com.google.gson.Gson,java.lang.reflect.Field,java.lang.String,com.google.gson.reflect.TypeToken,boolean,boolean|new:com.google.gson.internal.bind.ReflectiveTypeAdapterFactory:com.google.gson.internal.ConstructorConstructor,com.google.gson.FieldNamingStrategy,com.google.gson.internal.Excluder",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
