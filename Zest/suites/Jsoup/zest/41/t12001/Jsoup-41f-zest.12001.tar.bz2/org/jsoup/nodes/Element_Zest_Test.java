package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Element_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 6, 6, "\udb4e\udf66\udb3e\udee8\ud969\ude8f\uda15\udff9\udab9\udde4\ud804\udd6e", "\u60c9\u66da\u5687\u8052\u397a\u51ff\u3cd9\uc81b\u7055\ud60d\u7087\ub7b7\u9398\u7300\u98ed\ud5c8\ua4cc\u31ec\ube5e\u4ddb\u4113\u8f84\u0f07\u639a\u7fef\u15de\u9d9f", "\uda3d\udecf\udb93\udfa9\ud96d\uddb4\ud9e0\udf74\ud8ac\udd06\udb45\udc7f",
        -1, 95354, 2078410511, 8257803846581639827L, 45090L, false, false, (char) 29592, (char) 15965,
        Double.longBitsToDouble(0x3fa1c2b7ff276310L), Double.longBitsToDouble(0x3fe03f5195faa815L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 6, 12, "\udaac\udfb4\udb82\udda4\ud93d\udd92\uda15\udff9\udab9\udde4", "\ua535\u60c9\u67a0", "\uda52\udd5d\udbfa\udc84\ud900\udebe",
        32, 9832, -1580221008, 211964999205483498L, 62940L, false, true, (char) 28544, (char) 58889,
        Double.longBitsToDouble(0x3fca0fc401aae840L), Double.longBitsToDouble(0x3fc853f8f45de9b0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 7, 6, "\u97f3\uda81\udd6b\ud947\uddba\ud834\udffb\ud955\ude02\udaf1\udc3b", "\u60c9\u66da\u5687\u8052\u397a\u51ff\u3cd9\uc81b\ube8d\ud60d\u7087\ub7b7\u9398\u7300\u98ed\ud5c8\ua4cc\u31e3\ube5e\u4ddb\u4113\u8f84\u0f07\u639a\u7fef\u15de\u9d9f", "\uda3d\udecf\udb93\udfa9\ud96d\uddb4\ud9e0\udf74\ud837\udd8c\udb45\udc7e",
        -1, 95354, 2078410511, 187353314333695032L, 45090L, false, false, (char) 29592, (char) 15965,
        Double.longBitsToDouble(0x3fe91c2b7ff27624L), Double.longBitsToDouble(0x3fe03f5195faa815L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 6, 6, "\udb4e\udf66\udb3e\udee8\ud969\ude8f\uda15\udff9\udab9\udde4\ud804\udd6e", "\u60c9\u66da\u5687\u8052\u397a\u51ff\u3cd9\uc81b\u7055\ud60d\u7087\u05b8\u9398\u7300\u98ed\ud5c8\ua4cc\u31ec\ube5e\u4ddb\u4113\u8f84\u0f07\u4956\u7fef\u15de\u9d9f", "\uda3d\udecf\udb93\udfa9\ud96d\uddb4",
        52, 43091, 826071449, -5630178164371397422L, 5689L, true, false, (char) 14092, (char) 32685,
        Double.longBitsToDouble(0x3fa0028b04623520L), Double.longBitsToDouble(0x3fc89533208e15bcL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 10, 6, "\udb4e\udf66\udb3e\udee8\ud969\ude8f\uda15\udff9\udab9\udde4\ud804\udd6e", "\u60c9\u66da\u5687\u8052\u397a\u51ff\u3cd9\uc81b\u7055\ud60d\u0ae6\ub7b7\u9398\u7300\u98ed\ud5c8\ua4cc\u31ec\ube5e\u4ddb\u4113\u8f84\u0f07\u639a\u7fef\u785d\u9d96", "\uda3d\udecf\udb93\udfa9\udaa7\udff1\udbfe\ude1a\ud8ac\udc88\udb45\udc7f",
        -1, 95354, 2078410511, 8257803846581639827L, 45090L, false, false, (char) 29592, (char) 15965,
        Double.longBitsToDouble(0x3fa1c2b7ff276310L), Double.longBitsToDouble(0x3fe03f5195faa815L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 5, 11, "\ud998\ude4b\ud971\udc3f\ud969\ude8f\uda15\udff9\udab9\udde4\ud804\udd6e\uda87\udd99", "\u66da\u5687\u8052\u397a\u4dd9\uaf6b\uc81b\u7055\ud60d\u7087\ub7b7\u9398\u7300\u98ed\ud5c8\u198a\uba66\ube5e\u4ddb\u4113\u8f84\u0f07\u639a\u5208\u8f19\u66fd", "\uda44\ude8d\udb93\udfa9\ud96d\uddb4\ud9e0\udf74\ud8ac\udd06\udb45\udc7f",
        -1, 95354, 2078410511, 8257803846581639827L, 45090L, false, false, (char) 29592, (char) 15965,
        Double.longBitsToDouble(0x3fa1c2b7ff276310L), Double.longBitsToDouble(0x3fe03f5195faa815L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 6, "\udb4e\udf66\udb3e\udee8\ud969\ude8f\uda15\udff9\udab9\udde4\ud804\udd6e", "\u60c9\u66da\u5687\u8052\u397a\u51ff\u3cd9\uc81b\u7055\u5954\u7127\ub7b7\u9398\u7300\u98ed\ud5c8\ua4cc\u31ec\ube5e\u4ddb\u4113\u8f84\u0f07\u639a\u7fef\u15de\u9d9f", "\uda3d\udecf\udb93\udfa9\ud96d\uddb4\ud9e0\udf74\ud8ac\udd06\udb45\udc7f",
        -1, 95354, 2078410511, 8257803847437998739L, 45090L, false, false, (char) 29592, (char) 36445,
        Double.longBitsToDouble(0x3fa1c2b7ff276310L), Double.longBitsToDouble(0x3fe03f519094d2baL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 3, "\udb4e\udf66\udb3e\udee8\ud969\ude8f\uda30\udcbf\udab9\udd56\ud804\udd6e", "\u60c9\u66da\u5687\u8052\u397a\u51ff\u3cd9\uc81b\u7055\ud60d\u7087\ub7b7\u9398\u7bad\u98ed\ud5c8\ua4cc\u31ec\ube5e\u4ddb\u4113\u8f84\u0f07\u639a\u7fef\u0cdd\u9d9f", "\uda3d\udecf\udb93\udfa9\ud96d\uddb4\ud9e0\udf74\ud9f1\udc6b\udb15\uddc0",
        -1, 95354, 2078410511, 8257803846581639827L, -12238L, false, false, (char) 29592, (char) 15965,
        Double.longBitsToDouble(0x3fa1c2b7ff276310L), Double.longBitsToDouble(0x3fe03f5195faa815L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 6, 6, "\udb4e\udf66\udafd\udeee\ud969\udee4\uda15\udff9\udab9\udde4\ud931\udee5", "\u60c9\u66da", "\uda52\udd5d\udbe2\udf4f\ud829\udc38",
        23, 9832, -1580221008, 211964999205483498L, 62940L, true, true, (char) 28544, (char) 58889,
        Double.longBitsToDouble(0x3fca0fc401aae840L), Double.longBitsToDouble(0x3fc853f8f45de9b0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Element|equals|java.lang.Object|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|accumulateParents|org.jsoup.nodes.Element,org.jsoup.select.Elements|static",
    "M|org.jsoup.nodes.Element|addClass|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|after|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|after|org.jsoup.nodes.Node|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|append|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendChild|org.jsoup.nodes.Node|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendElement|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendNormalisedText|java.lang.StringBuilder,org.jsoup.nodes.TextNode|static",
    "M|org.jsoup.nodes.Element|appendText|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendWhitespaceIfBr|org.jsoup.nodes.Element,java.lang.StringBuilder|static",
    "M|org.jsoup.nodes.Element|attr|java.lang.String,java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|before|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|before|org.jsoup.nodes.Node|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|child|int|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|children||new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|equals|java.lang.Object|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
