package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class Tokeniser_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ua0fc", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\udf04\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udd90\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\ud93f\udf9e\ud8f5\udd5a", "\u9baa\uae85", "\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05",
        -2, 27739, 1714284175, -1920947593760021655L, 59252L, true, true, (char) 31031, (char) 16372,
        Double.longBitsToDouble(0x3febfda75661095dL), Double.longBitsToDouble(0x3fa720761b2e60f0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 9, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud92c\udec3\uda99\udc0d\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud917\udcf3\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\ud841\udea3\ua0fc", "\u80a7\u4e33\u559e\u1041\uc538\ua0ee\u1ca7\u4184\u7553", "\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05",
        -2, 39403, -1747344627, -1920947690078018711L, 7886L, true, true, (char) 2197, (char) 16600,
        Double.longBitsToDouble(0x3febfda75061095dL), Double.longBitsToDouble(0x3fa2bc7b42c47380L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 3, "\udae0\udcbd\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\ud8b6\uddf3\udb1d\udfc6\ud9bd\udd9b\u53a1\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\ud96e\uddd5\uda71\ude3a\uda75\udd90\udbfa\ude28\u02b2\udabf\udd9e\ua0fc", "\u9baa", "\udbd4\ude72\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\ud8e6\udec4\ud9d4\udf0d\u21f5\ud94d\ude65\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 0, "\udadc\udfe2\uda3b\udd9a\ud9a2\udec9\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ua0fc", "\u225f", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\uda0f\ude74\ud9d9\udec2\uda07\udc94\udb36\udec4\ud828\udcff\udb7b\udee5\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 409194348, -5210685608140588486L, -51677L, false, false, (char) 7486, (char) 16477,
        Double.longBitsToDouble(0x3fdb6fc91a38e654L), Double.longBitsToDouble(0x3fe17e2d7eaffd26L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 10, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ua0fc", "\u9baa\u776c\u563a\u1041", "\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0",
        35, 99078, 84521395, 1261622363435474208L, 74251L, true, false, (char) 53892, (char) 51392,
        Double.longBitsToDouble(0x3fe417265292f735L), Double.longBitsToDouble(0x3fdbd354e28ffe9aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 6, 2, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\ud97b\udc19\u156f\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\ud847\udfa9\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\uda96\udfaa\udaf6\uddb8", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda3e\udd4c\ud9cd\udc3d",
        0, 43172, 1401933676, -9055393718516172230L, 61038L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 0, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\ud928\udea0\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udab5\udd73\ua0fc", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda93\udd63\ud894\udf05\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udad7\udfb6\ud9db\ude8f\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 10, 9, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c", "\u3af5\u38f9\u7e5d\ubcae\uc6be", "\ud89e\udf31",
        45, 48708, -1225821715, -7245430982890637289L, -45245L, false, true, (char) 64372, (char) 64619,
        Double.longBitsToDouble(0x3fcb106d57266c78L), Double.longBitsToDouble(0x3fd8f38cb3a59938L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\udb3d\udf96\ud97c\ude42\uda7a\udd16\ud9c4\uddb9\udbff\udecb\u154c\udacb\udfe6\udaa9\uddfa\ub50d\ud920\ude52\uda26\udd9b\udb59\udc12\ud81e\uddf7\uda7c\udd38\u879a\u02b2\udabf\udd22\udb15\udd94", "\u9baa", "\ud81c\udcb1\ud969\udf7b\udb5e\udcd0\udad7\ude87\ud9a0\ude5d\ud894\udf48\u3f6e\ud9dd\uddd0\ud87a\udff3\uda6e\udcfa\ud9eb\ude8b\ud85d\udfe3\ud917\udd04\ud9e5\udc88\udbdc\udfa6\uda07\udc94\ud86d\udce0\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud982\uded1\ud9dc\udf70\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d\ud895\udd20",
        23, 52676, -1213207196, -393437995641861325L, -17551L, true, true, (char) 57378, (char) 20450,
        Double.longBitsToDouble(0x3fe8e5ca0e66d02eL), Double.longBitsToDouble(0x3fe8ee662cd28561L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 0, "\udadc\udfe2\ud896\udea6\udb62\udddb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udb67\udff3\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9f9\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ua0fc", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud831\udc8e\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\udbb2\udc3e\ud9c6\uddc3\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\udb7a\ude55",
        52, 13327, 1401926477, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\u909a\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\udb0a\udfe4\ud83f\udc55\udb79\udf97\ua0fc", "\u79aa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 12132, 1401933676, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 10, "\udadc\udfe2\uda48\ude60\uda39\udcf9\ud8e8\udc01\ud8f4\ude98\uda77\udf4e\udbc5\udd80\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\ud9ee\uddbe\ud89e\udf31\u879a\u02b2\udabf\udd9e\ua0fc", "\u9a9c\u75a6\u563a\u1041\uc538", "\ud986\uddca\ud894\udee5\u3f6e",
        30, 34290, -627614922, 6199681744703205083L, 78784L, true, false, (char) 50733, (char) 52306,
        Double.longBitsToDouble(0x3feb4f2abe82e4caL), Double.longBitsToDouble(0x3fe497b9a9bd354eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\udb64\udc3b\udbf8\uddbc\uda17\udc03\udad2\udc43\ud9e0\udf1a\ud998\uddcc\ud9d6\udc49\u154c", "\u7e5d\ubcae\uc6be", "\ud89e\udf31",
        45, 48708, -1225821715, -7245430982890637289L, -45245L, true, true, (char) 64372, (char) 64619,
        Double.longBitsToDouble(0x3fd386f6aaed4302L), Double.longBitsToDouble(0x3fd8f38ed3a59938L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ua0fc", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udb36\udec4\u72b6\ud93e\udde5\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd7310bd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 6, "\udadc\udfe2\uda48\ude60\ud97d\udcea\uda46\udf9e\udbaf\udfdc\ud870\ude80\ud87f\udd66\ud960\udcda\uda2f\uddc5\ud8ab\udf8e\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\udb8c\udfd6\ud9f2\udd28\udbae\udd6a\udb1b\udd69\udaef\ude94\uda3c\udd00\u02b2\udabf\udd9e\udab6\udc8a\ud93e\udf9f\u8ca9\ud818\udc37\ud891\udfb0\udae0\udda1\ud8c0\udfaf\udbf2\udfa7\ud999\uddc9\udad7\ude87\uda6d\udd62\uda52\udf34\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\uda12\udd88\ud9c7\udcc2", "\uc329\u330f\ua1bf\u48e9\ua3f7\ud7f6\u4a98\u52bc", "\ud9a8\udd5d\udab7\udef5\udb21\udf35\udb74\udda6\uda69\udec5\ud951\udde1\udabc\udea7\ud8f9\udf50\uda95\udf72\ud93f\ude26\ud847\udf2f\udab8\udcdb\uda3f\ude0c\ua157\ud991\ude0c\uf578",
        46, 54093, -1745336760, 4676412938668900206L, 39753L, true, false, (char) 5505, (char) 60072,
        Double.longBitsToDouble(0x3fe5b59fb3ed30c3L), Double.longBitsToDouble(0x3fb0bf79b0878578L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 1, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\ud9a0\udfb8\udae0\udd3d\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\udb8b\udf48\ud820\udd1e\u02b2\udbf3\udf57\ua0fc", "\u9bbe", "\udb84\udec4\ud110\udb5e\udc67\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb2d\udc00\uda6e\udd01\u46c5\ud85d\udfe3\udbb5\udc02\ud9e5\udc88\ud9d9\udec2\ud9fc\udf94\udb36\udec4\ud98c\ude90\udb43\udd97\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd639c082L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 9, 11, 9, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\ud8f3\udf48\udadf\udd2a\udaa9\uddfa\udbdd\udda8\ud9f2\udcf6", "\ua00c\u0636\ua82f\u5d64\u3354\u5938\ua2f7\u22e5\u1443\uaed9", "\ud969\udfa6\udb5e\udcd0",
        14, 52076, -93197335, -186204953053886749L, 43067L, false, true, (char) 45883, (char) 36883,
        Double.longBitsToDouble(0x3feea4494457662dL), Double.longBitsToDouble(0x3feb4f2abe82e4caL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=org.jsoup.parser.Token$EndTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 9, 8, 7, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\ud929\udd1d\udbf8\uddf0\ud9cf\ude95\ud959\ude96\ud960\udcda\ud97e\udf7c\u7639\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ud879\udd43", "\u9af4\ub2fb", "\ud969\udfa6",
        18, 83695, 1014901202, -400279505942710379L, 33622L, false, true, (char) 35914, (char) 2624,
        Double.longBitsToDouble(0x3fef3ed4fda0ede0L), Double.longBitsToDouble(0x3fb9d1d3f47efcf0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 7, "\udb6b\udee1\ud9d8\ude19\udbe1\udeeb\uda29\ude29\udbf8\uddf0\udb4d\ude94\uda67\udc36\ud960\udcda\udbbf\udd81\udaee\udfab\u154d\ud99b\udf89\ud84e\udf11\uda08\uddb2\ud9c8\udcf6\ud881\uddd4\ud894\udf35\uda49\udc8b\ud89e\udf31\u879a\u02b2\ud85c\udc7f\ua04f", "\u9ac8", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud968\udcfe\ua625\ud8ee\udde9\ud8c0\uddaf\udbdf\ude84\u465a\udbd8\udf80\ud952\ude0e\ud8d8\udfc6\udae1\udceb\uda2a\udd07\udb34\udd7c\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\ud98d\udeeb\u352e\ud8f2\udc0c\uda52\ude91\uda36\udffd",
        45, 87644, 1401933676, -5210685230183466464L, 58145L, true, true, (char) 18107, (char) 28565,
        Double.longBitsToDouble(0x3fccad2909c3207cL), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\ud867\udd8c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\ud99b\udcbb\uda97\udc9b\ud89e\udf31\u879a\u02b2\udabf\udd9e\udbbd\ude02", "\u9baa", "\udb84\udec4\udafa\udfe0\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud866\udc0a\ud9b5\udea4\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\ud968\udef4\uda9d\udefc\udb65\udd88\ud960\udcda\uda44\ude3f\udbe7\udd38\ud882\udc10\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6", "\ucf66\u0656\ua82f\u5d64\u3354\u8fbc\u763e\u22e5\u9baa\u776c", "\ud969\udfa6",
        18, 83695, 1014901202, -400279505942710379L, 33622L, false, true, (char) 35914, (char) 34020,
        Double.longBitsToDouble(0x3fd88ed82b41da84L), Double.longBitsToDouble(0x3fc56ea73a3f7e78L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 15, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\ud919\udf26\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\udadd\uddbf\ud96f\uddb6\ua0fc", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 1106L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=org.jsoup.parser.Token$StartTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 9, 8, 14, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ua0fc", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, -13486L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jsoup.parser.Token$StartTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 8, 6, 7, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude75\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\ud79a\u02b2\udab5\udcb9\ud921\udec8", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 922L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 9, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud92c\udec3\uda99\udc0d\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udb1c\udf2f\udaa9\uddda\udbdd\udda8\ud917\udcf3\udb5e\udd02\udb59\udc12\000\ud879\udd9b\u879a\ud86b\udd86\uda46\udfa3\ua0fc", "\u80a7\u4e33\u559e\u1041\uc538v\000\000\u7553", "\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05",
        -2, 39403, -1747344627, -1920947690078018711L, 7886L, true, true, (char) 65428, (char) 16372,
        Double.longBitsToDouble(0x3febfda75061095dL), Double.longBitsToDouble(0x3fa2bc7b42c47380L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 9, "\udadc\udfe2\uda48\ude60\ud889\udf42\ud8f2\udc17\udbf9\udc97\ud92c\udec3\uda99\udc0d\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud917\udcf3\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\ud841\udea3\ua0fc", "\u96cb\u4e33\u559e\u1041\uc538\ua0ee\u1ca7\u4184\u7553", "\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05",
        5, 39403, -1747344627, -1884074468128922775L, 7886L, true, true, (char) 2197, (char) 16600,
        Double.longBitsToDouble(0x3febfda75061095dL), Double.longBitsToDouble(0x3fa2bc7b42c47380L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 5, "\ua23a\udb0b\uddf5\ud9fc\ude39\ud8ae\udede\u44b0\uda60\udf5c\uda0b\udcef\ud960\udcda\uda95\udf1c\ud870\udd18\ud956\uddb0\udacb\udfe6\udaa9\uddfa\ud861\uddaa\ud917\udcf3\udb29\udd01\udb59\udc12\uda01\udf08\ud887\ude2f", "\ubbed\u4539\u2c7c", "\ud811\udc02\udac7\ude37\ud85f\udd33",
        33, 39438, -862152305, 4358967471167892457L, 29309L, false, false, (char) 50039, (char) 35914,
        Double.longBitsToDouble(0x3fe6dab04d201182L), Double.longBitsToDouble(0x3fda0ed42156ea72L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.Tokeniser:@?\0121=org.jsoup.parser.Token$EndTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 10, 8, 7, "\udadc\udfe2\uda48\ude99\ud827\udff3\udb8b\udc25\uda85\udc24\ud801\udc89\ud9a5\udd7f", "\ua1e5\u4c55\u3af5\u38f9\u7e5d", "\ud9f7\udf41\udacc\udc74\udb3e\ude46\ud817\udd97\u02b2\ud841\udea3\ua0fc\udb46\udf83\uda66\udebc\uda83\udf02\ud9d6\udfb4\udaba\udca4\udb13\udecd\ud815\udf00\ud800\ude2d\udb94\udf08\uda6d\udd42\ud81f\udffa\u3f94\ud9dd\uddd0",
        25, 16062, 1443475891, 892327193991062160L, 32165L, false, true, (char) 1051, (char) 54039,
        Double.longBitsToDouble(0x3fe59db14c0ebb08L), Double.longBitsToDouble(0x3fda3084428e424cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=org.jsoup.parser.Token$EndTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 12, 8, 16, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud92c\udec3\uda99\udc0d\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud917\udcf3\udb5e\udd02\udb59\udc12\udb1a\udc95\ud89e\udf31\u879a\u02b2\ud841\udea3\ua0fc\udb46\udf83\ud95f\udfd9\u1fe9\ud9db\udf62\udac7\ude37\udb84\udec4", "\u1ca7\u4184\u7553\ucc84\u4952", "\udb52\udc85",
        47, 10496, 1966687648, -7449331282978692339L, -27145L, false, false, (char) 20936, (char) 40715,
        Double.longBitsToDouble(0x3fd47ff4d1e8bfc8L), Double.longBitsToDouble(0x3febfda75061095dL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 12, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud92c\udec3\uda99\udc0d\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c", "\u7e5d\u386f\uc6be", "\ud9f4\udde7",
        45, 48708, -1232035081, -7245430982921242601L, 91074L, true, true, (char) 18860, (char) 64619,
        Double.longBitsToDouble(0x3fd386f6aaed4302L), Double.longBitsToDouble(0x3fe438e7b1d2cc97L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 12, 12, 0, "\udae0\udcbd\uda48\ude60\ud97d\udcdb\uda3e\ude48e\ud9ca\udcc5\ud8b6\uddf3\udb1d\udfc6\ud9bd\udd9b\u53a1\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\ud96e\uddd5\uda71\ude3a\uda75\udd90\udbfa\ude28\u02b2\udabf\udd9e\ua0fc", "\u9baa", "",
        -5, -1000, 0, 1014901202L, 459L, true, false, (char) 58328, (char) 50039,
        Double.longBitsToDouble(0x3ec2e00000000000L), Double.longBitsToDouble(0x3fd200000b41da84L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 6, 14, 3, "\udae0\udcbd\ud975\uded7\ud97d\udcdb\udbf0\ude41\udbf8\uddf0\ud9cf\ude95\ud8b6\uddf3\udb1d\udfc6\ud9bd\udd9b\udb5e\udfa5\u154c\udacb\udfe6\ud8bb\udee2\udbdd\udda8\ud9c8\udcf6\udb5e\udd02\ud96e\uddd5\uda71\ude3a\uda75\udd90\udbfa\udea7\u02b2\udabf\udd9e\ua0fc", "\u9baa", "\udbd4\ude72\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\ud8e6\udec4\ud9d4\udf0d\ud81b\ude5f\ud94d\ude65\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1949290348, -6907048770659908212L, 1106L, true, false, (char) 50554, (char) 32035,
        Double.longBitsToDouble(0x3fe7a448cb1cb941L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 6, 6, 4, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\ud97b\udc19\u156f\udacb\udfe6\udaa9\uddfa\udb21\udd8a\ud9c8\udd0c\ud847\udfa9\udb59\udc12\uda97\udc92\ud895\udc31\u879a\u02b2\uda93\udda7\udaf6\uddb8", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\ud9e5\udc88\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda3e\udd4c\ud9cd\udc3d",
        0, 43172, 1401933676, -9055393718516172230L, 61038L, false, true, (char) 50642, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397282L), Double.longBitsToDouble(0x3fe33682331dccc5L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 11, 11, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\ud97b\udc19\u156f\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\ud847\udfa9\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\uda96\udfaa\udaf6\uddb8", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\udb33\udc0f\uda9a\udfc5\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda3e\udd4c\ud9cd\udc3d",
        0, 43172, 1401933676, -9055393718516172230L, 61038L, true, false, (char) 50554, (char) 24099,
        Double.longBitsToDouble(0x3feeea345019aa2fL), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 7, 7, 3, "\udadc\udfe2\uda48\ude60\ud9fb\udefa\udab6\udce9\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6", "\ubcae", "\ud973\uddc0\ud85d\udcb5\uda0d\udcf3\u4d38\udabf\udd9e\ua0fc\ud91b\udc10\ud888\uddf4\ud988\uddcc\ud92a\udd62",
        39, 92350, -1692505649, 4092529376055040399L, 29928L, false, true, (char) 42045, (char) 6295,
        Double.longBitsToDouble(0x3fe3080f380fd26cL), Double.longBitsToDouble(0x3fee50fd59393210L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jsoup.parser.Token$EndTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\udb64\udc3b\udbf8\uddbc\uda4b\udc03\ud8c9\udd65\ud9e0\udf1a\ud998\uddcc\ud9d6\udc49\ud883\udd6a", "\u7e5d\ubfa4\ua1b7", "\uda48\ude4c\u879a\u02b2\udabf\udd9e\ua0fc\ud93e\udf9f\ud910\ude70\udaa2\udc62",
        -1, 16329, 1869251636, -6809102645984387722L, -45170L, false, true, (char) 52541, (char) 21794,
        Double.longBitsToDouble(0x3fe8f763f6434176L), Double.longBitsToDouble(0x3fcc9e91457b4354L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jsoup.parser.Token$EndTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\0121=org.jsoup.parser.Token$EndTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 8, 8, 7, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\ud929\udd1d\udbf8\uddf0\ud9cf\ude95\ud959\ude96\ud960\udcda\ud97e\udf7c\u7639\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9c8\udcf6\udb6a\udd08\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ud879\udd43", "\u9af4\ub2fb", "\ud969\udfa6",
        18, 83695, 1014901202, -400279505942710379L, 33622L, false, true, (char) 35914, (char) 2624,
        Double.longBitsToDouble(0x3fef3ed4fda0ede0L), Double.longBitsToDouble(0x3fb9d1d3f47efcf0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jsoup.parser.Token$StartTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\0121=org.jsoup.parser.Token$StartTag:!toString:java.lang.NullPointerException |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 8, 8, 15, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude75\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\udb69\udd14\udaa0\udc91\udb39\udfa3\ud97e\udfca\ud9c8\udcff\udb5e\udd02\udb59\udc12\uda96\udfe4\ud89e\udf31\ud79a\u02b2\udab5\udcb9\ud921\udec8", "\u9baa", "\udb84\udec4\ud840\udc50\u59ac\ud917\udd8f\uda6d\udd82\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud8f3\udc05\udae4\udfee\ud89d\udcfc\ud860\udf4d\udb36\ude8d\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\udb81\uddba\udacd\udfcd\ud969\ude8a\ud9cd\udc3d",
        0, 43172, 2106576748, -5210939045570790854L, 922L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fd814bbd6397276L), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 0, "\udadc\udfe2\uda48\ude60\ud97d\udcdb\uda3e\ude48\udbf8\uddf0\ud9cf\ude95\uda67\udc36\ud960\udcda\ud97e\udf7c\udbf3\udd38\u154c\udacb\udfe6\udaa9\uddfa\udbdd\udda8\ud9e8\udcdb\udb5e\udd02\udb59\udc12\uda97\udc92\ud89e\udf31\u879a\u02b2\udabf\udd9e\ua0fc", "\u9baa", "\udb84\udec4\ud969\udfa6\udb5e\udcd0\udad7\ude87\uda6d\udd62\ud894\udf95\u3f6e\ud9dd\uddd0\udb89\udc2e\uda6e\udd01\u46c5\ud85d\udfe3\ud96d\ude71\ud997\udd36\ud9d9\udec2\uda07\udc94\udb36\udec4\uda04\uddce\ud94d\uddfd\ud8a1\uddb6\ud9c6\uddb2\uda91\udeed\ud8df\udc87\ud8f2\udc0c\uda60\udef8\ud9cd\udc3d",
        0, 43172, 1401933676, -5210685230183466438L, 20803L, true, false, (char) 50554, (char) 57378,
        Double.longBitsToDouble(0x3fec0a5de9073e6dL), Double.longBitsToDouble(0x3fe33681731dccc5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.Tokeniser|appropriateEndTagName||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.TokeniserState|read|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader|fac:org.jsoup.parser.TokeniserState:valueOf:java.lang.String",
    "M|org.jsoup.parser.Tokeniser|acknowledgeSelfClosingFlag||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|advanceTransition|org.jsoup.parser.TokeniserState|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|characterReferenceError||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|consumeCharacterReference|java.lang.Character,boolean|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|createCommentPending||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|createDoctypePending||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|createTagPending|boolean|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|createTempBuffer||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|currentNodeInHtmlNS||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|emit|char|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|emit|java.lang.String|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|emit|org.jsoup.parser.Token|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|emitCommentPending||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|emitDoctypePending||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.Tokeniser|appropriateEndTagName||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader",
    "M|org.jsoup.parser.TokeniserState|read|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader|fac:org.jsoup.parser.TokeniserState:valueOf:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
