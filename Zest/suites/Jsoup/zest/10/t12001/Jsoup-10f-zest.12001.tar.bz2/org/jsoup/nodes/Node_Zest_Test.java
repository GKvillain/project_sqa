package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Node_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 3, 10, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u1a14\u988e\u394e\uc6d8\uc37d\u0190\ua8e5\uc532\ua8b3\u1ce0\u6cd4\uaf88\uc2ca\u23d0\u9d30\uadfb\ub440", "\ud8be\udcfd\udb46\udc59\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\udaa0\udf5b\udb05\udeb4\ud9ef\udfc8\ud945\udf25\ud819\udf33",
        0, 58568, 1549092867, -2766349162575706647L, -70449L, false, false, (char) 57596, (char) 56225,
        Double.longBitsToDouble(0x3fb797fcb5071890L), Double.longBitsToDouble(0x3fbcbf3f7cc7cac0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 3, 10, "\uda2b\udd02\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u1a14\u988e\u394e\uc6d8\uc37d\u0190\ua8e5\uc532\ua8b3\u1ce0\u00e6\uaf88\u1622\uce77\u7bf2\u7d3e\ub440", "\ud8be\udcfd\udb46\udc59\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udb10\ude1a\uda0b\udddb\udac5\udc8b\udaa0\udf5b\udb05\udeb4\ud9ef\udfc8\ud945\udf25\ud819\udf33",
        0, 58568, 1549092867, -2766349162575706647L, -70449L, false, false, (char) 57596, (char) 56225,
        Double.longBitsToDouble(0x3fb797fcb5071890L), Double.longBitsToDouble(0x3fbcbf3f7cc7cac0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\012",
        Z.run(T, 2, 13, 3, 10, "\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0", "\uc37d\u0190", "\ud987\ude07\ud8f6\ude98\udb47\ude89\uda9f\udca7\udbb5\udc95\uda7b\udc15\uda69\ude74\ud857\udf7b\udaf2\ude00\ud803\uded4\uda8b\udf12\ud8be\udcfd\ud99c\ude33\uda78\udd88\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\ud9c1\udd05\udb05\udeb4\ud8d2\udd7a\ud94b\udfe4\ud819\udf33\udac3\udfd3",
        58, 54867, -644090856, -2163480543116166497L, 10117L, false, false, (char) 53682, (char) 38255,
        Double.longBitsToDouble(0x3fecc7cac2866c14L), Double.longBitsToDouble(0x3fe3ed1eb5ca1ad0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 10, "\ud9fb\udf58\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u4ed8\ub744\u8280\uc6d8\u7100\u1eee\u1b7d\ucd5d\ua815\u49e8\ub75d\uaff3\uc2ca\u744d\u3934\uadfb\ub440", "\ud8be\udcf5\ud912\udc55\udb29\udd8d\udbc3\udcaa\ud929\udd4d\udae7\udf26\ud936\udcd8\ud9aa\ude42\udb98\udc14\ud95b\udc98\udb05\udeb4\udb27\udfc4\ud954\ude61\ud9b2\udd7f",
        44, 58568, 1549092867, -2766349160912140823L, 24165L, true, false, (char) 57771, (char) 56225,
        Double.longBitsToDouble(0x3fb797fcb5071890L), Double.longBitsToDouble(0x3fbcbf3f4a1aa2c0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89--> |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\012",
        Z.run(T, 1, 4, 0, 10, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u1a14\u988e\u38db\uc6d8\u06c5\u5b75\ua8e5\ucd97\u97f3\uc179\u6c85\u1775\u63ae\uc158\u9d30\uadfb\ub440", "\ud8d3\udf88\udb46\udc59\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\uda62\udee2",
        16, 9644, 209820319, -8607947070705235982L, -28484L, true, false, (char) 20589, (char) 40836,
        Double.longBitsToDouble(0x3fc87cff32467720L), Double.longBitsToDouble(0x3fe0777f5c5d7408L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud997\uddb7-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud997\uddb7-->\012",
        Z.run(T, 2, 0, 0, 10, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud997\uddb7", "\u35ee", "\u00b9\000\000\ud8ea\udd0e\ub34a\000",
        35, 86770, -2102160374, 6847294423882006528L, -42704L, false, false, (char) 19117, (char) 23860,
        Double.longBitsToDouble(0x3f8f3800d94ecbc0L), Double.longBitsToDouble(0x3fe80004d660203cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud85c\udf08\ud80f\udc38\udb5d\udea4\ud867\udf1f\ud8ba\udf89-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud85c\udf08\ud80f\udc38\udb5d\udea4\ud867\udf1f\ud8ba\udf89-->\012",
        Z.run(T, 2, 0, 3, 10, "\ud85c\udf08\ud80f\udc38\udb5d\udea4\ud867\udf1f\ud8ba\udf89", "\u2085\u988e\u394e\uc6d8\uc37d\ua3fc\u6e29\uc5d5\u5525\u0258\u6cd4\u23ad\uab61\u5d46\uc9ef\u5ce1\u806f", "\ud8be\udcfd\udb46\udc59\udbb7\udf8b\udbc3\udcaa\ud91d\ude4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb",
        14, 42319, -2004193857, -198149649080546252L, 45653L, false, true, (char) 43497, (char) 20589,
        Double.longBitsToDouble(0x3fedfeccd8c3e7f9L), Double.longBitsToDouble(0x3fc233b9183bbfacL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\uda29\udddc\udb69\ude8f\udb5d\ude5e--> |this=org.jsoup.nodes.Comment:\012<!--\uda29\udddc\udb69\ude8f\udb5d\ude5e-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\uda29\udddc\udb69\ude8f\udb5d\ude5e-->\012",
        Z.run(T, 2, 10, 3, 10, "\uda29\udddc\udb69\ude8f\udb5d\ude5e", "\u603a\u663d\u6596\uaa68\ud56c\uc6d8\uc37d\u176c\u035b", "\ud8f6\ude98\udb47\ude89\uda9f\udca7\uda53\udfc4",
        -1, 90140, -618153561, -1753346441552797744L, 13734L, true, false, (char) 16208, (char) 18423,
        Double.longBitsToDouble(0x3fdbf0c81fe51114L), Double.longBitsToDouble(0x3faa7ea0051aa2f0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\udbff\ude79\udaa0\udce0\uda0c\udee5\udb1f\ude71\ud8ba\udf89--> |this=org.jsoup.nodes.Comment:\012<!--\udbff\ude79\udaa0\udce0\uda0c\udee5\udb1f\ude71\ud8ba\udf89-->\0121=org.jsoup.nodes.Attributes: comment=\"&#56319;&#56953;&#55968;&#56544;&#55820;&#57061;&#56095;&#56945;&#55482;&#57225;\" \ud8be\udcfd\ud932\udd2f\udb94\udfe8\ud898\udfd5\ud854\ude31\ud928\ude7a\ud910\udf90\uda18\udf41\u394c\uda39\udc24\udb11\udf64\ud872\udd65\uda22\udfc6\uda93\udfec=\"&#56319;&#56953;&#55968;&#56544;&#55820;&#57061;&#56095;&#56945;&#55482;&#57225;\" |this=org.jsoup.nodes.Comment:\012<!--\udbff\ude79\udaa0\udce0\uda0c\udee5\udb1f\ude71\ud8ba\udf89-->\012",
        Z.run(T, 2, 4, 5, 10, "\udbff\ude79\udaa0\udce0\uda0c\udee5\udb1f\ude71\ud8ba\udf89", "\u1a14\u98a9\u394e\u9529\u1ef2\u6356\u38d0\u1da6\u5840\u9969\uc874\ud45d\u85fc\u1ae3\u9d30\uadfb\ub440", "\ud8be\udcfd\ud932\udd2f\udb94\udfe8\ud898\udfd5\ud854\ude31\ud928\ude7a\ud910\udf90\uda18\udf41\u394c\uda39\udc24\udb11\udf64\ud872\udd65\uda22\udfc6\uda93\udfec",
        52, 38413, 1549092927, -2742112627764640279L, -70449L, false, false, (char) 57596, (char) 50915,
        Double.longBitsToDouble(0x3fd6f8473d41d372L), Double.longBitsToDouble(0x3fbcbf3f6b37cac0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\ud842\udfd5\ud9da\udedd--> |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\ud842\udfd5\ud9da\udedd-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\ud842\udfd5\ud9da\udedd-->\012",
        Z.run(T, 2, 4, 3, 10, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\ud842\udfd5\ud9da\udedd", "\u1ac1\u988e\u394e\uc6d8\uc37d\u0190\ua8e5\uc532\ua8b3\u1ce0\u6cd4\uaf88\uc2ca\u23d0\ubdd1\uadfb\ub440\u54e9\u92aa", "\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\uda19\udd27\uda0b\udddb\ud9ef\udc80\udaa0\udf5b\udb05\udeb4\ud9ef\udfc8\ud945\udf25\udb00\ude3d\udac3\udfd3\u11a5\udbf5\udd73\ud926\uddab",
        19, 80059, -269775727, 8361115285289594100L, -62018L, false, true, (char) 29329, (char) 59632,
        Double.longBitsToDouble(0x3fc00e6c753f962cL), Double.longBitsToDouble(0x3fe74a322aa806a0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\u0e4e-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\u0e4e-->\012",
        Z.run(T, 2, 8, 3, 10, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\u0e4e", "\u1a2f\u988e\u394e\uc6d8\uc37d\u0190\ua8e5\uc532\ua8b3\u1ce0\u4f7f\u9f25\uc2ca\u23d0\u9d30\ub9fb\ub440\u54e9\u92aa\u512f\u0822\u2a35\u2d00\ub19b\u4e92\u73d6\u4200\u70c5\u7971\u7029\u8caf\ub67e\ua1da\u76cf\u97e8", "\udae4\udc4e",
        9, 95273, 1946723854, -8519001848287178277L, -95800L, true, false, (char) 15793, (char) 15206,
        Double.longBitsToDouble(0x3fdb134584b27202L), Double.longBitsToDouble(0x3fd56ca7776db2beL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"&#55803;&#57176;&#55635;&#56611;&#56157;&#56926;&#55948;&#56400;&#55482;&#57225;\" |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\012",
        Z.run(T, 2, 5, 3, 5, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u82af\ud721\ua7e5\u0ad1\uc2d2\u0190\ua8e5\uc532\u9570\u1b7f\u888c\ub02a\uc2ca\u8f18\u9cce\ud7cb\u3f5a", "\ud8be\udcfd\udb46\udc59\udb86\udc39\uc3e3\ud939\ude4d\ud835\udefd\ud958\ude6c\uda0b\udddb\udac5\udc8b\ud90b\udef1\udb05\udeaa\ud9ef\udfc8\ud9c4\udf77\ud876\udccd\udba2\udffe\u11a5\udbf5\udd73\udb36\uddd4\uda1d\udc7e\ud8c9\udc34",
        29, 28760, 811011606, -3475192913049524229L, -60974L, false, true, (char) 11900, (char) 61010,
        Double.longBitsToDouble(0x3fc0b3901f5ed4b8L), Double.longBitsToDouble(0x3fe89c3ca0464d3bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\0121=void |a0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\012",
        Z.run(T, 2, 13, 2, 5, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u1a14\u988e\u394e\uc6d8\uc37d\u0190\ua8e5\uc532\ua8b3\u1ce0\u6cd4\uaf88\uc2ca\u23d0\u9d30\uadfb\ub440", "\ud8be\udcfd\udb46\udc59\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\uddfd\udaac\ude28\uda0b\udddb\udac5\udc8b\udaa0\udf5b\udb05\udeb4\ud9ef\udfc8\ud945\udf25\ud819\udf33",
        0, 22440, 1549075278, -2766349162575706647L, -70449L, false, false, (char) 57596, (char) 56225,
        Double.longBitsToDouble(0x3fb797fcb5071890L), Double.longBitsToDouble(0x3fbcbf3f7cc7cac0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\uda42\udfcd\ud9ad\udefd\ud833\udc92\ud87c\udded-->\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\uda42\udfcd\ud9ad\udefd\ud833\udc92\ud87c\udded-->\012",
        Z.run(T, 2, 13, 12, 4, "\ud9fb\udf58\uda42\udfcd\ud9ad\udefd\ud833\udc92\ud87c\udded", "\u1a14\u988e", "\udadf\uddc2\udb91\uded1",
        57, 28482, 1231518132, 8847017299032778746L, 62543L, false, true, (char) 58005, (char) 45688,
        Double.longBitsToDouble(0x3fed9ed93dd04978L), Double.longBitsToDouble(0x3fb30799265f6ca8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud93f\udeba\ud953\udd23\udb5d\ude5e\uda60\udc5a\ud8ba\udf89\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\012",
        Z.run(T, 1, 9, 7, 15, "\ud93f\udeba\ud953\udd23\udb5d\ude5e\uda60\udc5a\ud8ba\udf89\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0", "\uc37d\u0190", "\ud99a\udce1\ud9ef\udda8\udb47\ude89\uda9f\udca7\uda53\udfc4\uda7a\udf72\uda79\udd47\ud857\udf7b\udaf2\ude00\ud803\uded4\uda8b\udf12\ud8be\udcfd\udb46\udc59\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\udaa0\udf5b\udb05\udeb4\ud9ef\udfc8\ud945\udf25\ud819\udf33\ud9d7\ude7c",
        48, 54867, -644090856, -1731134978877028157L, 10117L, false, false, (char) 53682, (char) 38255,
        Double.longBitsToDouble(0x3fecc7cac26bfeb3L), Double.longBitsToDouble(0x3fb5309c51f354c8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\0121=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89--> |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\012",
        Z.run(T, 2, 13, 10, 14, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u17e1\u5a70\u394e\uc6d8\u08d3\u6454\u8291\u0d00\ua8b3", "\uda9f\udca7\udaf4\udfcd\uda7a\udf72\uda79\udd47\ud857\udf7b\udaf2\ude00\ud803\uded4\uda8b\udf12\ud8be\udcfd\udb46\udc59\ud94f\udfd7\udba9\ude08",
        12, 69744, -570835926, -2805874343825531940L, 59167L, false, true, (char) 35188, (char) 64128,
        Double.longBitsToDouble(0x3fe8592e485efbbeL), Double.longBitsToDouble(0x3fde80aab830b9d8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\uda1f\udc2a\ud835\ude8c\uda1c\udf72\ud8d7\udced-->\012",
        Z.run(T, 1, 13, 3, 10, "\ud9fb\udf58\uda1f\udc2a\ud835\ude8c\uda1c\udf72\ud8d7\udced", "\u1a14", "\uda65\udc35\udadf\uddc2\udab8\udec4\ud9ad\udeaf\ud94f\ude7a\ud990\udcc2",
        4, 63477, -2102160324, -8428915329138054838L, -16455L, false, false, (char) 10455, (char) 34700,
        Double.longBitsToDouble(0x3fc97dbc31491cd0L), Double.longBitsToDouble(0x3f8f3970d94ecbc0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf1b\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud846\udc0f-->\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 7, 10, "\ud9fb\udf1b\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud846\udc0f", "\u1a14\u988e\u394e\uc6d8\uc008\u1c99\ub2d1\u1682\u893f\u1ce0\u6cd4\uaf88\uc2ca\u23d0\u9d30\uadfb\ub440", "\ud8d5\udcb8\udb46\udc59\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\ud9fa\udcd0\udac5\udc8b\udaa0\udf5b\udbae\udd13\ud9a9\udeeb\ud945\udf25\ud878\udc62\udac4\udc7c\u11a5\udbf5\udd73",
        7, 36730, -62037473, -1158677931362834930L, 10117L, false, false, (char) 53682, (char) 38085,
        Double.longBitsToDouble(0x3fefd9dd17def35cL), Double.longBitsToDouble(0x3fe4c55b992a06faL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud849\udf24\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 1, 10, "\ud849\udf24\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0", "\uc37d\u0190", "\ud99b\udc07\ud8f6\ude98\udb47\ude89\uda9f\udca7\udbb5\udc95\uda7b\udc15\uda69\ude74\ud857\udf7b\udaf2\ude00\uda13\udefd\ud94b\udd22\ud8d9\udcd9\ud99c\ude33\uda78\udd88\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\ud9c1\udd05\udb05\udeb4\ud901\udd56\ud94b\udfe4\ud819\udf33\udac3\udfd3",
        58, 54867, -644090856, -2163480543116166497L, 10117L, false, false, (char) 53682, (char) 38255,
        Double.longBitsToDouble(0x3fecc7cac2866c14L), Double.longBitsToDouble(0x3fe3ed1eb5ca1ad0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 3, 10, "\ud877\ude36\ud931\udc23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0", "\uc37d\u0190", "\ud987\ude07\ud8f6\ude98\udb47\ude89\uda9f\udca7\udbb5\udc95\uda7b\udc15\uda69\ude74\ud857\udf7b\udaf2\ude00\ud803\uded4\uda8b\udf12\ud8be\udcfd\ud99c\ude33\uda78\udd88\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\ud814\udc52\udb05\udeb4\ud8d2\udd7a\ud887\udfe2\ud819\udf33\udac3\udfd3",
        58, 54867, -644090856, -2163480543116166497L, 10117L, false, false, (char) 53682, (char) 38255,
        Double.longBitsToDouble(0x3fecc7cac2866c14L), Double.longBitsToDouble(0x3fc2547ad6a171d0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\ud80b\udfb6\uda8c\udc63\udad8\udd58\uda90\udf1e-->\0121=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\ud80b\udfb6\uda8c\udc63\udad8\udd58\uda90\udf1e--> |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\ud80b\udfb6\uda8c\udc63\udad8\udd58\uda90\udf1e-->\012",
        Z.run(T, 2, 12, 11, 8, "\ud877\ude36\ud953\udd23\ud80b\udfb6\uda8c\udc63\udad8\udd58\uda90\udf1e", "\u988e\u394e\uc6d8\uc37d\u0190\ub2e5\uc532\ua8b3\u4f3e\u6cd4\uaf88\u82ca\u2473\u5e5d\uadfb\ub440\u523e\u7065\u6f56\u7e8b\u9b01\u2f69\ub19b\u4e92\uc5e9", "\ud9c9\uddb1\udb05\udeb4",
        18, 35171, -302198808, 958641147397980128L, -65855L, true, false, (char) 4876, (char) 57596,
        Double.longBitsToDouble(0x3fddb89c68bcbfe4L), Double.longBitsToDouble(0x3fe507189072fcfdL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 0, "\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\ud90b\udc63\udba5\ude1f\udb2d\udfcf\ud8d3\udcb0", "\ub882\u0190\ua869\uc532\ua8b3\u1ce0\u3942\u00d6\ub9fe\u2473\u5e5d\uadfb", "\uda8b\udf12\ud862\udef2\ud99c\ude1f",
        11, 81245, 540830567, 8766800245166816298L, 56708L, false, false, (char) 5648, (char) 36988,
        Double.longBitsToDouble(0x3fce72480146a8bcL), Double.longBitsToDouble(0x3fe85f6867e00d4dL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 10, "\udb76\udf76\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud871\udcc3\udb3a\udc18", "\u988e\u58e2\uc6d8\uc37d\u0190\ub0c9\u9cf8\u65e4\u05e2\uc41a\uc859\ubf8f\u238f\ucc4b\ubfc8\u6940\u6d8a\u8cbe", "\uda78\udd88\udbc3\udcaa\udbf5\udd22\ud9d5\udd8b\udab8\udc28\uda0b\udddb\udac5\udc8b\ud9c1\udd05\udb05\udeb4\ud8d2\udd7a\ud94b\udfe4\ud819\udf33\udac3\udfd3\ud977\udda2\udbf5\udd73\udb36\uddd4",
        13, 23335, -269775727, 8361115285289594100L, 69054L, false, false, (char) 38255, (char) 59530,
        Double.longBitsToDouble(0x3fe43360a67da3d6L), Double.longBitsToDouble(0x3fdca1ad061b1e16L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:-2085659971 |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda5b\ude1e\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda5b\ude1e\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\012",
        Z.run(T, 2, 15, 3, 10, "\ud877\ude36\ud953\udd23\udb5d\ude5e\uda5b\ude1e\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0", "\uc37d\u0190", "\ud99f\uddbd\udbda\udd23\udb47\ude83\uda9f\udca7\ud8d3\udfc5\ud866\udd74\uda79\udf95\ud857\udf7b\udaf2\ude00\ud803\uded4\uda8b\udf12\ud8be\udcfd\ud9ab\udc3a\uda2f\udca1\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\ud9c1\udd05\udb05\udeb4\ud856\udf7b\ud977\udf4e\u4d1b\uda21\uddc8",
        53, 54867, -644090856, -2163480543116166497L, 10117L, false, true, (char) 33639, (char) 38255,
        Double.longBitsToDouble(0x3fecc7cac2866c14L), Double.longBitsToDouble(0x3fe3ed1eb5ca1ad0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0--> |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\0121=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0--> |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\012",
        Z.run(T, 2, 4, 4, 10, "\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0", "\uc37d\u0190", "\ud987\ude07\ud8f6\ude98\uda1b\uddc4\ud9bb\udda1\udbb5\udc95\uda7b\udc15\uda69\ude74\ud857\udf7b\udaf2\ude00\ud803\uded4\uda8b\udf12\ud8be\udcfd\ud99c\ude33\uda78\udd88\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\ud9c1\udd05\udb05\udeb4\ud8d2\udd7a\ud94b\udfe4\ud819\udf33\udac3\udfd3",
        58, 54867, -644090856, -2163480543116166497L, 10117L, false, false, (char) 53682, (char) 38255,
        Double.longBitsToDouble(0x3fecc7cac2866c14L), Double.longBitsToDouble(0x3fe3ed1eb5ca1ad0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0-->\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 10, "\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0", "\uc37d\u0190", "\u1368\ud8f6\ude7b\udb47\ude89\uda9f\udca7\udbb5\udc95\uda7b\udc15\uda69\ude74\ud857\udf7b\udaf2\ude00\ud803\uded4\uda8b\udf12\ud8be\udcfd\ud99c\ude33\uda78\udd88\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\ud9c1\udd05\udb05\udeb4\ud8d2\udd7a\ud94b\udfe4\ud819\udf33\udac3\udfd3",
        55, 55026, -644090856, -2163480543116166497L, 10117L, false, false, (char) 53682, (char) 38255,
        Double.longBitsToDouble(0x3fecc7cac2866c14L), Double.longBitsToDouble(0x3fe3ed1eb5ca1ad0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0\uda40\uddda\uda65\udc35\udadf\uddc2\udb91\uded1\ud8ea\ude0d\ud918\udcff\u1927\uda81\udcf2\ud838\udd69\ud8a2\udf0a\udbb5\udc95\uda7b\udc15\uda69\ude74-->\0121=org.jsoup.nodes.Attributes: comment=\"&#55415;&#56886;&#55635;&#56611;&#56157;&#56926;&#55948;&#56400;&#56024;&#56664;&#55937;&#56355;&#55697;&#57125;&#56143;&#56458;&#55507;&#56496;&#55872;&#56794;&#55909;&#56373;&#56031;&#56770;&#56209;&#57041;&#55530;&#56845;&#55576;&#56575;\u1927&#55937;&#56562;&#55352;&#56681;&#55458;&#57098;&... |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0\uda40\uddda\uda65\udc35\udadf\uddc2\udb91\uded1\ud8ea\ude0d\ud918\udcff\u1927\uda81\udcf2\ud838\udd69\ud8a2\udf0a\udbb5\udc95\uda7b\udc15\uda69\ude74-->\012",
        Z.run(T, 2, 0, 5, 10, "\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0\uda40\uddda\uda65\udc35\udadf\uddc2\udb91\uded1\ud8ea\ude0d\ud918\udcff\u1927\uda81\udcf2\ud838\udd69\ud8a2\udf0a\udbb5\udc95\uda7b\udc15\uda69\ude74", "\u54e9\u92aa\u512f\u7eac\u9b01\u2d00\ub19b\u4e92\u043f\u424d\u70c5\u8a91\u7029\u65de\ucf3d", "\ud977\udda2\udbf5\udd73\udb36\uddd4",
        13, 23335, -269775727, 8361115285289594100L, 69054L, false, false, (char) 55593, (char) 6729,
        Double.longBitsToDouble(0x3fe43360a67da3d6L), Double.longBitsToDouble(0x3fdca1ad0e0ce9b8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 10, "\u00fb\ud89e\ude2e\ud959\udf3d\000\udad8\udd58\ud4df\ud991\udede\000\000", "\u6bc9\u3ea3", "",
        26, -908, -978804480, -9028710056588838357L, -100000L, false, false, (char) 0, (char) 23755,
        Double.longBitsToDouble(0x3eaa000000000000L), Double.longBitsToDouble(0x3feb2d27b800159aL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |a1=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\0121=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89--> |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89-->\012",
        Z.run(T, 2, 1, 11, 10, "\ud9fb\udf58\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u4ed8\ub744\u8280\uc6d8\u7100\u1eee\u1b7d\ucd5d\ua815\u49e8\ub6c7\ub549\000\000\000\000\ub440", "\ud8be\udcf5\ud912\udc55\udb29\udd8d\udbc3\udcaa\ud929\udd4d\udae7\udf26\ud936\udcd8\ud9aa\ude42\ud957\udd07\ud95b\udc98\udb05\udeb4\udb27\udfc4\ud954\ude61\ud9b2\udd7f",
        44, 58568, 1549074435, -2766349160912140823L, 24165L, true, false, (char) 57771, (char) 56225,
        Double.longBitsToDouble(0x3fb797fc80000090L), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf1c\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89\uda81\udc23\ud836\uded8\udb25\udc0a\ud8ee\udce0\uda52\udf0c\uda65\udc35\ud946\udefc\udb63\udc30\u9875\ud895\udf16--> |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf1c\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89\uda81\udc23\ud836\uded8\udb25\udc0a\ud8ee\udce0\uda52\udf0c\uda65\udc35\ud946\udefc\udb63\udc30\u9875\ud895\udf16-->\0121=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf1c\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89\uda81\udc23\ud836\uded8\udb25\udc0a\ud8ee\udce0\uda52\udf0c\uda65\udc35\ud946\udefc\udb63\udc30\u9875\ud895\udf16--> |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf1c\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89\uda81\udc23\ud836\uded8\udb25\udc0a\ud8ee\udce0\uda52\udf0c\uda65\udc35\ud946\udefc\udb63\udc30\u9875\ud895\udf16-->\012",
        Z.run(T, 2, 4, 11, 13, "\ud9fb\udf1c\ud953\udc42\udb5d\ude5e\uda8c\udc50\ud8ba\udf89\uda81\udc23\ud836\uded8\udb25\udc0a\ud8ee\udce0\uda52\udf0c\uda65\udc35\ud946\udefc\udb63\udc30\u9875\ud895\udf16", "\ub75d\uaff3\uc2ca\u744d\u3934", "\ud803\uded4\uda8b\udf12\ud8be\udcf5\ud912\udc7c\udb29\udd8d\ud9df\udf67\ud929\udde3\udae7\udf26\ud936\udcd8\ud9aa\ude42\udb98\udc14\ud95b\udc98\udb05\udeb4\udb27\udfc4\ud954\ude61",
        33, 10469, 1642521568, 6653303201587786776L, -32571L, true, false, (char) 44562, (char) 57771,
        Double.longBitsToDouble(0x3fddb89c68bcbfe4L), Double.longBitsToDouble(0x3fe507189072fcfdL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud997\uddb7-->\0121=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud997\uddb7-->\012",
        Z.run(T, 2, 13, 13, 4, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud997\uddb7", "\u35ee", "\u00b9\000\000\ud8ea\udd0e\ub34a\000",
        35, 86770, -2102160374, 6847294423882006528L, -42704L, false, false, (char) 5549, (char) 9400,
        Double.longBitsToDouble(0x3f8f3800d94ecbc0L), Double.longBitsToDouble(0x3fe80004d660203cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\ud8a2\udf5e\ud815\udcc5\uda11\uded8\udaee\udf0b\udaf1\udf07\000\udaa8\uddd3\udabd\udde9\ud8d3\udcb0\uda40\uddda\u00b9\ud827\uddd3\udbb3\ude58\ud8ea\udd23\ub34a--> |this=org.jsoup.nodes.Comment:\012<!--\ud8a2\udf5e\ud815\udcc5\uda11\uded8\udaee\udf0b\udaf1\udf07\000\udaa8\uddd3\udabd\udde9\ud8d3\udcb0\uda40\uddda\u00b9\ud827\uddd3\udbb3\ude58\ud8ea\udd23\ub34a-->\0121=org.jsoup.nodes.Comment:\012<!--\ud8a2\udf5e\ud815\udcc5\uda11\uded8\udaee\udf0b\udaf1\udf07\000\udaa8\uddd3\udabd\udde9\ud8d3\udcb0\uda40\uddda\u00b9\ud827\uddd3\udbb3\ude58\ud8ea\udd23\ub34a--> |this=org.jsoup.nodes.Comment:\012<!--\ud8a2\udf5e\ud815\udcc5\uda11\uded8\udaee\udf0b\udaf1\udf07\000\udaa8\uddd3\udabd\udde9\ud8d3\udcb0\uda40\uddda\u00b9\ud827\uddd3\udbb3\ude58\ud8ea\udd23\ub34a-->\012",
        Z.run(T, 2, 11, 11, 5, "\ud8a2\udf5e\ud815\udcc5\uda11\uded8\udaee\udf0b\udaf1\udf07\000\udaa8\uddd3\udabd\udde9\ud8d3\udcb0\uda40\uddda\u00b9\ud827\uddd3\udbb3\ude58\ud8ea\udd23\ub34a", "\u6cd4\uaf88\ua6d3\u8804\u37b8\u7bbc\u53a8\uc170\u9318\u512f\ub01b\u2a35\u741c\ub134\u7d21\u1fca\u0af2\u4b1e\u5b78\u4e84\ub448\u4310\ub58c", "\udadc\udd11\ud8b8\udcbc\uda61\udedd\udb45\udd2a\udb8b\uddf9\ud887\udef2\udae2\udf6d\uda3f\udc77\udab9\udca8\u2cb1\ud8b8\udc67\ud84b\udf38",
        -3, 54352, 2029242024, 8840356038906241897L, -62284L, true, true, (char) 41679, (char) 32989,
        Double.longBitsToDouble(0x3feadfa1eff5bb58L), Double.longBitsToDouble(0x3fe62bac92b56accL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\uda29\udddc\udb69\ude8f\ud9aa\udc9d--> |this=org.jsoup.nodes.Comment:\012<!--\uda29\udddc\udb69\ude8f\ud9aa\udc9d-->\0121=org.jsoup.nodes.Comment:\012<!--\uda29\udddc\udb69\ude8f\ud9aa\udc9d--> |this=org.jsoup.nodes.Comment:\012<!--\uda29\udddc\udb69\ude8f\ud9aa\udc9d-->\012",
        Z.run(T, 2, 10, 10, 15, "\uda29\udddc\udb69\ude8f\ud9aa\udc9d", "\u5cfa\u5ff0\u6596\uaa68", "\udadf\uddc2\ud872\udf22",
        39, 28482, 1231518132, 8847017297406632442L, -203L, true, true, (char) 57825, (char) 45688,
        Double.longBitsToDouble(0x3fc67b64ff417ea8L), Double.longBitsToDouble(0x3fa23b864cbede10L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!----> |this=org.jsoup.nodes.Comment:\012<!---->\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 0, "", "\u2720", "\ud802\udd04\udae5\udffd\ud802\udc1c\ud9ba\udd82\uda67\uddf8\uda65\udc35\udadf\udccf\ud872\udf22\ud8f7\udc82",
        22, 24132, 2059856732, -4203932159138622454L, -99121L, false, true, (char) 45688, (char) 47066,
        Double.longBitsToDouble(0x3fee873d5024770cL), Double.longBitsToDouble(0x3fc97dbc38e51cd0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"&#56319;&#56953;&#55968;&#56544;&#55820;&#57061;&#56095;&#56945;&#55482;&#57225;\" |this=org.jsoup.nodes.Comment:\012<!--\udbff\ude79\udaa0\udce0\uda0c\udee5\udb1f\ude71\ud8ba\udf89-->\0121=org.jsoup.nodes.Attributes: comment=\"&#56319;&#56953;&#55968;&#56544;&#55820;&#57061;&#56095;&#56945;&#55482;&#57225;\" |this=org.jsoup.nodes.Comment:\012<!--\udbff\ude79\udaa0\udce0\uda0c\udee5\udb1f\ude71\ud8ba\udf89-->\012",
        Z.run(T, 2, 5, 5, 10, "\udbff\ude79\udaa0\udce0\uda0c\udee5\udb1f\ude71\ud8ba\udf89", "\u7590\u4b77\u394e\u9529\u1ef2\u6356\u38d0\u74d1\u86dc\u02e0\uc874\ud45d\u85fc\u1ae3\u51ee\u7231\ub440", "\ud8be\udcfd\ud932\udd2f\udb94\udfe8\ud898\udfd5\ud854\ude31\ud928\ude7a\ud910\udf90\uda18\udf41\u394c\uda39\udc24\udb11\udf64\ud872\udd65\uda22\udfc6\uda93\udfec",
        52, 38413, 1549124159, -2742112626794157335L, 21919L, true, false, (char) 17662, (char) 50961,
        Double.longBitsToDouble(0x3fd6f8473d41d372L), Double.longBitsToDouble(0x3fbcbf3f6b37cac0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:-1551338917 |this=org.jsoup.nodes.Comment:\012<!--\udb28\udea8\udab5\ude97\uda0c\udee5\udb1f\ude71\ud8ba\udf89\ud8c4\udda6\ud86c\ude71-->\0121=java.lang.Integer:-1551338917 |this=org.jsoup.nodes.Comment:\012<!--\udb28\udea8\udab5\ude97\uda0c\udee5\udb1f\ude71\ud8ba\udf89\ud8c4\udda6\ud86c\ude71-->\012",
        Z.run(T, 2, 15, 15, 10, "\udb28\udea8\udab5\ude97\uda0c\udee5\udb1f\ude71\ud8ba\udf89\ud8c4\udda6\ud86c\ude71", "\u394e\u4f9b\u1e10\u6356\u38d0\u1da6\u0a83\u8460\ua62f\ub41b\u8626", "\ud857\udf7b\udaf2\ude00\ud803\uded4",
        28, 12059, -1434184135, 4264742184345394021L, 65514L, true, false, (char) 55022, (char) 15237,
        Double.longBitsToDouble(0x3fe564b524ce2281L), Double.longBitsToDouble(0x3fe2f557771ca040L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |a0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud9cb\ude1f\ud953\udca4\udb5d\ude5e\uda8c\udc50\ud8ba\udf89\uda81\udc23\ud991\udf25-->\0121=void |a0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud9cb\ude1f\ud953\udca4\udb5d\ude5e\uda8c\udc50\ud8ba\udf89\uda81\udc23\ud991\udf25-->\012",
        Z.run(T, 2, 2, 2, 5, "\ud9cb\ude1f\ud953\udca4\udb5d\ude5e\uda8c\udc50\ud8ba\udf89\uda81\udc23\ud991\udf25", "\uab69\uc6d8\uc37d\u0190\ua8e5\uc532\ua8b3\u1ce0\u6cd4\uaf88\uc2ca", "\ud857\udf7b\udaf2\ude00\ud803\uded4\uda8b\udf12\ud8be\udcfd\udb46\udc59\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\uddfd\udaac\ude28",
        16, 9644, 209820319, -8607947070705235982L, -41664L, false, true, (char) 43540, (char) 27667,
        Double.longBitsToDouble(0x3fc87cff32467720L), Double.longBitsToDouble(0x3fe0777f5cf47408L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\uda42\udfcd\udba6\udfbb\ud859\ude9b\ud87c\udded-->\0121=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf58\uda42\udfcd\udba6\udfbb\ud859\ude9b\ud87c\udded-->\012",
        Z.run(T, 2, 9, 9, 2, "\ud9fb\udf58\uda42\udfcd\udba6\udfbb\ud859\ude9b\ud87c\udded", "\u1a14\u988e", "\udadf\uddc2\udb91\uded1",
        26, 62466, -676246166, -5117864144295057414L, 62543L, false, false, (char) 57898, (char) 45688,
        Double.longBitsToDouble(0x3fe4bca287c19526L), Double.longBitsToDouble(0x3fb307993eff6ca8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf1b\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud846\udc0f-->\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud9fb\udf1b\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud846\udc0f-->\012",
        Z.run(T, 2, 12, 12, 10, "\ud9fb\udf1b\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud846\udc0f", "\u1a14\u988e\u394e\uc6d8\uc008\u1c99\ub2d1\u1682\u893f\u1ce0\u6cd4\uaf88\uc2ca\u90b2\u1be8\u6230\u46d2", "\ud8d5\udcb8",
        52, 66415, 362470245, 2322849599983316576L, -51644L, false, true, (char) 7812, (char) 31179,
        Double.longBitsToDouble(0x3feb8c5a40b98496L), Double.longBitsToDouble(0x3fee7fa914f8197cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |a1=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\uda8b\udc44\ud813\udc35\ud925\udf60\ud9e3\udf8c\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8c7\udfcc\uda7a\uddab-->\0121=void |a1=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\uda8b\udc44\ud813\udc35\ud925\udf60\ud9e3\udf8c\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8c7\udfcc\uda7a\uddab-->\012",
        Z.run(T, 2, 1, 1, 1, "\uda8b\udc44\ud813\udc35\ud925\udf60\ud9e3\udf8c\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8c7\udfcc\uda7a\uddab", "\uaa7b\u97fb\u4086\u1e86\u1ce0\u6cd4\uaf88\u82ca\u2473\u5e5d\uadfb\u9df5\u6737\u3639\u8daf", "\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\uda93\uddbb\ud99d\ude84\ud84b\udc5b\ud9aa\udf4c\ud978\uddd0\ud9be\udf97\ud94b\udfeb",
        41, 91272, 1639628768, 6643520846635463704L, 10117L, false, false, (char) 10721, (char) 40047,
        Double.longBitsToDouble(0x3fe287cac165bfacL), Double.longBitsToDouble(0x3fca835ad7286bf0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\ud849\udf24\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud990\udeeb--> |this=org.jsoup.nodes.Comment:\012<!--\ud849\udf24\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud990\udeeb-->\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 1, 10, "\ud849\udf24\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud990\udeeb", "\uc37d\u0190", "\udad5\ude44\ud9fd\ude61\udb47\uddfe\uda9f\udca7\udbb5\udc95\uda7b\udc15\uda69\ude74\ud857\udf7b\udaf2\ude00\uda13\udefd\ud94f\udf7a\ud8d9\udcd9\ud99c\ude33\uda78\udd88\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\ud9c1\udd05\udb05\udeb4\ud901\udd56\ud94b\udfe4\ud819\udf33\udac3\udfd3",
        58, 54867, -644090856, -2163480543116166497L, 10117L, false, false, (char) 53682, (char) 38255,
        Double.longBitsToDouble(0x3fecc7cac2866c14L), Double.longBitsToDouble(0x3fe3ed1eb5ca1ad0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"&#55415;&#56886;&#55635;&#56611;&#56157;&#56926;&#55948;&#56400;&#56024;&#56664;&#55937;&#56355;&#55697;&#57125;&#56143;&#56458;&#55507;&#56496;&#55872;&#56794;&#55909;&#56373;&#56031;&#56770;&#56209;&#57041;&#56196;&#56411;&#55576;&#56575;\u1927&#55937;&#56562;&#55352;&#56681;&#55458;&#57098;&... |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0\uda40\uddda\uda65\udc35\udadf\uddc2\udb91\uded1\udb84\udc5b\ud918\udcff\u1927\uda81\udcf2\ud838\udd69\ud8a2\udf0a\udbb5\udc95\uda13\udd61\ud91f\uddea-->\0121=org.jsoup.nodes.Attributes: comment=\"&#55415;&#56886;&#55635;&#56611;&#56157;&#56926;&#55948;&#56400;&#56024;&#56664;&#55937;&#56355;&#55697;&#57125;&#56143;&#56458;&#55507;&#56496;&#55872;&#56794;&#55909;&#56373;&#56031;&#56770;&#56209;&#57041;&#56196;&#56411;&#55576;&#56575;\u1927&#55937;&#56562;&#55352;&#56681;&#55458;&#57098;&... |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0\uda40\uddda\uda65\udc35\udadf\uddc2\udb91\uded1\udb84\udc5b\ud918\udcff\u1927\uda81\udcf2\ud838\udd69\ud8a2\udf0a\udbb5\udc95\uda13\udd61\ud91f\uddea-->\012",
        Z.run(T, 2, 5, 5, 10, "\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0\uda40\uddda\uda65\udc35\udadf\uddc2\udb91\uded1\udb84\udc5b\ud918\udcff\u1927\uda81\udcf2\ud838\udd69\ud8a2\udf0a\udbb5\udc95\uda13\udd61\ud91f\uddea", "\u4c9d\u828b\u50fd\u7eac\u9b01\u2d00\ub19b\u4e92\u5db9\u962c\u27f4\u8a91\u7029\u65de\ucf3d", "\ud977\udda2\udbf5\udd73\udb36\uddd4",
        13, 23335, -269756527, 8361115285289594100L, 69054L, false, false, (char) 55593, (char) 6607,
        Double.longBitsToDouble(0x3fe43360a67da3d6L), Double.longBitsToDouble(0x3fdca1ad0ae805b8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"&#55415;&#56886;&#55635;&#56611;&#56157;&#56926;&#55948;&#56400;&#56024;&#56664;&#55937;&#56355;&#55697;&#57125;&#56143;&#56458;&#55507;&#56496;&#55872;&#56794;&#55909;&#56373;&#56031;&#56770;&#56209;&#57041;&#56196;&#56411;&#56201;&#57176;&#55822;&#56654;&#55937;&#56562;&#55352;&#56681;&#... |this=org.jsoup.nodes.Comment:\012<!--\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0\uda40\uddda\uda65\udc35\udadf\uddc2\udb91\uded1\udb84\udc5b\udb89\udf58\uda0e\udd4e\uda81\udcf2\ud838\udd69\ud8a2\udf0a\udbb5\udc95\uda13\udd61\ud91f\uddea-->\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 10, "\ud877\ude36\ud953\udd23\udb5d\ude5e\uda8c\udc50\udad8\udd58\uda81\udc23\ud991\udf25\udb4f\udc8a\ud8d3\udcb0\uda40\uddda\uda65\udc35\udadf\uddc2\udb91\uded1\udb84\udc5b\udb89\udf58\uda0e\udd4e\uda81\udcf2\ud838\udd69\ud8a2\udf0a\udbb5\udc95\uda13\udd61\ud91f\uddea", "\u4c9d\u828b\u50fd\u7eac\u9b01\u2d00\ub19b\u4e92\u5db9\u962c\u27f4\u8a91\u7029\u65de\ucf3d", "\ud977\udda2\udbf5\udd73\udb36\uddd4\u9c24\udb35\udcca\ud991\ude9e\uda19\udce4\ud96b\uddfc\ud9e5\udf82\uda3c\udea9\uda71\ude9a\ud9e4\udc3b\uda0b\ude04\uda5f\udd17\ud9f2\udc11\ud85f\uddf5\udba8\udd06\udb7c\udfcd\ud8fe\ude24\ud8db\ude56\ud822\uddcc\ud8d4\udc2b\udaf8\udca2\udbfb\ude4a\uda4c\ude3b\udb84\udec2\ud96a\udc7e\uda97\udf7d\ud8b9\udebc",
        46, 91302, -1875041388, -659689417736595668L, -58367L, false, false, (char) 16572, (char) 24347,
        Double.longBitsToDouble(0x3fd7f41a80ff6c50L), Double.longBitsToDouble(0x3fe3af5a89c5c33dL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 3, 10, "\ud9fb\udf58\ud953\udd23\udb5d\ude5e\uda8c\udc50\ud8ba\udf89", "\u1a14\u988e\u394e\uc6d8\uaf7d\u0190\ua8e5\uc532\ua8b3\u1ce0\u6cd4\uaf88\uc2ca\u23d0\u9d30\uadfb\ub440", "\ud83e\udea7\uda48\udf13\udbb7\udf8b\udbc3\udcaa\ud929\udd4d\ud9d5\udd8b\udaac\ude28\uda0b\udddb\udac5\udc8b\udaa0\udf5b\udb05\udeb4\ud9ef\udfc8\ud945\udf25\ud819\udf33",
        0, 58568, 1549092867, -2766349162575706647L, -70449L, false, false, (char) 57596, (char) 56225,
        Double.longBitsToDouble(0x3fb797fcb5071890L), Double.longBitsToDouble(0x3fbcbf3f7cc7cac0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Node|absUrl|java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|addChildren|int,[Lorg.jsoup.nodes.Node;|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|addChildren|[Lorg.jsoup.nodes.Node;|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|attr|java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|attr|java.lang.String,java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|attributes||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|baseUri||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|childNode|int|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|childNodes||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|childNodesAsArray||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|clone||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|doClone|org.jsoup.nodes.Node|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|equals|java.lang.Object|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|getOutputSettings||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|hasAttr|java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|hashCode||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|absUrl|java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
