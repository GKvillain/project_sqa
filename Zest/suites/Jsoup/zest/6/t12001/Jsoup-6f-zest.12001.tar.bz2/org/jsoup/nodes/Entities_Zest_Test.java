package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Entities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 2, "\ud955\udcff\udbae\udc9c\udac1\udfe2\udba6\udcf7\ud8d6\ude39\udb04\ude93\uda0c\udd4b", "\uba16\ua39d\u1d68\u75d8\u1516\u3d0b\u9e7d\ucfc8\u5ae3\u4c84\u4936\uc093\u6d01\u452b\u126f\u0436\ud35d\u2012\u6bc3\ubb48\u6f0e\u0663\u1d5c\ub0cf\ud15e\u5649\u3989\u5d26\u5d2a\uc8b4\ua1e0\u7eb6\u793f\ucc71\u11cb\u75b5\uc151\u00a6\u5d8d\u8b77\u96d9\u0b6c\u6449\uccc3\uaabc\uc424\u1d3c\u4a4f\ua460\u6e8f", "\udbae\udd93\udafc\udf54\ud91c\udc38\ud903\udd1d\uda49\udf86\udb8b\udc45\ud95a\uddc0",
        58, 28911, 299464715, 6521935456362965775L, -21445L, false, true, (char) 59756, (char) 29592,
        Double.longBitsToDouble(0x3fe0844eb6e8cc1cL), Double.longBitsToDouble(0x3fb45320a2dd34b0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 1, "\ud955\udcff\udbae\udc9c\udac1\udfe2\udba6\udcf7", "\u2469", "\udbd1\udf92\udbfa\udebf\ud805\udf61\ud86a\udcc8\ud91d\udc29\udbc9\udd1a\ud98d\udf6f\udbd3\udc3e\udb3a\ude8e\udb4d\udfe2\udab5\uded0\udb9e\udf53\udbca\udd81\ud933\udd1f\uda6f\udf84\ud875\udd7a\ud8df\udf8a\udaaf\udc3a\uda3d\udc28\udb0e\udd0f\ud949\udf62\ud8bb\udeb1\udb5e\udf49\udab2\udc9b\uda14\udff7\udb86\udc88\udaf3\udd7c\ud975\udcc6\ud814\udf90\ud89a\udd9a\ud9c3\udd1a\ud969\udca7\ud92a\udea2\ud8cd\udd6e\ud84c\ude7c\ud923\udecd\ud9c0\udf55\uda9c\udd20\udab8\udd11\udb5a\udd2d\udb11\udd38\ud9d0\udfab\ud850\udc00\ud80f\udc8e\uda54\udf7c\ud98f\udfbe\udb10\uddbc\udb08\udcdd\udae9\udf8c\udbb1\ude83",
        41, 12445, -2115227390, -3334979230591222357L, -1966L, false, true, (char) 37255, (char) 46269,
        Double.longBitsToDouble(0x3fdbf370a01626b0L), Double.longBitsToDouble(0x3fdbe11d961eb504L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 3, 2, 2, "\ud955\udcff\ud801\ude85\uda62\udf32\udbbb\udee8\ud8d6\ude39\udb04\ude93\uda0c\udd4b", "\uba16\u919e\u1d68\u75d8\u1516\u3d0b\u9e7d\ucfc8\u5ae3\u5e6f\u1806\uc093\uc36b\u03ea\u01b6\u0420\ud35d\u8517\u6bc3\ubb48\u6f0e\u0663\u1d5c\ub0cf\ud15e\u5649\u12b8\u5d26\u5d2a\uc8b4\ua1e0\u7eb6\u793f\ucc71\u11cb\u75b5\u5254\u46b8\u42ae\u9872\u189b\u0b6c\u6449\uccc3\uaabc\u4af3\u50ed\u5742\ua460\u6e8f", "\udbae\udd93\ud83a\udf53\ud91c\udc14\ud889\udc0b\udb57\udd2f\ud930\udf2a\u41cf\ud9c7\udc5c\udb50\udee2\ud8fa\uddbd\ud9d1\udf13\udbef\udcd8\ud95a\udd48\udbb0\udddc\udb2d\ude73\udaa7\udec8\ud905\udc15\u58db\ud91e\udca4\ud8b2\udc17\ud801\udc78",
        53, 18966, -1944256124, -4085849116931751094L, 68048L, false, true, (char) 5435, (char) 20846,
        Double.longBitsToDouble(0x3fd699e26721cff4L), Double.longBitsToDouble(0x3feac8b712aa9e66L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 2, "\ud89e\ude2e", "\u52d2\ube0f\u19bf\u1f0a\u80ad", "\ud85b\udeef\ud805\udf61\ud86a\udcc8\ud91d\udc29\udbc9\udd1a\ud98d\udf6f\udbd3\udc3e\udb3a\ude8e\udb4d\udfe2\udab5\uded0\ud89c\udf52\udbca\udd81\ud933\udd1f\uda6f\udf84\ud875\udd7a\ud8df\udf8a",
        15, 69620, 33114354, -7186569339356621345L, -100000L, false, true, (char) 230, (char) 9354,
        Double.longBitsToDouble(0x3fcdfdc93312fc00L), Double.longBitsToDouble(0x3fd890dd6c391fdaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\ud955\udcff\udbae\udc9c\udac1\udfe2\udba6\udcf7\ud8d6\ude39\udb04\ude93\uda0c\udd4b\012",
        Z.run(T, 1, 0, 0, 0, "\ud955\udcff\udbae\udc9c\udac1\udfe2\udba6\udcf7\ud8d6\ude39\udb04\ude93\uda0c\udd4b", "\uba16\u0ee4\000\u7e29\u1516\u3d0b\u8d9a\000\000\u9ef6\u4936\uc093\u6d01\u452b\u126f\u0436\u9fcf\u2012\u6bc3\ubb48\u6f0e\u0663\u1d5c\ub0cf\ud15e\u5649\ua132\u5d26\u5d2a\u0089\u8bc4\u7eb6\u793f\ucc71\u11cb\u75b5\uc151\uc5a5\u5d8d\u8b77\u96d9\u0b6c\u6449\uccc3\u8abc\u45a1\u48d4\u4a4f\ua460\u6e8f", "\udbae\udd93\udafc\udf54\uda49\uddaf\000\000\udb8b\udc45\ud95a\uddc0",
        58, 28911, 299464715, 160245977066255L, -21445L, false, true, (char) 59756, (char) 54269,
        Double.longBitsToDouble(0x3fe0844eb6e8cc1cL), Double.longBitsToDouble(0x3fb45320a2dd34b0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 2, "\ud955\udcff\udbae\udc9c\udac1\udfe2\udba6\udcf7\ud8d6\ude39\udb04\udf1f\uda0c\ude3a", "\uba16\ua39d\u1d68\u1b9e\u41ca\u936f\u9e7d\ucfc8\u5ae3\u0800\u1162\uc5de\ube47\uac33\u126f\u0436\ud365\ua6c6\u6bc3\ubb48\u6f0e\ub877\ub86e\u9db1\ud160\u9e95\u8944\ua6f8\u5d2a\uc8b4\ua1e0\u7eb6\u793f\ucc71\uaf5d\u821c\ua9c5\u9201\u47c6\u3a45\u52f4\u0b5c\u6449\uccc3\uaabc\u1fb3\u6171\u00cb\ua460\u6e8f", "\udbae\udd93\udafc\udf54\ud91c\udc38\ud903\udd1d\ud898\udcd8\ud9c4\udcf5\ud9fb\udf5d",
        -4, 28911, -858818549, 6521935456362965775L, -21445L, false, true, (char) 59756, (char) 29592,
        Double.longBitsToDouble(0x3fe4dc4eb6e8cc1cL), Double.longBitsToDouble(0x3fb45320a2dd34b0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=java.lang.String:\ud955\udcff\udbae\udc9c\udac1\udfe2\ud90e\udf05\ud8d6\ude76\udb04\ude93\uda0c\udd4b\012",
        Z.run(T, 2, 3, 0, 2, "\ud955\udcff\udbae\udc9c\udac1\udfe2\ud90e\udf05\ud8d6\ude76\udb04\ude93\uda0c\udd4b", "\uba16\ua39d\u1d68\u0448\uce4d\ub669\u9e94\ucfc8\u5ae3\u4c84\u4936\uc093\u6d01\u452b\u126f\u0436\ud35d\u2012\u6bc3\ucf03\ube5b\u0663\u1d5c\u87da\ubada\u800a\u3989\u5d26\u5d2a\uc8b4\ua1e0\ud34b\u7a0a\ucc71\u11cb\u6350\uc136\u78c6\u5e07\u8b77\u96d9\u0b6c\u6449\uccc3\uaabc\uc424\u1cdc\u4a4f\ua460\u6e8f", "\udbae\udd93\ud898\udee2\ud8f7\udc56\uda06\udddf\ud9ef\uddf6\ud9e4\uddf8\ud95a\uddc0",
        51, 42261, 299464715, 7026338614758583075L, -32506L, false, true, (char) 40290, (char) 25073,
        Double.longBitsToDouble(0x3feb9e6fc8d62efdL), Double.longBitsToDouble(0x3fe3bc65720a28b2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\ud955\udcff\ud93c\udca3\udac1\udfe2\udba6\udcf7\ud8d6\ude39\udb04\ude93\ud80f\ude6c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 2, "\ud955\udcff\ud93c\udca3\udac1\udfe2\udba6\udcf7\ud8d6\ude39\udb04\ude93\ud80f\ude6c", "\uba16\ua39d\u1d68\u75d8\u1516\u3d0b\u9e7d\ucfc8\u5ae3\u4c84\u4936\uc093\u6d01\u452b\u126f\u0436\ud35d\u2012\u6bc3\ubb48\u6f0e\u0663\u1d5c\ub0cf\ud15e\u5649\u3989\u5d26\u5d2a\uc8b4\ua1e0\u7eb6\ua53e\u55ed\u2463\u7038\uc151\u00a6\u1ff8\u1aa1\u6ea9\u0b6c\u6449\uccc3\uaabc\uc424\u1d3c\u4a4f\ua460\u6e8f", "\udbae\udd93\udafc\udf54\ud9b8\ude06\ud903\udcf4\uda49\udf86\udb8b\udc45\ud95a\uddc0",
        45, 84094, 299464715, 1487917126102170514L, -21445L, false, true, (char) 59756, (char) 29592,
        Double.longBitsToDouble(0x3fe0844eb6e8cc1cL), Double.longBitsToDouble(0x3fb45320a2dd34b0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 3, 2, 3, "\ud8da\udfe2\ud96f\udc46\uda62\udf32\udbbb\udee8\ud8d6\ude39\udb04\ude93\ud8bf\uddc5", "\uba16\u919e\u1d68\u75d8\u1516\u01a5\ua40e\u310d\u0685\u5e6f\u1806\uc093\uc36b\u03ea\u7801\u03ba\ud35d\u8517\u6bc3\ubb48", "\udae7\udc2c",
        21, 20878, -1779423562, -68574475434840908L, 46359L, false, false, (char) 61794, (char) 4228,
        Double.longBitsToDouble(0x3fdb77e9fd6a7e1aL), Double.longBitsToDouble(0x3fb66e16b4014d28L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\ud89e\ude2e\udbae\udc9c\udac1\udfe2\ud916\udc96\ud8d6\ude39\udb04\ude93\u1f0a\ud8c2\udcb4\ud9aa\udd9d\udbd1\udf92\ud9c3\ude43\ud96d\ude3f\uce64\ud842\ude9d\udbd3\udf2e\ud98d\udf6f\udbd3\udc3e\udb3a\ude8e\udb4d\udfe2\udab5\uded0\ud89c\udf52\udbca\udd81\ud933\udd1f\uda6f\udf84\ud875\udd7a\ud8df\udf8a\udaaf\udc3a\uda61\udc1a\udb0e\udd0f\ud95e\udc3e\uda9e\udc59\uda6d\udcce\000\ud980\udf4d\udb83\udfe1\udaf3\udd7c\ud957\udcef\udaf9\udd94\ud8af\udeee\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 2, "\ud89e\ude2e\udbae\udc9c\udac1\udfe2\ud916\udc96\ud8d6\ude39\udb04\ude93\u1f0a\ud8c2\udcb4\ud9aa\udd9d\udbd1\udf92\ud9c3\ude43\ud96d\ude3f\uce64\ud842\ude9d\udbd3\udf2e\ud98d\udf6f\udbd3\udc3e\udb3a\ude8e\udb4d\udfe2\udab5\uded0\ud89c\udf52\udbca\udd81\ud933\udd1f\uda6f\udf84\ud875\udd7a\ud8df\udf8a\udaaf\udc3a\uda61\udc1a\udb0e\udd0f\ud95e\udc3e\uda9e\udc59\uda6d\udcce\000\ud980\udf4d\udb83\udfe1\udaf3\udd7c\ud957\udcef\udaf9\udd94\ud8af\udeee", "\u5cb1\ua2b2\u650d\u8717\u7e21\u7cc5", "\ud9f6\ude1b\ud9ac\ude0e",
        46, 21894, 266976649, -2529052520356790314L, -22618L, false, true, (char) 14262, (char) 59785,
        Double.longBitsToDouble(0x3fe1a90c209c2a5fL), Double.longBitsToDouble(0x3fd5b2ba1cc81d4eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 2, "\ud89e\ude2e", "\ub072\u5e17\u19bf\u1f0a\u80ad", "\ud85b\udeef\udad5\udc69\uda98\udc05\ud91d\udc29\udbc9\udd1a\ud98d\udf6f\udbd3\udc3e\udb68\udef1\udb4d\udfe2\udafc\ude34\uda89\udf71\ud8da\udd09\uda2f\udd73\uda6f\udf84\ud875\udd7a\ud8df\udf8a",
        15, 69620, 33114354, -7186569339356621345L, -100000L, false, true, (char) 230, (char) 27813,
        Double.longBitsToDouble(0x3fcdfdd76cd10400L), Double.longBitsToDouble(0x3feddac2de1c8ffaL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud955\udcff\udbae\udc9c\udac1\udfe2\ud90e\udf05\ud8d6\ude76\udb04\ude93\uda0c\udd4b", "\uba16\ua39d\u1d68\u0448\uce4d\ub669\u9e94\ucfc8\u5ae3\u4c84\u4936\uc093\u6d01\u452b\u126f\u0436\ud35d\u2012\u6bc3\ucf03\ube01\u0663\u1d5c\u87da\u5608\ub09a\u6229\u5d26\u5d2a\uc8b4\ua1e0\ud34b\u7a0a\ucc71\u11cb\u6350\uc136\u78c6\u5e07\u8b77\u96d9\u0b6c\u6449\uccc3\uaabc\uc424\u1cdc\u4a4f\ua460\u6e8f", "\udbae\udd93\ud898\udee2\ud8f7\udc56\uda06\udddf\ud9ef\uddf6\ud9e4\uddf8\ud95a\uddc0",
        51, 42261, 299464715, 7026338614758583075L, -32506L, false, true, (char) 40290, (char) 25073,
        Double.longBitsToDouble(0x3feb9e6fc8d62efdL), Double.longBitsToDouble(0x3fe3bc65720a28b2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\udb7e\uddee\udbae\udc9c\ud888\udeed\ud90e\udf05\ud8d6\ude76\udb04\ude93\uda0c\udd4b\0121=java.lang.String:\udb7e\uddee\udbae\udc9c\ud888\udeed\ud90e\udf05\ud8d6\ude76\udb04\ude93\uda0c\udd4b\012",
        Z.run(T, 2, 0, 0, 2, "\udb7e\uddee\udbae\udc9c\ud888\udeed\ud90e\udf05\ud8d6\ude76\udb04\ude93\uda0c\udd4b", "\uba16\ua39d\uc4cf\uc02a\ud572\ub669\u9e94\ucfc8\u5ae3\u4c84\u4936\uc093\u6d01\u4bfc\u939f\u53f0\ud35d\u2012\u6bc3\ucf03\ube5b\u0663\u1d5c\u87da\ubada\u800a\u897e\u5d26\u5d2a\u2f6f\u2ff4\ud3ad\u7a0a\ucc71\u11cb\u6350\u59cd\u5145\u5e07\u1491\u7c85\u0b6c\u6449\uccc3\uaabc\u3d9d\u1cdc\u4a4f\ua460\u6e8f", "\ud974\uddf5\ud898\udee2\ud8f7\udc56\uda06\udddf\ud9ef\uddf6\ud9e4\uddf8\ud95a\uddc0",
        51, 42261, 299464715, 7026338614758583075L, -69506L, false, true, (char) 40290, (char) 25073,
        Double.longBitsToDouble(0x3feb9e6fc8d62efdL), Double.longBitsToDouble(0x3fe3bc65720a28b2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 0, 1, 0, "", "\uca1f\u14ce\000", "\ud8c2\udcb4\ud9aa\udd9d\udbd1\udf92\ud9c3\ude43\ud96d\ude3f\uce64\ud842\ude9d\udbd3\udf2e\ud98d\udf6f\udbd3\udc3e\udb3a\ude8e\udb4d\udfe2\udab5\uded0\ud89c\udf52\udbca\udd81",
        37, 39779, 815325853, 245563501508608L, 77934L, false, true, (char) 46941, (char) 59675,
        Double.longBitsToDouble(0x3f3adf1a20000000L), Double.longBitsToDouble(0x3ec3fa23f8040000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 3, 3, 2, "\uda0c\udeb6", "\ub072\u5e17\u19bf\u1f0a\u80ad", "\ud85b\udeef\udad5\udc69\uda98\udc05\uda57\ude66\udae4\udf20\ud8b3\ude87\udbd3\udc3e\udb68\udef1\udb4d\udfe2\udafc\ude34\uda89\udf71\ud8da\udd09\uda2f\udd73\uda6f\udf84\ud875\udd7a\ud8df\udf8a",
        15, 69620, 33114354, -7186569339356621345L, -100000L, false, true, (char) 230, (char) 27813,
        Double.longBitsToDouble(0x3fcdfdd76cd10400L), Double.longBitsToDouble(0x3feddac2de1c8ffaL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 1, 1, 1, "", "\u220e\u140a\000", "\ud8c2\udcb4\ud9aa\udd9d\udbd1\udf92\ud9c3\ude43\ud96d\ude3f\uce64\udba1\ude0b\udbd3\udf2e\udbc4\udc6a\udbd3\udc3e\ud9d5\udf9c\ud881\ude17\udab5\uded0\ud89c\udf52\udbca\udd81",
        3, 39779, 2123948701, -5061600098814532920L, 77934L, false, true, (char) 46941, (char) 59675,
        Double.longBitsToDouble(0x3fea83064bf44b71L), Double.longBitsToDouble(0x3ec3fa23f8040000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 1, 1, 0, "", "\uca1f\u14ce\u7782", "\ud8c2\udcb4\ud9aa\udd9d\udbd1\udf92\ud9c3\ude43\ud96d\ude3f\uce64\ud842\ude9d\udbd3\udf2e\udad3\udd9b\udbd3\udc3e\udb3a\ude8e\udb4d\udfe2\udab5\uded0\ud89c\udf52\udbca\udd81",
        37, 39779, 815325853, 245563501508608L, 77934L, false, true, (char) 62557, (char) 59137,
        Double.longBitsToDouble(0x3fe5c6ef03440026L), Double.longBitsToDouble(0x3f40d3ec8239a800L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 2, "\ud955\udcff\udbae\udc9c\udac1\udfe2\udba6\udcf7\ud8d6\ude39\udb04\ude93\uda0c\udd4b", "\uba16\ua39d", "\udbf5\ude0d\udbc9\udd1a\ud98d\udf6f\udbd3\udc3e\udb3a\ude8e\udb4d\udfe2\udab5\uded0\udb9e\udf53\udbca\udd81\ud933\udd1f\uda6f\udf84\ud875\udd7a\ud8df\udf8a\udb95\udd0d\uda3d\udccd\udb0e\udd0f\ud949\udf62\ud8bb\udeb1\udb5e\udf49\udab2\udc9b\uda14\udff7",
        14, 46104, -1086909969, 997086362512233865L, -5353L, true, false, (char) 40115, (char) 55632,
        Double.longBitsToDouble(0x3fedb1f11f295beaL), Double.longBitsToDouble(0x3fe9390322a0de84L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,java.nio.charset.CharsetEncoder,org.jsoup.nodes.Entities$EscapeMode|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,org.jsoup.nodes.Document$OutputSettings|static",
    "C|org.jsoup.nodes.Entities|<init>|",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
