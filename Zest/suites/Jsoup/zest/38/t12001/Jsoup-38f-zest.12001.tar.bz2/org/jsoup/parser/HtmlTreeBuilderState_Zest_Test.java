package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilderState_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 2, 4, "\udbe2\ude95\ud94d\udf47\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d\ud8c2\udeaa\ufc46\ue1d0\ud976\ude5d\ud8a9\udecc\udab8\uddc2\udb0f\udc5a\ud9fd\udc5d\ud5ae\ud83e\ude30\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\uda29\udf02", "\u0f7e\ucaa4\u4555\u659f\uc806\ua110\u1e82\u384a\u3854", "\udb09\udf4f\udbc5\udd65\ud914\uddb0\udb61\udd49",
        -3, 47342, -1779998494, 9201353229222991846L, 15652L, false, true, (char) 26034, (char) 56553,
        Double.longBitsToDouble(0x3fe5786410fd1e4aL), Double.longBitsToDouble(0x3faa196ffc8591e0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 4, 3, "\udbe2\ude95\ud94d\udf47\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d\ud8c2\udeaa\ufc46\ue1d0\udb80\udec0\ud923\udfad\udab8\uddc2\udb0f\udc5a\ud9fd\udc5d\ud5ae\ud83e\ude30\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\uda29\udf02", "\u0f7e\u3655\u4555\u659f\uc806\ua110\u1e82\u384a\u3854", "\udb09\udf4f\udbc5\udd65\ud914\uddb0\udb61\udd49\ud857\udfa3\uda3b\udf7f\ud956\udea1\ud9ff\udd88\uda15\udd95",
        15, 49244, 918231478, -4003085480177298313L, -50904L, true, false, (char) 63692, (char) 47380,
        Double.longBitsToDouble(0x3fd41b5afb2e76a0L), Double.longBitsToDouble(0x3feda4f2ba3b6ec8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 4, 0, "\udbe2\udf34\ud94d\udf47\udbb5\ude6b\ud8d4\udf8d\udb20\udfa9\udac2\ude91\ud94e\udd57\uda5b\udcbf\uda3f\udf3f\ud982\udd47\udb20\udf38\ud97e\udde0\udbea\udc5c\udb1d\ude84\ud9bb\udd6d\ud8c2\udeaa\ufc46\ue1d0\ud976\ude5d\ud8a9\udecc\udab8\uddc2\ud960\udde3\udb77\udcad\ud591\udbf3\ude5f\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\ud828\udeb5", "\u0f7e\ucaa4\u4555\u659f", "\ud8cd\udf80\udace\udf04\udb0f\udd6c",
        6, 88674, -1806242392, -8191568227404625792L, 52867L, false, true, (char) 17201, (char) 23246,
        Double.longBitsToDouble(0x3fd5220327c7b174L), Double.longBitsToDouble(0x3fae415067465000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 0, "\udbe2\ude95\ud95f\udd8b\udbb5\ude6b\udaeb\udd82\ud81a\udee4\udb9b\ude07\udb34\udea2\uda69\udff1\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d", "\u2415\u2a78\u5d0a\u81da", "\ud5ae\ud83e\ude30",
        34, 11848, 90944483, -7009348553034605926L, 19292L, true, false, (char) 1078, (char) 47049,
        Double.longBitsToDouble(0x3fbc87c007446610L), Double.longBitsToDouble(0x3febe50d1247bbadL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 4, "\udbe2\ude95\ud94d\udf47\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\uda39\udd16\ud982\udd53\uda8b\udc15\udb70\udc9c\udaed\udd3a\ud8e2\udfab\ud9d8\ude56\udad2\udeb2\ufc46\ud936\udcb0\ud945\udd6e\ud8d9\udf00\ud997\udd15\ud847\udfe7\uda86\udc21\udaab\udda8\udada\ude5f\ud98d\uddd2\ud97f\udd21\udb84\udd47\ud945\udc28", "\u2c32", "\ud996\udd22\ud99a\uddd1\ud954\udeba\ud8d2\udf75\udace\udf04\ud8d7\udee4\ud9c4\udccf\ud83c\udcb7\udb09\udf4f\udbc5\udd65\ud914\uddb0\udb61\udd49\ud857\udfa3\uda65\udf75\udbea\ude62\ud98a\ude6c\uda09\ude66\uda07\udc7f\u12b6\udabb\udcef\udb7e\udfb0\udabf\udd33\u3c8a\ud9c8\udfc8\ud9f7\udc71\ud9c8\udf6b\uda19\udf84\udb62\udf28\ud920\uddf9\udbd8\udcb4\ud8d8\udee8\udb81\ude46",
        17, 16013, -1992573900, -3307746296427587140L, 49416L, false, true, (char) 24768, (char) 13567,
        Double.longBitsToDouble(0x3fd80dab2dd9ce24L), Double.longBitsToDouble(0x3fd3b1b391372f72L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 2, "\udbe2\ude95\ud94d\udf47\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d\ud8c2\udeaa\ufc46\ue1d0\ud976\ude5d\ud8a9\udecc\udab8\uddc2\udb0f\udc5a\ud9fd\udc5d\ud5ae\ud83e\ude30\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\uda29\udf02", "\u0f7e\ucaa4\u4555\u659f\uc806\ua110\u1e82\u384a\u3854", "\udb09\udf4f\udbc5\udd65\uda9c\uddb4\udb61\udd49",
        -3, 47342, -1779998494, 9201353229222991846L, 15652L, false, true, (char) 26034, (char) 56553,
        Double.longBitsToDouble(0x3fe5786416fd1e4aL), Double.longBitsToDouble(0x3faa45ef7c8591e0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 2, 4, "\udbe2\ude95\ud94d\udf47\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb31\udfde\u1e95\ud9bb\udd6d\ud8c2\udeaa\ufc46\ue1d0\ud976\ude5d\ud8a9\udecc\udac7\uddc2\udb0f\udc5a\ud9fd\udc5d\ud5ae\ud83e\ude30\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\uda29\udf02", "\u0f7e\u61a5\u8555\u659f\uc806\ua110\u1e82\u384a\u3854", "\ud871\udcd0\udbc5\udd65\ud914\uddb0\udb61\udd49\ud857\udfa3\uda3b\udf7f\ud956\udea1\ud9f1\udec2\uda15\udd95\uda07\udc7f\ud8c8\udfb8\ud90a\udce4\udb7e\udeeb\udabf\udd33\ue71e\ud9c8\udf01",
        38, 86856, -1999839979, 5023852279227160409L, -75798L, true, false, (char) 48968, (char) 65522,
        Double.longBitsToDouble(0x3fd0311ba1ef5086L), Double.longBitsToDouble(0x3fe91494c93b2e7eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 1, 5, 0, 5, "\udbe2\udf1d\ud94d\udf47\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\ud859\udd5a\ud91a\ude07\uda8a\udfbb\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d\ud8c2\udea9\ufc46\ud816\uded0\uda74\ude5c\ud8a9\udecc\udab8\uddc2\udb0f\udc5a\ud9fd\udc5d\ud5ae\ud83e\ude30\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\uda29\udf02", "\u0f7e\ucaa4\u4555\u659f\uc806\ua110\u1e82\u384a\u3854", "\udabe\udc29\uda0e\udf1d\ud914\uddb0\udb61\udd49",
        -3, 47342, -1779998494, 9201353229214223512L, 15652L, false, true, (char) 26034, (char) 56553,
        Double.longBitsToDouble(0x3fe5786410fd1e4aL), Double.longBitsToDouble(0x3faa196ffc8591e0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 0, "\udbe2\ude95\ud979\udf17\ud926\udd69\ud915\udc06\ud95a\uddcb\udb37\udc31\ud83b\udce6\udb5f\udf8a\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d", "\u357d\ub940\u5d0a\u81da", "\ud5ae\ud83e\ude30",
        3, 96056, 90944483, -7009348553031549798L, -15268L, true, false, (char) 8647, (char) 47049,
        Double.longBitsToDouble(0x3fbc87c010bbb610L), Double.longBitsToDouble(0x3f805e0a89d42040L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 0, "\udbe2\ude95\udbe7\udf4f\udbb5\ude75\ud93c\ude95\ud81a\udee4\udb9b\ude07\udb34\udea2\uda69\udff1\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d", "\u99a8\u6b10\u5d0a\u8134", "\ud5ae\ud83e\ude30",
        34, 11848, 90944483, -7009348553034605926L, 19292L, true, false, (char) 50623, (char) 51618,
        Double.longBitsToDouble(0x3fdb2c922c2728c4L), Double.longBitsToDouble(0x3fd465c42c23775aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 1, "\udbe2\ude95\ud94d\udf47\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d\ud8c2\udeaa\ufc46\ue1d0\ud976\ude5d\ud8a9\udecc\udab8\uddc2\udb0f\udc5a\ud9fd\udc5d\ud5ae\ud83e\ude30\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\uda29\udf02", "\u0f7e\ucaa4\u4555\u659f\uc806\ua110\u1e82\u384a\u3854", "\udacb\udcc3\udbc5\udd65\uda9c\uddb4\udb61\udd49",
        -3, 47342, -1779998494, 9201353229222991846L, 15652L, false, true, (char) 26034, (char) 56553,
        Double.longBitsToDouble(0x3fe5786416fd1e4aL), Double.longBitsToDouble(0x3faa45ef7c8591e0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 2, 5, 5, 2, "\udbe2\ude95\ud94d\udf47\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\ud920\udf01\u5af0\ud9bb\udd6d\ud8c2\udeaa\udacb\ude2c\ubcf9\ud976\ude5d\ud8a9\udecc\udab8\uddc2\udb0f\udc5a\ud9fd\udc5d\ud5ae\ud83e\ude30\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\udb93\udef7", "\u0f7e\ucaa4\u4555\u659f\uca06\ua110\u1e82\u384a\u3854", "\udb09\udf4f\udbc5\udd65\ud81c\udf7c\udb61\udcbc",
        -3, 47342, -1779998494, 9201353229222991846L, 15652L, false, true, (char) 26034, (char) 56553,
        Double.longBitsToDouble(0x3fe5786416fd1e4aL), Double.longBitsToDouble(0x3faa45ef7c8591e0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 2, 5, 5, 1, "\uda6d\udc40\udac9\udcec\ud926\udd69\ud915\udc06\ud95a\uddcb\udb37\udc31\ud83b\udce6\udb5f\udf8a\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\udb39\ude9f", "\u357d\ub940\u5d0a\u81da", "\ud5ae\ud83e\ude30",
        3, -440, 90903078, 52295663314402882L, 79037L, true, false, (char) 13255, (char) 22742,
        Double.longBitsToDouble(0x3fbc87c035634e10L), Double.longBitsToDouble(0x3fe6f59c02383502L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 3, "\ud8c1\ude66\ud92b\udc13\udbb5\ude6b\uab09\udb5e\udde9\uda8b\udd28\ud94e\udd57\uda5b\udcbf\uda3f\udf3f\ud982\udd47\uda8b\udc15\udb70\udc9c\udb34\uddde\u1e95\ud9bb\udd6d\ud8c2\udeaa\ufc46\ue1d0\ud976\ude5d\ud8a9\udecc\udab8\uddc2\udb35\udeee\ud9fd\udc0d\ud5ae\ud83e\ude30\ud98d\uddd2\ud97f\udd21\ud9c3\udd8d\uda29\udf02", "\u0f7e\ucaa4\u4555\u659f\uc806\u7c10\u1e82\u384a\u3854", "\udb04\udf4f\udbc5\udd65\ud914\uddb0\udb61\udd49",
        -3, 8153, -1792328583, 9201353229222991846L, 15652L, false, true, (char) 26034, (char) 56553,
        Double.longBitsToDouble(0x3fe5786410fd1e4aL), Double.longBitsToDouble(0x3faa196ffc8591e0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilderState|process|org.jsoup.parser.Token,org.jsoup.parser.HtmlTreeBuilder|fac:org.jsoup.parser.HtmlTreeBuilderState:valueOf:java.lang.String",
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRawtext|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRcData|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|isWhitespace|org.jsoup.parser.Token|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|valueOf|java.lang.String|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|values||static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|process|org.jsoup.parser.Token,org.jsoup.parser.HtmlTreeBuilder|fac:org.jsoup.parser.HtmlTreeBuilderState:valueOf:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
