package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 10, "\udbce\udef3", "\uac49\u539c\u9bc0\u9912", "\ud8e0\udd06",
        28, 83779, -1406164865, -1982439580614231381L, 90994L, false, false, (char) 5470, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e7b01e593ba9L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 10, "\udbce\udef3", "\uac49\u539c\u9bc0\ucc55", "\ud8e0\udd06",
        28, 83779, -1406164865, -1982439580614231381L, 90994L, false, false, (char) 5470, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e7b01e593ba9L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 3, "\udbce\udef3", "\uac49\u539c\u9bc0\u9912", "\ud8e0\udd06\udaa1\uddbd\udb81\udc37\uda06\udf8e\udbbf\udc14\udbec\udd50\udb28\udcf1\ud8a3\uddfd\ud9c5\uddc2\uda77\udfe7\udba4\udf84\udafa\udd6c\ud92f\udc26\ud830\udde0",
        40, 46389, -1504629829, -4112605677897034595L, 4882L, true, true, (char) 37429, (char) 6341,
        Double.longBitsToDouble(0x3fd0b91ec0a3c8feL), Double.longBitsToDouble(0x3feb18fa7ed799d7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 10, "\udbce\udef3", "\uaba7\u539c\u9bc0\u9912", "\ud8e0\udd06",
        53, 83640, -1406164865, -1982439580614231381L, -100000L, false, false, (char) 47813, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e7b01e593ba9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 10, "\udbd4\udf14\udab8\ude26\ud810\udf1d\udad8\udd71", "\ud2e3\u9c46", "\udaa1\uddbd\udac0\uddea\uda32\udeae\udb40\ude0b\udb46\udf4e",
        55, 93514, 1519914210, -6467526653379619634L, -86877L, true, true, (char) 18228, (char) 53334,
        Double.longBitsToDouble(0x3fef46f36c4702e8L), Double.longBitsToDouble(0x3fd94c157e96904aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 10, "\udbce\udef3", "\uac49\u539c\ub407\u9912", "\ud8e0\udd06",
        28, 83779, -1406164865, -1982439580614231381L, -28850L, false, false, (char) 5470, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e7b01e593ba9L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 10, "\udbce\udef3", "\u3df9\u0a1a\u386a\u3413", "\ud8cc\udcba\uda0c\ude3e\ucc8d",
        51, 76253, 1892691053, 5281610343697541650L, 78886L, true, false, (char) 50825, (char) 14038,
        Double.longBitsToDouble(0x3fe2e7b01b593ba9L), Double.longBitsToDouble(0x3fd55dd099a1bf58L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\012",
        Z.run(T, 1, 2, 4, 10, "\udbce\udef3", "\uac49\u539c\u9bc0\u9912", "\uda3b\udd53\udb22\udca3\ud9a3\ude1f",
        57, 50241, 233461022, 5281635430608733893L, 78886L, true, false, (char) 50825, (char) 14038,
        Double.longBitsToDouble(0x3fe2e7b01e593ba9L), Double.longBitsToDouble(0x3fe3dd05514d7f29L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 9, "\udbce\udef3", "\uac49\u539c\u9bc0\u6ea7", "\ud8e0\udd06\udaa1\uddbd\udb81\udc37\udada\udfd1\udbbe\udf84\ud926\udd8d\ud90d\udc60\uda04\udc39\udb13\udc48\ud97f\udead\ud9d5\udf1a\ud8f2\udc59\ud92e\udff7\ud830\udde0\ud938\udc07\udbb3\udf32\udbf8\ude53\uda17\ude16\udaff\udf73",
        16, 34407, -1727118506, -750096818078399251L, -59370L, false, true, (char) 61523, (char) 36756,
        Double.longBitsToDouble(0x3fbb6582472d7648L), Double.longBitsToDouble(0x3fee5427d7cdf26fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 10, "\udbce\udef3", "\uac49\u5562\u9ffa\u9912", "\ud8e0\udd06",
        28, 46056, -1406164865, -1982439580614231381L, 90994L, false, false, (char) 5470, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e29ee8390a38L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 10, "\ud8dc\udd7e", "\uac49\u539c\u2c58\u9e81", "\ud8e0\udd06",
        28, 79064, -1406164865, -8539680638077685818L, 90994L, false, false, (char) 5470, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e7b01e593ba9L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 10, "\udbce\udef3", "\uac49\u539c\u9bc0\u603a", "\ud8e0\udd06",
        38, 83834, -1406164865, -1982439580614231381L, 90994L, false, false, (char) 5470, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e7b01e593ba9L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 0, 10, "\ud945\ude8e", "\uac4e\u539c\ud707", "\ud834\ude29\ud8e0\udd59\uda9f\udcbd\udb5a\udd37\uda06\udf8e\udbbf\udc14\udbec\udd50\udb28\udcf1\udb1d\ude5f\ud8d6\udf6b\uda21\udeb8",
        40, 78884, -167547715, 4299132639541554777L, 82097L, false, false, (char) 33997, (char) 13385,
        Double.longBitsToDouble(0x3fe67de45f78cd68L), Double.longBitsToDouble(0x3fe0abeb48183cc9L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 1, "\udb41\udfe9\udb44\udfa5\udac2\ude2c\udad8\udd30", "\u9912\u9c46", "\ud852\udff2\ud88c\udddc\udad2\ude77\udb87\udd14\udbec\udd50",
        31, 83794, 1519914210, 161771998109750478L, -62301L, false, false, (char) 43522, (char) 21051,
        Double.longBitsToDouble(0x3fc5e850599798b8L), Double.longBitsToDouble(0x3fee20918ea4c1ffL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 7, "\udbce\udef3\ua4aa\ud810\udf1d\udb96\udc76\udaab\ude7a\ud90f\udf62\uda42\udf13\udbd7\udf9b\ub094\ud8e0\udd06\udb72\udd45\ud91d\udfde\uda06\udf8e\ud910\udcfc\u0e1f\udbf5\udead", "\u2865\uc5fd\ud22b\uc868\u4d12\u363b\u2f72\u8b8d", "\ud80f\udea3\udacb\ude81\udb68\udecf\udb02\udff1\udbc2\udd44\ud899\udf1f\udad4\udc55\ud832\udfe6\ud98c\udf08",
        40, 49844, -2134305824, -7139790559803640406L, 33160L, false, false, (char) 51159, (char) 47430,
        Double.longBitsToDouble(0x3fd973acb70c936cL), Double.longBitsToDouble(0x3fe87a29b37c220dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 10, "\udbce\udef3\ua4aa", "\ua174\u9bc0\u9912\u9c46\u7220\u3f3a\u7615\u4ff1\ud79f\u37fd\u27fe", "\udaf2\ude38\udb99\udd7b\udba4\udf84\udae0\udf9e",
        -3, 58820, -136810919, 7738709183270728652L, 58790L, true, true, (char) 42581, (char) 17790,
        Double.longBitsToDouble(0x3fc3a5655064b878L), Double.longBitsToDouble(0x3fb9eb3e9a19a518L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 10, 3, "\udbce\udef3", "\uac49\u539c\u9bc0\u974b", "\ud8e0\udd06",
        -1, 55145, -1406181743, -1982439580614231381L, 92077L, false, false, (char) 5133, (char) 31598,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fd2ea503cb27752L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 11, 11, 2, "\udbce\udef3", "\uac49\u539c\u719d\u9912", "\ud829\ude0e\udbc8\uddef\udb93\udf37\uda06\udf8e\udbbf\udc14\ud9aa\ude0f\udb76\udc67\ud9d0\udca7\udaf2\udca0\uda60\udf47\ud917\udfe6",
        13, 10285, 1000969820, 3912342028063411514L, 89676L, true, false, (char) 45992, (char) 42141,
        Double.longBitsToDouble(0x3fea2e32c709f733L), Double.longBitsToDouble(0x3fed9d6cdb695a36L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 6, "\udb1b\udf2a", "\uac49\ud1af\u9b6b\u0e2e", "\ud8e0\udd24",
        31, 30146, -1406164861, -1982439580614231381L, -28850L, false, false, (char) 5470, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e7b476593ba9L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 7, "\ud976\uddec\u211b\ud810\udf1d\udad8\udd30\ud99b\udd6d\ud8dd\udd5d\uda42\udf13\udbd7\udf9b", "\u26b7\u6632\u42eb\u2c13\u4846", "\udaf2\udd9c\udb99\udd7b\udba4\udf84\udafa\udd6c\ud92f\udc26\ud830\udde0\ud81e\udf79\uda84\ude0b\ud8f5\udd09\udb62\udf19\ud8bb\udc61\ud821\udc78\ud98e\udcb8\udbe8\ude01\ud8f3\udcd5\udb41\udcca\ud9a7\udf91\udbd6\ude57\ud995\udd34\ud874\udf55\udb09\udd93\uda1e\uddd3",
        47, 30651, 604999052, -3109473315698220084L, -41989L, true, false, (char) 26465, (char) 14989,
        Double.longBitsToDouble(0x3fec9eeccc9719acL), Double.longBitsToDouble(0x3fc45a072f442fa8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 10, "\udbce\udef3", "\uac49\u5b9c\u9bc0\u9912", "\ud8e0\udd06",
        28, 83664, -1406143466, -1982439580614231381L, 90994L, false, false, (char) 5470, (char) 31500,
        Double.longBitsToDouble(0x3fc34e3df2f72860L), Double.longBitsToDouble(0x3fe2e7b01e593ba9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|crossStreams|java.io.InputStream,java.io.OutputStream|static",
    "M|org.jsoup.helper.DataUtil|emptyByteBuffer||static",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|mimeBoundary||static",
    "M|org.jsoup.helper.DataUtil|readFileToByteBuffer|java.io.File|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream,int|static",
    "C|org.jsoup.helper.DataUtil|<init>|",
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
