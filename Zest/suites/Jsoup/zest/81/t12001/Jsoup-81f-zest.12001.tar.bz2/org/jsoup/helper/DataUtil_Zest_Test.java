package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 13, 10, 8, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a", "\u28df\u6c9f\u17db", "\ud9b1\udfb3\udb55\ude6f\ud9b1\ude14\udb8f\ude66",
        3, 64552, -562175457, -2489632829021171459L, 10145L, true, true, (char) 28215, (char) 7229,
        Double.longBitsToDouble(0x3fb05f291d5b0040L), Double.longBitsToDouble(0x3fc2191ffc3ec358L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 13, 6, 8, "\udbfe\udebe\udb9d\udd63\udb71\udcf1", "\u55c5\u06b3\u17db", "\ud80f\udc96",
        54, 47950, -160962958, -1101069591541840573L, -37570L, true, false, (char) 18829, (char) 14642,
        Double.longBitsToDouble(0x3fda7c8e63fd13a4L), Double.longBitsToDouble(0x3fe75d7ce83a4429L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 3, 4, "\ud9c4\uddba", "\u4317\u7d8c\u28df", "\udadb\uded7\udb8c\udc2a\ud8ab\ude81\ud94f\udd65",
        41, 2935, 628617835, 1183443019118797343L, -8855L, false, false, (char) 15118, (char) 32689,
        Double.longBitsToDouble(0x3fdcd691b5e22866L), Double.longBitsToDouble(0x3fb0d67b1d5b0040L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 10, 8, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a", "\u28df\u6c9f\u17db", "\ud9b1\udfb3\udb55\ude6f\ud9b1\ude14\udb8f\ude66",
        -2, 64552, -562175457, -2489632829021171459L, 10145L, true, true, (char) 34991, (char) 14872,
        Double.longBitsToDouble(0x3fb05f291d5b0040L), Double.longBitsToDouble(0x3fc2191ffc3ec358L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 8, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a", "\u28df\u6c9f\u17db", "\ud9b1\udfb3\udb55\ude6f\ud9b1\ude14\udb8f\ude66",
        3, 64552, -562175457, -533381741875198989L, 10145L, true, true, (char) 28215, (char) 7229,
        Double.longBitsToDouble(0x3fb05f291d5b0040L), Double.longBitsToDouble(0x3fc2191ffc3ec358L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 11, 10, 8, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a", "\u28df\u6c9f\u17db", "\ud9b1\udfb3\udb55\ude6f\ud9b1\ude14\udb8f\ude66",
        3, 64552, -562175457, -2489632829021171459L, 10145L, true, true, (char) 28215, (char) 7229,
        Double.longBitsToDouble(0x3fe20be5256ac0daL), Double.longBitsToDouble(0x3fe05b109b06546dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 7, 6, 8, "\u13ad\udbc2\udfb6\udbbc\udf4a", "\u067e\u5ee9\u14e2", "\ud9ea\uddd4\udb48\udda9\udad4\udf1d\uda7a\udc80",
        50, 64552, -553655777, -2489632829021171459L, -50783L, true, true, (char) 11664, (char) 21423,
        Double.longBitsToDouble(0x3f861b5987785f80L), Double.longBitsToDouble(0x3fbcd22b7421ee20L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 13, 10, 8, "\udbfe\udebe\udb9f\udc15\udbbc\udf4a", "\u28ed\u6c9f\ua507", "\ud9b1\udfb3\udb55\ude6f\ud9b1\ude14\udb8f\ude66\ud8b8\udd80\udb3d\ude20\ud9c6\udc25",
        31, 45573, -1521527784, -3970396142689854047L, -10951L, true, true, (char) 29440, (char) 33661,
        Double.longBitsToDouble(0x3fe810261cdc955fL), Double.longBitsToDouble(0x3fe6152bdfddd92bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=!java.io.IOException\012",
        Z.run(T, 2, 0, 10, 8, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a", "", "\000\udaf2\ude42y\000\uda81\udf3f\ud9b1\ude14\udb8f\ude66\ud8b8\udd80\000\000\000\000\000\ud867\udcb3\ud812\uddb0\uda5d\ude57\ud994\ude49\uc041\ud867\udcb3\udac3\udfe5\uda7c\udefe\ud9d2\uded4\ud9ed\udd1c\udbe5\udd0c\uae47\ud801\udd7b",
        59, 93293, 947509010, 2649885082507639820L, 89953L, true, true, (char) 8993, (char) 62096,
        Double.longBitsToDouble(0x3fdbce62765ac2c8L), Double.longBitsToDouble(0x3fbc674cdd638ea8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 5, "\udbfe\udebe\udbed\udc6b\udbbc\udf4a", "\u28df\u6c9f\u17db", "\ud9b1\udfb3\udb55\ude6f\ud9b1\ude14\udb8f\ude66",
        3, 64552, -562175457, -2489632829021171459L, -58613L, true, false, (char) 8972, (char) 7229,
        Double.longBitsToDouble(0x3fb05f291d5b0040L), Double.longBitsToDouble(0x3fc2191ffd66fb50L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\012",
        Z.run(T, 2, 13, 3, 8, "\udbfe\udebe\udbbf\udfb6\udbbc\udf4a", "\u28df\u6c9f\u17db\u39ab\u238c\uc7f7\u360f\u2d49\u4004\u73b2\u20b4\u0643\u3bb1\u1774\u8380\u8ac6\ud595", "\udb42\udfe9\ud8a4\udebb\udac3\udfe5\udb3f\udea7",
        37, 6898, -758203, -6415129813089624275L, 43705L, false, false, (char) 39343, (char) 2908,
        Double.longBitsToDouble(0x3fe8c9739ddf51fdL), Double.longBitsToDouble(0x3fd54badad4f9056L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 8, "\ud95c\udf80\udbc2\udfbc\udbbc\udf4a\udb11\udd26\uda03\udcda\udb27\udc35\udb66\udd43", "\u238c", "\ud9b1\ude14\udb8f\ude66\ud8b8\udd80\udb3d\ude20\ud9c6\udc25\udb24\udd72\ud804\udfa1\ud979\ude9d\ud8c2\udeaf\ud81e\udeb0",
        1, 51209, 1611186241, -4014541617047903088L, -87227L, false, true, (char) 64805, (char) 1393,
        Double.longBitsToDouble(0x3fe18aaab3852b28L), Double.longBitsToDouble(0x3fd67412c5060d0eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\0121=!java.io.IOException\012",
        Z.run(T, 2, 12, 10, 8, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a", "\u6e80\u1c48\u25cf", "\ud9b1\udfb3\udb55\ude6f\udb7b\udd5c\udb8f\ude66",
        3, 64552, 8249887, -2489632975050113024L, 10145L, true, true, (char) 28215, (char) 7229,
        Double.longBitsToDouble(0x3fb05f291d5b0040L), Double.longBitsToDouble(0x3fc2191fe002c358L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 4, 0, 5, "\udbfc\udd77\udbc2\udfb6\udbbc\udf4a", "\u0b34\u6d03\u17db\u39ab\u238c", "\ud84c\udd60",
        -1, 43883, 276704552, -2414559008696103902L, -56098L, true, true, (char) 64141, (char) 28215,
        Double.longBitsToDouble(0x3fe78cca60417ca4L), Double.longBitsToDouble(0x3fed5b004690c8ffL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 1, 13, 10, 0, "\u00c3\udbc2\udf86\uc626", "\u28df\u6c9f\u25da", "\000",
        -5, -1000, -2001862656, 2699678501077658920L, -37570L, true, false, (char) 10, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe78cca60417ca4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 0, 0, 8, "\udbfe\uddfb\udbc2\udf86\udbbc\udf4a", "\u28df\u6c9f\u17db", "\udaa1\udf0d\udb55\ude6f\ud9b1\ude14\udb8f\ude66",
        3, 64552, -562175457, -2489632828837330691L, -50783L, true, true, (char) 11664, (char) 59365,
        Double.longBitsToDouble(0x3fc70300a8a4d674L), Double.longBitsToDouble(0x3fdef03bc9f75586L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 3, 13, 1, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a\udb11\udd26\ud8bb\udce8\udb5b\udea0\udb66\udcbf\ud875\udf8c\udaf2\ude42\ud92d\udcf7\ud9b1\udf6a\udb55\ude6f\ud9b1\ude14\uda4c\udf83\udb88\udda1", "\u6a04", "\udad2\udf81\ud81e\udeb0\uda5d\ude57\ud994\ude49\ud850\udd48\ud8a4\udc6d",
        28, 54103, -972257062, -435606634524209320L, 36355L, true, false, (char) 5989, (char) 53481,
        Double.longBitsToDouble(0x3fe78866f4d37083L), Double.longBitsToDouble(0x3feca5669b2a4767L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 6, 8, "\udac7\uddb4\udbc2\udfb6\udbbc\udf4a\udb11\udd26\ud8bb\udc66\udb27\udc35\udb80\ude43\ud875\udfa4\udaf2\ude42\udb3c\ude42\ud9b1\udfb3\udb55\ude6f\ud9b1\ude14\udb8f\ude66", "\u2268\uc32e\u3c00\u6105\u031c", "\ud994\ude49\udb43\udde9\ud8a4\udc6d\udae4\uddf5\udb66\udd8a",
        11, 33379, 858959801, -4791623280235430261L, -83113L, false, true, (char) 50476, (char) 40580,
        Double.longBitsToDouble(0x3fd81d8aba845e6aL), Double.longBitsToDouble(0x3fd752b717dcbca2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 6, "\u03aa\udbc2\udfb6\udb55\udc96", "\u3977\u6bdc\u5d53", "\ud92d\udee5\ud924\udfb8\ud9ec\udfb0\ud986\uddbc\ud8c5\udf54",
        30, 44591, 408030357, 4235688537173944962L, 18361L, true, false, (char) 44762, (char) 15589,
        Double.longBitsToDouble(0x3fe79208446ba5b0L), Double.longBitsToDouble(0x3fa72c6276b31ef0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=null\012",
        Z.run(T, 2, 13, 12, 8, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a\ud891\udfe7", "\u7341\u9d90\u39ab\u238c\uc7f7\ub10e\u2d49\u97b3\u73b2\u20b4\u2268\uc32e\u1d99", "\ud81e\udeb0",
        55, 6271, 1611186241, -3963313174021249904L, 75790L, false, false, (char) 11267, (char) 52301,
        Double.longBitsToDouble(0x3fe637abcf354eecL), Double.longBitsToDouble(0x3fd42a5948cf1b98L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\0121=!java.io.IOException\012",
        Z.run(T, 2, 4, 10, 8, "\udbfe\udebe\udbc2\udfb6\udbbc\udf4a", "\u28df\u6c9f\u17db", "\ud9b1\udfa2\udb55\ude6f\ud9b1\ude14\udb8f\ude66",
        3, 64552, -459418589, 2469143523959147278L, 10145L, true, true, (char) 28215, (char) 7229,
        Double.longBitsToDouble(0x3fd090ba4156c010L), Double.longBitsToDouble(0x3fc382e95c3ec1b0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 13, 13, 3, "\ud962\udd8f\udb9d\udd63\udb71\udcf1", "\u55c5\u06b3\u17db", "\ud8c7\udc32",
        19, 40950, -295062466, -1101069591541840573L, -37570L, true, false, (char) 18829, (char) 14642,
        Double.longBitsToDouble(0x3fda7c8e63fd13a4L), Double.longBitsToDouble(0x3fe75d7ce83a4429L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 7, 7, 6, "\udbfe\udebe\udb9d\udd63\udaaf\udce1", "\ud4f4\ud017\u06cd\ub00e\u5050\u257f", "\ud914\udf1d\uda5e\udf77\uda3d\uddf1\udbd2\udf81\udabb\udc04\udaaa\udc57\ud8c7\ude42\ud97f\udc94\ud81e\udeb0\ud949\ude27\udac0\udd30\ud944\ude4b\u9a18\udadf\udf8d\ud969\udff0",
        4, 92067, -273153893, -7731547905872589704L, -35416L, false, false, (char) 13402, (char) 65041,
        Double.longBitsToDouble(0x3fe53f9c62602b5bL), Double.longBitsToDouble(0x3fb7a5f431cea790L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 12, "\udbfe\udebe\udb7d\udcf0\uda2d\udc0f\udb11\udd1f\uda02\udd88\ud9e8\udcfa\uda39\udd41\uda82\uddd9\ud80a\udc50\uda3f\udf04\ud80f\udc96\ud935\udc31\udadc\udc29\udb26\ude0f", "\u81f0\u5deb\ua2b1\u773e\u642b", "\ud946\udccd\udb13\uddd6\ud96f\udf89\ud8f8\udeac\uda3e\ude00\ud9ea\udca2\udb4f\udf21\udb8a\ude67\uda52\udc23\udbd5\udf79\udb39\udf34\ud8ba\udcf1\ud8a9\udf47\udbf9\udd46\ud979\uddb6\udbf5\udc55\ud8ce\ude17\udaa0\udc1b\ud887\ude97\ud892\uddd5\ud896\udfa2\ud9ca\udd43",
        34, 69076, -993203553, -2359548017539988444L, -21638L, true, true, (char) 15235, (char) 31347,
        Double.longBitsToDouble(0x3feecce0f839cf23L), Double.longBitsToDouble(0x3fed18cc0d61beccL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 6, 6, 8, "\udbfe\udebe\udb9d\udd63\udb71\udcf1", "\u55c5\u06b3\u17db", "\ud80f\udc96",
        54, 47950, 1306764146, -1101069591541840573L, -37570L, true, false, (char) 18846, (char) 14642,
        Double.longBitsToDouble(0x3fda7c8e61e12bf4L), Double.longBitsToDouble(0x3fe0ab8aa83a4493L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 11, "\udbfe\udebe\ud8fb\udfb4\udb71\udc60\udb11\udd1f\ud8bb\udc66\ud9e9\uddfa", "\uaea3\u32a2\ua800\ucc8e\u9c99\u0313\u9ced\ua658\u396c\uc32e", "\udadc\udda2\ud81e\udeb0\ud8fb\udd41\ud946\udeef\ud9af\udd23\ud919\udc4f",
        38, 34216, 2099007263, -2397495109233671863L, 90679L, false, false, (char) 59987, (char) 4471,
        Double.longBitsToDouble(0x3fb18c6672dfc260L), Double.longBitsToDouble(0x3fd2de48ad56caceL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null\0121=!java.io.IOException\012",
        Z.run(T, 2, 12, 10, 12, "", "\u759b\u4541", "\udb5f\udc6f\ud875\udf8c\udaf2\ude42",
        15, 15766, 2064926511, 6602990282582426991L, -100000L, true, false, (char) 60063, (char) 44656,
        Double.longBitsToDouble(0x3f4ea146fe953c00L), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 10, "\udbfc\udd77\udbc2\udfb6\udbbc\udf4a", "\u0b34\u6d03\u17db\u19ab\u761f", "\ud84c\udd60\uda70\ude65",
        3, 64552, -562183328, -2489632829021171459L, 10145L, true, true, (char) 28215, (char) 7229,
        Double.longBitsToDouble(0x3fb05f291d5b0040L), Double.longBitsToDouble(0x3fe48647ff6e0884L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 12, "", "\u759b\u4541", "\udb5f\udc6f\ud992\ude57\udaf2\udeaf",
        32, 15766, 2064926511, 6602990283555505519L, -100000L, true, false, (char) 60063, (char) 44656,
        Double.longBitsToDouble(0x3f4ea146fe953c00L), Double.longBitsToDouble(0x3e20000000000000L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 13, 10, 8, "\udbfe\udebe\udada\udd05\udb92\ude24", "\u220e\u8213\u7dda", "\udb13\udfa7\udb22\udc5d",
        48, 62661, 628567883, 1188437000932155935L, -22429L, false, false, (char) 63246, (char) 64141,
        Double.longBitsToDouble(0x3fb96274978cca60L), Double.longBitsToDouble(0x3feeb3e523abe3ccL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|parseInputStream|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|crossStreams|java.io.InputStream,java.io.OutputStream|static",
    "M|org.jsoup.helper.DataUtil|detectCharsetFromBom|java.nio.ByteBuffer|static",
    "M|org.jsoup.helper.DataUtil|emptyByteBuffer||static",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|mimeBoundary||static",
    "M|org.jsoup.helper.DataUtil|readFileToByteBuffer|java.io.File|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream,int|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream|static",
    "M|org.jsoup.helper.DataUtil|validateCharset|java.lang.String|static",
    "C|org.jsoup.helper.DataUtil|<init>|",
    "M|org.jsoup.helper.DataUtil|parseInputStream|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
