package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Element_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 19, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud84c\udf3b\ud892\udeae", "\ua04e\u604f\u948a\u32b9\u5af4\u79f7\u7dc8\u2efd\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        -4, 29390, 86822236, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 19, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d1\udc17\u968b\ud84c\udf3b\ud892\udeae", "\ua04e\u604f\u948a\u32b9\u1d9f\u12a5\u7dc8\u2efd\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        -4, 29390, 86822236, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 23, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud859\udf51\ud8f5\udcf2", "\ua04e\u604f\u948a\u32b9\u5af4\u79f7\u7dc8\u2efd\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u2765\u5c55\u1a9f\ua66e\u03f4\u5f71", "\ud9b7\udf3e\ud983\udc52",
        59, 69111, 86800105, 3876345755272521473L, -93642L, true, true, (char) 61581, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e3ff63294L), Double.longBitsToDouble(0x3fd1ca6974e6acccL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 16, 19, 23, "\ud93d\ude71\ud8d1\udc3f\udb5c\udcab\uda03\ude40\ud978\udd1f\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\ud974\udf2d\udb18\udd88\ud99c\udd09", "\ua04e\u604f\ub1df\u32b9\u9e11\ud5a1\u7dc8\u8dda\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u970c", "\udb45\uddcd\udac9\udf8f",
        26, 74601, 1178295056, 3876345752349629697L, -93642L, true, true, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 19, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud84c\udf3b\ud892\udeae", "\u1a9b\u603b\u948a\u32b9\u5af4\u9d7c\u4baf\u83ba\u641f\ucdaf\u3fb4\u22d5\u67ce\u60ad\u6722\u5603\u5065\u5c55\u1a9f\u1165\u5a9c\ubdf7", "\ud9b7\udf3e\ud9a4\udf0f",
        -2, 96939, 86822236, 3876345755272521473L, -93642L, true, false, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements: |a0=[Lorg.jsoup.nodes.Element;:[[]]\012",
        Z.run(T, 1, 23, 23, 23, "\ud964\udf48\ud89d\udce5\udb0f\udf71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\uda00\udcb9\u968b\ud84c\udf3b\uda52\udd6a", "\u2673\u604f\u948a\u32b9\u5af4\u79f7\u6080\u2efd\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        -4, 29390, 86822236, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee356ba4acccL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Comment:\012<!--\ud964\udf48\ud89d\udce5\udb08\udd71\udb0c\udf6c\ud96d\uded9\uda05\udeeb\ud810\uddbb-->\012",
        Z.run(T, 1, 19, 7, 0, "\ud964\udf48\ud89d\udce5\udb08\udd71\udb0c\udf6c\ud96d\uded9\uda05\udeeb\ud810\uddbb", "\u9a86\u8f3c", "\ud990\udc67\udb07\udec8\ud912\udcad\udac4\udf02\udbbe\udf42\udaab\ude29\ud8f1\ude1a\ud8bc\ude18\uda6f\udf6b\udb08\udfc9\ud9d4\udd36\ud993\udcfd\uda38\ude3b\ud837\udef1\udb60\uddad\ud8fb\udcc6\ud4fe\udbc4\ude37\uda31\udf5d\uda85\uddf8\ud8b2\uddb9",
        51, 99418, -997860431, -8299304622206939067L, -81428L, false, true, (char) 82, (char) 37144,
        Double.longBitsToDouble(0x3fe809ae5922399cL), Double.longBitsToDouble(0x3fcaca5f7d652010L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.ClassCastException\012",
        Z.run(T, 1, 9, 1, 3, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\ud8ea\udf4d\ud84c\udf5c\ud892\udeae", "\ua04e\u604f\u948a\u32b9\u5af4\u79f7\u7dc8\u2efd\u4253\ud618\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        -4, 29390, -1607676580, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.ClassCastException\012",
        Z.run(T, 1, 22, 1, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud8ae\udeb9\ud9b4\ude28\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud84c\udf3b\ud892\udeae", "\ua04e\u604f\u948a\u32b9\u5af4\u79f7\u7dc8\u2efd\u3459\ucdaf\u41ab\u5470\u5ef6\u682d\u6722\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u5f71", "\ud9d9\udcaf\ud9a4\udf0f",
        -4, 29390, 86822236, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 33818,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\012",
        Z.run(T, 1, 8, 19, 22, "\uda87\udec1\uda03\udca8\ud889\udce7\ud89e\udcf4\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\udb53\udf99\ud83a\ude16\ud84c\udf3b\ud882\udf85\ud9aa\udd59\ud990\udc67\ud856\udd4f\ud912\udd60\uccfa\udb6b\udf54\udb7f\udfa5\udabd\udee0\ud8e1\udce1\ud880\uddd3\udb08\udfc9\ud9d4\udd36\ud993\udcfd\udb26\udc93\ud877\ude63\udae1\udeaa\ud963\udcef\ud9b5\uddb9\ud898\udd9a\uda39\udc9d\ud8fd\ude93\udbba\uddbe", "\ubd32\u0ee8\ud3a4\ua41f", "\ud811\uddaa\uda3b\udf18\ud876\ude66\udb99\ude05\ud9c5\udd14\udb22\uded0\udbac\udc90\ud9a4\udfbd\ud954\ude8b\uda52\uddf4\ud9d4\ude85\udb85\udc0c\ud8b9\udf14\ud93e\udc9a\ud812\udf4b\ud86a\uded6",
        55, 58004, 963596593, 4339765759302616907L, -7076L, false, true, (char) 3005, (char) 60173,
        Double.longBitsToDouble(0x3fcced585c59c288L), Double.longBitsToDouble(0x3feb7014e6546404L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 21, 12, 23, "\ud964\udf48\ud89d\udce5\ud93e\udd6c\ud89e\udd7b\uda44\udf71\uda05\udeeb\ud810\uddbb\ud8bd\ude73", "\ub617", "\ud990\udc67\ud973\udf37",
        47, 71238, 1098301380, -8561360238719867555L, 19207L, false, false, (char) 56342, (char) 22239,
        Double.longBitsToDouble(0x3fa2edb36fb99c70L), Double.longBitsToDouble(0x3fe9f882eafa2949L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Comment:\012<!--\ud617\uda8d\uddbc\udb08\uddac\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud84c\udf3b\ud892\udeae-->\012",
        Z.run(T, 1, 4, 19, 23, "\ud617\uda8d\uddbc\udb08\uddac\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud84c\udf3b\ud892\udeae", "\ua04e\u604f\u948a\u32b9\u5af4\u79f7\u7dc8\u2efd\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        -4, 29390, 86822236, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\012",
        Z.run(T, 1, 21, 8, 1, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9", "\u01f8\u541f\u4081\ud7bb\ucbb4\u0af9\u948a\u32b9", "\ud8e1\udce1",
        -1, 85312, -1005874086, -5968296590105319715L, 94753L, false, false, (char) 26792, (char) 22393,
        Double.longBitsToDouble(0x3fe2771420ece356L), Double.longBitsToDouble(0x3fd115fee4410d8eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException |a0=[Lorg.jsoup.nodes.Element;:[[null, null]]\012",
        Z.run(T, 1, 23, 16, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\udb0b\udeee\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\udaab\udc4a\u8a1b", "\ua04e\uc296\ubb1b\u00da\u89be\u58e3\u7dc8\u2efd\u3459\u916d\u3fb4\u22d5\u5e7b\u682d\u401b\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u5f71", "\ud9b7\udf3e\udaa2\udd0d",
        2, 29390, 86796124, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException |a0=[Lorg.jsoup.nodes.Element;:[[null, null, null]]\012",
        Z.run(T, 1, 7, 19, 23, "\udb20\udef8\ud89d\udccc\udb08\udd71\ud89e\udd7b\ud96d\uded9\udac3\udfeb\ud810\udd84\ud9ad\udeb9\ud9d0\udf90\u968b\ud84c\udf3b\ud892\udeae", "\ua04e\u604f\u948a\u32b9\u3683\u8c34\u813d\u2e76\u3459\ua4fc\u257c\u9abf\ub2c7\u3e2e\u7942\u5603\u5065\u5c55\u1a9f\u7f07\u6b0d\u5f71", "\ud9b7\udf3e\ud9e3\udd8e",
        7, 38326, -1787143712, 3876470438173124353L, -93642L, true, true, (char) 13444, (char) 36361,
        Double.longBitsToDouble(0x3fd1bd4e374ab91eL), Double.longBitsToDouble(0x3fd6ee3564e6acf0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Comment:\012<!--\ud8d8\udd23\ud8d1\ude7b\ud894\udd2d\udb42\udf9a\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud859\udf51\ud8f5\udcf2-->\0121=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException |a0=[Lorg.jsoup.nodes.Element;:[[null, null, null]]\012",
        Z.run(T, 2, 3, 23, 23, "\ud8d8\udd23\ud8d1\ude7b\ud894\udd2d\udb42\udf9a\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud859\udf51\ud8f5\udcf2", "\ua04e\u604f\u948a\u32b9\u5af4\u79f7\u7dc8\u2efd\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u2765\u5c55\u1a9f\u3678\u03f4\u5f71", "\ud9b7\udf3e\ud983\udc52",
        59, 22527, 99245246, 3876345755272521473L, -93642L, true, true, (char) 61581, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e3ff63294L), Double.longBitsToDouble(0x3fd1ca6974e6acccL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\012",
        Z.run(T, 1, 8, 18, 11, "\ud862\udd3f\ud9ef\udf27\udb08\udd71\ud89e\udd7b\udb20\udeb1\ud9f5\ude31\udb50\udd3b\ud97e\udc1c\ud9a3\udd04\u968b\uda43\udce6\ud8f5\udcf2", "\ua121\u604f\u948a\u32b9\u5af4\u79f7\u7dc8\u0e69\u3158\uabf3\uc12b\u4bd0\u5e97\u1cca\u6181\u4f80\ud4dd\uc0bf\ua02a\ua66e\u03f4\u5f71", "\ud90f\udd49\ud983\udc52\ub1fc\udb63\udc48\ud9ed\uddf2\ud87d\ude91\ud876\ude66\udb99\ude05\ud9c5\udd14\udb22\uded0\udb5e\ude5c\ud8d2\udf77\uda95\udde0\ud86b\udfd5",
        7, 40939, 2144819355, 7121264990161167260L, 95652L, false, false, (char) 39565, (char) 4299,
        Double.longBitsToDouble(0x3fcf2b18ab9d0f8cL), Double.longBitsToDouble(0x3feb422d978e931eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 23, 23, "\ud964\udf48\ud89d\udce5\ud91e\udfef\ud89e\udd6b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud8ca\udd0a\u0f93\ud99e\udc33\ud918\udd75", "\ua04e\u3688\uaa46\u32b9\u5af4\u9ca2\u8b94\u2efd\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u2765\u5c55\u1a9f\u311a\u03f4\u5f71", "\ud9b7\udf3e\ud983\udc52",
        59, 69111, 86800105, 3876345754028386049L, 72318L, true, true, (char) 11409, (char) 40888,
        Double.longBitsToDouble(0x3fe05b1e57fb2590L), Double.longBitsToDouble(0x3fd1ca6974e6acccL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Comment:\012<!--\ud864\udfe7\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\udae2\udd19\ud810\uddbb\ud9c6\udfb9\ud9c7\udeed\u968b\ud84c\udf3b\ud892\udeae-->\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 2, 23, "\ud864\udfe7\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\udae2\udd19\ud810\uddbb\ud9c6\udfb9\ud9c7\udeed\u968b\ud84c\udf3b\ud892\udeae", "\u1a9b\u603b\u948a\u32b9\u5af4\u9d7c\u4baf\ud7f4\u641f\ucdaf\u3fb4\u22d5\u67ce\u60ad\u6722\u5603\u5065\u5c55\u1a9f\u1165\u5a9c\ubdf7", "\ud9b7\udf3e\ud9a4\udf0f",
        -2, 96939, -1171468964, 3876345072372721409L, -93642L, true, false, (char) 14509, (char) 37741,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.ClassCastException\0121=new org.jsoup.select.Elements:\012",
        Z.run(T, 2, 9, 8, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud84c\udf3b\ud892\udeae", "\u1af3\u603b\u365b\ubbe8\u5a9c\u3fd6\ua12c\u83ba\u641f\ucdaf\u3fb4\u22d5\u67ce\u60ad\u6722\u5603\u5065\u5c55\u1a9f\u1165\u5a9c\ubdf7", "\ud9b7\udf3e\ud9a4\udf0f",
        51, 96930, 86822236, 3876345755272521473L, -93642L, true, false, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Comment:\012<!--\ud964\udf48\ud98e\udc9e\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud80c\udebb\ud9d0\udfed\u968b\ud84c\udf3b\ud904\udc07-->\0121=null |this=org.jsoup.nodes.Comment:\012<!--\ud964\udf48\ud98e\udc9e\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud80c\udebb\ud9d0\udfed\u968b\ud84c\udf3b\ud904\udc07-->\012",
        Z.run(T, 2, 20, 19, 23, "\ud964\udf48\ud98e\udc9e\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud80c\udebb\ud9d0\udfed\u968b\ud84c\udf3b\ud904\udc07", "\u1a9b\u603b\u8a78\u326e\u5af4\u9d7c\u4baf\u8410\u641f\ucdaf\u3fb4\u22d5\u67ce\u60ad\u6722\u9a29\u5094\u5c55\u1a9f\u1165\u5a9c\ubdf7", "\ud9b7\udf3e\ud9a4\udf0f",
        -2, 96939, 86822236, 3876345755272521473L, -93642L, true, false, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Comment:\012<!--\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\udb34\udf77\ud83e\uddef\ud84f\udc3b\ud892\udeae-->\0121=null |this=org.jsoup.nodes.Comment:\012<!--\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\udb34\udf77\ud83e\uddef\ud84f\udc3b\ud892\udeae-->\012",
        Z.run(T, 2, 19, 19, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\udb34\udf77\ud83e\uddef\ud84f\udc3b\ud892\udeae", "\ub183\ua2b4\u3eee\u32b9\u5af4\u8072\u4bae\u2cbb\u641f\ucdaf\u3fb4\u22d5\u67ce\u7087\u6722\u5603\u5065\u542f\u04a1\u080c\u517f\uc0ab", "\ud9db\udedb\ud9a4\udf0f",
        -2, 37282, -1837922251, 3876345755272521473L, -93642L, true, false, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\0121=new org.jsoup.select.Elements: |a0=[Lorg.jsoup.nodes.Element;:[[]]\012",
        Z.run(T, 2, 21, 23, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud9d0\udfed\u968b\ud84c\udf3b\ud892\udeae", "\u0f9b\ub9f0\u7577\u323f\u5af4\u9d7c\u4baf\u83ba\u641f\u40f2\u1b28\ud5be\u4d32\uc1e2\u6694\u5603\u5065\u5c55\u1a9f\u0f45r\uc4dd", "\ud9b7\udf3e\ud810\udda2",
        16, 41972, 86778884, 3876345755524179713L, 71682L, false, false, (char) 4769, (char) 59150,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException |a0=[Lorg.jsoup.nodes.Element;:[[null, null, null]]\0121=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException |a0=[Lorg.jsoup.nodes.Element;:[[null, null, null]]\012",
        Z.run(T, 2, 23, 23, 17, "\ud8d2\udd6f\ud865\udc47\udb02\ude26\ud952\udd92\ud853\ude30\ud90d\udec4\udaa8\uddb0\udaf3\udeb2\ud9d0\udfed\u968b\ud84c\udf3b\ud892\udeae", "\u1a9b\u603b\u9473\u3839\uae3e\u87ad\u4b8d\u83ba\ub46f\ucdaf\u3fb4\u22d5\u67ce\u60ad\u6722\u5603\u50e3\u5c55\u1a9f\u1165\u5a9c\ubdf7", "\uda97\udce2\ud94d\udcf7",
        43, 24903, 86822370, 3876345755272521473L, -20533L, true, true, (char) 64913, (char) 35301,
        Double.longBitsToDouble(0x3fd5936a04e73e2cL), Double.longBitsToDouble(0x3fedd5c97e6049cfL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\0121=new org.jsoup.select.Elements:\012",
        Z.run(T, 2, 24, 8, 24, "\ud827\udc65\ud89d\udc42\udab1\udc25\u8efa\ud838\uddfb\udbcd\ude68\uda80\udcc1\udaa4\udf77\uda9e\udc1a\ud800\udf34\ud89d\udcf5\ud882\udc86", "\u263f", "\ud91a\udf0b\udb61\udff2",
        52, 30801, -644650683, -8665432941179202369L, -15558L, true, true, (char) 18663, (char) 37954,
        Double.longBitsToDouble(0x3fd115fee03a1866L), Double.longBitsToDouble(0x3fd5ebce73f545b4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException |a0=[Lorg.jsoup.nodes.Element;:[[null]]\012",
        Z.run(T, 1, 23, 23, 23, "\ud95e\udcab\ud89d\udce5\udb0f\udf71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\uda00\udcb9\u968b\ud84c\udf3b\uda52\udd6a", "\u07ee\u4782\u9470\u32b9\u5af4\u79f7\u6080\u2efd\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u5065\u5c55\u1a9f\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        9, 29390, 86822236, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 36617,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee356ba4acccL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.ClassCastException\0121=new org.jsoup.select.Elements:!toString:java.lang.ClassCastException\012",
        Z.run(T, 2, 9, 22, 3, "\ud964\udf48\ud8aa\udfe5\udb0f\udf71\ud89e\udd7b\uda18\udded\ud824\ude62\ud8a4\uded1\ud9c6\udfb9\uda00\udcb9\u968b\ud84c\udf3b\uda52\udd6a", "\u2673\u604f\u948a\u32b9\u7f16\ub869\u6080\ub19b\u07be\u56f2\ucc71\ucac6\u560e\u682d\u6722\u5603\u1f9e\u5cdd\u4c84\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        -4, 10614, 86822236, 3876345755146287105L, -93642L, true, false, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee356ba4acccL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Comment:\012<!--\ud9b4\udd27\ud89d\udc99\udbc4\udd8f\udb2e\udd56\ud97a\ude17\uda05\udeeb\ud810\udd5a-->\0121=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Comment:\012<!--\ud9b4\udd27\ud89d\udc99\udbc4\udd8f\udb2e\udd56\ud97a\ude17\uda05\udeeb\ud810\udd5a-->\012",
        Z.run(T, 2, 4, 4, 0, "\ud9b4\udd27\ud89d\udc99\udbc4\udd8f\udb2e\udd56\ud97a\ude17\uda05\udeeb\ud810\udd5a", "\u9a86\u8f79", "\udaeb\udcb4\udb07\udec8\ud912\udcad\udac4\udf02\ud9c5\ude65\uda56\udfff\ud990\udd41\ud8bc\ude18\uda6f\udf6b\ud826\udc17\ud96b\uddcb\udbd4\udde5\ud8e5\udfde\ud837\udef1\ud924\udeb0\ud8fb\udcc6\ud828\uddf2\udbc5\udf11\uda31\udf5d\uda85\uddf8\udaff\udd08",
        21, 99418, -997073999, -8299304622206939067L, -47428L, true, true, (char) 56523, (char) 31422,
        Double.longBitsToDouble(0x3fb7fcfefaca4020L), Double.longBitsToDouble(0x3fc2af3784b605dcL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 21, 10, 1, "\ud964\udf48\ud89d\udce5\ud854\ude78\udb54\uddc4\udbef\ude2c\uda05\udeeb\ud810\uddbb\udb97\udf25", "\ub617", "\udafe\ude23\ud8d6\ude55",
        47, 69790, 1098301380, -8561360238719867555L, 19207L, false, true, (char) 17933, (char) 22239,
        Double.longBitsToDouble(0x3fa2edb36fb99c70L), Double.longBitsToDouble(0x3fe9f882edfa2949L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\0121=new org.jsoup.select.Elements:\012",
        Z.run(T, 2, 21, 21, 23, "\ud964\udf48\ud89d\udce5\ud91e\udfef\ud89e\udd6b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud8ca\udd0a\u0f93\ud99e\udc33\ud918\udd75", "\ua101\u3688\uaa46\u32b9\u5af4\u9ca2\u8b94\ub49e\u476d\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u2765\u5c55\u1a9f\u311a\u3d80\u5f71", "\ud9b7\udf3e\ud983\udc52",
        59, 69111, 86800105, 3876345754028386049L, 72318L, true, true, (char) 11409, (char) 40888,
        Double.longBitsToDouble(0x3fe05b1e57fb2590L), Double.longBitsToDouble(0x3fd1ca6974e6acccL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:\0121=new org.jsoup.select.Elements:\012",
        Z.run(T, 2, 24, 8, 24, "\ud827\udc65\ud89d\udc42\udab1\udc25\u8efa\ud838\uddfb\udbcd\ude68", "\u6841\ua2f8\u83c6", "\uda2e\udd9e\udb12\ude6c\ud912\udd83\uccfa\ud91a\udf0b\ud8a3\udc71\ud8c6\udc36\ud84d\udc89\ud913\udf01\udade\udf90\ud9d4\udd36\ud810\ude20\udb13\udd02",
        34, 85599, -1300069638, 1450922303797085015L, -14220L, true, true, (char) 3152, (char) 50757,
        Double.longBitsToDouble(0x3fdfaa2daa542db2L), Double.longBitsToDouble(0x3f9649615b6fc740L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.ClassCastException\0121=new org.jsoup.select.Elements:!toString:java.lang.ClassCastException\012",
        Z.run(T, 2, 22, 22, 3, "\ud964\udf48\ud8aa\udfe5\udb0f\udf71\ud89e\udd7b\uda18\udded\ud824\ude62\ud8a4\uded1\ud9c6\udfb9\uda00\udcb9\u968b\ud84c\udf3b\uda52\udd6a", "\u2673\u604f\u948a\u32b9\u7f16\ub869\u6080\ub19b\u07be\u56f2\ucc71\ucac6\u560e\u682d\u6722\u5603\u1f9e\u5cdd\u4c84\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        -4, 10614, 86822236, 3876345755146287105L, -93642L, true, false, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee356ba4acccL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 19, 23, "\ud964\udf48\ud89d\udce5\udb08\udd71\ud89e\udd7b\ud96d\uded9\uda05\udeeb\ud96b\ude08\ued60\ud9b2\udf1c\u968b\ud84c\udf3b\ud892\udeae", "\ua04e\u5fe6\u948a\u32b9\u5af4\u47e4\u5ca3\u8e90\u6d07\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u5065\u170d\u456c\u1165\u39ea\u5f71", "\ud9b7\udf3e\ud9a4\udf0f",
        -4, 29390, 86822236, 3876345755272521473L, -93642L, true, true, (char) 31917, (char) 34057,
        Double.longBitsToDouble(0x3fd1bd4e374ab894L), Double.longBitsToDouble(0x3fd6ee3564e6acccL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException\0121=new org.jsoup.select.Elements:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 23, "\ud964\udf48\ud89d\udce5\udadd\ude89\ud89e\udd4b\ud96d\uded9\uda05\udeeb\ud810\uddbb\ud9c6\udfb9\ud8ca\udd0a\u0f93\ud99e\udc33\ud918\udd75", "\ua04e\u3688\uaa46\u32b9\u5af4\u9ca2\u8b94\u2eba\u3459\ucdaf\u3fb4\u22d5\u5e7b\u682d\u6722\u5603\u2765\u5c55\u1a9f\u311a\u03f4\u5f71", "\ud9b7\udf3e\ud983\udc52",
        59, 69111, 86800105, 3876345754028386049L, 72318L, true, true, (char) 11409, (char) 40888,
        Double.longBitsToDouble(0x3fe05b1e57fb2590L), Double.longBitsToDouble(0x3fd1ca6974e6acccL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Element|nextElementSibling||new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|previousElementSibling||new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|siblingElements||new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Node|previousSibling||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|siblingNodes||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "C|org.jsoup.select.Elements|<init>|",
    "C|org.jsoup.select.Elements|<init>|java.util.Collection",
    "C|org.jsoup.select.Elements|<init>|[Lorg.jsoup.nodes.Element;",
    "C|org.jsoup.select.Elements|<init>|int",
    "C|org.jsoup.select.Elements|<init>|java.util.List",
    "M|org.jsoup.nodes.Element|accumulateParents|org.jsoup.nodes.Element,org.jsoup.select.Elements|static",
    "M|org.jsoup.nodes.Element|addClass|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|after|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|after|org.jsoup.nodes.Node|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|append|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendChild|org.jsoup.nodes.Node|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|nextElementSibling||new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|previousElementSibling||new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|siblingElements||new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Node|previousSibling||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|siblingNodes||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "C|org.jsoup.select.Elements|<init>|",
    "C|org.jsoup.select.Elements|<init>|java.util.Collection",
    "C|org.jsoup.select.Elements|<init>|[Lorg.jsoup.nodes.Element;",
    "C|org.jsoup.select.Elements|<init>|int",
    "C|org.jsoup.select.Elements|<init>|java.util.List",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
