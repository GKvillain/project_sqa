package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 14, 15, "\uda4f\udf77\udb92\uddc3", "\u67c7\u7442\ud70c\ua0f6\u24e3\ub513\u1cfb\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\uda05\udf9d\uda45\udf9a\ud8d6\udf60\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb88\ude8f\udaad\udf5f",
        36, 64612, 1334326062, -850244715113814688L, 10771L, true, true, (char) 25665, (char) 19821,
        Double.longBitsToDouble(0x3fc14300817b314cL), Double.longBitsToDouble(0x3fd8ea64750b0966L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 14, 15, "\ud960\udffd\udb8f\ude3f", "\u67c7\u7442\ud70c\ua0f6\u24e3\ub513\u1cfb\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\udb59\udfa8\udb94\udd04\ud8d6\udf60\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb88\ude8f\udaad\udf5f",
        36, 64612, 1334326062, -850244715113814688L, 10771L, true, true, (char) 25665, (char) 19821,
        Double.longBitsToDouble(0x3fc14300817b314cL), Double.longBitsToDouble(0x3fd8ea64750b0966L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 14, 15, "\uda4f\udf77\udb82\uddc3", "\u67c7\u7442\ud70c\ua0f6\u3f64\ub513\u1cfb\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\uda05\udf9d\uda45\udf9a\ud8d6\udf60\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb8b\ude8f\udaad\udf5f",
        36, 64612, 1334326062, -850244715113814688L, 10771L, true, true, (char) 25665, (char) 19821,
        Double.longBitsToDouble(0x3fc1630089639e6cL), Double.longBitsToDouble(0x3fd6a6aa450b0966L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 14, 15, "\uda4f\udf77\udb92\uddc3\udb3c\udc69", "\ub2cc\u67b9\u127a\u2114\u57e1\u66d7\ub5bf\ua54c\u923d\u7b75\u2b37\ucd1b\u498c\u417f", "\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud9fa\udd83\ud935\uddf4\udaad\udf5f\ud900\uddfa\uda59\uddc6\udb20\udebf\udbf0\ude3d\ub11a\uda89\ude76\ud807\udf61",
        18, 68309, -84964033, -6928390754716570220L, -83710L, false, true, (char) 20280, (char) 54291,
        Double.longBitsToDouble(0x3fec01ebc9d218f7L), Double.longBitsToDouble(0x3fd56709d869f0acL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 14, 0, "\uda4f\udf77\udb92\uddc3", "\u67c7\u7442\ud70c\ua0f6\u24e3\ub513\u1cfb\u6d03", "\u00b5\ud8de\udc38\uf338\uda05\udf9d\uda45\udf9a\u00cd\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb88\ude8f\u00ae",
        -3, 64612, 1334326062, -850244715113814688L, 10771L, true, true, (char) 25665, (char) 19821,
        Double.longBitsToDouble(0x3fc14300817b314cL), Double.longBitsToDouble(0x3e30000000000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 15, "\uda4f\udf77\udb92\uddc3", "\u67c7", "\ud8a7\udee9\ud93a\udfb6\uda89\udffb\udb38\udf12",
        17, 99834, 2086814609, -5898971455533031802L, -43209L, false, false, (char) 26969, (char) 42474,
        Double.longBitsToDouble(0x3fb627d6294ec8b0L), Double.longBitsToDouble(0x3fd6e95104294262L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 15, "\uda4f\udf77\udb92\uddc3", "\u67c7\u25fc\ud70c\ua0f6\u24e3\ub513\u1cfb\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\uda05\uded8\uda45\udf9a\ud8d6\udf60\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb88\ude8f\ud952\udf12",
        43, 64612, 1334326062, -850244715113814688L, 10771L, true, true, (char) 25665, (char) 19821,
        Double.longBitsToDouble(0x3fc14300817b314cL), Double.longBitsToDouble(0x3fd9c724750bcdfaL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 4, "\uda4f\udf8d\uda52\udec2\udb3c\udc69\udacc\udf63\ud928\udfc5\uda77\udee3\udb21\udddf", "\u995a\u1d0d\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\uda05\udf9d\uda45\udf9a\ud8d6\udf60\udb36\uddc1\udbf0\udc5d\uda1d\udc44\ud8cd\udf08\ud858\ude93\udb88\ude8f\udaad\udf5f",
        36, 82519, 1334326062, -850244715113814688L, 53822L, true, false, (char) 25665, (char) 19821,
        Double.longBitsToDouble(0x3fc14300817b314cL), Double.longBitsToDouble(0x3fd8ea64750b0966L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 8, 15, "\u689e\ud9ca\uddb8", "\uc4b4\u73e0\ud70c\ua0f6\u24e3\ub513\u0b04\u6d03\u4857\u923d\u7b75\u88a3\u1cdf\u498c\u417f\u25ed", "\udad6\udc76\ud8cd\udf08\ud858\ude93\udb88\ude8f\udaad\udf5f\ud947\udfd0\ud83e\udcd7\udb6d\udfdd\udbf0\ude3d\ub11a\uda89\ude76\ud807\udf61\ud8d9\uddb2\udbae\udd5f\uda4b\udcf2\ud984\udfa6\ud941\udefe\ud99a\udd7e",
        42, 23678, 1622525334, -3167267888701138939L, 76176L, false, false, (char) 13189, (char) 33472,
        Double.longBitsToDouble(0x3fe3fdfe65aa0f70L), Double.longBitsToDouble(0x3fee79d9b2a555ebL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 8, "\uda4f\udf77\udb92\uddc3", "\u67c7\u7442\ud70c\ua0f6\u24e3\u84ba\u1d36\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\uda05\udf9d\uda45\udf9a\ud8d6\udf60\udb2c\udd9d\ud9b7\udc71\u8a6b\ud8d6\udfb1\ud858\ude93\ud9d2\udfc4\udae2\udd42",
        13, 64612, 1334326062, -850244715113814688L, -78327L, true, false, (char) 13845, (char) 22938,
        Double.longBitsToDouble(0x3fd51faefb293fb2L), Double.longBitsToDouble(0x3fc14300817b314cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 15, "\uda4f\udf77\udb92\uddc3", "\u2cbf\u20e3\ud70c\ua0f6\u24e3\ub4e1\u1cfb\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\uda05\udf9d\uda45\udf9a\ud8d6\udf60\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb88\ude8f\udaad\udf5f",
        36, 64612, 1334326062, -850244715113814688L, 10771L, true, true, (char) 25665, (char) 19821,
        Double.longBitsToDouble(0x3fc14300817b314cL), Double.longBitsToDouble(0x3fd8ea64750b0966L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 14, 15, "\udb5c\udede\udb29\uddda", "\u67c7\u7442\ud70c\u5541\u24ea\ub513\u1cfb\u6d03", "\ud85c\udf8c\ud8de\udc18\uf338",
        -2, 37652, 1587197389, -6964738415458378664L, 70642L, true, false, (char) 41608, (char) 5364,
        Double.longBitsToDouble(0x3fc969f4ebb0cd08L), Double.longBitsToDouble(0x3fe976e56af04f88L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 15, "\uda4f\udf77\udb92\uddc3\udb3c\udc69\udacc\udf63\ud9e4\udc75\uda69\udd2a\udb21\udddf\ud8a7\udee9\ud85e\udd88\uda86\udff3\udb38\udf12\udbbc\udc31\ud8e8\udef8", "\u8849\ucd1b\u498c\u417f\u25ed", "\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb88\ude8f\udaad\udf5f\ud947\udfd0\ud83e\udcd7\udb6d\udfdd\udbf0\ude3d\ub11a\uda89\ude76\ud807\udf61\ufce5\udbae\udcf9\uda4b\udcf2\ud984\udfa6\ud941\udefe\ud99a\udd7e",
        42, 47798, 507038341, 7242495193906075008L, 60781L, false, true, (char) 63903, (char) 11357,
        Double.longBitsToDouble(0x3fec995a5b92a614L), Double.longBitsToDouble(0x3fc2f0e7315feda0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 14, 15, "\uda4f\udf77\udb92\uddc3", "\u7d2b\u7442\ud70c\u5ff2\u24e3\u5ce4\u1cfb\u6d03", "\ud89e\udf4e\ud8de\udc38\uf338\udae5\udda8\ud9db\udc75\ud8b7\uddd0\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\ud9c1\ude4c\udaad\udf5f",
        36, 64612, 797455150, -850244715113814688L, -59907L, false, true, (char) 56461, (char) 36017,
        Double.longBitsToDouble(0x3fd6da6470dd0894L), Double.longBitsToDouble(0x3fdfa8d40f6204eaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 7, 0, "\uda4f\udf77\ud8ff\udcc9", "\u67c7\u5006\u3362\ua115\u24e3\u7fe8\ud04f\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\ud98e\udc61\u2efb\ud8a1\udf01\udb2c\uddaf\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb88\ude8f\udaad\udf5f",
        36, 64612, 1334326062, -850244715113814688L, 69647L, false, true, (char) 56461, (char) 22732,
        Double.longBitsToDouble(0x3fd8e612d50b0966L), Double.longBitsToDouble(0x3fe351f4347c55cbL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 14, 15, "\ud94d\udf76\udb92\uddc3\udb3c\udc69\udacc\udf63\ud9e4\udc75\uda69\udd2a\udb21\udddf\ud8c5\ude78\udb1c\udd87", "\u6d03\u4857", "\ud8de\udc38\uda6b\udd3c\uda05\udf9d\uda45\udf9a\ud902\udeab",
        33, 64578, -1794089971, -7822359554511431141L, -43342L, true, true, (char) 10014, (char) 4060,
        Double.longBitsToDouble(0x3fe7827c4560f433L), Double.longBitsToDouble(0x3fee4dbbe4a92d72L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 15, 15, "\udb0f\ude9f\ub417", "\u67c7\u7442\ud70c\ua0f6\u3f64\ub513\u1cfb\u6d03", "\ud9c7\udf02\ud8de\udc38\uf338\uda05\udf9d\u9555\ud8d6\udf60\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud8a0\udc86\ud8f6\udc05\udab4\udf37",
        31, 64612, 1334326062, -850244712721308064L, 10771L, true, true, (char) 25665, (char) 55142,
        Double.longBitsToDouble(0x3fe8c30dda58e79bL), Double.longBitsToDouble(0x3feb5355269ab5e8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 14, 10, "\uda4f\udf77\udb82\uddc3\udb3c\udc69\udbaf\udc63\uda8c\uddf8\uda8f\udfbe\udbd5\udcce\ud8a7\udeef", "\u3d28\u6d03\u4857\u923d\u7b75\u78e5\ucd1b", "\ud8d6\udf60\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\udb51\udf6a\udb8b\ude8f\udaad\udf55",
        40, 30292, -144076870, -850245432373353120L, -40251L, true, true, (char) 55463, (char) 43436,
        Double.longBitsToDouble(0x3fd9ac2efb293fb2L), Double.longBitsToDouble(0x3fc1630089639e6cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 15, "\udbbe\uded0\udac8\udf67\udb3c\udc69", "\u44a4\u6ea4\u7f37\u1287\u57e1\ucda8\ub5dd\ua54c\u6982\u62c6\u2aba\ucd1b\u498c\u417f", "\uf212\udaaf\udedb\ud8cd\udf08\ud9fa\udd83\ud935\uddf4\udaad\udf5f\ud900\uddfa\uda59\uddc6\udb20\udebf\udbf0\ude3d\ub11a\uda89\ude76\uda01\ude8e",
        18, 68309, -84964033, -6928390754716570220L, -83710L, false, true, (char) 20280, (char) 32531,
        Double.longBitsToDouble(0x3fec030d69d218f7L), Double.longBitsToDouble(0x3fd56709d869f0acL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 0, "\uda4f\udf77\udb92\uddc3", "\u67c7\u7c6f\ud70c\ua0f6\u24e3\ub513\u6a9d\u6d7e", "\u00b5\ud8de\udc38\uf338\uda05\udf9d\uda45\udf9a\u00cd\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\udb88\ude8f\u00ae",
        -3, 64612, 1334326062, -850244715113814688L, -19949L, true, true, (char) 25665, (char) 19821,
        Double.longBitsToDouble(0x3fc143009eab314cL), Double.longBitsToDouble(0x3f17714000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 14, 0, "\uda4f\udf77\udb92\uddc3\udb3c\udc69\udacc\udf63\ud900\udc79\udb40\udc00\udb21\udddf\ud8a7\udee9\ud85e\udd88", "\u6d03\u225e\u923d\u00b5\u88a3\ucd1b\u498c\u417f\u191c\u7cc1\u1639", "\ud858\udf52\udb88\ude8f",
        39, 48392, -592602388, 5730886798292505328L, -14953L, true, false, (char) 6662, (char) 6823,
        Double.longBitsToDouble(0x3fdce0c072a3f5deL), Double.longBitsToDouble(0x3feb5cfecc8a1845L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 15, "\udaa6\udf44\udaac\udcf6", "\u0e98\ub608\u5427\u5d20\ua3cd\u0fb4\u640f\ud72e\u7a7f\uab0c\u8636\u9f04\ucd1b\u777b\u16ab\u6923\u7ce7\u1639\ud66a\ud15b\uc5c1\u9cda\ucd9e\ud22e\u0e25\u53aa\u8f6c\u37bc\u5c3c\ua6fc\uad47\u986c\ud12e\u15ac\ucdaa\ucc2a\u0819\u08a1\uc8ea\ua964\uc3a3\u4ebb\ua258\u624e\uceff\u1a39\u43d1\u9866\u7bbf\u323e\ub4aa\u27e7\ub32b\u154c\u31a8\u502b\ua98d\ub7ae\u650e\u0b91\u1dda\ua660", "\ud8a2\uddcf\udbbc\udcab\udbda\udd1a\udb8a\udd31\ud94b\udee4\uda81\udc90",
        13, 82986, 1895268164, -2502918361435338333L, 79331L, false, false, (char) 12476, (char) 8998,
        Double.longBitsToDouble(0x3fe986f5d79072d7L), Double.longBitsToDouble(0x3fe94bd8ce64bf4bL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 5, 15, "\udbcc\uddb3\ud8cc\udfc7", "\u67c7\u313e\ud70c\ua0f6", "\udb38\udf12\udbbc\udc31\ud8e8\udef8\ud8ab\udcd3\ud9c7\udf02\ud8b8\udef6\uf338\ud9df\udc44\uda45\udf9a\ud8d6\udf60\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\udb25\ude6b\udb77\udd93\ud952\udf12\udbe5\udcb0\ud83e\udcd7\udb6d\udfdd",
        -4, 93416, -777988407, 3354175353728461795L, 67231L, false, true, (char) 15062, (char) 56461,
        Double.longBitsToDouble(0x3fc7f98a7671c91cL), Double.longBitsToDouble(0x3fd8ae69d615a62eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 6, 9, "\udbe5\udee2", "\ubaf9", "\udb21\udddf\ud8c2\udc75\ud85e\udd74\uda42\udcf1\ud8ea\udf89\ud964\udf64\uda43\udea3\ud868\udf33\ud9d5\ude62",
        49, 2577, 505470423, 7098320235821554124L, 42917L, false, true, (char) 48489, (char) 59261,
        Double.longBitsToDouble(0x3fd57a9f69233fd6L), Double.longBitsToDouble(0x3fe65a7d3aec9459L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 8, "\uda4f\udf4a\udb92\uddc3\udb3c\udc69\udacc\udf63\ud9e4\udc75\ud9c5\udd02\udb21\udddf\ud8a7\udee9\ud85e\udd88\udad4\udc5a\udb38\udf4d\udbbc\udc31\ud8e8\udef8\ud85d\udc57", "\ucd1b\u498c\u417f\u25ed\u2027\ud568\u56d0\u2203", "\udae2\udd42\uda59\udfd9",
        7, 14062, -197963024, -5225049266414505015L, -70788L, true, true, (char) 19821, (char) 56461,
        Double.longBitsToDouble(0x3fb7b314dc18cde0L), Double.longBitsToDouble(0x3febe11377645069L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 1, 15, "\uda24\udc83\ud9f7\udd14", "\u3ad5\u7442\ubc11\u5ff2\u24e3\u5ce4\u1cfb\u6d03\u4857\u923d\u58f6\u88a3\ucd1b", "\ud8b7\uddd0\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\ud9c1\ude4c\udaad\udf5f\uda8a\udf54\ud83e\udcd7\ud829\uddfb\udbf0\ude3d\ub11a\ud89b\udcdf\ud83f\udf54\ua5f1\u1ffb\udb7b\udf93\ud922\udfda\ud941\udefe\ud99a\udd7e\ud865\udef8",
        29, 5294, 41223674, 235444683068255460L, 64605L, true, false, (char) 53237, (char) 1700,
        Double.longBitsToDouble(0x3fdcd64a0a9ff924L), Double.longBitsToDouble(0x3fcd798276d93c20L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 15, "\uda4f\udf77\udb92\uddc3", "\u7ce0\u7442\ud70c\u3155\u37eb\u5ce4\u1dbd\u6d03\u3be5\u929d\uc625\u8867\ucd1b\u4559", "\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\udb1c\udc01\ud94c\udfad",
        21, 66310, -2092923551, 3895065033394631470L, -59907L, true, true, (char) 56461, (char) 6350,
        Double.longBitsToDouble(0x3fe2abeb586e8463L), Double.longBitsToDouble(0x3fdfa8d4046498eaL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 15, "\uda4f\udf77\udb5b\udec3", "\u80f4\ub933\u7bc5\u62b9\u65e2\u5ce4\u4c09\u6d03", "\ud89e\udf4e\udb3b\udd39\uf338\udae5\udda8\ud9db\udc75\udbed\uddcb\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\ud822\udf7c\ud852\udd7e",
        36, 64612, 797455150, -850244715113814688L, 26041L, true, false, (char) 5077, (char) 37624,
        Double.longBitsToDouble(0x3fdfb2cfba2b7690L), Double.longBitsToDouble(0x3fc14300817b314cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 4, "\uda4f\udf77\udb92\uddc3", "\u7d2b\u7442\ud70c\u5ff2\u24e3\u5ce4\u1cfb\u6d03", "\ud89e\udf4e\udbdd\udfd9\uf34e\udae5\udda8\ud9db\udc75\ud8b7\uddd0\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\ud9c1\ude4c\udaad\udf5f",
        36, 64612, 797455150, -850244715113814688L, -59907L, false, true, (char) 56461, (char) 36017,
        Double.longBitsToDouble(0x3fd6da6470dd0894L), Double.longBitsToDouble(0x3fdfa8d40f6204eaL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 4, 2, "\uda4f\udf77\udb92\uddc3", "\u2d60\u7442\ud70c\u5ff2\u9870\u5ce4\u5705\u0465", "\ud89e\udf4e\ud8de\udc38\uf338\udae5\udda8\ud9db\udce1\ud8b7\uddd0\udb2c\udd9d\udbb0\ude0c\udaaf\udedb\ud8cd\udf08\ud858\ude93\ud9c1\ude4c\udaad\udf5f",
        36, 64612, 797455150, -850244715113851296L, 43213L, true, false, (char) 14247, (char) 25023,
        Double.longBitsToDouble(0x3fc3a2921653cc60L), Double.longBitsToDouble(0x3fc14300817b314cL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 0, "\uda4f\udf77\udb92\uddc3\udb3c\udc69\udacc\udf63\ud9e4\udc75\udb6d\udd2c\ud9e3\uded3\udaa7\uddae\ud82d\udd32\uda86\udff3", "\u4857\u923d\ucc42\u8887\ucd1b\u498c\u417f\ud1db\u7cc1\u1639\ud66a\u54c4\u238b", "\ud90c\udf05\ud83e\udcd7\udb6d\udfdd\udbf0\ude3d\ue680\uda89\ude76\uea61\u105e",
        49, 76967, -1613141679, 1730699007116952714L, -100000L, false, false, (char) 18415, (char) 21184,
        Double.longBitsToDouble(0x3fa37e2deb668670L), Double.longBitsToDouble(0x3fe1e0960589b291L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 0, "\uda4f\udf77\udb92\uddc3\udb3c\udc69\udacc\udf63\ud900\udc79\udb40\udc00\udb21\udddf\ud8a7\udee9\ud85e\udd88", "\u6d03\u225e\u923d\ud76d\u2165\ucd1b\u498c\u472a\u191c\u7cc1\u1639", "\ud858\udf52\udb88\ude8f",
        39, 26240, -592602556, 5730886798292505328L, -14953L, true, false, (char) 6662, (char) 6823,
        Double.longBitsToDouble(0x3fdce0c072a3f5deL), Double.longBitsToDouble(0x3feb5cfecc8a1845L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 7, "\uda4f\udf77\udb92\uddc3\udb3c\udc69\udacc\udf63\ud900\udc79\udb40\udc00\udb21\udddf\ud8a7\udee9\ud85e\udd88", "\u6d03\u225e\u923d\u00b5\u88a3\ucd1b\u388c\u417f\u191c\u7cc1\u1639", "\ud858\udf52\udb88\ude8f",
        39, 48392, -592602388, -5866108682789701062L, -14953L, true, false, (char) 6662, (char) 6823,
        Double.longBitsToDouble(0x3fdce0c072a3f5deL), Double.longBitsToDouble(0x3feb5cfeccc1cb45L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 0, "\uda4f\udf77\udb92\uddc3\udb3c\udc69\udacc\udf63\ud900\udc79\udb40\udc00\udb21\udddf\ud8a7\udee9\ud85e\udd88", "\u6d03\u225e\u923d\u00b5\u88a3\ucd1b\u498c\u417f\u191c\u7cc1\u1639", "\ud956\udeca\udb77\udc4d",
        52, 48392, -592602388, 5730886798292505328L, -14953L, true, false, (char) 6662, (char) 6823,
        Double.longBitsToDouble(0x3fdce0c072a3f5deL), Double.longBitsToDouble(0x3feb5cfecc8a1845L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 15, "\uda4f\udec3\udb5b\udec3", "\u80f4\ub933\u7bc5\u256d\u69a9\ub7d3\u0aeb\u47b1", "\udba4\udce8\udb3b\udd39\ud81a\ude38\udae5\udda8\ud9db\udc75",
        3, 50472, -652862376, 6201506339184772612L, 5311L, true, false, (char) 55596, (char) 52781,
        Double.longBitsToDouble(0x3fe976e56dba2f88L), Double.longBitsToDouble(0x3fd60f43d7936ef8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 5, "\uda4f\udf77", "\u606e\u7d2b\u7442\ud70c\u5ff2\u7155\u382b\u1cfb\u2603\u2c0b\u5830\u58f6W\ucd31\u4559\u905b\u805c\u7cc1\u1639\ud66a\u54c4\u238b", "\ud947\udfd0\ud83e\udcd7\ud829\uddfb\udbf0\ude3d\udb82\udd03\ud89b\udcf1",
        39, 94481, 478195277, 1481760414073658525L, -20041L, true, false, (char) 23476, (char) 64696,
        Double.longBitsToDouble(0x3fdfa8d40f6204eaL), Double.longBitsToDouble(0x3fea8014ad258e88L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 0, "\udb6e\udf58\uda3e\udea4\udb3c\udc69\udacc\udf63\ud9e4\udc75\udb6d\udd2c\ud8e6\udd13\udaa7\uddae\ud82d\udd32\udbc8\udd6c", "\u4857\u923d\u3e42\u8887\ucd1b\ua5f9\u4241\ud1db\u7cc1\u1639\ud66a\u54c4\u9d05", "\ud90c\udf05\ud83e\udcd7\udb6d\udfdd\udbf0\ude3d\udac3\udc64\uda89\uddd5\uea61\u105e\udaa1\udea3\uda4b\udcf2\ud984\udfa6\ud941\udefe",
        40, 54746, 0, 2658190308296565516L, -53702L, false, true, (char) 41834, (char) 6832,
        Double.longBitsToDouble(0x3fa64feff517e980L), Double.longBitsToDouble(0x3fa63047f33aaa50L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 2, 0, "\uda4f\udf77\udb92\uddc3", "\u67c7\u7c6f\ud70c\ua0f6\u3af3\u0bcf\uabdf\uc394", "\u00b5\ud864\udf1c\uf338\uda05\udf9d\ud820\udda0\u00cd\udb2c\udd9d\ud87a\udd51\udb72\ude70\ud8cd\udef5\uda3c\udc44\udb8e\udf76\udb2f\udc8d",
        19, 64612, 1334326062, -850244715113814688L, -63539L, true, false, (char) 31856, (char) 49487,
        Double.longBitsToDouble(0x3fd51faefb293ec8L), Double.longBitsToDouble(0x3fc143009eab314cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilder|resetInsertionMode||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|aboveOnStack|org.jsoup.nodes.Element|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearFormattingElementsToLastMarker||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToContext|[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableBodyContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableRowContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|error|org.jsoup.parser.HtmlTreeBuilderState|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk|boolean|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getActiveFormattingElement|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getBaseUri||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getDocument||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getFormElement||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|resetInsertionMode||new:org.jsoup.parser.HtmlTreeBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
