package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Entities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 2, "\ud8b5\udc14\ud8a5\udf55\udb3b\udc2b\ud903\udfc2\ud90f\udc75\udae1\udec5\udac9\udd81", "\u8a5e\uade1\u5c45\u0d20\u03ed\u2314\u20c4\u251f\u3afa\u7b2c\u594a\u5691\u97b9\u1489\u8a59\u3dc5", "\ud887\uddd4\ud85b\ude2f\ud850\udf78\uda9f\udd37\ud83f\ude06\udb61\uddd3\ud8ce\udf90\u1adc",
        21, 7480, 1039809672, 1127677338214564229L, 71261L, false, true, (char) 46144, (char) 9042,
        Double.longBitsToDouble(0x3fcf2acff57750f0L), Double.longBitsToDouble(0x3fceab8e8f84bc0cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 2, 2, "\ud8b5\udc14\ud8a5\udf55\udb3b\udc2b\ud903\udfc2\ud90f\udc75\udae1\udec5\udac9\udd81", "\u8a5e\uade1\u5c45\u0d20\u03ed\u2314\u20c4\u251f\u3afa\u7b2c\u594a\u5691\u97b9\u1489\u8a59\u3dc5", "\ud887\uddd4\ud85b\ude2f\ud850\udf78\uda9f\udd37\ud83f\ude06\udb61\uddd3\ud8ce\udf90\ud98e\udedf",
        21, 7480, 1039809672, 1127677338214564229L, 71261L, false, true, (char) 46144, (char) 9042,
        Double.longBitsToDouble(0x3fcf2acff57750f0L), Double.longBitsToDouble(0x3fceab8e8f84bc0cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 2, 0, "\ud8b5\udc14\ud8a5\udf55\udb3b\udc2b\ud903\udfc2\ud90f\udc75\udae1\udec5\udac9\udd81", "\ub564\u4999\uc5c5\u4996\ub19c\u2314\u20c4\u251f\u3afa\u7b2c\u594a\u5691\u857f\u1489\u8a59\u3dc5", "\ud887\uddd4\ud85b\ude2f\ud850\udf78\uda9f\udcb9\ucb41\ud9c4\udf1d\uda7a\udc68\u1adc",
        21, 7480, 1026631048, -1728569098437760681L, 52871L, false, true, (char) 1810, (char) 4730,
        Double.longBitsToDouble(0x3fea3927d5199e39L), Double.longBitsToDouble(0x3fc40aeff57750f0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 1, "\000\000\uda09\udda4\ud903\udfc2\ud90f\udc75\udae1\udec5\udac9\udd81", "\u8a5e\uade1\u5c45\u0d20\u03ed\u2314\u20c4\u4b724\000\u1d55\ucded\000\000\000\000", "\ud887\uddd4",
        53, 22946, -784365575, -4035224935400135641L, -34464L, true, false, (char) 64941, (char) 9609,
        Double.longBitsToDouble(0x3fc207bf46143e98L), Double.longBitsToDouble(0x3fb5df4006ce5000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 0, 2, 1, "", "\uaf96", "\udae1\udec5\uf200\000\udbf6\uddc8\udb8d\udc6d\udae0\udf3e\ud8f5\udd9a\u7073\ud9d6\udd84\ud9b6\ude8f\udab2\udd3a\ud8ce\udcfc",
        58, 54800, -598545517, 0L, 90463L, false, true, (char) 49277, (char) 0,
        Double.longBitsToDouble(0x3fd525b151f248eeL), Double.longBitsToDouble(0x3e409c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\ud9be\udd5a\ud8a5\udf55\udb3b\udc2b\ud903\udfc2\ud90f\udc75\udae1\udec5\udac9\udd81\012",
        Z.run(T, 1, 2, 2, 2, "\ud9be\udd5a\ud8a5\udf55\udb3b\udc2b\ud903\udfc2\ud90f\udc75\udae1\udec5\udac9\udd81", "\u8a5e\uade1\u5c45\u0d20\u03ed\u2314\u7b3d\u6e4f\u5215\u2cdd\ub538\ua149\u9879\u5e89\u8a59\u3dc5", "\udb63\udf7c\ud85b\ude2f\uda0c\ude37\uda9f\udd37\ud83f\ude06\udb61\uddd3\ud8ce\udf90\u1adc",
        21, 7480, 1039809672, 1127677338214564229L, 71261L, false, true, (char) 46144, (char) 53074,
        Double.longBitsToDouble(0x3fa5fd09d5dd43c0L), Double.longBitsToDouble(0x3fceab8e8f84bc0cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\ud8b5\udc14\ud8a5\udf55\udb3b\udc2b\ud903\udfc2\ud90f\udc75\ud94c\ude9a\ud87f\udd53\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\ud8b5\udc14\ud8a5\udf55\udb3b\udc2b\ud903\udfc2\ud90f\udc75\ud94c\ude9a\ud87f\udd53", "\u8a5e\uade1\ub7a5\ub29f\uaeef\u2314\u20c4\u251f\u3b84\u7b2c\u594a\u5691\u97b9\u1489\u8a59\u5db3", "\ud887\uddd4\ud8f8\udede\ud854\uddf5\uda9f\udd37\ud83f\ude06\udb61\uddd3\ud8ce\udf90\u1adc",
        21, 7480, 1039809672, 1127677338214564229L, 71261L, false, true, (char) 46144, (char) 9042,
        Double.longBitsToDouble(0x3fe80e7f055dd401L), Double.longBitsToDouble(0x3fceab8e8f84bc0cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\ud8b4\udf79\ud8a5\udf55\udb3b\udc2b\ud8c3\udc80\ud90f\udd26\ud9e9\udec9\udac9\udd81\0121=java.lang.String:\ud8b4\udf79\ud8a5\udf55\udb3b\udc2b\ud8c3\udc80\ud90f\udd26\ud9e9\udec9\udac9\udd81\012",
        Z.run(T, 2, 2, 2, 2, "\ud8b4\udf79\ud8a5\udf55\udb3b\udc2b\ud8c3\udc80\ud90f\udd26\ud9e9\udec9\udac9\udd81", "\u8a5e\uaf5c\u2e52\u5cc5\ud4cd\u13f1\ua27d\u251f\u3afa\u3db4\u0816\u3aa2\u5073\uba0d\u8a59", "\ud939\udff7\ud887\uddd4\ud85b\ude2f\ud850\udf78\uda9f\udd37\ud833\udfcb\ud9f6\ude5d\ud8dc\udd05\u1adc\ud986\udf28\udb65\uddec\u782f\ud82e\udd7c",
        44, 41407, 1056995545, 5099288417035787517L, -50069L, true, true, (char) 13955, (char) 5020,
        Double.longBitsToDouble(0x3fee84784ffce837L), Double.longBitsToDouble(0x3fce0f2c76ebc8a0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 0, 2, 1, "", "\u1835", "\udae1\udec5\uf200\ud9a6\udc3c\udbf6\uddc8\udb8d\udc6d\udae0\udf3e\ud8f5\udd9a\u7073\ud9d6\udd84\ud9b6\ude8f\udab8\udd4a\ud8c1\udef7",
        58, 54800, -598545517, 0L, 75229L, false, true, (char) 49277, (char) 0,
        Double.longBitsToDouble(0x3fd525b151c448eeL), Double.longBitsToDouble(0x3e409c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 0, 0, 1, "", "\uaf96\u69c4\u25c7\ud6b7\u436a\u6462\u6baf\u8a5e\ucbf0\u3874\u9f01\u9fd8\u5200\u20c4\u251f\u75a4\u193d\u1ce9\000\000\u388a\u1c9b\u3dc5\u02fd\ubc35\000\u63f3", "\000\udaf6\uddbd",
        16, 67263, -1212119813, 200484091491028452L, -43275L, false, false, (char) 14814, (char) 28140,
        Double.longBitsToDouble(0x3fe53a90ebe8510fL), Double.longBitsToDouble(0x3feeffef06ec374fL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\ud942\udddb\ud89a\udcad\udb3b\udc2b\uda04\udca2\ud947\uddf9\udae1\udec5\udac9\udd81", "\u8a5e\u8f96\u49e7\u387c\u07fe\u1325\u8573\u251f\u3afa\u7b2c\u594a\u5691\u97b9\u1489\u8a59\u3dc5", "\ud882\ude74\udbbe\udf01\ud862\udcec\ud911\uddcf\ud83f\ude06\udb61\uddd3\ud9a8\udfe4\u1a3e",
        21, 5416, 1039809672, 1127677333986705797L, 71261L, false, true, (char) 46144, (char) 9042,
        Double.longBitsToDouble(0x3fe5d2b3fd22b39eL), Double.longBitsToDouble(0x3fceab8e8135540cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,java.nio.charset.CharsetEncoder,org.jsoup.nodes.Entities$EscapeMode|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,org.jsoup.nodes.Document$OutputSettings|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
    "C|org.jsoup.nodes.Entities|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
