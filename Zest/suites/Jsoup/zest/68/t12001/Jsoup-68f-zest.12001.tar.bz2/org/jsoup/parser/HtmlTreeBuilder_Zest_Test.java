package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 12, 4, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ud9a5\udf15\ud85a\udd6b\udb47\udfe3\ub683", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, 405241362688151448L, -7347L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6c35de72eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 12, 7, "\udad4\udd22\ud94d\udc79\ud9dd\udeae\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ud9a5\udf15\ud85a\udd6b\udb47\udfe3\ub683", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\ud9d8\udc7e\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, 405241362688151448L, -7347L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6c35de72eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 12, 4, "\ud956\udd21\ud97d\udc28\ud9af\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ud9a5\udf15\ud85a\udd6b\udb47\udfe3\ub683", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, 405241362688151448L, -7347L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6c35de72eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 9, 4, "\udb15\uddea\udaa1\udd53\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\uc193\ud910\udcb9\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\u31dd\ud8c0\udcf8\udb4b\ude27\ud85a\udcd7\ud94a\udd69\udbfa\udd1b", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25\u74f8\u35c4", "\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23\ud8c0\udd4c\udbc0\udd90\ud8a7\udf9d\udb57\udd0c\udabf\udc44\udacc\udca9\udb3c\udfbd\udab8\udf4e\udb6e\ude80\ud9d5\ude1b\u9e77\ud99d\uddaa\udb8c\udd96\u877c\u984d\ud8f2\udc8c\udaf6\udc00\uda8f\udfd5",
        23, 53736, -293976372, -6707059126444461327L, -80628L, true, true, (char) 31540, (char) 22602,
        Double.longBitsToDouble(0x3fe2604767b03fe8L), Double.longBitsToDouble(0x3fea83b95788e7b7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 8, "\ud993\udcaf\ud9a2\udf1c", "\u4325", "\ud825\udc77\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\ud8ec\ude14\ud90b\udf14\u5a98\udade\udc62\ud9b2\ude33\udbbe\udc80\ud949\ude36\u1597\ub683\ud9c2\udc63",
        0, 1461, 1523335053, 4479664379874792599L, -45085L, true, false, (char) 18448, (char) 21411,
        Double.longBitsToDouble(0x3fe45cadb6d4c298L), Double.longBitsToDouble(0x3fecd39cb36ef9afL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 13, 4, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\udaa3\udc76\ud9eb\udf61\udb65\udcc7\ud908\udc8c\udbe0\ude0e\ud9af\udf66\ud8df\udd8a\udab0\udd83\uda6e\ude6c\ud9a5\udf15\uda85\udf81\ud961\udcb0\ub683", "\uc045\u332a\u9df1\ud42e\ucae2\ud030\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, 405241362688151448L, -7347L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6c35de72eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 7, 4, "\ud956\udd21\ud97d\udc28\uda32\udc1c\u7e6f\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\uda6b\udeaa\ud933\ude48\000\000\udb30\ude97\000\uda6e\ude6c\ud9a5\udf15\ud85a\udd6b\udb47\udfe3\ub683", "\uc045\u332a\u1c76\u47b3\u57bf\u297d\000\u5184", "\udb21\udfa3\u009a\ud9a7\uddd8\u9085\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538032128, 405241361357377432L, -7347L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6c35de72eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 12, 4, "\ud8f0\udd3e\ud97d\udcc8\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud8d3\udfdf\udb07\udeaf\ud86b\uded9\uda6e\ude6c\uda10\udfea\udb4f\uddbf\udb88\udd12\udabf\udceb", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25", "\udb51\udda3\udad6\ude36\ud9a7\ude46\u9085\uda25\udebd\ud91b\ude23",
        44, 78608, -1538031999, 405241362688151448L, -7523L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6dee8672eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 4, "\ud956\udd21\ud935\udc15\udaae\udfce\ud9c2\udfb8\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udd53\ud80a\udd81\udac1\udc3b\udbe0\ude0e\ud9af\udf66\udb5f\udc9b\ud86d\ude39\uda6e\ude6c\ud9a5\udf15\ud8aa\ude44\u69ab\u29d2", "\u12c1\u975f\u9df1\ud42e\ucae2\u3d4c\u76ec\u1c8f", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, -8480360702113837284L, -7347L, true, false, (char) 17999, (char) 53016,
        Double.longBitsToDouble(0x3fec41fa33e2ff8cL), Double.longBitsToDouble(0x3f9fe1f4c443fb80L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 1, 14, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\u8c02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\udb94\udcc2\udb1a\uddd3\udb98\udcf5\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ue813\ud85a\udd6b\udb47\udfe3\ub683", "\u5a45\u332a\u9df1\ud42e\u68d2\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23\ud8f6\udd21\ud838\udd43\udbd0\udd19\udb57\udd33\udabf\udc44\udacc\udca9\ud890\udfc7\udab8\udf4e",
        30, 11993, -344698963, -953163940049501030L, -96927L, true, false, (char) 63633, (char) 51882,
        Double.longBitsToDouble(0x3fe47b90e163d2b4L), Double.longBitsToDouble(0x3fe1933616e41aefL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 0, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\udbda\uddf6\ud85d\udfab\udb47\udfe3\ub683", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\uda97\ude98",
        44, 78608, -1538031999, 405241362688151448L, -7347L, false, false, (char) 48553, (char) 40466,
        Double.longBitsToDouble(0x3fed6c339672eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 12, 4, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\udae4\ude05\ud993\udc8b\uda73\ude2a\ud97b\udc85\ud825\udc77\ud9e8\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud86b\uded9\ud874\udd0e\uda2f\udcd7\uda57\udd4b\udb47\udfe3\ub683", "\uc045\u332a\u9df1\ubfa7\u6642\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, 405241362688151448L, -7347L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6c35de72eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 12, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\ud820\ude02\ud9de\udddb\uda5b\udcfb\u2a79\udbc6\udcb4", "\u5618\u9c20\u6029\u890f\u3862\u4a5a\u4c8d\u605d\u9af8\u568c\u07ac\u6112\uc045\u332a\u2f07\u09d5", "\udaec\udcc4\u66b9\ud9dd\udf97\ud935\ude72\u01c7\udbaf\udcc4\ud998\udea1\u9085\uda6c\udc2e\ud91b\ude23\ud96e\udcbd\ud856\udd93\udbd0\udd19\udab8\udd04\ud81e\udc51\udacc\udca9\udb36\udebf\udab8\udf4e\udb6e\ude80\ud9d5\ude1b\u9e77\ud99d\uddaa\udb8c\udd96\ud879\ude00\udbb9\udd2d\ud8c1\udda5\ud973\udd8a\ud977\ude01\u8381\uda2d\ude6d\ud9bb\ude5f\ud827\ude53\ud8f6\udda7\udaa8\udede\udbd1\udfc2",
        48, 77851, 1956216968, 3514980461514999679L, 374L, true, true, (char) 21194, (char) 9007,
        Double.longBitsToDouble(0x3fdb51e7e4da319eL), Double.longBitsToDouble(0x3fd51485359392ccL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 12, 4, "\ud956\udd21\ud97d\udc28\uda01\udc01\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ud9a5\udf15\ud85a\udd6b\udb47\udfe3\ub683", "\uc045\u332a\u9df1\ud42e\ucae2\ub73d\u94ac\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, -8836108935138531644L, -7347L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fe9e845de72eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 2, "\uda56\udf7f", "\u1df5\u4325\u183c\ubd7c\ud201\u561e\uaf0f\u837f", "\udb33\udfaa\ud86b\uded9\uda6e\ude6c\ud817\udc76",
        50, 41505, -789681766, -6166902392135524458L, -83731L, true, true, (char) 41538, (char) 20779,
        Double.longBitsToDouble(0x3fd7dfbe6c378ceeL), Double.longBitsToDouble(0x3fe80d9c5ddbc969L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 2, "\udad4\udd22\ud94c\udf97\ud9dd\udeae\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\u2b2a\uda1e\ude52\ud8e5\udf78\udbd7\udd92\ud9af\udf66\udaa9\udc00\ud86b\udf29\uda6e\ude6c\ud855\ude22\ud85a\udd6b\udb47\udfe3\ub683", "\uc045\u332a\u9df1\u2afc\uc807\ubb2a\u5961\u0389", "\udb5a\uded0\ud9d6\ude74",
        17, 42813, -1892032812, -7167667924721326597L, 36344L, true, true, (char) 5972, (char) 38809,
        Double.longBitsToDouble(0x3fd0ca7d2a83a9aeL), Double.longBitsToDouble(0x3fcc30c326df8208L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 7, "\udad4\udd22\ud94d\udc79\ud9dd\udeae\u6c2b\ud9a1\udc61\udaee\udc40\udb55\udfc1\udb8d\udd9c\ud9eb\udeee\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ud9a5\udf15\ud85a\udd6b\udb47\udfe3\ub683", "\uc045\u332a\u9df1\ud42e\u40d0\u31e6\u8ac5\uc1a4", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\ud9d8\udc7e\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, 405241362688151448L, -7347L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6c35de72eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 4, "\udb15\uddea\udaa1\udd53\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\uc193\ud910\udcb9\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud83a\udfd3\udb63\udf5f\udb4b\ude27\ud85a\udcd7\ud94a\udd69\udbfa\udd1b", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25\u74f8\u35c4", "\uda53\udf30\u9085\uda6c\udc2e\ud91b\ude23\ud8c0\udd4c\udbc0\udd90\ud8c7\udf9d\udb57\udd0c\udabf\udc44\udacc\udca9\udb3c\udfbd\u4788\udb6e\ude80\ud9d5\ude1b\u9e77\ud99d\uddaa\udb8c\udd96\u877c\u984d\ud8f2\udc8c\udaf6\udc00\uda8f\udfd5",
        37, 53736, -293976372, -6707059126444461327L, -80628L, true, true, (char) 31540, (char) 22602,
        Double.longBitsToDouble(0x3fe2604767b03fe8L), Double.longBitsToDouble(0x3fea83b95788e7b7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 4, "\uda3f\udc4a\ud97d\udc45\ud9dd\udeb2\ud820\ude02\udaa9\udf56\udab8\udfd9\ud97a\udf85\udabb\udc22\ud9eb\udf61\udbe1\udf46\ud90a\udcc2\udbe0\ude0e\ud9af\udf66\ud8df\udd8a\udab0\udd83\uda6e\ude6c\ud9a5\udf15\uda85\udf81\ud958\udfb0\udaa8\ude83", "\uc045\u332a\u4d8f\ud42e\ucae2\ucff0\u8ac5", "\uda68\udeec\udb51\udda3\ud89f\udf73\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23\ud8f6\udd21\ud838\udd43\udbd0\udd19\udb57\udd33\udabf\udc44\udacc\udca9\udb3c\udfbd",
        32, 67124, -2034531007, -1480470773272039822L, -60073L, false, false, (char) 47956, (char) 26493,
        Double.longBitsToDouble(0x3fed5b30d6eaf77eL), Double.longBitsToDouble(0x3fe27b09f8349750L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 0, "\udbdb\ude80\ud995\udc44\uda38\udca0\ud8f6\udebe\ud993\udd4a\uda5b\udf2a\ud99e\udd76\ud87b\udd55\uda8e\udd13\uda0d\udf7b\u822b\udb7a\udd4e\u59cb\udb30\ude97\udb09\udc2d\uda6e\ude6c\ud9a5\udf15\ud936\ude6d\udb47\udfe3\ub683", "\u579e\u332a\u1c76\u47b3\u57bf\u46e0\uc45c\u5212", "\udb7f\udfb2\udb67\udcbf\ud974\udf26\u9085\uda6c\udc2e\udbe1\ude26\ud8f6\udd21",
        37, 99625, -881935126, -8754959459019535792L, 70662L, false, true, (char) 23064, (char) 54888,
        Double.longBitsToDouble(0x3fdcdeb74934beb0L), Double.longBitsToDouble(0x3fefbaa51eedf623L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 4, "\ud8f0\udd3e\ud97d\udcc8\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\ud86a\udcf4\ud829\uddb1\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud8d3\udfdf\udb07\udeaf\ud86b\uded9\uda6e\ude6c\uda10\udfea\udb4f\uddbf\udb88\udd12\uda1d\ude69", "\uc045\u332a\u9df1\ud42e\ucae2\u86dc\u0d34\u1c25", "\udb51\udda3\udad6\ude36\ud9a7\ude46\u9085\uda25\udebd\ud8c9\ude25",
        44, 78888, -1538031999, 405241362688151448L, 58013L, true, false, (char) 20668, (char) 23064,
        Double.longBitsToDouble(0x3fed6dee8672eb74L), Double.longBitsToDouble(0x3fc35e58afdd528cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 10, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\u8c02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\udb94\udcc2\udb1a\uddd3\udb98\udcf5\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ue813\ud85a\udd6b\udb47\udfe3\ub683", "\u5a45\u332a\u74f2\u8706\u5d59\u692a\u8ac5\u1c25", "\ud8cf\udc63\udafd\udfeb\ud993\ude46\u9085\uda6c\udc2e\ud91b\ude23\ud8f6\udd21\ud838\udd43\ud864\udf82\udb57\udd2c\udabf\udc44\uf582\ud891\udc4a\udab8\udf4e",
        30, 11993, -344698963, -953163940049501030L, -96927L, true, false, (char) 63633, (char) 51882,
        Double.longBitsToDouble(0x3fe47b90e163d2b4L), Double.longBitsToDouble(0x3fe1933617e3a6efL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 1, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\u8c02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\udb94\udcc2\udb1a\uddd3\udb98\udcf5\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ue813\ud85a\udd6b\udb47\udfe3\ub683", "\u5a45\u332a\u9df1\ud42e\u68d2\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23\ud8f6\udd21\ud838\udd43\udbd0\udd19\udb57\udd33\udabf\udc44\udacc\udca9\ud890\udfc7\udab8\udf4e",
        30, 11993, -344698963, -953163940049501030L, -96927L, true, false, (char) 63633, (char) 51882,
        Double.longBitsToDouble(0x3fe47b90e163d2b4L), Double.longBitsToDouble(0x3fef790e114a76d3L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 1, 14, "\ud956\udd21\ud97d\udc3b\ud9dd\udeb2\u8c02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\udb94\udcc2\ud83d\udc2f\uefa4\ud9af\udf66\udb07\udeaf\udb42\udd83\ud97c\udcd0\ue813\udae6\udd71\udb47\udfe3\ub683", "\u5a45\u332a\u9df1\u1804\u00a0\u2569\u8b13\u1c25", "\udb3a\ude3a\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23\ud8f6\udd21\ud838\udd43\udbd0\udd19\udb57\udd33\udabf\udc44\udacc\udca9\ud90f\udcf7\udab8\udf2a",
        30, 11993, -344698963, -1961970257747085165L, -96927L, true, false, (char) 63633, (char) 51978,
        Double.longBitsToDouble(0x3fe47b90e163d2b4L), Double.longBitsToDouble(0x3fe8f2f7b6e48849L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 14, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\u8c02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\udb94\udcc2\udb1a\uddd3\udb98\udcf5\ud8d7\udd67\udb20\udd09\ud86b\uded9\uda6e\ude6c\ue813\ud85a\udd6b\udb47\udfe3\ub683", "\u5a5d\u332a\u9df1\u53b8\u3c82\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\ud9a7\ude46\u9085\uda6c\udc2e\ud91b\ude23\ud8f6\udd21\ud838\udd43\udbd0\udd19\ud9ab\udd9d\udafa\ude32\udacc\udca9\ud890\udfc7\udab8\udf4e",
        30, 11993, -344698963, -953163940049501030L, -96927L, true, false, (char) 63633, (char) 51882,
        Double.longBitsToDouble(0x3fe47b90e163d2b4L), Double.longBitsToDouble(0x3fe1933616e41aefL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 16, 10, "\udb99\udc46\ud97d\udc28\uda0a\udc84\ud85d\udd94\ud984\udd8e\uda73\ude2a\ud97a\udf85\ud836\udd77\ud9eb\udf61\udb94\udcc2\u0222\ud833\udc09\ud9af\udf66\udb07\udeaf\ud87e\uded9\uda6e\ude6c\ud804\ude13\ud85a\udd6b\udabb\udfdd\uda4b\udf51", "\ubdcc\u6e10\u4eff\u20b8\u68cf\u3d4c\u60b3\ucf2e\u0f74\u9020\ua86e\u8c0f\u5733\ua8aa\u7a7c", "\udb66\udcb8\udbd0\udd19",
        32, 11736, 773987557, 6974127900704433154L, 56118L, true, true, (char) 39502, (char) 39156,
        Double.longBitsToDouble(0x3fefbaa51cc21312L), Double.longBitsToDouble(0x3fe57e740c013517L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 14, "\ud9e7\udddf\ud939\udd31\ud9dd\udeb2\u8c02\ud993\udd4a", "\ub358\u8c13\uc37a\u1afd\u8a37\u6029\u890f\u2e58\u4a5a\u2d5d\u605d\u9af8\u568c\u07ac", "\ud9f0\udd1d",
        53, 69079, -2120366443, -4145596645726198245L, -17780L, false, true, (char) 54557, (char) 29365,
        Double.longBitsToDouble(0x3fe6a35d2c008f39L), Double.longBitsToDouble(0x3fea8ce43f309706L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 14, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\u8c02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\udb94\udcc2\udb1a\uddd3\udb98\udcf5\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ue813\ud85a\udd6b\udb47\udfe3\ub683", "\u5a45\u332a\u2a73\ud42e\u68d2\u3d4c\u8ac5\u1c25", "\udb51\udda3\udac8\udf3a\uda3b\udc50\u9085\uda6c\udc2e\ud91b\ude23\ud8f6\udd21\ud838\udd43\udbd0\udd19\udb57\udd33\udabf\udc44\udacc\udca9\ud890\udfc7\udab8\udf4e",
        30, 11993, -344698963, -953163940049501030L, -96927L, true, false, (char) 63633, (char) 51882,
        Double.longBitsToDouble(0x3fe47b90e163d2b4L), Double.longBitsToDouble(0x3fe1933616e41aefL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 15, "\uda65\udcde", "\uaa6d\u4325\u967a\ub01b\u4941\ua6dc\uaedf", "\ud801\udf3f\ud909\uddee\ub2a5\ud846\udf19\udb56\ude01\ud977\uddaa\ud9ab\udeaa\udbc5\udfc2\ud81e\udebd",
        37, 69637, -221495411, 974173439611353023L, -89315L, true, false, (char) 25983, (char) 29426,
        Double.longBitsToDouble(0x3fd815a03d538948L), Double.longBitsToDouble(0x3fe0b620da54adefL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 11, "\udbb9\ude04", "\u6bf7\u4325\u183c\ud50c", "\udac1\udf15\udb4e\udeca\ud882\udeb7\ud839\ude8b\ud8d6\ude4c\ud8ed\ude55\uda86\ude33\ud817\udc76\ud89d\udd4e\udb1d\udf90\ud8c5\udc23\udba3\uddec\udbb0\udedb\ud991\udfc8\ud85a\udcf9\udbaa\udfdf\ud96a\udde1\udbb5\ude72\ud802\udc3e\ud84b\udf32\ud870\udf10\u10e1\udad9\udd2d\ud993\udc8d\ud905\udc9c\ud824\udffa\udaf6\udff5\udb70\udeaa\udbb6\udf5b\ud88b\udc0b\ud87d\ude48",
        52, 16518, -741970229, 3427992810328036921L, -67313L, false, true, (char) 39563, (char) 36329,
        Double.longBitsToDouble(0x3fea69965b085913L), Double.longBitsToDouble(0x3fee22a2ae5e0330L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 4, "\udb15\uddea\udaa1\udd53\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\uc193\ud910\udcb9\ud9eb\udf61\ud9b2\udd72\ud85a\uded6\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud83a\udfd3\udbf5\udec8\udb59\ude49\ud85a\udcd7\ud94a\udd69\udbfa\udd1b", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25\u74f8\u35c4", "\uda53\udf30\u9085\uda6c\udc2e\ud91b\ude23\ud8c0\udd4c\udaac\udde7\udafc\udc89\udb57\udccb\udabf\udc44\udacc\udca9\udb3c\udfbd\u4788\udb6e\ude80\ud9d5\ude1b\udbbc\udda1\udacf\udede\ud90c\udd96\u877c\u984d\ud861\udec1\udaf6\udc00\uda8f\udfd5",
        37, 53736, -293976372, -6707059126173207823L, -80628L, true, true, (char) 31540, (char) 22602,
        Double.longBitsToDouble(0x3fe2604767b03fe8L), Double.longBitsToDouble(0x3fea83b95788e7b7L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 9, "\udbdb\ude80\ud995\udc81\uda38\udca0\uda31\udcfb\ud993\udd24\uda5b\udf2a\ud99e\udd76\ud8f1\udd50\uda8e\udd13\uda0d\udf7b\u822b\ud9ee\udfc3\udac5\udf06\udac6\udc9f\ud8cc\uddbc\u0689\udbb7\udf1e\ud936\ude6d\udb47\udfe3\ub683", "\u579e\ua77f\u1c76\u2a5e\u6301\u4ee5\uc4b8\u5212", "\udb7f\udfb2\udb67\udcbf\ud974\udf26\u9085\uda6c\udc2e\udbe1\ude26\ud8f6\udd21",
        0, 16507, -881967996, -6657911427292870098L, 70662L, false, true, (char) 56467, (char) 54888,
        Double.longBitsToDouble(0x3fdcdeb74934beb0L), Double.longBitsToDouble(0x3fefbaa51eedf623L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 10, "\u5388\ud97d\udc28\ud9dd\udeb2\u8c02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\udadb\uddb9\udb94\udd10\udb1a\uddd3\udb98\udcf5\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ue813\ud85a\udd6b\udb47\udfe3\ub683", "\u5a45\u332a\u74f2\u8706\u5d59\u692a\u8ac5\u7d55", "\ud8cf\udc63\udafd\udfeb\ud993\ude46\u9085\uda6f\ude4f\uda92\ude26\ud916\udf81\udb0b\ude7b\ud864\udf24\udb57\udd2c\ud9b6\udc61\uf539\ud891\udc4a\udab8\udf4e",
        30, 11993, -344698963, -953163940049501030L, 93535L, true, false, (char) 63633, (char) 51882,
        Double.longBitsToDouble(0x3fe47b90e1ba07b4L), Double.longBitsToDouble(0x3fdfaa9daee259deL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 10, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\u8c02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\udb94\udcc2\ud81a\ude32\udbb4\ude6e\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ue813\ud85a\udd6b\udb47\udfe3\ub683", "\u5a45\u332a\u74f2\u8706\u5d59\u692a\u8ac5\u1c25", "\ud8cf\udc63\udafd\udfeb\udbb5\udc83\uda09\udd0b\ud8a7\udf9c\udb83\udf22\ud95c\uddc3\ud863\uddac\ud864\udf82\udb57\udd2c\udb6d\udf9c\uf501\ud891\udc4a\udab8\udf4e",
        30, 11993, -344698963, -953163940049501030L, -22238L, false, false, (char) 16767, (char) 15656,
        Double.longBitsToDouble(0x3fe335b15b9e0f0dL), Double.longBitsToDouble(0x3fe47b90e163d2b4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 13, 4, "\ud956\udd21\ud97d\udc28\ud9dd\udeb2\ud820\ude02\ud993\udd4a\uda73\ude2a\ud97a\udf85\ud825\udc77\ud9eb\udf61\uda6b\udeaa\udab8\udf4a\udbe0\ude0e\ud9af\udf66\udb07\udeaf\ud86b\uded9\uda6e\ude6c\ud9a5\udf15\ud85a\udd6b\udb47\udfe3\ub683", "\uc045\u332a\u9df1\ud42e\ucae2\u3d4c\u8ac5\u1c25", "\udb51\udda3\ud842\udf65\ud9a7\ude57\u9085\uda6c\udc2e\ud91b\ude23",
        44, 78608, -1538031999, 405241361496969112L, 44916L, false, false, (char) 8250, (char) 23064,
        Double.longBitsToDouble(0x3fed6c35de72eb74L), Double.longBitsToDouble(0x3fd3ef2c56fae97aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilder|inSpecificScope|java.lang.String,[Ljava.lang.String;,[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|inSpecificScope|[Ljava.lang.String;,[Ljava.lang.String;,[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|aboveOnStack|org.jsoup.nodes.Element|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearFormattingElementsToLastMarker||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToContext|[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableBodyContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableRowContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|defaultSettings||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|error|org.jsoup.parser.HtmlTreeBuilderState|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk|boolean|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getActiveFormattingElement|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getBaseUri||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|inSpecificScope|java.lang.String,[Ljava.lang.String;,[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|inSpecificScope|[Ljava.lang.String;,[Ljava.lang.String;,[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
