package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class Token_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 8, 12, "\udaa4\udd8e", "\u3a09\u292b\u657e\u57d6\u9b52\ud6d3\ubb9f\uc50d\uc3ef\u15b7\u0ce5\u6710\u4da8", "\ud8ab\udc70",
        40, 29384, 2080075972, -4195781452631886375L, -49450L, true, false, (char) 65365, (char) 42027,
        Double.longBitsToDouble(0x3fc06075ea30bbc0L), Double.longBitsToDouble(0x3fe0ce8c44d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 8, 12, "\udaa4\ude18", "\u3a09\u292b\u657e\u57d6\u9b52\ud6d3\ubb9f\uc50d\uc3ef\u15b7\u0ce5\u6a06\u1dc9", "\ud8ab\udc70",
        40, 29384, 2080075972, -4195781452631886375L, -49450L, true, false, (char) 65365, (char) 42027,
        Double.longBitsToDouble(0x3fc06075ea30bbc0L), Double.longBitsToDouble(0x3fe0ce8c44d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 12, "\udaa4\udd8e", "\u3a09\u292b\ud434\u1a9b\u7f78\u776c\ubb9f\uc50d\uc3ef\u15b7\u0ce5\u6710\u4da8", "\ud8ab\udc70",
        40, 29384, 2080075972, -50875655598424563L, -49450L, true, false, (char) 65365, (char) 53291,
        Double.longBitsToDouble(0x3fc320ec6a30bbc0L), Double.longBitsToDouble(0x3fe3ecd444d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 12, "\udaa4\udd8e", "\u3a09\u292b\u657e\u57d6\u9b52\ud6d3\ubb9f\uc50d\uc3b4\u15b7\u0ce5\u6710\u4da8", "\ud8ab\udc70",
        40, 29384, 2080075972, -4195781452631886375L, -49450L, true, false, (char) 65365, (char) 42027,
        Double.longBitsToDouble(0x3fc06075ea30bbc0L), Double.longBitsToDouble(0x3fe0ce8c44d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 3, 0, "\udaa4\udd8e\ud878\udeee\uda48\udca8\ud8c7\udc1f\ud9a3\udd5a\ud8cb\udd02\udb64\udc0d\ud9d7\ude1c\ud819\uddbd\udad3\uddf8", "\u15b7\u0ce5\u6710\u632b\u9381\u8059\u4491\u5b51\u23c8", "\ud9d3\udf30\ud98e\ude57\uda6f\uddbc\udb95\ude85\udb20\udebf\uda55\udc4c\ud876\udf47\udbfd\udfce\udaae\udd18\udaac\ude31\ud901\udf83\udb9d\udff9\udb13\udc68\ud906\udeef\ud90c\udf5d\udad2\udc4e\ud90e\udeec\u24a0\ud8ff\ude6d\udaf1\udde5\udbb4\udeef\udb04\udf55\ud8e6\udd18\udb40\uddc3\udba8\udc7a\uda52\udffa\uda27\udd00\ud810\udfc1\ud87c\udc3b\ud9d0\udef5",
        54, 99091, -2025118657, -7817081119231432411L, -13003L, true, false, (char) 18786, (char) 32072,
        Double.longBitsToDouble(0x3fe6f52ba355951eL), Double.longBitsToDouble(0x3fea6ac3b6243252L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\0121=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 7, 12, "\udaa4\udd8e", "\u3a09\u292b\u657e\u57d6\u9b52\ud6d3\ubb9f\uc50d\uc3ef\ub57b\u0ce5\u6710\u4da8", "\ud8ab\udc70",
        40, 29384, 2080075972, -4195781452631886375L, -49450L, true, false, (char) 65365, (char) 42027,
        Double.longBitsToDouble(0x3fc06075ea30bbc0L), Double.longBitsToDouble(0x3fe0ce8c41d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\0121=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 12, "\ud98f\udf86", "\u3a09\u292b\u657e\uc318\u25c0\u4830\u7dff\u6614\u4251\u0236\u0ce5\ua1cb\u4d79", "\udb23\udfe3",
        51, 12784, 2080082058, -4195781452631886375L, 30961L, true, true, (char) 5785, (char) 42027,
        Double.longBitsToDouble(0x3fc06075ea30bbc0L), Double.longBitsToDouble(0x3fe0ce8c44d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 8, 11, "\000", "\000", "\udb19\uddd5\udad2\ude88\uda91\uddc3\000\000",
        -5, 38168, 0, 167772160L, 36561L, false, false, (char) 1639, (char) 10685,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3ec8a00000000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 12, "\udb0a\udf0a", "\u551f\u292b\uafec\uc680\u0957\u4029\u7353\025\u1582\u15b7\u0ce5\u6710\u4da8\u09bd\u32f0\ud0ed\u5b9d\ua8f6\uabb5\ub1fc\u22d4\u2382\u6d71\u8279\u4881", "\udbd3\ude59\uda8b\ude18\ud8ae\udd51\udaf7\udd64\udb48\udc9e",
        30, 22084, 498266772, -7391060718025281353L, 5025L, false, false, (char) 22676, (char) 34905,
        Double.longBitsToDouble(0x3fc34cfc3f24b89cL), Double.longBitsToDouble(0x3fccdd61d3d3fef0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 8, 12, "\udaa4\udd8e", "\u3a09\u292b\u657e\u57d6\u9b52\ud6d3\ubb9f\uc50d\uc3ef\u15b7\u8501\ub602\u4da8", "\ud8ab\udc70",
        40, 29384, 2080075972, -4195781452631886375L, -49450L, true, false, (char) 65365, (char) 42027,
        Double.longBitsToDouble(0x3fc06075ea30bbc0L), Double.longBitsToDouble(0x3fe0ce8c44d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 12, "\udaa4\udd8e", "\u3a09\u292b\u657e\u57d6\u9b52\ud6d3\u4f2d\uc20d\u2d79\ucb99\u0ce5\u6710\u4da8", "\ud8ab\udc70",
        40, 29384, 2080075972, -4195781450165635623L, -49450L, true, false, (char) 65365, (char) 42027,
        Double.longBitsToDouble(0x3fb4c03694617780L), Double.longBitsToDouble(0x3fe0ce8c44d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 8, 11, "\udaa4\udd8e", "\u3a09\u292b\u657e\u8fb5\u9b52", "\udb98\udefa\udb9b\uddc6\udae7\udd3b\ud8c4\udd4f\u251b\udb0f\udfb5\udb0a\udca7",
        5, 49358, 268812355, -1991407184193556284L, 5715L, false, true, (char) 62134, (char) 11667,
        Double.longBitsToDouble(0x3fc55de450f03df4L), Double.longBitsToDouble(0x3fc060738a31408cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void\0121=!H:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 7, "\udaa4\udd8e", "\u3a09\u28f1\u657e\u57d6\ud69e\ud6d3\ubb9f\u3396\u58a4\u4b58\u44e7\u2ce1\u4da8", "\u3d2d",
        -5, 82764, 350957600, -2653251666329700129L, -49450L, true, false, (char) 65439, (char) 42027,
        Double.longBitsToDouble(0x3fd8303af51940dcL), Double.longBitsToDouble(0x3fe0ce8c44d8de0aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\0121=void |a0=java.lang.StringBuilder:\012",
        Z.run(T, 2, 12, 12, 12, "\udb6d\ude09\uda20\udfe5\udb04\udc5a\ud9f5\udca0\udb43\udd9e\ud9af\udee4\udb0a\udc9a\ud996\udf18\uda79\udf39\ud980\udc78\udb56\udf69\udb9b\uddc6\ud915\udd46\ud8be\udc1b\ud8d7\ude39\ud9b8\ude44\udb0a\udca7\ud875\udc2b\ud827\udc6e\udad4\udd34\ud806\udc17\ud9bc\udc12\ud99d\udf70\u833a\uda6c\udfd4\udb54\udfb6\udb95\uded5\udb15\udcbf\ud9d0\udc84\ud876\udf5d\ud8c3\udc91\udab9\udc7c\udb6f\udf93\ud8a8\udd97\ud996\udd5f", "\u0e6b\u40a8\u0f45\u3d12\u65c5\u1708\uafc5\ucc15", "\udb6a\uddae\udb7f\udfad\ud823\udfec\ud92c\udde4\ud9ad\udcc9",
        13, 737, 894130709, 5957887950649229871L, 32155L, true, true, (char) 16868, (char) 22709,
        Double.longBitsToDouble(0x3fd168fc2a1b0e04L), Double.longBitsToDouble(0x3fd820bea0ff8f1aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\012",
        Z.run(T, 1, 12, 3, 0, "\udaa4\udd8e\ud878\udeee\uda48\udca8\ud8c7\udc1f\udbb7\udce5\udb91\udec5\ud8e0\udfc9\ud9d7\ude1c\ud819\uddbd\udad3\uddf8", "\u1568\u0ce5\u4a06\u1fa1\u6603\ud7ba\u4491\u5b51\u23c8", "\ud9d3\udf30\ud98e\ude57\uda6f\uddbc\ud9cb\udfd4\ud8db\udfc0\udb35\uddc4\ud881\udf3c\udbee\udea4\udaae\udd18\udaac\ude31\ud901\udf83\udb9d\udff9\udb13\udc68\ud906\udeef\ud90c\udf5d\udad2\udc4e\ud90e\udeec\u24a0\udb81\udced\udaf1\udde5\udbb4\udeef\udba0\udd63\udb32\udfcd\udb40\uddc3\udba8\udc7a\uda52\udffa\uda27\udd00\ud810\udfc1\ud87c\udc3b\ud9d0\udef5",
        54, 99091, 179548735, -7841600116861687515L, -9228L, true, false, (char) 18786, (char) 32072,
        Double.longBitsToDouble(0x3fe6f52ba3559596L), Double.longBitsToDouble(0x3fea6ac3b6243252L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 12, 12, 0, "\udaa4\udd8e\ud878\udeee\uda48\udca8\ud8c7\udc1f\ud9a3\udd5a\ud8cb\udd02\udb64\udc0d\ud9d7\ude1c\ud819\uddbd\udad3\uddf8", "\u56b7\u0ce5\u6710\u632b\u9381\u8059\u4491\u5ba6\u23c8", "\ud9d3\udf30\ud98e\ude57\uda6f\uddbc\udb95\ude85\udb20\udebf\uda55\udc4c\ud876\udf47\udbfd\udfce\udaae\udd18\udaac\ude31\ud901\udf83\udb9d\udff9\udb13\udc68\ud906\udeef\ud90c\udf5d\udad2\udc4e\udb2c\ude5b\ud88f\uddf8\ud91d\udc61\uda74\udfa8\udaf4\udeef\udb04\udf55\ud8e6\udd18\udb40\uddc3\udba8\udc7a\uda52\udffa\ud849\udc09\ud9c4\udf32\ud87c\udc3b\ud9d0\udef5",
        54, 59683, -2023788928, -7817081119231432411L, -13204L, true, false, (char) 18786, (char) 32072,
        Double.longBitsToDouble(0x3fe6f52ba355951eL), Double.longBitsToDouble(0x3fea6ac3b6243252L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 12, 7, 12, "\udb09\udca6", "\u3a09\u292b\u657e\u57d6\u9b52\ud6d3\ubb9f", "\udb21\udd38\ud8a6\ude1b\ud9e7\udfc1\ud9b8\ude33\udb87\udcb3",
        35, 7478, 268812355, -1991407180083138364L, -49450L, true, false, (char) 65365, (char) 42027,
        Double.longBitsToDouble(0x3fc06075ea30bbc0L), Double.longBitsToDouble(0x3fe0ce8c4106de0aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 8, 12, "\udaa4\udd8e", "\u3aab\u292b\u657e\u57d6\u9b52\ud6d3\ubb9f\uc50d\uc3ef\u15b7\u0ce5\u6710\u4da8", "\ud8ab\udc70",
        40, 29384, 2080075972, -4195781452631886375L, -49450L, true, false, (char) 65365, (char) 42027,
        Double.longBitsToDouble(0x3fc06075ea30bbc0L), Double.longBitsToDouble(0x3fd6aa0889b1bc14L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.Token|asCharacter||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|asComment||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|asDoctype||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|asEndTag||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|asStartTag||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|isCharacter||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|isComment||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|isDoctype||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|isEOF||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|isEndTag||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|isStartTag||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|reset||new:org.jsoup.parser.Token$Character:",
    "M|org.jsoup.parser.Token|reset|java.lang.StringBuilder|static",
    "M|org.jsoup.parser.Token|tokenType||new:org.jsoup.parser.Token$Character:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
