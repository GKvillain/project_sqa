package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilderState_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\udbad\udd92\udbbe\udc62\uda17\ude07\u7d8c\ud823\udfe3", "\u80c0\uadcb\uc102\u4def\u5899\uba62\u5cfe\u9db4", "\ud887\udfa5\udb87\udce6\uda7b\ude73\ud8c7\udc87\udb48\ude82\ud95a\udde4\uda9a\udcb1\u82cb\ue738\udbb2\udc92\ud8ca\udde6\ud838\udd11\ud9fa\udfe8\udbd0\ude0f\ud888\udf37\ud858\udd32\u0b38\udb42\udcb5\ud8b2\udfa1\udb64\udf1c\udafd\udd6e\udbfe\udc87\udbc3\udd77\udb30\udcce\ud907\udef2\ud9b4\udf9b\ud89e\ude09",
        39, -141, -1560657738, 7570361337540174675L, -30268L, true, false, (char) 27014, (char) 32227,
        Double.longBitsToDouble(0x3fd59192436e12dcL), Double.longBitsToDouble(0x3fc4dd42f8b87714L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\udbad\udd92\udbbe\udc62\uda17\ude07\u7d8c\ud823\udfe3", "\u80c0\uadcb\u60c6\u4def\u5899\uba62\u5cfe\u9db4", "\ud887\udfa5\udb87\udce6\uda7b\ude73\udb07\udc55\udb48\ude82\ud95a\udde4\uda9a\udcb1\u82cb\ue738\udbb2\udc92\ud8ca\udde6\ud838\udd11\ud9fa\udfe8\udbd0\ude0f\ud888\udf37\ud858\udd32\udab5\udf7b\udb20\udea3\ud8b2\udfa1\udb64\udf1c\udafd\udd6e\udbfe\udc87\udbc3\udd77\udb30\udcce\ud907\udef2\ud9b4\udf9b\ud89e\ude09",
        39, -141, -1109689162, 3414847828595230851L, -30268L, true, false, (char) 27014, (char) 44003,
        Double.longBitsToDouble(0x3fd5945c136e12dcL), Double.longBitsToDouble(0x3fc4dd42f8b87714L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 6, "\udbad\udd92\udbbe\udc62\udbc9\ude21\ud919\udecc\ud823\udfe3\udb25\uddf8\ud944\udc9f\uda1f\ude9e\ud9cd\udf5e\ud90a\udec2\udbcd\udc53\ud8e6\udd97", "\u9db4\u3815\u1bab\u00bc\u6685\u401f\ud3c8\uccf6", "\u82cb",
        19, 66179, 1871872851, -33941768630225325L, 41714L, false, false, (char) 59442, (char) 36274,
        Double.longBitsToDouble(0x3fccffcec8f7a99cL), Double.longBitsToDouble(0x3fe64c38b25170ccL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 1, "\u946f\ud934\ude85\uda17\ude10\ud955\udfa7\uda58\udcf7", "\u63c8\uadcb\uc102\uc127\u5899\uba62\u5cfe\u9db4\u3815\u3ae1\u4c1a\u6685\u401f\ud3c8\uccf6\u19ba\u42e1", "\ud816\ude49\ud8ca\udde6\ud838\udd11\ud9fa\udfe8\udbd0\ude0f\ud9b0\ude3a\ud858\udd32\u0b38\ud8f8\udcf2\udbe1\udc1e\ud8b1\udf22\uda20\udc34\udbfe\udc87\ud850\uded9\udb30\udc45\uda0e\udec9\ud9b4\udf9b\ud89e\ude09\udbdd\udc56\uda76\udda3\uda58\udef8\udbf8\uddb7\uda10\uddfe\ud8e0\udd5f\ud870\ude92\uda41\udd5c\u3838",
        18, 78488, 421833105, 679741559919839671L, 80306L, true, false, (char) 46146, (char) 54756,
        Double.longBitsToDouble(0x3fe8230b32d00e00L), Double.longBitsToDouble(0x3fe7ff9ae1b9c739L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 5, "\ud8a1\uddac\udbbe\udc62\uda17\ude07\u7d8c\udbcf\udfd9", "\u80c0\uadcb\uc102\u4def", "\ud9ad\udca2",
        4, 29680, -1412716882, 8655479301353516777L, -44361L, true, true, (char) 58616, (char) 18698,
        Double.longBitsToDouble(0x3fd4e5428830ba42L), Double.longBitsToDouble(0x3fd3b35076a761f8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 2, 2, 6, 4, "\udaec\udf92\udbbe\udc62\uda17\ude07\ud875\udec5\ud823\udfe3", "\u80c0\uadcb\uc102\u4def\u5899\uba62\u5cfe\u9db4", "\udbf2\ude98\udb87\udce6\uda7b\ude73\ud8c7\udc87\udb48\ude82\ud95a\udde4\uda9a\udcb1\u82cb\udbe3\uddda\udbb2\udc92\ud902\udea1\udb98\udf65\ud9fa\udfe8\udbd0\ude0f\ud888\udf37\ud9e7\udcd9\udb02\uddaa\udb42\udcbf\ud8b2\udfa1\udb64\udf1c\ud8e5\udf03\udb34\ude5b\ud904\udc8e\udaab\uddc9\ud8ff\udf24\ud9b4\udf9b\ud89e\ude09",
        25, 34747, -1881441871, -5613617996739154153L, -57575L, false, false, (char) 6106, (char) 26564,
        Double.longBitsToDouble(0x3fee058e3191d452L), Double.longBitsToDouble(0x3fd59192436e12dcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\ud800\udc8f\udbbe\udc62\uda17\ude07\ud823\udc6d\ud823\udfe9", "\u80c0\u4601\uc13a\u4def\u7399\uca7c\u5c91\u9db4", "\udb5c\udcae\uda71\udf7d",
        5, 90001, 290324447, -7687941118129961729L, 28436L, true, true, (char) 13391, (char) 55734,
        Double.longBitsToDouble(0x3fb5dd61cbfda668L), Double.longBitsToDouble(0x3fe23736dcdac975L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 6, "\udbad\udd92\udbbe\udc62\uda17\ude07\u7d8c\ud823\udfe3", "\u80c0\uadcb\uc102\u4def\u5899\uba62\u5cfe\u9db4", "\ud887\udfa5\udb87\udce6\uda7b\ude73\ud8c7\udc87\udb48\ude82\ud95a\udde4\ud9ba\udc62\u5478\ue738\udbb2\udc92\ud8ca\udde6\ud838\udd11\ud9fa\udfe8\udbd0\ude0f\ud888\udf37\ud858\udd32\u0b38\udb42\udcb5\ud8b2\udfa1\udb64\udf1c\udafd\udd6e\udbfe\udc87\udbc3\udd77\udb0e\udf6a\ud907\udef2\ud9b4\udf9b\ud89e\ude09",
        39, -141, 992033206, 7570360959583052627L, -30268L, true, false, (char) 27014, (char) 32227,
        Double.longBitsToDouble(0x3fd59192436e12dcL), Double.longBitsToDouble(0x3fc4dd42f8b87714L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 2, 6, 6, 6, "\udbad\udd92\udbbe\udc62\uda17\ude07\u7d8c\ud823\udfe3", "\u80c0\uadcb\uc102\u4def\u5899\uba62\u5cfe\u9db4", "\ud887\udfa5\udb87\udce6\uda7b\ude73\ud8c7\udc87\udb48\ude82\ud95a\udde4\uda9a\udcb1\u82cb\ue738\udbb2\udc92\ud8ca\udde6\ud838\udd11\ud9fa\udfe8\udb4e\ude0e\ud888\udf37\ud858\udd32\u0b38\udb42\udcb5\ud8b2\udfa1\udb64\udf1c\udafd\udd6e\udbfe\udc87\udbc3\udd77\udb30\udcce\ud907\udef2\ud9b4\udf9b\ud89e\ude09",
        39, 33619, -1560657745, 7570361337540174675L, -30268L, true, false, (char) 27014, (char) 32227,
        Double.longBitsToDouble(0x3fd1e192436e12dcL), Double.longBitsToDouble(0x3fc4dd42f8b87714L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 6, "\udbad\udd92\udbbe\udc62\uda17\ude07\u7d8c\ud823\udfe3", "\u80c0\uadcb\uc102\u4def\u5899\uba62\u5cfe\u9db4\u3815\u3ae1\u86ee\u6685\u401f\ua1b5", "\uda9a\udcb1\u82cb\ue738",
        51, 44671, 1971808804, -5418568851994721921L, -74618L, true, false, (char) 36274, (char) 62301,
        Double.longBitsToDouble(0x3fe1ef533ec98716L), Double.longBitsToDouble(0x3fe28b8660126975L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 1, "", "\u885a\u2d43\u2426\u71e8\u1c58\u4182\u0338\u18e4\u4def\u5899\uba62\u5cfe\u55a7\000\u3ae1\u7091\000", "",
        58, 10888, 1409332156, 6710808747880995864L, -100000L, false, false, (char) 54750, (char) 30284,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e19a00000000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 1, 6, 3, 5, "\ud8a1\uddac\udbbe\udc62\udb47\udf52\ud82f\uddfa\uda5b\uddbe", "\uafb4\u1574\uc102\u01c3", "\udba6\udfca\uda0d\udf13\ud925\udd57\uda11\udd99\uda92\udfab\udb9d\udd9e\uda8c\udd73\ua259\udb8e\udd34",
        56, 73596, -1916693170, -2533188511128500175L, -85490L, false, true, (char) 35115, (char) 62626,
        Double.longBitsToDouble(0x3fe8d20f56d89a77L), Double.longBitsToDouble(0x3fdbf3a4c5faee08L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 2, 6, 6, 5, "\udbb4\udf75\uda1f\udf0d\ud97d\udeed\u7d8c\uda1c\udfdf", "\u80c0\uadcb\uc102\u4def\u4f76", "\ud810\udc71\udbf9\ude81\uda18\udc92\ud888\udc0b\udb87\udce6\udbf3\udc6c\ud8a2\uddc6\udb48\ude41",
        56, 50569, 1562481998, -6310127073269910232L, 61486L, true, true, (char) 48144, (char) 37235,
        Double.longBitsToDouble(0x3f93801890950000L), Double.longBitsToDouble(0x3fe562021b34519dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 2, 1, "", "\u885a\u2d43\u2426\u71e8\u1c58\u4182\u0338\u18e4\u4def\u5899\uba62\u5cfe\u55a7\000\u3ae1\u544f", "\000",
        58, 46776, 1409332040, 6710808747880995864L, -100000L, false, false, (char) 54750, (char) 30284,
        Double.longBitsToDouble(0x3e4d780000000000L), Double.longBitsToDouble(0x3e19a00000000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\udbad\udd92\udbbe\udc62\uda17\ude07\u7d8c\ud823\udfe3", "\u80c0\uadcb\uc102\u4def\u5899\uba62\u5cfe\u9db4", "\ud887\udfa5\udb87\udce6\uda7b\ude73\ud8c7\udc87\udb48\ude82\ud95a\udde4\uda9a\udcb1\u82cb\ue738\udbb2\udc92\ud8ca\udde6\ud9e5\udc15\ud9fa\udfe8\udbd0\ude0f\ud888\udf37\ud858\udd32\u0b38\udb42\udcb5\ud8b2\udfa1\udb64\udf1c\udafd\udd6e\udbfe\udc87\udbc3\udd77\udb30\udcce\ud907\udef2\ud9b4\udf9b\ud89e\ude09",
        39, -141, -1560657738, 7570361337540174675L, -30268L, true, false, (char) 27014, (char) 32227,
        Double.longBitsToDouble(0x3fd59192436e12dcL), Double.longBitsToDouble(0x3fc4dd42f8b87714L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRawtext|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRcData|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|isWhitespace|java.lang.String|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|isWhitespace|org.jsoup.parser.Token|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|process|org.jsoup.parser.Token,org.jsoup.parser.HtmlTreeBuilder|fac:org.jsoup.parser.HtmlTreeBuilderState:valueOf:java.lang.String",
    "M|org.jsoup.parser.HtmlTreeBuilderState|valueOf|java.lang.String|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|values||static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRawtext|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
