package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class DocumentType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\u2df6\" \"\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\0121=void |a0=java.lang.StringBuilder:\udb65\udd70\ud842\udf2a\udb9c\udf9b |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\u2df6\" \"\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\012",
        Z.run(T, 2, 1, 3, 0, "\udb65\udd70\ud842\udf2a\udb9c\udf9b", "\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\u2df6", "\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e",
        4, 15292, -364596410, 6255606957640484235L, 45899L, false, true, (char) 46906, (char) 28471,
        Double.longBitsToDouble(0x3fed381e28de9f92L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud86d\uddf6\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\u2df6\" \"\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\0121=void |a0=java.lang.StringBuilder:\ud86d\uddf6\ud842\udf2a\udb9c\udf9b |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud86d\uddf6\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\u2df6\" \"\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\012",
        Z.run(T, 2, 1, 3, 0, "\ud86d\uddf6\ud842\udf2a\udb9c\udf9b", "\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\u2df6", "\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e",
        4, 15292, -364596410, 6255606957640484235L, 45899L, false, true, (char) 46906, (char) 28471,
        Double.longBitsToDouble(0x3fed381e28de9f92L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\uca2e\u0493\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u067d\u0c47\u8a1b |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udb7a\udc46\udba7\udcab PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u067d\u0c47\u8a1b\" \"\udb43\udc08\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\0121=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udb7a\udc46\udba7\udcab PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u067d\u0c47\u8a1b\" \"\udb43\udc08\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\012",
        Z.run(T, 2, 3, 0, 0, "\udb65\udd70\udb7a\udc46\udba7\udcab", "\uca2e\u0493\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u067d\u0c47\u8a1b", "\udb43\udc08\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e",
        4, 3908, -364596410, 6255606957640484235L, 45899L, false, true, (char) 46906, (char) 28471,
        Double.longBitsToDouble(0x3fedc1ae28de9f00L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\uca2e\u0493\u1a89\uaccd\u756c\ua529\u86e2\u2c00\ud31e\u9a8a\u38c6 |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\ud927\udd0e PUBLIC \"\uca2e\u0493\u1a89\uaccd\u756c\ua529\u86e2\u2c00\ud31e\u9a8a\u38c6\" \"\uda99\ude5b\uda07\ude76\">\0121=void |a0=java.lang.StringBuilder:\udb65\udd70\ud842\udf2a\ud927\udd0e |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\ud927\udd0e PUBLIC \"\uca2e\u0493\u1a89\uaccd\u756c\ua529\u86e2\u2c00\ud31e\u9a8a\u38c6\" \"\uda99\ude5b\uda07\ude76\">\012",
        Z.run(T, 2, 3, 3, 0, "\udb65\udd70\ud842\udf2a\ud927\udd0e", "\uca2e\u0493\u1a89\uaccd\u756c\ua529\u86e2\u2c00\ud31e\u9a8a\u38c6", "\uda99\ude5b\uda07\ude76",
        48, 62641, -760820897, -7784097929233868884L, -75070L, true, true, (char) 6314, (char) 10959,
        Double.longBitsToDouble(0x3fe5692b6615b2a4L), Double.longBitsToDouble(0x3fdbcf3bdc641212L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u7eda\u2df6\u783c\u7e47\uc08b\u6813<!DOCTYPE \udb65\uddb4\ud842\udf2a\udbd0\udd1a\uda37\udeff\u5a65\udb9b\udf17\ud8c7\udc76\uda94\udf7c\u3cc1\udba9\udf0c\udbcc\udfb3\udb30\udfc1 PUBLIC \"\u7eda\u2df6\u783c\u7e47\uc08b\u6813\" \"\ud862\ude9e\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\uddb4\ud842\udf2a\udbd0\udd1a\uda37\udeff\u5a65\udb9b\udf17\ud8c7\udc76\uda94\udf7c\u3cc1\udba9\udf0c\udbcc\udfb3\udb30\udfc1 PUBLIC \"\u7eda\u2df6\u783c\u7e47\uc08b\u6813\" \"\ud862\ude9e\">\0121=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\uddb4\ud842\udf2a\udbd0\udd1a\uda37\udeff\u5a65\udb9b\udf17\ud8c7\udc76\uda94\udf7c\u3cc1\udba9\udf0c\udbcc\udfb3\udb30\udfc1 PUBLIC \"\u7eda\u2df6\u783c\u7e47\uc08b\u6813\" \"\ud862\ude9e\">\012",
        Z.run(T, 2, 2, 0, 0, "\udb65\uddb4\ud842\udf2a\udbd0\udd1a\uda37\udeff\u5a65\udb9b\udf17\ud8c7\udc76\uda94\udf7c\u3cc1\udba9\udf0c\udbcc\udfb3\udb30\udfc1", "\u7eda\u2df6\u783c\u7e47\uc08b\u6813", "\ud862\ude9e",
        4, 12412, -364596355, 6255606957640484235L, 45899L, false, true, (char) 46906, (char) 28471,
        Double.longBitsToDouble(0x3fed381e28de9f92L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 3, 0, "\udb65\udd70\ud842\udf2a\udbeb\udc81", "\uca2e\u9483\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\u2df6\u783c\u7e47\uc08b\u6813\u1f16\ud40a\ub6f7", "\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\uda47\udeb3\udbc1\udc1d\ud801\udd5c\udb7b\udc7d\udb47\udd05\udb86\udc6d\ud8b8\uddf8\ud931\ude51\ud99e\udca2\uda86\udef6\ud94a\udf59\uda63\ude77\ud8ac\udc63\ud9ca\udc3c\ud8a0\udd15\ud80f\udc75\uda40\udf58\ud9b5\udf87\uf57b\uda38\udc7e\ud91b\udc47\ubc55\ud9ef\udfb4\ud818\udf37\udaf7\udc1c\ud89c\udd1f\ud951\udfe1\ud935\udec7\ud888\udef8\udb28\udfc3\ud90f\udcb8\udba4\udcb1\ud939\udc53\ud946\udf76\uda10\udd5c\uda79\uddb4\udb3e\udf99\ud9dd\udf50\u4c77\ud9e6\ude0b\ud8d9\udedc\u0f66\ud9c0\udee2\ud826\ude12",
        53, 29336, -766307227, 5174188598313838037L, -51565L, true, false, (char) 46464, (char) 21176,
        Double.longBitsToDouble(0x3fee6abc9d2fd26cL), Double.longBitsToDouble(0x3fb5a4110018d350L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u6827\u7eb6\u2df6\" \"\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\012",
        Z.run(T, 1, 1, 3, 0, "\udb65\udd70\ud842\udf2a\udb9c\udf9b", "\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u6827\u7eb6\u2df6", "\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e",
        4, 15292, -364596410, 6255606957640484235L, 45899L, false, true, (char) 46906, (char) 28471,
        Double.longBitsToDouble(0x3fed381e28de9f92L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\ud904\uddbc PUBLIC \"\ub988\u04bc\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\" \"\ud9c9\ude0c\ud981\ude66\ud95c\udd59\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\udbb5\udc4d\ud8cd\ude88\udbb7\udde0\ud8d4\udc9e\ud917\udee9\ud997\ude21\ua18a\udb38\udfb9\">\0121=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\ud904\uddbc PUBLIC \"\ub988\u04bc\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\" \"\ud9c9\ude0c\ud981\ude66\ud95c\udd59\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\udbb5\udc4d\ud8cd\ude88\udbb7\udde0\ud8d4\udc9e\ud917\udee9\ud997\ude21\ua18a\udb38\udfb9\">\012",
        Z.run(T, 2, 1, 1, 0, "\udb65\udd70\ud842\udf2a\ud904\uddbc", "\ub988\u04bc\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126", "\ud9c9\ude0c\ud981\ude66\ud95c\udd59\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\udbb5\udc4d\ud8cd\ude88\udbb7\udde0\ud8d4\udc9e\ud917\udee9\ud997\ude21\ua18a\udb38\udfb9",
        45, 68064, -1120674875, 8882184490989937985L, 53511L, false, false, (char) 7683, (char) 1801,
        Double.longBitsToDouble(0x3fd5964c60931300L), Double.longBitsToDouble(0x3fe5ed6c348b9b79L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 3, 0, "\uda92\udde7\ud82b\ude48\udb9c\udf9b\uda39\udfaf\u5a65\ud8f7\udf04", "\ubded\uad7a\u182a", "\ud955\ude13\uda7b\uddf1\udb77\udf7c\uda56\udc31\udb10\udd7a",
        56, 91583, 1815176923, 7629606347958658386L, 74164L, false, true, (char) 2240, (char) 37917,
        Double.longBitsToDouble(0x3fabd8cfc7fb67a0L), Double.longBitsToDouble(0x3fe2692b634afef7L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\u2e71\u7ee7\u86e2\u0126\u931e\u7eda\u2df6\" \"\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\012",
        Z.run(T, 1, 0, 0, 0, "\udb65\udd70\ud842\udf2a\udb9c\udf9b", "\uca2e\u0493\u3ed0\ubd85\u2e71\u7ee7\u86e2\u0126\u931e\u7eda\u2df6", "\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e",
        4, 15292, -364596410, 6255606957640484235L, 45899L, false, false, (char) 44593, (char) 28471,
        Double.longBitsToDouble(0x3fed381e28de9f92L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\ufd6c PUBLIC \"\uca2e\" \"\ud809\udca4\uda97\udf0b\ud876\udcbe\">\0121=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\ufd6c PUBLIC \"\uca2e\" \"\ud809\udca4\uda97\udf0b\ud876\udcbe\">\012",
        Z.run(T, 2, 0, 0, 0, "\udb65\udd70\ud842\udf2a\ufd6c", "\uca2e", "\ud809\udca4\uda97\udf0b\ud876\udcbe",
        -5, 64352, 670957568, 300647710720L, -100000L, false, true, (char) 63950, (char) 47367,
        Double.longBitsToDouble(0x3fc1ad863549a784L), Double.longBitsToDouble(0x3fa6e91200000f90L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \u9f13\000\000 \"\uda94\udf7c\u3cc1\uda97\udf0b\">\0121=void |a0=java.lang.StringBuilder: |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \u9f13\000\000 \"\uda94\udf7c\u3cc1\uda97\udf0b\">\012",
        Z.run(T, 2, 0, 3, 0, "\u9f13\000\000", "", "\uda94\udf7c\u3cc1\uda97\udf0b",
        12, 3330, 850824448, 2881868046744752966L, 96608L, true, false, (char) 21255, (char) 52735,
        Double.longBitsToDouble(0x3fd5269e185ba448L), Double.longBitsToDouble(0x3fed649fcb46df29L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70>\0121=void |a0=java.lang.StringBuilder: |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70>\012",
        Z.run(T, 2, 0, 3, 0, "\udb65\udd70", "", "",
        -3, 83231, -2095513383, -4045437461403270923L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e35a0e000000000L), Double.longBitsToDouble(0x3f4aad6658640000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\ud72e\u9357\u3ed0\u82e1\uce89\u739f\u8926\u0126\u931e<!DOCTYPE \udb65\udd70\ud842\udf2a\ud90b\ude52 PUBLIC \"\ud72e\u9357\u3ed0\u82e1\uce89\u739f\u8926\u0126\u931e\" \"\uda56\udc31\udb47\udef5\ud97b\udcf2\udaca\udf86\udb1a\uddba\ud971\udcca\ud862\ude9e\ud8d9\uddcf\uda37\uddbc\udb88\udeff\ud9d8\ude41\uda23\udf32\uda2d\ude70\ud9ac\udc29\udbc1\udc1d\ud831\udcf7\u0197\ud99e\udf60\udbc9\udd51\ud85a\udc81\ud8f7\udf19\uda6d\ude14\udb5c\udd10\ud9c2\udc8c\udaf8\udfbd\udbad\udd3e\udb0b\udf3b\udb9c\udd86\ud94a\ude02\ud93f\udf84\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\ud90b\ude52 PUBLIC \"\ud72e\u9357\u3ed0\u82e1\uce89\u739f\u8926\u0126\u931e\" \"\uda56\udc31\udb47\udef5\ud97b\udcf2\udaca\udf86\udb1a\uddba\ud971\udcca\ud862\ude9e\ud8d9\uddcf\uda37\uddbc\udb88\udeff\ud9d8\ude41\uda23\udf32\uda2d\ude70\ud9ac\udc29\udbc1\udc1d\ud831\udcf7\u0197\ud99e\udf60\udbc9\udd51\ud85a\udc81\ud8f7\udf19\uda6d\ude14\udb5c\udd10\ud9c2\udc8c\udaf8\udfbd\udbad\udd3e\udb0b\udf3b\udb9c\udd86\ud94a\ude02\ud93f\udf84\">\0121=void |a0=java.lang.StringBuilder:\udb65\udd70\ud842\udf2a\ud90b\ude52<!DOCTYPE \udb65\udd70\ud842\udf2a\ud90b\ude52 PUBLIC \"\ud72e\u9357\u3ed0\u82e1\uce89\u739f\u8926\u0126\u931e\" \"\uda56\udc31\udb47\udef5\ud97b\udcf2\udaca\udf86\udb1a\uddba\ud971\udcca\ud862\ude9e\ud8d9\uddcf\uda37\uddbc\udb88\udeff\ud9d8\ude41\uda23\udf32\uda2d\ude70\ud9ac\udc29\udbc1\udc1d\ud831\udcf7\u0197\ud99e\udf60\udbc9\udd51\ud85a\udc81\ud8f7\udf19\uda6d\ude14\udb5c\udd10\ud9c2\udc8c\udaf8\udfbd\udbad\udd3e\udb0b\udf3b\udb9c\udd86\ud94a\ude02\ud93f\udf84\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\ud90b\ude52 PUBLIC \"\ud72e\u9357\u3ed0\u82e1\uce89\u739f\u8926\u0126\u931e\" \"\uda56\udc31\udb47\udef5\ud97b\udcf2\udaca\udf86\udb1a\uddba\ud971\udcca\ud862\ude9e\ud8d9\uddcf\uda37\uddbc\udb88\udeff\ud9d8\ude41\uda23\udf32\uda2d\ude70\ud9ac\udc29\udbc1\udc1d\ud831\udcf7\u0197\ud99e\udf60\udbc9\udd51\ud85a\udc81\ud8f7\udf19\uda6d\ude14\udb5c\udd10\ud9c2\udc8c\udaf8\udfbd\udbad\udd3e\udb0b\udf3b\udb9c\udd86\ud94a\ude02\ud93f\udf84\">\012",
        Z.run(T, 2, 2, 2, 0, "\udb65\udd70\ud842\udf2a\ud90b\ude52", "\ud72e\u9357\u3ed0\u82e1\uce89\u739f\u8926\u0126\u931e", "\uda56\udc31\udb47\udef5\ud97b\udcf2\udaca\udf86\udb1a\uddba\ud971\udcca\ud862\ude9e\ud8d9\uddcf\uda37\uddbc\udb88\udeff\ud9d8\ude41\uda23\udf32\uda2d\ude70\ud9ac\udc29\udbc1\udc1d\ud831\udcf7\u0197\ud99e\udf60\udbc9\udd51\ud85a\udc81\ud8f7\udf19\uda6d\ude14\udb5c\udd10\ud9c2\udc8c\udaf8\udfbd\udbad\udd3e\udb0b\udf3b\udb9c\udd86\ud94a\ude02\ud93f\udf84",
        6, 50199, -1044525085, 8753104883709274850L, -47982L, true, true, (char) 52325, (char) 4189,
        Double.longBitsToDouble(0x3fbf18f6e5d65378L), Double.longBitsToDouble(0x3fad4636cc2b22f0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE PUBLIC \"\u35b4\" \"\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud955\ude13\ud80b\udf08\ud849\udd54\">\0121=new org.jsoup.nodes.DocumentType:<!DOCTYPE PUBLIC \"\u35b4\" \"\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud955\ude13\ud80b\udf08\ud849\udd54\">\012",
        Z.run(T, 2, 0, 0, 0, "", "\u35b4", "\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud955\ude13\ud80b\udf08\ud849\udd54",
        55, 85537, -1826684928, 5921220513705846491L, -90446L, true, false, (char) 38053, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f8e00011fed9e80L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \ud93d\ude5d PUBLIC \"\000\000\u217bW\u53d9\ubd85\000\000\000\">\012",
        Z.run(T, 1, 0, 0, 0, "\ud93d\ude5d", "\000\000\u217bW\u53d9\ubd85\000\000\000", "",
        -5, -1000, 7012352, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3d85800000000000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \u9f13>\012",
        Z.run(T, 1, 0, 3, 0, "\u9f13", "", "",
        41, 83231, -2095498535, -4045512253369178891L, -21037L, false, true, (char) 45924, (char) 34733,
        Double.longBitsToDouble(0x3fcf3aad60000000L), Double.longBitsToDouble(0x3fe57c98f8db522cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u35b4<!DOCTYPE PUBLIC \"\u35b4\" \"\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud93b\udc87\ud80b\udf08\uda1f\udfa0\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE PUBLIC \"\u35b4\" \"\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud93b\udc87\ud80b\udf08\uda1f\udfa0\">\0121=void |a0=java.lang.StringBuilder:<!DOCTYPE PUBLIC \"\u35b4\" \"\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud93b\udc87\ud80b\udf08\uda1f\udfa0\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE PUBLIC \"\u35b4\" \"\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud93b\udc87\ud80b\udf08\uda1f\udfa0\">\012",
        Z.run(T, 2, 2, 2, 0, "", "\u35b4", "\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud93b\udc87\ud80b\udf08\uda1f\udfa0",
        48, 85488, -1826684928, 5921220513705846491L, -90446L, true, false, (char) 38053, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f8e00011fed9e80L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE PUBLIC \"\u1d6d\" \"\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud955\ude13\ud80b\udf08\ud849\udd54\">\012",
        Z.run(T, 1, 0, 0, 0, "", "\u1d6d", "\udb9b\udf17W\000\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\udaf9\udd15\ud955\ude13\ud80b\udf08\ud849\udd54",
        55, 85537, -1826684928, 5921220513705846491L, -90446L, true, false, (char) 38053, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f8e00011fed9e80L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u4461\u2987\u2df6\" \"\ud986\udc73\udaca\udf86\ud8dd\udd3b\ud973\udf0a\ud8a7\udd0b\">\0121=void |a0=java.lang.StringBuilder:\udb65\udd70\ud842\udf2a\udb9c\udf9b |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u4461\u2987\u2df6\" \"\ud986\udc73\udaca\udf86\ud8dd\udd3b\ud973\udf0a\ud8a7\udd0b\">\012",
        Z.run(T, 2, 1, 3, 0, "\udb65\udd70\ud842\udf2a\udb9c\udf9b", "\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u4461\u2987\u2df6", "\ud986\udc73\udaca\udf86\ud8dd\udd3b\ud973\udf0a\ud8a7\udd0b",
        7, 15292, -364596410, 6255606957640484235L, -19637L, false, true, (char) 46906, (char) 56022,
        Double.longBitsToDouble(0x3fed381e28de9f92L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE \u9f13\000\000 \"\uda94\udf7c\u3cc1\uda97\udf0b\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \u9f13\000\000 \"\uda94\udf7c\u3cc1\uda97\udf0b\">\0121=void |a0=java.lang.StringBuilder:\u9f13\000\000<!DOCTYPE \u9f13\000\000 \"\uda94\udf7c\u3cc1\uda97\udf0b\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \u9f13\000\000 \"\uda94\udf7c\u3cc1\uda97\udf0b\">\012",
        Z.run(T, 2, 2, 2, 0, "\u9f13\000\000", "", "\uda94\udf7c\u3cc1\uda97\udf0b",
        12, 3330, 850824448, 6774385499676414923L, 21524L, true, false, (char) 26513, (char) 63950,
        Double.longBitsToDouble(0x3fe6da9166dcd701L), Double.longBitsToDouble(0x3fe012f69c2dd224L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE>\012",
        Z.run(T, 1, 0, 3, 0, "", "", "",
        -5, -1000, 2027558231, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f23ff0000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE \udb65\udd70> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70>\0121=void |a0=java.lang.StringBuilder:\udb65\udd70<!DOCTYPE \udb65\udd70> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70>\012",
        Z.run(T, 2, 2, 2, 1, "\udb65\udd70", "", "",
        -3, 83231, -2095513383, 2337585278558016111L, -100000L, false, false, (char) 0, (char) 5812,
        Double.longBitsToDouble(0x3fd4dac4732c321cL), Double.longBitsToDouble(0x3fd3ee74888ada50L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\0121=void |a0=java.lang.StringBuilder:\ud81c\udeec<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\012",
        Z.run(T, 2, 1, 2, 3, "\ud81c\udeec", " ", "\ud8c7\udc76",
        17, 23192, -2013265675, 1526609735937151514L, -100000L, true, true, (char) 59507, (char) 34484,
        Double.longBitsToDouble(0x3f4aad6658640000L), Double.longBitsToDouble(0x3fe0e3ca2ae7ef78L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\012",
        Z.run(T, 1, 1, 2, 0, "\ud81c\udeec", " ", "\ud8c7\udc76",
        17, 46192, -2013265803, 1526609734438552396L, -99943L, true, true, (char) 59507, (char) 40627,
        Double.longBitsToDouble(0x3f4ab75258640000L), Double.longBitsToDouble(0x3fe0e3ca2ae7ef78L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder: <!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\0121=void |a0=java.lang.StringBuilder:\ud81c\udeec<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\012",
        Z.run(T, 2, 2, 2, 3, "\ud81c\udeec", " ", "\ud8c7\udc76",
        17, 23192, -2013265675, 1526609735937151514L, -100000L, true, true, (char) 59507, (char) 6836,
        Double.longBitsToDouble(0x3f4aad6658640000L), Double.longBitsToDouble(0x3fe0e3ca2ee7ef78L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder: \000<!DOCTYPE \ud81c\udeec PUBLIC \" \000\" \"\uda86\udd2c\u3cc1\udb43\udf55\uda7c\udfac\ud8d6\udc89\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec PUBLIC \" \000\" \"\uda86\udd2c\u3cc1\udb43\udf55\uda7c\udfac\ud8d6\udc89\">\0121=void |a0=java.lang.StringBuilder:\ud81c\udeec<!DOCTYPE \ud81c\udeec PUBLIC \" \000\" \"\uda86\udd2c\u3cc1\udb43\udf55\uda7c\udfac\ud8d6\udc89\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec PUBLIC \" \000\" \"\uda86\udd2c\u3cc1\udb43\udf55\uda7c\udfac\ud8d6\udc89\">\012",
        Z.run(T, 2, 2, 2, 3, "\ud81c\udeec", " \000", "\uda86\udd2c\u3cc1\udb43\udf55\uda7c\udfac\ud8d6\udc89",
        27, 81253, -1590359020, 7930451438250715700L, -24967L, true, true, (char) 56385, (char) 40714,
        Double.longBitsToDouble(0x3fdf8fea0199beceL), Double.longBitsToDouble(0x3fe63182a02a1578L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud9a0\udf50\ud93d\udcc7\uda33\uddab\uda46\ude4b\u5a65\udb9b\udf17\ud8c9\ude76\uda94\udf7c\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\ud820\udc08\ud955\ude13\ud80b\udf08\ud849\udd54\udb49\uddca\udb10\udd11\ud9a8\udf2b\udaca\udf86\udb65\udd3f\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb78\udc7d\uda1a\udda8\udafc\udcc6\ud800\udf79\udb38\udfb9\uda47\udeb3\ud901\udf4c\ue579\ud94a\ude44\udb54\udc05\udb86\udc6d\ud8b8\uddf8\ud8e7\udffd\udbb9\udcdd\udb7f\udf44\udb55\udeed\udb25\ude26\ud8b7\uddf7\ud947\udfcf\ud8d5\udc4a\ud961\uddf4\udabc\udd86 PUBLIC \"\u6759\u5889\ube5f\u9a71\ud60d\u288b\u5f13\u9c00\u41d9\u33b6\u6fac\" \"\ud9a1\ude52\ud9f5\udd60\ud9e0\udfed\udada\ude9e\udafe\ude58\uda8a\udc24\ud886\udce8\udaeb\udcf4\udb1e\udfe0\uda8d\udf43\uda38\udd23\udb75\udfb0\ud86a\udcc1\uda00\ude73\udab9\udf4c\udb36\udc3d\ud9ae\udd55\ud84b\udd51\udb11\udeb9\udb2a\udc12\ud86d\ude30\uda19\udffc\ud80a\udf16\ud901\udfd5\ud96b\udead\ud822\udfe7\ud945\ude35\uda26\uddb4\ud812\ude91\ud8ff\udee6\udaaf\udd87\udbcd\udda0\ud8b8\udc54\ud85a\udf1b\udbba\udcdd\ud965\udc43\uda1e\udf41\ud802\ude10\ud896\udfe0\udaa4\udd87\ud8f3\ude06\ufb57\uda77\ude0d\udb40\udd3d\udae5\udf51\udbfb\udd6e\ud966\udf71\ud9d8\udf9b\ucb5f\udb2d\udfe7\ud90d\uddc3\">\0121=void |a0=java.lang.StringBuilder:\ud9a0\udf50\ud93d\udcc7\uda33\uddab\uda46\ude4b\u5a65\udb9b\udf17\ud8c9\ude76\uda94\udf7c\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\ud820\udc08\ud955\ude13\ud80b\udf08\ud849\udd54\udb49\uddca\udb10\udd11\ud9a8\udf2b\udaca\udf86\udb65\udd3f\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb78\udc7d\uda1a\udda8\udafc\udcc6\ud800\udf79\udb38\udfb9\uda47\udeb3\ud901\udf4c\ue579\ud94a\ude44\udb54\udc05\udb86\udc6d\ud8b8\uddf8\ud8e7\udffd\udbb9\udcdd\udb7f\udf44\udb55\udeed\udb25\ude26\ud8b7\uddf7\ud947\udfcf\ud8d5\udc4a\ud961\uddf4\udabc\udd86<!DOCTYPE \ud9a0\udf50\ud93d\udcc7\uda33\uddab\uda46\ude4b\u5a65\udb9b\udf17\ud8c9\ude76\uda94\udf7c\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\ud820\udc08\ud955\ude13\ud80b\udf08\ud849\udd54\udb49\uddca\udb10\udd11\ud9a8\udf2b\udaca\udf86\udb65\udd3f\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb78\udc7d\uda1a\udda8\udafc\udcc6\ud800\udf79\udb38\udfb9\uda47\udeb3\ud901\udf4c\ue579\ud94a\ude44\udb54\udc05\udb86\udc6d\ud8b8\uddf8\ud8e7\udffd\udbb9\udcdd\udb7f\udf44\udb55\udeed\udb25\ude26\ud8b7\uddf7\ud947\udfcf\ud8d5\udc4a\ud961\uddf4\udabc\udd86 PUBLIC \"\u6759\u5889\ube5f\u9a71\ud60d\u288b\u5f13\u9c00\u41d9\u33b6\u6fac\" \"\ud9a1\ude52\ud9f5\udd60\ud9e0\udfed\udada\ude9e\udafe\ude58\uda8a\udc24\ud886\udce8\udaeb\udcf4\udb1e\udfe0\uda8d\udf43\uda38\udd23\udb75\udfb0\ud86a\udcc1\uda00\ude73\udab9\udf4c\udb36\udc3d\ud9ae\udd55\ud84b\udd51\udb11\udeb9\udb2a\udc12\ud86d\ude30\uda19\udffc\ud80a\udf16\ud901\udfd5\ud96b\udead\ud822\udfe7\ud945\ude35\uda26\uddb4\ud812\ude91\ud8ff\udee6\udaaf\udd87\udbcd\udda0\ud8b8\udc54\ud85a\udf1b\udbba\udcdd\ud965\udc43\uda1e\udf41\ud802\ude10\ud896\udfe0\udaa4\udd87\ud8f3\ude06\ufb57\uda77\ude0d\udb40\udd3d\udae5\udf51... |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud9a0\udf50\ud93d\udcc7\uda33\uddab\uda46\ude4b\u5a65\udb9b\udf17\ud8c9\ude76\uda94\udf7c\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\ud820\udc08\ud955\ude13\ud80b\udf08\ud849\udd54\udb49\uddca\udb10\udd11\ud9a8\udf2b\udaca\udf86\udb65\udd3f\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb78\udc7d\uda1a\udda8\udafc\udcc6\ud800\udf79\udb38\udfb9\uda47\udeb3\ud901\udf4c\ue579\ud94a\ude44\udb54\udc05\udb86\udc6d\ud8b8\uddf8\ud8e7\udffd\udbb9\udcdd\udb7f\udf44\udb55\udeed\udb25\ude26\ud8b7\uddf7\ud947\udfcf\ud8d5\udc4a\ud961\uddf4\udabc\udd86 PUBLIC \"\u6759\u5889\ube5f\u9a71\ud60d\u288b\u5f13\u9c00\u41d9\u33b6\u6fac\" \"\ud9a1\ude52\ud9f5\udd60\ud9e0\udfed\udada\ude9e\udafe\ude58\uda8a\udc24\ud886\udce8\udaeb\udcf4\udb1e\udfe0\uda8d\udf43\uda38\udd23\udb75\udfb0\ud86a\udcc1\uda00\ude73\udab9\udf4c\udb36\udc3d\ud9ae\udd55\ud84b\udd51\udb11\udeb9\udb2a\udc12\ud86d\ude30\uda19\udffc\ud80a\udf16\ud901\udfd5\ud96b\udead\ud822\udfe7\ud945\ude35\uda26\uddb4\ud812\ude91\ud8ff\udee6\udaaf\udd87\udbcd\udda0\ud8b8\udc54\ud85a\udf1b\udbba\udcdd\ud965\udc43\uda1e\udf41\ud802\ude10\ud896\udfe0\udaa4\udd87\ud8f3\ude06\ufb57\uda77\ude0d\udb40\udd3d\udae5\udf51\udbfb\udd6e\ud966\udf71\ud9d8\udf9b\ucb5f\udb2d\udfe7\ud90d\uddc3\">\012",
        Z.run(T, 2, 1, 2, 0, "\ud9a0\udf50\ud93d\udcc7\uda33\uddab\uda46\ude4b\u5a65\udb9b\udf17\ud8c9\ude76\uda94\udf7c\u3cc1\uda97\udf0b\ud8dd\udf72\udaa7\udd3b\ud820\udc08\ud955\ude13\ud80b\udf08\ud849\udd54\udb49\uddca\udb10\udd11\ud9a8\udf2b\udaca\udf86\udb65\udd3f\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb78\udc7d\uda1a\udda8\udafc\udcc6\ud800\udf79\udb38\udfb9\uda47\udeb3\ud901\udf4c\ue579\ud94a\ude44\udb54\udc05\udb86\udc6d\ud8b8\uddf8\ud8e7\udffd\udbb9\udcdd\udb7f\udf44\udb55\udeed\udb25\ude26\ud8b7\uddf7\ud947\udfcf\ud8d5\udc4a\ud961\uddf4\udabc\udd86", "\u6759\u5889\ube5f\u9a71\ud60d\u288b\u5f13\u9c00\u41d9\u33b6\u6fac", "\ud9a1\ude52\ud9f5\udd60\ud9e0\udfed\udada\ude9e\udafe\ude58\uda8a\udc24\ud886\udce8\udaeb\udcf4\udb1e\udfe0\uda8d\udf43\uda38\udd23\udb75\udfb0\ud86a\udcc1\uda00\ude73\udab9\udf4c\udb36\udc3d\ud9ae\udd55\ud84b\udd51\udb11\udeb9\udb2a\udc12\ud86d\ude30\uda19\udffc\ud80a\udf16\ud901\udfd5\ud96b\udead\ud822\udfe7\ud945\ude35\uda26\uddb4\ud812\ude91\ud8ff\udee6\udaaf\udd87\udbcd\udda0\ud8b8\udc54\ud85a\udf1b\udbba\udcdd\ud965\udc43\uda1e\udf41\ud802\ude10\ud896\udfe0\udaa4\udd87\ud8f3\ude06\ufb57\uda77\ude0d\udb40\udd3d\udae5\udf51\udbfb\udd6e\ud966\udf71\ud9d8\udf9b\ucb5f\udb2d\udfe7\ud90d\uddc3",
        24, 4583, 646130928, -5008382879963077595L, -9209L, false, true, (char) 37496, (char) 27475,
        Double.longBitsToDouble(0x3fefac5ecd1c7631L), Double.longBitsToDouble(0x3fc3eaf3988a5358L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\0121=void |a0=java.lang.StringBuilder:\ud81c\udeec<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\012",
        Z.run(T, 2, 1, 2, 3, "\ud81c\udeec", "\015", "\ud8c7\udc76",
        17, 23192, -2013265675, 1526609735937151514L, -100000L, true, true, (char) 59507, (char) 34484,
        Double.longBitsToDouble(0x3f4aad665865c000L), Double.longBitsToDouble(0x3fe0e3ca2ae7ef78L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udcc0\">\012",
        Z.run(T, 1, 1, 0, 3, "\ud81c\udeec", "\015", "\ud8c7\udcc0",
        47, 23192, 1127665653, -1183140254268363470L, -86650L, true, false, (char) 2621, (char) 34484,
        Double.longBitsToDouble(0x3fd00466b1b3f97cL), Double.longBitsToDouble(0x3fe0e3cfeae7ef78L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\015\000\ua599\ua43c\u034d\ub45a\u80dc\u5493\u932a\u641f\ud3d5\ud7d7\u44f2\u8b4f\u2e26\uc151\ua9ff\u4315\u3e0b\u2b82\u101d\ub67d\u87f4\ucb08\ud46e\u3d20<!DOCTYPE \udad0\uddee PUBLIC \"\015\000\ua599\ua43c\u034d\ub45a\u80dc\u5493\u932a\u641f\ud3d5\ud7d7\u44f2\u8b4f\u2e26\uc151\ua9ff\u4315\u3e0b\u2b82\u101d\ub67d\u87f4\ucb08\ud46e\u3d20\" \"\udac3\udfe1\udaf3\udd5f\ud8ba\ude36\udb91\udc6c\uda4b\udf5a\ud946\udd8c\ud9a8\udcd4\ud910\udd45\udb33\udec6\udade\udf41\ud952\udc21\udb1f\udf52\udaf6\udcea\ud92f\udebf\udbdf\uddba\ud932\udf8e\udbee\udc0f\u4d2b\ud8ab\udc0c\ud95d\udd69\ud844\ude8e\uda2b\udceb\udb9a\udc73\ud9fe\ude6d\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udad0\uddee PUBLIC \"\015\000\ua599\ua43c\u034d\ub45a\u80dc\u5493\u932a\u641f\ud3d5\ud7d7\u44f2\u8b4f\u2e26\uc151\ua9ff\u4315\u3e0b\u2b82\u101d\ub67d\u87f4\ucb08\ud46e\u3d20\" \"\udac3\udfe1\udaf3\udd5f\ud8ba\ude36\udb91\udc6c\uda4b\udf5a\ud946\udd8c\ud9a8\udcd4\ud910\udd45\udb33\udec6\udade\udf41\ud952\udc21\udb1f\udf52\udaf6\udcea\ud92f\udebf\udbdf\uddba\ud932\udf8e\udbee\udc0f\u4d2b\ud8ab\udc0c\ud95d\udd69\ud844\ude8e\uda2b\udceb\udb9a\udc73\ud9fe\ude6d\">\0121=void |a0=java.lang.StringBuilder:\udad0\uddee<!DOCTYPE \udad0\uddee PUBLIC \"\015\000\ua599\ua43c\u034d\ub45a\u80dc\u5493\u932a\u641f\ud3d5\ud7d7\u44f2\u8b4f\u2e26\uc151\ua9ff\u4315\u3e0b\u2b82\u101d\ub67d\u87f4\ucb08\ud46e\u3d20\" \"\udac3\udfe1\udaf3\udd5f\ud8ba\ude36\udb91\udc6c\uda4b\udf5a\ud946\udd8c\ud9a8\udcd4\ud910\udd45\udb33\udec6\udade\udf41\ud952\udc21\udb1f\udf52\udaf6\udcea\ud92f\udebf\udbdf\uddba\ud932\udf8e\udbee\udc0f\u4d2b\ud8ab\udc0c\ud95d\udd69\ud844\ude8e\uda2b\udceb\udb9a\udc73\ud9fe\ude6d\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udad0\uddee PUBLIC \"\015\000\ua599\ua43c\u034d\ub45a\u80dc\u5493\u932a\u641f\ud3d5\ud7d7\u44f2\u8b4f\u2e26\uc151\ua9ff\u4315\u3e0b\u2b82\u101d\ub67d\u87f4\ucb08\ud46e\u3d20\" \"\udac3\udfe1\udaf3\udd5f\ud8ba\ude36\udb91\udc6c\uda4b\udf5a\ud946\udd8c\ud9a8\udcd4\ud910\udd45\udb33\udec6\udade\udf41\ud952\udc21\udb1f\udf52\udaf6\udcea\ud92f\udebf\udbdf\uddba\ud932\udf8e\udbee\udc0f\u4d2b\ud8ab\udc0c\ud95d\udd69\ud844\ude8e\uda2b\udceb\udb9a\udc73\ud9fe\ude6d\">\012",
        Z.run(T, 2, 2, 2, 3, "\udad0\uddee", "\015\000\ua599\ua43c\u034d\ub45a\u80dc\u5493\u932a\u641f\ud3d5\ud7d7\u44f2\u8b4f\u2e26\uc151\ua9ff\u4315\u3e0b\u2b82\u101d\ub67d\u87f4\ucb08\ud46e\u3d20", "\udac3\udfe1\udaf3\udd5f\ud8ba\ude36\udb91\udc6c\uda4b\udf5a\ud946\udd8c\ud9a8\udcd4\ud910\udd45\udb33\udec6\udade\udf41\ud952\udc21\udb1f\udf52\udaf6\udcea\ud92f\udebf\udbdf\uddba\ud932\udf8e\udbee\udc0f\u4d2b\ud8ab\udc0c\ud95d\udd69\ud844\ude8e\uda2b\udceb\udb9a\udc73\ud9fe\ude6d",
        34, 78711, 1569857270, 7349632684597126029L, 49324L, false, false, (char) 37911, (char) 64452,
        Double.longBitsToDouble(0x3fee7a91f22ba144L), Double.longBitsToDouble(0x3fd65e08fe34fe84L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\ua43d\" \"\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\0121=void |a0=java.lang.StringBuilder:\udb65\udd70\ud842\udf2a\udb9c\udf9b |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\ud842\udf2a\udb9c\udf9b PUBLIC \"\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\ua43d\" \"\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\012",
        Z.run(T, 2, 1, 3, 0, "\udb65\udd70\ud842\udf2a\udb9c\udf9b", "\uca2e\u0493\u3ed0\ubd85\ucef5\u7ee7\u86e2\u0126\u931e\u7eda\ua43d", "\ud9a8\udf2b\udaca\udf86\ud8dd\udd3b\ud971\udcca\ud862\ude9e",
        4, 15292, -364596410, 6255606957640484235L, 45899L, false, true, (char) 46906, (char) 28471,
        Double.longBitsToDouble(0x3fed381e28de9f92L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\0121=void |a0=java.lang.StringBuilder:\ud81c\udeec<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\012",
        Z.run(T, 2, 1, 2, 2, "\ud81c\udeec", "\011", "\ud8c7\udc76",
        17, 23192, -2013265675, 1526609735937151514L, -100000L, true, true, (char) 59507, (char) 34484,
        Double.longBitsToDouble(0x3f4aad6658640000L), Double.longBitsToDouble(0x3fe0e3ca2ae7ef78L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\011<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\uda86\udd2c\u3cc1\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\uda86\udd2c\u3cc1\">\0121=void |a0=java.lang.StringBuilder:\ud81c\udeec<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\uda86\udd2c\u3cc1\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\uda86\udd2c\u3cc1\">\012",
        Z.run(T, 2, 2, 2, 2, "\ud81c\udeec", "\011", "\ud8c7\udc76\uda86\udd2c\u3cc1",
        30, 47624, 1340878230, -7402326359961237564L, -100000L, false, false, (char) 2083, (char) 11093,
        Double.longBitsToDouble(0x3fec4b8a32e7ef78L), Double.longBitsToDouble(0x3fe0281af27b66a4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud81c\udeec \"\ud8c7\udc76\">\012",
        Z.run(T, 1, 1, 2, 2, "\ud81c\udeec", "\011", "\ud8c7\udc76",
        17, 23192, -2013265675, 1526609735937151514L, -100000L, true, true, (char) 59507, (char) 34484,
        Double.longBitsToDouble(0x3f4aad6658640000L), Double.longBitsToDouble(0x3fe0e3ca2ae7ef78L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 3, 0, "\udb65\udd70\ud842\udf2a\udb9c\udf9b\uda39\udfaf\u5a65\udb9b\udf17\ud8c7\udc76\uda94\udf7c\u3cc1\uda97\udf0b\ud8b6\udd72", "\u931e\u7eda\u2df6\u7e45\u6f37", "\ud90d\ude74\ud971\udcf4\ud939\udc48\ud806\udf9a\ud900\udf90\ud849\udecd\udad5\ude7f\ud800\udf79\udb29\uddb9\uda47\udeb3\udbc1\udc1d\ud801\udd5c\ud94a\ude44\ud97c\ude79\udb98\udd0a",
        38, 60878, -486044013, -5934335265218974260L, -43636L, true, false, (char) 52225, (char) 6884,
        Double.longBitsToDouble(0x3fd38fa9d07ab7e0L), Double.longBitsToDouble(0x3fea9170457937dcL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\014\u2b0e\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u01e0\u39a3\u32eb<!DOCTYPE \udb65\udd70\udb7a\udc46\udba7\udcab PUBLIC \"\014\u2b0e\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u01e0\u39a3\u32eb\" \"\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udb7a\udc46\udba7\udcab PUBLIC \"\014\u2b0e\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u01e0\u39a3\u32eb\" \"\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\0121=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udb7a\udc46\udba7\udcab PUBLIC \"\014\u2b0e\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u01e0\u39a3\u32eb\" \"\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\">\012",
        Z.run(T, 2, 2, 0, 0, "\udb65\udd70\udb7a\udc46\udba7\udcab", "\014\u2b0e\u3ed0\ubd85\ucef5\u8834\u4f96\u20aa\u01e0\u39a3\u32eb", "\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e",
        4, 3908, -364596410, 6255606957640484235L, -55210L, false, true, (char) 46906, (char) 28471,
        Double.longBitsToDouble(0x3fedc1ae28de9f00L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udb7a\udc46\udba7\udcab PUBLIC \"\014\u2b0e\u3ed0\u7669\uce49\u8834\u9cb0\u7438\" \"\udafc\udd59\uda56\udc31\udb10\udd7a\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\">\012",
        Z.run(T, 1, 1, 1, 2, "\udb65\udd70\udb7a\udc46\udba7\udcab", "\014\u2b0e\u3ed0\u7669\uce49\u8834\u9cb0\u7438", "\udafc\udd59\uda56\udc31\udb10\udd7a\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf",
        13, 12590, 1456497012, 7250660757341018127L, 7008L, false, true, (char) 54631, (char) 46906,
        Double.longBitsToDouble(0x3faa8f812b835e10L), Double.longBitsToDouble(0x3fee2bf12693f1a3L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\014\u2b0e\u3ed0\u79bb\ucef5\u8834\u4097\u5eea\u7bcf\u39a3\u32eb<!DOCTYPE \udb65\udd70\udbd2\udcf1\udbdf\ude3a PUBLIC \"\014\u2b0e\u3ed0\u79bb\ucef5\u8834\u4097\u5eea\u7bcf\u39a3\u32eb\" \"\ud87c\udc05\udacb\udcba\ud9de\ude02\ud971\udc7b\ud862\ude9e\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udbd2\udcf1\udbdf\ude3a PUBLIC \"\014\u2b0e\u3ed0\u79bb\ucef5\u8834\u4097\u5eea\u7bcf\u39a3\u32eb\" \"\ud87c\udc05\udacb\udcba\ud9de\ude02\ud971\udc7b\ud862\ude9e\">\0121=void |a0=java.lang.StringBuilder:\udb65\udd70\udbd2\udcf1\udbdf\ude3a<!DOCTYPE \udb65\udd70\udbd2\udcf1\udbdf\ude3a PUBLIC \"\014\u2b0e\u3ed0\u79bb\ucef5\u8834\u4097\u5eea\u7bcf\u39a3\u32eb\" \"\ud87c\udc05\udacb\udcba\ud9de\ude02\ud971\udc7b\ud862\ude9e\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udbd2\udcf1\udbdf\ude3a PUBLIC \"\014\u2b0e\u3ed0\u79bb\ucef5\u8834\u4097\u5eea\u7bcf\u39a3\u32eb\" \"\ud87c\udc05\udacb\udcba\ud9de\ude02\ud971\udc7b\ud862\ude9e\">\012",
        Z.run(T, 2, 2, 2, 1, "\udb65\udd70\udbd2\udcf1\udbdf\ude3a", "\014\u2b0e\u3ed0\u79bb\ucef5\u8834\u4097\u5eea\u7bcf\u39a3\u32eb", "\ud87c\udc05\udacb\udcba\ud9de\ude02\ud971\udc7b\ud862\ude9e",
        4, 3908, -364596410, 6255606957640484235L, -55210L, false, true, (char) 46906, (char) 28471,
        Double.longBitsToDouble(0x3fedc1ae28de9f00L), Double.longBitsToDouble(0x3fe49f88d185e307L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\012\u2b0e\u3ed0\ubd85<!DOCTYPE \udb65\udd70\udb7a\udc46\ud9fc\udcd5 PUBLIC \"\012\u2b0e\u3ed0\ubd85\" \"\ud986\udfce\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udb7a\udc46\ud9fc\udcd5 PUBLIC \"\012\u2b0e\u3ed0\ubd85\" \"\ud986\udfce\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb\">\0121=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udb65\udd70\udb7a\udc46\ud9fc\udcd5 PUBLIC \"\012\u2b0e\u3ed0\ubd85\" \"\ud986\udfce\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb\">\012",
        Z.run(T, 2, 2, 0, 0, "\udb65\udd70\udb7a\udc46\ud9fc\udcd5", "\012\u2b0e\u3ed0\ubd85", "\ud986\udfce\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\ud87c\udc05\udacb\udcba\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb",
        3, 68185, 151642556, 2234539895802908725L, -10110L, true, false, (char) 58508, (char) 38422,
        Double.longBitsToDouble(0x3fcf02213a801c70L), Double.longBitsToDouble(0x3fe0c64dcb44134cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\012\u2b0e\u3ed0\ubd85<!DOCTYPE \udabd\udeae\udb7a\udc46\ud9fc\udcd5 PUBLIC \"\012\u2b0e\u3ed0\ubd85\" \"\ud976\udce7\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\udbaf\udf96\udacb\udc82\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udabd\udeae\udb7a\udc46\ud9fc\udcd5 PUBLIC \"\012\u2b0e\u3ed0\ubd85\" \"\ud976\udce7\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\udbaf\udf96\udacb\udc82\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb\">\0121=void |a0=java.lang.StringBuilder:\udabd\udeae\udb7a\udc46\ud9fc\udcd5<!DOCTYPE \udabd\udeae\udb7a\udc46\ud9fc\udcd5 PUBLIC \"\012\u2b0e\u3ed0\ubd85\" \"\ud976\udce7\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\udbaf\udf96\udacb\udc82\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \udabd\udeae\udb7a\udc46\ud9fc\udcd5 PUBLIC \"\012\u2b0e\u3ed0\ubd85\" \"\ud976\udce7\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\udbaf\udf96\udacb\udc82\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb\">\012",
        Z.run(T, 2, 2, 2, 0, "\udabd\udeae\udb7a\udc46\ud9fc\udcd5", "\012\u2b0e\u3ed0\ubd85", "\ud976\udce7\udab5\udfb2\udb39\udc82\ud8ae\udf7e\udae6\udda2\uda56\udc31\udb10\udd7a\udbaf\udf96\udacb\udc82\ud8dd\udd3b\ud971\udcca\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\udad5\ude7f\ud800\udf79\udb38\udfb9\udaf0\udeeb",
        3, 68185, 151642556, 2234539895802908725L, -10110L, true, false, (char) 58508, (char) 38422,
        Double.longBitsToDouble(0x3fcf02212ea81c70L), Double.longBitsToDouble(0x3fd76914a8933528L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \udabd\udeae\udb7a\udc46\ud9fc\udcd5 PUBLIC \"\012\u2b0e\uc138\u776f\" \"\ud939\udea7\udab5\udfb2\udac2\udd5b\ud9c2\udf27\ud808\ude46\uda56\udc43\udb10\udd7a\udbaf\udf96\udacb\udc82\ud83e\udd0c\ud971\udd25\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\uda91\udc3e\ud91e\udee7\udade\ude56\udaf0\udeeb\">\012",
        Z.run(T, 1, 0, 0, 0, "\udabd\udeae\udb7a\udc46\ud9fc\udcd5", "\012\u2b0e\uc138\u776f", "\ud939\udea7\udab5\udfb2\udac2\udd5b\ud9c2\udf27\ud808\ude46\uda56\udc43\udb10\udd7a\udbaf\udf96\udacb\udc82\ud83e\udd0c\ud971\udd25\ud862\ude9e\ud8d9\uddcf\udb47\udf44\ud85e\uddfe\uda91\udc3e\ud91e\udee7\udade\ude56\udaf0\udeeb",
        3, 68185, 151642556, 129883323275462897L, -10110L, true, false, (char) 58508, (char) 38248,
        Double.longBitsToDouble(0x3fcf02212ea81c70L), Double.longBitsToDouble(0x3fd76914a8933528L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.jsoup.nodes.DocumentType|<init>|java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.DocumentType|nodeName||new:org.jsoup.nodes.DocumentType:java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.DocumentType|outerHtmlHead|java.lang.StringBuilder,int,org.jsoup.nodes.Document$OutputSettings|new:org.jsoup.nodes.DocumentType:java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.DocumentType|outerHtmlTail|java.lang.StringBuilder,int,org.jsoup.nodes.Document$OutputSettings|new:org.jsoup.nodes.DocumentType:java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "C|org.jsoup.nodes.DocumentType|<init>|java.lang.String,java.lang.String,java.lang.String,java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
