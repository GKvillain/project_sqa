package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class Token_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 17, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41", "\u53bd\u31b1\u7c20\u3ece\u08e3\ub4eb\u555c\u8d6d\u68aa\u5fdc\u15d6\u4dd7\u110d\u2194\u6108\u1d13\ua653\uad72", "\ud99e\udf50\ud903\udc82\ud8ba\udf50\ud943\udef0",
        20, 57877, 2051466450, -5306085279564773372L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 17, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41", "\u53bd\u31b1\u7c20\u3ece\ua9c5\ub4eb\u555c\u8d6d\u68aa\u5fdc\u15d6\ua6a4\u110d\u2194\u6108\u1d13\ua653\uad72", "\ud99e\udf50\ud903\udc82\ud8ba\udf50\ud943\udef0",
        20, 57877, 2051466450, -5306085279564773372L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\ud9ce\udd9e\ud813\udd50\udbf8\udf1e\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41\udb97\udec2\u67dc\uda3f\udc60\udb16\udd00\udaf4\udd5f\udaa0\ude46\ud8e7\udea2\ud90f\udc56\ud81d\ude67\udbd9\udc78\uda28\uddff\ud97c\udc9f\udadc\ude5b\udb2f\udcc2\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 7, 17, "\ud8e0\udc72\ud9ce\udd9e\ud813\udd50\udbf8\udf1e\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41\udb97\udec2\u67dc\uda3f\udc60\udb16\udd00\udaf4\udd5f\udaa0\ude46\ud8e7\udea2\ud90f\udc56\ud81d\ude67\udbd9\udc78\uda28\uddff\ud97c\udc9f\udadc\ude5b\udb2f\udcc2", "\u6108\u1d13\ua653", "\udb58\uddc5\ud99e\udf50\ud903\udc82\ud8ba\udf50\ud943\udef0",
        20, 57877, 2051466450, -5306085279564773372L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 13, 16, "\ud8e0\udc72\udb55\udc00", "\u1a00\u9a55\u7a5f\ubcef\ucf93\uc2a4\u360e\u89c3\uabaf", "\ud90f\udc56",
        22, 86745, 1767697354, 5069571564782064880L, 68288L, false, false, (char) 19927, (char) 26276,
        Double.longBitsToDouble(0x3fe77adba8d76b7cL), Double.longBitsToDouble(0x3fdc7c723f567a94L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 7, 17, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41", "\u53bd\u31b1\u7c20\u3ece\u08e3\ub4eb\u555c\u8d6d\u68aa\ua248\u158c\u4dd7\u110d\u2194\u6108\u1d13\ua653\uad72", "\ud99e\udf50\ud903\udc82\ud8ba\udf50\ud943\udef0",
        20, 57877, -453809559, -5306112591261808636L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8df\udfe4\012",
        Z.run(T, 1, 12, 7, 17, "\ud8df\udfe4", "\uc19f\u055a", "\ud9c6\udc41",
        19, 87523, 824691067, -4562369916237702103L, 1088L, true, false, (char) 62396, (char) 9686,
        Double.longBitsToDouble(0x3fce08cb5df9e904L), Double.longBitsToDouble(0x3fd60565a84119f4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41 |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41\012",
        Z.run(T, 1, 5, 7, 17, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41", "\u53bd\u31b1\u7c20\u246f\u3730\ub4eb\u555c\u8d6d\u68aa\u63dd\u151b\u4dd7\u110d\u2194\u6108\u1d13\ua653\uad72", "\ud99e\udf50\ud903\udc82\ud8ba\udf50\ud943\udef0",
        20, 57877, 2051466450, -5306085279564773372L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!H:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 16, 17, "\ud912\udf52\ud8a4\udc11\ud89d\udf79\uda07\ude6a", "\u9607\ud0e2\ucff4\uc9c0\u53bd\u31b1\u7c20\u3ece\u08e3\u2fdc\u555c\uc039\u822f\ua4db\u15d6\u4dd7\u110d\u7270\u86ac\u1a49\ub3de\u3f93", "\ud99e\udf50\ud903\udc82\ud8ba\udf50\ud943\udef0\ud813\udfe9\udaaf\udf40\udae5\udc06\ud812\udf36\udb82\udd2b\u7fc4\udbe6\udc5a\uda10\udf07\ud9a5\udd5c\ud941\udf50\u733c\uda73\udfe8\udaac\udd9c\uda50\udec9\ud8d1\udd57\ud942\udf30\uda71\udfd7\udacd\udf7c\ud9b8\udd25\ud129\ud857\udf64\ud8ad\udd10\ud85b\udc2b\uda9e\udc4a\udad9\udd0c\ud953\udc64\ud9cd\ude77\ud924\uddb0\udae7\uddd8\uda6f\ude35\uda33\udcde",
        4, 39382, 1654130212, -2983153400983444964L, 51410L, false, true, (char) 38913, (char) 18926,
        Double.longBitsToDouble(0x3fd73180b3a18a76L), Double.longBitsToDouble(0x3fc6c69e1aebd9dcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud83b\ude7d\012",
        Z.run(T, 1, 11, 7, 17, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud83b\ude7d", "\u53bd\u31b1\u7c20\u3ece\u08e3\u3003\u1b99\u0d4c\u68aa\u5fdc\u15d6\u4dd7\u110d\u223c\u6108\u1d13\u6d8d\ua4b6", "\ud99e\udf50\ud903\udc90\ud9dc\udea2\ud943\udef0",
        20, 57877, -177560622, 4133459487857795659L, -87659L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\udbd4\udc82\uda62\udde9\ud8b8\ude6b\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41\012",
        Z.run(T, 1, 14, 12, 17, "\udbd4\udc82\uda62\udde9\ud8b8\ude6b\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41", "\u01aa\u7fc3\ubff3\u3ece\u08e3\ud7a2\u7058\u8d6d\u68aa\u5fdc\u15d6\u4dd7\u110d\u2194\u6108\u1d13\ua653\uad72", "\udbaa\udef3\ud903\ude2f\ud8ba\udf50\ud943\udef0",
        20, 57877, 2051466450, 6655475331576464384L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fca831fcfc87b50L), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 19, 9, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41", "\ua9a4\u31b1\u7c20\u3ece\u08e3\ub4eb\u555c\u8d6d\u68aa\u5fdc\u92ae\u82a4\u6091\u05ba\ub485\ua28c\u86b4\uad72", "\ud99e\udf50\ud903\udc82\ud8ba\udf50\ud943\udef0",
        20, 57877, -1907956526, -5306085279564773372L, -48418L, false, true, (char) 49898, (char) 27405,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41\0121=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41\012",
        Z.run(T, 2, 14, 11, 17, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\udbc4\udf62\ud9c6\udc41", "\u5348\u31b1\u7c20\u8eb2\u4567\ub4eb\u2655\u8d6d\u68aa\ua851\ua37b\u4dd7\u110d\u2194\u6108", "\ud87b\udd7d\udaac\udd63\udacb\udcdf\ud99e\udf50\ud903\udc82\u5581\ud943\udf2d\ud813\udfe9\udaaf\udf40\ud95b\udec3\ud812\udf36\udb82\udd2b\udaab\udf19\ud963\udf7c\uda10\udf07",
        27, 72182, -1088680177, -3673664706678978510L, 20863L, true, true, (char) 26898, (char) 6402,
        Double.longBitsToDouble(0x3fd752d5e3124de0L), Double.longBitsToDouble(0x3fdb909bc9d7c5deL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ub51f\udac9\udd87\uda59\udc9a\udbba\uddc0\udb72\udf61\ud9c6\udc6f\udb97\udec2\012",
        Z.run(T, 1, 15, 16, 13, "\ud8e0\udc72\udb55\udc00\ub51f\udac9\udd87\uda59\udc9a\udbba\uddc0\udb72\udf61\ud9c6\udc6f\udb97\udec2", "\u702e\u7c20", "\ud90f\udc56",
        22, 86745, 1767697354, 5069571564782064880L, 51996L, false, false, (char) 22396, (char) 26276,
        Double.longBitsToDouble(0x3fd875b751af8ca6L), Double.longBitsToDouble(0x3fdc7c723f567a94L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\uda89\udd17\ud95a\udc43\012",
        Z.run(T, 1, 10, 0, 17, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ueab7\uda63\uddf6\uda89\udd17\ud95a\udc43", "\u53bd\u31b1\u7c20\u3f9b\u08e3\ub4eb\u555c\u8d6d\u68aa\u5fdc\u4796\u0e57\u3c04\uc0d7\u2d67\u5a5e\ua653\uad72", "\ud99e\udf50\ud903\udc82\ud8ba\udf50\ud943\udef0",
        20, 57877, 2051466450, -5306085348284250108L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\uda6e\udf2d\ud8b8\udeb8\udbf8\udf1f\ueab7\uda63\uddf6\012",
        Z.run(T, 1, 13, 13, 13, "\ud8e0\udc72\uda6e\udf2d\ud8b8\udeb8\udbf8\udf1f\ueab7\uda63\uddf6", "\ub784\uaf69\uc3f9\u30f9\u7c20\u3ece", "\ud859\ude1f\udb3f\udf99\uda28\uddff\ud97c\udc9f\udada\ude26\udb7b\udcb5\udaed\udc7c\udaeb\udc97\udab1\ude87",
        -2, 65111, -953960388, -8805303874189905187L, 96930L, false, true, (char) 14881, (char) 38477,
        Double.longBitsToDouble(0x3fe8b5cb2cd2aeafL), Double.longBitsToDouble(0x3fec6bd23004b65cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\ud972\udc08\ud863\udf67\udbf8\udf1f\ud903\udffd\uda62\ude49\ud9d1\ude2f\uda63\udc9d\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 3, 6, "\ud8e0\udc72\ud972\udc08\ud863\udf67\udbf8\udf1f\ud903\udffd\uda62\ude49\ud9d1\ude2f\uda63\udc9d", "\u5799\u31b1\u7c20\u3ece\u08e3\ub4eb\u555c\u8d6d\u68aa\u5fdc\u15d6\u4dd7\u110d\u2194\u6108\u1d13\ua653\uad72", "\uda87\uddbd\ud8dd\udc22\ud8ba\udf50\ud943\udef0",
        20, 57877, 2051466450, -5306085279564773372L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a09317262L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ud8a3\udd66\ue935\udb83\udce2\ud9c6\udc68\udb97\udec2\ud87e\udd47\ud959\udea4\udaf7\ude37\ud990\ude63\uda9d\ude0e\ud8e7\udea2\ud90f\udc56\ud98c\uddd3\ud87d\udf3f\uda28\uddff\ud97c\udc9f\uda4f\udcc8\uda1d\udf72\udabe\udcbe\ud81f\udd31\udae6\uddee\ud800\udc1b\ud8ea\udd26\ud875\udcf9\ud879\udfba\udbc2\udff2\u2f91\ud81f\udcf5\ud926\ude59\uda30\udd98\udb8a\udd6a\ud916\udebd\ud9ef\udf63\udb1a\udd28\ud9c4\udfd8\0121=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ud8a3\udd66\ue935\udb83\udce2\ud9c6\udc68\udb97\udec2\ud87e\udd47\ud959\udea4\udaf7\ude37\ud990\ude63\uda9d\ude0e\ud8e7\udea2\ud90f\udc56\ud98c\uddd3\ud87d\udf3f\uda28\uddff\ud97c\udc9f\uda4f\udcc8\uda1d\udf72\udabe\udcbe\ud81f\udd31\udae6\uddee\ud800\udc1b\ud8ea\udd26\ud875\udcf9\ud879\udfba\udbc2\udff2\u2f91\ud81f\udcf5\ud926\ude59\uda30\udd98\udb8a\udd6a\ud916\udebd\ud9ef\udf63\udb1a\udd28\ud9c4\udfd8\012",
        Z.run(T, 2, 13, 13, 16, "\ud8e0\udc72\udb55\udc00\ud8b8\ude03\udbf8\udf1f\ud8a3\udd66\ue935\udb83\udce2\ud9c6\udc68\udb97\udec2\ud87e\udd47\ud959\udea4\udaf7\ude37\ud990\ude63\uda9d\ude0e\ud8e7\udea2\ud90f\udc56\ud98c\uddd3\ud87d\udf3f\uda28\uddff\ud97c\udc9f\uda4f\udcc8\uda1d\udf72\udabe\udcbe\ud81f\udd31\udae6\uddee\ud800\udc1b\ud8ea\udd26\ud875\udcf9\ud879\udfba\udbc2\udff2\u2f91\ud81f\udcf5\ud926\ude59\uda30\udd98\udb8a\udd6a\ud916\udebd\ud9ef\udf63\udb1a\udd28\ud9c4\udfd8", "\u6c64\u91ce\u80ef\u47de\u7a01\u100a\uba2a\u7057", "\udb73\udf14\ud81f\udd10\ud92d\ude91\ud99e\udfb5\u3de4\udb92\udc6c",
        27, 93018, -1841556700, 1590651222473586417L, 35650L, true, false, (char) 61034, (char) 33667,
        Double.longBitsToDouble(0x3fed69183c1c25dfL), Double.longBitsToDouble(0x3fd699eae23bd992L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\0121=java.lang.Boolean:true |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\udb55\udc00\012",
        Z.run(T, 2, 10, 10, 16, "\ud8e0\udc72\udb55\udc00", "\u1a00\u9a55\u7a5f\ubcef\ucf93\uc2a4\u8cd2\u8a13\uabaf", "\ud90f\udc56",
        22, 86745, 1767697354, 5069571564782064880L, 68288L, false, false, (char) 19927, (char) 26276,
        Double.longBitsToDouble(0x3fe77adba9c91720L), Double.longBitsToDouble(0x3fdc75fe3f567a94L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.parser.Token$Character:\ud8e0\udc72 |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\0121=org.jsoup.parser.Token$Character:\ud8e0\udc72 |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\012",
        Z.run(T, 2, 5, 5, 15, "\ud8e0\udc72", "\uc19f\u055a", "\ud89d\udf1e",
        22, 87523, 824691067, -4562369916237702103L, 61167L, true, false, (char) 62396, (char) 62677,
        Double.longBitsToDouble(0x3fda6eabeefcf474L), Double.longBitsToDouble(0x3fe302b2d6956ca0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!H:java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 0, "\ud8e0\udc72", "\uc19f\u055a", "\ud9b5\udcd9",
        19, 87523, 0, -4562369916237702103L, -52736L, true, true, (char) 40914, (char) 9690,
        Double.longBitsToDouble(0x3fee503f9e7a695cL), Double.longBitsToDouble(0x3f3562c000000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud912\udf52\ud8a4\udc11\ud89d\udf79\uda07\ude6a\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 16, 17, "\ud912\udf52\ud8a4\udc11\ud89d\udf79\uda07\ude6a", "\u9607\ud0e2\ucff4\uc9c0\u53bd\u31b1\u7c20\u3ece\u08e3\u2fdc\u555c\uc039\u822f\ua4db\u15d6\u4dd7\u110d\u7270\u86ac\u1a49\ub3de\u3f93", "\ud99e\udf50\ud903\udc82\ud8ba\udf50",
        14, 99085, -1374854123, 8810981310355799949L, 79179L, true, false, (char) 63010, (char) 64990,
        Double.longBitsToDouble(0x3fe8b1bd270fbffeL), Double.longBitsToDouble(0x3fef95f8e2df4341L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud90c\udd21\udbec\udcac\ud8b0\udf2d\ud974\uded2\ud838\udee4\uda95\udfe5\ud99b\udc9d\ud83b\ude7d\0121=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud90c\udd21\udbec\udcac\ud8b0\udf2d\ud974\uded2\ud838\udee4\uda95\udfe5\ud99b\udc9d\ud83b\ude7d\012",
        Z.run(T, 2, 11, 11, 13, "\ud90c\udd21\udbec\udcac\ud8b0\udf2d\ud974\uded2\ud838\udee4\uda95\udfe5\ud99b\udc9d\ud83b\ude7d", "\u1dbb\ud076\uaba8\ucb7a\ub6b8\ua674\u8505\u0d4c\u68aa\u300e\u15d6\u4dd7\u110d\u5d40\u6108\u1d13\u662c\uca31", "\ud99e\udf50\udb71\udf08\ud854\ude5c\udab1\ude24",
        20, 57877, -1551850542, 1061920291617805749L, -87659L, false, true, (char) 44254, (char) 20662,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6ff1209317262L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\ud972\udc08\ud863\udf67\udbf8\udf1f\ud903\udffd\uda62\ude49\ud9d1\ude2f\uda63\udc9d\0121=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud8e0\udc72\ud972\udc08\ud863\udf67\udbf8\udf1f\ud903\udffd\uda62\ude49\ud9d1\ude2f\uda63\udc9d\012",
        Z.run(T, 2, 14, 14, 6, "\ud8e0\udc72\ud972\udc08\ud863\udf67\udbf8\udf1f\ud903\udffd\uda62\ude49\ud9d1\ude2f\uda63\udc9d", "\u5799\u4b0d\u89aa\u3ece\u08e3\ub4eb\u555c\u8d6d\u68aa\u5fdc\u15d6\u4dd7\u110d\u2194\u447b\u1d13\ua653\uad72", "\uda87\uddbd\ud8dd\udc22\ud8ba\udf50\ud943\udef0",
        20, 57877, 2051466450, -5306308480425211900L, -48418L, false, true, (char) 44254, (char) 27318,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fe6fa1a01317262L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud912\udf52\ud8a4\udc11\ud89d\udf59\uda07\ude6a\0121=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud912\udf52\ud8a4\udc11\ud89d\udf59\uda07\ude6a\012",
        Z.run(T, 2, 12, 12, 17, "\ud912\udf52\ud8a4\udc11\ud89d\udf59\uda07\ude6a", "\ua082\u1352\u8e2a\uca5d\u53bd\u08b3\u7cf0\u3ece\u0984\u2fdc\u555c\uc039\ud6ab\ua4db\u15d6\u4dd7\u110d\u7270\u86ac\u1a49\ucc26\u647b", "\ud92e\udc41\ud93e\udc7a\ud8ba\ude74\ud8a6\udd39\ud8c4\udceb\uda9e\udf62\udae5\udc06\ud812\udf36\udb82\udd2b\u7fc4\udbe6\udc5a\uda10\udf07",
        27, 72182, -1088680177, -6821879274435810946L, -74497L, true, true, (char) 17790, (char) 49198,
        Double.longBitsToDouble(0x3fa9e24142266bf0L), Double.longBitsToDouble(0x3fde1112668f4d78L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 7, 1, "\ud8e0\udc72\udb55\udc00\ud977\udff5\ud811\ude85\ueab7\uda63\uddf6\ud908\udcf8\udadc\udc3e", "\ud362\ud442\u7c20\u3ece\u08e3\ub4eb\u555c\u8d6d\u5567\u5fd3\u15d6\u4dd7\u110d\u2194\u6108\u1d13\ua653\u2739", "\ud9f9\udf6c\ud9f7\uddb4",
        13, 58560, -2070909745, 1984485931782286713L, -48418L, false, true, (char) 44254, (char) 33525,
        Double.longBitsToDouble(0x3fe87dfff3f2bf1cL), Double.longBitsToDouble(0x3fcbe86824c5ca7cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud92d\udd76\ud972\udc08\ud863\udf67\udbf8\udf1f\ud903\udffd\ud865\udf6a\ud9d1\ude36\uda63\udc9d\0121=java.lang.Boolean:false |this=org.jsoup.parser.Token$Character:\ud92d\udd76\ud972\udc08\ud863\udf67\udbf8\udf1f\ud903\udffd\ud865\udf6a\ud9d1\ude36\uda63\udc9d\012",
        Z.run(T, 2, 15, 15, 6, "\ud92d\udd76\ud972\udc08\ud863\udf67\udbf8\udf1f\ud903\udffd\ud865\udf6a\ud9d1\ude36\uda63\udc9d", "\u3ff2\u31b1\u7c20\uc914\u0945\ub4eb", "\uda28\uddff\ud97c\udc9f\ud991\udc24\ud9c2\udf6e\ud960\udc7d\ud81f\udd25",
        23, 63994, 1803323119, -4097228001391228473L, 7822L, true, false, (char) 22425, (char) 50208,
        Double.longBitsToDouble(0x3fc5b6972456bc8cL), Double.longBitsToDouble(0x3fe756ab39d14cc4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.TokeniserState|read|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader|fac:org.jsoup.parser.TokeniserState:valueOf:java.lang.String",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$StartTag|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Character|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Comment|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Doctype|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.Token|asCharacter||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|asComment||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|asDoctype||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|asEndTag||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|asStartTag||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|isCharacter||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|isComment||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|isDoctype||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|isEOF||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|isEndTag||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.Token|isStartTag||new:org.jsoup.parser.Token$Character:java.lang.String",
    "M|org.jsoup.parser.TokeniserState|read|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader|fac:org.jsoup.parser.TokeniserState:valueOf:java.lang.String",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$StartTag|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Character|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Comment|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Doctype|new:org.jsoup.parser.XmlTreeBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
