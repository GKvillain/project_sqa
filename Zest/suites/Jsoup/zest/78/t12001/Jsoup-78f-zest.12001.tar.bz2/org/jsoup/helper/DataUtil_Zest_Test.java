package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 1, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud9ac\udce0\uda4a\udf97\uda3a\udd54\ud89f\udd46", "\ua501\u7396\u2673\u02ea\u7887\u6727\u2a52\ua4f9", "\uda06\udf67\uda69\udf64\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud87f\udcb9\ud8fb\ude42",
        8, 31365, 1523128805, -7822809127978992852L, 80520L, false, true, (char) 29345, (char) 2509,
        Double.longBitsToDouble(0x3fec2dc0504c6e88L), Double.longBitsToDouble(0x3fe3ce75e615d74eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=null\012",
        Z.run(T, 2, 0, 4, 9, "\uda54\ude28\ufe1f\udba9\udc1d\ud8ff\uddbc\udb7f\udedd\ud9ac\udce0\udab0\uddf9\uda3a\udd54\ud810\udffe\ud9b3\udf44\uda01\uddd6\ud994\udc62\udaea\udd97\udb4b\udc67\udbf4\udc0e\udae1\udd60\udb2c\udd9c\udacf\udff0\u6153\ud80d\udc30\ud8c1\udf64", "\u3c27\u69c9\u33d4\u7c4d\u682d\u952a\u61f8\u6d7e", "\udbd6\udce4\udaa7\udf08\udb22\udfef\ud941\udef6\ud970\udfca\udac0\uddf5\ud929\udcfb\ud9cd\udff6\uda80\ude26\udab3\udd57\uda1a\udc69\udb90\udff7\ue260\ud8ca\udfc9\udb8d\udc54\ub3a0\u676f\udb30\udc5c\u24e7",
        51, 2764, 406795937, -9021292201545878663L, 83290L, false, true, (char) 43636, (char) 55504,
        Double.longBitsToDouble(0x3fd4d243b877cbf8L), Double.longBitsToDouble(0x3fd4bfa3513dafaeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 1, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud96e\udee1\udb59\udd1a\uda3a\udd54\ud89f\udd46", "\ua501\u7396\u2673\u02ea\u9e22\u6727\u2a52\uaca8", "\ud9eb\udc8c\uda69\udf64\ud8b6\udcf2\ud815\udea4",
        8, 49111, -1758962576, 5355330870080460645L, -86828L, false, true, (char) 52225, (char) 55627,
        Double.longBitsToDouble(0x3fe950afc965c93cL), Double.longBitsToDouble(0x3fdc859c570b71b6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 3, "\udb6c\udf0c\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd", "\u4510\ubb02\u0eae", "\u4252\ud9e5\udd75\udbfb\udcf5\ud890\udf13\udb2c\udd9c\u4a3d\ud84d\udcbe\udbd6\udc04\ud8a3\udc3c\uda06\udf67\uda69\udf64\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud87f\udcb9",
        14, 39133, 1720971365, 6541788403249171596L, -50561L, false, false, (char) 29987, (char) 29345,
        Double.longBitsToDouble(0x3f80b38ae16e0280L), Double.longBitsToDouble(0x3fb31ba233ce7648L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 1, "\ud86a\ude2d\ud97f\udfe5\udb13\udc4f\ud911\udf86\ud996\udf8a\ud8bc\udf3c\uda4a\udf97\ud9a2\udd53\udb24\udfd7", "\u92d7\u7396\u2673", "\udb1b\udd9c\u4a3d",
        13, 79355, -757084443, 3078475204128701344L, 57586L, true, true, (char) 36042, (char) 32660,
        Double.longBitsToDouble(0x3fd0d97280ca94a2L), Double.longBitsToDouble(0x3fde56693c86ee82L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=null\012",
        Z.run(T, 2, 3, 4, 11, "\ud934\udca7\u6cc0\ud816\uddaa\ud908\udd74\ud846\udcac\udb60\udda7\uda4a\udfce\uda3a\udd54\ud89f\udd46", "\u7f7a\ud4b1\u90f0\u79ac\ua00f\u6727\u2a52\ua4f9", "\uda08\udf02\ud8a3\udf0e",
        28, 68918, 706993971, -3021243928816733650L, -47916L, false, true, (char) 52225, (char) 49739,
        Double.longBitsToDouble(0x3fe950afc965c93cL), Double.longBitsToDouble(0x3f80b38a616e0280L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 7, "\uda92\udd6d\ufe1f\ud937\uddc4\ud908\uddea\u043d\u8eec\uda4f\udf44\uda2a\udebc\udbc0\udd15", "\ua501\u5e17\u4681\u9cbc\u8ad7\u1d11\u2a52\u1ab5", "\uda06\udf67\ud9fd\udecd\ud8b6\udcf2",
        2, 59843, 589587111, -7554686737561029363L, -27835L, false, false, (char) 36507, (char) 52225,
        Double.longBitsToDouble(0x3fe6c4d39f2a15f9L), Double.longBitsToDouble(0x3fd65d83c010b38aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.io.IOException\012",
        Z.run(T, 2, 3, 11, 7, "\uda54\ude28\ufe1f\ud937\udd97\ud908\uddea\ud823\udca6\ud9ac\udce0\uf1b1\u2c40\ud89f\udd46\uda64\udd73\ud94e\udf8f\ud89b\udea7\u4252\ud828\udcd6\ud9c0\udd0e\ud949\udf7e\udb2c\uddce\u4a3d\ud852\udeee\ud9c2\udc3b\ud8a3\udc3c\uda06\udf67\uda69\udf64\ud8b6\udcf2\uda98\udde9\udacf\udc5e", "\u8f22\u61f8\u4ff3\u6be0\u8306\uabc6\u10e3\ub641\u03cb\ucabe\u2686\u35e9\uae3d\u63e8\u851b", "\ud982\udf40\uda1d\udd10\udb87\udf8f\udb42\ude1e\ud97c\udc5f\udb5c\udf13\udafd\udd0b\udad5\udfe5\uda4c\uddaa\uda12\udf8e",
        17, 23880, -1150450135, -6080590473540045747L, 97280L, true, false, (char) 21261, (char) 26756,
        Double.longBitsToDouble(0x3febd2cfc83369ebL), Double.longBitsToDouble(0x3fb1f463a5df1e90L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 13, 7, 1, "\udb8b\ude23\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud9ac\udce0\uda4a\udf97\uda3a\udd54\uab3c", "\ua501\uc795\u065f\ua2ae\u7887\u6727\u2a52\ua4f9", "\ud964\udcd6\uda67\udedd\ud8d4\udc34\uda75\udf25\udaf9\uddf3\ud9dd\udd5c\ud94d\udc10",
        8, 31365, 1523128805, -7822809127978992852L, 80520L, false, true, (char) 29345, (char) 2509,
        Double.longBitsToDouble(0x3fec2dc0504c6e88L), Double.longBitsToDouble(0x3f819d798575c180L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 13, 13, 9, "\ud83b\udcb8\ud951\udd6c\uda72\ude99\udb3f\udc0c\udb7f\udedd\ud99a\udee0\ud97d\udf28\udb4d\udd3f\udbe5\uddc7", "\u2656\u5993\u328c\u0f99\u7887\u72b4\u3e94\uc5dc\ua42b\u3969\u7385\u0768\u1a55\u2c2b\u8ff4\u995e\u682d\u3f0a\u06ed\u58a2", "\ud8cc\ude9e\udad2\udf70\udb33\udd02",
        -4, 79360, 646478725, 6809853775939569062L, 67174L, true, true, (char) 32927, (char) 64933,
        Double.longBitsToDouble(0x3febf0e0bcb68d2aL), Double.longBitsToDouble(0x3fe5d6f1dc46ed68L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 10, 6, 1, "\ud87a\udfbc\ud91b\ude3d\ud937\uddc4\ubd13\ud9f8\uddbb\udb77\udde2\uda60\udcce\ud93b\udcd3\uda87\udf35", "\u4038\u3b76\u98d2s\ua969\u6727\u0452\ua4f9\ua005", "\ud807\udde5\udb22\udf01\ud815\udf1f\ud95d\udca6\ud820\udee0\ud998\udc7d\ud857\udf60\uaba5\uda3a\ude6b\ud9d9\ude9d\ud8c1\udd2b\ud8ee\ude2f\ud843\udecd",
        17, 3132, -1207259128, -6698687160403433396L, 36501L, true, true, (char) 33897, (char) 42961,
        Double.longBitsToDouble(0x3fe067c31badfc01L), Double.longBitsToDouble(0x3f9a87483d26b4c0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 6, 13, 2, "\ud89f\ude0a\ub474\ud83a\udd86\ud908\uddea\udb7f\udedd\ud9ac\udce0\udb74\udeed\uda45\ude49\ud89f\udd46\uda64\udd73", "\u33ca\u9b1d\ud3f8\u0446\u6727", "\udbd6\udc45\ud8a3\udc3c\uda06\udf67\uda69\udf64\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud87f\udcb9\ud8fb\ude42\ud8c2\ude6e\uda15\ude70\uda7b\udf3e\u00be\ud9af\udd9e\ud9ee\ude59\ud98a\ude59\udb22\udfef\ud806\udf72\ud970\udfca\uda35\udd08\udb2b\udd64\ud805\udcb7\ud8c0\udd06\udb7d\udddf\ud93e\udc6a\udb69\uddb0",
        34, 84690, -728232595, 8964068791900648651L, -75292L, false, true, (char) 27037, (char) 20986,
        Double.longBitsToDouble(0x3fe7609d0f581f65L), Double.longBitsToDouble(0x3fe36c3ac04253a1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\012",
        Z.run(T, 2, 7, 3, 1, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud9ac\udce0\uda4a\udf97\uda3a\udd54\ud89f\udd46", "\ua501\u7396\u2673\u02ea\u7887\u6727\u2a52\ua4f9", "\uda06\udf67\uda69\udf64\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud87f\udcb9\ud8fb\ude42",
        8, 31365, 1523128805, -7822809127978992852L, 80520L, false, true, (char) 29345, (char) 2509,
        Double.longBitsToDouble(0x3fec2dc0504c6e88L), Double.longBitsToDouble(0x3fe3ce75e615d74eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=null\012",
        Z.run(T, 2, 0, 12, 1, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud9ac\udce0\uda4a\udf97\uda3a\udd54\ud89f\udd46", "\ua501\u7396\u2673\u02ea\u7887\u6727\u2a52\ua4f9", "\ud9ca\udf67\uda69\udf64\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud87f\udcb9\ud8fb\ude42",
        8, 31365, 1523128805, 224899740269312L, 80520L, false, true, (char) 29345, (char) 2509,
        Double.longBitsToDouble(0x3fec2dc0504c6e88L), Double.longBitsToDouble(0x3fe3ce75e615d74eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null\0121=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\012",
        Z.run(T, 2, 4, 3, 3, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\uda2c\udce0\uda4a\udf97\uda3a\udd54\ud89f\udd46", "\ua501\u4839\uaba9\ub620\u31c8\u6727\u2a52\u6531", "\uda06\udf67\uda69\udf64\ud975\udf31\ud815\ude89\udacf\udc5e\ud87f\udcb9\ud8fb\ude42",
        8, 88365, 1523149950, -7822809342727357652L, 80520L, false, true, (char) 27939, (char) 2423,
        Double.longBitsToDouble(0x3fec2dc0504c6edeL), Double.longBitsToDouble(0x3fe3ccad5615d74fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 4, 1, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud9ac\udce0\uda4a\udf97\uda3a\udd54\ud8e3\udf0f", "\u9986\u705a", "\ud890\udf13",
        -3, 53309, 2056352693, 4728145627859373797L, -68352L, true, true, (char) 20784, (char) 49992,
        Double.longBitsToDouble(0x3fe539511c702324L), Double.longBitsToDouble(0x3fd0d97280ca94a2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 6, 7, 1, "\uda54\ude28\u3647\ud937\uddc4\udb53\udd4e\udaf8\udfe5\ud9ac\udce0\uda4a\udf97\uda3a\udd54\ud89f\udd46\uda64\udd73\ud94e\udf8f\ud89b\udea7\u4252\ud9e5\udd75\udbfb\udcf5\ud87d\uddc9\ud987\udd06\u4a34\uda01\udd27\udbd6\udc9d\ud8a3\udc3c\uda06\udf67\uda69\udf64\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud85e\udcd7\uda28\udf39\ud855\udcf0\ud96b\udeb9\uda7b\ude9a\ud867\ude26\udbf3\udc66\udbd6\udce4\ud901\udf50\uda5a\udeda\ud919\udc5d", "\u2ea7", "\ud94e\ude28\udb0b\udf5f\uda62\ude69\u110a\udb2a\ude87\ud872\udf0d\udb67\udfdd\ud915\udc6c\ud8f2\udd92\udaac\udc76\ud80a\udd21\uda09\udec0\ud8e3\udec9\udabc\udd41\uda7c\udf8d\udbb3\ude76\uda72\udc7b",
        51, 55141, 851701471, 2498149510763552990L, 2760L, true, false, (char) 46441, (char) 5185,
        Double.longBitsToDouble(0x3fe0211082634259L), Double.longBitsToDouble(0x3fb12008bf44ade0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\012",
        Z.run(T, 1, 3, 1, 1, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\udd14\udb7f\udedd\ud9ac\udce0\uda4a\udf97\uda3a\udd54\ud89f\udd46", "\ua501\u7396\u2673\u02ea\u7887\u6727\u2a52\ua4f9", "\uda06\udf67\uda69\udf64\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud87f\udcb9\ud8fb\ude42",
        8, 31365, 1523128805, -7822809127978992852L, -18376L, false, true, (char) 29345, (char) 2509,
        Double.longBitsToDouble(0x3fec2dc0504c6e88L), Double.longBitsToDouble(0x3fe3ce75e615d74eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 0, 7, 7, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud9ac\udce0\uda4a\udf97\ud9c6\udcb8\ud98f\udcd6", "\ua501\u7396\u2673\u02ea\u7887\u5edb\u93d8\u9bc7", "\uda06\udf67\ud99d\udc3f\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud9c7\udcbd\ud8fb\ude42",
        8, 31365, 1523128805, -7822809127978992852L, 80520L, false, true, (char) 29345, (char) 2509,
        Double.longBitsToDouble(0x3fb4ae02a5c60598L), Double.longBitsToDouble(0x3fe6f027968acf4eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 7, 7, 1, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud9ac\udce0\uda4a\udf97\uda3a\udd54\ud89f\udd46", "\u1c24\u7396\u2673\u02ea", "\u49b3\ud852\udeb7\udbd6\udc45\udb23\ude89\ud9c7\ude03\uda69\udf44\ud8b6\udcf2\udb1d\udda8\udad6\uddeb\ud87f\udcb9",
        38, 42476, 1720120078, 6541788403249171596L, -50561L, false, false, (char) 29987, (char) 29345,
        Double.longBitsToDouble(0x3f80b38ae16e0280L), Double.longBitsToDouble(0x3fb31ba233ce75e0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=null\012",
        Z.run(T, 2, 0, 4, 9, "\uda54\ude28\ufe1f\udba9\udc1d\ud8ff\uddbc\udb7f\udedd\ud98d\udee0\ud99d\ude0e\uda9a\udc31\ud811\udc45\ud9b3\udf44\uda01\uddd6\ud994\udc62\udaea\udd97\udb4b\udc67\udbf4\udc0e\udae1\udd60\udb2c\udd9c\udacf\udff0\u6153\ud80d\udc30\ud8c1\udf64", "\u3c27\u69c9\u7c09\u7c4d\u682d\u952a\u61f8\u6d7e", "\udbd6\udce4\udaa7\udf08\udb22\udfef\ud941\udef6\ud970\udfca\udac0\uddf5\ud929\udcfb\ud9cd\udff6\uda80\ude26\udab3\udd57\uda1a\udc69\udb90\udff7\ue260\ud8ca\udfc9\udb8d\udc54\ub3a0\u676f\udb30\udc5c\u24e7",
        51, 69204, 406802669, -9021292201545878663L, 83290L, false, true, (char) 43636, (char) 55504,
        Double.longBitsToDouble(0x3fd4d243b877cbf8L), Double.longBitsToDouble(0x3fd4bfa3513dafaeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 9, "\uda54\ude28\000\udba9\udc1d\udba9\uddb1\u00ed\ud9ac\udce0\udab0\uddf9\uda3a\udd54\ud810\udffe\ud9b3\udf44\uda01\uddd6\ud994\udc62\ud81a\udf2f\000\000\udae1\udd33\udb2c\udd9c\udacf\udff0\u6153\ud80d\udc30\ud9c2\udd00", "\u3c27\u69c9\u33d4\u7c4d\ub49f\u7814\u61f8\u6d7e", "\udbd6\udce4\udaa7\udf08\udb22\udfef\ud941\udef6\ud970\udfca\udac0\uddf5\ud929\udcfb\ud9cd\udff6\uda65\udc11\udab3\udd57\uda1a\udc69\udb90\udff7\ue260\ud8ca\udfc9\udb8d\udc54\ub3a0\u676f\udb30\udc5c\u24e7",
        51, 2764, 406795937, -9021292201545878663L, 83290L, false, true, (char) 43636, (char) 17361,
        Double.longBitsToDouble(0x3fd4d243b877cbf8L), Double.longBitsToDouble(0x3fd4bfa3513dafaeL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=!java.io.IOException\012",
        Z.run(T, 2, 0, 10, 9, "\uda54\udeba\ud9f6\ude1e\udba9\udc1d\ud997\udc27\udb7f\udedd\ud9ac\udce0\udab0\uddf9\ud8c4\udf7b\ud802\udd2d\ud9b3\udf44\uda01\uddd6\ud994\udc62\udaea\udd97\udb4b\udc67\udbf4\udc0e\udae1\udd60\udb88\udc2d\udaa1\udeb8\u6153\ud80d\udc30\uda4d\udcea", "\u558f\u69c9\u33d4\u7c4d\u682d\u952a\u61f8", "\udbf3\udc66\udbd6\udce4\udaa7\udf08\udb22\udfef\ud941\udef6\ud86e\udd73\ud9a8\ude24\ud929\udc67\ud9a6\udcc9\ud96f\udc9f\udab3\udcc7\uda1a\udc69",
        51, 22849, -963887316, 4049775125168265965L, 60979L, false, true, (char) 50731, (char) 37164,
        Double.longBitsToDouble(0x3fe50af3fe8a183fL), Double.longBitsToDouble(0x3febcc166d411fd1L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 12, 11, "\uda54\ude28", "\u898d\u4eca\u9a65\ub18f\u4510\uca1f\uae9e\u2586\uc7ad\u6b30\ud227\ube02\u1293\u6727\ua7b3\u63c9\u30bf\u1b56\u90f1\u0760\u3c27\u69c9\u33d4\u7c4d\u682d\u952a\u61f8\u6d7e\u6be0\u2811\u6604\u56f9\ub641", "\udac0\uddf5\ud929\udcfb\ud9cd\udff6\uda80\ude56\udab3\udd57\uda1a\udc69",
        51, 22849, -963887316, 4049775125168265965L, 45057L, false, false, (char) 31478, (char) 56942,
        Double.longBitsToDouble(0x3febd6f01fbc00deL), Double.longBitsToDouble(0x3fd013d73a98870aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 3, 13, 11, "\uda0f\udf32\ufe1f\ud937\uddc4\udad6\udf96\udb7f\udedd\ud96e\udee1\udaa3\udd80\uda3a\udd53\ud89f\udd46", "\ua501\u7396\u2673\u02ea\u9e22\u300d\u790d\uaca8", "\ud9eb\udc8c\ud9eb\udd45\ud89d\udf56\ud815\udea4",
        8, 49111, -1758962576, 5355330870080460645L, -86828L, true, false, (char) 48641, (char) 55523,
        Double.longBitsToDouble(0x3fe950afc965c93cL), Double.longBitsToDouble(0x3fdc859c51bd71b6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 1, "\udb9b\ude41\uda71\udc78\ud937\udd21\ud879\udf6b\udb7f\udea0\ud96e\udee1\udb3b\udd6b\uda3a\uddda\ud89f\udd46\uda64\udd73\uda11\udca6\ud830\uddd2\ud99e\udd59\ud813\udf40\udbfb\udcf5\ud975\udc69\udb2c\udd9c\u4a3d\uda41\udde8", "\u04aa\u0768", "\udad1\udf03\ud87f\udcb9\ud8fe\udf42",
        8, 77277, -304226139, -7822809127978992852L, -18376L, false, true, (char) 29345, (char) 22413,
        Double.longBitsToDouble(0x3fe4ddc6daea0669L), Double.longBitsToDouble(0x3fea153b0554b1a5L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 3, "\ue372\000\000\ud908\udcfb\000", "\u5b94", "\uda33\udde3",
        14, 57540, 0, 7546492328669642716L, 96608L, false, false, (char) 50114, (char) 184,
        Double.longBitsToDouble(0x3fd253f000dc0184L), Double.longBitsToDouble(0x3fde3696514e5446L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 10, 7, "\ud86a\ude2d\ud885\ude76\udb13\udc4f\ud911\udf86", "\u0be3\u55a6\u09c6\u0282\u61a3", "\udb67\udc58\udb93\udcc3\ud890\udf20\udb1b\udd9c\u4a3d\ud852\udeee",
        -5, 99445, -1109600726, 4607315419857055013L, 68419L, true, false, (char) 32660, (char) 35893,
        Double.longBitsToDouble(0x3fb952944f2b3498L), Double.longBitsToDouble(0x3fe21bba0e0a0903L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 4, "\ud86a\ude2d\ud97f\udfe5\udb13\udc4f\ud911\udf86\ud996\udf8a\ud8bc\udf3c\uda4a\udf97\ud9a2\udd53\udb24\udfd7", "\u92d7\u3eec\u2673", "\udb1b\udd9c\u4a3d",
        13, 79355, -757084443, 7762218816118873564L, 57586L, true, true, (char) 36042, (char) 32660,
        Double.longBitsToDouble(0x3fd0d97280ca94a2L), Double.longBitsToDouble(0x3fde56693c86d080L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 6, 6, 3, "\ud87a\udfbc\ud91b\ude3d\ud937\uddc4\ubd13\ud9f8\uddbb\udb77\udde2\uda60\udcce\ud93b\udcd3\uda87\udf35", "\u4038\uc112\u98d2s\ua969\u6727\u0452\ua4f9\u276e\u3969\u4f69\u02a9\u86a4\ua5d3\u2091\u175d\u526b\u0bd9\u4eb3\u1d0e\u9993\ucba8\ua6e1\u7f93\u192f\u3ef5\ucabe\ub556\u8dd8\ub140\u915d", "\ud887\udce0\udace\uddcf\udb0f\udc8f\ud985\udf43\ud872\udf4b\udbff\udcf4\udbcc\udf6e\udb82\udee1\udb37\udc77\udb6c\udc8c\ue1c0\ud87f\ude3a\ud8ca\ude79\ud86b\udcb5\ud89f\udc64\u5848\uda05\udee2\ud927\udc42\udb15\udfea\udb78\udecf\udb3d\ude7a\udb60\udd18\udb61\udcb5\ud9bf\ude93\ud88e\udf65\uda6f\udfb6\ud840\udf95\udb30\udd04\udb0a\udf05\ud990\uddbd\ud8f7\uddd2\udb7d\udc45\udb00\udc06\ue7e9\udaa7\udf84\uda7e\ude02\ubca8\ued59\udb42\ude3b\ud95f\udfbe\udaaf\udd96\uda36\udd4a\ud9e4\udeb0\ud967\uddb2\ud811\udd1c\udbd2\udfca\uda1c\udf1a\ud92b\ude08\uda21\udf37\ud9ab\udcbb\ud92b\udf3e\uda2d\udd1c\uda02\udc45\ud81a\udd8c",
        54, 15753, -1614572110, 8911615696466928467L, -24796L, false, false, (char) 51039, (char) 19105,
        Double.longBitsToDouble(0x3fe238d3b010eaeaL), Double.longBitsToDouble(0x3feb8cbd3ef02205L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 1, "\ud9a4\udc78\ud86e\udd0e\ud87b\uddd6\ud98a\uddd5\ud820\udcdc\udb37\udf80\uda5b\udfd5\uda3a\udd54\ud89f\udd46\uda64\udd73\ud94e\udf8f\ud8aa\udea7\udb56\udcc6\ud81c\udf39", "\u6727\u2a52", "\ucee5\000\uda4a\udfc4\ud9e1\udc06\ud8b5\udda3\udadc\udeb8\uda2e\uded6\u5ce3\udb7a\ude69\ud81c\uddee",
        33, 52018, -1927282644, -7317435833089704232L, -84007L, false, false, (char) 56042, (char) 57952,
        Double.longBitsToDouble(0x3fe6056879025e2cL), Double.longBitsToDouble(0x3fc3c3e3223147b4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=null\012",
        Z.run(T, 2, 0, 12, 7, "", "\u1f11\u6990\u00ed\u38ff\u9002\u4510\ubb02\000", "\u00c4\000\u0e21\ud890\udf13\udb2c\udd9c",
        55, 92693, 234602240, -3251652922278674205L, 59013L, false, false, (char) 49891, (char) 36042,
        Double.longBitsToDouble(0x3fbc08c9286cb940L), Double.longBitsToDouble(0x3fb9529440000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 1, "\ud979\uddfa\udbc8\ude70\ud999\udcd0\ud920\udd8f\uda7e\ude70\ud806\udffa\uda20\udc5b\uda1a\udd54\udbd3\udf87\uda5c\uddc0\udbe4\udff9\uda30\udcf9", "\uc80d", "\ud995\udda9\uda06\udf7c\ud9f3\ude91\ud8ab\uddfb\ud892\uddcf\uda69\udf64\ud84e\ude3e\ud8b0\udca2\udac0\udf96\ud848\uded2",
        23, 39133, -1589186459, -8327432180782433447L, 33541L, true, false, (char) 14582, (char) 21872,
        Double.longBitsToDouble(0x3feef9b116979d93L), Double.longBitsToDouble(0x3fe395e40e4afcd3L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 7, "", "\u1f11\u6990\u00ed\u38ff\u9002\u4510\ubb02\000", "\u00c4\000\u0e21\ud890\udf13\udb2c\udd9c",
        55, 92693, 234602240, -3251652922278674205L, 59013L, false, false, (char) 49891, (char) 36042,
        Double.longBitsToDouble(0x3fbc08c9286cb940L), Double.longBitsToDouble(0x3fb9529440000000L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 1, "\uda54\ude28\ufe1f\ud937\uddc4\ud908\uddea\udb7f\udedd\ud9ac\udce0\uda4a\udf97\uda3a\udd54\ud89f\udd46", "\u24b1\u7396\u2673\u02ea\u7887\u45f7\u2a52\ua4f9", "\uda06\udf67\uda69\udf64\ud8b6\udcf2\ud815\udea4\udacf\udc5e\ud87f\udcb9\ud8fb\ude42",
        43, 31365, 1523128805, -7822809127978992852L, 80520L, false, true, (char) 29345, (char) 2509,
        Double.longBitsToDouble(0x3fec2dc057224b2bL), Double.longBitsToDouble(0x3fb9fdd103d92a58L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|parseInputStream|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|crossStreams|java.io.InputStream,java.io.OutputStream|static",
    "M|org.jsoup.helper.DataUtil|detectCharsetFromBom|java.nio.ByteBuffer|static",
    "M|org.jsoup.helper.DataUtil|emptyByteBuffer||static",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|mimeBoundary||static",
    "M|org.jsoup.helper.DataUtil|readFileToByteBuffer|java.io.File|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream,int|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream|static",
    "M|org.jsoup.helper.DataUtil|validateCharset|java.lang.String|static",
    "C|org.jsoup.helper.DataUtil|<init>|",
    "M|org.jsoup.helper.DataUtil|parseInputStream|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
