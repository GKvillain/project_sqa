package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 6, 6, 3, "\uda2e\udc67\ud88d\udfd7\uda5c\udeb4\u68e1\ud997\udcfd", "\u88e3\u14a0\u321f\ubbe2\u0c82\u6965", "\ud92c\udd9c\udbb6\ude79",
        6, 13888, -1027896478, 2029067148649203869L, 47848L, true, true, (char) 58995, (char) 9945,
        Double.longBitsToDouble(0x3f8abaeb39294740L), Double.longBitsToDouble(0x3fa0bb110ad49020L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 6, 6, 3, "\uda2e\udc67\ud88d\udfd7\uda5c\udeb4\ud8eb\udf6a\ud881\uddd5", "\u88e3\u14a0\u321f\ubbe2\u0c82\u6965", "\ud92c\udd9c\udbb6\ude79",
        6, 13888, -1027896478, 2029067148649203869L, 47848L, true, true, (char) 58995, (char) 9945,
        Double.longBitsToDouble(0x3f8abaeb39294740L), Double.longBitsToDouble(0x3fa0bb110ad49020L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 6, 6, 1, "\ud916\udf14\udba2\udc80\ud9bf\ude4a\u68e1\ud997\udcfd\udb83\udc63\ud850\udda2\uda23\ude08\ud877\udf15\ud80a\udc1d\ud5c4\ud867\udc6e\ud928\udd5d\ud83b\udd24\ud90b\udc17\ud806\udc3c", "\u74cd", "\u2430\ud8b6\udf6a\udafa\udc58\udb23\udc07\ud85d\udc45\udbd8\udd54\udb7c\udeb1\ud8ba\udfda\ud9bc\udc6e\udabb\udfbe\u0887",
        53, 26106, -757841622, -6090951674853576166L, -61959L, true, true, (char) 65393, (char) 43977,
        Double.longBitsToDouble(0x3fb7e7cb4785d998L), Double.longBitsToDouble(0x3fd455466aab2cbaL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 1, 5, 5, "\udb72\udd49\ud8a9\ude06\ud87b\udf43\u68e1\ud997\udcfd\udbaf\udf63", "\ub60b\u321f\ua107\u0c8c\u6965\u0566\u2afc\ua056\ud5b0\uc72c\ucd8f", "\u2430\ud8e5\ude61\udb0c\udc7a\uce18\ud85d\udc45\uda2c\ude1a",
        32, 27204, 1224899617, 1135004604415605684L, -88026L, false, true, (char) 50819, (char) 17946,
        Double.longBitsToDouble(0x3fe7735e219ee9a2L), Double.longBitsToDouble(0x3fd5f0c5ded124a6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 1, "\udbf2\udc69\ud88d\udfd7\uda5c\udeb4\u68e1\ud997\udcfd", "\u88e3\u14a0\ub515\u1538\u5428\u94ac", "\ud92c\udd9c",
        46, 22501, -1550032112, -4414781756211154478L, 91536L, false, false, (char) 27201, (char) 33448,
        Double.longBitsToDouble(0x3fee9ed8280d5d75L), Double.longBitsToDouble(0x3fcc94a3b085d888L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 6, 0, 4, "\uda2e\udc67\ud88d\udfd7\udb15\udcb1\000\ud997\udcfd", "\u88e3\u14a0\u321f", "\000\000\udab2\udc78",
        44, -879, -1929371904, 44019015709592418L, 66045L, false, true, (char) 133, (char) 5519,
        Double.longBitsToDouble(0x3fe398400bd3db05L), Double.longBitsToDouble(0x3f8abaea00000000L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 3, "\uda2d\udd20\uda4d\udfd7\uda5c\udeb4\u68e1\ud997\udcfd", "\u88e3\ub400\u165e\ubbe8\u0c82\u6965", "\ud92c\udd9c\udbb6\ude79",
        13, 13888, 867928930, -2375616542925063227L, 47848L, true, true, (char) 58995, (char) 15577,
        Double.longBitsToDouble(0x3fc14218b3929474L), Double.longBitsToDouble(0x3fa0bb110ad49020L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 3, 3, "\udb73\udd24\ud88d\udfd7\ud995\ude31", "\u424e\ub5ee\u95b1\u9829\u2f66\ubbe2\u0c82\ud32c\u5ff0\ud472\u1761\uab0f\uc71b\uc24d\u9f1d\uab31\u207f", "\udb23\udc07\ud85d\udc44",
        51, 23149, -2007225116, 5728794151998701655L, -86312L, true, true, (char) 14369, (char) 12238,
        Double.longBitsToDouble(0x3fe0d5d79fbf6547L), Double.longBitsToDouble(0x3fdc0d9caaa38004L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\uda2e\udc67\ud88d\udfd7\uda5c\udeb4\u68e1\ud997\udcfd", "\u88e3\u2c9f\uc90c\ubbe2\u72b4\u6965", "\udb4b\udf4b\ud83a\udf86",
        17, 8777, -1027896478, 2029067148649203869L, 32604L, true, true, (char) 58995, (char) 19375,
        Double.longBitsToDouble(0x3f8b977226933e80L), Double.longBitsToDouble(0x3feb3c42c0ad98cfL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 0, 3, 3, "\uda2e\udc67\ud88d\udfd7\ud876\udf12\ud90e\udc26\ud819\udcfe", "\u88e3\ucd3c\uba40\u9e1a\u05dd\uc50b", "\udacb\udeba\ud9f6\udd2f",
        30, 13888, -1027896478, -2112337957635242090L, 47848L, true, true, (char) 58995, (char) 9945,
        Double.longBitsToDouble(0x3fe718f1d4e431aeL), Double.longBitsToDouble(0x3fe9c8d840adb8f6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 2, "\uda2e\udc67\ud88d\udfd7\uda5c\udeb4\u68e1\ud997\udcfd", "\u88e3\u14a0\u321f\u3a67\u0c82\u6965", "\ud92c\udd9c\udbb6\ude79",
        6, 13888, -1027904173, 2029067148649203869L, 96596L, false, true, (char) 59194, (char) 9746,
        Double.longBitsToDouble(0x3f8abaeb39294740L), Double.longBitsToDouble(0x3fa0bb110ad49020L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 1, 6, 6, 3, "\uda2e\udc67\ud88d\udfd7\ud8ec\udecb\u68e1\ud997\udcfd", "\u88e3\u14a0\u321f\ubbe2\u0c82\u6965", "\ud92c\udd9c\udbb6\ude79",
        6, 13888, -1027896478, 2029067148649203869L, 47848L, true, true, (char) 58995, (char) 9945,
        Double.longBitsToDouble(0x3f8abaeb39294740L), Double.longBitsToDouble(0x3fa0bb110ae194d0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 4, "\uda2e\udc32\ud88d\udfd7\uda5c\udeb4\u68e1\ud997\udcfd\udb83\udc63\uda9c\udce7\ud817\udf62\udb5c\udc1b\udbbb\udd81\u636c\ud8ec\udf7f\ud82b\udcef\ud8b0\udc9e\ud88b\udc60\ud92c\udd64\udbb6\ude79\ud97c\udc87\ud875\udd9e", "\u207f\u5dd9\u184b\u550c\u929f\u5a97\ua455\u30e7\u12a9\u8685\ua40b", "\udb89\udc99\ud896\ude3b\udbf4\udf5b\uda9e\udff3\uda97\udfc8\ud8d1\udfaf\ud870\udef5\uda1d\udcef\udb2e\udc6b\uda88\udc44\udb9f\udeda\ud8f0\uddde\ud9ef\udd73\udaf5\ude9f\ud991\udea4\ud80a\udfcc\udaf3\udc2b\udb22\udd04\ud8d4\udd17\uda41\udd8e\ud9d5\ude5a\ud977\udc9a\ud86f\udf8a\udb09\udc36\u8e66\uda5b\uddc9\ud9fd\uddd4\udbc7\udd77\udb48\udce0\uda55\udea5\ud939\udfad\ud8bf\udfec",
        53, 61574, 1177074278, 4764493624801220482L, -76358L, true, true, (char) 2635, (char) 48142,
        Double.longBitsToDouble(0x3fd2ef3c501f51a6L), Double.longBitsToDouble(0x3fdcde7ec5badf5cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 5, "\udae0\uddff\ud9de\uddec\uda5c\udeb4\u68e1\ud997\udcfd", "\uaee2\u14a0\ua5ab\ubbe2\u0c82\u6965", "\ud85f\udf3a\uda4d\uddca",
        51, 93744, 1022474712, 2029087051527653533L, 47848L, true, true, (char) 58995, (char) 9945,
        Double.longBitsToDouble(0x3f8abaeb39294740L), Double.longBitsToDouble(0x3fa0bb110ad49020L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 2, "\uda2e\udc67\ud897\udcd7\ud8c9\ude2b\ud951\uddbb\ud997\udd2e", "\u88e3\u2111\u2e1e\u1c44\u0c82\u3744", "\udad6\udd33\ud83f\udda8",
        13, 49005, -1029408128, 2029067148649203869L, 22483L, true, true, (char) 11678, (char) 53761,
        Double.longBitsToDouble(0x3fa0bb11091efb00L), Double.longBitsToDouble(0x3fd046609da90992L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 0, "", "\u469d\u7343\000\000\000\u93d9\u14a0\u321f\u714e\000\000\000\u417b\u880d", "\020\udaa9\udf63\udb3e\udf7a",
        49, 4926, 1384758904, 576957245607501427L, -100000L, false, false, (char) 0, (char) 22528,
        Double.longBitsToDouble(0x3fef195a1eab3ef3L), Double.longBitsToDouble(0x3fbc89f3b7662b00L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 3, "\ud940\uddc0\udb27\udc82\udaed\udf49\udb8c\udf71\udbd9\ude1b", "\u893b\u14a0\u321f\u5a67\ucfbc\u039f\u0701\u417b\u880d\uab0f\ub34d\u4bf1\u92c4\uab31\uc8fc\u04b3", "\ud85d\udc45\udbd8\udd54\015\ud8e0\udc0e\udba4\udc83\udb62\uded0\ud866\ude9e\ud9b0\udca7",
        10, 89718, 1287116219, 404485817690680476L, -37349L, true, false, (char) 6933, (char) 55246,
        Double.longBitsToDouble(0x3fe831999342bfd3L), Double.longBitsToDouble(0x3fe03431e0c079f6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 6, 3, "\u4f59\ud8ab\udd70\uda5c\udeb4\u68e1\ud9d4\udefc", "\u2c31\u6401\u68d9\ub3cc\ud67b", "\uda4a\udc61\ud944\uddb7\udbb6\ude79\udbc0\udcc8\ud80b\ude05\udaa9\udfc5\udb3e\udf7a\u2430",
        41, 17574, 134333327, -2664479017449206829L, 19580L, true, false, (char) 41391, (char) 5928,
        Double.longBitsToDouble(0x3fc5352a20e78f38L), Double.longBitsToDouble(0x3fe4f317412c854aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream|static",
    "C|org.jsoup.helper.DataUtil|<init>|",
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
