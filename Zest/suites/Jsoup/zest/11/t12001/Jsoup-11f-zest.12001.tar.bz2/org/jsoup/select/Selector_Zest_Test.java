package org.jsoup.select;
import org.junit.Test;
import static org.junit.Assert.*;
public class Selector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 4, 19, "\udb00\udd87\udb8d\udc07\uda9b\udf9e\udaf7\udc20\udb53\udfc5\ud92d\uddde\uda14\ude36\ud92e\uddfa\ud9de\udf38\ud988\udd9b\ud9f8\udc6f\ud888\uddf2\ud907\ude3d", "\ubc41\u5c74\u4f70\u2827\u143f\u7b60\ub8d7\ua4e0\u2b0e\u384e\ub321\u0b8a\u427c\u5ccd\u2cf4\u5627\u1ecf\u42e0\u0aab\ua01c\u0294\u31c8\u7418\ucded\u5ed6\u9e50\u8eaf", "\u0c0d\u3eb7\udbff\ude26\udbea\udc22\ud843\udd96\udb4a\udd20\ud821\ude61\udbdb\udf6a\ud9f0\udc62\uda4d\udc1f",
        42, 86756, -1770416197, -1346049520047110579L, -98394L, false, true, (char) 17696, (char) 54883,
        Double.longBitsToDouble(0x3fed91aba7167f87L), Double.longBitsToDouble(0x3fdd4e354e679574L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 9, 19, "\udb00\udd87\udb8d\udc07\uda9b\udf9e\udaf7\udc20\udb53\udfc5\ud92d\uddde\uda14\ude36\ud92e\uddfa\ud9de\udf38\ud988\udd9b\ud9f8\udc6f\ud888\uddf2\ud907\ude3d", "\ubc41\u5c74\u10eb\u284c\u143f\u7b60\ub8d7\ua4e0\u2b0e\u384e\ub321\u0b8a\u427c\u5ccd\u2cf4\u5627\u1ecf\u42e0\u0aab\ua01c\u0294\u31c8\u7418\ucded\u5ed6\u9e50\u8eaf", "\u0c0d\u3eb7\udbff\ude26\udbea\udc22\ud843\udd96\udb4a\udd20\ud821\ude61\udbdb\udf6a\ud9f0\udc62\uda4d\udc1f",
        42, 86756, -1770416197, -1346049520047110579L, -98394L, false, true, (char) 17696, (char) 54883,
        Double.longBitsToDouble(0x3fed91aba7167f87L), Double.longBitsToDouble(0x3fdd4e354e679574L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 4, 19, "\udb00\udd87\udb8d\udc07\ud82f\udfad\udaf7\udc20\udb38\udcc5\udaa7\udf2b\udbf6\ude77\uda63\udc6c\udb2f\udee8\ud988\udd9b\ud9f8\udc6f\ud888\uddf2\ud907\ude3d", "\ubc41\u5c74\u1614\u5a7a\ub774\uc498\ub8d7\u7578\u8237\u384e\ub321\u0b8a\u427c\u5ccd\u2cf4\u5627\u83ff\u0747\u0a9a\ua01c\u63af\uc391\uce20\u13b2\u5ed6\u9e50\u8eaf", "\u0c0d\u3eb7\udbff\ude26\udbd1\udeb1\ud843\udd96\udb4a\udd20\uda9c\udf5f\uda0f\ude68\u1a9d\ud81c\udc42",
        49, 86756, 997824443, -5633833685107999252L, -65133L, true, true, (char) 10534, (char) 63133,
        Double.longBitsToDouble(0x3fdd4e354e679574L), Double.longBitsToDouble(0x3fe67ea297117e74L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 4, 19, "\udb00\udd51\udb8d\udc07\uda9b\udf9e\udaf7\udc20\udb53\udfc5\uda3c\udf27\ud93e\udc6e\ud87a\udfa3\udac9\ude4d\udab4\uddc6\ud9f8\udc6f\ud888\uddf2\ud907\ude3d", "\ubc41\u5c74\u4f70\u2827\u143f\u7b60\ub8d7\u9854\u9122\u384e\ub321\u0b8a\u427c\u5ccd\u2cf4\u5627\u1ecf\u42e0\u0aab\ua01c\u0294\u31c8\u1018\ucded\u5ed6\u9e50\u8eaf", "\u0c0d\u3eb7\udbff\ude26\udbea\udc22\ud843\udd96\udb4a\udd20\ud821\ude61\udbdb\udf6a\ud9f0\udc62\udba6\udf7f",
        -4, 56362, 412100395, -1346017999282125235L, -98394L, false, true, (char) 17696, (char) 54883,
        Double.longBitsToDouble(0x3fed91aba7167f87L), Double.longBitsToDouble(0x3fdd4e354e679574L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 16, 16, 19, "\ud823\ude59\000\000\000\uda40\udf1f\uda43\udfea\ud9ea\uddb4\ud92e\uddfa\uec86\ud812\udc08\000\000\000", "", "\udb54\ude18",
        1, -1000, 82, 61759568132226163L, -34464L, true, false, (char) 18353, (char) 21433,
        Double.longBitsToDouble(0x3feb1803decef3b1L), Double.longBitsToDouble(0x3ea8622730000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 4, 4, 19, "\udb00\udd87\udb8d\udc07\uda9b\udf9e\udaf7\udc20\udb53\udfc5\ud92d\uddde\uda14\ude36\ud854\udded\ud9de\udf38\ud988\udd9b\ud9f8\udc6f\ud888\uddf2\ud907\ude3d", "\ubc41\u5c74\u4f70\u2827\u143f\u7b60\ub8d7\ua4e0\u2b0e\u384e\ub321\u0b8a\u286f\u5ccd\u6602\u4d91\u1ecf\u42e0\u0aab\ua01c\u0294\u31c8\u7418\ucded\u5ed6\u9e50\u8eaf", "\u0c0d\u3eb7\udbff\ude26\udbea\udc22\ud843\udd96\udb4a\udd20\ud821\ude61\udbdb\udf6a\ud9f0\udc62\uda4d\udc1f",
        42, 86756, -1770416197, 2112714993773430349L, -90202L, false, true, (char) 9279, (char) 54883,
        Double.longBitsToDouble(0x3fe57463a7167f8cL), Double.longBitsToDouble(0x3fdd4e354e679574L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 19, 19, "\udb1f\udc47\udb8d\udc07", "\u63ad\uafd0\u82cd\u5b5f\u458a\u1f4c\u3514", "\uda42\udcf3\ud894\udef4\ud825\udfc9\udbe5\uddd7\u5e78\ud829\udfef\udadb\udffc\ud892\udfbe\udb08\udde1\ud833\udf8c\ud8cd\udd4b\udaa0\udc78\uda40\udc35\uda02\ude31\ud879\ude4c\ud944\udea9\udbb7\udec8",
        55, 79034, -1513296440, 7038034300979012714L, 3093L, false, true, (char) 3540, (char) 673,
        Double.longBitsToDouble(0x3fc81b4f111eaa3cL), Double.longBitsToDouble(0x3fbcaf1d8881e970L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 4, 19, "\ud9f6\udc14\udbb3\udce7\uda9b\udf9e\udaf7\udc20\udb53\udfc5\ud92d\uddde\uda14\ude36\ud92e\uddfa\ud9de\udf38\ud988\udd9b\ud9f8\udc6f\ud888\uddf2\udbce\ude4e", "\ubc41\u0cfb\u3772\u2827\u143f\u7b60\ub8d7\ua4e0\u2b0e\u384e\ub321\u9d03\u42e3\u5ccd\u2cf4\u0169\u0c0f\u43d7\u5645\ua18d\u0247\u43db\u7345\ud357\u5f39\u9e50\u8eaf\u85db\u9429\uc8f4\u7abd\u9f4a\u7665\ud7bc", "\udbdb\udf6a\ud9f0\udc62\uda14\udca2\udb4e\ude6e\ud822\udeaa\u0ad7\ud885\uddfe\ud9a5\udc26\udb11\udd73\udaf2\udce3\ud8fe\udd01\ud815\udf05\udb07\udc54\ud8cf\ude3f\ud99c\uded3\udbde\udf35\ud9bd\udd65\ud99c\udfa4\ud8d3\udc6a\udbc6\udd7f\uda23\udea8\ud811\udf1b",
        26, 86026, -377157468, 8464226139629319913L, -4932L, true, false, (char) 12661, (char) 14683,
        Double.longBitsToDouble(0x3fdce54028e9e8c8L), Double.longBitsToDouble(0x3fdc74086588b3baL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 13, 0, "", "\u6f5d", "\udaa7\ude31\udbf6\ude77\uda63\udc6c\udb2f\udee8",
        12, 64083, -146589066, 2690474209049764751L, 35834L, false, false, (char) 29486, (char) 3719,
        Double.longBitsToDouble(0x3fd56fa6feeedb92L), Double.longBitsToDouble(0x3fe65ae0a47384dbL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 17, 4, 19, "\udb00\udd87\udb8d\udc07\uda9b\udf9e\udaf7\udc20\udb53\udfc5\ud92d\uddde\uda14\ude36\ud92e\uddfa\ud9de\udf38\ud988\udd9b\ud9f8\udc6f\ud888\uddf2\ud907\ude3d", "\ubc41\u5c74\u4f70\u2827\u143f\u7b60\ub8d7\ua4e0\u2b0e\u384e\ub321\u0b8a\u427c\u5ccd\u2cf4\u5627\u1ecf\u42e0\u0aab\ua01c\u0294\u31c8\u7418\ucded\u5ed6\u9e50\u8eaf", "\u0c0d\u3eb7\udbff\ude26\udbea\udc22\ud843\udd96\udb43\udf4c\ud821\ude61\udbdb\udf6a\ud9f0\udc62\uda4d\udc1f",
        42, 86756, -1770416197, -1346049520047110579L, -98394L, false, true, (char) 17696, (char) 54883,
        Double.longBitsToDouble(0x3fed91aba7167f87L), Double.longBitsToDouble(0x3fdd4e354e679574L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.select.Selector|filterOut|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|findElements||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|not||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|select||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|select|java.lang.String,java.lang.Iterable|static",
    "M|org.jsoup.select.Selector|select|java.lang.String,org.jsoup.nodes.Element|static",
    "M|org.jsoup.select.Selector|addElements|java.util.Collection|new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|allElements||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|byAttribute||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|byClass||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|byId||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|byTag||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|combinator|java.lang.String|new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|consumeIndex||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|contains|boolean|new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|filterForAdjacentSiblings|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|filterOut|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|findElements||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|not||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|select||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|select|java.lang.String,java.lang.Iterable|static",
    "M|org.jsoup.select.Selector|select|java.lang.String,org.jsoup.nodes.Element|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
