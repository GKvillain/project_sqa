package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Entities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 10, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        16, 70088, -1296686451, -2993718438765947356L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 4, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udae8\udce2\uda3c\udc40\udaa4\udf5d\udaab\udcb1\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u3986", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        16, 70088, -1296686451, -2993718438765947356L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 10, 10, 3, "\uda2c\ude58\uda44\uddcd\udbc1\udff1", "\uad5b\u92cf", "\udb52\uddb0\udaef\ude95\ud99e\udcf8\ud914\udcd5\ud8e3\udd43\udb76\udfe9\ud8ac\udd16\udaa4\udf4b\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf",
        32, 42965, 370387423, -857552350820259802L, -49694L, false, false, (char) 41757, (char) 22454,
        Double.longBitsToDouble(0x3fdb2217a0614d7cL), Double.longBitsToDouble(0x3fdaa6535e5d3ef6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 8, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\ud8cc\ude7e\ud9cb\udd62\uda6a\udd8a\ub5b9\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        16, 70088, -1296686451, -2993718438765947356L, -31998L, true, false, (char) 31891, (char) 16290,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 10, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\u7681\udaa7\ude53\ud8cc\udc6e\ud8fe\udfab\udb88\udcb0\udaef\ude95\ud9fc\udcb8\ud928\udc7d\udbdc\udfeb\udad0\udd5a\uda3c\udc40\udaa4\udf5d\udbd5\udf2d\udb95\udc97\udab9\udc56\udbcd\udd1a\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\udb8b\udc08", "\u33e5", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\udab5\udfe3\ud939\udd62\ud83e\udc2b\uda96\udc11\ud9ac\udc66\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud8dd\udfb0\u56cb\udb5b\ude04",
        16, 70088, -1296686451, -2993718438765947356L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe9c5903b926513L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 7, 9, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\uda8a\udd9b\udb05\udd72\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\ud9f0\udd0b\udb96\udf80\udaa4\udf04\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        16, 70088, -1296686451, -2993718438765947356L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\uda2c\ude58\uda44\uddcd\udbc1\udff1\ud88d\ude1e\udb05\udd6e\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb69\udd1b\ud94f\udc23\ud896\udf28\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\udbb5\uddb9\uea1d\ud8a8\uddbf\uda28\ude7f\ud84d\udcc3\ud808\udc45\udbab\udf38\ud834\udf64\012",
        Z.run(T, 1, 8, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\ud88d\ude1e\udb05\udd6e\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb69\udd1b\ud94f\udc23\ud896\udf28\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\udbb5\uddb9\uea1d\ud8a8\uddbf\uda28\ude7f\ud84d\udcc3\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5\u042b\u6baa\u0b4c\u3f86\u3916\u0951\ucd9d", "\ud8cc\udc91",
        17, 89087, -523926936, 5164879785533447193L, -68062L, true, false, (char) 3325, (char) 12238,
        Double.longBitsToDouble(0x3fefa4b9d37bd1d3L), Double.longBitsToDouble(0x3fe198a7fbfe0266L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 2, "\uda2c\ude58\uda44\uddcd\uf859\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\uda63\udcf3\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\ud230\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5", "\ud880\udd0c\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud961\udf66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\uddf0\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud989\udda0\u288b\ud8b4\udf04\udae9\ude60\udae5\uddf6\udad7\udcc9\udb02\udce3\udbe3\uddc8\ud8ad\udc0e",
        41, 93696, -1296686451, -2993503170710104540L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d3b1f0910L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\udab1\udcf6\uda55\udcf6\udbc1\udf77\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uf1e9\ud87d\udd9a\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\ud9a9\udc9c\udb09\uddd5\ud835\udd8e\ud9a9\ude6e\uea32\ud8a8\uddbf\udbd4\ude15\udbbe\udc10\ud808\udc45\udbab\udf38\ud834\udf31\012",
        Z.run(T, 1, 9, 2, 2, "\udab1\udcf6\uda55\udcf6\udbc1\udf77\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uf1e9\ud87d\udd9a\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\ud9a9\udc9c\udb09\uddd5\ud835\udd8e\ud9a9\ude6e\uea32\ud8a8\uddbf\udbd4\ude15\udbbe\udc10\ud808\udc45\udbab\udf38\ud834\udf31", "\u33e5", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\udbc0\ude7d\udb1a\udd07\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        16, 70088, -1296686451, -2993718438765947356L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 2, 9, 9, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\ud91e\ude07\uda60\udc90\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud953\udf63\ud8b8\udc62\udb21\udd37\udbc3\udf1c\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\ud9e6\udf7f\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud925\uddb4\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\udb4d\udcda\ud98b\udff7\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        16, 70088, 2053005766, 6673502545023964917L, 94142L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 7, "\uda2c\ude58\uda44\uddcd\udbae\udc37", "\u9cff\ubbd7", "\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\u0f9c\udad4\ude41\udb86\udf17\ud866\udfb2\ud8b5\udc1b",
        4, 98722, 370388728, -6672825369662412672L, -49715L, false, false, (char) 41757, (char) 22454,
        Double.longBitsToDouble(0x3fee790bd404dd55L), Double.longBitsToDouble(0x3faaff0a13ba0c00L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 2, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68", "\u92cf\u0f06\u9768\ua584\ud321\u775b\u41d1\ub7dd\u442f\u3da4\u8a02\u5ad1\u7f81\u302a\ucc73\u35f1\u0610\u44bb", "\ud808\udc45\udbab\udf38\ud834\udf64\udb30\udf53\udac0\udf06\udb03\udef3\udafd\udd95\udbca\udc0f",
        12, 86577, 1406940594, 8390342658383414914L, -18314L, false, true, (char) 51889, (char) 65081,
        Double.longBitsToDouble(0x3fe7296c2ecde0eeL), Double.longBitsToDouble(0x3f9947adfcdb8a20L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\uda2c\ude0b\uda44\uddcd\udbc1\udff1\012",
        Z.run(T, 1, 8, 2, 2, "\uda2c\ude0b\uda44\uddcd\udbc1\udff1", "\u05a7\u92cf", "\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud8cb\udc8c\ud801\udc89\ud8b9\udd72\ud96d\udf71\uda6f\udfb7\ud8f3\ude8a\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf",
        45, 98722, 370388728, -6672825369662412672L, -43550L, false, false, (char) 41588, (char) 22454,
        Double.longBitsToDouble(0x3fdb2217a864a7b8L), Double.longBitsToDouble(0x3fe413a3813ba0c0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 8, "\udb40\ude01\udb48\uddcf\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca", "\u9768\u2b25\u58a9\u775b\u41d1\ub7dd\u46b7", "\udaab\udcb1\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32",
        45, 30894, -1263410278, 1590807472013401262L, 39894L, false, true, (char) 62585, (char) 6264,
        Double.longBitsToDouble(0x3fe0a27a55b2217aL), Double.longBitsToDouble(0x3fa929ee68274700L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 2, 2, "\udb87\udea5\uda3f\udd15\udbc1\udff1\udaa7\udc6b\udb05\uddb5\ud8e7\udec6\ud8fc\udfcc\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udae8\udce2\uda3c\udc40\udaa4\ude90\udaab\udcb1\udb8d\udf1d\ud953\udf63\udab5\udc76\udb55\ude04\ud97f\udfe5\ud8a8\ude39\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u3986", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf20\u18e5\udb8a\udf09\ud96a\udce3\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\udafd\udcb7\uda39\udcda\ud9a7\udf28\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\ud8bc\uddaf",
        8, 70088, -1163124083, 8478490411321072625L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udae8\udce2\uda3c\udc40\udaa4\udf5d\ud82f\udc32\udb61\udd1e\ud92e\udd11\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\udb58\udf36", "\u3986", "\udaf5\udc23\ud82d\udebc\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud996\udd0c\udaeb\udf0a\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud846\udd7d\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        8, 70088, -1296686451, 8085418119542183568L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6666L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udae8\udce2\uda3c\udc40\udaa4\udf5d\udaab\udcb1\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u3986", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udbc0\udf87\ud8de\udd10\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        16, 70088, -1296686451, 4644386531113060784L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\udbf9\udfc5\ud8b4\ude17\udbc0\udd6d\ud829\ude7d\udb05\uddb5\ud94f\udf63\uda1b\udf44\udaa5\udcf0\ud81a\udedf\uda1d\udeac\udb63\udfb1\ud9f9\ude5e\ud916\ude03\012",
        Z.run(T, 1, 8, 3, 9, "\udbf9\udfc5\ud8b4\ude17\udbc0\udd6d\ud829\ude7d\udb05\uddb5\ud94f\udf63\uda1b\udf44\udaa5\udcf0\ud81a\udedf\uda1d\udeac\udb63\udfb1\ud9f9\ude5e\ud916\ude03", "\u3d3c\u89f0\uc4c2\ub773", "\ub153\uea17\uda8e\udf39\ud913\udfd1",
        0, 4348, -190386558, -4606434587674939948L, 55494L, false, true, (char) 28087, (char) 11213,
        Double.longBitsToDouble(0x3fe24d1c620be532L), Double.longBitsToDouble(0x3fef02aaa9aa6535L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 10, 10, 3, "\uda2c\ude58\uda44\uddcd\udbc1\udff1", "\u8d04", "\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udcf8\ud8e7\udfd5\ud8e3\udd43\udb76\udfe9\ud8ac\udd16\udaa4\udf4b\uda42\udcb9",
        54, 94630, -119329566, -31289397666096094L, 75402L, true, false, (char) 22172, (char) 29377,
        Double.longBitsToDouble(0x3fe507b0cf83310eL), Double.longBitsToDouble(0x3fd1af4aa5632608L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 3, "\uda2c\ude58\uda6c\udf55\udbc1\udff1", "\uad5b\u926c", "\udb52\uddb0\udaef\ude95\ud99e\udcf8\u09d1\ud816\uddef\ud87a\udc4a\udb89\udece\udaa4\udf4b\uda8a\udfbe\ud91c\udcc4\ud953\udf63\udab5\udc76\ud930\ude71\u4d99\ud8a8\uddbf",
        32, 42965, 370387423, -857552350820259802L, -49694L, false, false, (char) 41757, (char) 22454,
        Double.longBitsToDouble(0x3fdb2217a1454d7cL), Double.longBitsToDouble(0x3fdaa6535e5d3ef6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 10, 3, "\uda2c\ude58\uda44\uddcd\udbc1\udff1", "\uad5b\u92cf", "\udb52\uddb0\udaef\ude95\ud99e\udcf8\ud914\udcd5\ud888\udf55\000\ud88a\udde4\udaa4\udf4b\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\u5c22\000",
        32, 42965, 370387423, -857552350820259802L, -49694L, false, false, (char) 41757, (char) 22454,
        Double.longBitsToDouble(0x3f20bd030a6be000L), Double.longBitsToDouble(0x3fdaa6535e5d3ef6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 7, 5, 11, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5\u94b0\u6baa\u0b4c\u3f86\u802b\u2e33\ucd9d\u7713\u92af\u0263\u15b9\u9b7a\ud611\ua3c0\u39ce\u21d0", "\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\ud8cc\ude7e\ud9cb\udd62\uda6a\udd8a",
        8, 29709, -801587141, -897785520133704009L, 34605L, false, false, (char) 850, (char) 9782,
        Double.longBitsToDouble(0x3fb1ace4797d9038L), Double.longBitsToDouble(0x3fec93289eeceef2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 2, "\udba5\udc59\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\udda7\uda5e\udf45\ud98f\udcc7\uefe7\ud904\udef7\udb52\ude03\udaef\ude95\ud99e\udca9\ud852\udfb5\ud940\udc1f\udad0\udd5a\ud8d6\udc4c\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud953\udf63\uda06\udd1e\udb19\ude0f\uc451\udaf3\udd24\uda2e\udedc\ud8b4\udf77\udb13\udf38\u0991\ud834\udf64", "\u33e5\u94b0\u6baa\u0b4c", "\udb46\udc45\u195d\udba9\uddf0\ud931\uddc9\udaa6\ude5d",
        13, 99777, -521266459, 5164879785533447193L, -68062L, true, false, (char) 3325, (char) 12238,
        Double.longBitsToDouble(0x3fdf497927f311a6L), Double.longBitsToDouble(0x3fe5e3b7f8d3a538L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\u7681\udaa7\ude53\ud8cc\udc6e\ud8fe\udfab\udb88\udcb0\udaef\ude95\ud9fc\udcb8\ud928\udc7d\udbdc\udfeb\udad0\udd5a\uda3c\udc40\udaa4\udf5d\udbd5\udf2d\udb95\udc97\udab9\udc56\udbcd\udd1a\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\udb8b\udc08\udb47\udf05\udac0\udf06\udb03\udef3\udafd\udd95\udbca\udc0f\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06", "\ub650", "\ud943\udd35",
        49, 70939, 40282675, 2917079107668079744L, 14747L, true, true, (char) 59969, (char) 64054,
        Double.longBitsToDouble(0x3fe085bf228d740cL), Double.longBitsToDouble(0x3fce3656d89359d0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\u7681\udaa7\ude53\ud8cc\udc6e\ud8fe\udfab\udb88\udcb0\udaef\ude95\ud9fc\udcb8\ud928\udc7d\udbdc\udfeb\udad0\udd5a\uda3c\udc40\udaa4\udf5d\udbd5\udf2d\udb87\udd97\udab9\udc56\udbcd\udd1a\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud8a0\udc32\udbab\udf38\udb8b\udc08", "\u33e5", "\ud8a6\ude5b\uda35\udeb1\ud8ec\udf02\uda9a\udf62\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\udab5\udfe3\ud939\udd62\ud83e\udc2b\uda96\udc11\ud9ac\udc66\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud8dd\udfb0\u56cb\ud988\udc1c",
        29, 52312, -1985829416, -2961573877025499612L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe9c5903b926513L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 0, "\uda2c\ude58\uda44\uddcd\uda1c\udcdf\udba8\udc74\udb05\uddb5\u7681\udaa7\ude53\ud8cc\udc6e\ud8fe\udfab\udb88\udcb0\udaef\ude95\ud9fc\udcb8\ud928\udc7d\000\000\000\udaa4\udf5d\udbd5\udf2d\udb95\udc97\udab9\udc56\udbcd\udd1a\ud9a9\ude6e\u8632\udb1d\ude39\uda13\udfa9\udb97\udf29\ud808\udc45\udbab\udf38\udb8b\udc08", "\u33e5", "\ud8a6\ude5b\ue1d2\udbe7\uddbe\000\u1863\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\udab5\udfe3\ud939\udd62\ud83e\udc2b\uda96\udc11\ud931\udc68\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude24\udae9\ude60\ud81d\udfef\udad7\udcc9\ud8dd\udfb0\u56cb\udb5b\ude04",
        16, 70088, 0, -2993767852364687836L, 94304L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe9c5903b926513L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 10, 10, 1, "\uda2c\ude58\uda44\uddcd\udb49\udda6\udb3f\udc81\udb05\uddb5\u7681\udaa7\ude53\ud899\uddf5\ud910\udd59\udb88\udcb0\udaef\ude95\ud9fc\udcb8\ud928\udc7d\udbdc\udfeb", "\u8a15\uc626\u9cd2\uaad5\u19ab\u3625\u0610\ud1bb\u940b\u6259\u5922\u9eec\u5079\u0a73\u9a28\u33e5\u94b0\u5d0c\u0bbd\uab20\ucfb6\u506e", "\ud96a\udd66\ud8a9\udfb1",
        32, 99687, -521266459, 5164879785533483518L, -68062L, true, false, (char) 4306, (char) 12238,
        Double.longBitsToDouble(0x3fd01b63a6f7a3a6L), Double.longBitsToDouble(0x3fe198a7fbfe0266L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\u7681\udaa7\ude53\ud8cc\udc6e\ud8fe\udfab\udb88\udcb0\udaef\ude95\ud9fc\udcb8\ud928\udc7d\udbdc\udfeb\udad0\udd5a\uda3c\udc40\udaa4\udf5d\udbd5\udf2d\u8264\udae0\udda0\ud895\ude2a\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\udb8b\udc08", "\u33e5", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\uda75\udffb\udbae\udd81\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\udab5\udfe3\ud939\udd62\ud83e\udc2b\uda96\udc11\ud9ac\udc66\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud8dd\udfb0\u56cb\udb5b\ude04",
        16, 70088, -1296686451, -2993718438765947356L, -31998L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe9c5903b9261d9L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=java.lang.String:\uda2c\ude58\uda44\uddcd\udbc1\udff1\udb17\udd22\ud9ba\udc53\012",
        Z.run(T, 2, 10, 8, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udb17\udd22\ud9ba\udc53", "\u0f06\u0c17\u4115\u588b\ud08a\u4f12\u5894\ubf2e\u0305\u8a02\u0b02\u9cfb\uaad5\ud550", "\udb4c\ude72\uda20\udcb3\udb97\udf29\u5aed\udbcf\udfd5\udaf0\udca1\ud979\udc08\ud9ae\udfc1\ud934\udc37\udaf9\udc9d\udbca\udc0f\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\uda62\udc05\ud992\ude35\ud8de\udd10",
        38, 99158, 1918238694, -1679143243650624004L, 1534L, true, true, (char) 56654, (char) 56625,
        Double.longBitsToDouble(0x3feff2793f06287bL), Double.longBitsToDouble(0x3fe4897da03b6d04L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\u0aa4\012",
        Z.run(T, 1, 8, 2, 2, "\u0aa4", "\u676b\u70af\u05a7\u92cf\u0f06\u9768\u1fe3\u1851\u69c1\u41d1\ub7dd\u3812\u4897\u8a02\u00d1\u7f81", "",
        27, 90661, 50, -432345563897142374L, -10738L, false, false, (char) 20270, (char) 32899,
        Double.longBitsToDouble(0x3fe3b06b78000076L), Double.longBitsToDouble(0x3fc6c000187fd3f8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\uda3f\udfa2\012",
        Z.run(T, 1, 8, 2, 2, "\uda3f\udfa2", "\u8088\u7134\u05a7\u92cf\u0f06\u9768\u1fe3", "\uda2c\ude21\udacf\udcae",
        40, 90280, -139363365, -6201244684381212177L, 97740L, true, false, (char) 7359, (char) 40317,
        Double.longBitsToDouble(0x3fe6b5a4239afa45L), Double.longBitsToDouble(0x3fdf313b195cb68eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\uda2c\ude58\ud8e1\udd28\ud830\udf5e\ud8c3\ude6d\udb05\udd6e\udb9c\uded6\udaab\ude69\ud9ae\udf20\u60ae\udacf\udfac\ud94f\udc23\ud894\udf28\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud815\udf05\udab5\udc76\udbb5\uddb9\uea1d\ud927\udc90\uda28\ude7f\ud9e5\udecc\ud808\udc45\udbc9\udf7f\udb3b\udcdc\uda1c\udfaa\udac0\udf06\udb03\udef3\ub9c2\udbca\udc4a\ud8a6\ude5b\ue1d2\ud872\udea3\ud995\udca0\ud8fc\uddff\ud945\udc5d\ud96a\udd66\ud8cc\udc91\012",
        Z.run(T, 1, 8, 10, 2, "\uda2c\ude58\ud8e1\udd28\ud830\udf5e\ud8c3\ude6d\udb05\udd6e\udb9c\uded6\udaab\ude69\ud9ae\udf20\u60ae\udacf\udfac\ud94f\udc23\ud894\udf28\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\ud815\udf05\udab5\udc76\udbb5\uddb9\uea1d\ud927\udc90\uda28\ude7f\ud9e5\udecc\ud808\udc45\udbc9\udf7f\udb3b\udcdc\uda1c\udfaa\udac0\udf06\udb03\udef3\ub9c2\udbca\udc4a\ud8a6\ude5b\ue1d2\ud872\udea3\ud995\udca0\ud8fc\uddff\ud945\udc5d\ud96a\udd66\ud8cc\udc91", "\ud56f\u61b3\u43b8", "\ud977\udcd8\u6ea5\ud996\udea0",
        2, 70939, 40282675, 7676539487024019278L, -94740L, true, false, (char) 49766, (char) 61098,
        Double.longBitsToDouble(0x3fe28c4a331688b3L), Double.longBitsToDouble(0x3fe8e6b8b1f0d5f0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 8, 2, 2, "", "\uaf36", "",
        32, 57428, 13072, 503321418L, -87896L, true, true, (char) 39531, (char) 56552,
        Double.longBitsToDouble(0x3fa410cb3dbbdc10L), Double.longBitsToDouble(0x3fca3ef63fbea7c0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\uda2c\ude58\uda44\uddcd\uf859\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\uda63\udcf3\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\udbc6\udddd\ud814\uddbf\ud919\udddc\ud230\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 2, "\uda2c\ude58\uda44\uddcd\uf859\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\uda63\udcf3\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\udbc6\udddd\ud814\uddbf\ud919\udddc\ud230\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5", "\ud880\udd0c\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud961\udf66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\uddf0\ud939\udc87\ud83e\udc2b\ud977\udcd8\udaa0\udc06\ud943\udd35\ud989\udda0\u288b\ud8b4\udf04\udae9\ude60\udae5\uddf6\udad7\udcfe\udb02\udce3\udbe3\uddc8\ud8ad\udc0e",
        41, 93696, -1296686451, -2993503170699815388L, 94142L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3feb009e9d8f8488L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 2, 2, "\ud828\udd9a\ud8df\udfdd\udbc1\udfd6\ud8e3\udcc8\udaf1\udeee\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uf1e9\ud87d\udd9a\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\ud9a9\udc9c\udb09\uddd5\ud835\udd8e\ud9a9\ude6e\uea32\ud8a8\uddbf\udbd4\ude15\udbbe\udc10\ud808\udc45\udbab\udf38\ud834\udf31", "\u0773", "\ud8a6\ude5b\udaf5\udc71\ud8a0\udfb8\uda9a\udf0e\ud9f2\udcda\udba9\uddf0\ud96a\udd66\uda9c\udfab",
        2, 99687, -521266459, 5164879787580267545L, -68062L, true, false, (char) 3325, (char) 50208,
        Double.longBitsToDouble(0x3fdf4970c6f7a3a6L), Double.longBitsToDouble(0x3fe198a7fbfe0266L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 2, 9, 9, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95", "\ub7ddL\u7094\u8a02\u5ad1\u7f81\u302a\ud14e\ua457\u554c", "\udb97\udf29\ud808\udc45",
        24, 95224, 1481055776, 968179618583814774L, 8362L, true, false, (char) 57, (char) 22316,
        Double.longBitsToDouble(0x3fa929ee68274700L), Double.longBitsToDouble(0x3fae50600ea37610L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\uda2c\ude58\uda44\uddcd\ud950\udd5a\udb24\ude6c\ud8a9\ude5d\ud854\udd1b\ud941\udda0\udbbb\udf77\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\ud91e\ude07\uda49\udd25\ud8a2\udc61\uda62\ude6c\udb8d\udf1d\uda95\ude4e\ud962\udd3a\ud86c\uddce\ud865\udf36\udb52\udf22\udba2\udc08\udb58\udf19\ud808\udc45\udbab\udf38\ud834\udf64\0121=java.lang.String:\uda2c\ude58\uda44\uddcd\ud950\udd5a\udb24\ude6c\ud8a9\ude5d\ud854\udd1b\ud941\udda0\udbbb\udf77\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\ud91e\ude07\uda49\udd25\ud8a2\udc61\uda62\ude6c\udb8d\udf1d\uda95\ude4e\ud962\udd3a\ud86c\uddce\ud865\udf36\udb52\udf22\udba2\udc08\udb58\udf19\ud808\udc45\udbab\udf38\ud834\udf64\012",
        Z.run(T, 2, 8, 9, 9, "\uda2c\ude58\uda44\uddcd\ud950\udd5a\udb24\ude6c\ud8a9\ude5d\ud854\udd1b\ud941\udda0\udbbb\udf77\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\ud91e\ude07\uda49\udd25\ud8a2\udc61\uda62\ude6c\udb8d\udf1d\uda95\ude4e\ud962\udd3a\ud86c\uddce\ud865\udf36\udb52\udf22\udba2\udc08\udb58\udf19\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5\u94b0\u6baa\u0b4c\u3f86\u43e1\u844d\ucb3b\ua153\u92af\u92d0\u4d46\u9b7a\ud1eb\ua3c0\u39ce\u2555\ub650\u5dc3\u53ef\u6018\u3f80\u7751\u6d0b\ua662\u7d86\ub792\u4786\u1ea8\ua26a", "\ud86f\udce6\ud8b0\udcaa\udba7\udeb5",
        45, 55922, -1739961499, 6891585316676952027L, -58086L, true, true, (char) 32933, (char) 34801,
        Double.longBitsToDouble(0x3fc5feffa9a28784L), Double.longBitsToDouble(0x3fb4370971966958L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 9, 9, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\ud91e\ude07\udb56\ude5e\udabc\uddde\uda8a\udfbe\udbb4\uddb1\ud953\udf63\ud8b8\udc62\udb21\udd37\udbc3\udf1c\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\u33e5", "\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\ud9e6\udf7f\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udae7\udd86\ud925\uddb4\ud94a\udf06\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\udb4d\udcda\ud98b\udff7\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb5b\ude04",
        16, 70088, 2053005766, 6673502545023964917L, 94142L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\uda2c\ude58\uda44\uddcd\udbcf\udf37\0121=java.lang.String:\uda2c\ude58\uda44\uddcd\udbcf\udf37\012",
        Z.run(T, 2, 9, 9, 7, "\uda2c\ude58\uda44\uddcd\udbcf\udf37", "\u68c3\u2773", "\udb52\uddb0\ud81d\ude9b\uda2d\uddaf\ud8d9\udd7f\ud8a5\ude04\ud852\udfef\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\u0f9c\udad4\ude41\udb86\udf17\uda51\udf4f\ud9c7\udd21",
        -4, 98697, 370388728, -6672825369655334784L, -49715L, false, false, (char) 41757, (char) 22454,
        Double.longBitsToDouble(0x3fee790bd404dd55L), Double.longBitsToDouble(0x3faaff0a03ba0c00L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\0121=java.lang.String:\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\012",
        Z.run(T, 2, 8, 9, 10, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68", "\u13fa\u5a3b\u9768\u8985\ub4ea\u50ef\u41d1\ub7dd\u442f\u3da4\u8a02\u5ad1\u7f81\u302a\ucc73\u35f1\u0610\u44bb", "\ud808\udc45\udbab\udf38\ud834\udf64\udb30\udf53\udae7\udd9a\udb03\udebf\udafd\udd95\udb12\udf14\ud8a6\ude5b\ue1d2",
        54, 54690, -1598028284, -4022003385258557206L, 74593L, true, true, (char) 18538, (char) 14268,
        Double.longBitsToDouble(0x3f9909c8fcdb8a20L), Double.longBitsToDouble(0x3fd390ac47e6e3beL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 2, "\ud80f\udd69\uda44\ude34\ud8a2\ude49\uda8c\ude25", "\u92cf\u0f06\u9768\ua584\ud321\u775b\u41d1\ub7dd\u442f\u3da4\u8a02\u5ad1\u7f81\u302a\ucc73\u35f1\u0610\u44bb", "\ud808\udc45\udbab\udf38\ud834\udf64\udb30\udf53\udac0\udf06\udb03\udef3\udafd\udd95\udbca\udc0f",
        12, 86577, 1406940594, 8390342658383414914L, -18314L, false, true, (char) 51889, (char) 31545,
        Double.longBitsToDouble(0x3fe03e00fc93e0eeL), Double.longBitsToDouble(0x3fe46eb4e30dfe7fL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 0, "\udbab\udd77\ud8a4\udd08\udbc1\udff1\udaa1\udc68\u491d\u7728\udaa7\ude53\uda11\udf7a\ud8fe\udfab\udb88\udcb0\udaef\ude95\ud9fc\udcb8\ud928\udc7d\udbdc\udfeb\udad0\udd5a\uda3c\udc40\udaa4\udf5d\udbd5\udf2d\udb95\udc97\udab9\udc56\udbcd\udd1a\ud9a9\ude6e\uea32\udacc\ude01\uda28\ude7f\udb97\udf29\ud87a\udd63\udbab\udeec\udb26\udc14\udb47\udf05\udac0\udf06\udb03\udef3\udafd\udd95\udbca\udc0f\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud94d\udc3d\ud8a9\udf4f\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06", "\ud5f2\u247d\u29bf\uc734", "\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud8dd\udfb0\u56cb",
        3, -636, 1946947088, -5569225900908335887L, -17518L, false, true, (char) 4865, (char) 8177,
        Double.longBitsToDouble(0x3fd968d247c44654L), Double.longBitsToDouble(0x3fc197f4bb41e3f4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 2, 2, "", "\uae58\u6d0c\u5185\u0c78\u82b9\u0f06\u9768\000\u58a9\u8e2c\u4e58\u15e9\u871c\u3da4\u8a02\ud2c7\u65fb\000\ud526\u35f1\u0610\u0ebb\u940b\u0b9b", "\udb8b\udc08",
        35, 46364, -998890890, -7222863965204883274L, -32731L, false, false, (char) 15874, (char) 51889,
        Double.longBitsToDouble(0x3f4c204000000000L), Double.longBitsToDouble(0x3fe66f0771fe47adL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 2, 4, "", "\uae58\u6d0c\u5185\u0c78\u82b9\u0f06\u9768\000\u58a9\u8e2c\u4e58\u15e9\u871c\u1994\u9dd2\u908b\u65fb\000\ud526\u35f1\u0610\u0ebb\u940b\u0b9b", "\udb5d\udd99",
        35, 46364, -998890890, -7222863965204883274L, -51594L, true, true, (char) 42153, (char) 51889,
        Double.longBitsToDouble(0x3f83700000000000L), Double.longBitsToDouble(0x3fe66f0771fe47adL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 10, 6, 5, "", "\u6bad\u6d0c\u518b\u0c78\u82b9\u0f06\u9768\000\u58a9\u8e2c\u4e58\u15e9\u871c\u1994\u9dd2\u908b\u65fb\u758e\uaf85\u05c1\uab8a\ucae0\u905d\u389f", "\ud8af\udda2\udb47\udf05\ud8bb\udf11",
        24, 45934, -184657738, 5178486594384629721L, -51594L, true, true, (char) 18862, (char) 39654,
        Double.longBitsToDouble(0x3fe11c3768000000L), Double.longBitsToDouble(0x3fe66f0771fe47adL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 10, 2, 2, "\uda2c\ude58\uda44\uddcd\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud870\udf7e\udad0\udd5a\uda3c\udc40\udaa4\udf5d\uda8a\udfbe\udb8d\udf1d\uda0c\udd60\udab5\udc76\ud9a9\ude6e\uea32\ud8a8\uddbf\uda28\ude7f\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64", "\ub9eb", "\ud85a\udcb6\ud813\udc14\ud872\udea3\uda9a\udf0e\u18e5\udba9\uddf0\ud96a\udd66\ud8a9\udfb1\ud9c4\udc2d\udba3\udda4\ud8d1\udec2\ud94a\ude49\uda92\uddfe\ud939\udd62\ud83e\udc2b\ud977\udcd8",
        47, 25946, -774654476, 1512940622768957747L, -37408L, true, false, (char) 11583, (char) 15628,
        Double.longBitsToDouble(0x3fe5bf9c56467bf0L), Double.longBitsToDouble(0x3fe085bf228d740cL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:\uda30\ude51\uda4d\udfe3\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud8cb\udc8c\ud801\udc89\ud8b9\udd72\ud96d\udf71\uda6f\udfb7\ud8f3\ude8a\udaab\udd6a\udab5\udc76\ud978\ude95\ueae8\ud8a8\uddbf\ud951\ude83\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64\udb7f\ude8a\udaa5\udc17\ud8d9\udd3e\uda1d\udf67\udbf1\udc27\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\ud825\udd0d\ud85b\udfef\ua940\uda18\udeb4\udbcf\udcf9\uda5a\udc58\ud9f6\udf87\ud8e6\ude21\uda0c\ude3c\uc715\ud951\udcf4\ud92d\udc71\udb3e\udf2c\u7d45\ud9fe\udd50\ud974\udc54\u66d8\udb1f\udd26\ud87d\udd52\uda4f\udedf\uda4f\udf72\uc8fa\ud8f5\udfdd\udbb0\udf24\ud9f5\ude06\uda49\udf38\udb4d\udd7c\udafe\uddf4\ud89d\udeea\udb27\udf08\ud820\udfe9\udab4\udf10\ud83b\udc78\udb83\udd9e\012",
        Z.run(T, 1, 8, 6, 7, "\uda30\ude51\uda4d\udfe3\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\udaab\ude69\ud8cc\udc6e\ud8fe\udfab\udb52\uddb0\udaef\ude95\ud99e\udca9\uda2c\ude21\ud8cb\udc8c\ud801\udc89\ud8b9\udd72\ud96d\udf71\uda6f\udfb7\ud8f3\ude8a\udaab\udd6a\udab5\udc76\ud978\ude95\ueae8\ud8a8\uddbf\ud951\ude83\udb97\udf29\ud808\udc45\udbab\udf38\ud834\udf64\udb7f\ude8a\udaa5\udc17\ud8d9\udd3e\uda1d\udf67\udbf1\udc27\ud8a6\ude5b\ue1d2\ud872\udea3\uda9a\udf0e\u18e5\ud825\udd0d\ud85b\udfef\ua940\uda18\udeb4\udbcf\udcf9\uda5a\udc58\ud9f6\udf87\ud8e6\ude21\uda0c\ude3c\uc715\ud951\udcf4\ud92d\udc71\udb3e\udf2c\u7d45\ud9fe\udd50\ud974\udc54\u66d8\udb1f\udd26\ud87d\udd52\uda4f\udedf\uda4f\udf72\uc8fa\ud8f5\udfdd\udbb0\udf24\ud9f5\ude06\uda49\udf38\udb4d\udd7c\udafe\uddf4\ud89d\udeea\udb27\udf08\ud820\udfe9\udab4\udf10\ud83b\udc78\udb83\udd9e", "\u642e\u356c\u0970", "\uda0e\udecd\ud8cd\udf0a\uda9a\udd88\uda1f\udc6d",
        24, 31604, 1182123564, 8288849842879652477L, 30523L, false, true, (char) 5303, (char) 48233,
        Double.longBitsToDouble(0x3fd86779171b56ceL), Double.longBitsToDouble(0x3fe44b1df12d3676L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 7, 7, 11, "\ud9fd\udfbe\uda51\ude93", "\u1fb7\u1565\u82b9\u0f06\u9768\u3937\uaa90\u8e2c\u4e58\u67e8\u871c\u1994\u9dd2\u908b\ud00d", "\ud87f\uddd5\udac1\udc9d\ud92c\udf28\udb11\ude3f\udbe4\udc19\udadb\udd42\ud93a\ude36\ud8af\udda2\udb47\udf05\ud8bb\udf11\udb03\udf5b\udafd\udd95\udbca\udc0f\ud8a6\ude5b\uda35\ude0a\ud84d\udcff\udba3\udc49\ud8b3\udfd9\udaf2\udf6f\uda71\udc61",
        12, 53692, -1113016676, -2238850977147736373L, 20693L, false, false, (char) 30851, (char) 52432,
        Double.longBitsToDouble(0x3fe3400b51e3d23fL), Double.longBitsToDouble(0x3fdaa4a483f2e102L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:\udb40\ude01\udb48\uddcf\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\0121=java.lang.String:\udb40\ude01\udb48\uddcf\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca\012",
        Z.run(T, 2, 8, 8, 8, "\udb40\ude01\udb48\uddcf\udbc1\udff1\udaa1\udc68\udb05\uddb5\ud830\uddca", "\u9768\u2b25\u58a9\u775b\u41d1\ub7dd\u46b7", "\udaab\udcb1\udb8d\udf1d\ud953\udef1\udab4\udf97\ud9a9\ude6e\uea32",
        45, 30894, -1263410278, 1590807472013401262L, 39894L, false, true, (char) 62585, (char) 6264,
        Double.longBitsToDouble(0x3fe0a27a55b2217aL), Double.longBitsToDouble(0x3fa929ee68274700L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 7, 7, 11, "\ud9fd\udfbe\uda51\ude93\udb08\udd58\udb09\udda7\uda0d\udc54\udb35\ude8c\udaa7\ude53\ud8cc\udc6e\ud8fe\udfab\ud83b\udd2d\ud85d\udf7d\u8e2c\ud927\udfc3\udb2f\udf06\udb64\uddf1\udb61\udcd2\udb02\ude06\ud91d\udf22\ud9a4\udc86\ud939\udfa9\ud927\udf53\ud87f\uddd5", "\u905d\u389f\u4476\u1b61\ub2b1\u0a73\u2451\u344d\u94b0\u6baa\u0b4c\u87fc\ud622\ud342\u104f\u4629\ubac6\u65c4", "\ud8d7\udf11\udb87\uddf8\ud92d\udedf",
        48, 73862, -616353905, 102159528694338152L, -22774L, true, true, (char) 38755, (char) 43286,
        Double.longBitsToDouble(0x3fa168ffcc25f340L), Double.longBitsToDouble(0x3fcf500242a704e4L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 7, 9, 2, "\uda2c\ude58\uda44\udd3d\ud97f\udff0\uda8a\udd9b\udb05\udd72\ud830\uddca\uda40\udd94\ud8cc\udc6e\ud8fe\udfab\uda33\udea3\udaef\ude95,\000\000\uda84\udda2\udb96\udf80\udaa4\udf04\uda8a\udfbe\udb8d\udf1d\ud953\udf63\udab5\udc76\ud9a9\ude6e\uea32\ud98a\udfb7\uda28\ude7f\udb97\udf29\u00f8\udb94\ude8a\ud834\udf64", "\u11e5", "\ud87b\udc3c\ue1d2\udbe7\uddbe\uda7b\udedc\u18e5\udba9\uddf0\udab8\udced\000\ud9c4\udc2d\udae7\udd86\ud8de\udd10\ud94a\udf06\uda92\udde5\ud939\udd62\ud83e\udc2b\ud977\udcd8\ud9ac\udc0c\ud943\udd35\ud97c\udf3b\udafd\udcb7\ud8b4\ude57\udae9\ude60\ud81d\udfef\udad7\udcc9\ud88f\udd6a\u8c17\udb1e\udc04",
        16, 70088, -1296686451, 32700510826987520L, -34464L, true, false, (char) 31891, (char) 16254,
        Double.longBitsToDouble(0x3fd6013d388d6722L), Double.longBitsToDouble(0x3fe97d903b926513L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 2, 2, "", "\000\u6d0c\u5185\u0c78\u82b9\u0f06\u9768\000\u58a9\u8e2c\u4e58\u15e9\u871c\u3da4\u8a02\ud2c7\u65fb\000\ud526\u35f1\u0610\u0ebb\u940b\u0b9b", "",
        3, 14250, 225378364, -4290203706504037506L, 52033L, true, true, (char) 123, (char) 27319,
        Double.longBitsToDouble(0x3fe413a3813ba0c0L), Double.longBitsToDouble(0x3fcd5905d71020f8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 5, 7, 2, "\uda2c\ude58\uda44\udd3d\ud97f\udff0\uda8a\udd9b\udb05\udd72\ud830\uddca\udb26\ude67\ud8cc\udc6e\ud8fe\udfab\uda33\udea3\udaef\ude95,\000\000\uda84\udda2\udb96\udf80\udaa4\udf04\uda8a\udfbe\ud82f\udf6d\ud953\udf6b\udab5\udc76\ud9a9\ude6e\ueaa5\ud98a\udfb7\uda28\ude7f\udb97\udf29\ud9be\udfd7\udba5\udef1\ud834\udf64", "\u11e5\u94b0", "\ue1d2",
        36, 55088, -1598028158, -4022003385392774934L, -12449L, true, true, (char) 8238, (char) 14268,
        Double.longBitsToDouble(0x3f31eb7f36e28800L), Double.longBitsToDouble(0x3fe9f6aaac555397L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,org.jsoup.nodes.Document$OutputSettings|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.StringBuilder,java.lang.String,org.jsoup.nodes.Document$OutputSettings,boolean,boolean,boolean|static",
    "M|org.jsoup.nodes.Entities|canEncode|org.jsoup.nodes.Entities$CoreCharset,char,java.nio.charset.CharsetEncoder|static",
    "M|org.jsoup.nodes.Entities|getCharacterByName|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|isBaseNamedEntity|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|isNamedEntity|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|loadEntities|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|toCharacterKey|java.util.Map|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String,boolean|static",
    "C|org.jsoup.nodes.Entities|<init>|",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,org.jsoup.nodes.Document$OutputSettings|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.StringBuilder,java.lang.String,org.jsoup.nodes.Document$OutputSettings,boolean,boolean,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
