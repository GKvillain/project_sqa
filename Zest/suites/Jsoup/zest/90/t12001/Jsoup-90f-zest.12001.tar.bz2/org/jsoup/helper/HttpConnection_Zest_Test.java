package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class HttpConnection_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 7, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449301180792L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 7, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26",
        40, 93318, -1849480706, -7811177008780145154L, -68856L, false, false, (char) 38135, (char) 21516,
        Double.longBitsToDouble(0x3feb9bfe5a7daad1L), Double.longBitsToDouble(0x3fefe05b8c48ff6aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\uda33\uddbe\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 12, 6, 3, "\uda8b\udf21\uda33\uddbe\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b", "\ucdc9\u2c44\u8a50\uc5ea\u076b\u5d4e\ub6d7\u629f\u42ae\u9086\u9f8a\uac3d\u6835\u9410\u9b65", "\uda67\udec8\udb54\udce9\ud919\udc1b",
        -1, 38819, -136278053, -7943459148679514685L, -12697L, false, true, (char) 4685, (char) 38135,
        Double.longBitsToDouble(0x3fedc362db737fcbL), Double.longBitsToDouble(0x3fe3ed568ffc0b71L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 7, "\uda8b\udf21\uda00\udd64\ud881\udf14\udb46\uddff\ud810\udc45\ud85e\udf2b\ud9e0\udf7d\ud8bd\uddc2\ud98b\udff6\udaf3\udc89\uda9a\ude1c\uda09\udefe\ud86e\udd5e\uda6e\udc64\uda31\ude3e", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\ucfda", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\udab6\udce4\ud8c1\udeef\uda66\udded\udace\udda3\ud94e\udf3d\udbba\udd9f\ud986\ude0a\udbc2\udf60\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb76\ude5f\udb31\uddf0",
        4, 45955, 1863764043, 6590755449301180792L, 89818L, true, true, (char) 18403, (char) 45008,
        Double.longBitsToDouble(0x3fd0e5dd8b44460eL), Double.longBitsToDouble(0x3fb1ca19bb071f98L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\ud96c\udfda\udbcf\uddec\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\udacf\udcc0\0121=java.lang.String:\ud96c\udfda\udbcf\uddec\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\udacf\udcc0\012",
        Z.run(T, 2, 12, 12, 0, "\ud96c\udfda\udbcf\uddec\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\udacf\udcc0", "\u4eed\u274c\uac3d\u114c\u2f9d\u389d\u74e7", "\udb54\udce9\ud918\udfeb\udba6\udf26\ud859\udd0d\udbc6\udf2b\udb8a\uded9\ud86d\udf57\udbc9\udce4\udac5\udf68\udac8\uded1\ud8cd\ude72\uda5e\ude61\udbfa\udf25\udba5\ude6d\udae5\ude6e\ud88b\ude8a\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755446895973496L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8eb09820L), Double.longBitsToDouble(0x3fe072eec5763452L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud919\udf99\ud98b\udfd1\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0\0121=null\012",
        Z.run(T, 2, 12, 13, 0, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud919\udf99\ud98b\udfd1\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u6106\u756f", "\udb54\udce9\udaaa\udc9b\udb69\ude99\ud859\udd0b\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b",
        4, 37944, -1780138984, -5733364820677516386L, 36579L, false, true, (char) 7091, (char) 37795,
        Double.longBitsToDouble(0x3fc1a3e7a72cc044L), Double.longBitsToDouble(0x3fea5ca7bb046a28L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 2, 4, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0\ud9af\udc9d\ud911\uddd6\uaa9d\uda59\udc10\udaae\udf30\udbb3\udc31\ud8bd\udd8c\ud8aa\udf7a\ud8df\udfc7\ud82e\udc4f\uda67\udec8", "\u9e56\u4ca8\u5e3a\u6756\u676a\u509d\ud529\ub81e\u6e56\u70c4\uab14\u167e\u780d\u074b\u0498\ud0b6\u5185\u6aef\ub3f4\u9590\u42bc\ucd9a\u5db1\u1ecf\u31fd", "\udb2c\udfb3\ud873\udfb7\ua381\ud8c2\udf4d\ud984\udf8c",
        3, 72778, -1886222268, 8138254372467837402L, -68324L, false, true, (char) 63058, (char) 47751,
        Double.longBitsToDouble(0x3fe93b2d2f7180caL), Double.longBitsToDouble(0x3feefe93684c8eb7L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 7, "\uda8b\udf21\ue341\uda84\udc23\uda8c\udf0e\uda20\ude84\udbb1\ude94\udb51\udec5\udb3e\ude39\ud9a7\ude30\uda06\ude30\udb3e\udea0\udac3\udda1\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086", "\ud806\udf9b\ud8d0\udd20",
        24, 67469, -1957120209, -8236092487798585343L, 22985L, true, false, (char) 64012, (char) 8671,
        Double.longBitsToDouble(0x3fef2c8e1dfe9399L), Double.longBitsToDouble(0x3fd0759f6350513aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 7, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb3d\udf88\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\uda78\ude96\udba6\udfce\ud81f\udefa\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u2aba\u9410\u9b65\u1e20", "\udb54\udce9\ud919\udc1b\udba6\udf26\udaeb\udd76\udb18\udc57\ud968\udca2\udad4\udce9\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449301180792L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 7, 7, "\uda8b\udf21\uda01\uddc5\ud8f9\udfb3\ud87f\udfbe\ud80a\udd1f\udba0\ude35\ud823\udcb9\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\udb25\uddc1\ud863\udead\ud9f3\udd80\ud9bc\udc66\uda31\udeb0", "\u9086\u9f8a\u5b3b\u1c90\u9410\u9b65\u36a8", "\udb54\udc34\ud919\udc1b\udba6\udf26",
        24, 40643, -1209726660, -1984548534494032433L, -68856L, false, false, (char) 38135, (char) 21537,
        Double.longBitsToDouble(0x3feb9bfe5a7daad1L), Double.longBitsToDouble(0x3fb9c2dc60e585f0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 13, 7, "\udae9\udc1e\ud85c\udf12\ud9a8\udc4a\ud898\udf9b\udb08\ude62\ud85e\udf2b\ud80c\udf2a\ud825\udf2e\uda68\udcb6\ud997\ude6f\ud805\udfb4\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0\ud9af\udc9d\ud911\uddd6\ud983\udc2e\uda59\udc98", "\u9410\u9b65\ub63b\u94bf\u0ed4\u748b\uc2b4\u9e56\u4ca8\u5e3a\u6756\u676a\u509d\u558a\u8721\u4c21\u70c4\uad31\u61d2\u780d\u5143\u519a\u0bdc\u5113\u6aef\ub3f4\u9590\u42bc\u21e9\005\u53a6\u6be9\u447f\u7b34\u6ee9\ucc76\u50f3\u4811\u0b77\u3f44\uc97b\u3bb9\u0700\u0f91\u4057", "\uda21\udc77\ud9df\udf47\ud9a7\udd64\udb27\ude97\uda80\udd58\ud97f\udc94\udb75\udfd0\udb39\udef6\ue947\ud872\udf65\udab8\udc7c\ud8a3\uddfb\udb02\udc69\ud861\udf34\ud8d4\udfb8\ud9fe\ude60\udb6f\udfc0\uda36\udd04\ud956\ude6a\udb5e\uddc8\uda87\udc60\udb75\ude01\udb8d\uddaa\ud91e\ude6c\ud9df\uddc5\udb51\udd91\ud9f0\udcc0\u50b7\ud858\udf28\ud973\udec1\udb5d\uddcd\ud83d\udca7\ud9ed\ude10\ud8a1\udf38",
        52, 55335, 433901823, 365480891354423242L, -4959L, true, true, (char) 59780, (char) 42234,
        Double.longBitsToDouble(0x3fd1b96be53f0f76L), Double.longBitsToDouble(0x3fc5ea1fdf6dc0e0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0\0121=null |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 12, 10, 14, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449301180792L, 46189L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 8, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64", "\ubc24\u3989\ucdc9\u2c44\u27d3\u909d\ub165\uc128\u20b5\ub4e3\u42ae\u9086\u9f8a\uac3d", "\ud8aa\udf7a",
        39, 56791, -1917614715, -2326801003665086156L, 12949L, true, true, (char) 8671, (char) 45480,
        Double.longBitsToDouble(0x3fdfe9399a0eb3ecL), Double.longBitsToDouble(0x3fda8289d831ac68L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=null |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 9, 10, 9, "\uda9b\udd0e\udb09\udd87\ud8f9\udfb3\uda56\udf64\udb08\ude62\ud899\udfbf\udbcc\udd40\uda99\udf30\uda86\udcfe\ud983\udd1f\ud816\udf9c\uda09\udefe", "\u1d55\uabfa\u1519\u9086\u9f8a\u7f0e", "\ud8aa\udf7a",
        39, 9591, -1917614599, -741533934830671564L, 12949L, false, true, (char) 8671, (char) 45480,
        Double.longBitsToDouble(0x3fdfe9399a0eb3ecL), Double.longBitsToDouble(0x3fda8289d831ac68L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 7, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda06\ude0a\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udae5\uded6\uda9f\udc0b\udbf1\udc44\ud918\udc45\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449301215864L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 10, 3, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb2c\udd62\ud85e\udf2b\udb75\udfa8\uda8a\udc22\udb13\udf52\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u29d4\u0fee\uab79\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\ud8d8\ude86\ud9c4\udd5e\ud8c4\udfa3\ud906\udc0b\uda12\udc09\uda2a\udc75\ud81e\uddf7\udaf2\ude8c\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449301180792L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5f5eb31L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 9, 7, "\udaad\udc21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb84\udfa5\ud9c4\udd5f\ud835\udcb8\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u073a\u1645\u6aa3\u199a\u5d11\u9e56\u1a95", "\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\ud942\udd4a\ud8bb\udefa\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78\ud882\udf62\ud8b4\udf7c\udbcb\uded6\udb8d\ude8c\ud9a5\udfe5\u6ec3\ud989\udf92\ud930\udc9e\ud9a6\udf50\udb4d\ude0f\udba0\udc31\udb17\udd37\ud874\udc24\udadb\udc38\ud851\udf96\ud819\udc4c\uda89\udd98\ud89c\udd7a\uda6d\ude2d\ud9ce\udc19\ud810\uddaf\ud95c\udcbd",
        35, 84875, -988849847, 2320819712734773345L, 94245L, false, false, (char) 50161, (char) 51511,
        Double.longBitsToDouble(0x3fc5b541ecb3d210L), Double.longBitsToDouble(0x3fd0f83642bcf0c8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udefb\udb09\uddc9\uda85\udd39\uda57\udcba\udb08\ude62\udbbb\udd04\ud9d3\udeb7\ud9d0\ude34\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\uda27\udd42\ud9bd\udec9\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 14, 13, "\uda8b\udefb\udb09\uddc9\uda85\udd39\uda57\udcba\udb08\ude62\udbbb\udd04\ud9d3\udeb7\ud9d0\ude34\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\uda27\udd42\ud9bd\udec9", "\u42ae\u9086\u528a\uac3d\u1cfc", "\ud89e\udfa7\udba6\udf3f\udb53\ude9a\udbb1\udf20\uda82\udfdf\ud879\udd38\ud8e1\uddd1\ud9af\udf57\udba4\udd7e\uda40\udd81\udb5e\udc2a\udbf3\udf97\udaa4\udd93\udbbe\ude52",
        51, 46491, -170802397, 824698523288776700L, 68545L, false, true, (char) 7672, (char) 39942,
        Double.longBitsToDouble(0x3fda51833af5a614L), Double.longBitsToDouble(0x3fd45db4eca393ccL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 9, 8, 5, "\uda8b\udf21\udb09\uddc9\ud9c7\ude53\udbd1\udcf9\udb08\ude62\ud85e\udf2b\udb93\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\u5288\u1c90\u9410\006\u8c5e", "\udb6b\ude6f\ud919\udc1b\uda15\udd1c\ud856\ude08\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        -1, 82755, 1863750813, -615003954491612757L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe1464c8fb09820L), Double.longBitsToDouble(0x3fe072eec593b048L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 7, 7, "\uda8b\udf21\udb09\uddc9\ud8bc\uddb4\ud819\udd94\ud836\udf0e\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\ud87f\udc19\uda6e\udd11\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449301180792L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 13, 2, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\ud981\udf9d\udb8a\udfb1\udb75\udf83\ud9c4\udd5f\ud98b\udf86\ud9e0\ude60\udaed\udf06\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\u2e14\u3814\u9464\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\udbe2\udf4b\ud9ac\udd47\udadf\udf6b",
        14, 86016, -546373870, -5989503239126400141L, 76124L, false, false, (char) 32823, (char) 30680,
        Double.longBitsToDouble(0x3fdcb3011a9729eeL), Double.longBitsToDouble(0x3fd2933588f0b6eeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 10, 3, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\ud8fa\udeaa\ua39f\ud9a8\udf75\ud9e5\udf9e\ud859\udcfc\uda00\udc59\ud880\uddce\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\017", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud86d\udc0d\ud97e\udc16\udb8a\udf1c\uda40\udd81\ud8a0\udf4b\udadf\udf6b",
        14, 86016, -1334915310, 9208633760660177779L, 70853L, true, false, (char) 21338, (char) 34587,
        Double.longBitsToDouble(0x3fdcb3011751879cL), Double.longBitsToDouble(0x3fdc43daf1aab610L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 2, 6, 7, "\uda13\udd86\ud88f\udcc0\ud8f9\udeda\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\uda0d\udf87\udbbd\udcce\uda5a\udde6\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\u8144\u1cb6\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud901\udc08\udb8a\udf13\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\ud880\udd49\udbb1\udd12\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 87335486029373816L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf19\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\ud9a9\udc79\udb47\udd9e\ud98b\udf86\udaf3\udc89\uda76\uddeb\uda09\udf51\ud86e\udd5e\ud9bc\udc81\uda31\udeb0\ud9af\udc9d\ud911\uddd6\uaa9d\uda59\udc10\udaae\udf30\udbb3\udc31\ud8bd\udd8c\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 12, 5, 7, "\uda8b\udf19\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\ud9a9\udc79\udb47\udd9e\ud98b\udf86\udaf3\udc89\uda76\uddeb\uda09\udf51\ud86e\udd5e\ud9bc\udc81\uda31\udeb0\ud9af\udc9d\ud911\uddd6\uaa9d\uda59\udc10\udaae\udf30\udbb3\udc31\ud8bd\udd8c", "\ub4ec\u3e0d", "\udba8\udd26\ud859\udd0d\ud9c3\udc60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\uda78\udf24\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78\ud882\udf62\ud8b4\udf7c\udbcb\uded6\udb8d\ude8c\ud9a5\udfe5\u6ec3\ud989\udf92\ud930\udc9e\ud9a6\udf50",
        -1, 6393, 1574442888, 7442218235488318867L, -19066L, false, true, (char) 5626, (char) 42715,
        Double.longBitsToDouble(0x3fc0a191de9fb4d0L), Double.longBitsToDouble(0x3fefa60f18dba59cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\udbc9\udfa1\ud91f\udd02\ud80d\udfb1\udb4c\ude44\udaf3\udc89\udb3e\udcee\uda92\udc94\uda4b\udda9\ud9bc\udcf8\uda31\udeb0\0121=java.lang.String:\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\udbc9\udfa1\ud91f\udd02\ud80d\udfb1\udb4c\ude44\udaf3\udc89\udb3e\udcee\uda92\udc94\uda4b\udda9\ud9bc\udcf8\uda31\udeb0\012",
        Z.run(T, 2, 12, 11, 14, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\udbc9\udfa1\ud91f\udd02\ud80d\udfb1\udb4c\ude44\udaf3\udc89\udb3e\udcee\uda92\udc94\uda4b\udda9\ud9bc\udcf8\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud9b8\udef7\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449314150776L, 31713L, false, false, (char) 26880, (char) 13922,
        Double.longBitsToDouble(0x3fe072e801936748L), Double.longBitsToDouble(0x3fdf3f326a144c0eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 12, 7, "\ud942\udc1d\ud85b\ude2b\uda90\udd35\uda4c\udd64\udb08\udec9\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\udbd9\udeb5\ud9d2\udc80\ud83b\udc55", "\u9086\u9f8a\uac3d\u1c90\u9410\ua9dc\u759f\ub4ec\u36a6\u9c7c\uc2b4", "\ud9af\udf60\udb8a\udecc\uda40\udd81",
        17, 52559, -701214808, 8547898167437300481L, 15571L, false, false, (char) 48008, (char) 7091,
        Double.longBitsToDouble(0x3fed02c0188d1f4bL), Double.longBitsToDouble(0x3fdcb304509729eeL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 7, 12, "\uda8b\udf21\udb09\uddc9\ud9bd\udfb5\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb76\udc13\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\udb84\udcc0\uda09\udefe\ud846\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a", "\ud8bd\udd8c\u3aac\ud8df\udfc7\ud82e\udc4f\uda2d\udeea\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda4f\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud94f\ude17\ud888\udd3f\udbfd\ude2e\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78\ud882\udf62\ud8b4\udf7c\udad4\udf1c\udbc0\udd56\ud9a5\udfe5\ud858\udec1\udae4\udd34\ud930\udc9e\ud9a6\udf50\udb4d\ude0f\udba0\udc31\udb17\udd37\ud874\udc24\ud85f\udf3c\udb48\udd70\ud90f\udf5d\uda99\udc5f\uda32\udcf6\uda31\udd96\ud9f0\uddfa\ud8be\uddc8\uda77\ude8d",
        53, 81586, 313126600, 587380715368958897L, -660L, true, false, (char) 60833, (char) 31045,
        Double.longBitsToDouble(0x3fd38e8e2dd5a3eeL), Double.longBitsToDouble(0x3fe274b4666937eaL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 4, 4, 0, "\uda47\udcba\udb93\ude90\ud8f9\udeec\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb8c\ude0a\ud83b\udc21",
        39, 45955, 1863764043, 6590755449301180792L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 4, "", "\u98b6\u102f\u1a33\uaecb\ubc24\u3989\ucdc9\u2c44\u6a6a\uae5c\uad7e\000\000\u6233\u4665\u6ae5\u9f8a\uac3d\u1c90\u9410\u0823\000\000\000\000\u10e3\u1f97\u4ca8\u5e3a\u6756\u676a\u509d\ud529\ub81e\030", "\uda1c\udeee\uda5a\udd29",
        7, 78856, 525024160, 3463646949242522059L, 29044L, true, true, (char) 30157, (char) 21892,
        Double.longBitsToDouble(0x3fd45db4eca39322L), Double.longBitsToDouble(0x3fed84c1020e5dd8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection$KeyVal:\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0=\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552 |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 6, 10, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\udbaa\uddd1\udb07\udf48\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449301180792L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fd0e5dd8b26cfccL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 6, 6, 7, "\ud8de\udf8c\uda25\udfaa\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u6a45\u9fc8\uac3d\ua5c1\u9408\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udbc5\ude26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b",
        4, 37944, -1780138984, -5733364820677516386L, -41704L, false, true, (char) 30680, (char) 31196,
        Double.longBitsToDouble(0x3fe75347e1292bebL), Double.longBitsToDouble(0x3fd785b77028da2cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 5, 5, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\udb37\udc88\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u09e8\u6093\u06c6\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud8a0\udf4b\udbbc\udd78\ud856\udd4f\ud8cd\uddd7\udb6c\ude60\udbeb\udd1b\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1863764043, 6590755449301180792L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 3, 9, 7, "\ud989\udf2e\udb2e\udff2\udace\udf89\uda4c\udd64\udb08\ude62\ud85e\udf2b\u53d8\ud9c4\ude4e\ud98b\udf86\udaf3\udc89\udbd9\ude60\uda09\udfdb\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a", "\ud8bd\ude0c\ud8aa\udf7a\ud8df\udfc7",
        16, 71285, -541750575, -6231529206775123561L, -63173L, false, true, (char) 45480, (char) 41367,
        Double.longBitsToDouble(0x3feaea6759a8289dL), Double.longBitsToDouble(0x3f98d634e252bca0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 6, 3, "\uda8b\udf21\uda33\uddbe\ud8f9\udfb3\uda4c\udd64", "\u08b0\u3989\ucdc9\u26f7\u8a50\uc5ea\u076b\u5d4e\ub6d7\u629f\u42ae\u9086\u9f8a\u4836", "\ud8aa\udf7a\ud8df\udfc7\ud874\udc54\udbfd\uddee\udb54\udce9\uda3c\udeed\ud94c\udd0d\udaf0\udd2b\ud87b\udcf2\udb8a\ude80\uda07\udf58\ud8a0\udf4b\udadf\udf6b\ud998\udd24",
        24, 68402, 2144014264, -6137909918248605059L, 7927L, true, true, (char) 14570, (char) 47679,
        Double.longBitsToDouble(0x3fe9f2d0cf133bfdL), Double.longBitsToDouble(0x3fd1b14fc0e699d0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 6, 3, "\uda8b\udf21\ud881\udda4\ud8f9\udfb3\ud876\udd19\udafe\uddd9\ud817\uddd7", "\u0fe2\u2c44\u8a50\uc5ea\u076b\u5d4e\ub6d7\u629f\u42ae\u9086\u3f8a", "\ud8bd\udd8c\ud9c7\udf87\ud8e0\udc29\ud82e\udc4f\uda67\udec8\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda07\udf58\ud899\udf09\udafe\ude11\ud9b1\udf31\ud8cd\uddd7\uda68\udd45\udbd5\udf24\udba5\ude6d\uda94\udf29",
        22, 8847, -570085579, 2134257343906888759L, -84671L, false, false, (char) 41555, (char) 62663,
        Double.longBitsToDouble(0x3fe94e4d25ce2f7bL), Double.longBitsToDouble(0x3fef45f183c9534cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 3, "\uda8b\udf21\uda33\uddbe\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b", "\000", "\ud86e\ude36",
        32, 23626, 1962134587, 3073706818694807552L, 90073L, true, false, (char) 23336, (char) 0,
        Double.longBitsToDouble(0x3fe9782760008b58L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 2, 2, 3, "\uda8b\udf21\uda33\uddbe\ud8d4\udf22\uda4c\udd64\udb08\ude62\ud85e\udf2b", "\ucdc9\u2c44\u8a50\u50a7\u0946\u5d4e\ub6d7\u629f\u42ae\u8848\u9f8a\uac3d\u6835\u9410\u9b65", "\uda67\udec8\udb54\udce9\udaab\udde3",
        5, 38819, -136278053, -7943459144881244733L, 577L, false, true, (char) 4685, (char) 38135,
        Double.longBitsToDouble(0x3fedc362db737fcbL), Double.longBitsToDouble(0x3fe3e88e8ffc0b71L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 12, 11, 7, "\uda8b\udf21\ud8c8\ude48\ud959\udc98\ud948\udc70\udb40\udf91\udabe\udeb9", "\u4941\u2c44", "\udac5\udc5c\ud89e\udded\ud97e\udf1f\uda08\ude94\ud911\uddd6\uaa9d\uda7b\ude13\udaae\udf30\ud996\udc26\ud8bd\udd8c\udb1c\uddd3\ud848\udca6",
        10, 39678, 851907000, -2898664968248221801L, -89093L, false, true, (char) 44797, (char) 894,
        Double.longBitsToDouble(0x3f98d6d0c0f2bca0L), Double.longBitsToDouble(0x3fedc362db737fcbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\udaf7\udfff\udac5\udf78\ud8b6\ude34\udb1b\udf62\udbc7\udd3e\0121=java.lang.String:\uda8b\udf21\udaf7\udfff\udac5\udf78\ud8b6\ude34\udb1b\udf62\udbc7\udd3e\012",
        Z.run(T, 2, 11, 11, 3, "\uda8b\udf21\udaf7\udfff\udac5\udf78\ud8b6\ude34\udb1b\udf62\udbc7\udd3e", "\ud53d\u92d5\u2326\uc5ea\u076b\u5d4e", "\ud911\uddd6\uda40\udfc8\ud806\udd0d\udaae\udf30\ud996\udc26\udaaf\udfc8\ud8ad\uddaf\ud8ca\uddc3\ud8cd\udc7e\ud928\uddaa\ud925\udd4b\uda0a\udd03\udba6\udf26",
        -3, 70901, -1849480706, -8883316371623456567L, 29296L, false, false, (char) 21963, (char) 64037,
        Double.longBitsToDouble(0x3feb9b246a7daad1L), Double.longBitsToDouble(0x3fefe05b8eeb426cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 3, 9, 3, "\ud84d\udf72\uda33\uddbe\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b", "\ucdc9\u2c44\u8a50\uc5ea\u076b\u5d4e\ucc08\u629f\u1923", "\udaae\udf30\ud996\udc26\ud8bd\udd8c\uda20\udf75\ud8df\udfc7\ud82e\udc4f\ud86d\udc60\udb3f\udcff\ud8fb\udf15\ud8ad\udec7\ud859\udd0d",
        32, 30294, -1826523709, 6482384098903741703L, 81224L, true, false, (char) 31763, (char) 17214,
        Double.longBitsToDouble(0x3fe3ed568d5270ceL), Double.longBitsToDouble(0x3fdd70aa431f6bd0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null |this=org.jsoup.helper.HttpConnection:@?\0121=null |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 10, 10, 13, "\udb1c\udd1d\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\ud986\udf81\udba2\uddb0\uda1e\udc03\udb25\ude45\ud99e\udd16\udbf7\udc8b\udb0e\udfbe\udb9f\udea7\ud86e\udd5e\ud9bc\udc81\uda4b\udc7e", "\u9086\u9f8a\u6348\u4f97\ud458\u614d\u756f\u3e95\u3e0d", "\udb69\ude99\uda0e\ude49\ud9f7\udc3b\ud8ef\udc70\ud831\udeb6\ud85e\udf26\udadf\udf6b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda64\uddf0\ud89b\udff3\udb28\udd77\ud881\udcd9\udbc0\udfe9\ud8b4\udf7c\uda12\udd8c\udad5\udc05\udbf2\udf27\udbcc\udc6a\udbb9\udca6\ud8a6\uddf3\udafc\udd92",
        28, 18808, 1427433193, -8132289838557346678L, 60084L, true, true, (char) 49951, (char) 32325,
        Double.longBitsToDouble(0x3fe3a878963c59bfL), Double.longBitsToDouble(0x3feaeab63ba52d63L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 9, 9, 11, "\ud933\udf15\udaf4\udec9\ud8f9\udfb3\uda4c\udd64\udb3d\udf88\ud85e\udf2b\u67a9\ud916\udd24\udaed\udcde\udbb6\udcdb\ud8df\ude3b\uda60\udc5e\ud89a\udfea\uda96\udce3", "\u42ae\u9086\u9f8a\uac3d\u2aba", "\udbd7\udd04\ud9b3\udc9a\uda67\udec8\udb54\udce9\ud919\udc1b\udba6\udf26\udaeb\udd76\ud89c\udc59\ud968\udca2\udad4\udce9\ud8a0\udf4b\ud8c0\ude1b\ud9b1\udf31\ud8cd\uddd7\uda5e\ude61\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78\uda62\ude52\udaa6\udc9a\udbcb\uded6\udb8d\ude8c\ud9a5\udfe5\udaae\udde6\ud86d\udeb8\ud930\udc9e\ud9a6\udf50\udb4d\ude0f\udba0\udc31",
        53, 20750, -141367127, -3164022311394007468L, -19863L, true, true, (char) 13546, (char) 8491,
        Double.longBitsToDouble(0x3fc11b8994594908L), Double.longBitsToDouble(0x3fe4e839e5cefc60L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 10, 0, "", "\u98b6\u1dd3\u1a33", "\uda99\udf30\uda86\udcfe\ud983\udd1f\ud816\udf9c",
        16, 17974, -1623093707, 4716825444149486115L, 1049L, true, false, (char) 40811, (char) 15804,
        Double.longBitsToDouble(0x3fa780000225b060L), Double.longBitsToDouble(0x3febe9c6032f04ecL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 3, 3, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb09\udfa6\ud85e\udf2b\udbb2\udd95\uda74\ude1c\udb13\udf52\udaf3\udc89\ua3c4\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u29d4\u1038\uab79\u1c90\u9ccf\ub6cc\ucf63", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud93c\udffc\udb8d\udef7\ud933\udf53\ud9c4\udd5e\ud8c4\udfa3\ud906\udc0b\uda12\udc09\uda2a\udc75\ud81e\ude1f\udaf2\udeea\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, 1496504651, -6813956379094474445L, 38414L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5f5eb31L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 11, 11, 14, "\uda8b\udf21\udacf\udd10\ud8f9\udfb3\udb88\udee6\uda2f\ude3e\udbc9\udfa1\ud91f\udd02\ud80d\udfb1\udb4c\ude44\ud8b5\udd8a\udb3e\udcee\uda92\udc94\uda4b\udda9\ud9bc\udcf8\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b72\u7552", "\udb54\udce9\ud919\udc1b\ud801\uded2\ud86a\udc42\ud9af\udf60\udb8a\udf7e\udbb3\udefd\udb46\ude89\ud82e\ude93\ud8de\uddc2\uda54\udc90\uda5e\ude8e\udbfa\udf25\udba5\ude6d\ud9be\ude7e\ud89b\udfbd\udb28\udd77\ud841\udd78\ud9b3\udd82\ud82f\udda5\ud9c6\udedf\udbad\ude71\ud837\udff1\ud961\udc17\udaa2\udd7b\udaf6\udff4\udb3d\udcb6\ud95b\ude1a\udad4\ude81\ud8db\udf03\ud874\udc24\ud85c\udcd1\udad6\udc30\ud8f3\ude81\u2103\udb47\udd2c\ud8b3\udcc2\uda08\udcba\udbba\udd73",
        33, 86500, 1766593605, 5697568963244276834L, 89990L, false, false, (char) 6966, (char) 35592,
        Double.longBitsToDouble(0x3fd5cda4b5ac9730L), Double.longBitsToDouble(0x3fed87c090a8a580L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 10, 7, "\uda8b\udf21\ud830\udcbc\ud8e9\udcb4\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\uda69\ude12\ud98b\udf86\udaf3\udc89\ud828\udfc3\uda09\udefe\ud86e\udd5e\ud9bc\udc81\uda31\udeb0", "\u9086\u9f8a\uac3d\u1c90\u1836\u0823\000", "",
        45, 74044, -1263394921, 7652256554411921371L, 88443L, false, true, (char) 44568, (char) 41541,
        Double.longBitsToDouble(0x3f98d634e252bca0L), Double.longBitsToDouble(0x3fecf58373737fcbL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:\uda8b\udf21\ud881\udda4\ud8f9\udfb3\000\000\000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 6, 3, "\uda8b\udf21\ud881\udda4\ud8f9\udfb3\000\000\000", "", "",
        37, 4536, 1714478669, 6358190671231437883L, 85416L, true, false, (char) 1163, (char) 14661,
        Double.longBitsToDouble(0x3fe2a4dbc82f0000L), Double.longBitsToDouble(0x3fbb16c1beff86d0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 9, 3, 7, "\uda8b\udf21\udb09\uddc9\ud8f9\udfb3\uda4c\udd64\udb08\ude62\ud85e\udf2b\udb75\udfa8\ud9c4\udd5f\ud98b\udf86\udaf3\udc89\ud828\udfc3\ud86c\udd27\ud882\udc0f\ud830\udefb\udaa7\ude31", "\u9086\u9f8a\uac3d\u1c90\u9410\u9b65\u7552", "\udb54\udce9\ud919\udc1b\udba6\udf26\ud859\udd0d\ud9af\udf60\udb8a\udf7e\uda40\udd81\ud89f\udc4b\udadf\udf6b\ud9b1\udf31\ud8bf\ude97\uda5e\udef4\udbfa\udf25\udba5\ude6d\uda94\udf29\ud89b\udff3\udb28\udd77\ud841\udd78",
        39, 45955, -320557184, 2634689123386990928L, 84845L, false, false, (char) 21892, (char) 48275,
        Double.longBitsToDouble(0x3fe28e4c8fb09820L), Double.longBitsToDouble(0x3fe072eec5936748L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.HttpConnection|connect|java.lang.String|static",
    "M|org.jsoup.helper.HttpConnection|connect|java.net.URL|static",
    "M|org.jsoup.helper.HttpConnection|cookie|java.lang.String,java.lang.String|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|cookies|java.util.Map|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.lang.String,java.lang.String|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.lang.String,java.lang.String,java.io.InputStream|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.lang.String,java.lang.String,java.io.InputStream,java.lang.String|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|[Ljava.lang.String;|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.util.Collection|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.util.Map|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.lang.String|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|encodeMimeName|java.lang.String|static",
    "M|org.jsoup.helper.HttpConnection|encodeUrl|java.lang.String|static",
    "M|org.jsoup.helper.HttpConnection|encodeUrl|java.net.URL|static",
    "M|org.jsoup.helper.HttpConnection|execute||new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|followRedirects|boolean|new:org.jsoup.helper.HttpConnection:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
