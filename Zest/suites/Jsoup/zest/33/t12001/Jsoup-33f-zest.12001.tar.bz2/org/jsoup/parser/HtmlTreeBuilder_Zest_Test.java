package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\udaca\udfbf",
        5, 42343, 1667274414, -4150152818625514875L, -55511L, true, true, (char) 9072, (char) 5128,
        Double.longBitsToDouble(0x3fc0363eb017f248L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 2, "\uda5c\udc04\udb1b\udee8\udae4\udd87\uda3d\udcb7\udb8f\ude1e\uda67\udef7\u320e\udaac\ude39\ubb3b\udae1\udc04\udb0f\udf44\ud9b2\udd0f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u6764\ud111\u1800\u9764\uc3c8\u6443\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\uda62\udfef\udb0c\udc52\udb9c\udeea\udac8\udf53\uda35\ude7c",
        36, 98475, 1187601343, 7160889080621281792L, -50868L, true, false, (char) 52663, (char) 9072,
        Double.longBitsToDouble(0x3fcd6e63b206c7d4L), Double.longBitsToDouble(0x3f77f24ad24e2180L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 15, "\uda5c\udc04\udad1\udc23\ud97b\udda1\ud929\udd02\uda0c\ude9e\u540e\ud8bb\udc7c\ud8cb\udcf7\ud82a\udefe\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbc1\udf0b\uda17\udf37\ud8b8\udef0\ud849\udfa2\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud928\udd09\udbdc\udd36\ue4ff\uda35\ude7c\udaca\udfbf",
        5, 42343, 1667274414, -4150144911590722939L, -55511L, true, false, (char) 58685, (char) 5128,
        Double.longBitsToDouble(0x3fd2db1c380bf924L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 2, "\uda4c\udf85\udad1\udc23\ud97b\udda1\uda05\uddb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u1ddd\u8c88\uce70\u836f\u17e1\000\uab9b\uc3c8\u9317\u8d2c", "\udb7e\udcdf",
        6, -1000, 0, 818962452937244672L, -5891L, false, true, (char) 35071, (char) 37968,
        Double.longBitsToDouble(0x3fd449acbb636838L), Double.longBitsToDouble(0x3fe942c5749a02e5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 19, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\ubc87\udac0\udd0c\udb64\udf50\ud8f9\udea6", "\u28a3", "\ud8d6\udfd4\u612b\udb38\udf4d\udad9\udeff\udbe2\udcaa\u488d\ud9ab\ude5d\udb53\udebe\udadb\ude5d\uda57\udd03\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udd21",
        35, 30885, -1496733227, -5227664361573327486L, -81734L, false, true, (char) 20941, (char) 7126,
        Double.longBitsToDouble(0x3fc3405cb6507f48L), Double.longBitsToDouble(0x3fd5b68b577edd46L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 13, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\udaca\udfbf",
        5, 42343, 1667274414, -4150152818625514875L, -55511L, true, true, (char) 9072, (char) 5128,
        Double.longBitsToDouble(0x3fc0363eb017f248L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 2, "\udb6d\uddee\udae1\udeb7\u805a\uda3d\udd4f\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud97c\udcc1\ud9a7\udd19\udb0f\udf44\ud9a2\udcfd\udb7e\udd9c\udad3\udcd9\ud9a4\udedb\uda7f\ude4f\ud984\uddca", "\u00c2\u667c\u8cdb\uce70\u836f\u9bce\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\udbc1\udf63\ud8aa\udc78\udbaa\udcf9\uda6a\udfc6\udaa2\udc3d\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud8c3\udf97\udb8e\udcea\udac8\udf53\uda35\ude7c\udad7\udebb",
        5, 42343, 1667274414, -4438383194777214381L, 17236L, true, false, (char) 45899, (char) 16032,
        Double.longBitsToDouble(0x3fc02caef0145e48L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 14, "\u8007\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud838\udf82\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\ud88c\udeae", "\u1bcd\u667c\u8cdb\uce70\u836f\u07ea\u51f9\u499c\u59cb\u1428\ua906", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\uda85\udc09",
        40, 42343, 811636398, -4120389376737971579L, -55511L, true, true, (char) 9072, (char) 5128,
        Double.longBitsToDouble(0x3fcedb9eb9e8023cL), Double.longBitsToDouble(0x3fd9453a4e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 13, 2, "\udb26\ude00\udad1\udc23\ud97b\udda1\ud894\uddf5\ud8e5\udc59\uda67\udef7\ud8ea\udd3a\ud9e8\udedc\ud82a\udf19\ud9a7\udd19\udb0f\udf44\ud816\udcaf\udb9b\udc53\ud879\udc3c\udb98\udd2d\ud9e0\udf01\ud8b7\udfbd", "\u9fad\u4b83\u11bd\u7dd1\u836f\ua749\ucbda\uabd3\ub2aa\u9317\u8d2c\uc0da\ubce2\u9019\u047c\u6656\u72b7\u97ff\uadd9", "\ud898\udfa2\udb59\udfa0\ud880\udeaf\uda94\udf43\ud84b\udfce\uda0b\udefc\uda55\udc14\uf8fd",
        13, 99193, 1014592771, -4150152818625514875L, 25610L, false, true, (char) 15472, (char) 34670,
        Double.longBitsToDouble(0x3fef1c77ad5fed65L), Double.longBitsToDouble(0x3fda4e18ae5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\ud913\udfed\ud815\udc8d\ud92c\udd1b\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\uda45\udcb9\uda9d\ude6f\uae7f\ud9dd\udee3\uda55\ude64\udb71\udd79\uda3c\udf76\udb09\udd44", "\ua749\ucbda\uabe1\ub1c8\u9317", "\udba5\udc8a\udb7e\uddbc\ud941\udca4\ud91c\udedf",
        46, 91555, 196476885, -7584156516149456797L, -4197L, false, false, (char) 3088, (char) 20941,
        Double.longBitsToDouble(0x3fe942c5749a02e5L), Double.longBitsToDouble(0x3fd941ffc2b6d16aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 10, "\uda81\udcd4", "\uadf2\u26a3\ubc52\u36a5\u31bc\u13c8", "\udbb5\udc7f\udb7e\udd9c\udbf5\udfdd\udb74\udef0\uda9d\udf4f\udb42\uddcb\udac3\udcf6\ud9c3\ude40\ud919\uddcb\uda41\udd27\udb0b\udecd\ud8d6\udfd4\u612b\udb38\udf4d\udad9\udeff\ud976\uddc7\udaf0\udd84\ud94a\udc2d\udb2c\udd5a\udadb\ude5d\uda57\udd03\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\ue952\udbb5\udf24\u9894\udbd0\udf6e",
        46, 86046, -1273204412, 6390218304868696872L, 16116L, true, true, (char) 51810, (char) 48247,
        Double.longBitsToDouble(0x3fd1fa59a50b8da2L), Double.longBitsToDouble(0x3fcfa0c508de04a8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\uda8c\udd39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbf0\udc1b\uda5e\udd11\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\ucfc0\u667c\u8cdb\uce70\u836f\ua749\ucbda\ubee1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\uda66\udddd\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud812\udf7e\ud977\ude9e\udbfa\udc6f\ud880\udeaf\ud82b\udccb\udbaa\udfe0\udac8\udf53\ud9a1\uddb3\udaca\udfbf",
        38, 61631, 1667274414, -4150152818625514875L, 23887L, false, true, (char) 24539, (char) 19352,
        Double.longBitsToDouble(0x3fda49c82e5b2d22L), Double.longBitsToDouble(0x3fb9429b397beb38L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 2, "\udb85\udff9\udad1\udc23\ud97b\udda1\udbc7\udd87\ud9d8\udced\uda67\udef7\u320e\uda77\udd39\ud82a\udf19\ud9a7\udd19\ud9d4\udc05\udbba\udf66\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f\ud9dd\udee3", "\u667c\u8cdb\uadfc\u836f\ua749\ucbda", "\ud9ab\ude5d\udb4f\udee1\uda2e\udfd8\uda9a\udcad\udb7e\udcdf\ud86f\udf5a\ud882\ude78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\udaca\udfbf\ud84d\udfe0\udbaf\udfea\ud8df\udc89\ud823\ude9b\ud837\udfad\ud0a7",
        -2, 53185, 1931328495, -5623411628581927807L, 33724L, true, true, (char) 5623, (char) 56212,
        Double.longBitsToDouble(0x3fe1f7aade27eb4eL), Double.longBitsToDouble(0x3fb7450ae96a50a8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\uda16\uddaf\udad3\ude6a\udba7\udce7\ud989\udc9b\uda9d\udf45\uae7f", "\u6ac1\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\uda06\udc37\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\udaca\udfbf",
        5, 42343, 1667274414, -4150152818625514875L, -55511L, true, true, (char) 9072, (char) 5128,
        Double.longBitsToDouble(0x3fc0363eb017f248L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 17, 5, "\uda5c\udc04\udb3a\ude16\udbdd\udcd1\ud9e9\udef9\ud8f3\udd7c\uda67\ude3e", "\u2560\ub26b\ub971\u3fa0\ua418\u97f2\u0c05\u7356\u8095\u5bfa\uc812\u00c2", "\ud938\udf04\ud97f\udda0\udbbd\udc2d\udad9\udf15\ud976\uddc7\udb00\udda0\ud9ab\ude5d\udb4f\udee1\udadb\ude5d\uda57\udd03\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9",
        17, 30885, -1765824043, -4183122348787847854L, -81734L, false, true, (char) 20941, (char) 54371,
        Double.longBitsToDouble(0x3fc3405cb6507ff0L), Double.longBitsToDouble(0x3fd5b68b5d7edd46L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 13, 2, "", "\u9199\uadf2\ud061\u337e\u36a5\u31bc\u2560\ub26b\ub988\u8d72\ua418\u97f2\u0c05\u7356", "\uda55\ude64\udb71\udd79",
        31, 11459, -1986972977, 2192416703629430612L, 38644L, false, false, (char) 28965, (char) 45967,
        Double.longBitsToDouble(0x3fefd378d0b14c3dL), Double.longBitsToDouble(0x3fe0180007d50b5dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 2, "\ud872\ude6f\udad0\udfca\ud97b\udda1\uda3d\udcb7\udbb4\udf90\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\uda06\uddfe\udbcb\ude2d\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\u02e3\ub4ca\u840c\u90c8\uac82\uc3c8\u726d\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udc85\ud9ba\udeae\ud9db\ude7d\ud832\uddd5\ud88d\udcf7\ud93d\udd3b\ud944\ude8d\ud880\ude4c\ud847\udccb\ud817\udde8\uda89\ude70\u67f3\udaca\udfbf",
        5, 42343, 1667274414, -6888306205579848732L, 13647L, false, false, (char) 9634, (char) 34199,
        Double.longBitsToDouble(0x3feca6cf0f2d96f6L), Double.longBitsToDouble(0x3fde8055e653cd64L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 2, "\ud824\udd89\udb78\udc64\ud97b\ude56\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\uda41\udd64\ufd4d\ud9a7\udd19\udb0f\udf44\udbd8\udee8\uda74\udc98\udad3\udcd9\ud989\udc9b\uda9d\udf4f\ud8c2\udccd", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\uc7d4\ua9ae\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udbe2\udf80\ud86d\udcaa\udaba\udebf",
        5, 42343, 1671630254, -4150152820573905488L, -55511L, true, true, (char) 9072, (char) 5323,
        Double.longBitsToDouble(0x3fc0363eb017f248L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 19, 8, "\uda7b\udf2d\udad0\udfd6\ud97b\udda1\uda3d\udd1b\udacd\ude1d\uda6c\udff7\u320e\udaac\ude39", "\u6219\u8d72\ua418\u4807\u5f12\u58f8\ua9f8\u5be1\u4051\uc537\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u93b3\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud93f\ude88\ud06f\ud9ba\udeae\udaa2\udc85\udbda\udfd1\udb33\udff3\ud91a\udfa3\udb59\udfa0\ud9c8\uddb2\ud82b\udccb\ud814\ude47\u96cd\ud811\udd5e\udaca\udfbf",
        5, 42343, 1346467246, -7248783432678608187L, 2318L, true, false, (char) 54366, (char) 36075,
        Double.longBitsToDouble(0x3fed24e21f4fd528L), Double.longBitsToDouble(0x3fdbce65aef18a84L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 17, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\ud819\udce5\uda24\uddf3\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud807\udffc\ud929\udc8b\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\udb96\udf06",
        31, 42343, 1667274414, -4150152818625514875L, -55511L, true, true, (char) 9072, (char) 5128,
        Double.longBitsToDouble(0x3fc0363eb017f248L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 13, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\ud9ee\udd35\udad3\udcdb\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u0f34", "\ud98c\uddc6\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud8d7\uddc0\udb9c\udf0f\udb48\udc49\uda35\ude7c",
        15, 98475, 1187601343, 7160889080621281792L, -50868L, true, false, (char) 37432, (char) 9072,
        Double.longBitsToDouble(0x3fcd6e63b206c7d4L), Double.longBitsToDouble(0x3f77f24ad24e2180L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 18, 2, "\uda5c\udc04\udacf\udd23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud85c\udc10\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua797\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\uda8d\udf66\ud871\ude29\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\udaca\udfbf",
        5, 42343, 1667274414, -4150152820079365499L, -11123L, false, false, (char) 30326, (char) 49303,
        Double.longBitsToDouble(0x3fda49c43e5b2d22L), Double.longBitsToDouble(0x3fd533e0799705f8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\udada\udca0\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udd60\ud886\udf6c\udac8\ude9d\ud989\udc9b\uda9d\udf4f\uae7f\ud9dd\udee3", "\u667c\u8cdb\ubae2\u836f\ua712\ucbda", "\ud97f\ude76\udb47\uddc2\udadb\ude5d\uda57\udd03\udb7e\udcdf\ud86f\udf5a\ud8c9\udd49\udbaa\udcf9\ud9ba\udeae\uda9c\uddf0\ud842\udfa1\ud876\udc84\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\ud97f\ude52\uda35\ude7c\udb7e\udee9\ud9e5\udd7f\udbb7\udde0\ud930\udd8c\udacf\ude91\udbcc\udd0b\udb47\udf4f",
        50, 98441, 1931328495, -5623411626452593279L, 33724L, true, true, (char) 46928, (char) 39757,
        Double.longBitsToDouble(0x3fd9ce99399b6964L), Double.longBitsToDouble(0x3fc5341fdb9b2d88L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 5, 8, "\uda5c\udc04\udad1\udc23\uda07\udc86\ud9e0\udca6\uda3b\ude94\u540e\ud8bb\udc7c\ud8cb\udcf7\u5f35\ud9da\udc7c\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\uda7d\udd04\ud9a3\udc57\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbc1\udf0b\uda17\udf37\ud8b8\udef0\ud849\udfa2\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud931\udc09\u3749\udb85\udd73\uda5a\udfc0\uda27\udfb8",
        5, 77415, 1667274414, -4150144910058325316L, 13647L, true, false, (char) 31376, (char) 49303,
        Double.longBitsToDouble(0x3fda49c43e5b2d22L), Double.longBitsToDouble(0x3fc6c14dc8ab44a0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 15, "\uda5c\udc04\udad1\udc23\ud97b\udda1\ud929\udd02\uda0c\ude9e\u540e\ud8bb\udc7c\ud8cb\udcf7\ud82a\udefe\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udbc1\udf0b\uda17\udf37\ud8b8\udef0\ud849\udfa2\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud928\udd09\udbdc\udd36\ue4ff\uda35\ude7c\udaca\udfbf",
        5, 42343, 1667274414, -4150144911590722939L, -55511L, true, false, (char) 58685, (char) 5128,
        Double.longBitsToDouble(0x3fd2db1c380bf924L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 6, 15, "\uda5c\udc04\udad1\udc23\ud97b\udda1\ud929\udd02\uda0c\ude9e\udb86\udec5\ud8d6\udc8b\ud8cb\udcf7\ud82a\udefe\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\ude4e\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f\ud9dd\udee3\uda55\ude64\udb71\udd79\uda3c\udf76\uda51\uded0\ud8d6\udfd4\u612b\udb38\udf4d\udad9\udeff", "\u51e7\u8d10\uc0da\ubce2\u9019\u96da\u7eeb\u9a45\u96be\u4337\uccb2\u1c2c\u4b7c\ub6b4\u48b3\u0ca8\u62a1\u9822\u4a83\u51ae\u847b\u69fc\u4c76\ud4ed\u4bb1\u12bd", "\udac2\udeb7",
        31, 79893, -1673280507, -7597021010047230163L, 13843L, false, false, (char) 57272, (char) 65343,
        Double.longBitsToDouble(0x3fe52d0392d9bfa6L), Double.longBitsToDouble(0x3fe07f26f72ed775L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 16, 17, "\udbeb\ude6d\uda2f\udc57\ud8c2\udd57\ud929\udcc1\uda0c\ude9e\u540e\ud9e3\ude7a\ud8cb\udcf7\ud82a\udefe\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\uc678\u8cdb\uce70\u16af\ua749\u3c30\ub40e\uc3c8\u9317\u8ce1\uc0da\ubce2\u9019", "\ud83a\ude91\uda33\udee4\ud9fc\udfb0\udb79\udf9a",
        16, 96034, -611789883, -7292532147198594748L, 1589L, true, true, (char) 58529, (char) 27154,
        Double.longBitsToDouble(0x3fedfb751d5a46c9L), Double.longBitsToDouble(0x3fd6d894d0bd07b6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 18, 15, "\uda5c\udc04\udad1\udc23\ud97b\udda1\ud929\udd02\uda0c\ude9e\u540e\ud8bb\udc7c\ud8cb\udcf7\ud92c\udc7e\ud8eb\udcea\ud88b\udd3a\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8aa\udc78\udb9d\udeda\uda17\udf37\udb7b\udc92\ud86f\udf0b\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud928\udd09\udbdc\udd36\ue4ff\uda35\ude7c\udaca\udfbf",
        5, 42343, 1667274414, -4150144911590722939L, -55511L, true, false, (char) 58685, (char) 5128,
        Double.longBitsToDouble(0x3fd2db1c380bf924L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 10, "\uda4c\udf85\udad1\udc23\ud97b\udda1\uda05\uddb7\udacd\ude1d\ud9f0\udd7b\uda6c\udf76\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u1ddd\u8c88\uce70\u836f\u17e1\000\ud28a\u602c\u9317\u8d2c", "\udb7e\udcdf",
        6, -1000, 0, 818962452937244672L, -5891L, false, true, (char) 35071, (char) 37968,
        Double.longBitsToDouble(0x3fd449acbb636838L), Double.longBitsToDouble(0x3fe942c5749a02e5L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 2, "\uda4c\udf85\udad1\udc23\ud98a\ude81\uda05\uddb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb1f\udf4c\udbb7\udf76\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u1ddd\u8c88\uce70\u836f\u17e1\000\uab9b\uc3c8\ua6f7\u7a83", "\udb7e\udcdf\u00ce\000\000\ud9ba\udeae\uda62\udcb0",
        12, 83931, 56658, -2618129601967441754L, -9297L, true, true, (char) 49022, (char) 56898,
        Double.longBitsToDouble(0x3fe0589250dc5da8L), Double.longBitsToDouble(0x3fefb4cf1a3402acL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 14, 7, "\uda4c\udf85\udad1\udc23\uda29\uded5\uda05\uddb7\udacd\ude1d\uda6a\udcf7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udae9\udf83\udbc7\udea1\ud8de\udc77\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u1ddd\u8c88\uce70\u836f\u6323\000\uab9b\uc3c8\u9317\u8d2c", "\udb7e\udcf7\u00ce",
        -5, 45215, -126187005, 859540172411218389L, -81704L, false, true, (char) 20941, (char) 7126,
        Double.longBitsToDouble(0x3fc3405cb036b408L), Double.longBitsToDouble(0x3fb091b14d731420L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 17, 14, "\uda73\ude64\udad1\udc23\ud97b\udda1\uda05\uddb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\ubfc1\u1d81\u8c88\uce70\u836f\u17e1\000\uab9b\u49d0\u9317\u74a5", "\udb7e\udcdf",
        6, -1000, 0, 818962452937244672L, 1696L, false, true, (char) 35071, (char) 37968,
        Double.longBitsToDouble(0x3fd449acbb636838L), Double.longBitsToDouble(0x3fe942c5749a02e5L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 7, 2, "\uda4c\udf85\ud89e\udde5\ud978\udfa6\uda05\uddb7\u43da\uda67\udef7\u320e\udaac\ude39\udbd4\udecd\uda8d\udc51\udadd\udc98\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u1ddd\u8c88\uce70\u836f\u17e1\000\uab9b\uc3c8\u9317\uc365", "\udb7e\udcdf",
        6, -1000, 0, 1251308017164455525L, 89673L, false, false, (char) 28712, (char) 40093,
        Double.longBitsToDouble(0x3fd449acbb636838L), Double.longBitsToDouble(0x3fe942c5749a02e5L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 15, 1, "\uda78\udc8b\udad1\udc23\uda8c\udeca\u25aa\uda0e\udd45\uda67\ude85\udbd6\ude91\udaac\ude39\ud911\udf5a\uda55\udc07\u84f5\udb52\udccd\u7a21\udac8\udf71\uc6b0\ud9f9\udd4c\ud84d\udc8c", "\u7af7\u6675\u8e3b\u9888\u836f\u17e1\u6cbd\ucee7\uc3c8\u9317\u18a4\u0ac5\u08b3\u9019\uc2ce\000\u2264\uae7e\u0e25\u39d3\u8e59\ucf0e", "\ud946\ude30\udb9c\udeea\udac8\udf53\ud8f5\uddbc\udbeb\udd1f\udbd7\udf93\ud815\udea8\ud896\udd91\ud9b3\udce4\uda13\udddd\ud974\udf7d\ud8a6\uddf3\ud92a\udf0d\ud85c\udc37\uda60\ude46\uda78\udc4c",
        24, 85556, 1994246617, 7667997893215287559L, -14881L, true, true, (char) 56593, (char) 55652,
        Double.longBitsToDouble(0x3fc8ec2c4cc543bcL), Double.longBitsToDouble(0x3fe058892d2b8f46L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 0, 2, "\uda4c\udf85\udad1\udc23\ud97b\udda1\uda05\uddb7\udacd\ude1d\ud8b2\udcbc\u7887\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udbf8\uddc8\ud854\udfa0\ud992\uddf0\uda9d\udf4f\uae7f", "\u00c2\u1ddd\u8c88\uce70\u836f\u17e1\000\uab9b\uc3c8\u9317\u8d2c", "\udb7e\udcdf",
        20, -756, 0, 861835709839114240L, -5891L, false, true, (char) 55295, (char) 28300,
        Double.longBitsToDouble(0x3fd449acbb636838L), Double.longBitsToDouble(0x3fe942c5749a02e5L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 11, 10, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udac6\udfe8\ud875\uddb3\udb64\udf50\ud8f9\udea6", "\u28a3", "\ud8d6\udfd4\u612b\udb38\udf4d\udad9\udeff\udbe2\udcaa\u488d\ud9ab\ude5d\udaa8\udeae\udadb\ude54\uda57\udd03\udb7e\udcdf\ud86f\udf5a\udb4f\udf3d\udbaa\udcc5",
        35, 30885, 197765589, -5291706709118296702L, -81734L, false, true, (char) 20941, (char) 7126,
        Double.longBitsToDouble(0x3fc3405cb6507f48L), Double.longBitsToDouble(0x3fd5b033f77edd46L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\ubc87\udac0\udd0c\udb64\udf50\ud8f9\udea6", "\u28a3", "\ud8d6\udfd4\u612b\udb38\udf4d\udad9\udeff\udbe2\udcaa\u9d8d\ud9ab\ude5d\udb53\udebe\ud85a\udcdb\uda07\udfe6\udb44\udc85\udbab\udd45\ud8b3\udc5f\udbaa\udd21",
        35, 30885, -1496733227, -5227664361573327486L, -81734L, false, true, (char) 274, (char) 7126,
        Double.longBitsToDouble(0x3fc3405cb6507f48L), Double.longBitsToDouble(0x3fd5b68b577edd46L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 6, 2, "\uda5c\udc04\udb34\udfda\udb4d\udd36\ud897\udd9c\udbee\udcf8\udacf\udd10\ud9a6\uddf9\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\ud9d3\udf3d\ud967\udfc3", "\u00c2\u667c\u8cdb\u9541\u3df4\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udd8e\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\ud8e6\udc68\ud842\udfbb\uda06\udec5\ud91a\udfa3\udb59\udfa0\ud89e\udcfd\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\ud9ac\udcbc",
        5, 42343, -1006135634, 5891788076058732797L, 48689L, true, false, (char) 30326, (char) 49303,
        Double.longBitsToDouble(0x3fda49c43e5b2d22L), Double.longBitsToDouble(0x3fde65896bd8344aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 14, "\u8007\udad1\udc23\ud97b\udda1\uda3d\udcb7\udacd\ude1d\uda67\udef7\ud912\udc01\udaac\ude39\ud82a\udf19\ud838\udf82\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\ud88c\udeae", "\u1bcd\u667c\u8cdb\uce70\u836f\u07ea\u51f9\ud30b\u41e4\u1428\ua906", "\udb83\udcc3\ud86f\udf5a\ud8aa\udc78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ue4ed\ud91a\udfa3\udb59\udfa0\udb2f\ude59\ud82d\udf19\udb9c\udeea\udac8\udf53\uda35\ude7c\uda85\udc09",
        40, 42343, 811636398, -4127989201100789636L, -55511L, true, true, (char) 9072, (char) 5128,
        Double.longBitsToDouble(0x3fcedb9eb9e8023cL), Double.longBitsToDouble(0x3fd9453a4e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 5, "\uda83\udcce\ud813\udf10\ud9ae\udcf6\ud894\uddf5\ud8e5\udc59\uda67\udef7\ud8ea\udd3a\ud9e8\udedc\ud82a\udf19\ud9a7\udd19\udb0f\udf44\ud816\udcaf\udb9b\udc53\ud879\udc3c\udb98\udd2d\udb3f\ude04\ud8b7\udfbd", "\u9fad\u4b83\u11bd\u7dd1\u836f\ua749\u0e66\u4c65\u0e4e\ub892\u8d2c\uc0da\ubce2\u9019\u047c\u6656\u72b7\u97ff\u7e68", "\ud898\udfa2\udb59\udfa0\ud880\udeaf\uda94\udf43\ud84b\udfce\uda0b\udefc\uda55\udc14\uf8fd",
        13, 4888, 866546947, 6156455907972678124L, 36534L, false, true, (char) 15472, (char) 34670,
        Double.longBitsToDouble(0x3fef1c77ad5fed65L), Double.longBitsToDouble(0x3fc49c315cb73b50L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 14, 19, "\udb26\ude00\udad1\udc23\ud97b\udda1\ud894\uddf5\ud8e5\udc59\uda67\udef7\ud8ea\udd3a\ud9e8\udedc\ud82a\udf19\ud9a7\udd19\udb0f\udf44\ud816\udcaf\udb9b\udc53\ud879\udc3c\uda29\udf96\uda47\udf54\ud8b8\udc21", "\u9fad\u4b83\u11bd\u7dd1\u8333\ua749\ucbda\uabd3\ub2aa\u9317\u8d2c\uc0da\ubce2\u9019\u047c\u6656\u72b7\u2849\uadd9", "\ud898\udfa2\udb59\udfa0\ud880\udeaf\uda94\udf43\ud84b\udfce\uda0b\udefc\uda55\udc14\uf8fd",
        13, 99193, 1014592771, -4150152818625514875L, 25610L, false, true, (char) 15472, (char) 34670,
        Double.longBitsToDouble(0x3fef1c77ad5fed65L), Double.longBitsToDouble(0x3fda4e18ae5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:true |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 12, "\udb85\udff9\udad1\udc23\ud97b\udda1\ud85e\udf74\ud9b4\udeb3\u4e8e\ud815\ude11\uda77\udd39\ud82a\udf19\ud9a7\udd19\ud9d4\udc05\udbba\udf66\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f\ud9dd\udee3", "\u667c\u921d\uc1fc\u836f\u3134\ucbda", "\uda2f\ude96\udb29\udf3e\uda2e\udfd8\uda9a\udcad\udb7e\udcdf\ud86f\udf5a\ud882\ude78\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb61\udda0\uac25\u7637\ub489\udac9\udc12\uda35\ude7c\udaca\udfbf\ud84d\udfe0\udbaf\udfea\ud8df\udc89\ud823\ude9b\ud837\udfad\ud0a7",
        -2, 53185, 1931328495, -6632217945112937343L, 33724L, true, true, (char) 18113, (char) 3479,
        Double.longBitsToDouble(0x3fe1f7aade27eb70L), Double.longBitsToDouble(0x3fb7450ea96a50a8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 2, "\000", "\uadf2\u841e\u337e", "\ud82a\udf19\ud9a7\udd19\uda06\uddfe\udbcb\ude2d\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f\ud9dd\udee3\uda55\ude64\udb71\udd79",
        31, 11459, -1131347761, -7625849567423638029L, -87431L, false, false, (char) 60087, (char) 63548,
        Double.longBitsToDouble(0x3fe3662d442fbb2dL), Double.longBitsToDouble(0x3fe87070b80000c1L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 18, "\uda4c\udf85\ud89e\udde5\ud978\udfa6\udbda\udf34\u43ae\uda67\udef7\u32bf\udaac\ude39\udbd4\udecd\uda8d\udc51\udadd\udc98\ud8a2\udc9b\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\uae7f", "\u00c2\u1ddd\u8c88\uce70\u836f\u17e1\000\uab9b\uc3c8\u9317\uc365", "\udb7e\udcdf",
        6, -1000, 0, 1251308017164455525L, 89673L, false, false, (char) 28712, (char) 40093,
        Double.longBitsToDouble(0x3fb126b2ed37e7c0L), Double.longBitsToDouble(0x3fe942c5749a02e5L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 2, "\uda5c\udc04\udad1\udc23\ud97b\udda1\uda3d\udcb7\udb65\ude0a\uda67\udef7\u320e\udaac\ude39\ud82a\udf19\ud9a7\udd19\udb0f\udf44\udbb5\udc7f\udb7e\udd9c\udad3\udcd9\ud989\udc9b\uda9d\udf4f\ud827\udfdd", "\u00c2\u667c\u8cdb\uce70\u836f\ua749\ucbda\uabe1\uc3c8\u9317\u8d2c", "\udb7e\udcdf\ud86f\udf5a\ud8a9\udd70\udbaa\udcf9\ud9ba\udeae\udaa2\udc85\ud842\udfa1\ud88d\udcf7\ud91a\udfa3\udb59\udfa0\ud880\udeaf\ud82b\udccb\udb9c\udeea\udac8\udf53\uda35\ude7c\udaca\udfbf",
        5, 42343, 1667274414, -4150152818625514875L, -55511L, true, true, (char) 9072, (char) 5128,
        Double.longBitsToDouble(0x3fc0363eb017f248L), Double.longBitsToDouble(0x3fda49c43e5b2d22L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 2, "Q", "\uadf2\u841e\u337e", "\ud93c\udc41\ud9a7\udd19\uda06\uddfe\udbcb\ude2d\udb7e\udd9c\ud841\udc70\ud955\udc1c\uda9d\udf4f\uae7f\ud9dd\udee3\uda55\ude64\udb71\udd79",
        31, 11459, 1932308687, -7625849369855142413L, -87431L, false, false, (char) 60087, (char) 63548,
        Double.longBitsToDouble(0x3fe366ed442fbb2dL), Double.longBitsToDouble(0x3fe87070b80000c1L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 2, "b", "\uae3b\ua4ce\u337e", "\ud8cd\ude2d\ud9a7\udcf6\uda06\uddfe\udbcb\ude2d\udb7e\udd9c\uda6e\udf3b\ud955\udc1c\uda9d\udf4f\uae7f\ud9dd\udee3\uda55\ude64\udb71\udd79",
        31, 11459, 1932308687, 680758667433596290L, -41254L, true, true, (char) 55559, (char) 28508,
        Double.longBitsToDouble(0x3fe87074280000c1L), Double.longBitsToDouble(0x3fec7d808591b93bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|org.jsoup.parser.Token$StartTag|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|org.jsoup.nodes.Element|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|org.jsoup.parser.Token$Character|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|org.jsoup.parser.Token$Comment|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|aboveOnStack|org.jsoup.nodes.Element|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearFormattingElementsToLastMarker||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToContext|[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableBodyContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableRowContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|error|org.jsoup.parser.HtmlTreeBuilderState|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk|boolean|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|org.jsoup.parser.Token$StartTag|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|org.jsoup.nodes.Element|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|org.jsoup.parser.Token$Character|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insert|org.jsoup.parser.Token$Comment|new:org.jsoup.parser.HtmlTreeBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
