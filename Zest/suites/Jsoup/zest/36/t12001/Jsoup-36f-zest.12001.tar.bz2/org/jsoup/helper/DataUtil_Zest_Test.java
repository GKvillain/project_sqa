package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 3, "\ud994\udddb\ud988\udcf5", "\u2eea", "\udb82\uddbb\udbe7\udf59\udbeb\udc1a\uda86\udd0f\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\uda57\udc15\uda43\udd30\ud8e3\udc5f\ud808\ude39\ud944\ude8a\ud92b\udcbd\ud89c\udec9\udbb5\udd8b\uda90\ude25\u9deb\udb05\udf67\ud95c\udfca\uda94\udf10\uda99\udc8a\udb31\udc5f\uda78\udcd4\udbd4\udc0e",
        7, 9384, -2088904095, -8140437519113802506L, 2051L, false, true, (char) 29290, (char) 59899,
        Double.longBitsToDouble(0x3fe9a4cc3d082a1fL), Double.longBitsToDouble(0x3feb2b7f8e9deb2dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 3, "\ud994\udddb\ud988\udcf5", "\u2eea", "\ud8cf\udea2\ud95b\udce7\udbeb\udc1a\uda86\udd0f\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\uda57\udc15\uda43\udd30\udba2\udf9e\ud808\ude39\ud944\ude8a\ud92b\udcbd\ud89c\udec9\udbb5\udd8b\uda90\ude25\u9deb\udb05\udf67\ud95c\udfca\ud9e9\ude2e\uda89\udf10\udb31\udc5f\uda78\udcd4\udbd4\udc0e",
        7, 9384, -2088904095, -8140437519113802506L, 2051L, false, true, (char) 29290, (char) 59899,
        Double.longBitsToDouble(0x3fe9a4cc3d082a1fL), Double.longBitsToDouble(0x3feb2b7f8e9deb2dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 3, "\ud994\udddb\ud988\udcf5", "\u2f6f", "\udb82\udf68",
        57, 40510, 1616552802, 3902471200948635768L, -10805L, false, false, (char) 11188, (char) 10238,
        Double.longBitsToDouble(0x3fe5f60f705293e8L), Double.longBitsToDouble(0x3fe94cc4471a7d3bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 1, 7, 2, 3, "\ud994\udddb\ud988\udcf5", "\u4a3b", "\udb82\ude50\udbe7\udf59\udbeb\udc1a\uda5e\udf0f\uf013\ud868\udd03\udbdb\udf04\udbae\udc75\ud8eb\udd62\uda57\udc15\uda43\udd30\ud8e3\ude5f\ud808\ude39\ud944\ude8a\ud92b\udcbd\ud89c\udec9\udbb5\udd8b\uda90\ude25\udb08\udd6f\udbfa\ude2c\ud95c\udfca\uda94\udf10\uda99\udc8a\udb31\udc5f\uda78\udcd4\ud844\udf67",
        37, 9384, -2088904095, -8140437519113802506L, 29187L, false, true, (char) 29290, (char) 59899,
        Double.longBitsToDouble(0x3fe9a4cc3d082a1fL), Double.longBitsToDouble(0x3feb2b7f8aa6eb2dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 2, "\ud96a\udd10\uda05\uddd0", "\u9d82\uc952\u7778", "\udb9d\udcd3\uda86\udda8\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\ud9c9\ude71\uda57\udc15",
        -3, 78462, -1735858045, 9024082433484228536L, -98033L, false, true, (char) 54103, (char) 642,
        Double.longBitsToDouble(0x3fee9ccd272dbb8dL), Double.longBitsToDouble(0x3fed120ffa3b87acL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 1, 1, 8, 8, "\ud994\udddb\ud988\udcf5\ud986\udd2c\ud97c\udd45", "\u7778\u6767\uc398\u80d9\u0d95\u1d12\u9381\uc607", "\uda57\udc15\uda43\udd30\udb95\uded8\ud853\udecc\ud996\udf83\u6eba\ud87f\udc4b\udbb5\udd8b\uda90\ude25\u9deb\udb05\udf67\ud95c\udfca\uda94\udf10",
        48, 11691, -526406994, -3347279774890957077L, 40703L, true, true, (char) 15357, (char) 1312,
        Double.longBitsToDouble(0x3fe518dfeffe1a3dL), Double.longBitsToDouble(0x3fecc556930526f7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 3, "\ud994\udddb\ud988\udcf5", "\u2eea", "\udb82\uddbb\udbe7\udf59\000\000\uda9e\udf2e\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\ud86d\ude80\000\ud8c2\udda1\ud808\ude39\ud944\ude8a\ud92b\udcbd\ud89c\udec9\udbb5\udd8b\uda90\ude25\udbfe\udddf\udb05\udf67\ud95c\udfca\uda94\udf10\uda99\udc8a\udb31\udc5f\uda78\udcd4\udbd4\udc0e",
        7, 9384, 0, -8142508127142171402L, -63485L, false, true, (char) 29290, (char) 9975,
        Double.longBitsToDouble(0x3fe9a4c805082a1fL), Double.longBitsToDouble(0x3feb2b7f8e9deb2dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 2, 3, "\ud994\udddb", "\u920b\u2eea\uc952\u7778\u0767\uc398\u80d9\u0d95\u1d12\u4282\u15dd\ub5b8\u641a\ua31b\uc9af\u7aa1\u45b1\u9796", "\ud9a3\uddc2\uda90\ude25\u9deb\udb05\udf67\ud95c\udfca\uda94\udf10\uda99\udc8a\udb31\udc5f\udbe3\udee9\udbd4\udc0e\ubf75\ud955\ude7a\udaf7\udd43\uda8b\udfe7\udbe6\uddf3\ud8dc\uddd0\udb7c\udc2e\udbe6\udef8\udb8a\udde3\ud81d\udcfb\ud9f2\uddaf\udb70\udfa0\udb74\udc3a\ud8bc\udf1c",
        4, 73661, -1103058803, -5770171658346577587L, -21055L, false, true, (char) 17526, (char) 10143,
        Double.longBitsToDouble(0x3fbdb9c1e95f0da8L), Double.longBitsToDouble(0x3fe2546988507425L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 3, "\ud994\udddb\ud988\udcf5", "\u2eea", "\ud8e5\udc64\ud92a\udf22\udb53\udc2d\uda86\udcb7\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\uda57\udc4b\uda43\udd30\ud8e3\udc5f\ud808\ude39\udb7f\udeb8\udb07\udcab\ud89c\udea2\udbb5\udd8b\ud925\udeaf\ud868\uddfd\udb05\udf67\udb26\udfa2\ud944\ude4e\udabf\udd56\udb31\udc5f\uda78\udcd4\udbd4\udc0e",
        31, 9384, -2088904095, -8140437171221451530L, 9557L, true, false, (char) 29092, (char) 59899,
        Double.longBitsToDouble(0x3fe9a4cc3d082a1fL), Double.longBitsToDouble(0x3fb95bfc51312020L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 6, 3, "\ud994\udddb\ud9d9\udc3e", "\u361e\uc952\u7778\u6767\uc398", "\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\udac4\udda6\ud944\udf49\ud8e3\udc8a\ud808\ude39\ud9ca\udf4e",
        0, 7158, 1488975953, 3408643669661689078L, 49549L, true, true, (char) 11425, (char) 10776,
        Double.longBitsToDouble(0x3fe574e502c8e09fL), Double.longBitsToDouble(0x3fe75acc66d885c6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 6, 3, "\ud994\udddb\ud988\udcf5", "\u7887\uc952\u7778\u6767\uc398\u80d9\u0d95\u1d12\u4282\u15dd\ub5b8\u641a\u6611\u5f48", "\ud944\ude8a\ud92b\udcbd\ud89c\udec9\udbb5\udd8b\uda90\ude25\u9deb\udb05\udf67\ud95c\udfca\uda94\udf10\uda99\udc8a\udb31\udc5f\uda78\udcd4\udbd4\udc0e\ubede\ud955\ude7a\uda48\udf0a\uda85\udc8c\udbe6\uddf3\ud8dc\uddd0\udb7c\udc2e\udbe6\udef8\udb8a\udde3\ud81d\udcfb\ud9f2\uddaf\udb70\udfa0\udbcd\udf70\uda01\ude05\ud95b\udfa4\ud8a7\ude7f\ud886\udd82\ud8f4\udf36\udb61\udc07\udb3a\udf38\udb21\udd44\ud877\udd16\udaf0\udeee",
        17, 79991, -1350751305, -6560714146280701180L, -51656L, false, true, (char) 14019, (char) 39278,
        Double.longBitsToDouble(0x3fe390ee0276559dL), Double.longBitsToDouble(0x3fe47f8db9033339L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 1, 7, 8, 3, "\ud994\udddb\ud988\udcf5", "\u08fe", "\udb82\uddbb\udbe7\udf59\udbeb\udc1a\uda86\udd0f\ud848\udf33\udb99\udedb\udba8\udf04\uda93\udef3\u4604\ud8ab\ude59\ud9ce\uddf5",
        41, 27861, 2101082921, 7681645739606977713L, 26812L, true, false, (char) 62849, (char) 20765,
        Double.longBitsToDouble(0x3fe96ddc6ba241ffL), Double.longBitsToDouble(0x3fe1d81d60638fa0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 3, "\ud994\udddb\ud988\udcf5", "\u2eea", "\udb82\uddbb\udbe7\udf59\udbeb\udc1a\uda86\udd0f\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\uda57\udc15\uda69\udd30\ud8e3\udc5f\ud808\ude39\ud944\ude8a\ud92b\udcbd\ud89c\udec9\udbb5\udd8b\uda90\ude25\u9deb\udb05\udf67\ud95c\udfca\uda94\udf10\uda99\udc8a\udb31\udc5f\uda78\udcd4\udbd4\udc0e",
        7, 9384, -2088904095, -8140437519113802506L, 2051L, false, true, (char) 29290, (char) 59899,
        Double.longBitsToDouble(0x3fe460a7ad082a26L), Double.longBitsToDouble(0x3feb2b7f8f41cf2dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 8, 7, 3, "\ud994\udddb\ud990\udcf5", "\u5481", "\ud85e\udde9\u00aa\udbeb\udc1a\uda86\udd0f\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\uda57\udc15",
        39, 71142, 1804396626, 232486478849360851L, 29194L, true, false, (char) 22748, (char) 49252,
        Double.longBitsToDouble(0x3fe550aed0ee26a3L), Double.longBitsToDouble(0x3fed15cd3a3b87acL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 4, 0, "\ud994\udddb\ud988\udcf5", "\u2eea", "\udb82\uddbb\udb58\udd91\udac1\udc25\uda86\udd0f\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\uda57\udc15\uda43\udd30\ud8e2\udff5\ud808\ude39\ud944\ude8a\ud92b\udcbd\ud89c\udec9\u2ad7\ud8b0\udcd8\u9deb\udb05\udf67\ud95c\udfca\ud973\udcc0\uda37\udd78\udb30\udfee\uda78\udcd4\udbd4\udc0e",
        -3, 5014, -2088928496, -8140437519113802506L, 2051L, false, true, (char) 29290, (char) 59899,
        Double.longBitsToDouble(0x3fe9a4cc3d082a1fL), Double.longBitsToDouble(0x3fecd9ff8b9deb2dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 3, 3, "\ud8f0\uddf7\u9576", "\u2f6f", "\udb82\udf68",
        18, 38105, 1616549970, 3902471200948635768L, -65419L, false, false, (char) 11188, (char) 10238,
        Double.longBitsToDouble(0x3fe5f60f705293e8L), Double.longBitsToDouble(0x3fe94cc4471a7d3bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 7, "\ud994\udddb\ud818\udfb6", "\u2f6f\u7618\u3650", "\udb6b\uddb9\ud9f5\udcce\ud975\udd95\ud8b8\uddcb\udb75\udea0\udbae\udc75\uda7d\udf2a\ud857\udc92",
        30, 76332, -1735858094, 9055001349781030682L, -91317L, true, true, (char) 28408, (char) 34169,
        Double.longBitsToDouble(0x3fdee5d9992d5376L), Double.longBitsToDouble(0x3fec6df017d87814L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 5, "\ud994\udddb\ud988\udcf5", "\u4a3b", "\udb82\ude50\ud94c\udecb\udb5c\udf25\uda5e\udf10\ufaf9\ud868\udd03\udbdb\udf04\udad2\udeb3\ud9f3\udfbe\uda57\udc15\uda77\udd2a\ud960\udf1d\ud86c\udfcd\ud944\ude8a\uda5c\udc8c\ud810\udc77\udbb5\udd8b\uda90\ude25\udb08\udd6f\udbfa\ude2c\udace\udfc3\uda94\udf10\uda99\udc8a\udb31\udc5f\uda4b\udc91\ud844\udf42",
        37, 31480, 735681384, -8106798746841010954L, 32957L, false, true, (char) 29290, (char) 59899,
        Double.longBitsToDouble(0x3fe9a4cc3d082a1fL), Double.longBitsToDouble(0x3feb2b7f8aa6eb2dL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 3, "\udaf7\udfd6\ud8c2\udcb4\ub69c\udb97\udc74\uda97\ude93\ud8b5\udf9d\ud81a\ude0d\udb82\uddbb\udbe7\udf59", "\u1d12\ub8da\u15dd\ub5b8\ua968\u6611\u5f48\u0812\u561d\u97fc\u711b\u8e5e", "\u9deb\udb09\udc67\ud95c\udfca\uda94\udf10\uda99\udc8a\ud8f1\udd3e\udbf6\udc5d\ud8f8\udd94\ud938\udd32\uea34\ud903\udfa6\ud8c9\udf21\udace\udf48\udb73\udc25\u57df\ud8d3\udcbf\udab5\ude81\uda02\udc47\udbad\udf1c\udaa4\udff9",
        30, 57766, -1874636537, -6626097755871724443L, 84279L, true, false, (char) 47460, (char) 9227,
        Double.longBitsToDouble(0x3fe1c920e8dc86c5L), Double.longBitsToDouble(0x3fc20c2c734fe558L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 0, 0, "", "\ud5fc", "\udb96\udcba\000\000\000",
        36, -1000, 0, 1054867456L, -47738L, false, false, (char) 10238, (char) 0,
        Double.longBitsToDouble(0x3e394cc440000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 0, 1, 8, "\ud994\udddb\ud988\udcf5\ud986\udd2c\ud97c\udd45", "\u7778\u6767\u7cdc\u9741\u0da1\u1d12\u9381\u0571", "\uda57\udc15\uda43\udd30\udb95\uded8",
        34, 67718, -762795650, -2329990263050602415L, 7531L, false, true, (char) 55770, (char) 28285,
        Double.longBitsToDouble(0x3fdaf56a8dd3b62aL), Double.longBitsToDouble(0x3fe574e5eac8e09fL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 3, "\ud994\udddb\ud988\udcf5", "\u2eea", "\udb82\uddbb\udbe7\udf59\000\000\uda9e\udfc3\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\ud86d\ude80\000\ud8c2\udda1\ud808\ude39\ud944\ude8a\ud92b\udcbd\ud89c\udec9\udbb5\udd8b\uda90\ude25\udbfe\udddf\ud9e2\udc95\ud8a8\udd35\uda94\udf10\uda99\udc8a\udb31\udc5f\uda78\udcd4\udbd4\udc0e",
        7, 9384, 0, -8142508127142171402L, -63485L, false, true, (char) 29371, (char) 9975,
        Double.longBitsToDouble(0x3fe9a4c805082a1fL), Double.longBitsToDouble(0x3feb2b7f8e9deb2dL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 3, "\ud994\udddb", "\u920b\u2eea\uc952\u7778\u0767\uc398\u80d9\u1584\u10a2\u4282\u15dd\ub5b8\u641a\ua31b\u85ae\u7aa1\u45b1\u9796", "\ud9a3\uddc2\uda90\ude25\u9deb\udb05\udf67\ud95c\udfca\udab5\udd20\uda99\udc8a\udb31\udc5f\udbe3\udee9\udbd4\udc0e\ubf75\ud955\ude7a\udb00\udfe8\udaac\udea1\udbe6\uddf3\ud8dc\uddd0\udb7c\udc2e\udbe6\udef8\udb8a\udde3\ud81d\udcfb\ud9f2\uddaf\udb70\udfa0\udb74\udc3a\ud8bc\udf1c",
        4, 73661, -1103058803, -5770171658346577587L, -21055L, false, true, (char) 17526, (char) 10143,
        Double.longBitsToDouble(0x3fbdb9c1e95f0da8L), Double.longBitsToDouble(0x3fe2546988507425L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 3, "\ud99f\udd8c\ud988\udcf5\ud83f\udda8\ud97c\udd45\udab2\udc7f\ud8b5\udf9d\ud9cc\ude27\uda4d\udff7\ud92a\udf22\udb53\udc2d", "\u37bf", "\ud914\udc36\uda57\udc4b\uda43\udd30\ud8e3\udc5f\udbdf\udd63\udb7f\ude7b\uda7e\udea8\ud914\ude44\udbb5\udd8b\ud925\udeaf\ud868\uddfd\udb05\udf67\udb26\udfa2",
        -2, 69377, -817044504, -2260900757688806712L, -50552L, true, false, (char) 57091, (char) 28584,
        Double.longBitsToDouble(0x3fa5667abf51bfd0L), Double.longBitsToDouble(0x3fb2ef5e7cc55060L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 3, "\ud994\udddb\ud988\udcf5", "\u2eea", "\udaf2\udf4a\uda09\udce9\udab3\udc42\uda28\ude76\uf013\ud868\udd03\uda2b\udf0c\udbae\udc75\udbb9\ude0d\udbcf\udfd4\uda43\udcb9\ud8e3\udc5f\ud808\ude39\ud84f\udcc1\udb07\udcab\ud9a6\udfa6\udb7c\udf3a\ud906\udc21\ud91a\udf76\udb1d\udea2\udb26\udfa2\ud944\ude4e\udabf\udd56\udb31\udc5f\udaee\udd88\ud9c0\udf9f",
        31, 9384, -2088904095, -2714619966722746893L, -15947L, false, false, (char) 29299, (char) 59899,
        Double.longBitsToDouble(0x3fe9a4cc3d082a1fL), Double.longBitsToDouble(0x3fb95bfc51312020L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 8, 3, "\ud832\uddf4\udb8c\udddd\ud89c\udef0\ud970\udc81\udab2\udc7f", "\u6767\uc398\u80d9\u0d95\u1d12\u4282\u15dd\ub5b8\u641a\u6611\u1f49\u7aa1\u45b1\u3a8c\u707d\u8e5e\ub980\ua76c\ud0dc\u3c1f\uad8e\u05b1\u903b\u2506", "\ubfb7\uda6f\udea7",
        55, 21693, -856314865, 2016829961611873955L, -85560L, true, true, (char) 37761, (char) 7982,
        Double.longBitsToDouble(0x3feb2b7f8f41cf2dL), Double.longBitsToDouble(0x3fcf9d82def1e424L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 7, 7, 3, "\ud9b5\ude86\ud9a6\ude56", "\u2f6f", "\udb0e\udf06",
        3, 38105, 1616549970, -2267478976292465723L, -65419L, false, false, (char) 11188, (char) 10238,
        Double.longBitsToDouble(0x3fe5f60f705293e8L), Double.longBitsToDouble(0x3fe94cc4471a7d3bL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 1, 0, "", "\u8639", "\000\udac7\udc0b\udb82\ude50\ud94c\ude21\u00f4\000\000\ud868\udd03\udbdb\udf04\udad2\udeb3\ud9f3\udfbe\uda57\udc15\uda77\udd2a\ud960\udf1d\ud86c\udfcd\ud800\udf29\uda5c\udc8c\ud810\udc77\udbb5\udd8b\uda90\ude25\udb08\udd6f\udbfa\ude2c\udace\udfc3\uda88\udfe3\uda99\udc8a\ua23b\uda48\udce3\ud844\ude9f\uda4b\udf47\u3ed8\udad2\ude88\udab3\udedc\udbe6\uddf3\u382a\udb96\udd8b\udbe6\udef8\udb8a\udde3\ud81d\udcfb\ud9f2\uddaf\udb70\udfa0\udb53\ude2a\udbb1\ude5c\uda04\udd10\u302b\ud8b1\udd58\uda13\udff7\udbac\udfc2",
        37, 96207, -2127451567, -1817141937371445050L, -47794L, false, false, (char) 55396, (char) 35529,
        Double.longBitsToDouble(0x3fe624ade6560b8aL), Double.longBitsToDouble(0x3fe56fdc504c67adL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 3, "\ud97a\udddb\ud988\udcf5", "\u2eea", "\ud847\ude7e\ud8d1\udc4d\udb3d\udea4\udaa3\udf95\udbf5\uddd1\ud868\udd03\uda2b\udf0c\udbae\udc75\ud8eb\udd62\udb05\udf6d\ud86f\udf79\uda12\uddcb\ud808\udec6\ud8da\uddf7\uda2b\udf83\ud89c\udec9\udbb5\udd8b\uda90\ude25\u9deb\udb05\udf67\ud915\udf26\ud847\ude9e\udaaa\udc1b\udb31\udc5f\ud9ea\udd04\udbd4\udc0e",
        7, 9384, -2088904095, -8140437519113802506L, 2051L, false, true, (char) 29290, (char) 59899,
        Double.longBitsToDouble(0x3fe9a4cc3d082a1fL), Double.longBitsToDouble(0x3feb2b7f8e9deb2dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream,int|static",
    "C|org.jsoup.helper.DataUtil|<init>|",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
