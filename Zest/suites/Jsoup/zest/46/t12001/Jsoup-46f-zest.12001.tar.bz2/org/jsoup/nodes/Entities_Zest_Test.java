package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Entities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9\012",
        Z.run(T, 1, 9, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u606b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        24, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a53b7982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\ud80a\ude16\ud8e0\udfec\udac8\udfcf\uda68\udd38\udb0e\ude21\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udb8e\udee4\033\000\000\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\u741e\000\udb0d\udca6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9\012",
        Z.run(T, 1, 9, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\ud80a\ude16\ud8e0\udfec\udac8\udfcf\uda68\udd38\udb0e\ude21\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udb8e\udee4\033\000\000\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\u741e\000\udb0d\udca6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "G\u1b6d\u0de5\u606b\u4622\u041a\ube34", "\ud8f2\udf98\ud8b9\udeee\u4e91",
        24, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a53b7982L), Double.longBitsToDouble(0x3fe2bf9810000060L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 5, 9, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\udab8\udda5\uda5d\udfb9\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud80e\udeb5\ud907\udc34\uda55\udc8b\udb9d\udf6b\udb26\ude8d\udbcc\udf8a\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\ud8ea\udf05\uda75\udcc5\ud868\udc77\ud870\udf99\ue432\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u606b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        24, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a53b7982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\udae0\udd73\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\012",
        Z.run(T, 1, 9, 9, 6, "\udae0\udd73\ud9c8\udc27\udb5d\udfd3\ud954\ude2c", "\ucf51\u651e\u023b\u4a1d", "\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0",
        -2, 95704, 1762521526, -8749112904900435944L, -62442L, true, false, (char) 30225, (char) 6440,
        Double.longBitsToDouble(0x3fcd0e304b4872e4L), Double.longBitsToDouble(0x3fe462dab3e9a070L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 9, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda53\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8d9\ude5d\uda6f\udfbe\udbfb\udd54\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\u6050\u3097\u8640\u70cd\u7c81\u041a\ube34", "\udbc3\udcfa\udaf1\ude42\u4e91",
        20, 50205, -1778543374, -1504508155911180419L, 8145L, true, false, (char) 10985, (char) 12127,
        Double.longBitsToDouble(0x3fe2bf9810afb460L), Double.longBitsToDouble(0x3fea673873aab838L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\udacd\ude2b\udbee\udcff\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8cd\udc24\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\uda91\udcba\ud878\udd40\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\ud9ac\ude67\ud8ca\udd51\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud831\udd3d", "\ubc75\u0571\u0de5\u606b\u4622\u041a\ube34\uc2f9\u410e\u30eb\ub8ba", "\uda8d\ude33\udaa5\udeb2\u1093\ud95a\ude9c\ud952\udfaa\ud9d5\ude9f\ud85c\ude44\ud8b2\uddb3\udb04\udc69\uda19\uddf9\udaf2\udd7e\uda87\ude9f\ud9dd\udff1\ud824\udf1f\udb68\udeee\ud829\ude85\u3746\udb98\udf48\ud82e\udcf0\ud930\udee6\uda29\udf80\ud956\udc7c\ud9f1\ude82\ud9b2\ude35",
        35, 11579, 161776460, 6690645751935666161L, 76910L, true, false, (char) 35827, (char) 15176,
        Double.longBitsToDouble(0x3fbf2ce62f3d1318L), Double.longBitsToDouble(0x3fd83d9fc0382220L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\012",
        Z.run(T, 1, 9, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3", "\u77fc\ucf51", "\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84",
        15, 46448, 735576399, -7636628672267015991L, -49611L, true, false, (char) 30518, (char) 37405,
        Double.longBitsToDouble(0x3fecf677d16869ceL), Double.longBitsToDouble(0x3fb82a93c15b48e8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 10, 5, 11, "\udb09\udcd3\udb5b\udd11\ud903\ude9d\ud954\ude31\udbfd\udf50\ud8e1\udc0b\ud9a0\ude0f\uda65\udf60\udb0e\uded1\ud888\udccc\ud8c8\uddd8\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\udbac\udd34\ud859\ude7c\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\udaad\udc15\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udb9a\udc2f\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda91\ude58\ud9de\udeec\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\ud867\udfc3\ud93e\udf83\ud81b\udc9a\uda5e\udd3f", "\ubc75\u0571", "\uda06\uddb2\uda75\ude25\udbe2\udc26\ud9b2\udded\udb18\ude4d\ud8b2\udef2\ud8b9\udeee\u4e91\ud978\udf44\ud9b4\ude26",
        17, 72398, -1388548227, -6380807533303392568L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a4397982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:\ud9b9\udd17\ud912\ude1a\ud9af\udcdf\ud954\ude6a\udbfd\udf50\ud8e1\udc92\udac8\udfcf\ud931\udffd\ud8cd\udfca\ud826\ude9c\ud9fd\udc76\ud895\udd00\uda35\udeb4\ud96b\udd71\udbbd\udde4\012",
        Z.run(T, 1, 9, 5, 11, "\ud9b9\udd17\ud912\ude1a\ud9af\udcdf\ud954\ude6a\udbfd\udf50\ud8e1\udc92\udac8\udfcf\ud931\udffd\ud8cd\udfca\ud826\ude9c\ud9fd\udc76\ud895\udd00\uda35\udeb4\ud96b\udd71\udbbd\udde4", "\u75e3\u469e\u6113\ua78d\u4848\u5671\u499d", "\uda23\udc1b\udb54\udc62\ud8aa\ude4e\udaaa\udd88\ud8a0\udf60\ud815\udf37\uda7f\udf6e\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d2\ude1a\ud89e\udd70\udbe2\udc33\ud908\uddea\udb30\udd5b\ud8e1\udfa0\uda25\udd8b\ue553\udb1d\uddf6\ud934\udffd\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\udb38\udd97",
        37, 6575, -1027910388, -3457629944518409370L, 92367L, true, false, (char) 58621, (char) 63061,
        Double.longBitsToDouble(0x3fe66e342900c7fdL), Double.longBitsToDouble(0x3fc89082ab134e40L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\uda50\udecc\ud9c8\udc27\udb5d\udfd3\ud954\ude1d\u8c61\ud85e\ude7d\ud8ce\udc35\udabd\udf32\udbe6\udc6a\ud871\uddae\ud96a\ude0e\udafd\udcb4\udbc5\ude97\ud940\udd70\udbc4\udfe4\uda4b\uddfc\ud950\udf77\uda7d\uddc1\ud9ad\udc0f\012",
        Z.run(T, 1, 9, 5, 0, "\uda50\udecc\ud9c8\udc27\udb5d\udfd3\ud954\ude1d\u8c61\ud85e\ude7d\ud8ce\udc35\udabd\udf32\udbe6\udc6a\ud871\uddae\ud96a\ude0e\udafd\udcb4\udbc5\ude97\ud940\udd70\udbc4\udfe4\uda4b\uddfc\ud950\udf77\uda7d\uddc1\ud9ad\udc0f", "\u2eab\ub91b\u499d\u76b9\u6440\ua877\u17e8", "\ud816\ude99\ud983\ude4f\ud8f3\udf5d\udb01\udf27\ud817\udd45\ud877\udf28",
        39, 43447, 481887976, 4470804297029795575L, 50754L, false, false, (char) 60197, (char) 55841,
        Double.longBitsToDouble(0x3fe6c95c068e85a5L), Double.longBitsToDouble(0x3feca59c700cbdb3L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud9d1\udff7\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud982\udcbb\uda6f\udc65\ud900\udcd9\udace\ude99\ud9ae\udf30\ua2ce\udab8\udc6c\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud9a9\udd19\ud8e4\ude63\ud93e\udc5f\uda25\udce2\ue553\ud920\udf17\udb70\udea9\ud970\udd98\ud97f\udd64\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u381f\u86ce\u03f5\u0e01\uc2f9\u410e\u30eb\ub8ba\uc90f\ucbc4\u163a\u4f4d\ud10e\u4d65\u4867\u3b99\u92ba\ua843\u8d99\u3d59\u221e\u53cd\u2fa0", "\ud829\udde2\udb4b\uddc5",
        3, 46191, 1788801868, 2252787092973698138L, 24454L, false, false, (char) 59341, (char) 8132,
        Double.longBitsToDouble(0x3fc9b13ff71bcba0L), Double.longBitsToDouble(0x3fb5b8c5b22b4d40L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\000\012",
        Z.run(T, 1, 9, 5, 11, "\000", "\u8273", "\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c",
        19, 16528, 983003940, 9162586578704448285L, 31072L, false, false, (char) 5792, (char) 27271,
        Double.longBitsToDouble(0x3fc932c0be738fd8L), Double.longBitsToDouble(0x3fd7a8051ea0b120L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 9, 5, 3, "", "\000\u91f6\u6ac2\u77fc\ucf51\u0abf\u9efc", "\000\udba8\udf73\ud942\udf71\udbbd\udde4",
        43, 95830, 357688448, 3159276575636405935L, 31172L, false, true, (char) 24544, (char) 40320,
        Double.longBitsToDouble(0x3fd0d53bc0f1381aL), Double.longBitsToDouble(0x3fe45dafff9ece86L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 3, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u606b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        24, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a53b7982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\012",
        Z.run(T, 1, 9, 1, 0, "\udb09\udcd3", "\u8273\000\000\000\000\000\u3d0f\u758e\u06d8\000\uc2a7\uba26\u46bc\u848a\u9dc4\ua545\u2eb5\ua78d\u4848\u5671\u499d\u7f8d\u7a97\ua8c2\u17e8\u8505", "\ud8aa\udd03",
        25, 59803, -1670419126, -6900916724345743914L, -16824L, false, false, (char) 37346, (char) 41305,
        Double.longBitsToDouble(0x3fe77683641e6581L), Double.longBitsToDouble(0x3fda685472a16d40L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:\uda2d\udcc5\ud9d5\ude00\udb6b\udfdb\ud958\udfb6\u449b\ud8fb\udf1a\ud998\udfd7\udb90\udf7b\udae9\udc1b\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\ud9aa\udc94\ud946\udf30\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\uda53\uddac\uda48\udfc3\ud8f5\ude49\ud850\udeac\ud8fc\udd3e\ud8c5\udea3\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\uda37\udf9e\ud92e\udf1f\ud802\udc9d\u38bc\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbd3\udd33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb25\udcf6\ud9c9\udc07\udacf\udfe1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9\012",
        Z.run(T, 1, 8, 5, 11, "\uda2d\udcc5\ud9d5\ude00\udb6b\udfdb\ud958\udfb6\u449b\ud8fb\udf1a\ud998\udfd7\udb90\udf7b\udae9\udc1b\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\ud9aa\udc94\ud946\udf30\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\uda53\uddac\uda48\udfc3\ud8f5\ude49\ud850\udeac\ud8fc\udd3e\ud8c5\udea3\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\uda37\udf9e\ud92e\udf1f\ud802\udc9d\u38bc\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbd3\udd33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb25\udcf6\ud9c9\udc07\udacf\udfe1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\u3e13\u0571\u0de5\u606b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        43, 11039, -1782320275, -1504508155911144970L, -5629L, true, false, (char) 12475, (char) 62109,
        Double.longBitsToDouble(0x3fd73edc34812e5cL), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\uda5e\udda8\udbb4\ude90\ud860\udf6a\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udf6f\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\udbd4\udf8e\uda8a\udc16\udb9d\udf6b\ud877\udf28\ud8d4\udde4\udaa0\udf0b\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\udaea\udf8b\udb36\udf06\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u226b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        52, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a53b7982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udbde\udda3\udbc5\udebd\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue529\udb1d\uddf6\ud9d3\udf07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u1e4d\u605a\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91\ud978\udf44\uda8d\ude33\udaa5\udeb2\u1093\ud95a\ude9c\ud805\udc23\ud9d5\ude9f\udb64\udce8\ud8b2\uddb3\udb04\udc69\ud857\udd3f\udade\udd7e\ud8d5\ude66\ud810\udc49\ud9f0\uddd7\u51d9\ud829\udde2\ud8a3\udf71\uda65\udead",
        45, 33281, 217168602, -1600772002656584113L, -56748L, true, true, (char) 28869, (char) 34692,
        Double.longBitsToDouble(0x3feca6ceed402570L), Double.longBitsToDouble(0x3fe8d71c46b656e7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 5, 11, "\udaa7\uddfd\udabe\udf8d\udb5e\udc0b\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\ud9cc\ude90\ud826\ude9c\uda5e\udd50\udaa9\udf9f\uda9c\udd17\ud942\udf71\ud845\udde8\uda4b\udd84\ud950\udf77\udbaa\udf38\ud9ad\udc35\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\udafb\udfd2\ud8ca\udc65\uda23\udc28\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\udbcd\udc6a\u40f0\udb98\udc1f\ud877\udf28\ud8d1\udde4\u5a07\ud962\udd96\udbe2\udc33\ud90a\udcea\udbef\uddb3\ubcf1\ud939\udfc1\ud90d\udcfc\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udb78\udfeb\uda71\udfbc\udbe6\ude3d\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\udb46\udc47\ud80a\udf19", "\ubc75\u0571\u9386\u606b\u4622\u041a\uc28e", "\udb10\udf81\ud8b9\udeee\udbe9\udddb",
        56, 50205, -1778536974, -1504508155911180419L, -78266L, false, true, (char) 64663, (char) 39137,
        Double.longBitsToDouble(0x3fc467add49d38e4L), Double.longBitsToDouble(0x3fe38a4d84b3ff49L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 5, 10, 3, "\ud893\udf14\ud9c8\udc1d\udb5d\udfd3\ud96e\udd39\ud91c\udf8c\udb2f\udc0d\udac8\udf37", "\u8902\ua509\u84e1\u60b0", "\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud9ab\udc85\ud81e\udc16\ud98b\udca4\ud8f7\uddc1\uda6f\udcba",
        6, 5907, -207652557, -7706048349779038902L, 41866L, false, false, (char) 46698, (char) 36747,
        Double.longBitsToDouble(0x3fe462dab3e9a070L), Double.longBitsToDouble(0x3fe77683641e6581L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 2, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u606b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        24, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a53b7982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\ud9ac\udd69\udb5d\udfd3\ud940\udf2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud9c8\udf8d\ud83c\udfc9\udab3\ude41\udb7b\udd60\udac2\udf15\udbbd\ude88\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8f6\uddd6\udb61\ude00\ud8aa\udd03\ud8f3\udf5d\udbe3\udf18\udbab\udce6\ud877\udf28\ud9c8\uddde\ud873\udebe\ud935\ude99\udbe2\udc33\ud90a\udcea\ud987\udcee\ud93e\udce9\uda25\udce2\ue553\ud9b6\udca1\udbed\udf73\ud840\udc05\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud8a0\udd34\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 5, 6, "\udb09\udcd3\ud9ac\udd69\udb5d\udfd3\ud940\udf2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud9c8\udf8d\ud83c\udfc9\udab3\ude41\udb7b\udd60\udac2\udf15\udbbd\ude88\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8f6\uddd6\udb61\ude00\ud8aa\udd03\ud8f3\udf5d\udbe3\udf18\udbab\udce6\ud877\udf28\ud9c8\uddde\ud873\udebe\ud935\ude99\udbe2\udc33\ud90a\udcea\ud987\udcee\ud93e\udce9\uda25\udce2\ue553\ud9b6\udca1\udbed\udf73\ud840\udc05\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud8a0\udd34", "\ubc75\u0571\ubbc5\u606b\u4622\u041a", "\udb93\ude51\udb10\udf81\ud8b9\udeee\ua4fc\ud98e\uded5\uda8d\udec3\udaa5\udeb2\u1093\ud95a\udf18\udbc9\udc25\ud9d5\ude9f\udb64\udce8\ud8b2\uddb3\udb04\udc69\ud857\udd3f\udade\udd7e\ud984\uddbe\uda98\ude16\ud9f0\uddd7\u51d9\ud829\udde2\ud853\udc49\uda6b\ude1e\uda69\uddd8",
        4, 96908, -1064981555, 2633057112218271997L, -90126L, false, true, (char) 51654, (char) 33410,
        Double.longBitsToDouble(0x3feadfc5f5519a0aL), Double.longBitsToDouble(0x3feb3b72672a4aa0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 2, 2, 10, "\udae0\udd73\ud9c8\udc27\udb5d\udfd3\ud954\ude2c", "\ucf51\u651e\u023b\u4a1d", "\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udab7\udd15\udac2\udcdf\ud884\uddc7\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0",
        -2, 95704, 1762521526, -8749112902551625704L, -62442L, true, false, (char) 30225, (char) 6440,
        Double.longBitsToDouble(0x3fcd05904b4872e4L), Double.longBitsToDouble(0x3fe462dab5470610L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 7, 9, 6, "\udae0\udd73\ud9c8\udc27\udaa6\ude77\ud954\ude2c", "\ucf51\u651e\u023b\u4a1d", "\udaa3\udf9f\ud942\udf7a\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70",
        43, 99204, 1485854074, 3544622420501621839L, -63256L, true, false, (char) 48676, (char) 52022,
        Double.longBitsToDouble(0x3fdb6aa4f056d21aL), Double.longBitsToDouble(0x3f988694bb7e73e0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 9, 6, "\ud877\udd4f\ud9c8\udc27\uda98\udd10\u7794", "\ucf51\u651e\u023b\u4a1d", "\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\u8100\uda7d\ude09\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\uda40\udd65\ud861\udd42\uda22\udf1b\uda5d\udfa0",
        -2, 95704, -49417802, -1225857668461783958L, -62442L, true, false, (char) 30225, (char) 6440,
        Double.longBitsToDouble(0x3fcd0e304b4872e4L), Double.longBitsToDouble(0x3fe462dab3e9a070L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\udae0\udd73\uda76\udf7f\udb5e\udc02\ud954\ude2c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 6, "\udae0\udd73\uda76\udf7f\udb5e\udc02\ud954\ude2c", "\ucf51\u651e\u023b\u4a1d", "\udbc5\ude97\ud942\udf71\udb25\uddf7\ud8b0\udd25\udbd1\uddf8\ud814\udfdf\ud9ce\udc1a\udba6\udc7a\udbfb\udf21\udad1\udd6d\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0",
        -2, 97627, 1762521444, -8749112904900435944L, -62442L, true, false, (char) 30225, (char) 6440,
        Double.longBitsToDouble(0x3fcd0e3059f2a2e4L), Double.longBitsToDouble(0x3fe376f853e9a070L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 10, 5, 11, "\udb09\udcd3\udb5b\udd11\ud903\ude9d\ud954\ude31\udbfd\udf50\ud8e1\udc0b\ud9a0\ude0f\uda65\udf60\udb0e\uded1\ud888\udccc\ud8c8\uddd8\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\udbac\udd34\ud859\ude7c\uda7d\uddc1\uda2c\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud913\ude88\ud850\udf29\ud003\uda5d\udf34\udaad\udc15\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\udaa0\udcf7\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udb9a\udc2f\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda91\ude58\ud9de\udeec\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\ud867\udfc3\ud93e\udf83\ud81b\udc9a\uda5e\udd3f", "\ubc75\u0571", "\uda06\uddb2\uda75\ude25\udbe2\udc26\ud9b2\udded\udb18\ude4d\ud8b2\udef2\ud8b9\udeee\u4e91\ud978\udf44\ud9b4\ude26",
        17, 72398, -1389596803, -6380807533555050808L, -41890L, true, false, (char) 44561, (char) 864,
        Double.longBitsToDouble(0x3fe38a4d849024e3L), Double.longBitsToDouble(0x3fdceb51a4397982L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:\uda50\udecc\ud93d\udee2\ud996\udd5c\ud926\udf55\u8d2c\uad24\uda88\udfe9\udabd\udf32\ud9a1\udd29\ud81e\udeab\ue4fd\udb11\udcf1\udbe5\udeac\ud940\udd70\ud806\udd44\uda53\udd72\ud950\ude9d\uda7d\uddc1\ud9ad\udc0f\0121=java.lang.String:\uda50\udecc\ud93d\udee2\ud996\udd5c\ud926\udf55\u8d2c\uad24\uda88\udfe9\udabd\udf32\ud9a1\udd29\ud81e\udeab\ue4fd\udb11\udcf1\udbe5\udeac\ud940\udd70\ud806\udd44\uda53\udd72\ud950\ude9d\uda7d\uddc1\ud9ad\udc0f\012",
        Z.run(T, 2, 9, 9, 9, "\uda50\udecc\ud93d\udee2\ud996\udd5c\ud926\udf55\u8d2c\uad24\uda88\udfe9\udabd\udf32\ud9a1\udd29\ud81e\udeab\ue4fd\udb11\udcf1\udbe5\udeac\ud940\udd70\ud806\udd44\uda53\udd72\ud950\ude9d\uda7d\uddc1\ud9ad\udc0f", "\u9da0\ub91b\u4970\u76b9\u4841\uc4e4\u9ea9", "\ud816\ude99\ud983\ude4f\ud990\udcad\udb01\udf27\ud81e\udf45\udae4\udd3d",
        1, 2711, 481887976, 4470804297029795575L, 4341L, false, false, (char) 60197, (char) 25381,
        Double.longBitsToDouble(0x3fe6c95ef06285a5L), Double.longBitsToDouble(0x3fc8bc0e47e6cec8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\udb5a\udf4c\0121=java.lang.String:\udb5a\udf4c\012",
        Z.run(T, 2, 9, 9, 11, "\udb5a\udf4c", "\u821f\u6ac2", "\ud800\udc28\uda92\udd8c\udace\udd59\ud823\ude5e\ub30a\udaef\udced",
        51, 25709, -1707343872, -3847845785491086208L, -18417L, false, true, (char) 51954, (char) 54731,
        Double.longBitsToDouble(0x3fea83431c3c10b9L), Double.longBitsToDouble(0x3fa24b443d0ed540L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 8, 9, "\uda2d\udcc5\ud9d5\ude00\udb6b\udfdb\ud958\udfb6\u449b\ud8fb\udf1a\udb93\udc53\udb90\udf7b\ud9de\udf17\ud8e1\udf21\ud9fd\udc9b\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\ud9aa\udc94\udbd3\udcdc\uda7d\uddc4\ud9ac\udfe4\ud852\udc70\uda53\uddac\uda48\udfc3\uda36\udd0a\ud850\udeac\ud8fc\udd3e\ud8c5\udea3\uda23\udc1b\uda5d\udfa0\udb11\udca8\ud95f\udff1\uda37\udf9e\ud92e\udf1f\ud802\udc9d\u38bc\udb9d\udf6b\ud877\udf28\udac0\udcd8\ud9d8\udf5a\ud92b\udff4\udbd3\udcf6\uda55\ude0e\ud8be\udcbb\ud93e\udce9\uda2f\udce7\ue553\udb25\udcf6\ud9c9\udc07\udacf\udfe1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\ud930\udd4d\ud9f9\udebd\ud897\udfa0\ud81f\udc5c", "\u3e13\u0571\u0de5\u606b\u4622\u041a\ube34", "\uda15\udfc9\udb18\udc47\ud87e\udfca",
        43, 11039, -1413221523, 4123943805257623894L, 73647L, true, true, (char) 2988, (char) 21345,
        Double.longBitsToDouble(0x3fc467adc9ac8ce4L), Double.longBitsToDouble(0x3fe59e703cb365ebL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 11, "\udb09\udcd3\udace\udc2a\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\uda5e\udda8\udbb4\ude90\ud860\udf6a\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udf6f\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\udbd4\udf8e\uda8a\udc16\udb9d\udf6b\ud877\udf28\ud8d4\udde4\udaa0\udf0b\ud935\ude99\udbe2\udc33\ud90a\udcea\uda81\udc1c\uda52\udd25\u61b8\udaea\udf54\udb36\udf06\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud97b\udea3", "\ubc75\u0571\u0de5\u226b\u4622\u041a\ube34\uc2f9\u410e\u30eb", "\ud84a\udf4d\uda8d\ude33\ud9b0\ude0a\u1084\ud95a\ude9c\ud8c9\udc25\ud9d5\ude9f\udb64\udce8\ud8b2\uddb3\udb04\udc69\ud857\udd3f\udade\udd7e\ud8d5\ude66\ud810\udc49\ud9e4\udef8\u51d9\ud829\udde2",
        43, 93397, 496147680, -4509573594847786074L, 43306L, false, false, (char) 444, (char) 63317,
        Double.longBitsToDouble(0x3fc4a2706b2bba0cL), Double.longBitsToDouble(0x3fd28770b9157c56L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 0, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud995\udec0\udbf8\udd69\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud863\udea0\udb05\udf63\u01e2\udbc5\ude97\ud942\udf71\ud938\ude41\uda3d\udef1\ud950\udf77", "\u9110\ua76f\u165c\uce98", "\ud850\udf29\udb83\udfeb\ud92e\udf98\ud8c6\udcb1",
        44, 81112, -2037061589, -5545443966799013339L, -35693L, false, true, (char) 50818, (char) 46769,
        Double.longBitsToDouble(0x3fe690e5ce8c5b56L), Double.longBitsToDouble(0x3fef4d0382eed06cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\ud829\udd55\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud90b\udd47\udab0\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\uda6f\udeaf\ud9ae\ude81\udbbd\ude9e\uda14\udc09\ud958\udd1b\uda0c\udee9\ud9ac\udfe4\ud852\udc70\ud9df\uddb5\uda64\uddf6\udbb4\ude90\ud860\udf6a\ud8fc\udd3e\u2886\ud816\udf67\uda5d\udf6f\ud8ae\udcd6\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud849\ude08\ud973\udf04\ud92d\udebe\ud877\udf28\ud8c0\udf15\udaa0\udf0b\ud935\ude99\udbe2\udc33\ud855\udd0e\ud8be\udd1b\ud949\ude83\ud872\udcd1\udb9b\udcbd\udb36\udf67\udb30\udffb\udae2\udee1\udaf6\udfab\uda65\udeef\uda8d\udc04\ud916\udff4\udb72\ude7b\u81c6\ud8a5\udf14\ud8bb\udfa3\ud839\udfd7\0121=java.lang.String:\udb09\udcd3\ud829\udd55\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud90b\udd47\udab0\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\uda6f\udeaf\ud9ae\ude81\udbbd\ude9e\uda14\udc09\ud958\udd1b\uda0c\udee9\ud9ac\udfe4\ud852\udc70\ud9df\uddb5\uda64\uddf6\udbb4\ude90\ud860\udf6a\ud8fc\udd3e\u2886\ud816\udf67\uda5d\udf6f\ud8ae\udcd6\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud849\ude08\ud973\udf04\ud92d\udebe\ud877\udf28\ud8c0\udf15\udaa0\udf0b\ud935\ude99\udbe2\udc33\ud855\udd0e\ud8be\udd1b\ud949\ude83\ud872\udcd1\udb9b\udcbd\udb36\udf67\udb30\udffb\udae2\udee1\udaf6\udfab\uda65\udeef\uda8d\udc04\ud916\udff4\udb72\ude7b\u81c6\ud8a5\udf14\ud8bb\udfa3\ud839\udfd7\012",
        Z.run(T, 2, 8, 8, 11, "\udb09\udcd3\ud829\udd55\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud90b\udd47\udab0\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\uda6f\udeaf\ud9ae\ude81\udbbd\ude9e\uda14\udc09\ud958\udd1b\uda0c\udee9\ud9ac\udfe4\ud852\udc70\ud9df\uddb5\uda64\uddf6\udbb4\ude90\ud860\udf6a\ud8fc\udd3e\u2886\ud816\udf67\uda5d\udf6f\ud8ae\udcd6\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud849\ude08\ud973\udf04\ud92d\udebe\ud877\udf28\ud8c0\udf15\udaa0\udf0b\ud935\ude99\udbe2\udc33\ud855\udd0e\ud8be\udd1b\ud949\ude83\ud872\udcd1\udb9b\udcbd\udb36\udf67\udb30\udffb\udae2\udee1\udaf6\udfab\uda65\udeef\uda8d\udc04\ud916\udff4\udb72\ude7b\u81c6\ud8a5\udf14\ud8bb\udfa3\ud839\udfd7", "\ubc75\u0571\u0de5\u226b\u4622\u041a\ube34", "\udb67\ude47\uda3b\udc67\udb73\udfed",
        43, 63003, -1778543374, -1504508154300224807L, -48311L, true, false, (char) 52064, (char) 864,
        Double.longBitsToDouble(0x3fe38a4d86d6d849L), Double.longBitsToDouble(0x3feab81310f38cceL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\000\000\000\udb8e\udec7\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\uda5e\udda8\udbb4\ude90\ud860\udf6a\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udf6f\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\udbd4\udf8e\uda8a\udc16\u6d4a\ud877\ude5b\ud5d6\udaa0\udeb4\ud935\ude99\udbe2\udc33\ud8fc\ude5e\ud8be\udd1b\ud93e\udce9\uda25\udce2\udaea\udf8b\udb36\udf06\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\000\000\000\uda87\udc63\ud81b\udd0f\ud80a\udea9", "\u5133\000\u0b42\u226b\u4622\u041a\ube34", "\udb10\udf81\uabe8\u4e91",
        52, 31093, 0, -1513209476185034883L, -100000L, false, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a53b7982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 2, 7, 3, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\udb57\uddb3\ud813\udda6\ud9d7\uddfe\udbdd\udd8b\ud942\udf71\udac2\udfa7\udb6c\udc3c\udbc5\udea3\uda7d\uddc1\ud9ac\udfe4\udb4a\udc7d\udbfb\udf21\uda5e\udda8\udbb4\ude90\ud860\udf6a\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udf6f\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\udbd4\udf8e\uda8a\udc16\udb9d\udf6b\ud877\udf28\ud8d4\udde4\udaa0\udf0b\ud935\ude99\udbe2\udc33\ud90a\udcea\ud843\udd1d\ud9f9\udfff\uda25\udce2\udaea\udf8b\udb36\udf06\ud9c9\udc07\udaa1\udeb0\udae0\udd71\uda65\udf68\ud9a1\udcd9\udbc0\udd23\ud898\ude45\u81c6\uda9c\udd6f\ud81b\udd0f\ud844\ude87", "\ubc75\u0571\u0de5\u226b\u4622\ua9bb\u252e", "\udb10\udf81\ud8b9\udeee\u4e91\ud84a\udf4d\uda8d\ude33\udaa5\udeb2\u1093\ud95a\ude9c\ud8c9\udc25\ud9d5\ude9f\udb64\udce8\ud8b2\uddb3\udb04\udc69\ud857\udd3f\udade\udd7e\ud9f3\ude63\ud810\udc49\ud9f0\uddd7\u51d9\ud829\udde2\udb03\udf60\uda5f\udf80",
        46, 52772, -2044569270, -8233393628076214928L, 91077L, true, true, (char) 37931, (char) 16213,
        Double.longBitsToDouble(0x3fe64307a8248f16L), Double.longBitsToDouble(0x3f9eb630605be900L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 7, "\udaa7\uddfd\udabe\udf8d\udb5e\udc0b\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\ud9cc\ude90\ud826\ude9c\uda5e\udd50\udaa9\udf9f\uda9c\udd17\ud942\udf71\ud845\udde8\uda4b\udd84\ud950\udf77\udbaa\udf38\ud9ad\udc35\ud852\udc70\udbfb\udf21\uda6a\ude11\uaabc\ud850\ude36\udafb\udfd2\ud8ca\udc65\uda23\udc28\uda5d\udfa0\ud8f7\uddda\ud852\ude1a\udb47\udffd\ud8aa\udd03\udbcd\udc6a\u40f0\udb98\udc1f\ud877\udf28\ud8d1\udde4\u5a07\ud962\udd96\udbe2\udc33\ud90a\udcea\udbef\uddb3\ubcf1\ud939\udfc1\ud90d\udcfc\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udb78\udfeb\uda71\udfbc\udbe6\ude3d\ud8d5\udc9a\ud89f\udeae\udbac\uddcb\uda9c\udd6f\udb46\udc47\ud80a\udf19", "\ubc75\u0571\u9386\u606b\u4622\u041a\uc28e", "\udb10\udf81\ud8b9\udeee\udbe9\udddb",
        56, 50205, -1778536974, -1504508155911180419L, -78266L, false, true, (char) 64663, (char) 39137,
        Double.longBitsToDouble(0x3fc467add49d38e4L), Double.longBitsToDouble(0x3fe38a4d84b3ff49L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 7, 7, 11, "\udaa7\uddfd\udabe\udf8d\udb5e\udc0b\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\ud9cc\ude90\ud84a\uddcd\udbbb\udda5\udaa9\udf9f\uda9c\udd17\ud942\udf71\ud845\udde8\uda4b\udd84\ud950\udf77\udbaa\udf38\ud9ad\udc35\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\udafb\udfd2\ud8ca\udc65\uda23\udc28\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\udbcd\udc6a\u40f0\udb98\udc1f\udaeb\udead\ud9b2\udeb6\u5a0d\udbfe\udca4\ud8a0\udc25\ud90a\udca9\uda69\udfb7\udb8d\ude98\udb0c\udc10\ud90d\udcfc\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udb78\udfeb\uda71\udfbc\udbe6\ude3d\uda41\udc48\ud8ab\udd63\u81c6\uda9c\udd6f\ud872\udcbc\uda2a\udf04", "\ua9f0", "\u8780",
        1, 77995, 978107766, 1385344988683899502L, 9544L, true, false, (char) 59489, (char) 28571,
        Double.longBitsToDouble(0x3fdf20e3a39d2bfaL), Double.longBitsToDouble(0x3fe4ef58f36c600fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 7, 7, 11, "\udaa7\uddfd\udabe\udf8d\udb8f\udee7\ud954\udea6", "\u880a\u651e\u998b\u1328", "\uda9c\udd17\ud942\udf71",
        23, 76963, 731033830, -1562216356578328160L, 20631L, false, true, (char) 54731, (char) 24544,
        Double.longBitsToDouble(0x3fc6062628ceb5d4L), Double.longBitsToDouble(0x3fc0ad248a2ed7fcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 2, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\udbc6\udc85\udbfd\udf3f\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\ude58\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\ud89b\udc0d\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u606b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        24, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fdce000053b7982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 10, "\ud980\udf4d\udbc7\udd8a\udb5d\udfd3\ud954\ude2c", "\u2fd9\u3691\u023b\u3b8e", "\udbc5\ude97\udbf7\udc7e\udb3f\udd14\uda4b\udd84\ud973\udffb\ud8ef\uddde",
        0, 62831, -470406967, -9200549901387837062L, 75439L, true, true, (char) 20273, (char) 27137,
        Double.longBitsToDouble(0x3fecf674373469ceL), Double.longBitsToDouble(0x3fe44aa2fae5b5d2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 2, 10, "\udae0\udd73\ud9c8\udc27\udb5d\udfd3\udbc5\udc24", "\u91b1\u9120\u023b\u4a1d", "\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udab7\udd15\udac2\udcdf\ud884\uddc7\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0",
        -2, 95704, 1762521526, -8749112868191887336L, -62442L, true, false, (char) 30225, (char) 6440,
        Double.longBitsToDouble(0x3fcd05904b4872e4L), Double.longBitsToDouble(0x3fe462dab5470610L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 10, "\udae0\udd73\ud9c8\udc27\udb5d\udfd3\ud954\ude2c", "\u16d9", "\ud9c6\udfaf\udbc9\udc3c\ud89f\uddf0\udb09\udcbc\ud8a0\udcf1\udbaa\udd7f\uda4b\udd84",
        15, 46448, 735576399, -7636628672267015991L, 42982L, true, false, (char) 40320, (char) 36639,
        Double.longBitsToDouble(0x3fcba18b8a2ed7fcL), Double.longBitsToDouble(0x3fecf674333e3cceL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\udae0\udd73\ud9c8\udc27\udaa6\ude70\ud954\ude2c\0121=java.lang.String:\udae0\udd73\ud9c8\udc27\udaa6\ude70\ud954\ude2c\012",
        Z.run(T, 2, 8, 9, 6, "\udae0\udd73\ud9c8\udc27\udaa6\ude70\ud954\ude2c", "\ucf51\u651e\u12b5\u4e8c", "\udaa3\udf9f\ud942\udf7a\ud916\udc6e\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9c8\udc0d\ud852\udc70",
        43, 44140, 1485854082, 3577273519652802333L, 67816L, true, true, (char) 48471, (char) 46134,
        Double.longBitsToDouble(0x3fdb6aa4f067441aL), Double.longBitsToDouble(0x3f988694bb7e73e0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 6, "\udae0\udd73\uda76\udf7f\udb5e\udc02\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udaba\udd67", "\u6cbe\u6095\uc287\u5c86", "\udb2b\ude70\ud94e\udd07\udba6\udc7a",
        43, 65756, 1795588474, 3552932712572283983L, -30270L, true, true, (char) 26506, (char) 20792,
        Double.longBitsToDouble(0x3f988694bb7e73e0L), Double.longBitsToDouble(0x3fd4a950e99b38deL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 6, "\udae0\udd73\udb00\udd23\udb5d\udfbb\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\udb09\udd44\ud9fc\ude6e\udbc2\udd1a\ud9fd\udc76\udafd\udcb4\ud859\udd57\udbaa\udcca", "\u8e0d\ub11f\u517c", "\udad1\udd6d\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda11\udd1b\uda5d\udfa0\ud8f7\uddda\udb2d\udf77\udb65\udc00\ud8aa\udd03",
        25, 59803, 644836682, -6900917029288421930L, -16824L, false, true, (char) 57893, (char) 1114,
        Double.longBitsToDouble(0x3fc468a99f169cc8L), Double.longBitsToDouble(0x3fe745208f8aa067L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 3, 3, 2, "\udae0\udd73\uda76\udf7f\udb5e\udc02\ud954\ude2c", "\ucf51\u651e\u023b\u4a1d", "\udbc5\ude97\ud942\udf71\udb25\uddf7\ud8b0\udd25\udbd1\uddf8\ud814\udfdf\ud9ce\udc1a\udba6\udc7a\udbfb\udf21\udad1\udd6d\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0",
        -2, 97627, 1762521444, -8749112904900435944L, -62442L, true, false, (char) 30225, (char) 53544,
        Double.longBitsToDouble(0x3fef438c167ca8b9L), Double.longBitsToDouble(0x3fe376f853e9a070L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 10, 10, 9, "\uda1f\udfc5\ud9d5\ude00\udb6b\udfdb\ud958\udfb6\u449b\ud8fb\udf1a\udb93\udc53\udb90\udf7b\ud9de\udf17\ud8e1\udf21\ud9fd\udc9b\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\ud9aa\udc94\udbd3\udcdc\uda7d\uddab\ud9ac\udfe4\ud852\udc70\uda53\uddac\uda48\udfc3\uda36\udd0a\ud8eb\uddd6\ud8fc\udd99\ud8c5\udea3\ud8aa\udcfe\uda5d\udfa0\udb11\udca8\udb4e\udd93\uda07\udf0c\ud92e\udf1f\ud802\udc9d\u38bc\udb9d\udf6b\ud877\udf28\udac0\udcd8\ud9d8\udf5a\ud92b\udff4\udbd3\udcf6\uda55\ude0e\ud8be\udcbb\ud93e\udce9\uda2f\udce7\ue553\udb25\udcf6\ud9c9\udc07\udacf\udfe1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\ud808\udfbd\ud9f9\udea7\ud897\udfa0\ud81f\udc5c", "\u3e13\u0571\u0de5\u606b\u4622\u041a\ube34", "\udbfa\udd3b",
        52, 80756, -104733924, -5910360164509944979L, 8886L, false, true, (char) 49010, (char) 20599,
        Double.longBitsToDouble(0x3fe01ead44cb3e96L), Double.longBitsToDouble(0x3fc467adc9ac8ce4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 10, 10, 9, "\uda2d\udcc5\uda61\udce5\udaf6\udfe5\ud8c3\udc0c\udb48\udc47\ud8fb\udf1a\udb93\udc53\udb90\udf7b\ud9de\udf17\ud8e1\udf21\ud9fd\udc9b\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\ud9aa\udc94\u567d\uda7d\uddc4\udb16\udfd9\ud852\udc70\ud80f\udce7\ud953\udc13\ud915\udd0e\ud87b\udccd\ud8d1\uddaa\ud8e0\udce3\uda23\udc1b\uda5d\udfa0\udb11\udca8\ud95f\udff1\uda37\udf9e\ud92e\udf1f\ud802\udc9d\u38bc\udb9d\udf6b\ud877\udf28\udac0\udcd8\ud9d8\udf5a\ud893\udcef\udbd3\udcf6\uda55\ude0e\ud8be\udcbb\ud93e\udce9\udb2c\udd25\ud97a\udc09\ud896\udc30\ud9c9\udc07\udacf\udfe1\udad9\udf1c\ud866\udc12\udb91\udc5c\ud8d5\udc9a\ud8d2\udf9f\ud86f\udcfb\ud993\udcb7\ud882\udcf9\ud81f\udc5c", "\u3e13\u0571\u0de5\u606b\u4622\u041a\ube34", "\uda15\udfc9\udb18\udc47\ud87e\udf86",
        43, 11039, -1413221523, 4123943805257623894L, 73647L, true, true, (char) 2988, (char) 21345,
        Double.longBitsToDouble(0x3fc467adc9ac8ce4L), Double.longBitsToDouble(0x3fe59e703cb365ebL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud845\udf21\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9\012",
        Z.run(T, 1, 9, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\uda7d\uddc1\ud9ac\udfe4\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud845\udf21\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u606b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        24, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a53b7982L), Double.longBitsToDouble(0x3fe2bf9810afb460L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 2, 10, "\udae0\udd73\000\udb5d\udfd3\udbc5\udc24", "\u90b7", "\u26a5\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84",
        15, 46448, 335, -7636628672267015991L, 19162L, true, false, (char) 0, (char) 46281,
        Double.longBitsToDouble(0x3fbe270340000000L), Double.longBitsToDouble(0x3e26800000000000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 8, 0, "", "\u37bc", "\000",
        23, 34877, -1674213127, 631733875323694971L, -52099L, true, false, (char) 18876, (char) 29142,
        Double.longBitsToDouble(0x3fd4f1551d5e57b0L), Double.longBitsToDouble(0x3fc932c0ad014bd8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 8, 0, "", "\ub75a", "\000",
        23, 34877, -1674213127, 631733875323694971L, -52099L, true, false, (char) 18876, (char) 29142,
        Double.longBitsToDouble(0x3fd4f1551d5e57d0L), Double.longBitsToDouble(0x3fc932c0ad014bd8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.String:\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 9, 6, 4, "", "\u37bc", "\000",
        23, 34877, -1674213127, 631733875323694971L, -52099L, true, false, (char) 58056, (char) 60797,
        Double.longBitsToDouble(0x3fd892223d5e778aL), Double.longBitsToDouble(0x3fc932c0ad014bd8L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\udb69\udf18\ud9ac\udfca\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9\012",
        Z.run(T, 1, 9, 5, 11, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\uda4b\udd84\ud950\udf77\udb69\udf18\ud9ac\udfca\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\ud850\ude36\ud8fc\udd3e\ud850\udf29\uda23\udc1b\uda5d\udfa0\ud8f7\uddda\ud8bf\udc5b\udb46\ude91\ud8aa\udd03\ud8f3\udf5d\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\udbe2\udc33\ud90a\udcea\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u606b\u4622\u041a\ube34", "\udb10\udf81\ud8b9\udeee\u4e91",
        24, 50205, -1778543374, -1504508155911180419L, -5629L, true, true, (char) 61472, (char) 35836,
        Double.longBitsToDouble(0x3fdceb51a13f432eL), Double.longBitsToDouble(0x3fe2bf9fe0afb460L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\udadf\udf51\udb6c\udfff\0121=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\udadf\udf51\udb6c\udfff\012",
        Z.run(T, 2, 9, 8, 0, "\udb54\udea0\ud838\udd61\udb7a\udffd&\udadf\udf51\udb6c\udfff", "\u8db2\uaa1e\ud2bd\u9a1a\u042e\u0d65\u7d44\u63a2\u4bb5\u9dc7\ua545\u05c1", "\udbeb\uddb4\ud904\uddba\ud9b4\ude1e\udb0d\udc74\uda57\udd11\udaa2\udd6c\uda2f\udd07\uda94\udcc9\ud901\ude66\ud881\uddaf",
        24, 71101, 1594089848, 6536423900207817038L, -30503L, false, false, (char) 52921, (char) 40047,
        Double.longBitsToDouble(0x3fdfba8cf495fc60L), Double.longBitsToDouble(0x3fd4514d0c9c4e70L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\udadf\udf51\udb6c\udfff\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 4, 0, "\udb54\udea0\ud838\udd61\udb7a\udffd&\udadf\udf51\udb6c\udfff", "\u8db2\uaa1e\ud2bd\u1829\uc641\u0d65\u4590\u2d90\u4bc8\u9dc7\ua545\u05c1", "\udbeb\uddb4\ud904\uddba\ud9b4\ude1e\udb0d\udc74\uda57\udd11\udaa2\udd6c\uda2f\udd07\uda94\udcc9\ud901\ude66\ud881\uddaf",
        24, 79829, -1914794440, 6536423899735368014L, 92723L, false, false, (char) 52921, (char) 40047,
        Double.longBitsToDouble(0x3fdfba8cf495fc60L), Double.longBitsToDouble(0x3fd4514d0c9c4e70L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 7, "\udb54\udea0\ud838\udd61\udb7a\udffd&", "\u2752\u5c5e\u9589\u9710\ud318\u9a1a\uc42b\ud02d\ucb17\ubb7e\u1661\u9dc7\ub445\u05c1\u0261\ubefe\u2128\u792c\uc0c5\u1a4a\u94d3\u8f4f\u4aef\uc205\u59b0", "\udbc1\udff3\ud83a\udc24\uda93\udc4f",
        -1, -947, 171307903, -5995587910863371282L, 71728L, false, false, (char) 2609, (char) 48517,
        Double.longBitsToDouble(0x3fde3d8bd3c05a3aL), Double.longBitsToDouble(0x3fe705c14746b287L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\0121=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\012",
        Z.run(T, 2, 9, 8, 1, "\udb54\udea0\ud838\udd61\udb7a\udffd&", "\u85cf\uc201\u7450\ubede\u2219\u14a6\u2684\ud43f\uc917\u97af\u3614\u0ff9\ua545\u1a61\uc655\ua689\u7864\u792c\u5d99\u4e53\u9512\u5025\u366c\ud717\u66ae", "\ud816\udf9a",
        8, 10784, 1715642702, 7259369409091014521L, -89083L, true, false, (char) 55370, (char) 56869,
        Double.longBitsToDouble(0x3fdf6d884ed1e3a0L), Double.longBitsToDouble(0x3fc84a81836ce92cL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\ud937\udddb\ud981\udf01\udbac\udd1f\ud9ca\udcd9\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\udb50\ude36\ud8fc\udd3e\ud888\udca4\uda23\udc96\uda5d\udfa0\ud8f7\uddda\uda99\udc8f\udb46\ude91\ud8fe\uddad\ud8db\ude65\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\ud9ad\udfd9\ud8a0\udcba\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9\012",
        Z.run(T, 1, 9, 5, 7, "\udb09\udcd3\ud9c8\udc27\udb5d\udfd3\ud954\ude2c\udbfd\udf50\ud8e1\udc92\udac8\udfcf\uda68\udd38\udb0e\uded1\ud826\ude9c\ud9fd\udc76\udafd\udcb4\udbc5\ude97\ud942\udf71\udbbd\udde4\ud937\udddb\ud981\udf01\udbac\udd1f\ud9ca\udcd9\ud852\udc70\udbfb\udf21\udaf2\udc15\ud848\udeb2\udb50\ude36\ud8fc\udd3e\ud888\udca4\uda23\udc96\uda5d\udfa0\ud8f7\uddda\uda99\udc8f\udb46\ude91\ud8fe\uddad\ud8db\ude65\uda4b\udf8d\udb9d\udf6b\ud877\udf28\ud8d4\udde4\ud9d8\udf07\ud935\ude99\ud9ad\udfd9\ud8a0\udcba\ud8be\udd1b\ud93e\udce9\uda25\udce2\ue553\udb1d\uddf6\ud9c9\udc07\udad0\udde1\udaf6\udfab\uda65\udeef\udb8f\udfe5\ud8d5\udc9a\ud89f\udeae\u81c6\uda9c\udd6f\ud81b\udd0f\ud80a\udea9", "\ubc75\u0571\u0de5\u606b\u4622\u90d7\ubdcc", "\udb10\udf81\ud997\ude7d\udb58\udd72",
        57, 60406, -1778543374, -1504508155911180419L, 8145L, true, false, (char) 10985, (char) 12127,
        Double.longBitsToDouble(0x3fe2bf9810afb460L), Double.longBitsToDouble(0x3fdbc77d29e45ff0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\000\000\0121=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\000\000\012",
        Z.run(T, 2, 9, 8, 0, "\udb54\udea0\ud838\udd61\udb7a\udffd&\000\000", "\u8db2", "\ud991\udc10\u44cb\uda33\udcd3",
        18, 54889, -1923915008, 1536260199937474895L, 55884L, true, true, (char) 30986, (char) 28987,
        Double.longBitsToDouble(0x3f3e9a7b36000000L), Double.longBitsToDouble(0x3fe331130a8da4e5L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.String:\udb66\uddf9\ud838\udd61\udb7a\udffd&\000\000\000\ud85e\uded9\ud9c3\ude17\ud90a\udc3e\ud9e3\udecd\ud991\udc10\u44cb\udb50\udf21\udb91\udc1c\uda7b\ude76\udbe2\ude7a\uda7d\uddc4\ud9ac\udfe4\udb8a\udfc5\uda9e\udcc0\ud96c\udfc8\012",
        Z.run(T, 2, 2, 8, 8, "\udb66\uddf9\ud838\udd61\udb7a\udffd&\000\000\000\ud85e\uded9\ud9c3\ude17\ud90a\udc3e\ud9e3\udecd\ud991\udc10\u44cb\udb50\udf21\udb91\udc1c\uda7b\ude76\udbe2\ude7a\uda7d\uddc4\ud9ac\udfe4\udb8a\udfc5\uda9e\udcc0\ud96c\udfc8", "\u5d99\u4e53\u7c25\u5025", "\ud985\udc94\udaad\ude53\udaf1\udeb5",
        16, 29980, 2001593310, -7054308721049776976L, 22350L, false, false, (char) 9773, (char) 45542,
        Double.longBitsToDouble(0x3feddf57d0c61cc3L), Double.longBitsToDouble(0x3fd4dbec8c8cff9aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.lang.String:\udb54\udea0\ud818\udc9e\udb80\udc28&\000\000\012",
        Z.run(T, 2, 7, 8, 0, "\udb54\udea0\ud818\udc9e\udb80\udc28&\000\000", "\u8db2", "\ud991\udc10\u44cb\uda33\udcd3",
        18, 54889, -1923915008, 1536260199937474895L, 55884L, true, true, (char) 30986, (char) 28987,
        Double.longBitsToDouble(0x3fcfb7ed3d995eacL), Double.longBitsToDouble(0x3fe331130a8da4e5L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 1, 0, "/", "\006\u017b\ua52e\u4e7a", "\ud8e1\udf21\ud9fd\udc9b\udafd\udcb4\ubd97\ud942\udf71",
        12, 83227, -993203809, 1536260197615303503L, 20631L, false, true, (char) 14554, (char) 34142,
        Double.longBitsToDouble(0x3fd9efe39c625f7cL), Double.longBitsToDouble(0x3fe30fa40c860c41L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\000\u0300\000\udaa5\udfb1\ud9c3\ude17\ud8c8\ude9d\ud9e3\udf1b\u3c10\0121=java.lang.String:\udb54\udea0\ud838\udd61\udb7a\udffd&\000\u0300\000\udaa5\udfb1\ud9c3\ude17\ud8c8\ude9d\ud9e3\udf1b\u3c10\012",
        Z.run(T, 2, 9, 8, 0, "\udb54\udea0\ud838\udd61\udb7a\udffd&\000\u0300\000\udaa5\udfb1\ud9c3\ude17\ud8c8\ude9d\ud9e3\udf1b\u3c10", "\uc141\u0252\u4b16\u9dc7", "\uda9e\udcc0\ua3c7\udbeb\uddb4\ud904\uddba\ud9b4\ude1e\udb0d\udc74\ud9b5\udc3a\udaa2\udd6c\ud925\udec1\udad9\udffd\ud9bb\ude2a\uda36\udf1a\ud8d2\udd28\udbcd\uded7\uda31\udd97\udbdc\udd93\ud8b7\udeb2\ud826\ude07\udbb5\udc37\uda51\udd6f\ud939\ude0d\ud9c1\udece\udb4b\udd93\udb45\udf89\udb85\uddbd\udb0c\udf24\uda98\udd75\ud9e7\udc5b\uda13\udd16\ud84d\udce3\ud898\udf34",
        6, 50254, 1888465042, 8074670482540300389L, -85863L, false, true, (char) 49134, (char) 13299,
        Double.longBitsToDouble(0x3fee5d70dbf3c029L), Double.longBitsToDouble(0x3fc78e8dcd53d934L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud92c\udd42\udb7a\udffd&4\ud9e0\udc8d\0121=java.lang.String:\udb54\udea0\ud92c\udd42\udb7a\udffd&4\ud9e0\udc8d\012",
        Z.run(T, 2, 9, 8, 0, "\udb54\udea0\ud92c\udd42\udb7a\udffd&4\ud9e0\udc8d", "\u8cd1\uaa1e\u2303", "\uda33\udcf7\ud888\udee4\ue251\udbd3\udc3d",
        11, 56647, -1793180792, -7605384881398868330L, 93403L, false, false, (char) 41181, (char) 28221,
        Double.longBitsToDouble(0x3fab0b5dede4c700L), Double.longBitsToDouble(0x3fcf2dcf6bba4e74L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud95a\udc18\udb7a\udffd&4\ud9e0\udc8d\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 8, "\udb54\udea0\ud95a\udc18\udb7a\udffd&4\ud9e0\udc8d", "\u8cd1\u2a1e\u2303", "\uda33\udcf7\u0421\ud802\udd6f\udb3d\udd33",
        4, 56647, -1793180792, -7605384881398868330L, 93403L, false, false, (char) 41181, (char) 28221,
        Double.longBitsToDouble(0x3fab0b5dede4c700L), Double.longBitsToDouble(0x3fcf2dcf6bba4e74L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud83c\uddca\udb7a\uddde&4\012",
        Z.run(T, 1, 9, 8, 8, "\udb54\udea0\ud83c\uddca\udb7a\uddde&4", "\u5b80\u8cd1\uaa1e\u2303", "\uda33\udcf7\ud888\udee4\ue251\udbd3\udc3d",
        11, 56647, -1793180792, -7605384881398868330L, -3474L, true, true, (char) 42106, (char) 17731,
        Double.longBitsToDouble(0x3fad3e7cbc24a010L), Double.longBitsToDouble(0x3fc0ba026ac1f6d4L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud83c\uddca\udb7a\uddde&4\0121=java.lang.String:\udb54\udea0\ud83c\uddca\udb7a\uddde&4\012",
        Z.run(T, 2, 9, 8, 8, "\udb54\udea0\ud83c\uddca\udb7a\uddde&4", "\u5b80\u8cd1\uaa1e\u2303\ubc2c\u27b9\uadd4\uc141\u0252\u4b16\u9dc7\u9b43\u8cda\u01a7\u528c", "\ud8dc\udf78\ud86e\uddb6\ud8fe\uded5\udbc5\udd38",
        20, 92722, -1697903678, 8266152228070599243L, -19244L, true, true, (char) 48847, (char) 41962,
        Double.longBitsToDouble(0x3fdc3aa6cd40d680L), Double.longBitsToDouble(0x3fba869f4f4e59f0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud83c\uddca\udb7a\uddde&A\012",
        Z.run(T, 1, 9, 8, 8, "\udb54\udea0\ud83c\uddca\udb7a\uddde&A", "\u5b80\u8cd1\uaa1e\u2303", "\uda33\udcf7\ud888\udee4\ue251\udbd3\udc3d",
        11, 56647, -1793180792, -7605384881398868330L, -3474L, true, true, (char) 42106, (char) 17731,
        Double.longBitsToDouble(0x3fad3e7cbc24a010L), Double.longBitsToDouble(0x3fc0ba026b420ed4L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.String:\ud95f\ude20\ud80d\uddba\udb7a\uddde&A\0121=java.lang.String:\ud95f\ude20\ud80d\uddba\udb7a\uddde&A\012",
        Z.run(T, 2, 9, 8, 8, "\ud95f\ude20\ud80d\uddba\udb7a\uddde&A", "\u5b80\u8cd1\uaa1e\u2303", "\ud8a0\udd8b\ud888\udee4\ue251\udbd3\udc3d",
        11, 2997, -1781457281, -7605384881398868330L, -3474L, true, true, (char) 42106, (char) 17731,
        Double.longBitsToDouble(0x3fec70efcbc24a11L), Double.longBitsToDouble(0x3fd85d0134e411c6L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud92c\udd42\udb7a\udffd&j\ud9e0\udc8d\0121=java.lang.String:\udb54\udea0\ud92c\udd42\udb7a\udffd&j\ud9e0\udc8d\012",
        Z.run(T, 2, 9, 8, 11, "\udb54\udea0\ud92c\udd42\udb7a\udffd&j\ud9e0\udc8d", "\u8cd1\uaa1e\u2303", "\uda4b\udc19\ud888\udee4\ue251\udbd3\udc3d\uda7d\uddc4",
        17, 73208, -1770766657, -3163753903364611860L, -100000L, true, true, (char) 54504, (char) 21618,
        Double.longBitsToDouble(0x3fe611e8a4858ed4L), Double.longBitsToDouble(0x3fe583edab0965d4L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud92c\udd42\udb7a\udffd&j\udabc\udebb\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 5, 11, "\udb54\udea0\ud92c\udd42\udb7a\udffd&j\udabc\udebb", "\u8cd1\uaa1e\u2303", "\uda4b\udc19\ud888\udee4\ue251\udbd3\udc3d\uda7d\uddc4",
        17, 73208, -1770766657, -3163753903364611860L, -100000L, true, true, (char) 54504, (char) 21618,
        Double.longBitsToDouble(0x3fe611e8a4858ed4L), Double.longBitsToDouble(0x3fe583edab0965d4L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\uddf0\udb04\udcb9\ud8d4\udce9\u00c2\udadf\udf51\udb6c\udfff\udb84\ude19\ud85e\udf9b\ud9c3\ude17\ud90a\udc3e\ud9e3\udecd\ud991\udc10\u44cb\ud90f\ude01\ud8ad\udee6\ud938\udcdc\udad0\udddd\uda6d\udea8\ud9ac\udfe4\udb8a\udfc5\uda9e\udcc0\ua3c7\udbeb\uddb4\ud904\uddba\uda06\udf59\udb28\ude3c\uda57\udd11\udaa2\udd6c\uda29\udccd\uda94\udcc9\ud901\ude66\ud881\uddaf\ud9c8\udc12\ud816\udf9a\ud9ad\udf11\ud9f6\udc40\ud8c9\udf7e\udb7f\udc64\udbf8\udc12\udac9\udfa8\ud863\udfba\uda47\udceb\uda99\udddf\uc384\udadd\udf94\ud986\udebd\uda8e\udf61\udb4f\udc88\uda54\udf80\uda82\udc58\ud97e\udf3f\u2a31\ud964\ude19\ud830\udec0\ud92e\udc18\ud9da\udde6\udb9c\udf64\ud945\udc9e\ud8d8\ude42\udb94\udc50\uda92\udcac\ud99d\udde2\uff11\ud9d2\udc28\ud9b4\udc24\ue7e3\ud8ed\udcfa\udbbb\udfc1\ud81c\udddd\ud97e\udc4d\u2ecb\ud991\udf17\0121=java.lang.String:\udb54\uddf0\udb04\udcb9\ud8d4\udce9\u00c2\udadf\udf51\udb6c\udfff\udb84\ude19\ud85e\udf9b\ud9c3\ude17\ud90a\udc3e\ud9e3\udecd\ud991\udc10\u44cb\ud90f\ude01\ud8ad\udee6\ud938\udcdc\udad0\udddd\uda6d\udea8\ud9ac\udfe4\udb8a\udfc5\uda9e\udcc0\ua3c7\udbeb\uddb4\ud904\uddba\uda06\udf59\udb28\ude3c\uda57\udd11\udaa2\udd6c\uda29\udccd\uda94\udcc9\ud901\ude66\ud881\uddaf\ud9c8\udc12\ud816\udf9a\ud9ad\udf11\ud9f6\udc40\ud8c9\udf7e\udb7f\udc64\udbf8\udc12\udac9\udfa8\ud863\udfba\uda47\udceb\uda99\udddf\uc384\udadd\udf94\ud986\udebd\uda8e\udf61\udb4f\udc88\uda54\udf80\uda82\udc58\ud97e\udf3f\u2a31\ud964\ude19\ud830\udec0\ud92e\udc18\ud9da\udde6\udb9c\udf64\ud945\udc9e\ud8d8\ude42\udb94\udc50\uda92\udcac\ud99d\udde2\uff11\ud9d2\udc28\ud9b4\udc24\ue7e3\ud8ed\udcfa\udbbb\udfc1\ud81c\udddd\ud97e\udc4d\u2ecb\ud991\udf17\012",
        Z.run(T, 2, 9, 8, 0, "\udb54\uddf0\udb04\udcb9\ud8d4\udce9\u00c2\udadf\udf51\udb6c\udfff\udb84\ude19\ud85e\udf9b\ud9c3\ude17\ud90a\udc3e\ud9e3\udecd\ud991\udc10\u44cb\ud90f\ude01\ud8ad\udee6\ud938\udcdc\udad0\udddd\uda6d\udea8\ud9ac\udfe4\udb8a\udfc5\uda9e\udcc0\ua3c7\udbeb\uddb4\ud904\uddba\uda06\udf59\udb28\ude3c\uda57\udd11\udaa2\udd6c\uda29\udccd\uda94\udcc9\ud901\ude66\ud881\uddaf\ud9c8\udc12\ud816\udf9a\ud9ad\udf11\ud9f6\udc40\ud8c9\udf7e\udb7f\udc64\udbf8\udc12\udac9\udfa8\ud863\udfba\uda47\udceb\uda99\udddf\uc384\udadd\udf94\ud986\udebd\uda8e\udf61\udb4f\udc88\uda54\udf80\uda82\udc58\ud97e\udf3f\u2a31\ud964\ude19\ud830\udec0\ud92e\udc18\ud9da\udde6\udb9c\udf64\ud945\udc9e\ud8d8\ude42\udb94\udc50\uda92\udcac\ud99d\udde2\uff11\ud9d2\udc28\ud9b4\udc24\ue7e3\ud8ed\udcfa\udbbb\udfc1\ud81c\udddd\ud97e\udc4d\u2ecb\ud991\udf17", "\uccee\u997c\u1ada\u1e51", "\uda23\ude29\ud9e6\ude59\ud9ae\udcef\ud939\udc0e\ud813\udee0\ud959\udce4",
        4, 92485, 572906401, -6312237271454991440L, -93206L, true, false, (char) 52036, (char) 59725,
        Double.longBitsToDouble(0x3fda584b3016edf8L), Double.longBitsToDouble(0x3fd134433ac4f3fcL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud838\udd61\ud86a\udd75&\000\000\0121=java.lang.String:\udb54\udea0\ud838\udd61\ud86a\udd75&\000\000\012",
        Z.run(T, 2, 9, 8, 0, "\udb54\udea0\ud838\udd61\ud86a\udd75&\000\000", "\u8db2", "\ud991\udc10\u44cb\uda33\udcd3",
        18, 54889, -1923915008, 1536260199937474895L, 55884L, true, true, (char) 30986, (char) 28987,
        Double.longBitsToDouble(0x3f3e9a7b36000000L), Double.longBitsToDouble(0x3fe331130a8da4e5L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:\ud988\udd59\uda84\udf08\udb7a\uddde&\014\012",
        Z.run(T, 1, 9, 8, 8, "\ud988\udd59\uda84\udf08\udb7a\uddde&\014", "\u5b80\u54b7\u19b4\u2303", "\uda33\udcf7\ud888\udfd8\ue251\udbd3\udc3d\udb53\udd90\udb97\udd32",
        8, 65343, -736618858, 5850845431674639643L, -3474L, true, true, (char) 42106, (char) 17731,
        Double.longBitsToDouble(0x3fad3e7cec24a010L), Double.longBitsToDouble(0x3fc0ba10aac1f6d4L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:\ud988\udd59\uda84\udf08\udb7a\uddde&\014\0121=java.lang.String:\ud988\udd59\uda84\udf08\udb7a\uddde&\014\012",
        Z.run(T, 2, 9, 8, 8, "\ud988\udd59\uda84\udf08\udb7a\uddde&\014", "\u5b80\u54b7\u19b4\u2303", "\uda33\udcf7\ud888\udfd8\ue251\udbd3\udc3d\udb53\udd90\udb97\udd32",
        8, 65343, -736618858, 5850845431674639643L, -3474L, true, true, (char) 42106, (char) 17731,
        Double.longBitsToDouble(0x3fad3e7cec24a010L), Double.longBitsToDouble(0x3fc0ba10aac1f6d4L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud92c\udd42\udb7a\udffd&;\ud9e0\udc8d\ud847\udf10\ud85e\uded9\ud988\uded8\ue6b6\0121=java.lang.String:\udb54\udea0\ud92c\udd42\udb7a\udffd&;\ud9e0\udc8d\ud847\udf10\ud85e\uded9\ud988\uded8\ue6b6\012",
        Z.run(T, 2, 9, 8, 0, "\udb54\udea0\ud92c\udd42\udb7a\udffd&;\ud9e0\udc8d\ud847\udf10\ud85e\uded9\ud988\uded8\ue6b6", "\ubb07\uadd4\uc141\u5fb8", "\ud963\udf5f\ud9f5\udd3b\uda9e\udc86\udaee\udd89\udb7a\udd02\ud9a8\uddd6\ud8be\udc1c\ud826\udcc8\u34c6\udbc4\udfde\uda84\udcf8\ud9cd\ude25\uda97\udc16\ud9d6\udfed\ud8ee\udcb0\uda57\udced\udbe3\udf34",
        46, 90105, -1818394573, -9026855303158055154L, -21106L, false, false, (char) 57918, (char) 59231,
        Double.longBitsToDouble(0x3fcbfd6a86f8da70L), Double.longBitsToDouble(0x3fe3424756150344L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udea0\ud92c\udd42\udb66\ude8a&;\ud9e0\udc8d\ud847\udf10\ud85e\uded9\ud988\uded8\udb5b\udcb6\udb0e\udd4f\udbb0\udf40\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 4, 11, "\udb54\udea0\ud92c\udd42\udb66\ude8a&;\ud9e0\udc8d\ud847\udf10\ud85e\uded9\ud988\uded8\udb5b\udcb6\udb0e\udd4f\udbb0\udf40", "\uc141\u5fb8\u8574\u37db", "\uda9e\udc86\udaee\udd89\udb7a\udd02\ud9a8\uddd6\ud8be\udc1c\ud826\udcc8\u34c6\udbc4\udfde\uda84\udcf8\ud9cd\ude25\uda97\udc16\ud9d6\udfed\ud8ee\udcb0",
        14, 31734, -210741194, -795616472627052493L, 47698L, true, false, (char) 24448, (char) 52896,
        Double.longBitsToDouble(0x3feeca7331acf5b3L), Double.longBitsToDouble(0x3fcbfd6a86f8da70L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,org.jsoup.nodes.Document$OutputSettings|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.StringBuilder,java.lang.String,org.jsoup.nodes.Document$OutputSettings,boolean,boolean,boolean|static",
    "M|org.jsoup.nodes.Entities|canEncode|org.jsoup.nodes.Entities$CoreCharset,char,java.nio.charset.CharsetEncoder|static",
    "M|org.jsoup.nodes.Entities|getCharacterByName|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|isBaseNamedEntity|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|isNamedEntity|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|loadEntities|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|toCharacterKey|java.util.Map|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String,boolean|static",
    "C|org.jsoup.nodes.Entities|<init>|",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,org.jsoup.nodes.Document$OutputSettings|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.StringBuilder,java.lang.String,org.jsoup.nodes.Document$OutputSettings,boolean,boolean,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
