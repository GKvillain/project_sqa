package org.jsoup.select;
import org.junit.Test;
import static org.junit.Assert.*;
public class Selector_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 13, 10, 1, "\ud987\udc3b\uda65\udfa5\ud9b9\udde6", "\u261b\ub6a0\u1b7a\u0d60", "\udb44\udcb6\udaf6\uddb5\ud9ad\udeb4\udb05\udd8d\udada\udef2\ud95b\udf9b\ud9a8\ude20\ud844\uddca\udafb\udf3b\ud82b\udc0a",
        47, 58802, 131267443, -167457663165723716L, 69967L, false, false, (char) 65427, (char) 27363,
        Double.longBitsToDouble(0x3fd80958c5192ff2L), Double.longBitsToDouble(0x3fdded389f69ff7aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 1, "\ud9e2\udf22\uda6c\udcb2\ud9b9\udde6", "\u261b\ub6a0\u1b7a\u0cc5\ub428\u7c04\u05fc\u24b9\u4519\uc87b\uc4f0\uc60f\u8832\ua688\u3102\u17fd\u771c\u5287\uccb8\u6e80\u8b1a\ubad3", "\uda86\udc90\ud8fc\udffe\ud8f2\udd46\ud85a\ude7c\udaa1\udf40\ud8e7\uddff\udbb5\udeab\uda21\ude43\uda44\udf5e\ud8c2\udded\ue9da\ud939\uded4\ud929\udd15\ud9cd\udf85\udb0f\udd42\udb68\udda6\ud9e7\udc48\ud8ac\ude93\udbcc\udd2f",
        -4, 98463, 1335742438, 1954788532198450937L, 1130L, false, true, (char) 14344, (char) 21436,
        Double.longBitsToDouble(0x3fe35a64e67e9b2bL), Double.longBitsToDouble(0x3fe4abef1a8af681L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 10, 1, "\ud987\udc3b\uda65\udfa5\ud9b9\udde6", "\u1781\u67a0\u1b7a\u0d60", "\udb44\udcb6\udaf6\uddb5\ud9ad\udeb4\udb05\udd8d\udada\udef2\ud95b\udf9b\ud9a8\ude20\ud844\uddc1\udafb\udf3b\ud82b\udc0a",
        47, 17450, 1466956659, 4428044484707815487L, 69967L, false, false, (char) 65427, (char) 27363,
        Double.longBitsToDouble(0x3fe91af4628c97f9L), Double.longBitsToDouble(0x3fcbda713ed3fef4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 1, "\ud8d7\udde3\uda66\udc2b\ud9b9\udde6", "\u6a43\uac1d\uc3b7\u1d18\u89f8\u7c04\u05fc\u24b9\u4519\uc87b\u3288\u0c11\u6a42\ucc1b\u3fcf\u8123\u4fee\u5287\uccb8\ubf63\u6422", "\ud910\udf76",
        4, 6410, -1961559011, 4581424163674744926L, 2253L, true, true, (char) 46860, (char) 53893,
        Double.longBitsToDouble(0x3fdded389f69ff7aL), Double.longBitsToDouble(0x3fe4efc5d523214eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 9, 1, "\ud987\udc3b\uda65\udfa5\ud8b9\udffc", "\u261b\ub6a0\u1b7a\u0d60", "\ud843\udebc\udb44\ude33\ud9a6\uddba\udb05\udd8d\udada\udef2\udb46\udfdf\ud9ca\udfa7\ud844\udde0\udafb\udf3b\ud82b\udc0a",
        47, 58802, 131267443, -167457663165723716L, 69967L, false, false, (char) 2750, (char) 13597,
        Double.longBitsToDouble(0x3fd80958c5192ff2L), Double.longBitsToDouble(0x3fdded389f69ff7aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 10, 12, "\ud987\udc3b\uda65\udfa5\ud9b9\udde6\udabb\udede\udb3d\uddc3\udb6f\udce4\ud9ed\udf72\u40c3", "\u7c04\u05fc\u24b9\u4519\uc87b\uc4f0\uc60f\u8832\uabc2\u1ea7\ub7cc\u456d\ucbfe", "\ud8ef\udc32\ud885\udc2e\u724b\uda71\ude46\ud891\udea8\ud9e0\ude67\ud8f2\udd46\ud85a\ude7c\udab9\ude40\ud8e7\uddff\ud91a\udfb1\udbff\udfb2\uda44\udf5e\ud891\udfed\ue9da",
        42, 58637, 560454906, 8564808192780859007L, 14737L, false, false, (char) 4763, (char) 25780,
        Double.longBitsToDouble(0x3fe552b3f6fc663bL), Double.longBitsToDouble(0x3fdc67f57dec4216L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 10, 1, "\ud82a\udcb9\udbea\udc7b\ud8f5\udfb8", "\u261b\ub6a0\u1b7a\u0d60\ub428\u7c04", "\ud9ad\udeb4\udb05\udd8d\udada\udef2\ud95b\udf9b\ud9a8\ude20\ud844\uddca\udafb\udf3b\ud82b\udc0a\udb9a\udf13\udb0e\udd56",
        3, 96725, -2145973316, 3482761720544878841L, 69967L, false, false, (char) 65427, (char) 27363,
        Double.longBitsToDouble(0x3fd80958c5192ff2L), Double.longBitsToDouble(0x3fdded389e72b57aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 14, 11, 12, "\ud987\udc3b\uda65\udfa5\ud9b9\udde6", "\u4384\u12aa\u677e\u9cc8", "\udb25\udc81\udaf6\uddb5\uda4e\udd4a\udb05\udd8d\udada\udef2\ud95b\udf9b\ud9a8\ude20\ud844\uddca\ud863\udeae\ud82b\udc0a",
        47, 58802, 131267443, -167457663165723716L, 69967L, false, false, (char) 58259, (char) 27363,
        Double.longBitsToDouble(0x3fd80958c5192ff2L), Double.longBitsToDouble(0x3fdded389f69ff7aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 11, 11, 0, "\udb9f\udd68\uda65\udf95\ud9b6\ude26", "\u08c6\u7fd5\u65ae\u0d60\u699b\u7c04\u2c57\u4f76\u44f9\uc87b\uc4f0\uc60f\u8832", "\ud82b\udc0a\udb9a\udf13\udb0e\udd6d",
        10, 96725, -2145973316, 4154762334606713081L, 64067L, true, false, (char) 273, (char) 50657,
        Double.longBitsToDouble(0x3fc271e011257ba8L), Double.longBitsToDouble(0x3fdfa94642572ff2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 10, 1, "\ud987\udc3b\uda65\udfa5\ud9b9\udde6", "\u261b\ub6a0\u1b7a\u0cdd", "\udb44\udcb6\udaf6\uddb5\ud9ad\udeb4\uda22\udedb\udac2\udff6\ud95b\udf9b\uda73\udd49\ud84d\udcd3\udafb\udf3b\ud82b\udc0a",
        35, 37307, -197368723, 3327884244918740027L, 28788L, false, false, (char) 43153, (char) 35584,
        Double.longBitsToDouble(0x3fe8ecf6e5ff9cecL), Double.longBitsToDouble(0x3f91c46b951c2720L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 10, 6, 15, "\u5501\ud99c\udec1\ud9b9\udde6", "\u261b\u615f\u1b7a\u0d60", "\udb44\udcb6\udaf6\uddb5\ud9ad\udeb4\udb05\udd8d\uda38\udde4\ud956\ude66\ud9a8\ude20\ud844\uddca\udafb\udf3b\ud82b\udc0a",
        47, 58802, 131267443, -167457663165723649L, 69967L, false, false, (char) 65427, (char) 27363,
        Double.longBitsToDouble(0x3fd80958c5192ff2L), Double.longBitsToDouble(0x3fdded389f69ff7aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 1, "", "\000\000K", "",
        39, 1529, 148, 0L, -16985L, false, false, (char) 39589, (char) 7095,
        Double.longBitsToDouble(0x3e4424dc70000000L), Double.longBitsToDouble(0x3fd04c800bdb3bc4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 13, 10, 1, "\ud987\udc3b\uda65\udfa5\ud9b9\udde6", "\u261b\ub6a0\u1b7a\u0d60", "\udb44\udcb6\udaf6\uddb5\ud9ad\udeb4\udb05\udd8d\udada\udef2\ud95b\udf9b\000\ud844\uddc1\udafb\udf3b\ud82b\udc0a",
        47, 58802, 131267443, -167457663165723716L, 69967L, false, false, (char) 65427, (char) 27363,
        Double.longBitsToDouble(0x3fd80958c5192ff2L), Double.longBitsToDouble(0x3fdded389000017aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.select.Selector|combinator|char|new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|consumeSubQuery||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|addElements|java.util.Collection|new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|allElements||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|byAttribute||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|byClass||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|byId||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|byTag||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|consumeIndex||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|contains|boolean|new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|filterForAdjacentSiblings|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|filterForChildren|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|filterForDescendants|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|filterForGeneralSiblings|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|filterForParentsOfDescendants|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|filterForSelf|java.util.Collection,java.util.Collection|static",
    "M|org.jsoup.select.Selector|combinator|char|new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
    "M|org.jsoup.select.Selector|consumeSubQuery||new:org.jsoup.select.Selector:java.lang.String,org.jsoup.nodes.Element",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
