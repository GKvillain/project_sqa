package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class W3CDom_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 0, "\ud903\udee8\ud865\udebe\ud98f\udcdd\udb44\udec3", "\u4103\u2168\ucf45\u4370\ud7e8\u0b1c\u919e\u6ebb\ub82d\u83ad\u0a31\u64bc\u6e81\u4a78\uaab8\u1f61\u3c67", "\udb9c\ude21\udaa5\udfb8\ud9cf\udd46\uda7a\udffa\uda8f\udd9c\udb33\udd4f\uda16\udf72\udab9\ude4e\ud96c\udf4c\ud9a9\ude91",
        31, 89833, -337723448, -6608721210625910028L, 87802L, false, true, (char) 34807, (char) 62342,
        Double.longBitsToDouble(0x3fadf3694d9d9a70L), Double.longBitsToDouble(0x3fee18fdc6de4408L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 0, "\ud903\udee8\ud865\udebe\ud98f\udcdd\udb44\udec3", "\u4103\u2168\ucf45\u4370\ud7e8\u0b1c\u919e\u6ebb\ub82d\u83ad\u0a31\u64bc\u6e81\u4a78\ucfbc\000\ubae9", "\udb9c\ude21\udaa5\udfb8\ud9cf\udd46\uda7a\udffa\uda8f\udd9c\udb33\udd4f\uda16\udf72\udab9\ude4e\ud96c\udf4c\ud9a9\ude91",
        31, 89833, -337723448, -6608721210625910028L, 87802L, false, true, (char) 34807, (char) 62342,
        Double.longBitsToDouble(0x3fadf3694d9d9a70L), Double.longBitsToDouble(0x3fee18fdc6de4408L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 0, "\udaa1\udc6c\uf45e\ud96d\ude9f\ud948\udcc1", "\u1028\u2150\u2954\u1332\ud7e8\u5ff7\u54b9\u6ebb", "\ud907\ude6c",
        -2, 7027, -1961055279, -8086829148766032485L, -38051L, false, false, (char) 33529, (char) 25887,
        Double.longBitsToDouble(0x3fc99bed0b792ff8L), Double.longBitsToDouble(0x3fdb412dedb1fce6L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 0, "\ud903\udee8\ud865\udebe\ud98f\udcdd\udb44\udec3", "\u4103\u2168\ucf45\u4370\uc4a8\u368b\u2267\u6e83\ub82d\u83ad\u0a31\u64bc\u6e81\u4a78\uaab8\u1f61\u3c67", "\udb9c\ude21\udaa5\udfb8\ud9cf\udd46\uda7a\udffa\uda8f\udd9c\udb33\udd4f\uda16\udf72\udab9\ude4e\ud96c\udf4c\ud9a9\ude91",
        -2, 17841, -832029380, -6608720355927418124L, 87802L, false, true, (char) 34807, (char) 62342,
        Double.longBitsToDouble(0x3fadf3694d9d9a70L), Double.longBitsToDouble(0x3fee1905c6de4408L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\0121=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udafb\ude8b\ud918\udcec\ud9d6\udefd\udaf1\uded7\udbb7\ude11\ud9ce\ude76\ud89a\udc7f\ud9c1\udc3a\ud89c\udf6a\uda22\udea9\uda18\udeff\ud992\uddc6\udb44\uddf1", "\u3ebb\u0a31\u64bc\u6e81\u4a78", "\ud997\udd9c\ud894\udc07\ud883\udf33\udb9c\ude21\udaa5\udfb8\ud9cf\udd46\udaec\udd53\uda8f\udd9c\udb33\udd4f\uda16\udf72\udab9\ude4e\ud96c\udf4c\ud9a9\ude91\uda51\udf8d\udb03\udf0f\udbe6\udd38\ud937\uddf2\ud965\udff3\ud960\udfe6\ud8f2\udcb9\udb36\udce7\uda48\udd45\ud852\udcd4\ud9dd\uddf8\uda33\udeb7\ud984\udfc5\ud8ac\udd71\ud956\udf2c",
        -4, 20940, -1405407843, -6558748348651582881L, -10577L, true, true, (char) 45908, (char) 51000,
        Double.longBitsToDouble(0x3feb9d271491825cL), Double.longBitsToDouble(0x3fec42bc9b5ca95fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "\ud903\udee8", "\ub9bc", "\037",
        -5, -1000, 0, -5836665118124810887L, -95328L, false, false, (char) 26173, (char) 57684,
        Double.longBitsToDouble(0x3fd43c150a97bb9cL), Double.longBitsToDouble(0x3fe912242fbc5730L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 0, "\ud903\udee8\ud865\udebe\ud98f\udcdd\udb44\udec3", "\u4103\u2168\ucf45\u4370\ud7e8\u0b1c\u919e\u6ebb\ub82d\u83ad\u0a31\u64bc\u6e81\u4a78\uaab8\u1f61\u3c67", "\udb9c\ude21\udaa5\udfb8\ud9cf\udd46\uda7a\udffa\uda8f\udd9c\udb33\udd4f\uda16\udf72\udab9\ude4e\ud96c\udf4c\ud9a9\ude91",
        31, 89833, -337723448, -6608721210625910028L, 87802L, false, true, (char) 34807, (char) 62342,
        Double.longBitsToDouble(0x3fa7f3694d9d9a70L), Double.longBitsToDouble(0x3fee18fdc6de4408L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 0, "\u43ba\udade\ude98\ud8b8\ude58\ud8c5\udfdd\udbb7\udd2f\udac5\udc75\ud89a\udc7f\udab0\udeb5\uda6d\udd21", "\u0b1c\u99f3\u541a\u1c88\u83ad", "\ud963\udc2c\ud94d\ude60\udaa7\ude2c\ud9e5\udcc9",
        36, 90059, 2139367640, 310811426804088352L, -2751L, true, true, (char) 14887, (char) 3283,
        Double.longBitsToDouble(0x3fb19b8a496e4a18L), Double.longBitsToDouble(0x3fecfce2247aee22L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\0121=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\012",
        Z.run(T, 2, 0, 0, 2, "\ud903\ude82\ud865\udebe\ud867\udfea\udb44\udec3\udbb7\ude11\udac5\udc75\ud89a\udc7f\ud932\udef2\ud8f3\udeb9\uda22\udf49\uda18\udf05\ud992\uddc6\udbfa\udfad\udbfe\udcee\ud8ae\uddee\ud98c\udd56\ud8ea\udccb\ud862\udf3f\ud8db\udd7c\udaba\udf21\ucfbc\uda5c\ude0d", "\u923e\ud03f\u77bd\u62dd\u1afd\u8407\u2016", "\ud96c\udf4c\ud9a9\ude91\uda51\udf8d",
        23, 19552, -1538712813, -3671107749014426164L, 11364L, false, false, (char) 62342, (char) 28445,
        Double.longBitsToDouble(0x3fcb3b34ff0c7ee0L), Double.longBitsToDouble(0x3fe6f220408c8d03L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 0, "\ud903\udee8\ud865\udebe\ud98f\udcdd\udb1d\uddef", "\ub06f\u6542\ucf45\u4370\ud7e8\u0b1c\u919e", "\ud98c\udd56\ud8ea\udccb\ud862\udf3f\udb00\udd54\ud966\udc45",
        54, 46483, 1173707133, 7385043556763452218L, 72331L, true, false, (char) 20188, (char) 2194,
        Double.longBitsToDouble(0x3febf7f39af31ee0L), Double.longBitsToDouble(0x3fb5e02d096b2a18L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.W3CDom|asString|org.w3c.dom.Document|new:org.jsoup.helper.W3CDom:",
    "M|org.jsoup.helper.W3CDom|convert|org.jsoup.nodes.Document,org.w3c.dom.Document|new:org.jsoup.helper.W3CDom:",
    "M|org.jsoup.helper.W3CDom|fromJsoup|org.jsoup.nodes.Document|new:org.jsoup.helper.W3CDom:",
    "C|org.jsoup.helper.W3CDom|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
