package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class DocumentType_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\ud8ea\udc41\u2877\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\ud8ea\udc41\u2877\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d\">\012",
        Z.run(T, 1, 4, 4, 0, "\ud922\ude88\udb04\udf5c", "\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47", "\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\ud8ea\udc41\u2877\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d",
        -2, 29608, 152228079, -6817715654680267194L, -54203L, false, false, (char) 61590, (char) 47675,
        Double.longBitsToDouble(0x3fd5a417f5c174b6L), Double.longBitsToDouble(0x3fd923027c1b5d6aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud882\udfe1\000\u5fe8\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\ud8ea\udc41\u2877\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d\">\012",
        Z.run(T, 1, 1, 0, 1, "\ud922\ude88\udb04\udf5c", "\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47", "\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud882\udfe1\000\u5fe8\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\ud8ea\udc41\u2877\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d",
        -2, 29608, 152228079, -6817715654680267194L, -54203L, false, false, (char) 61590, (char) 47675,
        Double.longBitsToDouble(0x3fd5a417f5c174b6L), Double.longBitsToDouble(0x3fd923027c1b5d6aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u7dab\u265c\u0dc5\u6920\u8569\u1ba4\u2762\u70d8\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udaf3\udc40\ud829\udcee\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d\">\012",
        Z.run(T, 1, 2, 1, 0, "\ud922\ude88\udb04\udf5c", "\u7dab\u265c\u0dc5\u6920\u8569\u1ba4\u2762\u70d8\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47", "\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udaf3\udc40\ud829\udcee\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d",
        -2, 29608, 152228079, -2926605574326976110L, 88901L, false, false, (char) 61590, (char) 47675,
        Double.longBitsToDouble(0x3fd5a417f5c174b6L), Double.longBitsToDouble(0x3fd923027c1b5d6aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 2, 4, "\ud922\udedc\udb04\udf5c", "\u5881\u265c\u0dc5\u6920\u1323\u862c\u2762\ua62c\ub59a\uc8fd\u0ab2\uac19\u491c\u4f47", "\udb39\udd45\uda26\udc5c\ud9f0\udf9d\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\udbc4\udd7e\ud81b\uded5\ud8fa\udd5a\ud93a\udc03\ud98c\udd40\ud8ac\ude6e",
        47, 71246, -356703074, 4527812705363928634L, 80971L, true, false, (char) 26078, (char) 50085,
        Double.longBitsToDouble(0x3fc2ee1adc64ff98L), Double.longBitsToDouble(0x3fce9828103b1158L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\udb1a\udfd3\uda8c\udff3\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\udb1a\udfd3\uda8c\udff3\">\012",
        Z.run(T, 1, 4, 4, 0, "\ud922\ude88\udb04\udf5c", "", "\udb1a\udfd3\uda8c\udff3",
        43, 46071, 506567577, -6744776933250868825L, 30455L, true, false, (char) 58901, (char) 35823,
        Double.longBitsToDouble(0x3fd09edc9e1817f2L), Double.longBitsToDouble(0x3fc50135b90ab2d4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 0, 0, "", "", "",
        -5, -1000, 1339801375, -2743371398205428070L, 5369L, true, true, (char) 64524, (char) 46406,
        Double.longBitsToDouble(0x3fe34cd65835af3eL), Double.longBitsToDouble(0x3fec66344cddb712L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u5881\u25e6\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u25e6\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udb6f\udc7b\u287e\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb5c\udddb\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\ud8b9\udc2d\ud870\udf79\ud8bd\ude7d\ud897\udf0d\ud80f\ude7d\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u25e6\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udb6f\udc7b\u287e\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb5c\udddb\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\ud8b9\udc2d\ud870\udf79\ud8bd\ude7d\ud897\udf0d\ud80f\ude7d\">\0121=void |a0=java.lang.StringBuilder:\ud922\ude88\udb04\udf5c<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u25e6\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udb6f\udc7b\u287e\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb5c\udddb\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\ud8b9\udc2d\ud870\udf79\ud8bd\ude7d\ud897\udf0d\ud80f\ude7d\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u25e6\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udb6f\udc7b\u287e\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb5c\udddb\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\ud8b9\udc2d\ud870\udf79\ud8bd\ude7d\ud897\udf0d\ud80f\ude7d\">\012",
        Z.run(T, 2, 4, 4, 0, "\ud922\ude88\udb04\udf5c", "\u5881\u25e6\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47", "\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udb6f\udc7b\u287e\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb5c\udddb\ud94c\udf21\udb61\udd9f\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\ud8b9\udc2d\ud870\udf79\ud8bd\ude7d\ud897\udf0d\ud80f\ude7d",
        -2, 29608, 152228079, -6817715654680267194L, -54203L, false, false, (char) 61590, (char) 47675,
        Double.longBitsToDouble(0x3fd5a417f5c174b6L), Double.longBitsToDouble(0x3fd92302701b5d6aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u0978\u25a0\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u52fe\uabfe\u491c\u4f47\ua73a\u9a84\u01f1\u3bbe\" \"\ud9c7\udcc3\ud899\udede\u6048\udb95\udf45\ud9b1\udc64\ud9a9\udf50\udab9\udf5f\ud8ac\ude6e\uc0dc\ud84a\udce2\ud8c8\udf64\">\0121=void |a0=java.lang.StringBuilder:\u0978\u25a0\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u52fe\uabfe\u491c\u4f47\ua73a\u9a84\u01f1\u3bbe<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u0978\u25a0\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u52fe\uabfe\u491c\u4f47\ua73a\u9a84\u01f1\u3bbe\" \"\ud9c7\udcc3\ud899\udede\u6048\udb95\udf45\ud9b1\udc64\ud9a9\udf50\udab9\udf5f\ud8ac\ude6e\uc0dc\ud84a\udce2\ud8c8\udf64\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u0978\u25a0\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u52fe\uabfe\u491c\u4f47\ua73a\u9a84\u01f1\u3bbe\" \"\ud9c7\udcc3\ud899\udede\u6048\udb95\udf45\ud9b1\udc64\ud9a9\udf50\udab9\udf5f\ud8ac\ude6e\uc0dc\ud84a\udce2\ud8c8\udf64\">\012",
        Z.run(T, 2, 1, 4, 2, "\ud922\ude88\udb04\udf5c", "\u0978\u25a0\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u52fe\uabfe\u491c\u4f47\ua73a\u9a84\u01f1\u3bbe", "\ud9c7\udcc3\ud899\udede\u6048\udb95\udf45\ud9b1\udc64\ud9a9\udf50\udab9\udf5f\ud8ac\ude6e\uc0dc\ud84a\udce2\ud8c8\udf64",
        57, 83709, -1469310215, 403420803200897092L, 19544L, true, false, (char) 28415, (char) 44596,
        Double.longBitsToDouble(0x3f8d88adffbe3c40L), Double.longBitsToDouble(0x3fabc615bfe86ab0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\036\u265c\u0dc5\u6920\u8569\u1ba4\u2762\u70d8\ub59a\ua1e1\ud32e\uac38\u491c\u50c2\" \"\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udaf3\udc40\ud829\udcee\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\ud8c6\udf12\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d\">\012",
        Z.run(T, 1, 2, 1, 0, "\ud922\ude88\udb04\udf5c", "\036\u265c\u0dc5\u6920\u8569\u1ba4\u2762\u70d8\ub59a\ua1e1\ud32e\uac38\u491c\u50c2", "\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\ud98c\udd40\ud8ac\ude6e\uc0dc\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udb23\ude86\ud9ee\udd2a\uda1f\udd10\udaf3\udc40\ud829\udcee\ud909\udf96\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udabd\udeb6\udb5c\udeaa\ud94c\udf21\ud8c6\udf12\u385a\ud973\udd52\ud9a8\ude51\ud83f\udcd6\udb87\udfe2\ud986\uddc7\udaac\udc67\uda87\ude9e\ud8ef\udc57\ud897\udf0d\ud80f\ude7d",
        -4, 29608, 152228079, -2926605574326976110L, 88901L, false, false, (char) 61590, (char) 47675,
        Double.longBitsToDouble(0x3fd5a417f5c174b6L), Double.longBitsToDouble(0x3fd923027c1b5d6aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder: |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \uc06f\000 \"\udb1a\udfd3\uda69\udc01\ud80b\udea9\000\ud9f7\udd60\udbfe\udf43\ud909\ude9f\ud86a\udefa\uda7b\udda6\">\012",
        Z.run(T, 1, 3, 1, 0, "\uc06f\000", "", "\udb1a\udfd3\uda69\udc01\ud80b\udea9\000\ud9f7\udd60\udbfe\udf43\ud909\ude9f\ud86a\udefa\uda7b\udda6",
        42, 64956, -305539875, 862985824737545996L, -16478L, false, false, (char) 23857, (char) 6995,
        Double.longBitsToDouble(0x3fed087b40607ad6L), Double.longBitsToDouble(0x3fca7fcd244b5bd0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE \000> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \000>\012",
        Z.run(T, 1, 4, 2, 1, "\000", "", "",
        28, 35375, -654311360, -4107372255602862698L, -100000L, true, true, (char) 46406, (char) 40244,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f46e248ebb72400L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\udb1a\udfd3\uda8c\udff3\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\udb1a\udfd3\uda8c\udff3\">\0121=void |a0=java.lang.StringBuilder:\ud922\ude88\udb04\udf5c<!DOCTYPE \ud922\ude88\udb04\udf5c \"\udb1a\udfd3\uda8c\udff3\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\udb1a\udfd3\uda8c\udff3\">\012",
        Z.run(T, 2, 4, 4, 0, "\ud922\ude88\udb04\udf5c", "", "\udb1a\udfd3\uda8c\udff3",
        15, 46071, 506567577, -6744776933250868825L, 30455L, true, false, (char) 58872, (char) 35823,
        Double.longBitsToDouble(0x3fdafedc9e1817f2L), Double.longBitsToDouble(0x3fc50135b90ab2d4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\037\000\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\037\000\">\012",
        Z.run(T, 1, 4, 4, 0, "\ud922\ude88\udb04\udf5c", "", "\037\000",
        43, 46071, 506567577, -6744776933250868825L, 30455L, true, false, (char) 58901, (char) 35823,
        Double.longBitsToDouble(0x3fd09edc9e1817f2L), Double.longBitsToDouble(0x3fc50135a002b2d4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud8bb\udf6d\udb04\udfbe PUBLIC \"\u58dc\u9096\ucffe\u4267\u936a\u1ba4\u2762\u3450\u7ace\u4800\u443f\ua111\ua01e\u6188\u2ead\uc7c9\u5385\u57bf\ua1a0\u3e82\ub0cd\u3ed5\u2d74\u4bbb\u1056\u18bd\" \"\udb60\ude17\udb68\uddc9\udbb7\udf81\ud83a\udf06\ud9fb\udfdc\">\0121=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud8bb\udf6d\udb04\udfbe PUBLIC \"\u58dc\u9096\ucffe\u4267\u936a\u1ba4\u2762\u3450\u7ace\u4800\u443f\ua111\ua01e\u6188\u2ead\uc7c9\u5385\u57bf\ua1a0\u3e82\ub0cd\u3ed5\u2d74\u4bbb\u1056\u18bd\" \"\udb60\ude17\udb68\uddc9\udbb7\udf81\ud83a\udf06\ud9fb\udfdc\">\012",
        Z.run(T, 2, 2, 2, 4, "\ud8bb\udf6d\udb04\udfbe", "\u58dc\u9096\ucffe\u4267\u936a\u1ba4\u2762\u3450\u7ace\u4800\u443f\ua111\ua01e\u6188\u2ead\uc7c9\u5385\u57bf\ua1a0\u3e82\ub0cd\u3ed5\u2d74\u4bbb\u1056\u18bd", "\udb60\ude17\udb68\uddc9\udbb7\udf81\ud83a\udf06\ud9fb\udfdc",
        58, 25861, -1888423283, 8576879113321754780L, -84246L, false, true, (char) 21678, (char) 25224,
        Double.longBitsToDouble(0x3fb35b10aa050e20L), Double.longBitsToDouble(0x3fee3f1f731bdf65L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\007>\012",
        Z.run(T, 1, 1, 2, 0, "\ud922\ude88\007", "", "",
        -5, 4040, -1828737382, 14517294403158169L, 73657L, true, false, (char) 40244, (char) 65395,
        Double.longBitsToDouble(0x3fc198d13376dc48L), Double.longBitsToDouble(0x3fd09edc900017f2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\uda13\udf54 PUBLIC \"\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47\ua73a\u4e82\u5efb\u4c23\u170c\u5338\u5e1e\u97c0\ua66e\u9c2d\u49b5\u1256\u8005\ucdcb\u314e\u1488\u136b\u3824\" \"\ud9b9\udd69\udbaf\udc60\">\0121=new org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\uda13\udf54 PUBLIC \"\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47\ua73a\u4e82\u5efb\u4c23\u170c\u5338\u5e1e\u97c0\ua66e\u9c2d\u49b5\u1256\u8005\ucdcb\u314e\u1488\u136b\u3824\" \"\ud9b9\udd69\udbaf\udc60\">\012",
        Z.run(T, 2, 1, 1, 2, "\ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\uda13\udf54", "\u6920\u8569\u1ba4\u2762\ua62c\ub59a\uc8fd\u0ab2\ud462\u491c\u4f47\ua73a\u4e82\u5efb\u4c23\u170c\u5338\u5e1e\u97c0\ua66e\u9c2d\u49b5\u1256\u8005\ucdcb\u314e\u1488\u136b\u3824", "\ud9b9\udd69\udbaf\udc60",
        18, 40424, 1072081047, -4521562242460226316L, -70537L, true, false, (char) 34217, (char) 24739,
        Double.longBitsToDouble(0x3fe28452dd92cd0fL), Double.longBitsToDouble(0x3fd3ea91395c53bcL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:#doctype |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud8f7\udd72\udab2\udde7 \"\uda69\udc01\uda12\udc2d\ud895\ude3e\ud9f7\udd02\udbfe\udf43\ud909\ude9f\ud913\uddce\ud821\udf64\ud80f\udcf1\udaae\udf3c\ud8e4\udd14\ud94c\ude31\u5f9e\ud80b\udece\udb51\ude69\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\udb73\udfba\udb10\udced\ud8fe\udf62\udac1\ude71\udb0a\ude9d\ud98c\udd40\ud948\udc7c\uf340\ud97b\udc29\ud8c8\udf28\ud9e1\uddda\">\012",
        Z.run(T, 1, 2, 0, 0, "\ud8f7\udd72\udab2\udde7", "\036", "\uda69\udc01\uda12\udc2d\ud895\ude3e\ud9f7\udd02\udbfe\udf43\ud909\ude9f\ud913\uddce\ud821\udf64\ud80f\udcf1\udaae\udf3c\ud8e4\udd14\ud94c\ude31\u5f9e\ud80b\udece\udb51\ude69\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\udb73\udfba\udb10\udced\ud8fe\udf62\udac1\ude71\udb0a\ude9d\ud98c\udd40\ud948\udc7c\uf340\ud97b\udc29\ud8c8\udf28\ud9e1\uddda",
        52, 36785, 93928725, 5029060925774962708L, 8695L, true, true, (char) 44596, (char) 32215,
        Double.longBitsToDouble(0x3fefd6314a43c4dcL), Double.longBitsToDouble(0x3fcfdc12cb10dd50L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\011<!DOCTYPE \000 \"\udb1a\udfd3\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \000 \"\udb1a\udfd3\">\012",
        Z.run(T, 1, 4, 4, 2, "\000", "\011", "\udb1a\udfd3",
        20, 45874, 467503322, 13963355123127025L, -100000L, false, false, (char) 6974, (char) 51094,
        Double.longBitsToDouble(0x3feb80c10e9d3f9eL), Double.longBitsToDouble(0x3f82464b2601f940L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\037\000\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\037\000\">\0121=void |a0=java.lang.StringBuilder:\ud922\ude88\udb04\udf5c<!DOCTYPE \ud922\ude88\udb04\udf5c \"\037\000\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c \"\037\000\">\012",
        Z.run(T, 2, 4, 4, 0, "\ud922\ude88\udb04\udf5c", "", "\037\000",
        -4, 46071, 506527744, -6744776933250868825L, 30455L, true, false, (char) 58872, (char) 35823,
        Double.longBitsToDouble(0x3fdafedc9e1817f2L), Double.longBitsToDouble(0x3fc50135b90ab2d4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\011<!DOCTYPE \000 \"\udb29\udcd3\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \000 \"\udb29\udcd3\">\0121=void |a0=java.lang.StringBuilder:\000<!DOCTYPE \000 \"\udb29\udcd3\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \000 \"\udb29\udcd3\">\012",
        Z.run(T, 2, 4, 4, 2, "\000", "\011", "\udb29\udcd3",
        20, 26418, 467503322, 13963355123127025L, -100000L, true, true, (char) 6974, (char) 51197,
        Double.longBitsToDouble(0x3fe53bf90c89049eL), Double.longBitsToDouble(0x3febfb0946b420ebL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE \ud80c\udc7c\udb1d\udd54> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud80c\udc7c\udb1d\udd54>\0121=void |a0=java.lang.StringBuilder:\ud80c\udc7c\udb1d\udd54<!DOCTYPE \ud80c\udc7c\udb1d\udd54> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud80c\udc7c\udb1d\udd54>\012",
        Z.run(T, 2, 4, 4, 0, "\ud80c\udc7c\udb1d\udd54", "", "\037",
        -5, 3096, 3342336, 2175520093426269469L, 76075L, true, true, (char) 35823, (char) 57208,
        Double.longBitsToDouble(0x3ecf32a000000000L), Double.longBitsToDouble(0x3fb0ab2d6ece2f48L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\" \"\ud80f\udcd2\udaee\udf3f\ud8d0\udfca\udaa6\uddbd\u5f9e\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c PUBLIC \"\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a\" \"\ud80f\udcd2\udaee\udf3f\ud8d0\udfca\udaa6\uddbd\u5f9e\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\">\012",
        Z.run(T, 1, 4, 4, 2, "\ud922\ude88\udb04\udf5c", "\u5881\u265c\u0dc5\u6920\u8569\u1ba4\u2762\ua62c\ub59a", "\ud80f\udcd2\udaee\udf3f\ud8d0\udfca\udaa6\uddbd\u5f9e\ud9ad\udfbf\ud851\udfc1\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048",
        1, 56826, -505889261, 9134251981743134035L, -70702L, false, false, (char) 61544, (char) 58639,
        Double.longBitsToDouble(0x3fe7cc45bd15a86cL), Double.longBitsToDouble(0x3fb1016640a22e50L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\011<!DOCTYPE \000> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \000>\0121=void |a0=java.lang.StringBuilder:\000<!DOCTYPE \000> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \000>\012",
        Z.run(T, 2, 4, 4, 2, "\000", "\011", "\037",
        -5, 26418, 467503322, 13963355291123712L, -100000L, false, true, (char) 6974, (char) 51197,
        Double.longBitsToDouble(0x3fe53bf90c89049eL), Double.longBitsToDouble(0x3fe8030946b420ebL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:<!DOCTYPE o\udb1d\udd4d> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE o\udb1d\udd4d>\0121=void |a0=java.lang.StringBuilder:o\udb1d\udd4d<!DOCTYPE o\udb1d\udd4d> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE o\udb1d\udd4d>\012",
        Z.run(T, 2, 4, 0, 0, "o\udb1d\udd4d", "", "",
        -5, -1000, 4096, 14355223815454720L, -100000L, true, false, (char) 40244, (char) 20595,
        Double.longBitsToDouble(0x3feb7e344cddb712L), Double.longBitsToDouble(0x3fd00000000001f2L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\u6b47\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\udaee\udf3f\ud8c0\udeca\udaa6\uddbd\u5f9e\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud8ac\udece\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb32\udddb\ud94c\udf21\udb61\udd9f PUBLIC \"\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\u6b47\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\" \"\udb9a\udfb2\ud8c0\udc6e\uda41\uddb3\udb8f\uded6\ud892\udeda\ud90a\ude18\ud802\udc50\ud89b\udfac\udaea\udf91\udb63\udc78\udae6\ude58\ud959\uddf3\ud832\udcb2\ud8d9\udd31\ud9e6\udc3e\udb8d\udfbe\u2c0c\ud81a\udfa0\udbb2\ude8e\udb5c\uddc1\"> |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\udaee\udf3f\ud8c0\udeca\udaa6\uddbd\u5f9e\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud8ac\udece\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb32\udddb\ud94c\udf21\udb61\udd9f PUBLIC \"\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\u6b47\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\" \"\udb9a\udfb2\ud8c0\udc6e\uda41\uddb3\udb8f\uded6\ud892\udeda\ud90a\ude18\ud802\udc50\ud89b\udfac\udaea\udf91\udb63\udc78\udae6\ude58\ud959\uddf3\ud832\udcb2\ud8d9\udd31\ud9e6\udc3e\udb8d\udfbe\u2c0c\ud81a\udfa0\udbb2\ude8e\udb5c\uddc1\">\0121=void |a0=java.lang.StringBuilder:\ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\udaee\udf3f\ud8c0\udeca\udaa6\uddbd\u5f9e\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud8ac\udece\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb32\udddb\ud94c\udf21\udb61\udd9f<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\udaee\udf3f\ud8c0\udeca\udaa6\uddbd\u5f9e\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud8ac\udece\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb32\udddb\ud94c\udf21\udb61\udd9f PUBLIC \"\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\u6b47\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\" \"\udb9a\udfb2\ud8c0\udc6e\uda41\uddb3\udb8f\uded6\ud892\udeda\ud90a\ude18\ud802\udc50\ud89b\udfac\udaea\udf91\udb63\udc78\udae6\ude58\ud959\uddf3\ud832\udcb2\ud8d9\udd31\ud9e6\udc3e... |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\udaee\udf3f\ud8c0\udeca\udaa6\uddbd\u5f9e\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud8ac\udece\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb32\udddb\ud94c\udf21\udb61\udd9f PUBLIC \"\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\u6b47\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\" \"\udb9a\udfb2\ud8c0\udc6e\uda41\uddb3\udb8f\uded6\ud892\udeda\ud90a\ude18\ud802\udc50\ud89b\udfac\udaea\udf91\udb63\udc78\udae6\ude58\ud959\uddf3\ud832\udcb2\ud8d9\udd31\ud9e6\udc3e\udb8d\udfbe\u2c0c\ud81a\udfa0\udbb2\ude8e\udb5c\uddc1\">\012",
        Z.run(T, 2, 4, 4, 0, "\ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\udaee\udf3f\ud8c0\udeca\udaa6\uddbd\u5f9e\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud8ac\udece\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udbb4\udc8a\udb32\udddb\ud94c\udf21\udb61\udd9f", "\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\u6b47\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4", "\udb9a\udfb2\ud8c0\udc6e\uda41\uddb3\udb8f\uded6\ud892\udeda\ud90a\ude18\ud802\udc50\ud89b\udfac\udaea\udf91\udb63\udc78\udae6\ude58\ud959\uddf3\ud832\udcb2\ud8d9\udd31\ud9e6\udc3e\udb8d\udfbe\u2c0c\ud81a\udfa0\udbb2\ude8e\udb5c\uddc1",
        53, 54021, 2113834756, 2460380081550947238L, -69986L, false, false, (char) 28701, (char) 36693,
        Double.longBitsToDouble(0x3fc123b1ea506198L), Double.longBitsToDouble(0x3fe0ec9a1c302246L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\uc523\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\u8004\u98d2\u273a\u97a9\u3c24\ubcdb\u9592\u86e9\u65ca\uc5ed\u9c17\ub052\u5cbc\uac2a\u896a\u2010\ud53a\u1bce\u0533\uab33\uba25\u3147\u46f3\u5baa\u4458\uc71d\u41eb\u0ccb\u1f64<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\ud8a6\udde6\udaff\udcf1\ud8cc\udc53\udac6\udca8\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud881\udfce\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udb42\udc8e\uda11\uddb1\ud8af\udc1a\ud945\udeff PUBLIC \"\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\uc523\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\u8004\u98d2\u273a\u97a9\u3c24\ubcdb\u9592\u86e9\u65ca\uc5ed\u9c17\ub052\u5cbc\uac2a\u896a\u2010\ud53a\u1bce\u0533\uab33\uba25\u3147\u46f3\u5baa\u4458\uc71d\u41eb\u0ccb\u1f64\" \"\udbe0\ude9b\ud846\uddf9\uda27\udc2b\ud81b\udc22\udaf7\ude40\ud865\udf6e\udb14\udcfd\uda0f\udf37\uda29\udcce\ud83a\udd5a\ud948\udc45\uda7b\udf27\ud874\uddb6\udb45\uddf3\uf460\udbeb\udf0d\ud826\udd75\ud909\udc97\ud9c1\udfd8\udaa1\ude7e\udb95\udfaf\udbf8\ude96\ud9ba\udc88\udbe4\udee5\udb00\ude2a\udbe4\udfc7\udbab\udf2b\ud943\udd35\udaf5\ude68\ud991\udeef... |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\ud8a6\udde6\udaff\udcf1\ud8cc\udc53\udac6\udca8\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud881\udfce\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udb42\udc8e\uda11\uddb1\ud8af\udc1a\ud945\udeff PUBLIC \"\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\uc523\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\u8004\u98d2\u273a\u97a9\u3c24\ubcdb\u9592\u86e9\u65ca\uc5ed\u9c17\ub052\u5cbc\uac2a\u896a\u2010\ud53a\u1bce\u0533\uab33\uba25\u3147\u46f3\u5baa\u4458\uc71d\u41eb\u0ccb\u1f64\" \"\udbe0\ude9b\ud846\uddf9\uda27\udc2b\ud81b\udc22\udaf7\ude40\ud865\udf6e\udb14\udcfd\uda0f\udf37\uda29\udcce\ud83a\udd5a\ud948\udc45\uda7b\udf27\ud874\uddb6\udb45\uddf3\uf460\udbeb\udf0d\ud826\udd75\ud909\udc97\ud9c1\udfd8\udaa1\ude7e\udb95\udfaf\udbf8\ude96\ud9ba\udc88\udbe4\udee5\udb00\ude2a\udbe4\udfc7\udbab\udf2b\ud943\udd35\udaf5\ude68\ud991\udeef\ud8aa\udf50\ud819\udff1\ud9d3\udcd9\udabe\uddb6\udbba\ude22\u34c4\udb96\udf34\ud8db\udc19\uda74\udc5a\ud802\udda0\u52ec\ud9bd\udeff\ud976\udca4\udb0a\udcc3\udb02\udefe\ud8ea\udf2a\ud983\udd6f\ud88a\udd5c\">\0121=void |a0=java.lang.StringBuilder:\ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\ud8a6\udde6\udaff\udcf1\ud8cc\udc53\udac6\udca8\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud881\udfce\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udb42\udc8e\uda11\uddb1\ud8af\udc1a\ud945\udeff<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\ud8a6\udde6\udaff\udcf1\ud8cc\udc53\udac6\udca8\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud881\udfce\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udb42\udc8e\uda11\uddb1\ud8af\udc1a\ud945\udeff PUBLIC \"\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\uc523\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\u8004\u98d2\u273a\u97a9\u3c24\ubcdb\u9592\u86e9\u65ca\uc5ed\u9c17\ub052\u5cbc\uac2a\u896a\u2010\ud53a\u1bce\u0533\uab33\uba25\u3147\u46f3\u5baa\u4458\uc71d\u41eb\u0ccb\u1f64\" ... |this=org.jsoup.nodes.DocumentType:<!DOCTYPE \ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\ud8a6\udde6\udaff\udcf1\ud8cc\udc53\udac6\udca8\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud881\udfce\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udb42\udc8e\uda11\uddb1\ud8af\udc1a\ud945\udeff PUBLIC \"\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\uc523\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\u8004\u98d2\u273a\u97a9\u3c24\ubcdb\u9592\u86e9\u65ca\uc5ed\u9c17\ub052\u5cbc\uac2a\u896a\u2010\ud53a\u1bce\u0533\uab33\uba25\u3147\u46f3\u5baa\u4458\uc71d\u41eb\u0ccb\u1f64\" \"\udbe0\ude9b\ud846\uddf9\uda27\udc2b\ud81b\udc22\udaf7\ude40\ud865\udf6e\udb14\udcfd\uda0f\udf37\uda29\udcce\ud83a\udd5a\ud948\udc45\uda7b\udf27\ud874\uddb6\udb45\uddf3\uf460\udbeb\udf0d\ud826\udd75\ud909\udc97\ud9c1\udfd8\udaa1\ude7e\udb95\udfaf\udbf8\ude96\ud9ba\udc88\udbe4\udee5\udb00\ude2a\udbe4\udfc7\udbab\udf2b\ud943\udd35\udaf5\ude68\ud991\udeef\ud8aa\udf50\ud819\udff1\ud9d3\udcd9\udabe\uddb6\udbba\ude22\u34c4\udb96\udf34\ud8db\udc19\uda74\udc5a\ud802\udda0\u52ec\ud9bd\udeff\ud976\udca4\udb0a\udcc3\udb02\udefe\ud8ea\udf2a\ud983\udd6f\ud88a\udd5c\">\012",
        Z.run(T, 2, 4, 4, 0, "\ud922\ude88\udb04\udf5c\udb02\udce7\uda0e\udd04\udbf5\udc9c\ud935\uddb9\udb1a\udfd3\uda8a\ude77\uda12\udc2d\udb07\udcb7\uda9f\udc84\ud8c6\ude98\ud909\ude9f\uc568\uda7b\ude01\ud9f4\ude12\ud8a6\udde6\udaff\udcf1\ud8cc\udc53\udac6\udca8\ud9ad\udfbf\uda3d\udc76\ud9f0\udfa4\ud8dc\udeb9\ud9c7\udcc3\ud899\udede\u6048\udb18\ude67\ud9b2\udc4e\ud823\udc4c\udbf3\udeb4\ud881\udfce\udbab\ude38\udb41\udebd\ud8c8\udf5d\udbea\udd5e\ud999\udf32\udaf3\uddcf\ud9b9\udd69\udbaf\udc60\ud81c\uddde\ud91a\udfae\ucc5b\ud926\udf66\udbb2\udd6f\udadf\ude25\ud9ea\udf5c\uda1f\udd10\udb6f\udc7b\ud917\udda2\ud86d\udd8c\uda62\udc72\uda7a\udfb5\udaf8\udd4f\udb42\udc8e\uda11\uddb1\ud8af\udc1a\ud945\udeff", "\u9c17\ud3b8\u3ebb\u2a0e\u08dd\uc546\u65bd\u1061\u5568\u87df\uc523\u03b0\u8b98\uaf5a\ua015\ub1c9\u7e37\u94c2\u7a6a\u02cf\u2bf2\u1139\uab86\u98e4\u8004\u98d2\u273a\u97a9\u3c24\ubcdb\u9592\u86e9\u65ca\uc5ed\u9c17\ub052\u5cbc\uac2a\u896a\u2010\ud53a\u1bce\u0533\uab33\uba25\u3147\u46f3\u5baa\u4458\uc71d\u41eb\u0ccb\u1f64", "\udbe0\ude9b\ud846\uddf9\uda27\udc2b\ud81b\udc22\udaf7\ude40\ud865\udf6e\udb14\udcfd\uda0f\udf37\uda29\udcce\ud83a\udd5a\ud948\udc45\uda7b\udf27\ud874\uddb6\udb45\uddf3\uf460\udbeb\udf0d\ud826\udd75\ud909\udc97\ud9c1\udfd8\udaa1\ude7e\udb95\udfaf\udbf8\ude96\ud9ba\udc88\udbe4\udee5\udb00\ude2a\udbe4\udfc7\udbab\udf2b\ud943\udd35\udaf5\ude68\ud991\udeef\ud8aa\udf50\ud819\udff1\ud9d3\udcd9\udabe\uddb6\udbba\ude22\u34c4\udb96\udf34\ud8db\udc19\uda74\udc5a\ud802\udda0\u52ec\ud9bd\udeff\ud976\udca4\udb0a\udcc3\udb02\udefe\ud8ea\udf2a\ud983\udd6f\ud88a\udd5c",
        31, 14245, 2104235235, 1201115289645176245L, -95611L, true, true, (char) 23902, (char) 34008,
        Double.longBitsToDouble(0x3fe31440d9321c88L), Double.longBitsToDouble(0x3fc8f186adf4e828L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.DocumentType|outerHtmlHead|java.lang.StringBuilder,int,org.jsoup.nodes.Document$OutputSettings|new:org.jsoup.nodes.DocumentType:java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "C|org.jsoup.nodes.DocumentType|<init>|java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.DocumentType|nodeName||new:org.jsoup.nodes.DocumentType:java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.DocumentType|outerHtmlTail|java.lang.StringBuilder,int,org.jsoup.nodes.Document$OutputSettings|new:org.jsoup.nodes.DocumentType:java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.DocumentType|outerHtmlHead|java.lang.StringBuilder,int,org.jsoup.nodes.Document$OutputSettings|new:org.jsoup.nodes.DocumentType:java.lang.String,java.lang.String,java.lang.String,java.lang.String",
    "C|org.jsoup.nodes.DocumentType|<init>|java.lang.String,java.lang.String,java.lang.String,java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
