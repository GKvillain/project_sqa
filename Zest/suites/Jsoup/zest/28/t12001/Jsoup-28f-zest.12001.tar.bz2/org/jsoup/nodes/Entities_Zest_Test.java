package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Entities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 9, 15, 4, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\ua0ea\uc05b\u8dde\u2c3d", "\ud90c\udf1b\ud987\ude24",
        34, 49569, 1524217616, -4638219710900640927L, 1407L, false, true, (char) 52890, (char) 40527,
        Double.longBitsToDouble(0x3fe397ee330617b7L), Double.longBitsToDouble(0x3feac47c34c9a00cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 9, 15, 4, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\ua0ea\uc05b\u8dde\u2c3d", "\ud90c\udf1b\ud987\ude24",
        34, 49569, -1269713136, 3711101767976313697L, 1407L, false, true, (char) 52890, (char) 40527,
        Double.longBitsToDouble(0x3fe397ee330617b7L), Double.longBitsToDouble(0x3feac47c34c9a00cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 12, 16, 4, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\ua0ea\uc05b\u8dde\ua890", "\ud90c\udf1b\ud987\ude24",
        34, 49569, 1524217616, -4638219712264337668L, 1407L, false, true, (char) 20123, (char) 53411,
        Double.longBitsToDouble(0x3fddb792f54685b0L), Double.longBitsToDouble(0x3fe4698211d0e54fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 17, 2, "\ud930\uddee\udb9c\udc71", "\u1633\u18a0", "\ud9a8\udd9e\udab0\ude4b\uda8a\udcc1\udbba\uddaf\uda18\udf22\udb9c\udf2f\ud987\udeaf\uda52\udc47\ud925\udfd3\udaad\udd8a\udad1\uded6\udb64\udf0f\ud9b2\udfc4\ud88b\uddd8\ufcc2\uda87\udda7\udb79\udf24\udb05\udced\ud9b1\udd75\ud97b\uddb0\uda9f\udddc\udb35\ude19",
        22, 36698, -1359970304, 8161698595308768360L, -43961L, true, true, (char) 7145, (char) 27482,
        Double.longBitsToDouble(0x3fcec847687ab7d8L), Double.longBitsToDouble(0x3fcf9fbe99f68f0cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\u2ea6\ud93d\udcaa\012",
        Z.run(T, 1, 19, 6, 8, "\u2ea6\ud93d\udcaa", "\u3ba5\u18a0\u5339\u32b2\ud3d1\u8dde\u7193", "\ud90c\udf1b\ud910\udefc",
        34, 49569, 1524217616, -4638219710900640927L, 1407L, false, true, (char) 52890, (char) 55437,
        Double.longBitsToDouble(0x3fe397ee330617b7L), Double.longBitsToDouble(0x3feac47c34c9a00cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\uda4c\udde5\ud821\udf39\ud80b\udee2\uda35\udda4\udb0b\udee1\udbec\ude68\ud979\udc2e\udae5\udfe0\uda59\udd51\udacd\ude87\udb83\udef6\ud933\udfb1\udb5a\udc48\ud90c\uded7\ud987\ude24\uda5f\udd78\012",
        Z.run(T, 1, 2, 10, 17, "\uda4c\udde5\ud821\udf39\ud80b\udee2\uda35\udda4\udb0b\udee1\udbec\ude68\ud979\udc2e\udae5\udfe0\uda59\udd51\udacd\ude87\udb83\udef6\ud933\udfb1\udb5a\udc48\ud90c\uded7\ud987\ude24\uda5f\udd78", "\u9bbd\u4f4b\uc8ac\u7284", "\ud9a8\udc09\udb37\udfd7\ud845\udc65\ud97b\uddb0\ud964\udcdc\udbbb\udced",
        16, 50440, 2047582784, -4426392041425803627L, -60331L, false, false, (char) 39764, (char) 34025,
        Double.longBitsToDouble(0x3fe200a8457c2111L), Double.longBitsToDouble(0x3fe406caebeaf54dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 9, 15, 4, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\ua0ea\uc05b\u8dde\u2c3d", "\ud90c\udf1b\ud987\ude24",
        34, 99361, 754331249, 7591453090386895713L, 1407L, true, true, (char) 21610, (char) 40527,
        Double.longBitsToDouble(0x3fe397ee330617b7L), Double.longBitsToDouble(0x3feac47c34c9a00cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 8, 16, 13, "\ud990\uddc7\ud93d\udcaa", "\ucd9d\u0ea8\u5339\ua0ea\uc05b\u2edf\ud689", "\udb33\uddb1\ud987\ude24\uda5f\udd78\ud925\udfd3",
        36, 44291, -26909855, 7294158556400106321L, -6720L, true, false, (char) 15491, (char) 32066,
        Double.longBitsToDouble(0x3fd1b4eb644e2eceL), Double.longBitsToDouble(0x3feedd6bc9157df9L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=org.jsoup.parser.Parser:@?\012",
        Z.run(T, 2, 9, 15, 4, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\ua0ea\uc05b\u8dde\u2c3d", "\ud90c\udf1b\ud987\ude24",
        34, 49569, 1524217616, -4638219710900640927L, 1407L, false, true, (char) 52890, (char) 40527,
        Double.longBitsToDouble(0x3fe397ee330617b7L), Double.longBitsToDouble(0x3feac47c34c9a00cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.Parser:@?\012",
        Z.run(T, 1, 13, 11, 10, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\ua0ea\uc05b\u8dde\u2c3d", "\ud90c\udf1b\ud987\ude24",
        34, 49569, 1524217616, -4638219710900640927L, 1407L, false, true, (char) 52890, (char) 40527,
        Double.longBitsToDouble(0x3fe397ee330617b7L), Double.longBitsToDouble(0x3feac47c34c9a00cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\ud8b7\udf5b\ud842\udf55\ud821\udf51\udacb\ude5c\ud9d3\udce5\udb2f\udf67\ud81f\ude29\uda9a\udf67\udb7a\udeef\udabe\udc6a\uda50\udcfb\uda09\udf28\ud91b\udc33\ud9b8\uddb7\ud991\ude8a\uda5f\udd78\udbd5\udfe7\012",
        Z.run(T, 1, 1, 2, 1, "\ud8b7\udf5b\ud842\udf55\ud821\udf51\udacb\ude5c\ud9d3\udce5\udb2f\udf67\ud81f\ude29\uda9a\udf67\udb7a\udeef\udabe\udc6a\uda50\udcfb\uda09\udf28\ud91b\udc33\ud9b8\uddb7\ud991\ude8a\uda5f\udd78\udbd5\udfe7", "\u2584\uaae2\ucd87\u1550\u0d1e\u9f55\uabf0\u1dc0\u66c8\ub826\u0ba6\u014e", "\udbfa\udc1e\udac3\ude64\ud8d0\ude98\udb70\udc42\ud83b\udead\ud806\udef8\ud9bd\ude9d\udbaf\udc7e",
        42, 2404, 1834010571, -7801473130616523986L, -27198L, true, true, (char) 19570, (char) 56033,
        Double.longBitsToDouble(0x3fed0d893bc6ce23L), Double.longBitsToDouble(0x3fecaa82c4dab8cbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 15, 4, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\u634a\uc05b\u8dde\u2c3d", "\ud90c\udf1b\ud987\ude24",
        34, 82593, 1524217616, -4638219710900640927L, -49537L, false, true, (char) 52890, (char) 40527,
        Double.longBitsToDouble(0x3fe397ee330617b7L), Double.longBitsToDouble(0x3feac47c34c9a00cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 9, 4, "\udaf9\ude52\udb9e\udfd8", "\u3ba5\u18a0\u5339\uc293\uc05b\u8dde\u6806", "\ud90c\uded9\udb2a\udefa\ud977\ude40\ud925\udfd3\uda2b\udc2e\ud96d\udc38\udbfd\udff2\ud9b2\udfc4\uda5b\udd9f\ufcc2\ud90e\udc3a\ud9a8\udc09\ud876\udf5c\udb8f\uddce\ud97b\uddb3\udbe5\udd5f\udb81\udc0e\ud972\uddee\ud8bd\udceb\udb08\udc21\uda81\udf26\uda14\uddee\ud800\udcad\ud9cb\ude73\udaf3\ude31\udbf9\ude7f\ud8ca\udc04\ud958\uddf3",
        57, 12654, -1232216202, 1994285792012094367L, 89490L, false, true, (char) 226, (char) 60000,
        Double.longBitsToDouble(0x3fe39b4b2d8372f7L), Double.longBitsToDouble(0x3fed39936b6bd60eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\ud990\uddc7\ud93d\udcaa\012",
        Z.run(T, 1, 17, 20, 3, "\ud990\uddc7\ud93d\udcaa", "\u3105\uc043\u5339\ua0ea\u50a8\ubada\u2c3d", "\ud974\ude28\ud987\udea6\uda5f\udd78",
        59, 10514, -1079919658, 5588231980019386076L, -84988L, true, false, (char) 40527, (char) 44088,
        Double.longBitsToDouble(0x3fdb517b76b11f0cL), Double.longBitsToDouble(0x3fc934018501a2f0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 1, 4, "\ud990\uddc7\ud93d\udcaa", "\u4b3f\u3185\u5339\u4770\uc05b\u88e5\u2c3d", "\ud90c\udf1b\uda94\udd8b\uda5f\udd78\ud91a\ude46\uda65\udc6a\udb97\udff3\udbfd\udff2\udb11\udc1c\ud860\ude53\ud8f5\udc7f\uda4f\ude7c\ud9a8\udc09\udb37\udfd7\udab9\uddce\ud97b\uddb0\ud98c\ude52\ud89b\udc44\uda72\udf13\ud9f6\udf17",
        52, 10595, -607342736, 510723041470467254L, 61310L, false, true, (char) 5426, (char) 59501,
        Double.longBitsToDouble(0x3fe74122558c829eL), Double.longBitsToDouble(0x3fefcd75b2b5b3a6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 20, 13, "\ud851\udde4\udae5\uded9\ud936\ude44\uda35\udda4\udb0b\udee1\udbbe\udd68\ud82f\udc29\ud908\udd9f\ud83d\udfb2\udac7\udc5c\udb83\udef6\uda9d\uded0\udb49\udc09\ud8f4\udc1b\ud87f\ude20\uda5f\udd78\ud925\udfd3\uda65\udc6a\udb97\udff3\ud8cd\udf49\udada\ude69\udb40\udf5b\udabd\udec9\ud90e\udc3a", "\u3db7\ua99e\u8600\u7648\u2c9b\u548f", "\udbae\udf0b\ud966\udc50\ud944\udf78\ud9e0\udf39\ud996\udcc8\uda4b\uddc6\uda29\uddd7",
        36, 66327, 393957045, 6937800528480634845L, -11629L, false, false, (char) 3282, (char) 24190,
        Double.longBitsToDouble(0x3fe92ff465daabe1L), Double.longBitsToDouble(0x3fd694d64364f496L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 17, 15, 4, "", "]", "\udbbe\udd68\ud95d\udc20\ud908\udd9f",
        -2, 31432, -1232293045, 4932333056663559936L, -99955L, true, false, (char) 1641, (char) 13388,
        Double.longBitsToDouble(0x3fc7eb5b20000000L), Double.longBitsToDouble(0x3e3f0e5800000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 15, 4, "\udad5\udfda\udb6d\udccf\udb67\ude0f\udaf2\ude20\ud884\udce7\udbbe\udd68", "\u7766\u8dde\u2c3d\u7be8\u0207\u7e1d\uc89c\u7d09\u34f2\u2abd\ub774\ucab4\uc7bf\u7284\ud143\u7520\u2d88\u2a8e\u3db7\ua99e\u0eaa\u2276", "\u4f9d",
        20, 4708, 2068944815, 439809910248844805L, -62688L, true, true, (char) 9711, (char) 3496,
        Double.longBitsToDouble(0x3f9194ce3ed9d9a0L), Double.longBitsToDouble(0x3fd99557a0d6d874L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=org.jsoup.parser.Parser:@?\012",
        Z.run(T, 2, 12, 15, 4, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u9538\ua0ea\uc05b\u8dde\u2c3d", "\udad9\ude5b\udb10\udc30",
        34, 49569, 886683408, -4638185385522011295L, 1407L, false, true, (char) 52890, (char) 40527,
        Double.longBitsToDouble(0x3fe397ee330617b7L), Double.longBitsToDouble(0x3fe2647c34c9a0afL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\udba2\ude74\ud93d\udcaa\udae7\ude70\uda38\udd77\ud87d\udccb\udaa9\udcbe\uda38\udf83\ud908\udd9f\uda16\udecd\ud94e\ude34\012",
        Z.run(T, 1, 18, 7, 6, "\udba2\ude74\ud93d\udcaa\udae7\ude70\uda38\udd77\ud87d\udccb\udaa9\udcbe\uda38\udf83\ud908\udd9f\uda16\udecd\ud94e\ude34", "\uc68d\u60d9\u45ab", "\ud9fa\udd0f\udafe\udc4f\ud852\udcbd\ud9b2\udfc4\ud4a3\ud8c3\ude7a\ud9a3\udd95\udb79\udc42\uda11\ude58\ud845\udc65\ud939\udf3e\ud98d\udd0b\ud84e\uddc9\ud810\udf0c\udb0a\udf67",
        11, 54481, -59438446, 7486492934276525069L, -45314L, true, true, (char) 2803, (char) 15888,
        Double.longBitsToDouble(0x3fe2c1cd72d529a1L), Double.longBitsToDouble(0x3fe61cd78f90c955L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 9, 11, "\ud990\uddc7\ud93d\udcaa\ud936\uddf6", "\u18a0\u5339\u52ee", "\udbef\udfbb\udb09\udfd5\udb43\udd8a\ud90c\udedb\ud9f7\udecd\uda5f\udd78\ud925\udfd3\uda65\udc6a\udb97\udff3\uda75\udfc1",
        51, 78180, -171195044, -1925894881554475180L, 70775L, false, false, (char) 55611, (char) 8555,
        Double.longBitsToDouble(0x3fe8c0f16c61ff1fL), Double.longBitsToDouble(0x3fe0ba020bb46d58L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\ud990\uddc7\udb41\udf78\udac7\ude13\udb7c\uddf2\012",
        Z.run(T, 1, 2, 15, 4, "\ud990\uddc7\udb41\udf78\udac7\ude13\udb7c\uddf2", "\u5339\u0e3d\u32ab\u45a2\ub46d\u7be8\u0207\u7e1d\uc89c\u7d09\u34f2\ua1bc\u8b19\ucf93", "\ufcae\ud90e\udc3a\ud98a\ude44\udb3b\udd2f\ud807\ude66\udb2e\udfd1\ud8dd\udc3b\uda71\udf61\udb3f\udcea\uda06\ude46\udae5\udc0e\ud8e3\udd24\uda5d\udf30\udb85\udd5d\udb89\udc73\udba3\udef7\uf959\ub0e6\ud81e\udd55\udbdc\udee7\udacd\udd48",
        6, 17856, 1372292142, -4840289764220160521L, -82808L, false, false, (char) 63637, (char) 53393,
        Double.longBitsToDouble(0x3fdadec3ec46b9bcL), Double.longBitsToDouble(0x3fd7f5514ddeb018L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 12, 16, 4, "\ud869\udd11\ud93c\udff4\uda3a\udf38\uda35\udda4\ud932\udc75\udbd0\udd49\ud956\udd74\ud969\udc75\udb64\udf8c\ud97f\udce0\udb9f\udf6c\udac5\udd56\ud8e2\udeb6\ud90c\udf1b\ud987\ude24\uda5f\udd78\uda4b\ude07\ud8b9\udd45\udb97\udfee\udad1\udec3\ud9b2\udfc4\ud88b\uddd8\ufcc2\udb0b\udd89\ud8cd\udf46\ud9da\uddcb\ud81d\udd7b\u1eb8\ud8eb\udd03\uda03\udf22\udb5f\udc04", "\u4786\u66d7", "\udabc\ude19\ud838\udec7\udb94\uddc3\ud8f3\uded4\udabd\ude9d\uda3a\ude95\u4161",
        15, 93751, -2127877255, -5222931197622762379L, 83794L, false, true, (char) 20443, (char) 39553,
        Double.longBitsToDouble(0x3fe788b752a768b9L), Double.longBitsToDouble(0x3fe38f9f70fa3275L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 11, "\ud990\uddc7\ud964\udf79\udb67\udc45\ud827\udf53\uda54\udc0c\udb32\udc3a\udb0b\udebe\ud98d\udd86\udb0c\udd50\udac7\udc5c\ud8ef\udd8b\udab6\udcb4", "\uc212\u7d09\ua8b8", "\udaf4\udcee\udb72\udca4\ud9af\ude35\ufcc2\ud9c0\ude8c\ud8cd\udf46\uda78\udeef\ud947\udde1\ud90a\udfec\ud852\udcaa\ud809\udff2\udaa9\udf5c",
        34, 69426, -2145716386, -2770022573755374687L, -11283L, true, true, (char) 32814, (char) 60416,
        Double.longBitsToDouble(0x3fcfd704bbef2344L), Double.longBitsToDouble(0x3fb3812adc8b4090L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\ud930\uddee\udb9c\udc71\0121=java.lang.String:\ud930\uddee\udb9c\udc71\012",
        Z.run(T, 2, 1, 17, 2, "\ud930\uddee\udb9c\udc71", "\u1633\u18a0", "\udba6\udcd0",
        7, 77920, 14385571, -1038594303003124699L, 23408L, false, false, (char) 62337, (char) 54340,
        Double.longBitsToDouble(0x3fef0e5c455c999aL), Double.longBitsToDouble(0x3fda7f5cb4240016L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\000\012",
        Z.run(T, 1, 1, 17, 2, "\000", "\ucd32\u1633", "\000\000\000\ud940\udcc0\udbba\uddaf\udb5d\udc04\000\ud987\udeaf\uda52\udc47\u7871\000\000\udb61\udc8f\uc6e4\ud81c\uddee\ufcc2",
        32, 54368, 251658240, 20244319759761408L, -77429L, true, false, (char) 40776, (char) 32767,
        Double.longBitsToDouble(0x3e0a1c5100000000L), Double.longBitsToDouble(0x3d11600000000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 12, 2, "\ud930\uddee\udb9c\udc71", "\u1633\u18a0", "\ud9a8\udd9e\udab0\ude4b\uda8a\udcc1\ud8f1\udfd0\udb09\udc1a\uda90\udc2e\uda9d\ude42\uda52\udc47\ud925\udfd3\udaad\udd8a\udad1\uded6\udb64\udf0f\ud9b2\udfc4\ud88b\uddd8\ufcc2\uda87\udda7\udb79\udf24\udb05\udced\ud9b1\udd75\ud97b\uddb0\uda9f\udddc\udb35\ude19",
        22, 36698, -1359970304, 8161698595308768360L, -43961L, true, true, (char) 7145, (char) 27482,
        Double.longBitsToDouble(0x3fcec847687ab7d8L), Double.longBitsToDouble(0x3fcf9fbe99f68f0cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 11, 6, 5, "\u2e1c", "\u08b7", "\u0089\u4f00\ud8ce\udf67\udac7\udc5c\ud991\ude47\udb1e\udd03\000\000\000\000\ud9ca\udc04\udb47\udf0c",
        -1, 28649, 8947420, 127410204886272L, 74123L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc9340005c8ce0cL), Double.longBitsToDouble(0x3fe36b64f53e7f59L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 11, 0, 8, "\u2ea6\ud93d\udcaa", "\u59ab\u18a0\u0e8e\u32b2\ud3d1\u5126\u908c\u70e1\uc642\u7e1d\u1e04\u2b48\u4f5e\u9ce8\ub774\u4f4b\uc8ac\u7284\ud143\u1b58\ub10c\u368e\u4a9e\u2709\ud2b7\ub7e2", "\udb4d\uddd1\udb5a\udcb4",
        28, 49927, 741595903, -8019584074493364669L, -43939L, true, false, (char) 4556, (char) 54760,
        Double.longBitsToDouble(0x3feacb35feb63610L), Double.longBitsToDouble(0x3febc2fa16ff4510L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\u2ea6\ud93d\udcaa\ud936\uddf6\uda3f\udfa4\udb0b\udee1\udb90\ude92\ud82f\udc29\ud8eb\uddb0\ud9c8\ude80\ud990\ude5f\ud979\udf51\udaa3\udd05\udb49\udc09\udbd5\udf13\ud9fc\ude8c\udb38\udf57\ud9da\udf8f\uda65\udd1b\uda8d\udeb1\ud965\udcbc\udbe7\udf66\ud88b\uddd8\ufcc2\ud932\udfac\ud9f9\ude51\udb3a\udfd7\ud845\udc9d\ud9a7\ude4c\uda32\udc79\udafe\udd51\ud969\udc17\ud909\ude8c\ud900\udd9e\uda1c\udd81\ud9cd\ude4c\ud98a\udcd9\012",
        Z.run(T, 1, 19, 6, 6, "\u2ea6\ud93d\udcaa\ud936\uddf6\uda3f\udfa4\udb0b\udee1\udb90\ude92\ud82f\udc29\ud8eb\uddb0\ud9c8\ude80\ud990\ude5f\ud979\udf51\udaa3\udd05\udb49\udc09\udbd5\udf13\ud9fc\ude8c\udb38\udf57\ud9da\udf8f\uda65\udd1b\uda8d\udeb1\ud965\udcbc\udbe7\udf66\ud88b\uddd8\ufcc2\ud932\udfac\ud9f9\ude51\udb3a\udfd7\ud845\udc9d\ud9a7\ude4c\uda32\udc79\udafe\udd51\ud969\udc17\ud909\ude8c\ud900\udd9e\uda1c\udd81\ud9cd\ude4c\ud98a\udcd9", "\u3d5a", "\uda15\udf6f\ud910\udfb5\uda76\udd45\ud91e\udf30\ud93c\udddf\ud869\udd38\u6e64\udb7f\udee6",
        47, 69325, 391417346, 73912952464829960L, -95075L, true, false, (char) 11642, (char) 22065,
        Double.longBitsToDouble(0x3fa4242ff562cf40L), Double.longBitsToDouble(0x3fef8a5ecf911f98L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\uda4c\udd39\0121=java.lang.String:\uda4c\udd39\012",
        Z.run(T, 2, 2, 3, 7, "\uda4c\udd39", "\u08b7", "\ud8a1\udc71\udae5\udf2c\uda59\udd51\udab8\udf9d\udb83\udef6\ud933\udfb1\udb5a\udc1d\ud90c\uded7\ud987\ude24\ud93f\udcc7\udb29\udd31\udb8e\udfc0",
        14, 28649, -880245028, 3870126864828450236L, -11979L, false, false, (char) 12989, (char) 26062,
        Double.longBitsToDouble(0x3f78bbbc69e52a80L), Double.longBitsToDouble(0x3fdad45a938179eeL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 4, 2, "\ud990\ude2f", "\u09aa\u474e\u0db8\u9558\ua0ea", "\udb83\udef6\ud952\udceb\udb49\udc09\ud90c\udf1b\ud987\ude24\uda5f\udd78\ud913\udf4a\ud91a\udd17\ud97e\udc92\udbfd\udff2",
        47, 88225, -154442948, -710204457685178325L, 71771L, false, true, (char) 31957, (char) 54341,
        Double.longBitsToDouble(0x3febcc9191368f8dL), Double.longBitsToDouble(0x3fe02306a8b6bbc2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 2, 1, "\ud990\uddc7\ue3c8", "\uca1b\u18a0\u5339", "\uda67\udfab",
        53, 38151, 86843274, -3180084550872567297L, 50967L, true, false, (char) 40527, (char) 47646,
        Double.longBitsToDouble(0x3fccb6c6cc30c74cL), Double.longBitsToDouble(0x3fc9340180db69c0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.Parser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 1, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\ua0ea\u3602\u8dde\u2c3d", "\udaba\udcd0\ud987\ude24\uda5f\udd78\ud925\udfd3\uda94\udec2\udad8\ude8d\ud860\udf4b\udaca\udd33\uda09\udce0",
        20, 4765, 144235184, 1333358129706310495L, 53441L, true, false, (char) 52216, (char) 24165,
        Double.longBitsToDouble(0x3fcb2677d0cb62fcL), Double.longBitsToDouble(0x3fddfee15555216eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jsoup.parser.Parser:@?\0121=org.jsoup.parser.Parser:@?\012",
        Z.run(T, 2, 15, 15, 11, "\ud97d\ude39\ud93d\udcaa", "\u3ba5\u4983\uaec6\ud0c0\u5494\u74f6\u71d1", "\ud90c\udf1b\ud987\ude24",
        2, 30244, 1524217616, 7889328802127040667L, 1407L, false, true, (char) 52890, (char) 24873,
        Double.longBitsToDouble(0x3fe948e2330617b7L), Double.longBitsToDouble(0x3feac47c34c9a00cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 4, "\ud990\uddc7", "\u08b7\u3ba5", "\ud908\udd9f",
        26, 65618, 9220939, 4932332197670100874L, 54925L, true, false, (char) 247, (char) 13404,
        Double.longBitsToDouble(0x3ecb200000000000L), Double.longBitsToDouble(0x3ec1a00000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 6, 15, 20, "", "\u11db", "\udbbe\udd68\ud82f\udc29\ubf93",
        10, 65618, 75, 4932286018181734282L, 54925L, true, false, (char) 36343, (char) 13328,
        Double.longBitsToDouble(0x3fedfad6cb61bfa1L), Double.longBitsToDouble(0x3fe6e26c68000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 12, 12, 11, "\ud990\uddc7\ud964\udf79\udb67\udc45\ud827\udf53\uda54\udc0c\udb32\udc3a\udb0b\udebe\ud98d\udd86\udb08\udd4e\udac7\udc5c\udbca\udfda\ud8c1\udddd", "\uc212\u7d09\ua8b8", "\udaf4\udcee\udb72\udca4\ud9af\ude35\ufcc2\ud9c0\ude8c\ud8cd\udf46\uda78\udeef\udab6\udc6d\ud9b9\udf0d\ud9f6\udfa3\ud809\udff2\udaa9\udf5c",
        34, 80474, -2139586273, -2770022575835421791L, -11283L, true, true, (char) 32814, (char) 60416,
        Double.longBitsToDouble(0x3fcfd704bbef2344L), Double.longBitsToDouble(0x3fb3812adc8b4090L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 12, 12, 18, "\ud990\uddc7\ud964\udf79\udb67\udc45\ud827\udf53\uda54\udc0c\udb32\udc3a\udb0b\udebe\ud98d\udd86\udb0c\udd50\udac7\udc5c\ud8dc\ude9c\uda9d\udcb4", "\uc212\u7d09\ua8b8", "\udaf4\udcee\ud8e7\udc7d\ud9dc\ude29\ufcc2\ud9c0\ude8c\ud8cd\udf46\uda78\udeef\ud947\udde1\uda01\udfa6\ud848\ude03\ud809\udff2\udaa9\udf5c",
        43, 91466, -1193001194, -2792120919227669599L, -11283L, true, true, (char) 32814, (char) 60416,
        Double.longBitsToDouble(0x3fcfd704bbef2344L), Double.longBitsToDouble(0x3fb3812adc8b4090L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 4, 0, "\ud97e\udcc7", "\u9c2c\u9077", "\udaa3\udf92\udb0c\udd50\ud94d\udefd\ud8f2\ude6d",
        5, 15538, 204825796, -2675983369093893099L, 69744L, false, true, (char) 25821, (char) 6073,
        Double.longBitsToDouble(0x3fe7168bd75c7c50L), Double.longBitsToDouble(0x3fdcff5cb045915eL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.Parser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 10, "\ud97a\udfd9\ud8a8\udf8b\udb67\udc45\uda36\uddfd\ud832\udc15\udb32\udc3a\udb0b\udebe\ub0fb\udb0c\udd19", "\u3e48", "\ud985\udf9a\ud998\uded3\udb8f\udecf",
        47, 69355, -62549721, -7599676089651161374L, -40047L, false, false, (char) 43173, (char) 36705,
        Double.longBitsToDouble(0x3fe1196b6faa968fL), Double.longBitsToDouble(0x3fe034104a20ec4fL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.Parser:@?\0121=null |this=org.jsoup.parser.Parser:@?\012",
        Z.run(T, 2, 14, 14, 17, "\ud990\uddc7\ud96d\udd16\uda0a\udee9\udbed\udfbf\udb8b\udc28\udae7\udda8\udb0b\udebe\ud98d\udd86\udb0c\udd50\udac7\udc5c\udb30\uddec\uda43\uddce", "\ube2e\u7d09\ua8b8", "\udaf4\udcee\ud97c\ude69\ud9e5\udf51\ufcc2\ud9c0\ude8c\ud8ce\udc1f\ud85f\udf41\ud951\udf2e\ud90a\udfec\ud88d\udd48\udaeb\udde9\uda83\udf0f\ud9b9\udc05",
        51, 27614, -644946139, 3999024539400514480L, 12629L, false, false, (char) 58315, (char) 1239,
        Double.longBitsToDouble(0x3fbef7d1bb6ca2c8L), Double.longBitsToDouble(0x3fd9671dc10dd450L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 11, 11, 11, "\ud990\uddc7\ud964\udf79\udb67\udc45\ud827\udf53\uda54\udc0c\udb32\udc3a\udb0b\udebe\ud98d\udd86\udb0c\udd50\udac7\udc5c\ud8ef\udd8b\ud9ef\udcb4", "\u9f89\uae61\ua8b8", "\udaf4\udcee\udb72\udca4\ud9af\ude35\ufcc2\ud9c0\ude8c\ud8cd\udf46\uda78\udeef\ud947\udde1\ud8e0\udfe7\ud852\udc79\ud809\udff2\udaa9\udf5c",
        39, 8195, -2145716386, -2697964979825394989L, 73502L, true, true, (char) 35374, (char) 60245,
        Double.longBitsToDouble(0x3fcfd704bbef2344L), Double.longBitsToDouble(0x3fe98fe55b91dadeL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 11, 11, 13, "\ud930\uddee\udb7f\udc82", "\u1633\u18a0\u5339", "\udab0\uddf1",
        50, 32595, 1052870760, 4449869290875055026L, 96498L, false, false, (char) 54340, (char) 16234,
        Double.longBitsToDouble(0x3fd5c999ab4feb96L), Double.longBitsToDouble(0x3fe090005bfdce58L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:\ud990\ude1c\ue3c8\ud8c9\udf33\ud95a\udfb6\udb2f\udd57\udbbe\udd68\ud82f\udc29\ud9cb\ude8d\udb10\udea6\uda67\udfab\ud8b5\udef3\udb2b\ude64\ud825\udfea\ud891\udf59\ud8cb\udc35\ud883\udd56\ud925\udfd3\ud861\udd49\u7787\uda7d\ude24\ud921\udc5e\ud9c2\udfd5\ud90e\udf66\udbf7\udfe5\ud97b\udd93\udb36\udc59\udaab\udfd4\ud97b\udd64\ud903\uddee\ud832\udfd8\ud998\uddbc\ud946\udc0a\ud8c2\udd08\ud92f\ude41\uda93\uddbd\udb9c\udee9\udbd2\udeca\udb99\udcad\ud9ba\udd29\udb1b\udcbf\udbec\udda3\uda04\udc42\udb6d\udc3f\ud872\ude3c\0121=java.lang.String:\ud990\ude1c\ue3c8\ud8c9\udf33\ud95a\udfb6\udb2f\udd57\udbbe\udd68\ud82f\udc29\ud9cb\ude8d\udb10\udea6\uda67\udfab\ud8b5\udef3\udb2b\ude64\ud825\udfea\ud891\udf59\ud8cb\udc35\ud883\udd56\ud925\udfd3\ud861\udd49\u7787\uda7d\ude24\ud921\udc5e\ud9c2\udfd5\ud90e\udf66\udbf7\udfe5\ud97b\udd93\udb36\udc59\udaab\udfd4\ud97b\udd64\ud903\uddee\ud832\udfd8\ud998\uddbc\ud946\udc0a\ud8c2\udd08\ud92f\ude41\uda93\uddbd\udb9c\udee9\udbd2\udeca\udb99\udcad\ud9ba\udd29\udb1b\udcbf\udbec\udda3\uda04\udc42\udb6d\udc3f\ud872\ude3c\012",
        Z.run(T, 2, 1, 2, 1, "\ud990\ude1c\ue3c8\ud8c9\udf33\ud95a\udfb6\udb2f\udd57\udbbe\udd68\ud82f\udc29\ud9cb\ude8d\udb10\udea6\uda67\udfab\ud8b5\udef3\udb2b\ude64\ud825\udfea\ud891\udf59\ud8cb\udc35\ud883\udd56\ud925\udfd3\ud861\udd49\u7787\uda7d\ude24\ud921\udc5e\ud9c2\udfd5\ud90e\udf66\udbf7\udfe5\ud97b\udd93\udb36\udc59\udaab\udfd4\ud97b\udd64\ud903\uddee\ud832\udfd8\ud998\uddbc\ud946\udc0a\ud8c2\udd08\ud92f\ude41\uda93\uddbd\udb9c\udee9\udbd2\udeca\udb99\udcad\ud9ba\udd29\udb1b\udcbf\udbec\udda3\uda04\udc42\udb6d\udc3f\ud872\ude3c", "\u973b\u64b4\uaf7e\ucfba\u7a39\u3811\u110c\u58a8\uacfa\u1955\u0846\u3919\u9715\ud2d7\u63e4\u4480\u0212\u4127\ud017\u9a3f\ucbec\u117d\u522d\u730f\ub325\u5a9b\ub6d4\u614a\ud04f\u83a8", "\ud93e\uddc8\uda3c\udf9d\uca0d\uda73\udd26\udb8f\udf70\udbc0\udce0\udabd\udc97",
        27, 35509, 825351052, 1040696035171108883L, -36142L, true, true, (char) 13551, (char) 24285,
        Double.longBitsToDouble(0x3fbb373d35de4790L), Double.longBitsToDouble(0x3fc6262dca78471cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.Parser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 5, 1, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\u1ceb\u7dd1\u8dde\u2c3d", "\u8244\ud987\uddf9\ud947\udd8b\ud925\udfd3\uda94\udec2\udb95\udf4d\ud860\udf47\udaca\udd33\uda09\udce0",
        20, 27253, 145645647, 1333358129706310495L, 53441L, true, false, (char) 21521, (char) 24286,
        Double.longBitsToDouble(0x3fcb2677c8cb62fcL), Double.longBitsToDouble(0x3fed93189675b8a8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NumberFormatException\012",
        Z.run(T, 1, 10, 4, 1, "", "\u9a72\u3206", "\ud966\udc45\ud935\udf88\ud83d\udf6e\uda5d\udf88\udad1\udcc4\uda93\udce9\udae3\udfa2\ud813\udf95\uda06\udfd1\udbb8\ude60\udb72\udcd1",
        46, 82863, -1677330117, 28847036170240L, 68340L, false, false, (char) 48813, (char) 24061,
        Double.longBitsToDouble(0x3fed66ed115d534eL), Double.longBitsToDouble(0x3fe55dd9878c5afdL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 8, 10, 3, "", "\u1e05\u133e\ud768\u18a0", "\ud83d\udf6e\udaaa\udc5cK\ud89c\uddad\ud8ef\udf7b\ud91f\udeba\ud83a\uddee\u71ef\ud859\udc32\udbae\udf13\ud9ca\udf55\udbfd\udfda\u86dc\uda6d\ude35\ud878\udf42\ud9e4\uddc4\uda53\udc67\ud85a\udf94\u3465\ud81e\ude23\uda49\ude07\u3579",
        10, 66382, 223306431, -366542769572095147L, -99415L, false, true, (char) 19037, (char) 47931,
        Double.longBitsToDouble(0x3fea0dcd0f08d638L), Double.longBitsToDouble(0x3fc064af1bf9262cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 20, 11, 1, "\ud9c8\ude53", "\u7450\u3ba5\u2bb5\031\u3d1a\u7d0c\u8d5e\u9e7b\ud317\u8f4c\u7179\uc89c\u7d09\u34f2\u03ec\u7b6e\ucae4\uc81e\ua11b\ucded\u7520\u2d88\ucc54\u2af1", "\uf2bc\uda56\udfe3\uda26\udc1f\ud826\udec5\uda5a\udd4c\udbfe\udc4c\ud95b\ude10",
        20, -103, -1468946536, 7765275462068742263L, -34408L, true, false, (char) 19243, (char) 38579,
        Double.longBitsToDouble(0x3fe87b42d8ac07b1L), Double.longBitsToDouble(0x3fe6547d5acc0e61L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 15, 20, "\u00a0\uda91\udced\uc9cd\uda35\udda4\udbec\uded4\udbbe\udd68\ud82f\udc29\uda43\udc3c\ud83e\udc17\udac7\udc5cK\uda93\udc08\udb49\udc09", "\ud342\u6ab4\uac83\ub774\u2224\u86dc\ubecb\u26f1\u0b20\u4801\u8d1e", "\ud913\udcf5\udb84\ude3a\ud99b\ude54\ud82e\ude8b\udb35\udd5a\udb54\udd75\udae9\ude48\udb35\udc21\udbba\udcdf\uda3e\uddcc\ud8ca\udf5e\ud944\uded7\ud820\udfaa\ud9bc\uddd4\ud915\udca3\udbcf\udfc6\udb25\uded0\udb72\udd1c\udb04\ude7e\ud8a6\udc92\ud980\udeee\udb0e\udce4\ud8c4\udc3d\ud95d\udd03\ud822\ude97\ud97c\udebc\u6e57\udad8\udef6",
        40, 81292, 1873095850, 548539876122664013L, -78815L, true, false, (char) 18422, (char) 34624,
        Double.longBitsToDouble(0x3fe8f1a8f5d51c65L), Double.longBitsToDouble(0x3fecd340c7b12564L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "", "\u1e05\u133e\ud768\u18a0", "\udbbb\udce7\udaaa\udc5cK\ud89c\uddad\ud8ef\udf7b\ud91f\udeba\ud83a\uddee\u71ef\ud859\udc32\udbae\udf13\ud9ca\udf55\udbfd\udfda\u86dc\uda6d\ude35\ud878\udf42\ud9e4\ude30\uda53\udc67\ud85a\udf94\u3465\ud81e\ude23\uda49\ude07\u3579",
        10, 66382, 223306431, -366542769572095147L, -99415L, false, true, (char) 19037, (char) 47931,
        Double.longBitsToDouble(0x3fea0dcd0f08d638L), Double.longBitsToDouble(0x3fc064af1bf9262cL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:&nbsp;\012",
        Z.run(T, 1, 6, 15, 20, "\u00a0", "\u08b7", "\ud82f\udc29\uda43\udc3c\ud83e\udc17\udac7\udc5cK\uda93\udc08\udb49\udc09",
        40, 49263, -352893903, 9007408767504594704L, -100000L, true, true, (char) 1216, (char) 27572,
        Double.longBitsToDouble(0x3fb2bc6f0e5a0698L), Double.longBitsToDouble(0x3fe7a2de3ae5e7abL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 9, 15, 4, "\ud990\uddc7\ud93d\udcaa", "\u3ba5\u18a0\u5339\ua0ea\uc05b\u8dde\u2c3d", "\ud90c\udf1b\ud987\ude24",
        34, 49569, 1524217616, -4638219710900640927L, 33146L, true, false, (char) 44088, (char) 12989,
        Double.longBitsToDouble(0x3feac6b434c9a00cL), Double.longBitsToDouble(0x3fd2a684c48ec9aaL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 11, 7, 9, ",", "\u8491\u2bbe\u18a0\u5339", "\udb08\ude40",
        5, 26008, -2141461527, 4190188505030557968L, -17709L, true, true, (char) 47512, (char) 56578,
        Double.longBitsToDouble(0x3fe6e3b6208c0000L), Double.longBitsToDouble(0x3fe41ad5e0425b2bL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 6, 6, 6, "", "\uc11c\u133e\ud768\u18a0", "\ud83d\udf6e\udaaa\udc5c\ud9f5\udc58\uda31\udcd8\ud8ef\udf7b\ud91f\udeba\ud83a\uddee\ud937\udc5c\ud983\udc91\udbde\udec6\ud9ca\udf55\udbfd\udfda\udac1\udfba\udb37\udcd5\ud878\udf42\udb40\udf51\ud8f3\udfbf\udac0\udf73\u3d09\ud81e\ude23\uda49\ude07\u3579",
        10, 66382, 223306431, -412430887357326507L, 97193L, false, true, (char) 19037, (char) 47931,
        Double.longBitsToDouble(0x3fea0dcd0f08d638L), Double.longBitsToDouble(0x3fc064af1bf9262cL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.jsoup.parser.Parser:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 11, 9, ",", "\u8491\u2bbe\u18a0\u5339", "\udb42\ude3dK\udaac\udf67\ud92d\udc63\ud8ff\uddac\ud9c8\udfe4\ud8c2\udcf0\udb88\udfc7",
        47, 32743, 1992563992, 148280973215884L, 71945L, true, true, (char) 28131, (char) 61506,
        Double.longBitsToDouble(0x3fe55663fd6ac4beL), Double.longBitsToDouble(0x3fb27451d147eaa8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Entities|isBaseNamedEntity|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String,boolean|static",
    "M|org.jsoup.parser.Parser|unescapeEntities|java.lang.String,boolean|static",
    "M|org.jsoup.parser.Tokeniser|consumeCharacterReference|java.lang.Character,boolean|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|unescapeEntities|boolean|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,java.nio.charset.CharsetEncoder,org.jsoup.nodes.Entities$EscapeMode|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,org.jsoup.nodes.Document$OutputSettings|static",
    "M|org.jsoup.nodes.Entities|getCharacterByName|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|isNamedEntity|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|loadEntities|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|toCharacterKey|java.util.Map|static",
    "C|org.jsoup.nodes.Entities|<init>|",
    "M|org.jsoup.parser.Parser|getErrors||new:org.jsoup.parser.Parser:org.jsoup.parser.TreeBuilder",
    "M|org.jsoup.parser.Parser|getTreeBuilder||new:org.jsoup.parser.Parser:org.jsoup.parser.TreeBuilder",
    "M|org.jsoup.parser.Parser|htmlParser||static",
    "M|org.jsoup.nodes.Entities|isBaseNamedEntity|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String,boolean|static",
    "M|org.jsoup.parser.Parser|unescapeEntities|java.lang.String,boolean|static",
    "M|org.jsoup.parser.Tokeniser|consumeCharacterReference|java.lang.Character,boolean|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|unescapeEntities|boolean|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
