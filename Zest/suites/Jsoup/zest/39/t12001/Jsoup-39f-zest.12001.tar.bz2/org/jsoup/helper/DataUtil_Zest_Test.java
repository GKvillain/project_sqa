package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 2, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb48\udff7\udacb\udd58\ud933\udeac\ud8b7\udc01\ud97f\udcb5\ud869\udc8a", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u254d\u784c\u34ed", "\udb37\udf69\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udada\ude9a\ud959\ude5d\udb75\udd38\ud866\udfdc\ud8bc\udd2c\uad64\ud979\udd06\uda2f\udc3a\uda52\udc4f\udbc4\uddda\ud950\udd2b\uda09\ude15\ud82d\udde4\uda17\ude8f\udb19\udc4c\ud8af\uddc7\udba7\uddba\ud8a6\udcac\ud898\udff7\ud910\uddc0\udbeb\udf45\udbf5\udf25\udbb3\ude3d\udb7e\udd8d\uda4a\udfa8\u87a9\ud967\ude64\ud97e\udc98\ud9d5\udd0b\udb1e\udf06\ud877\ude6b\udaee\udc45\ud914\udde0",
        57, 85697, -1026471559, -6017497889559461964L, 74416L, true, true, (char) 13823, (char) 18301,
        Double.longBitsToDouble(0x3fe74d6493fc060cL), Double.longBitsToDouble(0x3fcc6d29c489e6e0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 2, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb49\udc35\udacb\udd58\ud933\udeac\ud8b7\udc01\ud97f\udcb5\ud869\udc8a", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u254d\u784c\u8d5c", "\udb37\udf69\ud9bd\udfba\ud92a\uddd9\u503c\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udada\ude9a\ud959\ude5d\udb75\udd38\uda2f\udf7c\ud948\uddb6\udac9\udcf2\ud979\udd06\uda2f\udc3a\ud8d9\udc4f\udbc4\uddda\ud950\udd2b\uda09\ude15\ud82d\udde4\uda17\ude8f\udaf5\udc26\udb46\udfc8\udba7\uddba\ud8a6\udcac\uda38\udea7\ud910\ude2f\udbeb\udf45\ud9d6\udfb6\ud824\udfff\ud85d\udfdc\uda4b\udc13\u87a9\ud967\ude64\ud97e\udc98\ud9d5\udd0b\udb1e\udf06\ud877\ude6b\udaee\udc45\ud914\udde0",
        32, 13374, 1765886329, -2399981489038962452L, 74416L, true, true, (char) 13823, (char) 18301,
        Double.longBitsToDouble(0x3fe74d6493fc060cL), Double.longBitsToDouble(0x3fcc6d29c489e6e0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 5, "\ud960\udcf4\uda1b\udd00\ud925\udc3b\ufc9c\udb48\udff7\udacb\udd58\ud933\udeac\ud8b7\udc01\ud97f\udcb5\ud869\udc8a", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u254d\u1430\u34ed", "\udb37\udf69\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udada\ude9a\ud959\ude5d\udb75\udd38\ud866\udfdc\ud8bc\udd2c\uad64\ud979\udd06\uda2f\udc3a\uda52\udc4f\udbc4\uddda\ud950\udd2b\uda09\ude15\ud82d\udde4\uda17\ude8f\udb19\udc4c\ud8af\uddc7\uda26\udfe1\ud8a6\udcac\ud898\udff7\ud910\uddc0\udbeb\udf45\udbf5\udf25\udbb3\ude3d\udb7e\udd8d\uda4a\udfa8\u87a9\ud967\ude64\ud97e\udc98\ud9d5\udd0b\udb1e\udf06\ud877\ude6b\udaee\udc45\ud914\udde0",
        57, 85697, -1026471559, -6017497889559461964L, 74416L, true, true, (char) 13823, (char) 18301,
        Double.longBitsToDouble(0x3fe74d6493fc060cL), Double.longBitsToDouble(0x3fcc6d29c489e6e0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 2, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb48\udff7\udacb\udd58\ud933\udeac\ud8b7\udc01\ud93e\udc95\uda00\udf5e", "\u2841", "\ud91e\udec2\udac3\udd8a\uda91\udc8e\udbbf\udc4a\uda07\ude98\ud85d\udd2d\ud936\ude8c\udb9d\udc03\ud8f4\udd13\udb7f\udf6d\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udada\ude9a\ud959\ude5d\udb75\udd38\ud866\udfdc\ud8bc\udd2c\uda85\ude51\ud963\ude13\uda4b\udc3a",
        28, 47764, 464477783, 7494816543594460981L, 26552L, true, true, (char) 33255, (char) 5876,
        Double.longBitsToDouble(0x3fd9aeca8d01c87aL), Double.longBitsToDouble(0x3fe251b9588b1b1aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 1, 0, 0, 2, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb48\udff7\udacb\udd58\ud933\udeac\ud8b7\udc01\ud97f\udcb5\ud869\udc8a", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u254d\u784c\u34ed", "\udb37\udf69\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udada\ude9a\ud959\ude5d\udb75\udd38\ud866\udfdc\ud8bc\udd2c\uad64\ud979\udd06\uda2f\udc3a\uda52\udc4f\udbc4\uddda\ud950\udd2b\uda09\ude15\ud82d\udde4\uda17\ude8f\udb19\udc4c\u00c8\udae9\uddf3\ud8a6\udcac\ud898\udff7\ud910\uddc0\udbeb\udf45\udbf5\udf25\udbb3\ude3d\udb7e\udd8d\uda4a\udfa8\u87a9\ud967\ude64\ud97e\udc98\ud9d5\udd0b\udb1e\udf06\ud877\ude6bv\000",
        -5, -1000, 0, -6017497889559461964L, 74416L, true, true, (char) 13823, (char) 18301,
        Double.longBitsToDouble(0x3fe74d6493fc060cL), Double.longBitsToDouble(0x3fcc6d29c489e6e0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 1, 5, 1, "\ud98c\udc58\uda03\udcf8\udb35\udd84\ufc9c\udaee\ude09\udbf5\udc06\ud9fd\udff7\udaa9\udfac", "\u6dbb\u3d52", "\u03eb\ud91e\udec2\udbc3\udd8a\uda91\udc8e\udbbf\udc4a\ud8e3\udfc6\ud8ae\ude3a\ud936\ude87\udb9d\udc03\ud8ef\ude13\ud8a5\udf00\udb7e\ude46\ud8f9\udfb4\u4fdd\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udb69\udc22\ud959\ude5d\udb75\udd38\ud866\udfdc\ud8bc\udd2c\uad64\ud96f\ude62\udbb1\ude7b\uda82\udf83\udbc4\uddda\udb3f\udf64\uda09\ude15\uda20\ude1e",
        15, 9284, -1709008800, 7288204929962389968L, -48416L, false, false, (char) 36086, (char) 24964,
        Double.longBitsToDouble(0x3fde8d89f2576c4cL), Double.longBitsToDouble(0x3fdf3a2836b89928L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 5, 6, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb60\udcc4\udacb\udd58\ud9c9\udc36\ud8ca\udda0\ud97f\udcb5\ud869\udc55", "\u36cd\uc5f0\u82a2\u34c8\u21c7\u6631\u5f24\u254d\u784c\u34ed", "\udb37\udf69\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud821\udc46\ucd3b\udafb\udf4e\udb75\udd19\ud866\udfdc\ud8bc\udd2c\uad64\ud979\udd06\uda2f\udc3a\uda52\udc4f\udb1c\udee4\ud860\udc44\uda09\uddae\ud82d\udde4\uda17\ude8f\ud812\udc69\ud8a4\udc48\udba7\uddba\ud8a6\udcac\ud923\uddfd\udb54\udd43\ud88c\udc1b\udbf5\udf25\uda31\udf5c\udb53\udf30\uda4a\udfa8\ud897\udf7c\u663b\udbe1\udfd0\ud9d5\udd0b\udb1e\udf06\ud90c\ude9d\udb27\udd0f\ud920\udd56",
        9, 65311, 177344396, -4111916547045777887L, 74416L, true, true, (char) 13823, (char) 18301,
        Double.longBitsToDouble(0x3fe74d6493fc060cL), Double.longBitsToDouble(0x3fcc6d38c489e6e0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 5, 2, "\ud9ec\udc7a", "\u9a22\u2822\u2729\u6a1a\u35c5\u6454\u5ee5\u6dbb\u3d52\u36cd", "\udb52\udebc\udac3\udd8a\uda91\udc8e\udbbf\udc4a\uda2c\ude4e\ud85d\udd44\ud936\ude8c\ud83f\udc53\udaa8\ude0b\udb37\udf69\ud9bd\udfba\udb23\ude97\u504d\ud9f3\uddb1\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udada\ude9a\ud959\ude5d\udb75\udd38\ud99d\udff8\udaf3\udded\ud915\udde4\ud98b\udf7c\uda2f\udc3a",
        28, 47764, 1272607923, 7515645691871049525L, -42980L, false, true, (char) 33255, (char) 5876,
        Double.longBitsToDouble(0x3fd9aeca8d01c87aL), Double.longBitsToDouble(0x3fe251b95823ccd3L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 1, 7, 5, 2, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb48\udff7\udacb\udc67\ud933\udeac\ud91b\udcda\ud99a\ude19\ud869\udc8a", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u254dM\ua756", "\ud83d\udc7a\ud9bd\udfba\udb23\ude97\u504d",
        34, 23833, -1312249531, 2465324189042348592L, 51300L, true, false, (char) 39665, (char) 39281,
        Double.longBitsToDouble(0x3f9a66e00a21f560L), Double.longBitsToDouble(0x3fa92131f64be160L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 3, 2, "\uda7a\uddf8\uda56\uddc7\udb34\ude94\u4043\ud9f7\ude7e\udacb\udd58\ud933\udeac\ud8b7\udc01\ud97f\udcb5\ud869\udc8a", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u254d\u784c\u34ed", "\udb37\udf69\ud9bd\udfba\udb23\ude97",
        28, 67610, -149253167, -5636068818199144630L, 21549L, false, true, (char) 31082, (char) 13907,
        Double.longBitsToDouble(0x3feaa0c2341a66e0L), Double.longBitsToDouble(0x3fb443eae1921318L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 5, 5, "\ud960\udcf4\uda1b\udd00\ud925\udc3b\ufc9c\udb48\udff7\udacb\udd58\ud933\udeac\ud8b7\udc01\ud97f\udcb5\ud869\udc8a", "\u36cd\uc5f0\u4514\ucf0f\u61c7\u6d7d\u0102\u254d\u6538\uce94", "\udb37\udf69\ud9bd\udfba\udb23\ude97\u504d",
        -5, 23833, -1312249531, 7031692738099328965L, 24828L, true, false, (char) 37970, (char) 16282,
        Double.longBitsToDouble(0x3f9a66e00a21f560L), Double.longBitsToDouble(0x3fa92131f64be160L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 5, "\ud960\udcf4\uda1b\udd00\ud925\udc3b\uda2a\udfb2\udb49\udc7a\ud871\udc6c\udbd0\udeb8\uebe3\ud9fa\udc83\udb3c\udc6f", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631", "\ud9e6\udd69\ud8d1\ude67",
        4, 76648, 386792974, -9106121024800740213L, 80906L, true, true, (char) 41055, (char) 18706,
        Double.longBitsToDouble(0x3fee2b0caacd301aL), Double.longBitsToDouble(0x3fece1e3ca2d5f3dL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 1, 2, 2, "\ud960\udcf4\uda1b\udd00\ud971\udd61\ud812\udc0d\uda58\ude7e\udacb\udd11\ud933\udeac\ud8b7\udc01\ud97f\udc3c\udaf7\udd1a", "\u36cd\uc5f0\u933a\u98cc\u21c7\u6631\u5f24\u254d\u1430\u34ed\ub558\u496e\ub3dd", "\u504d\ud93d\udeaf\udb18\udf4a",
        39, 83546, 807057349, 4357754688670984092L, 81582L, false, true, (char) 58106, (char) 30716,
        Double.longBitsToDouble(0x3fa92131950be160L), Double.longBitsToDouble(0x3fc660e37fc12f68L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 1, 7, 5, 2, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb48\udff7\udacb\udd58\ud933\udeac\ud8b7\udc01\ud93e\udc95\uda00\udf5e", "\u2841", "\ud91e\udec2\udac3\udd8a\uda91\udc8e\udbbf\udc4a\uda07\ude98\ud85d\udd2d\ud936\ude8c\udb9d\udc03\ud8f4\udd13\udb7f\udf6d\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udada\ude9a\ud959\ude5d\udb75\udd38\ud866\udfdc\ud8bc\udd2c\uda85\ude51\ud963\ude13\uda4b\udc3a",
        28, 47764, 464477783, 7494816543594460981L, 26552L, true, true, (char) 33255, (char) 5876,
        Double.longBitsToDouble(0x3fd9aeca8d01c87aL), Double.longBitsToDouble(0x3fe251b9588b1b1aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 2, "", "", "\udb48\udff7",
        -5, 94902, 1933016375, -3532771022863381144L, -9113L, false, false, (char) 31383, (char) 8301,
        Double.longBitsToDouble(0x3fe2a9730f8a9e02L), Double.longBitsToDouble(0x3fd9850a9c8d9a42L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=null\012",
        Z.run(T, 2, 7, 1, 3, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb48\udff7\ud8ac\udf6b\ud933\udeac\ud8b7\udc01\ud97f\udcb5\ud869\udc8a", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u9a0c\u5844\u34ed", "\udb37\udf69\udaee\udf52\udb06\ude1f\ud9ea\udf8b\udad2\udea9\udb18\udf10\udbf1\udca8\udaac\udcbd\ud828\udc21\ud92d\udd27\udb75\udd38\ud8d7\udcdf\ud8bc\udd2c\ud9ef\udd65\ud979\udd06\uda2f\udc3a\uda52\udc4f\udbc4\uddda\ud950\udd2b\ud8cd\ude17\ud82d\udde4\uda17\ude8f\udb19\udc4c\u00f6\udb57\udeab\ud899\udf3c\ud898\udff7\ud910\uddc0\udbeb\udf45\udbf5\udf25\udbb3\ude3d\ud830\udd06\udb48\udc42\u8800\uda65\udd84\udabc\ude9c\udb8e\ude62\ud8ac\udfba\ud879\ude07v\000",
        -5, -1000, 0, 8497856589622458509L, 74456L, true, true, (char) 13823, (char) 18301,
        Double.longBitsToDouble(0x3fe74d6493fc060cL), Double.longBitsToDouble(0x3fcc6d29c489e6e0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 1, "\ud98c\udc58\uda03\udcf8\udb35\uddfa\ufc9c\udaee\ude09\udbf5\udc06\ud9fd\udff7\udaa9\udfac", "\u6dbb\u3d52\ud562\u7cf7\u6f14\ucf0f\uc1cb", "\ud8b6\ude03\ud8ae\ude3a\ud936\ude87\udb9d\udc03\ud8ef\ude13\ud8a5\udf00\u6855",
        18, 74706, 1144701610, -641037472401675963L, -62018L, true, false, (char) 9237, (char) 31082,
        Double.longBitsToDouble(0x3fedf46027541846L), Double.longBitsToDouble(0x3f9a66e01233df80L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 0, "\udb61\udf75\ud890\udc78\ud98a\udda7\ufc9c\ud9f4\udcce\udacb\udd58\ud9c9\udc36\udac7\udc7f", "\ub7cd\u3d52\u36cd", "\udb6d\udc68\udac3\udd8a",
        46, 14186, -853468776, -1341449965550188245L, 88848L, false, false, (char) 42553, (char) 28374,
        Double.longBitsToDouble(0x3fedd4dfc4e114beL), Double.longBitsToDouble(0x3fee8dc9d15f491aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 0, "\ud8f1\udf1d", "\u9a22\u2822\u2729\u6a1a\u8212\u6454\u5ee5\u2360\uc32b\u4217\uc5f0", "\udac3\udd8a\uda91\udc8e\udbbf\udc4a\uda2c\ude4e\ud85d\udd44\ud936\ude8c\udb2d\udfff\uda0c\ude2e\udb37\udf69\ud9bd\udfa4\udbd6\udc10\u4f9b\ud9f3\uddb1\udb18\udf4a\udbf1\udca8\ud8a9\udd0a",
        3, 19918, 1594276183, -2696501496072303338L, 54674L, true, true, (char) 31661, (char) 21454,
        Double.longBitsToDouble(0x3fe9ab4267d0e9abL), Double.longBitsToDouble(0x3fe5e39413c8d6b0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 7, 0, 0, "\ud960\udcf4\ud9b0\udc2b\000\000\000\ud867\udd73\udbd0\udeb8\uebe3\ud9fa\udc83\udb03\ude61", "\u36cd\uc5f0\024\000\u21c7\u6631", "\ud9e6\udd69\uc738",
        -5, 31000, 385875982, -9106121024800740213L, 80906L, true, true, (char) 41055, (char) 200,
        Double.longBitsToDouble(0x3fee280002cd301aL), Double.longBitsToDouble(0x3fece1e0022d5f3dL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 5, "\ud960\udcf4\uda1b\udd00\ud8a9\udd3b\uda2a\udfb2\udb49\udc7a\ud871\udc6c\udbd0\udeb8\uebe3\udafa\udc83\udb3c\udc6f", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631", "\ud9e6\udd69\ud8d1\ude67",
        4, 76648, 386792974, -9106121024800740213L, 80906L, true, true, (char) 41055, (char) 18706,
        Double.longBitsToDouble(0x3fee2b0ca929301aL), Double.longBitsToDouble(0x3feaebcc4a2d5f3dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 5, "\ud960\udcd0\uda1b\udd00\ud925\udc3b\uda2a\udfb2\udb49\udc7a", "\u5b66\u90cd", "\ud9fc\udec7\udb9c\udff4",
        31, 96676, -174236833, 3321733267065043541L, -27912L, true, false, (char) 29492, (char) 29944,
        Double.longBitsToDouble(0x3fe2855e050eeb01L), Double.longBitsToDouble(0x3febf8b86c59b284L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 7, "\ud960\udcf4\uda1b\udd00\ud925\udc3b\uda2a\udfb2\udb49\udc7a\ud871\udc6c", "\u9039\u3184\u572c\u6416", "\u03eb\udbc0\ude93\udac3\udd8a\uda91\udc8e\udbbf\udc4a\uda07\ude98\udbcd\udc9b\udad4\udd43\u8b19\ud8d1\udc77\udb37\udf69\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\uda93\uddf6\udaa0\uddba\udb75\udd38\udb81\udc0a\udae4\ude69\udbc0\udda5\udaa7\udeec\udac5\udd1c\ud874\udd0b\ud80d\uddc2\udbfd\udf0d\udbe6\udf71\udae4\udee6",
        -5, 62843, 1861821626, 4250279017845643528L, 31061L, true, true, (char) 30384, (char) 20708,
        Double.longBitsToDouble(0x3fcaa65730c27324L), Double.longBitsToDouble(0x3fed8d28cf517445L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 5, "\ud8ad\udf7b\ud964\udd8d\udab2\udc40", "\u63af\u4563\u5556\u90cd\u3184\uadb0\u6416\u36cd", "\uf452\ud9e4\udf72\uda91\udc8e\udbbf\udc4a\uda07\ude98\ud9e6\udd69\ud8d1\ude67\udbf1\uddd7\ud8f4\udd13\udb37\udf69\ud9bd\udfba\ud887\udf89\u5078\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud892\udc84\udada\ude9a\ud959\ude5d\udb75\udd38\udb10\udf71\ud887\udd41\ud822\uddfd\ud8a5\udc0e\udaea\udf79",
        3, 69560, 1092046837, 1164238682399763905L, -74849L, false, true, (char) 13964, (char) 24495,
        Double.longBitsToDouble(0x3fd281301a0a8a8cL), Double.longBitsToDouble(0x3fea72357e4b634eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 7, 7, 5, "\ud960\udcf4\uda1b\udd00\ud925\udc3b\uda2a\udfb2\udb49\udc7a\ud871\udc6c\ud8cc\uddad\uebe3\ud9fa\udc83\udb3c\udc6f", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u40dc\ub2c9\u9ed1\u0ef5\u496e\u1161", "\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a",
        54, 72829, 1597892508, -1994502902501412418L, -23519L, false, true, (char) 15867, (char) 43652,
        Double.longBitsToDouble(0x3fed96ec14a3f96dL), Double.longBitsToDouble(0x3fdaab5971d8a838L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 5, "\uda9d\udfdb\ud8bf\ude28\ue7a5\ud910\udf6f\ud8fb\ude6b\udaba\ude74\udbd0\udeb8\uda15\udcbd\ud8ec\udeb4\udb3c\udc6f", "\u36cd\uc5f0\u6f14\ucf0f\u21c7\u2adb", "\ud9e6\udd69\udad5\udd88\ud901\udfda\udb16\ude3a\udb3f\udfd7\ud9be\udc67\udb23\ude97\u504d",
        28, 23833, -1903963579, 7031692739136042949L, 24828L, true, false, (char) 5910, (char) 370,
        Double.longBitsToDouble(0x3fd2d3a996dd9118L), Double.longBitsToDouble(0x3fdd424426a9cdceL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 0, "", "\000\000\000\u3cb6\u4563\u7d37\000", "\ud800\udec9",
        -5, 24351, 20, 6367744L, 35286L, false, false, (char) 862, (char) 29492,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f8dd60000000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 6, 0, "\ud8a7\udf6a\ud9b0\udc2b\000\ud8a1\udf2f\ud82b\udfcb\ud8b1\udd25\uda34\udfef\uebe3\ud9a2\udcf8\ud932\udee2", "\u36cd\uc5f0\u4e4c\u7f88\ub700\u5852\u5f24\u254d\ub2c9\uc738\000\u6f1d\u980d", "\udbce\uded0\ud890\udef5\udb18\udf4a\udb42\udd50",
        -5, 66349, 1006688973, 6862896062828845613L, 42635L, false, true, (char) 19782, (char) 40303,
        Double.longBitsToDouble(0x3fe233ff89304b31L), Double.longBitsToDouble(0x3fd128ab359becc0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 7, 7, 0, "\ud960\udcf4\ud9b0\udc2b\udaf2\udf02\000\000\ud867\udd73\udbd0\udeb8\uebe3\ud9fa\udc83", "\ud0ab\ud459", "\000\udac3\udd8a\uda91\udc8e\udbbf\udc4a\uda07\ude98\ud9e6\udd69\uc738\000\ud8c7\udec3\ud874\udd87\ud9be\udc29\udb23\ude97\ub7ba\ud93d\udeaf\udb18\udf4a\udb42\udd50\000\udada\ude9a\ud8bd\udfe5\udb0d\udc35\ud8af\udd20\uda68\udef1\ud95f\udfce\ud9cb\udee2\ud9b4\udee0",
        26, 43265, 1923084163, 3144484850339378794L, -84877L, false, true, (char) 43662, (char) 13381,
        Double.longBitsToDouble(0x3fdf4c956817eff0L), Double.longBitsToDouble(0x3fe9d5b7707a88e3L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 5, "\ud960\udcd0\uda1b\udd00\ud925\udc3b\uda2a\udfb2\udb49\udc7a", "\u5b66\u90cd", "\ud9fc\udec7\udb9c\udff4",
        31, 63924, -183750798, 3321733268221164117L, -27912L, true, false, (char) 29492, (char) 29944,
        Double.longBitsToDouble(0x3fe2855e050eeb01L), Double.longBitsToDouble(0x3febf8b86c59b284L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 5, 2, "\uda6a\uddf8\ud9ff\uddfa\udb35\udd84\ufc9c\udb48\udff7\udacb\udd58\ud933\udeac\ud8b7\udc01\ud97f\udcb5\ud869\udc8a", "\u367e\uc5f0\u6f14\ucf0f\u21c7\u6631\u5f24\u254d\u784c\u34ed", "\udb37\udf69\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\udada\ude9a\ud959\ude5d\udb75\udd38\ud866\udfdc\ud8bc\udd2c\uad64\ud979\udd06\uda2f\udc3a\uda52\udc4f\udbc4\uddda\ud950\udd2b\uda09\ude15\ud82d\udde4\uda17\ude8f\udb19\udc4c\ud8af\uddc7\udba7\uddba\ud06b\ufa7a\ud910\uddc0\udbeb\udf45\udbf5\udf25\udbb3\ude3d\udb7e\udd8d\uda4a\udfa8\u87a9\ud967\ude64\ud97e\udc98\ud9d5\udd0b\udafd\ude06\ud877\ude6b\udaee\udc45\ud914\udde0",
        57, 85697, -1026471559, -6017497889559461964L, 74416L, true, true, (char) 13823, (char) 18301,
        Double.longBitsToDouble(0x3fe74d6493fc060cL), Double.longBitsToDouble(0x3fcc6d29c489e6e0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 7, "\ud960\udcf4\uda1b\udd00\ud886\udd6c\ud841\ude0d\udb49\udc7a\ud871\udc6c", "\u9039\u3184\u572c\u6416", "\u03eb\udbc0\ude93\udac3\udd8a\uda91\udc8e\udbbf\udc4a\uda07\ude98\udbcd\udc9b\udad4\udd43\u8b19\ud8d1\udc77\udb38\udc3c\ud9bd\udfba\udb23\ude97\u504d\ud93d\udeaf\udb18\udf4a\udbf1\udca8\ud8a9\udd0a\uda93\uddf6\udaa0\uddba\udb75\udd38\udb81\udc0a\udae4\ude69\udbc0\udda5\udaa7\udeec\udac5\udd1c\ud874\udd0b\ud80d\uddc2\udb92\ude38\ud87f\ude90\udae4\udee6",
        -5, 62843, 1861821626, 4250279017845643528L, 31061L, true, true, (char) 30384, (char) 20708,
        Double.longBitsToDouble(0x3fcaa65730c27324L), Double.longBitsToDouble(0x3fed8d28cc517445L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream,int|static",
    "C|org.jsoup.helper.DataUtil|<init>|",
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
