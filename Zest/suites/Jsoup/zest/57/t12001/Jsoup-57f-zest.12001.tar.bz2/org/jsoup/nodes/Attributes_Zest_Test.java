package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Attributes_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 14, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 14, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u89ac\u1f94\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 2, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u80e8\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45", "\ud84c\udf99\ud8d5\ude13",
        16, 99435, 1545058607, 3574550645190336875L, 61779L, true, true, (char) 14679, (char) 24970,
        Double.longBitsToDouble(0x3fd5475df4189cf4L), Double.longBitsToDouble(0x3f91ba499fee62a0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 14, 13, 8, "\uda49\udfd9\ud83b\udd36\uda7c\udc5a\ud834\udea3", "\ub5a9\u86bc\u787b\ub7fe\ucb96\u8064\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\uc452\u20af\u0a20\u8952\ucdb9\u0321\u4657\ub996\u099c\u7653\u4daa\u2801\ua051\u7a94\u612b\u14b5\u35dc\ub0e5\u3018\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\udbf8\ude59\ud945\udcc3\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9d8\udd97\udbbe\udcb2\udb29\ude76\ud80d\udeda\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud968\uded2\ud985\udfc0\ud8b2\udd64\ub71b\udb90\udf46",
        45, 62609, 1333645484, 7202591859705170259L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3feba4eec0276dcbL), Double.longBitsToDouble(0x3fdfa984385ecfb4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 14, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua4cf\u9df3\u8f96\ua70f\u0451\u0d9d\u7832\u12a3\u6a52", "\ud84c\udf99\ud8d5\udd7a\ua1f4\uda88\uddf9\ud94b\ude9c\ud971\udd7b\ud84c\udcdb\udace\udc71\udbb8\udd17\udb5c\udc5f\ud9b5\udd65\ud919\udde9\udbdc\uddf3\ud8e9\uddf0\ud833\ude10\udbfd\udef3\udbdf\ude8a\udb53\udc70",
        6, 20547, -1929208204, -7722942152407157839L, 62105L, false, true, (char) 22677, (char) 626,
        Double.longBitsToDouble(0x3fcea3bf7377f868L), Double.longBitsToDouble(0x3fef9390ccd43e8aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 14, 0, 11, "\udb3e\udc21\udac4\uddb2\ud827\ude78\ud866\ude49\udadb\udf6d\uda1d\ude6b\ud97a\udd61\ud81b\udf05\ud84f\ude93\ud9a2\ude0a\ud957\udd49\udbfe\ude1e\udbb1\uddf7\ud9e9\ude0c\udba2\udc0d\uab1f\udb4f\udf04\udb5e\udd86\udb85\udceb\udba4\ude56\uda55\ude67\ud99f\udda6\ud8e4\ude8d\u7f8e\udbef\udfd4\uda4d\uded8\uda10\udfbd\ud84c\udf99\ud8d5\ude13\u59c2\uda88\uddf9\ud94b\ude9c\ud971\uddcb\ud84c\udcdb\udace\udc71\udbb8\udd17\udb5c\udc5f\udb80\udf60\ud919\udde9\udbdc\uddf3\ud8e9\uddf0\ud968\udc4b\udb05\udc18\udb83\udfe3\udb1d\udc88\ud838\ude8f\ud9c0\udceb\ud899\udfad\ud804\udeb7\ud9dd\udf30\udba6\uddad\ud803\udc4b\udb07\uddd4\ud9c5\udde0\uda2c\udc19\ud96e\ude0d\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud96c\udfd5\udacf\ude40\uec30\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud857\udec4\uda84\uddf9\ud8d8\ude4f\ud971\udee0\ud89e\uddad\ud932\udfb9\udabf\udf9b\udaa4\udc6d\ud938\uded2\udbbf\udfbd", "\u1b93\ucbe8\u93fd\u553c\u0e42\u5fa1\uab02\u73d7\u9e5a\u088a\u359d\u915d\u3534\u9d36\u017a\ub072\uaeed\u428c\u35a6\u1497\u1e8b\u63f5\u8e7a\ucb39\u30b0\u808a\u9336\u59b9\u2b87\u1c35\ua4a9\u16c1\u83f3", "\uda5e\udebb\ud810\udda7\udb39\udfad\ud9b2\udc8d",
        25, 42945, 230060002, -549853842367857103L, -4258L, true, true, (char) 37059, (char) 31132,
        Double.longBitsToDouble(0x3fe4e5d404989d38L), Double.longBitsToDouble(0x3fe7ac93337eee9bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes:\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 0, 6, 5, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\ub44b\u3416\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\uc2f0\u82e2\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\udb11\udf75\udacf\ude40\ud81b\udd70\ud972\udcc3\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udae8\ude93\ud8b2\uddc3\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981637207119984L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 1, 14, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\u1dd2\u86bc\u787b\u727f\u655b\u0b78\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\uaa40\ua14d\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u8b47\u27b2\u1655\uaaff\u2660\ua051\u5d05\u612b\u1926\u72ab\uc998\ua311\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda53\udf60\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 90250, 729915899, -3402981638918396016L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 2, 6, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u30de\u77d7\ubc43\u1e27\u810c\u4981\u7ae8\u25ae\uc019\ua547\ucf21\u8f96\ubff9\uc97a\u0d9d\u7832\u5d7d\u6a45\u8d4e\u5d6e\u802c\u4457\u1992\u099c\u1655\u1641\ua701\ua051\u5d05\ud203\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u2f51\u543f\u1605", "\ud804\udeb7",
        -2, 79646, -1403356871, 7960956017779337755L, 41557L, true, false, (char) 21003, (char) 29534,
        Double.longBitsToDouble(0x3fd8cd41ac2f6e8aL), Double.longBitsToDouble(0x3fe8fd9f28d27a09L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\0121=java.lang.String: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 9, 8, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u77fd\ub7fe\u1e25\u810c\u4981\u7ae8\u87bd\uc4e1\ua547\u9df3\u7a77\u4ba7\u69e2\u46be\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\ub365\u099c\u3d30\ud14f\uc531\u17ba\u6783\u612b\u1926\u72ab\u4ef4\u2f6c\u3ca7\u4b69\u1783\uc6b0\ub255", "\ud81d\ude2d\udaeb\udff8\uda0a\udc6c\udba9\udc5d\udba3\ude5a\ud9c5\udde0\ud91c\udff7\ub846\ud966\udf24\uda18\udfa1\udae0\ude3d\ud92e\ude05\ud99c\ude3a\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe",
        11, 22018, -1416461745, 3026103470964245983L, -99689L, true, true, (char) 28587, (char) 44852,
        Double.longBitsToDouble(0x3fc687fefa6e8fb0L), Double.longBitsToDouble(0x3fe916dfc9aca239L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jsoup.nodes.Attributes:\0121=java.lang.String:data-\uda49\udfd9\ud83b\udd36\ud829\udf78\ud834\udec0\012",
        Z.run(T, 2, 11, 4, 12, "\uda49\udfd9\ud83b\udd36\ud829\udf78\ud834\udec0", "\u97b0\u8662\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u44a4\u5c42\u3e22\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u054d\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 60000L, false, true, (char) 41836, (char) 26630,
        Double.longBitsToDouble(0x3fe036b318276d53L), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 7, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0\udaf3\ude35\udae3\udd6e\uda06\udd68\ud81b\udf05\ud84f\ude93\ud9a2\ude0a\ud957\udd49\udbfe\ude1e\udbb1\uddf7\ud9e9\ude0c\udba2\udc0d\uab1f\udb4f\udfcf\udb5e\udd86\ud972\udc00\udbb4\ude9c\uda55\ude67\ud99f\udda6\ud8e4\ude8d\ud8db\udeaa", "\u130e\u0321\u4457\u1992\u099c", "\ud84c\udcdb",
        11, 86557, -584000915, -7740604347676899593L, -1172L, true, false, (char) 18653, (char) 37510,
        Double.longBitsToDouble(0x3fe8e57dc207906eL), Double.longBitsToDouble(0x3fbce05173a25ee0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 14, 3, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u1734\u79b3\u3ca7\u9ae8\u9d79\u16e1\u0573", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 9, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\uc8fb\u3164\u20d5\u49b3\u7ae8\u25ae\u99e1\u3812\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud87d\udd8d\ud9a1\udf16\ud9e9\ude42\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc8f",
        56, 11591, -1738220071, 2585021412149791574L, 35525L, false, true, (char) 17381, (char) 31976,
        Double.longBitsToDouble(0x3fec81798629ab17L), Double.longBitsToDouble(0x3fd0070178ed044cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 1, 15, 5, 12, "\uda49\udfd9\ud97d\udd01\ud8d2\udc50\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\ub07d\u25ae\u66e1\ua547\ua9f4\u2d4f\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u6738\u73b4\u6fd8\u18b6\u9de4\u7f2a\u1926\u72ab\u4257\u2f6c\u66e8\u9ae8\u9d3b\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\u2888\ud944\uddad\udbcd\udd6f\ud9fc\udf15\ud9b4\ude26\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8a7\udf5d\ub71b\udab3\udf82",
        26, 61638, 729915820, -3402981638918396016L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\u0091\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\000\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c",
        14, 1514, -1203836389, 2160402029126232309L, 88402L, false, false, (char) 49062, (char) 38941,
        Double.longBitsToDouble(0x3fe3a5dc50d27a95L), Double.longBitsToDouble(0x3fbe970b86866378L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 14, 12, "\udb20\udc87\udbce\udda9\ud846\udc43\ud834\udec0", "\u60d7\u5f89\u2e1e\u5786\u1edf\u810c\u32ed\u7ab3\u25ae\u99e1\u22d5\u9df3\u8f96\u5d3f\u78c7\u1e50\u7832\u5d7d\u69e7\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u06b9\ua701\ua051\u5d05\u612b\u78e2\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u4121\u1d71", "\ud808\uddf3\udaeb\udff8\uda0a\udc6c\udb5e\udd98\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1",
        46, 42385, 1944626294, -248309424474198531L, -4412L, true, false, (char) 38947, (char) 43202,
        Double.longBitsToDouble(0x3fce26e2c263bfdcL), Double.longBitsToDouble(0x3fe3d739d24f4aa9L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:data-null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 0, 1, "\uda49\udfd9\ud845\udf36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u5576\u4602\u82f2\ua8e5\u06fa\ud38b\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\ud969\udd62\ud889\udde7\ud94e\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud86c\uddf7\udbb2\udd4e\ud9a8\udc0c\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, -48224596, -7568460135353820972L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 14, 14, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud9c3\ude4e", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u43c1\u5ff9\u099c\u1655\u4daa\ua701\ua051\u5d05\u6149\u1926\u72ab\u4257\u2f6c\u3ca7\u68d5\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\uda5f\udc3f\ud808\ude9e\udb36\udc40\udafb\udd46\udac4\uddba\ud879\udd0c\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\udad2\udc3f\udb1b\udfe5\udbd9\udd7f\ud938\uded2\udbbf\udfbd\ud8ab\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 86192L, true, false, (char) 16207, (char) 48238,
        Double.longBitsToDouble(0x3fde064dc04edb84L), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\0121=java.lang.String: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 10, 7, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\uce90\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\u2a65\udaec\udf85\ud8d8\udcf7\ud827\udd8b\ud8b7\uddfe\udaaf\udfba\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21cd367daL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=java.lang.Integer:0 |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 11, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\ua265\u3b3b\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u89ac\u01d2\u5f08\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\ud9c5\ude30\udbc7\udf43\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 2132L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 7, 0, 15, "\udb57\udf54\ud97b\udd57\udaa1\ude49\uda67\uddfa", "\u2150\u875a\ucdbe\u8306\u644f\u8978\u4981\u1121\u254b\ua595\u4093", "\udafb\udedb\uda55\uddd4\ud916\udda2\uda01\udcff\ud9f9\udca8",
        12, 30610, 1926690786, 7647457792134161277L, 38358L, true, false, (char) 42076, (char) 38491,
        Double.longBitsToDouble(0x3fef3bf1b564b7ebL), Double.longBitsToDouble(0x3fe4c902af6d5259L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Attributes:\0121=java.lang.String: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 8, 8, 12, "\uda50\uddac\ud9de\udc78\ud827\ude78\ud834\udec0", "\u9acd\u8671\uc9ca\ua9e0\u6658\u3ce8\u4981\u1aac\u25ae\u5067\ua547\u68df\uc8df\u4b83\u9e33\u0d9d\u7832\u5d7d\u95cd", "\ud84c\udf99\ud8ae\udf5d",
        58, 99435, 1544954377, 3574550643999154539L, 61779L, true, true, (char) 35693, (char) 33646,
        Double.longBitsToDouble(0x3fd5475df59c9cf4L), Double.longBitsToDouble(0x3f884e2cb2a038c0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Attributes:\0121=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 2, 2, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u80e8\ub7fe\u1e25\u31a4\u3c1d\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45", "\ud84c\udf99\ud8d5\ude13",
        11, 58016, 472271481, 3574550138384195947L, 61779L, true, true, (char) 14679, (char) 61432,
        Double.longBitsToDouble(0x3fd54a5674189cf4L), Double.longBitsToDouble(0x3f91ba499fee62a0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e\0121=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e\012",
        Z.run(T, 2, 15, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e", "\ub5a9\u5038\u80e8\ud6d3\u1e25\u810c\u6806\u733e\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45", "\ud9d9\udc4c\ud884\udea7",
        16, 99435, 1545058607, -7882606806840204927L, 61779L, true, true, (char) 31092, (char) 8384,
        Double.longBitsToDouble(0x3fd54753a4189cf4L), Double.longBitsToDouble(0x3f91ba499fee62a0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Attributes:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 15, 12, "\ud8e5\udce7\udb66\udeed\uda59\udfbb\udb07\udf49", "\ub5a9\u86bc\u80e8", "\udbfe\ude1e\udbb1\uddf7\ud9e9\ude0c\udba2\udc0d\uab1f\udb4f\udfcf\udb5e\udd86\ud972\udc00\udbb4\ude9c\ud963\ude6e\ud99f\udda6\udb8d\udf78\ud8db\udeaa\udafe\udd72",
        5, 44458, 1787960664, 1424541459926970766L, -81871L, true, false, (char) 54021, (char) 64809,
        Double.longBitsToDouble(0x3f8b22f9db446c40L), Double.longBitsToDouble(0x3fe66a2c56007142L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 3, 13, 12, "\uda49\udfd9\ud838\ude36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u80e8\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u6079\u35e6\u9e33\u0d9d\u7832\u5d7d\u6a45", "\ud84c\udf99\ud8d5\ude13",
        16, 33339, 1545058607, 3574550642786602859L, -46810L, false, true, (char) 53730, (char) 24970,
        Double.longBitsToDouble(0x3fd5475df4189cf4L), Double.longBitsToDouble(0x3f91ba499fee62a0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyList:[] |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0\012",
        Z.run(T, 2, 2, 15, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub599\u86bc\u80e8\u6a11\u5a36\uaf45\u70df\u9a90\u25ae\u99e1\u3a2a\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u97ab", "\ud84c\udf99\ud8d5\ude13",
        16, 99435, 1545058607, 3574550645190336875L, 61779L, true, true, (char) 14679, (char) 24970,
        Double.longBitsToDouble(0x3fd5475df418eef4L), Double.longBitsToDouble(0x3f91ba499fee62a0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 9, 4, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud88b\udfa8\ud9b1\udcf5\udae3\udd6e\ud97a\udd61\ud81b\udf05\uda19\ude98\ud9a2\ude0a\ud9e9\udea1\ud8b9\udf1d", "\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u679a\u5dbb\u6a45\u31a1\uad0c\u5e16\u4457\ub378", "\ud971\udd4d\ud84c\udcdb\udace\udc71\udbb8\udd17\ud869\udc86\udb87\uddd2\ud919\udde9",
        48, 92300, 1930807313, 2624548544319720071L, -16154L, false, false, (char) 53376, (char) 48333,
        Double.longBitsToDouble(0x3fc5e3ac86f0f28cL), Double.longBitsToDouble(0x3fda7f64410c63d0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 15, 15, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u8648", "\udb3a\udeff\ud873\ude2c\ud8e9\udd34\ud802\udf60\udba2\udc0d\uab1f",
        46, 2265, 1423883008, -3525221749844691564L, -48651L, false, false, (char) 22684, (char) 26528,
        Double.longBitsToDouble(0x3fe71125cceddbd8L), Double.longBitsToDouble(0x3fcd335a46384f10L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 13, 13, 8, "\uda49\udfd9\udbe9\udf18\uda7c\udc32\ud834\udea3\udaf3\ude35\udae3\udd6e\ud97a\udd61\ud81b\udf05\ud84f\ude93\udb44\udefb", "\u0fb6\u575e\u25ae\u99e1\ua547\u221a\u8f96\u4b83\u9e33\u0d9d\uc452", "\ud826\udf07\uda09\ude72\ud84c\udf99\ud8d6\udc13\ud9ce\udda4",
        15, 85386, 832264927, 9094494339284583587L, 8966L, false, false, (char) 41746, (char) 33370,
        Double.longBitsToDouble(0x3fcfe07bdb3a66f4L), Double.longBitsToDouble(0x3fe8e652e207906eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u8204\u7d4a\u9787", "\000",
        12, -1000, 1578827776, -2161727607409344512L, -100000L, true, true, (char) 6991, (char) 0,
        Double.longBitsToDouble(0x3fe80000057f54deL), Double.longBitsToDouble(0x3fd94cf13142000cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 0, 0, 8, "\uda49\udfd9\ud83b\udd36\uda7c\udc5a\ud834\udea3", "\ub5a9\u86bc\u787b\ub7fe\ucb96\u8064\u4981\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\uc452\u20af\u0a20\u8952\ucdb9\u0321\u4657\ub996\u099c\u7653\u4daa\u2801\ua051\u7a94\u612b\u14b5\u35dc\ub0e5\u3018\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\000\000\000\000\udb07\udd82\udbf8\ude59\ud945\udcc3\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9d8\udd97\u62a1\ud8f9\udc1c\ud80d\udeda\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud968\uded2\ud985\udfc0\ud8b2\udd64\ub71b\udb90\udf46",
        45, 62609, 1333645484, 7202591859705170259L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3feba4eec0276dcbL), Double.longBitsToDouble(0x3fdfa984385ecfb4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.jsoup.nodes.Attributes:\0121=java.lang.Integer:0 |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 11, 11, 12, "\ud9b9\udf66\ud83b\udd9c\udae5\udf70\ud834\ude73", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua4cf\u9df3\u8f96\ua70f\u0451\ub747\u7832\u5fc5\u6a52", "\ud84c\udf99\ud8d5\udd7a\ua1f4\uda88\uddf9\ud81f\udcef\ud971\udd7b\ud84c\udcdb\udace\udc71\udb45\ude5a\udbf7\ude4c\ud932\udd6f\ud919\udde9\udbdc\uddf3\ud8e3\udc6c\ud833\ude10\udbfd\udef3\udbdf\ude8a\udb53\udc70",
        6, 20547, 580492916, -7722942152407157839L, 62105L, false, true, (char) 6542, (char) 24433,
        Double.longBitsToDouble(0x3fdd4499c9bbfc34L), Double.longBitsToDouble(0x3fef9390ccd43e8aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:data-\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0\012",
        Z.run(T, 1, 4, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u2a79\ua4cf\u9df3\u8a40\ua70f\u0451\u0d9d\u7832\u12a3\u6a52", "\ud80c\ude5d\ud8d5\udd7a\ud93c\udf94\udaa6\udeb2",
        22, 87103, 2117509483, -5126287546175617011L, 59060L, false, false, (char) 33370, (char) 36699,
        Double.longBitsToDouble(0x3fde05abe60816aaL), Double.longBitsToDouble(0x3fe03c8373f78145L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua4cf\u9df3\u8f96\ua70f\u0451\u0d9d\u7832\u12a3\u6a52", "\ud84c\udf99\ud8d5\udd7a\ua1f4\uda88\uddf9\ud94b\ude9c\ud971\udd7b\ud84c\udcdb\udace\udc71\udbb8\udd17\udb5c\udc5f\ud9b5\udd65\ud944\udc12\udbdc\uddf3\ud8e9\uddf0\ud833\ude10\udbfd\udef3\udbdf\ude8a\udb53\udc70",
        59, 29624, -1929208204, -7722942152407157839L, 62105L, false, true, (char) 22677, (char) 626,
        Double.longBitsToDouble(0x3fcea3bf7377f868L), Double.longBitsToDouble(0x3fef9390c980b7aaL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 6, 6, 5, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u7ae8\u25ae\u99e1\ua547\ub44b\u3416\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u6076\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\uc2f0\u82e2\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\udab4\ude1b\udaec\udc0d\ud8f9\udee4\u154c\udb07\udd91\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\udb11\udf75\udacf\ude40\ud81b\udd70\ud972\udcc3\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\uda42\uddd7\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udba0\udfeb\ud938\uded2\udae8\ude93\ud8b2\uddc3\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981637207119984L, 60000L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 12, 3, 6, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u30de\u77d7\ubc43\u1e27\u810c\u6806\u3fde\u25f3\uc019\ua547\ucf21\u8f96\ubff9\uc97a\u0d9d\u7832\u5d7d\u6a45\u8d4e\u5d6e\u0b2c\u4457\u1992\u099c\u1655\u15f6\u1e40\u19b2\u5d05\ud203\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u2f51\u543f\u1605", "\ud804\udeb7\udaeb\udff8\udbb4\udc61",
        14, 91410, 899404885, 2160402613241784565L, 88402L, false, false, (char) 44454, (char) 9565,
        Double.longBitsToDouble(0x3fe8fd9f28d27a09L), Double.longBitsToDouble(0x3fe7c3a18f70c5ebL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 3, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud94e\ude0d", "\ub5a9\u86bc\u77fd\ub7fe\u1e25\u810c\u4981\u7ae8\u87bd\uc4e1\ua547\u9df3\u7a77\u4ba7\u69e2\u46be\u7832\u5d7d\u279a\u54a1\u130e\u0321\u4457\ub365\u099c\u3d30\ud14f\uc531\u17ba\u6783\u612b\u1926\u72ab\u4ef4\u2f6c\u3ca7\u4b69\u1783\uc6b0\u2fb3", "\uda90\udd14\udaeb\udff8\uda0a\udc6c\udba9\udc5d\udba3\ude5a\ud9c5\udde0\ud91c\udff7\ub846\ud966\udf24\uda18\udfa1\udae0\ude3d\ud92e\ude05\ud99c\ude3a\ud944\uddad\udaf0\udc43\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud894\udca7\ud834\udd8c\ud8b7\uddfe",
        11, 22018, -1416461745, 3026103470964245983L, -99689L, true, true, (char) 28587, (char) 44852,
        Double.longBitsToDouble(0x3fc687fefa6e8fb0L), Double.longBitsToDouble(0x3fee2800c1acb371L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=java.lang.String: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 8, 12, "\uda49\udfd9\ud83b\udd36\ud861\ude75\ud8d0\udcb6\udb32\udf02\udacd\ude63\ud9c5\udc26", "\ub7fe\u1e25\u6158\u4981\u7ae8\u87bd\uc4e1\u5fc0", "\udb33\udd7a\udada\udccc\ud855\udffb\ud8e4\ude8d\ud8db\udeaa",
        7, 30792, -606581272, -8709647940231824151L, -62563L, false, false, (char) 7610, (char) 22097,
        Double.longBitsToDouble(0x3fc46fc6deb7176cL), Double.longBitsToDouble(0x3fe36daceb9f4406L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 8, 0, "", "\uc34a\u7d67\u9787", "\ud81b\udf05",
        32, 44537, 684076, -2115896878977093235L, 55015L, true, false, (char) 20765, (char) 40168,
        Double.longBitsToDouble(0x3fd1f7594b472386L), Double.longBitsToDouble(0x3fe6b6789b65dd72L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udaf3\ude3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\ud9a2\ude0a\0121=java.lang.String: |this=org.jsoup.nodes.Attributes: \udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udaf3\ude3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\ud9a2\ude0a\012",
        Z.run(T, 2, 15, 8, 1, "\udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udaf3\ude3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\ud9a2\ude0a", "\u4981\u7ae8\u28ed\u8f42\u4381\u9df3\u7a77\u4ba7\u69e2\u46be\u7832\u0cc7\u6a45\u8955", "\ud8d5\ude13\ucc41\uda8e\udfe3\udb6a\udef0\ud804\udd85\ud8f0\ude5b\udb56\udd35\ud848\udf87\udb5c\udc2a\udb80\udf60\ud919\udde9\ud956\udfd1\ud8e9\uddf0\ud968\udc4b\ud895\udce5\udbb1\udf09\udbf7\udd1d\ud827\udf35\udb42\udd99\ud85b\udced\ud8c1\udc4a\ud85d\udd87\uda09\udd28\udba9\udc5d\udba3\ude5a\ud9c5\udde0\ud91c\udff7\ub846\udaaa\udf26\uda18\udfa1\udb26\ude40",
        40, 47125, -1881851276, 6642458070230597242L, 70572L, true, false, (char) 7512, (char) 19815,
        Double.longBitsToDouble(0x3fe27fb20113ab92L), Double.longBitsToDouble(0x3fddf29fee93d0ccL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 3, 3, 8, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0\udaf3\ude35\udae3\udd6e\uda06\udd68\ud81b\udf05\ud84f\ude93\ud872\ude12\ud957\udd49\udbfe\ude1e\udbb1\udda4\ud9e9\ude0c\udba2\udc0d\uab1f\udb4f\udfcf\udb5e\udd86\ud972\udc00\udbb4\ude9c\uda55\ude57\udb9b\uddfa\ud99a\ude80\ud8db\udeaa", "\u130e\u0321\u4457\u1992\u099c", "\ud84c\udcdb",
        11, 86557, -584000915, -7740604347676899593L, -1172L, true, false, (char) 49176, (char) 32019,
        Double.longBitsToDouble(0x3fe8e57dc207906eL), Double.longBitsToDouble(0x3fc50148b9d12f70L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Attributes:\0121=java.lang.String: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 7, 7, 6, "\ud80a\udfa3\udacd\udf74\ud96f\ude8c\udae7\udf6c\uda37\udd35\udae3\udd6e\uda06\udd68\ud81b\udf05\ud84f\ude93\ud97c\ude6b\ud957\udd49\ud9fb\udf57\udbb1\uddf7\ud9e9\ude0c\udba2\udc0d\uab1f\udb4f\udfcf\udb5e\udd86\ud972\udc00\udbb4\ude9c\uda55\ude67\ud99f\udda6\ud8e4\ude8d\ud8db\udeaa", "\u130e\u0321\u4457\u1992\u1a9c", "\ud84c\udcdb",
        42, 90492, 740631849, -1615708854441406176L, 48735L, false, false, (char) 49876, (char) 12917,
        Double.longBitsToDouble(0x3fbce051670556e0L), Double.longBitsToDouble(0x3fc496497c7284e4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=java.util.Collections$UnmodifiableRandomAccessList:[] |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 2, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0\udaf3\ude35\udae3\udd6e\uda06\udd68\ud81b\udf05\ud84f\ude93\ud9a2\ude0a\ud957\udd49\udbfe\ude1e", "\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u75cc\ud20d\u5395\u6a45\u8955\u130e\u0321\u4457\u1992", "\ud971\uddcb\ud84c\udcdb\udace\udc71\ud81a\udc05\udaa2\udc97\ud94c\udf06\ud919\udde9\udbdc\uddf3\ud9ba\udd17\ud968\udc4b\uda2e\udead\udb6b\udef8\uda19\udcc0\ud838\udf12\ud9c0\udceb\uda6c\udfac\udbdd\udd1d\udbf1\ude9e\udab1\ude18\ud960\udcf7\udbb0\ude75\udbc9\ude8b\uda1c\ude8e\ud829\udc84\ud848\udce7\udbe9\udc83\ud997\udd7c",
        25, 64302, 1686622827, -4711730892337340221L, 7288L, false, true, (char) 51651, (char) 28411,
        Double.longBitsToDouble(0x3fe25470c91da8ceL), Double.longBitsToDouble(0x3fc8f1a3fe1c24b8L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0\udaf3\ude35\udae3\udd6e\ud97a\udd61\ud81b\udf05\0121=java.lang.Boolean:true |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0\udaf3\ude35\udae3\udd6e\ud97a\udd61\ud81b\udf05\012",
        Z.run(T, 2, 15, 9, 13, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0\udaf3\ude35\udae3\udd6e\ud97a\udd61\ud81b\udf05", "\uc22b\u20d5\u49b3\u7ae8\u25ae\u99e1\u3812\u9df3\u8f96\u45e2\u4e57\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321", "\uda88\uddf9\ud94b\ude9c\ud971\uddcb\ud84c\udcdb\udace\udc71\udbb8\udd17\udb5c\udc5f\udb80\udf60\ud919\udde9\udbdc\uddf3\ud8e9\uddf0\ud968\udc4b\udb29\udf39\udb83\udfe3\udb1d\udc88\ud838\ude8f\ud991\udde9\ud8a6\udcad\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud8e5\ude7c\ud8a5\udff7\ud9a1\udf16\ud9e9\ude42",
        46, 90356, -1148556816, 8833030515594281170L, 20624L, true, false, (char) 38947, (char) 43202,
        Double.longBitsToDouble(0x3fce26e2cf144760L), Double.longBitsToDouble(0x3fe3d739d24f4aa9L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud979\udc20\ud81a\udec2\0121=java.util.LinkedHashMap$LinkedValueIterator:@? |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud979\udc20\ud81a\udec2\012",
        Z.run(T, 2, 15, 14, 6, "\uda49\udfd9\ud83b\udd36\ud979\udc20\ud81a\udec2", "\ub5a9\u86bc\u787b\uc8fb\ucdd4\u20d5\u49b3\u7ae8\u25ae\uc070\u3812\u9df3\u8f96", "\ud99f\udda6\ud8dc\udd30\ud811\udcb5\udbee\udf85\ud826\udf0a\uda10\udfc6\ud84c\udf99\ud8d5\ude13\ud9dc\udded\uda88\uddf9\ud94b\ude9c\ud971\uddcb\ud85f\udddb\udb4c\ude90",
        51, 36236, -1483229490, -54387380908454017L, -20145L, true, false, (char) 56668, (char) 49876,
        Double.longBitsToDouble(0x3fe03c8371738145L), Double.longBitsToDouble(0x3feba1e0c64bc102L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 9, 9, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\uda55\uddd0", "\u58b2\ubeb8", "\udbfa\udd45\udb80\udca4\udbb1\ude29\ud9e9\ude0c\udba2\udc0d\uab1f\ud8d6\uddd3\udb5e\udd86\ud972\udc00\udbb4\ude9c\uda55\ude67\ud99f\udda6\ud8e4\ude8d\ud8db\udeaa\udb73\ude74\ud826\udf0a\uda10\udfc6\ud84c\udf99",
        35, 47886, -1077973565, 6635976188300581599L, -44083L, true, true, (char) 24970, (char) 58163,
        Double.longBitsToDouble(0x3fe06273d011ba49L), Double.longBitsToDouble(0x3fcfe07bd27fc2f4L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 10, 10, 10, "\uda49\udfd9", "\u7d67\u9787\u40ed\u7faa\uafa5\uc280\ub7fe\u3eb9\u810c", "\ud8eb\udda3\uab61\udb4f\udfcf\udb5e\udd86\ud972\udc00\udbb4\ude9c\uda55\ude67\ud99f\udda6\ud8e4\ude8d\ud8db\udeaa\udb73\ude74\ud826\udf0a\uda10\udfc6\ud84c\udf99\ud8d5\ude13\ua1f4",
        15, 60607, 832264927, -6441377362283381413L, -44083L, true, true, (char) 24970, (char) 58163,
        Double.longBitsToDouble(0x3fe06273d011ba49L), Double.longBitsToDouble(0x3fcfe07bd27fc2f4L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=java.lang.String: |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 7, 12, "\uda49\udfd9", "\uaa66\u9787\u8791\u65df\u821e\u787b\ub7fe\u1e25\u810c", "\udba2\udc0d\uab1f\udb4f\udfcf\udb5e\udd86\ud972\udc00\udbb4\ude9c\uda55\ude67\ud99f\udda6\ud8e4\ude8d\ud8db\udeaa\udb73\ude74\ud826\udf0a\uda10\udfc6\ud84c\udf99\ud8d5\ude13\ua1f4",
        15, 60607, 832264927, 9094633977261311139L, -44083L, true, true, (char) 24970, (char) 58163,
        Double.longBitsToDouble(0x3fe06273d011ba49L), Double.longBitsToDouble(0x3fcfe07bc67fc2f4L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 15, 15, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\ua265\u3b3b\u7ae8\u25ae\u5596\ud242\u9e33\u8f96\u4b83\u89ac\u01d2\u5f08\ua164\u64b0\ubcde\u5026\u0379\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u9edd\ub7e3\u19a8\u2ef6\u42da\u2f6c\u3ca7\u9ae8\uc9eb\u2edd\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b",
        -4, 82611, 503007795, -136751804035011363L, 44596L, false, true, (char) 38941, (char) 62974,
        Double.longBitsToDouble(0x3fca4f52a1e970b8L), Double.longBitsToDouble(0x3fca198de33467b8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 10, 15, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\ua265\u3b3b\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u89ac\u01d2\u427a\u2d0c\u79b0\ua80a\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\udb72\ude0d\udae6\ude91\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\ud8b0\udd95\ud889\uddb1\ud944\uddad\udacf\ude40\ud8a7\udc55\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\ud9c5\ude30\udbc7\udf43\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 2132L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 5, 0, 0, "\uda49\udfd9\ud83b\udd36\ud827\ude78a", "\ub5a9\u86bc\u787b\ub7fe\u1e25\ua265\u3b3b\u7ae8\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u13ac\u01d2\u5f08\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u015c\u83b3\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud980\udd0c\udaeb\udf47\000\000\udb07\udd82\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud852\udcf8\ud935\udf39\udacf\ude40\ud81b\udd70\u00d0\000\ud8b6\udcda\ud92a\ude4d\000\ud8d5\ude8a\ud971\udee0\ud8ed\udd55\uda2c\udf8c\ub5e5\000\000\udbfc\uddde\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 172, -1426063360L, 2132L, false, false, (char) 31535, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\uda6f\udd30\ud827\ude78\u3447\0121=void |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 15, 0, 0, "\uda49\udfd9\uda6f\udd30\ud827\ude78\u3447", "", "\uda19\ude98\udbc0\udc16\ud957\udd49\udbfe\ude1e",
        40, 16122, -988720249, 1968013124956009934L, 78944L, true, true, (char) 33959, (char) 22183,
        Double.longBitsToDouble(0x3fc2aaa69ae885b0L), Double.longBitsToDouble(0x3fda7fef4c36a30aL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e\0121=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e\012",
        Z.run(T, 2, 15, 15, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e", "\ub5a9\u5038\u80e8\u8507\ub49e\u810c\u6806\u733e\u25ae\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45", "\ud9d9\udc4c\ud884\udea7",
        16, 99435, 1545058607, -7882606806840204927L, 61779L, true, true, (char) 31092, (char) 8384,
        Double.longBitsToDouble(0x3fd54753a4189cf4L), Double.longBitsToDouble(0x3f91ba499fee62a0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \udb17\udcfa\ud895\udf24\ud90d\udd0c\ud8f0\udf4a\0121=org.jsoup.nodes.Attributes: \udb17\udcfa\ud895\udf24\ud90d\udd0c\ud8f0\udf4a |this=org.jsoup.nodes.Attributes: \udb17\udcfa\ud895\udf24\ud90d\udd0c\ud8f0\udf4a\012",
        Z.run(T, 2, 15, 3, 12, "\udb17\udcfa\ud895\udf24\ud90d\udd0c\ud8f0\udf4a", "\ub5a9\u5038\u80e8\uca16", "\ud8ce\ude45\ud9e7\ude62\udba2\udc0d\uab1f\udb4f\udfcf\udb5e\udd86\ud972\udc00\udbb4\ude9c\uda55\ude67\ud99f\udda6\ud8e4\ude8d\ud8db\udeaa\udb73\ude74\u6845",
        14, 94774, 383099258, -985032702959281589L, 88388L, true, true, (char) 31902, (char) 33370,
        Double.longBitsToDouble(0x3fcfee62aa5a8160L), Double.longBitsToDouble(0x3feaec8eeeac4b76L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e\0121=java.lang.Boolean:true |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e\012",
        Z.run(T, 2, 15, 10, 3, "\uda49\udfd9\ud83b\udd36\ud827\ude78\uda3e\ude9e", "\ub5a9\u5038\u80e8\ud6d3\u1e25\u810c\u6806\u733e\u22b8\uc04b\u83c4\u732c\u901a\u4b83\u9e33\u0d9d\u2fee\u9035\u7fd0", "\ud928\ude0a\udbf8\udce6",
        8, 99435, 1545058607, -7882606806840204927L, 61779L, true, true, (char) 31092, (char) 8384,
        Double.longBitsToDouble(0x3fd54753a4189cf4L), Double.longBitsToDouble(0x3fd58ba499fee74aL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud81f\ude5b\ud827\ude78\uda3e\ude9e\0121=java.lang.Integer:462303262 |this=org.jsoup.nodes.Attributes: \uda49\udfd9\ud81f\ude5b\ud827\ude78\uda3e\ude9e\012",
        Z.run(T, 2, 15, 11, 12, "\uda49\udfd9\ud81f\ude5b\ud827\ude78\uda3e\ude9e", "\u1188\u5038\u80e8\ud6d3\u1e25\ud36a\u9541\ub7e3\u7137\u11b6\ua3cc\u302d", "\ud857\ude68\ud99f\udda6\ud8e4\ude8d\ud8db\udeaa\udb73\ude74\u6845\ud879\udca9",
        16, 13298, 113471886, -4629861206082471633L, -10273L, true, false, (char) 16616, (char) 28446,
        Double.longBitsToDouble(0x3fee41cd605a4866L), Double.longBitsToDouble(0x3fd54753a4189cfaL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:data-null\012",
        Z.run(T, 1, 4, 15, 3, "\udb0b\udeaa\udb66\udef3\uda59\udfbb\ud90f\uddbb\ud854\uddc7\udae3\udd6e\ud97a\udd61\uf175", "\u1e25", "\ud9e9\ude0c\udba2\udc0d\uab1f\udb4f\udfcf\udb5e\udd86\ud972\udc00\udbb4\ude9c\u8e48\ud99f\uddaa\udb8d\udf78\ud8db\udeaa",
        33, 8595, -606560542, 7679232578746107505L, -67501L, true, false, (char) 47389, (char) 36944,
        Double.longBitsToDouble(0x3fe0038a1416fee3L), Double.longBitsToDouble(0x3fbf38b14f6c5968L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:data-\uda49\udf49\0121=java.lang.String:data-\uda49\udf49\012",
        Z.run(T, 2, 4, 4, 0, "\uda49\udf49", "\u7d4a", "\u33ab\ud836\ude1b\ucf83\000\udad9\udd8b\ud977\ude6d\udb95\udc6a\u5784\udb8b\udc85\uab1f\000\000\ud972\udc00\udb9a\udd9c\ud96f\udd94\ud91e\udea6\udb09\uddce\udbaa\udef3\uda9b\udcec\udb8f\udc4f\udb8b\udfde\uda35\udfce\ud95e\udd82\ud938\udf20\ud866\udf39\ud977\udf86\ud8cc\uddd8\ud8a6\udf2e\udb61\udd82\udb57\uded7\udb82\udd98\ud861\uddca\u34ef\ud918\udde6\u2892\udb2f\ude2f\ud885\udc0c\udac6\udd95\uda6c\udc84\uda6d\uddd4",
        10, 64584, -1584974074, -4205537919994664168L, 16916L, true, false, (char) 8110, (char) 55266,
        Double.longBitsToDouble(0x3fe6a654152a6ae5L), Double.longBitsToDouble(0x3fda73d857291b24L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udad6\udf3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\0121=java.lang.String: |this=org.jsoup.nodes.Attributes: \udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udad6\udf3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\012",
        Z.run(T, 2, 15, 8, 1, "\udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udad6\udf3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\000", "\u4981\u7ae8\u28ed\u8f42\u0e81\u9df3\u7a77\u4ba7\u69e2\u46be\u7832\u0cc7\u6a45\u8955", "\ud8d5\ude13\ucc41\uda8e\udfe3\udb6a\udef0\ud804\udd85\ud8f0\ude5b\udb56\udd35\ud848\udf87\udb5c\udc2a\udb80\udf60\ud919\udcf2\ud956\udfd1\ud8c8\udfe4\ud968\udc4b\ud895\udce5\udbb1\udf09\udbf7\udd1d\ud827\udf35\udb42\udd99\ud85b\udced\ud8c1\udc4a\ud85d\udd87\uda09\udd289\udb63\udf70\ud9c5\udde0\ud91c\udff7\ub846\udb39\udc6e\000\000",
        34, 47125, -1881851276, 6642458070230597242L, 70572L, true, false, (char) 7512, (char) 59194,
        Double.longBitsToDouble(0x3fe27fb00113ab92L), Double.longBitsToDouble(0x3fddf29fee93d0ccL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \udb0f\udde2\udbd4\uddea\ud8c8\ude87\ud802\udc45\udaf3\ude3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\ud9af\udcb7\0121=java.util.Collections$UnmodifiableRandomAccessList:[\udb0f\udde2\udbd4\uddea\ud8c8\ude87\ud802\udc45\udaf3\ude3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\ud9af\udcb7] |this=org.jsoup.nodes.Attributes: \udb0f\udde2\udbd4\uddea\ud8c8\ude87\ud802\udc45\udaf3\ude3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\ud9af\udcb7\012",
        Z.run(T, 2, 15, 2, 1, "\udb0f\udde2\udbd4\uddea\ud8c8\ude87\ud802\udc45\udaf3\ude3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\ud9af\udcb7", "\u4981\u7ae8\u28ed\u8f42\u4381\u9df3\u7a77\u4ba7\u69e2\u46be\u7832\u0cc7\u6a45\u8955", "\ud8d5\ude13\ucc41\uda8e\udfe3\udb6a\udef0\ud804\udd85\ud8f0\ude5b\udb56\udd35\ud848\udf87\udb5c\udc2a\udb80\udf60\ud919\udde9\ud956\udfd1\ud8e9\uddf0\ud968\udc4b\ud895\udce5\udbb1\udf09\udbf7\udd1d\ud827\udf35\udb42\udd99\ud85b\udced\udb8d\udc88\ud86e\udd00\uda09\udd28\udba9\udc5d\udba3\ude5a\ud9c5\udde0\udb1b\udef7\uda58\udc8f\udaaa\udf26\uda18\udfa1\udb26\ude53",
        40, 47125, -1881851276, 6642458070230597242L, 70572L, true, false, (char) 7512, (char) 19815,
        Double.longBitsToDouble(0x3fe27fb20113ab92L), Double.longBitsToDouble(0x3fedf94ff3df2f9aL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udaf3\ude3a\uda8c\udcc4\ud97a\udd4d\u4a61\ud84f\uddfb\ud9a4\udc15\0121=java.lang.String: |this=org.jsoup.nodes.Attributes: \udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udaf3\ude3a\uda8c\udcc4\ud97a\udd4d\u4a61\ud84f\uddfb\ud9a4\udc15\012",
        Z.run(T, 2, 15, 7, 1, "\udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udaf3\ude3a\uda8c\udcc4\ud97a\udd4d\u4a61\ud84f\uddfb\ud9a4\udc15", "\u28ee\u7ae8\u28ed\u8f42\u4381\u9df3\u7a77\u4ba7\u69e2\u46be\u7832\uc767\u6a45\u8955", "\ud8d5\ude13\ucc41\uda8e\udfe3\udb6a\udef0\ud804\udd85\ud8f0\ude5b\udb56\udd35\ud848\udf87\udb5c\udc2a\udb80\udf60\ud919\udde9\ud956\udfd1\ud8e9\uddf0\ud968\udc4b\ud895\udce5\udbb1\udf09\udbf7\udd1d\ud827\udf35\udb42\udd99\udbcb\udd65\ud8c0\udfea\ud85d\udd87\uda09\udd28\udba9\udc5d\udba3\ude5a\ud9c5\udde0\ud91c\udff7\ub846\udaaa\udf26\uda18\udfa1\udb26\ude40",
        40, 47125, -1126876556, 6642345743950904954L, 70572L, true, false, (char) 7512, (char) 19815,
        Double.longBitsToDouble(0x3fe27fb20113ab92L), Double.longBitsToDouble(0x3fddf29fee93d0ccL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \uda49\udf65\uda6f\udd30\ud827\ude78\u3447\0121=void |this=org.jsoup.nodes.Attributes: \uda49\udf65\uda6f\udd30\ud827\ude78\u3447\012",
        Z.run(T, 2, 15, 0, 0, "\uda49\udf65\uda6f\udd30\ud827\ude78\u3447\000", "\u5038", "\ud957\udd49\udbfe\ude1e\udb32\udfd8\ud9e7\ude78\udba2\udc0d\uab1f\uda84\udc88\uda41\ude9d\ud972\udc00\udbb4\ude9c\uda55\ude67\ud8bf\udd57\ud8e4\udeea\ud8db\udeaa\udb73\ude74\udb03\udd38\ud871\udc3f\ud852\udc4d\ud848\uddc6\udbce\uddc0\ud834\ude33\ud8ea\udcd3\ud840\udca5\udb45\udc32\ud861\ude2e",
        44, 29084, -714425416, -3829139894641614372L, 26877L, true, false, (char) 15852, (char) 15649,
        Double.longBitsToDouble(0x3faccd133e7992b0L), Double.longBitsToDouble(0x3fe846c5cb049154L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.jsoup.nodes.Attributes: \udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udad6\udf3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Attributes: \udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udad6\udf3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\012",
        Z.run(T, 2, 15, 10, 1, "\udb0f\udde2\uda4f\udce8\ud81f\udc9c\ud801\udc30\udad6\udf3a\udae3\udd6e\ud97a\udd61\u4a61\ud84f\uddfb\000", "\u4981\u7ae8\u28ed\u8f42\u0e81\u9df3\u7a77\u4ba7\u69e2\u46be\u7832\u0cc7\u6a45\u8955", "\ud8d5\ude13\ucc41\uda8e\udfe3\udb6a\udef0\ud804\udd85\ud8f0\ude5b\udb56\udd35\ud848\udf87\udb5c\udc2a\udb80\udf60\ud919\udcf2\ud956\udfd1\ud8c8\udfe4\ud968\udc4b\ud895\udce5\udbb1\udf09\udbf7\udd1d\ud827\udf35\udb42\udd99\ud85b\udced\ud8c1\udc4a\ud85d\udd87\uda09\udd289\udb63\udf70\ud9c5\udde0\ud90f\udd50\udad1\udf92\udb39\udc6e\000\000",
        34, 47125, -1881851276, 6642458070230597242L, 70572L, true, false, (char) 7512, (char) 59194,
        Double.longBitsToDouble(0x3fe27fb00113ab92L), Double.longBitsToDouble(0x3fddf29fee93d0ccL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.util.Collections$EmptyIterator:@? |this=org.jsoup.nodes.Attributes:\0121=org.jsoup.nodes.Attributes$Dataset:{} |this=org.jsoup.nodes.Attributes:\012",
        Z.run(T, 2, 14, 5, 12, "\uda49\udfd9\ud83b\udd36\ud827\ude78\ud834\udec0", "\ub5a9\u86bc\u787b\ub7fe\u1e25\u810c\u4981\u5784\uaa26\u99e1\ua547\u9df3\u8f96\u4b83\u9e33\u0d9d\u7832\u5d7d\u6a45\u8955\u130e\u0321\u4457\u1992\u099c\u1655\u4daa\ua701\ua051\u5d05\u612b\u1926\u72ab\u4257\u2f6c\u3ca7\u9ae8\u9d79\u2ee0\u13d4", "\ud804\udeb7\udaeb\udff8\uda0a\udc6c\ud803\udc4b\udb07\uddd4\ud9c5\udde0\ud91c\udff7\ud952\udcd8\ud950\udf96\uda18\udfa1\udae0\ude3d\udaad\ude44\ud889\udde7\ud944\uddad\udacf\ude40\ud81b\udd70\ud9b4\ude84\udb11\udd92\ud8c8\udc01\ud827\udd8b\ud8b7\uddfe\ud8d8\ude4f\ud971\udee0\ud8ed\udd55\uda2c\udf8c\udbd9\udc7a\udbd9\udcd5\ud938\uded2\udbbf\udfbd\ud8b2\udd64\ub71b\udb90\udf46",
        25, 5250, 729915820, -3402981638918396016L, 60000L, false, false, (char) 31279, (char) 63748,
        Double.longBitsToDouble(0x3fe9ec4ec0276dcbL), Double.longBitsToDouble(0x3fe104c21c2f67daL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Attributes|removeIgnoreCase|java.lang.String|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|addAll|org.jsoup.nodes.Attributes|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|asList||new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|clone||new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|dataKey|java.lang.String|static",
    "M|org.jsoup.nodes.Attributes|dataset||new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|equals|java.lang.Object|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|get|java.lang.String|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|getIgnoreCase|java.lang.String|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|hasKey|java.lang.String|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|hasKeyIgnoreCase|java.lang.String|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|hashCode||new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|html||new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|html|java.lang.Appendable,org.jsoup.nodes.Document$OutputSettings|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|iterator||new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|put|java.lang.String,boolean|new:org.jsoup.nodes.Attributes:",
    "M|org.jsoup.nodes.Attributes|removeIgnoreCase|java.lang.String|new:org.jsoup.nodes.Attributes:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
