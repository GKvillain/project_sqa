package org.jsoup.safety;
import org.junit.Test;
import static org.junit.Assert.*;
public class Whitelist_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 12, 12, 4, "\ud923\ude03", "\u6f4e*", "\udb71\udea7\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud903\uddac\udbd6\udf22\uda7e\udd91\uda53\udd14\udb8e\udced\ud8b0\udc82\udaaf\udf00\ud921\udd80",
        49, 24790, -351042946, 3097970235878392718L, -39428L, true, true, (char) 20585, (char) 18574,
        Double.longBitsToDouble(0x3fdc9bce9923f034L), Double.longBitsToDouble(0x3fb276035b0bfac8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 12, 12, 9, "\udbc7\uddf5", "\u00f4\000", "\udb45\udd82",
        -5, -932, 2424832, 1448624700067450410L, 61626L, true, true, (char) 20673, (char) 39717,
        Double.longBitsToDouble(0x3fddd55af18f6bf6L), Double.longBitsToDouble(0x3fe00000027ef7cbL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 10, 1, 4, "\ud9af\ude34", "\uba77", "\ud968\ude54\ud99e\uddc1\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud903\uddac\udbd6\udf22\uda7e\udd33\uda53\udd26",
        27, 258, -1394184495, -5333553626804090169L, -67870L, false, true, (char) 42796, (char) 46521,
        Double.longBitsToDouble(0x3feb25d35bc9c1cfL), Double.longBitsToDouble(0x3fbb8efeec2f0840L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 9, 14, 4, "\ud923\ude03", "\u6f4e*", "\udb71\udf3f\ud97c\uddd7\ud907\udcd3\uda72\udff2\uda91\udf19\udbb7\udc11\uda7e\udd91\udb31\udee2\u97e3\ud9b7\udfc0\udaa1\udf94\udb64\udcdd",
        49, 24790, -351044738, -2810752475231698034L, -86440L, true, true, (char) 17905, (char) 21676,
        Double.longBitsToDouble(0x3fb276035b0bfac8L), Double.longBitsToDouble(0x3fdcb64a1b6c017cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 12, 0, 7, "\ud9b8\udf8d", "\u25d2\u1962", "\ud8fb\ude5d",
        56, 94192, -1037746878, 1448624700067450410L, 84898L, true, true, (char) 64213, (char) 39717,
        Double.longBitsToDouble(0x3fdf355af58f6bf6L), Double.longBitsToDouble(0x3fdfc2023a4ce448L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 6, 1, 0, "\ud923\ude03\ud923\udec2\ud8ce\ude1d\ud801\udc7b", "\u1d48\u3017\ua9c4\u65f9\u430f\u107a\u1a2b\u0c19\u41ad\uc918\u62f1\ubf81\u0223\u87c5\ub8ec\u61b1\u6548\u5fb8\u2355\u59ae\u92e0\u99cc\uacfc\u1ffd\u4538\u0b39\u900d\u81ac\u0f13\u7915", "\ud850\udce1\ud937\udde3\uda45\udd9e\ud809\udd11\udb0c\udc6a\ud853\ude88\udbe5\uddd7\ud90a\uddb1\ud9ee\udf79\ud85c\udc23\ud931\udd19\ud9e8\ude01\ud81e\udfbf\ud962\udce9\ud8e1\udefa\udae9\udc6d\ud962\udc38\ud963\udceb\uda65\ude1c\ud87e\ude9e\ud8a4\udca7\uda5a\ude30\ud895\udc36\udba0\uddd9\ud9b5\udfd5\ud8ca\udd97\udb50\udd37\ud8b6\uddad\ud928\uddbe\udb7b\udec6\udaf5\udefd\ud936\udd5f\ud964\udf7a\uda1d\udcd0",
        -1, 98433, -1438636865, -1779764898584169043L, -2165L, false, true, (char) 44880, (char) 40828,
        Double.longBitsToDouble(0x3fc4ae4ee45b862cL), Double.longBitsToDouble(0x3fe0505415ee926eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a1=[Ljava.lang.String;:[[\u4f17\ua9c4\uae8c\u73f2\u3050\u1a2b\u0c19\u41ad\uafb5\u7bb8\ubf81\u0223\u8afe\ua745\u61b1\u8678\u9ca5\u9eaa\u235a\uc2fd\ua7b9\u9b99\u7996\ub732\uabdd]] |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 1, 1, 13, "\ud997\udd3d\udbb1\udc32\ud9d7\udd3f\ud933\udd0b\ud9a0\uddd8", "\u4f17\ua9c4\uae8c\u73f2\u3050\u1a2b\u0c19\u41ad\uafb5\u7bb8\ubf81\u0223\u8afe\ua745\u61b1\u8678\u9ca5\u9eaa\u235a\uc2fd\ua7b9\u9b99\u7996\ub732\uabdd", "\ud877\udf97\udb63\udcc6\udacd\udf5a\ud8fd\udf83\udab4\udcc2\ud8f1\udd04\ud818\udcf6\ud976\udec1\udad6\udce7\uda7a\udd8f\ud813\udc28\ud960\udf58\ud8f8\udca8",
        25, 14819, 2028645630, -6315737193644233853L, -18700L, true, false, (char) 12372, (char) 37968,
        Double.longBitsToDouble(0x3fd41e59cbef674eL), Double.longBitsToDouble(0x3fea35daa44a05f3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 10, 4, "\ud9aa\udde4", "\ud745\ud7b5", "\udb71\udea7\ud98a\udcd7\udacd\uddf6\ud849\udfa3\u5035\udbec\ude3d\uda7e\udd91\uda53\udd14\uda10\ude27\udbad\udff8\udac0\ude90\ud9a3\uddc0\ud832\udd6e\ud8be\ude2a\ud92a\udd42\uda5f\ude0c\udb67\udc28\ud8df\ude41",
        18, 87305, -519564178, -4834218904998213175L, 72215L, false, false, (char) 6619, (char) 41235,
        Double.longBitsToDouble(0x3fe42da37d8f167bL), Double.longBitsToDouble(0x3feac56cfe74351cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 13, 12, 4, "\ud923\ude03", "\u6f4e\u9861", "\udb71\udea7\ud98a\udcd7\ud972\udf85\ud882\udf6a\ud8c6\udd00\ud9da\udc45\uda7e\udd91\uda53\udd14\ud969\udfbc\ud8b0\udc82\udaaf\udf00\ud921\udd80",
        49, 24790, -1911324034, 3097970253058261902L, -39428L, true, true, (char) 20585, (char) 18574,
        Double.longBitsToDouble(0x3fdc9bce9923f034L), Double.longBitsToDouble(0x3fb276035b0bfac8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 14, 12, 4, "\ud923\ude03\ud961\udee1\ud8a0\udd8a\uda60\udce9\udb83\udc2c\udba8\udc26", "\ua9c4\u65f9\u73f2\u61a6\u1a2b", "\udb8e\udd18",
        9, 25831, -1242246214, -1647320451528548954L, 32537L, true, true, (char) 18411, (char) 52687,
        Double.longBitsToDouble(0x3fef8e0e7c0e2eecL), Double.longBitsToDouble(0x3fec2f0b29c9bce9L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a2=[Ljava.lang.String;:[[\udb71\udea7\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud903\uddac\udbd6\udf22\uda7e\udd91\ud95a\uddd7\udb8e\udced\ud8b0\udc82\udaaf\udf00\ud921\udd80\ud832\udd6e]] |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 3, 12, 4, "\ud923\ude03", "\u296b*", "\udb71\udea7\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud903\uddac\udbd6\udf22\uda7e\udd91\ud95a\uddd7\udb8e\udced\ud8b0\udc82\udaaf\udf00\ud921\udd80\ud832\udd6e",
        25, 32054, -163510001, 1403990562795178546L, -80489L, false, false, (char) 62735, (char) 56651,
        Double.longBitsToDouble(0x3fdabd2fbd90c364L), Double.longBitsToDouble(0x3feb0bd5f2974a75L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 4, "\udb3a\ude6e\ud961\udee1\ud8ce\ude1d\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\u2818\uaa7f\uc918\u62f1\ubf81\u984d\u9c9c\u08b1\u6150\u98d6\ud30e\u4de2\u59ae\u92e0\ua7b9\u7801\u206d\u4538\u0b39\u0be5\u5097\u8bb1\u5575\u45a3\u99cd\u3758\u9651\u22c6\u17ee\ub909\u51a5\u2d5b\ub8f9\u4c4c", "\uda62\udeef\udad3\udcfa\ud978\ude99\udb87\udf31\ud8b5\udd09\ud85a\udde6\ud920\udd76\ud8af\udf4c\ud8aa\udf0f\udb34\udd3f\udad3\udca0\udb43\udefb\uda00\udf37\ud96d\udc8d\udbdb\udec7\udbd9\udc2d\udbf7\ude89\ud92e\udc65\ud8ab\ude32\ud986\uddbf\udb30\ude44\udb7c\udc66",
        24, 18002, 1037930634, 362224385950077353L, 65826L, false, false, (char) 41969, (char) 38708,
        Double.longBitsToDouble(0x3fb1ceb3a3564eb0L), Double.longBitsToDouble(0x3faa6a55bdc74570L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a0=[Ljava.lang.String;:[[\ud831\udf70]] |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 4, 12, 4, "\ud831\udf70", "\u783e*", "\udb71\udea7\ud985\ude90\u16f1\udb44\udd9c\ud903\udda5\udbd6\udf22\uda7e\udd91\uda53\udd14\udb8e\udced\ud8b0\udc82\udbab\udcff\ud90c\udd5d",
        49, 13350, -1288649850, 3097969923251749774L, 86268L, true, true, (char) 34921, (char) 36112,
        Double.longBitsToDouble(0x3fd1c3240923d9a2L), Double.longBitsToDouble(0x3fb276035b0bfac8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 6, 7, "\udb81\udf59", "\u817d\ubcbe\u9ade\u1006\ube6d\ua9c4\u65f9\u73f2\u9c50", "\udb34\ude05",
        46, 2394, -350727692, -3820343461368591626L, -67870L, false, true, (char) 61067, (char) 21662,
        Double.longBitsToDouble(0x3feb22698bc9c1f5L), Double.longBitsToDouble(0x3feb33f97d3bf191L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 5, 13, 4, "\ud923\ude03", "\u6f4e*", "\udb71\udea7\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud903\uddac\udbd6\udf22\uda7e\udd91\uda53\udd14\udb8e\udced\ud8b0\udc82\udaaf\udf00\ud84a\udf4b",
        56, 20476, -349180275, 3097970235878392718L, -94770L, true, true, (char) 18098, (char) 21676,
        Double.longBitsToDouble(0x3fb276035b0bfac8L), Double.longBitsToDouble(0x3fd3d84c9b950ae0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 12, 12, 13, "\udb32\udf70", "\u8119\u566a\u03c8\uab24\u0c21\u464b\u6796\u609a\uac0d\u6bed\u0c19\u41ad\uc918\ub45f", "\udb93\udc88\ud9c8\udcb8\udb3c\udec5\ud9d0\udeb3\udb64\udf5f\ud8df\ude41\ud90a\udc45\ud97d\udca4\uda34\ude11\udb70\udf59\udb74\udd51\uc897\ud9e3\ude82\ud8a0\ude2a\udb8d\ude20\udb84\uded9\udacc\ude62\uda47\udec5\udb53\ude6a\ud8bf\ude09\uda5d\udd89\uda53\ude94\u1e09\udae7\udfb4\ud8be\udc2c",
        47, 3409, 474132992, -3287221787457070235L, -83582L, true, false, (char) 46243, (char) 31263,
        Double.longBitsToDouble(0x3fa3d39d8a6d4260L), Double.longBitsToDouble(0x3fce81019eba7908L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 11, 13, 5, "\ud923\ude03", "\u6f4e\uc529", "\udb71\udea7\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud903\uddac\udbd6\udf22\uc045\udbd9\udd1b\udb8e\udced\ud8b0\udc82\udaaf\udf00\ud921\udd80",
        49, 24790, -351042946, 3097970235878392718L, -39428L, true, true, (char) 20585, (char) 18574,
        Double.longBitsToDouble(0x3fdc9bce9923f034L), Double.longBitsToDouble(0x3fb276035b0bfac8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 12, 5, "\ud91c\udd03", "\u6f4e*", "\udb71\udea7\ud98a\udcd7\udacd\uddf6\ud923\ude8c\udb72\udc1d\udafc\udc78\udb96\udde7\uda53\udd14\udb8e\udced\ud8b0\udc82\udaaf\ude74\ud921\udd80",
        -5, 86285, -351059107, 3097970235878392718L, 77133L, true, true, (char) 18098, (char) 21676,
        Double.longBitsToDouble(0x3fb276035b0bfac8L), Double.longBitsToDouble(0x3fd1b224a7be6dacL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a0=[Ljava.lang.String;:[[\ud923\ude03]] |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 4, 12, 4, "\ud923\ude03", "\u6f4e*", "\udb71\udea7\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud903\uddac\ud910\udfe0\udbc2\udf2d\uda12\udca1\udb8e\udced\ud8b0\udc82\udaaf\udf00\ud921\udd80",
        49, 24790, -351042946, 3097970235878392718L, -39428L, true, true, (char) 20585, (char) 18574,
        Double.longBitsToDouble(0x3fdc9bce9923f034L), Double.longBitsToDouble(0x3fb276035b0bfac8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 12, 4, "\ud923\ude03", "", "\udba8\udc26\ub2b7\000\000",
        -5, 11440, 1739901, 6080015809338477781L, -83423L, false, false, (char) 18981, (char) 48861,
        Double.longBitsToDouble(0x3fc8f6bf6a9ba400L), Double.longBitsToDouble(0x3fbfbdc01c200098L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 6, "\ud808\uddf7\ud81a\udcd2", "*\u3fcb\ucb4d\ud2f7\ua9c4\u65f9", "\ud95e\ude26\uda25\udc63\ud82d\udf63\udab6\ude48\ud8d5\uddc5\udaaf\udf00\ud921\udd80\ud832\udd6e",
        25, 35382, 721349060, 741620102141266523L, -60965L, false, false, (char) 28744, (char) 58948,
        Double.longBitsToDouble(0x3feb0bface0fc4fbL), Double.longBitsToDouble(0x3fcc15288f80f9ecL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 7, 9, 10, "\u09ef\udb27\udece\ud906\udc1d\ud963\udc3b\ud8de\ude0d\ud970\ude76\ud947\udd4d\ud99e\uddc1\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud903\uddac\udbd6\udf22\udb90\udd3c\udb19\udc28\ud8df\ude12\ud9c2\udc9b\ud92b\udcb0\ud921\udcdf\ud80f\udf71\ud8be\udde1\ud92a\udd42\uda5f\ude0c\ud98a\ude82\uda37\udca2\udaf0\udc1e\ud90b\udd1f\ud978\udeb9\uda81\udf0a\ud8cf\uded9\ud8f4\udef0\ud9ab\uddac\ud822\ude8d\ud852\udfbd\udacc\ude25\ud846\udd36\ud99e\udefd\uda62\uddb9\ud8d7\udfc3\udb3a\ude53\ud8dc\udf5d\udbce\udc27\udb82\udc0c\uda45\udd6a\udada\udfd9\udaaf\uddfe\ud974\uddd6\ud906\uded0\uda0c\udc52\udba2\udf18", "\ucd92\ucf89", "\udaf9\udda5",
        39, 79591, -1981800901, -1639060741859912764L, 17644L, false, true, (char) 57336, (char) 45987,
        Double.longBitsToDouble(0x3fe95120609482a1L), Double.longBitsToDouble(0x3fce97d9eefc9df0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 11, 8, 4, "\u433c\u7314\udbf9\udeb6\ud963\udc36\uda36\udddc\udbb8\udd46\ubd23\ud99e\uddc1\ud9ac\ude90\udacd\uddf6\udb44\udd9c\ud903\uddac\udbd6\udf22\uda7e\udd33\uda53\udd26\ud892\udcea\uda51\ude97\ud910\uddeb", "\ub8a3\u61b1\u8678\u037b\u37d9\u59ae\u92e0", "\udafa\udf96\ud88d\udf8d\ud8ed\uddfe",
        29, 83064, 200892944, 7606928238669930805L, -54221L, false, true, (char) 49522, (char) 20338,
        Double.longBitsToDouble(0x3fb600ce88008098L), Double.longBitsToDouble(0x3fdbef8dbc879544L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |a1=[Ljava.lang.String;:[[\uba77\ud60b\u80eb\u8d61\u9252\u7ecd\uad60\u9e06\u9c50\u1a2b\u0bbb\ua4bf\ucc4e\u19a4\ua1d1\u8997\uabc7\u09e2\u61b9\u5407\u7170\ud705\u6d73\u6830\ua7b9\u0f0e\uca67\u3e53\u26a6\u8fd2\u8bec\u2b12\u594b]] |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 7, 1, 4, "\udad3\udfd8", "\uba77\ud60b\u80eb\u8d61\u9252\u7ecd\uad60\u9e06\u9c50\u1a2b\u0bbb\ua4bf\ucc4e\u19a4\ua1d1\u8997\uabc7\u09e2\u61b9\u5407\u7170\ud705\u6d73\u6830\ua7b9\u0f0e\uca67\u3e53\u26a6\u8fd2\u8bec\u2b12\u594b", "\ud82d\ude4d\ud961\udf25\udbdd\ude4e\ud95e\udd38\udbad\udce0\udbab\udc76\udb6d\udd19\uda0c\udc2b\u7601\ud96c\udff4\ud905\ude53\ud96d\udcb8\udb70\udd06\uda4f\udf45\udb29\udc99\ud98d\ude12\ud942\udc71\udb37\udcc0\ud800\udc7a\udb4d\udddd\udb9d\udc57\udab0\uddd9\ud9bb\udda3\udaac\udd75\ud9ed\ude38\ud921\ude32\udb0d\udd9e\ud98e\udf0a\uda83\udfc7\ud915\udc50\udb8c\udf47\ud986\udc9e\ud92f\udeb5\udb98\udc82\uda53\udf85\ud8b9\udc9b\ud89f\udc37\udbcb\udd12\udbbf\udec0\ud948\udd9c\ud80d\udd0a\ud82b\ude50\udab5\udcfb",
        25, 28179, 2003699310, 6204181129966795545L, 13334L, false, true, (char) 39892, (char) 45861,
        Double.longBitsToDouble(0x3fafc2c54a434780L), Double.longBitsToDouble(0x3fe6f002bcadba88L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 8, 11, "\ud91d\uddfe\ud961\ude9f\ud95a\udcc3\udbe8\udca5\udaae\udeb1\ud951\udf14\ud850\ude54\udb7b\udd09", "\u0ee5\uc23a\u3f7d\uc23c\u31d1\u50f9\u814a\ua1e4\uba9e\u6557", "\ud9f4\udd37\ud9b6\udd2f\udba1\ude1c\udb89\udf2d\ud88b\udc98\udb9c\udffc\udbc5\udfd7",
        -2, 22025, 2136551172, -8673638898056301109L, 65740L, false, true, (char) 8336, (char) 28380,
        Double.longBitsToDouble(0x3fe50b853a38ac5bL), Double.longBitsToDouble(0x3fe1adff2bccaa03L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a1=[Ljava.lang.String;:[[\uc62a\u9a89]] |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 1, 11, 4, "\ud923\ude03", "\uc62a\u9a89", "\udb71\udf3f\udad4\ude0d\ud907\udcb0\uda72\udff2\uda91\udf19\udbb7\udc11\ud88d\udfba\udb47\uddec\udbd2\udc6a\udbfd\ude65\ud9fd\udcaa",
        7, 50251, -137637210, -1507726021984636028L, 50107L, false, true, (char) 60472, (char) 8451,
        Double.longBitsToDouble(0x3fb7c40efb685718L), Double.longBitsToDouble(0x3fc360d931276034L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 7, "\ud89f\ude3a", "\u25d2\u1962", "\ud8fb\ude5d",
        56, 94192, -1037746878, 1448624700067450410L, 84898L, true, true, (char) 64213, (char) 39717,
        Double.longBitsToDouble(0x3fba8369d6e1a320L), Double.longBitsToDouble(0x3fdfc2023a4ce448L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a2=[Ljava.lang.String;:[[\udaf5\udef9\uda1b\uddf5\ud814\ude29\udba1\udf7e\ud912\udeff\ud9b2\uded5\udac0\udebe\ud8b7\ude3c\udb26\udf5a\udbb9\udeff\udb50\udfaf\udb34\uddec\ud804\uddd0\ud9ed\ude17\udb0b\uded1\udb1e\udee2]] |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 3, 2, 10, "\udb5a\udcbf\udbf9\udd37\ud824\udd8d\ud964\udf59\uda64\uddd7\ud876\udd41\udab5\udf56\udac6\udf34\uda76\udc44\udacd\ude02\udb2b\ude98\udbc7\udf5f\udb27\udccc\udb5d\ude73\uda44\ude43", "\u9a9b\ucd14", "\udaf5\udef9\uda1b\uddf5\ud814\ude29\udba1\udf7e\ud912\udeff\ud9b2\uded5\udac0\udebe\ud8b7\ude3c\udb26\udf5a\udbb9\udeff\udb50\udfaf\udb34\uddec\ud804\uddd0\ud9ed\ude17\udb0b\uded1\udb1e\udee2",
        28, 17449, 1585586089, 2479316877775925892L, -8634L, true, false, (char) 17729, (char) 23994,
        Double.longBitsToDouble(0x3fde28a8905d0672L), Double.longBitsToDouble(0x3fe403229b2a1dd0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a1=[Ljava.lang.String;:[[\uce95\u506a\u4d05\u6afd\u8069\ua264\uc2e8\u2369\u3ec7\u3507\u4a91\u8a0b\u48de\u7d44\u471e\u5de5\ubb38\u0cfa\ub35d\ucb5c\u8d80\u661c\ua1f6\u6eb1\u8be7\u4f64\u2896\ua3d7\u801d\u46aa\ubc38\u339e\u1e98\ucce9\ub6ad]] |this=org.jsoup.safety.Whitelist:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 7, "\ud9b8\udf8d\ud961\udeae\ud95e\udfc5\uda9e\udf91\ud90f\udd12", "\uce95\u506a\u4d05\u6afd\u8069\ua264\uc2e8\u2369\u3ec7\u3507\u4a91\u8a0b\u48de\u7d44\u471e\u5de5\ubb38\u0cfa\ub35d\ucb5c\u8d80\u661c\ua1f6\u6eb1\u8be7\u4f64\u2896\ua3d7\u801d\u46aa\ubc38\u339e\u1e98\ucce9\ub6ad", "\udbc9\ude2e\ud981\uddc9\u3ad9\udbbc\udd9f\uda62\udfc5\udb29\udfe2\ud945\uddff\udbfa\ude2e\ud963\udf6b\ud85f\udf30\uda21\udfad\udbd2\udf68\ud95d\uded6\uda5b\udcbc",
        44, 53924, 967587291, 2191318197028275215L, 18584L, true, false, (char) 10802, (char) 54306,
        Double.longBitsToDouble(0x3fde434515c1bf1cL), Double.longBitsToDouble(0x3fe8ff84c00a0a34L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a1=[Ljava.lang.String;:[[\u4f17\uce35\u92e5\u73f2\u3050\u1a2b\u0c19\u41ad\uafb5\u7bb8\ubf81\u0223\u8afe\ua745\ua9b1\u8678\u9ca5\u9eaa\u235a\uc2fd\uc74e\u9b99\u50ff\ub701\uabdd]] |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |a1=[Ljava.lang.String;:[[\u4f17\uce35\u92e5\u73f2\u3050\u1a2b\u0c19\u41ad\uafb5\u7bb8\ubf81\u0223\u8afe\ua745\ua9b1\u8678\u9ca5\u9eaa\u235a\uc2fd\uc74e\u9b99\u50ff\ub701\uabdd]] |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 1, 1, 13, "\ud997\udd3d\udbb1\udc32\ud9d7\udd3f\ud933\udd0b\ud9a0\uddd8", "\u4f17\uce35\u92e5\u73f2\u3050\u1a2b\u0c19\u41ad\uafb5\u7bb8\ubf81\u0223\u8afe\ua745\ua9b1\u8678\u9ca5\u9eaa\u235a\uc2fd\uc74e\u9b99\u50ff\ub701\uabdd", "\ud877\udf97\udb63\udcc6\udacd\udf5a\ud8fd\udf83\udab4\udcc2\ud8f1\udd04\ud818\udcf6\ud976\udec1\udad6\udce7\uda7a\udd8f\ud813\udc28\ud960\udf58\ud8f8\udca8",
        25, 14819, 2028645630, -6315737193644233853L, -54284L, true, false, (char) 12372, (char) 37968,
        Double.longBitsToDouble(0x3fd41e59cbef674eL), Double.longBitsToDouble(0x3fea35d9f44a05f3L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 13, 13, 4, "\ud923\ude03\ud961\udee1\ud8a0\udd8a\uda60\udce9\udb83\udc2c\udba8\udc26", "\u0618\u666f\u73f2\u507c\ud5e2", "\udb8e\udd18",
        52, 3719, -1242246214, -1647320451528548954L, 32537L, true, true, (char) 18411, (char) 52687,
        Double.longBitsToDouble(0x3fef89f67c0e2eecL), Double.longBitsToDouble(0x3fec2f0b29c9dee9L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 3, 0, "\udae5\udf83\udb5d\udce4\ud80d\udcfe\ud965\udf6d\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\u1d9e\uaa7f\uc918\u62f1", "\uda4a\ude0a\udbeb\udddf\ud92a\udce1\ud831\ude36\udaff\udcf1\ud8e5\udc40",
        18, 87305, -519564178, -4834218904209684023L, 34071L, true, true, (char) 42230, (char) 33788,
        Double.longBitsToDouble(0x3fdd75209dba93daL), Double.longBitsToDouble(0x3fd22f837ca10e22L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 6, 4, "\ub239\ud83d\udc79\ud8d9\udccc\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\u2818\uaa7f\uc918\u62f1\ubf81\u22f9\u9c90\u08b1\u6150\u98d6\ud30e\u4de2\u00af\u345b\ua7b9\u7801\u206d\u4538\u0b39\u8f37\u5097\u8bb1\u5575\u45a3\u99cd\u3758\u9651\u22c6\u17ee\ub909\u51a5\u2d5b\ub8f9\u4c4c", "\uda62\udeef\udad3\udcfa\ud978\ude99\udb87\udf31\ud8b5\udd09\ud85a\udde6\ud920\udd76\ud8af\udf4c\ud8aa\udf0f\udb34\udd3f\ud8d9\udc24\ud919\udea4\ud8c0\udcc5\ud96d\udc8d\udbdb\udec7\udbd9\udc2d\udbf7\ude89\ud92e\udc65\ud8ab\ude32\ud986\uddbf\udb30\ude44\udb7c\udc66",
        24, 18002, 1037930634, 362224385950077353L, 65826L, false, false, (char) 41969, (char) 38708,
        Double.longBitsToDouble(0x3fb1ceb3a3564eb0L), Double.longBitsToDouble(0x3faa6a55bdc74570L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 6, 6, 4, "\udb3a\ude6e\udb88\ude75\ud858\udc1c\ud976\udd7c\ud9d9\udc3e\udba8\udc57\ud8cf\udd8f\udb5a\udff1", "\u25ba\u7fc7\u1a2b\u2818\uaa7f\uc918\u62f1\u9740\u984d\u9c9c\u08b1\u6150\u98d6\ud30e\u4de2\u59ae\u92e0\u6e8a\ua385\u206d\u4538\u0b39\u0be5\u5097\u8bb1\u5575\u45a3\u99cd\u3758\u9651\u22c6\u17ee\ub909\u51a5\u2d5b\ub8f9\u4c4c", "\uda62\udeef\udad3\udcfa\ud978\ude99\udb87\udf31\ud8b5\udd09\ud85a\udde6\ud920\ude30\ud8af\udf4c\ud9e9\udead\u1866\ud982\udd20\uda12\udd53\uda00\udf37\ud96d\udc8d\udbdb\udec7\udbd9\udc2d\udbf7\ude89\ud92e\udc65\ud8ab\ude32\ud986\uddbf\udb30\ude44\udb7c\udc66",
        55, 97657, 1037930634, 362224385950077353L, 65826L, false, false, (char) 41969, (char) 38708,
        Double.longBitsToDouble(0x3fb1ceb3a3564eb0L), Double.longBitsToDouble(0x3faa6a55cdfafb70L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.safety.Whitelist:@?\0121=java.lang.Boolean:false |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 9, 9, 12, "\ud89a\udd43\ud9c0\udc1c", "*\u3fcb\u0141\u64f9\ub52b", "\uda83\udc98\udbec\udec6\uda25\udc63\ud82d\udf63\udab6\ude48\ud8d5\uddc5",
        5, 80437, -378161206, 6002781983128736290L, 81134L, false, true, (char) 46678, (char) 31616,
        Double.longBitsToDouble(0x3fbb8ee03c2f0840L), Double.longBitsToDouble(0x3fc00b35f46d6cb4L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 2, 6, "\ud808\uddf7\ud81a\udcd2", "*\u3fcb\ucb4d\ud2f7\ua9c4\u65f9\ubacd\u402b\uc9ca\u724f\u684a", "\udaaf\udf00\ud921\udd80\ud832\udd6e\ud8be\ude2a\uda7e\udcac\uda8d\udc4c\ud8e9\udc29",
        2, 36308, 998291889, -638830126977554555L, -29061L, true, true, (char) 35514, (char) 51978,
        Double.longBitsToDouble(0x3fcc15288f80f9ecL), Double.longBitsToDouble(0x3fe7d1ac040d1195L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 2, 6, "\ud808\uddf7\ud81a\udcd2", "*\u3fcb\uaf4d\u04a1\u8849\uc606", "\ud9f3\uddf7\uda24\udfdc\ud82d\udf63\udab6\ude48\udad0\udca2\ud82b\uddc4\udb0e\udd36\ud85b\ude62\ud8be\ude1b",
        7, 9428, -1689599079, -5036349925431911850L, -94770L, true, true, (char) 58011, (char) 28908,
        Double.longBitsToDouble(0x3fd97acad6c2feb2L), Double.longBitsToDouble(0x3fe07e27dce0a944L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a1=[Ljava.lang.String;:[[\uca3c\u8470\ub502\u87c6\ua9c4\u65f9]] |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 1, 5, 6, "\ud808\uddf7\ud81a\udcd2", "\uca3c\u8470\ub502\u87c6\ua9c4\u65f9", "\u6920\uda25\udc0a\ud82d\udf63\ud82a\udd2e\u19d0\udbb4\udf0c\ud921\udcab\ud84f\udcc8",
        3, 35382, 721349060, 741620105055724635L, -60965L, false, false, (char) 28744, (char) 58948,
        Double.longBitsToDouble(0x3feb0bface0fc4fbL), Double.longBitsToDouble(0x3fcc15289b80f9ecL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a0=[Ljava.lang.String;:[[\ud808\uddf7\ud81a\udcd2\uda40\udf04\ud94f\udee3\udbc2\uddd3\udba8\udc6c\ud910\udd34\uda54\udf4c\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud9cc\ude90\ud95e\ude26\uda25\udc63\ud82d\udf63\udab6\ude48\ud8d5\uddc5\udaaf\udf00\ud921\udd80\ud832\udd6e\ud8be\ude2a\uda7e\udcac\uda8d\udc4c\udb85\udf2c\ud8df\ude41\udaef\udfb9\udab3\udd32\udb1e\ude9a\ub4ce\uda3d\udddf\udbb2\udc31\ud8d4\udd18\uda4d\udfe6\ud9c8\udcf2\uda88\udc8e\ud9d4\udd15\uda36\udf48\ud906\udd29\udaf5\udc1f\uda5e\udfd4]] |this=org.jsoup.safety.Whitelist:@?\0121=java.lang.Boolean:true |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 4, 9, 10, "\ud808\uddf7\ud81a\udcd2\uda40\udf04\ud94f\udee3\udbc2\uddd3\udba8\udc6c\ud910\udd34\uda54\udf4c\ud98a\udcd7\udacd\uddf6\udb44\udd9c\ud9cc\ude90\ud95e\ude26\uda25\udc63\ud82d\udf63\udab6\ude48\ud8d5\uddc5\udaaf\udf00\ud921\udd80\ud832\udd6e\ud8be\ude2a\uda7e\udcac\uda8d\udc4c\udb85\udf2c\ud8df\ude41\udaef\udfb9\udab3\udd32\udb1e\ude9a\ub4ce\uda3d\udddf\udbb2\udc31\ud8d4\udd18\uda4d\udfe6\ud9c8\udcf2\uda88\udc8e\ud9d4\udd15\uda36\udf48\ud906\udd29\udaf5\udc1f\uda5e\udfd4", "\u393d\u3a89\u358c\u3411\u4f55\u6b7a\u4593\u8135\ua4a5\uaba8", "\ud87b\udf4f\ud8a0\uddd4\ud82f\udda9\udb5a\udcc1\udb4b\ude4a\ud8cb\udddd\ud895\udcf0\ud831\udf47\udab6\udc52\ud9dc\udc7b\udacc\uddbc",
        25, 11256, 823201335, 9047732719348051695L, -97874L, true, false, (char) 45859, (char) 47190,
        Double.longBitsToDouble(0x3fc286c73a5c0f8cL), Double.longBitsToDouble(0x3fb6394b4183f788L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: |this=org.jsoup.safety.Whitelist:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 1, 2, "\000", "", "",
        58, 15913, -110718427, -8875819938528848060L, 66912L, false, false, (char) 24791, (char) 61536,
        Double.longBitsToDouble(0x3fd9f0a66f74f786L), Double.longBitsToDouble(0x3febe878e951cf57L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 11, 11, 4, "\udad3\udfd8", "\uba77\u3a8e\u8643\u8d61\u9252\u7ecd\uad60\u9e06\u9c50\u1a2b\u0bbb\ua4bf\u988a\u8272\ua1d1\u8997\uabc7\u09e2\u61b9\u5407\ud2d6\u6592\u6d73\u6830\ua7b9\u0f0e\uca67\u3e53\u26a6\u8fd2\u8bec\u2b12\u594b", "\ud82d\ude4d\ud961\udf25\udbdd\ude4e\ud95e\udd38\udbad\udce0\udbab\udc76\udb6d\udd19\uda0c\udc2b\u7601\ud96c\udff4\ud905\ude53\ud96d\udcb8\udb70\udd06\ud851\udf25\ud9df\ude92\ud98d\ude12\ud942\udc71\udb37\udcc0\ud800\udc7a\udb4d\udddd\udb9d\udc57\udab0\uddd9\ud9bb\udda3\udaac\udd75\ud9ed\ude38\ud921\ude32\udb0d\udd9e\ud98e\udf0a\uda73\udfbf\ud915\udc50\udb8c\udf47\ud986\udc9e\ud918\uddb5\udb98\udc82\uda53\udf85\ud8b9\udc9b\ud89f\udc37\udbcb\udd12\udbbf\udec0\ud948\udd9c\ud8eb\udcbe\ud82b\ude38\udab5\udcfb",
        25, 28179, 2003699310, 6204181129966795545L, -93891L, false, false, (char) 64608, (char) 45861,
        Double.longBitsToDouble(0x3fafc2c54a434780L), Double.longBitsToDouble(0x3fe6f002bcadba88L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 7, 7, 4, "\udad3\udfd8", "\uba77\ud60b\u80eb\u8d61\u02fc\ub7f8\uad60\u9e06\u9c50\u1a2b\u0bbb\ua4bf\ucc4e\u19a4\ua1d1\u8997\uabc7\u09e2\u61b9\u5407\u7170\ud705\u6d73\u6830\ua7b9\u0f0e\uca67\u3e53\u26a6\u8fd2\u8bec\u2b12\u594b", "\ud82d\ude4d\ud961\udf25\udbdd\ude4e\ud95e\udd38\udbad\udce0\udbab\udc76\udb6d\udd19\uda0c\udc2b\u7601\ud96c\udff4\ud905\ude53\ud96d\udcb8\udb70\udd06\uda4f\udf45\udb29\udc99\ud98d\ude12\ud942\udc71\udb37\udcc0\ud800\udc7a\udb4d\udddd\udb9d\udc57\udac6\udddd\ud9bb\udda3\udaac\udd75\ud9ed\ude38\ud921\ude32\udb0d\udd9e\ud98e\udf0a\uda83\udfc7\ud915\udc50\udb8c\udf47\ud986\udc9e\ud92f\udeb5\udb98\udc82\uda53\udf85\ud8b9\udc9b\ud89f\udc37\udbcb\udd12\udbbf\udec0\ud948\udd9c\ud80d\udd0a\ud82b\ude50\udab5\udcfb",
        25, 28179, 2003699310, 6204181129966795545L, 13334L, false, true, (char) 39892, (char) 45861,
        Double.longBitsToDouble(0x3fafc2c54a434780L), Double.longBitsToDouble(0x3fe6f002bcadba88L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a2=[Ljava.lang.String;:[[\udb71\udf3f\udad4\ude0d\ud907\udcb0\ud999\udda9\uda91\udf19\uda56\ude16\ud88d\udfba\udb47\uddec\udbd2\udc6a\udbfd\ude65\ud9fd\udcaa]] |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |a2=[Ljava.lang.String;:[[\udb71\udf3f\udad4\ude0d\ud907\udcb0\ud999\udda9\uda91\udf19\uda56\ude16\ud88d\udfba\udb47\uddec\udbd2\udc6a\udbfd\ude65\ud9fd\udcaa]] |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 3, 3, 14, "\ud8fd\udf86", "\u59d7\u9a89", "\udb71\udf3f\udad4\ude0d\ud907\udcb0\ud999\udda9\uda91\udf19\uda56\ude16\ud88d\udfba\udb47\uddec\udbd2\udc6a\udbfd\ude65\ud9fd\udcaa",
        7, 27075, -137637210, -1507726021984636028L, -80965L, true, false, (char) 7337, (char) 8451,
        Double.longBitsToDouble(0x3fe9bf428719d195L), Double.longBitsToDouble(0x3fecd8364a92be5aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |a0=[Ljava.lang.String;:[[\ud87b\udc29]] |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |a0=[Ljava.lang.String;:[[\ud87b\udc29]] |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 4, 4, 7, "\ud87b\udc29", "\u25d2\u8336", "\ud8fb\ude5d\uda02\ude8b\udacd\ude02\udb44\udd9c\ud903\uddac\udafb\udef8\ud809\ude3c\uda69\udffc\udb8e\udced\udad7\udd76\u2796\ud9a1\udfcf\udb6d\udcc0\u8cb6",
        29, 35373, 2123539896, -3020046997425296251L, -2174L, false, true, (char) 22768, (char) 39906,
        Double.longBitsToDouble(0x3fe42c6e7cf0ef78L), Double.longBitsToDouble(0x3fe0f17640817de6L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 10, 10, 13, "\ud89f\ude3a\udbde\udccb\udaa0\uddb8\ud93b\udeb8\uda26\uded8\udb41\udc42\ud8ee\ude81\ud8fb\ude5d\uda76\udc44\udb83\udcfc\udb44\udd9c\ud903\uddac\udbd6\udf22\uda16\udedd\uda69\udffc\udb8e\udced\ud8da\ude97\udbf0\udec1\u97df\ud9ad\udfe0\u1849\ud875\ude62\udb31\udc60\ud8e6\udcdd\ud8e5\ude3a\udae9\udc08\uda6e\udc5e\ud9fd\udf47", "\u2ccd\ud01a\u8d65\u4a83\u8492\ud5bf\u1722\u1e81\ua127\u50c9\ua32a\u4069\u9b1c", "\ud9cd\udc9a\ud975\udeb1\uda25\udf71\ud935\udc0d\ud959\udd9e\ud941\ude30\ud828\udd76\udbed\udfd2\udbb3\udcbb\ud9e6\udfe0\ud8d8\udc17",
        -4, 38967, -619606001, 5631800609477284704L, 60348L, true, false, (char) 14473, (char) 23119,
        Double.longBitsToDouble(0x3fda4dd332f0c5c6L), Double.longBitsToDouble(0x3fab637d6d267870L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 2, 10, "\udb5a\udcbf\udbf9\udd37\ud824\udd8d\ud964\udf59\uda64\uddd7\ud876\udd41\udab5\udf56\udac6\udf34\uda76\udc44\udacd\ude02\udb2b\ude98\udbc7\udf5f\udb27\udccc\udb5d\ude73\uda44\ude43", "\u9a9b\ucd14", "\udaf5\udef9\uda1b\uddf5\ud814\ude29\udba1\udf7e\ud912\udeff\ud9b2\uded5\udac0\udebe\ud8b7\ude3c\udb26\udf5a\udbb9\udeff\udb50\udfaf\udb34\uddec\ud804\uddd0\ud99c\udd1e\udb0b\uded1\ud9c7\udcb6",
        1, 12943, 477388201, 2479316877775925892L, -8634L, true, false, (char) 17729, (char) 24131,
        Double.longBitsToDouble(0x3fde28a8905d0672L), Double.longBitsToDouble(0x3fe403229b2a1dd0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\u2818\uaa7f\uc918\u62f1\ubf81\u22f9\u9c90\u08b1\u1050\u98d6\ud30e\u4de2\u00af\u345b\ua7b9=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\u2818\uaa7f\uc918\u62f1\ubf81\u22f9\u9c90\u08b1\u1050\u98d6\ud30e\u4de2\u00af\u345b\ua7b9", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        16, 311, 1240288727, 1614335807892298701L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce05d5ccfL), Double.longBitsToDouble(0x3fdcf76f59ee0558L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.jsoup.safety.Whitelist:@?\0121=new org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 14, 14, 14, "\ud8f4\udd82", "\u59d7\u9a89\u0611\u8a5e\u3baf\ud541\u86f1\u3942\ua700\u7977\u162b\u4e6d\u14ae\u800e\ua009\u04e4\uc9e0\ub8ec\u5a5f\ua548\u5fb8\ua6ed\u4a78\ub442\u86f5\u0434\u6053\uaa3b\ub7c5\u3015\u62c7\u0d66", "\uda35\udfb9",
        35, 8805, -1919319783, 1059442274340680914L, 81964L, true, true, (char) 10228, (char) 24414,
        Double.longBitsToDouble(0x3fe90b643bdf8e8bL), Double.longBitsToDouble(0x3feaacea4b6d9e94L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \ud7cf\u92c0\u2138\u5105\ud3de\u6cff\u2a75\u8445=\"&#56183;&#56916;&#55571;&#57185;&#55785;&#57337;&#55529;&#56354;&#55612;&#57025;&#55977;&#56548;&#56053;&#57081;&#55835;&#56821;&#55316;&#56873;&#55571;&#56630;&#55592;&#57307;&#55730;&#57045;&#56000;&#57022;&#55479;&#56912;&#56102;&#57178;&#55472;&#56505;&#55616;&#57163;&#55509;&#56472;&... |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 5, "\udb4b\udc46\udbf9\udd37\ud824\udd8d", "\ud7cf\u92c0\u2138\u5105\ud3de\u6cff\u2a75\u8445", "\udb77\ude54\ud913\udf61\ud9e9\udff9\ud8e9\udc22\ud93c\udec1\udaa9\udce4\udaf5\udef9\uda1b\uddf5\ud814\ude29\ud913\udd36\ud928\udfdb\ud9b2\uded5\udac0\udebe\ud8b7\ude50\udb26\udf5a\ud8b0\udcb9\ud940\udf4b\ud8d5\udc98\ud941\uddcc",
        -2, 52980, 1665287901, -2747500763112029873L, -61190L, false, false, (char) 9274, (char) 49301,
        Double.longBitsToDouble(0x3fc3a87f2f230de4L), Double.longBitsToDouble(0x3fda229e2bc40336L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\u2818\u1cc4\u03c3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u6747\u91f2\u00af\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\u2818\u1cc4\u03a3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u6747\u91f2\u00af\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        16, 311, 1240288727, 1614335807892298701L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce1f75ccfL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\u2818\u1cc4\u03c3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u6747\u91f2\u6cf7\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\u2818\u1cc4\u03a3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u6747\u91f2\u6cf7\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        16, 423, 1475788639, 1614335807892298701L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce1f75ccfL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u0c9e\u56cb\u1cf8\u03c3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u4f93\u91f2\u00af\u345b\uac5b=\"&#55774;&#57342;&#55550;&#57179;&#55438;&#57223;&#56262;&#56766;&#55923;&#57164;&#55564;&#56882;&#56309;&#57134;&#55443;&#57138;&#55303;&#57088;\ubd6a&#55316;&#56615;&#55728;&#56997;&#55371;&#56412;&#55468;&#56605;&#55560;&#56382;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\ud981\udcc3\udb79\udd09\uda4f\udcbe", "\u25ba\u7fc7\u0c9e\u56cb\u1cf8\u03a3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u4f93\u91f2\u00af\u345b\uac5b", "\ud9de\udffe\ud8fe\udf5b\ud88e\udf87\udbc6\uddbe\uda73\udf4c\ud90c\ude32\udbf5\udf2e\ud893\udf32\ud807\udf00\ubd6a\ud814\udd27\ud9b0\udea5\ud84b\udc5c\ud8ac\udd1d\ud908\udc3e",
        7, 9556, 1691458766, 6961354091956568273L, -21648L, false, true, (char) 61127, (char) 44673,
        Double.longBitsToDouble(0x3fe2d0d9db5fdf75L), Double.longBitsToDouble(0x3fe20c21e9604ac7L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\u890d\u1b9e\u03c3\u64e0\u9499\u05e3\u1685\u08b1\u1050\u7af3\ub22b\u91f2\u00af\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud836\udc3f\udb67\ude25", "\u25ba\u7fc7\u1a2b\u890d\u1b9e\u03a3\u64e0\u9499\u05e3\u1685\u08b1\u1050\u7af3\ub22b\u91f2\u00af\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        39, 311, 1240288727, 1614335807892298701L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce1f75ccfL), Double.longBitsToDouble(0x3fe4cda64df702acL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\uafc4\ucc66\u03c3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u6747\ua18c\u00af\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\uafc4\ucc66\u03a3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u6747\ua18c\u00af\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        16, 311, 1240288727, 1614335807892298701L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce1f75ccfL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u2818\u1cc4\u03c3\u6389\uaf43\u0523\u1f33\u08b1=\"&#56165;&#57249;&#56201;&#57278;&#56079;&#57017;&#56261;&#57301;&#55318;&#57238;&#55860;&#57156;&#56180;&#56657;&#55614;&#56751;&#55992;&#56456;&#55702;&#57137;&#56262;&#56799;&#55923;&#57164;&#55564;&#56882;&#56309;&#57134;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\udb01\udc71\udba8\udc57\ud95e\udf54\udb71\udedf\ud9e1\udca0\udb3c\uddfe\ud857\udfa3", "\u2818\u1cc4\u03a3\u6389\uaf43\u0523\u1f3b\u08b1", "\udb65\udfa1\udb89\udfbe\udb0f\udeb9\udbc5\udfd5\ud816\udf96\uda34\udf44\udb74\udd51\ud93e\uddaf\udab8\udc88\ud996\udf31\udbc6\udddf\uda73\udf4c\ud90c\ude32\udbf5\udf2e",
        -4, 99888, 737346259, -8504620242472572709L, -43873L, true, true, (char) 3062, (char) 57506,
        Double.longBitsToDouble(0x3fd0edaf0b4146a8L), Double.longBitsToDouble(0x3fcc296446011564L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u5c32\u028c\ucf37\u1cd2\u03c2\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u6747\u91f2\u00af\u345b\uac5b=\"&#55614;&#56751;&#56270;&#57329;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb83\udf98", "\u25ba\u5c32\u028c\ucf37\u1cd2\u03a3\u6389\uaf43\u0523\u9c90\u08b1\u1050\u98d6\u6747\u91f2\u00af\u345b\uac5b", "\ud93e\uddaf\udbce\udff1\ud88e\udf87",
        16, 85887, 1240275083, 1614335807892298701L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed2e3aa1f75ccfL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u8110\ud50b\u1c30\u03c3\u6389\uaf43\u0523\u9c90\u07f1\u1050\u78d6\u6747\u91f2\u00af\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u8110\ud50b\u1c30\u03a3\u6389\uaf43\u0523\u9c90\u07f1\u1050\u78d6\u6747\u91f2\u00af\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        16, 311, 1240288727, 1614335807892320973L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce1f75ccfL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u03c3\u6389\uaf43\u0523\u9c90\u08b1=\"&#56165;&#57249;&#56201;&#57278;&#56079;&#57017;&#56261;&#57301;&#55320;&#57238;&#56176;&#57232;&#56180;&#56657;&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;&#56262;&#56766;&#55923;&#57164;&#55568;&#56655;&#56051;&#57133;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf\ud9e1\udca0\udab4\udd3a\ud857\udf45\ud9a1\udf59\udbd6\udf22", "\u03a3\u6389\uaf43\u0523\u9c90\u08b1", "\udb65\udfa1\udb89\udfbe\udb0f\udeb9\udbc5\udfd5\ud818\udf96\udb70\udf90\udb74\udd51\ud93e\uddaf\ud902\udfec\ud88e\udf87\udbc6\uddbe\uda73\udf4c\ud910\udd4f\udaf3\udf2d",
        19, 52372, 737346259, -1943581699279668427L, 93274L, true, true, (char) 35829, (char) 49011,
        Double.longBitsToDouble(0x3fe5db7d7f9aa4b9L), Double.longBitsToDouble(0x3fef2769cbdfdf2bL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u0fab\u548c\u734c\u030e\ua86d\u03c3\u6389\uaf43\u0577\u9c90\u4c93\u06bc\u5cdc\u5582\u91f2\u6cf7\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud8ff\udfaa\ud9bc\udc55\ud976\ude5b\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf", "\u0fab\u548c\u734c\u030e\ua86d\u03a3\u6389\uaf43\u0547\u9c90\u4c93\u06bc\u5cdc\u5582\u91f2\u6cf7\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        15, 58738, 1475788639, 1417515529939000269L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce1f75ccfL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\u2818\u01c6\u03c3\u0ddb\uaf43\u0523\u9c90\u4b9c\u9e10\u1ef5\u6747\u91f2\u6cf7\u345b\uac5b=\"&#56153;&#56626;&#55786;&#57106;&#55805;&#56457;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\ud9c4\udf3b\ud976\ude54\ud9a3\udcfe\udba8\udc58\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\u2818\u01c4\u03a3\u0ddb\uaf43\u0523\u9c90\u4b9c\u9e10\u1ef5\u6747\u91f2\u6cf7\u345b\uac5b", "\udb59\udd32\ud9ea\udf12\ud9fd\udc89",
        56, 41007, 1475788816, 5389193420180828089L, 97331L, false, false, (char) 8254, (char) 41117,
        Double.longBitsToDouble(0x3feea84fb9f7bd0cL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u01da\ub3d0\u1a2b\uafc4\ucc66\u03c2\u6389\u5c9a\ub66f\u2999\u08b1\u1050\u98d6\u6a87\ua18c\u00af\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\ud92f\udd2b\ud95e\udf0b\udb71\udedf", "\u01da\ub3d0\u1a2b\uafc4\ucc66\u03a3\u6389\u5c9a\ub66f\u2999\u08b1\u1050\u98d6\u6a87\ua18c\u00af\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        16, 311, 1240288727, 1614335807892298701L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce1f75ccfL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u7fc7\u1a2b\uafc4\ucc66\u03c3=\"&#55933;&#57339;&#55882;&#56830;&#56299;&#56799;&#55573;&#57313;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 9, "\udad2\udc0b\ud9c7\udf00\u742a\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf\ud9e1\udca0", "\u7fc7\u1a2b\uafc4\ucc66\u03a3", "\uda7d\udffb\uda4a\uddfe\udbeb\udddf\ud915\udfe1",
        3, 46654, -1164526639, -4481202147140324407L, -7963L, true, true, (char) 63403, (char) 6237,
        Double.longBitsToDouble(0x3fe5dbfacb875168L), Double.longBitsToDouble(0x3fe3bb4c2dd75209L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\u01d8\ucc80\u03c3\u39c2\ud05a\u0523\u9c90\u08b1\u1050\u98d6\u6e0d\ua18c\u00af\u8eba\u3568=\"&#55545;&#56890;&#55554;&#57324;\ud6c0&#56118;&#56720;&#55923;&#57164;&#55550;&#56733;&#56309;&#57134;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\ubfe6\ud91e\udedb\udaba\udf37\ud976\ude54\ud8ad\udc88\udbf0\udcb3\ud954\udd9f\ud89d\udef9", "\u25ba\u7fc7\u1a2b\u01d7\ucc80\u03a3\u39c2\ud05a\u0523\u9c90\u08b1\u1050\u98d6\u6e0d\ua18c\u00af\u8eba\u3568", "\ud8f9\ude3a\ud902\udfec\ud6c0\udb36\udd90\uda73\udf4c\ud8fe\udd9d\udbf5\udf2e",
        -4, 99888, 737346259, -1943581699596469451L, 81047L, true, true, (char) 1606, (char) 25328,
        Double.longBitsToDouble(0x3fe744aedbb5cf4cL), Double.longBitsToDouble(0x3fe92b3d55eceb68L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u01da\ub3d0\u1a2b\uafc4\ucc66\u03c3\uae2a\ua649\ua776\u2982\u08b1\u6f0b\u7274\u69e8\ua18c\u00af\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 7, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\ud92f\udd2b\ud95e\udf0b\udb71\udedf", "\u01da\ub3d0\u1a2b\uafc4\ucc66\u03a3\uae2a\ua648\ua776\u2982\u08b1\u6f0b\u7274\u69e8\ua18c\u00af\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        16, 311, 1240288727, 1614335807892298701L, 97331L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed2d1329f75ccfL), Double.longBitsToDouble(0x3fe087164df702acL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u7fc7\u95ac\ua385\ucc66\u03c3=\"&#55933;&#57339;&#55882;&#56830;&#56299;&#56799;&#55573;&#57313;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 9, "\udad2\udc0b\ud9c7\udf00\u742a\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udb71\udedf\ud9e1\udca0", "\u7fc7\u95ac\ua385\ucc66\u03a3", "\uda7d\udffb\uda4a\uddfe\udbeb\udddf\ud915\udfe1",
        3, 46654, -23675951, 1179355104760327709L, -7963L, true, true, (char) 63403, (char) 6237,
        Double.longBitsToDouble(0x3fe5dbfacb875168L), Double.longBitsToDouble(0x3fe3bb4c2dd75209L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\u01d8\ucc80\u03c2\u39c2\ud05a\u184d\u6c8c\u08a5\u1050\u98d6\u6e0d\ua18c\u00af\u8eba\u3568=\"&#55535;&#57169;&#55554;&#57324;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\ubfe6\ud91e\udedb\udaba\udf37\ud976\ude54\ud8ad\udc88\udbf0\udcb3\ud954\udd9f\ud89d\udef9", "\u25ba\u7fc7\u1a2b\u01d7\ucc80\u03a3\u39c2\ud05a\u184d\u6c8c\u08a5\u1050\u98d6\u6e0d\ua18c\u00af\u8eba\u3568", "\ud8ef\udf51\ud902\udfec",
        1, 67660, 1376328311, 5326937307837056477L, -46888L, true, false, (char) 11953, (char) 31126,
        Double.longBitsToDouble(0x3fdace39a74a5b38L), Double.longBitsToDouble(0x3fefbae67b370225L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u184e\u5ad0\ubd2a\uc298\u4f4f\u0ec9\u1279\u01da\u3c1c\u1a2b\uafc4\ucc66\u03c2\u1a50\u4a6c\u9da3=\"&#56124;&#57104;&#55923;&#56725;&#55481;&#57132;&#55547;&#57271;&#56015;&#56920;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 7, "\uc09a", "\u184e\u5ad0\ubd2a\uc298\u4f4f\u0ec9\u1279\u01da\u3c1c\u1a2b\uafc4\ucc66\u03a3\u1a50\u4a6c\u9da3", "\udb3c\udf10\uda73\udd95\ud8b9\udf2c\ud8fb\udfb7\udacf\ude58",
        -2, 21365, -1125554299, -568990905924386927L, -47077L, true, true, (char) 3324, (char) 64883,
        Double.longBitsToDouble(0x3fdddfc0779a2cceL), Double.longBitsToDouble(0x3fd43399d5a6ff98L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u184e\u5ad0\ubd2a\u5e72\u6017\u0ec9\u1279\u01da\u3c1c\u1a2b\uafc4\ucc66\u03c2\u1a50\u4a6c\u7ca3=\"&#56124;&#57104;&#55923;&#56725;&#55481;&#57132;&#55547;&#57271;&#56015;&#56920;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 7, "\uc09a", "\u184e\u5ad0\ubd2a\u5e72\u6017\u0ec9\u1279\u01da\u3c1c\u1a2b\uafc4\ucc66\u03a3\u1a50\u4a6c\u7ca3", "\udb3c\udf10\uda73\udd95\ud8b9\udf2c\ud8fb\udfb7\udacf\ude58",
        -2, 21365, -1125554299, -568990905924386927L, -47077L, true, true, (char) 3324, (char) 64883,
        Double.longBitsToDouble(0x3fdddfc0779a2cceL), Double.longBitsToDouble(0x3fd43399d5a6ff98L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 1, 12, 12, 2, "\ud923\ude03\ud961\udee1\ud8ce\ude1d\ud976\ude54\udbc2\uddd3\udba8\udc26\ud968\ude54\udb71\udea7\ud98a\udcd7\udacd\uddf6", "\u1a2b\u0c19\u41ad\uc918\u62f1\ubf81\u0223\u87ae", "\uda5f\ude0c\udb67\udc28\ud8df\udc95\udaef\udfb9\udbbf\udf51\udb1e\ude9a\udb70\udf90\udb74\udd51\ud922\ude36\ud902\udfca\udb22\udd10\ud9e2\ude24\ud8dd\uddde\udaa1\udd74\ud8e3\ude0c\u7d6a\ud974\udeab\ud973\udcea\ud9ee\udde4\ud99f\udee1\ud8b8\udc38\udba9\udc3e\ud9f1\uddeb\ud842\udef0\udadb\udda7\ud2eb\udb68\udd58\uda32\udc29\udb28\udc5c",
        15, 86654, -1970475152, -7908159099105606709L, 45993L, true, true, (char) 19960, (char) 33479,
        Double.longBitsToDouble(0x3fe709fc38cbd79aL), Double.longBitsToDouble(0x3fdddb76ef503e9eL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 11, 11, 6, "\ud808\uddf7\ud81a\udcd2", "*\u3fcb\ucb4d\ud2f7\ua9c4\u65f9\u3fb6\u3fe8\uc9ca\u724f\u684a", "\ud94c\ude9d\uda9f\ude58\ud83c\udc7d\ud8be\ude2a\udbc8\udd83\uda8c\udfbb\ud8e9\udc29",
        2, 36308, 998291889, -638830126977554555L, -29061L, true, true, (char) 35514, (char) 51966,
        Double.longBitsToDouble(0x3fcc15288f80f9ecL), Double.longBitsToDouble(0x3fe7d1ac040d1195L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u1cc4\u03c3\u6389\uaf43\u0523\u9c90=\"&#55345;&#56886;&#56165;&#57249;&#56201;&#57278;&#55763;&#56342;&#56261;&#57301;&#55320;&#57238;&#56176;&#57232;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\udb49\uddbf\ud91e\udedb\udaba\udf37\ud976\ude54\ud9d9\udc3e\udba8\udc57\ud95e\udf54\udafe\udfc9\udb8e\udc7d\ud9c9\udea9\ud892\uddd1\udb57\udce5", "\u1cc4\u03a3\u6389\uaf43\u0523\u9c90", "\ud831\ude36\udb65\udfa1\udb89\udfbe\ud9d3\udc16\udbc5\udfd5\ud818\udf96\udb70\udf90",
        56, 55697, 240776299, 5866045620019876743L, 80063L, true, true, (char) 12852, (char) 2325,
        Double.longBitsToDouble(0x3fe69bfe62be2bf3L), Double.longBitsToDouble(0x3fe9af2839acf67cL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u01da\ub3d0\u1a2b\uafc4\ucc66\u03c2\ua846\u09d7\ub66f\u2999\u08b1\u1050\u98d6\u6a87\ua18c\u00af\u345b\uac5b=\"&#55614;&#56751;&#55554;&#57324;&#55438;&#57223;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\uda93\udc82\udaa2\udd99\ud976\ude25\ud823\ude03\ud815\udf47\ud96c\udf47\udb71\udedf", "\u01da\ub3d0\u1a2b\uafc4\ucc66\u03a3\ua846\u09d7\ub66f\u2999\u08b1\u1050\u98d6\u6a87\ua18c\u00af\u345b\uac5b", "\ud93e\uddaf\ud902\udfec\ud88e\udf87",
        16, 311, 837635543, 1793936389429861177L, 97159L, false, false, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce0f75ccfL), Double.longBitsToDouble(0x3fd2d19c0bee040aL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u5ad0\ubd2a\uc298\u4f4f\u0ec9\u1279\u01da\u3c1c\u1a2b\uafc4\ucc66\u03c2\u1a50\u4a6c=\"&#56299;&#56820;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 7, "\uc09a\ud91e\udedb", "\u5ad0\ubd2a\uc298\u4f4f\u0ec9\u1279\u01da\u3c1c\u1a2b\uafc4\ucc66\u03a3\u1a50\u4a6c", "\udbeb\uddf4",
        -3, 38500, -1746797233, -5013707252698148252L, -88803L, true, true, (char) 18098, (char) 27820,
        Double.longBitsToDouble(0x3fbac8eff5dbfac8L), Double.longBitsToDouble(0x3fec3a8b43776985L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=org.jsoup.safety.Whitelist:@? |this=org.jsoup.safety.Whitelist:@?\0121=org.jsoup.nodes.Attributes: \u25ba\u7fc7\u1a2b\u2818\u1cc4\u03c3\u6389\uaf43\u0523\u2a7f\uc1d8\u1050\u98d6\u6747\u91f2\u6cf7\ub5d6\u03c3=\"&#55464;&#56981;&#56122;&#56929;&#56178;&#56979;\" |this=org.jsoup.safety.Whitelist:@?\012",
        Z.run(T, 2, 2, 7, 4, "\uc09a\ud91e\udedb\udaba\udf37\ud976\ude54\udbd3\udcba\udbfa\udeb0\ud95e\udf54\udb71\udedf", "\u25ba\u7fc7\u1a2b\u2818\u1cc4\u03a3\u6389\uaf43\u0523\u2a7f\uc1d8\u1050\u98d6\u6747\u91f2\u6cf7\ub5d6\u03a3", "\ud8a8\ude95\udb3a\ude61\udb72\ude93",
        43, 31180, -1004573345, 7105789574604742193L, 18903L, true, true, (char) 8253, (char) 38952,
        Double.longBitsToDouble(0x3fed296ce3f75ccfL), Double.longBitsToDouble(0x3fe887164df70224L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.safety.Whitelist|testValidProtocol|org.jsoup.nodes.Element,org.jsoup.nodes.Attribute,java.util.Set|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|addAttributes|java.lang.String,[Ljava.lang.String;|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|addEnforcedAttribute|java.lang.String,java.lang.String,java.lang.String|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|addProtocols|java.lang.String,java.lang.String,[Ljava.lang.String;|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|addTags|[Ljava.lang.String;|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|basic||static",
    "M|org.jsoup.safety.Whitelist|basicWithImages||static",
    "M|org.jsoup.safety.Whitelist|getEnforcedAttributes|java.lang.String|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|isSafeAttribute|java.lang.String,org.jsoup.nodes.Element,org.jsoup.nodes.Attribute|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|isSafeTag|java.lang.String|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|none||static",
    "M|org.jsoup.safety.Whitelist|preserveRelativeLinks|boolean|new:org.jsoup.safety.Whitelist:",
    "M|org.jsoup.safety.Whitelist|relaxed||static",
    "M|org.jsoup.safety.Whitelist|simpleText||static",
    "C|org.jsoup.safety.Whitelist|<init>|",
    "M|org.jsoup.safety.Whitelist|testValidProtocol|org.jsoup.nodes.Element,org.jsoup.nodes.Attribute,java.util.Set|new:org.jsoup.safety.Whitelist:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
