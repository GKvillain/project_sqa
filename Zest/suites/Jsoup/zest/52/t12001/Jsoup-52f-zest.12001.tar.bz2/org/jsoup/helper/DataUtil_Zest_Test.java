package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 2, 17, "\udb22\udf6c\ud84e\udccd", "\ub8d8\uab1f\u8be8\u0f96\u1818\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\uc182\uc7f9\u8106\u0b4a\u49cd\u8a22\u1018\u0f68\u517c", "\ud87c\ude37",
        8, 43643, 1707364455, 6742653060605885761L, -53005L, true, false, (char) 2539, (char) 31309,
        Double.longBitsToDouble(0x3fec6a0c849ebb41L), Double.longBitsToDouble(0x3febb4677de0613eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 2, 17, "\udb22\udf6c\ud84e\udccd", "\ub8d8\uab1f\u8be8\u202e\ucb30\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\uc182\uc7f9\u8106\u0b4a\u49cd\u8a22\u1018\u0f68\u517c", "\ud87c\ude37",
        8, 43643, 1707364455, 6742653060605885761L, -53005L, true, false, (char) 2539, (char) 31309,
        Double.longBitsToDouble(0x3fec6a0c849ebb41L), Double.longBitsToDouble(0x3febb4677de0613eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 13, "\udb22\udf6c\ud84e\udccd", "\ub8d8\uab1f\uad3a\ubdaa\u0f8a\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\uc182\uc7f9\u8106\u5b28\u49cd\u8a22\u1018\u0f68\u517c", "\ud860\udefc",
        8, 43643, 1707364455, 6742653060605885761L, -53005L, true, false, (char) 2539, (char) 36703,
        Double.longBitsToDouble(0x3fec6a0d8c9ebb41L), Double.longBitsToDouble(0x3febb4677de0613eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 18, 10, 17, "\ud9b2\udc06\ud92b\udd02", "\ub8d8", "\udb15\udcac\udbd1\udd25\udaa5\ude31\udaa9\udccd\ue752\ud96a\udd33\ud95f\udf87\udb54\udc41\ud90b\udc04\ud8c0\udf45\ucdc3\uda77\udd63\udb48\udc65\udb84\udec4\udb04\udc4e\ud9d9\udd3b\ud95a\udfc5\uda85\ude6e\uda56\udefc\ud84d\udc00\ud87c\ude37\ud8e9\udf00\uda0c\ude4c\ud915\ude66\udab7\udcbf\ud9e3\uddca\udaaf\uded0\ud8af\udecd\uda4d\udf9f\ud9f5\udd9d\ud8db\udcef\u123f\ud84f\udcfc\udb7c\udf7f\ud817\uddd6\ud800\udd31\ud853\udeb6\udb91\udc5b\ud9f1\udfb8",
        23, 82713, 423554225, -2066981479724301284L, -43702L, true, false, (char) 51378, (char) 40070,
        Double.longBitsToDouble(0x3fe5d57809685bdfL), Double.longBitsToDouble(0x3fcc0a9ba5cf8320L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 17, "\000\000", "", "\uda28\udc23\udbc9\udf04\u46bc\000\uda91\udc07\ue752\ud96a\udd33",
        42, 66149, 3659, 2368465204356422904L, 73310L, true, true, (char) 29927, (char) 3868,
        Double.longBitsToDouble(0x3fbac2692117a828L), Double.longBitsToDouble(0x3e0d490000000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 6, "\ud82f\udcd3\udbfc\udcc7", "\u135f\uab1f\uc35e\uc321\uaabe\ua28f\u91d2\ua5e8\u1f9d", "\udba4\udd7e\ud93d\udc4d",
        10, 44070, -2034410750, -7870265485740049222L, 3531L, false, false, (char) 57374, (char) 34978,
        Double.longBitsToDouble(0x3fd8be3d186b8f12L), Double.longBitsToDouble(0x3fb85ad94ccbb7e0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 2, 17, "\udb22\udf6c\ud84e\udccd", "\ub8d8\uab1f\u8be8\u0f96\uaa17\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\uc182\uc7f9\u8106\u0b4a\u49cd\u8a22\u1018\u0f68\u517c", "\u8d8b",
        -5, -1000, 0, 6742652802907848001L, -53005L, true, false, (char) 2539, (char) 31309,
        Double.longBitsToDouble(0x3fec6a0c849ebb41L), Double.longBitsToDouble(0x3febb4677de0613eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 18, 17, "\udb22\udf6c\ud84e\udccd", "\ub8d8\uab1f\u8be8\u0f96\u1818\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\u21e9\uc775\u8106\u0b4a\u49cd\u8a22\u1018\u0f68\u517c", "\ud87c\ude37",
        8, 43643, -2059590297, -2615031842069463743L, -53005L, false, false, (char) 2539, (char) 31309,
        Double.longBitsToDouble(0x3fec693c1c9ebb41L), Double.longBitsToDouble(0x3febb4677de0613eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 3, "\ud9a1\udd01\ud84e\udccd", "\ub8d8\uab1f\u4aae\u0fad\u1818\u11e8\u91d2\uc438\u1fb5\u0ac0\u84e8\uc303\u99e4\uc7f9\u8106\u0b4a\ubcc8\u8971\u962f\u0bf8\uc1e8", "\ud9b8\ude3a\ud9d7\udcf1\ud9b1\udcc1\ud620\udab7\udcbf\ud9e3\uddca\udaaf\uded0",
        10, 71709, 1477396589, 3067604925122797401L, -10003L, false, false, (char) 43109, (char) 18011,
        Double.longBitsToDouble(0x3fe5c931f4b9da2aL), Double.longBitsToDouble(0x3fe188b2102a39b4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 18, 7, 19, "\uda97\udd4e\udbac\udf59\ud9a1\uddc0\udb76\udc23\udba5\udfc0\udb72\udcfe\udbfa\udc2c\udbc9\udf04\udbea\ude5e\ud82f\udc73\uda15\udcce\ud9f0\udd2f\ud821\uddc8\udbbe\udc96\uda29\udc0a\ud9bf\ude44\uda12\udf43\ud9de\udd43\ud8cb\udd46\uda4a\udfdc\udb84\udec4\udb04\udc4e", "\u517c\u6063\u6e83\u6a9f\u2466\ucdad", "\ud9e3\uddca\udaaf\uded0\uda66\ude48\udbcf\uddcb\ud9f5\udd9d\ud93e\udcb6",
        1, 83943, -700358771, -8291236756188992906L, 82044L, false, true, (char) 9961, (char) 37378,
        Double.longBitsToDouble(0x3fe0fa395003b3deL), Double.longBitsToDouble(0x3fcc0c7c9581ed88L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 5, "\udb22\udf6c\ud84e\udccd", "\ub8d8\u444e\u31d0\u19fd\uc866\u21e5\u8b3e\uc007\u1fb5\u0ac0\u84e8\u65ae\u7a2a\ub570\u8106\u0b4a\u49cd\u9d22\u1018\u0f68\u517c", "\ud87c\ude37\ud8e9\udf00",
        8, 16951, 1570169906, 656781456741097752L, 49965L, true, false, (char) 43644, (char) 29254,
        Double.longBitsToDouble(0x3fd1f312ef1a8320L), Double.longBitsToDouble(0x3fc3d7682dda33bcL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.XmlDeclaration:<?\ud981\udcc7\ud8ab\udeba?>\0121=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\012",
        Z.run(T, 2, 1, 9, 18, "\ud981\udcc7\ud8ab\udeba", "\ub8d8\uab1f\u8be8\u0f96\u1818\u11e8\u91d2\u5846\uc801\u6314\u84e8\u6dfa\uc182\uc7f9\u906e\u0c35\ua89c\u933f\u6c00\u0f68\u517c\u13cb\u8fb8\u6a9f\u2466", "\uda8b\ude3d\udbed\udf57\udaff\uddd3\uda9a\uddc4\uda07\udf1d\ud9f5\udd93\ud8db\udcef\ud9a1\udd52\ud84f\uddc3\udb7c\udf7f",
        52, 6214, -1685611040, 6803263345876790571L, 27041L, false, true, (char) 24965, (char) 45101,
        Double.longBitsToDouble(0x3f85d4f273260800L), Double.longBitsToDouble(0x3fd7558780cf145cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.XmlDeclaration:<!\udb22\udf6c\ud84e\udccd!>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 2, 17, "\udb22\udf6c\ud84e\udccd", "\u0124\uab1f\u8be8\u0f96\u1818\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\ubf0c\uc7f9\u8106\u0b4a\u49cd\u8a22\u1018\u0f68\u517c", "\ud87c\ude37",
        8, 43643, 1707364455, 6742653060605885761L, -53005L, true, false, (char) 2539, (char) 31309,
        Double.longBitsToDouble(0x3fec6a0c849ebb41L), Double.longBitsToDouble(0x3febb4677de0613eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 17, "\udb22\udf01\ud84e\udccd", "\u02df\uab1f\u8be8\u0f96\u1818\u11e8\u91d2\u49b1\u1fb5\u0ac0\u84e8\u953c\uc182\uc7f9\u47d7\u2fbc\u49cd\u8a22\u1018\u0f68\u517c", "\ud87c\ude37",
        8, 43643, -457907905, -5421543896262015813L, 33373L, false, false, (char) 1148, (char) 17844,
        Double.longBitsToDouble(0x3feac954911f312eL), Double.longBitsToDouble(0x3fec6a0c849ebb41L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 17, "\udb9a\udea8\udb44\udc54", "\u42a9\uab86\u64cc\u9ef2\u1818\u11e8\u91d2\u219a\u1fb5\u0ac0\u84e8\u50f0\uc182\uc128\u8106\u0b4a\u7308\u299b\u9b67\u4e2b\u5f0f", "\ud9d7\ude84",
        38, 39626, -1546425181, -5697494305309764826L, -91218L, true, true, (char) 1148, (char) 43644,
        Double.longBitsToDouble(0x3feac9549654312eL), Double.longBitsToDouble(0x3fdb08c14b3d0664L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.XmlDeclaration:<!\uedb0\ud84e\udccd!>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 20, "\uedb0\ud84e\udccd", "\ub8d8\uab1f\ua83a\ubdaa\u0f8a\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\uc182\uc7f9\u8106\u5b28\u49cd\u2723\u47ef\u0f68\u517c", "\ud860\udefc",
        8, 43643, 1707364455, 6742653060605927233L, -53005L, true, false, (char) 2539, (char) 36703,
        Double.longBitsToDouble(0x3fee75458d1e1874L), Double.longBitsToDouble(0x3febb46375e0613eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 13, "\udb22\udf6c\ud84e\udccd", "\ub8d8\uab1f\uad3a\ubdaa\u0f8a\u11e8\u91d2\u5846\u78b4\u0ac0\u84e8\u65ae\uc182\uc7f9\u8106\u5b28\u2f89\u7faa\u0f8e\u0f68\u517c", "\udaa2\udc72",
        -5, 43625, 1707364455, 6742653060605885761L, -53005L, true, false, (char) 2539, (char) 36703,
        Double.longBitsToDouble(0x3fec6a0d8c9ebb41L), Double.longBitsToDouble(0x3febb4677de0613eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 13, "\udb22\udf6c", "\u53b3\u084c\uab1f\uad3a\ubdaa\u0f8a\u11e8\u00c6\u57e3\u1fb5", "\000\000",
        -5, 15336, 30435586, -573695217585980195L, -100000L, false, false, (char) 40922, (char) 1456,
        Double.longBitsToDouble(0x3fe00002b835c789L), Double.longBitsToDouble(0x3fe6d8000067f68eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.XmlDeclaration:<!\000\000!>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 17, "\000\000", "", "\uda28\udc23\udbc9\udf04\u7b82\udbd6\udd9e\uda91\udc0f\ue752\ud96a\udd33",
        42, 66149, 3659, 2368465204356422904L, 73310L, true, true, (char) 29927, (char) 3868,
        Double.longBitsToDouble(0x3fbac2692117a828L), Double.longBitsToDouble(0x3e0d490000000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 19, "\udacb\udc07\ud84e\udccd", "\u1436\ua6c2\uc123\u0f96\u78db\u11e8\u91d2\u6c5e\u1fb5\u0ac0\u84e8\u65ae\uc182\u3082\u8106\u0b4a\u49cd\u64cc\u9aff\u36cf\u86d7", "\u8d8b",
        45, 45168, 0, 6742652802907848001L, 69555L, true, true, (char) 55599, (char) 47996,
        Double.longBitsToDouble(0x3feac954911f312eL), Double.longBitsToDouble(0x3fda5fdc98bcf530L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.XmlDeclaration:<!\udb22\udf6c\ud84e\udccd!>\0121=java.lang.String: |this=org.jsoup.nodes.XmlDeclaration:<!\udb22\udf6c\ud84e\udccd!>\012",
        Z.run(T, 2, 17, 17, 17, "\udb22\udf6c\ud84e\udccd", "\ub8d8\uab1f\u8be8\uad85\uaa17\u7bfa\u915a\uc072\u9e8b\u6ac0\uc05a\u65ae\u689e\u546b\u420c\ucf1e\u1708\u8a22\u1018\u0f68\u517c", "\u8d8b",
        -5, -1000, 9313148, 6742652802469805377L, -67064L, true, false, (char) 2458, (char) 59724,
        Double.longBitsToDouble(0x3fb8a356a4f5db78L), Double.longBitsToDouble(0x3fd8d4eeae2cc1c6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 13, 17, "\udb22\udf6c", "\uc41e\ub8d8\uab1f\u8be8\u0f96\uaa17\u11e8\u91d2\u8209\u4b69", "\udb85\udcab\udb7f\udc7d",
        58, 44070, -2034410750, -573695217585980195L, 3531L, false, false, (char) 57374, (char) 62639,
        Double.longBitsToDouble(0x3fd8b3c200000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 14, "\udb22\udf6c\ud84e\udccd\ud9a1\uddc0\udb76\udc23\u91e0\udb72\udd19\udb29\udf87\udbc9\udf04\udbc7\ude5e\udaa5\ude6d\udaa9\udccd\ue752\ud96a\udd33\ud95f\udf87\uda1f\udec0\udb85\udd01\udb7f\udc7d\ud8f5\udd1e", "\u49cd", "\ud95a\udfc5\uda85\ude6e\uda56\udefc\ud84d\udc00\u8d8b\000\000\000\udab7\udc83",
        50, 93692, -144188042, 7027161329230825059L, 88249L, true, true, (char) 41245, (char) 22495,
        Double.longBitsToDouble(0x3febb4677de0613eL), Double.longBitsToDouble(0x3fe7020564af6bc2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.XmlDeclaration:<?\udb22\udf6c\ud869\udccd?>\0121=java.lang.String: |this=org.jsoup.nodes.XmlDeclaration:<?\udb22\udf6c\ud869\udccd?>\012",
        Z.run(T, 2, 17, 1, 17, "\udb22\udf6c\ud869\udccd", "\u5381\uab92\u8be8\u0f96\u1818\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\u21e9\uc775\u73f4\u86ef\u4a2f\uabe5\ub942\u0f68\u517c", "\ud85c\udeae",
        8, 43643, -2059590297, -2615031842069463743L, 12531L, false, false, (char) 2539, (char) 31309,
        Double.longBitsToDouble(0x3fec693c1c9ebb41L), Double.longBitsToDouble(0x3febb4677de0613eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 2, "\ud974\udce5\udb60\ude68\ud9a1\uddc0\uda4e\ude8c\u86ee\udb72\udd19\uda2e\udc26\udbc9\udf04\uda58\udc5b\udb8e\udf96\udb31\udcec\udbbd\udc50\udba9\ude32\uda74\udedc\udb5e\udc1e\udbfb\udc51\udb65\ude74\ud8f5\udc9a\udbe9\udde4\uda4a\udfdc\udb84\udec4\udb04\udc4e\udbdf\udebf\ud9c5\ude0a\ud9d6\udf42\udb5f\udcbe", "\ud3f9", "\udb8c\udc9c\ud9e3\uddca\ud827\udd0c\uda65\udc75\udbcf\uddcb\udbd1\udfaa\ud8d5\udc84\ud969\udcc2\udbb9\udccb\ud92d\ude50",
        1, 6214, -235299379, -6260757292016037525L, 90087L, false, true, (char) 40561, (char) 17872,
        Double.longBitsToDouble(0x3fe6c6917967ce9cL), Double.longBitsToDouble(0x3fc8659730792494L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 2, 17, "\udb22\udf6c\ud84e\udccd", "\ub8d8\uab1f\u8be8\u0f96\u1818\u11e8\u91d2\u5846\u1fb5\u0ac0\u84e8\u65ae\uc182\uc7f9\u8106\u0b4a\u49cd\u8a22\u1018\u0f68\u517c\u13cb\u8fb8\u6a9f\u8ec8\u9a85\u5104\u3e23\u500e\u710c\u51f9\ub945\u60cb\ua4e1\ua9a3", "\ud8d5\udcd4\ud9cb\ude9e\udbd4\udd76\ud91e\ude04\uda12\uddc3",
        -4, 36183, -1088198461, -7226311907633585425L, 49939L, true, false, (char) 18355, (char) 23892,
        Double.longBitsToDouble(0x3fcaeafbacbe0140L), Double.longBitsToDouble(0x3fe8989aa755d281L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.nodes.XmlDeclaration|getWholeDeclaration||new:org.jsoup.nodes.XmlDeclaration:java.lang.String,java.lang.String,boolean",
    "M|org.jsoup.nodes.XmlDeclaration|outerHtmlHead|java.lang.Appendable,int,org.jsoup.nodes.Document$OutputSettings|new:org.jsoup.nodes.XmlDeclaration:java.lang.String,java.lang.String,boolean",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$StartTag|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Character|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Comment|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Doctype|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.helper.DataUtil|crossStreams|java.io.InputStream,java.io.OutputStream|static",
    "M|org.jsoup.helper.DataUtil|detectCharsetFromBom|java.nio.ByteBuffer,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|emptyByteBuffer||static",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|mimeBoundary||static",
    "M|org.jsoup.helper.DataUtil|readFileToByteBuffer|java.io.File|static",
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.nodes.XmlDeclaration|getWholeDeclaration||new:org.jsoup.nodes.XmlDeclaration:java.lang.String,java.lang.String,boolean",
    "M|org.jsoup.nodes.XmlDeclaration|outerHtmlHead|java.lang.Appendable,int,org.jsoup.nodes.Document$OutputSettings|new:org.jsoup.nodes.XmlDeclaration:java.lang.String,java.lang.String,boolean",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$StartTag|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Character|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Comment|new:org.jsoup.parser.XmlTreeBuilder:",
    "M|org.jsoup.parser.XmlTreeBuilder|insert|org.jsoup.parser.Token$Doctype|new:org.jsoup.parser.XmlTreeBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
