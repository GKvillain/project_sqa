package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 9, 10, "\udbf2\udd5e\ud96b\ude02\udb98\udc87", "\u8d2d\u1b57\ua916\u6811\u261e", "\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd68",
        59, 39219, 441519377, 8998035796802488211L, 75112L, true, false, (char) 57540, (char) 35889,
        Double.longBitsToDouble(0x3fd3aa152374b1e2L), Double.longBitsToDouble(0x3fd1ba1dd04304c2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 9, 10, "\udbf2\udd5e\ud96b\ude02\udb98\udc87", "\u8d2d\u1b57\ua916\u6811\u261e", "\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd68",
        59, 39219, 441519377, 8998035796802488211L, 75112L, true, false, (char) 57540, (char) 40559,
        Double.longBitsToDouble(0x3fd3aa152374b1e2L), Double.longBitsToDouble(0x3fd1ba1dd04304c2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 9, 10, "\udbf2\udd5e\ud96b\ude02\uda88\udcf3", "\u8d2d\u1b57\ua916\u6811\u261e", "\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd68",
        59, 39219, 1884359953, 5547545126584213161L, 75112L, true, false, (char) 57540, (char) 35889,
        Double.longBitsToDouble(0x3fd3aa152374b1e2L), Double.longBitsToDouble(0x3fd1ba1dd04304c2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 9, 10, "\udbf2\udd5e\ud96b\ude02\u0d5d", "\u8d2d\u1b57\u3588\u9338", "\ubc04\uda1f\udc67",
        -5, 22590, -616747117, 6090451332222254603L, 44349L, false, false, (char) 51059, (char) 57540,
        Double.longBitsToDouble(0x3fe127d8693a95baL), Double.longBitsToDouble(0x3fd2158f1a379158L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 9, 10, "\ud999\ude80\ud815\udcaa\uda86\udf97", "\u1b18\u1b82\u2d0f\u5092\u261e", "\udbc4\udfa0\udac6\ude2e\uda65\udc4a\ud977\udd68\ud861\ude33\udb0e\udf62\ud8ba\udf4b\ud87f\udc74\ud850\ude71",
        54, 27870, -685748515, 6590747916177974866L, -6134L, false, true, (char) 49835, (char) 26360,
        Double.longBitsToDouble(0x3fa0c130c470ed40L), Double.longBitsToDouble(0x3fcca7b1713aa8bcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 13, 15, "\ud858\udc3b\ud991\udcc1", "\ub390\ud120\ua15c", "\udac8\udc1c\ud998\udc0b\uda35\udeb4\uda1f\udc76",
        -2, 22486, 2017275795, -7816664317170651308L, 95566L, true, true, (char) 41077, (char) 12584,
        Double.longBitsToDouble(0x3feeefb15c081d8aL), Double.longBitsToDouble(0x3fe7cf63d5d93e05L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 8, 10, "\ud946\udf27\ud96b\udd79\udb98\udc87", "\u8d2d\u1b57\ua916\u6811\u261e", "\uda1f\udc67\u0f3c\uda77\udd2a\ud84f\udf10",
        59, 39219, -597998063, 8997967824650061715L, 15518L, false, false, (char) 2064, (char) 44074,
        Double.longBitsToDouble(0x3fdbf7b5e249f61aL), Double.longBitsToDouble(0x3fd3aa152f5f8ed2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 3, 10, "\udbf2\udd5e\ud96b\ude02\ud8fd\udd7a\uda36\ude7d\uda71\udc19\ud934\udca4", "\uc595\ud040", "\uda1e\udff9\uda71\udf9b\uda3a\udff8\ud977\udd64",
        59, 39219, 1126042897, 8998035567496514707L, 75112L, true, true, (char) 54505, (char) 56296,
        Double.longBitsToDouble(0x3fd3aa152374b1e2L), Double.longBitsToDouble(0x3fd1ba1dd04304c2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 5, 10, "\ud96a\ude0e\udbae\ude79\ud806\udcf1", "\u8d2d\u1b57\ua916\u6811\u261e", "\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd68",
        40, 9410, 441519377, 8998035798105278355L, 75112L, true, false, (char) 57540, (char) 35889,
        Double.longBitsToDouble(0x3fd3aa152374b1e2L), Double.longBitsToDouble(0x3fd1ba1dd04304c2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 9, 10, "\udbf2\udd5e\uda7e\udded\udbad\udd04", "\u8d2d", "\udba4\udd39\udac8\udc1c\uda20\udd8c\uda0b\udf32\udb07\udcbc\uda8d\udf9b\udbfd\udfbd\ud823\udf4a\u76e3",
        -1, 47377, 2095018466, 3506412482961049804L, 40551L, true, true, (char) 15921, (char) 22252,
        Double.longBitsToDouble(0x3fdba58f1c37df8eL), Double.longBitsToDouble(0x3fa0c130f78a9e60L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 4, 11, "\udbf2\udd5e\ud96b\ude02\udb98\udc87", "\u8d2d\u1b57\ua916\u6811\u261e", "\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd68",
        59, 39219, 441519377, 8998035796802488211L, 75112L, true, false, (char) 57540, (char) 35889,
        Double.longBitsToDouble(0x3fd3aa152184b1e2L), Double.longBitsToDouble(0x3fd1ba1dd04304c2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 11, "\udbf2\udd5e", "\u7567\u66fb\u8d2d\u1b57\ua916\u6811\u261e\u3481", "\u0f3c\uda27\ude4b\ud977\udd68\ud861\ude33\udb0e\udf62\u769e\udb96\udd3d\ud850\ude71\ud9e9\uddae\udac8\udea9\uda89\udd9a\ud9de\udee1\udbf8\ude38\ud945\udd74\uda7a\udf8f\uda3f\ude6c\udb41\udc2d\udb61\uddb3\ud81d\udef0\ud854\udcbd\ud847\ude77\ud921\udd2f\ud887\udd0f\ud86f\udd69\ud80d\udff9\uda70\udf36",
        39, 17863, -456023560, -1229480669587886340L, -49154L, true, true, (char) 39913, (char) 37705,
        Double.longBitsToDouble(0x3fdf0e0f78c11318L), Double.longBitsToDouble(0x3fd5009be1e9be14L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 13, 5, "\udbf2\udd73\ud96b\ude02\udb98\udc87", "\u8d2d\u1b57\ua916\u6811\u1664", "\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd68",
        59, 39219, 441519377, 4674580153137374369L, -71778L, true, true, (char) 51603, (char) 51059,
        Double.longBitsToDouble(0x3fdbf7b05249f61aL), Double.longBitsToDouble(0x3fa750a91ba58ae0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 10, "\udbf2\udd5e\ud96b\ude02\udb98\udc87", "\u8d2d\u1b57\ua916\u6811\u8814", "\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd68",
        59, 63731, 1137384839, 6885968376110860179L, 24734L, true, false, (char) 51601, (char) 50945,
        Double.longBitsToDouble(0x3fdbf7b05249f61aL), Double.longBitsToDouble(0x3fd3aa152374b1e2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 9, 1, "\udbcb\udec8\ud96b\ude02\udb98\udc87\udab4\ude10\ud9b3\udd47\ud928\udfec\ud97e\ude44\ud8e9\udee4", "\u3481\uc455\u7410\u7d87", "\ud861\ude33\udb0e\udf62\u769e",
        16, 16275, 1390643404, 1026255833514200374L, -6198L, true, false, (char) 35980, (char) 653,
        Double.longBitsToDouble(0x3fdba58f1a3743baL), Double.longBitsToDouble(0x3fa0c1309a424ea0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 12, "\udbf2\udd5e\ud96b\ude02\udb98\udc87", "\u8d2d\u1b57\ua916\u0225\u9cda", "\ud963\udd4b\u0f3c\uda65\udc4a\ud977\udd68",
        59, 52067, 441519377, 8998035796802488211L, 15518L, true, true, (char) 17102, (char) 51059,
        Double.longBitsToDouble(0x3fdbf7b05649f61aL), Double.longBitsToDouble(0x3fd3aa12a374b1e2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 12, 10, "\u1485\udbd7\udf59\uda7d\uddf4", "\u5e91\u5cbb\uc51a\u8802\uccbb\u5302", "\ud90f\udcec\uda77\ude47\ud820\udce0\udb4b\udefd\ud924\uddee\ud9d2\udeca\ud9ca\udf70\udba5\udf70\udb7b\udf65\u4f5c\udbf6\udce6\ud903\udf42\udbf8\ude27\ud945\udd74\u9b43\udaff\udd78\udb34\ude69\ud914\udc4b\udb22\ude78\uda3f\ude2b\ud9f7\udf9e",
        37, 86662, -1373407281, 4903509556735542103L, -54732L, false, true, (char) 52728, (char) 55414,
        Double.longBitsToDouble(0x3feccab1b535d6b1L), Double.longBitsToDouble(0x3fe2e7655995f32dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 7, 10, "\udbf2\udd90\ud9dc\udf5b\udbf3\udc90", "\u8dcd\u1b57\ua916\u6811\u0c13\u0537\uc455\u5641\u2c4a\u7a47\u3401\ub855\u324f", "\udabd\udcff\ud9f9\udf43\uda83\udf18",
        16, 36460, 1097818319, -356366666636816092L, -7398L, true, true, (char) 29314, (char) 3859,
        Double.longBitsToDouble(0x3fcd2856b88b29b4L), Double.longBitsToDouble(0x3fda9ed6701becc0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 10, "\udbf2\udd5e\ud95a\udf1b\ue4b7", "\u8d2d\u1b57\u3588\u9338", "\ubcb5\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd42\ud861\ude33\udb0e\udf62\u769e\udb96\udd3d\ud850\ude71\ud9e9\uddae\ud94f\udc4b\ud8fe\udc13\ud9de\udee1\udbf8\ude38",
        50, 43620, 1492214074, 154955414143610312L, 9839L, false, false, (char) 18332, (char) 2242,
        Double.longBitsToDouble(0x3fdc8d618ff9bd28L), Double.longBitsToDouble(0x3fd9ff5f5b09c4eeL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 10, 6, "\udbf2\udd5e\ud96b\ude02\u0d5d", "\u8d2d\u6273\u7ea8\u600c", "\ubc04",
        30, -586, 147483590, 7313898102376587848L, 27727L, false, true, (char) 18596, (char) 25461,
        Double.longBitsToDouble(0x3faf29443dd592b0L), Double.longBitsToDouble(0x3fe8423c52f9ec7aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 3, "\udbf2\udd5e\ud96b\ude02\u0d5d", "\ucd2d\u9731\u2474\u69b5", "\ubc04\uda1f\udc67",
        -5, 22590, -616747117, 6090451332222254603L, 66092L, false, false, (char) 51382, (char) 62353,
        Double.longBitsToDouble(0x3fe7cf63d5bf7b05L), Double.longBitsToDouble(0x3fe127d8693a953fL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 13, "\udb0d\udcbc\ud815\udcaa\udaf9\udfe2", "\u44db\u5a3d\u61c1\ubb98\ubb4d", "\udbc4\udfa0\udac6\ude2e\uda65\udc4a\ud977\udd68\ud861\ude33\ud88f\udc3e\ud95a\udec0\ud897\udc74\ud93b\udcb6",
        17, 92574, -685748515, 7768439215492038552L, -35537L, false, false, (char) 26789, (char) 35146,
        Double.longBitsToDouble(0x3fb7d57862398bd0L), Double.longBitsToDouble(0x3f94268b49b69f00L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 10, "\ud999\ude80\ud815\udcaa\uda86\udf97", "\u61c7\u1b82\u2d0f\u5092\u841a", "\udbc4\udfa0\udac6\ude2e\uda65\udc4a\ud977\udd68\ud861\ude33\udbce\udda1\udace\udcb5\ud893\udf3b\ud850\ude71\ud9e9\uddae\ud90f\ude4d\ud87e\ude92",
        30, 30462, 232540022, -4180805526181809996L, 46149L, true, true, (char) 47829, (char) 46704,
        Double.longBitsToDouble(0x3fb3aa8bfa55c6a8L), Double.longBitsToDouble(0x3fcbd5fdce93ba34L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 10, "\ud999\ude80\udb98\uddcb\ud878\udc50", "\u1b18\u1b82\u2d0f\u5092", "\ud862\udcab\udbc4\udfa0",
        0, 22590, -616747117, 6090451332222254603L, -6134L, true, false, (char) 45610, (char) 61688,
        Double.longBitsToDouble(0x3fa0c12fc470ed40L), Double.longBitsToDouble(0x3fcca7b1713aa8bcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 2, "\ud86d\udcf6\ud991\udcc1\udb98\udc87", "\ub8fe\ua15c\u8150\u6f03\u261e\u2651\u0f27\u6de7\ub382\u5b38\uaa1c", "\udbea\udc1a\udbc9\udeb3\ud850\ude71\udb66\ude86\ud81e\udfaa\uda89\udd9a\ud9de\udee1\ud9f0\udc94\ud8e7\ude27\udb57\uddae\uda75\udece\ud806\udc8a\ud9b1\uddf2\ud8fb\udd1d\ud9fb\udd2b\ud9a9\udf25\udb4b\ude31\uda8d\udf74\ud8ea\udddd\udbe2\udfc3\ud835\ude3c",
        8, 41103, 167771125, 1533695223176189749L, 56208L, false, true, (char) 58161, (char) 6424,
        Double.longBitsToDouble(0x3fe5673f49d9d74eL), Double.longBitsToDouble(0x3fc6f045ec881be0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 3, "\udbf2\udd92\ud96b\ude02\udb98\udc87\uda5e\ude86\ud9c8\udca3\ud87f\udf04", "\u6811\u261e\u630b\u0711\u6dd8\u7d87\u2e31\u1c02\u0d65", "\udb96\udccc\ud850\ude71\uda70\udcae\udb57\ude07\uda5a\udd80\ud959\udc38\udb95\ude2e\udbd0\udd76\udb67\ude53\udb55\ude77\udb58\udf35\udb61\uddb3\udbd0\ude8a",
        46, 21844, 1861290315, 8688118976729477297L, -58793L, false, false, (char) 27266, (char) 48581,
        Double.longBitsToDouble(0x3feb29874bd1b883L), Double.longBitsToDouble(0x3fef678f717adc91L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 11, "\udbf2\udd5e", "\u60a9\u36ed\ua7d7\ub6d2\u9212\u6811\u8100\u68bf", "\u0f3c\uda27\ude4b\ud977\udd68\ud861\ude33\u2768\uda76\udf0d\udbaa\udd3d\ud850\ude71\ud9e9\uddae\ud803\udca7\uda9a\udd6a",
        12, 45305, -83008065, -6822230900228333254L, 46149L, true, false, (char) 687, (char) 5904,
        Double.longBitsToDouble(0x3fb8ca2062328b58L), Double.longBitsToDouble(0x3feddc2ca8777138L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 5, "\udbf2\udd73\ud96b\ude02\udb4b\udfd4", "\u8d2d\uc261\u66c4\u6811\u85e4", "\uda1f\udc72\u35e1\uda6e\udc7d",
        48, 2704, -756449781, 1896311285853680098L, 40551L, true, true, (char) 35889, (char) 3457,
        Double.longBitsToDouble(0x3fdb358ae0109322L), Double.longBitsToDouble(0x3fe4f59cc39f45d1L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 2, 1, "\ud8b9\ude76\ud96b\ude07\udb98\udc87", "\uac2d\u1b57\u25e9\u8164\u2237", "\ud9d8\udda0\ud8ee\uddaa",
        15, 58883, 1418043704, -3249018329484948207L, -90623L, false, false, (char) 8473, (char) 37358,
        Double.longBitsToDouble(0x3f803b18be7b1e80L), Double.longBitsToDouble(0x3fdbf7ba1249f61aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 12, 10, "\u1485\udbd7\udf59\uda7d\uddf4", "\u5e91\u5cbb\uc51a\u8802\uccbb\u5302", "\ud90f\udcec\uda77\ude47\ud820\udce0\uae0e\ud964\udcf1\ud9d2\udeca\ud9ca\udf70\udba5\udf70\udb7b\udf65\u4f5c\udbf6\udce6\ud903\udf42\udbf8\ude27\ud945\udd74\u9b43\udaff\udd78\u37f6\000\udaf7\udf5b\uda3f\ude2b\ud9f7\udf9e",
        37, 86662, -1373407281, 4903509556735542103L, -54732L, false, true, (char) 52728, (char) 55414,
        Double.longBitsToDouble(0x3fc32ac6d4d75ac4L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 8, 10, "\udbf2\udd90\ud9dc\udf5b\udbf3\udc90", "\u0a8c\u7105", "\ud98b\udfe6\udb5b\udc83\udb29\ude4a\ud858\udcf5\udace\udf02\udaae\udc64\ud977\udd68\ud8a9\udf46\ud807\ude9e\udb02\udf5b\udba2\ude9b\udabd\udcff\ud9f9\udf43\uda83\udf18\ud9f2\udc22\udb5a\udd52\ud84b\udec8\ud95b\udecf\uda7a\udf8f",
        38, 11002, -1538341605, 4359748462067316371L, -97474L, true, true, (char) 7837, (char) 3388,
        Double.longBitsToDouble(0x3fd091e3b8fda51aL), Double.longBitsToDouble(0x3fee757dcdbc803cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 12, 5, "\udbf2\udd90\ud9dc\udef3\udbf3\udc90", "\ub061\u8cc7\u617e\u6811\u3faa\u1bab\uab79\ub542\u8a33\u7a47\u3401\u647c\u0543", "\udabd\udcff\ud94a\udcac",
        29, 6389, 42256788, -5666352483999551896L, 55334L, true, true, (char) 33865, (char) 29314,
        Double.longBitsToDouble(0x3fe498ec007342b5L), Double.longBitsToDouble(0x3fd22ca54152ce2cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 10, "\udbf2\udd5e\ud95a\udf1b\ue4b7", "\u8d2d\u1b57\u3588\u9338", "\udbfa\uddbc\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd42\ud861\ude33\udb0e\udf62\u769e\udb96\udd3d\ud850\ude71\ud9e9\uddae\ud94f\udc4b\ud8fe\udc13\ud9de\udee1\udbf8\ude38",
        50, 43620, 1492214074, 10840226872164352L, -100000L, true, true, (char) 17708, (char) 39548,
        Double.longBitsToDouble(0x3fd1e027ed72b412L), Double.longBitsToDouble(0x3fdc8d618ff9bd28L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 16, "\udbf2\udd5e\ud95a\udf1b\ue4b7", "\u8d2d\u1b57\u3588", "\ud820\udc3b\ubcb5\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd42\ud861\ude33\udb0e\udf62\000\000\ud850\ude71\ud9e9\uddae\ud94f\udc4b\ud8fe\udc13\ud9de\udee1\udbf8\ude38\ud945\udd74\udaf6\udfe0\000\ud982\udc20\uda84\udef4",
        29, 76990, -231024153, 41811968L, -55271L, false, true, (char) 54928, (char) 53140,
        Double.longBitsToDouble(0x3fd84e277a1c3484L), Double.longBitsToDouble(0x3fb134dd88264ff0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 1, "\udbf2\udd5e\ud95a\udf1b\udb30\uddaf", "\ub948\u3394\u2da9\u9976\u95cd\u035d\u94ef\u6dd8\u7d87\u2e31\u33db\u0d65\ua09a\uac41\u05e2\u613f", "\ud8fe\udc13\ud9de\udee1\ud852\ude26\uda31\udf1f\udabd\udf94\udb55\ude77\ud9a2\udf41\uda84\udef4\ud884\udf31\ud9e2\udec3\ud8d8\udd17\uda9b\udef4\uda83\ude43",
        48, 34522, -560724536, -723399503914739297L, -71432L, false, true, (char) 57605, (char) 43948,
        Double.longBitsToDouble(0x3fd653b665a65bd4L), Double.longBitsToDouble(0x3fddb63db934775eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 12, "\ud999\ude80\ud815\udcaa\uda86\udf97", "\u5c5d\u5bea\u12f7\u8e53", "\ud843\ude2f\udbc4\udfa0",
        58, 22611, -30003309, 6105405933383941643L, -26697L, false, true, (char) 64264, (char) 43540,
        Double.longBitsToDouble(0x3fc8d79a3dd94fe0L), Double.longBitsToDouble(0x3fc0c1bb82d317c4L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 2, "\ud86d\udcf6\ud991\udcc1\udb98\udc87", "\ub8fe\uc5d3\u8150\u6f03\uc373\u2651\u0f27\u6de7\ub382\u5b38\uaa1c", "\udbe9\udfb0\udbc9\udeb3\ud850\ude71\udb66\ude86\ud81e\udfaa\uda89\udd9a\ud9de\udee1\ud9f0\udc94\ud8e7\ude27\udb57\uddae\uda75\udece\ud806\udc8a\ud9b1\uddf2\ud8fb\udd1d\ud9fb\udd2b\ud9a9\udf25\udb4b\ude31\uda8d\udf74\ud8ea\udddd\udbe2\udfc3\ud835\ude3c",
        8, 90744, -1666182553, 1533688626106423077L, 5922L, false, true, (char) 58358, (char) 6424,
        Double.longBitsToDouble(0x3fe5673f49d9d74eL), Double.longBitsToDouble(0x3fc6f045ec881be0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 14, "\udbf2\udd73\ud96b\ude02\ud9f0\udff4", "\u9eba\u8bdd\u678a\u228c\u389b\u651a\ud2a6\u6de3\u1245\u5264\u8e60\u0d65\ua09a", "\uda56\ude47\ud9de\udca0\udb74\udc8d\udb01\udf78\ud9de\udee1\udbf8\ude38\ud945\udd74\uda7a\udf8f\udb90\udd67",
        2, 12456, 1171331750, 3733971858058090279L, 20724L, true, false, (char) 30973, (char) 8321,
        Double.longBitsToDouble(0x3fea9ac7ced29c36L), Double.longBitsToDouble(0x3fdaae10942f8b2cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 9, 10, "\udbf2\udf57\ud96b\ude02\udb98\udc87", "\u8d2d\u1b57\ua916\u6811\u261e", "\uda1f\udc67\u0f3c\uda65\udc4a\ud977\udd68",
        59, 1187, 771497857, 8998035870148191379L, -354L, true, true, (char) 61063, (char) 51059,
        Double.longBitsToDouble(0x3fdbfb305227f61aL), Double.longBitsToDouble(0x3fd3aa152374b1e2L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 1, 10, "\u13c4", "\030\000\000\u7d89", "\u8e76\uda55\udfce\udb1d\udd79\ud874\udcb0\ud90f\udcec\udbc5\uddce\000\000\ud924\uddee,\ud9ca\ude89\u5ea9\000\000",
        5, 44016, 0, -356516924477233884L, 82282L, true, true, (char) 57655, (char) 53028,
        Double.longBitsToDouble(0x3ec1980000000000L), Double.longBitsToDouble(0x3e9ef9e000000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilder|inSpecificScope|java.lang.String,[Ljava.lang.String;,[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|inSpecificScope|[Ljava.lang.String;,[Ljava.lang.String;,[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|aboveOnStack|org.jsoup.nodes.Element|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearFormattingElementsToLastMarker||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToContext|[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableBodyContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableRowContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|defaultSettings||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|error|org.jsoup.parser.HtmlTreeBuilderState|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk|boolean|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getActiveFormattingElement|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getBaseUri||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|inSpecificScope|java.lang.String,[Ljava.lang.String;,[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|inSpecificScope|[Ljava.lang.String;,[Ljava.lang.String;,[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
