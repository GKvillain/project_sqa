package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 4, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\uc9cf", "\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud810\udf35\ud9b2\udd41\ud901\ude12",
        -1, 35323, -5199156, -5166152501149705351L, -87686L, true, false, (char) 2148, (char) 17496,
        Double.longBitsToDouble(0x3fd1d1656c1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 4, 3, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\u2073\u5441\u427a\u1777\u1422\uc9cf", "\udbcb\udfe1\ud94e\udf85\udaa1\udfc7\uda46\udf30\u61c8\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud810\udf35\ud9b2\udd41\udb71\udc57",
        54, 20379, -5199156, -5166152501149705351L, -87686L, false, true, (char) 42350, (char) 23135,
        Double.longBitsToDouble(0x3fb9ab72b077e930L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 4, "\uda90\udf29", "\u28cb\u760d\u6c65", "\ud9b5\udf99\udaae\uded5\ud8d9\udcba\udb12\udddf\ud878\ude85\u7eb7\ud89b\udc0b\ud8ff\uddf6\udaf4\ude9b\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8bc\udf7a\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf",
        35, 79240, -1833711194, 2187225747230008524L, -61909L, true, false, (char) 9053, (char) 37831,
        Double.longBitsToDouble(0x3feebf8bcce6e39fL), Double.longBitsToDouble(0x3fe4ded2c9700ef4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 6, 4, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\uc9cf", "\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud810\udf35\ud9b2\udd41\ud901\ude12",
        -1, 35323, -5199156, -5166152501149705351L, -87686L, true, false, (char) 2148, (char) 17496,
        Double.longBitsToDouble(0x3fd1d1656c1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 0, "\ud878\udd04\uda90\ude21", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\uc566\u3c86", "\ud89b\udc1e\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\ud899\udf14\uda12\udc44\uda04\uddaf\ud977\udd26\ud865\udd6e\udabf\ude1b\ud9b2\udd3b\ud901\ude12\ud90f\udebf\ud97f\ude97\ud922\udec7\ud96e\udf72\udb80\ude9d\udb8e\udca6\uda35\udc05\uda44\udf7c\udb36\ude6b\udbef\udcf8\ud91d\udf29\udb15\udcb9\ud9cb\ude8e\udaf6\udceb\ud9b2\udd83\ud985\udce1\ud915\udecf\uda51\udf59\ud9a9\udfd0\uda98\udc43\udaff\ude04\ud97f\udd3e\udba4\ude32\udbeb\udc1a",
        58, 3485, -1574640943, -4647825660174476096L, -29684L, true, false, (char) 64749, (char) 33371,
        Double.longBitsToDouble(0x3fde4ced0a97979aL), Double.longBitsToDouble(0x3fe9a49b56fe48aaL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 17, 4, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\ua1ce", "\ud89a\udf49\ud973\udd8c\ud93a\ude9a\ud8e2\udd6e",
        -4, 84190, -495373822, 4659411282116182748L, -93070L, false, false, (char) 49515, (char) 51535,
        Double.longBitsToDouble(0x3fea147f5b79b84eL), Double.longBitsToDouble(0x3feebf8bcfe6e39fL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 16, 2, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ud65b\u4367", "\ud935\udca4\ud850\udf10\ud9b4\udd32\udb42\ude34\ud89a\udff3\ud94e\udfa7\udb93\udee7\udbb2\udc55\ud94f\udd19\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud820\udf2e\ud9b2\udd41\ud901\ude12\ud90f\udebf\udbb3\udeb1\udbbf\udf4c\uda67\udd4d\udb80\udf00\udb9b\ude2a\uda35\udc05\uda44\udf7c\udb36\ude6b\udbef\udc50\udbdb\udcda\udaed\udc9a\ud9d7\udd8e\ud8f6\udc2c\udabd\udc0d",
        32, 91426, 1729588413, -268096540963701603L, -61283L, true, false, (char) 49746, (char) 63874,
        Double.longBitsToDouble(0x3fe86466b3965cbcL), Double.longBitsToDouble(0x3fc0ff3f67f37500L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 1, "\uda24\udf16", "\u2822\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u5a12\u5f74\u39b7\u0204\uc951\u47bd\uc1c9\u271f\ubefa\u4a98\ub78f\u1861\u15e5\u3703\u5283\u315b\u5dc0\u901b\u2a2e\u2b00\u1104\u42c5\ud26d\ubeb2\u3242\u5e35\u8414", "\ud8d6\udcb8\ud910\udfa0\udb15\udcb9\ud9cb\ude8e",
        23, 89370, -819726446, -1659276282415585654L, 64066L, true, true, (char) 60253, (char) 45968,
        Double.longBitsToDouble(0x3fe0d2cddb3f3021L), Double.longBitsToDouble(0x3fec15c04e296024L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 4, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\uc9cf", "\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u4032\udb6d\ude9a\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud810\udf35\ud9b2\udd41\u00ee",
        39, 35323, -5199156, -5166152501149705351L, -87686L, true, false, (char) 2148, (char) 17496,
        Double.longBitsToDouble(0x3fd1d1656c1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 16, 0, "\u1bfe", "\u0d8d\000\u9cfd\u412b\u2f93\u44ca\ub228\u426c\u427a\uc695\ud59d\000\000\u8e40%\u0596\u7bbc\u6186\000\000\u8a91\000\000\000\000\000\000\ud4e4\u70f6\ud26d\ubeb2\u3242\u5e35\u2ad3", "\000\ud918\ude0c\u26b3",
        20, 49456, -1071061822, -4299007018596070367L, -29906L, true, true, (char) 40806, (char) 28049,
        Double.longBitsToDouble(0x3fe632768c7d2f50L), Double.longBitsToDouble(0x3fead965d4eb08beL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 9, 4, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\uc9cf", "\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud810\udf35\ud9b2\udd41\ud901\ude12",
        -1, 35323, -5753908, -5166152501149705351L, -87686L, true, false, (char) 2148, (char) 17496,
        Double.longBitsToDouble(0x3fd1d1656c1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 4, "\udba2\udc0b\uda66\udf58", "\u75d5\u9cfd\u41a2\u2f93\u9d23\ub228\u426c\u427a\u1777\u1422\uc9cf", "\uda2e\ude45\ud958\udde4\ud8d9\udce8\ud90f\udcb2\udb20\uddb9\udb6d\udf84\ud9fb\udfd8\ud8a7\udd78\udad5\udf50\uda1d\udf49\ud810\udf35\ud9b2\udd41\ud901\ude12",
        31, 45992, -5199156, -5166152501149705351L, 24954L, true, false, (char) 1974, (char) 17496,
        Double.longBitsToDouble(0x3fd1d1656c1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 7, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\uc9cf", "\ud9e2\ude4c\ud977\udf2d\ud93a\ude9a\udb2c\udeb4\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf\udb32\udcc4\uda1d\udf49\ud810\udf35\ud9b2\udd41\ud901\ude12",
        -1, 35323, -5199156, -5166152501149705351L, -87686L, true, false, (char) 2148, (char) 44375,
        Double.longBitsToDouble(0x3fd1d2aecc1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 14, 13, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\ud34f\u4c12\u316a\uc209", "\udaf4\ude9b\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf",
        35, 79240, -1833711194, -6082790543499205394L, -61909L, false, false, (char) 9053, (char) 37831,
        Double.longBitsToDouble(0x3fc9994f3f9b8d28L), Double.longBitsToDouble(0x3fe4da2fb9700ef4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 17, 11, "\udba2\udc0b\uda90\ude5d", "\u75d5", "\udbc4\udc78\ud8ae\udefd\udaae\uded5\ud8d9\udcba\ud804\udd22\udabc\udf3a\ud96a\ude5e\ud88d\udcf0\ud9d9\ude87\ud8a5\udcbb\ud8d8\udf4b\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\udb6d\udf38\udb31\udff3\uda33\udf33\ud877\uddc1\ud8a5\udf81\ud81e\udce3\ud8d5\udf13\u07b2\ud83c\uddf1",
        50, 94524, 2076031398, -1046563984391548969L, -99333L, false, true, (char) 17496, (char) 11123,
        Double.longBitsToDouble(0x3fe074d80e81e972L), Double.longBitsToDouble(0x3fedc00a549e1b41L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 5, 10, "\ud876\ude22\uda90\ude5d", "\u7456\u7022\uae59\u53ed\u44ee\ub228\u426c\u427a\u8651\uc850\uc9cf", "\ud9fe\udf1f\ud94e\udfd0\ud93a\ude9a\ud8e2\udd6e\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud810\udf35\ud99d\udc35\udadb\udf92",
        57, 35323, -5199156, -7153887005238502443L, -87686L, true, true, (char) 2000, (char) 26123,
        Double.longBitsToDouble(0x3fd1d1656c1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 15, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\uc9cf", "\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\ud960\udff2\uda12\udc44\ud9da\udeba\uda9a\ude80\udaaa\udd93\ud911\udd3d\udb61\udf67\ud901\ude12",
        39, 23686, -1004697652, -8109097987881722458L, 35450L, true, false, (char) 64123, (char) 17496,
        Double.longBitsToDouble(0x3fd1d1656c1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 4, "\udba1\udf5f\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\uc9cf", "\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud810\udf35\ud9b2\udd41\ud901\ude12",
        -1, 35323, -5199156, -5166152501149705351L, -87686L, true, false, (char) 2148, (char) 17496,
        Double.longBitsToDouble(0x3fc346fd754cbc70L), Double.longBitsToDouble(0x3fe7b8cdf3b8014aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 16, "\udba6\ude0b", "\u0bc0\u75d5\u83ce\u0625\u55f6\ub428\ub228\u5304\ua314\u95b8\u1422\u7ceb\u47bd\u348e\u4689\u0596\u7bbc\u0857\u9412\uc17a\u2e38\u4e44\u315b\ub3e0\u7c1c\ub8f1\uc653\ub98a\u70f6\ud26d\ubeb2\u1d39\uc977\ua654", "\udb9b\udfd5\ud91d\udf29\udb15\udcb9\ud9cb\ude8e\ud8a2\udee1\udbba\ude7a\udae8\udc74\udba4\ude3a\udbe2\udf55\ud974\udc12\udab2\udcea\udbb6\udf68\ud94b\udebf",
        55, 88665, -538692426, 5344864553903809116L, 36508L, false, true, (char) 27643, (char) 12211,
        Double.longBitsToDouble(0x3fae94a8a250dd80L), Double.longBitsToDouble(0x3fc280669f61d4c0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 3, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u17bf\u44e3\u2073\u5441\ub608\u1702\u1422\uc9cf", "\udbcb\udfe1\ud94e\udf85\uda16\udc4c\uda46\udf61\u61c8\udb38\udd7d\ud832\udf63\uda04\uddaf\udac0\udccb\uda1d\udf49\ud96f\udda3\ud9b2\udd41\udb2f\ude55",
        4, 39495, -5208019, 4466901391435721516L, -19059L, true, true, (char) 54279, (char) 48766,
        Double.longBitsToDouble(0x3f9179bcf4fa1980L), Double.longBitsToDouble(0x3fe6a3a5fcd8ed25L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 8, 3, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\u2073\u5441\u427a\u1777\u1422\uc9cf", "\udbcb\udfe1\ud94e\udf85\udaa1\udfc7\uda46\udf30\u61c8\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud810\udf35\ud9b2\udd41\udb71\udc57",
        54, 20379, -5199156, -5166152501149705351L, -87686L, false, true, (char) 42350, (char) 23135,
        Double.longBitsToDouble(0x3fb9ab72b077e930L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\udba2\udc0b\uda90\ude5d", "\u75d5", "\udbc4\udc78\ud812\udeef\ud87f\uddbf\ud805\udf05\ud81e\udf46\ud87a\ude76",
        24, 54648, 0, -643937792L, -100000L, false, false, (char) 31148, (char) 38046,
        Double.longBitsToDouble(0x3fe0100005e0e279L), Double.longBitsToDouble(0x3fe6e2054800dcfbL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 4, "\ud89b\udc0d\uda90\ude5d", "\u7513\u9cfd\ua13e\u2f93\u44ca\u2073\u5441\u4078\u17778\000", "",
        15, 67266, 1718890942, 215534343831587L, -100000L, false, true, (char) 33279, (char) 33131,
        Double.longBitsToDouble(0x3fda6305bc772400L), Double.longBitsToDouble(0x3fbaaae57f15d760L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 2, 3, "\udba2\udc0b\uda67\udf04", "\u050f\u9cb3\u41a2\uc90f\u157d\u4f8b\u5441\u427a\u1777\u1422\uc9cf", "\udbf2\udc3e\ud94e\udf85\udaa1\udfc7\ud918\udfb8\ud9ed\udce1\ud933\ude75\uf9fa\ud97f\udc45\udac0\udccb\uda1d\udf49\ud810\udf35\ud9b2\udd41\udb71\udc57",
        54, 20379, -5199156, -5166152501663049607L, -87686L, false, true, (char) 22894, (char) 48348,
        Double.longBitsToDouble(0x3fd569375c1c98aaL), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 6, 13, "\udba2\udc0b\ud961\udf71\ud989\ude78\uda34\udf6b\ud961\udedd\udad1\udde7\udbd0\ude00\udbc4\udc78\ud8ae\udefd\ud8b2\udf82\ud805\udf05\ud81e\udf46\ud865\udfbd\u7e67\ud89b\udc0b\ud8ff\uddf6\uda4b\udfc7\udae5\udeb6\ud94f\udc02\udaa1\udfc7\uda46\udf30\u61c8\udb6d\udf38\udad3\udee4\ud9ff\udf38", "\u901b\u9984\u2e8b", "\ud922\udec7\ud955\udf72\udb80\ude9d\uda23\ude4e\udb00\udf4c\uda0a\udc0c\ud90c\uddc5\udaf7\udd9f",
        52, 3126, 21663355, -3060534340854084181L, 50704L, false, true, (char) 60230, (char) 59441,
        Double.longBitsToDouble(0x3fea675f2daea69aL), Double.longBitsToDouble(0x3fdf23fc73a72272L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=null |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 15, 2, "\udba2\udc0b\uda90\ude5d\ud989\ude70\uda34\udf6b\ud99f\udf16\udad1\udde7\udbd0\ude00\udbba\uddd3\udafb\udc31\udb4d\udece\ud88e\udce4\ud8f0\udeb6\ud988\udd81\u7e67\ud89b\udc0b\ud8ff\ude04\udaf4\ude9b\udbcb\udfe1\ud94e\udf85\udaa1\udfc7\uda46\udf30\u61c8\udb6d\udf38\uda12\udc44\uda04\uddaf", "\u901b\u2a2e\u2e8b", "\ud922\udec7\ud955\udf72\udb80\ude9d\udb9b\ude2a\udb6f\ude42\uda0a\udca6\ud852\udc87\ud81d\uddbe",
        0, 3126, 21663355, 4599076510936430739L, -8883L, false, true, (char) 5890, (char) 19891,
        Double.longBitsToDouble(0x3fbcb9ceec028738L), Double.longBitsToDouble(0x3fe116b588b07ae5L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 10, 16, "\ud97f\udd2c", "\ub328\u1e51\u125c", "\u0d4f\ud87e\ude08",
        49, 47045, -415360481, -2034350580867874442L, 59682L, false, false, (char) 9805, (char) 13888,
        Double.longBitsToDouble(0x3feb6840d03200e0L), Double.longBitsToDouble(0x3fd9e94286043676L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 11, 3, "\ud878\udd04\uda90\ude21\ud989\ude70\uda34\udf6b\ud99f\udf16\udad1\udde7\udbd0\ude00\uda72\uded0\ud8ae\udedf\udaae\uded5\ud8d9\udcba\ud81e\udf46\udb91\udca5\udbf2\udecb\uda27\udf11\ud801\ude33\udbcc\uded5\ud89b\udc1e\ud94e\udfa7\ud93a\ude9a\ud99e\udd8c\u61d7\ud87a\udc14\uda12\udc44\uda04\uddaf\ud977\udd26\ud865\udd6e\udabf\ude1b\ud9b2\udd3b\ud901\ude12\ud90f\udebf\ud97f\ude97\ud922\udec7\ud96e\udf72\udb80\ude9d\udb8e\udca6\uda35\udc05\uda44\udf7c\udb36\ude6b", "\ua353\ua802\u7457\ub937\u0949\ua30c\ua736\u4b24\u4fbc\u0f7c\u8bf2\u6456\u76f4\uc938\u8caa\u73e0\u2be2", "\ud8c3\udf24\udbcd\udd6f\uea15\udbe7\ude65\ud9ec\uded0\udb5d\udee4\ud8e6\udf7c",
        4, 62163, 486253452, 4094212258778426198L, 29518L, true, false, (char) 777, (char) 49553,
        Double.longBitsToDouble(0x3fe1b040a7c95718L), Double.longBitsToDouble(0x3fc6f2a9c352d438L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 9, 8, "\uda24\udf16", "\u2822\u75d5\u9cfd\u1509\u2f93\u44ca\ub228\u5a12\u5f74\u22e2\ub608\uc951\ubba9\uc141\u9e7d\u45e6\u53ec\u620d\u1861\u15e5\u3703\u1dc5\ud078\u27dc\u901b\u6783\u5e36\u0797\ub5f0\u8696\u8551\u3242\u5e35\u960a", "\ud8d6\udcb8\ud910\udfa0\udb15\udcb9\ud9cb\ude8e\udabb\udc50\udaaa\udef4\udb7b\udcfc\ud88d\udefb\ud9d7\udfa5\ud963\ude2c\udb43\ude0e\ud9fc\udc73\uc96c\udad7\ude1c\ud867\udcf0",
        -4, 72189, -1268015202, -3021651431909345289L, -77702L, false, false, (char) 55293, (char) 20922,
        Double.longBitsToDouble(0x3fdaf0c7adf4e1e2L), Double.longBitsToDouble(0x3fd30caad4615022L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 1, "\uda24\udf16", "\u2822\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u5a12\u5f74\u39b7\u0204\uc951\u47bd\uc1c9\u271f\ubefa\u4a98\ub78f\u1861\u15e5\u3703\u49a1\u315b\u5dc0\u901b\u2a2e\u2b00\u1104\u42c5\ud26d\ubeb2\u3242\u5e35\u8414", "\ud8d6\udd0e\ud910\udfa0\udb15\udcb9\ud9cb\ude8e",
        23, 89370, -819726446, -1659276282415585654L, 64066L, true, true, (char) 60253, (char) 45968,
        Double.longBitsToDouble(0x3fe0d2cddb3f3021L), Double.longBitsToDouble(0x3fec15c04e296024L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 10, 4, "\udba2\udc0b\uda90\ude32", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u334f\u4c6f\u7667\u87b0\u6317", "\uda3c\udda9\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\udb75\udd96\uda12\udc44\uda04\uddaf\udac0\udccb\uda56\udd66",
        18, 61963, -1952455442, 3215900116791891147L, 21940L, true, true, (char) 36757, (char) 29031,
        Double.longBitsToDouble(0x3fe039ff914c384cL), Double.longBitsToDouble(0x3fed4085851d1656L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 2, 6, "\uda9e\uddbf\uda66\udf58", "\u6c0e\u2829", "\uda03\udfa9\ud893\uddfb\ud8d9\udcc1\ud81e\udf46\ud988\udd81\u7e67\ud89b\udc0b\udaa1\ude64\ud90b\udd82\uda2e\ude45\ud958\udde4\ud91c\udf6b\udb39\udd74\udb20\uddb9\udb6d\udf84\ud9fb\udfd8\ud8a7\udd78",
        19, 79240, -1833711194, -6082790543499205394L, 78920L, false, false, (char) 5469, (char) 54319,
        Double.longBitsToDouble(0x3feebf8befe6e3c4L), Double.longBitsToDouble(0x3fe4da2c33700e46L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 0, "\udba2\udc0b\uda66\udf58", "\u75d5\u9cfd\u41a2\000\000\000\000\u694c\u1777\u1422\uc9cf", "\uaec4\000\000\000\000\ud930\udd97\ud9fb\udfd8\udaf2\udd3d\000\000\000\000\ud8c8\udd24",
        31, 45992, 204, 7929977L, -100000L, false, false, (char) 3696, (char) 0,
        Double.longBitsToDouble(0x3fd000000c1d3602L), Double.longBitsToDouble(0x3e3dc00800000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 14, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u3715\u44ca\uc9e4\u6554\u5c0e\u1bfd\u4285", "\ud884\udd86\udbca\ude55\uda30\udf0d\ud93a\ude9a\ud8e2\udd6e\u61d7\u262c\udbe0\udc72\udb92\udcaa",
        35, 79240, -1833711194, -6082880703452683026L, -94677L, true, true, (char) 8953, (char) 37831,
        Double.longBitsToDouble(0x3fc9994f3f9b8d28L), Double.longBitsToDouble(0x3fe4da2fb9700ef4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 10, 13, "\udba2\udc0b\uda08\udf0f", "\u75d5\u9cfd\u41a2\u2d1f\ubbca\ub1af\ud34f\u4c12\u316a\uc209", "\udac9\udcc3\ud9c1\udfbd\ud94e\udfa7\ud93a\ude9a\ud9f6\ude6d\u61d7\uda9a\udfaf\u3c23\udb4c\udfae",
        44, 71719, -1833711194, -6082790543499262553L, 21940L, false, true, (char) 4934, (char) 45872,
        Double.longBitsToDouble(0x3fe4da2fb9700ef4L), Double.longBitsToDouble(0x3fee08bc785fa4acL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 16, 4, "\udba2\udc0b\uda90\ude5d", "\u75d5\u9cfd\u41a2\u2f93\u44ca\ub228\u426c\u427a\u1777\u1422\uc9cf", "\ud89a\udf49\ud94e\udfa7\ud93a\ude9a\ud8e2\udd6e\u61d7\udb6d\udf38\uda12\udc44\uda04\uddaf\udac0\udccb\uda1d\udf49\ud95e\udebc\udbf3\udf4d\ud8ac\udec3",
        45, 1085, 1874074390, -5166152501149705351L, -87686L, true, false, (char) 2148, (char) 17496,
        Double.longBitsToDouble(0x3fd1d1656c1d3602L), Double.longBitsToDouble(0x3fe3df4b93b8014aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableBodyContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableRowContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilderState|process|org.jsoup.parser.Token,org.jsoup.parser.HtmlTreeBuilder|fac:org.jsoup.parser.HtmlTreeBuilderState:valueOf:java.lang.String",
    "M|org.jsoup.parser.HtmlTreeBuilder|aboveOnStack|org.jsoup.nodes.Element|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearFormattingElementsToLastMarker||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToContext|[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|defaultSettings||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|error|org.jsoup.parser.HtmlTreeBuilderState|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk|boolean|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|generateImpliedEndTags|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getActiveFormattingElement|java.lang.String|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getBaseUri||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|getDocument||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableBodyContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableRowContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilderState|process|org.jsoup.parser.Token,org.jsoup.parser.HtmlTreeBuilder|fac:org.jsoup.parser.HtmlTreeBuilderState:valueOf:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
