package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 0, "\uda75\udc86\ud859\udfa3\ud904\udfdd\ud9c8\udcd0", "\ubb52\ucadd\u73d9\u80f2", "\ud80e\udc6d\uda37\ude96\ud90b\uded4\udabd\udf3c\udb84\udc65\udad2\udfb5",
        51, 94252, 343555384, -408899744512861024L, -57286L, true, true, (char) 15972, (char) 41664,
        Double.longBitsToDouble(0x3fe7e85f28ed0d73L), Double.longBitsToDouble(0x3fe6ffb18040c545L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 4, "\uda75\udc86\ud859\udfa3\ud907\udfdd\ud870\udea4\ud9e4\udd93\udb26\udc2d\ud8ac\udc6a\udb25\udc90\udadf\udf71\uda62\ude8d\uda2f\udeaf\u5af3\ud80e\udc6d\uda85\udf7c\uda7c\udece\ud841\ude49\udb84\udc65\udad2\udfb5\u57b9\udb7b\ude8c\udbb9\ude6c\ud968\udf83\udbf0\udd13\uda57\udede\udaaf\ude5b\ud82a\udd81\ud8c3\udd6d\ud9ac\udeba\udbb2\udfc7\ud97b\udee1\udbf5\udf68\ud999\udedf\ud901\udf57", "\uc766\u56d9\u1154\u67f0\u8c33\ua299\u3760\u643c\u215a\u8bbc\u0fae\u2bb6\u012d\uc692\u58b3\u3b21\ucebb", "\uca74\ud98e\udf7a\ud956\udc77\udb53\ude2c\udb2b\udceb\ud9f7\udd90\ud858\udd34\udae9\udef8\udb7c\udf62\ud86b\udc38\udb62\ude2e\udaad\udfcd\ud986\udedc\uda83\udc3b\ud9bd\ude6e\ud9ff\udf49",
        -5, 69236, 362997720, 6196929426619844401L, 78056L, true, false, (char) 25967, (char) 34423,
        Double.longBitsToDouble(0x3fabc2fdb682a1a0L), Double.longBitsToDouble(0x3fba49d899ea46d0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 9, 7, 0, "\uda75\udc86\ud859\udfa3\ud904\udfdd\ud9c8\udcd0", "\ubb52\ucadd\u73d9\u80f2", "\ud80e\udc6d\uda37\ude96\ud90b\uded4\udabd\udf3c\udb84\udc65\udad2\udfb5",
        4, 94206, 343555384, -408899744512861024L, -57286L, true, true, (char) 15972, (char) 41664,
        Double.longBitsToDouble(0x3fe7e85f28ed0d73L), Double.longBitsToDouble(0x3fe6ffb18040c545L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 0, 7, 8, "\uda75\udc12\udb47\udcc9\udb19\udd52\ud9c8\udcd0\uda0b\udec0\uda42\udfba\udbc0\udf56\udb25\udc56", "\ud6a4\u2459\u24a0\u3af1\u05ed\u7424\ub923\ua698\u2527\u3c69\u64f9\u0516\u2a06", "\ud84d\udfdf\udbaf\ude75",
        42, 34885, -1315878675, 9176221767460463906L, -79023L, false, false, (char) 1537, (char) 56725,
        Double.longBitsToDouble(0x3fe8e83c9b3dd8e2L), Double.longBitsToDouble(0x3fc88fe2be579bb4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 7, 0, "\u00a0\udb3c\udf55\000\ud9c6\udca3", "\ubb52\u706c\u73d9\000", "\ud80e\udc6d\uda37\ude96",
        35, 49240, 0, 0L, 46688L, true, true, (char) 5876, (char) 19344,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3fefe5d3420790b9L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 7, 6, 0, "\uda74\udfec", "\u2ffb\uaf97\ua59b\ubb52\u0621", "\uda2f\udeaf\u0311\ud91a\ude4f\uda3b\uded5\ud90b\uded4\udabd\udf3c",
        36, 93384, -1873994011, 6666739975382603951L, -30931L, true, true, (char) 1371, (char) 41664,
        Double.longBitsToDouble(0x3fe7e85f28ed0d73L), Double.longBitsToDouble(0x3feeffb183ca293bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 1, 11, 7, 0, "\udaf9\ude68\ud859\udfe4\ud904\udfdd\ud9c8\udcd0\ud9e4\udd93\udb26\udc2d", "\u1942\u80f2\uaa0c\u9a99\u824e\ucf91\u5e4c\u2874\u4c5a\u442e\ua248", "\ud968\udf6b\udbf0\udd13\uda57\udede\udaaf\ude5b",
        41, 95652, 199561782, 969244775602473197L, 6432L, false, true, (char) 24649, (char) 435,
        Double.longBitsToDouble(0x3fd91ee18708d0fcL), Double.longBitsToDouble(0x3fd54381c161772cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 4, 7, 0, "\uda75\udc86\udaa1\udcba\udb94\udce1\udb6b\udecd", "\ubb6c", "\udb4c\udf8d\uda2f\udeaf\u5af3\ud81b\udd33\uda35\udde1\ud90b\uded4\udabd\udf3c\udb84\udc65\udad2\udfb5\u57c3",
        32, 53384, -95204391, 5444883424525470093L, -69893L, false, true, (char) 41699, (char) 32436,
        Double.longBitsToDouble(0x3fcda1ae6b7fd8c0L), Double.longBitsToDouble(0x3fb0315173c49ba8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 10, 7, 0, "\uda75\udc86", "\u6c20\uc052", "\udb25\udc90\ud909\udf26\ud9b5\udde4\udb8b\udc2f\udb7e\udefa\ud951\udf6b\uda37\ude96\ud90b\uded4\udb8d\udfc4\udb41\udca7\udb4e\udcb3\u57c9\udb7b\ude8c\ufe6f\udb75\udc58\ud974\ude62\u282a\udb56\udc6f\ud9af\ude8c\ud99b\udea5\udb05\udd7f\ud845\uddce",
        57, -41, 1862688832, -6003309607486126545L, -88941L, false, false, (char) 56727, (char) 18979,
        Double.longBitsToDouble(0x3feb67e0d1f67cb1L), Double.longBitsToDouble(0x3fd1b5f6e357b0d4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\012",
        Z.run(T, 1, 0, 0, 0, "", "\u0299\u6c20\uaf6f\ua59bg\000\u73ca\000\000", "\ud8ae\udd93\ud90b\uded4\uda99\udfac\udb84\udc65\udad2\udfb5\u57c3\udb23\uddd1\udbb9\ude6c\ud968\udf83\udbf0\udd13\uda57\udede\udaaf\ude5b\ud82a\udd81\000\000\000\000\udbf5\udf68\ud83f\udc92\ud887\ude67\ud96d\udfba\udb26\udd26\ud907\udf37\ud8e5\udfcb",
        48, 46962, -440286587, 1501155740831262730L, -91587L, false, true, (char) 24413, (char) 51190,
        Double.longBitsToDouble(0x3faffe33eaa32c10L), Double.longBitsToDouble(0x3f9f01553c37e620L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 5, "\uda75\udc86\ud859\udfa3\ud904\udfdd\ud9c8\udcd0", "\ubb52\ucadd\u73d9\u80f2", "\uda01\udca7\u179a\ud90b\ude50\udabd\udf3c\udb84\udc65\udad2\udfb5",
        51, 94252, -832684744, 6424311990510056436L, -57286L, true, true, (char) 15972, (char) 41664,
        Double.longBitsToDouble(0x3fe7e85f28ed0d73L), Double.longBitsToDouble(0x3fe6ffb18040c545L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 7, 0, 7, "\uda75\udc86\ud859\udfa3\ud904\udfdd\ud9c8\udcd0", "\u0467\ucadd", "\uda2f\udeaf\u5af3\ud80e\udc6d\udbf0\udef2\ud937\ude43",
        18, 63706, 1794561384, 2904071217809975468L, 47840L, false, false, (char) 62715, (char) 44851,
        Double.longBitsToDouble(0x3fe3a5e78afd0eddL), Double.longBitsToDouble(0x3fc8b9fb831ff37cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 0, "\uda75\udc86\ud859\udfa3\ud904\udfdd\ud9c8\udcd0", "\ubb52\ucadd\u73d9\u80f2", "\ud80e\udc6d\uda37\ude96\ud90b\uded4\udabd\udf3c\udb84\udc65\udad2\udfb5",
        51, 94252, 343555384, -408899744512861024L, 68613L, true, true, (char) 21286, (char) 41664,
        Double.longBitsToDouble(0x3fe7e85f28ed0d73L), Double.longBitsToDouble(0x3fe6ffb18040c545L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 10, 11, 0, "\uda75\udc86\ud859\udfa3\ud904\udfdd\uda22\udcdd", "\ubb52\u5f50\ub535\u80bc", "\ud80e\udc6d\uda37\ude96\ud90b\uded4\udabd\udf3c\udb84\udc65\udad2\udfb5\u57c3\udb7b\ude8c\udbb9\ude6c\ud968\udf83\udbf0\udd13",
        56, 81602, 1227634197, 8956065879723152005L, -57523L, true, true, (char) 2705, (char) 55266,
        Double.longBitsToDouble(0x3fa403e89de1d760L), Double.longBitsToDouble(0x3fabb0f1c3aaa330L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 7, 6, "\udaf0\udc84\ud859\udfa3\ud904\udfdd\ud9ef\udf22", "\u537e\ucadd\u73d9\u80f2\ud14e\u8f64\u0df3\u2820\u5e4c\ua904\u9736\u6f12\u2527\u0601\u1d7d\u351f\ua62e\ucc84\ud5d1\uc31f", "\u2568\ud8a8\udfd9",
        -4, 77856, -2011536994, 4896760493562590810L, 20559L, false, true, (char) 39839, (char) 51917,
        Double.longBitsToDouble(0x3fe6f011589edffcL), Double.longBitsToDouble(0x3fdb3d5ebe2e4762L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 7, 7, 0, "\uda75\udc86\ud859\udfa3\ud904\udfdd\ud9c8\udcd0", "\u23fb\ucadd\u73d9\uc4cd", "\ud80e\udc6d\ud931\udd0d\ud844\udee2\udbbb\uded5\udb84\udc65\udad2\udfb5",
        54, 94252, 343555384, -408899744512861024L, -57286L, true, true, (char) 15972, (char) 41664,
        Double.longBitsToDouble(0x3fe7e85f28ed0d73L), Double.longBitsToDouble(0x3fe6ffb18040c545L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\012",
        Z.run(T, 1, 6, 6, 0, "\ud80f\udc8f\ud859\udfa3\udb4d\udde3\ud9c8\udcd0", "\ud2a7\u4562\u73d9\u80f2", "\ud80e\udc6d\ud9dd\udca8\udaec\udf78\udbe9\udf47\ud83e\udef7\udbdc\udd00",
        21, 94252, 343555384, 311676195866418336L, 97801L, true, false, (char) 557, (char) 30717,
        Double.longBitsToDouble(0x3fe7e85f28ed0d73L), Double.longBitsToDouble(0x3fe6ffb18040c545L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 10, 7, 0, "\uda75\udc86\ud859\udfa3\ud99b\udf47\ud952\udf28\ud9e4\udde8", "\u8fa6\u73d9\u80f2\ud6a4", "\uda37\ude96\ud90b\uded4\udabd\udf3c\uda46\udfc5\uda5f\udf48\u57c3\udb7b\ude8c\udbb9\ude6c\udb51\udc80\u6fec\ud902\udc4c\udaaf\udde1\ud82a\udd81\ud8c3\udd6d\ud9ac\udeba\udbb2\udfc7\udbea\udc58\udbf5\udf68\udb32\udecc\ud93b\udefd\ud8f1\udcfd\udb00\uddb0\uff97\ud971\udec9",
        39, 63991, -1309070, 293831277870835560L, -11560L, false, false, (char) 53114, (char) 57321,
        Double.longBitsToDouble(0x3f933997a9584a60L), Double.longBitsToDouble(0x3fea5b436e10501cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 7, 8, "\ud92e\udf57\uda35\udcd5\ud905\udc99\ud9c8\udcd0", "\ubb52\ucadd\u73d9\u80f2\ud6a4\ucd4f", "\uda59\udd44\udbbc\udc5f\udbf8\udfdf\udabf\ude72\u57c3\udb55\uddf7\udbb9\ude6c\ud8e1\udc8b\udbf0\udd13\uda48\ude15\ud9a5\ude56\ud82a\udd81\ud8c3\udd6d\ud9ac\udeba\udbb2\udfc7\udbea\udc58\udbf5\udf87\uda11\udf1c\ud8e4\ude9b",
        0, 62751, -1439479433, 1933333856147914178L, -2436L, true, false, (char) 50204, (char) 9489,
        Double.longBitsToDouble(0x3fe6afc284649300L), Double.longBitsToDouble(0x3fed1ba7e9db63a6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 9, 10, 11, "\uda75\udc86\udb95\udf75\ud9ea\udf2e\udbae\uddb4", "\ubb52\ucadd\u73d9\u80f2", "\ud8ea\udf52\uda1d\udf69\ud90b\ude42\udabd\udf3c\udb84\udc65\udad2\udfb5",
        27, -431, 347780797, -408899744512861024L, -57286L, true, true, (char) 27063, (char) 11478,
        Double.longBitsToDouble(0x3fc91bbee3b435ccL), Double.longBitsToDouble(0x3fe6ffb18040c545L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 9, 4, "\uda75\udc86\ud859\udfa3\ud907\udfdd\ud870\udea4\ud9e4\udd93\udb26\udc2d\ud8ac\udc6a\udb25\udc90\udadf\udf71\uda62\ude8d\uda2f\udeaf\u5af3\ud80e\udc6d\uda85\udf7c\uda7c\udece\ud841\ude49\udb84\udc65\udad2\udfb5\udb46\udfca\udb7b\ude8c\uda1b\udedd\ud970\ude6d\udbf0\udd13\uda57\udede\udaaf\ude5b\ud82a\udd81\ud8c3\udd6d\ud9ac\udeba\udbb2\udfc7\ud97b\udee1\ud817\udc6a\ud999\udedf\ud901\udf57", "\uc766\u56d9\u1154\u67f0\u8c33\ua299\u3760\u643c\u215a\u8ccc\u0fae\ud754\u012d\uc692\u58b3\u3b21\ucebb", "\uca74\ud98e\udf7a\ud956\udc77\udb53\ude2c\udb2b\udceb\ud9f7\udd90\ud858\udd34\udae9\udef8\udb7c\udf62\ud86b\udc38\ud83b\udc3b\udaac\udf21\ud986\udedc\uda83\udc3b\ud9bd\ude6e\ud9ff\udf49",
        -5, 69236, 362997720, 6196929426619844401L, 78056L, true, false, (char) 25967, (char) 34423,
        Double.longBitsToDouble(0x3fabc2fdb682a1a0L), Double.longBitsToDouble(0x3fba49d881ea46d0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 9, 7, 8, "\uda75\udc86\ud859\udfa3\ud904\udfdd\udbe2\udf5c\u3d97\uda38\ude0f\udbb6\udc6f", "\u4cb5\ud6a4\u112a\u824e\ucf91\u2d1f\u0b4c\u9709\u9350\ua572\u05d3\u551c\u8154\ua5ef\u9d1c\ud5d1\uc31f\u8819\ubc8e\u2b7f\u154c", "\ud832\udec6\uc1b5\ud81a\udf51\udab7\udc22",
        0, 64963, -1184857839, -4886240410560281948L, 66012L, true, true, (char) 42974, (char) 22554,
        Double.longBitsToDouble(0x3fe9b47cbcaf6406L), Double.longBitsToDouble(0x3fcb029ecaa3d3f8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 0, "\uda75\udc86\ud9fb\ude57\udb5a\ude3f\ud8f5\udd6a", "\u3b52\u9e0f\ubc25\u80f2", "\ud80e\udc6d\udb7f\udd99\udb73\udd6b\udbb1\udedc\ud817\udfc9",
        55, 39556, -603985794, 1475559138549517273L, 25367L, false, false, (char) 62715, (char) 16739,
        Double.longBitsToDouble(0x3f7e42e57e9aba80L), Double.longBitsToDouble(0x3fdd266735be7d44L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 8, "\uda75\udc12\udb47\udcc9\udb19\udd52\ud9c8\udcd0\uda0b\udec0\uda42\udfba\udbc0\udf56\udb25\udc56", "\ud6a4\u2459\u24a0\u3af1\000\ubc6a\ub923\u5c53\000\000\u64d1\u0516\u2a06", "\ud84d\udfdf\udbaf\ude75",
        42, 91077, 0, 1828716544L, -79023L, false, false, (char) 1537, (char) 34453,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4e579bb4000000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 5, "\ud949\udc1c\udb47\udcc9\udb19\udd52\udba7\udf4c\uda07\udeb2\uda42\udfba\udbc0\udf56\udb25\udc37", "\ud6a4\u2459\u24a0\ubbfa\u05ed\u7424\ub923\ua698\u2527\ubd77\u0332\ub309\u2a06", "\udbc4\ude26\udbaf\ude03",
        42, 34885, -1318459219, 9176221767460463906L, -79023L, false, false, (char) 1537, (char) 30700,
        Double.longBitsToDouble(0x3fe3578dc7300e63L), Double.longBitsToDouble(0x3fe2164a9495e6edL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 11, 11, 0, "\ud809\ude17\ud849\udfe1", "\uafef\ua59b\u7e6e\u68ea", "\uda2f\udeaf\u0311\udb3c\udf00\ud971\udf29\ud90b\udee5\udbc0\udcdd\ud8c8\udf42\udac1\udc80\udb4d\udc7a\udaf0\udd7b\ud8ba\udc30\ud8b4\ude46\udafd\udf37\udb59\udf55\ud8e8\udc88",
        8, 74668, 199561735, -4290959590122567582L, 82178L, true, true, (char) 43112, (char) 48138,
        Double.longBitsToDouble(0x3fe5f1bf7eeb0997L), Double.longBitsToDouble(0x3fe710c2e724b4b1L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 6, 6, 0, "\udbe8\udc32", "\u892a\uafdb\ua59b\ubb52\u0621", "\uda26\uddca\ud8eb\udd3b\ud91a\ude68\uda3b\uded5\ud90b\uded4\udabd\udf3c",
        8, 79153, -1873994011, 6666739975382603951L, -62976L, true, true, (char) 38075, (char) 22866,
        Double.longBitsToDouble(0x3fefe40afa0790b9L), Double.longBitsToDouble(0x3fe7e85f2d3b0d73L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 0, "\uda75\udc86\ud859\udfa3\ud904\udfdd\ud9c8\udcd0", "\ubb52\ucadd\u73d9\u80f2", "\ud80e\udc6d\uda37\ude96\ud9b0\udf87\ud9a5\udfb5\ud80d\udc78\udad2\udfb5\udbce\udc7f\udb7b\ude33\ud972\udcc8\uda5e\uddd8\udbec\udcab\ud857\uddde\udb0d\udf58\uda48\udc7d\ud8c3\udd56\ud9ac\udeba",
        17, 21237, -985298209, -6695057967158493456L, -68036L, true, true, (char) 31370, (char) 64804,
        Double.longBitsToDouble(0x3fe2edd44adc7eeeL), Double.longBitsToDouble(0x3fd9e751e2241a7eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null\0121=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\012",
        Z.run(T, 2, 10, 3, 0, "", "", "\ud9de\udce8\ud8e0\udc98\udbd6\udeb2\ud8f9\udc1c\017\udb4c\udf8d\uda2f\udded\u5af3\ud80e\udc6d\uda37\ude96\ud90b\uded4\udabd\udf3c\ufda2\uda5f\udf48\u02c3\udb7b\ude8c\u3d38\000\u538a\ud901\udf50\udaaf\udde1\000\ud90c\ude62\ud9a8\udcba\udbb2\udfc7\udb46\udc02\000\000\000\000",
        -5, -1000, 12336384, 59359433032990720L, -100000L, false, false, (char) 232, (char) 0,
        Double.longBitsToDouble(0x3fcf9687c003abc8L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 0, "\uda75\udc86\ud859\udfa3\ud9ce\udcc1\udbaf\udc02", "\ubb52", "\udb4c\udf8d\uda2f\udeaf\udbe4\uddf2\ud901\ude06\uda37\ude96\ud90b\uded4\udabd\udf3c\udbe6\udd51\ud8f5\udf28\ud9cc\ude59",
        32, 30728, -1316777291, 5437329997448486436L, 91993L, true, false, (char) 22112, (char) 33039,
        Double.longBitsToDouble(0x3fb031517c66fbe8L), Double.longBitsToDouble(0x3fd6c0fcc053a8bcL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null\0121=java.nio.HeapByteBuffer:java.nio.HeapByteBuffer[pos=0 lim=0 cap=0]\012",
        Z.run(T, 2, 10, 3, 0, "n", "\uabb0", "\udbd6\udeb2\ud8f9\udc1c\ud8d2\udd97\udb4c\udf8d",
        9, 50789, -806167742, -8126449499484512108L, 99262L, true, true, (char) 27276, (char) 4345,
        Double.longBitsToDouble(0x3fd38dbff0000000L), Double.longBitsToDouble(0x3e3001e070000000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 0, "", "", "\ud9de\udce8\ud8e0\udc98\udbd6\udeb2\ud896\udd8a\017\udb4c\udf8d\uda2f\udded\u5af3\ud80e\udc6d\uda37\ude96\ud90b\uded4\udabd\udf3c\ufda2\uda5f\udf48\u02c3\udb7b\ude8c\u3d38\000\ud997\udc52\ud901\udf50\udaaf\udde1\000\ud90c\ude62\ud9a8\udcba\udbb2\udfc7\udb46\udc02\udb36\udf1b\u00cc\000\uda21\udd6f",
        18, -1000, 12336384, -3701669621537709620L, -100000L, false, false, (char) 232, (char) 0,
        Double.longBitsToDouble(0x3fcf9687c003abc8L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 4, "n", "\uabb0", "\udbd6\udeb2\ud8f9\udc1c\ud8d2\udd97\udb4c\udf8d",
        9, 60235, -674603085, 4795900603506303185L, -37118L, true, false, (char) 27276, (char) 4345,
        Double.longBitsToDouble(0x3fd38dbff8000000L), Double.longBitsToDouble(0x3fd73ba83f60f5dcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|parseInputStream|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|crossStreams|java.io.InputStream,java.io.OutputStream|static",
    "M|org.jsoup.helper.DataUtil|detectCharsetFromBom|java.nio.ByteBuffer|static",
    "M|org.jsoup.helper.DataUtil|emptyByteBuffer||static",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|mimeBoundary||static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream,int|static",
    "M|org.jsoup.helper.DataUtil|validateCharset|java.lang.String|static",
    "C|org.jsoup.helper.DataUtil|<init>|",
    "M|org.jsoup.helper.DataUtil|parseInputStream|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
