package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class HttpConnection_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 1, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 1, 12, "\ud9b1\uded1\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud830\udeaf\ud993\ude40\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\uda31\udd04\ud8cc\uddcd\ud9ba\ude0c", "\u81a0\uc283\ua653\u0bbc\u1b89\u10ec\ubdde\u1faa\u30f0\u879a\u982e\u9089\u6af8", "\ud9a1\ude20\ud8bf\udfd2\udac8\ude3d\udbd5\udda4\ud891\udfd1\udb11\udf1e\ud91f\udedf\ud928\udd2b\udbcb\udc84\uda11\uddbb\ud821\udcae\ud8a0\udcec\udbd5\udc8d\ud940\udd47\udb18\udfad\ud955\udc86\ud896\udeaf\ud915\udfba\udbd6\udf5a\udb9c\udfc3\udb45\ude0e\ud89c\udf83\uda7b\udce9\ud90f\udda3\udaf9\udda3\uda68\udebc",
        26, 51243, -1691463321, 9201899165213214126L, -63657L, true, false, (char) 4968, (char) 62479,
        Double.longBitsToDouble(0x3faa8d64b1e2b9f0L), Double.longBitsToDouble(0x3fef0e69f33f2a93L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 1, 3, 1, 12, "\ud996\ude79\ua834\udab5\ude40\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud84b\udc1c\ud9f8\udd3a\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda83\uddf1", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc50\u879a\ud00a\u9ec3\u593e\u2c67\uc5de", "\udac8\ude3d\ud95c\udf73",
        46, 5811, 336825423, -5363163831998504915L, 884L, false, true, (char) 13314, (char) 5782,
        Double.longBitsToDouble(0x3fdf55e47ad8a06eL), Double.longBitsToDouble(0x3fcf1773f0f5b17cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 13, 2, "\ud996\ude79\ud902\udc7b\udab5\ude10\ud8e0\udf33\ud956\udcf9\uda40\ude1a\udabe\udcb7\uda44\udcf9\ud8df\ude75\ud8d2\udcff\ud8a6\udd31\ud9af\ude0b\uda3c\udcac\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u8b7c\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u312c\u593e\u2c67\u7408\u62f4\u9493\u3697\u573f\uba82\u8192\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        30, 33405, -131540398, -3648335573042701148L, 34322L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 1, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\ud9a0\udc2b\ud932\ude71\ud983\udc93\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c", "\udb51\udf68\uda8f\uded1\ud85e\ude8c\udb68\ude02\uf82e\uda90\udc6f\udba9\ude34\ud927\udd8e\ud9a4\udfc4\udb3f\udddc\uda83\udcb1\ud8c0\udc35\udac8\ude3d\ud95c\udf73\ud891\udfd1\udb11\udf1e\udb81\udd7d\ud848\ude86\u8fcb\ud99f\udd8c",
        25, 90961, -1572500972, -3164988345979871250L, -50072L, true, false, (char) 42038, (char) 30824,
        Double.longBitsToDouble(0x3fec9434a5400145L), Double.longBitsToDouble(0x3fd9ebd2f7528882L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\udb1e\udcfb\ua834\udab5\ude20\ud8ac\udfd9\ud84a\udc36\ud875\udf72\ud84d\udcbe\ud9a3\udca4\uda5f\udc9a\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud9a8\uddc3\ud887\udcd3\uda66\ude47\udad4\udf34\ud841\udcb6\u1b48\udb2f\udd06\012",
        Z.run(T, 1, 10, 11, 4, "\udb1e\udcfb\ua834\udab5\ude20\ud8ac\udfd9\ud84a\udc36\ud875\udf72\ud84d\udcbe\ud9a3\udca4\uda5f\udc9a\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud9a8\uddc3\ud887\udcd3\uda66\ude47\udad4\udf34\ud841\udcb6\u1b48\udb2f\udd06", "\u1b89\ub049\u72a4\ua08d\u6bf3", "\ud926\udcd1\ud927\uddf0\ud9b6\ude23\udb01\udf7c\udb24\udc58",
        37, 60535, -300948350, -774961949799214828L, 45129L, true, false, (char) 37745, (char) 55241,
        Double.longBitsToDouble(0x3fcc28709b7dede4L), Double.longBitsToDouble(0x3feef515f7eed413L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 1, 8, 1, 12, "\ud996\ude79\u4ed0\ud96b\udcba\ud8ef\udfe6\ud8fe\udd6b\ud999\uddca\udabe\udcb7\ud81d\udd65\uda87\udf62\ud8f8\udef1\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u77f2\u593e\u2c67\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud92d\udd0b\udb4c\udc54\ud8a5\udfd3\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6e05f9aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 1, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u48e7\u70f0\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 9, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabc\udeb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\ud996\ude79\uda4a\udd43\udab5\uddca\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02\012",
        Z.run(T, 1, 9, 13, 12, "\ud996\ude79\uda4a\udd43\udab5\uddca\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\ucb82\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbf6\udc5c\ud95a\udf96",
        24, 4392, 1345814005, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 1, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd671c2f4f74634L), Double.longBitsToDouble(0x3fedc14736635f9aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 4, 5, "\ud996\udea0\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud924\udc48\ud8df\uddab\ud96c\udd2d\ud8a6\udd31\ua44c\ud8be\udfaa\ud945\udf12\ud862\udd4f", "\ub503", "\udacc\udd0d\udbcf\ude36\uda55\ude4b\ud936\ude42\uda8f\uded1",
        29, 31434, 1302287259, 6116789271814488681L, -87958L, false, true, (char) 45987, (char) 23228,
        Double.longBitsToDouble(0x3fe8a1a0c5fe995cL), Double.longBitsToDouble(0x3fcdcccfacee0a24L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 1, 5, 1, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u9191\u4d29\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 2, 2, "\ud99f\udeb9\ua834\ud9d2\udf6e", "\u6cd4\u5052\u160e\u4d2a\u5bd0", "\ud8be\udfaa\ud945\udf12\ud862\udd4f\ud87a\udf63\ud871\udd69\ud841\udcb6\u1b48\ud89b\udf85\udbec\udc31\ud8eb\udc23\ud942\ude9c\ud936\ude42",
        -2, 46973, -111642944, 5602868449184527215L, 86455L, true, true, (char) 64752, (char) 26531,
        Double.longBitsToDouble(0x3fed39f3863f4d4dL), Double.longBitsToDouble(0x3fc048794f9b483cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 1, 14, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\udb29\udc12\ud918\ude17\ud89d\udd82\ud92e\udfa7\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd57",
        25, 90961, -1572500972, -3164988345979871250L, -50072L, true, false, (char) 42038, (char) 30824,
        Double.longBitsToDouble(0x3fef90fa1d40254dL), Double.longBitsToDouble(0x3fd9ebd2f7528882L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 1, 14, 11, 2, "\udb25\udcc6", "\u0d3e\u9721\u1917\u399a\u7774\u2b18\u903b\u302a\u77a3\u8d85", "\udafa\udd59\uda33\udf50\ud841\udcb6\u1b48\ud939\udd0b\udaca\udf7d\ud940\udfee\udbd8\udf85\ud936\ude42\uda8f\uded1\ud93b\udccf\ud9b6\udf49\uf82e\uda90\udcb2\udba9\ude34\ud809\udf40\ud9c4\uddf3\udb4c\udea2\u1423\ud8c0\udc35\udac8\ude3d\ud95c\udf73\ud891\udfd1\udb11\udf1e\ud998\udc8b\ud848\ude86\u5b05\udaaf\udeec\udb71\udef6\ud980\udfcf",
        37, 5719, 766260168, 3918040019361502998L, -91967L, true, false, (char) 33238, (char) 54632,
        Double.longBitsToDouble(0x3f9eed6de80028a0L), Double.longBitsToDouble(0x3feab7b725fd435dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 9, 1, 12, "\ud996\ude79\ua834\udab5\ude20\ud90b\uddfa", "\u3670\ud38a\u6b89\u39da", "\ud8be\udfd3\ud947\udfaa\ud862\udd4f\uda66\ude02",
        56, 76170, -202682879, 4445793530420246169L, -26206L, false, false, (char) 7045, (char) 49896,
        Double.longBitsToDouble(0x3fc811bde2c35680L), Double.longBitsToDouble(0x3feb7a6b67a154e3L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345813858, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 1, 4, 6, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u161d\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6698007766946065249L, -25123L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 5, 8, 4, "\ud996\ude79\ua834\udab5\ude0c\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\uda73\uddf2\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8bd\udc9c\udbf4\udd4c\ud8be\udfaa\u639c\ud8c0\udfd1\ud90e\udf40", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u0fc2\u2c67\uc5de", "\ud9f4\udc5c\udbd3\ude9e\ud891\udfd1\udb11\udf1e\ud8c1\ude3e\udbb2\udcd9\u8fcb\ud99f\udd8c\u5e41",
        13, 4324, -736906311, 4584206948098365176L, -55436L, false, false, (char) 41116, (char) 42038,
        Double.longBitsToDouble(0x3fe55e2deb928694L), Double.longBitsToDouble(0x3fd400145d3d7a5eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 7, 4, 4, "\ud996\ude79\ud95e\udf92\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8fc\ude33\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\uba25\u7f96\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\ub99a\ud00a\u9ec3\u593e\u2c67\uc5de\u1276\u8f45\ua39f\ubb8f\ubb36\u3d83\u5c1a", "\ud99f\udd8c\ud8c4\udf20\udbfd\udd18\ub8a1\ud8d0\udc26",
        4, 4392, 1345814005, -6962312770077377288L, -25123L, true, false, (char) 45606, (char) 34238,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 1, "\ud996\ude79\ua834\udab5\ude40\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\u29c8\uda03\udeee\ud9e8\udd3a\udbf4\udd4c\ud8be\udfaa\ud945\udf12\udaa9\udf73\uda83\ude85", "\u81a0\uc283\uae45\u9204\u76e1\u10ec\ua080\u2494\u3b3f\u1ad2\ud00a\u9ec3\u593e\u2c67\u8a04", "\udac8\ude3d\ud95c\udf73\udb56\udc55\udb11\udf1e\udb81\udd7d\ud848\ude86",
        59, 9778, 1132750990, -8934467795251208543L, 6514L, false, false, (char) 56380, (char) 13405,
        Double.longBitsToDouble(0x3fcf177b15e9b17cL), Double.longBitsToDouble(0x3fce7f60cd49d574L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 1, 12, "\ud996\ude79\udaf8\udc14\udbc3\udd1d\ud9d7\udeed\ud9c3\udfff\udb19\udd9c\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud84b\udc1c\ud9f8\udd3a\ud87e\udd51\ud8be\udfaa\ud945\udf12\ud862\udd4f\u62d9", "\u81a0\uc283\u863c\u4fa7\u0a24\u2858\u0bed\u0d4b\ucc50E\u403c\ud272\u40a5\u4be4\u4b54", "\udac8\ude3d\ud95c\udf73\ud891\udfd1\udb11\udf1e\udb81\udd5a\ud848\ude86\ud89d\udfc7\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47\udb18\udfad\ud955\udc86\ud896\udeaf\ud95f\ude9f\udbd6\uded2\udaaf\ude2c\ud839\uddae\uda02\udc55\udb8d\udfb1\uda19\udd50\ud9d3\udcfd\ud957\udc9a\ud980\ude83\ud823\udd21\udbb1\udd92\ud93f\uddf8\udada\udc64\udaa1\ude87\ud8cf\udc4d\ud94f\udd8a\ud8c1\udc55\ud8c3\udc20\ud8de\udd98\ud92a\udc34\ud9ad\udfb2",
        6, 98703, 863919375, 6335224834185812181L, 41332L, false, false, (char) 20726, (char) 45311,
        Double.longBitsToDouble(0x3fe8d29a4aff85dfL), Double.longBitsToDouble(0x3febc25e0cda563dL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 4, 2, 2, "\ud9b4\udcba\udb9f\udef2", "\u6cf7\u2062\u5094", "\ud84b\udc1c\ud9f8\udd3a\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud8d8\udcba\uda83\uddf1\ud808\udf66\ud841\udcb6\u1b48\ud972\udf74\ud8fa\udf2c\udaad\udc3d\uda16\ude54\u1a2c\uda8f\uded1\ud85e\ude8c\udaee\udf18\uf82e\uda90\udc6f\u490a\uda5c\ude84\ud9b6\ude23\udb3f\udddc\u616d\ud80e\udc9d\udb76\ude19\ud95c\udf73\ud891\udfd1\udb11\udf1e\uda54\uddb7\udada\udd5b\ud879\ude15\ud9b6\udcf7\ud854\udc37\uda4f\ude79\udb68\uddc8",
        21, 63144, 1581766328, 5780227136826631532L, 44445L, true, true, (char) 57060, (char) 28364,
        Double.longBitsToDouble(0x3fe0cb5fa7c80e85L), Double.longBitsToDouble(0x3fe96f65f4fd8546L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 10, 14, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\ud9a0\udc2b\ud932\ude71\ud983\udc93\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c", "\udb51\udf68\uda8f\uded1\ud85e\ude8c\udb68\ude02\uf82e\uda90\udc6f\udba9\ude34\ud927\udd8e\ud9a4\udfc4\udb3f\udddc\uda83\udcb1\ud8c0\udc35\udac8\ude3d\ud95c\udf73\ud891\udfd1\ud9b6\udd13\uda69\udf9e\ud848\ude86\u8fcb\ud99f\udd8c",
        22, 89429, -1572500972, -3164988345979871250L, -2219L, false, true, (char) 49236, (char) 41116,
        Double.longBitsToDouble(0x3fbf5fee555e2de8L), Double.longBitsToDouble(0x3fec9434a5400145L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 6, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\ud9a0\udc2b\ud932\ude71\ud983\udc93\ud8df\uddab\ud8d2\udcff\udb4b\udee4\ud813\udd0b\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c", "\udb51\udf68\uda8f\uded1\ud85e\ude8c\udb68\ude02\uf82e\udbdc\udf13\uda67\udede\ud927\udd8e\ud9a4\udfc4\udb3f\udddc\uda83\udcb1\ud8c0\udc35\udac8\ude3d\ud95c\udf73\ud891\udfd1\udb11\udf1e\udb81\udd76\ud848\ude86\u8fcb\ud99f\udd8c",
        35, 90961, -1572500972, -3164988345979871250L, -50072L, true, false, (char) 42038, (char) 30824,
        Double.longBitsToDouble(0x3fec9434a5401f1dL), Double.longBitsToDouble(0x3fecf5e97868005eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 10, "\udb1e\udcfb\ua834\udab5\ude20\ud8db\udca6\udb98\uddd1\ud871\udcc8\ud84d\udcbe\ud9a3\udca4\uda5f\udc9a\ud8d2\udcff\udaed\uded5\udbe2\udd03\ud8a6\udfaa\ud8db\udebe\ud8e7\udce1\uda78\udff5\udad4\udf34\ud841\udcb6\u1b48\udb2f\udd06", "\u1b89\ub049\u72a4\ua08d\u6bf3\u879a\ud00a\ud5ef\u1bc5\u2c67", "\ud8c0\udc35\udac8\ude3d\ud95c\udf73\udaed\udf93\udbb9\udf6d\udb81\udd7d\ud848\ude86\u8fcb\udbd5\udd87\uda3f\ude3d",
        59, 38543, -736906274, 7957684543134107521L, -44371L, false, false, (char) 1994, (char) 17883,
        Double.longBitsToDouble(0x3fecc3843b52984cL), Double.longBitsToDouble(0x3fc7e59d4ac902ccL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 14, "", "\u140c", "\udb0f\udd63~\ud81d\udd65\ud8df\uddab\ud8d2\udcff",
        3, 47396, -449014466, 279188982488L, -100000L, false, true, (char) 18909, (char) 42757,
        Double.longBitsToDouble(0x3ec6400000000000L), Double.longBitsToDouble(0x3fedf7d800000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\ud976\udd89\ud9a0\ude40\ud9b6\udd9e\ud901\ude4f\ud8fe\udd6b\udb0f\udd63\udabc\udeb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\udbe2\udcaf\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02\0121=java.lang.String:\ud976\udd89\ud9a0\ude40\ud9b6\udd9e\ud901\ude4f\ud8fe\udd6b\udb0f\udd63\udabc\udeb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\udbe2\udcaf\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02\012",
        Z.run(T, 2, 9, 9, 10, "\ud976\udd89\ud9a0\ude40\ud9b6\udd9e\ud901\ude4f\ud8fe\udd6b\udb0f\udd63\udabc\udeb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\udbe2\udcaf\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u4c99\uc283\u863c\uba2e\u1b89\u10ec\ua080", "\uff2e\uda90\udc6f\udba9\ude34\ud927\udd8e\ud9b6\ude23\ud9d6\udd1d",
        58, 54825, 1137325597, -1292563323140083914L, -97635L, false, false, (char) 21951, (char) 50388,
        Double.longBitsToDouble(0x3fe21dac34e14384L), Double.longBitsToDouble(0x3fd201c137bdafd4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\ud996\ude79\uda4a\udd43\udab5\uddca\ud843\udcc4\udb19\uddb4\udb0f\udd8f\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 13, 12, "\ud996\ude79\uda4a\udd43\udab5\uddca\ud843\udcc4\udb19\uddb4\udb0f\udd8f\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\ucb82\uc5de", "\udac8\ude3d\ud95c\udf73\ud891\udfd1\udb11\udf1e\udb81\udd7d\ud848\ude86\u8fcb\ud99f\udd8c\uda3f\ude3d",
        16, 83220, 2072192079, 4584206325328107256L, -41268L, false, false, (char) 41116, (char) 42038,
        Double.longBitsToDouble(0x3fe55e2deb928694L), Double.longBitsToDouble(0x3fd40014533d7a5eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud88c\udc59\ud84d\ude31\udab7\udf0d", "\u2062\u5094\u9164\u4c5b\u99c8", "\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02\ud9f3\uded3\ud8bc\udf1d\uda3d\udfc2\udb2f\udd06",
        9, 79107, 1865605054, 7080076941921080900L, -37438L, true, true, (char) 33038, (char) 38732,
        Double.longBitsToDouble(0x3fb5d01b07b56588L), Double.longBitsToDouble(0x3fd36ae7f8eb8e5cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 0, 5, "\ud996\udea0\ua834\udab5\ude20\ud8e0\udf33\udb0a\udd7e\udb0f\ude1f\udad9\ude26\ud924\udc48\ud8df\uddab\ud96c\udd2d\ud8a6\udd31\ua44c\ud8be\udfaa\ud945\udef8\ud892\udd47", "\ub55a", "\udacc\udd0d\udbcf\ude36",
        21, 86176, -2119969268, 7705449253868467298L, 41271L, false, false, (char) 30645, (char) 45987,
        Double.longBitsToDouble(0x3fdd8e0e3e286830L), Double.longBitsToDouble(0x3fdfe995c1dcccfaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=null\012",
        Z.run(T, 2, 5, 10, 7, "\ud97d\udc11\ua82f\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\udaa2\udc87\ud8df\ude5d\ud96c\udd2d\ud8a6\udd31\ua44c\ud8be\udfaa\ud945\udf12\ud862\udd4f", "\ub503", "\udacc\udd0d\udbcf\ude36\uda55\ude4b\ud936\ude42\udbcd\uddd0",
        29, 31434, 1302287259, 6116789271814477161L, -87958L, false, true, (char) 46083, (char) 23228,
        Double.longBitsToDouble(0x3fe8a1a0c5fe995cL), Double.longBitsToDouble(0x3fcdcccfacee0bd8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 0, 5, "\ud996\udea0\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\ud989\udd60\udabe\udcb7\ud924\udc48\ud8df\uddab\ud96c\udd2d\ud8a6\udd31\ua44c\ud8be\udfaa\ud945\udf12\ud862\udd4f", "\ub503", "\udacc\udd0d\udbcf\ude36",
        9, 36872, 888680772, 7705449575991014498L, 20919L, false, false, (char) 30645, (char) 45987,
        Double.longBitsToDouble(0x3fdd8e0e3e286830L), Double.longBitsToDouble(0x3fdfe995c1dcccfaL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 6, 12, "\ud996\udea0\ucf34\udab5\ude20\ud8e0\udf33", "\u5094\u9164\u3470\u2691", "\ud8be\udfaa",
        57, 24962, 1155448888, 8218549243700463130L, -23657L, true, true, (char) 52711, (char) 57056,
        Double.longBitsToDouble(0x3fd9b6f84c896068L), Double.longBitsToDouble(0x3fd4581a38c4d5deL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 4, 5, 13, "\ud961\udfc7\ua834\udbb2\ude5e\ud9c7\uddfc\ud89f\uddef\udb0f\udd63\udabe\udcb7\ud9e0\udd93\ud85d\udd46\ud96c\udd2d\ud8a6\udd31\ua44c\ud8be\udfaa\ud945\udf12\ud9e2\udf6f\uda66\udea9\ud9f3\uded3\ud8bc\udf1d\udb03\ude85\udb30\udd88\udacc\udd0d\udbcf\ude36\uda55\ude4b\ud936\ude42\uda8f\uded1\ud8ed\udf92\udaee\udeb9\ud82c\udc4e\udac3\udfc9\udbb0\udc31\ud8a4\udf6e\ud999\udc28", "\u6796\ubd6d\ub776\ub63c\uc0e9\u8875\u8270\ua7f2\u9bef\uc991\u9b58\u4d0c\u5e97\ua670\u7cb4\u6319", "\udad6\udfed\udba1\udfe0\udb78\uddb5\udbfb\udc1a\ud89d\ude39\ud9e6\udc34\udb11\uddfc\ud909\udf53\ud82f\ude89\udaf0\udd36\uda2f\ude5c\ud9a4\udf7b\ud984\udcbb\udb44\udd51",
        6, 63377, 1834200120, 7539314497163528484L, 9093L, true, false, (char) 21688, (char) 29096,
        Double.longBitsToDouble(0x3fe1879518868e7cL), Double.longBitsToDouble(0x3fd17f8c350c2cd6L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 3, 3, 12, "\ud996\udea0\udbc1\ude9e\udab5\ude20\ud88f\udfea\ud911\uddde\udb0f\udded\udabe\udcb7\ud80a\udf19\udb39\udd0a\ud96c\udd2d\ud8a6\udd31\uda5a\udf2e\ud8be\udfaa\uda52\udf0e\udbef\udd53\uda60\ude45\ud9f3\uded3\ud8bc\udf1d\uda3d\udfc2\udb2f\udd06\uda1a\udcc3\udbcf\udeba", "\u5443\u4802\ubba4\ud312\ud00a\u70bc\u65db\u885d\uc5de\u3395\u8ee1\ubd83\ub776\u1c3b\ub248\u2514\ub869\u6514\ud467", "\ud9d5\udfb4\udbb6\udfe9\ud8a6\udc91\udb14\ude6e\udb72\udc22\ud88f\ude58\udbd1\ude43\udb00\udc1e\uda67\uddcf\udab0\udd7b\ud912\udc3f\uda65\udca2\uda41\ude32\udb1d\udc04\ud9aa\udc28\udb65\ude36\ueca4",
        19, 48820, 1174171332, -6959832922702997334L, -69506L, false, true, (char) 5194, (char) 43732,
        Double.longBitsToDouble(0x3feee92720ec4e8eL), Double.longBitsToDouble(0x3fdb88091725fc18L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 3, 8, 1, "\ud996\udea0\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\uda77\udd76\udabe\udcb7\ud924\udc48\ud8df\uddab\ud96c\udd2d\ud8a6\udd31\ua44c\ud8be\udfaa\ud945\udf12\ud862\udd4f", "\ub503", "\udacc\udd0d\udbcf\ude36\uda55\ude4b",
        42, 19788, 1794064709, 7755467261378253723L, -59959L, true, true, (char) 32167, (char) 30645,
        Double.longBitsToDouble(0x3fbd71cb8ec70718L), Double.longBitsToDouble(0x3fe8a1a0c5fe995cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 5, 5, 12, "\udb2b\udc69\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\ud87d\ude97\ud81d\udd5e\ud8df\uddab\ud8d2\udd73\ud8a6\udd31\ud97d\udd5e\ud97a\udf7f\udb8d\udee6\ud862\udc8d\uda66\ude02", "\u81a0\uc283\uabe8\u7178\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u59bc\u2c67\uc5de\u9191\u4d29\u3697\u573f\uba82\u8175\u5c1a", "\ud9fe\udf7b\uda3f\uddfe\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6962312770077377288L, 40413L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fe4f5e97ba94441L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 7, 1, "\ud99f\udeb9\ud858\udd0a\ud9d4\udd08", "\u6dbb\u5052\u685f\u4d2a\u5bd0", "\ud8be\udfaa\ud9f3\ude8f\ud862\udcdf\ud885\ude6f\ud871\udd69\ud841\udcb6\u1b48\ud89b\udf85\ud9fb\udfb9\uda72\udf81\udbe3\udf7c\u71a6",
        3, 75370, -111642944, 5602868449184527215L, 86455L, true, true, (char) 47396, (char) 26531,
        Double.longBitsToDouble(0x3fed39f382173280L), Double.longBitsToDouble(0x3fc05513ef9b483cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud978\uddda\ud8ae\udc2c\ud9d2\udf6e\ud901\udfae\ud8fe\udd6b\udb70\udf93\udabe\udc75\u07b8\ud8df\ude7a\ud9c4\udc27\ud8af\uddd0\u3791\ud8be\udfaa\ud945\udf12\ud862\udd4f\ud87a\udf63\ud871\udd69\ud841\udcb6\u1b48\ud89b\udf85\udbec\udc31\ud8eb\udc23\ud942\ude9c\ud936\ude42", "\ucedc\ud752\ud00a\u9ec3\ub4dc\u2c67", "\ud8c0\udc35\udac8\ude3d\udbce\uddcc\ud864\udc1c\udb43\udc72\udb5e\udfb2\udaa1\ude2d\ud8e6\udef9\ud8ea\udc57\ud94e\udeeb\udb6c\udebc\ud922\udc5d\ud873\udc5a\ud876\udc04\ud9ce\udc5d\ud988\udd6e",
        4, 94839, 2096130405, 7293949921757926040L, 10449L, true, false, (char) 36986, (char) 34417,
        Double.longBitsToDouble(0x3fd92e4a72e8bfe0L), Double.longBitsToDouble(0x3fec78302699e092L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 2, 7, "", "\u1eb8\u3594", "\udabe\udc75\u07b8\ud8df\ude7a\ud9c4\udc27",
        32, 73576, -449014466, 3445399129209293528L, -7301L, false, true, (char) 18909, (char) 26118,
        Double.longBitsToDouble(0x3fd27f13b3666744L), Double.longBitsToDouble(0x3f70a5863c37f480L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 12, 12, 4, "\ud99f\udeb9\ua834\ud9d2\udf6e", "\u6cd4\u5052\u160e\u4d2a\u5bd0", "\ud8be\udfaa\ud945\udf12\ud862\udd4f\ud87a\udf63\ud871\udd69\ud841\udcb6\u1b48\ud89b\udf85\udbec\udc31\ud8eb\udc23\ud942\ude9c\ud947\udd6c",
        45, 46973, -111642944, 5602868449171485551L, 86542L, true, true, (char) 64752, (char) 26531,
        Double.longBitsToDouble(0x3fed39f3863f4d4dL), Double.longBitsToDouble(0x3fc04861ef9b483cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 7, 2, "\udaa9\udccb\ua834\ud9d2\udf6e", "\ub6d4\ub313\u12b8\u4d2a\u5bd0", "\udb5d\udc5c\udbe4\ude3b\ud862\udd4f\ud87a\udf63\ud871\udd69\uda85\udd97\u1b48\ud89b\udf85\ud8a7\ude4f\ud8eb\udc23\ud942\ude9c\uda50\ude6f",
        44, 81408, 1044574493, 6225733028431622083L, 86455L, true, true, (char) 64752, (char) 26491,
        Double.longBitsToDouble(0x3fed39f3863f4d4dL), Double.longBitsToDouble(0x3fc048794d70058cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 9, 10, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\ud9b9\udeb9\ud932\ude2a\ud983\udc93\ud8df\uddab\ud8d2\udcff\udb4b\udee4\ud813\udd0b\ud8be\udfaa\ud945\udf12\ud8ea\ude13\u3720", "\u81a0\uc283\u863c", "\udb51\udf68\uda8f\uded1\ud85e\ude8c\udb68\ude02\uf82e\udbdc\udf13\uda67\udede\ud927\udd8e\ud9a4\udfc4\udb3f\udddc\uda83\udcb1\ud8c0\udc35\udac8\ude3d\ud95c\udf73\ud891\udfd1\udb11\udf1e\ud997\udf3d\ud85f\ude85\u8fcb\ud99f\udd8c",
        35, 90961, -1572500972, -3164988345979871250L, -50072L, true, false, (char) 42038, (char) 30824,
        Double.longBitsToDouble(0x3fec9434a5401f1dL), Double.longBitsToDouble(0x3fecf5e97868005eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\udb1e\udcfb\ua834\udb7c\udee3\ud8d1\udd5f\udb98\uddd1\ud871\udcc8\ud84d\udcbe\ud9ba\ude01\uda5f\udc9a\ud8d2\udcff\ud8bf\udeff\ud819\udd31\ud8a6\udfaa\ud8db\udebe\ud8e7\udce1\uda78\udff5\udad4\udf34\ud841\udcb6\u1b48\udb2f\udd06\0121=java.lang.String:\udb1e\udcfb\ua834\udb7c\udee3\ud8d1\udd5f\udb98\uddd1\ud871\udcc8\ud84d\udcbe\ud9ba\ude01\uda5f\udc9a\ud8d2\udcff\ud8bf\udeff\ud819\udd31\ud8a6\udfaa\ud8db\udebe\ud8e7\udce1\uda78\udff5\udad4\udf34\ud841\udcb6\u1b48\udb2f\udd06\012",
        Z.run(T, 2, 10, 10, 10, "\udb1e\udcfb\ua834\udb7c\udee3\ud8d1\udd5f\udb98\uddd1\ud871\udcc8\ud84d\udcbe\ud9ba\ude01\uda5f\udc9a\ud8d2\udcff\ud8bf\udeff\ud819\udd31\ud8a6\udfaa\ud8db\udebe\ud8e7\udce1\uda78\udff5\udad4\udf34\ud841\udcb6\u1b48\udb2f\udd06", "\u1b2c\ub049\u31a4\ua08d\u293c\u879a\u10b1\u061f\u1bc5\u2c67", "\uda31\udc2f\udac8\udeb5\uda92\udebc\ud9ac\ude31\udbb9\udf6d\udb81\udd7d\ud994\ude8c\u8fcb\udbd5\udd87\ud8e1\ude6a",
        59, 38543, -736906274, 7957684543134107521L, -44371L, false, false, (char) 1994, (char) 17883,
        Double.longBitsToDouble(0x3fecc3843b52984cL), Double.longBitsToDouble(0x3fc7e59d4ac902ccL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 14, 14, 8, "\ud91c\udd3a\ua834\udab5\ude20\uda46\udfe8\uda39\udc9c\udbab\udc2d\uda51\udd62\ud924\udc48\ud8df\uddab\ud923\udd9a\udb00\udd25\u3ac0\udb48\udf2f", "\uc74f\u31f1\ub7d6\u1f45\u4591\u863c\u7122\u982d\u9b3d\ua048\uc3e7\ucc54\u879a\u6e36\ua0fc\u432c\u43ac\uc5de\u6879", "\ud856\udff7\ud943\udd99\ud834\udddc\ud823\ude21\uda41\udc9b\udb39\ude97\ud8eb\udcf1\ud891\ude2e\ud892\ude50",
        40, 74501, -1413766421, 2709613106156556265L, -3644L, true, true, (char) 55285, (char) 41441,
        Double.longBitsToDouble(0x3fde8c77c1be9fd2L), Double.longBitsToDouble(0x3fe7bdd39904cb30L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 9, 9, 7, "\ud996\udea0\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\ud989\udd60\udabe\udcb7\ud924\udc48\ud8df\uddab\ud96c\udd2d\ud8a6\udd31\ua44c\ud8be\udfaa\ud945\udf12\ud862\udd4f", "\ub503", "\udacc\udd0d\udbcf\ude36",
        9, 36872, 888680772, 7705449575991014498L, -10092L, false, false, (char) 30645, (char) 45987,
        Double.longBitsToDouble(0x3fdd8e0e3e286830L), Double.longBitsToDouble(0x3fdfe995c1dcccfaL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\0121=org.jsoup.helper.HttpConnection:@? |this=org.jsoup.helper.HttpConnection:@?\012",
        Z.run(T, 2, 8, 8, 12, "\uda91\udd9d\ucf34\udb2b\udec3\udad2\udf18", "\uaf1e", "\udb6d\udfdd\ud988\udfe3\ud9ad\udc38\ud8be\udfaa\udad3\uddb6\udb96\uddbf",
        1, 84110, -2144996459, -9154565753503033911L, 68059L, false, true, (char) 44491, (char) 34424,
        Double.longBitsToDouble(0x3fd4581a39db71deL), Double.longBitsToDouble(0x3fe2eb0329ca3d66L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 6, 1, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\udb0f\udd63\udabe\udcb7\ud81d\udd65\ud8df\uddab\ud8d2\udcff\ud8a6\udd31\udbf4\udd4c\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c\u7122\u1b89\u10ec\ua080\u1214\ucc4f\u879a\ud00a\u9ec3\u593e\u2c67\uc5de\u1276\u8f45\u3697\u573f\uba82\u8175\u5c1a", "\ud99f\udd8c\uda3f\ude3d\ud89b\ude41\udbd5\udc8d\ud940\udd47",
        39, 4392, 1345814005, -6962312770077377288L, 57024L, true, false, (char) 45606, (char) 16005,
        Double.longBitsToDouble(0x3fd9ebd2f7528882L), Double.longBitsToDouble(0x3fe813c0a6635f9aL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 10, 10, 12, "\ud996\ude79\ua834\udab5\ude20\ud8e0\udf33\ud8fe\udd6b\ud9a0\udc2b\ud932\ude71\ud983\udc93\ud8df\uddab\ud8d2\udcff\udb4b\udee4\ud813\udd0b\ud8be\udfaa\ud945\udf12\ud862\udd4f\uda66\ude02", "\u81a0\uc283\u863c", "\udb51\udf68\uda8f\uded1\ud85e\ude8c\udb68\ude02\uf82e\udbdc\udf13\uda67\udede\ud927\udd8e\ud9a4\udfc4\udb3f\udddc\uda83\udcb1\ud8c0\udc35\udac8\ude3d\ud95c\udf73\ud891\udfd1\udb11\udf1e\udb81\udd76\ud848\ude86\u8fcb\ud99f\udd8c",
        35, 90961, -1572500972, -3164988345979871250L, -50072L, true, false, (char) 42038, (char) 30824,
        Double.longBitsToDouble(0x3fec9434a5401f1dL), Double.longBitsToDouble(0x3fecf5e97868005eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.HttpConnection|connect|java.lang.String|static",
    "M|org.jsoup.helper.HttpConnection|connect|java.net.URL|static",
    "M|org.jsoup.helper.HttpConnection|cookie|java.lang.String,java.lang.String|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|cookies|java.util.Map|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.lang.String,java.lang.String|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.lang.String,java.lang.String,java.io.InputStream|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|[Ljava.lang.String;|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.util.Collection|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|data|java.util.Map|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|encodeMimeName|java.lang.String|static",
    "M|org.jsoup.helper.HttpConnection|encodeUrl|java.lang.String|static",
    "M|org.jsoup.helper.HttpConnection|execute||new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|followRedirects|boolean|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|get||new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|header|java.lang.String,java.lang.String|new:org.jsoup.helper.HttpConnection:",
    "M|org.jsoup.helper.HttpConnection|ignoreContentType|boolean|new:org.jsoup.helper.HttpConnection:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
