package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class DataUtil_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\ud98b\udeec", "\uc43e\ub5d3\u1af9\ucfe3\uaefa\u2d2c\u6c6b\u3c93\u5519\ubaa1\u78c2\u4eb7\u5f77\u3552\u8f8c\u77ca\uc8bb\uc2f8\u9d2d\u20e2\u6ca3\u5479\u3742\u0737\u815a", "\u3a44\ud914\ude27\uda23\udfb2\ud88e\udd4a\ud8d5\uddc6\udbfd\udc6c\ud919\udd5a\udb5a\udd33\ud858\udfef\udbc7\udc16\udb69\udd9a",
        -3, 46252, -199124666, -2817427654531734151L, 88701L, true, false, (char) 20396, (char) 51298,
        Double.longBitsToDouble(0x3fe92b4b842c6ce3L), Double.longBitsToDouble(0x3fefafe67af00efeL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\udb5b\udd15", "\uc43e\ub5d3", "\uda2c\udf77\ud9f2\udf8b\udb5c\ude71",
        -3, 54075, -2113327123, 4395364213373245240L, 99143L, true, false, (char) 23800, (char) 63084,
        Double.longBitsToDouble(0x3fe4b471de1c7312L), Double.longBitsToDouble(0x3fc76f16d81a9404L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 3, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\ud98b\udeec", "\uc43e\ub5d3\u1af9\ucfe3\uaefa\u2d2c\u6cb5\u3c93\u5519\ubaa1\u4f23\u66be\u5f77\u3552\u4b4f\u0c41\u3758\u2504\uc923\u20e2\u6ca3\u5479\u3742\u0737\u815a", "\u3a44\ud914\ude27\uda23\udfb2\ud88e\udd4a\ud8d5\uddc6\udbfd\udc6c\ud919\udd5a\udb5a\udd33\ud858\udfef\udbc7\udc16\udb69\udd9a\udad0\udf06\udad8\udd93\udbc0\udc92\ud844\ude2c\ud9e8\udda8",
        -3, 97459, 1478551193, 4062519046324654083L, 35920L, false, false, (char) 49745, (char) 13867,
        Double.longBitsToDouble(0x3fec031037cb75caL), Double.longBitsToDouble(0x3f8caaf1f668e780L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 4, 5, 4, "\ud8a7\udf5b\uda9d\udd21\ud8b8\udf6e\ud98b\udeec\ud8d2\udc3a\ud8c7\udcf4\udb5c\uded1\udb29\udd7b\udb55\udf2f\uda41\udefc\uda2c\udf77\ud9f2\udf8b\udb5c\ude71\uda94\ude5d\ud8bc\udccf\uda72\udc80\ud8d1\udc0f\ud8eb\udd9a", "\u8f8c\u77ca\uc8bb\uc2f8\u9d2d\u20e2\u6ca3\u5479\u3742\u0737\u815a\uabba\ud685", "\udaf7\udc9f\ud88e\udd4a\ud8d5\uddc6\udbfd\udc6c\ud919\udd5a\udb5a\udd33\ud858\udfef\udbc7\udc16\udb69\udd9a",
        -3, 46252, -199124666, -2817427654531734151L, 88701L, true, false, (char) 20396, (char) 51298,
        Double.longBitsToDouble(0x3fe92b4b842c6c15L), Double.longBitsToDouble(0x3fefafe67af00efeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\ud98b\udeec\ud8d2\udc3a\ud8c7\udcf4\udb5c\uded1\udb29\udd7b\udb55\udf2f\uda41\udefc\uda2c\udf77\ud9f2\udf8b\udb5c\ude71\uda94\ude5d", "\u78c2\u4eb7\u5f77\u3552\u8f8c\u77ca\uc8bb", "\ud8a3\udf5e\uef97\ud9ee\udff8\uda57\udc0a\udb8f\ude5c\ud9ec\ude18\uda69\udd35\ud8c6\ude56\uda2b\udd32\udaac\udd5b\ud85c\ude5d\udadb\udce8\udaa2\udd8a\ud995\udf15",
        13, 94909, -2126109849, 3442275132894784950L, 90967L, true, true, (char) 41405, (char) 65036,
        Double.longBitsToDouble(0x3fc297e8db8e72b4L), Double.longBitsToDouble(0x3fe4ccc5af8c5820L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 6, "\ud849\udf5d\uda9d\udc88\udb19\udfbd\udbd6\udf89", "\uc43e\ub5d3\u1af9\ucfe3\uaefa\u2d2c\u6c6b\u3c93\u5519\u8c66\u86bc\u4eb7\u5f77\u3552\u8f8c\u77ca\u1ccd\uc2f8\u9d2d\u20e2\u6ca3\u5479\u3742\u0737\u815a", "\u3a44\ud914\ude27\uda23\udfb2\ud88e\udd4a\ud8d5\uddc6\udbfd\udc6c\ud919\udd5a\udb5a\udd33\ud858\udfef\udbc7\udc16\udb69\udd9a",
        -3, 46252, -199124666, -2817427654531734151L, 88701L, true, false, (char) 20396, (char) 51298,
        Double.longBitsToDouble(0x3fdf86970858970eL), Double.longBitsToDouble(0x3fefafe67af00efeL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 0, 4, 6, "\ud8a7\udf5b\u0099\ud8c3\udc6e", "\u6506\uc43e\ub5d3\u1af9\ucfe3\uaefa\u2d2c\u1e87\u7d4c\u5519\ubaa1\u78c2\u4eb7\u5f77\u3552\u8f8c\u77ca\uc8e2\uc2f8\u9d2d", "\ud9ee\udff8\ud8df\udc0e\udb8f\ude5c",
        59, 82077, 181533107, 4203185376021672621L, -100000L, false, true, (char) 60517, (char) 31034,
        Double.longBitsToDouble(0x3fb52051bd79fea0L), Double.longBitsToDouble(0x3fdf7dcba000018eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\ud98b\udeec", "\u009b\u1d55\u1af9\ucfe3\uaefa\u2d2c\u6c6b\u3c93\u5519\ubaa1\u784b\u4eb7\u7f38\u3552\u8f8c\u77ca\u0092\uc262\u9d2d\u20e2\u6ca3\u5479\u3742\u0737\u80fc", "\u3a44\ud978\udeba\u5fad\uda48\udd47\ud8d5\uddc6\udbfd\udc2e\ud919\udd5a\udb5a\udd33\ud858\udfef\udbc7\udc16\udb69\udd9a",
        -3, 46252, -199124666, -2817427654531734151L, -100000L, true, false, (char) 20396, (char) 51298,
        Double.longBitsToDouble(0x3fe92b4b842c6ce3L), Double.longBitsToDouble(0x3fefafe67af00efeL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\udae3\udd18", "\uc43e", "\uda41\udefc\uda2c\udf77\ud9f2\udf8b",
        40, 37726, 0, 0L, -34464L, true, true, (char) 59772, (char) 23800,
        Double.longBitsToDouble(0x3fec9076da968e3bL), Double.longBitsToDouble(0x3fe0039894bb78b6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 0, "\ud8a7\udf5b\uda9d\udd21\ud95d\ude7a\ud9dd\udfeb\udbf6\udd2b\ud8c7\udc7d\uda69\udc97\udae2\udf05\u108c\udb0d\udf03\ud85d\udfe8\ud9e9\ude45\udaa5\ude16\uda3e\udc22", "\u6c90\u5ff9\u423c\ud2a7\u2d84\u3a1a\u3c33", "\uda41\udd09\uda61\udd49\uda44\udd99\udbb2\udce8\udb8f\ude64\ud9ec\ude18\uda69\udd35\udbfd\udf72\udbd4\udc29\udb92\udccb\udb73\udc98\ud88e\udd31\ud8d5\uddc6\ud9c8\ude4e\ud919\udd5a\udb5a\udd33\u30c8\uda9d\udc51\udb69\udd9a\ud863\udcd3\udaee\udf96",
        34, 43962, 1915523149, 749842609004868687L, -36628L, true, false, (char) 48277, (char) 2319,
        Double.longBitsToDouble(0x3fefafe67af00efeL), Double.longBitsToDouble(0x3fc82b3bd9d7a1b8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 3, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\ud98b\udeec", "\uc43e\ub5d3\u1af9\ucfe3\uaefa", "\uda94\ude5d\ud8bc\udccf",
        -3, 42479, -460089544, -722928218646926705L, -28982L, false, false, (char) 60785, (char) 2824,
        Double.longBitsToDouble(0x3feabc96ad904e94L), Double.longBitsToDouble(0x3fd10e66ecbc2c20L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 3, 5, "\ud8a7\udf5b\uda9d\udd21", "\u8d62\u6506", "\udb55\udf2f\uda41\udefc\uda2c\udf77\ud9f2\udf8b\udb5c\ude71\ud92e\udc4b",
        29, 71509, 1023375479, -1976069544594800840L, 72007L, true, false, (char) 63084, (char) 30929,
        Double.longBitsToDouble(0x3fe0e398949878b6L), Double.longBitsToDouble(0x3fe0352e2f5792d5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 4, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\ud98b\udeec", "\uc43e\ub5d3\u1af9\ucfe3\uaefa\u2d2c\u6c6b\u3c93\u5519\ubaa1\u78c2\u4eb7\u5f77\u3552\u8f8c\u77ca\uc8bb\uc2f8\u9d2d\u20e2\u6ca3\u5479\u3742\u0737\u815a", "\u3a44\ud914\ude27\uda23\udfb2\ud88e\udd4a\ud8d5\uddc6\udbfd\udc6c\ud919\udd5a\udb5a\udd33\ud858\udfef\udbc7\udc16\udb69\udd9a",
        -3, 46252, -199124666, -2817427654531734151L, 88701L, true, false, (char) 20396, (char) 51298,
        Double.longBitsToDouble(0x3fe92b4b842c6ce3L), Double.longBitsToDouble(0x3fefafe67af00efeL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 6, 6, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\ud98b\udeec", "\u30d8\u6152", "\ud805\udfde",
        16, 33855, -1397123258, 5865168835455762157L, 99143L, true, false, (char) 64504, (char) 63084,
        Double.longBitsToDouble(0x3fe4b471de1c7312L), Double.longBitsToDouble(0x3fc76f16d81a9404L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 1, 6, 5, 6, "\ud9b3\udc60\udb86\udf52\ud95b\udc72\ud825\udd95", "\uc43e\u80b1\u6842\u7125\uaefa\u643b\u6c6b\u3c93\u5519\u2f13\u0bd8\ub18f\u5f77\u3552\u4c39\u0922\u2ff5\u47df\u9dc2\u20e2\u7329\ubda7", "\udb91\ude89\ud851\udf86\uda7b\udf9f\ud8e9\udeb9\ud914\ude27\ud89a\udd8d\ud836\udea6\ud8d5\udda5\udbfd\udc6c",
        14, 83749, 1078373535, 4540163877370480559L, 8097L, true, true, (char) 8553, (char) 48016,
        Double.longBitsToDouble(0x3fa57695f8c093f0L), Double.longBitsToDouble(0x3f69c30325697000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 4, "\uda66\ude83\udac9\udefc", "\u87e2\u5bec", "\udb55\udf2f\udacb\udd71\ua396\ud97f\udde1\udb5c\udebb\uda94\ude5d\ud8bc\udccf",
        7, 19658, 532278745, 462603331960018151L, -94175L, true, false, (char) 1558, (char) 12703,
        Double.longBitsToDouble(0x3fee54892bf42da4L), Double.longBitsToDouble(0x3fedced02d904e94L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 0, "\ud8a7\udf5b\uda9d\udd21\ud8b8\udf6e\ud98b\udeec\ud8d2\udc3a\ud8c7\udcf4\udb36\udfd1\udb29\udd7b\udb11\udcee\uda41\ude90\uda2c\udf77\ud9f2\udf8b\udb5c\ude71\uda94\ude5d\ud8bc\udccf\uda72\udc80\ud8d1\udc0f\ud8eb\udd9a", "\u8f8c\u77ca\u1dbb\uc2f8\u9d2d\u20e2\u6ca3\u5479\u3742\u0737\u815a\uabba\ud685", "\udb43\udcf0\ud88e\udd4a\ud8d5\uddc6\udbfd\udc6c\ud919\udd5a\udb5a\udd33\ud858\udfef\u54df\udb69\udd9a",
        -3, 46252, -199124666, -2817427654531734151L, 88701L, true, false, (char) 41900, (char) 51298,
        Double.longBitsToDouble(0x3fe92b4b842c6c15L), Double.longBitsToDouble(0x3fefafe67af00efeL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 2, "\ud89f\udc95\uda9d\udd21\ud8c3\udc6e\ud98b\udeec\ud8d2\udc3a\ud8c7\udcf4\u69c6\udb29\udd7b\udb55\udf2f\uda41\udefc\uda2c\udf77\ud9f2\udf8b\udb5c\ude71\uda94\ude5d", "\u78c2\u4eb7\u5f77\u3552\u8f8c\u77ca\uc8bb\uc2f8\u9d2d", "\ud9ee\udff8\uda57\udc0a\udb8f\ude5c",
        59, 32533, 181533107, -1993767712580860265L, -45915L, false, false, (char) 20031, (char) 31034,
        Double.longBitsToDouble(0x3fe7fc0a35b62fc5L), Double.longBitsToDouble(0x3fe6de9ad609c047L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.jsoup.helper.DataUtil:@?\0121=new org.jsoup.helper.DataUtil:@?\012",
        Z.run(T, 2, 6, 6, 6, "\ud8a7\udf5b\u0099\ud8c3\udc6e", "\u638b\u84cc\ub5d3\u1af9\ucfe3\u410d\u8e43\u1e5d\u7d4c\u5519\ubaa1\u78c2\u4eb7\u5f77\u6b8b\u8fe4\u77ca\ud6be\uc2f8\u9d2d", "\ud9ee\udff8\ud8df\udc0e\udb8f\ude5c",
        59, 82077, 181533107, 4203185376021672621L, -100000L, false, true, (char) 60517, (char) 31034,
        Double.longBitsToDouble(0x3fb52051bd79fea0L), Double.longBitsToDouble(0x3fdf7dcba000018eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 0, "", "\u3f01\u78d9\u87e2\u5bec\ud7c5\u7644\u1af9\ub14f\u07d5\ub759\u1ed1\000\u5519\u7b59", "\000\000",
        58, -807, -2085768704, 450971566080L, -100000L, false, false, (char) 0, (char) 63893,
        Double.longBitsToDouble(0x3fd8709b5580b5a4L), Double.longBitsToDouble(0x3fd478fcad8d129cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 6, "\ud8a7\udf5b\uda9d\udd21\ud8c3\udc6e\ud98b\udeec", "\ud48b\u99bb\u1af9\ucfe3\uaefa\u2d2c\u6c6b\u3c93\u4e0b", "\ud8eb\udd9a",
        24, 30183, -175557171, -1902676123267185900L, -85749L, true, true, (char) 62733, (char) 44638,
        Double.longBitsToDouble(0x3fba471d28873610L), Double.longBitsToDouble(0x3fe2f0b080853f44L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.File,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String|static",
    "M|org.jsoup.helper.DataUtil|load|java.io.InputStream,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|parseByteData|java.nio.ByteBuffer,java.lang.String,java.lang.String,org.jsoup.parser.Parser|static",
    "M|org.jsoup.helper.DataUtil|readToByteBuffer|java.io.InputStream|static",
    "C|org.jsoup.helper.DataUtil|<init>|",
    "M|org.jsoup.helper.DataUtil|getCharsetFromContentType|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
