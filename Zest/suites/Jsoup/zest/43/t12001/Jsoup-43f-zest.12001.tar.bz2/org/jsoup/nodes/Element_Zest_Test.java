package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Element_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 10, "\ud8ba\udc86\ud9ca\uddd5\u072b\uda0e\udfdb\ud9f0\ude9c\udacd\udfcf\udbd2\udce2\uda84\udf6e\ud9d8\udfef\ud9dc\udf62\ud88b\udcb6\ud9a7\udcb9\u9442\udba6\udea4\ud8d8\udc0e\ud9c7\udf0a\uda05\udc85\udbf4\udec8\ud976\udfee\udabc\udc1b\ud9f4\udc75\udad8\udf07", "\u7b32\u7949\u5dc8\u68de\u4196\u9211\u23cf\u26e0\u26fd\ua2a8\u2a2e\u6c0b\u077c\u6283\ua8fd\ua52c\u67a5", "\udabb\udec8\ud9df\udda8\udbe8\udca5\udbd6\ude2a\ud989\udf7d\udaeb\udde4\uda44\udc92\ud86d\udff4\ud839\udfbb\ud9ad\udc8d\udbdf\udcd6\udaf1\udd87\ud9fd\udfa7",
        16, 20244, 1503901259, -320032938334902437L, 30596L, true, false, (char) 50906, (char) 42919,
        Double.longBitsToDouble(0x3fd8b19783f497d8L), Double.longBitsToDouble(0x3fe9133622f61055L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 10, "\ud87d\udd86\ud9ca\uddd5\u072b\uda0e\udfdb\ud9f0\ude9c\udacd\udfcf\udbd2\udce2\uda84\udf6e\ud9d8\udfef\ud9dc\udf62\ud88b\udcb6\ud9a7\udcb9\u9442\udba6\udea4\ud8d8\udc0e\ud800\udc27\udb77\udf3b\udbf4\udec8\ud976\udfee\udabc\udc1b\ud9f4\udc75\000", "\u7b32", "\000",
        42, 20598, -413210368, 894390042624L, -81863L, false, false, (char) 13056, (char) 43850,
        Double.longBitsToDouble(0x3f922976379304e0L), Double.longBitsToDouble(0x3fea3be3300cb970L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 6, 10, "\ud8ba\udc86\ud9ca\uddd5", "\u8e9d\u33f9\u231e\u7896\u3975\ucfba\u90d9\ube5b\uade7\u37ee\u8e3c\u12b1\u8e73", "\udabc\udc1b\ud9f4\udc75\udad8\udf07\udb38\udfc5\ud891\ude1d\udafe\ude6e\ud91e\udca1\ud817\udcd5\uda0b\ude0d\udaef\udc73\uda25\udf3a",
        22, 38632, 1036846526, 1814366605867501273L, -99805L, true, true, (char) 38280, (char) 10723,
        Double.longBitsToDouble(0x3fea3be3360cb970L), Double.longBitsToDouble(0x3fec8d3718c8ce47L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 10, "\ud8ba\udcad\ud9ca\uddd5\ud8d0\ude92\uda0f\udc4c\ud9f0\ude9c\udacd\udfcf\udbd2\udce2\uda84\udf6e\ud9d8\udfef\ud9dc\udf62\ud88b\udcb6\ud9a7\udcb9\u9442\uda58\udf1d\udbab\ude9a\ud9c7\udf0a\uda05\udc85\udbf4\udec8\ud899\udcbf\u05d6\uda1e\udd6d\udad8\udf07", "\u7b32\u7949\u5dc8\u68de\u4196\u9211\u23cf\u26e0\u26fd\ua2a8\u2a2e\u6c0b\u527c\u6283\ua8fd\ua52c\u67a5", "\udabb\udec8",
        9, 17888, -693969765, 1411005840286187007L, 39715L, true, true, (char) 50091, (char) 53411,
        Double.longBitsToDouble(0x3fe3e244a6ffabefL), Double.longBitsToDouble(0x3fe49c1b5e508db0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 10, "\000\ud81c\uddee\u072b\uda0e\udfdb\ud9f0\ude9c\udacd\udfcf\udbd2\udce2\uda84\udf6e\ud9d8\udfef\ud9dc\udf62\ud9dc\ude5e\000\000\udb76\udf9b\ud8d8\udc0e\ud9c7\udf0a\uda05\udc85\u00df\ud976\udf48\udabc\udc1b\ud9f4\udc75\ud96d\udf91", "\u7a8c\u7949\u5dc8\u68de\u4196\u9211\u23cf\u26e0\u26fd\u4672\u2a2e\u6c0b\u077c\u6283\ua8fd\u142c\u67a5", "\udabb\udec8\ud9df\udda8\ud986\udd75\udbd6\udd8f\ud989\udf7d\udaeb\udde4\uda44\udc92\ud86d\udff4\ud839\udfbb\ud90c\udd8c\udbdf\udcd6\udaf1\udd87\ud9fd\udfa7",
        16, 20244, 1503901259, -320032938334902437L, -100000L, true, false, (char) 50906, (char) 42919,
        Double.longBitsToDouble(0x3f19780000000000L), Double.longBitsToDouble(0x3fe9133622f61055L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 2, 10, "\ud8ba\udc86\ud9ca\uddd5\u072b\uda0e\udfdb\ud9f0\ude9c\udacd\udfcf\udbd2\udce2\uda84\udf6e\ud9d8\udfef\ud9dc\udf62\ud88b\udcb6\ud9a7\udcb9\u9442\udba6\udea4\ud8d8\udc0e\ud9c7\udf0a\uda05\udc85\udbf4\udec8\ud942\uddb3\udae1\udf70\ud9f4\udc75\udad8\udf07", "\u7b32\u7949\u5dc8\u68de\u4196\u9211\u23cf\u26e0\u26fd\ua2a8\u2a2e\u6c0b\u077c\u6283\ua8fd\ua52c\u67a5", "\udabb\udec8\ud9df\udda8\udbe8\udca5\udbd6\ude2a\ud989\udf7d\udaeb\udde4\uda44\udc92\ud86d\udff4\ud839\udfbb\ud9ad\udc8d\udbdf\udcd6\udaf1\udd87\ud9fd\udfa7",
        16, 20244, 1503901259, -320032938334902437L, 30596L, true, false, (char) 50906, (char) 42919,
        Double.longBitsToDouble(0x3fd8b19783f497d8L), Double.longBitsToDouble(0x3fe9133622f61055L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 10, "\ud814\udf90\ud9ca\uddd5\ud894\udf6d\ud882\udefe\ud9f0\ude9c\udafa\udcaf\ud857\udfc4\ud92e\ude2c\ud9d8\udfef\ud9dc\udf62\ud88b\udcb6\ud9a7\udcb9\u9442\udba6\udea4\udbb7\udf4a\ud801\uddb5\uda05\udc85\udbf4\udec8\ud976\udfee\udabc\udc1b\udbc4\udc3c\udad8\udfe9\udb1f\uddf7\ud891\ude1d\udafe\ude6e", "\u0b89\uca12\u8d84\u5f96\u8bf4\u9ac6\ubc13\uc9de\u6c0b\u077c\u6283\ua8fd\ua52c\u67a5\u0c6f\ua4a2\u5592", "\udbd6\ude2a\ud897\udf3e\uda99\udfca\udbf0\udc50\ud86d\udffe\uda7b\udfbc",
        58, 18408, -1410372996, -8976880226710088045L, -77307L, false, false, (char) 23905, (char) 38793,
        Double.longBitsToDouble(0x3fe6271c608e3312L), Double.longBitsToDouble(0x3fec58cbc1fa4bc0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 10, 15, "\ud949\udec2\ud817\udf44\u0714\uda0e\udfdb\ud9f0\ude9c\udacd\udfcf\udbd2\udce2\uda84\udf6e\ud9d8\udfef", "\u80db\uadce", "\uda57\udd53\uda05\udcf5\udb86\udf90\uda42\udd19\ud831\udf4a",
        56, 89159, -1554867908, -2296475179081092186L, -3294L, false, false, (char) 54838, (char) 30510,
        Double.longBitsToDouble(0x3fdbe13759a27b9aL), Double.longBitsToDouble(0x3fe6c8c96880ab10L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 6, 10, "\ud8ba\udc86\ud9ca\uddd5", "\u8e9d\u33f9\u231e\u7896\u3975\ucfba\u90d9\ube5b\uade7\u6f00\u9182\u12b1\u8e73", "\udabc\udc1b\ud9f4\udc75\ud9e2\udf0b\udb38\udf8f\ud891\ude1d\udafe\ude6e\ud91e\udca1\udb97\udef5\uda38\udff9\udaef\udc73\uda25\udf3a",
        22, 38632, 1036846526, 1814366605867501273L, -99805L, true, true, (char) 38280, (char) 10723,
        Double.longBitsToDouble(0x3fea3be3360cb970L), Double.longBitsToDouble(0x3fec8d3718c8ce47L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Element|indexInList|org.jsoup.nodes.Element,java.util.List|static",
    "M|org.jsoup.nodes.Element|accumulateParents|org.jsoup.nodes.Element,org.jsoup.select.Elements|static",
    "M|org.jsoup.nodes.Element|addClass|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|after|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|after|org.jsoup.nodes.Node|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|append|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendChild|org.jsoup.nodes.Node|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendElement|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendNormalisedText|java.lang.StringBuilder,org.jsoup.nodes.TextNode|static",
    "M|org.jsoup.nodes.Element|appendText|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|appendWhitespaceIfBr|org.jsoup.nodes.Element,java.lang.StringBuilder|static",
    "M|org.jsoup.nodes.Element|attr|java.lang.String,java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|before|java.lang.String|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|before|org.jsoup.nodes.Node|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|child|int|new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|children||new:org.jsoup.nodes.Element:org.jsoup.parser.Tag,java.lang.String",
    "M|org.jsoup.nodes.Element|indexInList|org.jsoup.nodes.Element,java.util.List|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
