package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class TokeniserState_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 7, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7508\ua0a5\u4774\ube44\ub872\uc178\uc956\u5c4f\u9d73", "\ud8dd\udf7b\udba6\udea2\ud991\udcad\ud8c2\udfa7\ud97d\uded8\ud875\udc9c\uda0d\ude01\uda95\udf90\udb59\udf75\udb3f\udfc2\ud9b5\udeee\uda98\udc51\ud812\udfa8\udbf1\udd2c\ud970\udc94\uda3a\ude2e\u0229\udb00\udd7c\udadc\udcd8\udb35\udd14",
        57, 91527, -666507619, -4055035808503753026L, -88439L, true, true, (char) 2610, (char) 13084,
        Double.longBitsToDouble(0x3fcc1d9049c13504L), Double.longBitsToDouble(0x3fd6d13642b5a772L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 4, 6, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\ud38d\u1b41\u476a\ube44\ub872\uc178\uc956\u5c4f\u9d73", "\udbf4\udde7\udbc2\udce5\ud991\udcac\ud8c2\udfa7\ud97d\uded8\ud875\udc9c\uda0d\ude01\uda95\udf90\udb59\udf75\udb3f\udfc2\ud9b5\udeee\uda98\udc51\ud812\udfa8\udbf1\udd2c\ud970\udc94\uda3a\ude2e\u0229\udb00\udd7c\udadc\udcd8\udb35\udd14",
        57, 91527, -666507619, -4055035808503753026L, -88439L, true, true, (char) 2610, (char) 13084,
        Double.longBitsToDouble(0x3fcc1d9049c13504L), Double.longBitsToDouble(0x3fd6d13642b5a772L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 2, "\udab7\udf58\uda43\udfd0", "\u315e\u17f1\u5c08\ua0a5", "\uce49\u5e99\ud9ac\udf1e\ud875\udfea\udb95\udf13\ud895\udccf\uda5c\ude5b\udbc7\udd1a\udba8\udfde",
        33, 92995, 1043569454, -1322240035844227925L, -54784L, false, false, (char) 55370, (char) 5569,
        Double.longBitsToDouble(0x3fd651ad286b3d44L), Double.longBitsToDouble(0x3fecbbd17f965ce3L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7508\ua0a5\u4774\ube44\ub872\uc178\uc956\u5c4f\u9d73", "\u4277\udba6\udea2\ud991\udcad\ud8c2\udfa7\ub932\uda4b\udf77\ud946\ude94\uda95\udf90\udb59\udf75\udb3f\udfc2\ud9b5\udeee\uda98\udc51\ud812\udfa8\ueef2\ud9c7\udf61\ud9f6\ude97\ud913\udfd1\udb00\udd7c\udadc\udcd8",
        22, 84837, 1551755527, -2862628427083964821L, 19445L, true, true, (char) 54562, (char) 39331,
        Double.longBitsToDouble(0x3fe3d2b720e0ec82L), Double.longBitsToDouble(0x3fe3826a0d6d1364L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7508\ua0a5\u4774\ube44\ub872\uc178\uc956\u5c4f\u9d73", "\ud8dd\udf7b\udba6\udea2\ud991\udcad\ud8c2\udfa7\ud97d\uded8\ud875\udc9c\uda0d\ude01\uda95\udf90\udb59\udf75\udb3f\udfc2\ud9b5\udeee\uda98\udc51\ud812\udfa8\udbf1\udd2c\ud970\udc94\uda3a\ude2e\u0229\udb00\udd7c\udadc\udcd8\udb35\udd14",
        57, 91527, -666507619, -4055035808503753026L, -88439L, true, true, (char) 2610, (char) 13084,
        Double.longBitsToDouble(0x3fcc1d9049c13504L), Double.longBitsToDouble(0x3fd6d13642b5a772L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7508\ua0a5\u4774\ube44\ub872\uc178\uc956\u5c4f\u9d73", "\ud8dd\udf7b\udba6\udea2\ud991\udcad\ud8c2\udfa7\ud97d\uded8\ud875\udc9c\uda0d\ude01\uda95\udf90\udb59\udf75\udb3f\udfc2\ud9b5\udeee\uda98\udc51\ud812\udfa8\udbf1\udd2c\ud970\udc94\uda3a\ude2e\u0229\udb00\udd7c\udadc\udcd8\udb35\udd14",
        57, 91527, -666507619, -4055035808503753026L, -88439L, true, true, (char) 2610, (char) 13084,
        Double.longBitsToDouble(0x3fcc1d9049c13504L), Double.longBitsToDouble(0x3fd6d13648b5a772L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7508\ua0a5\ub47c\u8bf3\uc126\uc178\uc956\u5c4f\u9d73", "\ud8dd\udf7b\udba6\udea2\ud991\udcad\ud8c2\udfa7\ud97d\uded8\ud875\udc9c\uda0d\ude01\uda95\udf90\ud808\udd0d\udb3f\udfdd\ud9b5\udeee\uda98\udc51\ud812\udfa8\udbf1\udd2c\ud970\udc94\uda3a\ude2e\u0229\udb00\udd7c\ud9d8\ude8b\udb35\udd14",
        57, 91527, -666507619, -4055035808503753026L, -88439L, true, true, (char) 2610, (char) 13084,
        Double.longBitsToDouble(0x3fcc1d9049c13504L), Double.longBitsToDouble(0x3fd6d13642b5a772L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\0121=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\012",
        Z.run(T, 2, 7, 7, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7508\ua0a5\u4774\ube44\ub872\uc178\uc956\u8063\u9d73", "\ud8dd\udf7b\udba6\udea2\ud991\udcad\ud8c2\udfa7\ud97d\uded8\ud875\udc9c\uda0d\ude01\uda95\udf90\udb59\udf75\udb3f\udfc2\uda42\udeba\u1bfa\ud92d\udc27\udbf1\udd2c\ud970\udc94\uda3a\ude2e\ud8c9\udd0c\uda14\udc80\udadc\udcd8\udb35\udd14",
        2, 91527, -666507619, -7946146019695847746L, -8558L, false, false, (char) 64866, (char) 4017,
        Double.longBitsToDouble(0x3fd6d13642b5a772L), Double.longBitsToDouble(0x3fde2bfe31a4b89cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 1, "\udab7\udf58", "\u300c", "\uda0f\udc5a\u7634",
        58, 49048, 1906369336, -1927123287607042595L, 28744L, true, true, (char) 64370, (char) 180,
        Double.longBitsToDouble(0x3fe2a6f869e05ebcL), Double.longBitsToDouble(0x3fcc7c180cb8d1c8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 2, "\udaad\udfa1", "\ua125", "\uda0f\udc5a\u7634\ud84a\udf4c\ud984\ude8f\uce49\ud864\udda0\ud883\uddca\ud8cf\uddce\udb85\udfc3\ud895\udccf\uda5c\ude5b\uda19\udf5f\udba8\udf97\ud94f\udcac\ud8c2\udffa",
        35, 90001, -923042645, -4989303280071058371L, 43717L, true, false, (char) 26054, (char) 33913,
        Double.longBitsToDouble(0x3fdc4f47af2b455eL), Double.longBitsToDouble(0x3fd6f31d2469c75eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 6, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7126\ua0b0\u4774\ube44\ub872\uc178\uc956\u5c4f\u9d73", "\u4277\udba6\udea3\ud991\udcad\ud8c2\udfa7\ub932\ud84e\ude4c\ud946\udf49\ud94f\udc43\ud89e\udda0\uda49\udfc6\ud95a\ude28\uda98\udc51\uda75\ude7c\ueef2\ud833\udea5\ud9e7\uddb1\ud913\udfd1\udb00\udd7c\ud9cb\udf50",
        34, 91990, 572482004, 1451556419468941935L, 19445L, true, true, (char) 54562, (char) 39331,
        Double.longBitsToDouble(0x3fa14ef1097ec2b0L), Double.longBitsToDouble(0x3fe1ad72956d1364L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\0121=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\012",
        Z.run(T, 2, 7, 7, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7508\ua0a5\u4774\ube44\ub872\uc178\uc956\ub028\u1b39", "\udbf1\ude07\udb95\udfbb\uda40\udc0a\ud8c2\udfa7\ud809\udc74\uda4b\udf77\ud946\ude94\uda95\udf90\udb59\udf75\udb3f\udfc2\ud9b5\udeee\uda98\udc51\ud812\udfa8\ueef2\ud9c7\udf61\ud9f6\ude97\ud913\udfd1\udb00\udd7c\udadc\udcd8",
        22, 84837, 1551755527, -2862803249432781205L, 19445L, true, true, (char) 22051, (char) 26490,
        Double.longBitsToDouble(0x3fe3b7a4d0e0ec82L), Double.longBitsToDouble(0x3fe3826a0d6d1364L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\012",
        Z.run(T, 1, 7, 0, 1, "\udab7\udf58\udba1\ude80\udaef\udc72", "\u17f1\u7508\ua0a5\u8441\ube44\ub872\uc178\u3a57\u5c4f\u9d73", "\ud8dd\udf7b\udba6\udea2\ud991\udcad\ud8c2\udfa7\ud97d\uded8\ud875\udc9c\uda13\ude04\uda95\udf90\udb59\udf75\udb3f\udfc2\ud9b5\udeee\uda98\udc51\u3005\udbf1\udd2c\ud970\udc94\uda3a\ude2e\u0229\udb00\udd7c\udadc\udcd8\uda7f\udfd7",
        57, 91527, -456333667, -4055036182165907778L, -88439L, true, true, (char) 2610, (char) 13084,
        Double.longBitsToDouble(0x3fcc1d9049c13504L), Double.longBitsToDouble(0x3fd8713642b5a772L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.TokeniserState;:[[Data, CharacterReferenceInData, Rcdata, CharacterReferenceInRcdata, Rawtext, ScriptData, PLAINTEXT, TagOpen, EndTagOpen, TagName, RcdataLessthanSign, RCDATAEndTagOpen, RCDATAEndTagName, RawtextLessthanSign, RawtextEndTagOpen, RawtextEndTagName, ScriptDataLessthanSign, ScriptDataEndTagOpen, ScriptD...\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 0, "\u606a\udba1\udd89\udaef\udc72", "\000\000\000\000\000\u4471\uc178\uc956\u8063\u5509", "\ua742\udba6\ude8a\ud990\udfcd\000\000\ud875\udc9c\uda0d\ude01\uda95\udf90\ub0a0\udb3f\udf94\uda3f\udd3e\u1bfa\ud92d\udc27\udbee\udf2c\ud970\udc94\u9a94\ud8c9\udd0c\uda14\udc80\000\000",
        -5, -1000, 0, -7946146346124181504L, -100000L, false, false, (char) 30014, (char) 29388,
        Double.longBitsToDouble(0x3ec0400000000000L), Double.longBitsToDouble(0x3fd6d13002b5a772L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 7, 1, "\ud9fc\uddc1\udafa\uddb7\ud930\udc01", "\u17f1\u7508\ua0a5\u4774\ube44\ub872\uc178\uc956\u5c4f\u86ef", "\ud8dd\udf7b\udba6\udea2\ud991\udcad\ud8c2\udfa7\ud97d\uded8\ud875\udc9c\ud9fa\ude01\uda95\udf90\ud95f\udc70\ud973\ude52\ud9f0\udc63\uda6e\udd81\ud882\udfa0\udbf1\udd2c\ud970\udc94\uda3a\ude2e\u0229\udb00\udd7c\udadc\udcd8\udb35\udd14\ud8a3\udc32\udbb9\udd66\udad4\udd6b\u131a\ud8f6\uddb6\ud8f5\udfe0\udaae\udff4\ud89b\udf33\uda16\udfa8\udbd8\udd7c\ud9e1\udd6d\uda3a\udf94\ub2d1\ue52b\udb92\udd71\udada\ude3f\udaff\udf43\udaa4\udc1d\udb51\udc4a\ud998\udec5\u89b1\udaed\udf78\uda58\ude77\uda10\udedf\uda53\ude48\ud8d2\udf54",
        14, 8777, -1229989323, -6298364731690427015L, 87763L, false, true, (char) 61838, (char) 42298,
        Double.longBitsToDouble(0x3fe8bb7b72574618L), Double.longBitsToDouble(0x3fe1630625d03180L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.TokeniserState|read|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader|fac:org.jsoup.parser.TokeniserState:valueOf:java.lang.String",
    "M|org.jsoup.parser.TokeniserState|handleDataDoubleEscapeTag|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader,org.jsoup.parser.TokeniserState,org.jsoup.parser.TokeniserState|static",
    "M|org.jsoup.parser.TokeniserState|handleDataEndTag|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader,org.jsoup.parser.TokeniserState|static",
    "M|org.jsoup.parser.TokeniserState|readCharRef|org.jsoup.parser.Tokeniser,org.jsoup.parser.TokeniserState|static",
    "M|org.jsoup.parser.TokeniserState|readData|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader,org.jsoup.parser.TokeniserState,org.jsoup.parser.TokeniserState|static",
    "M|org.jsoup.parser.TokeniserState|readEndTag|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader,org.jsoup.parser.TokeniserState,org.jsoup.parser.TokeniserState|static",
    "M|org.jsoup.parser.TokeniserState|valueOf|java.lang.String|static",
    "M|org.jsoup.parser.TokeniserState|values||static",
    "M|org.jsoup.parser.TokeniserState|read|org.jsoup.parser.Tokeniser,org.jsoup.parser.CharacterReader|fac:org.jsoup.parser.TokeniserState:valueOf:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
