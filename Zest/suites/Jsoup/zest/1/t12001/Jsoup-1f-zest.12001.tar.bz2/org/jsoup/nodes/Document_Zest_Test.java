package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Document_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6", "\ud883\ude6c\ud61f\ud94a\udf78\ud9db\uddb9\ud98d\udfd9\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\udb82\udfdc\uda84\udfa6\uda43\ude87",
        21, 94599, -644022609, 4906930509663268214L, 1768L, true, true, (char) 9718, (char) 8930,
        Double.longBitsToDouble(0x3feb246efaf67177L), Double.longBitsToDouble(0x3f970e0f45387f80L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\udad8\udd2a\uda0b\udc0e", "\u0568\uaa2b\uac67\u809c\u8cb2\u757f\u92a1", "\ud83e\ude5a\udbd3\ude03\ud94a\udf95\ud9db\uddb9\ud98e\udc24",
        12, 64093, 38092058, -6106469328953555074L, 87813L, false, false, (char) 44071, (char) 2340,
        Double.longBitsToDouble(0x3fef403410419727L), Double.longBitsToDouble(0x3fd25aab029ee158L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 8, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6", "\udb9b\udf5b\ud80a\udfb1\ud94a\udf78\ud9db\uddb9\ud98d\udfd9\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6",
        20, 76963, 654697008, -6828718024497666072L, -44130L, true, true, (char) 12679, (char) 50409,
        Double.longBitsToDouble(0x3fd764418781dc02L), Double.longBitsToDouble(0x3fd8859f63d9f606L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Document:\0121=new org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 7, 11, 8, "\uda64\udff5\udbae\udddc\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\u9e30\u32ec\u85b4\ucc66\u60a6", "\ud883\ude6c\ud61f\ud94a\udf78\ud9db\uddb9\ud98d\udfd9\ud9df\udc98\udab8\udd7b\udb10\ude5e\uda01\udc05\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\udb82\udfdc\uda84\udfa6\uda43\ude87",
        21, 94599, -1390984785, -2826725965884985863L, 60270L, true, true, (char) 9718, (char) 8930,
        Double.longBitsToDouble(0x3feb246ef8e89a77L), Double.longBitsToDouble(0x3f97c49b45387f80L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 2, 1, 6, "\ud9e8\udee7\ud8f5\udf72\ud903\udf1b\ud908\udc77\uda3e\udc7a", "\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6", "\ud883\ude6c\ud61f\ud94a\udf78\ud9db\uddb9\uda28\udd3c\udb54\udd8d\udbd6\udfb3\ud8d5\udd3c\ud91e\udf4f\ud93b\udd26\ud917\udf15\ud98e\udf3d\ud8c5\udec2\ud8f5\udfff\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\udb82\udfdc\uda84\udfa6\uda43\ude87",
        21, 94599, 233569967, 4953809270245256566L, -63768L, true, true, (char) 43723, (char) 8930,
        Double.longBitsToDouble(0x3feb246efaf69277L), Double.longBitsToDouble(0x3f970e0f45387f80L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 8, "\ud8a8\udd9d\udbb0\udd4f\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\u8039\u0645\u304b\ucc66\ub975", "\ud883\ude6c\ud61f\ud9b5\udeb6\ud9c4\ude00\udbee\udda8\ud8b1\ude73\uda43\udd2a\ud8d5\ude18\ud9e0\udd81\uda81\udfa6\udb08\udcbb\ud8cb\udff5\udb17\udec6\ud94c\udec8\uda70\udec1\ud8ae\uddba\uda70\udfb2\ud979\uddb8\udaae\udcc7\uda43\udf2f",
        21, 94599, -644022609, 4906930509663268214L, -50648L, true, true, (char) 9718, (char) 8930,
        Double.longBitsToDouble(0x3feb246efaf67177L), Double.longBitsToDouble(0x3f970e0f45387f80L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Document:\0121=java.lang.String: |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 11, 9, 0, "\uda31\udf88\ud8a2\ude1f\ud801\ude11\udacd\ude1a\uda3e\udcf7\ud86f\udfd0\udb38\udd4b\udb63\uddea\ud9a4\udec7\udbde\udf49\udb98\udde8\ud84e\udd64", "\u6b8e", "\ud61f\ud94a\udfc0\ud9db\uddb9\udb43\ude94\udbc2\udf83\ud945\udd3d\ud858\udfd9\ud8bc\uddca\ud894\uddd1\ud917\udee4",
        26, 75501, -1594159825, 469051555570984936L, 29715L, false, true, (char) 1990, (char) 16903,
        Double.longBitsToDouble(0x3fe6b8b3e6356364L), Double.longBitsToDouble(0x3fea6ecce776077cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Element:<\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6>\012</\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6> |this=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 5, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6", "\ud883\ude6c\ud61f\ud94a\udf78\ud9db\uddb9\ud98d\udfd9\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\udb82\udfdc\uda84\udfa6\uda43\ude87",
        21, 94599, -644022609, 4906930509663268214L, 1768L, true, true, (char) 9718, (char) 8930,
        Double.longBitsToDouble(0x3feb246efaf67177L), Double.longBitsToDouble(0x3f970e0f45387f80L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;&#56240;&#56523;&#56181;&#56956;\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;&#56240;&#56523;&#56181;&#56956;\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c", "\u2988\u7891\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6\u6b8e\ub88c\uaae4\uc286", "\ud98e\udc83\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6\ud917\udee4",
        33, 14008, -1589934813, 469051555570984936L, 88879L, true, true, (char) 13799, (char) 57491,
        Double.longBitsToDouble(0x3fdd7167cd5e65b0L), Double.longBitsToDouble(0x3fea6ecce0764418L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 12, 10, "\ud9ec\udcf9\ud8df\udef3\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6", "\ud883\ude6c\ud61f\ud94a\udfe5\ud9db\uddb9\ud98d\udfd9\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\uda8b\udd3e\udb82\udfe8\uda84\udfa6\uda43\ude87",
        21, 94599, -644022609, 4906930509663268214L, 71126L, true, true, (char) 9718, (char) 8930,
        Double.longBitsToDouble(0x3feb246efaf67177L), Double.longBitsToDouble(0x3f970e0f45387f80L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55870;&#56442;\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55870;&#56442;\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\ua074\uac67\ud064\u304b\ucc66\u301b\u6b8e\ub88c\u1939\uc2d1\u9878\u3e36\u2128\u5afd\u9e87\ubfca\u6a0f\u3d71\u33e0\u0657\u1070\u44d1\u079f", "\udb83\udc36\uda84\udfa6\uda43\ude87\ud8de\udf91\ud818\udcd6\udb79\udc6b\ud863\ude66\uda1a\udecb\ud8c8\udd0d\ud950\ude5e\ud83a\udff3\uda45\udcf0\ud890\udf05\ud971\udc6d\udab6\uddb5",
        8, 98706, 17021967, 7420578452719125088L, 43816L, true, false, (char) 30366, (char) 12698,
        Double.longBitsToDouble(0x3fef511f8b5d7e4fL), Double.longBitsToDouble(0x3fc4f01d458832a4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 8, 8, "\ud8a8\udd07\udbb0\udccb\udb75\ude7c\udb0c\udf23\ud861\udd7a", "\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6", "\ud887\uddbc\ud61f\uda57\udedf\uda55\udd16\ud98d\udfd9\ud9df\udc98\ud9d8\udfb4\ud8d5\udd3c\udbce\udcd7\uda81\udfa6\ud917\udee4\uda08\udd87\udb2c\udc49\ud8f5\udf8d\udaca\uddff\udafe\udf04\ud8ac\udf93\udaaa\udea8\udaab\udd50\ud960\udcf5",
        56, 21972, -644022673, 4906930509663268214L, 1768L, true, true, (char) 9718, (char) 8800,
        Double.longBitsToDouble(0x3feb246efaf67177L), Double.longBitsToDouble(0x3f970e0f45387f80L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Document:\012",
        Z.run(T, 1, 11, 8, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u03ed\u7270\u2727\ud00f\ubd85\u815f\u7945L\ub88c", "\ud9d1\udea3\ud8fb\udda0\ud98d\udfd9",
        -3, 87188, -1079346129, -8623593556007898723L, 87813L, false, false, (char) 19282, (char) 23124,
        Double.longBitsToDouble(0x3fef403410419727L), Double.longBitsToDouble(0x3fd39b2b0a9ee158L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 8, 8, "\udb4c\ude78\ud840\udde2\ud87a\ude9d\ud908\udc77\uda3e\udc7a", "\u0cb5\u7270\uac67\ud064\u304b\ucc66\u60a6", "\ud883\ude6c\u1fe8",
        49, 22608, -1529727687, 5504647894526434845L, -4128L, true, true, (char) 44828, (char) 21943,
        Double.longBitsToDouble(0x3fe184baed6f2705L), Double.longBitsToDouble(0x3fef4509dfe80682L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 11, 1, 4, "\ud8a8\udd78\udbb0\udccb\udb75\ude58\ud908\udc77\uda3e\udc7a", "\u39a2\u7270\ucaec\u2f12\u304b\u8e66\u60a6", "\ud883\ude6c\ud61f\ud94a\udf78\udba7\udf5f\ud98d\udfd9\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud884\udd05\udbb0\udd00\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\udb82\udfdc\uda84\udfa6\uda50\udf4d",
        51, 94599, -644022609, 4906930509663268214L, 1768L, true, true, (char) 9718, (char) 8930,
        Double.longBitsToDouble(0x3feb246efa6b7177L), Double.longBitsToDouble(0x3f970e0f45387f80L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 8, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\u0897\ud064\u304b\ucc66\u60a6", "\ud883\ude6c\ud61f\u6d01\000\000\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\udb65\ude83\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\ued39\000\uda43\ude87",
        21, 94599, -644022609, 4906930509663268214L, 1768L, true, true, (char) 9718, (char) 4543,
        Double.longBitsToDouble(0x3feb246efaf67177L), Double.longBitsToDouble(0x3f970e0f00187f80L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 11, 4, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\udb64\udf40\ud8c1\ude8b", "\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6", "\ud883\ude6c\ud61f\ud94a\udf78\uda2e\udebf\uda4a\udda4\ud9df\udcd1\udbd6\udfb3\ud86a\udc67\ud9e0\uddef\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\udb82\udfdc\uda84\udfa6\uda43\ude87",
        21, 94599, -644022609, 4906930509663268214L, 1768L, true, true, (char) 9706, (char) 8930,
        Double.longBitsToDouble(0x3feb246efaf67177L), Double.longBitsToDouble(0x3f970e0f45387f80L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 10, 8, "\udaa1\udc94\udbb0\udcdb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\uac67", "\udbf9\udea1\udbc6\udd1e\u3809\ud822\uddc6\udb9b\udf5b",
        38, 86919, 722294971, -6570130386169073640L, 38266L, true, false, (char) 44005, (char) 846,
        Double.longBitsToDouble(0x3fe1dd35c230973eL), Double.longBitsToDouble(0x3fd232705fd14276L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 4, 1, 8, "\ud8a8\udd78\udbb0\udccb", "\u69f9", "\ud8b7\udd6e\ud848\uddcf\ud976\udfdf\ud9a5\udeab\uda6e\udede\udbf9\udea1\udbc6\udd1e\u3809\udafb\uded3\udab4\ude76\ue4ca\udae3\uddc4\udb67\udf2a\uda39\udc39\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a",
        5, 73232, 1887823267, 2864097287881494056L, -75977L, true, false, (char) 12010, (char) 57508,
        Double.longBitsToDouble(0x3fee07700d8859f6L), Double.longBitsToDouble(0x3fdecfb03764dab0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Document:\0121=new org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 11, 11, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u7270\uac67\ud064\uad69\ucc66\u60a6", "\udb98\udfc6\ud80a\udfb1",
        7, 27216, -1529727687, 5504647894526434845L, -4128L, true, false, (char) 6734, (char) 59098,
        Double.longBitsToDouble(0x3fe184baed232705L), Double.longBitsToDouble(0x3fef4509dfe80682L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Element:<\u0568\ua61c\ub0c1\u3b13\u21ca\u8033\u606c>\012</\u0568\ua61c\ub0c1\u3b13\u21ca\u8033\u606c> |this=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Element:<\uda64\udff5\udbae\udddc\udb75\ude7c\ud908\udc77\uda2d\udce5>\012</\uda64\udff5\udbae\udddc\udb75\ude7c\ud908\udc77\uda2d\udce5> |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 3, 3, 11, "\uda64\udff5\udbae\udddc\udb75\ude7c\ud908\udc77\uda2d\udce5", "\u0568\ua61c\ub0c1\u3b13\u21ca\u8033\u606c", "\uda59\udc50\ud61f\ud8a9\ude93\ud8f6\udf47\udb0f\uddac\ud9c9\udf81\ud8b7\udd79\udb10\ude5e\uda01\udc05\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\udb9a\udc6f\uda7b\udeea\udb82\udfdc\uda84\udfa6\uda43\ude87",
        21, 58417, -1088975100, 1867151025352913585L, 1823L, true, true, (char) 55797, (char) 24793,
        Double.longBitsToDouble(0x3fef01416063bc77L), Double.longBitsToDouble(0x3f97c49b45233f80L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Document:\0121=null |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 5, 2, 8, "\uda64\udff5\udb6e\udc7d\uda61\udddd\ud908\udc77\uda3e\udc7a", "\u0568\u7270\u9e30\u32ec\uc309\ucc66\u60a6", "\ud82f\udc63\ud61f\ud94a\udf78\ud9db\uddb9\ud98d\udfd9\ud9df\udc98\udab8\udd7b\udb10\ude5e\uda01\udc05\uda81\udfa6\ud917\udee4\ud973\udc30",
        38, 6187, -1927583768, -7443268244700374871L, -44130L, true, true, (char) 29831, (char) 8398,
        Double.longBitsToDouble(0x3fdf9d8c5781dc1aL), Double.longBitsToDouble(0x3fdf2a2512f394aaL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 1, 6, "\ud9e8\udee7\ud8f5\udf72\ud903\udf1b\ud930\udd77\uda3e\udc7a", "\u4f68\u7270\uac67\ud064\u304b\ucc66\u8a97", "\ud883\ude6c\ud61f\ud94a\udf78\ud9db\uddb9\uda28\udd3c\udb54\udd8d\udbd6\udfb3\ud8d5\udd3c\ud91e\udf4f\ud93b\udd26\ud917\udf15\ud98e\udf3d\ud8c5\udec2\ud9fc\udcae\ud8b3\udcfa\ud8ae\uddba\uda70\udfb2\udb82\udfdc",
        17, 50016, 1635572286, 3663781474213283311L, -83971L, true, true, (char) 13174, (char) 25201,
        Double.longBitsToDouble(0x3fe25de401bf1123L), Double.longBitsToDouble(0x3fd5279f95ed24eeL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 6, "\ud9e8\udee7\ud8f5\udf72\ud903\udf1b\ud908\udc77\uda09\udebb\udae1\ude29\udb2c\ude04\udb8e\udc30\ud9c6\uddb1\ud976\udf5a\udb58\ude83\ud803\udf2c\udbf9\udea1\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\ud94a\udf78\ud9db\uddb9", "\u9e87\ubfca\u4e83\u15cf", "\ud8c5\udec2\uda53\udf4d",
        35, 74440, -1297074111, 8119116261884907855L, -44130L, true, true, (char) 12679, (char) 34100,
        Double.longBitsToDouble(0x3fd764446ef64e02L), Double.longBitsToDouble(0x3fd4fb5763e361aeL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Document:\0121=java.lang.String: |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 9, 9, 6, "\ud9e8\udee7\uf7b7\uda43\udd5b\ud908\udcae\uda3e\udc7a\udae1\ude29\udb2c\ude04\ud88a\ude6e\ud848\uddcf\ud976\udfdf\udb58\ude83\ud803\udf2c\udbf9\udea1\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f", "\u182b\u5fb1\u9e87\ubfca\u4e83\u15cf\u3411", "\ud8f5\udfff\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\udb82\udfdc\uda84\udfa6\uda43\ude87\ud8de\udf91\ud818\udcd6\uda79\udccb\udb88\ude3e\uda9d\ude9b\ud8c8\udd0d\uda84\udcd8",
        13, 19435, -1914760769, -7892717346420221194L, 78686L, true, true, (char) 24619, (char) 36082,
        Double.longBitsToDouble(0x3fcf993a25d3a940L), Double.longBitsToDouble(0x3fe6f9ef35ddfb90L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Element:<\uacee\u322a\u779b\u03c7\u9ef8\ucc66\ud2f8\u6b8e>\012</\uacee\u322a\u779b\u03c7\u9ef8\ucc66\ud2f8\u6b8e> |this=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 3, 4, 5, "\udbc0\udc42\udbbe\udccb\udb75\ude7c\ud9d1\udd6c\uda3e\udc7a", "\uacee\u322a\u779b\u03a7\u9ef8\ucc66\ud2f8\u6b8e", "\ud61f",
        4, 27216, -1529727687, 5504647894526434845L, -6944L, true, false, (char) 6734, (char) 5833,
        Double.longBitsToDouble(0x3fe6fd1aed232705L), Double.longBitsToDouble(0x3fef4509dee80682L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 12, 5, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\000", "\udb58\ude83\ud803\udf2c\udbf9\udea1\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud990\udc6b\ud94a\udf77",
        13, 17256, 1281650712, 6834667756940770586L, -86783L, false, false, (char) 59098, (char) 31117,
        Double.longBitsToDouble(0x3fd232705fd14276L), Double.longBitsToDouble(0x3fef403000419727L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;&#55375;&#56886;&#56181;&#56956;\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;&#55375;&#56886;&#56181;&#56956;\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\ud8a8\udd78\ud84f\ude36\udb75\ude7c", "\u2927\u7891\u0568\u7270\u0fc5\ucfb4\u304b\ucc66\u60a6\u71dd\u7aa0\uaae4\uc286\u6628\u1a4f\u21d2\u5aa2\u9e87\ubfca\u6a0f\u3d71\u33e0\u0657\u1070\u44d1\u079f\u0ba4\u8c9f\u1367\ub86a\u65aa\u0ce5", "\ud943\udf50\uda89\udf5a\uda26\udf49\udba5\udf82\ud8ae\ude3f\ud9e8\udd02\udaf9\udd51\udb4f\udcaa\ud984\ude9d\ud8b0\udc58\ud97c\udcfc\udb06\ude62",
        31, 82152, 1484438213, 8333525753143691949L, 88795L, false, true, (char) 29161, (char) 32818,
        Double.longBitsToDouble(0x3fe275dce0352377L), Double.longBitsToDouble(0x3faf2b4a531efa60L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>&#55464;&#56696;&#56240;&#56523;&#56181;&#56956;</title>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 10, 2, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c", "\u2988\u7891\u0568\u7270\u21d0\u74b2\u7532\ucc66\u60a6\u6b8e\u9f5d\uaa51\uc286", "\uda28\udfe6\ud9df\udc98\udbd6\udfb3\udb75\ude46\ud9e0\udd81\uda81\udfa6\ud917\udee4",
        33, 14008, -1589934813, 469051555570984936L, 88879L, true, true, (char) 13799, (char) 31380,
        Double.longBitsToDouble(0x3fdd7b312d5e65b0L), Double.longBitsToDouble(0x3fea6ecce0764418L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;&#55368;&#56783;\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;&#55368;&#56783;\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3a\uddda\udae1\ude29\udb2c\ude04\ud88a\ude6e\ud848\uddcf", "\u304b\ucc66\u60a6\u6b8e\ub88c\uaae4\uc286", "\ud98e\udc83\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6\ud917\udee4",
        33, 14008, -1589934813, 469051555570984936L, 88879L, true, true, (char) 13799, (char) 57491,
        Double.longBitsToDouble(0x3fdd7167cd5e65b0L), Double.longBitsToDouble(0x3fea6ecce0764418L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55464;&#56696;\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 6, "\ud8a8\udd78", "\u61a7\u807c\u90f3\u1f03\u1692\ub98c\u8399\ud310\u304b\ub398\uaeef\u6c04\ub88c", "\ud93d\udd18\ud85d\udf1f\ud98e\udc83",
        12, 64093, 256195866, -4733765759307723716L, 49614L, false, false, (char) 9799, (char) 25418,
        Double.longBitsToDouble(0x3feec2dc10419727L), Double.longBitsToDouble(0x3fe18d95814f7065L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#56015;&#56806;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;&#55368;&#56783;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#5694... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#56015;&#56806;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;&#55368;&#56783;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#5694...\012",
        Z.run(T, 2, 1, 8, 8, "\udacf\udde6\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3a\uddda\udae1\ude29\udb2c\ude04\ud88a\ude6e\ud848\uddcf\uda4d\udd89\udb58\ude83\ud803\udf2c\ud890\udca5\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\ud94a\udf78\ud85d\udf1f\ud98e\udc83\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81", "\u0657\u1070\u44d1\u079f\u0ba4\u3d53\u51f1\u932a\u65aa\u0ce5\u121a\ud12f\u8402\u8e57\ud75f\ud503\ua829\ub563\u93a3\u1260\u23de\ua491\u5482\ucca2\uab5f\u25a0\u34d6\uc813\u92ed\uacd1\u311f\u1f8e\u38f4\ubbac\u8b64\u6cdb", "\ubf3e\udb9b\ude5d\ud92c\uddd7\udbb4\udcbc\udbc1\udd82\ud893\udde2\udb09\udcaa\ud9f1\udfac\udbce\udc5b",
        14, 80775, -706101867, -6639109325607238639L, -38526L, true, false, (char) 38730, (char) 46127,
        Double.longBitsToDouble(0x3feaa006c94db89bL), Double.longBitsToDouble(0x3fe2acd17d7e4805L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 \000&#55924;&#56953;&#56181;&#56956;\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 \000&#55924;&#56953;&#56181;&#56956;\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\000\uda74\ude79\udb75\ude7c", "\u2988\u7891\u0568\u7270\uac67\ud064\u304b\ucc66\u60a6\u6b8e\ub88c\uaae4\uc286", "\ud98e\udc83\ud9df\udc98\udbd6\udfb3\032\ud9c2\udf01\uda81\udfa6\ud917\udee4",
        33, 14008, -1589934813, 469051555570984936L, 88879L, true, true, (char) 13799, (char) 57491,
        Double.longBitsToDouble(0x3fdd7167cd5e65b0L), Double.longBitsToDouble(0x3fea6ecce0764418L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#59584;\000&#56181;&#56956;\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#59584;\000&#56181;&#56956;\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\ue8c0\000\udb75\ude7c", "\000\000\uabf7\u7270\uac67\ud064\u304b\ucc66\u60a6\u6b8e\ub88c\uaae4\uc286", "\ud98e\udc83\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6\ud917\udee4",
        33, 14008, -1589934813, -1759041792L, 88879L, true, true, (char) 13799, (char) 57491,
        Double.longBitsToDouble(0x3fdd7167cd5e65b0L), Double.longBitsToDouble(0x3fea6ecce0000018L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>&#55464;&#56696;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;&#55368;&#56783;&#55548;&#57047;&#56152;&#56963;&#49964;&#56313;&#56993;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;</title>\012</hea...\012",
        Z.run(T, 2, 1, 10, 8, "\ud8a8\udd78\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3a\uddda\udae1\ude29\udb2c\ude04\ud88a\ude6e\ud848\uddcf\ud8fc\uded7\udb58\ude83\uc32c\udbf9\udea1\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c", "\u1a4f\u21d2\u5aa2\u9e87", "\uda81\udfa6\ud917\udee4\ud973\udc30\uda2a\udda8\u51aa\udadf\udefd\ud8ae\uddba\uda70\udfb2",
        27, 46615, 106303016, 1588040304300678615L, -9441L, true, false, (char) 38467, (char) 59889,
        Double.longBitsToDouble(0x3fecb7a9986e4d83L), Double.longBitsToDouble(0x3fe7e7dbd0dd656eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#56173;&#56871;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55464;&#56528;&#55888;&#56802;&#56108;&#56836;&#55434;&#56942;&#55884;&#56560;&#55670;&#57311;&#55903;&#56842;&#56190;&#56869;&#56037;&#56924;&#56293;&#56749;&#56178;&#56983;&#56158;&#56583;&#55427;&#5694... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#56173;&#56871;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55464;&#56528;&#55888;&#56802;&#56108;&#56836;&#55434;&#56942;&#55884;&#56560;&#55670;&#57311;&#55903;&#56842;&#56190;&#56869;&#56037;&#56924;&#56293;&#56749;&#56178;&#56983;&#56158;&#56583;&#55427;&#5694...\012",
        Z.run(T, 2, 1, 8, 8, "\udb6d\ude27\udbb0\udccb\udb75\ude7c\ud908\udc77\ud8a8\udcd0\uda50\udde2\udb2c\ude04\ud88a\ude6e\uda4c\udcf0\ud976\udfdf\uda5f\ude0a\udb7e\ude25\udae5\ude5c\udbe5\uddad\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\ud94a\udf78\ud84d\udd28\ud98e\udc83\ud9df\udc98\udb03\udd7f\ud8d5\udd3c\ud9e0\udd81\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\u592f\udbfa\udd6e\uda3a\udd10\uda43\ude87\ud8de\udf91\ud818\udcd6\udb79\udc6b\ud943\udf50\udb4f\udcec", "\uc64a\u6882\ua739\u7f67\ua862\u94ab\u83f1\u8935\uabbd\u0f10\u0845", "\ud942\udc5a\uda2d\udfad\ud8ef\udcc4\ud985\ude2c\ud8ea\udec0\ud9ca\udf88\uda63\udc4d\ud9b2\udf3a\udbfe\udc29\ud933\udd6c\uda5d\udfd0\udba2\udfbe\udb5f\udef2\ud827\udf1a\uda84\uddf1\ua5bd\ud83e\udd58\ud9aa\ude17\udaca\udcf4\udbd4\udf52\ud9b7\udd46",
        29, 38447, -1164828447, -211742165735482571L, 90038L, false, false, (char) 13132, (char) 21116,
        Double.longBitsToDouble(0x3fd153508ae9ccfeL), Double.longBitsToDouble(0x3fc8c9e9529b6f84L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 0, "", "\ub377\ud66a", "\udb2c\ude04\ud88a\ude6e\ud92e\udea2\ud9fc\uddd4",
        18, 4808, -867415634, 7135499825528260616L, 68703L, false, true, (char) 30884, (char) 5355,
        Double.longBitsToDouble(0x3fe0ea63251a5ed9L), Double.longBitsToDouble(0x3fe400122c5fab41L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 \000\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 \000\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\000", "\ud66a\u0f7d\u89d3", "\u009d\000",
        30, -1000, -867415634, 7135499825528260616L, -76745L, false, false, (char) 17997, (char) 58921,
        Double.longBitsToDouble(0x3fde3420003149a4L), Double.longBitsToDouble(0x3fe00003201a5ed9L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 4, 4, 8, "\udb57\udc81\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3e\udc7a", "\u0568\u1cd6\u0897\ud064\u304b\ucc66\u60a6", "\ud9bd\udc69\ud61f\u6d01\000\000\ud9df\udc98\udbd6\udfb3\ud8d5\udd3c\udb65\ude83\uda81\udfa6\ud917\udee4\ud973\udc30\udad3\udc7c\ud8f5\udf8d\ud8a0\udc4a\ud8ae\uddba\uda70\udfb2\udb15\ude66\000\uda43\ude87",
        21, 94599, -644022609, 4906930509663268214L, 1768L, true, true, (char) 55625, (char) 4543,
        Double.longBitsToDouble(0x3f80b9beb59c4f40L), Double.longBitsToDouble(0x3f970e0f00187f80L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>\000\000&#56181;&#56749;</title>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 10, 2, "\000\000\udb75\uddad", "\u2988", "\ud92e\udea2",
        19, 61719, -698290553, -3725521778407742647L, 22293L, false, false, (char) 6247, (char) 17997,
        Double.longBitsToDouble(0x3fa872fc80000000L), Double.longBitsToDouble(0x3f980000c3a98c80L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>\000&#56240;&#56455;&#56181;&#56956;</title>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 10, 2, "\000\udbb0\udc87\udb75\ude7c", "\u2988\u7891\u0568\u7270\u21d0\u74b2\u7532\ucc66\u60a6\u6b8e\u9f5d\uaa51\uc286", "\uda28\udfe6\ud9df\udc98\udbd6\udfb3\udb75\ude46\ud9e0\udd81\uda81\udfa6\ud917\udee4",
        33, 14008, -1589934813, 469051555570984936L, 88879L, true, true, (char) 13799, (char) 31380,
        Double.longBitsToDouble(0x3fdd7b312d5e65b0L), Double.longBitsToDouble(0x3fea6ecce0764418L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#56015;&#56806;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;&#55598;&#56994;\000&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#3515;&#55444;&#57225;&#54815;&#55626;&#5720... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#56015;&#56806;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;&#55598;&#56994;\000&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#3515;&#55444;&#57225;&#54815;&#55626;&#5720...\012",
        Z.run(T, 2, 1, 8, 8, "\udacf\udde6\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3a\uddda\udae1\ude29\udb2c\ude04\ud88a\ude6e\ud92e\udea2\000\udb58\ude83\ud803\udf2c\ud890\udca5\udbc6\udd1e\udb72\ude97\u0dbb\ud894\udf89\ud61f\ud94a\udf78\ud85d\udf1f\ud98d\udfa0\ud9df\udc98\035\ud8d5\udd3c\u7680", "\u0657\u063f\u44d1\u079f\u0ba4\u3d53\u51f1\u932a\u65aa\u0ce5\u121a\ud12f\u8402\u8e57\ud75f\ud503\ua829\ub563\u93a3\u1260\u23de\ua491\u5482\ucca2\uab5f\u25a0\u34d6\uc813\u92ed\uacd1\u311f\u1f8e\u38f4\ubbac\u8b64\u6cdb", "\ubf3e\udb9b\ude5d\ud92c\uddd7\udbb4\udcbc\udbc1\udd82\ud893\udde2\udb09\udcaa\ud9f1\udfac\udbce\udc5b",
        14, -1000, -721420288, -6639109325607238639L, -38526L, true, false, (char) 38730, (char) 46127,
        Double.longBitsToDouble(0x3feaa006c94db89bL), Double.longBitsToDouble(0x3fe2acd17d7e4805L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#56015;&#56806;&#56240;&#56523;&#56268;&#56692;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;\000\000\000&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#56302;&#57058;&#54712;&#55953;&#56936;&#64304;\000&#55863;&#... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#56015;&#56806;&#56240;&#56523;&#56268;&#56692;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#55434;&#56942;\000\000\000&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#56302;&#57058;&#54712;&#55953;&#56936;&#64304;\000&#55863;&#...\012",
        Z.run(T, 2, 1, 8, 8, "\udacf\udde6\udbb0\udccb\udbcc\udd74\ud908\udc77\uda3a\uddda\udae1\ude29\udb2c\ude04\ud88a\ude6e\000\000\000\ud803\udf2c\ud890\udca5\udbc6\udd1e\udb72\ude97\udb5e\udd07\udbee\udee2\ud5b8\uda91\ude68\ufb30\000\uda37\udc7a\udbd6\udfb3\ud8d5\udd3c\ud9e0\udd81", "\u0657\u1070\u7569\000\000\000\u5178\u932a\u65aa\u0ce5\u1143\ud12f\u8402\u8e57\ud75f\ud503\ua829\u00e1\u930c\u1260\u23de\ua491\u5482\ucca2\uab5f\u65a1\031\uc813\u258c\uacd1\u311f\u1f8e\000\000\u8b64\u6cdb", "\ubf3e\udb9b\ude5d\ud92c\uddd7\udbb4\udcbc\udbc1\udd82\ud893\udde2\ud8e2\udd9e\ud9f1\udfac\udbce\udc5b",
        14, 80775, -706101867, -6639109325607238639L, -38526L, true, false, (char) 38730, (char) 19197,
        Double.longBitsToDouble(0x3fe80000014db89bL), Double.longBitsToDouble(0x3fe2acd1787e4805L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&#55866;&#56770;&#56033;&#56873;&sup3;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#55626;&#57208;&#... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&#55866;&#56770;&#56033;&#56873;&sup3;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#55626;&#57208;&#...\012",
        Z.run(T, 2, 1, 8, 8, "\u5529\udbb0\udc87\udb75\ude7c\u0175\uda3a\uddc2\udae1\ude29\u00b3\ud964\udcf1\ud848\udd32\uda4d\udd89\udb58\ude83\ud803\udf2c\ud890\udca5\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\ud94a\udf78\ud85d\udf1f\ud98e\udc83\ud9df\udc98\udbd6\udfb3\032\000", "\u0657\u1070\u44d1\u079f\u5816\u3d53\u51f1\u932a\u65aa\u0ce5\u121a\ud12f\u8402\u2077\ud75f\ud503\ua829\u4363\u93a3\000\000\000\ud052\ucca2\uab5f\u25a0\u34d6\uc813\u92ed\000\u311f\u1f8e\u38f4\ubbac\u8b64\u6cdb", "\ubf3e\u00f0\ud92c\uddd7H\udb6e\udc96\ud893\udde2\udb09\udcaa",
        29, 25461, -1239606336, 593778261598256533L, -100000L, false, false, (char) 0, (char) 13029,
        Double.longBitsToDouble(0x3fe8d661823269fdL), Double.longBitsToDouble(0x3feaa006c800009bL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title></title>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 10, 0, "", "\ub377\ud66a", "\udb2c\udd51",
        19, 74725, -2030042890, -698308192L, 5655L, false, false, (char) 2350, (char) 37692,
        Double.longBitsToDouble(0x3fb9cf32e80eca58L), Double.longBitsToDouble(0x3fe9872fcde342c1L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 3, 0, "", "\ub377\ud66a", "\udb2c\ude04\ud88a\ude6e\ud92e\udea2\ud9fc\uddd4",
        18, 4808, -867415634, 7135499825528260616L, 68703L, false, true, (char) 30884, (char) 5355,
        Double.longBitsToDouble(0x3fe0ea63251a5ed9L), Double.longBitsToDouble(0x3fe400122c5fab41L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>\000&#56089;&#57132;&#55389;&#57078;&#148;&#55866;&#56794;&#56033;&#56873;&sup3;</title>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 10, 2, "\000\udb19\udf2c\ud85d\udef6\u0094\uda3a\uddda\udae1\ude29\u00b3", "\u674b\u74b2\u3d7e", "\udb72\ude97",
        42, -932, -649389977, -1875347918760706000L, -71304L, true, false, (char) 21885, (char) 11761,
        Double.longBitsToDouble(0x3fe7139143ad5dd5L), Double.longBitsToDouble(0x3fe9283c56b0d171L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&#55866;&#56770;&#56033;&#56873;&sup3;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#56278;&#57181;&#... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&#55866;&#56770;&#56033;&#56873;&sup3;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#56278;&#57181;&#...\012",
        Z.run(T, 2, 1, 8, 8, "\u5529\udbb0\udc87\udb75\ude7c\u0175\uda3a\uddc2\udae1\ude29\u00b3\ud964\udcf1\ud848\udd32\uda4d\udd89\udb58\ude83\ud803\udf2c\ud890\udca5\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\udbd6\udf5d\udb46\udf02\ud98e\udc83\ud9df\udc98\ud956\udd6e\ud871\udd01\u00a3", "\u0657\u1070\u44d1\u079f\u5816\u3d53\u51f1\u932a\u65aa\u0ce5\u121a\ud12f\u8402\u2077\ud75f\ud503\ua829\u4363\u93a3\000\000\000\ud052\ucca2\uab5f\u25a0\u34d6\uc813\u92ed\000\u311f\u1f8e\u38f4\ubbac\u8b64\u6cdb", "\ubf3e\u00f0\ud92c\uddd7H\udb6e\udc96\ud893\udde2\udb09\udcaa",
        29, 25461, -1239606336, 593778261598256533L, -100000L, false, false, (char) 0, (char) 13029,
        Double.longBitsToDouble(0x3fe8d661823269fdL), Double.longBitsToDouble(0x3feaa006c800009bL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&#57600;\000\000\000&#56089;&#57132;&#55885;&#56713;\000&#55299;&#57132;&#55440;&#56485;&#55878;&#56606;&#56178;&#56983;&#58805;\000&#55911;&#56755;&#27905;\000\000&#56232;&#56349;\000\000\000\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&#57600;\000\000\000&#56089;&#57132;&#55885;&#56713;\000&#55299;&#57132;&#55440;&#56485;&#55878;&#56606;&#56178;&#56983;&#58805;\000&#55911;&#56755;&#27905;\000\000&#56232;&#56349;\000\000\000\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 10, "\u5529\udbb0\udc87\udb75\ude7c\u0175\ue100\000\000\000\udb19\udf2c\uda4d\udd89\000\ud803\udf2c\ud890\udca5\uda46\udd1e\udb72\ude97\ue5b5\000\uda67\uddb3\u6d01\000\000\udba8\udc1d\000\000\000", "\u0657\u1070\u44d1\u67e8\u302e\ucc11\u51f1\u932a\u65aa\u0ce5\u121a\u00af\000\u2001\ud75f\ud503\ua829\u4363\u93a3\000\000\000\ud052\ucca2\uab5f\u25a0\u34d6\u1ed0\u92ed\000\u311f\000\u101f\u3e1d\000\000", "",
        -5, -1000, 13828096, 309405417472L, -99915L, false, false, (char) 0, (char) 50580,
        Double.longBitsToDouble(0x3fd3ed5e900147baL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&#56239;&#57243;&#55430;&#57258;&mu;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#56148;&#57117;&#55... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&#56239;&#57243;&#55430;&#57258;&mu;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#56148;&#57117;&#55...\012",
        Z.run(T, 2, 1, 8, 2, "\u5529\udbb0\udc87\udb75\ude7c\u0175\udbaf\udf9b\ud886\udfaa\u03bc\ud964\udcf1\ud848\udd32\uda4d\udd89\udb58\ude83\ud803\udf2c\ud890\udca5\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\udb54\udf1d\ud978\uddd7\ud98e\udc83\ud9df\udc98\udbd6\udfb3\ud960\udeea\uacc8", "\uaf04\u1070\u44d1\u079f\u5816\u3d53\u51f1\u932a\u65aa\u0ce5\ubb4e\ud12f\u8402\u2077\u2b92\ud49a\ua829\u4363\u93a3\000\000\u78e3\ud052\ucca2\uab5f\u25a0\u34d6\uc813\u92ed\000\u311f\u3e8e\u38f4\ubbac\u8b64\u6cdb", "\ubf3e\u00f0\ud92c\uddd7\uda27\ude8a\udb6e\udd53\ud893\udde2\udb09\udcaa",
        29, 18711, -224352194, 593778261598256533L, 96608L, true, false, (char) 17282, (char) 13029,
        Double.longBitsToDouble(0x3fe8d661823269fdL), Double.longBitsToDouble(0x3feaa006c800009bL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 0, "\ud8a8\udd78", "\u9bda\u5d9e\u2988\u26b3\u82f6\u7270\u92f6\u0af7\000\000\ubd55\u6b8e\ub88c", "\ud94a\udf78\000\ud98d\udfd9",
        12, 64093, 38092058, 548411998208L, 87813L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e24f70ac0000000L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>&#313;</title>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 10, 2, "\u0139", "\ud244\u0ffb\u7688\u7891\u0568\u7270\uac67", "\udbf9\udea1\udbbe\udd1e\udb6b\udd97\udb5e\udd07\ud883\ude6c",
        58, 84537, 1120006960, 653406743996893079L, -99974L, false, false, (char) 30624, (char) 6734,
        Double.longBitsToDouble(0x3fe2de23fa30cef7L), Double.longBitsToDouble(0x3fd232705fd14276L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 \014&#55924;&#56953;&#56181;&#56956;\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 \014&#55924;&#56953;&#56181;&#56956;\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\014\uda74\ude79\udb75\ude7c", "\u2988\u7891\uba75\u7270\u265f\u166b\u3055\ucc66\u60a6\u6b8e\ub88c\uaae4\uc286", "\ud98e\udc83\ud9df\udc98\udbd6\udfb3\032\ud9c2\udf01\uda81\udfa6\ud917\udee4",
        33, 14008, 1570423843, 499947785066850280L, -26735L, true, true, (char) 13799, (char) 57491,
        Double.longBitsToDouble(0x3febc75c41af32d8L), Double.longBitsToDouble(0x3fd08abad89d4e82L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>&#21801;&#56240;&#56455;&#56181;&#56956;&#55572;&#57183;&#55601;&#56444;&#55397;&#57089;&mu;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#55818;&#57277;&#55583;&#56475;&#55602;&#56869;&#56148;&#...\012",
        Z.run(T, 2, 1, 10, 2, "\u5529\udbb0\udc87\udb75\ude7c\ud914\udf5f\ud931\udc7c\ud865\udf01\u03bc\ud964\udcf1\ud848\udd32\uda4d\udd89\udb58\ude83\ud803\udf2c\ud890\udca5\udbc6\udd1e\udb72\ude97\uda0a\udfbd\ud91f\udc9b\ud932\ude25\udb54\udf97\ud978\uddd7\ud98e\udc83\ud9df\udc98\udbd6\udfb3\ud960\udeea\uacc8", "\uaf04\u1070\u44d1\u079f\u5816\u3d53\u51f1\u932a\u65aa\u0e83\u1188\ud12f\u8402\u2077\u2b92\ud49a\ua829\u4363\u93a3\000\000\u78e3\ud052\ucca2\uab59\u25a0\ud525\uc813\u92ed\000\u311f\u3e8e\u1df5\ubbac\u8b64\u9289", "\ubf3e\u00f0\ud92c\uddd7\uda27\ude8a\udb6e\udd53\ud893\udde2\udb09\udcaa\ud9f1\udfac\ud9d2\udf27\ud8d7\udf74\ud9de\ude6c\ud8b3\uddb6\u4fba\ud8af\udc16\ud9be\udd69\ud9f5\udf0c\ud946\udf53\uc959\udb2c\ude3e\ud891\udf5d\uda27\udd73\ud806\udc43\ud898\udc96",
        0, 28259, -1204502146, -3563795515530248280L, 44807L, true, true, (char) 22087, (char) 65245,
        Double.longBitsToDouble(0x3fed3cdfb89f7aeeL), Double.longBitsToDouble(0x3fd3e6d5ebd64f7cL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>\014&#55924;&#56953;&#56181;&#56956;&#55653;&#56873;&#55866;&#56794;</title>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 10, 6, "\014\uda74\ude79\udb75\ude7c\ud965\ude29\uda3a\uddda", "\u218e\uc0e6\u0082\uae7b\u3055\ucc75\u3674", "\ud883\ude6c",
        58, 29985, 1122416150, -6570129656024633320L, -99974L, false, false, (char) 30624, (char) 64323,
        Double.longBitsToDouble(0x3fe6fd2a4aee6b5dL), Double.longBitsToDouble(0x3feb18392990eb5eL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\014\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\014\012</body>\012</html>\012",
        Z.run(T, 2, 1, 8, 8, "\014", "\ud66a\u0f7d\u2988\u7891\ubadd\u7270\u265f", "\udbf9\udea1\udbbf\udfef\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\ud94a\udf78\ud85d\udf1f\ud98e\udc83\ud9df\udc98\udbd6\udfb3\032\ud9c2\udf01\uda81\udfa6",
        20, 76963, 2051072560, 6744919046660041693L, -44130L, false, true, (char) 60550, (char) 52405,
        Double.longBitsToDouble(0x3fb3a9d05c9bc0a0L), Double.longBitsToDouble(0x3fe852767aa624caL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012<head>\012 <title>\014</title>\012</head>\012<body>\012</body>\012</html>\012",
        Z.run(T, 2, 1, 10, 8, "\014", "u\000\u28bb\u7891\ubadd\u7270\u265f", "\udbf9\udea1\udbbf\udfef\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\ud94a\udf78\ud85d\udf1f\ud98e\udc83\ud9df\udc98\udbd6\udfb3\032\ud9c2\udf01\uda81\udfa6",
        20, 76963, 2051072560, 6744919046660041693L, -44130L, false, true, (char) 60550, (char) 52405,
        Double.longBitsToDouble(0x3fb3a9d05c9bc0a0L), Double.longBitsToDouble(0x3fe852767aa624caL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55408;&#56504;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#6765;&#55598;&#56994;&#55804;&#56788;&#23748;&#55299;&#57132;&#56313;&#56993;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#55626... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55408;&#56504;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#6765;&#55598;&#56994;&#55804;&#56788;&#23748;&#55299;&#57132;&#56313;&#56993;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#55626...\012",
        Z.run(T, 2, 1, 8, 0, "\ud870\udcb8\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3a\uddda\udae1\ude29\udb2c\ude04\u1a6d\ud92e\udea2\ud9fc\uddd4\u5cc4\ud803\udf2c\udbf9\udea1\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\ud94a\udf78\ud85d\udf1f\ud98e\udc83\ud9df\udc98\udbd6\udfb3\ud84d\ude1b\ud9e0\udd81\ud8b2\uddde\uda57\udd7b\ud913\udc3d\uda63\udd96\udaaf\udfbc\udb1f\udfb5\ud951\udc76\ud8c8\ude74\ud932\udc66\ud975\udc62\ud9bd\udcdb\uda54\ude21\udb27\ude63\ud9df\udc6b\u5a2f\ud9e0\udc44\udb8c\udd52\udab0\uddf1\udb67\udf27\udac6\udca7\ud88e\udd77\ud97f\ude9d\uda4b\udc06\ud99e\udc48\ud885\udf9e\ud8db\udec3\ud9c0\udce5\ud9d8\udc9c\ud859\ude83\ud8bc\udc22\ud98c\ude78\udb68\udde6\ud83e\udfe1\udbe0\udd96\ud97e\udf9a\ud96b\udf82\uda7b\udc9f\ud9c8\udd33\ud87c\udcc4\udbd0\uded4\uda37\udece\ud859\udf45\udbad\udebe\udbee\udfa1\ud9bc\udc0e\ud900\udccc\ud950\uddb6", "\u428f", "\ud8f2\udd3a",
        55, 75211, -66922053, 1599520516475998458L, -47364L, false, true, (char) 20745, (char) 42932,
        Double.longBitsToDouble(0x3fe9744ec9b7c1bdL), Double.longBitsToDouble(0x3fe099e9c552841eL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Element:\012<p></p> |this=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Element:<\uda64\udff5\udbae\udddc\udb75\ude7c\ud908\udc77\uda2d\udce5>\012</\uda64\udff5\udbae\udddc\udb75\ude7c\ud908\udc77\uda2d\udce5> |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 3, 3, 11, "\uda64\udff5\udbae\udddc\udb75\ude7c\ud908\udc77\uda2d\udce5", "p", "\udbb9\udeac",
        5, 22464, 1661362959, 1691462332680621775L, -93087L, false, false, (char) 20936, (char) 9865,
        Double.longBitsToDouble(0x3fb7ead053357f38L), Double.longBitsToDouble(0x3fe2de23fa30975dL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55408;&#56504;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#6765;&#55598;&#56994;&#55804;&#56788;&#23748;&#55299;&#57132;&#56313;&#56993;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#55626... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#55408;&#56504;&#56240;&#56523;&#56181;&#56956;&#55560;&#56439;&#55866;&#56794;&#56033;&#56873;&#56108;&#56836;&#6765;&#55598;&#56994;&#55804;&#56788;&#23748;&#55299;&#57132;&#56313;&#56993;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#55626...\012",
        Z.run(T, 2, 1, 8, 1, "\ud870\udcb8\udbb0\udccb\udb75\ude7c\ud908\udc77\uda3a\uddda\udae1\ude29\udb2c\ude04\u1a6d\ud92e\udea2\ud9fc\uddd4\u5cc4\ud803\udf2c\udbf9\udea1\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\ud94a\udf78\udb9f\udfa0\ud9b7\udda5\ud9df\udc98\udbd6\udfb3\ud84d\ude1b\ud9e0\udd81\ud8b2\uddde\uda57\udd7b\ud913\udc3d\uda63\udd96\udaaf\udfbc\udb1f\udfb5\ud951\udc76\ud8c8\ude74\ud932\udc66\ud975\udc62\ud9bd\udcdb\uda54\ude21\udb27\ude63\ud9df\udc6b\u5a2f\ud9e0\udc44\udb8c\udd52\udab0\uddf1\udb67\udf27\udac6\udca7\ud88e\udd77\ud97f\ude9d\uda4b\udc06\ud99e\udc48\ud885\udf9e\ud8db\udec3\ud8f6\udfb4\ud958\ude93\ud859\ude9c\ud8bc\udc22\ud98c\ude78\udb68\udde6\ud83e\udfe1\udbe0\udd96\ud97e\udf9a\ubf85\uda7b\udc9f\ud9c8\udd33\ud87c\udcc4\udbd0\uded4\uda37\udece\ud859\udf45\udbad\udebe\udbee\udfa1\ud9bc\udc0e\ud92b\udd93\ud950\uddb6\uda45\udd52\ud9bf\udf36\uf184\udbfc\udebb\ud876\udfb0\ud8f2\udd3a\udb7b\udea2\ud8f7\udc99\udb3e\udd7e\udb87\udcbd\ud851\uded7\udb30\ude37\ud951\udc0a\uda0a\udda9\ud95a\ude4b\ud9eb\udc2d\udac3\udf82\uda75\udd52\ucac6\udb6f\ude69\u4baa\uda60\udc0c\udb58\ude7d", "\ua3df\u9f96\ub6b2\u650d\ua384\u1c39\uc29e\u5e82\u4e65\u7515\ub32b\u3c1d\u9575\ub7a2\u92c6", "\ud9e2\udf8b\ud8ce\udce9\ud9a5\uddf5",
        37, 16519, -411252833, -5169272609745059728L, -58209L, true, false, (char) 8810, (char) 31892,
        Double.longBitsToDouble(0x3fd7c68fc4bd297cL), Double.longBitsToDouble(0x3fd074c623ba6baaL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html> |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012</body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&cap;&#56066;&#57266;&mu;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#56148;&#57117;&#55672;&#56791... |this=org.jsoup.nodes.Document:<html>\012<head>\012</head>\012<body>\012 &#21801;&#56240;&#56455;&#56181;&#56956;&#373;&cap;&#56066;&#57266;&mu;&#55652;&#56561;&#55368;&#56626;&#55885;&#56713;&#56152;&#56963;&#55299;&#57132;&#55440;&#56485;&#56262;&#56606;&#56178;&#56983;&#56158;&#56583;&#55427;&#56940;&#54815;&#56148;&#57117;&#55672;&#56791...\012",
        Z.run(T, 2, 1, 8, 4, "\u5529\udbb0\udc87\udb75\ude7c\u0175\u2229\udb02\udfb2\u03bc\ud964\udcf1\ud848\udd32\uda4d\udd89\udb58\ude83\ud803\udf2c\ud890\udca5\udbc6\udd1e\udb72\ude97\udb5e\udd07\ud883\ude6c\ud61f\udb54\udf1d\ud978\uddd7\ud98e\udc83\ud9df\udc98\udbd6\udfb3\ud960\udeea\uacc8", "\uaf04\u1070\u44d1\u079f\u5816\u3d53\u51f1\u932a\u65aa\u0ce5\u2775\u884a\u2a10\u8297\u2b92\ud49a\ua829\u4363\u93a3\000\000\u78e3\u5182\u715c\u2cbc\u25a0\u34d6\uc813\u92ed\000\u311f\u3e8e\uc1d6\u5bad\u8b64\u6cdb", "\ubf3e\u00f0\ud92c\uddd7\uda27\ude8a\udb46\udf1f\u5087\udb09\udcaa",
        29, 88319, -224352194, 593778261598256533L, 96608L, true, false, (char) 17282, (char) 13029,
        Double.longBitsToDouble(0x3fe8d661823269fdL), Double.longBitsToDouble(0x3feaa006c800009bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Document|normalise|org.jsoup.nodes.Element|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|normalise||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|body||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|createElement|java.lang.String|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|createShell|java.lang.String|static",
    "M|org.jsoup.nodes.Document|head||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|nodeName||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|outerHtml||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|text|java.lang.String|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|title||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|title|java.lang.String|new:org.jsoup.nodes.Document:java.lang.String",
    "C|org.jsoup.nodes.Document|<init>|java.lang.String",
    "M|org.jsoup.nodes.Document|normalise|org.jsoup.nodes.Element|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|normalise||new:org.jsoup.nodes.Document:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
