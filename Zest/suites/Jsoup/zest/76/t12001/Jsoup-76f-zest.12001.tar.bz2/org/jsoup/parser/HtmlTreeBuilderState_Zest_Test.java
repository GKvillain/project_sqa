package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilderState_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 1, 6, 1, 6, "\ud8a6\udf00\udac9\udf1c\uda74\ude0e\udb70\udec8\udacf\ude04\ud88d\ude13\udb78\udf0e\ud95c\udcbd\uda0f\udf48\udabf\udf20\udb95\udc00\udaff\udd6f\ud9b1\udfd7\ud825\udc80\ud808\udd43\udaae\udf33\udacd\ude8d\udb39\udd93\ud92d\ude1a\udb74\uddd7\udb63\udf9e\udb29\udfe2\udacf\udc8d\udb42\udd39\udafe\udff6\udba8\udc60\uda87\udd0d", "\uac32", "\ud9c3\uddec\ud818\udd5a\uda3b\ude6c\u4d7d\ud91d\udc8d",
        8, 99097, -1088741569, 4447297708980300715L, 79048L, false, false, (char) 8601, (char) 31424,
        Double.longBitsToDouble(0x3fedd27582bfe823L), Double.longBitsToDouble(0x3fc3d868536b139cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 1, 6, "\ud80a\udf64\udac2\udf55\udbe1\ude25", "\u91a1\u59ce", "\udabf\udf20\udb95\udc00\udaff\udd6f\ud9b1\udfd7\ud825\udc80\udb9b\udc0b\uda56\udc55\ud9b1\ude73\ud8db\udc84\udab4\udc57\uda26\udca9\udb63\udf9e\udb29\udfe2\udacf\udc8d\ud895\udd68\udafe\udfb9\uda19\udcb9\udadc\udf45\uda01\udc48\uda77\udfa8\udb40\ude4d\udb05\udec5\uda36\ude0d",
        10, 15889, -4911503, 6725079295789429662L, -37311L, true, true, (char) 47311, (char) 10594,
        Double.longBitsToDouble(0x3fefa0d16c98e5baL), Double.longBitsToDouble(0x3fe362946f48da50L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 1, 6, 0, 6, "\ud8a6\udf00\udac9\udf1c\uda74\ude0e\udb70\udec8\udacf\ude04\ud88d\ude13\udb78\udf0e\udb48\udc0b\ud9d6\ude29\udaba\udd01\udb95\udc00\udaff\udd6f\ud9b1\udfd7\ud825\udc80\ud808\udd43\ud832\udf35\udacd\ude8d\udb39\udd93\ud92d\ude1a\udb74\uddd7\udb63\udf9e\udb29\udfe2\udacf\udc8d\udb42\udd39\udafe\udff6\udba8\udc60\ud926\udc3c", "\uac32\u010d\u5fe3", "\uda3b\ude6c\u4d7d\ud91d\udc8d\ud800\ude4f\ud9a7\udf56\udbe0\udf6b",
        23, 68067, -440739852, 5948486101819752078L, -75206L, false, false, (char) 15075, (char) 52192,
        Double.longBitsToDouble(0x3fdc8c4e7e8a470eL), Double.longBitsToDouble(0x3fcc83a3c871d158L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 6, "\ud8a6\udf00\ud859\udcc5\uda74\ude0e\ud880\uded0\udacf\ude04\udaa1\udcbc\ud8fd\ude27\uda2e\ude7a\uda0f\udf99\ud967\udff4\uda54\udcba\udafe\udcbd\uda23\udd50\ud80e\udf66\ud808\udd43\udae6\udf5c\udacd\ude8d\udb39\udd93\ud920\udd32\udb74\uddd7\udb26\udd9f\udbfc\udd16\udbf2\udf14\ud87b\uded2\ud853\uddd3\udba8\udcfd\uda87\udd0d", "\uac32\u010d\u5fe3\ucb93\uc232\u2618\u3e9a\u0e6b\u35e9\u815c\u422a\u32da\ud6b1", "\ud85b\udc28\uda3a\udc68\udad1\udd9f\u3252\uda6b\udf2a\ud98b\udd22",
        22, -764, -1460671553, -3789613596278457545L, 72204L, true, false, (char) 56340, (char) 23321,
        Double.longBitsToDouble(0x3fea5fd9c9c7820fL), Double.longBitsToDouble(0x3fd53ae0c134a688L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 3, 3, 0, "\ud8a6\ude84\udac9\udf1c\uda74\ude0e\udb70\udec8\udacf\ude04\ud88d\ude13\udb78\udf0e\ud95c\udcbdr\uda9d\ude8d\udb95\udc00\udaff\udd6f\ud9b1\udfd7\ud825\udc80\ud808\udd43\udaae\udf33\udacd\ude8d\udb39\udd93\ud92d\udd7c\udb74\udd06\udb63\udf9e\udb29\udfe2\udacf\udc8d\udb42\udd39\udafe\udff6\udba8\udc60K", "\uac32", "\uda85\ude8e\ud818\udd29\uda3b\ude6c\u4d7d\ud91d\udc8d",
        8, 99097, -1088741569, 4447297708980300544L, 79048L, false, false, (char) 8601, (char) 31424,
        Double.longBitsToDouble(0x3fedd27582bfe823L), Double.longBitsToDouble(0x3fc3d868536b139cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 6, "\000\udb85\udc01\uda74\ude0e\udb70\udec8\udacf\ude04\ud88d\ude13\udb78\udf0e\ud95c\udcbd\uda0f\udf48\udabf\udf20\udb95\udc00\udaff\udd6f\ud9b1\udfd7\ud825\udc80\ud808\udd43\udaae\udf33\udacd\ude8d\udb39\udd93\uce9e\000\udb63\udf9e\udb29\udfe2\uda6d\ude5d\udb42\udd39\udafe\udff6\udaab\udc22\uda5c\udc0d", "\uac32", "\ud9c3\uddec\ud818\udd5a\udba2\udc61\u4d7d\ud91d\udc8d",
        4, -1000, 0, 4447297708980300715L, -16904L, false, false, (char) 8601, (char) 31424,
        Double.longBitsToDouble(0x3fedd27582bfe823L), Double.longBitsToDouble(0x3fc3d868536b139cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 4, "\ud8a6\udf00\udac9\udf1c\uda74\ude0e\udb87\udfc8\udacf\ude04\ud88d\ude13\udb78\udf0e\udafc\udf96\uda2e\ude3b\udabf\udf20\udb95\udc10\udaff\udd6f\uda40\udfc0\ud938\udfe9\ud8a9\ude49\uda61\udf39", "\uc52a\u8a77\u34b6\ua533\u33ae\u63d8\u1be7\u5171\ua395\u5609\u0a85\ubf25\u49db", "\ud9b6\uddd1\udbb1\udd1f\udaec\udcb4\udbe2\udd85\ud98f\uddf6\udbcf\udf19\udbe0\udfb7",
        23, 36187, -2121533634, -5799573090137309552L, -75206L, false, true, (char) 36583, (char) 19761,
        Double.longBitsToDouble(0x3fcb589cfc510f40L), Double.longBitsToDouble(0x3fdd3be11ea73e34L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 5, "\ud80a\udf64\uda98\udf40\udae9\uddcc", "\u91a1", "\uda0f\udf48\udabf\udf20\udb95\udc00\udbc3\udc4d\ud9b1\udfd7\ud825\udc80\ud9cb\udc44\uda6c\ude5e\ud9b1\ude73\ud8db\udc84\udab4\udc57\uda26\udca9\udb63\udf9e\ud866\ude82\udb52\udc00\ud895\udd68\udafe\udfb9",
        33, 7936, -665536865, -7949444702370263440L, 40152L, true, false, (char) 34806, (char) 36227,
        Double.longBitsToDouble(0x3fefea4bcb9e5d54L), Double.longBitsToDouble(0x3f821fb9384de300L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 6, "\ud8a6\udf00\udac9\udf1c\uda74\ude0e\udb70\udec8\udacf\ude04\ud88d\ude13\ud907\uddb6\udb78\udf1e\ud9d6\ude29\udaba\udd01\udb95\udc00\udaff\udd6f\ud9b1\udfd7\ud825\udc80\ud8e4\udf71\ud832\udefe\udacd\ude8d\udb39\udd93\ud92d\ude1a\ud86d\uddf4\udb63\udf9e\udb29\udfe2\uda7e\udd4a\udb42\udd4d\ud949\udefb\uda00\udd3e\ud926\udc3c", "\uac32\u010d\u5fe3", "\uda3b\ude6c\u4d7d\ud91d\udcc6\ud800\ude4f\ud9a7\udf56\uda45\udebc",
        5, 48541, 1840921458, 5948579388509421198L, 22793L, true, true, (char) 16216, (char) 52192,
        Double.longBitsToDouble(0x3fdc8c4e7e8a470eL), Double.longBitsToDouble(0x3fcc83a3c871d158L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 3, 5, "\ud8a6\udf00\ud859\udcc5\uda74\ude0e\ud880\uded0\udacf\ude04\udaa1\udcbc\ud8fd\ude27\uda2e\ude7a\uda0f\udf99\ud967\udff4\uda54\udcba\udafe\udcbd\uda23\udd50\ud80e\udf66\udb60\udf0e\ud8ba\ude39\ud8b3\udf09\udb39\udd93\ud920\udd32\udb74\uddd7\udb26\udd9f\udbfc\udd16\udbf2\udf14\ud87b\uded2\ud853\uddd3\udba8\udcfd\uda87\udd0d", "\uac32\u010d\u5fe3\ucb93\uc232\u2618\u3e9a\u0e6b\u35e9\u815c\u422a\u32da\u1551", "\ud85b\udc28\uda3a\udc68\udad1\udd9f\u3252\uda6b\udf2a\ud98b\udd22",
        22, -764, -1460671553, -3789613596278457545L, 72204L, true, false, (char) 56340, (char) 23321,
        Double.longBitsToDouble(0x3fea5fd9cfc3aaffL), Double.longBitsToDouble(0x3fdda2b37134a688L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 5, 1, "\ud8a6\udf00\ud859\udcc5\uda74\ude0e\ud880\ude8b\udacf\ude04\udaa1\udcbc\ud8fd\ude27\uda2e\ude7a\uda0f\udf99\ud967\udff4\uda54\udcba\udafe\udcbd\uda23\udd50", "\u3330\u52f7\u8de4\ua75d", "\udbfc\udd16\udbf2\udf14\ud87b\uded2\ud853\uddd3\udba8\udcfd\uda87\udd0d\ud884\uddea\ud964\udfbd\ud889\udcc1\udb05\udec5\uda36\ude0d\ud9c3\uddec\ud818\udd5a\uda3b\ude6c\u4d7d\ud9af\udd63\udbc2\udd0a\udb53\udec8\udbe0\udf40\ud847\udd57",
        51, 23005, 1714856046, 7012316376309465693L, 43007L, false, true, (char) 26237, (char) 8967,
        Double.longBitsToDouble(0x3fe41d477b37cb68L), Double.longBitsToDouble(0x3fe0f96ea754b64dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 2, 6, 6, 6, "\ud8a6\udf00\ud859\udcc5\uda74\ude0e\ud880\uded0\ud944\ude9f\uda2f\udd58\ud8fd\ude27\uda2e\ude7a\uda0f\udf99\ud967\udff4\uda7e\udcba\udafe\udcbd\uda23\udd50\ud80e\udf66\ud808\udd43\udae6\udf5c\udacd\ude8d\udb39\udd93\ud920\udd32\ud981\udfba\udb62\ude4c", "\ub0cb\u11cb\u5ae7\ua395\u1a0d\u3b68", "\uda6b\udc28\ud90b\uddb3\ud99f\udd2e\uda3b\ude50\u4d7d",
        51, 67081, 251768799, 7680618531040457136L, 86213L, false, false, (char) 53497, (char) 4269,
        Double.longBitsToDouble(0x3feca3dfebba2c53L), Double.longBitsToDouble(0x3fe4414b089ec342L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\0121=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 2, 6, 6, 6, "\ud8a6\udf00", "\u69c2\u0c01\u3d5e", "\uda0f\udf99\ud967\udff4\uda54\udcba\udafe\udcbd\uda23\udd50\uda9a\uddb8\uda69\udea9\udae6\udf5c\udacd\ude8d\udb39\udd93\ud920\udd32\udb74\uddd7\udb26\udd9f\udbfc\udd16\udbf2\udf14\ud87b\uded2\ud853\uddd3\udba8\udcfd\uda87\udd0d\ud895\ude5f\uda77\udfa8\udb40\ude4d\udb05\udec5\uda36\ude0d\ud9c3\uddec",
        44, 50873, 1565804541, 1143056266942702409L, -30709L, true, true, (char) 168, (char) 53578,
        Double.longBitsToDouble(0x3fe2eb0a848a0b94L), Double.longBitsToDouble(0x3fedd2d7aabfe823L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 3, 0, "\ud8a6\ude84\udac9\udf1c\uda74\ude0e\udb70\udec8\udacf\ude04\ud88d\ude13\udb78\udf0e\ud95c\udcbd\udba9\udea5\uda9d\ude8d\udb95\udc00\udaff\udd6f\ud9b1\udfd7\ud825\udc77\ud808\udd43\udaae\udf33\udacd\ude8d\ud850\udf7e\udb58\udd74\udba3\udc8a\ud9d5\udd50\udb29\udfe2\udacf\udc8d\ud846\udd37\udafe\udff6\udba8\udc60K", "\uac32", "\ue414\ud818\uddfc\ud818\udc62\u4d7d",
        29, 44873, -1577519903, -4676109431615260236L, 86356L, false, true, (char) 20973, (char) 32396,
        Double.longBitsToDouble(0x3fcb433e2ee93ac0L), Double.longBitsToDouble(0x3fe5ff411db353d6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 4, "\ud80a\udf26\ud988\udf46\ud998\udca2\ud863\udc56\ud811\udf39\ud81e\udc89\udae3\uddb0\ud97a\udec0\u4380\udabf\udf56", "\u0ae1\u50d3\u441b\uc40a", "\udaac\udc2e\ud869\udea7",
        8, 35816, -1532727726, -5697165606227010242L, 67732L, false, false, (char) 29535, (char) 38648,
        Double.longBitsToDouble(0x3fa21989517e1510L), Double.longBitsToDouble(0x3fc2dbe008c5cda8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 1, 6, 1, 6, "\ud8a6\udf00\ud98b\udebe\udb35\udeab\uda56\ude62\ud93b\udf1d\uf691\udb87\udc40\ud95c\udcb6\uda0f\udf48\udabf\udf20\udb95\udc00\udaff\udd6f\ud9a4\udf11\udb3f\ude19\ud8d5\uddea\udae1\udd81\udacd\ude8d\udb39\udd93\ud92d\ude1a\udb74\uddd7\udb63\udf9e\udb29\udfe2\udad7\ude8d\udb42\udd39\udafe\udff6\udba8\udc60\uda87\udd0d", "\uac32", "\ud9c3\uddec\ud818\udd5a\uda3b\ude6c\u4d7d\udaa3\udf52",
        8, 42009, -1088741587, 3294376204373413647L, 83656L, false, false, (char) 55247, (char) 55487,
        Double.longBitsToDouble(0x3fedd27582bfe823L), Double.longBitsToDouble(0x3fc3d868536b139cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 3, 6, 0, "", "\u4112\u712f\ua658m\000\000\u21f5", "\udaff\udd6f",
        40, 38790, -1622427914, -6146568807475127773L, -34464L, false, false, (char) 22272, (char) 2566,
        Double.longBitsToDouble(0x3fe294dc011169c5L), Double.longBitsToDouble(0x3fbec0ad00073220L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[Lorg.jsoup.parser.HtmlTreeBuilderState;:[[Initial, BeforeHtml, BeforeHead, InHead, InHeadNoscript, AfterHead, InBody, Text, InTable, InTableText, InCaption, InColumnGroup, InTableBody, InRow, InCell, InSelect, InSelectInTable, AfterBody, InFrameset, AfterFrameset, AfterAfterBody, AfterAfterFrameset, ForeignContent]]\012",
        Z.run(T, 1, 6, 1, 6, "\ud8a6\udf00\udac9\udf1c\uda74\ude0e\udb70\udec8\udacf\ude04\ud88d\ude13\udb78\udf0e\udaa4\udcc1\uda0f\udf48\ud9a0\ude72\udb94\udfcd\udaff\udd6f\ud9b1\udfd7\ud825\udc80\ud808\udd43\udaae\udf33\udacd\ude8d\udb39\udd93\ud92d\ude1a\udb74\uddd7\udb63\udf9e\udb4a\uddf2\udacf\udc8d\udb42\udd39\udafe\udff6\udba8\udc60\uda87\udd0d", "\uac32", "\ud9c3\uddec\ud818\udd5a\uda3b\ude6c\u4d7d\ud91d\udc8d",
        8, 99097, -1088741569, 4447297708980300715L, 79048L, false, false, (char) 8601, (char) 31424,
        Double.longBitsToDouble(0x3fedd27582bfe823L), Double.longBitsToDouble(0x3fc3d868536b139cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 3, 3, 6, "", "\u4112\u69c2\ua658\ubbb8\u883b\u10b9\ua52f", "\udafe\udcbd\uda23\udd50\ud80e\udf66\ud808\udd43",
        34, 79539, -1782840361, -628927566262265135L, 23392L, false, true, (char) 451, (char) 19678,
        Double.longBitsToDouble(0x3fecf8673e29a6edL), Double.longBitsToDouble(0x3fe3848d68cb419cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 3, 1, 6, "\012\udb85\udc01\uda74\ude0e\udb70\udec8\ud884\ude3f\uda30\udc61\uda50\ude9e\ud95c\udd23\uda0f\udf48\udabf\udf20\udb95\udc00\udaff\udd6f\ud932\ude58\ud825\udc80\ud808\udd43\udaae\udf33\udacd\ude8d\udb39\udd93\uce9e\udaf3\udc98\uda04\uddcf\ud993\udce9\ud887\ude12\udb45\uddea\udafe\udff6\udaab\udc22\uda5c\udc0d", "\ua30c", "\ud9c3\uddec\ud818\udd5a\udba2\udc61\u4d7d\ud91d\udc8d",
        36, 90112, 572980648, 4456727867252665259L, 13412L, false, false, (char) 8601, (char) 18073,
        Double.longBitsToDouble(0x3fedd2758778e823L), Double.longBitsToDouble(0x3fc3c011336b139cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 6, "\ud8a6\udf00\udac9\udf1c\uda74\ude0e\udb70\udec8\udacf\ude04\ud8bf\ude0b\udb78\udf0e\ud95c\udcbd\uda0f\udf48\ud874\udf5b\udb95\udc00\udaff\udd6f\ud9b1\udfd7\ud825\udc80\ud808\udd43\udaae\udf33\udacd\ude8d\u015a\ud86b\ude64\udaec\udd13\udb63\udd93\udb29\udfe2\udacf\udc8d\udb42\udd39\udafe\udff6\udba8\udc60\uda87\udd0d", "\u0cca", "\ud87e\udd88\ud818\udd88\udba0\udd5e\u4d7d\ud91d\udc8d\ud800\ude4f",
        -3, 37431, 1035467188, 1886422937212999668L, -67636L, false, true, (char) 10176, (char) 61717,
        Double.longBitsToDouble(0x3fe13c59189ec342L), Double.longBitsToDouble(0x3fcb589ce978f3c4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 3, 0, "\012\udb85\udc01\uda74\ude0e\udb70\udec8\ud884\ude3f\uda30\udc61\uda1c\udd9e\ud95c\udd23\ud898\udd6c\udb23\ude75\udb95\udc00\udae3\ude6f\udb8a\ude1d\udaa4\udf6e\ud808\udd43\udaae\udf33\udacd\uded4\udb39\udd93\uce9e\udaf3\udc98\ud899\ude59\ud993\udcd1\ud887\ude12\ud90b\udccd\udafe\udff6\udaab\udc22\uda5c\udc0d", "\ua30c", "\ud8cb\ude44\ud8c1\udc9f\udba2\udc61\u4d7d\ud91d\udc8d",
        36, 90112, 572980648, 4456727867252665259L, 13412L, false, false, (char) 8601, (char) 18073,
        Double.longBitsToDouble(0x3fedd2758778e823L), Double.longBitsToDouble(0x3fc3c011336b139cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 3, 1, 6, "\015\udb85\udc01\udabc\ude12\udb70\udec8\ud884\ude3f\uda30\udc61\uda50\ude9e\ud95c\udd23\uda0f\udf48\udabf\udf20\udb95\udc00\udaff\udd6f\ud932\ude58\ud825\udc80\udb5d\udf10\udab9\udc88\udacd\ude8d\udb46\ude34\uce9e\udaf3\udc98\uda04\uddcf\ud869\udd35\ud88f\udd91\udb45\uddea\udafe\udff6\udaab\udc22\uda5c\udc0d", "\u360c", "\ud9c3\uddec\ud818\udd5a\udba2\udc61\u4d7d\ud91d\udc8d",
        36, 90112, 572980648, 4456727867252665259L, 48622L, false, false, (char) 8601, (char) 18073,
        Double.longBitsToDouble(0x3fedd2758778e823L), Double.longBitsToDouble(0x3fc3c011336b139cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 3, 1, 6, " \udb85\udc01\udabc\ude12\udb70\udec8\ud884\ude3f\uda30\udc61\uda50\ude9e\ud95c\udd23\uda0f\udf48\udabf\udf20\udb95\udc00\udaff\udd6f\ud932\ude58\ud825\udc80\udb5d\udf10\udab9\udc88\udacd\ude8d\udb46\ude34\uce9e\ube22\uda04\udde6\ud869\udd35\ud88f\udd91\udaf4\udd59\udb88\udeb5\udaab\udcdb\uda5c\udc0d\uda01\udc48\uda77\udfa8\ud886\udf3e\udaf7\uddfa\uda36\ude0d\ud9c3\uddec\ud818\udd5a\udba2\udc61", "\uac40\ub19b\ubf4b\ucc3e", "\udb98\udd70\ud9af\udc33\udae0\udcce\ud854\udd56\u3252\ud827\udf80\ud98b\udd22\ud8e3\ude6f\uda04\udfb3\ud88a\uddef\uda38\ude9e\udb0d\udea4\udba3\udeaf\ud8de\udf8d\ud958\udcd5\u7a90\ud956\ude2c\ud9b5\udffa\ud8e3\uddfc\uda3f\udfca\ua553\ud806\udd1f\ud93c\udf00\ud905\udd8d\ud8b2\udf99\udb29\udf30\ud9e5\udd97\udbee\udd50\ud8e3\udefd\udba3\udfd0\uda9e\ude05\udb8c\udd69",
        24, 36014, -2144073738, 5859052353169929579L, -24743L, true, false, (char) 27132, (char) 12744,
        Double.longBitsToDouble(0x3fea91864abe6607L), Double.longBitsToDouble(0x3feb2b420ee1aedbL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 3, 1, 6, "\011\ud81c\udf8d\udabc\ude12\udb70\udec8\udadc\udeca\ud940\uddaf\uda50\ude9e\ud95c\udd23\uda0f\udf48\udbd6\udd2c\uda2f\udd83\udae8\udd36\udb22\ude50\ud9bb\udc0b\udb5d\udf10\udab9\udc88\udacd\ude8d\udb46\ude34\uce9e\udaf3\udc98\uda04\uddcf\ud869\udd35\ud88f\udd91\udb45\uddea\uda59\ude83\uda34\ude67\ud955\uddcc", "\u359f", "\ud9c3\uddec\ud818\udd5a\udba2\udc61\u4d7d\ud91d\udc8d",
        36, 90112, 572980648, 4456727867252665259L, 48622L, false, false, (char) 8601, (char) 18073,
        Double.longBitsToDouble(0x3fedd2758778e823L), Double.longBitsToDouble(0x3fc3c01134f7139cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 3, 6, "\011\ud81c\udf8d\udabc\ude12\udb42\udff2\udaec\udde8\uda92\uddef\ud960\udd99\udb2c\udfc7\udb44\udce2\udb14\ude39\uda26\udd34\udb0a\udc6d\ud9df\udddc\ud92f\udd26\udbb5\ude9b\udab9\udc3f\udacd\ude8d\ud88e\udf05\uce9e\udaf3\udc98\uda04\uddcf\ud869\udd35\ud946\udd2b\udb2f\uddff\ud859\udebd\udbef\udc06\ud868\udee8", "\ua5f7\ua041\u23df\u1bf9\uc232\u7f41\u3e9a\u3d3a\uad0d\ub19b\u7622\u6de6\u235a\u58d2\u9803\u2db9\ucac5\ubb70\u722b\u4b0e\ube21\u9e45\u03df\u9492\u60c0\u859f", "\udb95\udfb9\udbd7\udca0\udac6\udcdf\udb70\udd7a\udb05\udce7\ud864\ude32\ud89a\udead\ud968\udf95\ud952\ude07\u9bfb\ud8ee\udda5\udb1a\udded\ud858\udde5\udad2\udec2\uda30\udeba\ud966\udc7a\uf493\udaba\udcd5\ud8e2\udcd8\udb0f\udd90\ud85f\udce8\udb08\udfff\udabb\udd68\ud8d8\udc7d\ud88a\udfae\u87cf\uda1a\udc28\udaca\udea3\ud93f\udeb3\udb26\udd88\udb7c\uddaf\ud91d\ude19\udad7\udc75\uda5a\ude43\uda24\udf4f\udbfa\udd96\ud8e0\uded2\udbdc\udd41\udb25\udcd6\udbd3\udec2\ud94f\udc28\ud95a\udca5\ud9f0\udfb7\ud9bd\udc98\udba1\udda5\udb2f\uddd8\ud8b8\udd05",
        36, 66858, 1831759560, -1893266946129175035L, 55367L, true, false, (char) 42660, (char) 6275,
        Double.longBitsToDouble(0x3fd22a1873f5ddf2L), Double.longBitsToDouble(0x3fc19b990821e330L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 3, 1, "\015\udae2\uddb1\ud8fc\udecf\ud900\udd9e\ud90c\udee1\uda30\udc61\uda47\udc9e\ud95c\udd23\uda0f\udf48\udabf\udf20\udb95\udc00\udaff\udd6f", "\uc0af", "\udade\ude7f\udbfe\udf1b\udaf3\udc98\uda04\uddcf\ud869\udd35\ud981\udd6b\udb45\uddea\udb35\udcb1\ud970\udf55\u53e2\uda01\udc48",
        18, 66401, 1702297600, 8050786281304995459L, -99887L, true, true, (char) 20722, (char) 13279,
        Double.longBitsToDouble(0x3eaa5a8669b00000L), Double.longBitsToDouble(0x3fe3111113ab3dd9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilderState|process|org.jsoup.parser.Token,org.jsoup.parser.HtmlTreeBuilder|fac:org.jsoup.parser.HtmlTreeBuilderState:valueOf:java.lang.String",
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRawtext|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRcData|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|isWhitespace|java.lang.String|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|isWhitespace|org.jsoup.parser.Token|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|valueOf|java.lang.String|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|values||static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|process|org.jsoup.parser.Token,org.jsoup.parser.HtmlTreeBuilder|fac:org.jsoup.parser.HtmlTreeBuilderState:valueOf:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
