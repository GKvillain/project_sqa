package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilderState_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 0, 0, "\ud97c\udf97\udab6\udf14\udb91\udefc\uda61\udf8e\udb7f\udcb8\udbcd\udf89\ud96d\udd03\uda59\udec4\uda55\udc8a\uf86a\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udbd6\udd43\ud8ff\udcb1\ud810\udce6", "\u2796\u14b3\u596c", "\ud907\udf8e\udb4b\ude0a\udb14\udcbe\uda81\udcf6",
        43, 80472, 1719526518, -1513579068612213347L, 67092L, false, true, (char) 24251, (char) 61470,
        Double.longBitsToDouble(0x3feaa6862a22e92eL), Double.longBitsToDouble(0x3fb374f2a85d5a30L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 0, 0, "\ud97c\udf97\udab6\udf14\udb91\udefc\uda61\udf8e\udb7f\udcb8\udbcd\udf89\ud96d\udd03\uda59\udec4\uda55\udc8a\uf86a\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udbd6\udd43\ud8ff\udcb1\ud9f7\ude3f", "\u2796\u14b3\u596c\u8af3\uceb5", "\ud899\udd95\uda52\ude9a\udb1a\udc20\uda36\udf40\ud8d0\ude80\ud833\ude9e\udad2\udd24\ud8b8\ude97\udbd4\udd25\uda39\udc93\ud8bb\udf87\udaae\udcea\udbc4\udff5\ud9b7\ude30\udaf4\uddfb\udad3\ude20\udbe5\udd2e\udb5c\udf9b\udba1\udc15\ud97b\udca9\ud987\udf2b\udb36\ude17\ud949\udca7\ud998\udcaf\udbf2\udd6b\uda77\udd85\ud97d\udd33\udaaf\udd9b\udb4d\udf8f\uda3e\udccf\ud9d9\udee6\uda8f\udddb",
        14, 26234, 1036438496, 7704637176563920246L, -18208L, false, true, (char) 22220, (char) 46226,
        Double.longBitsToDouble(0x3fd2348586bfd628L), Double.longBitsToDouble(0x3fe35171f20c634cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 2, 0, 0, "\ud97c\udf97\udab6\udf14\udb91\udefc\uda61\udf8e\udb86\uddfa\udbcd\udf89\ud908\udcb2\ud91f\udc8f\udb7e\udc5c\ud868\uddd3\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udb79\udfab\udb67\udc8e\ud8e4\udc92", "\u2796\u14b3\u716b", "\ud8ec\udcc7\udb4b\ude0a\udb14\udcbe\uda81\udcf6",
        43, 80472, 1719526518, -1513579068612213347L, 67092L, false, true, (char) 24251, (char) 61470,
        Double.longBitsToDouble(0x3feaa686289b7807L), Double.longBitsToDouble(0x3fb374f2a85d5a30L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 0, "\ud97c\udf97\udab6\udf14\udb9a\udcfc\uda61\udf8e\udb7f\udcb8\udbcd\udf89\ud96d\udd03\uda59\udec4\uda55\udc8a\uf86a\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udbd6\udd43\ud8ff\udcb1\ud810\udce6", "\u2796\u14b3\u596c", "\ud883\udc68\udb5c\udc23\udb14\udd34\udba5\ude09",
        52, 80472, 1719526518, -1513579068612213347L, 67092L, false, true, (char) 24251, (char) 61470,
        Double.longBitsToDouble(0x3feaa6862a22e92eL), Double.longBitsToDouble(0x3fb374f2a85d5a30L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 2, "\ud976\udff7\udab6\udf14\ud8ca\udf1a\ud94d\ude8d\ud862\udfe2\udbcd\udf89\ud96d\udd03\uda59\udec4", "\u5aa9\u6509", "\ud8ff\udcb1\ud860\udc2a\ud9d2\udce9\udb84\ude5b\udb03\udec8\udaaa\ude30\ud8ed\udd38\udb89\udd5f\uda7e\udc81\ud907\udf8e\udb4b\ude0a\udbbc\udf92\ud8cd\ude97\udb05\udc72\uda36\udf40\ud8d0\ude80\ud833\ude9e\udad2\udd24\ud8b8\ude97\udbd4\udd25\ud9a2\ude81\udb29\udc21\udaae\udcfc\uda62\udc88",
        31, 66375, -741715422, -6105191915590609047L, -28799L, false, false, (char) 23724, (char) 38650,
        Double.longBitsToDouble(0x3fea35fdee84c744L), Double.longBitsToDouble(0x3fe0e98f315c6a00L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 4, "\ud914\udc35\ud8a9\ude63\udb79\udd36\ud9d9\ude0c\udaf0\udc34\udbcd\udf89\ud96d\udd03\uda59\udec4\ud94a\udf86\udb24\udc19\ua095\ud971\ude7c\uda2b\udce5\uda47\udd9c\ud83b\udc45\ud912\udeb3", "\u2796\u90f0", "\ud951\udd09\uda56\ude47\udb32\uddfe\udace\udc4f\uda81\udcf6\udba4\ude26\ud9c9\udd40\ud8d0\ude58\uda1a\udfb0\udad2\udca5\uda54\udc62\ud80b\ude16\ue2b4",
        -1, 74462, -411324457, 3428272828102786122L, -90461L, false, false, (char) 29437, (char) 22617,
        Double.longBitsToDouble(0x3fe62809c6b92652L), Double.longBitsToDouble(0x3fa157cfeaf72e50L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 2, 0, 2, "", "\ud1d0\u3b54\u6a53\u10a7\u5853\uc1bd", "\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udb79\udfab",
        12, 84464, 1894384375, -1517451768388618318L, 23544L, false, false, (char) 28957, (char) 55074,
        Double.longBitsToDouble(0x3fa1ebfdc7e98950L), Double.longBitsToDouble(0x3fd74c06ba99ef60L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 4, "\ud97c\udf97\udab6\udf14\udb91\udefc\uda61\udf8e\udb86\uddfa\udbcd\udf89\ud908\udcb2\ud91f\udc8f\udb7e\udc5c\ud868\uddd3\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udb79\udfab\udb67\udc8e\ud8e4\udc92", "\u2796\u14b3\u716b", "\ud8ec\udcc7\udb4b\ude0a\udb14\udcbe\uda81\udcf6",
        43, 80472, 1719526518, -1513579068612213347L, 67092L, false, true, (char) 24251, (char) 61470,
        Double.longBitsToDouble(0x3feaa686289b7807L), Double.longBitsToDouble(0x3fb374f2a85d5a30L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 0, "\ud97c\udf97\udab6\udf14\ud835\udd0a\uda61\udf8e\u2e5f\udbcd\udf96\ud96d\udd03\uda59\udec4\uda49\uddd1\uf86a\udaa4\udc92\ud98e\udc7c\uda5a\udc8a\ud8c4\udeb0\ud90c\udc5e\uda37\udc88", "\u268a\u14b3\u6629", "\ud883\udc68\udb5c\udc23\ud89a\uddf7\ud9a2\udc3d",
        20, 85529, 1719526518, -1513579068619842915L, 67092L, false, true, (char) 24251, (char) 61470,
        Double.longBitsToDouble(0x3feaa6862a22e92eL), Double.longBitsToDouble(0x3fe49da650e0c6aaL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 4, "\ud97c\udf97\udab6\udf14\udb91\udefc\uda61\udf8e\udb86\uddfa\udbcd\udf89\ud85e\udd5f\ud9db\udfa4\udb94\udd8e\ud868\uddd3\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udb79\udfab\udb67\udc8e\ud8e4\udc92", "\u2796\u14b3\u716b", "\udb2e\udcc8\ud9b0\udf62\udb14\udcbe\uda81\udcf6",
        24, 80485, 1719526518, -1513579068612213347L, 67092L, false, false, (char) 44088, (char) 61470,
        Double.longBitsToDouble(0x3feaa686289b7807L), Double.longBitsToDouble(0x3fb374f2a85d5a30L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 0, 0, "\ud97c\udf97\udab6\udf14\udb91\udefc\uda61\udf8e\udb17\ude04\udbcd\udf3d\ud96d\udd03\uda59\udec4\uda55\udc8a\uf86a\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udbd6\udd43\ud8ff\udcb1\ud810\udce6\ud9d2\udce9\ud8cc\udea4\ud8f4\udc7c\ud805\udf2e\uda1e\udf05\u8b50\udb28\ude45\ud907\udf39\udb4b\ude0a\udb14\udcbe\uda81\udcf6", "\u1ae5", "\ud8b8\ude97\udbd4\udd25\uda39\udc93\ud9a7\udcb1\udaae\udcfa\udbdf\udf27\ud9b7\ude30\udaf4\uddfb\u7787\udb02\udf4e\udae6\udc9f\ud848\uddd9\udad4\uddcb\ud862\udd0e",
        50, 40327, 118714390, 3343218505963957109L, -87208L, false, true, (char) 63224, (char) 1443,
        Double.longBitsToDouble(0x3fcbe2b83ffc2644L), Double.longBitsToDouble(0x3fc813a63d6bc7b8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 2, 2, 2, "", "\ud1d0\u3b54\u6abc\u10a7\u5853\uc1bd", "\udaa4\udc92\ud98e\udc7c\uda2b\udce5\udb79\udfab",
        57, 80878, 1894384351, -1517451768388618318L, -42691L, true, true, (char) 33860, (char) 46332,
        Double.longBitsToDouble(0x3fc3cbd855e5eb40L), Double.longBitsToDouble(0x3fe44eee90f04d45L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRawtext|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|handleRcData|org.jsoup.parser.Token$StartTag,org.jsoup.parser.HtmlTreeBuilder|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|isWhitespace|java.lang.String|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|isWhitespace|org.jsoup.parser.Token|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|process|org.jsoup.parser.Token,org.jsoup.parser.HtmlTreeBuilder|fac:org.jsoup.parser.HtmlTreeBuilderState:valueOf:java.lang.String",
    "M|org.jsoup.parser.HtmlTreeBuilderState|valueOf|java.lang.String|static",
    "M|org.jsoup.parser.HtmlTreeBuilderState|values||static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
