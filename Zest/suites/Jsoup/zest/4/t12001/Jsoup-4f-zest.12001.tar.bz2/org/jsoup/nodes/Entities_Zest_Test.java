package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Entities_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 3, "\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c\uacb3", "\uc818\ub431\ua884\uc52d\u9c26\u74bd\u6135\u5f8a\uae29\u00ca\u2bed\ub173\u73ee\u0785\u6d87\u26c1\u6228\u6f77\u3332\u2412\u5db5\uccfe", "\ud8aa\ude64\udba6\ude3d\ud9f6\udcfe\udae0\udc7e\ud82c\udf34\udbc7\udd8d\udb34\udfa7",
        8, 96464, -1477688341, 3651784039203450922L, 43949L, true, true, (char) 13900, (char) 15898,
        Double.longBitsToDouble(0x3fe5411544f3937fL), Double.longBitsToDouble(0x3fdc98a629048a22L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 3, "\udb5b\udded\ud992\udc00\udbfc\udefc\u5f5b\udad8\udf1c\uacb3", "\uc818\ub431\ua884\uc52d\ubc16\u750f\u6135\u5f8a\uae29\u00ca\u2bed\ub173\u73ee\u0785\u6d87\u26c1\u6228\u6f77\u3332\u340c\u5db5\uccfe", "\ud87a\udf53\udba6\ude3d\ud9f6\udcfe\udae0\udc7e\ud82c\udf34\udbc7\udd8d\udb34\udfa7",
        8, 96464, -1477688341, 3651784039203450922L, 43949L, true, false, (char) 55967, (char) 42519,
        Double.longBitsToDouble(0x3fe5411544f3937fL), Double.longBitsToDouble(0x3fdc98a579048a22L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\udb5b\udded\ue1f3\ud962\udcd5\u5f5b\udad8\udf1c\uacb3\012",
        Z.run(T, 1, 0, 3, 3, "\udb5b\udded\ue1f3\ud962\udcd5\u5f5b\udad8\udf1c\uacb3", "\uc818\ub431\ua884\uc52d\u9c26\u74a7\u6135\u5f8a\uae29\u00ca\u2bed\000\u73ee\u0785", "\ud975\ude21\ud8b8\udd87\ud80b\ude2e\udbde\udf37\udb1f\udf29\udbb6\ude09\udbf1\udd85\ud9a3\udc9f\ud8aa\ude64",
        7, -932, 15489792, 3098476545759331860L, -82613L, false, false, (char) 58070, (char) 31234,
        Double.longBitsToDouble(0x3fe26b0b7b33a806L), Double.longBitsToDouble(0x3fb7c87b500520d0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 3, 3, "\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c\uacb3", "\uc818\ub431\ua884\ub473\u9c26\u74bd\u6135\u5f8a\uae29\u00ca\u2bed\ub173\u73ee\u0785\u6d87\u26c1\u7124\u6f77\u3332\u23cc", "\uda65\udfff\ud9a3\udd38\ud8aa\udf08\udbf4\udc03\ud9f6\udcfe\udae0\udc7e\udb5d\udecd\udbc7\ude6b\ud8e0\udd3d\udb28\udde1\udad1\udf03\ud8af\udeba\uda2a\udd38\udb37\udd2e",
        56, 24085, 569209651, -6621957903258969600L, 86115L, false, false, (char) 39831, (char) 22842,
        Double.longBitsToDouble(0x3fd1fb464e64edd0L), Double.longBitsToDouble(0x3fdf0f6e7bddc99aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 3, "\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c\uacb3\ud991\udc64", "\ub431\ua884\uc52d\u9c26\u74bd\u6135\u5f8a", "\udbe8\udffc\ud886\udf07\ud853\udfc2\ud946\udc68\ud94c\ude82\udb80\udd85\ud991\udf21\ud8b8\udd87\ud80b\ude2e\udbde\udf37\udb3d\udf38\udbb6\ude09\udbf1\udd85\ud863\udc9f\udaaa\udf84\ud8f5\ude11\ud9f6\udcfe",
        22, 94440, 2128430612, 6480510929982949854L, -82613L, false, false, (char) 58070, (char) 31234,
        Double.longBitsToDouble(0x3fe26b0b7b33a806L), Double.longBitsToDouble(0x3fb7c87b500520d0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 3, 3, 3, "\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c", "\u90d9\uc7c7\ub431\u116d\uc52d\u040f\u74bd\u6135\u5f8a\uae29\u00ca\u2bed\ub173\u3d6a\u0e33\u6d87\u26c1\u6228\ua0bf\u9360\u2412\u5db5\ud6fd\u93a9\u62c9\u6b45\u7235\u5196\u4df5\u8be2\u3c70\u25ad\u064c", "\uda2a\udd38\udb37\udd2e\udbc6\ude96\udaed\udd1d\udb5d\udd32\uda2f\udef4\udb7d\udc0a\ud81a\udc43\uda4f\ude04\u91db\ud9fc\udd23",
        15, 28033, 328849092, 1061054486250648111L, 34234L, false, false, (char) 10741, (char) 27012,
        Double.longBitsToDouble(0x3fdefc4d1357e8eeL), Double.longBitsToDouble(0x3f6223208ae78600L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c\uacb3\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 0, 3, 3, "\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c\uacb3", "\uc818\ub431\ua884\uc52d\u9c26\u7537\u6135\u5f8a\u0cc6\u00ca\u2bed\ub173\u2f1c\u0785\u6d87\u26c1\u6228\u6f77\u3332\u2412\u5db5\uccfe", "\ud8aa\ude64\ud9d5\udd35\ud9f6\udcfe\udae0\udc7e\ud82c\udf34\udbc7\udd8d\udb34\udfa7",
        8, 96464, -1477688341, 3651784039203450922L, 43949L, true, true, (char) 13900, (char) 15898,
        Double.longBitsToDouble(0x3fe5411544f3937fL), Double.longBitsToDouble(0x3fdc98a629768a22L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 1, 3, 3, 3, "\udbed\udd56\ud99a\udf10\udbfc\udefc\udb33\ude8d\udaf3\ude48\udb80\uddf6", "\uc818\u1331", "\udac4\udc78\udb20\udc26\udbda\udc84\ud845\udde2\udba8\ude03\ud8a9\udfcf\udbe8\udffc\ud886\udf07\ud853\udfc2\ud946\udc68\ud94c\ude82\udb80\udd85\ud991\ude8a\udbd8\udf38\udb6f\udc30\udb1f\udefe\udaa7\udfc3\udbb6\ude09\udbf1\udd85",
        34, 94978, -477166613, 8227225791292529658L, -50900L, false, false, (char) 22743, (char) 31234,
        Double.longBitsToDouble(0x3fe7130b7e232543L), Double.longBitsToDouble(0x3fe5bbf6920060bdL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 3, "\udb5b\udded\ue1f3\ud962\udcd5\u5f5b\udad8\udf1c\uacb3", "\uc818\ub431\ua884\uc52d\u9c26\u3ea7\u6135\u5f8a\uae29\u00ca\u2bed\000\u73ee\u0785", "\ud975\ude21\uda1d\udc79\ud82d\udd0d\ud877\udfe4\ud8c4\udf54\udabf\udc64\ud97d\ude7c\ud9b9\ude80\ud8aa\ude64",
        7, 9612, -688068333, 3098476543062207764L, -82613L, false, false, (char) 58070, (char) 31234,
        Double.longBitsToDouble(0x3fe26b0b7b33a806L), Double.longBitsToDouble(0x3fb7c87b500520d0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 3, 3, 3, "\udb5b\udded\ue1f3\ud962\udcd5\u5f5b\udae0\udcf2\udbae\ude70", "\u3343\ub431\ua884\uc52d\u9c26\u227f\u9899\u5f8a\uae29\u00ca\u2bed\000\u73ee\u0785", "\ud975\ude21\ud8b8\udd87\ud80b\ude2e\udbde\udf37\udb1f\udf29\udbb6\ude09\udbf1\udd85\ud9a3\udc9f\ud8aa\ude64",
        7, -932, 15489792, 3112470416793093652L, -82613L, false, false, (char) 58070, (char) 31234,
        Double.longBitsToDouble(0x3fa63a3124cd9210L), Double.longBitsToDouble(0x3fb7c873900520d0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 1, 3, "\udb81\uddd7\ud93d\ude96\udb7b\udc29", "\uc793\u4b49\u89ae\uc818\ub470", "\udbd5\udc68\udb1f\udfd4\udae3\udcca\ud8e6\udc02",
        50, 15456, 1611236011, 3986828576951526437L, -66505L, false, false, (char) 50207, (char) 50703,
        Double.longBitsToDouble(0x3fe254b82b6b2de8L), Double.longBitsToDouble(0x3fdc457abf059f2aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 1, 3, 3, "", "", "\udad8\udf1c\uacb3\udb8d\udf4b\udb81\udd9d\ud91b\udd4b\uda82\udcf1\ud82d\udfc5\ud840\udfdb\udbd5\udc68\udb1f\udfd4\udae3\udcca\ud911\udc02\udba8\ude03\ud8a9\udfcf\udbe8\udffc\ud886\udf07\ud853\udfc2\ud946\udc68",
        49, 7496, 1687908839, -643713421157891879L, -100000L, true, false, (char) 11123, (char) 13271,
        Double.longBitsToDouble(0x3fdafd3c07d71e42L), Double.longBitsToDouble(0x3fe2222c43fa722cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c\0121=java.lang.String:\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c\012",
        Z.run(T, 2, 0, 0, 3, "\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udad8\udf1c", "\u89ae\u3787\u27c8\ua884\uc52d\u9c26\u7537\u6135\u5f8a\u80a0\u00ca\u2bed\ub173\u2f1c\u0785\u6d87\u26c1\u6228\u6f77\u3332\u2412\u5db5\uccfe\u93a9\u62c9\u6b45\u4cfd\u5196\u4df5\u8be2\u43b7\u692f\u8424", "\uda2a\udd38\udb37\udd2e\udbc6\ude96\udaed\udd1d\udb5d\udd32\ud859\udea9\udb7d\udc0a\ud81a\udc43\uda4f\ude04\u91db\udbc3\udd4a",
        29, 12849, -1834878658, 5650484530399468189L, -65145L, false, false, (char) 47474, (char) 50918,
        Double.longBitsToDouble(0x3fd095ea75bb8acaL), Double.longBitsToDouble(0x3fe13a205f265f38L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udbc5\udc73\ue592\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 3, "\udb5b\udded\ud93d\ude96\ud962\udcd5\u5f5b\udbc5\udc73\ue592", "\uc818\ub431\ua884\uc52d\u9c26\u7537\u6135\u5f8a\u0cc6\u00ca\u2bed\u0500\ud2d8\u0785\u6d87\u26c1\u6228\u6f77\u32d2\u2412\u5db5\uccfe", "\ud8aa\ude64\ud9d5\udd35\ud9f6\udcfe\udb1f\udf3b\ud831\ude73\udbc7\udd8d\udb34\udfa7",
        8, 96464, -1477688341, 3651784039203450922L, 43949L, true, true, (char) 13900, (char) 15898,
        Double.longBitsToDouble(0x3fe4291544f3937fL), Double.longBitsToDouble(0x3fdc98a629768a22L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Entities:@?\0121=new org.jsoup.nodes.Entities:@?\012",
        Z.run(T, 2, 3, 3, 1, "\udb81\uddd7\uda40\udf58\udb9a\udcfd\u5fb3\udad8\udf1c\uacb3\udb8d\udf4b\udb81\udd9d\ud91b\udd4b\uda82\udd30\udbdc\udd1f\ud8ef\udf69\udbd5\udc68\uda10\udfcc\udae3\udcca\ud8e6\udc02\udba5\udcee\u616c\uda8d\udf80\udbb1\udceb\ud853\udfc2\ud899\udf73\ud9c8\udde7\udb31\udd26\ud934\ude12\ud881\udff2\ud89e\udd1e\ud8bf\udff1\ud867\udfed\uda99\udeff\ud826\udc7e\ud8cc\ude02\ud801\udd24\udba4\uddb1\ud96a\ude57\udb25\uddfb", "\u803e\u3ddc\uc088\u9163f\u24fa\ub2a5\ud4c4\u4ead", "\udbf3\udf5c\udb58\udcb2\ud991\udefd\u4294\uda67\udedf\ud901\udc6f\ud8ba\udd8a\udb4e\ude28\ud8e4\uddb1\ud805\udd2c",
        0, 89791, -1943741408, -6713370239147970418L, -1864L, false, false, (char) 37670, (char) 3229,
        Double.longBitsToDouble(0x3fe9852c80dabd46L), Double.longBitsToDouble(0x3fe61c0c72c156d7L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 0, 1, 0, "", "\000\000\000\000", "\000",
        47, 7793, 848813166, 12227771891712L, -100000L, false, true, (char) 15710, (char) 171,
        Double.longBitsToDouble(0x3f38000000000000L), Double.longBitsToDouble(0x3fe4c000004b62a7L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 1, 3, 0, "", "\ua439\ub65a\u7288\uc793\u4b49\u89ae\uc818", "\ud840\udfdb",
        39, 65230, 1972508125, 225958241914276729L, 25414L, true, true, (char) 39825, (char) 16426,
        Double.longBitsToDouble(0x3fee5b153f28a657L), Double.longBitsToDouble(0x3fe5e9414a0e649bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 3, 3, "\udb5b\udded\udaca\udef2\u0f4b\ua242\udad8\udf1c\uacb3", "\uc818\ub431\ua884\uc52d\u9c26\u74bd\u6135\u5f8a\uae29\u00ca\u2bed\ub173\u73ee\u0785\u6d87\u26c1\u6228\u6f77\u3332\u2412\u9293\u9937", "\ud8aa\ude64\udba6\ude3d\ud9f6\udcfe\udae0\udc7e\ud82c\udf34\udbc7\udd8d\udb34\udfa7",
        8, 96464, -1477688341, 3651784039203450922L, -27596L, true, true, (char) 13900, (char) 15898,
        Double.longBitsToDouble(0x3fe5411544f3937fL), Double.longBitsToDouble(0x3fdc98a62d048a22L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 1, 1, 3, "", "", "\udad8\udf1c\uacb3\udb8d\udf4b\udb81\udd9d\ud91b\udd4b\uda82\udcf1\ud82d\udfc5\ud840\udfdb\udbd5\udc68\udb1f\udfd4\udae3\udcca\ud911\udc02\udba8\ude03\ud892\udccf\udbe8\udffc\ud886\udf07\ud853\udfc2\ud946\udc68",
        49, 7496, 1687908839, -643713421157891879L, -100000L, true, false, (char) 11123, (char) 13271,
        Double.longBitsToDouble(0x3fed7e9e03eb8f2eL), Double.longBitsToDouble(0x3fe2222c43fa722cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 1, 1, 3, "", "\ua34c\ub65a\u7288\uc793\u4b49\u89ae\uc818", "\udb1a\udce8\uda6e\udfff\udb1f\udfd4\udae3\udcca\ud911\udc02\udba8\ude03\ud892\udccf\udbe8\udffc\ud886\udf07\udb5e\uddc6\ud942\udf20\ud94c\ude82\udb80\udd85\udb39\udfd4",
        35, 55281, 13911723, 6485183463688490125L, -91558L, true, false, (char) 58235, (char) 30501,
        Double.longBitsToDouble(0x3f75dcf8a32ce700L), Double.longBitsToDouble(0x3fdbfd30b01993a4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,java.nio.charset.CharsetEncoder,org.jsoup.nodes.Entities$EscapeMode|static",
    "M|org.jsoup.nodes.Entities|escape|java.lang.String,org.jsoup.nodes.Document$OutputSettings|static",
    "C|org.jsoup.nodes.Entities|<init>|",
    "M|org.jsoup.nodes.Entities|unescape|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
