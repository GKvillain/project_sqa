package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class Tag_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 3, "\udbeb\udfb1", "\u55c8\ua3df\uc7f3\u4b85\u0bc3\u22cb\u385e\u3433\u23d7\u59c5\u5dfb\u70ea", "\ud8d9\udc30\ud935\udc96\udacc\udd79\ud905\udf58\ud8da\uddb3\ud9f3\udfbd",
        42, 80500, -245115360, -6351100138319980533L, -45546L, false, false, (char) 16276, (char) 59292,
        Double.longBitsToDouble(0x3fb04f8385f472f8L), Double.longBitsToDouble(0x3fdb0de8181acb38L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 7, "\udbeb\udfb1", "\u55c8\ua3df\u7a06\u2f1a\u0bc3\u22cb\u385e\u3433\u23d7\u59c5\u5dfb\u9103", "\ud8d9\udcad\ud8a6\udf4e\udb03\udfdb\ud905\udf9b\ud8da\uddb3\ud9f3\udfbd",
        42, 80500, -245115360, -6351100138319980533L, -45546L, false, false, (char) 16276, (char) 59292,
        Double.longBitsToDouble(0x3fb04f8385f472f8L), Double.longBitsToDouble(0x3fdb0de8181acb38L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 9, "\ud99d\udecc\udbfe\udc97\ucfdf\uda0d\udd83\udb0d\udf35\ud920\udca2", "\u27c8\u385e\u3433\u2441", "\udaa0\udc89\ud997\uddd4\ud894\udcc5\ud8d9\udc30",
        22, 105, -1912416752, -7492740923255656308L, 93628L, false, false, (char) 19831, (char) 1000,
        Double.longBitsToDouble(0x3fef3960194af3e2L), Double.longBitsToDouble(0x3fcb87194aebf364L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udaaa\uddd0\ud96b\udf59\ud843\udf7e\ud8c7\udf6b\ud8e7\udeb7\012",
        Z.run(T, 1, 8, 5, 10, "\udaaa\uddd0\ud96b\udf59\ud843\udf7e\ud8c7\udf6b\ud8e7\udeb7", "\u0bc3\uc9a9\u37d7\u3433\u23d7\u59c5\u6dd7\uc398\u7581\u8975\uc652\u17bb\u49ac\u3ef6\ua935\u5438\ud347", "\ud85b\udef4\udbf8\ude13",
        23, 77082, 378846011, -4603917197628748861L, -2874L, false, true, (char) 2636, (char) 42568,
        Double.longBitsToDouble(0x3f9ecc5e639fdee0L), Double.longBitsToDouble(0x3fe32f615696cda1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jsoup.parser.Tag:\udbeb\udfb1 |this=org.jsoup.parser.Tag:\udbeb\udfb1\012",
        Z.run(T, 1, 14, 11, 1, "\udbeb\udfb1", "\ub4bf\u1e3e\uc7e8\u4b85\u0bc3\u03fb\ua3a0\u41e7\u87d2\u59c5\u5dfb\u70ea", "\ud8ba\udcd3\udbdb\udf62",
        1, 76230, -1744536099, -1718969725766536347L, -45546L, false, false, (char) 16276, (char) 59292,
        Double.longBitsToDouble(0x3fb04f8385f472f8L), Double.longBitsToDouble(0x3fdb0de8181acb38L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:256988807 |this=org.jsoup.parser.Tag:\uda46\udc9f\012",
        Z.run(T, 1, 4, 3, 6, "\uda46\udc9f", "\u55c8\ua3df\uc7f3\u58a3\u3845\u0bd1\uc3ba\u321b\u23d7\ua7fd\u5dfb\u97c0", "\ud8b4\udff2",
        47, 49370, 820190843, -1976558487628096018L, 63692L, true, true, (char) 31542, (char) 32743,
        Double.longBitsToDouble(0x3fe9e714034af340L), Double.longBitsToDouble(0x3fcb5f11653ff364L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udbeb\udfb1\0121=java.lang.Boolean:true |this=org.jsoup.parser.Tag:\udbeb\udfb1\012",
        Z.run(T, 2, 12, 2, 5, "\udbeb\udfb1", "\u55c8\ua3df\uc7f3\u4b85\u36ba\u22cb\u2aef\u5d46\u314d\u9730\ud5d5\u737e\u484b\u41b9\u4f65\u07df\u5b88\ubd27\u43d7\uc6a0\ub958\u183d\u1ccf\u5b9c\u4515\uc32b\u452b\u33f0\ua988\ua165", "\udbe5\udca7",
        49, 9756, 1803304603, -7262886093764330156L, 68864L, true, true, (char) 17366, (char) 3817,
        Double.longBitsToDouble(0x3fd7c7dbd9545f5aL), Double.longBitsToDouble(0x3fc416662ecf8f30L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 12, 9, "\udbeb\udfb1", "\u55c8\ua3df\u70d4\u4b85\u0bc3\u6b17\u9e7d\u347c\u23d7\u59c5\u5dfb\u70ea", "\ud8e4\udc9c\ud935\udc96\udacc\udd79\ud905\udf58\udb66\udd8a\uda1b\udfb4",
        42, 80500, -245115360, -6945004642598070142L, -45546L, false, false, (char) 16276, (char) 59292,
        Double.longBitsToDouble(0x3fb04f8385f472f8L), Double.longBitsToDouble(0x3fdb0de8181acb38L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 10, 12, 3, "\u097e", "\u55c8\ua3df\uc7f3\u4b85\u0bc3\u22cb\u1ff7\u3433\u23d7\u59c5\u5dfbU", "",
        27, 98662, -160452086, -8213767407907082284L, -37693L, false, false, (char) 65109, (char) 19831,
        Double.longBitsToDouble(0x3f44fb8000000000L), Double.longBitsToDouble(0x3fea579a00daeb57L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udbde\udeeb\012",
        Z.run(T, 1, 6, 5, 10, "\udbde\udeeb", "\u1bf5\ua3fa\uc7f3\uc0af\u9948\ub74c\u385e", "\udaff\udc5b\ud882\udd6c\ud91d\udc65\ud949\udcd7\uda14\udc76\ud972\udfdd\ud935\udc96\ud912\udde3\ud905\udf58\ud9d1\uddca\uda88\udcfc\ud9a2\udd96\uda9e\ude61\udacb\ude4a\ud8f3\udee1\udada\ude0b\ud9e6\udf2b\udbcc\ude23",
        38, 50250, 1041128031, -5307560356908816246L, -57966L, false, false, (char) 30215, (char) 55015,
        Double.longBitsToDouble(0x3fc548ae1568ba58L), Double.longBitsToDouble(0x3fefc904c05126feL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\000\012",
        Z.run(T, 1, 11, 12, 3, "\000", "\u55c8\ua3df\uc7f3\uaa0a\u09c7\u22cb\u385e", "\ud8ba\uded8\uda4b\ude25\udaa0\udc89\ud997\uddd4\uda1a\udc87\ud8d9\udc30\ud935\udc96\000\000",
        20, -812, 586595, 2897644147747903008L, -100000L, false, true, (char) 7819, (char) 59609,
        Double.longBitsToDouble(0x3fe5d7e6c95f2e3eL), Double.longBitsToDouble(0x3fb04f8385f472f8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udbeb\udfb1\012",
        Z.run(T, 1, 1, 8, 0, "\udbeb\udfb1", "\ub19e\u8211\uc7f3\ud5b3\ubf2b\u038e\u0878", "\ud8ba\uded8\uda14\udcaa\udaa0\udc89\udbae\udfc3\uda1a\udc77\udbd6\udd6e\ud96b\udc91\ud9ac\udcc8",
        54, 32308, 455409188, -8500294773520301932L, -35720L, true, false, (char) 57875, (char) 64004,
        Double.longBitsToDouble(0x3fc7a7d4acaf08a4L), Double.longBitsToDouble(0x3fe5f472fbbf4387L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\ud9ad\ude5d\ud851\udc56\ud843\udf7e\ud8c7\udf6b\ud8e7\udeb7\ud936\udea2\uda08\ude71\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 10, "\ud9ad\ude5d\ud851\udc56\ud843\udf7e\ud8c7\udf6b\ud8e7\udeb7\ud936\udea2\uda08\ude71", "\u46be\uaf84", "\ud90c\udea0",
        7, 10686, -698838316, -3981542914810080370L, -23728L, false, false, (char) 32492, (char) 9398,
        Double.longBitsToDouble(0x3fe82b1e5e20289aL), Double.longBitsToDouble(0x3f93f16313c61b80L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.jsoup.parser.Tag:\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\udb85\udc59\ud814\udc18\ud920\udc97\uda08\ude71\ud8ee\udcce\udb83\udc8a\ud96c\udfa3\udada\ude20\ud9ed\udc8a\ud8ba\uded8\udbc6\ude51\ud8fb\udc6c\udae3\ude71\u76dd\ud8ba\udcd3\udbdb\udf62\uda3f\udd72\ud8de\udd1f\ud8dd\udfbc |this=org.jsoup.parser.Tag:\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\udb85\udc59\ud814\udc18\ud920\udc97\uda08\ude71\ud8ee\udcce\udb83\udc8a\ud96c\udfa3\udada\ude20\ud9ed\udc8a\ud8ba\uded8\udbc6\ude51\ud8fb\udc6c\udae3\ude71\u76dd\ud8ba\udcd3\udbdb\udf62\uda3f\udd72\ud8de\udd1f\ud8dd\udfbc\0121=java.lang.Boolean:true |this=org.jsoup.parser.Tag:\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\udb85\udc59\ud814\udc18\ud920\udc97\uda08\ude71\ud8ee\udcce\udb83\udc8a\ud96c\udfa3\udada\ude20\ud9ed\udc8a\ud8ba\uded8\udbc6\ude51\ud8fb\udc6c\udae3\ude71\u76dd\ud8ba\udcd3\udbdb\udf62\uda3f\udd72\ud8de\udd1f\ud8dd\udfbc\012",
        Z.run(T, 2, 14, 11, 1, "\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\udb85\udc59\ud814\udc18\ud920\udc97\uda08\ude71\ud8ee\udcce\udb83\udc8a\ud96c\udfa3\udada\ude20\ud9ed\udc8a\ud8ba\uded8\udbc6\ude51\ud8fb\udc6c\udae3\ude71\u76dd\ud8ba\udcd3\udbdb\udf62\uda3f\udd72\ud8de\udd1f\ud8dd\udfbc", "\u183d", "\ud8ba\ude8c\uda83\ude7b\uda6c\udd15\ud9dc\udcaa\uda85\udd73\ud8c1\udd07\udafc\udd8e\uda97\udec4\udbe5\udfac\ud816\udf8d\udaae\udde6\udb73\udeb9",
        57, 19103, -716643780, -3863278468556225567L, -76530L, true, true, (char) 56034, (char) 48560,
        Double.longBitsToDouble(0x3fd55f668e5d18e0L), Double.longBitsToDouble(0x3fe66d7470c0ef60L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 13, 6, "\udbeb\udfb1", "\u55c8\u4ab0\u426f\u1bb8\u2a70\uccb4\u25d7\ub89a\u748b\u5968\u5dfb\ua348", "\ud8e4\udc9c\ud935\udc96\udacc\udd79\ud905\udf58\udb25\udd8d\uda30\udc02",
        42, 80500, 375641632, -7651952363977189246L, 52195L, false, false, (char) 16276, (char) 59292,
        Double.longBitsToDouble(0x3fb9fff785f472f8L), Double.longBitsToDouble(0x3fdb0de8181acb38L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udbeb\udfa3\012",
        Z.run(T, 2, 10, 1, 4, "\udbeb\udfa3", "\u8696\ua3df\u7a9d\u4b85\u140f\u6d46\u9e7d\u347c\u23d7\ub1fa\ud12d\u70ea", "\u6356\ud935\udcc4\udaa1\udc0e\ud905\udf58\udb66\udd8a\uda1b\udfb4\ud915\udc6f\uda9e\udef2\uda3d\udd43",
        0, 81770, -213905604, -1486717523862099750L, 78527L, true, false, (char) 46877, (char) 34865,
        Double.longBitsToDouble(0x3f8acb38f39fd480L), Double.longBitsToDouble(0x3fcec8179de22844L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 13, "\ud9e4\ude6f", "\u55c8\uc25d\u25ce\u4b85\u0bc3\u6b17\u9e7d\u347c\u83b3\u59c5\u5dfb\u70ea", "\ud9d4\udcc1\uda34\udc4e\udad7\udfd7\ud905\udf58\udb66\udd85\uda64\udef8",
        43, 74925, -245115360, -6945004642598070142L, -45546L, false, false, (char) 16276, (char) 59292,
        Double.longBitsToDouble(0x3fb04f8385f472f8L), Double.longBitsToDouble(0x3fe216f40c09d4b6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jsoup.parser.Tag:\udbeb\udfb1 |this=org.jsoup.parser.Tag:\udbeb\udfb1\0121=java.lang.Integer:-717772807 |this=org.jsoup.parser.Tag:\udbeb\udfb1\012",
        Z.run(T, 2, 14, 4, 9, "\udbeb\udfb1", "\u55c8", "\uda08\ude71\ud8ee\udcce\uda00\udd49\udaff\udf9a\udb9e\udcba\ua62f\ud8ba\uded8\uda4b\ude25\udaa0\udc89\ud978\uddd4\uda1a\udd4c\000\000\000\ud8d0\udd48\udb66\udd8a\uda1b\udfb4\ud915\udc6f\uda9e\udef2\uda3d\udd43\udbbb\udd64\udbfb\udec4\udb77\udf77",
        33, 95058, 775832250, 4471715295792171073L, -100000L, true, false, (char) 11584, (char) 26462,
        Double.longBitsToDouble(0x3f95617992970b20L), Double.longBitsToDouble(0x3fe3b6c1a6c6ba86L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:-1768217691 |this=org.jsoup.parser.Tag:\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\ud903\uddcd\udba3\udcbf\udb9e\udd9d\udaf5\udf86\udbeb\ude10\uda00\udc6e\udaff\udf9a\udb9e\udcba\ua62f\ud8ba\uded8\uda4b\ude25\0121=java.lang.Integer:-1768217691 |this=org.jsoup.parser.Tag:\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\ud903\uddcd\udba3\udcbf\udb9e\udd9d\udaf5\udf86\udbeb\ude10\uda00\udc6e\udaff\udf9a\udb9e\udcba\ua62f\ud8ba\uded8\uda4b\ude25\012",
        Z.run(T, 2, 4, 4, 4, "\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\ud903\uddcd\udba3\udcbf\udb9e\udd9d\udaf5\udf86\udbeb\ude10\uda00\udc6e\udaff\udf9a\udb9e\udcba\ua62f\ud8ba\uded8\uda4b\ude25", "\u8caf\u0cb2\u076e\u36b4\u3ef6\u93a3\u6ffc\u9aa4\uad8a", "\udbfb\udec4\ud86f\ude11\ud9c7\udc3d\udbfb\udc88\ud87f\udc93",
        14, 31673, 1787756463, 8402815659828267349L, 95780L, false, false, (char) 25712, (char) 28134,
        Double.longBitsToDouble(0x3fd587db97e6c742L), Double.longBitsToDouble(0x3fe71646eb822385L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\u2e62\0121=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\u2e62\012",
        Z.run(T, 2, 6, 6, 9, "\u2e62", "\u55c8\ua3df\u70d4\u4b85\u0bc3\u6b17\u9e7d\u347c\ua1b9\u07a7\ub8c7\u70ea\ud180\u4270", "\u9c9e\ud849\ude70\udb66\udd8a\uda1b\udfb4\ud915\udc6f\uda9e\udef2\uda3d\udd43",
        34, 26554, -213905604, -1488673556406867750L, -16383L, true, false, (char) 46877, (char) 34865,
        Double.longBitsToDouble(0x3fb59f273fbb4908L), Double.longBitsToDouble(0x3fe5974853e1f894L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\ud986\ude60\0121=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\ud986\ude60\012",
        Z.run(T, 2, 8, 8, 0, "\ud986\ude60", "\ub19e\u8211\uc7f3\ud5b3\ubf2b\u67b4\u4bd5", "\ud8bb\udf11\uda14\udcaa\udaa0\udc89\udbae\udfc3\uda1a\udc77\udbd6\udd6e\ud96b\udc91\ud9ac\udcc8",
        54, 32308, 455409188, -8500294773520301932L, -35720L, true, false, (char) 57875, (char) 64004,
        Double.longBitsToDouble(0x3fc7a7d4acaf08a4L), Double.longBitsToDouble(0x3fe5f472fbbf4b21L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jsoup.parser.Tag:\ud9c6\ude15\ud851\udc56\ud843\udf7e\ud8c7\udf6b\uda82\udd0e\uda99\udced\udaf7\udf7e\ud8ee\udcce\ud99a\ude7c\udb6a\uded2\ud939\udf92\udaad\uddf9\udba4\udc0c\ud90c\udea0\uda7e\udf38\ud9f7\udf0d\uda3c\udc5f |this=org.jsoup.parser.Tag:\ud9c6\ude15\ud851\udc56\ud843\udf7e\ud8c7\udf6b\uda82\udd0e\uda99\udced\udaf7\udf7e\ud8ee\udcce\ud99a\ude7c\udb6a\uded2\ud939\udf92\udaad\uddf9\udba4\udc0c\ud90c\udea0\uda7e\udf38\ud9f7\udf0d\uda3c\udc5f\0121=org.jsoup.parser.Tag:\ud9c6\ude15\ud851\udc56\ud843\udf7e\ud8c7\udf6b\uda82\udd0e\uda99\udced\udaf7\udf7e\ud8ee\udcce\ud99a\ude7c\udb6a\uded2\ud939\udf92\udaad\uddf9\udba4\udc0c\ud90c\udea0\uda7e\udf38\ud9f7\udf0d\uda3c\udc5f |this=org.jsoup.parser.Tag:\ud9c6\ude15\ud851\udc56\ud843\udf7e\ud8c7\udf6b\uda82\udd0e\uda99\udced\udaf7\udf7e\ud8ee\udcce\ud99a\ude7c\udb6a\uded2\ud939\udf92\udaad\uddf9\udba4\udc0c\ud90c\udea0\uda7e\udf38\ud9f7\udf0d\uda3c\udc5f\012",
        Z.run(T, 2, 14, 14, 14, "\ud9c6\ude15\ud851\udc56\ud843\udf7e\ud8c7\udf6b\uda82\udd0e\uda99\udced\udaf7\udf7e\ud8ee\udcce\ud99a\ude7c\udb6a\uded2\ud939\udf92\udaad\uddf9\udba4\udc0c\ud90c\udea0\uda7e\udf38\ud9f7\udf0d\uda3c\udc5f", "\u49ac\u3ef6", "\uda20\udee2\uda32\udf69\uda3d\udd43",
        39, 46570, -1542717479, -7012857641340054554L, 81723L, true, false, (char) 62360, (char) 52624,
        Double.longBitsToDouble(0x3fd79ed106d28c24L), Double.longBitsToDouble(0x3fe5793dceddf1adL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\ud9ad\ude5d\ud851\udc56\ud843\udf7e\ud8c7\udf6b\ud8e7\udeb7\ud9cf\udc65\uda08\uddee\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 11, "\ud9ad\ude5d\ud851\udc56\ud843\udf7e\ud8c7\udf6b\ud8e7\udeb7\ud9cf\udc65\uda08\uddee", "\ucc7d", "\ud9a7\ude63\ud90c\udea0\uda7e\udf38\ud997\uddd4\ud90e\uddf9\ud940\udede\uda80\uddba\udad1\udc71\ud905\udf58\uda7a\udd74\ud905\udda5\uda20\udee2\uda19\udd69",
        25, 69379, -1662111671, 72583526180632994L, -93513L, false, false, (char) 39836, (char) 16481,
        Double.longBitsToDouble(0x3fe9f89a9359884cL), Double.longBitsToDouble(0x3fcaa442344918d4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udb71\udca4\udb0e\udfdd\ud9cb\ude21\ud9c9\udc4d\ud9c3\udff6\ud808\udc6c\ud861\ude9b\0121=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udb71\udca4\udb0e\udfdd\ud9cb\ude21\ud9c9\udc4d\ud9c3\udff6\ud808\udc6c\ud861\ude9b\012",
        Z.run(T, 2, 1, 1, 3, "\udb71\udca4\udb0e\udfdd\ud9cb\ude21\ud9c9\udc4d\ud9c3\udff6\ud808\udc6c\ud861\ude9b", "\ubbfc\u3244", "\ud9f0\udda9\uda7e\udf7e\ud997\uddd4\uda3c\udc5f\ud96b\udc8e\uda80\uddba\uda36\udfe3\ud8d7\udec0\uda7a\udd74\ud905\udda5\ud923\udea4\uda8e\udd85\udbb9\udc30\uda21\udf04\uda35\udfb2\udac2\udec9\ud842\udc6f\ud813\udc4e\udabb\udf19\u611e\uda5d\ude53\ud821\uddb7\udbd5\udedf\udbf5\ude1d",
        55, 13696, 2049858467, -5297300003999997643L, 747L, true, false, (char) 14590, (char) 53639,
        Double.longBitsToDouble(0x3fef039c05a764c8L), Double.longBitsToDouble(0x3fc52baaa92f8c58L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\udb85\udc59\ud814\udc18\ud920\udc97\uda08\ude71\ud8ee\udcce\udb83\udc8a\ud96c\udfa3\udada\ude20\ud9ed\udc8a\ud8ba\uded8\udbc6\ude51\ud8fb\udc6c\udae3\ude71\u76dd\ud8ba\udcd3\udbdb\udf62\uda3f\udd72\ud8de\udd1f\ud8dd\udfbc\0121=java.lang.Boolean:false |this=org.jsoup.parser.Tag:\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\udb85\udc59\ud814\udc18\ud920\udc97\uda08\ude71\ud8ee\udcce\udb83\udc8a\ud96c\udfa3\udada\ude20\ud9ed\udc8a\ud8ba\uded8\udbc6\ude51\ud8fb\udc6c\udae3\ude71\u76dd\ud8ba\udcd3\udbdb\udf62\uda3f\udd72\ud8de\udd1f\ud8dd\udfbc\012",
        Z.run(T, 2, 11, 11, 1, "\udbeb\udfb1\udbfe\udc4f\ud8d9\udf2e\udb85\udc59\ud814\udc18\ud920\udc97\uda08\ude71\ud8ee\udcce\udb83\udc8a\ud96c\udfa3\udada\ude20\ud9ed\udc8a\ud8ba\uded8\udbc6\ude51\ud8fb\udc6c\udae3\ude71\u76dd\ud8ba\udcd3\udbdb\udf62\uda3f\udd72\ud8de\udd1f\ud8dd\udfbc", "\u183d", "\ud8ba\ude8c\uda83\ude7b\uda6c\udd15\ud9dc\udcaa\uda85\udd73\ud8c1\udd07\udafc\udd8e\uda97\udec4\udbe5\udfac\ud816\udf8d\udaae\udde6\udb73\udeb9",
        57, 19103, -716643780, -3863278468556225567L, -76530L, true, true, (char) 56034, (char) 48560,
        Double.longBitsToDouble(0x3fd55f668e5d18e0L), Double.longBitsToDouble(0x3fe66d7470c0ef60L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 12, 8, "\ud99d\udf8e", "\u55c8\ua3df\uc7f3\u4b85\u0bc3\u22cb\ua566\u6cf6\u23d7\u59c5\u5dfb\ua052", "\ud8d9\udc30\ud935\udc96\uda4a\udc80\ud905\udf58\ud8da\uddb3\ud8c4\udee6\ud915\udc6f\uda9e\udef2",
        20, 9267, -494872565, -918717573957735606L, 13990L, true, true, (char) 57378, (char) 17740,
        Double.longBitsToDouble(0x3fdc8bad87edbda6L), Double.longBitsToDouble(0x3fc952ca25dc6128L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.Tag|canContainBlock||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|equals|java.lang.Object|new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|formatAsBlock||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|getName||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|hashCode||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|isBlock||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|isData||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|isEmpty||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|isInline||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|isKnownTag||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|isKnownTag|java.lang.String|static",
    "M|org.jsoup.parser.Tag|isSelfClosing||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|preserveWhitespace||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|register|org.jsoup.parser.Tag|static",
    "M|org.jsoup.parser.Tag|setSelfClosing||new:org.jsoup.parser.Tag:java.lang.String",
    "M|org.jsoup.parser.Tag|toString||new:org.jsoup.parser.Tag:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
