package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Node_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 0, 6, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u70d7\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda49\ude78\ud930\udcf9\udb60\udc2c\uf0b2",
        3, 73792, -1203128949, -7335291113442390599L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud80d\udc5d\ud922\udead\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud80d\udc5d\ud922\udead\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 0, 6, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud80d\udc5d\ud922\udead\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u70d7\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\udac2\udcdb\uda49\ude78\ud930\udcf9\udb60\udc2c\uf0b2",
        3, 73792, -1203128949, -7335290954528600647L, 54049L, false, false, (char) 59644, (char) 37860,
        Double.longBitsToDouble(0x3fd9e00f13e8ed44L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:-1398772930 |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a-->\0121=void |a0=java.lang.StringBuilder:\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a\012<!--\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a--> |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a-->\012",
        Z.run(T, 2, 15, 1, 4, "\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a", "\u6389\ub7ec", "\udaa1\udda5\udaad\udce1\udbeb\udd74\ud974\udd58\ud95b\udc64\ud81b\udda1\ud82b\udc59\ud93b\uddb4\uda36\uddf6\ud925\udc25\ud930\udd0a\udb9f\udc91",
        25, 3898, -1085877208, -5167399490533732455L, 40664L, true, true, (char) 9113, (char) 59644,
        Double.longBitsToDouble(0x3fe9952f1e828600L), Double.longBitsToDouble(0x3fdf476b9613876eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f\uda2b\udfad\ud806\udee9\uad6a\ud817\udd0b\udb9b\udcc2\ud929\udf16\ud893\udd1c\ud8c0\udfcf\ud918\udef9\udaa1\udda5\udaad\udce1\udbeb\udd74", "\u9937\u4655\u62c2\u8410\ua151\u56b7\u2104\uaaaa\u0fb2\u1772\u888c\u3ef2\u7933\ub164\u8dfc\u2d34\u7141\u78ce\u4338\u4281\uc364", "\ud946\udfec\u2a5b\ud97a\udeb6\udaa2\udf54\ud831\udc72\uda7b\udc9e\udb8b\ude1a\ud8a3\udf6e\udbcf\udca6\udbd7\udec4\uda07\udcbf\udac6\udc16\udb25\udcd2\ud893\uddcc\uda48\udc98\udb80\ude10",
        52, 15882, 1103701263, 2823563798471700356L, 38952L, true, false, (char) 6992, (char) 17303,
        Double.longBitsToDouble(0x3fd3613f529294d8L), Double.longBitsToDouble(0x3fea5513fc8558d0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude5f\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude5f\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 0, 12, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude5f\u6fc9\udbc2\ude18\uda63\udf9f", "\u819b\u3ee7\u40cf\u11c1\uaf49\u84c3\u70d7\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\ud97f\ude62\ud930\udf14\udb60\udc2c\uf0b2",
        3, 73792, -1203129012, -7335291113442390599L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda32\udf0d\ud91f\udd5f\udb5d\udd58\uf0b2\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\uda0e\udcb8\udb96\udefd\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f--> |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\uda0e\udcb8\udb96\udefd\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\uda0e\udcb8\udb96\udefd\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 17, 6, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\uda0e\udcb8\udb96\udefd\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u970a\uc488\u6514\u7401\uae72\u84c3\u70d7\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda32\udf0d\ud91f\udd5f\udb5d\udd58\uf0b2",
        3, 73792, -1203128949, -7335291113442390599L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\u33c8\u8486\u70d7\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda49\ude78\ud930\udcf9\udb60\udc2c\uf0b2",
        3, 73792, -1203128949, -7335291111412347463L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=void |a1=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 0, 4, 1, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u70d7\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud982\udd45\uda7d\udc78\udbe2\udd63\ud90c\uddc1\ud92b\udcb3\udb45\udfb4\uf0b2",
        3, 73792, -257148630, 6288421750211333561L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\uda96\udcc7\ud87c\udf80\ud85d\udfba\ud8d2\udf20\ud901\udc31\udb73\udc90\uc804\udab9\udeef\udbc2\ude3d\ud8ce\udf74-->\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 16, "\uda96\udcc7\ud87c\udf80\ud85d\udfba\ud8d2\udf20\ud901\udc31\udb73\udc90\uc804\udab9\udeef\udbc2\ude3d\ud8ce\udf74", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u3db3\ud366\uc7ee", "\udba8\udcbd\udbd7\uddbc\ud80b\udd29\udb13\udc63\uda36\uddb5\uda49\ude78\ud930\udcf9\udb60\udc2c\ud945\udcf6\ud92b\udcd4\uda14\udc57\ud83a\udd51\ud8b4\udd99\ud9b4\udcb9\u2871\ue191",
        27, 30815, -2032392407, 8554946490315276788L, -1496L, true, false, (char) 26549, (char) 57254,
        Double.longBitsToDouble(0x3fe941dbb101adbeL), Double.longBitsToDouble(0x3fe700c6723f6b01L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\uda2b\ude37\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\ub02e\ud973\udca6-->\0121=org.jsoup.nodes.Comment:\012<!--\uda2b\ude37\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\ub02e\ud973\udca6--> |this=org.jsoup.nodes.Comment:\012<!--\uda2b\ude37\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\ub02e\ud973\udca6-->\012",
        Z.run(T, 2, 16, 7, 12, "\uda2b\ude37\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\ub02e\ud973\udca6", "\u9e4a\u8c31\u56b7\ud4ea\uad52\u84c3\u70d7\u7741\uc72d", "\udbc9\udc42\udaec\udd6d\ud81f\udf29\ud815\udfcf\ud9ee\udcfa\uda48\udfe9\ud930\udcf9\udacf\udf8d\u274e\udaa3\udc61\uda11\udf0c\ud83a\udd51\ud8be\udd2a\ud9b4\udcb9\u2871\ud92c\udf16\udb71\udef0\udb9b\udedf\ud982\udc64\ud853\udd81",
        39, 17673, 1728974409, -108769135835222011L, 86078L, false, false, (char) 18922, (char) 4175,
        Double.longBitsToDouble(0x3fc2460947fd3ef8L), Double.longBitsToDouble(0x3fb2acab38463bc8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20-->\0121=org.jsoup.nodes.Attributes: comment=\"&#55656;&#57168;&#55421;&#56353;&#56232;&#56864;&#55506;&#57120;\" |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20-->\012",
        Z.run(T, 2, 12, 8, 10, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20", "\u9f34\u36e9\ubba7\u13e9\u806c\uabca\u8bb5\u3ee7", "\ud833\udcab\ud8d0\udf2b\ud918\udef9\udaa1\udda5\udaad\udce1",
        36, 68476, -324778509, 8175769168610660038L, -71469L, true, true, (char) 42352, (char) 40323,
        Double.longBitsToDouble(0x3fe75cb198dc1e29L), Double.longBitsToDouble(0x3fdca3bc4b177e0cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud9f1\udd10\ud8b8\ude21\udba8\ude20\ud8d2\udf20\ud901\udc31\ud834\udf12\ud812\uddf8\uda9b\udd91\uda40\udd6d\uda2a\udde5-->\012",
        Z.run(T, 1, 12, 12, 2, "\ud9f1\udd10\ud8b8\ude21\udba8\ude20\ud8d2\udf20\ud901\udc31\ud834\udf12\ud812\uddf8\uda9b\udd91\uda40\udd6d\uda2a\udde5", "\ud31d\ud1e8\u78ec", "\ud8d9\udc0a\ud918\udef9\udaa1\udda5\udaad\udce1\udbeb\udd74\ud974\udd58\udbc9\udcce\ud893\ude6a\ud80b\udd29\ud815\udfcf\uda36\uddf6\u462c\udaa8\udd6e\udb60\udc2c\ud87a\uded1\udac8\udeec\ud9e2\udc5e\ud83a\udc28\ud8b4\udd99\ud9b4\udcb9\u2871\udb91\udcdd\udb67\udcb4\ud9e3\udebf\udbbd\udc04\ud853\udd81",
        55, 58225, 51664275, 7392709415754943377L, -33501L, false, false, (char) 13098, (char) 62629,
        Double.longBitsToDouble(0x3feeff473c9a7f82L), Double.longBitsToDouble(0x3fcbb363e57be488L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud904\udebd\ud818\udd60\ud80f\udef0\ud8d2\udf20\uda24\ude42\uda94\udf1f\ud962\udd1f\udbeb\udc79\ud803\udcae\uda43\udfd5-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud904\udebd\ud818\udd60\ud80f\udef0\ud8d2\udf20\uda24\ude42\uda94\udf1f\ud962\udd1f\udbeb\udc79\ud803\udcae\uda43\udfd5-->\012",
        Z.run(T, 2, 3, 6, 12, "\ud904\udebd\ud818\udd60\ud80f\udef0\ud8d2\udf20\uda24\ude42\uda94\udf1f\ud962\udd1f\udbeb\udc79\ud803\udcae\uda43\udfd5", "\u8bb5\u3ee7\ucb60\u4639\uae72\u84c3\u92ea\u096e\u4bb6", "\ud91a\udd65\udaec\udd6d\ud99b\udc8e\ud8a0\udd34",
        29, 70039, 1553435322, 6987618114119227627L, -49423L, true, true, (char) 27548, (char) 16582,
        Double.longBitsToDouble(0x3fe6ba6f698796eaL), Double.longBitsToDouble(0x3fe637e6940fdcedL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20-->\0121=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20--> |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20-->\012",
        Z.run(T, 2, 6, 7, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20", "\u9f34\u36e9\ubba7\u13e9\u806c\uabca\u2f90\ud00b", "\ud893\udd1c\ud8c0\udfcf",
        7, 56634, -1514976635, -984003245543986788L, 84741L, true, false, (char) 10393, (char) 42352,
        Double.longBitsToDouble(0x3fe349b8d15b9633L), Double.longBitsToDouble(0x3fe9428e27f89dafL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 1, 13, 16, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\uae72\u5a65\ube48\u59d8\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda49\ude78\ud930\udcf9\udb60\udc2c\uf0b2",
        3, 73792, -1203128949, -7335291113442390599L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |a0=java.lang.StringBuilder:\udaec\udd6d\ud80b\udd29\ud815\udfcf\ud961\udc0a\ud80e\uddd1\uda64\udd4b\ud977\udc1e\uf0b2\udaa3\udc61\ud8f0\ude0a\uda8b\udd5a\ud96e\udc46\ud9b4\udcb9\u2b71\udbd5\udd56\ud93e\udde9\udb14\udfb2\uda4a\udf44\ud924\udf48\uda1d\udfa4\ud981\udead\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\udb6e\ude35\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\ud9c4\udf70--> |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\udb6e\ude35\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\ud9c4\udf70-->\0121=void |a0=java.lang.StringBuilder:\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\udb6e\ude35\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\ud9c4\udf70\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\udb6e\ude35\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\ud9c4\udf70--> |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\udb6e\ude35\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\ud9c4\udf70-->\012",
        Z.run(T, 2, 1, 17, 4, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\udb6e\ude35\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\ud9c4\udf70", "\u400a\u3e39\u40cf\u220e\u2fa2\u84c3\u70d7\u7741\uc72d\u8e13", "\udaec\udd6d\ud80b\udd29\ud815\udfcf\ud961\udc0a\ud80e\uddd1\uda64\udd4b\ud977\udc1e\uf0b2\udaa3\udc61\ud8f0\ude0a\uda8b\udd5a\ud96e\udc46\ud9b4\udcb9\u2b71\udbd5\udd56\ud93e\udde9\udb14\udfb2\uda4a\udf44\ud924\udf48\uda1d\udfa4\ud981\udead",
        25, 1070, -1448151289, 5500162205767335230L, 2582L, false, true, (char) 81, (char) 43986,
        Double.longBitsToDouble(0x3fe9c08f028469c5L), Double.longBitsToDouble(0x3fce5a5d0306b750L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 10, 5, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\ud855\udd10\ud953\ude58\udaf0\ude93\ud933\udd9f\ud88e\uddd6", "\u8bb5\u3ee7\u27eb\u5233\uae72\u84c3\u70d7\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda49\ude78\ud930\udcf9\udb76\ude2c\uf0b2",
        3, 73792, -1203128949, 5712337748144147798L, 8167L, false, false, (char) 1789, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud8ef\udccf\ud87d\udc21\udba8\ude4d\ud8d2\udf20\ud860\udf5f\uda06\udfda\ud92b\udcd9\u6fc9\udbc2\ude18\u064e-->\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 10, 4, "\ud8ef\udccf\ud87d\udc21\udba8\ude4d\ud8d2\udf20\ud860\udf5f\uda06\udfda\ud92b\udcd9\u6fc9\udbc2\ude18\u064e", "\u64bd\uba66\u40cf\u220e\uae72\u84c3\u70d7\u7741\uc72d", "\udbc9\udcce\ud8de\udfa7\ud81e\ude37\uda64\uddb5\ud8e3\udc23\ud93e\ude8f\ud913\ude6e\udb60\udc2c\uf0b2",
        3, 73792, -1203128949, -7335291113442390599L, 53861L, false, false, (char) 59644, (char) 48303,
        Double.longBitsToDouble(0x3fe41431e9f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b67cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\uda84\ude11\udb7f\udc15\ud855\udf19-->\0121=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\uda84\ude11\udb7f\udc15\ud855\udf19-->\012",
        Z.run(T, 2, 0, 0, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\uda84\ude11\udb7f\udc15\ud855\udf19", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u70d7\u3e5d\uc72d\u8e13", "\udac8\udf9c\ud80b\udcac\ud815\udfcf\uda36\uddf6\ud8a9\udfc8\ud930\udd3c\udb60\udc2c\uf0b2\udaa3\udc61\uda14\udc57\ud83a\udd51\ud8b4\udd99\ud9b4\udcb9\u2871\ue191\udb67\udcb4\ud9e3\udebf\ud982\udc0e\ud853\udd81\uda05\ude66\ud981\udead",
        53, 45560, 1569602089, -6406739012500430510L, -51810L, false, false, (char) 15484, (char) 47578,
        Double.longBitsToDouble(0x3fe60d8450796196L), Double.longBitsToDouble(0x3fb0cf4c77ada808L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |a1=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 4, 12, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u70d7\u7d27\u3a02", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda49\ude78\ud930\udcf9\udb60\udc2c\uf0b2",
        3, 92192, -1203113635, -7335291113442390599L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |a0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=void |a0=java.lang.StringBuilder:\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f--> |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 5, 17, 15, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u70d7", "\udbeb\udd74\ud974\udd58\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud8a6\ude8c\udbf1\ude31\ud9b2\udfa1\ud902\udefd\udbeb\ude91\uf0b2\ud995\udebb\ud98d\udd6b\ud83a\udd51\udb58\ude8f",
        20, 1672, 881940929, -8703690614341016647L, -93986L, false, true, (char) 39269, (char) 53332,
        Double.longBitsToDouble(0x3fdd791df4f0bb08L), Double.longBitsToDouble(0x3fe7f2086df2da77L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 6, 0, "\udac2\udf08\ud87d\udc2a\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58", "\u13e9\u806c\uabca\u8bb5\u3ee7\u40cf\u2271\uae72\u84c3\u70d7\u7741\uc72d\u8e13\u644c\u5f01\u05a9\u4641\u62c2\u8410\u131e\u5709\u2104\uaaaa\u0fb2\u1772\u888c\u3ef2\u2981\uce0c\u8d97\u2d34\u7141\u779e\u4338\u4281\u2b64\u4e19\u25c6\u52fd\u750c\u1bd5\ub10e\u1842\ucd72\u8dc9\u9600\u0312\ua9ab\u17c0", "\ud91a\udfff\udb0a\ude55\uda68\uddcd\udac8\udc75\uaa2d\ud9a9\udd41\ud89c\udfbc\udb6b\udd2b\ud869\udf52\ud9bb\udd31\ud930\udee6\ud97b\uddb3\udab7\udd6c\udb03\udd77\ud8cf\udeb2\udb96\udee0\udac6\udde8\udba8\udd21",
        -1, 70778, 1338510055, -7256081124043304674L, -30978L, true, true, (char) 30088, (char) 20041,
        Double.longBitsToDouble(0x3fc067d5cf4bc1e4L), Double.longBitsToDouble(0x3fe402b24e9e23e6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\012<!--\ud968\udf50\ud87d\udc21\uda59\ude17\ud8d2\udf20\ud983\udc71\udb91\ude36\ud953\ude1d\u6fc9\udbc2\ude18\uda63\udf9f--> |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\uda59\ude17\ud8d2\udf20\ud983\udc71\udb91\ude36\ud953\ude1d\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=java.lang.String:\012<!--\ud968\udf50\ud87d\udc21\uda59\ude17\ud8d2\udf20\ud983\udc71\udb91\ude36\ud953\ude1d\u6fc9\udbc2\ude18\uda63\udf9f--> |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\uda59\ude17\ud8d2\udf20\ud983\udc71\udb91\ude36\ud953\ude1d\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 2, 2, 12, "\ud968\udf50\ud87d\udc21\uda59\ude17\ud8d2\udf20\ud983\udc71\udb91\ude36\ud953\ude1d\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u8926\uafea\u84c3\u70d7\u7741\u9ecc", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda49\ude78\ud930\udcf9\udb60\udc2c\uf0b2",
        3, 73792, -1203128949, -7335291113442390599L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dbb38b60dL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:624674552 |this=org.jsoup.nodes.Comment:\012<!--\u5fa9\ud9b2\udcda\udbb9\udf44\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58-->\0121=java.lang.Integer:624674552 |this=org.jsoup.nodes.Comment:\012<!--\u5fa9\ud9b2\udcda\udbb9\udf44\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58-->\012",
        Z.run(T, 2, 15, 15, 14, "\u5fa9\ud9b2\udcda\udbb9\udf44\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58", "\u3575\uce70\u0e99\u8bb5\u16bd\u40cf\u9b64\u2dfd\u68e9\u6e9b\u7741\uc7d0\u8e13", "\ud81b\udda1\udb3d\udec1\ud93b\uddb4\uda36\uddf6\ud925\udc25\udb87\udc0c\udb9f\udc91\uf0b2\ud8ad\udc6d\udbb4\udd26\ud83a\udced\ud8b4\udd99\ud9b4\udcb9\u2871\ue191\udb67\udcb4\ud9f8\udc6b\ud9a8\udc01\udb0c\udcfe\udb76\ude03\ud88e\udfd3",
        19, 13109, -865056839, 3789549294255233016L, -2741L, true, true, (char) 42512, (char) 18781,
        Double.longBitsToDouble(0x3fc26f5be7cbd544L), Double.longBitsToDouble(0x3fe89b7d4ae5a088L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\udbc2\udc7d\ud88b\ude56\ud990\ude77\udb3a\uddae\ud8a8\udd6b\udad9\udf2c\udabe\ude5b-->\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 5, 8, "\ud968\udf50\udbc2\udc7d\ud88b\ude56\ud990\ude77\udb3a\uddae\ud8a8\udd6b\udad9\udf2c\udabe\ude5b", "\u36da\ua5dc\u41f1\u3e75\u40cf\u6389\u8c8b", "\ud947\udff5",
        41, 27917, 1577330021, 8274331836983391069L, -4563L, false, true, (char) 20872, (char) 20556,
        Double.longBitsToDouble(0x3fe68ea05eeb9601L), Double.longBitsToDouble(0x3fda21e2985171e8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a-->\012",
        Z.run(T, 2, 3, 3, 3, "\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a", "\u6389\ub7ec", "\udaa1\udda5\udaad\udce1\udbeb\udd74\ud974\udd58\ud95b\udc64\ud81b\udda1\ud82b\udc59\ud93b\uddb4\uda36\uddf6\ud925\udc25\ud930\udd0a\udb9f\udc91",
        25, 3898, -1085877208, -5167399487245398119L, 60947L, true, true, (char) 48931, (char) 57442,
        Double.longBitsToDouble(0x3fe99529ee828600L), Double.longBitsToDouble(0x3fdf476b9613876eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a-->\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a-->\012",
        Z.run(T, 2, 13, 13, 4, "\ud968\udf50\ud9b2\udcda\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\uda43\udde6\uad6a", "\u6389\ub7ec", "\ud822\ude86\ud9e7\udc7f\udb11\udfb0\u4ca8\ud94e\udc7b\ud81b\udda1\ud82b\udc59\udaca\udd5b\uda36\udd7c\ud924\udfb0\ud930\udd0a\udb9f\udc91",
        25, 3898, -1085877208, -5167399490533732455L, 40664L, true, true, (char) 9113, (char) 59644,
        Double.longBitsToDouble(0x3fe9952f1e828600L), Double.longBitsToDouble(0x3fdf4e1b9613876eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\ud933\udc2e\ud9f8\udc77--> |this=org.jsoup.nodes.Comment:\012<!--\ud933\udc2e\ud9f8\udc77-->\0121=org.jsoup.nodes.Attributes: comment=\"&#55603;&#56366;&#55800;&#56439;\" \ud939\udcf8\udbf5\uddfd\ud902\udf3d\udb99\udd97\udad1\udf3c\ud83f\uddeb\udb4b\udf34\udae0\udcaf\ud9ff\udc2b\ud9f0\udc04\udac8\udef3\udbeb\udd74\ud974\udd58\ud95b\udc64\udafb\udf92\ud822\uddbd=\"&#55603;&#56366;&#55800;&#56439;\" |this=org.jsoup.nodes.Comment:\012<!--\ud933\udc2e\ud9f8\udc77-->\012",
        Z.run(T, 2, 7, 8, 8, "\ud933\udc2e\ud9f8\udc77", "\ua93f\u22e3\u2fc4\ua2c9", "\ud939\udcf8\udbf5\uddfd\ud902\udf3d\udb99\udd97\udad1\udf3c\ud83f\uddeb\udb4b\udf34\udae0\udcaf\ud9ff\udc2b\ud9f0\udc04\udac8\udef3\udbeb\udd74\ud974\udd58\ud95b\udc64\udafb\udf92\ud822\uddbd",
        16, 4709, 1420787896, 3261410117590282739L, -8888L, false, true, (char) 10194, (char) 34786,
        Double.longBitsToDouble(0x3fdb99a33511565eL), Double.longBitsToDouble(0x3fdc16449d8df91aL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\udbbf\udd46\ud9b2\udcda\udb89\udc20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\ud81d\udf94\u9bb8--> |this=org.jsoup.nodes.Comment:\012<!--\udbbf\udd46\ud9b2\udcda\udb89\udc20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\ud81d\udf94\u9bb8-->\0121=void |a1=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\udbbf\udd46\ud9b2\udcda\udb89\udc20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\ud81d\udf94\u9bb8-->\012",
        Z.run(T, 2, 7, 4, 7, "\udbbf\udd46\ud9b2\udcda\udb89\udc20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\udb1e\udf65\udb69\udffa\uda09\uddb2\ud81d\udf94\u9bb8", "\u3a71\ub7ec\u2e8a\u517d\ua446\uc72d\u8e13\u644c\u2291\u729b\u85ce\ub1c7\u8410\u853e\u0b48\u8820\uc271\u0621\u17a0\u888c\u3ef2\u7933\u86db\u8dfc\u2d34\u7141\uae99\u4338\u4281", "\udaa6\udf1d\udbd0\udfc5\udb0d\udfd2",
        50, 91208, -229088208, 5582476044458690373L, -75076L, true, true, (char) 19196, (char) 58230,
        Double.longBitsToDouble(0x3fec2b11ae2f6dddL), Double.longBitsToDouble(0x3fed26f6b65d68e1L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Comment:\012<!--\udab6\udd14\ud9ea\udcb0\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\u76fb\udb6a\udc52\uda09\uddb2\uda43\udde6\uda00\udfb4--> |this=org.jsoup.nodes.Comment:\012<!--\udab6\udd14\ud9ea\udcb0\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\u76fb\udb6a\udc52\uda09\uddb2\uda43\udde6\uda00\udfb4-->\0121=org.jsoup.nodes.Comment:\012<!--\udab6\udd14\ud9ea\udcb0\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\u76fb\udb6a\udc52\uda09\uddb2\uda43\udde6\uda00\udfb4--> |this=org.jsoup.nodes.Comment:\012<!--\udab6\udd14\ud9ea\udcb0\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\u76fb\udb6a\udc52\uda09\uddb2\uda43\udde6\uda00\udfb4-->\012",
        Z.run(T, 2, 7, 7, 4, "\udab6\udd14\ud9ea\udcb0\udba8\ude20\ud8d2\udf20\udb8a\udcd4\udb96\udf03\ud953\ude58\uebb8\u76fb\udb6a\udc52\uda09\uddb2\uda43\udde6\uda00\udfb4", "\u6389\u7c53\u82b6\uaaa6\ua979\uc72d\u965f\u6424\u85b8", "\ud93b\uddb4\uda36\uddf6\ud925\udc25\ud930\udd0a\udb9f\udc91",
        25, 15282, -1085877208, 8166860705110397496L, 40674L, true, true, (char) 9113, (char) 59644,
        Double.longBitsToDouble(0x3fe9952f1e828600L), Double.longBitsToDouble(0x3fdf476b9613876eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a1=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude5f\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=void |a1=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude5f\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 4, 4, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude5f\u6fc9\udbc2\ude18\uda63\udf9f", "\u819b\u3ee7\u40ff\u11c1\uaf49\u84c3\ub2d6\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud8be\udea3\uda3c\udf92\ud97f\ude62\ud930\udf14\ud972\udc35\uf0b2",
        3, 73792, -1203129012, -4886654473125241559L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fe41436e1f476b9L), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"&#55747;&#56620;&#55420;&#57216;&#55389;&#57274;&#55506;&#57120;&#55553;&#56369;&#56179;&#56464;\uc804&#55993;&#57071;&#56258;&#56893;&#55391;&#57000;&#55596;&#57208;&#55853;&#57246;&#56048;&#56325;&#55503;&#57240;&#56194;&#57082;&#55593;&#57110;&#55443;&#56604;&#55488;&#57295;&#55563;&#57301;&... |this=org.jsoup.nodes.Comment:\012<!--\ud9c3\udd2c\ud87c\udf80\ud85d\udfba\ud8d2\udf20\ud901\udc31\udb73\udc90\uc804\udab9\udeef\udbc2\ude3d\ud85f\udea8\ud92c\udf78\uda2d\udf9e\udaf0\udc05\ud8cf\udf98\udb82\udefa\ud929\udf16\ud893\udd1c\ud8c0\udfcf\ud90b\udfd5\udb26\udc48\udaad\udd7e\udb03\udd77\ud943\ude2b\ud81a\udce4\ud915\udd88-->\0121=java.lang.Boolean:false |this=org.jsoup.nodes.Comment:\012<!--\ud9c3\udd2c\ud87c\udf80\ud85d\udfba\ud8d2\udf20\ud901\udc31\udb73\udc90\uc804\udab9\udeef\udbc2\ude3d\ud85f\udea8\ud92c\udf78\uda2d\udf9e\udaf0\udc05\ud8cf\udf98\udb82\udefa\ud929\udf16\ud893\udd1c\ud8c0\udfcf\ud90b\udfd5\udb26\udc48\udaad\udd7e\udb03\udd77\ud943\ude2b\ud81a\udce4\ud915\udd88-->\012",
        Z.run(T, 2, 8, 13, 16, "\ud9c3\udd2c\ud87c\udf80\ud85d\udfba\ud8d2\udf20\ud901\udc31\udb73\udc90\uc804\udab9\udeef\udbc2\ude3d\ud85f\udea8\ud92c\udf78\uda2d\udf9e\udaf0\udc05\ud8cf\udf98\udb82\udefa\ud929\udf16\ud893\udd1c\ud8c0\udfcf\ud90b\udfd5\udb26\udc48\udaad\udd7e\udb03\udd77\ud943\ude2b\ud81a\udce4\ud915\udd88", "\ua25a\u8eb2\uc757\u2c06\u9c10\u60da\u1772\u888c\u3ef2\u17dc\ud44a\u0b01\u2d34\u792a\u5125", "\ud969\udef5\ud9c6\ude7e\udb5d\ude06\udb22\udfc2\ud813\udd72\u524f\ud8ea\ude77\ud94a\udd2e\udba5\udc9d\u9999\udb08\udd3b\uda8f\ude9e\udbe0\udf64\udaef\udd96\ud9c3\udf63",
        33, 56427, 133676442, -8610820038671512071L, -18806L, false, false, (char) 21163, (char) 48481,
        Double.longBitsToDouble(0x3fd2b5bedbf50f6aL), Double.longBitsToDouble(0x3fca5d2a7a4572c4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud99a\udd7c\ud8a1\udc3d\ud9c0\uddf7\ud997\ude87\udb80\udfe4\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\udaea\ude77\uda2b\udfad\ud806\udee9\uad6a\ud817\udd0b-->\0121=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud99a\udd7c\ud8a1\udc3d\ud9c0\uddf7\ud997\ude87\udb80\udfe4\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\udaea\ude77\uda2b\udfad\ud806\udee9\uad6a\ud817\udd0b-->\012",
        Z.run(T, 2, 12, 12, 8, "\ud99a\udd7c\ud8a1\udc3d\ud9c0\uddf7\ud997\ude87\udb80\udfe4\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\udaea\ude77\uda2b\udfad\ud806\udee9\uad6a\ud817\udd0b", "\u96ef\u6db6\u1437\u9306\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\ud877\udc4e\udb61\uddac\u24fe\ud89b\udce1",
        3, 26026, -534202997, -4352503711870447878L, 39327L, false, true, (char) 13036, (char) 59197,
        Double.longBitsToDouble(0x3fed2bdc2185805cL), Double.longBitsToDouble(0x3fd9ba2056af89bcL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"&#55656;&#57168;&#55421;&#56353;&#56232;&#56864;&#55506;&#57120;\" |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20-->\0121=org.jsoup.nodes.Attributes: comment=\"&#55656;&#57168;&#55421;&#56353;&#56232;&#56864;&#55506;&#57120;\" |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20-->\012",
        Z.run(T, 2, 8, 8, 10, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20", "\u9f34\u36e9\ubba7\u1407\u806c\uabca\u8bb5\u3ee7", "\ud833\udcab\ud8d0\udf2b\ud918\udef9\ud976\udcaa\udaad\udce1",
        33, 83600, -325368333, 8175769168610660038L, -71469L, true, true, (char) 42352, (char) 40323,
        Double.longBitsToDouble(0x3fe75cb198dc1e29L), Double.longBitsToDouble(0x3fdca34c4b177e0cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 6, 12, "\ud904\udebd\ud818\udd60\ud80f\udef0\ud8d2\udf20\uda24\ude42\uda94\udf1f\ud962\udd1f\udbeb\udc79\u2753\000", "\u8bb5\u3ee7\ucb60\u4639\uae72\u84c3\u92ea\000\000", "",
        27, 21598, 1361649606, -1890426902272306968L, -100000L, false, true, (char) 47588, (char) 16239,
        Double.longBitsToDouble(0x3fe37c83518bc89fL), Double.longBitsToDouble(0x3fdfdc59fc5f652eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"&#55656;&#57168;&#55421;&#56353;&#56232;&#56864;&#55506;&#57120;&#55553;&#56369;&#55937;&#56344;&#55635;&#56821;\u6fc9&#56258;&#56856;&#55464;&#56544;&#55851;&#57261;&#55302;&#57065;\uad6a&#55319;&#56587;&#56219;&#56514;&#55593;&#57110;&#55443;&#56604;&#55683;&#56916;&#55428;&#56862;&#55301;&#57206;... |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\uda81\udc18\ud953\uddf5\u6fc9\udbc2\ude18\ud8a8\udce0\uda2b\udfad\ud806\udee9\uad6a\ud817\udd0b\udb9b\udcc2\ud929\udf16\ud893\udd1c\ud983\ude54\ud884\ude1e\ud805\udf76\uda32\udfcb\udbeb\ude2b\ud974\udd58\udbc9\udcce\udaec\udd6d\ud80b\udd29-->\012",
        Z.run(T, 1, 8, 16, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\uda81\udc18\ud953\uddf5\u6fc9\udbc2\ude18\ud8a8\udce0\uda2b\udfad\ud806\udee9\uad6a\ud817\udd0b\udb9b\udcc2\ud929\udf16\ud893\udd1c\ud983\ude54\ud884\ude1e\ud805\udf76\uda32\udfcb\udbeb\ude2b\ud974\udd58\udbc9\udcce\udaec\udd6d\ud80b\udd29", "\u131e\u5709\u2104\uaaaa\u0fb2\u1772\u888c\u3ef2\u7933\ub164\u8dfc", "\ud982\udc0e\ud853\udd81\uda05\ude66",
        10, 58933, 1724977755, 838209789961063810L, 80571L, true, false, (char) 32468, (char) 5630,
        Double.longBitsToDouble(0x3fe53dbabbf0aaa0L), Double.longBitsToDouble(0x3fc779b1a7d6de08L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |a0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=void |a0=[Lorg.jsoup.nodes.Node;:[[]] |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 5, 5, 14, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u70d7", "\udbeb\udd74\ud974\udd58\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud8a6\ude8c\udbf1\ude31\ud9b2\udfa1\ud902\udefd\udbeb\ude91\uf0b2\ud995\udebb\ud98d\udd6b\ud83a\udd51\udb58\ude8f",
        20, 1672, 881940929, -8703690612747181127L, -71633L, false, true, (char) 39269, (char) 53332,
        Double.longBitsToDouble(0x3fdd791df4f0bb08L), Double.longBitsToDouble(0x3fe7f2086df2da77L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"&#55747;&#56620;&#55420;&#57216;&#55389;&#57274;&#55506;&#57120;&#55553;&#56369;&#56179;&#56464;\uc804&#55993;&#57071;&#56258;&#56893;&#55391;&#57000;&#55596;&#57208;&#55853;&#57246;&#56048;&#56325;&#55503;&#57240;&#56194;&#57082;&#55593;&#57110;&#55443;&#56604;&#55488;&#57295;&#55563;&#57301;&... |this=org.jsoup.nodes.Comment:\012<!--\ud9c3\udd2c\ud87c\udf80\ud85d\udfba\ud8d2\udf20\ud901\udc31\udb73\udc90\uc804\udab9\udeef\udbc2\ude3d\ud85f\udea8\ud92c\udf78\uda2d\udf9e\udaf0\udc05\ud8cf\udf98\udb82\udefa\ud929\udf16\ud893\udd1c\ud8c0\udfcf\ud90b\udfd5\uda63\udfa6\udac1\ude4d\udb03\udd77\ud943\ude2b\ud81a\udce4\ud915\udd88-->\0121=org.jsoup.nodes.Attributes: comment=\"&#55747;&#56620;&#55420;&#57216;&#55389;&#57274;&#55506;&#57120;&#55553;&#56369;&#56179;&#56464;\uc804&#55993;&#57071;&#56258;&#56893;&#55391;&#57000;&#55596;&#57208;&#55853;&#57246;&#56048;&#56325;&#55503;&#57240;&#56194;&#57082;&#55593;&#57110;&#55443;&#56604;&#55488;&#57295;&#55563;&#57301;&... |this=org.jsoup.nodes.Comment:\012<!--\ud9c3\udd2c\ud87c\udf80\ud85d\udfba\ud8d2\udf20\ud901\udc31\udb73\udc90\uc804\udab9\udeef\udbc2\ude3d\ud85f\udea8\ud92c\udf78\uda2d\udf9e\udaf0\udc05\ud8cf\udf98\udb82\udefa\ud929\udf16\ud893\udd1c\ud8c0\udfcf\ud90b\udfd5\uda63\udfa6\udac1\ude4d\udb03\udd77\ud943\ude2b\ud81a\udce4\ud915\udd88-->\012",
        Z.run(T, 2, 8, 8, 12, "\ud9c3\udd2c\ud87c\udf80\ud85d\udfba\ud8d2\udf20\ud901\udc31\udb73\udc90\uc804\udab9\udeef\udbc2\ude3d\ud85f\udea8\ud92c\udf78\uda2d\udf9e\udaf0\udc05\ud8cf\udf98\udb82\udefa\ud929\udf16\ud893\udd1c\ud8c0\udfcf\ud90b\udfd5\uda63\udfa6\udac1\ude4d\udb03\udd77\ud943\ude2b\ud81a\udce4\ud915\udd88", "\ua25a\u8eb2\uc757\u2c06\u9c10\u60da\u1772\u888c\u3ef2\u17dc\ud44a\u0b01\u2d34\u792a\u5125", "\ud969\udef5\ud9c6\ude7e\udb5d\ude06\udb22\udfc2\ud813\udd72\u524f\ud8ea\ude77\ud94a\udd2e\udba5\udc9d\u9999\udb08\udda5\uda8f\ude9e\udbe0\udf64\udaef\udd96\ud9c3\udf63",
        33, 56427, 133676442, -8610820038671512071L, -18806L, false, false, (char) 21163, (char) 48481,
        Double.longBitsToDouble(0x3fd2b5bedbf50f6aL), Double.longBitsToDouble(0x3fca5d2a7a4572c4L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Attributes: comment=\"\" |this=org.jsoup.nodes.Comment:\012<!---->\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 7, 0, "", "\u9aad", "\udb45\udd90\uc804\000\udb9c\udf0e\ud85f\udea8\ud92c\udf78\u5db4\udad2\uddc9\ud8cf\udf98\udb82\udefa\ud929\udf16\uac28\000\u8200\udb25\udfa6\udaad\udd7e\udbf6\udd73\ud943\ude2b\ud81a\udce4\u3786\uda57\ude8a\ud9b5\udc07\udbc1\ude2c\ud304\ud973\udf39\udbe8\udfa1\udaa6\udd6e\ud92b\udd57\uda14\udc57\ud83a\udd51\000\ud8a4\udf71\ud837\udfbd\ud80d\ude95\udb67\udcb4\u8277\ud978\udd95\u00dc",
        59, 54601, 8641848, 6461583544320074005L, 39048L, true, false, (char) 0, (char) 1344,
        Double.longBitsToDouble(0x3fe89941d534a312L), Double.longBitsToDouble(0x3fef75e51e14e9c5L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\0121=java.lang.String: |this=org.jsoup.nodes.Comment:\012<!--\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f-->\012",
        Z.run(T, 2, 0, 6, 12, "\ud968\udf50\ud87d\udc21\udba8\ude20\ud8d2\udf20\ud901\udc31\udb96\udf03\ud953\ude58\u6fc9\udbc2\ude18\uda63\udf9f", "\u8bb5\u3ee7\u40cf\u220e\uae72\u84c3\u70d7\u7741\uc72d", "\udbc9\udcce\udaec\udd6d\ud80b\udd29\ud815\udfcf\uda36\uddf6\uda49\ude78\ud930\udcf9\udb60\udc2c\uf0b2",
        3, 73792, -1203128949, -7335291113442390599L, 54049L, false, false, (char) 59644, (char) 52501,
        Double.longBitsToDouble(0x3fedb87ee1f4768eL), Double.longBitsToDouble(0x3fe84e1dba38b60dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Node|getOutputSettings||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|outerHtml|java.lang.StringBuilder|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|outerHtml||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|absUrl|java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|addChildren|int,[Lorg.jsoup.nodes.Node;|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|addChildren|[Lorg.jsoup.nodes.Node;|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|attr|java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|attr|java.lang.String,java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|attributes||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|baseUri||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|childNode|int|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|childNodes||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|childNodesAsArray||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|equals|java.lang.Object|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|hasAttr|java.lang.String|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|hashCode||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|getOutputSettings||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|outerHtml|java.lang.StringBuilder|new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
    "M|org.jsoup.nodes.Node|outerHtml||new:org.jsoup.nodes.Comment:java.lang.String,java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
