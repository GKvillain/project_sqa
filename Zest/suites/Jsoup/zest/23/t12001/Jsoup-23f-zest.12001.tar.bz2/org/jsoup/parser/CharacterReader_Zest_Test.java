package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class CharacterReader_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc85\ud85a\udf97 |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 8, 8, 13, "\udb7f\udc85\ud85a\udf97", "\u9f2a\u5ed5\u1710\u6cbf", "\uda33\udecd\udb52\ude35\ud81b\udf3a",
        35, 16311, -1215295478, 8256029117024917450L, -89766L, true, false, (char) 25986, (char) 37380,
        Double.longBitsToDouble(0x3fe06c4a09c577b4L), Double.longBitsToDouble(0x3fcc1448868e67e8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 8, 13, "\udb7f\udc85\ud85a\udf97", "\u9f2a\u0081\ubdfe\u8b7c", "\uda33\udecd\uda7c\udc8b\ud81b\udf3a\ud9de\udd45\ud9fc\udd60\ud87a\udfc5\uda17\udd7d\udb62\udcb0\ud821\udc16\uda4c\ude98\ud850\udf08\uda43\ude0c\uda09\udc27\ud922\udc26\u9937\udb5d\udedc\udae1\udcaa\udbca\udc3c\uda93\udffe\ud899\udd5c\ud8fa\udf93\ud99d\udea5\ud8dc\udf4b\ud8b5\udddb\ud8f7\uded8\uda08\udf08\ud9c7\udf0f\ud8a6\udf7b",
        46, 32794, -1470096894, -6844806025558928277L, 48645L, true, true, (char) 7687, (char) 43088,
        Double.longBitsToDouble(0x3fe7e32abd6876e5L), Double.longBitsToDouble(0x3fd81197b4771208L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc85\ud90d\udeb4 |a0=[C:[[\u4003, \u5f84]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 8, 13, "\udb7f\udc85\ud90d\udeb4", "\u4003\u5f84", "\ud9f6\udfe1\ud921\uddbd\ud842\udf0c",
        20, 42451, 119579435, 2710838662866669578L, 81466L, false, false, (char) 28332, (char) 42354,
        Double.longBitsToDouble(0x3fedb2316cf06e68L), Double.longBitsToDouble(0x3fe06c4b016d5199L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\ud94e\udf59\ud85a\udf97 |a0=[C:[[\u9f2a, \u5ed5, \u1710, \ud3f5]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 3, 14, "\ud94e\udf59\ud85a\udf97", "\u9f2a\u5ed5\u1710\ud3f5", "\ud9c6\udd9b\uda01\udc8a\ubb2e\uda00\udf96",
        34, 59199, 1922256573, 6308795176344348807L, 76303L, false, true, (char) 41969, (char) 23419,
        Double.longBitsToDouble(0x3fe1a1543ce0a24bL), Double.longBitsToDouble(0x3fda399fa15d7e3aL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc85 |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 11, 0, 0, "\udb7f\udc85", "\u64ba\ubf1b\u5ed5", "\u3335\000\uda16\udc4a",
        3, -1000, 119579392, 2710838220485038080L, -34464L, true, false, (char) 28332, (char) 59189,
        Double.longBitsToDouble(0x3fec252ff3276eddL), Double.longBitsToDouble(0x3fe06c4a09c577b4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Character:\udb54 |this=org.jsoup.parser.CharacterReader:\udb54\udfcb\ud876\udf5d\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\ud9a7\ude1d\udbcc\udc33\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udb54\udfcb\ud876\udf5d\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\ud9a7\ude1d\udbcc\udc33\012",
        Z.run(T, 2, 13, 7, 7, "\udb54\udfcb\ud876\udf5d\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\ud9a7\ude1d\udbcc\udc33", "\u945e\u02d3\u1df8", "\ud94a\udd2d\uda1a\ude6b\uda85\udd8c\udbc6\udcde\udaa4\udf9f\u7d6f",
        19, 4135, 2008338957, -6754245208961280800L, -3743L, true, true, (char) 17392, (char) 41449,
        Double.longBitsToDouble(0x3fcd915ed3b4d8d0L), Double.longBitsToDouble(0x3fa2ae4a0c973080L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.CharacterReader:\udb7e\udfea\012",
        Z.run(T, 1, 14, 11, 13, "\udb7e\udfea", "\uc65f\000\000", "",
        -5, -1000, 82903040, 31102145713405952L, 85600L, false, false, (char) 1614, (char) 51805,
        Double.longBitsToDouble(0x3fe43abc680696a6L), Double.longBitsToDouble(0x3ec0fe1294000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.CharacterReader:\udc85\ud85a\udf97\012",
        Z.run(T, 1, 2, 8, 13, "\udb7f\udc85\ud85a\udf97", "\u9f2a\u1d5a\u34e3\u6cbf\u88f0\uca3b", "\ud81b\udf3a\udbc3\ude97\uda25\udf9e",
        27, 8485, 1468880842, -7591170633941657594L, 47696L, true, true, (char) 23374, (char) 37241,
        Double.longBitsToDouble(0x3fcc1448868e67e8L), Double.longBitsToDouble(0x3fd4c3c034ed55b0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbd9\udc9c\uda86\udcb2\ud992\udca9\ud881\udfbe\ud949\udc5f\ud95d\udcb7\udad0\udc70\ud876\udc9a\udbe0\udea6\012",
        Z.run(T, 1, 5, 0, 5, "\udbd9\udc9c\uda86\udcb2\ud992\udca9\ud881\udfbe\ud949\udc5f\ud95d\udcb7\udad0\udc70\ud876\udc9a\udbe0\udea6", "\u1c0e\u1daf\u380a\u1bd2\u2035\u8dd0\u89e3\u7b2f\u87b9\u176d\u149e\u8881\u3ba0\uc2ac\u63f5\u22a4\u800c\u4dcb\u040a\u9833\u7083\u144d\u994b\u524d\u039e\u50a8\ub943", "\udbda\udcde\ud9c0\udffc\ud8af\ude66\ud93e\udf08\uda3c\udc0c\u58dc\uda27\uddce\ud8ad\udcea\uda0f\udd63\ud9ee\udef4\uda0a\udc76\ud948\udefe\udad2\udec6",
        31, 3144, -487813570, -3945169687679817142L, -18394L, false, false, (char) 10702, (char) 4218,
        Double.longBitsToDouble(0x3fecac096c979a54L), Double.longBitsToDouble(0x3fe138bef3fdbaecL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Character:\udb7f |this=org.jsoup.parser.CharacterReader:\udc85\ud85a\udf97\012",
        Z.run(T, 1, 3, 8, 13, "\udb7f\udc85\ud85a\udf97", "\u9f2a\u5ed5\u1710\u6cbf", "\ud87a\udd39\uda86\ude68\u9ee3",
        53, 48674, -1215295478, 8256029117024917450L, -89766L, true, false, (char) 5728, (char) 55414,
        Double.longBitsToDouble(0x3fe06c4a09c577b4L), Double.longBitsToDouble(0x3fcc1448868e67e8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\uda96\uddea\ud882\ude97\ud87a\udcc1\udba0\udf4b\ud8f0\udd97\012",
        Z.run(T, 1, 16, 0, 13, "\uda96\uddea\ud882\ude97\ud87a\udcc1\udba0\udf4b\ud8f0\udd97", "\u6cbf\ua2ef\uca3b", "\ud976\udf87\uc1ef\ud9f0\udf53\ud87a\udfc5\uda17\udd7d\udb69\udcf2\uda84\udc51",
        51, 38143, 1860026244, -8539210445633564147L, 75648L, true, false, (char) 57989, (char) 36977,
        Double.longBitsToDouble(0x3fd306db1c5efd30L), Double.longBitsToDouble(0x3fd0239ebfbe8018L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 13, 10, "\udb7f\udc85\ud85a\udf97", "\ub4b9\u5f21\u1710\u6cbf", "\uda33\udecd\udac7\uddc8\ud81b\udf3a\uda00\udf96\udaec\udfd1\ud885\udcd7\uda17\udd7d\udb69\udcf2\uda84\udc51\uda50\uddd2\ud840\udc54\uda43\ude0c\uda09\udc27\udbd2\udd1a\ud808\ude86",
        43, 77851, -203151821, 55478202401590428L, -42783L, true, true, (char) 41429, (char) 8604,
        Double.longBitsToDouble(0x3fdb9d2b8cb43346L), Double.longBitsToDouble(0x3fdaf1feea0d12feL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\ud935\uddba\ud8fb\ude11 |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 9, 11, 5, "\ud935\uddba\ud8fb\ude11", "\u9f2a\u5ed5\u1710\ud698", "\uda03\udd94\ud975\udf1a",
        34, 13754, 631166210, -5219654331064430915L, 79847L, false, false, (char) 7990, (char) 25986,
        Double.longBitsToDouble(0x3fe93b76eaedb741L), Double.longBitsToDouble(0x3fdc577b44e94488L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.CharacterReader:\udb7f\udc85\ud85a\udf97\012",
        Z.run(T, 1, 12, 8, 13, "\udb7f\udc85\ud85a\udf97", "\u9f2a\ud4fd\u87a6\u8191", "\udae7\udccd\udb52\ude35\ud81b\udf3a",
        35, 83567, -1215295478, 8256029117024917450L, -89766L, true, true, (char) 20126, (char) 44863,
        Double.longBitsToDouble(0x3fe06c4a09c577b4L), Double.longBitsToDouble(0x3fcc1448868e67e8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc85\ud85a\udf97 |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 8, 8, 13, "\udb7f\udc85\ud85a\udf97", "\u9f2a\u5ed5\u1710\u6cbf", "\uda33\udecd\udb52\ude35\ud81b\udf3a",
        35, 16311, -1215295478, 1056743637696468938L, 47580L, true, true, (char) 23374, (char) 37241,
        Double.longBitsToDouble(0x3fcc1448868e67e8L), Double.longBitsToDouble(0x3fb7d60c576b8d50L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbd4\udd24\ud85a\udff9\udb85\udf79\udbc9\udf97\ud8f0\udd97\uabfe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b\0121=java.lang.String: |a0=[C:[[\udbd4, \udd24, \ud85a, \udff9, \udb85, \udf79, \udbc9, \udf97, \ud8f0, \udd97, \uabfe, \udac7, \udfa3, \udbbf, \ude44, \udb1e, \udc3d, \udac2, \uddd0, \uda47, \udd3a, \udbd3, \udc7b]] |this=org.jsoup.parser.CharacterReader:\udbd4\udd24\ud85a\udff9\udb85\udf79\udbc9\udf97\ud8f0\udd97\uabfe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b\012",
        Z.run(T, 2, 0, 10, 8, "\udbd4\udd24\ud85a\udff9\udb85\udf79\udbc9\udf97\ud8f0\udd97\uabfe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b", "\u71fd\u0430", "\uda84\udc51\udaa4\udf3c\ud850\udf61\uda43\ude0c\udb24\udd8f\ud843\udcce\uda63\udc8d\udb60\udca5\ud9ab\udea3\ud9f8\udee1",
        13, 80307, 224051048, 2184535336962659010L, -39392L, true, true, (char) 20621, (char) 53029,
        Double.longBitsToDouble(0x3fe49917baa9969eL), Double.longBitsToDouble(0x3fed61bca5c08dfeL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udcaf\ud85a\udf97\udbbd\udcf4\udba0\udf75\udaad\udc14\u0806\udaad\udcf2\udbcb\udf5d\uda13\udff7\ud843\udcfe\uda33\udecd\udb52\ude35\ud81b\udf3a\ubbee |a0=[C:[[\u8e88, \u5f8e, \ub9aa, \u40a7, \u3e02]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 13, 12, "\udb7f\udcaf\ud85a\udf97\udbbd\udcf4\udba0\udf75\udaad\udc14\u0806\udaad\udcf2\udbcb\udf5d\uda13\udff7\ud843\udcfe\uda33\udecd\udb52\ude35\ud81b\udf3a\ubbee", "\u8e88\u5f8e\ub9aa\u40a7\u3e02", "\udbd2\udd1a\udb79\udc3e\udb5d\udedc\ud8bc\udc96\u01aa\ud99e\udc04\ud90c\udec8\uda2b\uddee\ud99a\udd5d\udb9c\udc04\ud84d\udd98\udaa5\udcc2",
        53, 52943, 1453194630, 3764271450900403369L, -39424L, false, false, (char) 28495, (char) 25785,
        Double.longBitsToDouble(0x3f9f77c835c07ae0L), Double.longBitsToDouble(0x3fce0dc76dc5b880L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\ud9e0\udf2a\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44\0121=java.lang.Character:\ud9e0 |this=org.jsoup.parser.CharacterReader:\udf2a\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44\012",
        Z.run(T, 2, 6, 3, 9, "\ud9e0\udf2a\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44", "\ua58c\u0e6a\u5fed\uc2ac\u63f5\u6976\u7b5f\u9802\u4536\u390a", "\u57a9\ud83b\udce5\udbb6\udcc4\udb8c\udfe5\udab2\uded5\udb73\udcb3\udbda\udfd4\udbcc\udd8b\ud91e\udc13\ud878\udc13\udb37\udf75\ud80b\udf9e\ud8f7\udea1\uda30\udc77\ud93a\uddfa\ud841\ude1b",
        5, 46716, -1147335226, 3075987566786526104L, -79109L, true, false, (char) 44228, (char) 24145,
        Double.longBitsToDouble(0x3fd1ad9e15d669acL), Double.longBitsToDouble(0x3fd6ded0a46b8802L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\012",
        Z.run(T, 1, 0, 0, 13, "\000", "\u645b\000\u8e0a", "\000",
        56, 11379, 846102333, 269565032398848L, -95894L, true, false, (char) 51805, (char) 22548,
        Double.longBitsToDouble(0x3e15e6c000000000L), Double.longBitsToDouble(0x3fec252ff00000ddL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\ub498\ud85a\udf97 |a0=[C:[[\u9f2a, \u5ed5, \u1710, \u6cbf]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 10, 8, "\ub498\ud85a\udf97", "\u9f2a\u5ed5\u1710\u6cbf", "\uda33\udecd\udb52\ude35\ud81b\udf3a",
        35, 16311, -1215295478, 8256029117024917450L, -89766L, true, false, (char) 25986, (char) 37380,
        Double.longBitsToDouble(0x3fe06c4a09c577b4L), Double.longBitsToDouble(0x3fcc1448868e67e8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\ud8bc\udd42\ud85a\udfc8\udbbd\udcf4\ud8b9\ude22\ud8f0\udd97\uda5b\udf45\ud9a7\uddf3\udbcc\udc33\udb4f\udff5\ud9b7\udf97\uda30\udc4e\udb52\ude35\ud81b\udf3a\uda58\udea1\uda25\udf9e\ud878\udfc5\uda17\udd7d\udb69\udcf2 |a0=[C:[[\uabfa, \u0b46, \ud410, \u5fed, \uc2ac, \u63f5, \u0ab1, \uc60a, \u6bf0, \u0fdb, \ubc34]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 7, 13, "\ud8bc\udd42\ud85a\udfc8\udbbd\udcf4\ud8b9\ude22\ud8f0\udd97\uda5b\udf45\ud9a7\uddf3\udbcc\udc33\udb4f\udff5\ud9b7\udf97\uda30\udc4e\udb52\ude35\ud81b\udf3a\uda58\udea1\uda25\udf9e\ud878\udfc5\uda17\udd7d\udb69\udcf2", "\uabfa\u0b46\ud410\u5fed\uc2ac\u63f5\u0ab1\uc60a\u6bf0\u0fdb\ubc34", "\uda4c\udf15\ud92f\udeb9\ud984\udcbc\udbe2\udd95\udafa\ude5d\ud870\udeac\udbbb\ude3e\udacb\udd28\ud96d\udf3a\ud94d\uddbf\ud82f\udc94\ud8f9\udc55\u2d66\ud9e4\udd87\ud8c5\ude5c\ud8af\udfcd",
        12, 4037, -456838636, 8896303771023138561L, -87312L, false, false, (char) 21039, (char) 7933,
        Double.longBitsToDouble(0x3fc4cbf34d28cbbcL), Double.longBitsToDouble(0x3feedd0502c4bb99L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\udb0b\ude87\udbff\uddb7\u3bda\udba0\udfa6\ud8f0\udd97\ud8a9\udc2c\udab5\ude02\udbd3\udef0\udb4b\udc7f\udba8\udd5c\ud9f8\udf67\ud82f\ude4f\ud9db\udcc2\uda59\udd43\uda18\udf25\ud8aa\udcdd\ud9de\ude27 |a0=[C:[[\u4392, \u3da9, \u32ea, \u0e6a, \u6e43, \u8785, \u40b4, \uc5af, \u7152, \u42d5, \u5002, \u7b70, \ud5fa, \u62e7, \ud3e2, \u9910, \u4e8d, \u43f8, \u97d3, \u5475, \u50f4]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 4, 0, "\udb0b\ude87\udbff\uddb7\u3bda\udba0\udfa6\ud8f0\udd97\ud8a9\udc2c\udab5\ude02\udbd3\udef0\udb4b\udc7f\udba8\udd5c\ud9f8\udf67\ud82f\ude4f\ud9db\udcc2\uda59\udd43\uda18\udf25\ud8aa\udcdd\ud9de\ude27", "\u4392\u3da9\u32ea\u0e6a\u6e43\u8785\u40b4\uc5af\u7152\u42d5\u5002\u7b70\ud5fa\u62e7\ud3e2\u9910\u4e8d\u43f8\u97d3\u5475\u50f4", "\ud913\udc80",
        2, 41437, 1158059855, 2384613127734396730L, -81078L, false, true, (char) 62349, (char) 45631,
        Double.longBitsToDouble(0x3fd898758de24ddeL), Double.longBitsToDouble(0x3fee2083f4bdea97L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 13, "\ud8c1\udcf6\ud85b\udc5d", "\u9f2a\u2a48\u79da\u8b7c", "\uda33\ude9d\uda7c\udc8b\uda22\ude1d\ud9de\udde7\ud9fc\udd60\ud87a\udfc5\uda17\udd7d\udb62\udcb0\ud821\udc16\uda4c\ude98\ud850\udf08\uda43\ude0c\uda09\udc27\ud922\udc26\u9937\udb5d\udedc\udae1\udcaa\udbca\udc3c\uda93\udffe\ud899\udd5c\ud8fa\udf93\ud99d\udea5\ud8d9\udd2a\ud907\udc10\ud8f7\uded8\uda08\udf08\ud9c7\udf0f\ud8a6\udf7b",
        46, 32794, -1470096894, -6844806028795494228L, 48726L, true, true, (char) 7775, (char) 43088,
        Double.longBitsToDouble(0x3fe7e32abd6876e5L), Double.longBitsToDouble(0x3fd81197b4771208L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc85\000 |a0=[C:[[\u3f6f, \u5f84]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 8, 13, "\udb7f\udc85\000", "\u3f6f\u5f84", "\ud9f6\udfe1\ud921\uddbd\ud842\udf0c",
        20, 31907, 119579435, 2710838662866669578L, 81466L, false, false, (char) 28332, (char) 42354,
        Double.longBitsToDouble(0x3fedb2316cf06e68L), Double.longBitsToDouble(0x3fe06c4b016d5199L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc74\ud90d\udeb4 |a0=[C:[[\u4003, \u5f84, \u1710, \u6cbf, \u9937, \uc95d, \u902c, \u839f, \u06f5, \u7b9d, \u71fd]] |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 10, 8, 8, "\udb7f\udc74\ud90d\udeb4", "\u4003\u5f84\u1710\u6cbf\u9937\uc95d\u902c\u839f\u06f5\u7b9d\u71fd", "\ud82c\udf74\uda6f\udfd1\udbbb\udd48\udbc2\udc10\uda96\ude37\ud96f\uddf2\ue4dc\ud89d\udd03\ud854\udc03\ua916\ud8e8\udc84\udae9\udec9\udb51\uddb3\udabb\udc7a\udb71\udc6a\ud8a7\udcc9\uda72\udf26\udb4b\ude08\ud806\udfcc\udabd\udff8\u59e6\ud9c5\udd52",
        -1, 78306, 1671318433, -4350485060715385727L, -35748L, true, true, (char) 33032, (char) 52858,
        Double.longBitsToDouble(0x3fd06c57261c1030L), Double.longBitsToDouble(0x3febe5136d0e6271L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\udb2e\udffa\udb99\ude99\u3760\ud8ae\udf08\ud871\udee8\uda5b\udff4\ud9a7\uddf3\udbcb\udfd0 |a0=[C:[[\u5f47, \ua5d3, \ucaa1, \u7c0b, \u71fd, \u822f, \u051a, \u9148, \u0385, \u80f2, \u2f18]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 8, 8, "\udb2e\udffa\udb99\ude99\u3760\ud8ae\udf08\ud871\udee8\uda5b\udff4\ud9a7\uddf3\udbcb\udfd0", "\u5f47\ua5d3\ucaa1\u7c0b\u71fd\u822f\u051a\u9148\u0385\u80f2\u2f18", "\ud815\udedc\ud8b9\udf70\ud925\udcc6\ud9d8\udcde\udb6e\udf11\u0cf7\ud983\ude96\udb37\udd06",
        51, 65839, 1014910, -5268996766793947643L, 26807L, false, true, (char) 32811, (char) 63867,
        Double.longBitsToDouble(0x3fe07e9ea91a8dbcL), Double.longBitsToDouble(0x3fe62316a27f9e4bL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\udbaf\uddbc\ud90d\ude6a\udbd1\udfb9\ud878\udd86\ud894\udec8 |a0=[C:[[\u6cbf, \u9937, \uc922]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 6, 11, "\udbaf\uddbc\ud90d\ude6a\udbd1\udfb9\ud878\udd86\ud894\udec8", "\u6cbf\u9937\uc922", "\ud828\udf9f\uda00\udf96\ud8b7\ude07",
        16, 8221, 86850342, 2878488876792529670L, 42835L, true, true, (char) 17095, (char) 53668,
        Double.longBitsToDouble(0x3fe0d3019d247a0fL), Double.longBitsToDouble(0x3fddbb7c1c4ecbf8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:\udb7b\udfbc |a0=[C:[[\u6462, \u72db, \ud7ef, \ubda3, \u6cbf, \u9937, \uc95d, \u312c, \u6e3c, \u5823, \u38ca, \u72c5, \u715d]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 1, 12, "\udb7b\udfbc", "\u6462\u72db\ud7ef\ubda3\u6cbf\u9937\uc95d\u312c\u6e3c\u5823\u38ca\u72c5\u715d", "\ud935\udd5b\ud956\udd0b\ud8c7\udc20\ud9e5\udc3e",
        15, 80277, 1382074733, -3997114271558047699L, -20740L, true, false, (char) 17946, (char) 33133,
        Double.longBitsToDouble(0x3fe3a5682fd3d8a6L), Double.longBitsToDouble(0x3fe2d6b0dacd68deL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\u0547\ud9f4\ude68 |a0=[C:[[\u4003, \u5f84, \u1710, \u6cbf, \u9937, \uc95d, \u9015, \u839f, \u06f5, \u7b9d, \u71fd, \u822f, \u051a, \u9148, \ub598, \u938c, \u938c, \ubaa7, \u6058, \ua383, \u71cb, \u1f40, \u337a, \u93dd, \u5148, \u4fb8, \u424c, \u9d68, \u817d, \u33f1, \u48e7, \u9df5, \ub0e4, \u52ab, \uca6f, \u89cd, \u2d6e, \u5170]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 8, 13, "\u0547\ud9f4\ude68", "\u4003\u5f84\u1710\u6cbf\u9937\uc95d\u9015\u839f\u06f5\u7b9d\u71fd\u822f\u051a\u9148\ub598\u938c\u938c\ubaa7\u6058\ua383\u71cb\u1f40\u337a\u93dd\u5148\u4fb8\u424c\u9d68\u817d\u33f1\u48e7\u9df5\ub0e4\u52ab\uca6f\u89cd\u2d6e\u5170", "\ud889\uddef\ud8a7\udf05\ud978\udf0a\ud8a0\udd72\ud987\udc50\uda6a\udda7\ud98f\udeb3",
        49, 423, 2029193727, -54239430611588527L, 33374L, true, true, (char) 33200, (char) 59022,
        Double.longBitsToDouble(0x3fc911baf02242d4L), Double.longBitsToDouble(0x3fe77c1e96eaf163L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc34\ud90d\udeb4\udb63\udc9e\udbde\uddd5\ud894\udec8\uda68\udcf4\ud9a7\uddf3\udbcc\udc33\ud9f6\udfe1\ud921\uddbd\udbbd\udea4\udb52\uded2\ud828\udf9f\uda00\udf96\ud82f\udd37\ud91f\udffe\uda47\udd3e\uc490\ud997\uded1 |a0=[C:[[\u9a75, \ud567, \uac3c, \ub913, \u32a0, \uab17, \u4dc5, \u7fda, \u3119, \u1694, \u8159, \uc160, \u6414, \u5c7f, \u02e7, \u73ac, \ud01a, \u4218, \u6d14, \uc08f, \u1041, \u4345, \u9c14, \u46d8, \ud111, \u2d3a, \u71f7, \u7e71, \uc396, \u3cf3, \u4f08, \u3acf, \u855b, \u223b]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 8, 13, "\udb7f\udc34\ud90d\udeb4\udb63\udc9e\udbde\uddd5\ud894\udec8\uda68\udcf4\ud9a7\uddf3\udbcc\udc33\ud9f6\udfe1\ud921\uddbd\udbbd\udea4\udb52\uded2\ud828\udf9f\uda00\udf96\ud82f\udd37\ud91f\udffe\uda47\udd3e\uc490\ud997\uded1", "\u9a75\ud567\uac3c\ub913\u32a0\uab17\u4dc5\u7fda\u3119\u1694\u8159\uc160\u6414\u5c7f\u02e7\u73ac\ud01a\u4218\u6d14\uc08f\u1041\u4345\u9c14\u46d8\ud111\u2d3a\u71f7\u7e71\uc396\u3cf3\u4f08\u3acf\u855b\u223b", "\udba7\udeec\ud915\ude41\ud872\ude45\udb24\ude82\ud888\udec6\udaaf\udeaa\udb4d\udcc7\udbd1\ude71\udad8\uddea\ud993\udfdb\udac0\uddbf\udafe\udfc0\udbaf\udd19\udbd5\udeaf",
        1, 39143, 268849034, -7306607744233945301L, 45326L, false, false, (char) 1339, (char) 56410,
        Double.longBitsToDouble(0x3fe0bb34eda11240L), Double.longBitsToDouble(0x3fe9448308203221L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbb1\udc9a\uda7e\udeec\ub859\udba0\udf20\ud894\udec8\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbb1\udc9a\uda7e\udeec\ub859\udba0\udf20\ud894\udec8\012",
        Z.run(T, 2, 5, 9, 13, "\udbb1\udc9a\uda7e\udeec\ub859\udba0\udf20\ud894\udec8", "\ub14c\uc59f", "\udabb\udf30\udaeb\udd9f\udbb2\udc60\uda25\udf9e\ud87a\udfc5\ud9a3\udd38\ud82c\udf74\udbb2\udeba\ud8d6\udd32\udb80\udf63\ud82e\udd83\uda45\uded2\ud8c1\udd00\udb82\udff4",
        20, 82777, 915168136, -7357411486125990364L, 17244L, false, true, (char) 54717, (char) 55735,
        Double.longBitsToDouble(0x3fbd562f432b8188L), Double.longBitsToDouble(0x3fba73ca2d346760L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\012",
        Z.run(T, 1, 5, 0, 14, "\000", "", "",
        5, 73601, 13401088, 0L, -99782L, false, false, (char) 0, (char) 56422,
        Double.longBitsToDouble(0x3f844b3def6de400L), Double.longBitsToDouble(0x3eb1800000000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\ua29b |a0=[C:[[\u64ba]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 8, 13, "\ua29b", "\u64ba", "\ud9a7\uddf3\u00fd\000\000\000\udb52\uddf8\ud828\udf9f\uda00\udf96\ud949\udd70",
        16, 8221, 86850342, -7591370905666201594L, -99818L, false, false, (char) 23405, (char) 6918,
        Double.longBitsToDouble(0x3fe002ad6c850a61L), Double.longBitsToDouble(0x3fe605f6c661f91aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc85\ud90d\udeb4\ud931\udfdb\udba0\udf75\ud894\udec8\uda5b\udff4\ud9a7\uddf3\udbcc\udc33\ud9f6\udfe1\udba8\udf01\ud842\udf0c\udb52\uded2\ud828\udf9f\uda06\ude72\udabc\udc0a\ud85e\ude17\ud91e\ude99\udb40\udfd4\uda56\ude77\udbbb\udd48\udafc\udc0d\uda96\ude37\ud958\udff2\ud815\udedc\u1a98 |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 11, 6, 3, "\udb7f\udc85\ud90d\udeb4\ud931\udfdb\udba0\udf75\ud894\udec8\uda5b\udff4\ud9a7\uddf3\udbcc\udc33\ud9f6\udfe1\udba8\udf01\ud842\udf0c\udb52\uded2\ud828\udf9f\uda06\ude72\udabc\udc0a\ud85e\ude17\ud91e\ude99\udb40\udfd4\uda56\ude77\udbbb\udd48\udafc\udc0d\uda96\ude37\ud958\udff2\ud815\udedc\u1a98", "\u9275\u8a64\u89b5\ubda8\u9f14\u9559\ua899\uc147\u329f\uc948\u5c4f\u1a40\u9b85\u7490\u79d7\u2cde\uab03\u9e3c\ubed9\uc96c\u7f76\u46f2\u66b4\u8110\u57da\u0381\u6adcb\u2793\u0dc6\u824b\u9adc\u5170", "\ud877\ude3d\ud95d\udcb4\u5868\udbb7\udcb5\ud9c7\udc17\ud88b\udd84\ud97f\udfbe",
        7, 88923, -318887354, 3941236806468256665L, -60623L, false, false, (char) 40386, (char) 37891,
        Double.longBitsToDouble(0x3fdbebb17461922cL), Double.longBitsToDouble(0x3feeef7926ac1e9dL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:\ua29b\000 |a0=[C:[[\u4003]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 8, 13, "\ua29b\000", "\u4003", "\udbcc\udc33\ud9f6\udfe1\ud921\uddbd",
        59, 24490, 1837233451, 513589763230324071L, -13917L, false, true, (char) 3471, (char) 28332,
        Double.longBitsToDouble(0x3fef5e8c3bb6462dL), Double.longBitsToDouble(0x3fce0dcd08362580L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\ud94e\udf59\ud88c\udf90\ud861\udce8\uda52\udf53\uda0d\udfab |a0=[C:[[\ud3c9, \u4d1b, \ucf36]] |this=org.jsoup.parser.CharacterReader:\0121=java.lang.Character:\uffff |this=org.jsoup.parser.CharacterReader:!toString:java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 3, 13, "\ud94e\udf59\ud88c\udf90\ud861\udce8\uda52\udf53\uda0d\udfab", "\ud3c9\u4d1b\ucf36", "\ubb2e\udb83\udf38\uda2e\udf70\ucc49\ud98e\ude2d\udb69\udcf2\uda08\udfed\ud862\udcda\ud850\udf61\ud8a5\udc05",
        30, 79205, 1232418295, -4972308834702302999L, 82096L, false, true, (char) 64562, (char) 26609,
        Double.longBitsToDouble(0x3fd4a7578e5e8948L), Double.longBitsToDouble(0x3fe66991c6b6cf46L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc85 |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 11, 0, 0, "\udb7f\udc85", "\u3b7e\u6071\u6577", "\ud95e\udf3d\000\uda16\udc4a",
        25, -901, 129723012, 2239930584448110625L, -34464L, true, false, (char) 8207, (char) 51654,
        Double.longBitsToDouble(0x3feff977f3276eddL), Double.longBitsToDouble(0x3fe06c4a0de57b1bL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Character:\udb54 |this=org.jsoup.parser.CharacterReader:\udb54\udfcb\u00eb\udbbd\udcf4\ud9da\ude53\000\ud92e\udfb6\uda25\ude1c\udbcc\udc33\0121=java.lang.Boolean:true |this=org.jsoup.parser.CharacterReader:\udb54\udfcb\u00eb\udbbd\udcf4\ud9da\ude53\000\ud92e\udfb6\uda25\ude1c\udbcc\udc33\012",
        Z.run(T, 2, 13, 12, 7, "\udb54\udfcb\u00eb\udbbd\udcf4\ud9da\ude53\000\ud92e\udfb6\uda25\ude1c\udbcc\udc33", "\u945e\u02d3\ub5ac", "\ud94a\udd2d\uda1a\ude6b\uda85\udd8c",
        54, 13425, -71139921, 7988751885689496359L, -93403L, false, false, (char) 58269, (char) 25175,
        Double.longBitsToDouble(0x3fecc5b327ff9c4aL), Double.longBitsToDouble(0x3fea4dc6b412a7deL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Character:\000 |this=org.jsoup.parser.CharacterReader:\000\uda91\ude68\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\u00d3\udbcc\udc33\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\uda91\ude68\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\u00d3\udbcc\udc33\012",
        Z.run(T, 2, 13, 7, 7, "\000\uda91\ude68\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\u00d3\udbcc\udc33", "\u945e\u02d3\u1df8", "\ud94a\udd2d\uda1a\ude6b\uda85\udd8c\udbc6\udcde\udaa4\udf9f\u7d6f",
        19, 4135, 2008338957, -6754245208961280800L, -3743L, true, true, (char) 17392, (char) 41449,
        Double.longBitsToDouble(0x3fcd915ed3b4d8d0L), Double.longBitsToDouble(0x3fa2ae4a0c973080L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udf36\ud87a\uddef\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\ud9a7\ude1d\udb88\udfb1 |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 11, 7, 7, "\udb54\udf36\ud87a\uddef\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\ud9a7\ude1d\udb88\udfb1", "\u945e\u3b74\uad3b\u63cc\uc789\u12c8\u6d57\u8a13\u702f\u410a\ub837", "\udbd2\udd1a\ud850\udf9f\udba2\udd1d\ud8c7\udc2b\ud9ea\udfa8\uda4b\uddc0\ud9d6\udf58\udaf4\udf94\ud823\udd8f\ud933\ude5e\ud9d3\udf37\udb6a\udfd1",
        9, 94857, -1680289249, 8396665040111191234L, 39477L, true, true, (char) 63934, (char) 54415,
        Double.longBitsToDouble(0x3fbd95f369bf1800L), Double.longBitsToDouble(0x3fd04f4e1b06ce94L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udb54\udfcb\ud876\udf5d\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\ud9a7\ude1d\udbcc\udc33\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udb54\udfcb\ud876\udf5d\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\ud9a7\ude1d\udbcc\udc33\012",
        Z.run(T, 2, 7, 7, 7, "\udb54\udfcb\ud876\udf5d\udbbd\udcf4\ud9da\ude53\uda29\uddba\ud945\udd5c\ud9a7\ude1d\udbcc\udc33", "\u945e\u79a2\ucb61", "\ud94a\udd2d\uda92\udc48\uda85\udd8c\udbc6\udcde\udaa4\udf9f\u7d6f\uda43\ude0c\uda09\udc27\udbd2\udd1a\udb79\udc3e\udb08\udcb9\udbac\udec7\ud9f8\udc5d\udaf9\udd96\ud97e\udfcd\ud98a\ude17\u5c29\ud933\ude21\udb22\udc1d\udbc4\udee9\uda52\udf55\ud8bb\udd2f\ud80c\ude3f\ua423\u1b81\ud9e1\udead\uda21\uded0\uda95\udef3\ud828\udede\ud991\udc91\ud90a\ude64\ud8c2\udee3\udb1f\udc5f\ud847\udf62\udb53\udcd1",
        24, 90407, -238833001, -6327421417241063461L, -76728L, true, false, (char) 61849, (char) 4450,
        Double.longBitsToDouble(0x3fe071262980f8b3L), Double.longBitsToDouble(0x3fbf31c38f119a78L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:\ud866\udf94\ud876\udf5d\udb98\udc71\udbcb\udc2a\ud9fb\ude8c\ud945\udd5c\u4cc0\udbcb\udf9e\udb11\udf0e\ud8aa\udf0c |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 9, 5, 12, "\ud866\udf94\ud876\udf5d\udb98\udc71\udbcb\udc2a\ud9fb\ude8c\ud945\udd5c\u4cc0\udbcb\udf9e\udb11\udf0e\ud8aa\udf0c", "\u9290\u36ae\u602b\ud73e\u9add\ud2fd\u6f7f", "\uda43\uddb9\ud8c9\udf9d\uda6d\udffb\udb79\udc3e\udb5d\udedc\ud8af\udeb1\udba8\udf8e\udb32\udd4e\ud993\ude9a\udb7b\ude8f",
        27, 15204, 909440236, 4210026644544995365L, 15749L, false, true, (char) 40981, (char) 10532,
        Double.longBitsToDouble(0x3fd1a69072540e72L), Double.longBitsToDouble(0x3fe653c09a406d69L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.CharacterReader:\udb2d\udd90\0121=void |this=org.jsoup.parser.CharacterReader:\udb2d\udd90\012",
        Z.run(T, 2, 15, 15, 7, "\udb2d\udd90", "\u6a54\ub542\u6e65\ubb9c\u6c39\ucaf0\ud051\u945e\u02d3\u1df8\u63cc\ub4dd\uccda\ucab4\u1b51\u99b1\u410a\u60a8\u32ea\u0e6a\u5fed\ua261\u8631", "\udaf9\uddb7\udba6\udde7\ud975\ude7a\udb21\udeaf\ud933\ude5e\udb22\udc1d\udaac\ude61",
        27, 28801, 1750893072, -4526811480530422407L, -55881L, false, false, (char) 36078, (char) 29563,
        Double.longBitsToDouble(0x3fe75cf546cbc8eaL), Double.longBitsToDouble(0x3fee0e8cc5c30601L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udb54\udfcb\ud876\udf5d\udbbd\udcf4_\000\ud950\udfa7\ud9a7\ude1d\udbcc\udc33\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udb54\udfcb\ud876\udf5d\udbbd\udcf4_\000\ud950\udfa7\ud9a7\ude1d\udbcc\udc33\012",
        Z.run(T, 2, 0, 16, 7, "\udb54\udfcb\ud876\udf5d\udbbd\udcf4_\000\ud950\udfa7\ud9a7\ude1d\udbcc\udc33", "\u7683\ubd55\u1df8", "\ud94a\udd2d\uda1a\ude6b\uda85\udd8c\udbc6\udcde\udaa4\udf9f\ud9b7\uddba",
        1, 4135, 2008338957, -6754245208961280800L, -100000L, false, true, (char) 34814, (char) 28703,
        Double.longBitsToDouble(0x3f92a7dea89494a0L), Double.longBitsToDouble(0x3fcd915ed3b4d8d0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:\udb54\udfcb\ud876\udf5d\udbbd\udcf4\ud9da\ude53\ud926\udd74\udaaa\udf88\ud9a7\ude44\udbcc\udc33 |this=org.jsoup.parser.CharacterReader:\0121=java.lang.Character:\uffff |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 11, 13, 16, "\udb54\udfcb\ud876\udf5d\udbbd\udcf4\ud9da\ude53\ud926\udd74\udaaa\udf88\ud9a7\ude44\udbcc\udc33", "\u945e\u02d3\u1df8", "\ud94a\udd2d\uda1a\ude6b\uda85\udd8c\udbc6\udcde\udaa4\udf9f\u7d6f",
        19, 4135, 2008338957, -6754245208961280800L, -3743L, true, true, (char) 17392, (char) 55961,
        Double.longBitsToDouble(0x3fdb760c59da6d9eL), Double.longBitsToDouble(0x3fa2ae4a0c973080L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udc85\ud85a\udf97\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 6, "\udb7f\udc85\ud85a\udf97", "\u5a3e\u5ed5\u1710\u6cbf", "\ud87a\udd39\uda86\ude68",
        32, 16363, 1644632674, -5219654334371250755L, 14311L, false, false, (char) 30006, (char) 56441,
        Double.longBitsToDouble(0x3fbf833e506c4a00L), Double.longBitsToDouble(0x3fdc577b48948a88L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:\udb90\udc07 |this=org.jsoup.parser.CharacterReader:\000\012",
        Z.run(T, 1, 8, 0, 16, "\udb90\udc07\000", "\ubf1b", "\udb94\udf2a\000\ud843\udcfe",
        26, 15760, -466619136, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd586edd41b12fcL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String:\udbd4\udd24\ud85a\udff9\udb85\udf79\udbc9\udf97\ud8f0\udd97\ud867\udffc\udad5\udeb2\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b |a0=[C:[[\u71fd, \u0430]] |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |a0=[C:[[\udbd4, \udd24, \ud85a, \udff9, \udb85, \udf79, \udbc9, \udf97, \ud8f0, \udd97, \ud867, \udffc, \udad5, \udeb2, \udbbf, \ude44, \udb1e, \udc3d, \udac2, \uddd0, \uda47, \udd3a, \udbd3, \udc7b]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 10, 10, 8, "\udbd4\udd24\ud85a\udff9\udb85\udf79\udbc9\udf97\ud8f0\udd97\ud867\udffc\udad5\udeb2\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b", "\u71fd\u0430", "\uda84\udc51\udaa4\udf3c\ud850\udf61\uda43\ude0c\udb24\udd8f\ud843\udcce\uda63\udc8d\udb60\udca5\ud9ab\udea3\ud9f8\udee1",
        13, 80307, 224051048, 2184535336962659010L, -39392L, true, true, (char) 20621, (char) 53029,
        Double.longBitsToDouble(0x3fe49917baa9969eL), Double.longBitsToDouble(0x3fed61bca5c08dfeL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.CharacterReader:\u45a4\ud85a\udffd\udb85\udf79\udbc9\udf97\udb68\ude6c\uacf3\ud909\udea8\udbbf\ude75\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 8, "\u45a4\ud85a\udffd\udb85\udf79\udbc9\udf97\udb68\ude6c\uacf3\ud909\udea8\udbbf\ude75\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b", "\u6cfd\u0430", "\uda84\udc51\udaa4\udf3c\udbbb\udc12\uda43\uddee\udb25\udfdd\ud843\udcce\uda63\udc8d\udb60\udca5\ud9ab\udea3\ud9f8\udee1",
        18, 80307, 224051048, 2184535338220950210L, -97450L, true, false, (char) 21381, (char) 64223,
        Double.longBitsToDouble(0x3fe8a5ade91779d0L), Double.longBitsToDouble(0x3fe176e30a38422cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbd4\udd24\ud85a\udff9\udb85\udf79B\ud8c6\ude03\ua2fe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd35\u8583\0121=java.lang.Boolean:true |this=org.jsoup.parser.CharacterReader:\udbd4\udd24\ud85a\udff9\udb85\udf79B\ud8c6\ude03\ua2fe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd35\u8583\012",
        Z.run(T, 2, 0, 12, 8, "\udbd4\udd24\ud85a\udff9\udb85\udf79B\ud8c6\ude03\ua2fe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd35\u8583", "\u74fc\u0430", "\udb43\ude90\ue006\ud850\udf61\uda43\ude0c\u00a6\ud81c\udc4d\uda63\udc8d\u84c6\ud9a9\ude94\000",
        57, 80307, 224051048, 2184535336962659010L, -100000L, false, false, (char) 27854, (char) 64768,
        Double.longBitsToDouble(0x3e35480000000000L), Double.longBitsToDouble(0x3fed61bca5c08dfeL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String:\udbc5\udd10\ud85a\udff9\udb85\udf79\udbc9\udf97\ud8f0\udd97\uabfe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b\udb56\ude58\udb61\udc0e\uda25\udf9e\ud891\uddc5\udb5c\udf40\udb42\udce0\uda84\udc51\udaa4\udf3c\ud850\udf61\uda43\ude0c\udb24\udd8f\ud843\udcce\uda63\udc8d\udb60\udca5\ud9ab\udea3\ud9f8\udee1\uda56\udc9b\ud8b5\udf22\uda0a\udef7\ud970\udf13\ud843\udc91\udbfd\udddd\udb85\udf84\uda74\udc1d\ud8b0\udfa9\uda14\udfa5\ud86c\udc5d\ud9e1\uddef |a0=[C:[[\ubc50, \u17d4, \u11dd, \uc07f, \ub53c, \ud649, \ub6d0, \u21ff, \u77f2, \uca7f]] |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |a0=[C:[[\udbc5, \udd10, \ud85a, \udff9, \udb85, \udf79, \udbc9, \udf97, \ud8f0, \udd97, \uabfe, \udac7, \udfa3, \udbbf, \ude44, \udb1e, \udc3d, \udac2, \uddd0, \uda47, \udd3a, \udbd3, \udc7b, \udb56, \ude58, \udb61, \udc0e, \uda25, \udf9e, \ud891, \uddc5, \udb5c, \udf40, \udb42, \udce0, \uda84, \udc51, \udaa4, \udf3c, \ud850, \udf61, \uda43, \ude0c, \udb24, \udd8f, \ud843, \udcce, \uda63, \udc8d, \udb60, \udca5, \ud9ab, \udea3, \ud9f8, \udee1, \uda56, \udc9b, \ud8b5, \udf22, \uda0a, \udef7, \ud970, \udf13, \ud843, \udc91, \udbfd, \udddd, \udb85, \udf84, \uda74, \udc1d, \ud8b0, \udfa9, \uda14, \udfa5, \ud86c, \udc5d, \ud9e1, \uddef]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 10, 10, 16, "\udbc5\udd10\ud85a\udff9\udb85\udf79\udbc9\udf97\ud8f0\udd97\uabfe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b\udb56\ude58\udb61\udc0e\uda25\udf9e\ud891\uddc5\udb5c\udf40\udb42\udce0\uda84\udc51\udaa4\udf3c\ud850\udf61\uda43\ude0c\udb24\udd8f\ud843\udcce\uda63\udc8d\udb60\udca5\ud9ab\udea3\ud9f8\udee1\uda56\udc9b\ud8b5\udf22\uda0a\udef7\ud970\udf13\ud843\udc91\udbfd\udddd\udb85\udf84\uda74\udc1d\ud8b0\udfa9\uda14\udfa5\ud86c\udc5d\ud9e1\uddef", "\ubc50\u17d4\u11dd\uc07f\ub53c\ud649\ub6d0\u21ff\u77f2\uca7f", "\udb72\udce5\udb7c\udfa4\udb16\ude91\ud8aa\udead\uda63\ude32\ua86b\udb92\udc7c\ud934\udcff\ud8e9\udc82\ud91d\udda4\ud9cf\udd92\udb78\udddc",
        38, 96875, -724811427, 4074008388117598708L, 26409L, true, true, (char) 40787, (char) 53708,
        Double.longBitsToDouble(0x3fe85068df482372L), Double.longBitsToDouble(0x3fe93f1ac6a2e3b4L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:\udbd4\udd24\ud85a\udff9\udb3c\udf05\udb75\udd7a\ud8f0\udd8e\uabfe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b |a0=[C:[[\u71fd, \u0430]] |this=org.jsoup.parser.CharacterReader:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 1, 13, "\udbd4\udd24\ud85a\udff9\udb3c\udf05\udb75\udd7a\ud8f0\udd8e\uabfe\udac7\udfa3\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbd3\udc7b", "\u71fd\u0430", "\uda84\udc51\udaa4\udf3c\udb8b\udffd\uda43\ude0c\udb24\udd8f\ud843\udcce\uda63\udc8d\udb60\udca5\ud9ab\udea3\ud9f8\udee1",
        13, 80307, 224051048, 2184535336962659010L, -39392L, true, false, (char) 20533, (char) 53029,
        Double.longBitsToDouble(0x3fe49917baa9969eL), Double.longBitsToDouble(0x3fed61bca5c08dfeL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.String:6 |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 0, 0, 1, "6", "\u6fc9\u9f2a\u0c6f", "\udb1e\udc3d",
        55, 23237, 9471363, -1275699062L, -72854L, true, false, (char) 29467, (char) 48774,
        Double.longBitsToDouble(0x3f7a5a98579b4380L), Double.longBitsToDouble(0x3fec252ff1a66eddL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Character:\udbd4 |this=org.jsoup.parser.CharacterReader:\udbd4\udd24\ud9b5\udea7\udbda\udc75\ud962\uddfa\ud8f3\udec9\uabfe\ud94c\udf1a\udbbf\ude44\ud898\udf9a\ud99f\udc98\uda7b\udd9e\ud873\udcab\0121=java.lang.Character:\udbd4 |this=org.jsoup.parser.CharacterReader:\udbd4\udd24\ud9b5\udea7\udbda\udc75\ud962\uddfa\ud8f3\udec9\uabfe\ud94c\udf1a\udbbf\ude44\ud898\udf9a\ud99f\udc98\uda7b\udd9e\ud873\udcab\012",
        Z.run(T, 2, 13, 13, 13, "\udbd4\udd24\ud9b5\udea7\udbda\udc75\ud962\uddfa\ud8f3\udec9\uabfe\ud94c\udf1a\udbbf\ude44\ud898\udf9a\ud99f\udc98\uda7b\udd9e\ud873\udcab", "\u211a\ucc21", "\ud8aa\udd96\ud855\udc6a\ud995\udd2e\ud802\udeca\uee5c",
        29, 3862, -1174502202, 6074548921456927202L, 76300L, true, false, (char) 52429, (char) 15994,
        Double.longBitsToDouble(0x3fe57177e798814eL), Double.longBitsToDouble(0x3fd96fd8fd2645eeL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\000\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44\0121=java.lang.Character:V |this=org.jsoup.parser.CharacterReader:\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\000\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44\012",
        Z.run(T, 2, 6, 3, 9, "V\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\000\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44", "\ua58c\u0e6a\u5fed\uc2ac\ua7f4\u6976\u7b5f\u9802\u4536\u00fe", "\u57a9\ud83b\udce5\udbb6\udcc4\udb8c\udfe5\udab2\uded5\udb73\udcb3\udbda\udfd4\udbcc\udd8b\ud91e\udc13\ud878\udc13\udb37\udf75\ud80b\udf9e\ud8f7\udea1\uda30\udc77\ud93a\uddfa\ud841\ude1b",
        5, 46716, -1147335226, 3075987566786526104L, -79109L, true, false, (char) 44228, (char) 24145,
        Double.longBitsToDouble(0x3fd1ad9e15d669acL), Double.longBitsToDouble(0x3fd6ded0a46b8802L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44\0121=java.lang.Character:\000 |this=org.jsoup.parser.CharacterReader:\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44\012",
        Z.run(T, 2, 6, 3, 9, "\000\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44", "\ua58c\u0e6a\u5fed\uc2ac\u63f5\u6976\u7b5f\u9802\u4536\u390a", "\u57a9\ud83b\udce5\udbb6\udcc4\udb8c\udfe5\ud8e9\uddce\udb73\udcb3\udbda\udfd4\udbcc\udd8b\ud91e\udc13\ud878\udc13\udb37\udf75\ud80b\udf9e\ud8f7\udea1\uda30\udc77\ud93a\uddfa\ud841\ude1b",
        5, 46716, -1147335226, 3075987566786526104L, -79109L, false, false, (char) 0, (char) 24145,
        Double.longBitsToDouble(0x3fd1ad9e15d669acL), Double.longBitsToDouble(0x3fd6ded0a46b8802L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\ud9e0\udf2a\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\udbed\udc26\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda04\udff2\uda17\udd91\udb69\udcf2\udbb7\udd44\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\ud9e0\udf2a\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\udbed\udc26\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda04\udff2\uda17\udd91\udb69\udcf2\udbb7\udd44\012",
        Z.run(T, 2, 6, 6, 10, "\ud9e0\udf2a\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\udbed\udc26\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda04\udff2\uda17\udd91\udb69\udcf2\udbb7\udd44", "\ua58c\u0e6a\u5fed\uc2ac\u63f5\u6976\u7b5f\u9802\u4536\u390a", "\uda4e\udfa0\ud83b\udce5\udbb6\udcc4\udb63\udd16\udab2\uded5\udb73\udcb3\udbda\udfd4\udbcc\udd8b\ud91e\udc13\ud878\udc13\udb37\udf75\ud80b\udf9e\ud8f7\udea1\uda30\udc77\ud93a\uddfa\ud841\ude1b",
        5, 46716, -1147335226, 3075987566786526104L, -79109L, true, false, (char) 44228, (char) 24145,
        Double.longBitsToDouble(0x3fd1ad9e15d669acL), Double.longBitsToDouble(0x3fd6ded0a46b8802L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Character:\uda87 |this=org.jsoup.parser.CharacterReader:\udcfc\ud891\udd44\ud860\udd74\ud95e\udcaf\ud8f0\udd0a\udb5c\udef6\uda55\udd79\uda14\ude3d\ud9cf\udcc3\ud991\ude26\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udb72\udf03\0121=java.lang.Character:\udcfc |this=org.jsoup.parser.CharacterReader:\ud891\udd44\ud860\udd74\ud95e\udcaf\ud8f0\udd0a\udb5c\udef6\uda55\udd79\uda14\ude3d\ud9cf\udcc3\ud991\ude26\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udb72\udf03\012",
        Z.run(T, 2, 3, 3, 9, "\uda87\udcfc\ud891\udd44\ud860\udd74\ud95e\udcaf\ud8f0\udd0a\udb5c\udef6\uda55\udd79\uda14\ude3d\ud9cf\udcc3\ud991\ude26\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udb72\udf03", "\ua58c\u3d04\u5fed\uc2ac", "\ud8c9\udf64\udaf3\ude02",
        33, 64222, -1281160903, -8283840551931854760L, 56452L, false, true, (char) 50875, (char) 44891,
        Double.longBitsToDouble(0x3fd28d676555d30eL), Double.longBitsToDouble(0x3fe7e768523dcea3L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:G |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 0, 0, 13, "G", "\u645b\000\u8e0a", "\000",
        56, 11379, 846102333, -8286353749329263545L, -95894L, true, false, (char) 51805, (char) 22548,
        Double.longBitsToDouble(0x3e15e6c000000000L), Double.longBitsToDouble(0x3fec252ff0000014L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\012",
        Z.run(T, 2, 0, 0, 13, "\000", "\u645b\u8495\u8e0a\u19bb\u1ed0\000\uca3b", "\ufd2b\000\ud9f0\ude37",
        2, 23573, 1468880842, 580726554624L, 47580L, false, false, (char) 41603, (char) 40155,
        Double.longBitsToDouble(0x3fe7d6d49a07b238L), Double.longBitsToDouble(0x3fe067cfbdf8abfbL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String:r |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 0, 0, 12, "r", "\u51f6\u9213\u6392", "\udbd4\udfca\u95b1\uda33\udecd\udb52\ude35\ufd2b\000\ud9f0\ude37\ud8ef\udf3f",
        42, 36704, 135, 3891110974186238127L, -100000L, false, false, (char) 22490, (char) 36543,
        Double.longBitsToDouble(0x3fe5e97d58d9b290L), Double.longBitsToDouble(0x3fe9771d7e95ff9aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.String:\udbb1\udc9a\uda7e\udeec\ub859\ud90a\udfd5\udb49\udfca |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 9, 9, 8, "\udbb1\udc9a\uda7e\udeec\ub859\ud90a\udfd5\udb49\udfca", "\ub14c\uc59f\u6416\u71aa", "\ud82a\udd74\ud94d\uddb0\ud8a1\udc44\ud9a3\udd38\ud82c\udf74\udbb2\udeba\ud8d6\udd32\udb80\udf63",
        44, 88185, 555182270, 3094475887447705428L, -92691L, false, true, (char) 30729, (char) 23211,
        Double.longBitsToDouble(0x3fdfc131135159e2L), Double.longBitsToDouble(0x3fed34729880ba37L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbb1\udc9a\uda7e\udeec\ub859\udba0\udf20\ud9f5\udf99\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbb1\udc9a\uda7e\udeec\ub859\udba0\udf20\ud9f5\udf99\012",
        Z.run(T, 2, 5, 5, 13, "\udbb1\udc9a\uda7e\udeec\ub859\udba0\udf20\ud9f5\udf99", "\000\000", "",
        -5, -1000, 8066304, -1215295478L, 44128L, false, false, (char) 17152, (char) 3734,
        Double.longBitsToDouble(0x3fe8016b016d2117L), Double.longBitsToDouble(0x3fe801578800a555L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:6 |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 5, 0, 14, "6", "", "",
        1, 73601, 13401088, 0L, -99782L, false, false, (char) 46169, (char) 57666,
        Double.longBitsToDouble(0x3f844ad9ef6de400L), Double.longBitsToDouble(0x3eb1b00000000000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 16, 0, 0, "", "", "\ud894\udec8\uda5b\udff4\ud9a7\uddf3\udbcc\udc33\ud9f6\udfe1\udba8\udf01\udb06\udde2\udb52\uded2\ud828\udf9f\uda06\ude72\udabc\udc0a",
        30, 8086, 525810172, -7591370582755125242L, -100000L, false, false, (char) 0, (char) 51455,
        Double.longBitsToDouble(0x3fee885a239fa7ddL), Double.longBitsToDouble(0x3fd1575335483192L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.String:\ud94e\udf59 |a0=[C:[[\ud3c9, \u3567, \000]] |this=org.jsoup.parser.CharacterReader:\000\000\uda3c\udebd\uda0d\udfab\0121=java.lang.String: |a0=[C:[[\ud94e, \udf59, \000, \000, \uda3c, \udebd, \uda0d, \udfab]] |this=org.jsoup.parser.CharacterReader:\000\000\uda3c\udebd\uda0d\udfab\012",
        Z.run(T, 2, 10, 10, 13, "\ud94e\udf59\000\000\uda3c\udebd\uda0d\udfab", "\ud3c9\u3567\000", "",
        -5, 10195, 558891386, -7455539435911514906L, -14159L, false, true, (char) 41969, (char) 23419,
        Double.longBitsToDouble(0x3fdf72a87eec92eaL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\uda91\ude68\u65d9\ucd39\uda29\uddba\ud945\udd5c\uda2a\udff4\udbcb\udf7e\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\uda91\ude68\u65d9\ucd39\uda29\uddba\ud945\udd5c\uda2a\udff4\udbcb\udf7e\012",
        Z.run(T, 2, 7, 7, 7, "\000\uda91\ude68\u65d9\ucd39\uda29\uddba\ud945\udd5c\uda2a\udff4\udbcb\udf7e", "\u945e\u02d3\u1df8", "\ud94a\udd2d\uda1a\ude6b\uda85\udd8c\udbc6\udcde\udaa4\udf9f\u7d6f",
        34, 4135, 2008338957, -6754245208961280800L, -3743L, false, false, (char) 56431, (char) 52458,
        Double.longBitsToDouble(0x3fcd915ed3b4d8d0L), Double.longBitsToDouble(0x3fa2ae4a0c973080L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.String:\uda56\udf79\ud85b\udc50\udb85\udf79\ud9ea\udca7\udbfe\udcdd\ud91e\uddfa\udac7\udf13\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbe1\udd7b\udb56\ude58\ud8a8\udd11\uda25\udf7a\ud891\uddc5\ud9bd\udf52\udb46\udd19\uda84\udc51\udb4d\ude10\udb26\udd40\uda43\ude0c\udb24\udd8f\ud843\udcce\uda63\udc8d\udb60\udca5\ud96f\udd24\ud9f8\udee1\uda56\udc9b\ud8b5\udf22\uda0a\udef7\ud970\udf13\ud843\udc91\udbfb\udc1c\udac1\udfce\uda74\udc1d\ud8b0\udfa9\uda14\udfa5\ud86c\udc5d\ud9e1\ude3c |a0=[C:[[\ubc50, \u17d4, \u11dd, \u12fa, \ub711, \ud6e0, \u8342, \u8521, \u77f2, \uca7f, \u151e, \ud217, \u91d5, \u4b27, \u997f, \u118a, \u7405, \u16bf, \ua65a, \u6fb6, \u78ac, \uc990, \u321b, \u78da, \u2d76, \u50a0, \uab68, \u5c0d, \u20d6, \u8334, \u196d, \ud333, \u8527, \ub8fe, \u00e6, \u72dc, \u3d12, \u06f5]] |this=org.jsoup.parser.CharacterReader:\0121=void |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 10, 15, 15, "\uda56\udf79\ud85b\udc50\udb85\udf79\ud9ea\udca7\udbfe\udcdd\ud91e\uddfa\udac7\udf13\udbbf\ude44\udb1e\udc3d\udac2\uddd0\uda47\udd3a\udbe1\udd7b\udb56\ude58\ud8a8\udd11\uda25\udf7a\ud891\uddc5\ud9bd\udf52\udb46\udd19\uda84\udc51\udb4d\ude10\udb26\udd40\uda43\ude0c\udb24\udd8f\ud843\udcce\uda63\udc8d\udb60\udca5\ud96f\udd24\ud9f8\udee1\uda56\udc9b\ud8b5\udf22\uda0a\udef7\ud970\udf13\ud843\udc91\udbfb\udc1c\udac1\udfce\uda74\udc1d\ud8b0\udfa9\uda14\udfa5\ud86c\udc5d\ud9e1\ude3c", "\ubc50\u17d4\u11dd\u12fa\ub711\ud6e0\u8342\u8521\u77f2\uca7f\u151e\ud217\u91d5\u4b27\u997f\u118a\u7405\u16bf\ua65a\u6fb6\u78ac\uc990\u321b\u78da\u2d76\u50a0\uab68\u5c0d\u20d6\u8334\u196d\ud333\u8527\ub8fe\u00e6\u72dc\u3d12\u06f5", "\u5fcf\udbe3\udf6d\ud9b6\ude24\uda1f\udce8\udbc9\udfce\ud8cf\udcfb\udb5e\udd60\uda4b\ude5f\ud8ed\ude7d\ud8b1\udce1\udb6b\udc8f\ud6ed\udb9f\udc26\udba0\udd40\udb64\uded6\udbc1\udeb7\uda7b\udcd4\udb6a\udcd4\uda09\uddb5\udb66\udd62",
        48, 28231, 1812872511, 4994217835444574118L, -50407L, false, true, (char) 12214, (char) 25739,
        Double.longBitsToDouble(0x3fcafc0bc672260cL), Double.longBitsToDouble(0x3fc673469a2eb698L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:6 |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 6, 0, 1, "6", "\u6fc9\u9f2a\u0c6f", "\udb1e\udc3d",
        55, 23237, 9471363, 8489365797780680008L, 99602L, false, true, (char) 28725, (char) 48774,
        Double.longBitsToDouble(0x3f7a5a98579b4380L), Double.longBitsToDouble(0x3fe2352ff27cead3L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.String:V |this=org.jsoup.parser.CharacterReader:\ud81a\udd22\ud94b\udf21\udbb4\udc64\ud965\udd11\ud818\udd87\uda76\udfc5\uda0d\udf5a\udb0f\udf6d\ud951\udd61\ud9d3\ude3e\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\ud900\udf6e\udb4a\uddd0\udb69\udcf2\udbb7\udd44\udaa4\udf3c\ud850\udf61\udab1\udda0\uda09\udc27\udbd2\udd1a\0121=java.lang.String:\ud81a\udd22\ud94b\udf21\udbb4\udc64\ud965\udd11\ud818\udd87\uda76\udfc5\uda0d\udf5a\udb0f\udf6d\ud951\udd61\ud9d3\ude3e\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\ud900\udf6e\udb4a\uddd0\udb69\udcf2\udbb7\udd44\udaa4\udf3c\ud850\udf61\udab1\udda0\uda09\udc27\udbd2\udd1a |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 7, 8, 12, "V\ud81a\udd22\ud94b\udf21\udbb4\udc64\ud965\udd11\ud818\udd87\uda76\udfc5\uda0d\udf5a\udb0f\udf6d\ud951\udd61\ud9d3\ude3e\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\ud900\udf6e\udb4a\uddd0\udb69\udcf2\udbb7\udd44\udaa4\udf3c\ud850\udf61\udab1\udda0\uda09\udc27\udbd2\udd1a", "\u6976\u7b5f\u9802\u1421V\u263c\u32a7\u9cdb", "\udb8c\udfe5\udab2\uded5\udb73\udcb3\udbda\udfd4\udbcc\udd8b",
        46, 485, -1118940316, 1800980412596247441L, 8765L, true, true, (char) 5353, (char) 49810,
        Double.longBitsToDouble(0x3fdc63f364cb773aL), Double.longBitsToDouble(0x3fecc155800d0bd4L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud834\udc3f\ud927\udc23\000\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udad7\udd49\uda5c\udd78\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud834\udc3f\ud927\udc23\000\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udad7\udd49\uda5c\udd78\012",
        Z.run(T, 2, 6, 6, 9, "V\ud81a\udd22\ud9d6\udd45\udbbf\ude78\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud834\udc3f\ud927\udc23\000\udb32\udef8\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udad7\udd49\uda5c\udd78", "\ua58c\u0e6a\u5fed\uc2ac\ua7f4\u6976\u6860", "\u00fe",
        38, 64072, -1114264685, 3683040565880311667L, 35717L, true, true, (char) 56248, (char) 3122,
        Double.longBitsToDouble(0x3fe7e768523dcea3L), Double.longBitsToDouble(0x3feb26da5625bd4eL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\012",
        Z.run(T, 2, 6, 6, 2, "\000\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1", "\ua41d\u82e0\u0f54\u7b9d\u71fd\u42c7\u8e9c", "\udaa4\udf3c\ud850\udf61\ud867\udd9b\uda09\udc27\udbd2\udd1a\udb79\udc3e\udb5d\udedc\ud8eb\ude08\ud8c9\udec3\udaf3\ude02\udb5f\uddf5\ud811\udcb5\udb35\udcb2\uda6b\udc21\u57a9\ud83b\udce5\udbb6\udcc4\udb8c\udfe5\ud8e9\uddce\udb73\udcb3\udbda\udfd4",
        40, 68436, -615896515, -4805812062976582107L, -70519L, false, false, (char) 49810, (char) 15868,
        Double.longBitsToDouble(0x3fe32e68fb982ab0L), Double.longBitsToDouble(0x3f8a17a866cf3740L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:e |this=org.jsoup.parser.CharacterReader:\ud81a\udc88\u51e6\udbbf\ude51\udacd\ude24\ud9b1\udddb\udbd7\udc91\udb1e\udfa1\ud9cf\udd31\ud927\udc23\udad6\uddf8\udbc1\udc8b\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb07\ude2b\udbb7\udd44\0121=java.lang.Character:\ud81a |this=org.jsoup.parser.CharacterReader:\udc88\u51e6\udbbf\ude51\udacd\ude24\ud9b1\udddb\udbd7\udc91\udb1e\udfa1\ud9cf\udd31\ud927\udc23\udad6\uddf8\udbc1\udc8b\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb07\ude2b\udbb7\udd44\012",
        Z.run(T, 2, 6, 3, 9, "e\ud81a\udc88\u51e6\udbbf\ude51\udacd\ude24\ud9b1\udddb\udbd7\udc91\udb1e\udfa1\ud9cf\udd31\ud927\udc23\udad6\uddf8\udbc1\udc8b\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb07\ude2b\udbb7\udd44", "\u9671\u96a3\u03e0\u3ab5\u5e7c", "\udaf3\ude02\udb5f\uddf5\ud811\udcb5\udad1\udc1f",
        31, 36251, 1213928930, -8181583573358625962L, -78153L, false, true, (char) 3122, (char) 43014,
        Double.longBitsToDouble(0x3fd5b1cf0726321cL), Double.longBitsToDouble(0x3fe12dea739118feL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.String:r |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 7, 0, 12, "r", "\u51f6\u9213\u6392", "\udbd4\udfca\u95b1\uda33\udecd\udb52\ude35\ufd2b\000\ud9f0\ude37\ud8ef\udf3f",
        42, 36704, 135, -2050341659760525308L, -82122L, true, false, (char) 22490, (char) 36543,
        Double.longBitsToDouble(0x3fe5e97d58d9b290L), Double.longBitsToDouble(0x3fe9771d7e95ff9aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbb1\udc9a\uda7e\udeec\ub859\ud90a\udfd5\000\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbb1\udc9a\uda7e\udeec\ub859\ud90a\udfd5\000\012",
        Z.run(T, 2, 9, 9, 8, "\udbb1\udc9a\uda7e\udeec\ub859\ud90a\udfd5\000", "", "\ud914\udf31\ud9ef\ude83\udabb\udf30\uda88\udded\ud82a\udd74",
        55, 75561, -716787779, 373019376927180898L, -100000L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4d50abc4000000L), Double.longBitsToDouble(0x3fef4d2aac8d2bf5L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:6 |this=org.jsoup.parser.CharacterReader:\ud853\ude69\udb85\udf79\uda98\udfff\ud8d8\udd19\uabfe\u00a9\udbbf\ude44\udb1e\udc3d\ud9be\udf79\uda47\udd3a\ud9f3\udd8b\ud978\udc28\u9bee\ud8b4\ude56\ud856\udebb\uda34\udc41Y\uda84\udc51\udaa4\udf3c\ud850\udf61\uda1f\udd06\ud894\udd3b\ud88e\udff2\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\ud853\ude69\udb85\udf79\uda98\udfff\ud8d8\udd19\uabfe\u00a9\udbbf\ude44\udb1e\udc3d\ud9be\udf79\uda47\udd3a\ud9f3\udd8b\ud978\udc28\u9bee\ud8b4\ude56\ud856\udebb\uda34\udc41Y\uda84\udc51\udaa4\udf3c\ud850\udf61\uda1f\udd06\ud894\udd3b\ud88e\udff2\012",
        Z.run(T, 2, 6, 6, 16, "6\ud853\ude69\udb85\udf79\uda98\udfff\ud8d8\udd19\uabfe\u00a9\udbbf\ude44\udb1e\udc3d\ud9be\udf79\uda47\udd3a\ud9f3\udd8b\ud978\udc28\u9bee\ud8b4\ude56\ud856\udebb\uda34\udc41Y\uda84\udc51\udaa4\udf3c\ud850\udf61\uda1f\udd06\ud894\udd3b\ud88e\udff2", "\ubcca\u2afb\u2b97\u3086\u25be\ucb19\ubdfa\u0d74\u4e60\ud177\ud10c\uab21\u93c3\u800b\uc2d3\u4aba\u89ba\u5557\u04d9\ud67c\u26d6\uc438\u9c4e\u65c2\u088b\u9959\u47f0\u28ef\u36b2\uc3ca", "\ud9ae\udd74\uda3f\udd7f\udb39\udfbc\udb8b\udf6d\ud937\udcd9\udac6\udd78\udbb8\udc81\ud933\ude21\uda29\udebe\ud963\udefd\ud989\ude60\ud8b9\udfa2\ud98b\udd1a\ud9cd\udc8c\udb09\udc7c\ud8ed\udcb3\ud911\udce7\udb78\udfbd\ud8c7\ude0c\ud929\udf6d\ud86d\ude5b\ud9dd\udc61\ud988\udc01\udb90\udd46\udae8\uddb2",
        53, 83977, -868791916, -3506993719172209530L, 93739L, false, false, (char) 58824, (char) 46965,
        Double.longBitsToDouble(0x3fe5609cc303cf87L), Double.longBitsToDouble(0x3fe5d7c073357a76L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\ud94b\udf21\udbb4\udc64\ud965\udd11\0121=java.lang.Boolean:true |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\ud94b\udf21\udbb4\udc64\ud965\udd11\012",
        Z.run(T, 2, 12, 12, 1, "V\ud81a\udd22\ud94b\udf21\udbb4\udc64\ud965\udd11", "\u760b\ua7e4\ud47f\u3740\u03c5\u1daf", "\ud900\udf6e\udb4a\uddd0\udb69\udcf2\udbda\uddb7\udaa4\udf96\ud8ef\udf10\udaa8\udff6\uda09\udcbf\udbd2\udd1a\udb79\udc3e\ud809\ude04\ud8eb\ude08\ud97f\udd31\ud842\udefd\uda8a\udccc",
        16, 86401, -1928731928, -4785730379460010782L, -77691L, false, true, (char) 3122, (char) 43070,
        Double.longBitsToDouble(0x3fe1ee751b64db4aL), Double.longBitsToDouble(0x3fe12dea739197feL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:E |this=org.jsoup.parser.CharacterReader:\ud81a\udc88\u51e6\udbbf\ude51\udacd\ude24\ud9b1\udddb\udbd7\udc91\udb1e\udfa1\ud9cf\udd31\ud927\udc23\udad6\uddf8\udbc1\udc8b\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda18\udc6c\uda17\udd91\udb07\ude2b\uda70\ude11\0121=java.lang.Character:\ud81a |this=org.jsoup.parser.CharacterReader:\udc88\u51e6\udbbf\ude51\udacd\ude24\ud9b1\udddb\udbd7\udc91\udb1e\udfa1\ud9cf\udd31\ud927\udc23\udad6\uddf8\udbc1\udc8b\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda18\udc6c\uda17\udd91\udb07\ude2b\uda70\ude11\012",
        Z.run(T, 2, 6, 3, 11, "E\ud81a\udc88\u51e6\udbbf\ude51\udacd\ude24\ud9b1\udddb\udbd7\udc91\udb1e\udfa1\ud9cf\udd31\ud927\udc23\udad6\uddf8\udbc1\udc8b\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda18\udc6c\uda17\udd91\udb07\ude2b\uda70\ude11", "\u9671\u96a3\u97db", "\ud8eb\udec6",
        28, 32269, -845332242, -2793772192524203719L, -21605L, false, true, (char) 36722, (char) 18891,
        Double.longBitsToDouble(0x3fcb7039355d8be8L), Double.longBitsToDouble(0x3fd28d690555d30eL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.String:r |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 7, 7, 12, "r", "\u51f6\u9213\u6392", "\udb89\udfb7\uc74b\uda33\udecd\udbe0\ude3c\ufd2b\000\ud9f0\ude37\ud8ef\udf3f\ud815\udce2\ud9fc\uddd6\ud830\udf7b\udad3\udf72",
        20, 90948, -1981266544, 4730380852402066997L, 58510L, true, false, (char) 63994, (char) 13000,
        Double.longBitsToDouble(0x3fe7f72881f16103L), Double.longBitsToDouble(0x3fda115128139c58L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.String:E |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 6, 6, 4, "E", "\u9237\u939d\u4862\u2cd6\u7828\u6ddb\u0954\u847c", "\uda00\udf96\uda25\udf9e\uda18\udc6c\uda17\udd91",
        12, 86546, 687307658, -2439482103810491510L, 74036L, true, false, (char) 5171, (char) 37473,
        Double.longBitsToDouble(0x3eb01b28cb380000L), Double.longBitsToDouble(0x3fcdc58c9bfb3674L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:\udb7f\udc85\ud85a\udf97\udbbd\udcf4\udba0\udf75\ud8f0\udd97\uda5b\udf45\ud9a7\uddf3\udbcc\udc33\uda13\udff7\ud843\udcfe\uda17\udccd\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\ud87a\udfc5 |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 8, 8, 13, "\udb7f\udc85\ud85a\udf97\udbbd\udcf4\udba0\udf75\ud8f0\udd97\uda5b\udf45\ud9a7\uddf3\udbcc\udc33\uda13\udff7\ud843\udcfe\uda17\udccd\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\ud87a\udfc5", "\ub9aa\u40a7\u3e02\u32ea\u0e6a\u5fed\uc2ac\u63f5\ucacb\u3f6f", "\udb36\udc28",
        2, 32203, -1201905309, -8433082808180254714L, 31663L, false, false, (char) 38606, (char) 13368,
        Double.longBitsToDouble(0x3fc59ede437953a4L), Double.longBitsToDouble(0x3fdc28d9cfba8afeL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udbd4\udd24\ud85a\udff9\udb85\udf79\ud8d4\udf5c\ud992\udc1c\u897a\udac7\udfa3\ud972\udc1c\udb1e\udc18\udac2\uddd0\uda47\udd57\ud915\udc7c\ud948\udf90\udafb\udfab\uda25\udf9e\udb48\udf80\udbcf\ude8b\ud94d\udea3\uda84\udc51\udaa4\udf3c\ud850\udf61\udaaa\udf4f\ud83d\udce1\ud8c6\udcd0\ud8a2\udfcc\uda84\ude1a\ud8cb\udd65\uda19\uddce\uda56\udc9b\udaab\udf3c\ud9c4\udc31\ud956\udd1a\ud843\udc91\udbfd\udddd\ud890\udc69\udba7\udc7b\udb0a\udcfa\uda66\ude41\udb50\udd23\ud9e1\uddef\ud80d\udcf4\udb07\udf35\ud8e6\uddcf\u941b\ud921\uddaa\uda0e\uddcf\ud9d4\udc5a\ud9a6\ude2f\uda53\ude8b\udaaa\udd85\uda95\udfcf\ud942\udf41\ud8be\udcd4\ud9b1\udd70\udad1\udc67\0121=java.lang.String: |a0=[C:[[\udbd4, \udd24, \ud85a, \udff9, \udb85, \udf79, \ud8d4, \udf5c, \ud992, \udc1c, \u897a, \udac7, \udfa3, \ud972, \udc1c, \udb1e, \udc18, \udac2, \uddd0, \uda47, \udd57, \ud915, \udc7c, \ud948, \udf90, \udafb, \udfab, \uda25, \udf9e, \udb48, \udf80, \udbcf, \ude8b, \ud94d, \udea3, \uda84, \udc51, \udaa4, \udf3c, \ud850, \udf61, \udaaa, \udf4f, \ud83d, \udce1, \ud8c6, \udcd0, \ud8a2, \udfcc, \uda84, \ude1a, \ud8cb, \udd65, \uda19, \uddce, \uda56, \udc9b, \udaab, \udf3c, \ud9c4, \udc31, \ud956, \udd1a, \ud843, \udc91, \udbfd, \udddd, \ud890, \udc69, \udba7, \udc7b, \udb0a, \udcfa, \uda66, \ude41, \udb50, \udd23, \ud9e1, \uddef, \ud80d, \udcf4, \udb07, \udf35, \ud8e6, \uddcf, \u941b, \ud921, \uddaa, \uda0e, \uddcf, \ud9d4, \udc5a, \ud9a6, \ude2f, \uda53, \ude8b, \udaaa, \udd85, \uda95, \udfcf... |this=org.jsoup.parser.CharacterReader:\udbd4\udd24\ud85a\udff9\udb85\udf79\ud8d4\udf5c\ud992\udc1c\u897a\udac7\udfa3\ud972\udc1c\udb1e\udc18\udac2\uddd0\uda47\udd57\ud915\udc7c\ud948\udf90\udafb\udfab\uda25\udf9e\udb48\udf80\udbcf\ude8b\ud94d\udea3\uda84\udc51\udaa4\udf3c\ud850\udf61\udaaa\udf4f\ud83d\udce1\ud8c6\udcd0\ud8a2\udfcc\uda84\ude1a\ud8cb\udd65\uda19\uddce\uda56\udc9b\udaab\udf3c\ud9c4\udc31\ud956\udd1a\ud843\udc91\udbfd\udddd\ud890\udc69\udba7\udc7b\udb0a\udcfa\uda66\ude41\udb50\udd23\ud9e1\uddef\ud80d\udcf4\udb07\udf35\ud8e6\uddcf\u941b\ud921\uddaa\uda0e\uddcf\ud9d4\udc5a\ud9a6\ude2f\uda53\ude8b\udaaa\udd85\uda95\udfcf\ud942\udf41\ud8be\udcd4\ud9b1\udd70\udad1\udc67\012",
        Z.run(T, 2, 0, 10, 8, "\udbd4\udd24\ud85a\udff9\udb85\udf79\ud8d4\udf5c\ud992\udc1c\u897a\udac7\udfa3\ud972\udc1c\udb1e\udc18\udac2\uddd0\uda47\udd57\ud915\udc7c\ud948\udf90\udafb\udfab\uda25\udf9e\udb48\udf80\udbcf\ude8b\ud94d\udea3\uda84\udc51\udaa4\udf3c\ud850\udf61\udaaa\udf4f\ud83d\udce1\ud8c6\udcd0\ud8a2\udfcc\uda84\ude1a\ud8cb\udd65\uda19\uddce\uda56\udc9b\udaab\udf3c\ud9c4\udc31\ud956\udd1a\ud843\udc91\udbfd\udddd\ud890\udc69\udba7\udc7b\udb0a\udcfa\uda66\ude41\udb50\udd23\ud9e1\uddef\ud80d\udcf4\udb07\udf35\ud8e6\uddcf\u941b\ud921\uddaa\uda0e\uddcf\ud9d4\udc5a\ud9a6\ude2f\uda53\ude8b\udaaa\udd85\uda95\udfcf\ud942\udf41\ud8be\udcd4\ud9b1\udd70\udad1\udc67", "\ua997\uafcc\u7644\uaf39", "\udb0c\udf90",
        4, 67682, 1239878100, -1451031918401665643L, 49039L, false, false, (char) 34468, (char) 51960,
        Double.longBitsToDouble(0x3fe84ad527ee3c17L), Double.longBitsToDouble(0x3febb6889590b50eL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\uda91\ude68\udbbd\udcf4\ud923\ude54\ud9cb\ude39\ud83e\ude6b\ud911\udf63\ud921\udc16\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\uda91\ude68\udbbd\udcf4\ud923\ude54\ud9cb\ude39\ud83e\ude6b\ud911\udf63\ud921\udc16\012",
        Z.run(T, 2, 5, 5, 14, "\000\uda91\ude68\udbbd\udcf4\ud923\ude54\ud9cb\ude39\ud83e\ude6b\ud911\udf63\ud921\udc16", "\u945e\u02d3\u1df8", "\ud94a\udd2d\uda1a\ude6b\udb7b\ude4e\ud815\udf45\udaa4\udf9f\u7d6f",
        20, 4135, 2008338957, -6754245208961280800L, -3743L, true, true, (char) 17392, (char) 41449,
        Double.longBitsToDouble(0x3fcd915ed3b4d8d0L), Double.longBitsToDouble(0x3fa2ae4a0c973080L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Character:\uffff |this=org.jsoup.parser.CharacterReader:!toString:java.lang.StringIndexOutOfBoundsException\0121=java.lang.Character:\uffff |this=org.jsoup.parser.CharacterReader:!toString:java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 3, 16, "", "", "\ud8f0\udd0a\udb5b\udcf6\uda7f\ude2e\uda0e\udca6\ud9cf\udcc3\ud991\ude26\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2",
        21, 48966, -2114277376, 8696123790926544935L, -93403L, false, true, (char) 55512, (char) 9014,
        Double.longBitsToDouble(0x3feb28cb38ee2c64L), Double.longBitsToDouble(0x3fe7f66ce939d93aL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[C:[[\u6976, \u7b5f, \u803b, \u4cdc, V, \u263c, \u32a7, \u9cdb]] |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\uda03\udf7a\udba5\udddd\ud80f\uddd1\uda7c\udf38\ud820\ude44\ud8eb\udd06\udb0f\udf6d\ud951\udd61\ud9d3\uded3\uda54\uddc2\ud93a\udd5c\ud911\uddab\uda25\udf9e\ud900\udf6e\udb4a\uddd0\udb69\udcf2\udbb7\udd44\udaa4\udf3c\ud850\udf61\ud832\ude81\uda18\udfd5\udbd2\udd1a\0121=java.lang.String: |a0=[C:[[V, \ud81a, \udd22, \uda03, \udf7a, \udba5, \udddd, \ud80f, \uddd1, \uda7c, \udf38, \ud820, \ude44, \ud8eb, \udd06, \udb0f, \udf6d, \ud951, \udd61, \ud9d3, \uded3, \uda54, \uddc2, \ud93a, \udd5c, \ud911, \uddab, \uda25, \udf9e, \ud900, \udf6e, \udb4a, \uddd0, \udb69, \udcf2, \udbb7, \udd44, \udaa4, \udf3c, \ud850, \udf61, \ud832, \ude81, \uda18, \udfd5, \udbd2, \udd1a]] |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\uda03\udf7a\udba5\udddd\ud80f\uddd1\uda7c\udf38\ud820\ude44\ud8eb\udd06\udb0f\udf6d\ud951\udd61\ud9d3\uded3\uda54\uddc2\ud93a\udd5c\ud911\uddab\uda25\udf9e\ud900\udf6e\udb4a\uddd0\udb69\udcf2\udbb7\udd44\udaa4\udf3c\ud850\udf61\ud832\ude81\uda18\udfd5\udbd2\udd1a\012",
        Z.run(T, 2, 10, 10, 15, "V\ud81a\udd22\uda03\udf7a\udba5\udddd\ud80f\uddd1\uda7c\udf38\ud820\ude44\ud8eb\udd06\udb0f\udf6d\ud951\udd61\ud9d3\uded3\uda54\uddc2\ud93a\udd5c\ud911\uddab\uda25\udf9e\ud900\udf6e\udb4a\uddd0\udb69\udcf2\udbb7\udd44\udaa4\udf3c\ud850\udf61\ud832\ude81\uda18\udfd5\udbd2\udd1a", "\u6976\u7b5f\u803b\u4cdcV\u263c\u32a7\u9cdb", "\udb8c\udfe5\udab2\udec8\ud869\ude6d\udbda\udff7\udbcc\udd8b",
        46, 5861, -1113052299, 1800980412596247441L, 8765L, true, true, (char) 5353, (char) 49810,
        Double.longBitsToDouble(0x3fd0e61364cb7762L), Double.longBitsToDouble(0x3fecc155800d0bd4L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 5, 5, 6, "", "\ubff0\u64ba", "\ud995\udcf3\udbcc\udc33",
        10, 38001, 163, 0L, 80803L, false, true, (char) 5652, (char) 38611,
        Double.longBitsToDouble(0x3fe579b000fc3b7eL), Double.longBitsToDouble(0x3fbf833e406c4a00L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44\012",
        Z.run(T, 2, 8, 8, 9, "\000\ud81a\udc88\u51e6\udbbf\ude51\ud8f0\udd97\ud986\ude42\ud9a6\uddb6\udb1e\udfa1\ud9cf\udd31\ud927\udc23\u8c9f\udb52\ude35\ud81b\udf3a\uda00\udf96\uda25\udf9e\uda05\udc6c\uda17\udd91\udb69\udcf2\udbb7\udd44", "\ua58c\u0e6a\u5fed\uc2ac\u63f5\u6976\u7b5f\u9802\u4536\u390a", "\u57a9\ud83b\udce5\udbb6\udcc4\udb8c\udfe5\ud8e9\uddce\udb73\udcb3\udbda\udfd4\udbcc\udd8b\ud91e\udc13\ud878\udc13\udb37\udf75\ud80b\udf9e\ud8f7\udea1\uda30\udc77\ud93a\uddfa\ud841\ude1b",
        5, 46716, -1147335226, 3075987566786526104L, -79109L, false, false, (char) 0, (char) 24145,
        Double.longBitsToDouble(0x3fd1ad9e15d669acL), Double.longBitsToDouble(0x3fd6ded0a46b8802L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:\ud8bc\udd42\udaff\udcc9\udacd\udee1\ud8b9\ude22\ud8f0\udd97\uda5b\udf45\ud9a7\uddf3\udb84\udf8f\udb78\udf6c\ud9b7\udf97\uda30\udc4e\udb52\ude35\ud81b\udf3a\uda58\udea1\uda25\udf9e\ud878\udfc5\uda17\udd7d\udb69\udcf2\uda84\udc51\udaa4\udf3c\udb1e\udfb4\ud9d1\udef8\u5ffe\udbd2\udd1a\udb0e\ude3f\ud955\udd1a\udb09\udc1e\udb60\udce7\udab4\ude1d\uda5a\udd85\udbb5\udf5b\udb85\udd10\ud9ee\udf34\uda4c\udf15\ud92f\udeb9\ud984\udcbc\udbe2\udd95\udafa\ude5d\ud870\udeac\udbbb\ude3e\udacb\udd28\ud96d\udf3a\ud94d\uddbf\ud82f\udc94\ud8f9\udc55\u2d66\ud9e9\ude87\ud8c5\ude5c\ud8af\udfcd\uda83\udc96\udbaf\udc06\ud898\udc79\uda51\udc6b\ud90e\udd3b\uda59\udea8\uda59\uddf5\uda31\udcf9\ud930\udfa6\ud915\udd1f\ud990\udfa6\ud85b\uddab\ud812\udfd3\ud8a0\udfa4\ud87a\udc28\ud81a\udc58\ud9a4\udff5\ud80a\udea5\uda81\udd17\udb6b\udfc8\ud8bb\udf5d\uda23\udea1\udae3\udecb\uda7c\ude6f\udba5\udcbd\udb94\udcc6 |a0=[C:[[\u8066, \ucf18, \u485f, \u662a, \u0127, \u772f, \u1c29, \u2901, \u9383, \u307a, \u7976, \uc0b1, \u2de1, \ucaa0, \u6a88, \uc1fd, \u7edb, \u4ab3, \u561d, \u256c]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 7, 1, "\ud8bc\udd42\udaff\udcc9\udacd\udee1\ud8b9\ude22\ud8f0\udd97\uda5b\udf45\ud9a7\uddf3\udb84\udf8f\udb78\udf6c\ud9b7\udf97\uda30\udc4e\udb52\ude35\ud81b\udf3a\uda58\udea1\uda25\udf9e\ud878\udfc5\uda17\udd7d\udb69\udcf2\uda84\udc51\udaa4\udf3c\udb1e\udfb4\ud9d1\udef8\u5ffe\udbd2\udd1a\udb0e\ude3f\ud955\udd1a\udb09\udc1e\udb60\udce7\udab4\ude1d\uda5a\udd85\udbb5\udf5b\udb85\udd10\ud9ee\udf34\uda4c\udf15\ud92f\udeb9\ud984\udcbc\udbe2\udd95\udafa\ude5d\ud870\udeac\udbbb\ude3e\udacb\udd28\ud96d\udf3a\ud94d\uddbf\ud82f\udc94\ud8f9\udc55\u2d66\ud9e9\ude87\ud8c5\ude5c\ud8af\udfcd\uda83\udc96\udbaf\udc06\ud898\udc79\uda51\udc6b\ud90e\udd3b\uda59\udea8\uda59\uddf5\uda31\udcf9\ud930\udfa6\ud915\udd1f\ud990\udfa6\ud85b\uddab\ud812\udfd3\ud8a0\udfa4\ud87a\udc28\ud81a\udc58\ud9a4\udff5\ud80a\udea5\uda81\udd17\udb6b\udfc8\ud8bb\udf5d\uda23\udea1\udae3\udecb\uda7c\ude6f\udba5\udcbd\udb94\udcc6", "\u8066\ucf18\u485f\u662a\u0127\u772f\u1c29\u2901\u9383\u307a\u7976\uc0b1\u2de1\ucaa0\u6a88\uc1fd\u7edb\u4ab3\u561d\u256c", "\udbbb\ude8b\uda7f\udd30\ue49a\ud974\udd08\u6be9\ud832\udeed\uda5c\udca3\udbbc\udd09\ud858\udd0c\ud819\udfef\ud80a\udcce\ud845\udd9a\udb5c\udf3c\ud8a9\uddbc\ud9a2\udf84\ud00e\ud773",
        55, 10553, -845296860, 2298225238787808092L, -6752L, false, true, (char) 6053, (char) 64498,
        Double.longBitsToDouble(0x3faf26ee211b1c20L), Double.longBitsToDouble(0x3fe01485b1b7e057L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:\ud8bc\udd42\udaff\udcc9\udacd\udee1\ud8b9\ude22\ud8f0\udd97\uda5b\udf45\ud9a7\uddf3\udb84\udf8f\udaff\udd65\ud9b7\udf97\uda30\udc4e\udb52\ude35\ud81b\udf3a\uda58\udea1\uda25\udf9e\ud878\udfc5\uda17\udd7d\uda27\ude12\udbfa\udd58\udb51\udde4\udb1e\udc84\ud9d1\udef8\u5ffe\udbd2\udd1a\udb0e\ude3f\uda1b\udc6d\uda22\udd68\udb43\udc84\udab4\ude1d\uda5a\udd85\udbb5\udf5b\udb85\udd10\ud9ee\udf34\uda4c\udf15\ud92f\udeb9\ud984\udcbc\udbe2\udd95\udafa\ude5d\ud870\udeac\udbbb\ude3e\udacb\udd28\ud96d\udf3a\ud94d\uddbf\ud82f\udc94\ud8f9\udc55\u2d66\ud9e9\ude87\ud8c5\ude5c\ud8af\udfcd\uda83\udc96\ud867\udc03\ud89a\udd99\uda51\udc6b\ud90e\udd3b\uda59\udea8\uda59\uddf5\udaf1\udcf9\ud930\udfa6\ud915\udd1f\ud990\udfa6\ud85b\uddab\ud812\udfd3\ud8a0\udfa4\ud87a\udc28\ud81a\udc58\ud9a4\udff5\ud80a\udea5\uda81\udd17\udb6b\udfc8\ud8bb\udf5d\uda23\udea1\udae3\udecb\uda7c\ude6f\udba5\udcbd\udb94\udcc6 |a0=[C:[[\ud1d8, \ucf18, \u485f, \u662a, \u0127, \u772f, \u1c29, \u2901, \u9383, \u307a, \u7976, \uc0b1, \u2de1, \ucaa0, \u6a88, \uc1fd, \u7edb, \u4ab3, \u561d, \u256c, \u702e, \ud05f, \u831b, \u15df, \u0c65, \u83d1, \u66a6, \u0ee9, \ub20c, \ubf63, \u3da1, \u4f2b]] |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 1, 10, 2, 7, "\ud8bc\udd42\udaff\udcc9\udacd\udee1\ud8b9\ude22\ud8f0\udd97\uda5b\udf45\ud9a7\uddf3\udb84\udf8f\udaff\udd65\ud9b7\udf97\uda30\udc4e\udb52\ude35\ud81b\udf3a\uda58\udea1\uda25\udf9e\ud878\udfc5\uda17\udd7d\uda27\ude12\udbfa\udd58\udb51\udde4\udb1e\udc84\ud9d1\udef8\u5ffe\udbd2\udd1a\udb0e\ude3f\uda1b\udc6d\uda22\udd68\udb43\udc84\udab4\ude1d\uda5a\udd85\udbb5\udf5b\udb85\udd10\ud9ee\udf34\uda4c\udf15\ud92f\udeb9\ud984\udcbc\udbe2\udd95\udafa\ude5d\ud870\udeac\udbbb\ude3e\udacb\udd28\ud96d\udf3a\ud94d\uddbf\ud82f\udc94\ud8f9\udc55\u2d66\ud9e9\ude87\ud8c5\ude5c\ud8af\udfcd\uda83\udc96\ud867\udc03\ud89a\udd99\uda51\udc6b\ud90e\udd3b\uda59\udea8\uda59\uddf5\udaf1\udcf9\ud930\udfa6\ud915\udd1f\ud990\udfa6\ud85b\uddab\ud812\udfd3\ud8a0\udfa4\ud87a\udc28\ud81a\udc58\ud9a4\udff5\ud80a\udea5\uda81\udd17\udb6b\udfc8\ud8bb\udf5d\uda23\udea1\udae3\udecb\uda7c\ude6f\udba5\udcbd\udb94\udcc6", "\ud1d8\ucf18\u485f\u662a\u0127\u772f\u1c29\u2901\u9383\u307a\u7976\uc0b1\u2de1\ucaa0\u6a88\uc1fd\u7edb\u4ab3\u561d\u256c\u702e\ud05f\u831b\u15df\u0c65\u83d1\u66a6\u0ee9\ub20c\ubf63\u3da1\u4f2b", "\udb5c\udf3c\ud8a9\uddbc\ud9a2\udf84\ud00e\ud773\udb41\ude6d\ud87b\ude50\udb82\udc2b\ud880\udd8f\ud827\udd74",
        36, 97039, -209320019, 1509431278332116224L, 43581L, false, false, (char) 46803, (char) 59616,
        Double.longBitsToDouble(0x3fdb7e0bf0183534L), Double.longBitsToDouble(0x3fdf49de6da27842L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Character:\uffff |this=org.jsoup.parser.CharacterReader:\0121=java.lang.Character:\uffff |this=org.jsoup.parser.CharacterReader:\012",
        Z.run(T, 2, 13, 13, 10, "", "\ua338", "\uda5b\udff4\ud9a7\uddf3\udbcc\udc33\ud9f6\udfe1\udba8\udf01\ud842\udf0c\udb52\uded2",
        -4, 16363, -193830727, 5474298646665167030L, 33293L, false, false, (char) 42354, (char) 35299,
        Double.longBitsToDouble(0x3fe78373420d8960L), Double.longBitsToDouble(0x3fdee51997a21688L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\u00e6\000\000\0121=java.lang.Boolean:false |this=org.jsoup.parser.CharacterReader:V\ud81a\udd22\u00e6\000\000\012",
        Z.run(T, 2, 12, 12, 1, "V\ud81a\udd22\u00e6\000\000", "\u760b", "\ud9d3\ude3e\000",
        -4, 95435, 54631, 4424231379902104572L, 90599L, false, false, (char) 59189, (char) 1546,
        Double.longBitsToDouble(0x3fedf94aba0d8941L), Double.longBitsToDouble(0x3fdc577b41c14488L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.parser.CharacterReader:sr\000\000\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c\0121=java.lang.String:sr |this=org.jsoup.parser.CharacterReader:\000\000\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c\012",
        Z.run(T, 2, 5, 0, 12, "sr\000\000\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c", "\u2b3a", "\u285b\uda4d\ude35",
        -4, 67140, -1675357217, 4008805315445033261L, -981L, true, true, (char) 6280, (char) 57397,
        Double.longBitsToDouble(0x3febb9fb90985793L), Double.longBitsToDouble(0x3fe7779645388143L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.jsoup.parser.CharacterReader:\ud9b9\udf56\uda49\ude93\u00e6\0121=java.lang.Boolean:true |this=org.jsoup.parser.CharacterReader:\ud9b9\udf56\uda49\ude93\u00e6\012",
        Z.run(T, 2, 12, 12, 0, "\ud9b9\udf56\uda49\ude93\u00e6", "", "\udb12\udcbc",
        40, 3914, 856222769, -1691418624L, -45369L, false, true, (char) 55127, (char) 13054,
        Double.longBitsToDouble(0x3fecc5dcfb00e78fL), Double.longBitsToDouble(0x3fc5f2f0e61f9208L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.String:sr |this=org.jsoup.parser.CharacterReader:\000\udab6\ude98\udb05\ude8a\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\ua0da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbff\udce1\udabe\udf2c\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\udab6\ude98\udb05\ude8a\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\ua0da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbff\udce1\udabe\udf2c\012",
        Z.run(T, 2, 7, 0, 12, "sr\000\udab6\ude98\udb05\ude8a\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\ua0da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbff\udce1\udabe\udf2c", "\u2b3a", "\u285b\uda4d\ude35",
        -4, 67140, -1665264673, 4008805315445033261L, -95454L, true, true, (char) 6280, (char) 57397,
        Double.longBitsToDouble(0x3febb9fb90985793L), Double.longBitsToDouble(0x3fe7779645388143L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.String:sr |this=org.jsoup.parser.CharacterReader:\000\000\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\000\000\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c\012",
        Z.run(T, 2, 16, 0, 12, "sr\000\000\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udbfc\udcaf\udb73\udcc7\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udabd\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c", "\u2b3a", "\u285b\uda4d\ude35",
        -4, 67140, -1675357217, 4008805315445033261L, -981L, true, true, (char) 6280, (char) 44342,
        Double.longBitsToDouble(0x3febb9fb90985793L), Double.longBitsToDouble(0x3fe7779645388143L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.String:sr |this=org.jsoup.parser.CharacterReader:\udb8c\udce4\ud21f\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udb7c\udeaa\udbbd\ude54\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udaaf\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c\0121=java.lang.String: |this=org.jsoup.parser.CharacterReader:\udb8c\udce4\ud21f\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udb7c\udeaa\udbbd\ude54\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udaaf\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c\012",
        Z.run(T, 2, 0, 0, 12, "sr\udb8c\udce4\ud21f\000\u6c0d\ud995\udcf3\ue40c\000\ud839\udc05\udb3e\udfcd\u00da\udb7c\udeaa\udbbd\ude54\uda62\udf47\ud87a\udfc5\ud875\udfc1\ud853\udf69\udaaf\ude22\udb7a\udfd6\udb9f\ude62\ud96a\udc05\uda0c\udd4b\ud8a4\udccf\udbe4\udf55\udabe\udf2c", "\u2b3a", "\u285b\uda4d\ude35",
        -4, 67140, -1675357217, 4008805315445033261L, -981L, true, true, (char) 6280, (char) 44336,
        Double.longBitsToDouble(0x3febb9fb90985793L), Double.longBitsToDouble(0x3fdeef2c8a70770cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.CharacterReader|consumeLetterThenDigitSequence||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.Tokeniser|consumeCharacterReference|java.lang.Character,boolean|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.CharacterReader|advance||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consume||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeAsString||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeDigitSequence||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeHexSequence||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeLetterSequence||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeTo|char|new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeTo|java.lang.String|new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeToAny|[C|new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeToEnd||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|containsIgnoreCase|java.lang.String|new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|current||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|isEmpty||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|mark||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.CharacterReader|consumeLetterThenDigitSequence||new:org.jsoup.parser.CharacterReader:java.lang.String",
    "M|org.jsoup.parser.Tokeniser|consumeCharacterReference|java.lang.Character,boolean|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
