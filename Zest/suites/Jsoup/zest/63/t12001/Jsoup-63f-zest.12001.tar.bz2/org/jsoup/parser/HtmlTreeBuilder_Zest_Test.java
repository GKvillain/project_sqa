package org.jsoup.parser;
import org.junit.Test;
import static org.junit.Assert.*;
public class HtmlTreeBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |a0=[I:[[55690, 56563]] |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 17, 19, 1, "\ud9ba\udd23", "\u7bb1\u46e7\u40b4\u5c40\u0e45\uc6b1\uc386\u71f2\u3338\u5481\u6564\u40e8\uab49\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b\u7c58\ubccb\u96e4\u5d23\u9c03\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33717, (char) 60617,
        Double.longBitsToDouble(0x3fe546d584f9716aL), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 21, 14, 1, "\ud9ba\udd23", "\u7bb1\u46e7\u40b4\u5c40\u0e45\uc6b1\uc386\u71f2\u3338\u5481\u6564\u40e8\uab49\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u03be\u86c9\ubc7b\u7c58\ubccb\u96e4\u5d23\u9c03\u2042", "\uda48\udc4e",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 34741, (char) 60617,
        Double.longBitsToDouble(0x3fe546d584f9716aL), Double.longBitsToDouble(0x3fedd7e73d9b3143L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 18, 1, "\ud9ba\udd23", "\u7bb1\u46e7\u40b4\u5c40\u0e45\uc6b1\uc386\u71f2\u3338\uba22\u6564\u40e8\uab49\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\ua7f3\u4924\u607d\u72f7\u8f87\u3456\u86c9\ubc7b\u7c58\ubccb\u96e4\u5d23\u9c03\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33717, (char) 60617,
        Double.longBitsToDouble(0x3fe546d584f9716aL), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 11, 1, "\ud8ca\udccb", "\u7bb1\u46e7\u40b4\u5c40\u4d02\ubf13\uc386\u71f2\u3338\u5481\u6564\u75a6\uaadc\u4ada\ua1ec\ube33\u86f2\u2189\ucdaa\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b\u7c58\ubccb\u96e4\u5d23\u664a\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33717, (char) 52425,
        Double.longBitsToDouble(0x3fe546d294f9716aL), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |a0=[C:[[\ud9ba, \udc95, \ud82d, \udff4, \ud868, \udf76, \udaed, \udc0c, \ud8e5, \udca9, \udab2, \udd93, \ud98a, \udc9f, \udb16, \udd8b, \uda80, \udce4, \udbd6, \udd48, \ud93e, \udf3c]] |this=org.jsoup.parser.Tokeniser:@?\0121=void |a0=[I:[[55690, 56421, 55293, 57284, 55352, 57158, 55997, 56284]] |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 2, 19, 19, "\ud9ba\udc95\ud82d\udff4\ud868\udf76\udaed\udc0c\ud8e5\udca9\udab2\udd93\ud98a\udc9f\udb16\udd8b\uda80\udce4\udbd6\udd48\ud93e\udf3c", "\u6564\u40e8\u7c02\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubfd1", "\ud871\udd20\udac7\udc1e\ud949\udd4f\udb64\udfe5\ud8c6\ude24\ud9b8\ude61\udb8d\udd8a",
        -3, 93469, -757249798, 5915655296753977885L, -76342L, false, false, (char) 33717, (char) 60617,
        Double.longBitsToDouble(0x3fe546d584f9716aL), Double.longBitsToDouble(0x3fe5d7e73bf94856L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |a0=[I:[[17503]] |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 17, 19, 1, "\u448f", "\u7bb1\u46e7\uc767\u5c40\u30f0\uc620\uc386\u71f2\u3338\u5481\u6564\u40e8\uab49\u4ada\ua1ec\ube33\u86f2\u57c2\u8311R\ud7b8\uc1f4\u4924\u857d\u72f7P\u85d3\u86c9\ubc7b\u7c58\ubccb\u96e4\u5d23\u9c03\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33717, (char) 4509,
        Double.longBitsToDouble(0x3fe5400004f9716aL), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=[I:[[55690, 56563]] |this=org.jsoup.parser.Tokeniser:@?\0121=void |a0=[I:[[55690, 56563]] |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 19, 19, 1, "\ud9ba\udd23", "\u7bb1\u46e7\u40b4\u5c40\u0e45\uc6b1\uc386\u71f2\uc36a\u1010\u364f\u0bfb\uaad3\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b\u7c58\ubccb\u96e4\u5e07\u9c03\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33717, (char) 60617,
        Double.longBitsToDouble(0x3fe95ed584f9716aL), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 7, 15, "\ud9ba\udd23\ud82d\udff4\ud868\udf76\udaed\udc0c\ud8e5\udca9\udafd\udc58", "\uc6b1\uc386\u71f2\u3338\u5481\u6564\u40e8\uab49\u4ada\u4e99\u7dff\u8772", "\ud84f\udcea\uda6b\udd4f\ua5bc\ud955\udf39\uda13\ude19\udb16\udfad\uda7e\udc6d\uda73\udc70\ud8e4\udfea\ud868\ude61\ud869\udc16\u5690\ud871\udd20\udac7\udc1e\ud949\udd4f\udb64\udfe5",
        -2, 5453, 350182480, -6736911574342462099L, 13122L, false, false, (char) 37702, (char) 33717,
        Double.longBitsToDouble(0x3fe9688ce8a8dab0L), Double.longBitsToDouble(0x3fcf331b5d31939cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 19, 1, "\ud9ba\udd23\ud82d\udff4\ud868\udf76\udaed\udc0c\ud8e5\udca9", "\u0e45\uc6b1\uc386", "\udbe7\ude36\udb32\udcb5\ud9e7\ude8f\udace\udc8c\ud98f\udcd1\udb23\udc6e\ud908\udc8d",
        21, 41206, 615798673, -9055194785761162485L, 56449L, true, false, (char) 55977, (char) 5858,
        Double.longBitsToDouble(0x3fe41787f88077aaL), Double.longBitsToDouble(0x3fe0f16e6ce9199fL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |a0=[I:[[55690, 56427]] |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 13, 19, 1, "\ud9ba\udc9b", "\u7bb1\u46e7\uc169\u9c4e\u2646\uc6b1\u78dc\ud3c7\u4a92\u5481\u18e6\u83d0\u0a90\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\u8900\u1ef3\u4924\u857d\u72f7\u62ca\u0249\u7e04\ub95d\u7c58\ubccb\u96e4\u5d23\u145c\u3959", "\udb8d\udd8a\ud9e6\udd1b\ud974\udd04\ud801\ude51\ud994\udd9c\uda1a\udc3d\uda0a\ude6f\uda45\udf60\ud9f3\ude4a\udade\uded4\ud852\udcfa\udafb\udf60\ud80e\ude6d\u3f45",
        3, 56679, -677194544, 1342792474368563450L, -70339L, true, true, (char) 63377, (char) 48433,
        Double.longBitsToDouble(0x3feba42ecb3827a9L), Double.longBitsToDouble(0x3fdf046f7ad935c6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 10, 12, "\ud9ba\udd23", "\u7bb1\u46e7\u40b4\u5c40\u0e45\uc6b1\uaf02\u71f2\u3338\u5481\u6564\u40e8\uab49\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\u5a66\uc151\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b\u7c58\ubccb\u96e4\u5d23\u9c03\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33646, (char) 60617,
        Double.longBitsToDouble(0x3fe546d584f9716aL), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 19, 1, "\uda5a\udeb7", "\u36a7\u46e7\u40b4\ud2ae\u0da5\uc6b1\uc386\uc6fb\u3338\u3a8b\ub121\u06dd\uab49\u5b97\u1233\ub837\ua49d\u8391\u4966\u8fd7\ub5d6\uc18d\uaaea\u857d\u72f7\u0f22\u4900\u86c9\u7985\u5fba\u7032\u96e4\ud0fb\u2c2a\u2042", "\ud912\udcfa\ud9a7\ude1e\ud994\udff3\ud801\ude51\ud864\ude24\uda1a\udc3d\uda0a\ude6f\uda45\udf60",
        58, 1835, 2099448172, 8172584656926362873L, 94235L, true, true, (char) 40330, (char) 35604,
        Double.longBitsToDouble(0x3f826d7de4983000L), Double.longBitsToDouble(0x3fe09e3d98ff9966L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 21, 18, "\000", "", "",
        59, -994, -1495947277, 6513150165899686949L, -100000L, false, false, (char) 44248, (char) 51864,
        Double.longBitsToDouble(0x3fc81359e002daf8L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 17, 17, 1, "\ud9ba\udd23", "\u7bb1\u46e7\u40b4\u5c40\u0e45\u8ad7\uc386\u71f2\u3338\u5481\u075f\u3ea0\u9eeb\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b\u7c58\ubccb\u96e4\u5d23\u9c03\u2042", "\udb8d\udd8a\ud9e6\udd1b\ud995\udc04\ud801\ude51\ud864\ude24\uda1a\udc3d",
        2, 50050, 1508547582, 1269216621217504045L, 63003L, true, false, (char) 19090, (char) 560,
        Double.longBitsToDouble(0x3faef476debac240L), Double.longBitsToDouble(0x3fe515a154b37826L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 9, 4, "\ud9ba\udd23", "\u38cc\uaccd\u40b4\u3dbb\u805e\u8253\ud395\u77f2\u3338\u5481\u6564\u40e8\u9c96\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\u58cd\uc1a2\u4924\u857d\u7222\u9004\u3456\u86c9\ubc7b\u7c58\uc80d\ud4f0\u5d23\u9c03\u2042", "\udb8d\udd8a",
        -3, 54365, -981184208, -7560391767413513809L, -76487L, false, false, (char) 1973, (char) 20073,
        Double.longBitsToDouble(0x3fef6ed427c5573eL), Double.longBitsToDouble(0x3fd89c010114c8e0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 13, 20, 1, "\ud979\ude28", "\u7bb1\u46e7\u40b4\u5c40\u0e45\uc6b1\uc386\u71f2\u3338\u5b52\u6564\u40e8\uab49\u4ada\ua1ec\u9d34\u86f2\u7069\u8311\u3f61\ud7c3\u1983\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b\u7c58\ubccb\u96e4\u5d23\u9c03\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33717, (char) 62086,
        Double.longBitsToDouble(0x3fe5a0491b1463faL), Double.longBitsToDouble(0x3fe5d48713458176L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 1, "\ud9ba\udd23", "\u7bb1\u46e7", "\udb26\udeb1\uda80\udce4\udbd6\udd48",
        25, 89147, -859649732, 6953350041337123702L, -40573L, false, false, (char) 62160, (char) 6022,
        Double.longBitsToDouble(0x3fe9daf96f7314e0L), Double.longBitsToDouble(0x3fea7ceef526b983L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 9, 18, "\ud9ba\udd23\ud82d\udff4\ud868\udf76\udaed\udc0c", "\u5c40\u0e45\u7619", "\udb01\udcfb\udbe7\ude36\udb32\udcb5\ud9e7\ude8f\udace\udc8c\ud98f\udcd1\udb23\udc6e\ud908\udc8d\ud940\udf40\ud934\udc8a\udb0b\udf11\ud84f\udcea\uda6b\udd4f\ud85a\udcb2",
        29, 1413, 227734241, 6084091860567136069L, -81340L, true, false, (char) 47492, (char) 58368,
        Double.longBitsToDouble(0x3fd1716e01755754L), Double.longBitsToDouble(0x3fef3e30374f43ccL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |a0=[I:[[55732, 56744]] |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 19, 14, 4, "\ud9e4\uddd8", "\u7bb1\u46e7\u40b4\u5c40\u0e45\uc6b1\uc386\u71f2\u2bfd\ua3e9\u65f6\u4166\uab49\u4ada\u55a6\ua83a\u9c4b\u57c2\u8311\u06574", "\u1a54\udb16\udfad",
        8, 86258, 768469120, 1846218690115548393L, 99737L, true, true, (char) 9317, (char) 24045,
        Double.longBitsToDouble(0x3fea7a1e62053012L), Double.longBitsToDouble(0x3fb4018834f0a6f8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 18, "\ud9ba\udd23", "\ub335\u46e7\u3011\u32a1\u0e45\uc6b1\u9ed6\ub1fe\ucd62\u5481\u6564\u40e8\uab49\u4ada\u5ac0\u7b7a\u925f\u5060\u439f\u1aa1\ud7c3\uc1f4\u4924\ua8c6\ud6d9", "\udb3a\udfd2\uda09\udebc\ud869\udc16",
        26, 40223, -1414864617, -4177518862942824473L, -35995L, false, false, (char) 4858, (char) 57079,
        Double.longBitsToDouble(0x3fe6a740c9358c81L), Double.longBitsToDouble(0x3fe6d448c1e260adL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 19, 1, "\000", "\u7bb1", "\udbc3\udf20\udb26\udeb1\uda80\udce4\ud995\udc28\ud93e\udf3c\udb01\udcfb\udbe7\ude36\udb32\udcb5\ud9e7\ude8f\udace\udc8c\ud98f\udcd1\udb23\udc6e\000\ud940\udf40\ud910\udc97\udaea\uddba\ud84f\udcea\uda6b\udd4f\ud9ce\udecd\000\000\udada\udccc\uda7e\udc6d\ud93f\udd8f\u8333\uda0b\udfa0\ud869\udc16\u5690\ud871\udd20\ue917\udbe9\udc94\000",
        -2, -1000, 0, -6736912252544641683L, -52414L, false, false, (char) 0, (char) 33717,
        Double.longBitsToDouble(0x3fe9688ceea8dab0L), Double.longBitsToDouble(0x3fcf2e2d5aebf39cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 7, 7, "\ud9ba\udd23\ud82d\udff4\ud868\udf76\udaed\udc0c\ud8e5\udca9\udb75\uddf3\ud818\udcef\udb26\udeb1\uda80\udce4\udbd6\udd48\ud93e\udf3c\udb01\udcfb\udbe7\ude36\udb32\udcb5\ud9e7\ude8f", "\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b\u7c58\ubccb\u96e4\u0b09\u9c03\u2042\ua709\u8fa1\ud50c\ubfce\u5919\u3b7b\u0d10\u8520\u7500", "\ud80f\udc6c\ud867\udde3\ucd57\ud8f7\udcca\u3f45\ud94a\udf99\ud94d\udd20\udbd6\udce6\udb61\udf17",
        54, 60771, 657260247, -3151643837527554199L, 62405L, true, false, (char) 34556, (char) 52289,
        Double.longBitsToDouble(0x3fe814c6b690e86eL), Double.longBitsToDouble(0x3fe8414e0c395263L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud9ba\udd23", "\u7bb1\u46e7\u9ca7\ub241\u0e45\uc6b1\uc386\u71f2\u42a0\u7921\u6564\u40e8\uab49\u4ada\ua1ec\ub46c\u52d5\ud1b3\u451a\u3f61\ud7c3\uc1f4\u4924\u857d\uca04\u99c7\u346b\u7e23\ubb43\u7c58\ubccb\u96e4\u5d23\u191a\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33717, (char) 60617,
        Double.longBitsToDouble(0x3fe546d584f90b72L), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jsoup.parser.ParseSettings:@? |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 6, 1, "\ud8fd\uddea", "\u7c29\u46e7\u40b4\u5c40\u0e45\uc6b1\uc386\u71f2\u3338", "\ud9e7\ude8f\ud8cd\udc13\ud98f\udcd1",
        15, 63326, -64107687, 4553258924625909649L, 93249L, false, true, (char) 30593, (char) 24618,
        Double.longBitsToDouble(0x3fe0f16e6ce91999L), Double.longBitsToDouble(0x3febf79033c7f039L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 17, 17, 7, "\ud9ba\udd23\ud856\udd48\ud868\udf76\udaed\udc0c\ud8e5\udca9\udaea\udd50\udbc3\udf20\udbbf\ude5c\ud84a\udfd3\udbd6\udd48\ud93e\udf3c", "\u7564\u18b6\uaac2\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b", "\ud871\udd20\udac7\udc1e\ud949\udd4f\udb64\udfe5\ud8c6\ude24\ud9b8\ude61\udb8d\udd8a\ud9e6\udd1b\ud995\udc04\ud801\ude51",
        44, 42315, 157399522, 3623247512064385278L, -43891L, false, false, (char) 48739, (char) 60321,
        Double.longBitsToDouble(0x3fea2c0bb189ba87L), Double.longBitsToDouble(0x3fe24a06994100feL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\0121=java.lang.Boolean:false |this=org.jsoup.parser.HtmlTreeBuilder:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 15, 1, "\ud9ba\udd23", "\u7bb1\ud6a2\u40b4\u5c40\u0e45\uc6b1\ucd4d\u6051\u4e87\uc56e\u3791\u6262\u9322\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u5a6e\u9782\ubd1f\u7c58\ubccb\u96e4\u5d23\u9c03\u2042", "\uda48\udc4e",
        -3, 93469, -757249798, -8567921104866482037L, -76342L, false, false, (char) 34741, (char) 60572,
        Double.longBitsToDouble(0x3fe526d584f9716aL), Double.longBitsToDouble(0x3fedd7e73d9b3143L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |a0=[C:[[\udb87, \udf1a]] |this=org.jsoup.parser.Tokeniser:@?\0121=void |a0=[C:[[\udb87, \udf1a]] |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 18, 18, 1, "\udb87\udf1a", "\u7bb1\u46e7\u40b4\u9935\u0e45\uc6b1\uc386\u71f2\u3338\uba22\u885a\u7ed6\uab30\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\ua7f3\u1c23\u607d\u72f7\u8f87\u3456\uc863\ubc7b\u7c58\ua7cb\u96e4\u5d23\u9c03\u2042", "\ud934\udc5e",
        50, 93469, 803883258, -800842293330421820L, -76342L, false, false, (char) 33717, (char) 60617,
        Double.longBitsToDouble(0x3feb3e7d84f9716aL), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=void |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 4, 20, 7, "\ud9ba\udc95\ud82d\udff4\ud868\udf76\udaed\udc0c\ud8e5\udca9\udb34\uddd3\ud98a\udcd2\uda39\udf5d\uda91\udda8\udbd6\udd48\ud93e\udf3c", "\uc15a", "\ud98f\udcd1\udb23\udc6e\ud908\udc8d",
        19, 48886, 615798673, -9055194785761162485L, 5695L, false, true, (char) 55235, (char) 5858,
        Double.longBitsToDouble(0x3fc41e9fe201dea8L), Double.longBitsToDouble(0x3fe0f16e6e5715caL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |a0=[I:[[55690, 56421, 55293, 57284, 51917, 55557, 56302, 56074]] |this=org.jsoup.parser.Tokeniser:@?\0121=void |a0=[I:[[55690, 56421, 55293, 57284, 51917, 55557, 56302, 56074]] |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 3, 19, 19, "\ud9ba\udc95\ud82d\udff4\ucafd\ud935\udc1e\udb3a\udfb3\udb83\udd7f\ud98a\udc9f\udb16\udd8b\uda80\udce4\udaf4\udef0\uda16\udc2c", "\u3348\uce24\u66f6\u4ada\ua1ec\ube33\u7698\u579e\u8311\u3f61\ud7c3\uc1f4\u0f7d\u85c5\u08e5\u8f48\u3456\u38c9\ubfd1", "\ud8ef\udc1c\ud865\udf82\ud935\udc17\udb93\udebf\udb6e\udda1\udaed\udc9f\udb8d\udd8a",
        -3, 93469, -757249798, 5915655296753977885L, -76342L, false, false, (char) 33717, (char) 60617,
        Double.longBitsToDouble(0x3fe28545818e26ecL), Double.longBitsToDouble(0x3fc8d1badd19bcf8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.jsoup.parser.Tokeniser:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 9, 20, "\ud9ba\udd23", "\u7bb1\u46e7\u40b4\u5c40\u0e45\uc6b1\uc386\u71f2\u3338\u698a\u0443\u9307\uaafb\u4ada\ua1ec\ube33\u86f2\u57c2\u8311\u3f61\ud7c3\uc1f4\u4924\u857d\u72f7\u8f87\u3456\u86c9\ubc7b\u699f\u3979\u9f7c\u5d23\u9c03\u2042", "\udb8d\udd8a",
        -3, 93469, -757249798, -8567921104869537141L, -76342L, false, false, (char) 33717, (char) 60617,
        Double.longBitsToDouble(0x3fe546d584f9716aL), Double.longBitsToDouble(0x3fe5d7e73b458176L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a0=[I:[[55629, 56280, 55666, 56360, 55312, 57266, 55997, 56404]] |this=org.jsoup.parser.Tokeniser:@?\0121=void |a0=[C:[[\ud97d, \udc08, \ud9a2, \udc58, \ud840, \udfe2, \udaed, \udc84, \ud8e5, \udca9, \ud835, \udc54, \udbc3, \udf20, \udb26, \udeb1, \uda80, \udce4, \udbd6, \udd48, \ud93e, \udf3c, \ud899, \ude47, \u782f, \ud92e, \udf4c, \ud9b9, \udfee, \ud8cd, \udc13, \ud98f, \udcd1, \udaa2, \ude2d, \ud894, \udd77, \ud9f2, \udcee, \ud910, \udc97, \ud824, \uddf7, \ud8ef, \udce7, \uda6b, \udd4f, \udbce, \udfcd, \ud9d6, \udf10, \ud9aa, \udc08, \uda5b, \udf7b, \uda88, \udcbc, \ud93f, \uddb6, \u8333, \ud88b, \udfa0, \ud869, \udc16, \ud82c, \ude28, \u08e4, \udb87, \udde1, \uda2d, \uddee, \udbcc, \udd62, \udafa, \ude6d, \udbce, \udec5, \uda4b, \udf42, \ud9bb, \ude58, \udbfb, \ude69, \ud870, \udede, \ud856, \udcdb, \ud9ca, \udd41, \ud8ee, \udd31, \ud953, \udd63, \ud81f, \udfdc, \udbe6, \udeab, \udb99, \udf0e, \udaf8... |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 3, 2, 9, "\ud97d\udc08\ud9a2\udc58\ud840\udfe2\udaed\udc84\ud8e5\udca9\ud835\udc54\udbc3\udf20\udb26\udeb1\uda80\udce4\udbd6\udd48\ud93e\udf3c\ud899\ude47\u782f\ud92e\udf4c\ud9b9\udfee\ud8cd\udc13\ud98f\udcd1\udaa2\ude2d\ud894\udd77\ud9f2\udcee\ud910\udc97\ud824\uddf7\ud8ef\udce7\uda6b\udd4f\udbce\udfcd\ud9d6\udf10\ud9aa\udc08\uda5b\udf7b\uda88\udcbc\ud93f\uddb6\u8333\ud88b\udfa0\ud869\udc16\ud82c\ude28\u08e4\udb87\udde1\uda2d\uddee\udbcc\udd62\udafa\ude6d\udbce\udec5\uda4b\udf42\ud9bb\ude58\udbfb\ude69\ud870\udede\ud856\udcdb\ud9ca\udd41\ud8ee\udd31\ud953\udd63\ud81f\udfdc\udbe6\udeab\udb99\udf0e\udaf8\udf0c\udbf0\udc18\udac6\udeda\ud96d\ude2a\uda0c\udc7b\uda43\udc8c\ud934\udd8e", "\uaede\u9437\u1889\ua65d", "\udbce\ude99\udb9d\udd49\ud85d\udecc\uda26\udfca\ud939\uddec\udbc3\udf85\uda5a\uddde\uda74\udd44\ud904\udfee\udaaa\ude01\ua4f6",
        42, 79543, -1814135863, -8925191563925819941L, 59839L, false, false, (char) 64845, (char) 51138,
        Double.longBitsToDouble(0x3fdc5e8cdd07cf56L), Double.longBitsToDouble(0x3fe1b904ceeecdf2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |a0=[C:[[\ud918, \udf75, \ud9a2, \udc58, \ud840, \udfe2, \udaed, \udc84, \ud8e5, \udca9, \ud835, \udc54, \udbc3, \udf20, \udb26, \udeb1, \uda80, \udce4, \udbd6, \udd48, \ud93e, \udf3c, \ud899, \ude47, \u782f, \ud92e, \udf4c, \ud9b9, \udfee, \ud8cd, \udc13, \ud98f, \udcd1, \uda6e, \uded3, \ud894, \udd66, \ud9f2, \udcee, \ud910, \udc97, \ud824, \uddf7, \ud8ef, \udce7, \uda6b, \udd4f, \udbce, \udfcd, \ud9d6, \udf10, \ud9aa, \udc08, \uda5b, \udf7b, \uda88, \udcbc, \ud90e, \udebe, \ud963, \uddf6, \ud88b, \udfb6, \ud869, \udc16, \ud82c, \ude28, \u08e4, \udb87, \udde1, \uda2d, \uddee, \udbcc, \udd62, \udae3, \udd85, \udbce, \udec5, \uda4b, \udf42, \ud9bb, \ude58, \udbfb, \ude69, \ud870, \udede, \ud856, \udcdb, \ud9ca, \udd41, \ud8ee, \udd31, \ud953, \udd63, \ud81f, \udfdc, \udbe6, \udeab, \udb99, \udf0e... |this=org.jsoup.parser.Tokeniser:@?\0121=void |a0=[C:[[\ud918, \udf75, \ud9a2, \udc58, \ud840, \udfe2, \udaed, \udc84, \ud8e5, \udca9, \ud835, \udc54, \udbc3, \udf20, \udb26, \udeb1, \uda80, \udce4, \udbd6, \udd48, \ud93e, \udf3c, \ud899, \ude47, \u782f, \ud92e, \udf4c, \ud9b9, \udfee, \ud8cd, \udc13, \ud98f, \udcd1, \uda6e, \uded3, \ud894, \udd66, \ud9f2, \udcee, \ud910, \udc97, \ud824, \uddf7, \ud8ef, \udce7, \uda6b, \udd4f, \udbce, \udfcd, \ud9d6, \udf10, \ud9aa, \udc08, \uda5b, \udf7b, \uda88, \udcbc, \ud90e, \udebe, \ud963, \uddf6, \ud88b, \udfb6, \ud869, \udc16, \ud82c, \ude28, \u08e4, \udb87, \udde1, \uda2d, \uddee, \udbcc, \udd62, \udae3, \udd85, \udbce, \udec5, \uda4b, \udf42, \ud9bb, \ude58, \udbfb, \ude69, \ud870, \udede, \ud856, \udcdb, \ud9ca, \udd41, \ud8ee, \udd31, \ud953, \udd63, \ud81f, \udfdc, \udbe6, \udeab, \udb99, \udf0e... |this=org.jsoup.parser.Tokeniser:@?\012",
        Z.run(T, 2, 18, 2, 9, "\ud918\udf75\ud9a2\udc58\ud840\udfe2\udaed\udc84\ud8e5\udca9\ud835\udc54\udbc3\udf20\udb26\udeb1\uda80\udce4\udbd6\udd48\ud93e\udf3c\ud899\ude47\u782f\ud92e\udf4c\ud9b9\udfee\ud8cd\udc13\ud98f\udcd1\uda6e\uded3\ud894\udd66\ud9f2\udcee\ud910\udc97\ud824\uddf7\ud8ef\udce7\uda6b\udd4f\udbce\udfcd\ud9d6\udf10\ud9aa\udc08\uda5b\udf7b\uda88\udcbc\ud90e\udebe\ud963\uddf6\ud88b\udfb6\ud869\udc16\ud82c\ude28\u08e4\udb87\udde1\uda2d\uddee\udbcc\udd62\udae3\udd85\udbce\udec5\uda4b\udf42\ud9bb\ude58\udbfb\ude69\ud870\udede\ud856\udcdb\ud9ca\udd41\ud8ee\udd31\ud953\udd63\ud81f\udfdc\udbe6\udeab\udb99\udf0e\udaf8\udf0c\udbf0\udc18\udac6\udeda\ud820\udce5\uda0c\udc7b\uda43\udc8c\ud934\udd8e", "\uaede\u9437\u1889\ua65d", "\udbce\ude99\udb9d\udd49\ud85d\udecc\uda26\udfca\ud939\uddec\udbc3\udf85\uda5a\uddde\uda74\udd44\ud9c2\udfed\udaaa\ude01\ua4f6",
        42, 79543, -1814135863, -8925191563925819941L, 59839L, false, false, (char) 64845, (char) 21442,
        Double.longBitsToDouble(0x3fdc555e3c0bcf56L), Double.longBitsToDouble(0x3fe9b9e29aeecdf2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.parser.HtmlTreeBuilder|insertEmpty|org.jsoup.parser.Token$StartTag|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.Tokeniser|emit|char|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|emit|[C|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|emit|[I|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|emit|java.lang.String|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|emit|org.jsoup.parser.Token|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|read||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.HtmlTreeBuilder|aboveOnStack|org.jsoup.nodes.Element|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearFormattingElementsToLastMarker||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToContext|[Ljava.lang.String;|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableBodyContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|clearStackToTableRowContext||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|defaultSettings||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|error|org.jsoup.parser.HtmlTreeBuilderState|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|framesetOk||new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.HtmlTreeBuilder|insertEmpty|org.jsoup.parser.Token$StartTag|new:org.jsoup.parser.HtmlTreeBuilder:",
    "M|org.jsoup.parser.Tokeniser|emit|char|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|emit|[C|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|emit|[I|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|emit|java.lang.String|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|emit|org.jsoup.parser.Token|new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
    "M|org.jsoup.parser.Tokeniser|read||new:org.jsoup.parser.Tokeniser:org.jsoup.parser.CharacterReader,org.jsoup.parser.ParseErrorList",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
