package org.jsoup.nodes;
import org.junit.Test;
import static org.junit.Assert.*;
public class Document_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 2, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbe7\udd6d\ud897\udf72\ud918\ude80", "\u3337", "\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\uda1b\udd26\ud9df\udd92\ud88c\ude96\udbe8\udfa1",
        14, 18787, -956403044, -8903230586457650253L, -71759L, false, true, (char) 28466, (char) 21295,
        Double.longBitsToDouble(0x3fcdf1f26d005594L), Double.longBitsToDouble(0x3fde28b97d21be84L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 2, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbe7\udd6d\ud897\udf72\ud918\ude80", "\u3337", "\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\uda1b\udd26\ud9df\udd92\ud88c\ude96\udbe8\udfa1",
        14, 18787, -968742500, -8903230586080643873L, -71759L, false, true, (char) 28466, (char) 21295,
        Double.longBitsToDouble(0x3fcdf1f26d005594L), Double.longBitsToDouble(0x3fde28b97d21be84L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 1, 12, 14, 2, "\uda77\udf92\ud948\udcec\ud9ab\udec0\udbe7\udd6d\ud897\udf72\ud97a\udd78", "\u3337", "\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\uda1b\udd26\udb5e\ude10\uda24\udd16\ud9f6\udcee",
        24, 18787, -956403044, -8903230586457650253L, 14928L, false, true, (char) 28466, (char) 3011,
        Double.longBitsToDouble(0x3fcdf1f26fe1f594L), Double.longBitsToDouble(0x3fde28b97d21be84L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\012",
        Z.run(T, 1, 0, 13, 2, "\uda77\udf92\udba2\udecf\udb87\udc1e\udbe7\udd6d\ud897\udf72\ud918\ude80", "\u33a3", "\ud972\udeaa",
        49, 63582, -2115948784, 3178984303745040326L, -21992L, true, false, (char) 22520, (char) 19526,
        Double.longBitsToDouble(0x3fe7a3319bb38471L), Double.longBitsToDouble(0x3fb8f566f0398eb8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Element:!toString:java.lang.NullPointerException |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 1, 3, 14, 2, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbe7\udd6d\ud897\udf72\ud918\ude80", "\u3337", "\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\uda1b\udd26\ud9df\udd92\ud88c\ude96\udbe8\udfa1",
        14, 18787, -956403044, -8903230584259785799L, -71759L, false, true, (char) 28466, (char) 21295,
        Double.longBitsToDouble(0x3fcdf1f26d005594L), Double.longBitsToDouble(0x3fde28b97d21be84L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 15, 6, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbe5\udc6d\ud897\udf72\ud918\ude80", "\u35ac\u7c92\u5cbd\ubb08\u2caf\u8c3f\u6f05\u8b61\u25da\u4f48\u9ecb\u9910\u6687\u870b\u2483", "\ud80a\udd48\uda7f\ude10\ud91c\udf04",
        3, 38135, -1952988352, -2359057303842371952L, 53176L, false, false, (char) 29933, (char) 797,
        Double.longBitsToDouble(0x3fca121fb027d3bcL), Double.longBitsToDouble(0x3fefc6946b4d3951L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 4, 9, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbe7\udd6d\ud83d\udfcd\ud918\ude80", "\u3337", "\udaf8\udd09\uda48\udee7\ud9c8\udfe8\ud939\udcb9\uda1b\udd26\ud9df\udd92\udb8b\udf27\udbb8\udc1e",
        10, 18787, -956403044, -8903230586457650253L, -71759L, false, true, (char) 28466, (char) 21295,
        Double.longBitsToDouble(0x3fe77c7c9b401565L), Double.longBitsToDouble(0x3fde28b97127abeeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 1, 10, 14, 2, "\udb7e\udd48\ud948\udcec", "\u426f\u7aaa\u1c84\u85e5", "\uda49\udc82\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\uda1b\udd26",
        40, 8867, 1238814536, 5274588516944621923L, -10156L, true, true, (char) 63606, (char) 40371,
        Double.longBitsToDouble(0x3fb473c16f8d0c88L), Double.longBitsToDouble(0x3fdc0fd1f9df1f26L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 1, 6, 15, 2, "\uda77\udf92\ud9ba\udf6d\udb87\udc1e\udbe7\udd6d\ud897\udf72\ud96e\udfe4", "\u3337", "\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\uda1b\udd26\ud9df\udd92\ud88c\ude96\udbe8\udfa1",
        14, 75147, -956403044, -8903230586457650253L, 32258L, true, true, (char) 28466, (char) 21295,
        Double.longBitsToDouble(0x3fcdf1f26d005594L), Double.longBitsToDouble(0x3fde28b97d21be84L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Document:\012",
        Z.run(T, 1, 14, 9, 2, "\uda45\udcad\ud948\udd78\udbab\udd1e\udbe7\udd6d\ud938\ude07\uda8a\ude0c", "\u31e6\u0ceb\u5d74\ubb08\u2caf\u256e\u6195\u8b61\u25da\u1141\u9ecb\u9910\u1f6b\u1e1a\uc1c3\u666c\ua599\u763b", "\ud910\udd53\ud9f6\udf66\uda6a\udcf4\ud91e\udee9\udaac\uddfc\udb1b\uddb3\uda4a\udc1f\udb10\udee1\ud89a\udc21\ud954\udd38",
        6, 88896, -2131585149, -141405753184808324L, 39553L, false, false, (char) 15406, (char) 47875,
        Double.longBitsToDouble(0x3fcf1e4240defaecL), Double.longBitsToDouble(0x3feccf708f606093L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\012",
        Z.run(T, 1, 4, 14, 2, "\uda77\udf92\ud948\udcec\udbb4\udd1e\udbe7\udd6d\ud897\udf72\ud918\ude80", "\u3337", "\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\uda1b\udd26\udb15\udc3b\ud91a\uddfa\udbbc\udd07",
        32, 18787, -958238052, -8903230586457650253L, -71759L, false, true, (char) 40696, (char) 42743,
        Double.longBitsToDouble(0x3fcdf1f26d00dc2cL), Double.longBitsToDouble(0x3fde28b97d21be84L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 9, "\udbd5\ude6b", "\uaa98\u0682\u7aaa\u1c84\u0b86\u3a84\u7cb1", "\ud893\udcac\ud833\udf18\ud8ed\udfa1\ud83e\udc99\ud9df\udd92",
        3, 73112, 1228085839, 1285409781451991452L, 83073L, false, true, (char) 44211, (char) 22070,
        Double.longBitsToDouble(0x3fdf1a141a20ac3eL), Double.longBitsToDouble(0x3fcdf1f26d005594L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 14, 2, "\uda77\udf92\ud948\udcec\ud9ab\udec0\udae7\udf6c\ud897\udf72\ud95c\udf78\udbb0\uddd9", "\u67d5\u5cfc\u7db1\u2caf\u256e\u6195\u8b61\u991d\u09d0\u4ede\u048d\u888d\ua460\u2478\u666c\u735c\u5fa6\u5b47\u7bee\u8e77\u398e\u7a00\u9b14\u812f\u2225", "\ud868\udd78\uda96\udcc5\ud9e0\udc07\uda10\udf5a\ud959\udd93\ud911\ude85\ud86d\udf88\ud837\udfff\uda89\udcaf",
        42, 84974, -50186246, -8840527550690679423L, -21016L, true, false, (char) 49171, (char) 12296,
        Double.longBitsToDouble(0x3fd27ad1872f7d28L), Double.longBitsToDouble(0x3fe50288ff293264L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Document:\0121=new org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 12, 14, 2, "\uda77\udf92\ud948\udcec\ud9ab\udec0\udbe7\udd6d\ud897\udf72\ud97a\udd78", "\u331d", "\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\uda1b\udd26\udb5e\ude10\uda24\udd16\ud9f6\udcee",
        24, 18787, -614829412, -8903230736781505613L, 14928L, false, true, (char) 28466, (char) 3011,
        Double.longBitsToDouble(0x3fcdf1f26fe1f594L), Double.longBitsToDouble(0x3fde28b97d21be84L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 2, "\uda77\udf92\ud948\udcec\ud9ab\udec0\udbe7\udd6d\ud8b8\udf72\ud97a\udd78", "\u3337", "\ud946\udcfd\ud893\udcac\ud84e\udca4\ud88b\udded\uda48\udde5\udb51\udfe7\uda24\udd16\ud9f6\udcee",
        24, 18787, -956403044, -8903230586457650253L, 14928L, false, true, (char) 28466, (char) 60610,
        Double.longBitsToDouble(0x3fcec24d8fe1f594L), Double.longBitsToDouble(0x3fe6d296a5dcf771L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.jsoup.nodes.Document:\0121=null |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 2, 6, 3, "\udb43\udc90\ud815\udffa\u57a3\ud93f\udd8c\uda3f\ude26\ud918\ude80\ud81b\udea8\ud9af\udf9e\uda6c\udf3f\ud943\ude9c\ud9e6\udd4c", "\uc712\u6dbf", "\udb1b\ude5a\ud8ec\udd4b\udafe\udc75\ud8ff\udf17\ud933\udd02",
        25, 9320, -1579713544, 5921228585705682735L, 59128L, false, true, (char) 2337, (char) 1080,
        Double.longBitsToDouble(0x3fec6a79d7141b6aL), Double.longBitsToDouble(0x3fe17e7155a8f053L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012 <head>\012  <title>&#55913;&#57098;&#55918;&#56341;&#56199;&#56359;\u6d68</title>\012 </head>\012 <body></body>\012</html>\012",
        Z.run(T, 2, 0, 13, 2, "\uda69\udf0a\uda6e\udc15\udb87\udc27\u6d68", "\u1c84\u85e5\u33a3\u410f\u2485\u84a2\u0ac6\u253c\u6195\u1a98", "\udbf2\ude87\udb5a\udfd8\udb1c\ude63\ud931\ude3d\udba1\udfff\ud9a4\udd6d\udba7\udf52\ud88f\udcff",
        50, 46590, -1845364191, 7098318712997431675L, 96011L, true, false, (char) 11074, (char) 35665,
        Double.longBitsToDouble(0x3fd9fec0b5bb8d66L), Double.longBitsToDouble(0x3fc00d93f8ea8bb8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Document:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 2, "\u84c6\ud95c\udd07\udb87\udc1e\udbe7\udd6d\ud897\udf72\ud918\ude80", "\u33a3", "\ud972\udeaa",
        49, 63582, -2115948784, 3178984303745040326L, -21961L, true, false, (char) 22520, (char) 3655,
        Double.longBitsToDouble(0x3fe2029048852071L), Double.longBitsToDouble(0x3fda7f8cec0e63aeL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Element:\012<head></head> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\012",
        Z.run(T, 2, 0, 6, 2, "\uda77\udf92\udba2\udecf\udac5\udc1d\udbe7\udd6d\udb15\udf4c\ud948\udd04", "\u33a3\u2593", "\ud849\udea6\uda5b\udc2c",
        12, 62784, -499911904, -3156309488213504184L, 35227L, true, true, (char) 61976, (char) 13453,
        Double.longBitsToDouble(0x3fe989305d72026aL), Double.longBitsToDouble(0x3fec5945329ac82aL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Element:!toString:java.lang.NullPointerException |this=org.jsoup.nodes.Document:\0121=new org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 3, 14, 2, "\uda77\udf92\ud948\udcec\ud919\ude52\uda9a\udc65\udb91\ude7a\ud968\ude53", "\u7ec4", "\ud937\udd8b\udbce\udd48\ud80d\udf7e\uda56\udcb4\ud875\udfdd\ud9d3\udc8d\ud88c\ude96",
        31, 29261, 555084121, -4107771530728874252L, 32203L, false, false, (char) 47779, (char) 28466,
        Double.longBitsToDouble(0x3fd10561d9df1f26L), Double.longBitsToDouble(0x3fb005594d438b48L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 14, 2, "\udaa5\ude68\000\000\u8a0b\ud897\udf72\ud918\ude80", "\000", "",
        35, 34679, -1216480418, -9087930827276337310L, 60412L, false, false, (char) 53290, (char) 29752,
        Double.longBitsToDouble(0x3fe289f203a6aa90L), Double.longBitsToDouble(0x3fdf1a141a20ac3eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\012",
        Z.run(T, 2, 0, 15, 6, "\ud910\udd84\ud98e\udfc3\udacf\udfad\ud92b\udcca\ud897\udf72\ud918\ude80\uda26\udd0f\uda9c\udc8a\ud8c9\uddb5\uda13\udc35\uda3e\udc16\ud946\udcfd\ud893\udcac\ub895\ud8f1\udd11\uda69\uddce\ud900\uddfd\uda89\udfc3\udbe2\udc6f", "\u9e49\uba7c\u666c\u1f9a", "\ud91c\udf04\udb87\ude74\udb39\ude31\udb37\udc63\ud821\udff4\udb61\udf78\udb85\udd4e\ud955\udddd\udb7d\udf0f\ud9a9\ude4a",
        -1, 11608, -762463223, 4130218639972836173L, -45707L, true, true, (char) 60994, (char) 32448,
        Double.longBitsToDouble(0x3fce3859493c5ee8L), Double.longBitsToDouble(0x3fe6352fca630a34L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\012",
        Z.run(T, 2, 12, 4, 9, "\uda0a\udc5a\ud948\udcec\udb87\udc1e\udbe7\udd6d\ud83d\udfcd\ud918\ude80", "\u3337", "\udaf8\udd09\uda48\udee7\ud9c8\udfe8\ud90e\uddae\uda15\udd60\ud9df\udd77\udb8b\udf27\udbb8\udc1e",
        48, 18787, -184651108, 4509534881139699580L, -71759L, false, true, (char) 65006, (char) 21295,
        Double.longBitsToDouble(0x3fe77c7c9b40156dL), Double.longBitsToDouble(0x3fde28b97127abeeL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\012",
        Z.run(T, 2, 4, 4, 9, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbe7\udd6d\ud83d\udfcd\ud9f9\udc74", "\u3337", "\udaf8\udd09\uda48\udee7\ud9c8\udfe8\ud939\udcb9\ud85e\udea9\ud9df\udd92\udb8b\udf27\udbb8\udc1e",
        10, 18787, -956403044, -8903230586457650253L, -71759L, false, true, (char) 28466, (char) 21295,
        Double.longBitsToDouble(0x3fe77c7c9b401565L), Double.longBitsToDouble(0x3fde28b97127abeeL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 8, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbe7\udd6d\ud83d\udfcd\ud918\ude80\udbb0\uddd9\ud80c\uddd1", "\u4f89\u4b69\ub120\uba78\u4e3d\u9c1a", "\udbb8\udc1e\ud9ea\udfb8\ud848\ude70",
        -4, 79092, -187921485, 4495159405315124817L, -87185L, false, true, (char) 22146, (char) 55460,
        Double.longBitsToDouble(0x3fde28b97127abeeL), Double.longBitsToDouble(0x3fd29d18122c3970L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 2, "\uda77\udf92\ud948\udcec\ud9ab\udec0\udbe7\udd6d\ud897\udf72\ud97a\udd78", "\u331d", "\ud946\udcfd\ud893\udcac\ud833\udf18\ud8ed\udfa1\udae0\udfe9\ud919\udd3c\ud9de\udf60\ud9f6\udcee",
        24, 18787, -614829412, -8903230736781505613L, 14928L, false, true, (char) 28466, (char) 3011,
        Double.longBitsToDouble(0x3fcdf1f26fe1f594L), Double.longBitsToDouble(0x3fde28b97d21be84L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=void |this=org.jsoup.nodes.Document:<html>\012 <head>\012  <title>&#56145;&#56339;&#55917;&#57293;&#56228;&#56342;\u6d94&#55778;&#56536;&#55588;&#56874;&#56050;&#56873;&#55308;&#56785;&#55855;&#56728;&#56060;&#57291;&#55560;&#56880;&#55500;&#56757;&#55728;&#56841;&#55347;&#57062;&#55533;&#57249;&#55610;&#56542;</title>\012 </head>\012 <body></body>\012</...\012",
        Z.run(T, 2, 0, 13, 2, "\udb51\udc13\uda6d\udfcd\udba4\udc16\u6d94\ud9e2\udcd8\ud924\ude2a\udaf2\ude29\ud80c\uddd1\uda2f\udd98\udafc\udfcb\ud908\ude30\ud8cc\uddb5\ud9b0\ude09\ud833\udee6\ud8ed\udfa1\ud93a\udcde", "\uc5b1\ubaef\u9740\u2c7e\u2aa9\u81ae\u2775\u8a31", "\uda46\udfa5\ud97c\ude15\uda03\ude93\udbc4\udfe9",
        6, 1140, -774580117, -1437851710453977697L, 81376L, false, false, (char) 16083, (char) 5033,
        Double.longBitsToDouble(0x3fec5c3132af025fL), Double.longBitsToDouble(0x3fd72117b1b639e4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55913;&#57098;&#55918;&#56341;&#56086;&#57176;\u6d68\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55913;&#57098;&#55918;&#56341;&#56086;&#57176;\u6d68\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\uda69\udf0a\uda6e\udc15\udb16\udf58\u6d68", "\u987e\u85e5\u33a3\u336d\ub026\u84a2\u0ac6\u253c\u6195\u1a98", "\ud875\udff6\u14cc\udb1c\ude63\ud931\ude3d\uda94\udd0b\ud955\udf08\udba7\udf52\ud88f\udcff",
        50, 26414, -1823498476, 7098488179522029947L, 96011L, true, false, (char) 11074, (char) 35665,
        Double.longBitsToDouble(0x3fd9fec0b5bb8d66L), Double.longBitsToDouble(0x3fc00d93f8ea8bb8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Document$OutputSettings:@? |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 10, 10, 2, "\uda69\udf0a\uda6e\udc15\udb87\udc27\u6d68", "\ua430\u1d19\u33a3\u410f\u2485\u84a2\u0ac6\u253c\u6195\u1a98", "\udbf2\ude87\u9b20\udb52\udccc\ud89a\udcb6\udba1\udfff\ud9a4\udd6d\udba7\udf52\ud88f\udcff\ud87d\udf8b",
        18, 15520, 1605544678, -3551007290800761350L, -81949L, true, true, (char) 27024, (char) 39711,
        Double.longBitsToDouble(0x3fe1d623b9424647L), Double.longBitsToDouble(0x3fef0d6abebf197cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Element:!toString:java.lang.NullPointerException |this=org.jsoup.nodes.Document:\0121=org.jsoup.nodes.Element:!toString:java.lang.NullPointerException |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 3, 3, 6, "\uda77\udf92\ud8cc\udcee\u7f54\ud918\ude4f\udb91\ude7a\ud968\ude53", "\u7ec4", "\ud937\udd8b\udbce\udd48\ud893\udf20\udaa7\udeac\ud9ca\udf12\ud9d3\udc8d\ud88c\ude96",
        31, 29261, 555084121, -1938443885219848460L, 32203L, false, false, (char) 47779, (char) 28466,
        Double.longBitsToDouble(0x3fd10561d9df1f26L), Double.longBitsToDouble(0x3fb005594d438b48L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55568;&#56708;&#55694;&#57283;&#56015;&#57261;&#55763;&#57246;&#55651;&#57140;&#55864;&#56431;&#55594;&#56515;&#55964;&#56458;&#55497;&#56757;&#55827;&#56373;&#56314;&#56340;&#55622;&#56573;&#55443;&#56492;&#55939;&#57216;&#55375;&#56395;&#55913;&#56782;&#55668;&#56... |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55568;&#56708;&#55694;&#57283;&#56015;&#57261;&#55763;&#57246;&#55651;&#57140;&#55864;&#56431;&#55594;&#56515;&#55964;&#56458;&#55497;&#56757;&#55827;&#56373;&#56314;&#56340;&#55622;&#56573;&#55443;&#56492;&#55939;&#57216;&#55375;&#56395;&#55913;&#56782;&#55668;&#56...\012",
        Z.run(T, 2, 0, 11, 6, "\ud910\udd84\ud98e\udfc3\udacf\udfad\ud9d3\udf9e\ud963\udf34\uda38\udc6f\ud92a\udcc3\uda9c\udc8a\ud8c9\uddb5\uda13\udc35\udbfa\udc14\ud946\udcfd\ud893\udcac\uda83\udf80\ud84f\udc4b\uda69\uddce\ud974\uddf7\uda89\udfc3\uda92\udc67", "\uc7f2\ud413\u666c\u1f9a", "\ud964\udf84\ud975\udda9\udb39\ude31\udb37\udc63\ud821\udff4\ud8ac\ude9c\ud810\uddfa\ud958\ude78\ud970\udcc0\ud936\udc92",
        1, 76261, -762463223, 4130218639972836173L, -45707L, true, true, (char) 60994, (char) 20160,
        Double.longBitsToDouble(0x3fce3859521fd318L), Double.longBitsToDouble(0x3fe6352e32630a34L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55568;&#56708;\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55568;&#56708;\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 4, "\ud910\udd84", "\u97c3", "\uda26\udd0f\uda9c\udc8a\ud8c9\uddb5\uda13\udc35\uda3e\udc16\udb78\udcf6\ud893\udcac\ub895\ud8f1\udd11\uda69\uddce",
        -1, 18003, 1238807574, 5274588515485004133L, 33907L, true, true, (char) 19063, (char) 44211,
        Double.longBitsToDouble(0x3fecb55485f12026L), Double.longBitsToDouble(0x3fd10561f9df1fceL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55927;&#57234;&#55624;&#56556;&#56199;&#56350;&#56295;&#56685;&#55357;&#57293;&#55576;&#56960;&#56240;&#56793;&#55826;&#57173;\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55927;&#57234;&#55624;&#56556;&#56199;&#56350;&#56295;&#56685;&#55357;&#57293;&#55576;&#56960;&#56240;&#56793;&#55826;&#57173;\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 8, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbe7\udd6d\ud83d\udfcd\ud918\ude80\udbb0\uddd9\uda12\udf55", "\u4f89\u4b69\ub120\uba78\u4e3d\u9c1a", "\udbb7\udf59",
        10, 18787, -956403044, -8903230586457650253L, -71759L, false, true, (char) 28466, (char) 21295,
        Double.longBitsToDouble(0x3fe77c7c9b401565L), Double.longBitsToDouble(0x3fde28b97127abeeL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55855;&#56815;&#55918;&#56341;&#56086;&#57081;\u6d68&#55778;&#56536;&#55864;&#57306;&#56217;&#56788;\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55855;&#56815;&#55918;&#56341;&#56086;&#57081;\u6d68&#55778;&#56536;&#55864;&#57306;&#56217;&#56788;\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\uda2f\uddef\uda6e\udc15\udb16\udef9\u6d68\ud9e2\udcd8\uda38\udfda\udb99\uddd4", "\u336d\ub026\u69f8\ub03c\u253c\u6195\u3627\ud37e", "\u14cc\udb1c\ude63\ud91c\udc3d\uda94\udd0b\ud955\udf08\udba7\udf52\ud88f\udcff\ud831\udc8d",
        44, 55524, 1652745572, -3551007514139060742L, -81949L, true, true, (char) 27024, (char) 12575,
        Double.longBitsToDouble(0x3fe1d517761235a0L), Double.longBitsToDouble(0x3fe5a9528aa8715aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  \000\000\000\u8a0b\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  \000\000\000\u8a0b\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 0, "\000\000\000\u8a0b", "\u987e\u3353\u871c\u336d\ub026\u84a2\u0ac6\u232d\000\000", "\udabb\udf1d",
        30, -1000, 1999865600, 141688487898196355L, -100000L, false, false, (char) 51886, (char) 8328,
        Double.longBitsToDouble(0x3eb3c00000000000L), Double.longBitsToDouble(0x3fdfaceb84abb9feL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  \u77e5\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  \u77e5\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\u77e5", "\u2ccb\u0da1\u9bd8\u987e\u85e5\u33a3\u336d\ub026\u84a2\u76be\uc044\u624b\u1a98\u7d0b\u0130\uaf8c\ub4cf\u9801\u2c7e\u8342\u97a7\u2775\ua6c7\u91cd\u168e\ucf72\ua5ee\ua712\u0c7e\u607c\u5b1e\uc6b2\u89d6", "\udbb7\udf03\ud8e4\udfdb\udbb1\udcf3\ud942\udcfb\udbbe\udf35\uda9c\udf9b\ud893\udeb2\udacb\udde4\ud995\uddea\ud81a\udc6c\ucfcb",
        29, 21361, 1840668318, -7631148303072076821L, 73338L, false, false, (char) 42371, (char) 25300,
        Double.longBitsToDouble(0x3fcf0d2ff9740f18L), Double.longBitsToDouble(0x3fb8c88663d7a788L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#56174;&#56470;&#55918;&#56341;&#56086;&#57176; \012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#56174;&#56470;&#55918;&#56341;&#56086;&#57176; \012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\udb6e\udc96\uda6e\udc15\udb16\udf58\013", "\u987e", "\udb9e\ude5d\udbd1\ude24\ud8cc\uddb5\ud9b0\ude09\ud833\udee6\ud8ed\udfa1\ud93a\udcde\uac11",
        39, 50450, 596071092, -4247107902190155977L, 89796L, true, true, (char) 25778, (char) 57172,
        Double.longBitsToDouble(0x3fcde76621ad4b5cL), Double.longBitsToDouble(0x3fd7dd1d4b3fd816L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "", "\u8d48\u5269\u6800\000\u7632\u85e5\u33a3\u336d\u4481\u84a2\u32c5\u253c\u6195", "\udba0\uddcb\ud875\udff6\u14cc\udb1c\ude63\ud931\ude3d\uda94\udd0b\ud955\udf08\udba0\udf52\ud88f\udcff\u7223\000\000\ud9cf\uddc6\uda03\ude93\ud805\ude09\udbfb\uddd1\ud82d\udcd5\uda10\udc77",
        21, 30247, 221, -6706422795799525830L, -10422L, false, false, (char) 25667, (char) 12619,
        Double.longBitsToDouble(0x3fe757eac9c82f88L), Double.longBitsToDouble(0x3fdd5876663901d0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55779;&#57140;&#56226;&#56782;&#56276;&#56981;&#55575;&#57253;&#55916;&#56663;&#56114;&#57121;&#55537;&#57001;&#56248;&#57160;&#55771;&#56718;&#56222;&#56925;&#56273;&#56868;&#55500;&#56757;&#55728;&#56841;&#55347;&#57062;&#55533;&#57249;&#55955;&#57211;\ubeb2&#56224;&#5... |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#55779;&#57140;&#56226;&#56782;&#56276;&#56981;&#55575;&#57253;&#55916;&#56663;&#56114;&#57121;&#55537;&#57001;&#56248;&#57160;&#55771;&#56718;&#56222;&#56925;&#56273;&#56868;&#55500;&#56757;&#55728;&#56841;&#55347;&#57062;&#55533;&#57249;&#55955;&#57211;\ubeb2&#56224;&#5...\012",
        Z.run(T, 2, 0, 11, 11, "\ud9e3\udf34\udba2\uddce\udbd4\ude95\ud917\udfa5\uda6c\udd57\udb32\udf21\ud8f1\udea9\udbb8\udf48\ud9db\udd8e\udb9e\ude5d\udbd1\ude24\ud8cc\uddb5\ud9b0\ude09\ud833\udee6\ud8ed\udfa1\uda93\udf7b\ubeb2\udba0\uddcb\ud875\udff6\ud91d\uded8\ud902\uddb5\ud89d\udc44\ud936\ude77\ud985\udda9\udaad\ude93\ud8e9\udd12\udad7\udc38\udae0\uddf8\ud8d8\udca5\ud93b\udf39\uda03\ude93\udbc4\udfe9\udbfb\uddd1\udb2d\uddd0\ud9c5\uddb2\udbd4\udc4f\ud8f0\udcd8\udaf8\udce3\udbb7\udf03\udbb2\udc21\ud852\udf6f\ud844\udd89\ud83e\udf71\ud804\udfb9\udaa4\udc2a\ud9f9\udee6\ud93b\udd2b\ud9dd\udcc4\udbea\udd58\udb25\udcb4\u3cf5\udb01\udd29\u8275\udb8c\udc7d\uda07\udd00", "\ub06d", "\ud87e\udfe0\ud8ba\udc5c\uba08\ud9ad\udd31\udb06\udf41\ud98a\udec0\uda89\udd33\ud82d\ude77\ud8ec\ude07\uda4b\udf8e\udb56\udcfa\ufba7",
        32, 38882, -2082403277, -3828082230146024412L, 4358L, true, true, (char) 61374, (char) 30066,
        Double.longBitsToDouble(0x3fe4bb728854c7bbL), Double.longBitsToDouble(0x3fbdf47bd4003128L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  \000\000\000 \012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  \000\000\000 \012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\000\000\000\013", "\u987e", "\udb9e\ude5d\udbd1\ude24\ud8cc\uddb5\uda70\udc48\ud800\udf2c\ud8ed\udfa1\ud93a\udcde\uac11",
        39, 50450, 596071092, 4290146047592247L, -99900L, true, true, (char) 25778, (char) 57172,
        Double.longBitsToDouble(0x3fcde76621ad4b5cL), Double.longBitsToDouble(0x3fd7dd1d4b3fd816L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 3, 5, "", "\ua77b", "\000\ud885\udfa6\ud80c\udde0",
        4, 59742, -1409286128, -2883697871023308729L, 84560L, false, true, (char) 49764, (char) 19701,
        Double.longBitsToDouble(0x3fc99be70ad3c6e8L), Double.longBitsToDouble(0x3fd402387e6f8a1eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.jsoup.nodes.Document:\0121=java.lang.String: |this=org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 12, 12, 5, "", "\u8d48\u5269\u6800\000\u7632\u85e5\u33a3\u336d\u4481\u84a2\u32c5\u253c\u6195", "\uda8a\udf5e\ud875\udff6\udac9\udd2d\udb1c\ude63\ud931\ude3d\uda94\udd0b\ud955\udf08\udba0\udf52\ud89b\ude87\u7223\000\000\ud9cf\uddc6\uda03\ude93\udb0e\udf44\udbfb\udd83\ud82d\udcd5\uda10\udc77",
        21, 30247, 221, -6706422795799525830L, -8397L, false, false, (char) 27863, (char) 12431,
        Double.longBitsToDouble(0x3fe757eac9c82f88L), Double.longBitsToDouble(0x3fe4ac3b371ca04bL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  \000\000\000\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  \000\000\000\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 2, "\000\000\000", "\u9bd8", "\udaf3\udc53",
        5, 60976, -1210643272, 7768105484876588L, 29694L, false, false, (char) 19701, (char) 23306,
        Double.longBitsToDouble(0x3fe5a78b6ddd2387L), Double.longBitsToDouble(0x3fe9b80078ee7733L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 14, 2, "\uda77\udf92\ud948\udcec\udb87\udc1e\udbd3\udca0\uda14\udf71\ud918\ude80\udbb0\uddd9\ud80c\uddd1\ud8eb\udfc7\udb76\udc90", "\ud528\uc2e7\u61c2\u8b61\u3a98\u1141\u9ecb\u9910", "\udbc5\udfab\udbb0\udef8\udbe7\udc57\ud814\udfdb\uda7f\ude10\ud91c\udf04",
        3, 38135, -1952988352, -2359057301846604144L, -70443L, false, false, (char) 23800, (char) 58643,
        Double.longBitsToDouble(0x3fec2b5c87dbdecdL), Double.longBitsToDouble(0x3fe2f3e77add992cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.jsoup.nodes.Document:\0121=new org.jsoup.nodes.Document:\012",
        Z.run(T, 2, 14, 14, 3, "\uda69\udf0a\uda6e\udc15\udb87\udc27\u6d68", "\u331f\u35e6\u33a3\uc985\u2509\u2721\u0900\u25be\u6195\ua94a\u057d\u4eaa\uc5b1", "\ud931\ude3d\udaa8\udde2\udbcf\udeb2\udba7\udf52\udb45\udf5b\ud8cf\udf77\uda6e\udfc2",
        24, 86059, -826763717, 131426799114584697L, -44597L, true, true, (char) 55722, (char) 27024,
        Double.longBitsToDouble(0x3fc00d93f8ea8bb8L), Double.longBitsToDouble(0x3fecfbdf5bdcf54eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &yen;\000\000 \012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &yen;\000\000 \012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\u00a5\000\000\013", "\u987e", "\udb9e\ude5d\udbd1\ude24\ud8cc\uddb5\uda70\udc48\ud800\udf2c\ud8ed\udfa1\ud93a\udcde\uac11",
        39, 50450, 596071092, 4290146047592247L, -99900L, true, true, (char) 25778, (char) 57172,
        Double.longBitsToDouble(0x3fe055d18f76b89cL), Double.longBitsToDouble(0x3fd81e51fb3fd816L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &yen;\000\000\000\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &yen;\000\000\000\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\u00a5\000\000\000", "\u987e", "\udb9e\ude5d\udbd1\ude24\ud8cc\uddb5\uda70\udc48\ud800\udf2c\ud8ed\udfa1\u0562\ud9a5\udd11",
        39, 50450, 21172, 4222126650525495L, -100000L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb9000000000000L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\037\000", "\u5a6e", "\ud80c\uddd1",
        4, 13145, -1400134896, -2883697869244878777L, -22416L, false, true, (char) 49764, (char) 19701,
        Double.longBitsToDouble(0x3fca55470ad3c5b4L), Double.longBitsToDouble(0x3fddd2387e6e001eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body> \012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body> \012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 12, "\037", "\u2f40", "\ud8da\udf92\ud80c\uddd1\uda2f\udd98\udb9e\ude5d\udbf1\uddb4\ud8d5\ude69\uda70\udc48\ud847\udd38\ud8ed\udfa1\ud93a\udcde\uac11\udba0\uddcb\ud875\udff6",
        27, 88877, -258003024, -658661661165409269L, -8101L, true, true, (char) 30824, (char) 30011,
        Double.longBitsToDouble(0x3fd845184bdcb9e2L), Double.longBitsToDouble(0x3fe070a4f57119ecL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, " \000", "\u5a6e", "\ud80c\uddd1",
        4, 13145, -1400134896, -2883697869244878777L, -22416L, false, true, (char) 49764, (char) 19701,
        Double.longBitsToDouble(0x3fca55470ad3c5b4L), Double.longBitsToDouble(0x3fddd2387e6e001eL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#56174;&#56587;&#55918;&#56341;&#56115;&#57159;&#55373;&#57072;&#56109;&#57252;&#56204;&#57211;&#56281;&#56862;&#55308;&#56785;&#55855;&#56728;&#55470;&#56640;&#55516;&#56702;&#55500;&#56757;&#55981;&#57248;&#55347;&#57062;&#55533;&#57249;&#56317;&#56503;&#55586;&#57... |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012  &#56174;&#56587;&#55918;&#56341;&#56115;&#57159;&#55373;&#57072;&#56109;&#57252;&#56204;&#57211;&#56281;&#56862;&#55308;&#56785;&#55855;&#56728;&#55470;&#56640;&#55516;&#56702;&#55500;&#56757;&#55981;&#57248;&#55347;&#57062;&#55533;&#57249;&#56317;&#56503;&#55586;&#57...\012",
        Z.run(T, 2, 0, 11, 10, "\udb6e\udd0b\uda6e\udc15\udb33\udf47\ud84d\udef0\udb2d\udfa4\udb8c\udf7b\udbd9\ude1e\ud80c\uddd1\uda2f\udd98\ud8ae\udd40\ud8dc\udd7e\ud8cc\uddb5\udaad\udfa0\ud833\udee6\ud8ed\udfa1\udbfd\udcb7\ud922\udee0\udba0\udd0c\ud875\udff6\u1450\udb1c\ude63\uda82\udc27\udae5\ude51\ud852\udfa1\ud89e\udf27\udb02\udcb7\udbf6\udcf0\ud966\udc99\udb69\ude6d\ud898\udf40\ud9de\udd8f\ud849\udf2c\udbfb\ude50\udb2d\uddd0\ud9c5\uddb2\udbd4\udc4f\udbb4\udc3a\ud850\udd96\ud923\ude1f\uda52\ude71\udb66\ude4d\uda83\ude61\ud9e5\udc8b\udbd4\ude32\udb25\ude56\ud8c0\ude13\udbc7\udf8d\uda04\udd38\ud86b\udf8f\udaf6\uddec\uda2a\udf5f\udab9\udce3\u714d\ud861\udd19\udb64\ude4c\ud90b\udea3\ud973\udda8\ud884\udc0a\ud8e8\ude2a\udbce\udc6e\uda11\udc85\uda8a\udcb6\ud8bb\uddc2\ud9e4\udd80\ud83f\uddeb\udb6d\udf33\u7fc5\udb4c\udd3e", "\u882d\u04ae\ua5c2\ua675\u4d06\u0fb4\u0405\u23e2\u20ff\u778c\uc321\uae13\u4735\u9387\uc3cf\u51ba\u7b6c\u6eea\u6151\u8755", "\udb6b\udcca\ud9ee\udf95\ud9d8\udee7\ud90f\udcfd\uda33\udd53\udbd0\udf48",
        34, 15684, -1931288638, -6196331617265140776L, -82180L, true, false, (char) 3977, (char) 2839,
        Double.longBitsToDouble(0x3fd01b2ed726093cL), Double.longBitsToDouble(0x3fe85e36668ee0d1L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000 &#55689;&#57039;&#55648;&#57103;&#55659;&#56430;\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000 &#55689;&#57039;&#55648;&#57103;&#55659;&#56430;\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, " \000\036\ud989\udecf\ud960\udf0f\ud96b\udc6e", "\u33a3\u336d\ub026\u84a2\ub067\uae1f\u6195\u1a98\u7d0b\u0130\uaf8c\ub4cf\u0def\ucf20\uab8f\u61a4\u0117\uc6ef\u6639\ud13d\u59fd\ud651", "\ud930\udd63\ud8d4\udfcc\udae5\udc45\ud8e3\udde4\udb15\ude05\udb4e\udc82\ud965\udfd3\udab5\udf8f",
        3, 15623, -163679254, 8301025339681930979L, -14915L, true, true, (char) 34306, (char) 21443,
        Double.longBitsToDouble(0x3fc6acdf52d44540L), Double.longBitsToDouble(0x3fdfb169173c1f46L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000\000 \000\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000\000 \000\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\015\000\000\013\000", "\u85e5\u33a3\u336d\ub026\u84a2\ub067", "\ud93a\udcde",
        -4, 40634, -244469550, 2560105846232006109L, -89604L, true, false, (char) 31873, (char) 40926,
        Double.longBitsToDouble(0x3fe11bb218aea138L), Double.longBitsToDouble(0x3e09000000000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000&#55574;&#56785;&#55382;&#57020;&#55671;&#56408;&#56084;&#56804;&#55633;&#57123;&#55851;&#56334;&#56172;&#56925;&#55648;&#56393;\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   \000&#55574;&#56785;&#55382;&#57020;&#55671;&#56408;&#56084;&#56804;&#55633;&#57123;&#55851;&#56334;&#56172;&#56925;&#55648;&#56393;\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\037\012\000\ud916\uddd1\ud856\udebc\ud977\udc58\udb14\udde4\ud951\udf23\uda2b\udc0e\udb6c\ude5d\ud960\udc49", "\u7a22\u6195\ud24c\u7cea\u0130\uaf8c\ub4cfQ\u76c8\u2f3f\u2620\u9521\u7908\u2510\u80e2\ua229\ub499\u7cd8\u79c4\u4cf7\uce1b\u4cb1\ub150\u94e5\u13d1\u4424\ucf91\u9b52\u8785\u1932\u462f\u26b1\u2bea\u7393\uc335\u0fe6\u0d9d\u1635\u6dec\u47f0\u8ef2\u578f\u9a68\u392a\uaa60\u4811\ub83d\ub94c\u03f5\u6751\ub415\u4529\u9d94", "\udbd0\udcaf\uda15\udf51\udaf1\udca7\udbf1\udcbc\ud821\udfef\uda66\uddc0\uda49\udc7f",
        -1, 4644, 2000830185, -5398918538175260902L, 83888L, false, true, (char) 43872, (char) 42245,
        Double.longBitsToDouble(0x3fa51a289538ae70L), Double.longBitsToDouble(0x3febd58f85e66afdL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 14, 2, "\uda77\udf92\ud948\udd78\udb87\udc1e\udbe7\udd6d\ud897\udf72", "\u114f", "\ud823\udee8\ud9e7\udd0d\ud893\udcac\udb44\udda0\ud907\ude92\uda1b\udd26\ud9df\udd92\ud88c\ude96\udbe8\udfa1\ud81c\udf11\uda08\udcf4\udb50\ude6b\uda22\ude99\u42ed",
        28, 15849, -1589531738, 6205905244624518416L, -93719L, false, true, (char) 6301, (char) 45724,
        Double.longBitsToDouble(0x3fb53a6ee85ece20L), Double.longBitsToDouble(0x3feba487b2b0d259L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body></body>\012</html>\0121=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   &#55574;&#56785;&#55382;&#57020;&#55671;&#56408;&#56084;&#56804;&#55633;&#57123;&#55851;&#56334;&#56172;&#56925;&#55648;&#56393;\012 </body>\012</html> |this=org.jsoup.nodes.Document:<html>\012 <head></head>\012 <body>\012   &#55574;&#56785;&#55382;&#57020;&#55671;&#56408;&#56084;&#56804;&#55633;&#57123;&#55851;&#56334;&#56172;&#56925;&#55648;&#56393;\012 </body>\012</html>\012",
        Z.run(T, 2, 0, 11, 5, "\037\012 \ud916\uddd1\ud856\udebc\ud977\udc58\udb14\udde4\ud951\udf23\uda2b\udc0e\udb6c\ude5d\ud960\udc49", "\u7a22\u6195\ud24c\u7cea\u0130\u5e5f\u876aQ\u76c8\u2f3f\u2620\u9521\u7908\u2510\u80e2\ua229\ub499\u7cd8\u79c4\u4cf7\uce1b\u8aa2\ub174\u94e5\u8fa3\u4b6c\ucf91\u9b52\u8785\u1932\u462f\u26b1\u2bea\uccc2\ubfba\u0fe6\u0d9d\u1635\u6dec\u47f0\u8ef2\u578f\u9a68\u392a\uaa60\u47b8\ub83d\ub94c\u03f5\u6751\ub415\u4529\u9d94", "\udbd0\udcaf\ud843\udce5\u64bd\udbf1\udcbc\ud821\udfef\uda66\uddc0\uda49\udc7f",
        -1, 4644, 2000830185, -5398918538175260902L, 83888L, false, true, (char) 43872, (char) 42245,
        Double.longBitsToDouble(0x3fa51a289538ae70L), Double.longBitsToDouble(0x3febd58f85e66afdL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.nodes.Document|normalise||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|normaliseStructure|java.lang.String,org.jsoup.nodes.Element|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|body||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|createElement|java.lang.String|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|createShell|java.lang.String|static",
    "M|org.jsoup.nodes.Document|findFirstElementByTagName|java.lang.String,org.jsoup.nodes.Node|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|head||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|nodeName||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|normaliseTextNodes|org.jsoup.nodes.Element|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|outerHtml||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|outputSettings||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|text|java.lang.String|new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|title||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|title|java.lang.String|new:org.jsoup.nodes.Document:java.lang.String",
    "C|org.jsoup.nodes.Document|<init>|java.lang.String",
    "M|org.jsoup.nodes.Document|normalise||new:org.jsoup.nodes.Document:java.lang.String",
    "M|org.jsoup.nodes.Document|normaliseStructure|java.lang.String,org.jsoup.nodes.Element|new:org.jsoup.nodes.Document:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
