package org.jsoup.helper;
import org.junit.Test;
import static org.junit.Assert.*;
public class W3CDom_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 1, "\ud921\udf8c\udac2\udce9\ud925\udc1d\ud8f4\ude56\ud86f\udf56", "\u5897\u038f\u7252\u2083\u777c\u5b73\u030f\uc025\u8fec\u1a28\ub164\u8a13\u09a2\ua7fa\u880b\ubbf8\u176d\u7458\u9a83\ua9a9\u2864\u3c97\uce72\u1dd0\u95fb\uc0fa\ucea8\u9728\u2608\uace2\ua7af\u10ed\u9a37\u345f\u8c6e\ua9e4\u936f\u5653\u3280\u1d2e\u119c\u0a60\ucd61\u3fce", "\ud939\udf9d\ud83d\udd86",
        12, 77143, 2045676143, 6958210940084365982L, 1305L, false, true, (char) 1198, (char) 25515,
        Double.longBitsToDouble(0x3fe592c059009763L), Double.longBitsToDouble(0x3feee4eace7759c7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 1, "\udac9\udce0\udae7\udeee\ud925\udc1d\ud8f4\ude56\udba4\uddee", "\u5897\u038f\u7252\u2083\u777c\u5b73\u030f\uc025\u8fec\u1a28\ub164\u8a13\u09a2\ua7fa\u880b\ubbf8\u176d\u7458\u9a83\u5543\uaa65\u3c97\uce72\u1dd0\u95fb\uc0fa\ucea8\u9728\u2608\uace2\ua7af\u10ed\u9a37\ucb44\u93cd\ua9a9\u936f\u5653\u3280\u1d2e\u119c\u0a60\ucd61\u3fce", "\ud939\udf9d\ud83d\udd86",
        12, 77143, 2045676143, 6958210940084365982L, 1305L, false, true, (char) 1198, (char) 25515,
        Double.longBitsToDouble(0x3fd4e580b2012f76L), Double.longBitsToDouble(0x3feee4eace7759c7L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 1, "\ud921\udf8c\udac2\udce9\ud925\udc1d\ud8f4\ude56\u00e3", "\u5897", "\ud97e\udc46\udb3b\udc0d\udbc2\udd9f",
        43, 83439, -1139482516, 79920751443968L, -86533L, false, false, (char) 1270, (char) 3021,
        Double.longBitsToDouble(0x3f940b40d113b260L), Double.longBitsToDouble(0x3fd19b3e8e863f22L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 1, "\uda99\uddb6\ud841\udeab\u8fed\ud8f4\udddd\ud86f\udf56\ud8b0\ude69\ucced\uda6d\udf2f", "\u2083\u1e6d\u5b73", "\ud937\udc6b\ud9f5\udf01\udb18\udc01\ud98b\udd51\ud81d\udfba\udb37\udc76\uda3f\udeaa",
        5, 80412, -1276621176, 7679170737252738883L, -57865L, false, false, (char) 47403, (char) 59755,
        Double.longBitsToDouble(0x3fcb0706116621d8L), Double.longBitsToDouble(0x3fee10ad5f40ba13L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud921\udf8c\udac2\udce9\ud925\udc1d\ud8f4\ude56\ud86f\udf56", "\u806f\u038f\u7252\u2083\u777c\u5b73\u030f\uc025\u8fec\u1a28\ub164\u8a13\u09a2\ua7fa\u880b\ubbf8\u176d\ua82f\u8c83\uaa26\u2864\u3c97\uce72\u1dd0\u95a8\uc0fa\ucea8\u9728\u2608\uace2\ua7af\u10ed\u9a37\u345f\u8c6e\ua9e4\u936f\u5653\u3280\u1d2e\u119c\u0a60\ucd61\u6d20", "\ud80c\udd94\ud81b\udf7a\ud89f\udd3f\udbd9\udc64\uda04\udd9e\udb45\uddac\ud94c\udc7e\udb3f\udf6f\ud8b7\udc73\udb5a\udd76\ud8f4\udd1d\ud91c\uddd7\udb26\udc87\udaae\udf2f\udac1\udd14\ud9ee\udf67\uea49\ud962\ude84\ud88b\udf2a\ud969\udc15\ud90d\udd90\ud90e\udce1\ud9e6\udcfc\udbce\udff3\uda7d\udfb1\ud9e6\udc50\udac3\udeb3\ud93a\udcd9\ud9c0\udd09\uda3d\ude69",
        52, 80935, -276685062, -5541340473141946566L, 66502L, true, true, (char) 29241, (char) 45254,
        Double.longBitsToDouble(0x3fd85ecfef829692L), Double.longBitsToDouble(0x3fd7ec021b80982cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 1, "\ud921\udf7f\udac6\udde9\ud925\udc1d\ud8f4\ude56\ud86f\udf56", "\u7052\u8434\u721f\u2083\u777c\u5b73\u030f\uc025\u8fec\u1a28\ub164\u8a13\uc99a\ua7fa\u880b\ubbf8\u176d\u7458\u9a83\ua9a9\u2864\u3c97\uce72\u6977\u5dce\u684f\u8f88\u9728\u2608\u7acf\ua7af\u10ed\u9a37\u345f\u8c6e\ua9e4\u936f\u5653\u9166\ud32e\u119c\u0a60\u1405\u3fce", "\ud939\udf9d\ud83d\uddc5",
        12, 77143, -538015121, 6958210940084365982L, 1305L, true, false, (char) 26259, (char) 62978,
        Double.longBitsToDouble(0x3fe592c059009763L), Double.longBitsToDouble(0x3fe65842ccb915f2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\012",
        Z.run(T, 1, 0, 1, 2, "\udac9\udce0\udac3\udeee\uda9c\ude00\ud8f4\ude22\udba4\uddee\ud8b0\udee8\ucced\uda6d\udf2f\ud920\uddfe\u7115\ud97e\udc46\udb3b\udc0d\udbc2\udd9f\ud80f\udc5b\udaf7\ude66\ud937\udc6b\ud950\udd8e\ud928\udfc0", "\ua829\u880b\ubbf8\u176d\u9104\ud203\u28dc\ucacb\ub490\u5b1a\u8700\uccf8\u4ffa\ucea8", "\ud842\udfa3\uda45\udda8",
        8, 61389, -1072615669, 5118076676586003656L, -64289L, true, false, (char) 46555, (char) 4766,
        Double.longBitsToDouble(0x3fdf30f0636430b0L), Double.longBitsToDouble(0x3fdb6a0bc623c290L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\0121=java.lang.String:<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?> |this=org.jsoup.helper.W3CDom:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud921\udf8c\udac2\udce9\ud925\udc1d\ud8f4\ude56\u00e3", "\u5897", "\ud97e\udc46\udb3b\udc0d\udbc2\udd9f",
        43, 65279, -71697871, -5659229147512176640L, -86533L, false, false, (char) 1270, (char) 3021,
        Double.longBitsToDouble(0x3f940b40d113b260L), Double.longBitsToDouble(0x3fd19b3e8e863f22L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 1, "\ud921\udf8c\udac2\udce9\ud925\udc1d\ud8f4\ude56\ud86f\udf56\udb21\ude26\uda37\ude99\uda6d\udf2f\ud920\uddfe", "\u777c\u5b73\u030f\uc025\u8fec\u1a28\ub164\u8a13\u09a2\ua7fa\u880b\ubbf8\u176d\u7458\u9a83\ua9a9\u2864\u3c97\uce72\u1dd0\u95fb\uc0fa\ucea8\u9728", "\uda45\udda8\udb3a\udeca\ud9fe\ude0e\uda60\udd62\uda0a\udd90\udaf3\udede",
        58, 70722, -902380688, 2481329865639559728L, 52793L, true, false, (char) 4618, (char) 41586,
        Double.longBitsToDouble(0x3fe88f0a47834d2dL), Double.longBitsToDouble(0x3fe226f223973296L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.jsoup.helper.W3CDom|asString|org.w3c.dom.Document|new:org.jsoup.helper.W3CDom:",
    "M|org.jsoup.helper.W3CDom|convert|org.jsoup.nodes.Document,org.w3c.dom.Document|new:org.jsoup.helper.W3CDom:",
    "M|org.jsoup.helper.W3CDom|fromJsoup|org.jsoup.nodes.Document|new:org.jsoup.helper.W3CDom:",
    "C|org.jsoup.helper.W3CDom|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
