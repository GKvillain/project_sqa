package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda25\udd6d\uda7d\udd82\ud9e0\udf85\udbd0\udf74\udb78\udd18\ud808\udc1b\udaaf\udf8d\ud8cb\udee0\udb9c\ude9e\ud9d7\udd57\ub5c2\ud9f7\ude7c\udae7\udf4b\uda68\udf22\udba6\ude74\ud9fe\udde4\ud89e\ude60\udb5c\udf9a\udb04\ude52\udb98\uddee\uda16\udf8e\uda29\uddc6\uda6c\udec3\uda1c\udc59\udad0\udd2d\udbab\ude10\uda40\udc18\ud8db\udf64\ud8ad\udfba\ud9e4\udef6\ue856\uda4d\udfc3\udbd1\ude38\udb80\uddad\udaf0\udd2e\uda03\udcc1\udbc6\udc18\ud87f\udc00\udb86\udc02\uda56\uded5\udbb3\udd80\ud9e7\udf5b\u61e0\uda06\udddf\ud9c7\udd07\ud935\udf7b\ud939\udcc6\ud8db\udd3d\ud97b\udf16\ud9cf\udc48\udbdd\udc26\ud95a\ude91\ud85f\udf38\uda10\udf5e\udb49\udd87\uda03\udd50\u0129\udbfa\ude8b\ud96a\udfdb\uda7b\udd24\ud83c\udce8\udb78\udf18\udbcb\udf87\ud8d4\udf0f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda25\udd6d\uda7d\udd82\ud9e0\udf85\udbd0\udf74\udb78\udd18\ud808\udc1b\udaaf\udf8d\ud8cb\udee0\udb9c\ude9e\ud9d7\udd57\ub5c2\ud9f7\ude7c\udae7\udf4b\uda68\udf22\udba6\ude74\ud9fe\udde4\ud89e\ude60\udb5c\udf9a\udb04\ude52\udb98\uddee\uda16\udf8e\uda29\uddc6\uda6c\udec3\uda1c\udc59\udad0\udd2d\udbab\ude10\uda40\udc18\ud8db\udf64\ud8ad\udfba\ud9e4\udef6\ue856\uda4d\udfc3\udbd1\ude38\udb80\uddad\udaf0\udd2e\uda03\udcc1\udbc6\udc18\ud87f\udc00\udb86\udc02\uda56\uded5\udbb3\udd80\ud9e7\udf5b\u61e0\uda06\udddf\ud9c7\udd07\ud935\udf7b\ud939\udcc6\ud8db\udd3d\ud97b\udf16\ud9cf\udc48\udbdd\udc26\ud95a\ude91\ud85f\udf38\uda10\udf5e\udb49\udd87\uda03\udd50\u0129\udbfa\ude8b\ud96a\udfdb\uda7b\udd24\ud83c\udce8\udb51\udec2\udbcc\udc92\ud8d4\udf0f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\ud9c6\udd89\ud9d2\udc56\uda7d\udd82\ud9e0\udf85\udbd0\udf74\udb78\udd18\ud8c5\udc7d\ud944\ude78\ud8cb\udefc\udb9c\ude9e\ud9d7\udd57\ub5c2\ud9f7\ude7c\udae7\udf4b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda25\udd6d\uda7d\udd82\ud9e0\udf85\udbd0\udf74\udb78\udd18\ud808\udc1b\udaaf\udf8d\ud923\udfac\udb74\udec6\ud9d7\udd57\ub5c2\ud9f7\ude7c\udae7\udf4b\uda68\udf22\udba6\ude74\ud9fe\udde4\ud89e\ude60\udb5c\udf9a\udb04\ude52\udb98\uddee\uda16\udf8e\uda29\uddc6\udbf2\udec6\uda1c\udc59\udad0\udd2d\udbab\ude10\uda40\udc18\ud8db\udf64\ud8ad\udfba\ud9e4\udef6\ue856\uda4d\udfc3\udbd1\ude38\udb80\uddad\ud8f3\udfef\ud96a\udda5\udbc5\udfbf\ud87f\udc00\udb86\udc02\uda56\uded5\udbb3\udd80\ud9e7\udf5b\udb23\uddfc\uda06\udddf\ud9c7\udd07\ud935\udf7b\ud939\udcc6\ud8db\udd3d\ud975\ude99\ud9cf\udc48\udbdd\udc26\ud95a\ude91\ud85f\udf38\uda10\udf5e\udb49\udd87\uda03\udd50\u0129\udbfa\ude8b\ud96a\udfdb\uda7b\udd24\ud83c\udce8\udb78\udf18\udbcb\udf87\ud8d4\udf0f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda25\udd6d\uda7d\udd82\ud9e0\udf85\udbd0\udf74\udb78\udd18\ud808\udc1b\udaaf\udf8d\ud8cb\udee0\ud9eb\udd59\ud89f\udff7\uda46\udefb\udb29\udf7a\udae7\udf4b\uda68\udf22\udba6\ude74\ud9fe\udde4\ud89e\ude60\udb5c\udf9a\ud9bc\ude4e\udb98\uddee\uda16\udf8e\uda29\uddc6\uda6c\udec3\uda1c\udc59\udad0\udd2d\udbab\ude10\uda40\udc18\ud8db\udf64\ud8ad\udfba\ud9e4\udef6\ue856\uda4d\udfc3\udbd1\ude38\udb80\uddad\udaf0\udd2e\uda03\udcc1\udbc6\udc18\ud87f\udc00\udb86\udc02\uda56\uded5\udbb3\udd80\ud9e7\udf5b\udb5c\udf44\uda06\uddde\ud9c7\udd07\ud935\udf7b\ud939\udcc6\ud8db\udd3d\ud97b\udf16\ud9cf\udcaf\udbdd\udc26\ud95a\ude91\ud85f\udf38\uda10\udf5e\udb49\udd87\uda03\udd50\u0129\udbfa\ude8b\ud96a\udfdb\uda7b\udd24\ud83c\udce8\udb78\udf18\udbcb\udf87\ud8d4\udf0f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda25\udd6d\uda03\udc28"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda25\udd6d\uda7d\udd82\ubb2a\udbd0\udf5d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\ud801\udc9e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda25\udd6d\uda05\udd86\ud9e0\udf85\udbd0\udf74\udb78\udd18\ud808\udc1b\udaaf\udf8d\ud8cb\udee0\udb9c\ude9e\ud9d7\udd57\ub5c2\ud9f7\ude7c\udae7\udf4b\uda68\udf22\udba6\ude74\ud9fe\udde4\ud89e\ude60\udb5c\udf9a\udb04\ude52\udb98\uddee\uda16\udf8e\uda29\uddc6\uda6c\udec3\uda1c\udc59\udad0\udd2d\udbd2\udca4\ud9a3\ude01\ud9b8\udfac\ud8ad\udfba\ud9e4\udef6\ue856\uda4d\udfc3\udbd1\ude38\udb80\uddad\udaf0\udd2e\uda03\udcc1\udbc6\udc18\ud8bf\ude6e\uda11\uddc9\ud815\udcb8\udb30\udcad\ud9e7\udf0b\u61e0\uda06\udddf\ud9c7\udd07\ud935\udf7b\ud939\udcc6\ud8db\udd3d\ud97b\udf16\ud9cf\udc48\udadd\udd85\uda2b\udfb0\ud832\udf50\ud980\udf1b\udb75\udea9\uda03\udd50\u0129\udbfa\ude8b\u5dd1\uda60\udd80\ud896\udddf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda25\udd6d\uda7d\udd82\ud9e0\udf85\udbd0\udf74\udb78\udd18\ud808\udc1b\udaaf\udf8d\ud8cb\udee0\udb9c\ude9e\ud9d7\udd57\ub5c2\ud9f7\ude7c\udae7\udf4b\uda68\udf22\udba6\ude74\ud9fe\udde4\ud89e\ude60\udb5c\udf9a\udb04\ude52\udb98\uddee\uda16\udf8e\uda29\uddc6\uda6c\udec3\uda1c\udc59\ud8a5\udf78\udbab\ude1c\uda40\udc18"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda58\udc49\uda20\ude2e\uda7d\udd82\ud9e0\udf85\udbd0\udf74\udb78\udd18\ud808\udc1b\udaaf\udf8d\ud8cb\udee0\udb9c\ude9e\ud9f9\udea8\udb7d\udda6\ud827\udfb0\ud9ca\udcfd\uda68\udf22\udba6\ude74\ud9fe\udde4\ud89e\ude60\udb5c\udf9a\udb04\ude52\udb98\uddee\ud8d5\udd0f\uda29\uddcc\uda6c\udec3\uda1c\udc59\udad0\udd2d\udbab\ude10\uda40\udc18\ud8db\udf64\ud8ad\udfba\ud881\udf22\ue855\uda4d\udfc3\udbd1\ude38\udb80\uddad\udaf0\udd2e\uda03\udcc1\udbc6\udc18\ud87f\udc00\udb86\udc02\uda56\uded5\udbb3\udd80\ud9e7\udf5b\u61e0\uda06\udddf\ud9c7\udd07\ud935\udf7b\ud939\udcc6\ud8db\udd3d\ud97b\udf16\ud9cf\udc48\udbdd\udc26\ud95a\ude91\ud85f\udf38\uda10\udf5e\udb49\udd87\uda03\udd50\u0129\udbfa\ude8b\ud96a\udfdb\uda7b\udd24\ud83c\udce8\udb78\udf18\udbcb\udf87\ud8d4\udf0f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\034\ud91d\udf64\uda7a\ude54\ud8be\udca4\ue661\udb62\udc91\uda77\udfa4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\034"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\u1949");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uff10");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
}
