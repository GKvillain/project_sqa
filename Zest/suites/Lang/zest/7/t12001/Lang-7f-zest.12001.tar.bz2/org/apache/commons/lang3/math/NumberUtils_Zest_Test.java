package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\ud85c\uddfd\ud85f\udd79\ud9f9\ude54\udabb\udf07\udb1e\udc43\udabc\udd35"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\udb03\udc90\ud87a\udf9b\udbbc\udf9b\udabb\udf07\udb1e\udc43\udabc\udd35\udadf\udf36\ud88e\udf77\ud8b0\udd11\u1547\uda03\udc4f\ud8b0\ude96\ud992\udc9f\uda2e\udf47\udb25\uded8\udba7\udc00\udba4\udca9\ud95b\udd10\udab3\udc96\uda3f\udf86\udba0\udd48\udb95\ude18"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\ud85c\ude11\ud85f\udd79\udbef\ude70\udb83\udd39\udb52\udd0a\udabc\udd35\uda7f\ude3c\ub1a9\ud888\udfcb\uda7d\udc35\ud8bd\udcf5\u1b16"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\uda96\udf5c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\udbdd\ude05\u1100\udbf2\ude25"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\udad0\ude13\ud901\udcac\uda5d\udebe\udaaf\uddb7\ud85f\udc76\ud943\udcfc\uda74\udce7\udaef\udf42\uda93\ude27\udabd\udea7\ud828\udc38\udb3f\udcd6\ud8dd\uddb6\udaae\udff2\ud9b4\udc46\udae4\ude36\uda67\ude2a\ud847\uddcc\udae8\udda4\uda35\udfe0\uda29\udf50\u76d6\ud884\udd2e\udbaf\udca4\ud8ed\udf41\uda62\ude4f\udb7f\udf2e\udacf\udcbd\udaac\udc06\udbf0\udc39\ud818\udef4\ud9c8\uddf1\udb88\udcaf\udb26\udde9\u9b26\ud91c\udfb0\ud8a1\udff0\ud8e8\udddc\ud9bc\udf04\uda38\udd5a\ud8aa\udcc2\udad8\udeac\udae1\udf44\uda3e\udfdc\udb58\ude0c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("d\000\ud9f9\ude54\udabb\udf07\udb1e\udc43\ud93e\udc75"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\udb4f\udf38\u320a\ud90d\udf7e\uda47\udd1e\ud8ae\udcce\ud961\udf58\uda3c\udd3b\udadf\udfdb\ucbf0\ud80c\udeae\ud8fa\udeb7\ud89a\udfff\udb7f\udd9f\udb3c\udfa7\ud9e2\udcd0\uda82\udfbe\ud8fe\udfed\ud99c\udf9f\udb16\ude5b\udbbf\ude72\u8bcc\udb90\udcc8\ud803\udec7\udb81\ude31\uda45\ude6a\udb77\udfe3\uda7c\udf79\ud999\udc6c\ud81b\udfee\uda66\udfab\ud83c\udd16\udacd\udd62\ud8ef\udf72\udbd2\ude53\udbe5\udc36\udbf4\ude95\ud93f\udcef\ud82f\udc0f\ud95f\udd93\udbca\udc9d\ud817\uddde\udadc\uddd5\uda87\ude7a\udbb8\udd23\ud810\udeef\ud8a3\ude28\ud98d\udf9d\udac2\udcc2\uda4c\udf46\uda13\ude59\udaef\udd36\udaaa\udf5b\udb37\udc5d\udb00\ude8b\u559f\ud852\udcd9\udbf7\udcb8\ud857\udd57\uda9a\ude98\ud86c\udda2\udbb6\udf29\u9e72\udbea\udf53\ud997\udfe6\uda2a\udffd\uda77\ude28\uda1a\udc15"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\udb4f\udf38\u320a\ud915\udde3\uda47\udd5b\ud8ae\udcce\ud961\udf58\ud8c1\udf59\uda02\udfed\ud96d\udcc9\uda22\udcd3\udb6c\udda1\ud89e\udcc6\udb7f\udd9f\udb3c\udfa7\ud8d1\ude39\uda83\udc11\ud8fe\udfed\ud99c\udf9f\udb16\ude5b\udbbf\ude72\ud8fc\udc9b\udac6\udcc3\udb92\udf6e\udb81\ude31\uda45\ude6a\ud8dc\udcd5\ud8a0\ude48\udb5f\udc7b\ud81c\udc9b\uda66\udfab\ud83c\udd16\udacd\udd62\ud8ef\udf72\udbd2\ude53\udbe5\udc36\udbf4\ude95\ud93f\udcef\ud82f\udc0f\ud9f3\udcbd\ud94c\udc9c\udac5\udcde\udadc\uddd5\uda87\ude7a\udbb8\udd23\ud810\udeef\ud8a3\ude28\udb13\udf40\ud892\udd9b\uda4c\udf46\uda13\ude59\ud8d8\udf2c\uda94\udce0\ud81f\udc2d\uda35\ude16\udab0\udfcb\ud930\udd1e\udbf7\udcb8\ud857\udd57\uda9a\ude98\ud86c\udda2\udbb6\udf29\u9e72\udbea\udf53\ud997\udfe6\uda2a\udffd\uda77\ude28\uda1a\udc15"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\015\udbee\udf52\ud852\udd66\udab3\udd3f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\015"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createBigDecimal("\ua9d0");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
}
