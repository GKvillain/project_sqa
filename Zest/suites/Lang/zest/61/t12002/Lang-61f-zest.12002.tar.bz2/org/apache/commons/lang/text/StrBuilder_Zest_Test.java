package org.apache.commons.lang.text;
import org.junit.Test;
import static org.junit.Assert.*;
public class StrBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 2043906364, 2711546380148521956L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\ud33e\ua079\u0aa8", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 2127792444, -3298082243503633105L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 17, 13, 0, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\uccdf\ud34b\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud9e5\udd04\u9551\udb61\udda2\u51dc\ud9ae\udcf5\udb2a\udffc",
        41, 90752, 2043906364, 2711546380148521956L, 66532L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u0f13\u8ce5\u9527\u08bc\u9ca1\u2e0f\uccc1\ub8b2", "\u77c0\ud9c6\udc82\u527c\ud98b\udf05\udba5\udea1\udb74\udded\u68c8\ud9ae\udcf5\ud862\ude5a\udb28\udde5\ud807\udcfd\udb69\udd62\udac6\udf48\ud99c\udd79\ud9df\udc32\uda1b\udcbc\udaee\udfeb\ud803\udc1a\udb25\udf6d\u1645\uda0d\udc3d\udab2\udd82\ud89f\udfe5\uda84\udc3c\uda1d\udfd1\ud942\udf9c\ud856\udf7f\udaf1\udc9b\uda7d\ude3c\ud89d\udff9",
        42, 89671, -1645504121, -1070066747505314667L, -56748L, true, false, (char) 23400, (char) 44696,
        Double.longBitsToDouble(0x3fea4c7909845c87L), Double.longBitsToDouble(0x3fd8df249c28e0deL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 4, "\ud89e\udf52\uda66\udcdb\udb78\udfa2\ud986\uddcc", "\ucd51\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\ud33e\u4f98\u2056", "\udaf9\udc9f\ud8c4\udcef",
        29, 15740, 376846543, 2627066026962469191L, -48651L, false, false, (char) 8288, (char) 53988,
        Double.longBitsToDouble(0x3fef212d0ebbfcbfL), Double.longBitsToDouble(0x3fe3e52a61b0df5bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 3, 8, 4, "\ud89e\udf52\ud963\udcfa\udaa9\ude3a\ud976\udde2", "\u3f0f\u5a88\u8cdc\u4d3a\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23\ud8cf\udd95\udab6\ude19\u8551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 616345720, 4152698587324595172L, -87324L, false, true, (char) 53102, (char) 17090,
        Double.longBitsToDouble(0x3fc5103c0dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 4, "\ud89e\udf52\udb7d\udf28\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 2033739099, 2711546380148521956L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 18, 0, 7, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2\ud999\uded5\ud9d8\ude40\udb89\udd33\u38bc", "\u9ca1\u2e0f\u8450\u23c6\uaf20\u8fe8\uce06\ua21e\u8706\u026c", "\ud8be\udf7a\ud95c\ude4c\udb2a\udffc\udbe6\udcc8",
        22, 69364, -338638319, -234238322320597317L, 71695L, false, false, (char) 27707, (char) 64562,
        Double.longBitsToDouble(0x3fe48bced0cff2e1L), Double.longBitsToDouble(0x3fd1fde000cf0f82L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\u4e12 |this=org.apache.commons.lang.text.StrBuilder:\u4e12\0121=org.apache.commons.lang.text.StrBuilder:\u4e12\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2 |a0=[C:[[\ud89e, \udf52, \ud932, \udce1, \udaa9, \ude3a, \ud976, \udde2]] |this=org.apache.commons.lang.text.StrBuilder:\u4e12\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\012",
        Z.run(T, 2, 7, 8, 4, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\ud024\ud5f7\u0c6c\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0",
        44, 90752, 2043906364, 2711546380148521956L, 43033L, true, false, (char) 19986, (char) 27707,
        Double.longBitsToDouble(0x3fefcd41ca9179daL), Double.longBitsToDouble(0x3fc507b8162fef58L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 17, 4, "\ud89e\udf52\uda66\udcdb\udbbc\udfa4\ud9c5\udc9d", "\u4bf3\u2e70\u4adc", "\ubc9a\ud954\ude72\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbba\udf23\uda26\udc0c\uda0c\udcd1\udbd0\udf66\udac9\udd75\u68c8\ud9ae\udcf5\udb2a\udffc\uda10\udecc\ue462\udbc0\udc69\udb96\udcb0\ud842\udd2c\uda1c\udebd\udbf1\udc2e\ud9df\ude08",
        28, 7007, -658060120, -6324862068900080647L, -77949L, false, false, (char) 7960, (char) 23518,
        Double.longBitsToDouble(0x3fd5aa6d9efe14eeL), Double.longBitsToDouble(0x3fcd2f106251fafcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\u333a\uc36f\u86a1", "\udb3c\udd04\000\000\ue57b\udb74\ude21\u68c8\ud9ae\udcf5",
        26, 53347, -1759227248, 8778510990097602833L, 71695L, false, false, (char) 27707, (char) 64562,
        Double.longBitsToDouble(0x3fe48bced0d94b8aL), Double.longBitsToDouble(0x3fcd1495e65ffc60L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:false |this=org.apache.commons.lang.text.StrBuilder:false\012",
        Z.run(T, 1, 6, 18, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\ucc36\u4adc\u1a3a\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 2043906364, 2711546380148521956L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 17, "\ud89e\udf52", "\u3129\u0fde\u3a0e\u3f0f\uc3c9\u4adc\ucb68\u9ca1\u2e0f\ud33e\u0e5c\u684c\u8fb7\ud5b1\000\000\u7da0", "\u68c8\ud9ae\udcf5\u1aea\000",
        8, 69364, 631331089, -234262069194776901L, 34736L, true, true, (char) 29113, (char) 0,
        Double.longBitsToDouble(0x3e3fc80000000000L), Double.longBitsToDouble(0x3fe48bced1b0b7a8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:7 |this=org.apache.commons.lang.text.StrBuilder:7\012",
        Z.run(T, 1, 12, 12, 4, "\ud89e\udf52\uda66\udcdb\udb0d\udc36\ud976\udde2", "\ucfff\u894c\u4adc\u1a3a\u9ca1\u2e0f\ud33e\u9870\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\udb85\uddc3\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 2043906364, 2711546380148521956L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2 |a0=[C:[[\ud89e, \udf52, \uda66, \udcdb, \udaa9, \ude3a, \ud976, \udde2]] |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2\012",
        Z.run(T, 1, 8, 16, 14, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\uca6f\uc3c9\u4adc\u3add\u7a2f", "\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbba\udf23\udbd7\udc49\ud98b\udef5\u9551\ud87d\udd0b\u6925\ud9ae\udcf5\udb2a\udffc\uda10\udecc\ue462\udbc0\udc69\udaef\ude3e\udbcc\udfb2\uda56\udd62\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud81c\udd88\ud965\uddd4\udb0b\udde1\ud934\udf27\uda9a\ude22\ud950\udfbe\uda48\udfde\ud879\udc41\ud8d8\ude1f\udaf0\udcf1\udb92\udd28\uda48\udce9\ud953\udff6\ud808\udf6e\ud9b5\uddcc\ud9f5\udf26\ud9db\udd50\u6d3b\ud9eb\udebc\uda06\udd89\ud857\udfb5\udaa6\udccc\ud900\udfdb\udb07\udecd\ud847\uddfc\ud992\udf68\udbdf\udd40\ud91c\udf9f\ud93a\udd94\u13cb\udb62\udf92\udb23\udce5\udbd8\udfcd",
        4, -512, -1386293408, 4573913065741327948L, -81077L, false, true, (char) 21680, (char) 30719,
        Double.longBitsToDouble(0x3fcc27d3ea1fb388L), Double.longBitsToDouble(0x3fe1bc9468582973L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 0, "\ud83b\udf7f\uda66\udcdb\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud87d\ude2d\ud81d\uddf5\ud9cf\udd29", "\uac32\u86dd\u8fb7\ucc2b\u52af\u86f3\u93f2\u3e35\u2b6e\ua9d7\ua8a0\u7164\u1286\u9648\u919f\u6daa\u8009\u8b3a\u27cc\u1122\uc010\uc8a7\u162b\ua86f\u8552\u89b3\u7578\u7cf5\u8304\ud54b\u6d12\u2317\ub015\u2887\ubf89\ucc02\u7c38\uad1c\u6abb\u898f\uc21f\u0ac8\u9fb6K\u332c\ua5f6\uc847\u74e9\u987a\ud36a\u7948\ud2c3\u5350\u5380", "\udb8b\ude1a\udbe0\udd1f\u4c29\ucb35\udba6\udde7\uda1e\udc19\ud820\udefa",
        15, 34235, -1188654329, -291905936039703031L, 76059L, false, true, (char) 49831, (char) 26877,
        Double.longBitsToDouble(0x3fe86ee5a985e85dL), Double.longBitsToDouble(0x3fefa54136dc6847L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ua766 |this=org.apache.commons.lang.text.StrBuilder:\ua766\012",
        Z.run(T, 1, 7, 11, 0, "\ud89e\udf52\u21cd\udaa9\ude3a\ud976\udde2\uda0a\udce3\ud822\udf50\ud9e1\udfed\uda76\ude86\ud902\uddef\ud8ba\udcb2\ud867\udf49\udb6f\uddf3\ud954\ude7a\ud896\udf08\ud901\udc30\ud918\uddef\ud800\udc59\udbba\udf23\udba5\udd21\ud9a9\uddd3\u9548\ud993\ude3f\udb67\udeca\u7657\udb42\udeb4\uda10\udecc\udb54\uddaf\udb8f\udf60\udac6\udf48\udbd8\udcb2\u2f9e\udb4a\udc60\udb70\udfec\udadc\udd4d", "\uc36c", "\udbea\udf77\udbaa\uddd0\ud823\udedf\ud8da\udebf\ub7ba\ud9ef\udffe\ud9e5\uddd4\uda6e\uddad\u5116\uda3b\udee7\ub253\udadb\ude89\ud800\udfa9\udaec\udef2\uda9d\udee2\ud8fb\udd60\ud8c6\udcc0\ud904\udf3f\uda61\udee3\udb6b\udeb9\udabe\udfc2\udba9\udc33\ue218\ud914\udf66\ud817\udf60\ud8fe\udf99\udbd4\udffc\ud843\udf45\ud8b5\udf82\ud9a6\ude6c\ud828\udf9a\ud956\ude0e",
        57, 9927, -1120708471, -8954121833863568244L, 55830L, true, false, (char) 42854, (char) 19715,
        Double.longBitsToDouble(0x3fee058fb8e59a4aL), Double.longBitsToDouble(0x3fa195218f30a770L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.16455618 |this=org.apache.commons.lang.text.StrBuilder:0.16455618\012",
        Z.run(T, 1, 11, 10, 0, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\uc8f2\u4499\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\udb22\uddb0\udb8e\ude52\udb74\ude21\ud860\udf6b\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 2043906364, 2711546380148521956L, -87324L, false, true, (char) 21270, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca917926L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 9, 20, 10, "\ud89e\udf64\udacd\udf8f\udaa9\ude3a\ud9cc\uddbd", "\u9296\u796c\u3c7c\u1a3e", "\ud954\uddae\uda60\ude29\ud918\udcef",
        36, 92638, 613405729, -6974361750423683109L, 45523L, false, false, (char) 26044, (char) 5507,
        Double.longBitsToDouble(0x3feec9f6ca90b19fL), Double.longBitsToDouble(0x3fe1e4b9218eca6cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2 |a0=[C:[[\ud89e, \udf52, \uda66, \udcdb, \udaa9, \ude3a, \ud976, \udde2]] |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2\012",
        Z.run(T, 2, 4, 8, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 2043906364, 6117796122682440676L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 0, 11, 17, "\udb34\udddc\ud965\udc4a\ud99c\udd50\ud852\udf10\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud87d\ude2d\ud960\udc09\ud9cf\udd29\ubc9a\ud954\udeae\ud85c\udf08\ud901\udc30\udb35\ude13\u5da5\udbba\udeef\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc\uda02\udec5", "\u6daa\u8009\u1317\u9055\uc767\uc010\uc8a7\u2ae9\ub794\u5f16\u84ef\u100d\u95b2\u7cdc\u10ca", "\ud9be\uddd8\udb04\udcfe\udbab\udffb\ud9c3\udeb3\uda33\udf5e",
        12, 47556, 1365521513, -4101328827852284808L, 84721L, false, true, (char) 58064, (char) 32275,
        Double.longBitsToDouble(0x3fe6890cf205fb43L), Double.longBitsToDouble(0x3fe6351f2714f176L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 13, 8, 4, "\ud89e\udf52\uc8e2\udaa9\ude3a\ud976\udde2", "\ub407\uc2d0\uad36\u1a3a\u9ca1\u2e0f\u9a5a\u82e2\u3710", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\uda4b\udee4\ud81e\ude66\uec9d\uda27\ude6d\udb2a\udffc",
        7, 83296, 2043906403, 2711546380148521956L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd6e318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.6150847449437215 |this=org.apache.commons.lang.text.StrBuilder:0.6150847449437215\012",
        Z.run(T, 1, 10, 8, 4, "\ud89e\udf52\uda66\udcdb\ud82a\udf1b\udaf4\udf44\udb79\uddc5\udafc\udc5d\ud833\udc29\u38d2", "\u9ca1\u2e0f\ud33e\u3ab5\u0d0b\u8fb7\ud5b1\uacb7\u8706\u93f2", "\u68c8\ud918\udeab\udb2a\udf8d\uda10\udecc",
        22, 69364, 631331089, 3168135984043765746L, 34736L, false, true, (char) 4200, (char) 30738,
        Double.longBitsToDouble(0x3fe3aec633f9a839L), Double.longBitsToDouble(0x3fe48bced4a06039L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\uda66\udcdb\uda3f\udfc5\uda91\uddf1 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\uda66\udcdb\uda3f\udfc5\uda91\uddf1\012",
        Z.run(T, 1, 13, 8, 4, "\ud89e\udf52\uda66\udcdb\uda3f\udfc5\uda91\uddf1", "\ud5fa\uc3c9\u6b61\u1a3a\u5acd\u14ed\u546b\uc36f", "\u77c0\udbba\udf23\uda1c\udf82\ud895\udce4\u9855\udb74\ude21\u68c8\ud8b1\udc66\ud819\udfab\uda20\udd17\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\uda56\udd62\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud8fb\udf39\ud8d4\ude58\udb0b\ude48\ud934\udf27\ud8ae\uddeb\ud9ee\udf8d\udbd0\uddef\uda33\udeae\ud9fe\udd56\udb83\uddcb\ud785\ud8ec\udfb5",
        1, 33210, -331021067, -1229002867225815272L, -53679L, true, true, (char) 64586, (char) 45597,
        Double.longBitsToDouble(0x3fe63e74bcb73be8L), Double.longBitsToDouble(0x3feab7164baadf48L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 12, 16, "\udaf9\udd0b\udb89\udd88\ud886\udfe0\ud976\udde2", "\u3f0f\uc3c9\u4adc\u644c\ua602\u314c\ucfce\u21a3\u86a1", "\udbba\udf23\ud8c4\udcef\ud91d\udfcd\ud9b8\udfd2\udb84\udc52\u68c8\ud9d7\udff5\u1a6b",
        -3, 94056, 2043906364, 2711546380148521956L, -87324L, false, true, (char) 21308, (char) 25704,
        Double.longBitsToDouble(0x3fe4d440eb757e21L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 9, 10, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u2e8f\u86fc\u6b12\ud5a6\u6db8\u2e0f\ud33e\uc36f\u86a1", "\udb8b\udc48\uda7e\ude87\ud98b\udf05\uda67\udd51\udb31\udd80\uad59\uda50\uddcd\udb2a\udffc",
        7, 90752, 2043906364, 2711546380147206372L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 9, 8, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud866\udcf1\udb2a\udffc",
        7, 90752, 2043906364, 2711546380148521956L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 8, 4, 4, "\ud971\udd38\udaa1\ude80\udaa9\ude3a\ud976\udde2", "\u7f85\uc35f\u131c\u44c3\u9ca1\u2e0f\u6ecd\uc36f\u86a1", "\ud81e\uddb6\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc",
        39, 90830, 2043875638, 3866426321122868027L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca4379daL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 15, 8, 14, "\ud89e\udf52", "", "\uda02\ude40",
        53, 34566, -1836936031, 43446865168675584L, 72707L, true, false, (char) 52662, (char) 16182,
        Double.longBitsToDouble(0x3fe00127557621d2L), Double.longBitsToDouble(0x3feea495c8cf5d21L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 4, "\u0f45", "\u3129\u0fde\u3a0e\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\u1894\000\u684c\u8fb7\u33eb", "\ud98b\udf05\u9551\000",
        -5, -1000, -1971905814, 0L, -77199L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fdb0df5b28f03eaL), Double.longBitsToDouble(0x3fe57b8dcca8816aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.16455618191573573 |this=org.apache.commons.lang.text.StrBuilder:0.16455618191573573\012",
        Z.run(T, 1, 10, 8, 4, "\ud89d\udee8", "\u3129\u0fde\u3a0e\u3f0f\uc3c9\u3d0d\u7d90\ua3a4\ud253\ucc1c\u057f\u2bd0\u24e5\u62a0\uc806\u8706\u56fb", "\u68de",
        22, 26631, -174835861, -7503739890928626628L, -87324L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:30 |this=org.apache.commons.lang.text.StrBuilder:30\012",
        Z.run(T, 1, 12, 17, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f43\uc3c9\u4adc\u1a3a\u24d9\uc6f5\u6723\ua320\uc97b", "\udbc9\udc8a\ud802\udec4\ud98b\udf6e",
        30, 14543, 345332386, -8554687200469949249L, -55600L, false, true, (char) 53988, (char) 17797,
        Double.longBitsToDouble(0x3fe67b5ffe7ca54cL), Double.longBitsToDouble(0x3fdb0df5b28f03eaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 14, 11, 1, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2\ud999\uded5", "\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\u9894\u5a48\u240d\u31ca\u4b7d\ua909\u8706\ua8b0", "\u68c8\ud9ae\udcf5\udb2a\udffc\uda10\udecc",
        23, 88026, -607043682, -234262281378707269L, 34736L, true, true, (char) 4200, (char) 19986,
        Double.longBitsToDouble(0x3feb65ec23f9a839L), Double.longBitsToDouble(0x3fe48bced40223d2L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 15, 8, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u485f\u9e5f\u3ef4\u3d93\ud33e\ub55e\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\udb2a\udffc",
        7, 90752, -988909525, -1545115829115339165L, -87324L, false, false, (char) 42139, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:true |this=org.apache.commons.lang.text.StrBuilder:true\012",
        Z.run(T, 1, 6, 10, 4, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a", "\u3a0e\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\ud33e\uc36f\u86a1\u8fb7\ud5b1\uacb7\u8706\u93f2\u06da\u2b6e\ua9d7\ud2de\u4fcd\uc31e\u9648\u919f\u0cb0\u8009", "\ud9e0\ude42\udadd\udffa\udb33\uddb4\ud913\udec1",
        43, 63088, -1817929386, -7388303467581303606L, -74434L, true, true, (char) 7018, (char) 45862,
        Double.longBitsToDouble(0x3fe3b29cb3bf4537L), Double.longBitsToDouble(0x3fe4f9afe264b033L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 19, 20, 0, "", "\000\u74ad\u0fde", "\000\000\000\uda84\udda2\udb69\uddd6\ud954\udeae\ud809\udca4\ud931\udd69\ud96f\udcd6\udae6\udfa3\ud840\ude1f\ud8c4\udcef\udbc3\udd80",
        -5, 43752, 7681698, 71773198483456L, -100000L, false, false, (char) 7035, (char) 29640,
        Double.longBitsToDouble(0x3fdb0df5b0000000L), Double.longBitsToDouble(0x3fc5ee2000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 4, 8, 4, "\ud810\udf4e\uda79\ude61\udaa9\ude3a\ud976\udde2", "\u3f0f\ubaa8", "\ud801\udea3",
        -4, 56363, -947311970, 8345554239884795501L, -1943L, true, false, (char) 30816, (char) 54853,
        Double.longBitsToDouble(0x3fe7d1509ef9dd6aL), Double.longBitsToDouble(0x3fd4724757d5f530L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 17, 13, 0, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u82ff\u239b\u4f9e\ub751\u9ca1\uccdf\ud34b\u109b\ucad3", "\udbba\udf23\ud8c4\udcef\ud9e5\udd04\u7151\udb61\udda2\ud9cd\udc37\ud9ae\udced\udb2a\udffc",
        -2, 36856, 1070827836, 8198025279629313342L, -88039L, true, false, (char) 19986, (char) 27707,
        Double.longBitsToDouble(0x3fefcd44529179daL), Double.longBitsToDouble(0x3fd83eedf89b2a64L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 3, 1, 0, "", "", "\ud999\uded5",
        46, -1000, 1711276032, -7889580176183764302L, -30788L, true, true, (char) 4670, (char) 0,
        Double.longBitsToDouble(0x3d1d400000000000L), Double.longBitsToDouble(0x3d92400000000000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 9, 16, 0, "\ud89e\udf51\uda66\udcdb\udb3b\uddea\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud9ce\udc66\ud948\udd09", "\u935a\u43c0\u6dad", "\udbba\udf23\ud8c4\udcef\ud9e5\udd04\u9551\udb61\udda2\u51dc\ud9f4\udcf8\udb2b\udc0f",
        44, 89780, 1503161982, 2711547157537602532L, 66532L, false, true, (char) 6244, (char) 51681,
        Double.longBitsToDouble(0x3fe2b114b0ea5ba7L), Double.longBitsToDouble(0x3fd624d653e7eb9aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 5, 1, 0, "\ud89e\udf52\uda66\udcdb\uda72\udd9e\ud976\uddb2\ud999\uded5\uda02\ude40\udb15\uddd6\ud8e2\udd40\ud87d\ude2d\ud948\udd09\ud9cf\udd29\ud901\ude22\ud954\udebb\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbba\udf23\u22d2\uda9e\udc75\uda8d\uddfc\udb41\udd69\u383b\uda63\udcee\ud873\udcf9", "\uac3e", "\uda56\udd62\ud9fc\udf8b\udbe2\udd3c\udadd\udffa\ud8fb\udf39",
        -2, 58293, -1378200583, -6962721066414051573L, -73496L, false, true, (char) 59236, (char) 5942,
        Double.longBitsToDouble(0x3fcb9dfa2cf7df54L), Double.longBitsToDouble(0x3fd9fec3c164049cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 17, 13, 0, "\u7ea4", "\ub497\u0fde\u9ffa\u4332\uc3b8\u4adc\u1a3a\u9ca1\uccdf\ud34b\ucc62\u68f5\u902f\ud5b1\uacb7\u7312", "\udbf1\udeda\uc805\udbea\ude21\udb2a\udffc\ud83e\udca2\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\uda56\udd62\uda11\udc0c",
        10, 20391, -2123719139, -2826346695674457227L, -77584L, false, true, (char) 26069, (char) 18492,
        Double.longBitsToDouble(0x3fe421af90104e95L), Double.longBitsToDouble(0x3fa9394d93a41dc0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\uda66\udcdb\uda2f\udcde\ud976\udde2\ud999\uded5\uda06\ude5c\ud82f\udc61\udb17\udd17\udbbc\uddf9\ud9f4\udf37\uda37\udebd\ud91a\udde5\u1c95\ud85c\udf39\ud901\udc30\ud996\udf43\uda7e\udf8a\ud826\udd6d\ud9ba\ude01\ud9e5\udd04\u9551\udb61\udda2\ud8ff\udd31\ud911\udcb5\udb2a\udffc\uda4c\udd08 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\uda66\udcdb\uda2f\udcde\ud976\udde2\ud999\uded5\uda06\ude5c\ud82f\udc61\udb17\udd17\udbbc\uddf9\ud9f4\udf37\uda37\udebd\ud91a\udde5\u1c95\ud85c\udf39\ud901\udc30\ud996\udf43\uda7e\udf8a\ud826\udd6d\ud9ba\ude01\ud9e5\udd04\u9551\udb61\udda2\ud8ff\udd31\ud911\udcb5\udb2a\udffc\uda4c\udd08\012",
        Z.run(T, 1, 14, 14, 6, "\ud89e\udf52\uda66\udcdb\uda2f\udcde\ud976\udde2\ud999\uded5\uda06\ude5c\ud82f\udc61\udb17\udd17\udbbc\uddf9\ud9f4\udf37\uda37\udebd\ud91a\udde5\u1c95\ud85c\udf39\ud901\udc30\ud996\udf43\uda7e\udf8a\ud826\udd6d\ud9ba\ude01\ud9e5\udd04\u9551\udb61\udda2\ud8ff\udd31\ud911\udcb5\udb2a\udffc\uda4c\udd08", "\u6daa\u2047\u8b3a\u8f44\u0c4e\uc010\u3150\u162b\u6077\uc797\ub1d6\u3de1\u2921\ua08f\u1281", "\ud97a\ude56\ud8e6\ude24\ud8b2\udcc4\uff2b\ud9ac\udfc1\ud92a\udcca\udbee\udd4b\ud913\udc48\ud99e\ude91\ud824\udc22\ud9b4\udde6\udab9\udfb4\ud9de\udcb3\ud942\uded9\ud899\udf75\udbae\ude6c\ud82e\ude50\ud9a2\udf73\uda67\udc3d\ud94a\udc68",
        51, 82135, -1010428543, -2650366440427405436L, 25912L, true, false, (char) 32359, (char) 21790,
        Double.longBitsToDouble(0x3fdc41f1da2349f8L), Double.longBitsToDouble(0x3fcd3ae18562208cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\udb22\udf54\ud963\udcfa\udaa9\ude3a\ud99b\udc28 |this=org.apache.commons.lang.text.StrBuilder:\udb22\udf54\ud963\udcfa\udaa9\ude3a\ud99b\udc28\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 15, 10, "\udb22\udf54\ud963\udcfa\udaa9\ude3a\ud99b\udc28", "\u3f0f\u5a88\u8cdc\u4d3a\u0ba2\u8c94\ub411\uc36f\u86a1", "\udbb2\udffa\ud9cf\udcb6\ud9cd\ude37\udacc\ude84\uda7a\ude61\udb34\ude23\udab1\ude37\udae2\uddb5",
        42, 44853, 593835376, -9141999264759432819L, -87307L, false, true, (char) 52776, (char) 21403,
        Double.longBitsToDouble(0x3fc2c03ace127b18L), Double.longBitsToDouble(0x3fefcd42fc9179daL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 15, 4, "\ud89e\udf52\ud885\udf2c\udaa9\udf1b\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23",
        45, 59198, 1562486740, 1618543578652948130L, -41354L, true, true, (char) 1072, (char) 64639,
        Double.longBitsToDouble(0x3fd1179387c84b42L), Double.longBitsToDouble(0x3fe5dfe5fe7ca54cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 14, 2, 16, "\ud89e\udf52\ud878\udc44\uda95\udf82\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u1b03\u6802\ud33e\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\uda18\udd13\uda4d\udf26\ud9ae\udcf5\udb2a\udffc",
        7, 90752, 2033739099, 2711546381586815644L, -87324L, false, true, (char) 21308, (char) 32020,
        Double.longBitsToDouble(0x3fe74ec394458e90L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 17, 0, 7, "\ud8ad\ude3d\uda66\udcdb\udaa9\ude3a\ud976\udde2\ud999\uded5\ud9d8\ude40\udb2a\udce4\u3855", "\ub278\u2e0f\u8450\u8737\uaf20\u8fe8\uce06\ua21e\u8706\u3dbb", "\ud8be\udf7a\ud95c\ude4c\udb2a\udffc",
        54, 65200, 2041153824, 7206360910074831551L, -87324L, true, false, (char) 42644, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d4dd76318L), Double.longBitsToDouble(0x3fefcd41ca9179daL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\012",
        Z.run(T, 2, 14, 18, 4, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2", "\u18d6\u6dc4\u4a83\u1a3a\u4bc5\u40e5\u0c6c\uc36f\u5ea0", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\udb83\udff4\uda9a\udeb5\udaa8\ude9e",
        53, 90752, 2043906364, 2711546381506129840L, 43033L, true, false, (char) 19986, (char) 34475,
        Double.longBitsToDouble(0x3fe3136bfa91798bL), Double.longBitsToDouble(0x3fc507b8162fef58L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 13, 8, 4, "\ud930\udf5e\ud932\udce1\udaa9\ude3a\ud976\udde2", "\ub1b5\uc03e\u4a77\u1a3a\ud024\ud5f7\u0c6c\uc36f\u9d25", "\udbba\udf23\ua382",
        29, 19704, 1340475465, 2627049341014524231L, 20974L, false, false, (char) 8288, (char) 53988,
        Double.longBitsToDouble(0x3fef212d0ebbfcbfL), Double.longBitsToDouble(0x3fe3e33a61b0df5bL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 15, 4, "\000", "\u3129\u0fde\u3a0e\u3f0f\uc3c9\u4adc\ucb68\000\000\000\000\u2944\u8fb7\ua266\uacb7\u8706\u93f2\u3e35\u2b6e\ua9d7\ud2de\u00ea\u2740\000", "\ubb00\000\ud9e7\ude13\ud9e0\ude42\udadd\udffa\ud8f5\udeb5",
        -5, -1000, 2044351481, 4449796748077363368L, -72595L, true, false, (char) 30783, (char) 2143,
        Double.longBitsToDouble(0x3fe793f053a306cbL), Double.longBitsToDouble(0x3fe24104aa3817c6L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ue61d |this=org.apache.commons.lang.text.StrBuilder:\ue61d\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 9, 4, "\ud89e\udf52\ud932\udce1\ud9f3\udc7f\ud955\udce5", "\u0823\uc30d\u4adc\u1a3a\ud024\ud5f7\u0c6c\uc36f\u0e0d", "\udad7\udc0a\udb6c\udf67\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0",
        54, 97608, 2043906364, 2711546378857545476L, 55872L, false, false, (char) 58909, (char) 60130,
        Double.longBitsToDouble(0x3f97bc606ebb18c0L), Double.longBitsToDouble(0x3fe44cc9cadfac48L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\u4e12 |this=org.apache.commons.lang.text.StrBuilder:\u4e12\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\u4e12\012",
        Z.run(T, 2, 7, 18, 18, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\ud024\ud5f7\u0c6c\uc36f\u86a1", "\udbba\udf23\uda0f\udfc2\ud97e\udc67\u9551\udb3d\udca6\u68c8\ud9ae\udcf5\ud814\udcf0",
        44, 36280, 2043906471, 8476153903182756836L, 42994L, true, false, (char) 19986, (char) 27707,
        Double.longBitsToDouble(0x3fefcd41ca9179daL), Double.longBitsToDouble(0x3fc507b8162fef58L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 9, 8, 15, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\udaa9\udc13\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud87d\ude2d\ud8a6\udf1e\ud96d\udff2\ud883\udf65\udbea\udd37\ud85c\udf08\uda51\ude1a\ud996\udf39\u77c0\udbba\udf23\ud8c4\udcef\ud933\ude58\ud96e\udc86\udb74\ude4b\u68c8\ud9ae\udcf5\ud814\udcf0", "\u919f\u6daa\u8009\ua128\u0fc6\u7a49\u8bbb\uc8a7", "\ud934\udf27\uda7f\ude34\ud8c0\udc69",
        19, 96518, -621353082, -2961608868898696684L, -26781L, false, true, (char) 26659, (char) 46440,
        Double.longBitsToDouble(0x3fea60be39e5cddcL), Double.longBitsToDouble(0x3fdb4b24569e7d7eL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud87d\ude2d\ud948\udd09\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc30\ud826\udf49\udba6\udde2\udbba\ude3a\ud8c4\udcef\ud98b\udf05\udb7a\udcfa\udb57\ude2c\u68e9\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud8fb\udf39\ud832\udfc6\udb0f\ude57\ud934\udf27\uda7f\ude34\ud8bf\udfee\udb51\udcd7\ud947\udf6e\uda97\udf9a\u0563\ud852\udf16\udaca\udf88\u3f9c\ud8b7\udd4e |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud87d\ude2d\ud948\udd09\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc30\ud826\udf49\udba6\udde2\udbba\ude3a\ud8c4\udcef\ud98b\udf05\udb7a\udcfa\udb57\ude2c\u68e9\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud8fb\udf39\ud832\udfc6\udb0f\ude57\ud934\udf27\uda7f\ude34\ud8bf\udfee\udb51\udcd7\ud947\udf6e\uda97\udf9a\u0563\ud852\udf16\udaca\udf88\u3f9c\ud8b7\udd4e\0121=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud87d\ude2d\ud948\udd09\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc30\ud826\udf49\udba6\udde2\udbba\ude3a\ud8c4\udcef\ud98b\udf05\udb7a\udcfa\udb57\ude2c\u68e9\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud8fb\udf39\ud832\udfc6\udb0f\ude57\ud934\udf27\uda7f\ude34\ud8bf\udfee\udb51\udcd7\ud947\udf6e\uda97\udf9a\u0563\ud852\udf16\udaca\udf88\u3f9c\ud8b7\udd4efalse |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud87d\ude2d\ud948\udd09\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc30\ud826\udf49\udba6\udde2\udbba\ude3a\ud8c4\udcef\ud98b\udf05\udb7a\udcfa\udb57\ude2c\u68e9\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud8fb\udf39\ud832\udfc6\udb0f\ude57\ud934\udf27\uda7f\ude34\ud8bf\udfee\udb51\udcd7\ud947\udf6e\uda97\udf9a\u0563\ud852\udf16\udaca\udf88\u3f9c\ud8b7\udd4efalse\012",
        Z.run(T, 2, 14, 6, 17, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\ud87d\ude2d\ud948\udd09\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc30\ud826\udf49\udba6\udde2\udbba\ude3a\ud8c4\udcef\ud98b\udf05\udb7a\udcfa\udb57\ude2c\u68e9\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud8fb\udf39\ud832\udfc6\udb0f\ude57\ud934\udf27\uda7f\ude34\ud8bf\udfee\udb51\udcd7\ud947\udf6e\uda97\udf9a\u0563\ud852\udf16\udaca\udf88\u3f9c\ud8b7\udd4e", "\u7a62\u9b44\u1bbf\uc4c1\u2fce\u07a5\uc1fe\u37da\u743b\ud22c\u49e5\u5224\ub7ee\u2197", "\ud9d5\udd84\ud941\udf36\ud907\udf3c\uda22\udc0e\u136b\uda25\ude52\u450d\udadc\udd22\ud843\udf26\ud8fc\udfc4\ud97f\udf05\ud9de\udcf0\ud9e8\udf1d\ud8de\udc23\ud983\udeff\udb73\udcb6\ud85d\udd95\udb5f\uded4",
        51, 39279, -1377495415, 102975121022398655L, -60872L, false, false, (char) 29159, (char) 62693,
        Double.longBitsToDouble(0x3febd183a7627944L), Double.longBitsToDouble(0x3fc46360e0fbcec4L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.8071427805436314 |this=org.apache.commons.lang.text.StrBuilder:0.8071427805436314\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:0.8071427805436314\012",
        Z.run(T, 2, 10, 16, 8, "\ud8d4\udf59\ud932\udce1\udaa9\ude3a\udb64\uddb9\udb8e\udc7f\uda02\uddb8\udb2d\udcee\uda39\ude47\ud873\udc14\ud948\udd09\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc93\ud996\udf43\ud8d9\udc1d\udb4e\udde1\udac6\uded2\ud98b\udf05\ud927\udd51\udbf5\udfc8\udb58\udccd", "\u32f4\u9648\ube3d\u6daa\u8009\u0ec3\u69a2\u6978\u3f4a\uc8a7", "\ud934\udf27\ue7d9\ud8c0\udc69",
        28, 64715, 1446119619, -2437096236430310067L, -86107L, false, true, (char) 57184, (char) 12962,
        Double.longBitsToDouble(0x3fe9d41d18b46599L), Double.longBitsToDouble(0x3fec84824cb24676L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 16, 16, 4, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\ud024\ud5f7\u0c6c\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb70\ude60\u68c8\ud9ae\udcf5\ud812\udc15",
        44, 90752, 2043906364, 2711546380148521956L, 43033L, true, false, (char) 19986, (char) 27707,
        Double.longBitsToDouble(0x3fefcd41ca9179daL), Double.longBitsToDouble(0x3fc507b8162fef58L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 2, 18, 13, "\ud8ca\uddfc\ud951\udfb7\udaa9\ude3a\ud976\udde2\ud999\uded5\ud961\udcaf\ud82f\udc61\u38d2\ud87d\ude2d\ud9b9\udf03\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc30\udb0b\ude44\u77c5\udbba\udf23\ud8c4\udcef\ud992\ude05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda0f\udf8c\ud9e0\ude42\udadd\udffa\ud8fb\udf39\ud8d4\ude58\udb0b\ude48\udb78\udeaa\udb07\udfa8\ud8b1\udcc9\ud84b\ude35", "\u18be", "\udb8e\udf66\uda6e\udf6d\ud949\udc15\udb64\udef7\udaf8\udfae\ud811\udf47\ud8b5\udd0a\ud9c9\udd0d\udbca\udf83\ud984\udfe2",
        42, 40599, 1477495655, -5868048091412390978L, -23137L, true, false, (char) 43735, (char) 55365,
        Double.longBitsToDouble(0x3fef819242fa1313L), Double.longBitsToDouble(0x3fd60bc4ee0ba77aL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.2953825 |this=org.apache.commons.lang.text.StrBuilder:0.2953825\0121=org.apache.commons.lang.text.StrBuilder:0.2953825\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2 |this=org.apache.commons.lang.text.StrBuilder:0.2953825\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2\012",
        Z.run(T, 2, 11, 13, 0, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\u38d2", "\ud024\ud5f7\u0c6c\uc36f\u86a1\u8fb7\ud5b1\uacb7\u369a\u40cd", "\udae9\udd2f\ud884\udf39\ud814\udc42\udb0e\udd74\ud830\ude55\udbc0\udcfc\udac6\udf48",
        57, 82851, -547631492, -9082087333398195897L, 62280L, false, true, (char) 64562, (char) 21611,
        Double.longBitsToDouble(0x3fd2e78c0b17f7acL), Double.longBitsToDouble(0x3fc69621b045ff3cL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ueefd |this=org.apache.commons.lang.text.StrBuilder:\ueefd\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\ueefd\012",
        Z.run(T, 2, 7, 16, 4, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\ucd39\ud024\ud5f7\u0c6c", "\ud996\udf43\u77c0\udbba\udf23\ud867\ude6d\ud98b\udf65\u9551\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\uda49\udcda\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud8fb\udf39\ud8d4\ude58",
        23, 71345, 1036049132, -299973832826888821L, 72875L, false, true, (char) 61181, (char) 49127,
        Double.longBitsToDouble(0x3fd8458cc3be3a5aL), Double.longBitsToDouble(0x3fe74cecc438ba51L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\u4e12 |this=org.apache.commons.lang.text.StrBuilder:\u4e12\0121=org.apache.commons.lang.text.StrBuilder:\u4e12\u4e12 |this=org.apache.commons.lang.text.StrBuilder:\u4e12\u4e12\012",
        Z.run(T, 2, 7, 7, 8, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\ud024\ud5f7\u0c6c\uc36f\uc6c9", "\udbba\udf23\ud8c4\udcef\udb68\udf92\u9551\udb3e\ude26\u68c8\ud9ae\udcf5\ud814\udcf0",
        44, 90752, 2043906364, 2711546380148521956L, 43033L, true, false, (char) 19986, (char) 27707,
        Double.longBitsToDouble(0x3fefcd41cf9179daL), Double.longBitsToDouble(0x3fc519a9362fef58L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2 |a0=[C:[[\ud89e, \udf52, \ud932, \udce1, \udaa9, \ude3a, \ud976, \udde2]] |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\0121=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2 |a0=[C:[[\ud89e, \udf52, \ud932, \udce1, \udaa9, \ude3a, \ud976, \udde2]] |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\012",
        Z.run(T, 2, 8, 8, 4, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u116d\ud087\ud5f7\u0c6c\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0",
        44, 90752, 2043906364, 2711546380148521956L, -21320L, true, true, (char) 64562, (char) 21611,
        Double.longBitsToDouble(0x3fc507b8162fef58L), Double.longBitsToDouble(0x3feddd00de5d5615L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |a0=[C:[[]] |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 13, 8, 0, "", "\u10af\u3129\u0fde", "\000\ud858\udd8c\ud948\udd09\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc30\ud92b\ude6e\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05",
        30, 14543, 611661474, -389489595131684118L, -11663L, false, true, (char) 7035, (char) 13768,
        Double.longBitsToDouble(0x3fdb0df5b28f03eaL), Double.longBitsToDouble(0x3fe57b8dcca8816aL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud893\udc57\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ud819\udd23\udbfb\ude9a\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\ud996\udf65\u77d0\ud9cc\ude2a\ud8c4\udcee\udb0d\ude77\uc29c\udb74\ude21\udbf6\udfc3\ud96d\udcd5\ud827\udd04\ud923\uddec\uefa9\udbc0\udcf4\udac6\udf48\ud8e6\udf26\uda56\udcdb\udb33\udec3\ud9de\udece\ud84b\ude8e\ud8ba\udccb\udb2d\udc1b\ud9a6\udf86\uda50\udee1\ud9f7\udf2a\u80c3 |a0=[C:[[\ud893, \udc57, \udaa2, \ude40, \udb95, \udf91, \ud89d, \ude1b, \ud999, \udf89, \udbf7, \udd3b, \ud82f, \udc61, \ud99a, \udcd7, \ud819, \udd23, \udbfb, \ude9a, \uda99, \udf30, \uda84, \udf9b, \ud952, \udd7a, \uda11, \udde9, \ud830, \udd30, \ud996, \udf65, \u77d0, \ud9cc, \ude2a, \ud8c4, \udcee, \udb0d, \ude77, \uc29c, \udb74, \ude21, \udbf6, \udfc3, \ud96d, \udcd5, \ud827, \udd04, \ud923, \uddec, \uefa9, \udbc0, \udcf4, \udac6, \udf48, \ud8e6, \udf26, \uda56, \udcdb, \udb33, \udec3, \ud9de, \udece, \ud84b, \ude8e, \ud8ba, \udccb, \udb2d, \udc1b, \ud9a6, \udf86, \uda50, \udee1, \ud9f7, \udf2a, \u80c3]] |this=org.apache.commons.lang.text.StrBuilder:\ud893\udc57\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ud819\udd23\udbfb\ude9a\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\ud996\udf65\u77d0\ud9cc\ude2a\ud8c4\udcee\udb0d\ude77\uc29c\udb74\ude21\udbf6\udfc3\ud96d\udcd5\ud827\udd04\ud923\uddec\uefa9\udbc0\udcf4\udac6\udf48\ud8e6\udf26\uda56\udcdb\udb33\udec3\ud9de\udece\ud84b\ude8e\ud8ba\udccb\udb2d\udc1b\ud9a6\udf86\uda50\udee1\ud9f7\udf2a\u80c3\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 9, 19, "\ud893\udc57\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ud819\udd23\udbfb\ude9a\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\ud996\udf65\u77d0\ud9cc\ude2a\ud8c4\udcee\udb0d\ude77\uc29c\udb74\ude21\udbf6\udfc3\ud96d\udcd5\ud827\udd04\ud923\uddec\uefa9\udbc0\udcf4\udac6\udf48\ud8e6\udf26\uda56\udcdb\udb33\udec3\ud9de\udece\ud84b\ude8e\ud8ba\udccb\udb2d\udc1b\ud9a6\udf86\uda50\udee1\ud9f7\udf2a\u80c3", "\u9f16\u7cf0\u2efe\u60fa\ud6b2\u58bc\u8ba9", "\ud8fc\uddb1\ud9db\udf21\ud808\udd19\ud96e\udda4\uda48\udfa6\ud8b8\udfce\ud99a\udedb\udbcf\ude28\udbe5\udcb3\ud88c\udcf7\uda3f\udf9f\uda03\ude8e\ud80e\udcac\ud8bb\udfab\ud80a\ude5e\uda97\udd25\ud821\udea9\udbb0\uded2\udb58\udd4e\udbbf\udf58",
        20, 71787, -739917924, 1884888729999937109L, 51810L, true, true, (char) 16708, (char) 53256,
        Double.longBitsToDouble(0x3fe0194763367b8bL), Double.longBitsToDouble(0x3fe45dc285fe2185L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.9251605908118073 |this=org.apache.commons.lang.text.StrBuilder:0.9251605908118073\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:0.9251605908118073\012",
        Z.run(T, 2, 10, 2, 16, "\udbae\udfb5\udb36\udcbd\uda8f\udc58\ud8ba\uddc4", "\u3f0f\u3f05\u4eca\uccfb\u9c2f\u2e0f", "\udbe6\udc0e",
        34, 37767, 619348153, 2437035570870465910L, -19921L, true, false, (char) 26044, (char) 56869,
        Double.longBitsToDouble(0x3fed9aea6222b647L), Double.longBitsToDouble(0x3fe1e4bff03d3bf7L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 9, 18, 4, "\ud89b\udc0d\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\ucc36\u4adc\u1a3a\u9ca1\u2e0f\ud33e\uc36f\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u36a2\ud9cb\udfa5\u00ea",
        -5, 90752, 2043906364, 2711546380148521956L, -34464L, true, false, (char) 19986, (char) 37946,
        Double.longBitsToDouble(0x3fefcd41c80079daL), Double.longBitsToDouble(0x3fe861bb6f1acd71L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:22 |this=org.apache.commons.lang.text.StrBuilder:22\0121=org.apache.commons.lang.text.StrBuilder:2222 |this=org.apache.commons.lang.text.StrBuilder:2222\012",
        Z.run(T, 2, 12, 12, 9, "\ud89e\udf52\uda66\udcdb\udb0d\udc36\ud976\udde2", "\ucfff\u894c\u4adc\u47a6\u9ca1\u2e47\ud2d4\u9870\u86a1\u8fb7\u85fe\u7c5a\u8706\u93f2", "\udb85\uddc3\ud9ae\udcf5\udb2a\udffc\uda10\udecc",
        22, 69364, 631315217, -234262911008366917L, 34716L, true, true, (char) 4200, (char) 19986,
        Double.longBitsToDouble(0x3febaec633f9a839L), Double.longBitsToDouble(0x3fe48bced4f2d559L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 0, 2, 16, "\ud83f\ude83\udbc2\ude96\ud918\udea3\ud8fc\udd26\udb28\udc37\ud941\udfd3\udbfa\udd79\ud944\ude28\udbd0\udd8c\ud992\udc37\udb2d\udeb7\uda9d\udd77\ud8ca\ude17\ud801\udd75\udb00\uddc1\ud890\udcf7\ud80b\udd9b\udbef\udecc\ud8b4\ude25\ud8e0\udd04", "\uc384\u5cf7\uc566\u12f4\u9fc4\u9671\ub344\u62dc\u64e4\u123f\uae3c\u23ac\u1829\u3c80\u394c", "\ud976\udddf\udb8d\udc16\ufd44\ud917\udd77\ud88f\udd3b\u0bfb\uda52\udceb\uda28\udda2\ud873\ude72\udab9\uddef\udabe\udec2\ud958\udc92\udba1\udf1a\udb48\udc71\udad0\udded\udb06\udc11\ud852\ude6b\ud87b\udc57\ud924\udf8e\ud97d\udde7\ud9f1\udce5\udbbd\udef9\uda9d\udebe\ud82d\udcf6\udbe8\udee7\udb10\udf29\udbec\ude4f\ud9b7\udc33\ud851\ude2f\ud917\ude53\ud886\udcbf\ud9e8\udead\ud9d6\udd0c\ud941\ude7b\udaca\ude71\ud84c\udf72\udb13\uddec\udad4\udc4e\ud990\udc76\ud817\udc6e\udb29\udd7a\udaf4\udf83\uda4e\udda5\udbc1\ude4e\ud9c2\ude7f\udbf8\udc58\udada\udfe3\ud879\udfc7\udade\ude2f\udb5f\udcbb",
        2, 92731, -569028261, 163362976195696602L, 3238L, false, true, (char) 19540, (char) 25928,
        Double.longBitsToDouble(0x3fe3aa0b3052547bL), Double.longBitsToDouble(0x3fef51896d1445e3L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 4, 20, 4, "\ud89e\udf52\000\udaa9\ude3a\ud976\udde2", "\u3f0f", "\ud948\udd09\ud9cf\udd29\ubc9a\ud954\udeae\ud85c\udeac\ud901\udc30\ud996\udf43",
        20, 15215, 567416561, 52272390662520832L, -100000L, true, true, (char) 0, (char) 14187,
        Double.longBitsToDouble(0x3fc21633e0000000L), Double.longBitsToDouble(0x3fe94bc803e454e6L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 8, 8, 4, "\ud89e\udf52\udb7d\udd30\udaa9\ude3a\ud976\udde2", "\ub407\uc2d0\uad36\u1a3a\ub863\u549d\u9a5a\u82e2\u3710", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\uda4b\udee4\ud81e\ude66\udb00\udee0\uda27\ude6d\udb2a\udffc",
        7, 83296, 2043906403, 2711546380148521956L, -87324L, false, true, (char) 21308, (char) 4036,
        Double.longBitsToDouble(0x3fc5102d5ec2e318L), Double.longBitsToDouble(0x3fed3ccc92603f85L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 0, 14, 0, "", "\u0cac\ud0d2\u0fde", "\000",
        -5, -1000, 0, -1513209474796466033L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3feea495ce000000L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 11, 10, "\ud8d9\udc8e\uda95\udfdb\udaa9\ude3a\udbcd\udfdf\udb69\udd62\udb28\udee6\udbf4\udcd5\ud9fc\ude8f\ud9ec\uded2\ud936\uddc1\uda20\ude28\ubcbb\ud954\udeae\udbbe\udd59\ud901\udc30\ud9ab\udf43\u70c0\udb8b\udc48\uda7e\ude87\ud98b\udf05\uda67\udd51\udb31\udd80\udae0\udff2\ud967\udc89\ud802\udc70\ud9c8\udd68\ue462\udbc0\udc69\ud924\udee1\u8eb6\uda56\udd62\ud8d4\udeeb\udac7\ude5e\ud8a6\udf2d\udb06\uddcf\uda83\udc1e\udb8d\udd4b\ud921\udd55", "\ud674\u7fe5\u41e0\u8165\u4345\u0e7b\ub4e8\u430a\ud681\u27ea", "\uda89\udc7e\udb2a\udfe1\uda0b\udd99",
        31, -773, -38251821, 8828409520573426307L, 21905L, true, false, (char) 26026, (char) 31432,
        Double.longBitsToDouble(0x3fbea41e4cb0f050L), Double.longBitsToDouble(0x3fce3a6ce04ccc48L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 19, 3, 11, "\ud8e7\udf3b", "\u8230\u0fda\u3a0e\u3f0f\u14ab\u4adc\ua617\u9142\u2e0f\u31bc\uc36f\u86a1\u75cf\ud5b1\u0f17\ub877\u8ed5", "\u68c8\ud8ea\udf94\ud8bb\udd0e\udaee\udff4",
        5, 69364, 631331089, -234262067734503749L, 24046L, true, true, (char) 14410, (char) 27962,
        Double.longBitsToDouble(0x3fe4c68803f9a81dL), Double.longBitsToDouble(0x3fe48bced6991a59L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 9, 8, 4, "\u0744\ud95a\ude4c\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u2783\u9ca1\u2e0f\000\000\u86a1", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud866\udcf1\udb2a\udffc",
        7, -1000, 2043906304, 0L, -100000L, false, true, (char) 21308, (char) 4200,
        Double.longBitsToDouble(0x3fc5102d40000000L), Double.longBitsToDouble(0x3fefcd41c89100daL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:-1 |this=org.apache.commons.lang.text.StrBuilder:-1\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:-1\012",
        Z.run(T, 2, 12, 18, 14, "\ud802\udce8", "\u84e4\ub2ce", "\u38d2\ud87d\ude2d\ud82a\udebb\ud90f\udff5\uaf2f\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbba\udf23\ud8c3\udffe\ud9e1\ude3a",
        -1, 8543, 1797159800, 2438892005968699860L, 79689L, true, false, (char) 53972, (char) 45439,
        Double.longBitsToDouble(0x3fa4b07226dbe2e0L), Double.longBitsToDouble(0x3feafb6c1e95951aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.8561917 |this=org.apache.commons.lang.text.StrBuilder:0.8561917\0121=org.apache.commons.lang.text.StrBuilder:0.85619170.8561917 |this=org.apache.commons.lang.text.StrBuilder:0.85619170.8561917\012",
        Z.run(T, 2, 11, 11, 1, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2\ud9a5\uddd5", "\uc3c9\u4adc\u1a3a\u9ca1\u2e0f\u9894\u5a48\u240d\u31ca\u4b7d\ua909\u8706\ua8b0", "\u68c8\ud9ae\udcf5\udb2a\udffc\uda10\udecc",
        11, 54398, -607043682, 6763744400345811131L, 34736L, true, true, (char) 26912, (char) 62246,
        Double.longBitsToDouble(0x3feb65ec23f9a839L), Double.longBitsToDouble(0x3fe48bced40223d2L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 15, 8, "\ud89e\udf52\uda8e\ude1f\udaa9\ude3a\ud95b\udf7f\ud999\uded5\uda02\ude40\uda8a\udcae\uda02\udd1c\ud967\ude82\ud816\udd89\ud8eb\uded1", "\ub55e\u870d\u7336\ud5b1\uacb7\u8706\u93f2\u3e35\u2b6e\u0356\u94b9", "\ue462\udae9\udcb1\ud9e3\udc13\udbad\ude31\ud9e6\udd6a",
        3, -482, 1908007495, -6917636028819410976L, -2206L, true, false, (char) 8616, (char) 61411,
        Double.longBitsToDouble(0x3fe6f3716a975b4cL), Double.longBitsToDouble(0x3fd1a7bc8585cbd6L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.621724315270494 |this=org.apache.commons.lang.text.StrBuilder:0.621724315270494\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:0.621724315270494\012",
        Z.run(T, 2, 10, 17, 8, "\ud89e\udf52\uda66\udcdb\uda7b\udc3c\ud976\udde2", "\u3f0f\u9d6a\u0a7e\u9e5f\u3ef4\u3d93\ud33e\ub55e\u86a1", "\udbba\udf23\ud8c4\udcef\ud99c\ude06\u9551",
        3, 4474, -90685113, -8469270983237224597L, 2357L, true, true, (char) 10482, (char) 7035,
        Double.longBitsToDouble(0x3fe3e52a6426df5bL), Double.longBitsToDouble(0x3fd47d354d5ee372L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 15, 15, 8, "\ud979\udc11\ud843\udc9b\udaa9\ude3a\ud976\udde2", "\u7252\u1d00\u34a6\u9dfb\u5908\u8cdf\ud33e\ud43e\u86a1", "\udbba\udf23\udb4c\udc14\ud911\udcba\ud99f\ude0a",
        52, 4474, -1583201977, -6629279629022847753L, 2357L, true, true, (char) 10482, (char) 7035,
        Double.longBitsToDouble(0x3fe84d2a62e1c460L), Double.longBitsToDouble(0x3fd47d3dbaf6e372L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:false |this=org.apache.commons.lang.text.StrBuilder:false\0121=java.lang.Integer:5 |this=org.apache.commons.lang.text.StrBuilder:false\012",
        Z.run(T, 2, 6, 0, 19, "\u0f45\000\000\ud976\udd67", "\u3f0f", "\ud816\udd89\udaa4\uddca\000\ud954\udeae\ud88f\udcf6\ud901\udc30\ud996\udf43",
        20, 15215, 567416561, -7874062953507346476L, -100000L, false, false, (char) 0, (char) 35447,
        Double.longBitsToDouble(0x3df5cb9200000000L), Double.longBitsToDouble(0x3fd00c50ecc7d51cL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.2824624413938116 |this=org.apache.commons.lang.text.StrBuilder:0.2824624413938116\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:0.2824624413938116\012",
        Z.run(T, 2, 10, 17, 0, "\uda26\udda0\ud880\udf98", "\u0fde\u4a08\u3f0f\uc3c9\u80eb\u1a3a\u9ca1\uccdf\u935a\u43c0\u6dad\u8fb7\ub2bb\uacb7\u8706", "\ud827\ude3c\udb87\udda9\uda36\udf37\ud872\ude46\udbd7\udfce\ud9a5\udd61\ud801\udf37\uda7a\udf30\udbcc\udfb2",
        17, 86396, 290124208, 4019189001282294299L, -26038L, false, true, (char) 63424, (char) 19555,
        Double.longBitsToDouble(0x3fd213dd59089f8aL), Double.longBitsToDouble(0x3fd12a23e1e76c4aL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 17, 1, 0, "\ud89e\udf52\uda66\udcdb\uda72\udd9e\ud976\uddb2\ud999\uded5\uda02\ude40\udb15\uddd6\ud8e2\udd40\ud87d\ude2d\ud948\udd09\ud9cf\udd29\ud901\ude22\ud954\udebb\ud85c\udf08\ud923\ude30\ud996\udf43\u77c0\udbba\udf23\u22d2\uda9e\udc75\uda8d\uddfc\udb41\udd69\u383b\uda63\udcee\ud873\udcf9", "\uac3e", "\uda56\udd62\ud9fc\udf8b\udbe2\udd3c\udadd\udffa\ud8fb\udf39",
        -2, 58293, -1378200583, -6962721066414051573L, -73496L, false, true, (char) 59236, (char) 5942,
        Double.longBitsToDouble(0x3fcb9dfa2cf7df54L), Double.longBitsToDouble(0x3fd9fec3c164049cL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud878\udc44\uda96\udc1e\uda32\udd41\ud9b8\udcf1\udad7\uddda\ud82f\udca5\ud9ed\uddc1\udb05\udda3\ud948\udd09\uda06\udecc\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\udbef\uddc7\udbba\udf23 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud878\udc44\uda96\udc1e\uda32\udd41\ud9b8\udcf1\udad7\uddda\ud82f\udca5\ud9ed\uddc1\udb05\udda3\ud948\udd09\uda06\udecc\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\udbef\uddc7\udbba\udf23\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 9, 19, "\ud89e\udf52\ud878\udc44\uda96\udc1e\uda32\udd41\ud9b8\udcf1\udad7\uddda\ud82f\udca5\ud9ed\uddc1\udb05\udda3\ud948\udd09\uda06\udecc\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\udbef\uddc7\udbba\udf23", "\u3e35\u8e31\u118b\u8080\ub9fc\ub3fd", "\udac6\udf87\ud911\udf78\uda73\udfe0\ud9d3\udc8b\ud9e0\ude42\udb05\udfee\ud8f7\uddc0\uda90\udfa3\udb21\udf18\ud934\udf27\uda59\udee2\udabe\udf83\udb0c\udfac\ud833\udd06\ud98a\uddc8",
        -3, 476, -1712190807, 5167916550745196500L, -33394L, true, true, (char) 64864, (char) 53243,
        Double.longBitsToDouble(0x3fecbbc19f568decL), Double.longBitsToDouble(0x3fe2319313ec7249L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\udaef\udd6b\ud87f\udf39\ud8ce\udd9e\udbbd\uddcd\ud9a5\ude57\udaf7\udfd1\ud926\udcc4\uc781\ud8ff\ude6d\ud92a\udc6a\ud9f2\udd5a\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbc8\udd23\ud8c4\udcef |this=org.apache.commons.lang.text.StrBuilder:\udaef\udd6b\ud87f\udf39\ud8ce\udd9e\udbbd\uddcd\ud9a5\ude57\udaf7\udfd1\ud926\udcc4\uc781\ud8ff\ude6d\ud92a\udc6a\ud9f2\udd5a\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbc8\udd23\ud8c4\udcef\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\udaef\udd6b\ud87f\udf39\ud8ce\udd9e\udbbd\uddcd\ud9a5\ude57\udaf7\udfd1\ud926\udcc4\uc781\ud8ff\ude6d\ud92a\udc6a\ud9f2\udd5a\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbc8\udd23\ud8c4\udcef\012",
        Z.run(T, 2, 14, 2, 16, "\udaef\udd6b\ud87f\udf39\ud8ce\udd9e\udbbd\uddcd\ud9a5\ude57\udaf7\udfd1\ud926\udcc4\uc781\ud8ff\ude6d\ud92a\udc6a\ud9f2\udd5a\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbc8\udd23\ud8c4\udcef", "\u06bb\u118b\ud2de\u5f9c\u1286\u40f4\u2375\u633f\ubc4f\u0212\ua139\u0e7a\u1bb7\u8d44\u6c77\ud020\u9c20\u6d25\u3ed8\u0ba6\u493f\u014a\u78c2\u22da\u6162\u5dd6", "\ud80c\udd25\ud91c\udc0f\ud82a\udcd3\udb7f\ude0e\u9e41\uda04\udd29\udb13\udc9f\udb78\udefd\ud84f\udd45\udb64\ude35",
        59, 80043, 1350086480, 7711006026696491517L, -78801L, true, false, (char) 2870, (char) 20921,
        Double.longBitsToDouble(0x3fe2be716a222770L), Double.longBitsToDouble(0x3fe43360c3ad2efaL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\u0744 |this=org.apache.commons.lang.text.StrBuilder:\u0744\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\u0744\012",
        Z.run(T, 2, 14, 2, 16, "\u0744", "\u3129", "\ud82f\udc61\u38d2\ud87d\ude2d\ud948\udd09\uda06\udecc\ud887\udec3\ud840\ude1f\ud85c\udf08\u5d5d",
        36, 86160, 247, 2437035570870465910L, -48651L, false, false, (char) 25983, (char) 53833,
        Double.longBitsToDouble(0x3fe000000539527aL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud878\udc44\uda95\udf82\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\udaba\udd47\ud92d\udcbc\ud948\udd09\uda06\udecc\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\ud8a6\udd5b\ud9ec\udd06\udace\udff7\udb2d\udf64\uda10\udecc\ue462\udb25\udc7f\udac6\udf48\ud911\udf78\uda73\udfe0\uda1b\udc8f\ud9e0\ude42\udb10\udfee\ud8da\uddd1\uda91\udc39 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud878\udc44\uda95\udf82\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\udaba\udd47\ud92d\udcbc\ud948\udd09\uda06\udecc\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\ud8a6\udd5b\ud9ec\udd06\udace\udff7\udb2d\udf64\uda10\udecc\ue462\udb25\udc7f\udac6\udf48\ud911\udf78\uda73\udfe0\uda1b\udc8f\ud9e0\ude42\udb10\udfee\ud8da\uddd1\uda91\udc39\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud878\udc44\uda95\udf82\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\udaba\udd47\ud92d\udcbc\ud948\udd09\uda06\udecc\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\ud8a6\udd5b\ud9ec\udd06\udace\udff7\udb2d\udf64\uda10\udecc\ue462\udb25\udc7f\udac6\udf48\ud911\udf78\uda73\udfe0\uda1b\udc8f\ud9e0\ude42\udb10\udfee\ud8da\uddd1\uda91\udc39\012",
        Z.run(T, 2, 14, 2, 16, "\ud89e\udf52\ud878\udc44\uda95\udf82\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\udaba\udd47\ud92d\udcbc\ud948\udd09\uda06\udecc\udb4d\udef0\ud954\udeae\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\ud8a6\udd5b\ud9ec\udd06\udace\udff7\udb2d\udf64\uda10\udecc\ue462\udb25\udc7f\udac6\udf48\ud911\udf78\uda73\udfe0\uda1b\udc8f\ud9e0\ude42\udb10\udfee\ud8da\uddd1\uda91\udc39", "\u8734", "\udbb1\udd0c\udb2c\udd25\uda17\udd08\ud913\udc61\udb85\udf4b\udb94\udd93\ud89f\udfeb\udbd8\udfd8",
        -3, 41628, -1375251452, -4682845465253294409L, -64651L, true, false, (char) 39394, (char) 52755,
        Double.longBitsToDouble(0x3fe32efb5b10898dL), Double.longBitsToDouble(0x3fe673d7233c9706L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\012",
        Z.run(T, 2, 14, 18, 4, "\ud89e\udf52", "\u3129\u350f\u5035\u18d6\u6dc4\u4a83\000\000\000\u9da0\uc36f\u5ea0\u902c\ud5b1\uacb7\u8706\u93f2\u3e35\u2b6e\u0e72\u04a2\u9e69\u2f82\u0abb", "\udaf5\udc43\u00bb\uda1b\udc8f",
        7, -1000, -2123719168, -952849247378631707L, -44047L, false, false, (char) 55649, (char) 46904,
        Double.longBitsToDouble(0x3fe9cde360d93c45L), Double.longBitsToDouble(0x3fefd8d1f8940fa6L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\u0744\ud932\udce1\udaa9\ude3a\ud976\udde2 |this=org.apache.commons.lang.text.StrBuilder:\u0744\ud932\udce1\udaa9\ude3a\ud976\udde2\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\u0744\ud932\udce1\udaa9\ude3a\ud976\udde2\012",
        Z.run(T, 2, 14, 18, 4, "\u0744\ud932\udce1\udaa9\ude3a\ud976\udde2", "\uc99a\u6dc4\000\u26d1\000\000\u0c6c\uc36f\u5ea0", "\udbba\udf23\ud95f\udefd\000\ue57b\udbdc\udcd5\000\000\uda89\udd44",
        27, 69616, 35132, 0L, 96608L, false, false, (char) 21308, (char) 0,
        Double.longBitsToDouble(0x3fc5102d4397cb18L), Double.longBitsToDouble(0x3fe313680291798bL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud964\udf1a\udbd3\udcbb\udbc8\udfba\ud93e\udd52\uda8a\udf9a\ud945\udef9 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud964\udf1a\udbd3\udcbb\udbc8\udfba\ud93e\udd52\uda8a\udf9a\ud945\udef9\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud964\udf1a\udbd3\udcbb\udbc8\udfba\ud93e\udd52\uda8a\udf9a\ud945\udef9\012",
        Z.run(T, 2, 14, 18, 13, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud964\udf1a\udbd3\udcbb\udbc8\udfba\ud93e\udd52\uda8a\udf9a\ud945\udef9", "\u449e\u99b2\u2a2f\ub07c\u9902\u7d98", "\udb12\udd78",
        3, 42003, 106833933, -3336466935944174351L, -69596L, true, true, (char) 32052, (char) 27745,
        Double.longBitsToDouble(0x3fe3e33a61b0df5bL), Double.longBitsToDouble(0x3fd4781f5d5ee372L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.68968326 |this=org.apache.commons.lang.text.StrBuilder:0.68968326\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:0.68968326\012",
        Z.run(T, 2, 11, 18, 4, "\ud89e\udf52\ud932\udce1\udb6c\udedf\ud95c\udfd8", "\u22cb\u7a47\u4a83\u88bd\u67c0\u4104\u75c7\uc36f\u5ea0\u902c\u64ce\ua6cd\u8706\u93f2", "\udb83\udff4\uda9a\udeb5\udaa8\ude9e\ud87a\udd89",
        22, 69364, 631324177, 5596619396631764667L, 34736L, true, true, (char) 33377, (char) 44912,
        Double.longBitsToDouble(0x3fe611e29ff78b8dL), Double.longBitsToDouble(0x3fe48bcb8a2c3dc0L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:false |this=org.apache.commons.lang.text.StrBuilder:false\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:false\012",
        Z.run(T, 2, 6, 18, 14, "\ud89e\udf52", "\u6547\u80c1\u3a0e\u18d6\u6dc4\u4a83\u1a3a\u82c5\u40e5\u0c6c\uc36f\u3c01\u902c\u1db2\uacb7\u0706\u6508\u5a0f\ucd3d\u0e72\u04a2\u9e69\u3073\uc322", "\udaf5\udc43\u2ad3\uda1b\udc8f\ud9e0\ude42\udadd\udffa\ud8fb\udf39",
        35, 88493, 2039175778, 4449752767612252328L, 67537L, false, true, (char) 31489, (char) 2089,
        Double.longBitsToDouble(0x3fe25c3dd0f52506L), Double.longBitsToDouble(0x3fe292c2561e3f4cL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:7.399648893624544E-9 |this=org.apache.commons.lang.text.StrBuilder:7.399648893624544E-9\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:7.399648893624544E-9\012",
        Z.run(T, 2, 10, 3, 4, "\udb6e\udddc", "\u3129\u0fde\u3a0e\u3f0f\uc3c9\u4adc\ucb68\u484c\u44ac\000\000\u2944\u8fb7\ua266\uacb7", "\u9551\udb74\ude21\u68c8\ud9ae\udcf5\u00ea\ud891\udf03",
        -5, 34232, 631331089, 205608674394112L, 34736L, true, false, (char) 58586, (char) 106,
        Double.longBitsToDouble(0x3e3fc80000000000L), Double.longBitsToDouble(0x3fe48bced4b6657cL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud2e4 |this=org.apache.commons.lang.text.StrBuilder:\ud2e4\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\ud2e4\012",
        Z.run(T, 2, 7, 18, 10, "", "\u10af\u3129\u0fde", "\u38d2\udab5\udca8\ud931\ude57\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud8e9\uded3\ud996\udf43\u77c0\udbba\udf23\uda0f\udfc2\ud97e\udc67",
        30, 82455, 611661474, -389489595131684118L, 9936L, true, true, (char) 53988, (char) 12677,
        Double.longBitsToDouble(0x3fe5dfe5fe7c674cL), Double.longBitsToDouble(0x3fdb0df5b2ddd1eaL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.19050300472981108 |this=org.apache.commons.lang.text.StrBuilder:0.19050300472981108\0121=org.apache.commons.lang.text.StrBuilder:0.190503004729811080.19050300472981108 |this=org.apache.commons.lang.text.StrBuilder:0.190503004729811080.19050300472981108\012",
        Z.run(T, 2, 10, 10, 2, "\udbd8\udccf\ud932\udca3\ud8c6\udcb5\udb64\uddb9\udb8e\udc7f\uda02\uddb8\udb2d\udcee\uda5f\udeef\ud873\udc14\ud948\udd09\ud937\ude7c\udb9a\udeb3\udbf1\udcf0\ud85c\udf08\ud901\udc93\ud996\udf43\ud8d9\udc1d\udb4e\udde1\udac6\uded2\ud909\ude83\udbf8\udc97\udbd0\udcbc\udb58\udccd", "\u32f4\u4848\ube3d", "\ud96d\udd2e\ud8b3\udf4a",
        48, 79177, -2123718993, -2826346692129025163L, 70129L, false, false, (char) 55649, (char) 47968,
        Double.longBitsToDouble(0x3fc86267078d58c8L), Double.longBitsToDouble(0x3fd4dde2d1134042L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 2, 18, 13, "\ud8ca\uddfc\ud951\udfb7\udaa9\ude3a\ud976\udde2\ud999\uded5\ud961\udcaf\ud82f\udc61\u38d2\ud87d\ude2d\ud9b9\udf03\ud937\ude7c\ud883\udf65\udbea\udd37\udaca\udcf0\ud980\udfe1\udbd4\udf28\ud945\udcd9\udbba\udee2\ud8c4\udcef\ud992\ude05\u9551\udb74\ude21\u05fd\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\ud8dc\udc26\ud9e0\ude42\udadd\udffa\ud89b\udcc7\ud8f9\udc36\udb13\uddb2\udb78\udeaa\ud8b3\udc23\ud9a7\udd5a\ud84b\ude47", "\u18be", "\udb8e\udf66\ud9ac\udecb\u4785\ud85b\udeac\udaf8\udf58",
        29, 46263, 1474015200, -7011670036772493282L, -96559L, true, true, (char) 55657, (char) 19022,
        Double.longBitsToDouble(0x3fe01713a23a7800L), Double.longBitsToDouble(0x3fb06ff87a1c5ca0L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:false |this=org.apache.commons.lang.text.StrBuilder:false\0121=org.apache.commons.lang.text.StrBuilder:falsefalse |this=org.apache.commons.lang.text.StrBuilder:falsefalse\012",
        Z.run(T, 2, 6, 6, 9, "\ud89e\udf52\ua8de\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\ub9f9\ucd1c\ud024\ud5f7\u7d6e", "\ud8b0\udf50\uda96\udd5b\uda0a\udd71\udaa1\udd94",
        21, 43757, 376859237, 2627066026962469191L, 20974L, false, false, (char) 13664, (char) 53988,
        Double.longBitsToDouble(0x3fef212d0ebbfcbfL), Double.longBitsToDouble(0x3fa65f411b0df350L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 13, 13, 20, "", "\u10af\u3129\u249c", "\ud140\ud858\udd8c\ud948\udd09\ud937\ude7c\ud883\udf65\udbea\udd37\ud85c\udf08\ud901\udc30\udac4\udf69\udaf8\udddf\udbba\udf23\ud8c4\udcef\ud989\udd05\u9551\udaa1\ude98\udab3\uddec\ud9ae\udcf5\ud954\udef0\ud87b\udc0a\ue462\udbc0\udc69",
        59, 96612, 1733041851, -2352059350514273872L, 56102L, false, false, (char) 54049, (char) 44408,
        Double.longBitsToDouble(0x3fe968ecef4132b8L), Double.longBitsToDouble(0x3fc5dc92bd6421e4L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |a0=[C:[[]] |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |a0=[C:[[]] |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 8, 8, 0, "", "\u10af\u3129\ua2b2", "\000\ud858\udd8c\ud948\udd09\ud937\ude7c\ud875\udd65\udbea\udd37\uda4f\udf42\udbf3\ude9f\uda91\ude6e\ud8b7\udd71\udbba\udf23\ud8c4\udcef\ud98b\udf05",
        30, 14543, 611661474, -389489595131684118L, -33712L, true, true, (char) 7035, (char) 13768,
        Double.longBitsToDouble(0x3fdb0df5b28f03eaL), Double.longBitsToDouble(0x3fe57b8dcca8816aL)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\000\ud858\udd8c\ud948\udd09\ud937\ude7c\ud9dd\ude73\udbea\udd95\ud85c\udf08\ud901\udc30\ud92b\ude6e\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\udadc\udd67\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udcae\ud9e0\ude42\udadd\udffa\ua275\udb42\udd23 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\000\ud858\udd8c\ud948\udd09\ud937\ude7c\ud9dd\ude73\udbea\udd95\ud85c\udf08\ud901\udc30\ud92b\ude6e\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\udadc\udd67\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udcae\ud9e0\ude42\udadd\udffa\ua275\udb42\udd23\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\000\ud858\udd8c\ud948\udd09\ud937\ude7c\ud9dd\ude73\udbea\udd95\ud85c\udf08\ud901\udc30\ud92b\ude6e\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\udadc\udd67\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udcae\ud9e0\ude42\udadd\udffa\ua275\udb42\udd23\012",
        Z.run(T, 2, 13, 1, 0, "\ud89e\udf52\ud932\udce1\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\ud82f\udc61\000\ud858\udd8c\ud948\udd09\ud937\ude7c\ud9dd\ude73\udbea\udd95\ud85c\udf08\ud901\udc30\ud92b\ude6e\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\udadc\udd67\udb74\ude21\u68c8\ud9ae\udcf5\ud814\udcf0\ud87b\udc0a\ue462\udbc0\udc69\udac6\udf48\udbcc\udfb2\ud977\udcd1\uda1b\udcae\ud9e0\ude42\udadd\udffa\ua275\udb42\udd23", "\ua783\u6070\u7d07\u7243\ua137\uc915\u0d03\ub5c1\u82e6\u008a\ub6ea\u049b\u3743\ubd6c\uc435\u6b70\u00e5\u5c52\u2edf\u3a21\uba63\u87f4\ube5e\u1f77\uc98c\uc02e", "\ud839\udf25\ud9fb\ude32\uf62e\udb66\udc6e\u18ea",
        1, 31076, 1565526481, -6321000095559361604L, -47331L, true, false, (char) 31777, (char) 36189,
        Double.longBitsToDouble(0x3fe4a786688526ebL), Double.longBitsToDouble(0x3f8b5dedd1726d00L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud893\udc57\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ucd11\udbfb\ude2d\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\000\u77d0\ud9cc\ude2a\ud8c4\udcee\udae9\uddf3\uc29c\udb74\ude21\udbf6\udfc3\ud96d\udcd5\ud827\udd04\udbdb\udde8\uefa9\udbc0\udcf4\udac6\udf48\ud8e6\udf26\uda56\udcdb\udb33\udec3\ud9de\udece\ud84b\ude8e\ud8ba\udccb\udb2d\udc1b\udb52\udf1c\000\000\u0ca1 |a0=[C:[[\ud893, \udc57, \udaa2, \ude40, \udb95, \udf91, \ud89d, \ude1b, \ud999, \udf89, \udbf7, \udd3b, \ud82f, \udc61, \ud99a, \udcd7, \ucd11, \udbfb, \ude2d, \uda99, \udf30, \uda84, \udf9b, \ud952, \udd7a, \uda11, \udde9, \ud830, \udd30, \000, \u77d0, \ud9cc, \ude2a, \ud8c4, \udcee, \udae9, \uddf3, \uc29c, \udb74, \ude21, \udbf6, \udfc3, \ud96d, \udcd5, \ud827, \udd04, \udbdb, \udde8, \uefa9, \udbc0, \udcf4, \udac6, \udf48, \ud8e6, \udf26, \uda56, \udcdb, \udb33, \udec3, \ud9de, \udece, \ud84b, \ude8e, \ud8ba, \udccb, \udb2d, \udc1b, \udb52, \udf1c, \000, \000, \u0ca1]] |this=org.apache.commons.lang.text.StrBuilder:\ud893\udc57\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ucd11\udbfb\ude2d\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\000\u77d0\ud9cc\ude2a\ud8c4\udcee\udae9\uddf3\uc29c\udb74\ude21\udbf6\udfc3\ud96d\udcd5\ud827\udd04\udbdb\udde8\uefa9\udbc0\udcf4\udac6\udf48\ud8e6\udf26\uda56\udcdb\udb33\udec3\ud9de\udece\ud84b\ude8e\ud8ba\udccb\udb2d\udc1b\udb52\udf1c\000\000\u0ca1\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 9, 19, "\ud893\udc57\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ucd11\udbfb\ude2d\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\000\u77d0\ud9cc\ude2a\ud8c4\udcee\udae9\uddf3\uc29c\udb74\ude21\udbf6\udfc3\ud96d\udcd5\ud827\udd04\udbdb\udde8\uefa9\udbc0\udcf4\udac6\udf48\ud8e6\udf26\uda56\udcdb\udb33\udec3\ud9de\udece\ud84b\ude8e\ud8ba\udccb\udb2d\udc1b\udb52\udf1c\000\000\u0ca1", "\u9f16\u7cf0\u2efe\u60fa\ud6b2\u58bc\u8ba9", "\ud8fc\uddb1\ud9db\udf21K\ud95f\udc0e\uda48\udfa6\ud8b8\udfce\ud908\udf72\udb97\udf4b\u81d1\000\uda3f\udf9f\uda03\ude8e\ud80e\udcac\ud8bb\udfab\ud80a\ude5e\uda97\udd25\ud821\udea9\udbb0\uded2\uda8a\udd47\udbbf\udf58",
        20, -1000, -739918080, 1884888729999937109L, 51810L, false, false, (char) 0, (char) 52223,
        Double.longBitsToDouble(0x3fe0194763367b8bL), Double.longBitsToDouble(0x3fe45dc285002185L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud8b4\udef7\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ud819\udd23\udbfb\ude9a\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\ud996\udf65\u77d0\ud9cc\ude2a |a0=[C:[[\ud8b4, \udef7, \udaa2, \ude40, \udb95, \udf91, \ud89d, \ude1b, \ud999, \udf89, \udbf7, \udd3b, \ud82f, \udc61, \ud99a, \udcd7, \ud819, \udd23, \udbfb, \ude9a, \uda99, \udf30, \uda84, \udf9b, \ud952, \udd7a, \uda11, \udde9, \ud830, \udd30, \ud996, \udf65, \u77d0, \ud9cc, \ude2a]] |this=org.apache.commons.lang.text.StrBuilder:\ud8b4\udef7\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ud819\udd23\udbfb\ude9a\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\ud996\udf65\u77d0\ud9cc\ude2a\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\ud8b4\udef7\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ud819\udd23\udbfb\ude9a\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\ud996\udf65\u77d0\ud9cc\ude2a\012",
        Z.run(T, 2, 8, 1, 6, "\ud8b4\udef7\udaa2\ude40\udb95\udf91\ud89d\ude1b\ud999\udf89\udbf7\udd3b\ud82f\udc61\ud99a\udcd7\ud819\udd23\udbfb\ude9a\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\ud830\udd30\ud996\udf65\u77d0\ud9cc\ude2a", "\u6b80\u2b6e\uc4ac\u0fe8\u186b\u8e03", "\udac6\udf48\ud8e6\udf26\uda56\udcdb\udb33\udec3\ud9de\udece\ud84b\ude8e\ud8ba\udccb\udb2d\udc1b\ud9a6\udf86\uda50\udee1\ud9f7\udf2a\u80c3\uda50\udfea",
        27, 11102, -643661954, -6723771344106592939L, 62404L, false, false, (char) 53851, (char) 49168,
        Double.longBitsToDouble(0x3fe74c2220d1a776L), Double.longBitsToDouble(0x3fe25b592d96a7d8L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 9, 9, 19, "\ud930\udfa6\udaa2\ude40\udb95\udf91\udaca\uddc2\udb8d\udd57\udbf7\udd3b\ud802\udc8b\ud884\ude47\ufecf\udbfb\ude9a\uda99\udf30\uda84\udf9b\ud952\udd7a\uda11\udde9\udb45\udc7a\ud996\udf65\u77d0\ud9cc\ude2a\ud8c4\udcee\udb0d\ude77\uc29c\udb74\ude21\udbfd\uddc3\ud96d\udcd5\ud9d5\udd5b\ud923\uddf7\ud8c6\udd28\udbc0\udcf4\udac6\udf48\ud8e6\udf26\udb97\udd1a\u27e1\u6149\ud82b\ude68\udbd0\udf61\udba3\udcf1\uda1f\udcfe\uda50\udf14\ud9f7\udf2a\ud9ae\udee7", "\u9f16\u7cf0\u2efe\u60fa\ud6b2\u58bc\u8ba9\u082d\u9de9\u703a", "\uda5b\ude79\ud8e9\udf60\ud8ad\udc41\ud99a\udedb\udbcf\ude28\udbe5\udcb3\ud89e\udf30\uda3e\udccf\uda03\ude5c\ud80e\udcac\udafe\udc4c\ud80a\ude5e\uf7c3\ud9de\ude9f\ud86c\udda7",
        40, 38333, -982123065, 4700445651627157272L, -63563L, true, true, (char) 51865, (char) 5890,
        Double.longBitsToDouble(0x3fdea41d4ef2703eL), Double.longBitsToDouble(0x3fe435af4b362a8bL)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 19, 3, 16, "", "\u9896\u8230\u0fcf\u3a0e\u3f0f\u14ab\u4adc", "\ubc9a\udae9\uddf3\ud85c\udf08\ud901\udc30\ud921\udd28\u77c0\ud846\udc08\ud9a5\udc23\udb73\udfc1\u9551\udb74\ude21\u68c8",
        -2, 114, 1666702874, 5031969662969284924L, 42977L, false, false, (char) 21308, (char) 14410,
        Double.longBitsToDouble(0x3fdae1f8cd31a200L), Double.longBitsToDouble(0x3fefcd40ea9179daL)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\u0f75\000\000\ud976\udd67 |this=org.apache.commons.lang.text.StrBuilder:\u0f75\000\000\ud976\udd67\0121=java.lang.Integer:1 |this=org.apache.commons.lang.text.StrBuilder:\u0f75\000\000\ud976\udd67\012",
        Z.run(T, 2, 13, 0, 19, "\u0f75\000\000\ud976\udd67", "\u3f0f", "\ud816\udd89\udaa4\uddca\000\ud954\udeae\ud88f\udcf6\ud901\udc30\ud996\udf43",
        20, 15215, 567416561, -7874062954386959916L, -47070L, false, false, (char) 0, (char) 35447,
        Double.longBitsToDouble(0x3df5cb9200000000L), Double.longBitsToDouble(0x3fd00c50ecc7d51cL)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:true |this=org.apache.commons.lang.text.StrBuilder:true\0121=org.apache.commons.lang.text.StrBuilder:truetrue |this=org.apache.commons.lang.text.StrBuilder:truetrue\012",
        Z.run(T, 2, 6, 6, 17, "\uda26\udda0\uda6d\udf4e", "\u0fde\u4a08\u5535\uc325\u80eb\u1a3a\u9ca1\uccdf\u935a\ub5c0\u6dad\u8fb7\ub2bb\uacb7\u8706", "\ud827\ude3c\udb87\udda9\uda36\udf37\ud953\udd76\u1e8e",
        50, 42222, -636742062, 9148039230481661131L, 93621L, true, false, (char) 30195, (char) 26896,
        Double.longBitsToDouble(0x3fdf3f58b341c5feL), Double.longBitsToDouble(0x3fd213d5e5089f8aL)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\u0f75\udbcb\udc07\000\ud976\udd67 |this=org.apache.commons.lang.text.StrBuilder:\u0f75\udbcb\udc07\000\ud976\udd67\0121=java.lang.Integer:3 |this=org.apache.commons.lang.text.StrBuilder:\u0f75\udbcb\udc07\000\ud976\udd67\012",
        Z.run(T, 2, 13, 0, 19, "\u0f75\udbcb\udc07\000\ud976\udd67", "\u3f0f", "\ud816\udd89\udaa4\uddca\000\ud954\udeae\ud88f\udcf6\ud901\udc30\ud996\udf43",
        20, 15215, 567416561, -7912112602238168620L, -47070L, false, false, (char) 0, (char) 35447,
        Double.longBitsToDouble(0x3df5cb9200000000L), Double.longBitsToDouble(0x3fd00c50ecc7d51cL)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 1, 0, 7, 8, "\ud89e\udf52\uda66\udcdb\udaa9\ude3a\ud976\udde2", "\u3f0f\uc3c9\u4adc\u1a3a\u9ca1\u85cb\u1afa\u48ab\u0b2d", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\ud91a\ude7a\udbdf\udc08",
        35, 90625, 2043906364, 2711546380148521956L, 86320L, false, true, (char) 25093, (char) 18426,
        Double.longBitsToDouble(0x3fefcd41ca9179daL), Double.longBitsToDouble(0x3fc701eae38ee328L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud97b\udee8\udbcf\ude74\ud86a\ude1d\ud90a\udf92\ud999\uded5\uda02\ude40\udbf2\ude03\u3868\ud86a\udc22\ud952\udf92\ud9cf\udd29\ud824\udf8e\ud92d\udf5c\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\ud96f\udf5e\udafc\ude12\ud98b\udf05\ud82b\udd53\ud853\udfb8\udbec\udeb8\uda2a\ude95\uda0e\udc16\ud83e\udf37\ud9cc\udce4\ud8ec\udecc\uda81\udd46\udbc7\udcf9\uda56\udd62\uda1b\udc8f\udb16\udccd\udadd\udffa\ud884\udd5c\ud8d4\uddd6\udb0b\ude48\ud934\udf27\uda67\udeba\ud903\udc36\ud8ca\udd48\udaf5\udc6b\udb60\udc33\udb3f\udff3\uda50\udf2a\udb2f\udc7f\ud901\ude0d\ud9f0\uddc2\udac8\uddab\ud957\udfa2\ud9c8\udf8c\ucd4e\ud9ae\udd7d\ud8e8\udf3f\ud8b0\ude7e\u5e13\uda6f\udf81\udbda\udde9\uda1a\udceb\ud939\udf09\ud935\udc4a\udac3\udcad |a0=[C:[[\ud97b, \udee8, \udbcf, \ude74, \ud86a, \ude1d, \ud90a, \udf92, \ud999, \uded5, \uda02, \ude40, \udbf2, \ude03, \u3868, \ud86a, \udc22, \ud952, \udf92, \ud9cf, \udd29, \ud824, \udf8e, \ud92d, \udf5c, \ud85c, \udf08, \ud901, \udc30, \ud996, \udf43, \u77c0, \ud96f, \udf5e, \udafc, \ude12, \ud98b, \udf05, \ud82b, \udd53, \ud853, \udfb8, \udbec, \udeb8, \uda2a, \ude95, \uda0e, \udc16, \ud83e, \udf37, \ud9cc, \udce4, \ud8ec, \udecc, \uda81, \udd46, \udbc7, \udcf9, \uda56, \udd62, \uda1b, \udc8f, \udb16, \udccd, \udadd, \udffa, \ud884, \udd5c, \ud8d4, \uddd6, \udb0b, \ude48, \ud934, \udf27, \uda67, \udeba, \ud903, \udc36, \ud8ca, \udd48, \udaf5, \udc6b, \udb60, \udc33, \udb3f, \udff3, \uda50, \udf2a, \udb2f, \udc7f, \ud901, \ude0d, \ud9f0, \uddc2, \udac8, \uddab, \ud957, \udfa2, \ud9c8, \udf8c... |this=org.apache.commons.lang.text.StrBuilder:\ud97b\udee8\udbcf\ude74\ud86a\ude1d\ud90a\udf92\ud999\uded5\uda02\ude40\udbf2\ude03\u3868\ud86a\udc22\ud952\udf92\ud9cf\udd29\ud824\udf8e\ud92d\udf5c\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\ud96f\udf5e\udafc\ude12\ud98b\udf05\ud82b\udd53\ud853\udfb8\udbec\udeb8\uda2a\ude95\uda0e\udc16\ud83e\udf37\ud9cc\udce4\ud8ec\udecc\uda81\udd46\udbc7\udcf9\uda56\udd62\uda1b\udc8f\udb16\udccd\udadd\udffa\ud884\udd5c\ud8d4\uddd6\udb0b\ude48\ud934\udf27\uda67\udeba\ud903\udc36\ud8ca\udd48\udaf5\udc6b\udb60\udc33\udb3f\udff3\uda50\udf2a\udb2f\udc7f\ud901\ude0d\ud9f0\uddc2\udac8\uddab\ud957\udfa2\ud9c8\udf8c\ucd4e\ud9ae\udd7d\ud8e8\udf3f\ud8b0\ude7e\u5e13\uda6f\udf81\udbda\udde9\uda1a\udceb\ud939\udf09\ud935\udc4a\udac3\udcad\012",
        Z.run(T, 1, 8, 4, 2, "\ud97b\udee8\udbcf\ude74\ud86a\ude1d\ud90a\udf92\ud999\uded5\uda02\ude40\udbf2\ude03\u3868\ud86a\udc22\ud952\udf92\ud9cf\udd29\ud824\udf8e\ud92d\udf5c\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\ud96f\udf5e\udafc\ude12\ud98b\udf05\ud82b\udd53\ud853\udfb8\udbec\udeb8\uda2a\ude95\uda0e\udc16\ud83e\udf37\ud9cc\udce4\ud8ec\udecc\uda81\udd46\udbc7\udcf9\uda56\udd62\uda1b\udc8f\udb16\udccd\udadd\udffa\ud884\udd5c\ud8d4\uddd6\udb0b\ude48\ud934\udf27\uda67\udeba\ud903\udc36\ud8ca\udd48\udaf5\udc6b\udb60\udc33\udb3f\udff3\uda50\udf2a\udb2f\udc7f\ud901\ude0d\ud9f0\uddc2\udac8\uddab\ud957\udfa2\ud9c8\udf8c\ucd4e\ud9ae\udd7d\ud8e8\udf3f\ud8b0\ude7e\u5e13\uda6f\udf81\udbda\udde9\uda1a\udceb\ud939\udf09\ud935\udc4a\udac3\udcad", "\u2f6c\u193e", "\uda44\udcf3\udb0d\udc5b\udb0c\udee5\udbea\udd3d\uda00\udf6b\ud92b\udc26\udb5c\udcfe\udb3a\udcea\ud8a4\udcfb",
        3, 29121, 1135970918, -5021896770130498960L, -7427L, true, true, (char) 34866, (char) 23742,
        Double.longBitsToDouble(0x3fe17d4fd8d6fd06L), Double.longBitsToDouble(0x3feba2fd3359b217L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 14, 14, 17, "\ud870\udd8d\u9d53", "\u9eb2\ub9f9\u8aca\u6dc4\u4a83\u1a3a", "\udbea\udd37\ud85c\udeac\udbb7\udf3f\ud9b1\udf98\ud810\udcdd\udac0\uddc5",
        51, 27854, -1350711852, 1618702145008254235L, -2374L, true, false, (char) 41158, (char) 3811,
        Double.longBitsToDouble(0x3fd11d2bff604b76L), Double.longBitsToDouble(0x3fe5da6d5e7c674cL)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\0121=org.apache.commons.lang.text.StrBuilder: |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 13, 13, 4, "\ud9bd\udeb1", "\ucbee\u0fde\u3a0e\u3f0f\u6bfa\u7933\ucb11\000\000\000\000\u4d26", "\udbba\udf23\ud8c4\udcef\ud98b\udf05\u9551\udb74\ude21\u68c8\udb8d\udedf\u00ea\ud891\udf03\000\udb9d\udf2d",
        41, 46937, 0, -2352286382485540432L, 71695L, false, false, (char) 38911, (char) 21497,
        Double.longBitsToDouble(0x3fe48bced0a83dc0L), Double.longBitsToDouble(0x3fd8bfbd661ac9a2L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\uda20\ude58\000\ud89e\ude2e\ud976\udde2\ud999\uded5\uda72\udf3d\ud82f\udc61\u38d2\ud87d\ude2d\uda88\udefd\uda06\udecc\uc93c\ud9e5\ude56\ud85c\udf14\u5d5d\ud938\udc34\ud940\udd2e\u00f7\ud8c4\udcef\ud98b\udf05\u9551\uda18\udd13\udb26\udf73\udaa9\udd85\udb2a\udf6e\uda10\udecc\ud85a\ude92\udb25\udc7f\u5911\ud911\udedc\u9539\000\ud93e\udd1e\ud999\udfb8\udb64\udfe4\ud929\uddb1\uda2b\ude36\uda52\udc23\udbc4\udfb2\udaf2\ude56\ud94b\udc59\udaf2\udc0a\ud98e\udcfd\udb92\uddec\ud914\udeb3\ud973\udfcc\udb49\udf54\ud97c\uded5\ud9ea\udda4\ud93b\udd6b\u3413\udb46\udc4d\udadc\udda8\udac3\ude1b\udb4f\udf16\ud8ab\udd59\u8046\u4137\udb4c\udea8\ud8a0\udcd0\udacc\udf8f\ud8c1\udd34\ud84a\udf87\udb91\uddc7\udad9\udc2c\udad3\uddaf\ud9f7\udf03\ud9dc\udd5e\udbce\ude31\ud9e6\udfb7 |this=org.apache.commons.lang.text.StrBuilder:\uda20\ude58\000\ud89e\ude2e\ud976\udde2\ud999\uded5\uda72\udf3d\ud82f\udc61\u38d2\ud87d\ude2d\uda88\udefd\uda06\udecc\uc93c\ud9e5\ude56\ud85c\udf14\u5d5d\ud938\udc34\ud940\udd2e\u00f7\ud8c4\udcef\ud98b\udf05\u9551\uda18\udd13\udb26\udf73\udaa9\udd85\udb2a\udf6e\uda10\udecc\ud85a\ude92\udb25\udc7f\u5911\ud911\udedc\u9539\000\ud93e\udd1e\ud999\udfb8\udb64\udfe4\ud929\uddb1\uda2b\ude36\uda52\udc23\udbc4\udfb2\udaf2\ude56\ud94b\udc59\udaf2\udc0a\ud98e\udcfd\udb92\uddec\ud914\udeb3\ud973\udfcc\udb49\udf54\ud97c\uded5\ud9ea\udda4\ud93b\udd6b\u3413\udb46\udc4d\udadc\udda8\udac3\ude1b\udb4f\udf16\ud8ab\udd59\u8046\u4137\udb4c\udea8\ud8a0\udcd0\udacc\udf8f\ud8c1\udd34\ud84a\udf87\udb91\uddc7\udad9\udc2c\udad3\uddaf\ud9f7\udf03\ud9dc\udd5e\udbce\ude31\ud9e6\udfb7\0121=java.lang.Integer:0 |this=org.apache.commons.lang.text.StrBuilder:\uda20\ude58\000\ud89e\ude2e\ud976\udde2\ud999\uded5\uda72\udf3d\ud82f\udc61\u38d2\ud87d\ude2d\uda88\udefd\uda06\udecc\uc93c\ud9e5\ude56\ud85c\udf14\u5d5d\ud938\udc34\ud940\udd2e\u00f7\ud8c4\udcef\ud98b\udf05\u9551\uda18\udd13\udb26\udf73\udaa9\udd85\udb2a\udf6e\uda10\udecc\ud85a\ude92\udb25\udc7f\u5911\ud911\udedc\u9539\000\ud93e\udd1e\ud999\udfb8\udb64\udfe4\ud929\uddb1\uda2b\ude36\uda52\udc23\udbc4\udfb2\udaf2\ude56\ud94b\udc59\udaf2\udc0a\ud98e\udcfd\udb92\uddec\ud914\udeb3\ud973\udfcc\udb49\udf54\ud97c\uded5\ud9ea\udda4\ud93b\udd6b\u3413\udb46\udc4d\udadc\udda8\udac3\ude1b\udb4f\udf16\ud8ab\udd59\u8046\u4137\udb4c\udea8\ud8a0\udcd0\udacc\udf8f\ud8c1\udd34\ud84a\udf87\udb91\uddc7\udad9\udc2c\udad3\uddaf\ud9f7\udf03\ud9dc\udd5e\udbce\ude31\ud9e6\udfb7\012",
        Z.run(T, 2, 14, 2, 14, "\uda20\ude58\000\ud89e\ude2e\ud976\udde2\ud999\uded5\uda72\udf3d\ud82f\udc61\u38d2\ud87d\ude2d\uda88\udefd\uda06\udecc\uc93c\ud9e5\ude56\ud85c\udf14\u5d5d\ud938\udc34\ud940\udd2e\u00f7\ud8c4\udcef\ud98b\udf05\u9551\uda18\udd13\udb26\udf73\udaa9\udd85\udb2a\udf6e\uda10\udecc\ud85a\ude92\udb25\udc7f\u5911\ud911\udedc\u9539\000\ud93e\udd1e\ud999\udfb8\udb64\udfe4\ud929\uddb1\uda2b\ude36\uda52\udc23\udbc4\udfb2\udaf2\ude56\ud94b\udc59\udaf2\udc0a\ud98e\udcfd\udb92\uddec\ud914\udeb3\ud973\udfcc\udb49\udf54\ud97c\uded5\ud9ea\udda4\ud93b\udd6b\u3413\udb46\udc4d\udadc\udda8\udac3\ude1b\udb4f\udf16\ud8ab\udd59\u8046\u4137\udb4c\udea8\ud8a0\udcd0\udacc\udf8f\ud8c1\udd34\ud84a\udf87\udb91\uddc7\udad9\udc2c\udad3\uddaf\ud9f7\udf03\ud9dc\udd5e\udbce\ude31\ud9e6\udfb7", "\u6ce6\u53dd\u52ed\u5402\u8958\u8fd3", "\uda0a\udd20\ud841\ude42\ud938\uddc9\uda2a\udc6d\ud8b7\udf78\udb9b\udec4\uda65\udf5e\ud9cb\udd10\ud9eb\udf23\ud845\udc0d\ud890\udfdb\udb47\udc6d\ud80c\udfa9\ud9cd\udd94\ub559\ud92c\uddc9",
        19, 66372, 1229819569, -5282065088251006070L, 26799L, true, true, (char) 37571, (char) 7378,
        Double.longBitsToDouble(0x3fb02a65244a2bb0L), Double.longBitsToDouble(0x3fe769c743591a21L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\ud97b\udee8\udbcf\ude74\ud86a\ude1d\ud90a\udf92\ud999\uded5\uda02\ude40\ud857\ude75\uda47\udc3d\ud8cd\udf3a\ud952\udf92\ud9cf\udd29\ud824\udf8e\ud92d\udf5c\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\ud96f\udf5e\udafc\ude12\ud98b\udf05\ud82b\udd53\ud853\udfb8\udbec\udeb8\uda2a\ude95\uda0e\udc16\ud83e\udf37\ud9cc\udce4\ud8ec\udecc\uda81\udd46\udbc7\udcf9\uda56\udd62\uda1b\udc8f\udab2\udc3a\udadd\udffa\ud972\udf54\ud8d4\ude35\udb0b\ude48\ud934\udf27\uda67\udeba\ud902\udff8\ud8ca\udd48\udaf5\udc6b\udb60\udc33\udb3f\udff3\uda50\udf2a\udb2f\udc7f\ud98f\udda7\ud9f0\uddc2\udac8\uddab\ud957\udfa2\ud9c8\udf8c\ucd4e\ud9ae\udd7d\ud8e8\udf3f\ud8b0\ude7e\u5e13\uda6f\udf81\udbda\udde9\uda1a\udceb\ud939\udf09\ud935\udc4a\udac3\udcad |a0=[C:[[\ud97b, \udee8, \udbcf, \ude74, \ud86a, \ude1d, \ud90a, \udf92, \ud999, \uded5, \uda02, \ude40, \ud857, \ude75, \uda47, \udc3d, \ud8cd, \udf3a, \ud952, \udf92, \ud9cf, \udd29, \ud824, \udf8e, \ud92d, \udf5c, \ud85c, \udf08, \ud901, \udc30, \ud996, \udf43, \u77c0, \ud96f, \udf5e, \udafc, \ude12, \ud98b, \udf05, \ud82b, \udd53, \ud853, \udfb8, \udbec, \udeb8, \uda2a, \ude95, \uda0e, \udc16, \ud83e, \udf37, \ud9cc, \udce4, \ud8ec, \udecc, \uda81, \udd46, \udbc7, \udcf9, \uda56, \udd62, \uda1b, \udc8f, \udab2, \udc3a, \udadd, \udffa, \ud972, \udf54, \ud8d4, \ude35, \udb0b, \ude48, \ud934, \udf27, \uda67, \udeba, \ud902, \udff8, \ud8ca, \udd48, \udaf5, \udc6b, \udb60, \udc33, \udb3f, \udff3, \uda50, \udf2a, \udb2f, \udc7f, \ud98f, \udda7, \ud9f0, \uddc2, \udac8, \uddab, \ud957, \udfa2, \ud9c8... |this=org.apache.commons.lang.text.StrBuilder:\ud97b\udee8\udbcf\ude74\ud86a\ude1d\ud90a\udf92\ud999\uded5\uda02\ude40\ud857\ude75\uda47\udc3d\ud8cd\udf3a\ud952\udf92\ud9cf\udd29\ud824\udf8e\ud92d\udf5c\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\ud96f\udf5e\udafc\ude12\ud98b\udf05\ud82b\udd53\ud853\udfb8\udbec\udeb8\uda2a\ude95\uda0e\udc16\ud83e\udf37\ud9cc\udce4\ud8ec\udecc\uda81\udd46\udbc7\udcf9\uda56\udd62\uda1b\udc8f\udab2\udc3a\udadd\udffa\ud972\udf54\ud8d4\ude35\udb0b\ude48\ud934\udf27\uda67\udeba\ud902\udff8\ud8ca\udd48\udaf5\udc6b\udb60\udc33\udb3f\udff3\uda50\udf2a\udb2f\udc7f\ud98f\udda7\ud9f0\uddc2\udac8\uddab\ud957\udfa2\ud9c8\udf8c\ucd4e\ud9ae\udd7d\ud8e8\udf3f\ud8b0\ude7e\u5e13\uda6f\udf81\udbda\udde9\uda1a\udceb\ud939\udf09\ud935\udc4a\udac3\udcad\012",
        Z.run(T, 1, 8, 4, 2, "\ud97b\udee8\udbcf\ude74\ud86a\ude1d\ud90a\udf92\ud999\uded5\uda02\ude40\ud857\ude75\uda47\udc3d\ud8cd\udf3a\ud952\udf92\ud9cf\udd29\ud824\udf8e\ud92d\udf5c\ud85c\udf08\ud901\udc30\ud996\udf43\u77c0\ud96f\udf5e\udafc\ude12\ud98b\udf05\ud82b\udd53\ud853\udfb8\udbec\udeb8\uda2a\ude95\uda0e\udc16\ud83e\udf37\ud9cc\udce4\ud8ec\udecc\uda81\udd46\udbc7\udcf9\uda56\udd62\uda1b\udc8f\udab2\udc3a\udadd\udffa\ud972\udf54\ud8d4\ude35\udb0b\ude48\ud934\udf27\uda67\udeba\ud902\udff8\ud8ca\udd48\udaf5\udc6b\udb60\udc33\udb3f\udff3\uda50\udf2a\udb2f\udc7f\ud98f\udda7\ud9f0\uddc2\udac8\uddab\ud957\udfa2\ud9c8\udf8c\ucd4e\ud9ae\udd7d\ud8e8\udf3f\ud8b0\ude7e\u5e13\uda6f\udf81\udbda\udde9\uda1a\udceb\ud939\udf09\ud935\udc4a\udac3\udcad", "\u2f17\u193e\u9f9e\ub85f\u0ffd\ua449\u95f3\ub4da\ua10e\u4473\u979a\u0749\uc957\u58d7\uaff1\ub2a5\u40e5\uaf66\u3743\ua4fd\ud2b9\ub907\ub4ae\u01a9\ua233\u471d\uab80\u5110\u2714\u76e4\u2481\u255b", "\ud99c\udf0a\ud9ad\udd98\ud979\uddf8\ud825\udfc3\ud8c1\uddd2\ud870\udea5\ud8c6\ude84\ud82b\ude97\ud8a8\udcee\ud86d\udd69\uda5a\udc7d\uda9e\udee3\ud921\udc19\uda14\udd6c\ud980\udee2\ud8a4\udf9b\udbfa\udc08\udbd5\ude50\uda73\udc24\uda7d\udc03\ud922\udea7\udb3a\udc67\udabd\udf64\ud909\ude29\ud8d9\udd71\ud893\udeb3\ud861\udfd0\ud955\ude82\ud9ac\uddca\ud9da\udcfa\ud917\ude38\udbdb\udc42\ud925\udccd\ud992\ude27\uda86\udc58\ud819\udd5b\udb8a\udd32\udb1e\udc35\uda0b\udd5d\uda24\udf1a",
        38, 74411, -1652265519, 2226682959306007884L, 37311L, true, false, (char) 34697, (char) 14842,
        Double.longBitsToDouble(0x3fede0a043374080L), Double.longBitsToDouble(0x3fc0f5b8cf32fbc0L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\012",
        Z.run(T, 2, 5, 5, 0, "\ud89e\udf52\uda6f\udf80\uda72\udd9e\ud976\uddb2\ud9ac\udcd5\uda0a\udd75\udb15\uddd6\ud8e2\udd40\udb91\uded6\ud93a\ude68\ud9cf\udd29\ud901\ude22\ud954\udebb\ud85c\udf08\ud901\udc30\ud996\udf43\uda7a\uddca\udbba\udf23\u22d2\uda87\udfdc\uda91\udc2a\udb41\udd69", "\u5ce7\u5316", "\ud81d\uded9\udb80\udc48\udafe\ude81\ud9fc\udf69\udbe2\udd3c\udadd\udffa\ud8fb\udf39\ud997\udc46\udb20\ude48\udaa5\udf21\ud8b9\udc63\ud961\udfde\ud8bd\udc2a\ud924\ude2c\ud95a\udcea\ud8f9\udeae\ud9ab\udf17\udb2f\udc60",
        -5, 99015, -1379190606, -5178251793046431617L, -39680L, true, false, (char) 8209, (char) 35484,
        Double.longBitsToDouble(0x3fd4a18c152d4e96L), Double.longBitsToDouble(0x3fe35cf305ebca6aL)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\udb44\ude3e\ud821\udd93\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\udaaf\udd60\ud99c\udc94\uda76\udd17\ud948\udd09\ud9cf\udd29\ud81e\udc3d\udb86\udeb8\ud882\ude7a\ud9c0\udd2e\ud996\udf8a\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\ud88c\ude04\uda91\udc34\ued1c\uda27\ude6d\udb2a\udffc\uda10\udecc\udba8\udd4d\udbc0\udc90\ud95b\udd13\udbd2\ude6f\ud8bf\udcba\uda1b\udd00\ud931\ude39\ud91c\udcb6\udaec\udeb8\ud9ce\udc75\udb0b\ude48\ud89f\udd9d\uda28\udf69\udae3\udd4f\udb3d\udc11\uda96\udddb\ud87c\udf07\ud897\ude73\udb49\udc81\uda84\udd10\udb3d\uded3\uda7b\ude07\udb2b\udc2a\uda2f\udd9c\ud996\udd79\u43ea\ud8ea\udf1d\ud85b\ude50\udad1\udfde\udbd5\udc6e\udab2\uddb4\udb56\udf3b\ud820\uded6\ud8fa\udd9e\ud871\udf29\udbca\udc21\uda82\udc23\ud91a\udc4d\udb6d\udf7d\udab3\ude1a\uda9e\udf99\udaf5\ude4c\ud89b\udeea\ud800\uddea\ud9d0\udc40\udaec\ude2a\ud9ba\udd8f\ud8ba\ude72\ud87e\udc47\udb33\udcc9\u055b\udb4b\udeeb\ud947\udf8b\ud844\udf28\udbf7\udcd3\uda12\udc7e\udb4f\udfca\ud805\udf1f\ud84f\udf70\udaf0\udc5f\udb77\udc36 |this=org.apache.commons.lang.text.StrBuilder:\udb44\ude3e\ud821\udd93\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\udaaf\udd60\ud99c\udc94\uda76\udd17\ud948\udd09\ud9cf\udd29\ud81e\udc3d\udb86\udeb8\ud882\ude7a\ud9c0\udd2e\ud996\udf8a\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\ud88c\ude04\uda91\udc34\ued1c\uda27\ude6d\udb2a\udffc\uda10\udecc\udba8\udd4d\udbc0\udc90\ud95b\udd13\udbd2\ude6f\ud8bf\udcba\uda1b\udd00\ud931\ude39\ud91c\udcb6\udaec\udeb8\ud9ce\udc75\udb0b\ude48\ud89f\udd9d\uda28\udf69\udae3\udd4f\udb3d\udc11\uda96\udddb\ud87c\udf07\ud897\ude73\udb49\udc81\uda84\udd10\udb3d\uded3\uda7b\ude07\udb2b\udc2a\uda2f\udd9c\ud996\udd79\u43ea\ud8ea\udf1d\ud85b\ude50\udad1\udfde\udbd5\udc6e\udab2\uddb4\udb56\udf3b\ud820\uded6\ud8fa\udd9e\ud871\udf29\udbca\udc21\uda82\udc23\ud91a\udc4d\udb6d\udf7d\udab3\ude1a\uda9e\udf99\udaf5\ude4c\ud89b\udeea\ud800\uddea\ud9d0\udc40\udaec\ude2a\ud9ba\udd8f\ud8ba\ude72\ud87e\udc47\udb33\udcc9\u055b\udb4b\udeeb\ud947\udf8b\ud844\udf28\udbf7\udcd3\uda12\udc7e\udb4f\udfca\ud805\udf1f\ud84f\udf70\udaf0\udc5f\udb77\udc36\012",
        Z.run(T, 1, 13, 8, 9, "\udb44\ude3e\ud821\udd93\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\udaaf\udd60\ud99c\udc94\uda76\udd17\ud948\udd09\ud9cf\udd29\ud81e\udc3d\udb86\udeb8\ud882\ude7a\ud9c0\udd2e\ud996\udf8a\u77c0\udbba\udf23\ud8c4\udcef\ud98b\udf05\ud88c\ude04\uda91\udc34\ued1c\uda27\ude6d\udb2a\udffc\uda10\udecc\udba8\udd4d\udbc0\udc90\ud95b\udd13\udbd2\ude6f\ud8bf\udcba\uda1b\udd00\ud931\ude39\ud91c\udcb6\udaec\udeb8\ud9ce\udc75\udb0b\ude48\ud89f\udd9d\uda28\udf69\udae3\udd4f\udb3d\udc11\uda96\udddb\ud87c\udf07\ud897\ude73\udb49\udc81\uda84\udd10\udb3d\uded3\uda7b\ude07\udb2b\udc2a\uda2f\udd9c\ud996\udd79\u43ea\ud8ea\udf1d\ud85b\ude50\udad1\udfde\udbd5\udc6e\udab2\uddb4\udb56\udf3b\ud820\uded6\ud8fa\udd9e\ud871\udf29\udbca\udc21\uda82\udc23\ud91a\udc4d\udb6d\udf7d\udab3\ude1a\uda9e\udf99\udaf5\ude4c\ud89b\udeea\ud800\uddea\ud9d0\udc40\udaec\ude2a\ud9ba\udd8f\ud8ba\ude72\ud87e\udc47\udb33\udcc9\u055b\udb4b\udeeb\ud947\udf8b\ud844\udf28\udbf7\udcd3\uda12\udc7e\udb4f\udfca\ud805\udf1f\ud84f\udf70\udaf0\udc5f\udb77\udc36", "\ubdb2\ud61c\uc840\u3db0\uc611\u6511\u6b60\u06c5\u8e1e\u88d5\u0d99", "\ud8e6\udfe0\udabb\udcc1\ud913\udeb2\udb29\udcb8\udbad\udc9d\ud818\udea7\uda86\udc61\ud994\udd81\udb20\udd1b\ud9ff\udfe4\ud858\udd9f\ud9ca\udccb\ud88c\ude1d\ud845\udf23\udaff\udefd\u0ccc\ud89a\udf7d\ud8dd\ude66\ud916\ude8c\udbbd\udf7c\udbd3\ude47\udbe8\udc12\udb41\udd6a\ud8d6\udcfd\udbae\udd82\udb4c\udca9\ud855\udf02\udbad\udc9a\ud821\udea9\ud88a\udea9\udaee\udeff\ud9d4\udd6f\ud9dd\udca1\udb17\udd56\uda98\udcf9\udbfe\ude1f\udb34\udcf5\ua738\uda3c\udeea\uda58\ude47\ud924\udf7c\ud9b8\udefe\udaea\udd17",
        18, 52445, -527710242, 8556271712425390186L, 33899L, true, false, (char) 48580, (char) 62192,
        Double.longBitsToDouble(0x3fed0bfee6f374eeL), Double.longBitsToDouble(0x3fe96a81626ea871L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:0.727399998694148 |this=org.apache.commons.lang.text.StrBuilder:0.727399998694148\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:0.727399998694148\012",
        Z.run(T, 2, 10, 18, 3, "\udbae\udfb5\ud9a6\udf88\uda8f\udc58\u268b\udac4\udfc0\uda55\udd5d\udabc\udd2b\ud832\udffd\udb52\udcb6", "\u2e0f\ud33e\u46bc\u01a8", "\udbba\udee5\ud8c4\udcef\ud9b5\udfba\udbf3\udd22\udaa1\udc9c\udb5a\udfe3\uc658\ud8f9\ude9c\udb86\ude8c\udbf0\udeb7\uf863",
        44, 5781, 1464669212, 4133071922068437190L, 93025L, false, true, (char) 530, (char) 43426,
        Double.longBitsToDouble(0x3fe746dc5cb00ed0L), Double.longBitsToDouble(0x3fee48eae7bcac45L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\udb44\ude3e\ud821\udd93\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\udaaf\udd60\ud99c\udc94\uda76\udd17\ud948\udd09\ud9cf\udd29\ud81e\udc3d\udb86\udeb8\ud882\ude7a\ud9c0\udd2e\ud996\udf8a\ud8d0\ude17\udbba\udf25\ud8c4\udcef\ud98b\udf05\ud88c\ude04\uda91\udc34\ued1c\uda27\ude6d\udb2a\udffc\uda10\udecc\udba8\udd4d\udbc0\udc90\ud95b\udd13\udbd2\ude6f\ud8bf\udcba\uda1b\udd00\ud931\ude39\ud91c\udcb6\udaec\udeb8\ud9ce\udc75\udb0b\ude48\ud89f\udd9d\uda28\udf69\udae3\udd4f\udb3d\udc11\uda96\udddb\ud87c\udf07\ud897\ude73\udb49\udc81\uda84\udd10\udb3d\uded3\uda7b\ude07\udb2b\udc2a\uda2f\udd9c\ud996\udd79\u43ea\ud8ea\udf1d\ud85b\ude50\udad1\udfde\udbd5\udc6e\udab2\uddb4\udb56\udf3b\ud820\uded6\ud8fa\udd9e\ud871\udf29\udbca\udc21\uda82\udc23\ud91a\udc4d\udb6d\udf7d\udab3\ude1a\uda9e\udf99\udaf5\ude4c\ud89b\udeea\ud800\uddea\ud9d0\udc40\udaec\ude2a\ud9ba\udd8f\ud8ba\ude72\ud87e\udc47\udb33\udcc9\u055b\udb4b\udeeb\ud947\udf8b\ud844\udf28\udbf7\udcd3\uda12\udc7e\udb4f\udfca\ud805\udf1f\ud84f\udf70\udaf0\udc5f\udb77\udc36 |this=org.apache.commons.lang.text.StrBuilder:\udb44\ude3e\ud821\udd93\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\udaaf\udd60\ud99c\udc94\uda76\udd17\ud948\udd09\ud9cf\udd29\ud81e\udc3d\udb86\udeb8\ud882\ude7a\ud9c0\udd2e\ud996\udf8a\ud8d0\ude17\udbba\udf25\ud8c4\udcef\ud98b\udf05\ud88c\ude04\uda91\udc34\ued1c\uda27\ude6d\udb2a\udffc\uda10\udecc\udba8\udd4d\udbc0\udc90\ud95b\udd13\udbd2\ude6f\ud8bf\udcba\uda1b\udd00\ud931\ude39\ud91c\udcb6\udaec\udeb8\ud9ce\udc75\udb0b\ude48\ud89f\udd9d\uda28\udf69\udae3\udd4f\udb3d\udc11\uda96\udddb\ud87c\udf07\ud897\ude73\udb49\udc81\uda84\udd10\udb3d\uded3\uda7b\ude07\udb2b\udc2a\uda2f\udd9c\ud996\udd79\u43ea\ud8ea\udf1d\ud85b\ude50\udad1\udfde\udbd5\udc6e\udab2\uddb4\udb56\udf3b\ud820\uded6\ud8fa\udd9e\ud871\udf29\udbca\udc21\uda82\udc23\ud91a\udc4d\udb6d\udf7d\udab3\ude1a\uda9e\udf99\udaf5\ude4c\ud89b\udeea\ud800\uddea\ud9d0\udc40\udaec\ude2a\ud9ba\udd8f\ud8ba\ude72\ud87e\udc47\udb33\udcc9\u055b\udb4b\udeeb\ud947\udf8b\ud844\udf28\udbf7\udcd3\uda12\udc7e\udb4f\udfca\ud805\udf1f\ud84f\udf70\udaf0\udc5f\udb77\udc36\012",
        Z.run(T, 1, 13, 8, 9, "\udb44\ude3e\ud821\udd93\udaa9\ude3a\ud976\udde2\ud999\uded5\uda02\ude40\udaaf\udd60\ud99c\udc94\uda76\udd17\ud948\udd09\ud9cf\udd29\ud81e\udc3d\udb86\udeb8\ud882\ude7a\ud9c0\udd2e\ud996\udf8a\ud8d0\ude17\udbba\udf25\ud8c4\udcef\ud98b\udf05\ud88c\ude04\uda91\udc34\ued1c\uda27\ude6d\udb2a\udffc\uda10\udecc\udba8\udd4d\udbc0\udc90\ud95b\udd13\udbd2\ude6f\ud8bf\udcba\uda1b\udd00\ud931\ude39\ud91c\udcb6\udaec\udeb8\ud9ce\udc75\udb0b\ude48\ud89f\udd9d\uda28\udf69\udae3\udd4f\udb3d\udc11\uda96\udddb\ud87c\udf07\ud897\ude73\udb49\udc81\uda84\udd10\udb3d\uded3\uda7b\ude07\udb2b\udc2a\uda2f\udd9c\ud996\udd79\u43ea\ud8ea\udf1d\ud85b\ude50\udad1\udfde\udbd5\udc6e\udab2\uddb4\udb56\udf3b\ud820\uded6\ud8fa\udd9e\ud871\udf29\udbca\udc21\uda82\udc23\ud91a\udc4d\udb6d\udf7d\udab3\ude1a\uda9e\udf99\udaf5\ude4c\ud89b\udeea\ud800\uddea\ud9d0\udc40\udaec\ude2a\ud9ba\udd8f\ud8ba\ude72\ud87e\udc47\udb33\udcc9\u055b\udb4b\udeeb\ud947\udf8b\ud844\udf28\udbf7\udcd3\uda12\udc7e\udb4f\udfca\ud805\udf1f\ud84f\udf70\udaf0\udc5f\udb77\udc36", "\ubdb2\ud61c\uc840\u3db0\uc611\u6511\u6b60\u06c5\u8e1e\u88d5\u0d99", "\ud8e6\udf8d\udabb\udcc1\ud913\udeb2\udb29\udcb8\udbad\udc9d\ud818\udea7\uda86\udc61\ud994\udd81\udb20\udd1b\ud9ff\udfe4\ud858\udd9f\ud9ca\udccb\ud88c\ude1d\ud845\udf23\udaff\udefd\u0ccc\ud89a\udf7d\ud8dd\ude66\ud916\ude8c\udbbd\udf7c\udbd3\ude47\udbe8\udc12\udb41\udd6a\ud8d6\udcfd\udbae\udd82\udb4c\udca9\ud855\udf02\udbad\udc9a\ud821\udea9\ud88a\udea9\udaee\udeff\ud9d4\udd6f\ud9dd\udca1\udb17\udd56\uda98\udcf9\udbfe\ude1f\udb34\udcf5\ua738\uda3c\udeea\uda58\ude47\ud924\udf7c\ud9b8\udefe\udaea\udd17",
        18, 52445, -527710242, 8556271712425390186L, 33899L, true, false, (char) 48580, (char) 62192,
        Double.longBitsToDouble(0x3fed0bfee6f374eeL), Double.longBitsToDouble(0x3fe96a81626ea871L)));
  }
  @Test(timeout = 4000)
  public void test115() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8c0\udc37\uda62\udd69\udb31\udd80\udae0\udff2\ud967\udc89\ud802\udc70\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee1 |this=org.apache.commons.lang.text.StrBuilder:\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8c0\udc37\uda62\udd69\udb31\udd80\udae0\udff2\ud967\udc89\ud802\udc70\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee1\0121=org.apache.commons.lang.text.StrBuilder:\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8c0\udc37\uda62\udd69\udb31\udd80\udae0\udff2\ud967\udc89\ud802\udc70\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee10.119691744 |this=org.apache.commons.lang.text.StrBuilder:\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8c0\udc37\uda62\udd69\udb31\udd80\udae0\udff2\ud967\udc89\ud802\udc70\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee10.119691744\012",
        Z.run(T, 2, 15, 11, 10, "\ud8d9\udc8e\uda95\udfdb\udaa9\ude3a\udbcd\udfdf\udb69\udd62\ud8fa\udc2e\udbce\udcd5\uda41\udcd0\ud9ec\udea1\ud936\uddc1\udbcf\ude4a\ud959\ude8f\uda58\udde1\udba2\ude17\udaed\udc26\ud9ab\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8c0\udc37\uda62\udd69\udb31\udd80\udae0\udff2\ud967\udc89\ud802\udc70\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee1\udaa1\udeb4\uda56\udd62\ud8d4\udeeb\udbc0\udf1a\udb5f\ude9b\udb06\uddcf\uda83\udc1e\udb8d\udd4b\uf30f", "\ud674\ubaf0\uca1f\u3604\u9877\u0e7b\u2cd9\ud2eb\u20d7\u5964", "\uda89\udc7e\udb2a\udfe1\uda0b\udd99",
        31, 27, 933643938, 8828314275374475907L, 21905L, true, false, (char) 26026, (char) 31432,
        Double.longBitsToDouble(0x3fbea41e4cb0f050L), Double.longBitsToDouble(0x3fe73bcb38133312L)));
  }
  @Test(timeout = 4000)
  public void test116() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8b5\udf37\uda62\udd69\udbac\udd7e\ud8d7\udee9\ud84d\udd1c\ud810\udcc5\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee1 |a0=[C:[[\ud9d2, \udeab, \uda95, \udfdb, \udaa9, \ude3a, \udbcd, \udfdf, \udb69, \udd62, \ud8fa, \udc2e, \udbce, \udcd5, \uda41, \udcd0, \ud9ec, \udea1, \ud936, \uddc1, \udbcf, \ude4a, \ud959, \ude8f, \uda58, \udde1, \udba2, \ude17, \udaed, \udc26, \ud9ab, \udf43, \ud9fe, \udc79, \ud9bf, \udd0d, \uda99, \udd66, \ud8b5, \udf37, \uda62, \udd69, \udbac, \udd7e, \ud8d7, \udee9, \ud84d, \udd1c, \ud810, \udcc5, \ud886, \udf26, \udb4e, \udf7d, \udbc0, \udc69, \ud924, \udee1, \udaa1, \udeb4, \uda56, \udd62, \ud8d4, \udeeb, \udbc0, \udf1a, \udb5f, \ude9b, \udb06, \uddcf, \uda83, \udc1e, \udb8d, \udd4b, \uf30f]] |this=org.apache.commons.lang.text.StrBuilder:\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8b5\udf37\uda62\udd69\udbac\udd7e\ud8d7\udee9\ud84d\udd1c\ud810\udcc5\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee1\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8b5\udf37\uda62\udd69\udbac\udd7e\ud8d7\udee9\ud84d\udd1c\ud810\udcc5\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee1\012",
        Z.run(T, 2, 9, 2, 10, "\ud9d2\udeab\uda95\udfdb\udaa9\ude3a\udbcd\udfdf\udb69\udd62\ud8fa\udc2e\udbce\udcd5\uda41\udcd0\ud9ec\udea1\ud936\uddc1\udbcf\ude4a\ud959\ude8f\uda58\udde1\udba2\ude17\udaed\udc26\ud9ab\udf43\ud9fe\udc79\ud9bf\udd0d\uda99\udd66\ud8b5\udf37\uda62\udd69\udbac\udd7e\ud8d7\udee9\ud84d\udd1c\ud810\udcc5\ud886\udf26\udb4e\udf7d\udbc0\udc69\ud924\udee1\udaa1\udeb4\uda56\udd62\ud8d4\udeeb\udbc0\udf1a\udb5f\ude9b\udb06\uddcf\uda83\udc1e\udb8d\udd4b\uf30f", "\ud674\ubaf0\uca1f\u3604\u9877\u0e7b\u9e64\u0b4f\u6247\u4478", "\uda89\udc7e\udb2a\udfe1\uda0b\udd99",
        31, 27, 933643938, 8828314275374475907L, 21905L, true, false, (char) 26026, (char) 31432,
        Double.longBitsToDouble(0x3fbea41e4cb0f050L), Double.longBitsToDouble(0x3fe73bcb38133312L)));
  }
  @Test(timeout = 4000)
  public void test117() throws Throwable {
    assertEquals("0=org.apache.commons.lang.text.StrBuilder:\udf43\ud80a\uddc0\ud9bf\udceb\ud9df\udca8\ud984\udea8\uda71\udc50\udb31\udd80\udae0\udff2\ud967\udc89\ud9c4\udcd8\ud9ee\ude09\udb4e\udd19\udbc0\udc69\ud924\udee1 |this=org.apache.commons.lang.text.StrBuilder:\udf43\ud80a\uddc0\ud9bf\udceb\ud9df\udca8\ud984\udea8\uda71\udc50\udb31\udd80\udae0\udff2\ud967\udc89\ud9c4\udcd8\ud9ee\ude09\udb4e\udd19\udbc0\udc69\ud924\udee1\0121=java.lang.Integer:-1 |this=org.apache.commons.lang.text.StrBuilder:\udf43\ud80a\uddc0\ud9bf\udceb\ud9df\udca8\ud984\udea8\uda71\udc50\udb31\udd80\udae0\udff2\ud967\udc89\ud9c4\udcd8\ud9ee\ude09\udb4e\udd19\udbc0\udc69\ud924\udee1\012",
        Z.run(T, 2, 15, 18, 10, "\ud8d9\udc8e\uda95\udfdb\udaa9\ude3a\udbcd\udfdf\udb69\udd62\ud8fa\udc2e\udbce\udcd5\uda41\udcd0\ud802\udf62\ud936\uddc1\udbcf\ude4a\ud959\ude8f\uda58\udde1\udba2\ude17\ud9da\udf67\ud9ab\udf43\ud80a\uddc0\ud9bf\udceb\ud9df\udca8\ud984\udea8\uda71\udc50\udb31\udd80\udae0\udff2\ud967\udc89\ud9c4\udcd8\ud9ee\ude09\udb4e\udd19\udbc0\udc69\ud924\udee1\udaa1\udeb4\uda56\udd62\ud8d4\udeeb\udbc0\udf1a\udb5f\ude9b\udb06\uddcf\uda83\udc1e\udb8d\udd4b\uf30f", "\ud674\ubaf0\uc423\u571c\u9877\u0e7b\u2cd9\ud2eb\u20d7\u5964", "\uda89\udc7e\udb2a\udfe1\uda0b\udd99",
        31, 27, 933643938, 8828314275374475907L, 21905L, true, false, (char) 26026, (char) 31432,
        Double.longBitsToDouble(0x3fbea41e4cb0f050L), Double.longBitsToDouble(0x3fe73bcb38133312L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|char|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|char,int|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|java.lang.String|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|java.lang.String,int|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|org.apache.commons.lang.text.StrMatcher|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|org.apache.commons.lang.text.StrMatcher,int|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|boolean|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|char|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|[C|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|[C,int,int|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|double|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|float|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|int|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|java.lang.Object|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|java.lang.String|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|append|java.lang.String,int,int|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|char|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|char,int|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|java.lang.String|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|java.lang.String,int|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|org.apache.commons.lang.text.StrMatcher|new:org.apache.commons.lang.text.StrBuilder:",
    "M|org.apache.commons.lang.text.StrBuilder|indexOf|org.apache.commons.lang.text.StrMatcher,int|new:org.apache.commons.lang.text.StrBuilder:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
