package org.apache.commons.lang3.text;
import org.junit.Test;
import static org.junit.Assert.*;
public class ExtendedMessageFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 6, "\udbd6\udde1\uda13\udce3\udacc\udf38\udaa3\udf48\ud8e5\udf25\uda01\udca4\ud952\udd51\ud928\udfa1\u442c\ud83b\udd01\ud9d2\ude06\ud997\udeb8\uda45\uddc2\udb02\ude70\ud8e2\udcbd\udb76\udcb6\ud8f8\ude0a\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\udb4a\uddb2\u069c\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud95c\uddc9\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud9b7\ude00\udbe3\ude31\ua02d\udb48\udf7b\ud89f\udfb7\ud978\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 730720154, -8636684254828611601L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fc2df3d32271ab8L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 9, "\udb8b\udf09\ud9eb\uddcc\ud82e\udf2a\udaa6\udeec\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda16\udd90", "\uc949\u659e\uaf79\uc227\ud304\u54a3\u69a2\u885a", "\u8587\ud9b5\udec4\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\ud8a7\udd59",
        14, 65231, -1045185858, -5820760009886232648L, 85620L, false, false, (char) 41345, (char) 12499,
        Double.longBitsToDouble(0x3fda87d6b5c15b22L), Double.longBitsToDouble(0x3fe1892873607ae7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 1, 1, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15", "\u3b2d\u474a\u3a43\u347c", "\u04cf\udacf\ude8d\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27",
        39, 71384, 1022890011, -7264374763138972906L, -107L, true, true, (char) 59931, (char) 6816,
        Double.longBitsToDouble(0x3fe68984094fcb82L), Double.longBitsToDouble(0x3fe7ccdbe561063fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9b0\udc88\udb23\udeb6\ud987\udd1b\ud9bb\udeed\uda62\udcbb\uda48\uddf0\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\ud990\udda0\uda18\uddd3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udf3d\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\ud861\udf12\udb80\udc20\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\udbaf\udcde\udb85\udd17\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud911\uddcb\ud88a\udef8\ud9d5\udea5\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\ud8b0\udd08\udbb3\udc9d\udb48\udf37\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u982f\u6304\ua7d2\u8a32\u677e\u8beb\uad6b", "\uda9e\udcb5",
        42, 45576, 1849517551, -2375348930110426404L, -34876L, false, true, (char) 51230, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 7, 6, "\u2929\ud90c\ude6e\udba0\ude5d\udaa3\udf48\udb0a\udc18\udbb0\udca6\ud952\udd3d\udb3f\ude03\uda5f\udd43\ud873\ude35\ud904\uddc0\udbe2\udf74\ud80f\udc1e\udbcd\udd74\ud820\udd4f\udbc5\udf67\ud88a\udfa7\ud9e1\udfbf\ud91c\udcc8\udaa7\udd94\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud936\ude0b\ud8a6\ude44\uda92\udd7a\uda4a\udc77\ud82d\udc35\udb13\udfa1\ud85c\ude8d\u2036\udbca\udfc8\ud873\udd52\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\u628d\ud85e\udf23\ud983\udccc\ud80d\udd0f\udae0\udd6d\uda92\udc0d\udb3f\udf78\udad9\udc49\ud949\ude13\ud8af\ude66\udbe3\ude31\ud8f0\udeaa\udb48\udf76\ud89f\udfb7\ud97b\udf7d", "\u2ccb\uce1d\u69f3\u2e5d\u4281", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 11541, (char) 64044,
        Double.longBitsToDouble(0x3fd42cbe097b9484L), Double.longBitsToDouble(0x3fd229fb1265be10L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 0, 5, 2, "\udb23\udc74\uda13\udce6\udba0\ude5d\udaa3\udf48", "\u0c96\u3b2a\u474a\u7add\ua855\u46fe\u948f\uafad\u8c76\u3a8e\uadb4\ubcc8\u3b04", "\uda23\ude27\udb90\udd2d\ud919\udfc1\udb34\udfb2\ud80e\udfb3",
        25, 97675, 337492427, -178917702170182593L, -71342L, false, true, (char) 59254, (char) 56662,
        Double.longBitsToDouble(0x3fb00c3a2b083578L), Double.longBitsToDouble(0x3fdc49119599428cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 7, 6, "\udbd6\uddce\uda13\udce3\ud979\udec9\udaa3\udf8c\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\udac0\udf7b\ud8a4\udc1d\udb0e\udd14\ud858\udd2d\udb42\udc66\u04cf\u0acf\udb23\udeb6\ud987\udd1b\ud90d\udfb5\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda3c\udff5\udbc9\udec3\udb34\ude20\udb34\udfb2\ud80e\udfb3\ud873\ude4f\ud88e\ude59\ud9ce\udefa\uda0c\udf26\udbab\udf14\ud826\udde0\udaed\udd8c\uda07\udefb\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udba3\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\uda11\udcb9\ud9df\udc58\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud971\uddb8\udb74\udc94\ud85e\ude78\ud983\udccc\udb66\ude1c\uda82\udce9\uda6e\udd13\udb3f\udf78\uf11b\udad1\udfa5\uda1f\udd24\udac9\udd58\ud943\udd7c\udbbc\ude2e\ud99c\udd64\uda5b\uddda", "\ub9c1\u1eec\uc509\u20d7\ub704\ua7d2\u8d28\u1763\u082b\u4ba9\u55ad\u01c9\u1c29\u5476\u6f01\u558a\ucdc4\u159b\u7374", "\udb6d\udd06\ud858\uddbb\ud8d7\udcf4\udb2b\ude94\uda90\udd30\uda41\udd95\uda63\udcee\ud859\udd92",
        0, 96595, -1940458408, -6795881209781125403L, 58887L, true, false, (char) 36516, (char) 1938,
        Double.longBitsToDouble(0x3fef04a6ec7f243aL), Double.longBitsToDouble(0x3fef19c8a49dcabaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 3, 7, 6, "\udbd6\uddce\uda13\udce3\000\udaa3\udf44}\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\000\ueb5e\000\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud811\uddb9\uda32\udf62\u46f9\000\udb98\udf6a\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\u75fc", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud9d1\udeb4\ud877\uddd1\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\udb0a\udf7a\ud836\udd6f\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udd43\udb96\udecb\ud85e\ude78\ud9b9\udfc7\ud80d\udd03\ud9d8\udd69\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbd4\udf24\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb3c\udd95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658276519185L, -98842L, false, false, (char) 52986, (char) 63263,
        Double.longBitsToDouble(0x3fd3e6cd742f71e2L), Double.longBitsToDouble(0x3fb57e7a644e3570L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 6, "\udbd6\uddce\uda13\udce3", "\u3027\u50fc\u439e", "\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\udbba\udc2a\ud997\udda6\ud98e\udd22",
        58, 44703, -254493222, 2686804313080889414L, -95877L, false, true, (char) 40517, (char) 63437,
        Double.longBitsToDouble(0x3fe3d464559a2d37L), Double.longBitsToDouble(0x3faffec25bf3e1d0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 12, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\uda98\ude6b\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udbd3\ude2e\udbdc\udc12\udb4f\uddfa\ud867\udf11\ud857\udf12\ud845\udeed\ud9bc\udd7a\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 3, 7, 15, "\udbd6\udd68\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4", "\u474a\u3a43\ua855\ubca1\u17ad\uafad\u8c76\u3b0f", "\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73",
        54, 62011, -1691369052, -5840602373544392485L, -76628L, true, false, (char) 50139, (char) 59931,
        Double.longBitsToDouble(0x3fcd63261b44c298L), Double.longBitsToDouble(0x3fd4fcb82df336f8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 13, 1, "\udbd6\uddce", "\u8b13\uc10a\u042f\u439e\u3b2d\u474a", "\udbe2\udf74",
        36, 25893, 519864253, -7399417745185416893L, -99194L, false, true, (char) 42382, (char) 26781,
        Double.longBitsToDouble(0x3fe781f80ad808bbL), Double.longBitsToDouble(0x3f9b535734879f00L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 4, 14, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud891\udc43\udbba\uddd8\udb77\udcc5\uda64\udd51\udb77\udeea\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud82c\ude0c\uda23\ude27\udafd\udf73\ud90e\udc5b\udb38\udf09\udbba\udc0b\udaf6\udc74\uda98\udfc8\udb53\udfa0\ud9ce\udedd\ud86d\udd8c\ud826\udde0\u8587\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud99a\udec5\udbaf\udf2c", "\u147d\u050b\u3fd2\uce1d\u69f3\u7fd3\u44dd\u77a9", "\ud99e\udf4d\ud853\uddab",
        23, 21602, 1123933379, 781910656925586704L, 41525L, true, true, (char) 45635, (char) 52986,
        Double.longBitsToDouble(0x3fcd67c6a4f9b35cL), Double.longBitsToDouble(0x3fe0bdc78855f9e9L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\ud9cc\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\udab7\udd7d\ud9a6\ude20\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud83e\udfb9\ud896\udc12\ud8cf\udf57\udb6f\uded7\udb99\udc2e\ud9d0\udfcd\uea51\ud87a\udf9c\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e42e44e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 15, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d", "\u042f\u439e\u3b2d\u474a\u3a43\ua855", "\u04cf\ud894\udc43\udab4\udf8d\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27",
        39, 71384, 1022890011, -7264374765166394602L, 13099L, false, true, (char) 63939, (char) 50139,
        Double.longBitsToDouble(0x3f868c223ac64c00L), Double.longBitsToDouble(0x3fe68985314fcb82L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 15, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\ud8ba\uddb3\udac5\ude15\udb05\udf47\ud952\udc63\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud885\udcf9\udbd9\uddce\ud9c8\udd90\udb44\udcc6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda8a\ude95\uda8e\uddb9\udace\udfe3\udb81\uddae\ud919\udf84\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9b7\udcfe\udb86\udc2f\udbfb\ude96\ud834\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad3\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u70c4\u149e\ub704", "\udb39\ude95\ud94e\udc04\ud82b\ude28\uda3b\udf6d",
        37, 2398, 182052762, -8636684658723309585L, -54108L, true, false, (char) 56853, (char) 10290,
        Double.longBitsToDouble(0x3fb3e7c7a44e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\u3fd2\uce1d\u69f3\u7fd3\ub704 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 14, 8, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\udbfb\udc4a\ud8fa\udff7\ud9fd\ude7b\ud8e6\udc12\ud9db\udc04\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\uda30\udf3d\udb86\udc0a\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\udb38\udde3\ud813\ude3a\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fe914508935bacdL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 4, 1, 13, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb0e\udd30\ud914\udf91\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\ud985\udd74\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude5a\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud8a8\udde1\u8587\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud48d\udb2c\udca0\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 5, 7, 6, "\udbd6\uddce", "\u8b13\uc10a\u042f\u439e\u3b2d\u474a", "\udbe2\udf74",
        36, 25893, 519864253, -7399417745185416893L, -99194L, false, true, (char) 42382, (char) 26781,
        Double.longBitsToDouble(0x3fe781f80ad80000L), Double.longBitsToDouble(0x3f9b535734879f00L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 0, 0, 6, "\udbd6\uddce\uda13\udce3\uda5a\udcda", "\u03e1\u439e\u7e90\u1b32\u3a43\ua855\u76b8\u948f\uafad\u8c76\u800e\uadb4\ubcc8\u3b04\ub78f\ud2d8", "\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud9b5\udc65\uda91\udd0c\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\udaa0\udea5\udbca\udfc8\ud9e5\udcf0\ud87c\udc1e\ud8cf\udea2",
        4, 91548, 1284256460, -4743088704317820985L, 99540L, false, true, (char) 17358, (char) 30903,
        Double.longBitsToDouble(0x3fe4dc4651ba79ddL), Double.longBitsToDouble(0x3fe1e56c8a31250eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 6, "\udb39\udc1f\uda13\udc68", "\u1334", "\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74",
        36, 25893, 519864253, -3168004417086411808L, 73836L, false, true, (char) 2313, (char) 31826,
        Double.longBitsToDouble(0x3fdf93f015b01176L), Double.longBitsToDouble(0x3f9b535734879f00L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 3, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud848\uddcc\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud846\ude5a\ud9e1\udf65\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\udbe2\ude77\udb05\udc95\ud919\udfc1\udad2\uddc1\ud80e\udf3e\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\ud88a\ude63\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:-1411087764 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 7, 6, "\ud969\ude92\udad7\udf53\ud9fc\udc82\uda58\udca3\udac5\ude15\uda01\udca4\ud861\uded6\udb60\udf3a\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud9d2\udf61\ud8cd\uddab\udbca\udc64\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\udae4\udd6c\u6a83\udbac\udf23\ud9e6\udef5\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\udb2f\ude83\ud994\udda1\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\u3f8e\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\uda47\uddff\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        54, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\udd81\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\udbf8\udc2f\ud82f\ude65\uda62\udd7d\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\u258d\uda84\udc2f\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\ud8a9\udc14\ud952\udd2d\udb48\udf7b\ud89f\udfb7\ud97b\udf7d |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\udd81\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\udbf8\udc2f\ud82f\ude65\uda62\udd7d\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\u258d\uda84\udc2f\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\ud8a9\udc14\ud952\udd2d\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 63531, 182052779, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 0, 15, "", "\u087c", "\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\u98f1",
        59, 73506, 109, 2232799963271658692L, -2207L, false, false, (char) 40529, (char) 42382,
        Double.longBitsToDouble(0x3fe38cb166f03f01L), Double.longBitsToDouble(0x3fe6c045d81b5357L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-562535620 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udb8b\udf09\ud9eb\uddcc\ud82e\udf2a\udaa6\udeec\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\uda08\udf0f\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda16\udd90 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 7, 9, "\udb8b\udf09\ud9eb\uddcc\ud82e\udf2a\udaa6\udeec\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\uda08\udf0f\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda16\udd90", "\uc949\u659e\ua052\uc227\ud304\u54a3\u69a2\u885a\u1dde\u90ca\ud1e5", "\uda32\udf62",
        3, 92849, -1589243452, -6661893898137425420L, -5720L, false, false, (char) 24536, (char) 19942,
        Double.longBitsToDouble(0x3fb6394a58a72df0L), Double.longBitsToDouble(0x3fda87d6b5c15b22L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 8, 15, "", "\u087c", "",
        45, 22095, 117, 3242591729832050355L, -52237L, false, false, (char) 10861, (char) 8540,
        Double.longBitsToDouble(0x3fc883ce850e653cL), Double.longBitsToDouble(0x3feffdcc07ff31beL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 6, "\udbd6\uddcc\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud95f\ude17\uda6b\udfca\udb07\ude09\udb05\udc58\ud90d\ude9e\uda21\udd3a\ud80f\udcc4\u04cf\ud9b0\udc88\udb23\udeb6\ud987\udd1b\ud9bb\udeed\uda62\udcbb\uda48\uddf0\ud9a6\ude37\uda23\ude27\udafd\udf73\ud9d4\udddf\udbea\ude11\uda03\ude51\ud8ed\ude4c\uda92\udd7a\ud9ce\udefa\ud9bb\udfdd\ud8d0\udc15\ud8f2\udc1d\u8587\udbca\udf3d\ud83e\udfb9\uda32\udf62\ud8cf\udf57\uda25\udd71\ud861\udea7\udb80\udc20\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\udbaf\udcde\udb85\udd17\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud911\uddcb\ud88a\udef8\ud9d5\udea5\ud98b\udd2a\udb3f\udf78\udad9\udc49\ud991\udc55\ud88a\udd6f\ud8b0\udd32\udbb3\udc9d\udb48\udf37\ud896\ude1c\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u982f\u7432\ua7d2\u8afb\u677e\u8beb\uad6b", "\uda9e\udcb5\udac2\udc3d\udbc9\udfa9\ud85b\udc6e\ud9e7\udcee\u51f6\ud809\uddd1",
        52, 89712, -1192114573, -438755619194904491L, -84114L, true, true, (char) 43804, (char) 49236,
        Double.longBitsToDouble(0x3fe6009aaea7c0b4L), Double.longBitsToDouble(0x3fe42564dc7f3a45L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 4, "", "", "\udac5\ude15",
        46, 22095, 916142709, 3291930274019032755L, -52237L, false, true, (char) 10890, (char) 8540,
        Double.longBitsToDouble(0x3fc883ce850e653cL), Double.longBitsToDouble(0x3feffdcc07ff31beL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 7, 7, "\u05a2\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\udab4\udf91\uda81\uddbb\udbe2\udf74\ud80f\udc1e\u04cf\ud8d0\udc39\ud8ed\udc2e\ud9d1\udc67\ud9ca\uddd2\uda62\udcbb\uda48\uddf0\ud9a6\ude09\uda23\ude27\udafd\udf73\ud919\udfc1\ud990\udda0\uda18\uddd3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udf3d\ud83e\udfb9\ud90a\udd5f\ud8cf\udf57\udb6f\uded7\ud861\udf12\udb80\udc20\udbc7\ude12\udbfc\udcc6\ud978\udd61\ud8d6\uddbc\ufa0e\udb85\udd17\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud911\uddcb\ud88a\udef8\ud9d5\udea5\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\ud8b0\udd08\udbb3\udc9d", "\u9ece\u2c31\ucb7b\u3fd2\uce1d\u69f3\u982f\u88ab\ua7f6\u8a32\u677e\u8beb\uad6b\uca75\ubed5\u1b67\u5476\u3161\u8853\u19aa\uc7ca\u34eb\u5aac\u817b\ub23b\u72df\u9c65\u78c3\u7f64\u5ce5\u8dd7\u1ee8\u90de\ua03e\u0554\u598c\u6730\u16a7\uadd7\u57cd\u072b\u586a\u2531\u7eeb\u309c\u2677\ua823\ud015\u2af7\u41a6\u12ae\u908d\u4603\u768f\uac80\uceb3\u9258\u1413\u36cf\ua244\uc9f1\uad88\u8d4a\u72f5\uce6b\u8fa5\u097a\ud0f2\u869f\ua5c4\u9524\u0211\u81b1\ubca4\u858d\uab91\ubc8d\u6341\u389f\uced7\u7b34\uc554\u1fa7\u248b\u86dc\ub27b\ub985\u2318\ud41e\u9755\u00e2\uc483", "\ud958\udd6c\uda28\udd70\ud9ea\udd11\udabc\udf01\ud80e\udce2",
        3, 20197, -339025792, -3038951315708440352L, -94488L, false, true, (char) 48463, (char) 29378,
        Double.longBitsToDouble(0x3fedbac06df7fc13L), Double.longBitsToDouble(0x3fdb180702ca1038L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbf6\udfde\uda13\udc26\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\udb7f\udc98\uda81\udcaa\ud8d1\udf1b\udae9\ude74\ud80f\udc1e\udb20\udede\ud8d5\udf18\udb23\ude6e\ud987\udd1b\ud9bb\udeed\ud972\udd43\ud922\udf13\udadb\udda3\udb35\udd91\udafd\udf73\ud919\udfc1\ud990\udda0\uda18\uddd3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\udb33\uddfc\udbbe\ude38\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\uda2a\ude97\ud8c7\udd61\ud844\udf07\udbfc\udcc6\ud857\udf12\ud91b\udcd9\udbaf\udcde\udb85\udd17\udb9a\udc66\ud822\udc93\udb96\udecb\ud85e\ude78\ud911\uddcb\ud88a\udef8\ud9d5\udea5\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\ud8b0\udd08\ud89c\udc68\udad2\udf9d\ud87e\udf94\ud97b\udf7d |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 4, 7, 6, "\udbf6\udfde\uda13\udc26\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\udb7f\udc98\uda81\udcaa\ud8d1\udf1b\udae9\ude74\ud80f\udc1e\udb20\udede\ud8d5\udf18\udb23\ude6e\ud987\udd1b\ud9bb\udeed\ud972\udd43\ud922\udf13\udadb\udda3\udb35\udd91\udafd\udf73\ud919\udfc1\ud990\udda0\uda18\uddd3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\udb33\uddfc\udbbe\ude38\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\uda2a\ude97\ud8c7\udd61\ud844\udf07\udbfc\udcc6\ud857\udf12\ud91b\udcd9\udbaf\udcde\udb85\udd17\udb9a\udc66\ud822\udc93\udb96\udecb\ud85e\ude78\ud911\uddcb\ud88a\udef8\ud9d5\udea5\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\ud8b0\udd08\ud89c\udc68\udad2\udf9d\ud87e\udf94\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u982f\u6304\ua7d2\u8a32\u4ba4\u826a\u0626", "\ud9d4\udf60\uda96\udc5b\udbc9\udfa9\ud8a5\udc73\udaa1\udeca",
        21, 44900, 1087572985, 3660427236766316365L, 6411L, true, false, (char) 56141, (char) 6203,
        Double.longBitsToDouble(0x3fbbc610cd90f650L), Double.longBitsToDouble(0x3fee269ee2cd07acL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 6, "\u3d8c", "\u8b13\u487d\u03ae\u439e\u3b2d\u474a", "\udbe2\udf74",
        42, 25784, 510942909, 22514440721160515L, -59041L, true, false, (char) 70, (char) 26737,
        Double.longBitsToDouble(0x3fe781f80ad808bbL), Double.longBitsToDouble(0x3f9b5357f7233a00L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 5, 2, "\udb23\udc74\uda13\udce6\udba0\ude5d\udaa3\udf48", "\u0c96\u3b2a\u474a\u7add\ua855\u46fe\u948f\uafad\u8c76\u3a8e\uadb4\ubcc8\u3b04", "\uda23\ude27\udb49\udf2a\ud919\udfb5\udb34\udfb2\ud80e\udfb3",
        25, 97675, 337492427, -178917702170182593L, -71342L, false, true, (char) 59254, (char) 56662,
        Double.longBitsToDouble(0x3fb02fba2b083578L), Double.longBitsToDouble(0x3fdc49119599428cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\u0c96\u3b2a\u474a\u7add\ua855\u46fe\u948f\uafad\u8c76\u3a8e\uadb4\uac6c\u3af5 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 5, 2, "\udb23\udc74\uda13\udce6\udba0\ude5d\udaa3\udf48", "\u0c96\u3b2a\u474a\u7add\ua855\u46fe\u948f\uafad\u8c76\u3a8e\uadb4\uac6c\u3af5", "\uda23\ude27\udb90\udd2d\ud919\udfc1\udb34\udfb2\ud80e\udfb3",
        7, 97675, 337492427, -178917702170182593L, -71342L, false, false, (char) 59126, (char) 56662,
        Double.longBitsToDouble(0x3fb00c3a2b083578L), Double.longBitsToDouble(0x3fdc49119599428cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 16, 15, 12, "\ud9ff\udce5\ud80e\udc3a\udba0\ude5d", "\u08f8\u0c96\u3b2a\u474a\u7add\ua855", "\u04cf\ud9d9\udd90\udb23\ude35\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\ud82f\udd92\ud9a6\ude09\uda23\ude27\udb90\udd2d",
        54, 62011, -1691369052, -5840602373544392485L, -76628L, true, false, (char) 50139, (char) 29231,
        Double.longBitsToDouble(0x3fecc03486d130a6L), Double.longBitsToDouble(0x3fdd4cb8288061d0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\u3eca\u3b2a |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 4, 3, "\u8bd4\uda1d\udf48\udba0\ude5d\uda3f\udeb5", "\u3eca\u3b2a", "\ud9c0\ude6e\uda86\udf9a\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\ude35",
        27, 44703, -1158415142, 6991766951461421126L, 62032L, false, false, (char) 25458, (char) 65179,
        Double.longBitsToDouble(0x3fce1f3526440de4L), Double.longBitsToDouble(0x3fdcb0a56698283aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 5, "\udb23\udc74\ud800\udf9e\udaee\udc8d\ud809\udec0", "\u0c96\u3b2a\u474a\u7add\ua855\u46fe\u948f\uafad\u8c76\u3a8e\uadb4\ubcc8\u3b04", "\uda23\ude27\udb90\udd2d\ud919\udfc1\udb10\udf81\ud93c\udca9",
        25, 97675, 337492427, -178917705143223233L, 77873L, false, true, (char) 62759, (char) 5136,
        Double.longBitsToDouble(0x3fdc4e519599428cL), Double.longBitsToDouble(0x3fe6182ac185419cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbd6\uddce\uda13\udce3\000\udaa3\udf44}\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\ud9bc\udc70\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\000\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud811\uddb9\uda32\udf62\u46f9\000\udb98\udf6a\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 7, 6, "\udbd6\uddce\uda13\udce3\000\udaa3\udf44}\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\ud9bc\udc70\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\000\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud811\uddb9\uda32\udf62\u46f9\000\udb98\udf6a\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\u75fc", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:\ubbc7 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 5, 6, "\udbd6\uddce\ud922\udee0\000\udaa3\udf44\udbb7\udf0c\udbf0\udff3\ud952\udd51\udb3f\udd37\ud9d6\udd4f\ud89b\udeef\ud904\uddc0\udb1f\udf14\ud80f\udc1e\u04cf\ud9c8\udd90\ud975\uddc5\ud946\udedd\uda78\udfac\000\u54ac\uda53\udefb\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9c6\udeb1\u00c9\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\udb1d\udfde\uda32\udf62\u46f9\000\udb2a\ude15\udb24\udc59\udbea\udcf5\ud902\udc7c\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud986\udd92\ud822\udc93\uda0f\udd68\udacf\udc1d\udbc5\uddd3\uda9a\udd49\udaac\udd03\udb4b\udf26\udac4\ude41\uf19b\udad1\udfa5\ud83e\udca3\udb99\udc51\ud965\ude24", "\ubbc7", "\ud955\ude1f\udb14\udece\uda5a\udc99\uda4a\udcff\uda63\udc93",
        2, 7891, 880695672, 551368633186793962L, -80266L, true, false, (char) 10903, (char) 24553,
        Double.longBitsToDouble(0x3fef7c41272be9bbL), Double.longBitsToDouble(0x3fdf10c51cd967aeL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 15, 1, "\000", "\u8b13", "\ud935\udc5a",
        9, 73245, 16051, 1716995328L, 94669L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e01800000000000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 11, 6, "\udbe7\udee7\ud957\udcc5\uda29\udc53\udaa3\udfa6\udac5\ude15\ud9cc\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\udbb4\udea5\udbfa\udf5a\ud9ff\udffd\ud80f\udc95\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\udab7\udd7d\ud9a6\ude20\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\udbae\ude6a\udaf7\uddf7\ud92d\ude08\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud83e\udfb9\ud896\udc12\ud8cf\udf57\ud916\udc2a\ud814\udf54\ud9d0\udfcd\ud964\udc49\ud9d1\udcbd\ud905\udf09\ud91b\udcd9\udbce\udffa\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud93a\ude86\ud92c\ude14\ud875\udcbb\udb28\ude8e\uf11b\ud90e\udeb3\udb16\udf84\u19ed\ud965\ude24\udbef\udecf\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\uafdf\u7f8e\ub704", "\udb39\ude95\udb4e\udfd3\udb02\udc14\ud8ed\udfe6\ud842\udcd3\udaf5\udec1",
        42, 24152, 1775150442, 887633309169293809L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e42e44e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:\u12b8\u439e\u3b2d\u474a\u3a43\u5301\ua0b5\uabef\uafad\u69f3j\uadb4\ua93a\u2a09\ub78f |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 7, 3, "\udbd6\uddce\udb7c\udc77\udbb2\udee5", "\u12b8\u439e\u3b2d\u474a\u3a43\u5301\ua0b5\uabef\uafad\u69f3j\uadb4\ua93a\u2a09\ub78f", "\udb78\ude85\ud919\udfc1\udb34\udfb2\ud80e\udfb3\udb88\ude99\udbcc\udc73\ud9ce\udf2e\uda0c\udf26",
        31, 13471, 422618123, 3505551942971722983L, 33300L, false, false, (char) 23148, (char) 15490,
        Double.longBitsToDouble(0x3fdcc99cc02d3b26L), Double.longBitsToDouble(0x3fe549c8b72288d7L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:\ua10d\u7da1\ub78f\u388d\ua5ae\uc949\u659e\ua85d\u01ba\u96d6\u0d66\u33cb\u3d0c\u1dde\u90ca\ud1e5\ub293\u3331\u6ac4\u6660\ub9ef\ub17e\u7585 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 10, 10, "\ud974\ude9e\ud913\uddcd\udba0\ude5d\udaa3\udf48\udb65\uddfc\udb15\uded2\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\ud865\udcbb\ud8fa\udf73", "\ua10d\u7da1\ub78f\u388d\ua5ae\uc949\u659e\ua85d\u01ba\u96d6\u0d66\u33cb\u3d0c\u1dde\u90ca\ud1e5\ub293\u3331\u6ac4\u6660\ub9ef\ub17e\u7585", "\ud857\udf12\ud9d8\udd1e\ud95f\udf00\ud855\ude06\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78",
        38, 64288, 2061996593, -4061442708142363145L, 95139L, true, false, (char) 63275, (char) 752,
        Double.longBitsToDouble(0x3febb0e8722d4442L), Double.longBitsToDouble(0x3fe1f6b20e92590bL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\u3fd2\uce1d\u69f3\u7fd3\ub704 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 7, 13, 15, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udffe\udab0\udfab\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\udbfb\udc64\ud8fa\udff7\ud9e1\udfd4\ud8e6\udc12\ud947\udd1a\udaee\udc2a\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\udb7e\udd54\uda46\uddb4\ud9ce\udfb3\ud873\ude4f\ud914\udc97\uda42\udf6f\udb86\udc0a\ud853\udfe8\ud826\udde0\u85c3\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\udb38\udde3\ud813\ude3a\udbfb\ude96\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\udb6e\udee0\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf11b\ud99b\udf6c\ud8af\uddfc\udbe3\ude31\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\ub704", "\udb39\ude95\uda8e\uddc4\ud90b\udef3\uda3b\udf6d",
        31, 4379, 182052762, -8636684658555537425L, -72938L, false, true, (char) 52956, (char) 63263,
        Double.longBitsToDouble(0x3fd3e6cd742f71e2L), Double.longBitsToDouble(0x3fb57e7a644e3570L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 6, "\000", "", "",
        53, 22095, 171391605, 3292119282644827827L, 94669L, true, true, (char) 35008, (char) 62098,
        Double.longBitsToDouble(0x3fcff73013680000L), Double.longBitsToDouble(0x3feaf5d798462549L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.lang3.text.ExtendedMessageFormat:org.apache.commons.lang3.text.ExtendedMessageFormat@0\012",
        Z.run(T, 1, 7, 7, 14, "", "", "\udac5\ude15",
        46, 22095, 916142709, 3291930274019032755L, 76219L, false, true, (char) 10890, (char) 8540,
        Double.longBitsToDouble(0x3fc883ce850e653cL), Double.longBitsToDouble(0x3feffdcc07ff31beL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:\u8b13\u487d\u9d7b\u79d7\u6b06\u3eb4 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\u3d8c |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 7, 7, 6, "\u3d8c", "\u8b13\u487d\u9d7b\u79d7\u6b06\u3eb4", "\udbe2\udf74",
        42, 25784, 510942909, 19972369837742403L, -59041L, true, false, (char) 70, (char) 26737,
        Double.longBitsToDouble(0x3fe781f80ad808bbL), Double.longBitsToDouble(0x3f9b5357f7233a00L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:1199022878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.Integer:1199022878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 1, 11, "\ud9ff\udce5\ud80e\udc3a\udba0\ude5d", "\u242d\u0c96\u3b2a\u474a\u7add\ua855", "\u04cf\ud9d9\udd90\udb23\ude35\ud987\uddab\ud9e1\udfbf\ud91c\udcc8\ud82f\udd92\ud9a6\ude09\uda23\ude27\udb90\udd2d",
        54, 62011, -1691369052, -5840602373544392485L, -76628L, true, false, (char) 50139, (char) 29231,
        Double.longBitsToDouble(0x3fecc03486d130a6L), Double.longBitsToDouble(0x3fdd4cb8288061d0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 4, 4, 10, "\ud803\ude66\ud861\uddea\udaee\udc6c\ud809\udec0", "\u0c96\u3b2a\u474a\u7add\ua855\u46fe\u948f\uafad\u8c76\u3a8e\uadb4\u83ce\u19d9", "\ud8a1\udf7b",
        48, 71384, -1309143013, -6646910522728774890L, 13099L, false, true, (char) 63939, (char) 220,
        Double.longBitsToDouble(0x3fd06f4e27300d20L), Double.longBitsToDouble(0x3fe6898531d4cb82L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:org.apache.commons.lang3.text.ExtendedMessageFormat@0\0121=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:org.apache.commons.lang3.text.ExtendedMessageFormat@0\012",
        Z.run(T, 2, 4, 0, 0, "\000", "\uc0cd\ud13d", "\udb3f\udda9\ud8b6\udfd6\udb83\udcd9\udbc4\udcff\000\ud926\udef2",
        18, 65181, -1722811325, -5079962235376205313L, 42735L, false, false, (char) 54034, (char) 25458,
        Double.longBitsToDouble(0x3fe0cd8fc316a3c1L), Double.longBitsToDouble(0x3fcb75de472c2a54L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 3, 6, "\udbd6\uddce\uda13\udce3\000\udaa3\udf44}\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\ud9bc\udc70\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\000\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud811\uddb9\uda32\udf62\u46f9\000\udb98\udf6a\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\u75fc", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbd6\uddce\ud89b\udd46\udba7\udfca\ud8a2\udd7a'\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\ud9bc\udc70\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\000\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfcb\ud811\uddb9\uda32\udf62\u46f9\000\udb98\udf6a\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\ud893\udd00\ud89f\udf8a\ud97b\udf7d |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 7, 6, "\udbd6\uddce\ud89b\udd46\udba7\udfca\ud8a2\udd7a'\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\ud9bc\udc70\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\000\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfcb\ud811\uddb9\uda32\udf62\u46f9\000\udb98\udf6a\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\uda92\udc0d\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\ud893\udd00\ud89f\udf8a\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\u75fc", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 23331, 182052667, -8636684658555537425L, 18324L, false, true, (char) 41262, (char) 38965,
        Double.longBitsToDouble(0x3fe12185da17b8f1L), Double.longBitsToDouble(0x3fd55f9e9daf0e42L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbe7\udee7\ud958\udf11\udb66\udfe1\udaa3\udfa6\udac5\ude15\ud9cc\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\udbb4\udea5\udbfa\udf5a\ud9ff\udffd\ud80f\udc95\u04cf\uda5c\udf9b\uda3b\uddb5\ud987\udd1b\ud953\ude77\ud8f6\udd6d\udab7\udd7d\ud9a6\ude20\uda23\ude27\udafd\udf73\uda8b\udfca\udb34\udfb2\udbae\ude6a\udaf7\uddf7\ud92d\ude08\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\uda18\udc82\udbca\udf84\ud83e\udfb9\ud896\udc12\ud8cf\udf57\ud916\udc2a\ud814\udf54\ud9d0\udfcd\ud964\udc49\ud9d1\udcbd\ud905\udf09\ud91b\udcd9\udbce\udffa\ud951\udfd5\udbd2\udedf\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud93a\ude86\ud970\ude16\ud875\udcbb\udb28\ude8e\uf11b\ud90e\udeb3\ud978\udcb4\ud83d\udd18\ud891\udf15\udb0c\udd6a\udb58\ude77\ud92b\udf60\ud94d\udc56\uda49\udeb8 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 7, 5, "\udbe7\udee7\ud958\udf11\udb66\udfe1\udaa3\udfa6\udac5\ude15\ud9cc\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\udbb4\udea5\udbfa\udf5a\ud9ff\udffd\ud80f\udc95\u04cf\uda5c\udf9b\uda3b\uddb5\ud987\udd1b\ud953\ude77\ud8f6\udd6d\udab7\udd7d\ud9a6\ude20\uda23\ude27\udafd\udf73\uda8b\udfca\udb34\udfb2\udbae\ude6a\udaf7\uddf7\ud92d\ude08\ud9ce\udefa\uda0c\udf26\ud853\udfe8\ud826\udde0\uda18\udc82\udbca\udf84\ud83e\udfb9\ud896\udc12\ud8cf\udf57\ud916\udc2a\ud814\udf54\ud9d0\udfcd\ud964\udc49\ud9d1\udcbd\ud905\udf09\ud91b\udcd9\udbce\udffa\ud951\udfd5\udbd2\udedf\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud93a\ude86\ud970\ude16\ud875\udcbb\udb28\ude8e\uf11b\ud90e\udeb3\ud978\udcb4\ud83d\udd18\ud891\udf15\udb0c\udd6a\udb58\ude77\ud92b\udf60\ud94d\udc56\uda49\udeb8", "\uafdf\u7f8e\ub704\u5f8a\u8a32\u677e\ubaeb\u689f\u9728\ub1da\u8bb2\ud56d\ud0b1\u3ad1\u7864\u1fad\u8960\ua676\ucd82\u5d06\u59d8\u9c65", "\udb12\udcd3\uda4b\ude92\udae5\udff0\udaef\ude40\ud919\udd44\ud8cf\udcb0\ud8af\uddc8",
        32, 30210, -309920903, 5785031142623218667L, -82537L, false, false, (char) 10743, (char) 51053,
        Double.longBitsToDouble(0x3fd853a6794de482L), Double.longBitsToDouble(0x3fdc305ae36e45d6L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbd6\uddce\ud89b\udd46\udba7\udfca\ud8a2\udd7a' |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 7, 6, "\udbd6\uddce\ud89b\udd46\udba7\udfca\ud8a2\udd7a'", "\uc7e1\u474a\u3a43\ua855\u76b8", "\ud9bc\udc70\udb23\udeb6",
        58, 44703, -1061355520, 952909179247783960L, -95877L, false, true, (char) 40517, (char) 63437,
        Double.longBitsToDouble(0x3fee5854aaa83c32L), Double.longBitsToDouble(0x3fbe8406adf9add8L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 3, 6, "\udbe1\udfec\ud89b\udd46\udba7\udfca\ud8a2\udd7a'\uda01\udc23\ud952\udd51", "\u3a43\ua855\u76b8\ubfbd\u0db4\u5b56\u3b0f\uadb4\ubcc8\000\u0b5f", "\udafd\udf73",
        54, 5707, -1691369052, -5840602373544392485L, -100000L, true, false, (char) 50139, (char) 59931,
        Double.longBitsToDouble(0x3fcdc3260344c298L), Double.longBitsToDouble(0x3fd4fcb82df336f8L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 7, 3, "\udb88\udd7c\uda89\udc12\uda15\udf3a\ud8a2\udd7a{\ud9d0\udd23\ud952\udd51\ud9ab\udc0f", "\ua855\u76b8\uc643\u0db4\u5b56\u50fb", "\udb6a\udc90\ud9ea\ude46\ud818\udd46\uda23\ude27\udafd\udf73\udb95\ude6c\udb1b\udc22\ud9b8\udcb9\udaa3\udf59\ud8ca\udf24\ud973\udd94\udbd4\udcb5\ud91c\udefa\udac0\udefb\u3812\uda65\uddf4\ud935\udf59\udaa7\udfd8\u0c65\ud867\udfab\ud800\udce3\ud8c0\udeae\ud89b\udf1f\udb69\ude53\udb6b\udfb3\uda0c\udc10\ud874\uddb9\ud8d5\udc17\ud91c\udf58\udae1\udf88\ud8d5\udc77\uda98\udfa5\ud87a\uddc3\udadf\ude06\uda97\ude0e\u9b79\ud841\ude3e\uda37\udf07\ud897\udf0c\udb64\udcb0\udbca\udf26\uda5e\udf62\ubeb2\udb10\udfbc\udb82\udfbc\ud821\udc87\udad8\udea5\ud98a\udfb6\ud9ef\udcdb\ud92a\udf76\u946c\udadd\udeb4\udb22\udf03\ud9cc\uddce\ud87e\ude80\ufc14\ud977\udda4\udafc\udc2f\ud91b\udcab\udb0d\ude71",
        -4, 72291, 617007815, -4561404157966273100L, -3366L, true, false, (char) 32988, (char) 33680,
        Double.longBitsToDouble(0x3fc334353ccc6e98L), Double.longBitsToDouble(0x3fafd9bba0193940L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 7, 3, "\udb88\udd7c\uda89\udc12\uda15\udf3a\ud8a2\udd7a{\ud9d0\udd23\ud952\udd51\ud9ab\udc0f\ud8b6\udfd6\ud8a4\udc1d\ud91c\udda6\udbe2\udf74", "\u5b56\u8cd5", "\udb6a\udc90\ud9ea\ude46\ud818\udd46\uda23\ude27\udafd\udf73\udb95\ude6c\udb1b\udc22\ud9b8\udcb9\udaa3\udf59\ud8ca\udf24\ud973\udd94\udbd4\udcb5\ud91c\udefa\udac0\udefb\u3812\udab2\udc39\ud935\udf5a\udaa7\udfd8\u0c65\ud867\udfab\ud800\udce3\ud8c0\udeae\ud89b\udf1f\udb69\ude53\udb6b\udfb3\uda0c\udc10\ud874\uddb9\ud8d5\udc17\udb60\udfdd\udac6\udfb2\ud8d5\udc77\ud8dd\udce6\udb0b\udda2\udadf\ude2a\uda97\ude0e\u9b79\ud841\ude3e\uda37\udf07\udbf1\udeaf\udb64\udcb0\udbca\udf26\uda5e\udf62\ubeb2\udb10\udfbc\udb82\udfbc\ud821\udc87\udad8\udea5\ud98a\udfb6\ud9ef\udcdb\ud92a\udf76\u946c\udadd\udeb4\udb22\udf03\ud9cc\uddce\ud87e\ude80\ufc14\ud977\udda4\udafc\udc2f\uf65d\udb0d\ude71",
        -4, 72291, 617007815, -4561404157966273100L, -3366L, true, false, (char) 32988, (char) 33680,
        Double.longBitsToDouble(0x3fc334353ccc6e98L), Double.longBitsToDouble(0x3fafd9bba0193940L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 3, 7, "\udb88\udd7c\uda89\udc12\uda15\udf3a\ud8a2\udd7a{\ud9d0\udd23\ud952\udd51\ud9ab\udc0f\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\udb92\udf07\ud88f\uded4\ud9bc\udc70", "\u1802\ub1a9\u592b\ud6ee\u251e\uc949\u2284\ua87d\u2d46", "\ud973\udd94\udbd4\udcb5\ud91c\udefa\udac0\udefb\u3812\uda65\uddf4\ud935\udf59",
        25, 26817, -270061410, 5688816243246111121L, -22578L, true, false, (char) 26131, (char) 60795,
        Double.longBitsToDouble(0x3fd05cee57b6222aL), Double.longBitsToDouble(0x3fe4547e13954d7dL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 3, "\udbcd\udcf7\ud96c\udd17\uda15\udf3a\ud8a2\udd7a{\ud9d0\udd23\ud952\udd51\ud9ab\udc0f\ud8b6\udfd6\ud914\udc6e\ud904\uddc0\udbf2\ude9d\udb92\udf45\ud88f\uded4\ud9bc\udc70\ud810\udf39\ud81a\uded2\ud884\udd05\ud827\udead\ud9ea\ude1b\ud818\udd46", "\u2284\ua87d\u2d46\u22ca\u556c\ub349\u3ad9\ubf39\uc51d\u4c91\u3289\u5c80\u6f13\ud1e9", "\ud8c0\udeae\ud89b\udf1f\udb69\ude53\udac3\udcdf\ud859\udfa0\ud874\uddb9\ud904\udf8f\ud91c\udf0d\udae1\udf88\ud8d5\udc77\udab7\udec6\ud87a\uddc3\udadf\ude06\udab9\udd3d\u9b1b\udb8d\uddda\ud88d\udf82\udaba\ude6e\uda77\uddcf\ud84a\udc0e\udbcd\udd7d\uda1a\udc10\ud9ac\ude40\uda5b\uddd7\udb1f\udf0a\ud9eb\udfa7\uda8b\ude87\ud957\udf54\ud83c\ude48\udbfd\udc50\ud98f\udf18\udad6\udc8e\ud9d5\udc87\uda86\udfac\u7849\ud938\udf3c",
        43, 78174, -1191418750, -707536014669182817L, -83040L, false, true, (char) 3188, (char) 48047,
        Double.longBitsToDouble(0x3fe66158e70bc558L), Double.longBitsToDouble(0x3fdbe8c7bffa851eL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 7, 6, "\udbd6\uddce\uda13\udce3\udba0\ude5d\udaa3\udf48\udac5\ude15\uda01\udca4\ud952\udd51\udb3f\uddac\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9c8\udd90\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\ud91c\udcc8\uda1f\udd90\ud9a6\ude09\uda23\ude27\udafd\udf73\udba8\udd13\ud909\udcd5\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\uda0c\udf26\ud839\ude5c\ud9be\udf0b\u8587\udbca\udfc8\ud83e\udfb9\uda32\udf62\ud8cf\udf57\udb6f\uded7\udb99\udc2e\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud981\udec6\ud91b\udc55\ud9bc\ude05\udb86\udc2f\udbfb\ude96\ud822\udc93\udb96\udecb\ud9c4\udd8c\ud983\udc3b\ud80d\udd0f\ud8a4\udd6f\uda92\udc0d\udb3f\udf78\uf150\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\udb48\udf7b\ud89f\udfb7\ud97b\udf7d", "\u3fd2\u60d4\u69f3\u7fd3\ub704", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -9213145411810626881L, 76964L, true, false, (char) 56853, (char) 62216,
        Double.longBitsToDouble(0x3fb57e7a644e3570L), Double.longBitsToDouble(0x3fe39c50895ae79eL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbd6\uddce\u009a}\udaa3\udf44}\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\ud9bc\udc70\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\000\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud8c1\udd2c\ud873\ude8f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud8c5\udfe2\ud986\udf8d\u46f9\000\ud83d\udc39\ud875\udfb4\udbc7\ude0f\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\ud9dd\uddca\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\ud858\udc10\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 7, 6, "\udbd6\uddce\u009a}\udaa3\udf44}\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\ud9bc\udc70\udb23\udeb6\ud987\udd1b\ud9e1\udfbf\000\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud8c1\udd2c\ud873\ude8f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud8c5\udfe2\ud986\udf8d\u46f9\000\ud83d\udc39\ud875\udfb4\udbc7\ude0f\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\ud9dd\uddca\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\ud858\udc10\udb3f\udf78\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\u7602", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, 182052762, -8636684658555537425L, 76964L, true, false, (char) 27346, (char) 57357,
        Double.longBitsToDouble(0x3fb57e4a09ae0570L), Double.longBitsToDouble(0x3fd228a11265be10L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 3, 4, "\uda94\udd24\ud89b\udd46\udba7\udfca\ud8a2\udd7a'", "\uc7e1\u474a\u3a43\ua855\u76b8", "\ud9bc\udc70\udb23\udeb6",
        58, 44703, -1061355520, 952909179247783960L, -96813L, false, true, (char) 40517, (char) 63437,
        Double.longBitsToDouble(0x3fee5f54aaa83c32L), Double.longBitsToDouble(0x3fbe8406a88af5d8L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 7, 2, "\udb88\udd7c\uda89\udc12\uda15\udf3a\ud8a2\udd7a{\ud9d0\udd23", "\u474a\u3a43\ua855\u76b8\uc643\u0db4\u5b56\u7b0d", "\udb6a\udc90\ud9ea\ude46\udbcb\udc5f\uda23\ude27\udafd\udf73\udb95\ude6c\udb1b\udc22\ud9b8\udcb9\udaa3\udf59\ud935\udff9\ud861\udd1d\ud988\udcaf\ud91c\udefa\udac0\udefb\u3812\uda65\uddf4\ud935\udf59\ud840\udc24\udbf5\udf54\ud867\udfab\ud800\udce3\ud8c0\udeae\ud89b\udf1f\udb69\ude53\udb6b\udfb3\uda0c\udc10\ud874\uddb9\ud8d5\udc17\ud91c\udf58\udae1\udf88\ud8d5\udc77\uda98\udfa5\ud87a\uddc3\udadf\ude06\uda97\ude0e\u9b79\ud841\ude3e\uda37\udf07\ud897\udf0c\udb64\udcb0\udbca\udf26\uda5e\udf62\ubeb2\udb10\udfbc\udb82\udfbc\ud821\udc87\udad8\udea5\ud98a\udfb6\ud87d\udd23\ud805\udd3b\uda93\udeca\u887e\udb22\udf03\ud9cc\uddce\ud87e\ude80\ufc14\ud977\udda4\udafc\udc2f\ud91b\udcab\udb0d\ude71",
        34, 72471, 617007815, -4561404157966273100L, -84455L, true, false, (char) 18070, (char) 55462,
        Double.longBitsToDouble(0x3fe260f486c70cc9L), Double.longBitsToDouble(0x3fc334353ccc6e98L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 3, 7, 6, "\ud871\udddc\udb81\udd20\u00c8\udaa3\udf44}\uda01\udc23\ud952\udd51\udb3f\udd37\ud8b6\udfd6\ud95e\ude1b\ud904\uddc0\udbe2\udf74\ud80f\udc1e\u04cf\ud9d2\udc35\udb23\udeb6\ud987\udd1b\ud877\udc49{\ueb5e\000\uda23\ude27\udafd\udf73\ud919\udfc1\udb34\udfb2\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud94a\udead\000\ud853\udfe8\ud826\udde0\udaf8\udc11\ud8af\udc37\udada\uddec\ud874\uded4\u46f9\000\ud85d\udf72\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud801\udd50\uda92\udc0d\udb3f\udf78\uf11b\ud96e\udf33\ud805\uddb6\udbe3\uddba\ud965\ude24\uf776\ud819\udca6\ud97b\udf7d", "\u3fd2\uce1d\u69f3\u7fd3\u75fc", "\udb39\ude95\ud99e\udf4d\ud853\uddab\uda3b\udf6d",
        37, 4379, -1411782758, -8636684658555537425L, -29103L, false, false, (char) 52986, (char) 63263,
        Double.longBitsToDouble(0x3fd3e6cd742f71e2L), Double.longBitsToDouble(0x3fb57e7a644e3570L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbd6\uddce\uda13\udce3\000\udaa3\udf44}\uda01\udc23\ud952\udd51\u1f9e\udb84\udc11\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\udbf9\udf6f\udafd\udffb\ud987\udd1b\ud91c\udcfc\ubf5d\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9b0\udefa\ud9f6\udc5a\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud811\uddb9\uda32\udf62\u46f9\udafd\udddb\udb99\udc20\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud8d2\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\uda92\udc0d\uda83\udf7a\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d\ud947\udff3\uda37\udcb8 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 7, 6, "\udbd6\uddce\uda13\udce3\000\udaa3\udf44}\uda01\udc23\ud952\udd51\u1f9e\udb84\udc11\ud8a4\udc1d\ud904\uddc0\udbe2\udf74\uda1d\udd2e\ud88f\uded4\udbf9\udf6f\udafd\udffb\ud987\udd1b\ud91c\udcfc\ubf5d\ueb5e\ud818\udd2e\uda23\ude27\udafd\udf73\ud919\udfc1\ud9dd\udd86\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9b0\udefa\ud9f6\udc5a\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud811\uddb9\uda32\udf62\u46f9\udafd\udddb\udb99\udc20\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud857\udf12\ud91b\udcd9\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud8d2\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\uda92\udc0d\uda83\udf7a\uf11b\udad1\udfa5\ud8af\uddfc\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d\ud947\udff3\uda37\udcb8", "\u69f3\u7fd3\u75fc\ua7d2\u8a32\u677e\u8beb\uad6b\u55ad\u01c9\u1c29\u5476\u6f01\u558a\ucdc4\u1fad\u8960\ua676\u8bea\u5d06\u72df\u9c65", "\ud99f\udcb3\ud8f7\udd0b\ud90b\udd39\uda00\udded\ud8a7\udc85\ud802\udd18\udb05\udf66\ud8bb\ude2f\udb64\udd22\ud9b0\udcd9\uda2e\udd5a\ud94d\udd3e\uda1b\ude59\ud9f9\udd3f\udbf2\udc44\ud810\udf82\ud999\uddc2\uda63\udd85\ud926\udfbb\uda27\ude08\ud9bf\udfc5\udac9\udf91\ud991\udf7a\udbff\ude46\ud9a5\udf5b\ud9b0\ude38\ud862\uddb4\udb12\udfda\ud9c6\udce6\ue91a\udb27\udce1\ud908\ude13\uda57\udcc6\uda3e\udeae\ud91b\udd96\uda8c\udd93\ud81c\ude92\uda64\udc65\udb65\uded2\ud9dc\ude91\udbdc\udc49\ud982\ude45\u9bfb\u1333\ud8b5\udd40\ud9ca\uddb5\ud9de\udd66\udb46\udd4e\ud999\ude5e\uda94\udc58\udb29\udea1\ud89a\udd67\ud982\udef4\udb1d\ude71\udabe\udc4f\ud805\udda7\udb43\udcf8\uda54\udd8e\ud95d\udce5\ud9d4\ude52\udafc\ude11\udb0e\ude5a\ud908\udce5\ud952\udee6",
        9, 56023, 1986441364, -4685011301613050029L, 12526L, false, true, (char) 32406, (char) 42383,
        Double.longBitsToDouble(0x3fe4a06d7bb09cbfL), Double.longBitsToDouble(0x3fef1ee3cbffb382L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 7, 2, "\udb88\udd7c\uda89\udc12\uda15\udf3a\ud8a2\udd7a{\u4124", "\u1286\u3a43\ua855\u76b8\uc643\u0db4\u5b56\u204a", "\udb6a\udc90\ud9ea\ude46\udbcb\udc5f\uda23\ude27\udafd\udf73\udb65\udd6c\udb1b\udc22\ud9b8\udcb9\udaa3\udf59\ud935\udff9\ud988\ude32\udbce\udcc0\ud91c\udf3b\udac0\udefb\u3812\uda65\uddf4\ud935\udf59\udaec\udc3a\ud896\udce5\ud804\uddd3\u9ff2\ud8c0\udeae\ud89b\udf1f\udb69\ude53\ud505\udbed\ude23\uda09\udce4\ud9fb\ude40\ud945\udce5\udae1\udf88\ud8d5\udc77\uda98\udfa5\ud87a\uddc3\udadf\ude06\ud943\ude03\u6842\ud817\udd3e\uda37\udf07\ud897\udf0c\udb64\udcb0\udbca\udf26\uda5e\udf62\ubeb2\udb10\udfbc\udb82\udfbc\ud821\udc87\udad8\udea5\ud833\udd8a\ud87d\udd23\ud805\udd3b\udafe\udf33\ud920\ude56\ud976\udc40\ud9bb\ude6e\udacc\udc60\ufc14\ud977\udda4\udafc\udc2f\ud91b\udcab\udb0d\ude71\uda04\udf70\udae6\ude49\ud849\udda2\udbf1\udf5a\u64ba\ud962\udcfa",
        56, 58559, 913999494, 2205534756899742284L, 5319L, true, true, (char) 16837, (char) 65415,
        Double.longBitsToDouble(0x3fdfb0c2cf71d120L), Double.longBitsToDouble(0x3fb7171003496770L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 3, 6, "\udbd6\uddce\uda13\udce3\000\udaa3\udf44}\udae5\ude88\ud954\ude4d\udb3f\udd37\ud8b6\udfd6\ud8a4\udc1d\ud80e\uddc4\udb4e\udeff\uda7e\udd55\ud88f\uded4\ud823\ude24\uda2f\uddff\ud992\udccb\ud9e1\udfbf\000\ud751\ud818\udd2e\ud958\ude06\udada\udc53\ud919\udfc1\ud9dd\udd86\ud80e\udfb3\ud873\ude4f\uda92\udd7a\ud9ce\udefa\000\ud853\udfe8\ud826\udde0\u8587\udbca\udfc8\ud811\uddb9\uda32\udf62\u46f9\000\udb98\udf6a\udb53\udf4e\udbc7\ude12\udbfc\udcc6\ud89d\uddf4\ud907\uddd0\ud9bc\ude05\udb86\udc2f\ud874\udd8d\ud822\udc93\udb96\udecb\ud85e\ude78\ud983\udccc\ud80d\udd0f\ud87f\udf6f\ud892\udfcd\udac2\udf70\ud958\udcec\ud843\udd15\ud8cd\udc43\udbe3\ude31\ud965\ude24\uf776\ud89f\udf8a\ud97b\udf7d\ud928\udd40\uda37\udcb8\ud93c\udda6", "\u7fd3\u75fc\ua7d2\u8a32\u677e\u8beb\uad6b\u10de\u6faf\u1c29\u5476\u6f01\u558a\ucdc4\u8c39\u8960\ua676\u8bea\u8100\uce48\u34b2\u78c3\u6e3f\u9492\u5a25\u02a2\u95dc", "\ud9b4\uded4\ud841\udfa5",
        49, 50278, -910187489, 2239152876538918481L, 98411L, false, false, (char) 16535, (char) 20546,
        Double.longBitsToDouble(0x3fd69d1579cf4052L), Double.longBitsToDouble(0x3fcc773ff931b104L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|equals|java.lang.Object|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|hashCode||new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|appendQuotedString|java.lang.String,java.text.ParsePosition,java.lang.StringBuilder,boolean|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|applyPattern|java.lang.String|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|containsElements|java.util.Collection|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|getFormat|java.lang.String|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|getQuotedString|java.lang.String,java.text.ParsePosition,boolean|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|insertFormats|java.lang.String,java.util.ArrayList|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|next|java.text.ParsePosition|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|parseFormatDescription|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|readArgumentIndex|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|seekNonWs|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|setFormat|int,java.text.Format|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|setFormatByArgumentIndex|int,java.text.Format|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|setFormats|[Ljava.text.Format;|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|setFormatsByArgumentIndex|[Ljava.text.Format;|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|equals|java.lang.Object|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|hashCode||new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
