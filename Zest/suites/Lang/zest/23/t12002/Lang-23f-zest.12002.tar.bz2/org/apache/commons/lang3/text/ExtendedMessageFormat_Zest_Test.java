package org.apache.commons.lang3.text;
import org.junit.Test;
import static org.junit.Assert.*;
public class ExtendedMessageFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:1720843878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 7, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u22ea\u98e6", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbcc\udf15",
        16, 99003, -381367428, 9200410382799349095L, 30368L, false, false, (char) 17851, (char) 11595,
        Double.longBitsToDouble(0x3fb6b635f3f4ccb0L), Double.longBitsToDouble(0x3fa695bca1220410L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:1720843878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 7, "\uda31\udfa4", "\u994a\ua706\u91b3\u22ea\u98e6", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbcc\udf15",
        16, 99003, -381367428, 9200410382799349095L, 30368L, false, false, (char) 17851, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e30910208000000L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 7, "\uda31\udfa4\udbd5\udd59\ub7a1\uda87\udf14\ud96f\uddc7\udb58\udc35\udb95\udce9\udaaa\udc42\ud96b\udee3\ud8d1\uded7\uda70\udccd\ud993\udf3a\ud913\udf62\uda49\uddbb\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uf867\uda4b\udd0b\uda13\udddf\udbcc\udf15\ud856\udd02\ud975\udd52\ud806\ude25\ud8eb\udc05\ud94e\ude08\ud97e\uddb4\udbf9\udf13", "\u9608\u36f9\u6204\u4a68\ud08f", "\ud8e3\udf86\udacd\udeff\ud8e2\udea2\udb63\udf83\uda91\ude90\ud86f\udd34\ud8c2\uddd3\ud87a\udc79\udbb8\udf4b\ud852\udf00\ud83b\udc93\ud936\ude29",
        -5, 14998, 655539892, 857588590060711714L, 53810L, false, false, (char) 24674, (char) 17998,
        Double.longBitsToDouble(0x3fe7fea1c2d13714L), Double.longBitsToDouble(0x3febaf01f3cf95ceL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:-2004451148 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 5, 13, "\uda31\udfa4\ud8b7\udf68\uda0d\udd8a\uda7d\udc2e\udb0e\udcc8\udb58\udc35\udb95\udce9\ud965\udf60\ud945\udf2a\ud80f\ude35\uda70\udd05\ud842\udc31\ud87d\udeb5\uda49\udd9e\udac2\udc09\ud897\udc24\udb96\ude81\udae2\udc89", "\ucd78\u14eb\u5790\u82ee", "\udb41\ude9a\ud97e\uddde\ua114\uda28\uddcc",
        17, 27218, -1718167462, -6923934240677434323L, 67393L, true, true, (char) 64741, (char) 57234,
        Double.longBitsToDouble(0x3fcb4a93ac8c0b70L), Double.longBitsToDouble(0x3feef022de37963eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:1734111782 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 7, "\udbf1\udf44", "\u994a\u8ee2\ua6ff\u22ea\u98e6\ua122\ua8fe\u61a6\u2652\u7e53\uceb7\u8c68", "\uc890\ud8e0\ude0e\uda20\udc64\ud8bf\udc58",
        -1, 67836, 1751945003, 1361155247767585568L, -56082L, false, false, (char) 55316, (char) 52921,
        Double.longBitsToDouble(0x3fe091020e3ee1d7L), Double.longBitsToDouble(0x3fe0125203707e0dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:-1142090604 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 7, "\uda31\udfa4\udbd5\udd59\ub7a1", "\ua6ff\u22ea\u7a80\u6cbc\u4fe8\u61a6\u89a6\u7298\uceb7\u8c68\u31f3\ub334\uba93\u551e\ua319\ucd78\uae3c\u5790", "\ud8eb\udc05\ud94e\ude08",
        3, 71976, -880837976, -2821328988921179022L, 80610L, true, false, (char) 30413, (char) 27112,
        Double.longBitsToDouble(0x3fc2703b58679554L), Double.longBitsToDouble(0x3fef027af13d6bfeL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:1720843878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 7, "\uda31\udfa4", "\u3138\ubcb2\u7cef\u22ea\u98e6\ua122", "\ud842\udc31\uda63\ude29\uda7e\udc45\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\ud875\udc6c\ud8be\udffe\udbcc\udf15\ud856\udd02\ud975\udd52",
        47, 27471, 1318200679, 1640216662465969472L, 20420L, false, false, (char) 17843, (char) 55892,
        Double.longBitsToDouble(0x3fe4d3c17f4a5247L), Double.longBitsToDouble(0x3fefbc9177c91f93L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:-2096785690 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 6, "\uda31\udfa4\udbd5\udd59\udbd2\udf93\ud946\udc6a\ud88c\udce3\udb58\udc35\uda92\udc27\udad4\udf53\udb9c\ude41\ud8ae\udc5b\uda70\udccd", "\uceb7\u8c68\u868b\ub3c5\u658a\u64a3\ua2e8\ucd78\u528e\u15d9\u82ee\ud630\u791d", "\ua114\uda73\udd52\ud8b7\udc83\ud8b8\uddfd\udbe2\ude50\udb70\udd0d\ud884\uddeb\ud9f4\udf62\uda8a\udf04\udab6\udcf2",
        0, 1107, -413420265, -3700772252886868190L, -13574L, true, false, (char) 40375, (char) 39845,
        Double.longBitsToDouble(0x3fee37b8daa0f7d3L), Double.longBitsToDouble(0x3fc5fc19edba51d8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:1901362222 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.Integer:1901362222 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 1, 7, "\uda31\udfa4\udbd5\udd59", "\u8ee2\ua6ff\u22ea", "\ud8d1\uded7\uda70\udccd\ud842\udc31\ud87d\udeb5\uda50\ude9e\ud987\udc84\udb57\udf90\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64",
        5, 8974, 335994836, 7524546492572781692L, 40647L, true, true, (char) 35952, (char) 48029,
        Double.longBitsToDouble(0x3fae52bfc72d8d80L), Double.longBitsToDouble(0x3fb6b635f3f4ccb0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:1720843878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 8, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u22ea\u98e6", "\ud852\udfde\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\ud837\udcf8\uda7f\udf10\u5d49\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbcc\udf15",
        16, 43819, -378905479, 9200410382799349095L, 30368L, false, true, (char) 32323, (char) 43606,
        Double.longBitsToDouble(0x3fb6b635f448ccb0L), Double.longBitsToDouble(0x3fa6afe5a1220410L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 0, 9, 7, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u05dc\u98e6", "\000\ud89e\udc0e\000\000\ud833\udc19\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\ud9fd\udc64\ud8bf\udc58\udbcc\udf15",
        30, 99003, 52092, 9200409837338502503L, 30368L, false, false, (char) 40959, (char) 55512,
        Double.longBitsToDouble(0x3f4b1ae000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:1720843878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 14, 8, "\uda31\udfa4", "\ub04f\u383e\u72cb\u7a24\u0ca2", "\uda70\udccd",
        1, 96066, -2112612226, -4770786582327919843L, 21879L, false, false, (char) 47213, (char) 41236,
        Double.longBitsToDouble(0x3feb53733fd47b8cL), Double.longBitsToDouble(0x3fe958a0367c686cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:1720843878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 12, 7, "\uda31\udfa4", "\u65c1\uc990\u8a9d\u22ea\u98e6", "\ud907\udd19\ud842\udc45",
        29, 13142, -1110785398, 5558843941728629309L, -62533L, false, true, (char) 23392, (char) 41776,
        Double.longBitsToDouble(0x3febe343647fe944L), Double.longBitsToDouble(0x3fd677fae0ba9d24L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 0, 9, 7, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u22ea\u7a16", "",
        53, 54363, 1607123216, -3512490509945093407L, -21603L, true, false, (char) 49017, (char) 61958,
        Double.longBitsToDouble(0x3fd5b3b000000172L), Double.longBitsToDouble(0x3e4cac5018000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 0, 4, "\ud9d2\udcf5\ud88c\udcd7\ud8a1\udfc8\uda87\udf14\ud96f\uddc7\udb58\udc35\udba6\udf0b\udba5\udc8f\ud9fc\udffc\ud8d1\uded7", "\u7298\u0af2\uad0a\uc212\u6623", "\uda20\udc23\ud8bf\udc58",
        42, 53702, 1751945003, -1637960628877497217L, 70993L, false, false, (char) 11595, (char) 45361,
        Double.longBitsToDouble(0x3fe7223f642d7524L), Double.longBitsToDouble(0x3fe091020860071dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 15, 9, 8, "\uda31\udfa4", "\u1784\uc80a\ua6ff\u0896\u4c62", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\udb6c\udf1e\uda20\udc64\ud8d5\udff8\udb3c\udfac",
        -4, 99003, -381367428, 9200410382799349095L, 30368L, false, false, (char) 17851, (char) 11595,
        Double.longBitsToDouble(0x3fb6b635f3f4ccb0L), Double.longBitsToDouble(0x3fa695bca4a3d7e0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 1, 7, "\ube4a", "\u994a\u8ee2\ua6ff\u22ea\ubfb7\u5532\u6b0e\u35e0", "\uda93\udd12\ud863\udee9\uda53\udc00\ucadc\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbcc\udf15\ud856\udd02\ud975\udd52\ud806\ude25\ud8eb\udc05",
        24, 10701, 1089862976, -6521358874092986308L, -24314L, false, false, (char) 25243, (char) 6995,
        Double.longBitsToDouble(0x3fe060cc4abeb0aaL), Double.longBitsToDouble(0x3fe51f5948f55c51L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:\u895f\u3c9a\ud5e6\ua122\u9cee\u61a6\u89a6\u7298\uceb7\ua64d\u3a85\u8ca0\uba93\u551e\ua319\ucd78\uae3c\u5790 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 12, 7, "\uda31\udfa4\udbd5\udd59\ub7a1", "\u895f\u3c9a\ud5e6\ua122\u9cee\u61a6\u89a6\u7298\uceb7\ua64d\u3a85\u8ca0\uba93\u551e\ua319\ucd78\uae3c\u5790", "\ud8eb\udc4a\ud94e\ude08\ud97e\uddb4\ud943\udf21\uda92\udddd",
        36, 27218, -1718167462, 3132603727240883245L, 30156L, false, false, (char) 31352, (char) 32018,
        Double.longBitsToDouble(0x3fe00ddcd9b87df5L), Double.longBitsToDouble(0x3fe3f2f225d7c9dfL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 5, 1, 7, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u22ea\u98e6", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbcc\udf15",
        58, 99003, -381367428, 9200410382799349095L, 30368L, false, false, (char) 17851, (char) 11595,
        Double.longBitsToDouble(0x3fb6b635f3f4ccb0L), Double.longBitsToDouble(0x3fa695bca1220410L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 6, 9, "\uda55\udff1", "\u994a\u8ee2\ua64c\u22ea\u0795", "\uda70\udccb\ud842\udc31\udb5c\udcb1\ud9e8\udcd8\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\ud9d5\udf63\udbce\udf4b",
        16, 32491, 740149126, 9200410511648367975L, -34502L, false, false, (char) 45918, (char) 619,
        Double.longBitsToDouble(0x3fa6f7bcc8ac2950L), Double.longBitsToDouble(0x3fb90ddcddf26978L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 15, 1, 7, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u22ea\u98e6", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\udb2c\udfcb\ud8bf\udc18\udbcc\udf15",
        59, 99003, -381367428, 9200410382799349095L, 30368L, false, false, (char) 17851, (char) 11609,
        Double.longBitsToDouble(0x3fb6b635c61cfe58L), Double.longBitsToDouble(0x3fa6b7aa21220410L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 13, 2, 7, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u22ea\u98e6", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda62\udc1b\ud8e9\ude0c\udb58\udc51\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbcc\udf15",
        16, 99003, -381367428, 9200410382799349095L, 30368L, false, false, (char) 17851, (char) 11595,
        Double.longBitsToDouble(0x3fb6b635f3f4ccb0L), Double.longBitsToDouble(0x3fa695bca1220410L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Integer:1146765336 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 11, "\ud98a\udf69\udb58\udd42\ub84b\uda87\udf14\ud96f\uddc7\udb58\udc65\udb95\udce9\ud955\udc79", "\u61a6\ub7de\u7f35\uc53b\u8c68\u9b8c\ub397\ud1ca\u551e\ubb60\ucd78\uae3c", "\udb84\ude24\ud8eb\udc05\ud97e\udd08\ud97e\uddb4\ua114\uda09\ude9c\ud9b4\udd7a\ud8b8\ude23\uda40\udd5f\udb70\udd0d\uda89\ude13\udae8\udd2e\ud9eb\uddab\udbfb\udd91\ud80d\uddd5\u71e4\ud9a3\udc0f\udaed\udc2e\udaed\ude81\udb9b\udf2c\uda0e\udd5e\ud9f3\udf10",
        37, 65142, 1768750184, -14220266624989806L, -84618L, true, true, (char) 29643, (char) 16707,
        Double.longBitsToDouble(0x3fd3d9377023128aL), Double.longBitsToDouble(0x3fe07d6ce7ac4095L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:2042502734 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 15, "\uda31\udfe4\udbd5\udd59\u77d3\uda87\udf14\ud96f\uddc7\udb58\udc35\ud923\udcf0\ud955\udc57\ud96b\udee3\ud8d1\uded7\ud8c8\udd19\uda07\udf48\udb3a\udcd0\udb50\udd7b\udbab\udcf2\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\udb71\udc51\udbcc\udf15\ud856\udd02\ud975\udd52\uda1b\uddf3\ud8eb\udc3f\ud94e\ude08\ud97e\uddb4\ua114\uda73\udd52\udbba\udfa5\ud936\uddd2\udbe2\ude49\udb70\udd0d\ud953\udcd9\ud89e\udf5f\ud966\uddc8\udbe3\uddf3\ud8fe\udd49\uda21\udeed\ud983\udd8a\uda28\udd23", "\ua10f\ud670\u79f4\u2624\u2060\u6a44\u585f\uac46\u4eae\u6bd5\u17fc\ucede\u1102", "\ud808\udfc9\ud94a\udfa8\uda9b\udf34\ud8f9\uddd3\ud84d\udc90\uda9b\udcd0\ud97e\ude73\udac4\udd63",
        44, 11406, 42059373, -8261953148920694446L, -65883L, false, false, (char) 36383, (char) 37267,
        Double.longBitsToDouble(0x3fe5097bd190c1a3L), Double.longBitsToDouble(0x3feb167faf035972L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\u994a\u8ee2\ua6ff\u22ea\u60e7 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 12, 14, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u22ea\u60e7", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbcc\udf15",
        16, 99003, -381367428, 9200410382799349095L, 30368L, false, false, (char) 17851, (char) 11595,
        Double.longBitsToDouble(0x3fb6b635f3f4ccb0L), Double.longBitsToDouble(0x3fa695bca1220410L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 15, 1, 1, "\uda31\udfa4", "\u994a\u7d1a\u7c89\u82e0\u98e6", "\ud88f\udcb7\ud849\uddf1\udac4\udf72\ud9e1\udda0\udb47\udeca\ud948\udd11\udbb1\udf20\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbcc\udf15",
        21, 99063, -381367428, 9200410382799349095L, -22193L, false, false, (char) 17851, (char) 11595,
        Double.longBitsToDouble(0x3fd75ab84d02864aL), Double.longBitsToDouble(0x3fdc692764244054L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 8, 7, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u22ea\u98e6", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\udb57\udfa8\udb42\udd17\ud9b7\udfcc\udb9b\udcfa\uda20\udc64\ud8bf\udc58\udbcc\udf15",
        16, 99003, -381367516, 9200410382799349095L, 30368L, false, false, (char) 17851, (char) 11595,
        Double.longBitsToDouble(0x3fb6b635f3f4ccb0L), Double.longBitsToDouble(0x3fa695bca1220410L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 3, 13, 3, "\uda31\udfa4\ud8cb\udf8e\ua7ce\uda87\udf14\ud96f\uddc7\udb58\udc35\udb95\udce9\ud955\udc79\ud96b\udee3", "\u89a6\u05db\ucb8f\u702a\u8723\ub334\uba93\u551e\ua319\ucd78\uae3c\u5790\u82ee", "\ud94e\ude08\ud9c0\uddb5\ua114\uda73\udd52",
        36, 27218, -1718208903, 3132603727240883245L, 5845L, true, true, (char) 623, (char) 59553,
        Double.longBitsToDouble(0x3fe387bc3d158066L), Double.longBitsToDouble(0x3fcf672fab488898L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 4, 11, 5, "\uda31\udfa4", "\u994a\u8ee2\ua6ff\u6a26\u3ac7", "\uda70\udccd\ud842\udc31\ud87d\udeb5\ud8e3\udfe2\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\ud812\udf63\ud902\udc71\ud856\udd02",
        -2, 57523, 1652466447, 5661628806251886685L, -56082L, false, false, (char) 55316, (char) 6054,
        Double.longBitsToDouble(0x3fe091020acf40c1L), Double.longBitsToDouble(0x3fcbacef01d13d78L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 1, 7, "\uda31\udfa4", "\ua1c3\u4a2f\ud78f\uc6ab\u98e6\ucdfb\u52f8\u4bf1\u8953\u49b7\u99ae\u8c68\ua2b0\u6871\uc171\u05d3\u42a0\u97ad\ua5e2\u5790\u82ee\u088b\ub493\u5ad4\u29a7\ud23d\ubcf9\ud0dc\u3a9e\u59de\u5a57\u4a68\u4fab\uc5f3\ud6d1\u1d42\u2f23\u3b8e\u4d58\ubbfc\ua8fb\u4279\ub754\u2e2a\u504c\uc022\u7bc8\u1203\u9451\ud61d\u5f25\u47d5\u228d\u3f08\u4adb\ub78f\u6b4e\u09dc\u371c\u28d1\u1c27\u9162\u6f60\u54b8\u8868\uaebe\u924b\ud64e\u7898\u0d04\ua7e2\u3434\u0fee\u299c\u33e6\u21c8\ucbef\u17f8\u9690\u71a7\uc514\ud242\u0659\u6d57\ucbb9\u454e", "\uda85\udeaa\u39d0\ud9f4\udcdc",
        20, 66827, 888540278, 2774403985928658049L, -9821L, false, true, (char) 30129, (char) 21064,
        Double.longBitsToDouble(0x3fa7bde04083da50L), Double.longBitsToDouble(0x3fc1bf4124d759a4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 0, 9, 7, "\ud948\udcb0", "\u89e2", "\udb95\udce9",
        54, 64712, -1159603478, 4148823961870911851L, -91808L, false, false, (char) 47133, (char) 32609,
        Double.longBitsToDouble(0x3fadf648ec008ba0L), Double.longBitsToDouble(0x3fccfe20056cece8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 0, 4, "\uda31\udfa4\udbd5\udd59\ub7a1\uda87\udf14\ud96f\uddc7\udb58\udc35\udb95\udce9\udaaa\udc42\ud96b\udee3\ud8d1\uded7\uda70\udccd\ud993\udf3a\ud913\udf62\uda49\uddbb\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uf867\uda4b\udd0b\uda13\udddf\udbcc\udf15\ud856\udd02\ud975\udd52\ud806\ude25\ud8eb\udc05\ud94e\ude08\ud97e\uddb4\udbf9\udf13\uda73\udd52\ud8b7\udc83\ud8b8\ude23\udbe2\ude50\udb70\udd0d\uda89\ude13\udb1c\udd27\udb58\uddcb\ud8e8\udcf1\ud8e3\udf86\udacd\udeff\ud8e2\udea2\udb63\udf83\uda91\ude90\ud86f\udd34\ud8c2\uddd3\ud87a\udc79\udbb8\udf4b", "\u9510\ub536\u228b\u4503", "\ud842\ude56\ud9dc\udf86\ud858\udda7\udb77\ude1d\ud9e2\udee0\udbda\ude3d\udba0\udcf1\udbb3\udd32\ud929\udfbf\ud963\uddf5\ud8c9\ude65\udbe2\ude39\ud99a\udf06\uda70\udc0b\ud9cc\udf4f\uda9f\udce1\ud9fd\ude55\udb7e\udd20\uda0a\uddb6\ud9e7\uddf1\udb4c\ude9d\udbdf\udc5a\udbfe\udee3\udad6\ude3d\u2cd6\uda8b\udcc1\ud800\udc2c\udb4f\udf3a\uda93\ude57\ud83b\ude3a\uda09\udcd5\udbce\udf08\udb27\udc81\udad1\udd32\udb80\udec7\ud9b5\udffa",
        29, 28313, -1486171211, 4213362719954599736L, 19088L, true, true, (char) 64308, (char) 39969,
        Double.longBitsToDouble(0x3faeb50dbcb716f0L), Double.longBitsToDouble(0x3fe0fe6caf745c08L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:1358683428 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\ud80e\ude5c\ud862\udcba\ud91e\udf58\ud803\uded5 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 7, 1, "\ud80e\ude5c\ud862\udcba\ud91e\udf58\ud803\uded5", "\u22ea\u98e6\ua122\uae75", "\udb1c\udcc9\udbff\udfd6\udbf5\udec1\udb34\udc69\ud9a1\udfe4\uda21\uded6\uda86\udfe5",
        3, 61355, 2072832974, 1443086832805646123L, 31389L, false, true, (char) 34543, (char) 5123,
        Double.longBitsToDouble(0x3fe54207a83ca57fL), Double.longBitsToDouble(0x3fbcb63636f5beb8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\u994a\u8ee2\u6291\u2228\u98e6\ua122\ua8fe\u61a6\u2652\u7e53\uceb7\u8c68 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 16, "\udbf1\udf44", "\u994a\u8ee2\u6291\u2228\u98e6\ua122\ua8fe\u61a6\u2652\u7e53\uceb7\u8c68", "\uc890\ud8e0\ude0e\uda20\udc64\ud8d6\ude58",
        -1, 67836, 1751945003, 1361155247767585568L, -56082L, false, false, (char) 55316, (char) 52921,
        Double.longBitsToDouble(0x3fe091020e3ee1d7L), Double.longBitsToDouble(0x3fe0125203707e0dL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:1734111782 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbf1\udf44 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 7, 8, "\udbf1\udf44", "\ub7cf\u8629\ub89c", "\uda9e\udf05",
        22, 49522, -174797916, 6902554550331318398L, 97859L, true, false, (char) 3021, (char) 58237,
        Double.longBitsToDouble(0x3fccfe3cc56cece8L), Double.longBitsToDouble(0x3fee7195cfd47b8cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 5, "\u00ae", "\u994a\u8ee2\ua6ff\u22ea\u98e6l\u1509\u61a6\u2652\ucccb\000\000", "",
        27, 65971, 993692903, 10286446674126L, -63349L, false, true, (char) 38402, (char) 39030,
        Double.longBitsToDouble(0x3fb753a480000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:1734111782 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 7, 7, "\udbf1\udf44", "\u994a\u8ee2\ua6ff\u22ea\u98e6\ua122\ua8fe\u61a6\ud5f7\u57e8\uceb7\u8c68", "\uc890\ud8e0\ude0e\ufc94\ud8bf\udcdd",
        -1, 67836, 1751945003, 1361155466810917664L, 86626L, false, true, (char) 6890, (char) 375,
        Double.longBitsToDouble(0x3fe6b6a89c3809ebL), Double.longBitsToDouble(0x3fe7635cdbaca57fL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 0, 0, 10, "\uda31\udfa4\udbd5\udd59", "\u8ee2\ua6ff\u22ea", "\ud8d1\uded7i\ud841\udfc6\ud84d\uddb5\uda50\ude9e\ud986\udff6\udb57\udf90\udb42\udcda\udac4\udcbe\uda2d\udddf\ud9ab\udcea",
        45, 8974, 335994836, 7524546307889187964L, 21600L, true, true, (char) 10234, (char) 47784,
        Double.longBitsToDouble(0x3fae52bfc72d8d80L), Double.longBitsToDouble(0x3fb6b635f3f4ccb0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 4, 4, 7, "\uda31\udfa4\udbd5\udd59", "\u8ee2\ua6ff\u22ea", "\ud8d1\uded7\uda70\udccd\ud842\udc31\ud87d\udeb5\uda50\ude9e\ud987\udc84\udb57\udf90\udb42\udd17\udab2\udcb3\uda2d\udddf\uda20\udc64",
        5, 8974, 335994836, 7524546492572781692L, 40647L, true, true, (char) 35952, (char) 48029,
        Double.longBitsToDouble(0x3fae52bfc72d8d80L), Double.longBitsToDouble(0x3fb6b635c3f4ccb0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\u8ee2\ua6ff\u22ea |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 7, 13, 7, "\uda31\udfa4\udbd5\udd59", "\u8ee2\ua6ff\u22ea", "\ud8d1\uded7\uda70\udccd\ud842\udc31\ud87d\udeb5\uda50\ude9e\ud987\udc84\ud862\ude35\uda11\udf53\udac4\udcbe\uda2d\udddf\uda20\udc64",
        5, 8974, 335994836, 7524546492572781692L, 40647L, true, true, (char) 35952, (char) 48029,
        Double.longBitsToDouble(0x3fae52bfc72d8d80L), Double.longBitsToDouble(0x3fb6b635f3f4ccb0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:\u8ee2 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 7, "\ud897\udc4d\udbbd\udc57", "\u8ee2", "\ud91b\udc94\ud96b\udee3\ud817\udd58\uda70\udccd\ud842\udc31\ud87d\udeb5",
        12, 39990, 1294269189, -1400282771414650821L, -4999L, true, true, (char) 7815, (char) 57761,
        Double.longBitsToDouble(0x3fe958a4fc7c686cL), Double.longBitsToDouble(0x3fbfc46dab3bfd70L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:1901362222 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 15, 7, "\uda31\udfa4\udbd5\udd59", "\u8ee2\u70be\u22ea", "\ud8d1\uded7\uda70\udccd\ud842\udc31\ud87d\udeb5\uda50\ude9e\ud8f0\udc38\u368c\ud87f\udc4d\udac4\udcbe\uda2d\udddf\uda20\udc64",
        5, 8974, 335994836, 7524546492572781692L, 40647L, true, true, (char) 35952, (char) 48029,
        Double.longBitsToDouble(0x3fae52bfc72d8d80L), Double.longBitsToDouble(0x3fe2d6c6b8c5f78cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 7, "\uda31\udfa4\udbd5\udd59", "\u59e2\ua6ff\u84df", "\ud8d1\uded7\uda70\udccd\ud842\udc31\ud87d\udeb5\uda50\ude9e\ud987\udc84\udb57\udf90\udb42\udd17\udac4\udcbe\ud857\udf03\uda20\udc35",
        5, 8974, 335994836, 7524546492572781692L, 40647L, true, true, (char) 35952, (char) 48029,
        Double.longBitsToDouble(0x3fae52e5c72d8d80L), Double.longBitsToDouble(0x3fb6b635f3f4ccb0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:\u8ee2\ua6ff\u22ea |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\uda31\udfa4\u6d5d |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 7, 7, 7, "\uda31\udfa4\u6d5d", "\u8ee2\ua6ff\u22ea", "\ud8d1\uded7\uda70\udccd\ud842\udc31\ud87d\udeb5\uda50\ude9e\ud987\udc84\udb57\udf90\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64",
        5, 8974, -622141484, 7524457436425899132L, 40647L, true, true, (char) 48117, (char) 48029,
        Double.longBitsToDouble(0x3fae52bfc72d8d80L), Double.longBitsToDouble(0x3fb6b635d0103c88L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "", "", "\ud96f\uddc7",
        51, 14939, -1364088508, 4238427572261739242L, -48544L, false, true, (char) 32840, (char) 37410,
        Double.longBitsToDouble(0x3fe8edee50c71f00L), Double.longBitsToDouble(0x3f778bc400000000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\u7298\u0af2\uad0a\uc212\u6623\u1b08\u633e\ua29b\ucd78\u443d\u205a\u02be\u088b\u23d3\u2c06\u743a\u8ed0\u561c\u4562\u6205\u6547\uc17e\u1089\u5d26\ua65f\u1998\u43d5\u4c37\u738b\u2068\ua28b\u82f1\u09ad\u9c07\ua54e\u8184\u31c5\uc02f\u8500\u94c2\uce5b\ud41a\ua37f\u59fc\u64ec\u52a3 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 7, 13, "\uda04\udf02\ud88c\udcd7\ud8a1\udfc8\udab1\udfc9\ud96f\ude5f\udb58\udc35\udba6\udf0b\udba5\udc8f\ud9fc\udffc\ud8d1\uded7", "\u7298\u0af2\uad0a\uc212\u6623\u1b08\u633e\ua29b\ucd78\u443d\u205a\u02be\u088b\u23d3\u2c06\u743a\u8ed0\u561c\u4562\u6205\u6547\uc17e\u1089\u5d26\ua65f\u1998\u43d5\u4c37\u738b\u2068\ua28b\u82f1\u09ad\u9c07\ua54e\u8184\u31c5\uc02f\u8500\u94c2\uce5b\ud41a\ua37f\u59fc\u64ec\u52a3", "\udbfe\udd60\udbbc\udcb7\udb6a\udde7\ud972\udf10\ud908\udd0b\ud811\ude24\uda13\udc20\ud9c6\udc66\udbfc\udec3\uda7f\ude3f",
        40, 43350, 1509146627, 3071719521729803008L, 7945L, false, false, (char) 46856, (char) 14128,
        Double.longBitsToDouble(0x3fdcab02e05fcc2eL), Double.longBitsToDouble(0x3fec290302e55b53L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 3, 9, "\udbf1\udf44\ud862\udcba\ud99c\udeb5\ud9ba\udf2e\ud9b6\uddd1\udb64\ude4e\udb5c\udde7\ud8bb\udcb5\ud9fa\udc2b\ud8a4\ude54\ud9f1\uded0\udb09\udfac\uda75\udefe\uda62\udce4\uda80\udfe9\udbfc\udeea\udac3\udfea\uc890\ud8e0\ude0e\uda20\udc64\ud9db\udfee\udbcc\udf15\ud856\udd02\ud975\udd52\udbed\udc98\ud87c\uddec\udbf9\uddf8\udba3\udefe\u0cd5\ud9a6\udf7a\udba1\uddd4\uda71\ude0d\ud8ca\udfcd\ud804\udeb0", "\ubcc2\u4768\u3179\u508f\uaa01", "\uda52\udd03\ud955\udf56\udadb\udfcb\uda59\udf19\ud9df\udfb4\udadc\udd7c\uda6b\uded1\udb69\ude50\ud80b\ude31\ud828\udd13\ud833\udfbd\udb77\udffd\ud806\udce8\ud91c\ude3c\udb06\udcf5\udb60\udec3\udbc1\udea7\ud94c\udcb8",
        25, 14026, 1772359020, -3964320171322357514L, 42122L, false, true, (char) 60267, (char) 15928,
        Double.longBitsToDouble(0x3fe2a86e3ef460a2L), Double.longBitsToDouble(0x3fef592f09308252L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=null |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 5, 15, "\udb44\udd13", "\u5970\u96e6\u12fc", "\ud94f\udf17",
        32, 611, -1569372880, 6902554550331318398L, 83781L, true, false, (char) 53619, (char) 50889,
        Double.longBitsToDouble(0x3fccfe3cdd6cece8L), Double.longBitsToDouble(0x3febf195cfd47b8cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.lang3.text.ExtendedMessageFormat:org.apache.commons.lang3.text.ExtendedMessageFormat@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 16, "\000", "", "\ud988\udfec",
        49, 16492, 986835820, 1005032019305L, -21355L, false, false, (char) 37410, (char) 47335,
        Double.longBitsToDouble(0x3fe1ea6927000000L), Double.longBitsToDouble(0x3fe718b4d80000e6L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:\ub994\ud277\u8f15\u0d3e\u9658\u67a0\u4549\u51ea\ua922\u6e51 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\uda31\udfa4\udb66\udce2\udad3\udc8c\uda87\udef8\ud96f\uddc7\udb58\udc35\udb95\udce9\ud955\udc79\ud96b\udee3\ud8d1\uded7\uda70\udccd\ud842\udc31\ud87d\udeb5\uda50\ude9e\ud987\udc84\ud862\ude35\uda11\udf53\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbbb\udd15\ud856\udd02\ud9a0\ude26\ud8d3\udc4b\ud8eb\udc05\udb7f\udc41\ud84d\udd90\u084a\uda73\udd52\ud90b\udded\ud8b8\ude23\udbe2\ude50\udb1f\udfc5\u39a1\ud93a\udc24\ud980\ude5c\ud83a\ude20\ud8c9\ude83\uda1b\udeba\uda28\uddf1\udafc\udc45\ud96d\udc84\ud8d1\udeea\ud880\udf71\udaa3\udc72 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 7, 7, 8, "\uda31\udfa4\udb66\udce2\udad3\udc8c\uda87\udef8\ud96f\uddc7\udb58\udc35\udb95\udce9\ud955\udc79\ud96b\udee3\ud8d1\uded7\uda70\udccd\ud842\udc31\ud87d\udeb5\uda50\ude9e\ud987\udc84\ud862\ude35\uda11\udf53\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbbb\udd15\ud856\udd02\ud9a0\ude26\ud8d3\udc4b\ud8eb\udc05\udb7f\udc41\ud84d\udd90\u084a\uda73\udd52\ud90b\udded\ud8b8\ude23\udbe2\ude50\udb1f\udfc5\u39a1\ud93a\udc24\ud980\ude5c\ud83a\ude20\ud8c9\ude83\uda1b\udeba\uda28\uddf1\udafc\udc45\ud96d\udc84\ud8d1\udeea\ud880\udf71\udaa3\udc72", "\ub994\ud277\u8f15\u0d3e\u9658\u67a0\u4549\u51ea\ua922\u6e51", "\uda89\uddb0\ud967\ude80\ud874\udcc7\ud9b1\udda9\uda3b\udfb6\ud855\udd2a\ud96f\udd3a\ud96a\ude05\ud8b5\udf31\ud955\udd61\ud9eb\uded9",
        1, 45608, 625771680, 4942613679414001328L, -94976L, true, false, (char) 61622, (char) 37722,
        Double.longBitsToDouble(0x3fd5173c8dd4588cL), Double.longBitsToDouble(0x3fe0d4f56eb8383cL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String:\u125d |this=org.apache.commons.lang3.text.ExtendedMessageFormat:org.apache.commons.lang3.text.ExtendedMessageFormat@0\0121=java.lang.Boolean:false |this=org.apache.commons.lang3.text.ExtendedMessageFormat:org.apache.commons.lang3.text.ExtendedMessageFormat@0\012",
        Z.run(T, 2, 7, 0, 0, "", "\u125d", "\udb58\udc35\udb95\udce9\ud955\udc79\ud813\uded7\ud8d1\uded7\uda70\udccd\ud8d0\udd79\ud8b5\udd99\uda50\ude9e\ud987\udc84\ud862\ude35\uda11\udf53\udac4\udcbe\udae9\udddd",
        3, 61355, 2072832974, 1443086832244883499L, -100000L, false, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe54207a83ca57fL), Double.longBitsToDouble(0x3f4b000000000000L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 3, 15, "\uda3f\udfa4\udac4\udfd1", "\u59e2\ua6ff\u84df\u24d2", "\udad4\udd60\ud924\udfc6\ud87d\udeb5\uda50\ude9e\ud987\udc84\udb57\udf90\udb42\udd17\udac4\udcbe\ud857\udf03\udb30\uddbd\ud9b3\udef6",
        46, 67763, 1751945003, 1276291640817870299L, 9771L, false, false, (char) 48029, (char) 17927,
        Double.longBitsToDouble(0x3fbcb63602d6c6b8L), Double.longBitsToDouble(0x3fe3f4ccb1643ec7L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:1720843878 |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 1, 7, "\uda31\udfa4", "\u994a\u01e2\ua6ff\u22ea\u98e6", "\uda70\udccd\ud842\udc31\ud87d\udeb5\uda49\udd9e\ud863\udefa\udb57\udfa8\udb42\udd17\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbac\udd08",
        16, 99003, -381367428, 9200410382799349095L, 30368L, false, false, (char) 956, (char) 10327,
        Double.longBitsToDouble(0x3fb6b635f3f4ccb0L), Double.longBitsToDouble(0x3fa695bca1220410L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 15, 9, 8, "\uda31\udfa4", "\u1784\uc80a\ua6ff\u0896\u4c62\ua122\ua8fe\u61a6\u50c2\u7298\uceb7\u8c68\u868b\ub334\uba93\ud6a5\u5fbc\u4f7c\u7c9d\u2982\u82ee\u088b\u23d3\u5a86\u6357\ud23d\u6f64\u31d4\u3033\u6d95\u6204\u850f\u3378\u1b95\u0e78\u572b\ub8a7\u3892\u364f\ud4ab\u45a0\u58be\u6897\u399b\ubab6\u4b4e\u9c94\u937f\u8c13\u9750\ubad7\u5f1d\u5004\u0b13\ubc51\u670f\u524d\u3468\ucea4\u0f34\u2976\u33e3\u4292\ucc72\ud123\u5aeb\u438d\u6ba9\u7093\u39ef\u1512\u648e\u1f6d\u97f2\u530a\ub9b7\u21e1\u391b\u01ed\u8bfd\u0e48\u55f7\ua396\ua2a5\uaed3\u57ed\uac14\ud413\u5a39\u9a5e\u7d68\u3c1e\u184b\u9663\u5d72\u8771\u28be\u7b52", "\udbcc\udd60\udbbf\udef6\udba3\udc89\ud965\uddac\ud87d\udd61\ud871\udc02\uda83\udd43\ud82b\udcae\uda07\udf90\udbf9\udd6e\udbf7\udf97\udbdb\udc02\ud8f9\udea5\uda54\udecc\ud95b\udd32\ud9cf\udfa0\ueef8\ud823\uded3\ud8b9\udfef\ud954\udc2a\ud9d9\udf20\ud950\udf5b\ud88a\udee0\ud8bb\udd74\udb20\udedb\u1f80\ud8fe\udde9\udb1b\udce7\ud9f4\ude36\uda86\udeb3\udb81\udfe5\udb48\udccb\ud8c6\udc44\uda2c\udc61\udb56\udf06\u4086\ud8f1\udccf\ud8cb\udc7b\udb96\udcc7\udb30\udc8f\udb3b\udc58\u37c3\uebc4\udb0b\uddc9\u994f\u17f2\udbf1\udc47\uda3a\ude29\uda3e\ude0b\uda02\udcb7\uda3f\udc52\udb9c\uded2\ud8d8\udf38\udbfc\ude03\udb4a\udc08\udaf1\udc98\udbe6\udf71\ud8a4\udcaa\uda27\ude5c\udb74\udc8a\ud9e6\udd66\uda70\udf1b\udacc\uddc6\udb13\udddc\ud935\udf8e\udb74\udf4c\ud803\ude7f",
        23, 44800, -1137233918, 5082543004014769532L, -99184L, true, false, (char) 33508, (char) 36926,
        Double.longBitsToDouble(0x3fef1a8fb78de906L), Double.longBitsToDouble(0x3fe73092ea6ead6aL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:\u895f\u3c9a\ud5e6\ua122\u9cee\u61a6\u89a6\u7298\uceb7\ua64d\u3a85\u8ca0\uba93\u551e\ua319\ucd78\u2eb3} |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 12, 7, "\uda31\udfa4\udbd5\udd59\ub7a1", "\u895f\u3c9a\ud5e6\ua122\u9cee\u61a6\u89a6\u7298\uceb7\ua64d\u3a85\u8ca0\uba93\u551e\ua319\ucd78\u2eb3}", "\ud8eb\udc4a\ud94e\ude08\ud97e\uddb4\ud943\udf21\uda92\udddd",
        15, 27218, -1718167462, 3132603727240883245L, 30156L, false, false, (char) 31352, (char) 32018,
        Double.longBitsToDouble(0x3fe00ddcd9b87df5L), Double.longBitsToDouble(0x3fe3f2f225d7c9dfL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String:\uba39\u7baf\u7e8d\u7c1d |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\0121=java.lang.String:\uda66\udda4\udb66\udce2\udad3\udc8c\uda87\udef8\ud96f\uddc7\udb58\udc35\udb95\udce9\ud955\udc79\ud96b\udee3\ud8d1\uded7\uda70\udccd\ud841\udfef\ud87d\udeb5\uda50\ude9e\ud987\udc84\ud862\ude35\uda11\udf53\uda00\udfe6\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbbb\udd15\ud856\udd02\ud9a0\ude26\ud8d3\udc4b\ud8eb\udc05\udb7f\udc41\ud84d\udd90\u084a\uda73\udd52\ud90b\udded\ud8b8\ude23\udbe2\ude50\udb1f\udfc5\u39a1\ud93a\udc24\udbfb\udf5a\ud83a\ude20\ud8c9\ude83\uda1b\udeba\uda28\uddf1\udafc\udc45\ud96d\udc84\ud8d1\udeea\ud880\udf71\udaa3\udc72\ud939\udfc4\ud830\udc0a\ud8b1\udd69\ud9e5\udeee\udb90\udf8d\uf44a\uda07\ude53\udab7\udf0c\ud804\udd03\ud98e\udde8\ud84f\udda1\ud82c\udd14\udae0\udce1\udab9\udc43\uda89\uddb0\ud967\ude80\ud874\udcc7\ud9b1\udda9\uda3b\udfb6\ud855\udd2a |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 7, 7, 11, "\uda66\udda4\udb66\udce2\udad3\udc8c\uda87\udef8\ud96f\uddc7\udb58\udc35\udb95\udce9\ud955\udc79\ud96b\udee3\ud8d1\uded7\uda70\udccd\ud841\udfef\ud87d\udeb5\uda50\ude9e\ud987\udc84\ud862\ude35\uda11\udf53\uda00\udfe6\uda2d\udddf\uda20\udc64\ud8bf\udc58\udbbb\udd15\ud856\udd02\ud9a0\ude26\ud8d3\udc4b\ud8eb\udc05\udb7f\udc41\ud84d\udd90\u084a\uda73\udd52\ud90b\udded\ud8b8\ude23\udbe2\ude50\udb1f\udfc5\u39a1\ud93a\udc24\udbfb\udf5a\ud83a\ude20\ud8c9\ude83\uda1b\udeba\uda28\uddf1\udafc\udc45\ud96d\udc84\ud8d1\udeea\ud880\udf71\udaa3\udc72\ud939\udfc4\ud830\udc0a\ud8b1\udd69\ud9e5\udeee\udb90\udf8d\uf44a\uda07\ude53\udab7\udf0c\ud804\udd03\ud98e\udde8\ud84f\udda1\ud82c\udd14\udae0\udce1\udab9\udc43\uda89\uddb0\ud967\ude80\ud874\udcc7\ud9b1\udda9\uda3b\udfb6\ud855\udd2a", "\uba39\u7baf\u7e8d\u7c1d", "\udb43\udcfe\udaee\udf5e\udb02\udcb7\ud878\udddd\uda02\udeae\ud8a2\udf4f\udb18\ude8c\udbbf\udfec\udae0\udd2d",
        8, 53122, 140195833, 245046587004215326L, -35687L, true, false, (char) 32443, (char) 21443,
        Double.longBitsToDouble(0x3fd02643f0952830L), Double.longBitsToDouble(0x3fdf8873ee536816L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String:\u3d59\u7a7f\u39bc\ud22f\u7ce4\u1326\u1796\u65cf\u1ba0\u8c44\u2eba\u9a8e\u43cc\ua99e\ub3f0\ubb54\u4b2f\u036d\u0dcf\u759b\u0f25\uaec1\ub82e\u1ee2\u4e8c\uc256'\uc8ab |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 7, 5, 16, "\uda31\udfa4\udbd5\udd59\ud8c2\udef7\udbeb\ude78\ud84f\ude4e\ud95e\udfd0\udb95\udff9\ud964\udd79\ud96b\udee3\udb23\udff2\uda70\udccd\uda80\udd28\ud87d\udeb5\uda49\udd9e\udb21\udf19\ud9eb\ude1c\ud92e\udec6\udac4\udcbe\uda2d\udddf\uda20\udc64\ud8bf\udc58\ud880\udf38\uda45\udc7e\uda9b\udf96\ud806\ude25\ud8d3\udd4a\ud94e\ude08\ud97e\uddb4\ud943\udf21\uda92\udddd\ud9a6\udf3a\ud8b8\ude23\udbb6\udc50\udb70\udd0d\uda89\ude13\ud8ae\udf51\uda5f\udfdb\ub657\ud92a\udcc4\ud89e\uddf5\udb6c\udfc6\ud87c\udd6f\ud98f\udf4d\ud9b9\udc27\ud98b\udc0c\udb2f\uddb8\ud985\udc74\ud9b0\uddd5\ud827\udfd4\udad6\udf45\ub426\ud843\udf27\ud899\udfa2\udbf4\udf75\ud854\udf5d\uda1e\uddc9", "\u3d59\u7a7f\u39bc\ud22f\u7ce4\u1326\u1796\u65cf\u1ba0\u8c44\u2eba\u9a8e\u43cc\ua99e\ub3f0\ubb54\u4b2f\u036d\u0dcf\u759b\u0f25\uaec1\ub82e\u1ee2\u4e8c\uc256'\uc8ab", "\ud8cf\udcc4",
        1, 19268, -1066894748, -7884578858550340072L, -9520L, false, false, (char) 3726, (char) 49829,
        Double.longBitsToDouble(0x3fb14ea3d1fcbce8L), Double.longBitsToDouble(0x3feec1535617a3f7L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang3.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 3, 5, 16, "\uda31\udfa4\udbd5\udd59\ud8c2\udef7\udbeb\ude78\ud84f\ude4e\ud95e\udfd0\udb95\udff9\ud964\udd79\ud96b\udee3\udb23\udff2\uda70\udccd\uda80\udd28\ud87d\udeb5\uda49\udd9e\udb21\udf19\udb51\ude0f\ud92e\udec6\udac4\udcbe\u00c0\uda20\udc64\ud8bf\udc58\ud880\udf38\uda45\udc7e\uda9b\udf96\ud806\ude25\ud8d3\udd4a\ud94e\ude08\ud97e\uddb4\ud943\udf21\uda92\udddd\ud9a6\udf3a\udaaf\udc7e\udbb6\udc50\udb70\udd0d\uda89\ude13\ud8ae\udf51\uda5f\udfdb\ub657\ud92a\udcc4\ud89e\uddf5\udb6c\udfc6\ud87c\udd6f\ud98f\udf4d\ud9b9\udc27\ud98b\udc0c\u87d2\000\ud994\ude49\ud827\udfd4\udad6\udf45\ub426\ud843\udf27\ud899\udfa2\udbf4\udf75\ud854\udf5d\u00d6", "\u3d59\u7a7f\u39bc\ud22f\u7ce4\u1326\u1796\u65cf\u1ba0\u8c44\u2eba\u9a8e\u43cc\ua99e\ub3f0\ubb54\u4b2f\u036d\u0dcf\u759b\u0f25\uaec1\ub82e\u1ee2\u4e8c\uc256'\uc8ab", "\ud8cf\udcc4",
        1, 58460, -1066894848, -7884578858550340072L, -9520L, false, false, (char) 3726, (char) 49829,
        Double.longBitsToDouble(0x3f2d0023f979d000L), Double.longBitsToDouble(0x3feec1535617a3f7L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|equals|java.lang.Object|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|hashCode||new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|appendQuotedString|java.lang.String,java.text.ParsePosition,java.lang.StringBuilder,boolean|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|applyPattern|java.lang.String|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|containsElements|java.util.Collection|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|getFormat|java.lang.String|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|getQuotedString|java.lang.String,java.text.ParsePosition,boolean|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|insertFormats|java.lang.String,java.util.ArrayList|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|next|java.text.ParsePosition|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|parseFormatDescription|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|readArgumentIndex|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|seekNonWs|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|setFormat|int,java.text.Format|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|setFormatByArgumentIndex|int,java.text.Format|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|setFormats|[Ljava.text.Format;|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|setFormatsByArgumentIndex|[Ljava.text.Format;|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|equals|java.lang.Object|new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang3.text.ExtendedMessageFormat|hashCode||new:org.apache.commons.lang3.text.ExtendedMessageFormat:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
