package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class ArrayUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, -935462874208487979]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 50]] |a0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\012",
        Z.run(T, 2, 32, 27, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935462874208487979L, -24758L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, -2795081205110500999]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 17]] |a0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\012",
        Z.run(T, 2, 32, 27, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\udada\udf24\ud8fb\udea7\udaa8\ude99\udb80\udcc9\ud937\udfdf", "\u38d8\ua12b\ud3eb\u133a\u8cf7\ub5d1\uae94", "\udbab\udf53\udb58\udc8a",
        17, 51090, -1737694849, -2795081205110500999L, -62961L, false, false, (char) 34993, (char) 62867,
        Double.longBitsToDouble(0x3fdf5343fcdfac0eL), Double.longBitsToDouble(0x3fe2bdd4b5814a8bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 4028285464244511651]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 24]] |a0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\012",
        Z.run(T, 2, 32, 11, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee", "\ua6c4\uab4c\u8232", "\udae7\udf23",
        24, 55453, -1098059402, 4028285464244511651L, 81409L, false, false, (char) 31962, (char) 8740,
        Double.longBitsToDouble(0x3feecc6e0fa86e9aL), Double.longBitsToDouble(0x3fe663dcefe07881L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, -9035412814428744032]] |a0=[J:[[55677, 56464, 55352, 56852]]\0121=[I:[[55677, 56464, 55352, 56852, 40]] |a0=[I:[[55677, 56464, 55352, 56852]]\012",
        Z.run(T, 2, 32, 27, 7, "\ud9ad\udcc0\ud868\ude44", "\ub271\ub094\u2fc5\uab4c\u8232\u75f9\ua37d\u8120\uc445\u558f\uabe3\uc28a\u4faf\u81b8\u4f04\u91b1\ua0f0\u478b\u7d00\ud412\u133a\u8cf7\ud19e\u7573\u219f\u3d72\ubbd0\u8344\u6be3\uc75b\u16bd\u7e54\u0a0a\u7a8e", "\ud94d\udf07\ud8d8\udf63\udb48\udf1d\udb2c\ude8e\uda87\udebb\ud9d3\ude48\udb03\udc79\udbb1\udfb1\ud92a\udd0f\ud9cd\udd22\ud8e4\udde5\u4940\udbc3\udd0e\udb34\udf47\ud8af\udf43\ub8a1\uda28\udfea\udbb6\uded4\ud9a2\udd25",
        40, 21262, 345544452, -9035412814428744032L, -76084L, false, false, (char) 56305, (char) 40375,
        Double.longBitsToDouble(0x3fef99dea70ec8ebL), Double.longBitsToDouble(0x3fede886da579883L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf05a\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\udaf9\udff8, \u38d8\u4507\ud397]] |a0=[Ljava.lang.Object;:[[\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf05a\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\udaf9\udff8]]\0121=[F:[[27838.5, 28232.0, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0, 0.6092149]] |a0=[F:[[27838.5, 28232.0, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0]]\012",
        Z.run(T, 2, 14, 9, 24, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf05a\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\udaf9\udff8", "\u38d8\u4507\ud397", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -717889420, -935462874208487979L, -24758L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 4028285464244511651]] |a0=[J:[[55677, 56464]]\0121=[I:[[55677, 56464, 24]] |a0=[I:[[55677, 56464]]\012",
        Z.run(T, 2, 32, 27, 11, "\ud9ad\udcc0", "\u13ca\ub271\ub094\u2353", "\ua348\ud09a\udae7\udf23",
        24, 55453, -1098059402, 4028285464244511651L, -8633L, true, true, (char) 50057, (char) 46211,
        Double.longBitsToDouble(0x3fe663dc07e07881L), Double.longBitsToDouble(0x3fe63b4f99080c86L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, -935462874208487979]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[C:[[\ud9ad, \udcc0, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \u8f81, \uf058, \udaeb, \udf58, \ud882, \udece, \ud8d7, \ude11, \udbdc, \udca0, \uda98, \uddf3, \uda89, \udf14, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud96e, \udf94, \udaa8, \ude99, \udb80, \udcc9, \ud8bc, \udd1d, \uf593]] |a0=[C:[[\ud9ad, \udcc0, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \u8f81, \uf058, \udaeb, \udf58, \ud882, \udece, \ud8d7, \ude11, \udbdc, \udca0, \uda98, \uddf3, \uda89, \udf14, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud96e, \udf94, \udaa8, \ude99, \udb80, \udcc9, \ud8bc, \udd1d]]\012",
        Z.run(T, 2, 32, 21, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\uda89\udf14\udacf\ude27\ud8b1\udf9d\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u725e\ua12b\ud3eb", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        38, 52424, -650780556, -935462874208487979L, -24758L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a00f701a72L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, -935462874208487979]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[Z:[[true, false, false, false, true, false, false, false, true]] |a0=[Z:[[true, false, false, false, true, false, false, false]]\012",
        Z.run(T, 2, 32, 1, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\u49e6\ud9bf\ude1e\udbce\udf83\ud94d\udeec\ud9c7\udc97\ud8fc\udcfd\udb42\ude95",
        50, 9151, -650780556, -935462874208487979L, -24758L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55596, 56348, 55803, 56294, 55611, 56695, -2075229862900272543]] |a0=[J:[[55677, 56464, 55596, 56348, 55803, 56294, 55611, 56695]]\0121=[Z:[[true, false, false, false, true, false, true, true, true]] |a0=[Z:[[true, false, false, false, true, false, true, true]]\012",
        Z.run(T, 2, 32, 1, 31, "\ud9ad\udcc0\ud95c\udc4c\uda2b\udc16\ud96b\udda7\udad5\udff9\ud829\udcaf", "\u8215\u75f9\ua71f\u1645\u1a59\u2503\u462a\u0a59\u4faf\u81b8\u9d3c\u3dec\u3d34\u96d5\u2dff", "\udbe1\udcc5\u9a75\ud9e8\udc99\udbd3\uded5\udac4\ude83\udbcc\udce5\uda82\udf78\ud866\udc28\udae7\udd57\ud982\udfb7\uda80\udf7d\ud9f0\uddf9\uda48\udd73\ud843\udc89\ud98c\udcb2",
        59, 7783, -704146955, -2075229862900272543L, 31000L, true, false, (char) 3731, (char) 45705,
        Double.longBitsToDouble(0x3fb86e2d5da24798L), Double.longBitsToDouble(0x3fe4cefe89f562ddL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 32, 7, "\uda20\uddb3\uec4e\000\uda78\udfee\u00ad\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\024\000\ud8b3\udf79\000\ud96e\udf4b\udaa8\ude99\u7cf9\u1800", "\uaab9", "\ud8db\udf35\ud89a\udddf\u491a\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef\ud95e\udfc4",
        1, 62444, -217804423, -2144639397303455919L, -15157L, true, false, (char) 50739, (char) 17527,
        Double.longBitsToDouble(0x3fe2bdd4b5814a8bL), Double.longBitsToDouble(0x3fedc069cd4056aeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[C:[[\ud9ad, \udcc0, \ud934, \udc1b, \uda38, \ude00, \ud857, \udef4, \udaa6, \udf46, \ud9a5, \udc23, \udae2, \uddc3, \ud882, \udece, \ud890, \udc2d, \ud85a, \udcec, \ud843, \udefb, \ud81f, \ude84, \ud983, \udef2, \ud8e7, \udf9e, \uda45, \udd9a, \ud96e, \udf94, \udb7b, \udd65, \udb83, \ude2c, \ud8e2, \ude1d, \ud843, \udcfb, \ud995, \udfee, \u0cf1]] |a0=[C:[[\ud9ad, \udcc0, \ud934, \udc1b, \uda38, \ude00, \ud857, \udef4, \udaa6, \udf46, \ud9a5, \udc23, \udae2, \uddc3, \ud882, \udece, \ud890, \udc2d, \ud85a, \udcec, \ud843, \udefb, \ud81f, \ude84, \ud983, \udef2, \ud8e7, \udf9e, \uda45, \udd9a, \ud96e, \udf94, \udb7b, \udd65, \udb83, \ude2c, \ud8e2, \ude1d, \ud843, \udcfb, \ud995, \udfee]]\0121=[I:[[55677, 56464, 55556, 56299, 55816, 56784, 55335, 57028, 42]] |a0=[I:[[55677, 56464, 55556, 56299, 55816, 56784, 55335, 57028]]\012",
        Z.run(T, 2, 22, 27, 7, "\ud9ad\udcc0\ud934\udc1b\uda38\ude00\ud857\udef4\udaa6\udf46\ud9a5\udc23\udae2\uddc3\ud882\udece\ud890\udc2d\ud85a\udcec\ud843\udefb\ud81f\ude84\ud983\udef2\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udb7b\udd65\udb83\ude2c\ud8e2\ude1d\ud843\udcfb\ud995\udfee", "\ud3eb\u133a\u8cf7\ud19e", "\udb63\uded1\udbdc\udc8c\ud8fc\udcb5\ud976\udcef\udb60\udfc5\ud982\udf64\udb25\ude2a",
        42, 35343, -1168949494, 1659177170379668549L, -96607L, true, true, (char) 3313, (char) 24977,
        Double.longBitsToDouble(0x3fd7f85893b87756L), Double.longBitsToDouble(0x3fd7b3b3bdc63e92L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 1981560753177804433]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 13]] |a0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\012",
        Z.run(T, 2, 32, 27, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udb53\udfd0\ud99e\udc90\ud8bc\udd1d", "\u38d8\ua12b\ub2bb", "\u49e6\udad7\udf7e\udbce\uded7\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef\ud8e7\udf48\ud982\udf64\udb25\ude2a\ud85e\udcb5\udbeb\udc13\ud82c\udf19\ud9b1\uddb2\ud94d\udf07\ud8d8\udf63\udb31\udf7b\ud98f\udf3d\udbd9\udeb6\ud9d3\ude48\udad1\udc60\udbb7\udc3b\ud891\udf67",
        13, 4883, 74415036, 1981560753177804433L, 41864L, true, false, (char) 29071, (char) 29680,
        Double.longBitsToDouble(0x3febd9dc993857d4L), Double.longBitsToDouble(0x3f844924c995aa80L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55858, 56865, 55817, 56362, 4732100810573527419]] |a0=[J:[[55677, 56464, 55352, 56852, 55858, 56865, 55817, 56362]]\0121=[D:[[27838.5, 28232.0, 27676.0, 28426.0, 27929.0, 28432.5, 27908.5, 28181.0, 0.5311332150637174]] |a0=[D:[[27838.5, 28232.0, 27676.0, 28426.0, 27929.0, 28432.5, 27908.5, 28181.0]]\012",
        Z.run(T, 2, 32, 23, 10, "\ud9ad\udcc0\ud868\ude44\uda62\ude51\uda39\udc5a\u8f81\u8ced\udaeb\udf58\ud882\udece\uda1a\udd0a\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\uda60\ude47\ud81d\ude4d", "\u38d8\ua12b\ud3eb\uba0b\u00dc\ud19e\u7573\u230b\u3e56\ubbd0\u8344", "\udb83\udc64\udb25\ude2a\ud85e\udcb5\udbeb\udc13\ud82c\udf19\ud9b1\uddb2\ud94d\udf07\ud8d8\udf63\udb31\udf7b\udb2c\ude57\uda87\udebb\ud9d3\ude48\ud9bb\uddf5\udbd5\ude1d\ud95c\udfea\udb5a\udcb8\ud92b\udf86\u92cb\ud8ea\udd30\ud999\udf6b\ud864\udd08",
        12, 72228, 630161010, 4732100810573527419L, -91558L, false, false, (char) 32838, (char) 52648,
        Double.longBitsToDouble(0x3fe0ff0b15909376L), Double.longBitsToDouble(0x3fe7f076ba74e166L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 20, 7, "\ud9ad\udcc0\ud93e\udc30\uda2a\udfae\uda78\udfee\u8f81\udbdd\ude27\uda7f\udc51\ud880\ude90\ud8d7\ude11\ud991\udcdb\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u34f4\ua12b\u8c4c", "\u49fb\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\uda25\udc47\ud95e\udfc4\ud982\udf64\udb25\ude2a\ud85e\udcb5\udbeb\udc13\ud913\udc32\ud9b1\uddb2\ud94d\udf07\udbcf\udc5f\ud9f1\udda2\ud730\ub808\udb72\udf40\udadf\udfb7\udaf4\uddf1\ud8a5\ude23\udbbf\uddf5\udb31\udcd2\udae8\udeb4\udb5a\ude23\uda56\ude8c\uda59\uddc6\udbf3\udf55\udbd7\udd9d\udacf\udde7\ud980\uddbc\ud8e2\udd57\ud810\udd25\udba4\udef4\ud9be\ude1c\ud917\udf84",
        11, 14611, 1768378626, -3927310718334684591L, -96570L, true, true, (char) 1152, (char) 26443,
        Double.longBitsToDouble(0x3fe89a0d04f687c7L), Double.longBitsToDouble(0x3fee047d676553ecL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[J:[[4957629894763078306]]\0121=[C:[[\uf32b]]\012",
        Z.run(T, 2, 32, 21, 21, "\ud88b\udfdc\ud868\ude44\uda2a\udfb8\uda78\udfee\ud9f6\udcce\uf028\udaeb\udf58\ud8ac\udd91\ud806\udd82\udaf6\ude14\udba7\ude5b\udb6e\ude85\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud9b8\udceb\ud9ff\udfc5\udb96\udda6\ud8bc\udd1d", "\u38d8\ua12b\u41c5\u1340\ub17c\uc1ff\ud0cd\u64ba\uaf51\u1ad3\u7c95\u6c4f\uc75b\u50af\ua284\u0a16\u7a8e\u827a\u838d\ud08d\u31c4\u4662\ud3be\u5ab1\ud52c\u4cbb\u82f0\u083f", "\ud8f9\ude80\udaed\ude9c\ud8d5\udc01\ud94c\udf27\udbd7\udfc4\u7170\udac7\udfe8",
        4, 59097, 369168429, 4957629894763078306L, 94017L, true, true, (char) 62251, (char) 2005,
        Double.longBitsToDouble(0x3fea9beba5c8c08cL), Double.longBitsToDouble(0x3fd2718cdadd4764L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[J:[[2830493674142816403]]\0121=[B:[[7]]\012",
        Z.run(T, 2, 32, 19, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\udab1\udfc8\ud812\udedb\udaeb\udf58\ud96d\udee2\udb48\udfc3\udb11\udfc9\uda85\udfa0\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u0ef2\ua12b\uc8e7", "\u49e6",
        7, 48607, 1647917320, 2830493674142816403L, -94546L, true, true, (char) 30944, (char) 47855,
        Double.longBitsToDouble(0x3fdd5f38aea3c478L), Double.longBitsToDouble(0x3fe0b5c35b6b3d46L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 27, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udb12\udce8\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935462874208487979L, -24758L, true, false, (char) 59695, (char) 50781,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, -3024288144467530129]] |a0=[J:[[55677, 56464, 55352, 56852]]\0121=[Z:[[true, false, false, false, false]] |a0=[Z:[[true, false, false, false]]\012",
        Z.run(T, 2, 32, 1, 30, "\ud9ad\udcc0\ud868\ude44", "\u4f6f\ub7b0", "\uda19\udc92\udbe0\udc0a\uda98\uddf3\udae7\udf23\udbda\udcff\udb91\udd80\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d\udbd3\ude0e\udbf0\udd2e\ud802\udf12\udbff\udc90\udb2f\udddc\ud9f9\udd53\ud89a\udd66\u49e6\ud9bf\ude1e\udbce\udf83\uda93\uddd5\ud941\uddba\uda84\ude78\ud8a9\udd8d\ud917\ude38\ud982\udf86\udb05\udf80\udb97\udc2c\udbeb\udc02\udb74\udf1c",
        23, 73467, 1277472079, -3024288144467530129L, -31007L, false, true, (char) 13873, (char) 38469,
        Double.longBitsToDouble(0x3fe77ee920339886L), Double.longBitsToDouble(0x3fcbbac90f3a292cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, -935462874208487979]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 50]] |a0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\012",
        Z.run(T, 2, 32, 27, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee", "\u2fc5\uab4c\u8232\u75f9\u2ae8\u8050\u1a67\u558f\uabe3\uc28a\u4faf\u81b8\u4f04\u2e90", "\ud85e\udd46\ud892\uddd6\udbe1\udd3a\ud9b7\udf39\u49ff\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935462874208487979L, -24758L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd50b896f701a72L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 26, 27, 7, "\ud99c\uddc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\u00e0\u0c08", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udba4\udc2f\uda86\udd7f\ud976\udcef",
        50, 9151, -650780556, 7850215572343040404L, 2801L, true, false, (char) 22540, (char) 3313,
        Double.longBitsToDouble(0x3fb163052fc2b040L), Double.longBitsToDouble(0x3fea5f8f57894c18L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 27, 7, "\ud9a6\udcc9\ud868\ude3d", "\ub271\ubbaa\u939a\u29a5\u1b41\u4989\ua765\u623b\u1a55\u68d2\u428e\u8d53\u4b1f\u81b8\u4f04\u2e90\u7844\u716e\ua12b\ud3eb\u133a\u8cf7\ud19e\u6c02\u2668\u689f\uc6e6\ua02c\u4d55\uc767\u1717\ua27a\u0a16\u7a8e", "\ud808\udf42\uda23\udcef",
        10, 92680, -2031271374, 8985457724652781466L, 42697L, true, false, (char) 25327, (char) 4276,
        Double.longBitsToDouble(0x3feb9eb744f002b9L), Double.longBitsToDouble(0x3fe88e8144424a1bL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[Z:[[true, false, false, false, true, false, false, false, true]] |a0=[Z:[[true, false, false, false, true, false, false, false]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 17, 4, 30, "\ud9ad\udcc0\ud868\ude44\ud941\udfa0\udabe\udc8a\u1a40", "\uab4c\u8232\u75f9\u2ae8\u8050\u1a67\u558f\uabe3\uc28a\u4faf", "\udbd3\ude0e\udac4\udcb9",
        17, 7021, 625448678, 6935364406856930965L, 30892L, true, true, (char) 41521, (char) 38709,
        Double.longBitsToDouble(0x3fe597dc217f8a6fL), Double.longBitsToDouble(0x3fbd261b25cf6828L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud95f\udcb9\ud868\ude44\udb75\udd0e\uda78\udfee\u8f81\ud949\udd55\udaeb\udf58\ud86a\ude2d\ud8d7\ude11\udb12\uddbb\ud9c4\ude16\udb0d\udf25\udae3\udda8\ud8e7\udf9e\ud88f\udf5f\uda7c\uded3\udbf4\uded0\ud8a6\uddba\ud8bc\udd1d\udbd3\ude0e\udbf0\udd2e\ud802\udf12\uda1a\udfc3\udbfb\ude8d\ud8db\udf35\ud892\udf5d\ud99d\udc61\ud839\ude1b\udbce\udece\udb63\uded1\ud9ed\udcb5\ud8fc\udcb5\udb4a\udf1b\ud92a\udfc1, null]] |a0=[Ljava.lang.Object;:[[\ud95f\udcb9\ud868\ude44\udb75\udd0e\uda78\udfee\u8f81\ud949\udd55\udaeb\udf58\ud86a\ude2d\ud8d7\ude11\udb12\uddbb\ud9c4\ude16\udb0d\udf25\udae3\udda8\ud8e7\udf9e\ud88f\udf5f\uda7c\uded3\udbf4\uded0\ud8a6\uddba\ud8bc\udd1d\udbd3\ude0e\udbf0\udd2e\ud802\udf12\uda1a\udfc3\udbfb\ude8d\ud8db\udf35\ud892\udf5d\ud99d\udc61\ud839\ude1b\udbce\udece\udb63\uded1\ud9ed\udcb5\ud8fc\udcb5\udb4a\udf1b\ud92a\udfc1]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 26, 7, "\ud95f\udcb9\ud868\ude44\udb75\udd0e\uda78\udfee\u8f81\ud949\udd55\udaeb\udf58\ud86a\ude2d\ud8d7\ude11\udb12\uddbb\ud9c4\ude16\udb0d\udf25\udae3\udda8\ud8e7\udf9e\ud88f\udf5f\uda7c\uded3\udbf4\uded0\ud8a6\uddba\ud8bc\udd1d\udbd3\ude0e\udbf0\udd2e\ud802\udf12\uda1a\udfc3\udbfb\ude8d\ud8db\udf35\ud892\udf5d\ud99d\udc61\ud839\ude1b\udbce\udece\udb63\uded1\ud9ed\udcb5\ud8fc\udcb5\udb4a\udf1b\ud92a\udfc1", "\u0a16\u7a8e", "\ud94d\udf07\ud8d8\udf63",
        55, 83551, 1250685527, -2382389356799219623L, -7163L, true, false, (char) 56261, (char) 21843,
        Double.longBitsToDouble(0x3fc9c1c7cabf4b6cL), Double.longBitsToDouble(0x3fc7672dff0a98e4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 21163, 55803, 56294, 55880, 57278, 36689, -935462874208487979]] |a0=[J:[[55677, 56464, 21163, 55803, 56294, 55880, 57278, 36689]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 32, 31, 18, "\ud9ad\udcc0\u52db\uda2b\udc16\uda78\udfee\u8f81\uf058\udb48\ude00\udae0\udf77\ud8f9\udc52\udbdc\udca0\ud9f4\udd45\ud97a\udd44\udae3\udd37\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\udb55\udc26", "\u38d8\u3093\u062f", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        55, 68363, -650780556, -935462874208487979L, -24758L, true, true, (char) 26768, (char) 50678,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[J:[[55659, 56645, 55352, 56852, 55349, 56962, 55864, 56561, -935462874208487979]] |a0=[J:[[55659, 56645, 55352, 56852, 55349, 56962, 55864, 56561]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 32, 29, 7, "\ud99b\udd75\ud868\ude44\ud865\udeb2\uda68\udd21\u8f81\uf058\ud9a3\uded4\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udaf2\udd6f\ud937\udebb", "\u38d8\uc2ca\u4420", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935462874208487979L, -24922L, true, true, (char) 62867, (char) 8754,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 22, 27, 7, "\ud9ad\udcc0\ud868\ude44\udabc\udf7f\ud885\udd75\ud9bf\udf8e\uf058\ud9f8\uddd0\ud882\udece\udb15\udd10\ud96a\udc92\ud90a\ude18\uda3f\udcec\udae9\udf81\u4caa\ud911\udeec\ud87a\udd65\ud80c\udd5f\ud830\udd38\uda88\udd18", "\u38d8\ua12b\ud3eb", "\u49e6\ud9fb\udda7\ud837\uddc5\udbf4\uddc5\ud851\udd29\udb5e\udd0e\udae8\udfa1",
        -1, 83807, -1323121911, 1698017007898755277L, -99766L, true, true, (char) 62867, (char) 22863,
        Double.longBitsToDouble(0x3fde0d6e5e72e192L), Double.longBitsToDouble(0x3fd81c52decd9c0cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, -935462874208487979]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 32, 0, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\uc89d\ud3eb", "\000\ud97f\ude3e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935462874208487979L, -100000L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, -4716129219717408695]] |a0=[J:[[55677, 56464]]\0121=[F:[[27838.5, 28232.0, 0.5296731]] |a0=[F:[[27838.5, 28232.0]]\012",
        Z.run(T, 2, 32, 9, 28, "\ud9ad\udcc0", "\u13ca\ub271\ub094\ua5c4", "\udbdc\udca0\uda98\uddf3",
        -1, 22663, -149827547, -4716129219717408695L, -92595L, true, false, (char) 58487, (char) 6222,
        Double.longBitsToDouble(0x3fe0f315088dcc4dL), Double.longBitsToDouble(0x3fc7a6d0b6c9b75cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[B:[[125, -112, -99, 56, 20, -5, -26, 72, -66]] |a0=[B:[[125, -112, 56, 20, -5, -26, 72, -66]]\0121=[F:[[27838.5, 28232.0, 0.5029884, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0]] |a0=[F:[[27838.5, 28232.0, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0]]\012",
        Z.run(T, 2, 4, 10, 17, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf0f0\ud88b\udded\udad0\ude82\uaf03\u16e7\ufdd4\ud969\ude63\udafe\udcd3\udb87\udd09\udbb9\ude3c\ud970\udf94\udaa8\ude99\udb80\udcc9\ud86f\udd56", "\uc4aa", "\ud81f\udf17\ud8a0\udebf\ud92a\udca4\udab9\uddfc\udbce\udf69\udb6e\udcbc\udbab\udf53\ud8fc\udcb5\udb26\udf27\ud813\udead",
        2, 28829, -1357561223, 377431700317892462L, -33629L, true, false, (char) 50739, (char) 40715,
        Double.longBitsToDouble(0x3fe0187b1e87fb5eL), Double.longBitsToDouble(0x3fc0afe73793c4c4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 27, 16, "\ud9ad\udcc0\uec4e\000\000\udaa8\uddd3\ua558\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\u4f81\000\ud8f9\udc1cI\udaa8\uddf6\udb80\udcc9\000", "", "\ud83e\udc36",
        37, 65568, 2021749452, 7634727131071009479L, -100000L, false, false, (char) 0, (char) 58802,
        Double.longBitsToDouble(0x3fd7f8a6f0e930d8L), Double.longBitsToDouble(0x3fd79d900babe608L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 27, 22, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\ud910\udc01\ud8ec\udc2d\ud938\udc96\ud82f\udd02\udbfe\uded5\ud806\udd65\udae7\udf23\udae3\udda8\ud976\udea4\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\u4d4a\ud9bf\uddd1\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935462874208487979L, -24758L, true, true, (char) 62867, (char) 45619,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 28, 32, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\udacd\ude93\000\000\000\000\ud8bb\ude1d\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\000\ud97f\ude3e\udbce\udebc\udb63\uded1\000\ud8fc\udcb5\ud976\udcef",
        50, -873, -650780672, -935462874208487979L, -44170L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb038000000L), Double.longBitsToDouble(0x3e4ee034e4000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[F:[[27803.0, 0.42328534, 28533.0, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0]] |a0=[F:[[27803.0, 28533.0, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 26, 16, 29, "\ud966\udf1a\ud868\ude44\uda2b\udc16\uda78\udfee\uda21\udf88\uf058\udaeb\udf58\u908d\ud8d7\ude11\ud8a5\udd44\uda0e\udc0b\ud824\ude7d\ud9dc\udd21\ud8bf\udc9e\uda45\udd9a\ud96e\udf94\udaa8\ude0b\udb80\udcc9\ud944\udde1\udbe1\udca6\ud9f9\udede\ud802\udf12\udbaf\udc0e\ud83e\udc36", "\u59f1\u7573\u219f\u3d72\ubbd0\u9261\u4daa", "\udb25\ude2a\ud8bc\udcc4\udbea\udfe8\ud82c\udf19\ud9b1\uddb2\ud94d\udf07\ud8dd\udc63\udb31\udf7b\udb03\udf9b",
        1, 3885, 373735807, -2346433775675603741L, 92212L, true, true, (char) 27109, (char) 34336,
        Double.longBitsToDouble(0x3fdb171b689e669cL), Double.longBitsToDouble(0x3fdceea1290fe560L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=[J:[[-4716129219717408695]]\0121=[I:[[3]]\012",
        Z.run(T, 2, 32, 27, 7, "\000", "\ud414\ub271\ub094\u2fc5", "\udbdc\udca0\uda98\uddf3",
        3, 19353, 0, -4716129219717408695L, -100000L, false, false, (char) 58487, (char) 6222,
        Double.longBitsToDouble(0x3ec4223730000000L), Double.longBitsToDouble(0x3fdbd0000b64dbaeL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=[J:[[55677, 56336, 55352, 56852, 55803, 56294, 55880, 57278, -935462874208487979]] |a0=[J:[[55677, 56336, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 32, 24, 7, "\ud9ad\udc40\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\u1f1c\u0ee0", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935462874208487979L, -24758L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[J:[[55260, 57108, 55352, 56932, 55803, 56294, -4342252160860150823]] |a0=[J:[[55260, 57108, 55352, 56932, 55803, 56294]]\0121=[I:[[55260, 57108, 55352, 56932, 55803, 56294, 5]] |a0=[I:[[55260, 57108, 55352, 56932, 55803, 56294]]\012",
        Z.run(T, 2, 32, 27, 20, "\ud80c\udf44\ud868\ude94\uda2b\udc16", "\ub094\u2fc5\uab4c\u8232\u195e\u09a4\u8050\u1a67\u558f\uabe3\uc28a\u4faf\u81b8\u4136\u2e90\u7844\u38d8\ua12b\ud3eb\u133a\ud168\ua7f2\u9b2e\uc102%\ubbd0\u8344\u6be3\uc75b\u16bd\ub312\ua166\u7a8e\u827a\u22b6\u4409\ud63b\u8836\u542a\u5ab1\ud52c", "\udb20\ude49\uda9e\uddd7\ud98a\ude61\ud8b7\udc4a\udbbf\udc61\ud966\ude85\ud806\ude20\udac7\udc1a\ud885\udf10\ud9fe\udee7\ud9eb\udf8f\ud91e\uddb0\ud83a\udf0d\udb25\udf31\udb08\ude83\udae0\udecd\udba3\udfde\ud83f\uddaa\udbe2\udfb2\ud82a\udefe\ud8b5\udd0c",
        5, 12473, 927537920, -4342252160860150823L, 1700L, true, true, (char) 11332, (char) 26339,
        Double.longBitsToDouble(0x3fd8726ec97d07ecL), Double.longBitsToDouble(0x3fe8c8872651b0c2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 56120, 56411, 55559, 56658, 56187, 56390, 6208118345475856308]] |a0=[J:[[55677, 56464, 56120, 56411, 55559, 56658, 56187, 56390]]\0121=[I:[[55677, 56464, 56120, 56411, 55559, 56658, 56187, 56390, 48]] |a0=[I:[[55677, 56464, 56120, 56411, 55559, 56658, 56187, 56390]]\012",
        Z.run(T, 2, 32, 27, 7, "\ud9ad\udcc0\udb68\udc8b\ud937\udd82\udbab\udc76\uda11\udc71\ud810\udef7\udaeb\udf58\ud882\udece\ud8d7\ude11\ud892\udee5\udbda\udd1f\ubb96\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\ud93b\udcdd\ud8bc\udce9\udbd3\ude0e\ud9f8\udd30\ud802\udf6c\uda1a\udfc3\ud83e\udc36\ud8db\udf35\ud89a\udddf\uc346\ud9bf\uddb0\ud8ba\uddee\uda7b\udcd0\udbab\udfee\ud8fc\udcb5\ud9d8\udc6f\ud995\uded4\udb8c\udf7b\udaae\udde2\udb6f\udfce\udbf9\ude9d\ud82c\udf19\ud9b1\uddb2\ud94d\udf07\ud8d8\udf63\udb31\udf7b\udb2c\ude57\ud945\udebb\ud85b\udc36\udaa4\uddc9\udb33\uddc3\uda6e\udc33\udac9\ude5e\udbae\udc4c\uda06\udc32\udb9c\udf33\uda7f\udea3\uda1f\udf2b\ud9dc\udef5\uda75\uddd6\udac5\udd10", "\u4e05\ua0d6", "\udae0\udd45\udb03\udee9\udaf2\ude31\ud9ce\uddcb\ud9a9\udd88\uda1f\udc81\ud90e\udec0\ud8f1\udc63\udbd7\udda8\ud966\udd7e\udb5e\ude31",
        48, 2601, -190567602, 6208118345475856308L, -24798L, false, false, (char) 7169, (char) 47135,
        Double.longBitsToDouble(0x3febf5521b6fe329L), Double.longBitsToDouble(0x3fed6920579b70a7L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud9ad\udcc0\ud868\ude44\ud9d9\ude2d\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d, \u38d8\ua12b\ud3eb]] |a0=[Ljava.lang.Object;:[[\ud9ad\udcc0\ud868\ude44\ud9d9\ude2d\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 18, 7, "\ud9ad\udcc0\ud868\ude44\ud9d9\ude2d\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\u49e6\ud9bf\ude1e\udbce\udf6d\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935406799115471403L, -24758L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fdeff773f701a72L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55350, 57187, 55803, 56294, 55880, 57278, -4819199700295174699]] |a0=[J:[[55677, 56464, 55350, 57187, 55803, 56294, 55880, 57278]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 32, 33, 2, "\ud9ad\udcc0\ud866\udf93\uda2b\udc16\uda78\udfee\u8f81\uda50\udec2\uda97\udc36\ud8ba\udfac\ud8d7\ude11\uda52\udfbc\uda56\ude59\udae7\udf86\udae3\udda8\ud8e7\udf9e\uda2a\udf9a\ud96e\udf94\udaa8\udf99\udb80\udcc9\ud8bc\udd1d", "\u38d8\u1764\uc3bc", "\udaca\udee2\udb40\udce7\udbca\udea6\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud81c\udd90",
        34, 9151, -650780556, -4819199700295174699L, -24758L, true, true, (char) 46596, (char) 50579,
        Double.longBitsToDouble(0x3fe37eb03957ba96L), Double.longBitsToDouble(0x3fb2e99b4dbf02a8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=[D:[[0.33159079958160875]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 20, 24, "\udbdb\udcb7\ud8f1\udcf5\ud93b\udffa\ud958\uddce\udbf0\udc0e\uf058\uda7e\udd5a\uda6f\udf84\u02f3\ud9e2\ude04\udb00\udef3\udae7\udfc8\udafc\udd97\udb65\udf9d\uda51\udde0\udaa6\udf90\ud8e9\udc9b\udb80\udccd\ud8db\udeec\udafd\ude5b\ud83d\udeed\ud829\ude38", "\u05db\u8cf7", "\udbce\udf83\udb63\udf97",
        15, 91499, -75218416, -8471294325573230209L, -62961L, false, false, (char) 3860, (char) 20636,
        Double.longBitsToDouble(0x3fd538c89df6e148L), Double.longBitsToDouble(0x3fe2bdd4b5814a8bL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[C:[[\uda61, \udf06, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \ud936, \udde0, \uf058, \ud8d2, \udc8a, \ud9bc, \udd63, \ud8d6, \uddd5, \udbdc, \udca0, \uda98, \uddf3, \udae7, \udf23, \udae3, \udda8, \uda5c, \udd39, \uda45, \udd8c, \ud96e, \udf94, \udaa8, \ude99, \udb80, \udcc9, \ud8bc, \udd1d, \uf593]] |a0=[C:[[\uda61, \udf06, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \ud936, \udde0, \uf058, \ud8d2, \udc8a, \ud9bc, \udd63, \ud8d6, \uddd5, \udbdc, \udca0, \uda98, \uddf3, \udae7, \udf23, \udae3, \udda8, \uda5c, \udd39, \uda45, \udd8c, \ud96e, \udf94, \udaa8, \ude99, \udb80, \udcc9, \ud8bc, \udd1d]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 21, 6, 10, "\uda61\udf06\ud868\ude44\uda2b\udc16\uda78\udfee\ud936\udde0\uf058\ud8d2\udc8a\ud9bc\udd63\ud8d6\uddd5\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\uda5c\udd39\uda45\udd8c\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -935462874208487979L, -24758L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=[J:[[952807645338927032]]\012",
        Z.run(T, 1, 32, 27, 14, "\udb91\udcbf\ud868\ude44", "\ub271\uc7fd\u9f1f\ua351\u8232\u75f9\u2ae8\u8050\u4854\u5013\uabe3\uc28a\u4faf\u81b8\u4f04\u2d36\uc5bc\u4916\ua12b\ud3eb\u133a\u8cf7\ud19e\u7573\u219f\u3d72\ubbd0\u8344\u38c3\uc75b\u16bd\ua27a\u33dd\u1063", "\ud94d\udf07\ud8d8\udf63",
        55, 15975, 1250685527, 952807645338927032L, 66171L, false, true, (char) 7023, (char) 65493,
        Double.longBitsToDouble(0x3fc0fa0817316cb0L), Double.longBitsToDouble(0x3fe7f14b59fe315aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 33, 1, 7, "\ud9ad\udcc0", "\u72d6\u7a02\ub094\u2f76\uab4c\u8232\u75f9\u35e8\u8050\u6a89\u55c7\u33e4\u58e0\u59af\uaded", "\udbf0\udd2e\ud946\udff4\udb27\uddc9\ud83d\udfc8\ud85d\udf36\ud89a\udddf",
        42, 98432, -847937849, 7077750997125736500L, -62961L, false, false, (char) 34993, (char) 62867,
        Double.longBitsToDouble(0x3fc90687f9bf5914L), Double.longBitsToDouble(0x3fe2bdd4b5814a8bL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=[Z:[[false]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 29, 21, "\ud8c8\udda3\ud96a\udc50\udb65\udda1", "\u8733\u6ae3\uab4c\u8232\ub01e\u4f5f\u0c67\u062f\u4cc1\u59fa\u9c42", "\ud8bc\udd1d\udbdf\udef2\ud940\udc4d\ud91d\ude8e\uda1a\udfc3\ud806\udebb\ud8a1\udf57\ud89a\udd48",
        -4, 5726, 214261208, -1249123239456658768L, -92522L, false, true, (char) 15305, (char) 31052,
        Double.longBitsToDouble(0x3fd79d935baab008L), Double.longBitsToDouble(0x3fea8f11e216b86bL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=[Z:[[false, false, false]] |a0=[Z:[[false, false]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 17, 10, 7, "\ud984\uded6", "\u13ca\ub271\u6b61\u2f8c", "\udbdc\udca0\uda98\uddf3",
        3, 99001, -320810971, -3855168701528729281L, -92595L, false, true, (char) 12009, (char) 6222,
        Double.longBitsToDouble(0x3fbb18a8446e6268L), Double.longBitsToDouble(0x3fdbd3685b64dbaeL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[I:[[55677, 56464, 55352, 56852, 56184, 56996, 56175, 56386, 48]] |a0=[I:[[55677, 56464, 55352, 56852, 56184, 56996, 56175, 56386]]\0121=[I:[[55677, 56464, 55352, 56852, 56184, 56996, 56175, 56386, 48]] |a0=[I:[[55677, 56464, 55352, 56852, 56184, 56996, 56175, 56386]]\012",
        Z.run(T, 2, 27, 27, 31, "\ud9ad\udcc0\ud868\ude44\udba8\uded4\udb9f\udc72\uda33\udc0f\ud993\ude70\ud891\uddb0\ud877\udfce\ud8d7\ude11\ud9a0\udf77\uda78\udd97\ud89a\ude3a\udae1\udf78\ud8e7\udf9e\udb84\udca4\ud802\udc56\udaa8\ude58\ud92a\udcbe\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\uda08\udd65\uda06\udd2a\udbce\udf83\udb63\uded1\udae9\udf25\ud8dd\uddb8\ud976\udcef\uda6d\udd3d\ud982\udf64\udb56\udea2\ud8cd\udcad\udbea\udf93\ud82c\udf19\udb0e\udf83",
        48, 11183, -704146955, -5001688911877253289L, 31000L, false, true, (char) 16963, (char) 62913,
        Double.longBitsToDouble(0x3fe0d9fdd2c1106bL), Double.longBitsToDouble(0x3fd7c86a3ba1ffacL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=[J:[[-4716129219717408743]]\0121=[D:[[0.6501756980318106]]\012",
        Z.run(T, 2, 32, 23, 7, "\ud9ad\udcc0", "\u70d3\ub271\ub053\u99df", "\udbdc\udca0\uda98\uddf3",
        3, 13849, -149817563, -4716129219717408743L, -74163L, true, false, (char) 51140, (char) 52429,
        Double.longBitsToDouble(0x3fe4ce3d43f66b4dL), Double.longBitsToDouble(0x3fdbd3685364dbaeL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=[D:[[27822.5, 28416.0, 27775.5, 28543.5, 27825.0, 28330.5, 27800.5, 28245.5, 0.9968589815700465]] |a0=[D:[[27822.5, 28416.0, 27775.5, 28543.5, 27825.0, 28330.5, 27800.5, 28245.5]]\0121=[D:[[27822.5, 28416.0, 27775.5, 28543.5, 27825.0, 28330.5, 27800.5, 28245.5, 0.9968589815700465]] |a0=[D:[[27822.5, 28416.0, 27775.5, 28543.5, 27825.0, 28330.5, 27800.5, 28245.5]]\012",
        Z.run(T, 2, 7, 23, 5, "\ud98d\ude30\ud92f\udf2f\ud992\udd85\ud961\udcdb\udb04\ude37\ud8c7\udff6\ud8b3\udddd\ud86f\ude5c", "\uc0f4\uaa63\uc244\ub4c5\u1e89\u32f9", "\ud8a5\udf32",
        40, 39374, -867306966, -8382894848120525076L, 633L, false, false, (char) 60505, (char) 27007,
        Double.longBitsToDouble(0x3fefe644ce9226a3L), Double.longBitsToDouble(0x3fee72186392082dL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 8, 19, "\ud9ad\udcc0", "\u13ca\ub2be\035\000", "\u549e",
        44, 32068, -525185151, -643733272835329674L, 23811L, true, false, (char) 0, (char) 55295,
        Double.longBitsToDouble(0x3feafee7761e62a1L), Double.longBitsToDouble(0x3fc1b989a2c165d0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\udb3a\udf45\ud843\udf6c\ud8ed\udf76\uda03\udc4e, \u5c0f\u46db\u8232]] |a0=[Ljava.lang.Object;:[[\udb3a\udf45\ud843\udf6c\ud8ed\udf76\uda03\udc4e]]\0121=[Ljava.lang.Object;:[[\udb3a\udf45\ud843\udf6c\ud8ed\udf76\uda03\udc4e, \u5c0f\u46db\u8232]] |a0=[Ljava.lang.Object;:[[\udb3a\udf45\ud843\udf6c\ud8ed\udf76\uda03\udc4e]]\012",
        Z.run(T, 2, 14, 30, 24, "\udb3a\udf45\ud843\udf6c\ud8ed\udf76\uda03\udc4e", "\u5c0f\u46db\u8232", "\udae7\udf23",
        24, 55453, -1098059402, -3032805697861852277L, 81409L, false, false, (char) 31962, (char) 8740,
        Double.longBitsToDouble(0x3fe86c6e0f30274dL), Double.longBitsToDouble(0x3fe663dcefe07881L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee, \ua6c4\uab4c\u605f]] |a0=[Ljava.lang.Object;:[[\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 30, 28, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee", "\ua6c4\uab4c\u605f", "\udae7\udf23\udae3\udda8",
        48, 11598, 937908297, 8514586858562002157L, 86400L, true, true, (char) 51391, (char) 31962,
        Double.longBitsToDouble(0x3fc60b2e8f663704L), Double.longBitsToDouble(0x3fed4374d150d0a0L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 24, 7, "\ud9b0\ude73", "\u13ca\ucbcf\u6eee\u60c9", "\u549e\ud969\udd83\ud89a\udcbe\udae3\udda8\ud867\uddfe\udb29\udc42\ud930\udd61",
        24, 33717, 207300768, -2526844707302982817L, 20905L, false, true, (char) 61033, (char) 40071,
        Double.longBitsToDouble(0x3fc5fbafb3de6d78L), Double.longBitsToDouble(0x3fed7752207e3f2eL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=[C:[[\udb05, \udd2c, \ud84f, \ude24, \ud9f6, \udf0b, \u17e1]] |a0=[C:[[\udb05, \udd2c, \ud84f, \ude24, \ud9f6, \udf0b]]\0121=[D:[[28010.5, 28286.0, 27663.5, 28410.0, 27875.0, 28525.5, 0.3865612539704655]] |a0=[D:[[28010.5, 28286.0, 27663.5, 28410.0, 27875.0, 28525.5]]\012",
        Z.run(T, 2, 5, 23, 26, "\udb05\udd2c\ud84f\ude24\ud9f6\udf0b", "\u166a\u848a\u47c0\u32e3\u39f4\u9be7\ud559\u80ad\u83e5\u3e3e\ub5d1\u4faf\u81b8\u4f04\u2e90\u7844\u9a36\ud667\u809c\ud776\u58e2\u8333\u08b1\u163e\u1048\ua609\uc4cf\u9fa6\u2d98\ud4bd\u9939\u853b\ube46\u9c4b\u3a4f\u60fc\uac85\u8783\u6feb\ua63e\u6a63", "\u3049\uda76\udd88\udbda\ude57\udbed\udef9\uda71\udc52\ud8fa\udc8e\ud850\ude4c\ud8e7\udf19\ud9fa\udda1",
        44, 17663, -187658862, -4243546864842050044L, -30928L, false, true, (char) 6113, (char) 6702,
        Double.longBitsToDouble(0x3fd8bd6b69ed0cb0L), Double.longBitsToDouble(0x3fe34d1d2942414eL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 16, "\ud9ad\udcc0\000\000\000", "\000", "\ud82b\ude08\000",
        -5, 44088, 1167397, -4716394709763751863L, -99763L, true, false, (char) 58399, (char) 6222,
        Double.longBitsToDouble(0x3fe0f315088dcc4dL), Double.longBitsToDouble(0x3e3ecc6e08000000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee, \ua6c4\uab4c\u8232]] |a0=[Ljava.lang.Object;:[[\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee]]\012",
        Z.run(T, 1, 14, 11, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee", "\ua6c4\uab4c\u8232", "\udae7\udf23",
        24, 55453, -564596362, 1289153216163610082L, -28208L, true, false, (char) 31962, (char) 8740,
        Double.longBitsToDouble(0x3feecc6e0fa86e9aL), Double.longBitsToDouble(0x3fe663dcefe07881L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 19, "", "\000", "\000",
        15, 86972, 0, -1719530633547453227L, 51425L, true, false, (char) 59527, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb8ee73000062c0L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 11, 7, "\ucba4", "\000\uc29b\035\000", "",
        36, 59429, 17506068, -149827547L, -92595L, true, false, (char) 58487, (char) 56558,
        Double.longBitsToDouble(0x3fe0f315088dcc4dL), Double.longBitsToDouble(0x3fc60b2e8f663704L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 4028285464244459171]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 24]] |a0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\012",
        Z.run(T, 2, 32, 11, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee", "\ucc65\u237a\u8232", "\udae7\udf23",
        24, 55453, -1098059402, 4028285464244459171L, -5076L, false, true, (char) 11992, (char) 52514,
        Double.longBitsToDouble(0x3fd2947d48093056L), Double.longBitsToDouble(0x3fcaa8fe2cdd2588L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=[F:[[27838.5, 28232.0, 27937.0, 28428.5, 27629.5, 28576.5, 4019.0, 0.13847466]] |a0=[F:[[27838.5, 28232.0, 27937.0, 28428.5, 27629.5, 28576.5, 4019.0]]\0121=[I:[[55677, 56464, 55874, 56857, 55259, 57153, 8038, 24]] |a0=[I:[[55677, 56464, 55874, 56857, 55259, 57153, 8038]]\012",
        Z.run(T, 2, 9, 11, 7, "\ud9ad\udcc0\uda72\ude49\ud80b\udf71\u1f96", "\u804a\u0f3f\u8232", "\udae7\udf23",
        24, 37493, -1098063126, 4028285460532552611L, 39554L, false, false, (char) 6222, (char) 51391,
        Double.longBitsToDouble(0x3fc1b989aaa463ccL), Double.longBitsToDouble(0x3feecc6e0f0c6e9aL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 4028285464244511651]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278, 4028285464244511651]] |a0=[J:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\012",
        Z.run(T, 2, 32, 32, 14, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee", "\uce22\uabb1\u8232", "\udae7\udf23",
        24, 55453, -1098059402, 4028285464244511651L, 81409L, false, false, (char) 31962, (char) 11044,
        Double.longBitsToDouble(0x3fcc05b85ea1b918L), Double.longBitsToDouble(0x3fe663dcefe07881L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=[F:[[27825.5, 28291.5, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0, 0.9579391]] |a0=[F:[[27825.5, 28291.5, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0]]\0121=[F:[[27825.5, 28291.5, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0, 0.9579391]] |a0=[F:[[27825.5, 28291.5, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0]]\012",
        Z.run(T, 2, 25, 9, 7, "\ud993\udd37\ud868\ude44\uda2b\udc16\uda78\udfee", "\ua6c4\uab4c\u881e", "\udbad\udde6",
        27, 89809, -1098059402, 4028285464244511651L, 81409L, false, false, (char) 31962, (char) 8740,
        Double.longBitsToDouble(0x3feea76fe7a86e9aL), Double.longBitsToDouble(0x3fe663dcefe07881L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=[C:[[\uda76, \udf24, \udbeb, \udcc3, \uda2b, \udc16, \uda78, \ucb54, \udfee, \ud86d, \ude23, \udbb5, \udf25, \udaeb, \udf77, \ud882, \udece, \ud95c, \udf03, \udbee, \ude20, \uda98, \uddf3, \udae7, \udf23, \uda9d, \udda5, \ud8e7, \udf9e, \uda45, \udd9a, \ud933, \udd25, \udaa8, \uddfa, \udb5e, \udc2e, \udaf9, \udff8]] |a0=[C:[[\uda76, \udf24, \udbeb, \udcc3, \uda2b, \udc16, \uda78, \udfee, \ud86d, \ude23, \udbb5, \udf25, \udaeb, \udf77, \ud882, \udece, \ud95c, \udf03, \udbee, \ude20, \uda98, \uddf3, \udae7, \udf23, \uda9d, \udda5, \ud8e7, \udf9e, \uda45, \udd9a, \ud933, \udd25, \udaa8, \uddfa, \udb5e, \udc2e, \udaf9, \udff8]]\0121=[C:[[\uda76, \udf24, \udbeb, \udcc3, \uda2b, \udc16, \uda78, \ucb54, \udfee, \ud86d, \ude23, \udbb5, \udf25, \udaeb, \udf77, \ud882, \udece, \ud95c, \udf03, \udbee, \ude20, \uda98, \uddf3, \udae7, \udf23, \uda9d, \udda5, \ud8e7, \udf9e, \uda45, \udd9a, \ud933, \udd25, \udaa8, \uddfa, \udb5e, \udc2e, \udaf9, \udff8]] |a0=[C:[[\uda76, \udf24, \udbeb, \udcc3, \uda2b, \udc16, \uda78, \udfee, \ud86d, \ude23, \udbb5, \udf25, \udaeb, \udf77, \ud882, \udece, \ud95c, \udf03, \udbee, \ude20, \uda98, \uddf3, \udae7, \udf23, \uda9d, \udda5, \ud8e7, \udf9e, \uda45, \udd9a, \ud933, \udd25, \udaa8, \uddfa, \udb5e, \udc2e, \udaf9, \udff8]]\012",
        Z.run(T, 2, 6, 6, 24, "\uda76\udf24\udbeb\udcc3\uda2b\udc16\uda78\udfee\ud86d\ude23\udbb5\udf25\udaeb\udf77\ud882\udece\ud95c\udf03\udbee\ude20\uda98\uddf3\udae7\udf23\uda9d\udda5\ud8e7\udf9e\uda45\udd9a\ud933\udd25\udaa8\uddfa\udb5e\udc2e\udaf9\udff8", "\ub511\u417e\ud397", "\ud85e\udf48\uda65\uddaf",
        7, 320, 662703360, 163775087265509683L, -26655L, false, false, (char) 52052, (char) 42765,
        Double.longBitsToDouble(0x3fea8f11e4f8b86bL), Double.longBitsToDouble(0x3feb5cc1314f3d45L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\u00a4, null]] |a0=[Ljava.lang.Object;:[[\u00a4]]\0121=[F:[[0.25]]\012",
        Z.run(T, 2, 14, 9, 24, "\u00a4", "\u22f6", "\udaa7\udf56\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\u23e1\udb9d\uddee",
        49, 44152, -616079219, 7914831603135370674L, -5076L, false, true, (char) 48314, (char) 3206,
        Double.longBitsToDouble(0x3fd0000001264f00L), Double.longBitsToDouble(0x3fd330245565f708L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud9b9\udc2b, \u13ca\ub271\u7970]] |a0=[Ljava.lang.Object;:[[\ud9b9\udc2b]]\0121=[B:[[-119, -5, 57]] |a0=[B:[[-119, -5]]\012",
        Z.run(T, 2, 14, 3, 21, "\ud9b9\udc2b", "\u13ca\ub271\u7970", "\ud8d7\udd49\uda56\udf1e\udabd\udcc3\udae7\udf23\udaac\udc2d\ud9b5\udfa3\udbcb\udfd0\uda3b\udd46\udaa8\udee2\udb5e\udc2e\udb5c\udce7\udbbe\udd51\uda7b\uddb6\ud802\udf53\u0e63",
        57, 56419, 2071995032, 8683347778823520224L, -19864L, false, true, (char) 19376, (char) 23136,
        Double.longBitsToDouble(0x3fe30887d914ea6fL), Double.longBitsToDouble(0x3fe80f7fa179d535L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[, ]] |a0=[Ljava.lang.Object;:[[]]\0121=[F:[[0.07201595]] |a0=[F:[[]]\012",
        Z.run(T, 2, 14, 9, 8, "", "", "\u8f81",
        56, 72569, -1065159028, 6406204254700214790L, -42420L, true, true, (char) 45271, (char) 59527,
        Double.longBitsToDouble(0x3fb26fa31d19bf38L), Double.longBitsToDouble(0x3fcdaec520000000L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=[F:[[27838.5, 0.58567274, 28232.0, 28096.5, 28316.5, 28002.5, 28433.0, 27709.5, 28257.0]] |a0=[F:[[27838.5, 28232.0, 28096.5, 28316.5, 28002.5, 28433.0, 27709.5, 28257.0]]\0121=[F:[[27838.5, 0.58567274, 28232.0, 28096.5, 28316.5, 28002.5, 28433.0, 27709.5, 28257.0]] |a0=[F:[[27838.5, 28232.0, 28096.5, 28316.5, 28002.5, 28433.0, 27709.5, 28257.0]]\012",
        Z.run(T, 2, 10, 10, 27, "\ud9ad\udcc0\udbb1\udd69\udaf5\ude52\ud8ab\udcf2\ud8ed\udc2c\ud882\udc32\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\uda89\udf14\udbd5\ude2a\ud8b1\udf9d\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud957\udf2b", "\u726f\ua12b\ud3eb\u133a\u54fc\u7b5a", "\uda1e\udffa\udac2\udf7d\ud8fc\udcb5\ud976\udcef\udb7d\udfc0",
        1, 62012, -217804423, -2144639397303455919L, -15157L, true, false, (char) 58109, (char) 17726,
        Double.longBitsToDouble(0x3fe2bdd4b5814a00L), Double.longBitsToDouble(0x3fedc069c988482aL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=[C:[[\ud9ad, \udcc0, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \ud991, \ude45, \udbdc, \udca0, \ud81f, \udd64, \ud85d, \uddb0, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud9df, \udfcc, \uab49]] |a0=[C:[[\ud9ad, \udcc0, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \ud991, \ude45, \udbdc, \udca0, \ud81f, \udd64, \ud85d, \uddb0, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud9df, \udfcc]]\0121=[C:[[\ud9ad, \udcc0, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \ud991, \ude45, \udbdc, \udca0, \ud81f, \udd64, \ud85d, \uddb0, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud9df, \udfcc, \uab49]] |a0=[C:[[\ud9ad, \udcc0, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \ud991, \ude45, \udbdc, \udca0, \ud81f, \udd64, \ud85d, \uddb0, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud9df, \udfcc]]\012",
        Z.run(T, 2, 21, 21, 33, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\uda24\udd40\uf0f8\udaeb\udf58\udb1a\udffa\ud991\ude45\udbdc\udca0\ud81f\udd64\ud85d\uddb0\udacf\ude27\ud8b1\udf9d\uda45\udd9a\ud9df\udfcc", "\u4f04\u2e90\u7844\u81b9\ua15d\u4664\u9dd8\u8cf7\ud19e\u7573\u219f\ub77f", "\ud976\udcef\uda48\udeb8\ud94a\udde5\u209c\ud85e\udcb5\udbeb\udc13\ud82c\udf19\ud9b1\uddb2\ud94d\udf07\ud8d8\udf63\udb5b\ude4f\udb69\udc6b\u649a\ud9d3\ude48\ud992\udf55\ud9d4\udd67\ud9a2\udc23\uda50\udf50\uda30\udff7\udabc\udcd4",
        46, 83327, 547646417, 1434821949124904441L, 75768L, true, true, (char) 43849, (char) 33216,
        Double.longBitsToDouble(0x3fcb78229889f9c8L), Double.longBitsToDouble(0x3fef2f2e8a78687aL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=[J:[[55536, 56410, 55634, 57020, 55802, 57230, 55880, 57278, -1653030105613593487]] |a0=[J:[[55536, 56410, 55634, 57020, 55802, 57230, 55880, 57278]]\0121=[Z:[[false, false, false, false, false, false, false, false, false]] |a0=[Z:[[false, false, false, false, false, false, false, false]]\012",
        Z.run(T, 2, 32, 1, 21, "\ud920\udc8a\ud982\udeec\uda2a\udfbe\uda78\udfee\uda03\udc70\uf058\ud839\udcdf\ud8c9\udf72\udaa8\uddb8\u46a9\ud925\udc2b\u6891\udae3\ude19\udbd9\udeef\udb90\ude94\udb5a\udccb\ud874\udc17\ud92b\udfda\ud8e4\udfca", "\u38d8\ua12b\u30ea", "\u0662\ud9bf\ude1e\udbce\udf83\ud94d\udeec\ud9c7\udc97\ud8fc\udc7c\udb42\ude95",
        50, 97439, -62696300, -1653030105613593487L, 75150L, false, true, (char) 62935, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fd814a8bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=[F:[[0.58567274]]\0121=[J:[[-2144639397303455919]]\012",
        Z.run(T, 2, 26, 32, 7, "\uda20\uddb3\uec4e\000\uda78\udfee\u00ad\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\024\000\ud8b3\udf79\000\ud96e\udf4b\udaa8\ude99\u7cf9\u1800", "\uaab9", "\ud8db\udf35\ud89a\udddf\u491a\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef\ud95e\udfc4",
        0, 40494, -217821149, -2144639397303455919L, -15086L, true, false, (char) 50739, (char) 17527,
        Double.longBitsToDouble(0x3fe2bdd4b5814a8bL), Double.longBitsToDouble(0x3fedc069cd4056aeL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=[D:[[27896.0, 28353.5, 30223.0, -24.0, 27990.0, 28632.0, 62.5, 30740.0, 0.699391468184717]] |a0=[D:[[27896.0, 28353.5, 30223.0, -24.0, 27990.0, 28632.0, 62.5, 30740.0]]\0121=[B:[[-16, -125, 30, -48, -84, -80, 125, 40, -19]] |a0=[B:[[-16, -125, 30, -48, -84, -80, 125, 40]]\012",
        Z.run(T, 2, 24, 20, 3, "\uda20\uddb3\uec4e\000\udadc\udfe0\u00ad\uf058\udaeb\udf58\udb3b\udd76\ud9a3\udf77\udb58\udd09\udb5d\udf3f\udb50\udf86\ud968\uded4\ud8b4\udc63\000\ud96e\udf4b\udaa8\ude99\u7cf9\u1800", "\uaab9\ua0bd\ud3eb\u133a\u8cf7\ud0d2\u7573\uab66\ub434\u458c\u8344\u6be3\uc75b\u16bd", "\udbeb\udc13\ud82c\udf19\ud9b1\uddb2\ud94d\udf07",
        8, 24045, -1164546407, 5371653436267367809L, 36512L, false, true, (char) 28062, (char) 51373,
        Double.longBitsToDouble(0x3fe6616a375e8d97L), Double.longBitsToDouble(0x3f97251189e04800L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=[B:[[15]]\0121=[B:[[15]]\012",
        Z.run(T, 2, 19, 3, 26, "\ud9ad\udcc0\ud868\ude44\uda62\ude51\uda39\udc5a\udbba\udd6d\ub896\udaeb\udfe4\ud882\udece\uda1a\udd0a\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud9ab\udd1f\ud885\uddd1\ud96f\udc40", "\u5f55\u3ee7\u78dc\u73d6\ua12b\ud3eb\uba0b\u4e4b", "\ud908\ude48\udb63\udfb5",
        15, 53859, 1568993587, 6630714486006014383L, -62961L, false, false, (char) 34993, (char) 62867,
        Double.longBitsToDouble(0x3fdf5343f726a4e0L), Double.longBitsToDouble(0x3fe2f5f3f5814a8bL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=[B:[[125, -112, 14, 0, -6, -112, 126, 72, -66]] |a0=[B:[[125, -112, 14, 0, -6, 126, 72, -66]]\0121=[B:[[125, -112, 14, 0, -6, -112, 126, 72, -66]] |a0=[B:[[125, -112, 14, 0, -6, 126, 72, -66]]\012",
        Z.run(T, 2, 4, 20, 9, "\ud9ad\udcc0\ud93e\udc30\uda2a\udfae\uda78\udfee\u8f81\udbdd\ude27\uda7f\udc51\ud880\ude90", "\u2ae8\u8050\u1a67", "\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d\udbd3\ude0e\udabf\uddf6\ud951\udea2\uda1a\udfc3\ud8e2\udea9\udbbc\udc84\ud89a\udddf\udae0\udec2\udbb0\udcc0\udbce\udf83",
        5, 41360, 38131859, -6015418002886890830L, 39148L, true, true, (char) 43225, (char) 8846,
        Double.longBitsToDouble(0x3f96ba176d67a8c0L), Double.longBitsToDouble(0x3fb3cf514c6de9f8L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=[J:[[55387, 57260, 55352, 56852, 5055822344741483978]] |a0=[J:[[55387, 57260, 55352, 56852]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 32, 33, 11, "\ud88b\udfdc\ud868\ude44", "\u5882\ub064\u2fc5", "\udaf6\ude5b\udba7\ude5b\udb6e\ude85\ud821\udc06",
        -3, 11598, -958084023, 5055822344741483978L, -34508L, true, true, (char) 51391, (char) 31962,
        Double.longBitsToDouble(0x3fea69b42bae08d5L), Double.longBitsToDouble(0x3fe986b91b17e390L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=[J:[[-48, 6705083897535894931]] |a0=[J:[[-48]]\0121=[B:[[-48, 17]] |a0=[B:[[-48]]\012",
        Z.run(T, 2, 32, 19, 7, "\000", "", "",
        17, 72569, -1726595853, 6705083897535894931L, -42420L, false, false, (char) 45271, (char) 59527,
        Double.longBitsToDouble(0x3fb26fa31d19bf38L), Double.longBitsToDouble(0x3e08ee7300000000L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 48607, 57278]] |a0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 48607, 57278]] |a0=[I:[[55677, 56464, 55352, 56852, 55803, 56294, 55880, 57278]]\012",
        Z.run(T, 2, 28, 28, 7, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\udab1\udfc8\ud812\udedb\udaeb\udf58\ud96d\udee2\udb48\udfc3\udb11\udfc9\uda85\udfa0\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\udb60\udf8d\udaa8\ude99\udb80\udcc9\ud884\udfa2", "\uc8e2\u6142\uc8e7", "\ud803\udf3e",
        7, 48607, 1647940872, 2830493674142816403L, -94546L, true, true, (char) 30944, (char) 47855,
        Double.longBitsToDouble(0x3fdd5f38aea3c478L), Double.longBitsToDouble(0x3fe0b5c35b6b3d46L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=[Z:[[true, true, false, false, false, true, false, false, true]] |a0=[Z:[[true, true, false, false, false, true, false, false]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 17, 18, 33, "\udb55\ude35\ud868\ude44\ud850\udf77\udabe\udd08\u1a40", "\uab4c\u8232\u75f9\u2ae8\u8050\u1a67\u558f\uabe3\uc28a\u4faf", "\udbd3\ude0e\uda60\udc26",
        51, 7021, 625448678, 6935364406856930965L, 30892L, true, true, (char) 41521, (char) 38709,
        Double.longBitsToDouble(0x3fe597dc217f8a6fL), Double.longBitsToDouble(0x3fbd261b25cf6828L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=[Z:[[true, true, true, false, true, false, false, true, true]] |a0=[Z:[[true, true, true, false, true, false, false, true]]\0121=[Z:[[true, true, true, true, false, true, false, false, true]] |a0=[Z:[[true, true, true, false, true, false, false, true]]\012",
        Z.run(T, 2, 17, 2, 30, "\ud9e9\uddb9\ud9a1\udd48\uda85\udc10\udabe\udc53\udbc8\udf07\uf049\udaeb\udf58\ud882\udece\ud8d7\ude11", "\uc2ef\u567f\u7c60\uabe3\uc28a\u4faf\uc2ef", "\udac4\udcb9\uda8e\udef7\udab6\uddea\ud98c\udd18\uc2db\uda5a\udd37\uda2a\udff8",
        1, 60117, 1631191220, 824288142121983562L, -94546L, true, true, (char) 22836, (char) 9371,
        Double.longBitsToDouble(0x3fe5aeed56580b9eL), Double.longBitsToDouble(0x3fdb1192bac1bc66L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=[Z:[[false, true, false, true, true, false, true, true, true]] |a0=[Z:[[false, true, false, true, true, false, true, true]]\0121=[Z:[[false, true, false, true, true, false, true, true, true]] |a0=[Z:[[false, true, false, true, true, false, true, true]]\012",
        Z.run(T, 2, 17, 1, 1, "\uda10\udf5d\ud9cc\udfbf\ud9c3\udf42\udac7\udf3f\uda0d\udd82", "\uab4c\u8232\u75f9", "\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udadc\udd39\udb3c\udd8f\udbd3\ude0e\udac4\udcb9\ud802\udf12\udab6\uddd1\ud98c\udd18\uc2db\udbfa\udfe7\uda2b\udc28",
        1, 60117, 1631191220, -4507973816848031551L, -94546L, true, true, (char) 30944, (char) 63934,
        Double.longBitsToDouble(0x3fe21f14e9e41e39L), Double.longBitsToDouble(0x3fd8814e79588b50L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=[Z:[[false]]\0121=[B:[[-127]]\012",
        Z.run(T, 2, 18, 4, 28, "\ud9ad\udcc0\ud868\ude44", "\u3d30\ub094\u2fc5\u6c02\uacf6\ucced\u2ae8\u8050\ud2bd\u8c23\uabe3\uc28a\u2b84\u1db8\u5617\u2e90\u9629\u38d8\u1a0f\u1b15\u4a70\u78c4\u1112\ud06c", "\udb8b\ude6a\udbc4\udf84\uda12\udff5\ud95e\udfc4\ud982\udf64\udabb\udf55\uda64\udd68\udacf\udf3d\ud91b\udce9\ud9c7\udfb1\ud86b\udd1b\udafb\uded4",
        0, 641, 1373700965, -2717444184791636363L, -1269L, false, false, (char) 6133, (char) 43913,
        Double.longBitsToDouble(0x3fe78c989d3e141fL), Double.longBitsToDouble(0x3fda51b45dc5650eL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=[J:[[55661, 56331, 55352, 56852, 55803, 56294, 55880, 57278, -2921973717662888420]] |a0=[J:[[55661, 56331, 55352, 56852, 55803, 56294, 55880, 57278]]\0121=[C:[[\ud99d, \udc3b, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \u8f81, \uf058, \udaeb, \udf58, \ud882, \udece, \ud8d7, \ude11, \udbdc, \udca0, \uda98, \uddf3, \udae7, \udf23, \udae3, \udda8, \ud8e7, \udf9e, \uda45, \udd9a, \ud96e, \udf94, \udaad, \udc2c, \udb80, \udcc9, \ud8bc, \udd1d, \udbc9, \ude8b, \udbf0, \udd2e, \u8e0d, \ud802, \udf12, \ud9ee, \udf36, \ud83d, \udf9d, \ud8db, \udf35, \ud89a, \udddf, \000, \ud944, \udea2, \udbce, \udf83, \udb63, \uded1, \uda76, \ude79, \ud8cf, \udc36, \ud976, \udcef, \ud95e, \udfc4, \ud955, \ude64, \udb25, \ude2a, \ud85e, \udcb5, \udbeb, \udc13, \ud929, \udf57, \ud8e4, \udcdb, \ud95f, \udf51, \udacf, \uddbe, \udb92, \udd16, \ud82c, \udd6d, \ud896, \udcd8, \ud9d3, \ude48, \uda13, \udde1, \udbf7, \udeaa, \ud927, \uddf7, \u0b5e, \ud918, \udc6f, \udb6e... |a0=[C:[[\ud99d, \udc3b, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \u8f81, \uf058, \udaeb, \udf58, \ud882, \udece, \ud8d7, \ude11, \udbdc, \udca0, \uda98, \uddf3, \udae7, \udf23, \udae3, \udda8, \ud8e7, \udf9e, \uda45, \udd9a, \ud96e, \udf94, \udaad, \udc2c, \udb80, \udcc9, \ud8bc, \udd1d, \udbc9, \ude8b, \udbf0, \udd2e, \ud802, \udf12, \ud9ee, \udf36, \ud83d, \udf9d, \ud8db, \udf35, \ud89a, \udddf, \000, \ud944, \udea2, \udbce, \udf83, \udb63, \uded1, \uda76, \ude79, \ud8cf, \udc36, \ud976, \udcef, \ud95e, \udfc4, \ud955, \ude64, \udb25, \ude2a, \ud85e, \udcb5, \udbeb, \udc13, \ud929, \udf57, \ud8e4, \udcdb, \ud95f, \udf51, \udacf, \uddbe, \udb92, \udd16, \ud82c, \udd6d, \ud896, \udcd8, \ud9d3, \ude48, \uda13, \udde1, \udbf7, \udeaa, \ud927, \uddf7, \u0b5e, \ud918, \udc6f, \udb6e, \udce1...\012",
        Z.run(T, 2, 32, 22, 19, "\ud99d\udc3b\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaad\udc2c\udb80\udcc9\ud8bc\udd1d\udbc9\ude8b\udbf0\udd2e\ud802\udf12\ud9ee\udf36\ud83d\udf9d\ud8db\udf35\ud89a\udddf\000\ud944\udea2\udbce\udf83\udb63\uded1\uda76\ude79\ud8cf\udc36\ud976\udcef\ud95e\udfc4\ud955\ude64\udb25\ude2a\ud85e\udcb5\udbeb\udc13\ud929\udf57\ud8e4\udcdb\ud95f\udf51\udacf\uddbe\udb92\udd16\ud82c\udd6d\ud896\udcd8\ud9d3\ude48\uda13\udde1\udbf7\udeaa\ud927\uddf7\u0b5e\ud918\udc6f\udb6e\udce1\ud800\ude66\udb88\ude8c\udb00\udea7\ud83b\udc03\udb2f\udca8", "\uba13\u8732\ub353\u1078\u9ff4\u018f\ud5f7\u7741\u13c9\uba49\u2515\u27c9\u16cf\u03d2\u2270\u2c50\uac7e\u7fff\u3f7e\u2402\u394b\u1c96\u4a1a\u2c45", "\udab6\udcad\u2133\ud998\udc41\ud99b\udecf\ud80c\udd87\ud861\udfae\uda6a\uddec\uda3f\uddb2\ud873\udc77",
        40, 37576, -925225958, -2921973717662888420L, 82911L, false, false, (char) 36365, (char) 21151,
        Double.longBitsToDouble(0x3fd5f42e34b0eeaaL), Double.longBitsToDouble(0x3fd272936ebdd934L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=[Z:[[true, false, true, false, false, false, false, false, true]] |a0=[Z:[[true, false, true, false, false, false, false, true]]\0121=[Z:[[true, false, true, false, false, false, false, false, true]] |a0=[Z:[[true, false, true, false, false, false, false, true]]\012",
        Z.run(T, 2, 2, 18, 16, "\ud9ad\udcc0\ud943\udc52\000\000\udaa8\uddd3\ua558\ud9a1\udfd3\ud882\udece\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udae7\udf23\u4f81\000\ud8f9\udc1cI\udaa8\uddf6\uda80\ude28\udb47\ude75", "\u7df9\u6fd7\u6e95\u3d56\ubcb9\u5357\u3590\u4de5\ud757\u1a7d\000\uca12\uc75b\u324c\uc23a\u0a16\u459b\u8272", "\ud99f\ude84\udbe2\udcc6\uda2c\uddeb\ud81e\uddad\uda91\udc48\udba9\ude46\ud9bf\udd96\udb20\udc09\uda33\udf40\u8312\ucc30\ud9a2\udee0\udaa4\udfac\ud951\udc4b\udbb7\uded4\ud8e9\udd7a\udac3\udebd\ud8e5\udf29\udb64\udd9d\udaf9\uddda\udb5e\uddcd\uda3b\ude3c\udaa6\udd9a\ud916\udf0d\ud847\udf5a\uda65\udc07\udbbd\udfb2\uda52\udc89\udb5d\udcf1\udb4d\udddd\udb72\ude6b\u65e5\u82dd\ud937\udc05\ud8ea\uded3\uda64\uddc3\udaa8\udc3d\uda27\udeda\ud928\udc9c\uda63\udea0\udb52\udf12\udba0\udd13\ud950\udc67\ud8f3\udda5\uda78\udd4c\udbf8\udf25\ud910\udd51",
        3, 15291, 155618296, 2749077520638567626L, 99226L, false, true, (char) 26376, (char) 60030,
        Double.longBitsToDouble(0x3fd78b836c2956e0L), Double.longBitsToDouble(0x3feced00073d0019L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=[J:[[-4716129220705514082]]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 32, 8, 7, "\000", "\ud414\ub271\ub094\u2fc5", "\udbdc\udca0\uda98\uddf3",
        3, 19353, 0, -4716129220705514082L, -86174L, false, false, (char) 58487, (char) 6222,
        Double.longBitsToDouble(0x3ec4223730000000L), Double.longBitsToDouble(0x3fdbd0000b64dbaeL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=[D:[[28124.0, 28474.0, 27676.0, 0.6092148913865738, 28431.5, 27901.5, 28147.0, 27850.0, 28394.0]] |a0=[D:[[28124.0, 28474.0, 27676.0, 28431.5, 27901.5, 28147.0, 27850.0, 28394.0]]\0121=[D:[[28124.0, 28474.0, 27676.0, 0.6092148913865738, 28431.5, 27901.5, 28147.0, 27850.0, 28394.0]] |a0=[D:[[28124.0, 28474.0, 27676.0, 28431.5, 27901.5, 28147.0, 27850.0, 28394.0]]\012",
        Z.run(T, 2, 24, 24, 7, "\udbe8\udea4\ud868\ude4f\uda2b\udc16\ud9c4\ude04\udbeb\udc5b\uf058\ub5bc\ud86c\udc29\ud8d7\ude11\udbdc\udca0\udbb3\udc40\udb02\udf37\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\u1f1c\u0ee0", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud94c\udffe\ud976\udcef",
        3, 72867, 1393648248, -935462479071496747L, -24758L, true, true, (char) 62867, (char) 30840,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fcf09517ee12834L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 33, 1, 7, "\000", "", "\uf058",
        20, 86972, 1491560660, -1705287534149339179L, -59296L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe1233007b6eebdL), Double.longBitsToDouble(0x3fe2a80000002dc3L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=[C:[[\ud9ad, \udc6e, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \ud991, \ude45, \udbdc, \udca0, \ud81f, \udd64, \ud85d, \uddb0, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud9df, \udfcc, \ud976, \udc6b, \uda99, \udffe, \ud8bc, \udd1d, \udbd3, \ude0e, \udbf0, \udd2e, \uda46, \udc1b, \uda1a, \udff5, \ud952, \udf2f, \ud8fe, \uddd3, \ud89a, \udddf, \u49e6, \ud9bf, \ude1e, \udbce, \udf83, \u0fc3, \udbab, \udf53, \ud8fc, \udcb5, \ud979, \udf10, \uda48, \ude0b, \ud94a, \uddf3, \uda99, \udf04, \ud85e, \udcb5, \u644a, \ud822, \udd86, \ud9b1, \uddb2, \ud94d, \udf07, \udba8, \uddcb, \uda94, \ude4c, \ud80b, \udcb2, \ud813, \udc0d, \ud9d3, \ude48, \ud992, \udf55, \ud9d4, \udd67, \ud9a2, \udc23, \uda50, \udf50, \uda30, \udff7, \udabc, \udcd4... |a0=[C:[[\ud9ad, \udc6e, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \ud991, \ude45, \udbdc, \udca0, \ud81f, \udd64, \ud85d, \uddb0, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud9df, \udfcc, \ud976, \udc6b, \uda99, \udffe, \ud8bc, \udd1d, \udbd3, \ude0e, \udbf0, \udd2e, \uda46, \udc1b, \uda1a, \udff5, \ud952, \udf2f, \ud8fe, \uddd3, \ud89a, \udddf, \u49e6, \ud9bf, \ude1e, \udbce, \udf83, \u0fc3, \udbab, \udf53, \ud8fc, \udcb5, \ud979, \udf10, \uda48, \ude0b, \ud94a, \uddf3, \uda99, \udf04, \ud85e, \udcb5, \u644a, \ud822, \udd86, \ud9b1, \uddb2, \ud94d, \udf07, \udba8, \uddcb, \uda94, \ude4c, \ud80b, \udcb2, \ud813, \udc0d, \ud9d3, \ude48, \ud992, \udf55, \ud9d4, \udd67, \ud9a2, \udc23, \uda50, \udf50, \uda30, \udff7, \udabc, \udcd4...\0121=[C:[[\ud9ad, \udc6e, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \ud991, \ude45, \udbdc, \udca0, \ud81f, \udd64, \ud85d, \uddb0, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud9df, \udfcc, \ud976, \udc6b, \uda99, \udffe, \ud8bc, \udd1d, \udbd3, \ude0e, \udbf0, \udd2e, \uda46, \udc1b, \uda1a, \udff5, \ud952, \udf2f, \ud8fe, \uddd3, \ud89a, \udddf, \u49e6, \ud9bf, \ude1e, \udbce, \udf83, \u0fc3, \udbab, \udf53, \ud8fc, \udcb5, \ud979, \udf10, \uda48, \ude0b, \ud94a, \uddf3, \uda99, \udf04, \ud85e, \udcb5, \u644a, \ud822, \udd86, \ud9b1, \uddb2, \ud94d, \udf07, \udba8, \uddcb, \uda94, \ude4c, \ud80b, \udcb2, \ud813, \udc0d, \ud9d3, \ude48, \ud992, \udf55, \ud9d4, \udd67, \ud9a2, \udc23, \uda50, \udf50, \uda30, \udff7, \udabc, \udcd4... |a0=[C:[[\ud9ad, \udc6e, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \ud991, \ude45, \udbdc, \udca0, \ud81f, \udd64, \ud85d, \uddb0, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud9df, \udfcc, \ud976, \udc6b, \uda99, \udffe, \ud8bc, \udd1d, \udbd3, \ude0e, \udbf0, \udd2e, \uda46, \udc1b, \uda1a, \udff5, \ud952, \udf2f, \ud8fe, \uddd3, \ud89a, \udddf, \u49e6, \ud9bf, \ude1e, \udbce, \udf83, \u0fc3, \udbab, \udf53, \ud8fc, \udcb5, \ud979, \udf10, \uda48, \ude0b, \ud94a, \uddf3, \uda99, \udf04, \ud85e, \udcb5, \u644a, \ud822, \udd86, \ud9b1, \uddb2, \ud94d, \udf07, \udba8, \uddcb, \uda94, \ude4c, \ud80b, \udcb2, \ud813, \udc0d, \ud9d3, \ude48, \ud992, \udf55, \ud9d4, \udd67, \ud9a2, \udc23, \uda50, \udf50, \uda30, \udff7, \udabc, \udcd4...\012",
        Z.run(T, 2, 21, 21, 33, "\ud9ad\udc6e\ud868\ude44\uda2b\udc16\uda78\udfee\uda24\udd40\uf0f8\udaeb\udf58\udb1a\udffa\ud991\ude45\udbdc\udca0\ud81f\udd64\ud85d\uddb0\udacf\ude27\ud8b1\udf9d\uda45\udd9a\ud9df\udfcc\ud976\udc6b\uda99\udffe\ud8bc\udd1d\udbd3\ude0e\udbf0\udd2e\uda46\udc1b\uda1a\udff5\ud952\udf2f\ud8fe\uddd3\ud89a\udddf\u49e6\ud9bf\ude1e\udbce\udf83\u0fc3\udbab\udf53\ud8fc\udcb5\ud979\udf10\uda48\ude0b\ud94a\uddf3\uda99\udf04\ud85e\udcb5\u644a\ud822\udd86\ud9b1\uddb2\ud94d\udf07\udba8\uddcb\uda94\ude4c\ud80b\udcb2\ud813\udc0d\ud9d3\ude48\ud992\udf55\ud9d4\udd67\ud9a2\udc23\uda50\udf50\uda30\udff7\udabc\udcd4", "\u1281\u828f\u8cd0\ubb9f\u6e7a\u219a\ua1dc\u10ff\uaeb8\u8719\u8fb9\ubca0\u2476\ud3a4\u9fc7\u51b4\u212c\ua524\u6301", "\udbbb\uded2\ud8c3\udf27\ud944\uddad\ud9b6\uddad\udb0b\udccd\ud922\udc27\udb00\udd00\uda7a\udc2e\uda6f\udcba\ud8ca\udf76\udafa\udd23\udad3\udf7d\udb0d\udca6",
        27, 28018, -1367777132, 1505144341519852797L, -68235L, true, false, (char) 51995, (char) 24529,
        Double.longBitsToDouble(0x3fe8bd4a3bba0485L), Double.longBitsToDouble(0x3f7903f745966600L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=[C:[[\ud9ad, \udc6e, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \u95f1, \ud9ff, \udf25, \ud818, \udc64, \ud85d, \ude0d, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud8a1, \ude4f, \ud97a, \udc64, \uda99, \udffe, \ud8bc, \udd1d, \udbd3, \ude0e, \udbf0, \udd2e, \uda46, \udc1b, \uda1a, \udff5, \ud952, \udf2f, \ud8fe, \uddd3, \ud89a, \udddf, \u49e6, \ud9bf, \ude1e, \udbce, \udf83, \u0fc3, \udb9f, \udf4d, \ud8fc, \udcb5, \ud979, \udf10, \uda48, \ude0b, \ud94a, \uddf3, \uda99, \udf04, \ud85e, \udcb5, \u644a, \ud822, \udd86, \ud9b1, \uddb2, \ud94d, \udf07, \udba8, \uddcb, \uda94, \ude4c, \ud8ab, \uddee, \ud97f, \udd36, \ud9d3, \ude8e, \udbe4, \udd0e, \ud9d4, \udd59, \ud9a2, \udc23, \uda50, \udf50, \uda30, \udff7, \udabc, \udcd4, \ua01b... |a0=[C:[[\ud9ad, \udc6e, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \uda24, \udd40, \uf0f8, \udaeb, \udf58, \udb1a, \udffa, \u95f1, \ud9ff, \udf25, \ud818, \udc64, \ud85d, \ude0d, \udacf, \ude27, \ud8b1, \udf9d, \uda45, \udd9a, \ud8a1, \ude4f, \ud97a, \udc64, \uda99, \udffe, \ud8bc, \udd1d, \udbd3, \ude0e, \udbf0, \udd2e, \uda46, \udc1b, \uda1a, \udff5, \ud952, \udf2f, \ud8fe, \uddd3, \ud89a, \udddf, \u49e6, \ud9bf, \ude1e, \udbce, \udf83, \u0fc3, \udb9f, \udf4d, \ud8fc, \udcb5, \ud979, \udf10, \uda48, \ude0b, \ud94a, \uddf3, \uda99, \udf04, \ud85e, \udcb5, \u644a, \ud822, \udd86, \ud9b1, \uddb2, \ud94d, \udf07, \udba8, \uddcb, \uda94, \ude4c, \ud8ab, \uddee, \ud97f, \udd36, \ud9d3, \ude8e, \udbe4, \udd0e, \ud9d4, \udd59, \ud9a2, \udc23, \uda50, \udf50, \uda30, \udff7, \udabc, \udcd4]]\0121=[D:[[27838.5, 28191.0, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0, 0.7731066862617274]] |a0=[D:[[27838.5, 28191.0, 27676.0, 28426.0, 27901.5, 28147.0, 27940.0, 28639.0]]\012",
        Z.run(T, 2, 21, 23, 22, "\ud9ad\udc6e\ud868\ude44\uda2b\udc16\uda78\udfee\uda24\udd40\uf0f8\udaeb\udf58\udb1a\udffa\u95f1\ud9ff\udf25\ud818\udc64\ud85d\ude0d\udacf\ude27\ud8b1\udf9d\uda45\udd9a\ud8a1\ude4f\ud97a\udc64\uda99\udffe\ud8bc\udd1d\udbd3\ude0e\udbf0\udd2e\uda46\udc1b\uda1a\udff5\ud952\udf2f\ud8fe\uddd3\ud89a\udddf\u49e6\ud9bf\ude1e\udbce\udf83\u0fc3\udb9f\udf4d\ud8fc\udcb5\ud979\udf10\uda48\ude0b\ud94a\uddf3\uda99\udf04\ud85e\udcb5\u644a\ud822\udd86\ud9b1\uddb2\ud94d\udf07\udba8\uddcb\uda94\ude4c\ud8ab\uddee\ud97f\udd36\ud9d3\ude8e\udbe4\udd0e\ud9d4\udd59\ud9a2\udc23\uda50\udf50\uda30\udff7\udabc\udcd4", "\u1281\u828f\u8cd0\ubb9f\u6e7a\u219a\ua1dc\u10ff\uaeb8\u8719\u8fb9\ubca0\u2476\ud3a4\u9fc7\u51b4\u212c\ua524\u6301", "\udbbb\uded2\ud8c3\udf27\ud944\uddad\ud9c3\udcad\udb0b\udccd\ud922\udc27\udb00\udd00\uda7a\udc2e\uda6f\udcba\ud8ca\udf76\udafa\udd23\udad3\udf7d\udb0d\udca6",
        27, 28018, -1367777132, 1505144341519852797L, -68235L, true, false, (char) 40987, (char) 24529,
        Double.longBitsToDouble(0x3fe8bd4a3bba0485L), Double.longBitsToDouble(0x3f7903f745966600L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 27, 7, "\ud9ad\udcc0\ud868\ude44\udb6a\udc0a\uda78\udfee\u8f81\uf058\udb67\udf15\ud843\udc7b\ud850\udebc\udbcf\uddff\uda98\uddf3\udae7\udf23\udaeb\udce6\ud8e7\udf9e\uda45\udd9a\uda3a\udedb\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\ua12b\ud3eb", "\u49e6\ud9bf\ude1e\udbce\udf83\udb63\uded1\udbab\udf53\ud8fc\udcb5\ud976\udcef",
        50, 9151, -650780556, -8334311913001545776L, -24930L, true, true, (char) 62867, (char) 50739,
        Double.longBitsToDouble(0x3fe37eb03a57ba96L), Double.longBitsToDouble(0x3fdb4588bf701a72L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=[S:[[10464, -9859, -9072, -10034, -8256, -9734, -8335, -9656, -8258]] |a0=[S:[[-9859, -9072, -10034, -8256, -9734, -8335, -9656, -8258]]\0121=[S:[[10464, -9859, -9072, -10034, -8256, -9734, -8335, -9656, -8258]] |a0=[S:[[-9859, -9072, -10034, -8256, -9734, -8335, -9656, -8258]]\012",
        Z.run(T, 2, 33, 33, 6, "\ud9ad\udcc0\ud8fe\udff0\uda2a\udfa1\uda78\udfee\u8f81\udacd\udc41\ud8e7\udf36\ua8d2\udb67\udc1c\udbb6\uddaf\uda98\uddf3\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d", "\u38d8\u7e80\u9c6e", "\u49e6\ud9bf\ude1e\ud737\udaf2\ude78\ud80f\udceb\ud8fc\udcfd\uda63\udc03\udb3f\udcc6\ud982\udf64\udb25\ude2a\ud85e\udcb5\udbeb\udc13\ud82c\udf19\ud87f\udf1a\ud8a7\ude2c\ud8d8\udf63\udb31\udf7b\ud96d\udd77\uda08\udd35\ud992\udeb7",
        0, 10464, -808892601, 1343797110863918474L, 16791L, false, false, (char) 42829, (char) 61869,
        Double.longBitsToDouble(0x3fe80f99c010aa54L), Double.longBitsToDouble(0x3fc39a5ddd678614L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=[J:[[-2144639397303455919]]\0121=[J:[[-2144639397303455919]]\012",
        Z.run(T, 2, 15, 31, 23, "\udb50\udcc1\uec4e\000\ud88c\ude8b\u4f4d\uf058\udaeb\udf58\ud882\udece\ud8d7\ude11\ud90d\ude19\uda06\uddb7\uc781\ud91c\udeff\ud8b4\udc4a\000\ud96e\udf4b\udaa8\ude99\u7cf9\u1800", "\u98a3", "\ud8db\udf35\ud89a\udddf\u491a\ud9bf\ude1e\udbce\udf83\udb63\uded1\ud963\uddaf\ud8fc\udcb5\ud976\udcef\ud95e\udfc4",
        0, 40494, -217821149, -2144639397303455919L, -15086L, true, false, (char) 50739, (char) 17527,
        Double.longBitsToDouble(0x3fe2bdd4b5814a8bL), Double.longBitsToDouble(0x3fedc069cba280aeL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 19, 6, "\ud9ad\udcc0\ud882\ude49\ud891\udcf6\udaad\uddf9\udae4\udeb5\ud9a6\udecd\udaeb\udfc8\uda18\udcd6\udba3\udddb\udb11\udfc9\uda85\udfa0\udae7\udf23\udae3\udda8\ud8e7\udf9e\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb80\udcc9\ud8bc\udd1d\uda8a\udd89\ud838\udc17\ud848\udcf5\uda2b\udf13", "\u8f40\u0666\u679b\u798d\u3d72\u4d8e\u8344\u4e15\uc75b\u16bd\u3e09\ud1f6\u7a8e\u827a\u22b6\u2b7e\uacd4", "\uda7a\uddbb\ud81a\uddcb\ud910\udc11\uda88\uddfc\uda52\udde2\ud83e\udc49\ud805\udf34\udb22\uddf2\udb33\udf27\udbb4\ude67\ud82b\udd49\udbe8\udee1\udac1\udebb\uda89\udd8b\uda59\udf2a\ud966\udda2\ud8af\udc60\udb3f\udd6e\udbc7\udcb1\ud9fb\udf1e\udb28\udcdf\ud98b\ude69\udae4\udd89\udba7\udd5c\udb2f\udcd6\uda1d\udfbd\udbc6\udca9\udaff\ude88\udbe0\udd2d\udb22\udc87\uda32\uddd0\udb47\udc58\udad6\udfe8\uda46\ude45\udb8e\udd65\udb8e\udfa6\udab1\udd29\uda5b\udc63\udb41\udcd2\ud9d8\uddd3\udb28\udfd5\udabb\udd7b\ud803\udc7c\ud98d\udde8\u17a8\ud992\udffc\uda7d\udc5a\udbd2\udeb1\udba8\uddc7\ud9d4\udd9c\udbc7\udf6b\udbcb\udcc0\uda9e\udea7\uda89\ude01\u5f8c\ud8af\udd45\udb11\uddd1\ud96c\udd04\udb6f\udeca\ud930\ude44\udbe1\udc12\udb0c\udce8\uda7d\udd67\ud8ff\udd50\ud801\udf69\ud9cf\ude9e\udb52\udfcf\ud590\ud899\udc7a\ud9c2\uddd2\u032c\uda5e\udf71\ud88d\udfa3\uda56\udd29\ud838\uddae\ud915\udee1\ud80c\udcae\ud9e4\udc9a\ud899\udcc1\udad2\udd76\ud8c4\ude06\ubf20\ud902\udc56\udacf\udf55\uda97\udc52\ud88a\udf3f\ud990\udeec\ud812\uddc7\udb2c\udfc5\ud8ce\udd8a\udbb6\udd78",
        17, 68028, -1624215239, -2722004925192839588L, -99641L, false, true, (char) 28561, (char) 10143,
        Double.longBitsToDouble(0x3fdbd12232cef9a0L), Double.longBitsToDouble(0x3fde219a8f1b5ff6L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=[B:[[-12, 125, -112, 56, 20, -5, -26, 72, -66]] |a0=[B:[[125, -112, 56, 20, -5, -26, 72, -66]]\0121=[C:[[\ud9ad, \udcc0, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \u8f81, \ud910, \udc01, \udb0f, \udda0, \ud938, \udc96, \ud82f, \udd02, \udbfe, \uded5, \ud806, \udd65, \udae7, \udf23, \udae3, \udda8, \ud976, \udea4, \uda45, \udd9a, \udbef, \ude15, \udbb0, \udf5f, \ucf80, \ud8bc, \udd1d, \u15cf]] |a0=[C:[[\ud9ad, \udcc0, \ud868, \ude44, \uda2b, \udc16, \uda78, \udfee, \u8f81, \ud910, \udc01, \udb0f, \udda0, \ud938, \udc96, \ud82f, \udd02, \udbfe, \uded5, \ud806, \udd65, \udae7, \udf23, \udae3, \udda8, \ud976, \udea4, \uda45, \udd9a, \udbef, \ude15, \udbb0, \udf5f, \ucf80, \ud8bc, \udd1d]]\012",
        Z.run(T, 2, 20, 21, 2, "\ud9ad\udcc0\ud868\ude44\uda2b\udc16\uda78\udfee\u8f81\ud910\udc01\udb0f\udda0\ud938\udc96\ud82f\udd02\udbfe\uded5\ud806\udd65\udae7\udf23\udae3\udda8\ud976\udea4\uda45\udd9a\udbef\ude15\udbb0\udf5f\ucf80\ud8bc\udd1d", "\u38d8\ua12b\ud3eb\u133a\u38d4\u02b0\u7526\u219f\u3d72\ubbd0\u8344\u6be3\uc75b\ud58d\u3403\u8e87\u7722\u827a\u600b\u8903\u9e87\u8836\ub3db\u340a\ucdd9\u9f50\u9d37\ua958\u7c49\u9ace\u16bd\u46b5\u59dc\u0ca7\ubd37\ub2e7\ubeeb\u7465\u8d0a", "\udb66\udca2\ud9c5\udd28\ud899\udf21\udb11\udfcd\ud8b0\udf5e\uda03\ude05\udb7c\uddc2\u09a8\ud82f\uddec\ud8e8\udd3c\ud894\udc27\ud919\udfcd\udba2\ude17\ud901\udd9e\ud971\udc4f\ud884\udd9d\uda0c\udd0b\uda16\udcc9\uda06\udd17\ud865\udd70\ud875\udde0\uda7b\ude07\ud89d\uddd4\ud8ea\udca0\uda10\udfb5\udb26\udcc8\ud9b1\udff3\ud9d2\udc94\ud9c4\udf56\udbfc\udcc8\ud89d\uddcc\u1d1f\uda35\ude3f\ud967\udfab\ud845\udcf3\ud81c\ude2a\ud8df\udeca\ud884\udd1c\uda02\udeaf\ud841\udd91\udbb3\udc02\udb99\udebf\udb14\udc41\ud97e\udda7\ud8af\udc61\ud940\udfc1\ud95d\ude7d\udae1\udddf\ud933\udf27\ud9dd\ude44\ud813\udf98\udb8a\ude50\ud87a\ude71\udab5\uddbd\uda6f\udf82\uda2a\udcf6\udb63\ude9a\ud8e3\udf0c\ud9d4\ude19\ud8ba\udc28\udb1f\udd00\ud9bc\udce6\udb64\udd3b\udbd1\udcff\ud97b\udd3a\ud91b\udf09\uda42\udc61\ud996\udc40\ud81e\udfea\udb05\uddfe\ud8e5\udfff\udb6d\udf03\ud8ed\udefc\uda6e\udf74\ud986\ude96\ud98b\udca9\ud8b7\ude38\ud9cd\udc04\ud997\uddce\ud9bc\udd9d\ud984\udf27\udb3f\udebf\uda90\uddf4\uda6a\udf53\udb01\udeb0\udbe0\udee1\udac4\ude89\u51fc\ud845\udd77\udae2\udedd\ud912\ude7e\udabf\udd5e\ud939\udc55\udb57\ude80\ud846\udd65\ud8c0\udcd8\ud944\udd37\udaba\udc96\ud879\udf28\udbca\udf12\udbc2\udd23\uda38\udc86\uda46\ude3c\ud87b\udfe4\udb39\udc15\ud9d8\udf0a\udb8f\udea5\uda42\udd8d\udb08\udd2c\ud923\udd4e\udbae\udee3\udb51\udc85\ud830\udef3\ufa18\ud95d\ude31\ud8c2\udd78\ud847\udde6\udb0b\udc90\ud810\udf7d\ud888\udf87\udb45\udeb5\udafd\udc10\ud98b\udc8b\ud9e9\udcd8\uda5f\ude10\uda44\udfbe\ud94e\udd3f\uda81\udfd8\udb4e\udf85\ud95b\udff8\ud86a\udf6a\ud95f\udc78",
        0, 66804, -366060115, 5006679360342591970L, 28997L, false, true, (char) 5583, (char) 30995,
        Double.longBitsToDouble(0x3fe4b0830a2ebe69L), Double.longBitsToDouble(0x3fec5a129056ae59L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\u8272\ud8c1\udc33\ud8fb\uded3\udaa1\udd18\u8f81\uf05a\uda42\udee2\udbe4\ude2f\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udb91\udeca\udae3\udda8\ud8eb\uddbf\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\udaf9\udff8, \u2415\u0294\u15d5\u6007\ub23f\ud19e\u7573\u0596]] |a0=[Ljava.lang.Object;:[[\u8272\ud8c1\udc33\ud8fb\uded3\udaa1\udd18\u8f81\uf05a\uda42\udee2\udbe4\ude2f\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udb91\udeca\udae3\udda8\ud8eb\uddbf\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\udaf9\udff8]]\0121=[Ljava.lang.Object;:[[\u8272\ud8c1\udc33\ud8fb\uded3\udaa1\udd18\u8f81\uf05a\uda42\udee2\udbe4\ude2f\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udb91\udeca\udae3\udda8\ud8eb\uddbf\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\udaf9\udff8, \u2415\u0294\u15d5\u6007\ub23f\ud19e\u7573\u0596]] |a0=[Ljava.lang.Object;:[[\u8272\ud8c1\udc33\ud8fb\uded3\udaa1\udd18\u8f81\uf05a\uda42\udee2\udbe4\ude2f\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udb91\udeca\udae3\udda8\ud8eb\uddbf\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\udaf9\udff8]]\012",
        Z.run(T, 2, 13, 13, 28, "\u8272\ud8c1\udc33\ud8fb\uded3\udaa1\udd18\u8f81\uf05a\uda42\udee2\udbe4\ude2f\ud8d7\ude11\udbdc\udca0\uda98\uddf3\udb91\udeca\udae3\udda8\ud8eb\uddbf\uda45\udd9a\ud96e\udf94\udaa8\ude99\udb5e\udc2e\udaf9\udff8", "\u2415\u0294\u15d5\u6007\ub23f\ud19e\u7573\u0596", "\ud8cf\udcb2\ud976\udcef\ud95e\udfc4\ud9db\udd6f\ud9ad\uddee\ud99a\udfd2\udbea\udfe6\ud82c\udf19",
        1, 62867, -852720135, -3168403329829444294L, -96543L, false, false, (char) 46710, (char) 17482,
        Double.longBitsToDouble(0x3fe347d9be921ebbL), Double.longBitsToDouble(0x3fe12ec1540b6455L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.ArrayUtils|add|java.lang.Object,int,java.lang.Object,java.lang.Class|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[Z,boolean|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[Z,int,boolean|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[B,byte|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[B,int,byte|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[C,char|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[C,int,char|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[D,double|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[D,int,double|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[F,float|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[F,int,float|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[I,int|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[I,int,int|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[Ljava.lang.Object;,int,java.lang.Object|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[Ljava.lang.Object;,java.lang.Object|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[J,int,long|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|java.lang.Object,int,java.lang.Object,java.lang.Class|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[Z,boolean|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[Z,int,boolean|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[B,byte|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[B,int,byte|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[C,char|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[C,int,char|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[D,double|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[D,int,double|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[F,float|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[F,int,float|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[I,int|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[I,int,int|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[Ljava.lang.Object;,int,java.lang.Object|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[Ljava.lang.Object;,java.lang.Object|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[J,int,long|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[J,long|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[S,int,short|static",
    "M|org.apache.commons.lang3.ArrayUtils|add|[S,short|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
