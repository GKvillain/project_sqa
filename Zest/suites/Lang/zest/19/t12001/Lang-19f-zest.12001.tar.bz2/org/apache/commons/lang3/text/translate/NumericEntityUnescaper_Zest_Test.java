package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumericEntityUnescaper_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\ud9a3\udc7a", "\u68d0\u4fab", "\udbc2\ude80\udab0\udfc2\udb77\udc57\uda9b\udd0f\ud85e\udf32\uda48\ude1a\udb3f\udc5d\udb7e\udf7f\udb92\udd19\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udab8\uddcf",
        55, 76418, -19335385, -3611707873586268092L, 96032L, false, false, (char) 3269, (char) 23941,
        Double.longBitsToDouble(0x3fd19e6ad66ee2b8L), Double.longBitsToDouble(0x3fe803c6e35a4573L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\ud9a3\udc7a", "\u68d0\u4fab", "\udbc2\ude80\udaab\udfe0\udbef\udc4c\udbef\uddd1\ud887\udce6\udbb8\udc4d\udb3f\udc5d\udb7e\udf7f\udb92\udd19\uda0b\udf0b\udbdf\ude65\ud8eb\udf7e\udab8\uddcf",
        55, 76418, -539429081, -3611645639510149052L, 96032L, false, false, (char) 3269, (char) 23941,
        Double.longBitsToDouble(0x3fd19e6ad66ee2b8L), Double.longBitsToDouble(0x3fce3a1b86758e54L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\uda51\udde9\udafe\udf62\ud95d\udd86", "\u2d25\uaeec\ua312\u3c9e\u21bf\u27db\u4d62\u148c\ub11c", "\ud9c0\ude7b",
        14, 91894, 294556495, 2644486981158083543L, -76353L, false, true, (char) 44971, (char) 49803,
        Double.longBitsToDouble(0x3fd289db98146048L), Double.longBitsToDouble(0x3fd64b2dd92b8686L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udbd5\ude0b\000\ud937\udd6f\ud977\udc68\000\ud84d\uddce\ud8f8\ude0a", "", "\ud8e5\udc32\ud8bc\udd2c\uf591\uda94\udffd\ud933\udc8d\ud8ce\udf67\udbc2\ude80\udab0\udfc2\udb77\udc57\uda94\ude29",
        45, -1000, -838729728, 6877266973416226875L, -64928L, false, false, (char) 34047, (char) 4057,
        Double.longBitsToDouble(0x3fecd02a3000daabL), Double.longBitsToDouble(0x3e01337800000000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\ud829\udd75\uda2f\udeb5", "\u5af1\u6d3c", "\udad5\udecb\ud943\udc46\ud9a3\udc7a\ud8e5\udc32\ud8bc\udd2c\udbf4\udf6d\uda94\udffd\ud933\udc8d\udb1d\udea9\udba6\ude8d\ud872\udc2e\udb76\udd57\ud925\udc35",
        55, 12762, -838693040, 6877266973664104507L, -22671L, true, false, (char) 14401, (char) 4057,
        Double.longBitsToDouble(0x3fbc06b6bbe5eef8L), Double.longBitsToDouble(0x3fec24a6c63ccdc0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "", "\000\000\uc951\u2d25\uae5b\ua312\u3c9e\u21bf\u27db\u4d62\u3902\u68d0", "\ud9c0\ude7b",
        14, 91894, 294556495, -184549376L, -100000L, false, true, (char) 24432, (char) 46021,
        Double.longBitsToDouble(0x3f43b72000000000L), Double.longBitsToDouble(0x3e42540000000000L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud8a9\udf2e", "\u1096\uc951\u2d25\uae5b\ua312\u165c\ucc82\u885e\u370e\ud135\uc5ba\u75fc\u532b", "\ud99c\ude40\ud893\udcb1\ud8ae\udf02\ud9f6\udf87\uda89\udd9b\ud9dc\udd5a\udb7e\udf7f\ud93f\udcf0\ud94e\udc36\ud910\udffe\udb96\udf73",
        4, 81188, -626324582, -83083293520240644L, -9474L, false, false, (char) 27762, (char) 47068,
        Double.longBitsToDouble(0x3fd5a457303bd2d2L), Double.longBitsToDouble(0x3fd0fad0ed90f668L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ufe00", "\u1096\u00a5\000\000\000\u48c2N", "\000\ud870\udf58",
        10, -915, 28416, -706543616L, -100000L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\ud829\udd75\ud88b\udec3", "\uc951", "\000\udb7a\udf7e",
        54, 70733, -458983985, 14802725044748288L, 96608L, false, false, (char) 26930, (char) 11380,
        Double.longBitsToDouble(0x3f22598000000000L), Double.longBitsToDouble(0x3fea84c005e0ce02L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe", "\u9af8\u1f69\u1633\u10b8\u8926\u6682\u773b\u9597\u59b3\u6b78\u35ce\u0455\036\u1e65\u6ee3\u15b0\u5410\u0827\u17d2\u4282\u1a37\ua89d\ub540\u52d5\u075b\u45c9\u9b73\ub790\u1be2\ub4e5\uc4be\u1b56\u1771\u2f6c\ua3e8\u64dd\u5275\u1150\u7fcf\u4845\u165c\u1bb7", "\uda8c\udc2e",
        -1, 3524, -1971598777, 4436199814016805433L, -4633L, false, false, (char) 58713, (char) 51245,
        Double.longBitsToDouble(0x3fd665942b0741c8L), Double.longBitsToDouble(0x3fe1b738db33b872L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6fd\000\ud9fd\ude2b\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\ud9a3\udc7a", "\u68d0\u47fc", "\uda61\uddaf",
        -5, -1000, 0, -1734156288L, 99200L, true, false, (char) 49803, (char) 9953,
        Double.longBitsToDouble(0x3f846049592cb740L), Double.longBitsToDouble(0x3fc2b8686e681518L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\ud9a3\udc7a", "\u68d0\u4fab\u5933\u6b78\u35ce\u0455\036\u1e65\u6ee3\u15b0\u6cd1\u16fe\ub1bd\u2f4c\u1a37\ua89d\ub567\u52d5\u075b\u45c9\u276b\ub790\u1be2\ub4e5\uc4be\u1b56\u1771\u2f6c\ua3e8\u3f74\u5275\u1150\u507c\u2c71\uad7b\u393e\u2390\u6243\ub3a0\ub520\u5c3d\u960b\ud0d6\u2e53\u8bfb\uaa51\u8bd7\u9872\u8294\u7f0e\uaa89\ua091", "\ud9de\udf00\ud801\udf5f\udb11\udc48\ud989\udc98\ud88b\udead",
        42, 35685, -292580412, 1251703441099486059L, -1760L, false, true, (char) 27480, (char) 3617,
        Double.longBitsToDouble(0x3fdc14ced2f1eea2L), Double.longBitsToDouble(0x3fd8dc780d34c322L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\ud9a3\udc7a", "\u68d0\u4fab", "\udbc2\ude80\udab0\udfc2\udb77\udc57\uda9b\udd0f\ud85e\udf32\uda48\ude1a\udb3f\udc5d\udb7e\udf7f\udb92\udd19\ud9f9\udcac\ud990\ude3c\ud8f0\udc99\udab8\uddcf",
        55, 76418, -19335385, -3611707873586268092L, 96032L, false, false, (char) 3269, (char) 23941,
        Double.longBitsToDouble(0x3fd19e6ad66ee2b8L), Double.longBitsToDouble(0x3fe803c6e35a4573L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\ud9a9\udf7a", "\u68d0\u4fab", "\udbc2\ude80\udab0\udfc2\udb77\udc57\uda9b\udd0f\ud85e\udf32\ud9b7\uddb6\udb3f\udc5d\udb7e\udf7f\udb92\udd19\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udab8\uddcf",
        55, 76418, -19335352, -3611707873586268092L, -92595L, false, false, (char) 3269, (char) 22405,
        Double.longBitsToDouble(0x3fd19e61f66ee2b8L), Double.longBitsToDouble(0x3fe803c6e35a4573L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud837\udf7d\ud88b\uded4\ud937\udd6f\udb83\udde2\ud8ba\udf67\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\ud9a3\udc7a\ud8e5\udc32\ud8bc\udd2c\ud90c\udcf4\uda94\udffd\ud933\udc8d\ud9c0\ude7b\udbc2\ude80\udab0\udfc2\udb77\udc57\uda9b\udd0f\ud85e\udf32\uda48\ude1a\udb3f\udc5d", "\u2f4c\u1a37\ubc97\ub567\u52d5\u075b\u45c9\u276b\ub790\u1be2\ub4e5\uc4be\u9211\u1771\u2f6c\ua3e8\u3f74\u5275\u1150", "\udb21\uddbe\udb95\udc50\ud82e\udff6\udba3\udc35\ud85e\udee1\ud87a\ude77\udbd4\uddf4\udab4\udc55\udb25\udd7a\ud8d0\udd76\uda00\udd34\uda56\udd5e\udad7\udc68\ud8c3\udfd1\ud9a9\udeb1\ud915\ude42\udb44\udee5\ud813\ude8c\ud805\udd74\ud846\udeba\ud899\udf24\udb6c\udeac\ud8eb\udfe9\ud93a\udda2\udbfe\udcb2",
        37, 81841, -689147552, -3225138930934111371L, -6524L, true, true, (char) 22245, (char) 3060,
        Double.longBitsToDouble(0x3fec33bd3a9f8b35L), Double.longBitsToDouble(0x3fde7abe7f15f502L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud829\udd75\016\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\020\000\ud959\udd9e\ud9a3\udc7a", "\u68d0\u4fab", "\udbc2\ude80\udab0\udfc2\udb77\udc57\uda9b\udd0f\ucf5a\uda48\ude1a\000\udb7e\udf7f\udb7e\udd19\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udbe9\udd67",
        0, 98626, -33554432, -3611707874029338624L, 96032L, false, false, (char) 3269, (char) 23941,
        Double.longBitsToDouble(0x3fd19e6ad66ee2b8L), Double.longBitsToDouble(0x3fe803c000004573L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 1, "\ud829\ude69\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\uda76\udc03", "\u68d0\u4fab\u5933\u6b78\u35ce\u0455", "\ud85e\udf32\uda48\ude1a\udb3f\udc5d\udb7e\udf7f\udb92\udd19",
        -2, 2776, -1294136310, -4376507748554850210L, 98873L, true, false, (char) 33611, (char) 7042,
        Double.longBitsToDouble(0x3fa4bb94215182a0L), Double.longBitsToDouble(0x3fdc008ff5b174ecL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 1, 0, "\ud84b\udf14\ud90a\udece\ud937\udd6f\udba7\udea1\ud913\udc49\ud987\udcb0\ud9ba\udeac\ud9dd\udd6d\udb87\udc44\udaad\udda8\uda70\udee5", "\u8881\ua17a\u5933\u6b78\u35ce\u15d2\u5702", "\uda48\ude1a\udb3f\udc5d",
        21, 22691, -1648774202, -6925259523391405610L, 11467L, false, true, (char) 53714, (char) 59526,
        Double.longBitsToDouble(0x3fb10f4ff540d340L), Double.longBitsToDouble(0x3fd29772862a3110L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uf1c8\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac", "\u21bf\u1c99\u704d\u3902\u68d0\u4fab\u5933\u6b78\u35ce\u0455\036\u1e65\u6ee3\u15b0\u5410\u16fe\ub1bd", "\ud8eb\udf7e\udab8\uddcf\uda33\udce4\udb1c\udd66\uda5b\udf15\udb3f\udfde",
        42, 48568, 406796329, 648327120345824704L, -36579L, true, false, (char) 41160, (char) 32542,
        Double.longBitsToDouble(0x3fd907f5644e6580L), Double.longBitsToDouble(0x3fc0257463756094L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8bb\udc05\ud84d\ude33\udbbe\uddcd\uda2d\ude41\udb75\udea9\ud885\udde5\udb59\ude28\uda49\udfc5\ud8bc\udd33\ud942\udcf4\uda58\udfff", "\u35ce\ub2e1\u1b0e\u1264\u6ee3\u3f2c\u1dac\u95ce\uc124\u2f4c\u1a37\ua89d\uc464", "\udab5\udd7b\ud8f4\udea2\ud98c\uddd2\udb93\udc20\udb89\udfe3\ud92a\udd1f\udbcc\udda6\u7444\u23bb\udbe1\udedd\ud8bf\udfc7",
        55, 43672, 1499114330, -2457694896802625537L, -68601L, false, true, (char) 23545, (char) 33179,
        Double.longBitsToDouble(0x3fe2d4bd186e4b91L), Double.longBitsToDouble(0x3fea0e4c6fdc39e6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\ub464", "",
        0, 35776, -117440293, 334461918821L, -100000L, false, false, (char) 18428, (char) 50577,
        Double.longBitsToDouble(0x3f835dc82bacaf80L), Double.longBitsToDouble(0x3f49436d3f540000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 1, 1, "\ud829\udd75\016\000\udba7\udea1\ud8ba\udffe\ud9cf\uddc6\ud9ba\udeac\ud9dd\udd6d\udb48\udc7e\ud9eb\udd55\000", "\u1672", "\ud9c0\ude7b",
        14, 40182, 232403836, 4317679126312491991L, -100000L, false, false, (char) 20539, (char) 48129,
        Double.longBitsToDouble(0x3fc103d720000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud9ae\udd6b\u009f\000\ud9fd\ude2b\ud91e\udebd\udbf9\udd25\ud9a4\ude66\ud962\udd6b\ud9a3\udc7a", "\u68d0\u47fc", "\uda61\uddaf",
        50, -1000, 0, -8770460895342829435L, 99200L, true, false, (char) 49803, (char) 9953,
        Double.longBitsToDouble(0x3f846049592cb740L), Double.longBitsToDouble(0x3fc2b8686e681518L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\ud8ba\udffe",
        27, 20336, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud829\udd75\016\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\020\000\ud959\udd9e\ud8fd\udfc7", "\u68d0\u4fab", "\udbc2\ude80\udab0\udfc2\udb77\udc57\udb64\udd93\ud828\udcaa\uda48\ude1a\000\udb7e\udf7f\udb80\udeda\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udbe9\udd67",
        0, 98626, -33554432, -3611707874029338624L, 96032L, false, false, (char) 3269, (char) 23941,
        Double.longBitsToDouble(0x3fd19e6ad66ee2b8L), Double.longBitsToDouble(0x3f3e0000022b9800L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud829\udd75\016\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud999\uddb0\000\ud959\udd9e\ud9a3\udc7a", "\uaa4b\uc608", "\udbc2\ude85\udab0\udfc2\udb77\udc57\uda9b\udd0f\ucf5a\uda48\ude1a\000\udb7e\udf7f\udb7e\udd19\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udbe9\udd67\u8210\udabc\udcee\ud90f\udf47\udb3f\udfde\000\udaad\udd05\udb2a\udd96\udae4\ude9c\udbcc\udda6\u7444\uda39\udc61\udbdc\udc6d\ud8bf\udfc7\ud96c\ude49\udb00\udf17\udbf0\udc98\udb79\uddbc\u7ddd\udaf9\udf5b\ud936\ude4e\udb63\udd46\udafe\udf07\uda9c\udf7f\ud8d9\udcb9\ud8e4\udc3a\ud874\udf3d\ud929\udf31\udbe3\udfa8\udb23\udf2e\ud8b7\udcfe\udaaa\udf3a\u5ca8\udba6\udc79\ud917\udeec\ud8ad\udfb6\ud95e\udf20\ud8db\uddee\udb3f\udd35\udb91\udd4e\uda4a\udcbb\udb33\udfbd\udb9f\udc99\ud832\uddf7\ud8f1\ude65\uda1b\udf1e\ud58c\udaa2\ude42\uda5e\udfe1\ud8e9\udc98\ud9df\udd69",
        45, 15428, -1992054136, -1487456401246720724L, 91149L, false, true, (char) 20649, (char) 62276,
        Double.longBitsToDouble(0x3fb0b96bb7a398e8L), Double.longBitsToDouble(0x3fdd13f7ac9502fcL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud829\ude69\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud8b4\udc5a\uda0e\udc40", "\u68d0\u4fab\u5933\u6b78\u35ce\u0455\036\u1e65\u6ee3\u15b0\u5410\u16fe\ub1bd", "\ud8eb\udf7e\udab8\uddcf\ud9dd\udf94\udb1c\udd66\uda5b\udf15\udb3f\udfde",
        20, 48568, 407336489, 648327120345824704L, -74263L, false, false, (char) 21591, (char) 60411,
        Double.longBitsToDouble(0x3f8f644f86612880L), Double.longBitsToDouble(0x3faa6fc0c35f9100L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d\udb7a\udf7e\ud959\uddec\ud9a3\udc7a", "\u68d0\u4fab", "\udbc2\ude80\udab0\udfc2\udb77\udc57\udbc3\udf52\ud85e\udedf\uda48\ude1a\udb3f\udc5d\udb7e\udf7f\udb92\udd19\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udab8\uddcf",
        55, 76418, -19335385, -3611707873586268092L, 96032L, false, false, (char) 3269, (char) 23941,
        Double.longBitsToDouble(0x3fd19e6ad66ee2b8L), Double.longBitsToDouble(0x3fe803c6e35a4573L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud829\udd75\016\ud937\udd6f\udba7\udea1\ud8ba\udffe\ud9fd\udfec\ud9ba\udeac\020\000\ud959\udd9e\udba3\udfb2", "\u68d0\u4fab\u5933\u6b78\u35ce\u0455\036\u9939\u5447\u15b0\000\u16fe\u6b7e\u2f4c\u1a37\ua89d\u05b4\u0ded\u9c64\u25a1\u276b\000\u1b3a\ub4e5\uc4be\u1b56\u1771\u2f6c\ua3e8\u3f74\u8970\ua250\ua76e\u3221\u603f\u5216\u9076\ua078\ua534\u2f5c\uaa3b\u5b26\u09d5\ub33b\u4d78\u1423\u00f4\u57f2\u51da\u2ab2\u7a00\u278a\uab99", "\uda79\udd39\uda5d\udc92\ud984\udcf7\uda17\udf0a\ud813\udce8\udab5\udca1\udb56\uddd2\ud935\udd25\ud821\ude6f\ud938\udc4b\uda9b\ude2b\ud9b5\udf53\ud9ab\udeea\udaaa\udd80\udad9\udc66\ud8ef\udfac\uda51\udc59\uda28\udf78\udbbd\udef6\udb34\uddc4\uda38\udfc3\udb3f\udf86\ud8df\udfa4\udb25\udc34\u733e\udb2a\udeb6\uda38\udd5d\udbac\udd85\uda78\udd58\uda22\udc32\ud848\udc93\udb04\uddf2\ud853\udc90\ud872\ude5b\udbb1\udd3a\ud922\udf91\u083c\ud83b\udf7a\uda6f\ude48\ud958\udca1\ud89b\udedf\ud858\udc53\ud8ef\udef6\ud908\udede\ud90c\udf6a\ud842\udfe0\ud808\udce2\ud893\uddf2\ud8a3\udca2\ud956\ude3c\ud9f3\ude0e\ud88e\udd0a\ud827\udc7e\uda28\udd35\uda41\udd32\udb70\udcbd\ud940\udf15\udbdf\udc8f\ud9c2\udece\ud94b\ude16\udbfa\udd99\udba6\udc3e\udbd2\udd8e\udb7a\udc38\ud8b4\uddac\ud826\ude4f\ud9e4\udcee\udaf6\udfcc",
        9, 37078, -911844164, -846134773623604549L, 54214L, true, true, (char) 49449, (char) 9539,
        Double.longBitsToDouble(0x3fe453e1db87dd4cL), Double.longBitsToDouble(0x3fef1beb3a95bbcbL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 1, "\ud829\ude69\ud88b\udec3\ud937\udd6f\ud820\udffe\ud8cf\uddff\ud84d\ude33\ud9ba\udeac\ud9dd\udd6d", "\ucef7\u44cb\u25be\u5856\u4fab\u5933\u6b78", "\udb77\udc57\uda9b\udd0f\ud85e\udf32\uda48\ude1a\udaa1\udd0e\ud8ef\udfdf\ud862\udd39\ud95c\ude75",
        46, 76690, -2039195804, -962432911017309286L, 54405L, false, false, (char) 35596, (char) 10505,
        Double.longBitsToDouble(0x3fd733ec26eb5b8eL), Double.longBitsToDouble(0x3fde431d0d5571e2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud829\udd75\016\ud937\udd6f\ud9da\udd8b\udbe9\udc23\ud949\udc12\ud9ba\udeac\020\000\ud959\udd9e\udba3\udfb2\udb82\ude33\ud8af\udf6f\ud942\udcf4\uda94\udffd\ud9f8\udf50\ud9c0\ude7b\udbc2\ude80\udab0\udfc2\udb77\udc57\udb64\udd93\ud828\udcaa\uda48\ude1a\udb19\udf2c\udb41\ude43\udb80\udeda\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udbe9\udd67\ud998\udc4b\ud818\udfa4\udb43\udfe1\udb3f\udfde\000\udaad\udd05\udb2a\udd96\udae4\ude9c\udbcc\udda6\u7444\uda39\udc61\udbdc\udc6d\ud8bf\udfc7\ud96c\ude49\udb25\udc17\ud8e3\uddf0\udabd\ude3c\u71bd\ud85c\udc80\ud877\udc0a\ud827\udf99\udb02\udfce\ud8b5\udd9a\udb54\udd13\ud826\udcf9\udade\udc2a\udb8d\ude1a\ud8b4\udf76\ud988\udc84\uda8b\uddb3\uda4e\udd77\udb07\udfcd", "\u278a\uab99", "\uda79\udd39\uda5d\udc92\ud984\udcf7\uda17\udf0a\ud813\udce8\udab5\udca1\udb56\uddd2\ud935\udd25\ud821\ude6f\ud938\udc4b\uda9b\ude2b\ud9b5\udf53\ud9ab\udeea\udaaa\udd80\udad9\udc66\ud8ef\udfac\uda51\udc59\uda28\udf78\udbbd\udef6\udb34\uddc4\uda38\udfc3\udb3f\udf86\ud8df\udfa4\udb25\udc34\u733e\udb2a\udeb6\uda38\udd5d\udbac\udd85\uda78\udd58\uda22\udc32\ud848\udc93\udb04\uddf2\ud853\udc90\ud872\ude5b\udbb1\udd3a\ud922\udf91\u083c\ud83b\udf7a\uda6f\ude48\udafd\udfb3\ud818\ude49\ud87e\udc4d\ud8ef\udef6\ud908\udede\ud90c\udf6a\ud842\udfe0\ud808\udce2\udb3e\ude7a\ud8a3\udc49\ud956\ude3c\ud9f3\ude0e\ud88e\udd0a\ud827\udc7e\uda28\udd35\uda41\udd32\udb70\udcbd\ud940\udf15\udbdf\udc8f\ud9c2\udece\ud94b\ude16\udbfa\udd99\udba6\udc3e\udbd2\udd8e\udb7a\udc38\ud8b4\uddac\ud826\ude4f\ud9e4\udcee\udaf6\udfcc",
        9, 37078, -911844164, -846134773623604549L, 54214L, true, true, (char) 9975, (char) 9539,
        Double.longBitsToDouble(0x3fe453e1db87dd4cL), Double.longBitsToDouble(0x3fef1beb3a95bbcbL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud829\udd75\016\ud937\udd6f\ud9da\udd8b\udbe9\udc23\ud949\udc12\ud9ba\udeac\u00de\000\ud959\udd9e\udba3\udfb2\udb82\ude33\ud8af\udf6f\ud942\udcf4\uda94\udffd\ud9f8\udf50\ud9c0\ude7b\udbc2\ude80\udab0\udfc2\udb77\udc57\udb64\udd93\ud828\udcaa\uda48\ude1a\udb19\udf2c\ud84f\ude4a\udb80\udeda\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udbe9\udd67\ud998\udc4b\ud818\udfa4\udb43\udfe1\udb3f\udfde\000\udaad\udd05\udb2a\udd96\udae4\ude9c\udbcc\udda6\u7444\uda39\udc61\udbdc\udc6d\ud8bf\udfc7\uda39\udc11\ud985\ude79\ud8e3\ude64\udabd\ude3c\u71bd\ud85c\udc80\ud877\udc0a\ud827\udf99\udb02\udfce\ud8b5\udd9a\udb54\udd13\ud826\udcf9\udade\udc2a\udb8d\ude1a\ud8b4\udf76\ud988\udc84\uda77\udcdf\uda4e\udd77\udb07\udfcd", "\u278a\uab99", "\uda79\udd39\uda5d\udc92\ud984\udcf7\uda17\udf0a\ud813\udce8\udab5\udca1\udb56\uddd2\ud935\udd25\ud821\ude6f\ud938\udc4b\uda9b\ude2b\ud9b5\udf53\ud9ab\udeea\udaaa\udd80\udad9\udc66\udbf1\udfad\uda51\udc59\uda28\udf78\udaff\uddfb\udb34\uddc4\uda38\udfc3\udb3f\udf86\ud8df\udfa4\udb25\udc34\u733e\udb2a\udeb6\uda38\udd5d\udbac\udd85\uda78\udd58\uda22\udc32\ud848\udc93\udb04\uddf2\ud853\udc90\ud872\ude5b\udbb1\udd3a\ud922\udf91\u083c\ud83b\udf7a\uda6f\ude48\udafd\udfb3\ud818\ude49\ud87e\udc4d\ud8ef\udef6\ud908\udede\ud90c\udf6a\ud842\udfe0\ud808\udce2\udb3e\ude7a\ud8a3\udc49\ud956\ude3c\ud9f3\ude0e\ud88e\udd0a\ud86e\udeab\ud8f6\udcab\uda3e\udd15\udb70\udcbd\ud940\udf15\udbdf\udc8f\ud9c2\udece\ud94b\ude16\udbfa\udd99\udba6\udc3e\udbd2\udd8e\udb7a\udc38\ud8b4\uddac\ud826\ude4f\ud9e4\udcee\udaf6\udfcc\udadc\udd1f\ud953\udedc\ub988\udb59\udc36\udb9d\udf81\ud8fc\udc2e\uda81\udc84\ud80f\ude09\ud812\udfaa\ud8b7\udf7d",
        25, -217, -1144319005, 5574808266454345901L, -2416L, true, true, (char) 57093, (char) 9571,
        Double.longBitsToDouble(0x3fa5d0f92a3dbcf0L), Double.longBitsToDouble(0x3fe48203ef735495L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 1, 1, "\uc9b1&\000\ud9cb\uddd2\ud91b\udcaa\ud80a\udcf9\ud9ba\udedd\ud9dd\udd6d\uda17\udc45\uda44\udcdb\000", "\ub285", "\ud9c0\ude7b\udbc2\ude80\udaab\udfe0\udabb\ude6b\udbef\uddd1\ud963\udf14\udb96\uddeb\000\000\ud8b5\udfca\uda01\udfce",
        1, -1000, 0, 5925329735993556522L, 21646L, true, false, (char) 52192, (char) 1755,
        Double.longBitsToDouble(0x3fece3fea9be114cL), Double.longBitsToDouble(0x3fee02dac558dab4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 1, 1, "\uc9b1&\000", "\u35f2", "\uda17\udc45\udb79\uddd5\ud928\udf6c5\ud8bc\udc4b\ud82e\udd0a\udb37\udfc3\ud933\udc8d\ud9c0\ude7b\udbc2\ude80\udb4b\udc0f\udab9\udd12\udbef\uddd1\ud963\udf14\udb96\uddeb\000\000\ud8b5\udfca\uda01\udfce",
        1, -1000, 0, 7366481616752115287L, 21646L, true, false, (char) 52192, (char) 1755,
        Double.longBitsToDouble(0x3fc5affaa6f84530L), Double.longBitsToDouble(0x3fee02dac558dab4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 1, "\uc9b1&\000", "\ucf3c", "\uda17\udc45\udb79\uddd5\ud928\udf6c5\ud8bc\udc4b\ud82e\udd0a\udb37\udfc3\ud953\ude9d\uda89\udd6a\udbbf\udd78\udb4b\udc0f\udab9\udd12\udbef\uddd1\ud963\udf14\udb96\uddeb\000\uda47\udf04\ud826\udea9\uda01\udfce",
        1, -1000, 0, 7366481616752115203L, 21646L, true, false, (char) 52192, (char) 5851,
        Double.longBitsToDouble(0x3fb8985a4df08a60L), Double.longBitsToDouble(0x3fcf182b15636ad0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 1, "\uc97d&\000\ud9cb\uddd2\ud812\udc05\udb9c\ude59\ud9ba\udedd\udac6\ude6b\uda17\udc45\udb79\uddd5\ud928\udf6c5\ud8bc\udc4b\ud82e\udd0a\udb37\udfc3\ud953\ude9d\uda89\udd6a", "\ud12f\u614e\u1cff\u85c0\000\u9194\ud66e\uca2f", "\000",
        1, 86027, -2119907308, 6259481018541188669L, -34032L, false, false, (char) 62217, (char) 26192,
        Double.longBitsToDouble(0x3fd58dab4f78f176L), Double.longBitsToDouble(0x3fdd347f150b4746L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud829\udd75\ud88b\udec3\ud937\udd6f\udba7\udea1\ud8ba\udffe\udb07\ude70\ud90b\udee1\ud9d9\ude00\udb7a\udf7e\ud959\uddec\ud9a3\udc7a", "\u68d0\u4fab", "\udbc2\ude80\udab0\udfc2\udb77\udc57\uda9b\udd0f\ud85e\udf32\uda48\ude1a\udb3f\udc5d\udb7e\udf7f\udb92\udd19\ud957\uddfb\ud910\udffe\ud8eb\udf7e\udab8\uddcf",
        55, 76418, -19335385, -3611707873586268092L, 96032L, false, false, (char) 3269, (char) 23941,
        Double.longBitsToDouble(0x3fd19e6ad66ee2b8L), Double.longBitsToDouble(0x3fe803c6e35a4573L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.NumericEntityUnescaper:",
    "C|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|<init>|",
    "M|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.NumericEntityUnescaper:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
