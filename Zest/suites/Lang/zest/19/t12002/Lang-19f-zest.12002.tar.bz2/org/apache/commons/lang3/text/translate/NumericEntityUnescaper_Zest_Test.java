package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumericEntityUnescaper_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\ud9ff\ude53\ue0e4\ud998\udf93\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud903\udd7d\udb25\udc8a\udac5\udc9e\ud934\udf7b\ud84f\udd68\uda40\udd6c\ud89f\udfb3\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\udb58\udf04\ud926\udd6a\ud9dc\ude9c", "\u0bf1\uab96\u8dff\u7cc0\u5145\u4047\u6d72\u6998\u1ad7", "\ud99e\udee9",
        8, 24595, -1165600527, 4313452922448015852L, -1365L, false, false, (char) 46601, (char) 65132,
        Double.longBitsToDouble(0x3f7b2307883d1f00L), Double.longBitsToDouble(0x3fed1977fb7ff31cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud906\udd21\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\ud9ff\ude53\ue0e4\ud998\udf93\uda8a\uddaa\ud882\uddb2\ud833\udf8f\uda88\uded1\ud9c5\udc74\udac5\udc9e\ud934\udf7b\ud84f\udd68\uda40\udd6c\ud89f\udfb3\ud920\udda3\ud82a\udebb\uda9a\udd2e\ud939\udce7\udb4c\udfc6\ud862\udd4c\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\udb58\udf04\ud926\udd6a\ud9dc\ude9c", "\u0bf1\u98e0\u8dff\u7cc0\u5145\u4047\ua94c\u6974\u7bd6", "\ud99e\udee9",
        48, 90107, 1395451380, 2158896927892488843L, -1365L, false, false, (char) 22026, (char) 65132,
        Double.longBitsToDouble(0x3f7b2307883d1f00L), Double.longBitsToDouble(0x3febf297fb7ff31cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\u6d75\uda56\udf5c\udbaa\udc32\ud8ee\udc34\udb44\udec4\ud8d6\udce9\ud8c0\udd95\ud8f6\udf10\udb36\udf41\ud9c2\udf61\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\ud8c8\udc2b\ue0e4\ud998\udf93\udaf2\udc5e\uda9d\ude71\ud90e\udd53\ud903\udd7d\udb25\udd39\ud8e8\udf70\ud934\udf7b\udad7\udfb6\uda7a\udfcc\ud978\udf11\ud920\udda8\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\uda25\ude8a\udbd1\udc76", "\u23ff", "\uc3a5\ud945\udf2f\ud8c1\ude67\ud953\udf9c\ud994\udcd9\ud90d\udf1b\udb8a\ude94\u87b2\u119a\ud99e\ude1a\ud959\udf5a\uda90\udddd\udb65\udcd8\ud82e\ude1b\u2e83\uda60\udcd2\uda0c\udc4b\ud83f\udd92\ud8d4\udf87\udb86\udfee\ud9d4\udfac\ud821\udff3\ud936\udd7c",
        25, 53288, 617186918, -4742073097396483351L, 74155L, false, true, (char) 13939, (char) 61222,
        Double.longBitsToDouble(0x3fe8b100ad649c3cL), Double.longBitsToDouble(0x3fc8b97305c3950cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\ud9ec\udc33\uda56\udfb1\udbaa\udc32\udaeb\udcf3\ud920\udd3e\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc66\ud876\udfae\udbfc\udcd0\ud8cf\udf45\uda0a\udd15\udb3a\udffb\uda6f\ude1e\udbd6\ude08\uda8a\uddaa\udb98\udf7b\ud876\ude42\ud9b6\udccd\ud974\uddcb\ud893\udf01\ud934\udf7b\ud84f\udd68\uda40\udd6c\ud89f\udfb3\ud920\udda3\ud82a\udebb\udaa1\ude2e\ud942\udc45\ud8fb\udfc3\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udaf1\udf26\udb58\udf04\ud926\udd6a\ud9dc\ude9c", "\u0bf1\uab96\u8dff\u7cc0\u5145\u93f4\uc7bd\u37b7\u1ad7", "\ud984\udd5d",
        10, -61, -1165600527, 4313452922448014572L, 68195L, true, true, (char) 47047, (char) 43267,
        Double.longBitsToDouble(0x3fd7c05a06ffe638L), Double.longBitsToDouble(0x3fc1f294e4ce02e0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6", "\ud78c\u79e8\u1a9a\u5905\u0c3f\u2f49\u8e7c\u18f5\uce89\u7361\u90e0\u5f27\u411f\ua7ce\u8a9b\ud45f\uab27\u744b\ua10b)\u1024\ud13c\ub3e3\u7ba9\u5985\u68cc\u3773\u3309", "\ud9ff\udfb6\ud8ec\uddc2\udbf9\udd21\udb88\udef6\ud953\udf9c\ud994\udcd9",
        42, 80036, -2075074820, 3614088880753661430L, -88805L, true, false, (char) 12571, (char) 44488,
        Double.longBitsToDouble(0x3fcfc9bc5ad7d600L), Double.longBitsToDouble(0x3fe64499968a477fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\udaa6\udd03\ud8d6\udce9\udb0b\udd5a\udbef\ude0d\ud856\ude5b\ud8f0\udc06\ud8fe\udc85\ud895\udc1e\u365b\uda60\udfe6\udbe2\udd39\ud9ff\ude53\ue0e4\ud998\udf93\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud903\udd7d\udb40\udc8e\udac5\udc9e\ud934\udf7b\ud84f\udd68\ud9e4\udefd\ud89f\udfb3\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\ud862\ude1d\ud8ce\udfeb\ud87f\udc8a\udade\udfc9\ud95c\udd3b\udb4c\uddc1\udb95\udc88\udb58\udf04\ud926\udd6a\ud9dc\ude9c", "\u5ea3\uab96\u8dff\u7cc0\u5845\u8212\u6d72\u6998\u1ad7", "\ud8e8\udf4f",
        51, 73212, 1422749681, 4313538886218445292L, -1365L, false, false, (char) 46601, (char) 65132,
        Double.longBitsToDouble(0x3f791307c4239f00L), Double.longBitsToDouble(0x3fed1f443b7ff31cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\uda85\udf29\udab0\uddd2\ud8fe\udc85\ud876\udfae\udbe4\udc5a\ud8a8\udded\udbe2\udd60\ud9ff\ude53\ue0e4\ud9a8\udd93\uda8a\uddaa\udb98\udf7b\ud843\ude42\udbdc\udda9\udb25\udc9a\udac5\udc9e\ud934\udf7b\ud84f\udd68\uda40\udd6c\ud89f\udfb3\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\udb58\udf04\ud926\udd6a\ud9dc\ude9c", "\u904b\uab96\u8dff\u7cc0\u5145\u4047\u6d72\u6998\u1ad7\u8c64\ub621\u0988\u9298\u063b\u4699\u8d86\u263b\u688c\ub5c0\u2385\u6344\u9bf4\u8ce8\u16c4\ucc5c", "\ud8dc\udc3d\ud807\udc54\udb1e\ude19\udafc\udc03",
        32, 42957, -1511825898, 9108750541692030945L, 55178L, true, true, (char) 55765, (char) 27295,
        Double.longBitsToDouble(0x3fe7782bbdf7d763L), Double.longBitsToDouble(0x3fe342ed7bc712fcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\u1522\ud8bc\udeeb\uda02\ude11\udaeb\udcf3\ud920\udd00\ud8c2\uddbe\udbd1\udc49\ud8ff\udf37\udae2\ude67\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\ud9ff\ude53\ud8f8\ude05\ud98f\udc46\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud997\udde7\ud813\udc56\udac5\udc9e\ud934\udf7b\ud84f\udd68\uda40\udd6c\ud89f\udfb3\ud920\udda3\udb81\uded1\ud93f\udc39\u8e54\ud90c\udc5c\udb16\udf5e\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\uda8d\ude04\ud878\ude4c\ud953\udcea\udb9b\udce2\ud93a\udcee", "\u0bf1\uab96\ubd67\u38c7\u5145\u4047\u6d72\u6998\ud0f5", "\ud972\udde1\ud959\udf5a\uda90\udddd\udb65\udcd8\udae0\udf4d\u2e5e\uda55\udc5f\uda0c\udc4b\uda80\udefe\udb65\udd2e\uda02\ude2d\ud8d6\udf3a\uf1d5\uda38\udee0\ud8d9\udc99\ud900\udce2\ud95e\udc64\uda36\udf73\ud80e\udee2\udbcc\udcde\ud9a9\uddaa\uda00\udf76\uda68\udf74\ud8e8\udda6\ud95a\udd9d\uda58\udf9e\ud8ce\udf5a\uda0b\udd66",
        26, 42799, -560617453, -5659577355071955088L, -92801L, true, true, (char) 42418, (char) 61571,
        Double.longBitsToDouble(0x3fe171947bdb4701L), Double.longBitsToDouble(0x3fce20efaa42f160L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\udbf9\ude50\ue0e4\ud998\udf93\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud903\udd7d\udb25\udc8a\udac5\udc9e\ud934\udf7b\ud84f\udd68\ud98b\udd90\ud88e\udd0b\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\udb58\udf04\ud926\udd6a", "\u2414\u0bf1\uab96\u8dff\u7cc0\u5145\u4047\u6d72", "\u87b2\uda9f\udda4\ud99e\udee9\ud959\udf5a\uda90\udddd\udb65\udcd8\ud82e\ude1b\u2e83\uda55\udc5f\uda0c\udc4b\uda80\udefe\udb65\udd2e",
        -1, 20622, 788512528, -928599541540353153L, 85705L, true, true, (char) 14773, (char) 50011,
        Double.longBitsToDouble(0x3fd1f9fd95c7179cL), Double.longBitsToDouble(0x3feec5bda6d158eaL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32", "\ucc35", "\uda76\udd4a\ud9c2\udf06\ud821\udd71\ud85b\udf7a",
        -4, 54836, 1294209643, -3465188474118231306L, 27339L, false, false, (char) 37134, (char) 51962,
        Double.longBitsToDouble(0x3fe26d9bb0359e48L), Double.longBitsToDouble(0x3fec12570ca1bbafL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud834\udcbe\udb0b\udd5b\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\ud9ff\ude53\ue0e4\ud998\udf93\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud903\udd7d\udb25\udc8a\ud853\ude45\ud934\udf54\ud84f\udd68\uda40\udd6c\ud89f\udfb3\ud920\udda3\ud82a\udebb\uda96\udf0d\udaa2\uddfb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\udb58\udf04\ud926\udd6a\uda3a\udeab", "\u0bf1\uab96\u8dff\u7cc0\u5145\u4047\u6d72\u6998\u1ad7\u8c64\ub621\u0988\u9298\u063b\u4699", "\uda55\udc5f\uda0c\udc4b\uda80\udefe\udb65\udd2e\uda02\ude2d\ud8d6\udf3a\uf1d5\uda38\udee0\udaf4\udfc7\ud9e8\udd8a\ud9ad\ude4c\udb1e\uddca\uda32\uddc5\uda0c\uddda\ud9ea\udf73\udb65\udff5\ud9b2\ude38\ud972\udd25\ud90f\udeaa\ud912\ude33\uda18\ude21\udbf7\ude16\ud9e2\ude8d\ud881\udfde\udbf9\udc64\udb68\uddf8\udab2\uddc4\ud88e\udede\udb7f\udf24\ud88f\ude3b\ud98b\udc20\ud9a7\udc28",
        12, 3222, 346692338, 2080292666825094003L, -32452L, true, false, (char) 64542, (char) 45385,
        Double.longBitsToDouble(0x3fe302ffada17f08L), Double.longBitsToDouble(0x3fea2da51a23ece4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\uda53\udd06\ud920\udd00\ud8d6\udce9\udb0b\udd5a", "\u7c6a\ud635\u19de\uafbb\u227f\u6274\u982a\ud78c", "\udb98\udf7b\ud843\ude42",
        45, 26021, 1256308789, -4922707614821579615L, 82093L, true, false, (char) 42606, (char) 37697,
        Double.longBitsToDouble(0x3fe9bb97546a2cdaL), Double.longBitsToDouble(0x3fcf484dfb5f9de8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 0, "\ud943\udd5f\ud811\udea2\ud9dd\uded4\uda27\uddf8\ud958\udde3\ud82f\udd2b\udb0b\udd82\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\ud9ff\ude53\ue0e4\ud956\uddcc\uda8a\uddaa\udb98\udf7b\ud843\ude42\uda3b\ude01\udb36\udc6b\udac5\udc9e\ud934\udf7b\uda4f\ude68\udb24\udfd1\ud89f\udfb3\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\udb58\udf04\ud926\udd6a\ud9dc\ude9c", "\u0bf1\ua770\u184b\u7cc0\u5145\u4047\u473d\u69d0\u1ad7", "\ud8e8\udf91",
        41, 35889, -1163803655, 4313452922435443692L, -1365L, false, false, (char) 46601, (char) 65132,
        Double.longBitsToDouble(0x3f7b2307883d1f00L), Double.longBitsToDouble(0x3fed1977fb7ff31cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 1, 0, "\udb8a\udf0b\uda56\udf5c\udbaa\udc32\uda3d\udcfc\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda58\udd41\udbe2\udd39\ud9ff\ude53\ue0e4\ud998\udf93\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud903\udd7d\ud943\udda6\udbb6\udf54\ud934\udf7b\ud84f\udd68\uda40\udd6c\ud89f\udfb3\ud920\udda3\ud82a\udebb\uda9a\udd2e\ud990\udda4\ud90c\udc54\ud862\ude1d\udac6\ude5e\udafb\udd02\ud83b\udfc2\uda53\udca9\udb1e\udee9\udb94\udfdf\udb58\udf04\ud926\udd6a\ud9dc\ude9c", "\u0bf1\uab96\u8dff\u7cc0\u5145\u4047\u6d72\u6998\u1ad7", "\ud99e\udee9",
        8, 24595, -1165600527, 4313452922448015852L, -1365L, false, false, (char) 46601, (char) 65132,
        Double.longBitsToDouble(0x3f7b2307883d1f00L), Double.longBitsToDouble(0x3fed1977fb7ff31cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\uda56\udf5c", "\uac36", "\ud8f6\ude97\ud88a\udd4c\ud9c2\udf06\ud8fe\udcfc",
        -3, 17317, -1927630164, -1456894229490325207L, -48559L, true, false, (char) 2248, (char) 37134,
        Double.longBitsToDouble(0x3fd834c119b4d392L), Double.longBitsToDouble(0x3faacf32f824ae10L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\u00a1\udbaa\udc32", "\ucb6c", "\ud88a\udd4c",
        -5, 45983, 0, -4518295643952775168L, 53303L, false, false, (char) 13791, (char) 39767,
        Double.longBitsToDouble(0x3f94328d00001560L), Double.longBitsToDouble(0x3fe00000024db376L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 0, 0, "\udb8a\udefe\uda56\udf5c\udbaa\udc32\ud867\udc91\ud94d\udcbb\ud8af\udfff\ud923\uded8\ud888\udd8c\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\ud9c8\udff9\ud818\udc8b\ud9ff\ude53\ue0e4\ud998\udf93\uda8a\uddaa\ud8dc\udc24\ud833\udf8f\uda88\uded1\ud9c5\udc74\ud9f5\udc96\ud934\udf7b\ud84f\udd68\udba2\udf7a\ud834\udeb2\udacf\udc4b\uda37\udc4d\udb74\udcc6\ud998\udd6b\udb89\udc82\uda4b\uddab\ud802\ude81\ud982\udd09\udade\udfc9\udb9d\udd05\uda4e\uddc0\udb95\udc88\udadc\udead\ud926\udcdb\ud9dc\ude9c", "\u1591\u75af\u00f6\u7cc0\u5145\u4047\u1198\u697d\ub20f", "\ud99e\udee9",
        43, 90107, 1395413492, 2158896925310304907L, -1365L, false, false, (char) 54241, (char) 64752,
        Double.longBitsToDouble(0x3fc36968fc41e8f8L), Double.longBitsToDouble(0x3febf297fb7ff31cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "", "", "\ud920\udd3e",
        51, 44256, 640864354, -8371927665575081121L, 67934L, true, false, (char) 26911, (char) 17395,
        Double.longBitsToDouble(0x3fd5300082af4ac0L), Double.longBitsToDouble(0x3fd8a511bd609894L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\udbf9\ude50\ue0e4\ud998\udf93\uda90\ude2e\udb98\udf7b\ud843\ude42\ud903\udd7d\udb25\udc8a\udac5\udc9e\ud934\udf7b\ud84f\udd68\ud98b\udd90\ud88e\udd0b\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\udb58\udf04\ud926\udd6a", "\u2414\u0bf1\uab96\u8dff\u7cc0\u5145\u4047\u6d72", "\u87b2\uda9f\udda4\ud99e\udee9\ud959\udf5a\udb70\ude2c\ud829\udce6\ud83b\udeeb\u2e83\uda55\udc5f\uda0c\udc4b\uda80\udefe\udb65\udd2e",
        51, 20622, 788512528, -928599541540353153L, 85705L, true, true, (char) 14773, (char) 50011,
        Double.longBitsToDouble(0x3fd1f9fd95c7179cL), Double.longBitsToDouble(0x3feec5bda6d158eaL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\uda30\udecb\udbc5\ude8c\ud998\udf93\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud903\udd7d\udb25\udc8a\ud866\udf8f\ud934\udf81\udbe6\uddb1\ud98b\udd90\ud88e\udd0b\ud8da\udd4d\ud916\udc21\uda9a\uddc3\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud871\udec2\udadf\udc1a\udb9d\udd05\udacd\udfa0\ud907\ude6b\udb58\ude91\ud926\udd6a", "\u2414\u0bf1\uab96\ub64b\u3e3b\u5145\u4047\u3cb8", "\u7a1a\uda9f\udda4",
        25, 11353, -530830405, -5006287954514250092L, -52584L, false, false, (char) 65132, (char) 29895,
        Double.longBitsToDouble(0x3feb0bd1f3a32effL), Double.longBitsToDouble(0x3fe89798e25a0be5L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\udbf9\ude50\ue0e4\ud998\udf93\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud903\udd7d\udb25\udc8a\ud961\ude9b\ud934\udf7b\ud84f\udd68\ud98b\udd90\ud88e\udd0b\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\udaa6\udda0\ud4b8\ud887\udffd\udade\udfc9\ud8d5\udd01\udb4c\uddbf\udb95\udc88\udb58\udf04\ud833\udf30", "\u2414\u0bf1\uab96\u8dff\u7cc0\u651e\u4059\u6d72\u6998\u1ad7\ua655\ub621\u0988\u9298\u063b", "\u2e83\uda55\udc5f\uda0c\udc4b\uda80\udefe\udb65\udd2e\ub3e3\ud8d6\udfa1\uf1d5\uda38\udee0\ud9cb\udc32",
        40, 77345, 287287289, -7509707755543254125L, 87013L, true, true, (char) 20194, (char) 56869,
        Double.longBitsToDouble(0x3fbfdde6b5e41fb0L), Double.longBitsToDouble(0x3fde08e917ce7472L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 1, 0, "\ud808\udc37", "\u2422\uac36\u606c\u6b0b\uc5a7\u9a70\u7c6a", "\u365b\ud8b0\udfee",
        24, 26561, -19961610, 5523444005908401840L, 36035L, false, false, (char) 24003, (char) 59517,
        Double.longBitsToDouble(0x3fef9128eca1bbafL), Double.longBitsToDouble(0x3fec142b9a54712cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 0, "\udb8a\udf0b\uda56\udf5c\udbaa\udc32\uda3d\udcfc\udad5\udf3b\u79e5\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udfa4\ud8fe\udc85\ud876\udfae\u5d00\ud827\udf08", "\ud78c\ucf3c\u1a9a\u5905\u0c3f", "\udbb6\udf54\ud934\udf7b\udb3a\udf5c\ud91a\ude19\ud962\udf56\ud920\udda3\ud82a\udebb\uda9a\udd2e\ud990\udda4\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud888\udc67\ud83b\udfc2\uda53\udca9\udb1e\udee9\udb94\udfdf\udb58\udf04\ud926\udd6a\ud9dc\ude9c",
        30, 56946, -542883253, -7408777271888914365L, -19013L, false, false, (char) 18424, (char) 5474,
        Double.longBitsToDouble(0x3fd44b6c2da91d28L), Double.longBitsToDouble(0x3fe5842285f63227L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "", "\u8fd8", "\uaa15",
        1, 51610, 974070863, 5293661269601059775L, -49398L, true, true, (char) 7864, (char) 44709,
        Double.longBitsToDouble(0x3fe5826253a90dd4L), Double.longBitsToDouble(0x3fd086a4ea8e0644L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 0, "\udb8a\udf03\uda56\udf5c\udbaa\udc32\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8cd\uddf8\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\uda9b\udc61\ud8d3\udcd9\ud998\udf93\uda8a\uddaa\udb98\udf7b\ud843\ude42\ud903\udd7d\udb25\udc8a\udac5\udc9e\ud934\udf7b\ud84f\udd68\uda40\udd6c\ud89f\udfb3\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udb95\udc88\udb58\udf04\ud926\udd6a\ud9dc\ude9c", "\u0bf1\uab96\u8dff\u7cc0\u5145\u4047\u6d72\u6998\u1ad7", "\ud99e\udee9",
        8, 24595, -1165600527, 4313452922448015852L, -1365L, false, false, (char) 46601, (char) 65132,
        Double.longBitsToDouble(0x3f7b2307883d1f00L), Double.longBitsToDouble(0x3fed1977fb7ff31cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 0, 0, "\udb8a\udf0b\uda56\udf5c\udbaa\udc32\uda3d\udcfc\udad5\udf3b\u79e5\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udfa4\ud8fe\udc85\ud876\udfae\u5d00\ua109", "\ud78c\ucf3c\u1a9a\u5905\u0c3f\u2f49\u3c3e\u7f90\uce89\u6c0d\u6e72\ub353\u411f\ua7ce\u8a9b\u93fd\u6809\u73da\ua10b\ua809\u54e0\u9605\uca67\u7b00\u5985\u68cc\u85ab\u3309\u2414\u0bf1\uba76\u8dfa\u7d00\u5145\u4047\u6d72\u6998\u1ad7\u8c3c\ub621\u96b4\u036d\ubbeb\ub753\u24cb\u860f", "\udaa5\udcf1\udbe2\udd08\udb0c\uddb9\u0f40\uda2c\udc62\udab5\udea4\ud80d\udd1e\udbe1\uddddw\ud87a\udf72\udaac\uddc7\ud844\udc5c\udb58\ude99\ud86f\udf43\ud89a\udd47\uda6e\ude2f\udb0a\udd47\udbd5\udef4\ud9d1\udc97\uda06\ude57\ud8ff\udc3a\uda56\udf27\ud818\udfeb\ud924\udfa9\ud917\udc43\ud9eb\udf13\udb75\udc42\ud969\udcc5\udaab\udf6d\udb1d\udf6e\udbc7\ude27\udbfe\udee5\ud9f2\udccf\ud8da\udf94\ud8f0\udced\ud996\udda0\ud8cb\uddfe\udaba\ude90\udade\udf33\uda38\ude22\uda82\ude0f\udb95\udfa4\uda08\ude3d\udb71\udfe6\ud85f\udd50\udb55\udded\udbe3\udf34\udbbb\udd26\udb2b\udfe0\udbe2\udc65\uda47\udde7\ud954\ude6b\udb75\udd98\udb55\udd4f\udbc8\udf30\ud981\udcfc\uda5f\udfc1\ud9dc\udd35\ud97d\udf1f\ud8cb\udd8c\uda0a\udd50\udb94\ude74\ud90c\ude25\ud8e6\udfff\ud80b\udf41\uda6e\uddc7\ud982\udcda\uf191\ud9a2\udd85\udb31\uded3\u33ce\ud828\udd3b\udaab\udded\ud87e\udc6b\uda36\ude93\udbd6\udcd3\ud8ba\udff9\ud880\udd8b",
        4, 59996, 655571881, 8872171095078065961L, -3971L, false, false, (char) 48879, (char) 49067,
        Double.longBitsToDouble(0x3fde62d5731c4960L), Double.longBitsToDouble(0x3fc843a84020aae0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb8a\udf03\ud84f\ude7b\udada\udcff\udaeb\udcf3\ud90c\udf00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\ud82a\udea6\udb8e\udf29\uda59\udf6b\ud999\udc1f\uda90\ude2e\udb98\udf7b\ud864\udd60\ud903\udd7d\udb25\udc8a\udac5\udc9e\ud934\udf7b\ud84f\udd68\ud98b\udd90\ud88e\udd0b\ud920\udda3\ud82a\udebb\uda9a\udd2e\udaa2\udddb\ud9f3\udf49\ud862\udd25\udac6\ude5e\u7875\udade\udfc9\udb9d\udd05\udb4c\uddbf\uda4a\udf22\udb58\udeb2\udb7f\udd76", "\u2414\u0bf1\uab96\u8dff\u7cc0\u5145\u4047\u886a", "\u87b2\ud814\udc7c\u0b41\ud951\ude7b\udb70\ude2c\ud8ad\uddf3\ud83b\udeeb\u2e83\uda55\udc5f\uda0c\udc4b\uda80\udefe\udb65\udd2e\uda8e\udd12\ud8d6\udf3a\uf1d5\ud9d7\udcb0\ud9cb\udc32\udb5e\udd3e\ud88b\udc33\ud930\udcfb\udac0\ude71\ud975\udde8\u8646\ufe9a\ud9b1\udd15\udaee\uddc0\ud917\udee1\ud831\udcc8\udbb6\ude43\udbc1\udea7\ud846\udf45\uda76\ude84\udb13\ude33\ud834\udfcd\ud97a\udcbb\uda08\uddf4\ud9bd\udfdb\ud914\ude2d\uda66\ude37\u67f9\uda2d\udd39\ud89a\uddb7\udbfa\udc5d\ud8bb\udc3e\udb93\udc31\udb7c\udf32\uda9e\udf92\uda73\udda6\ud989\ude29\udb83\ude8e\ud9e5\udd96\uda72\udd71\udb34\udc5c\ud828\udef0\uda2b\udd28\udac8\udcf6\uda44\udd57\ud8ec\uddf9\u091c\ud864\udd9a\udae8\udf7d\ud989\udc9f\ud853\udd6f\ud894\udfa4\ud83f\udfa5\udaa4\ude2a\ud9de\udeec\ua306\udbe3\udf0c\uda5e\udf36\ud91c\udf96\udb27\ude97\ud913\udc58\udad9\udff1\udb8d\udda8\ud933\udf52\u732b\ud96e\ude3e\uda62\udf59\ud995\ude6a\ud8a4\ude72\uda59\udf4b\ud998\udcc1\ud881\udfd5\ud993\udddd\uda58\udc40\ud950\udf42\ud8ce\udff3\ud9db\udd32\ud8db\udf99\udb02\udece",
        41, 42084, -1091504216, 7134826025107245600L, 94911L, false, true, (char) 20688, (char) 1951,
        Double.longBitsToDouble(0x3fb7f8e225c8d470L), Double.longBitsToDouble(0x3fd4e2b70dfc039cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb8a\udf03\udb56\ude1c\ud936\ude56\udaeb\udcf3\ud920\udd00\ud8d6\udce9\udb0b\udd5a\ud8f6\udea2\ud88a\udd4c\ud9c2\udf06\ud8fe\udc85\ud876\udfae\u365b\uda60\udfe6\udbe2\udd39\ud884\udf35\ue071\ud998\udf93\uda90\ude2e\udb98\udf7b\uda8c\udfeb\ud903\ude65\udb25\udc8a\udac5\udc9e\ud934\udf7b\ud84f\udd68\ud98b\udd9a\ud88e\udd0b\ud920\udda3\ud9df\udc60\uda9a\udd19\udaa2\udddb\ud90c\udc54\ud862\ude1d\udac6\ude5e\ud87f\udc8a\udade\udfc9\udb9d\udd05\udb4c\uddbf\udbdc\udef9\u6c1c\ud926\udd49", "\u2414\u56e8\uac2f\u8dff\uc557\ub74a\u4047\u6d72\u6998\u1ad7\u8c64\ub621\u0932\u9298\u6ae2\u1634\uc256\u263b\u688c\ub5c0\u2385\u6344", "\u7ba9\udb76\udc68\ud9be\udde0\udb5e\udd3e\ud88b\udc33\ud930\udcfb\udac0\ude71\ud975\udde8\u8646\ud915\udea0\ud9b1\udd15\udb25\udc3b\uda30\udc6e\udb5c\udeb8\udb75\udf6f\udadd\uddd6\uda52\ude04\uda78\udd1a\ud9ca\udc41\udaec\udfa3\udaa6\udcbb\ud878\udf04\uda4d\udd23\ud989\ude21\udaa8\udd7a\ud80b\udeca\udb8a\udfd3\ud80b\udf45\udbfd\ude55\ud91f\udedf\uda72\udd39\udb61\udfd0\udb4b\udedf\ud8cf\udf37\ud979\udf70\ud916\udc7d\u2c75\udbf0\udcfb\uda2e\udde8\ud8ce\ude67\udb13\udf09\ud832\ude53\udbbc\udeba\ud829\udc47\udb75\udf63\ud9cf\udd55\uda9b\udfe8\udbec\udf48\udae7\udfe8\ud9e7\udc6b\ud8fd\udfb7\ud986\udc42\udac5\udf32\ud995\udc77\udb9b\udfd6\ud9b5\udfb8\udb6c\udde1\udbaf\udeae\ud880\udc82\uda6a\udf33\udbc8\udc03\ud956\udc4f\udb06\ude1c\udb83\udcce\u8212\uda6e\ude59\udb7a\uddac\udafb\udcba\udbd6\udc37\uda0d\udfb8\ud969\udcd2\ud91a\udf8f\udb83\udc4c\udbbb\udf1a\udacc\udd1d\ud9cb\udc5e\udb82\uddd5\u0500\ud87c\udefb\uda25\udcc5\uda4e\udd42\ud997\udd87\udb28\uddaa\udb8a\udce2\udad1\ude12\ud88e\udc4e\uda69\ude18\ud9ea\udea4\uda7e\udff3\udb86\udeb7\udb66\udcba\udb3f\udfe5\ud8bf\udf5a\ud8f5\udf48\udabb\udffd\uda60\uddc3\udaf4\udf75\uda23\udcfc\ud9a1\udec2\udb60\udc39\ud950\ude3c\udb09\ude20\ud9ba\udf5c\ud809\ude8d\udad1\ude39\uda86\udce0\ud81b\udd33\ud8ac\udec4\ud96e\udc47\uda23\udee6\ud976\udf7a\uda05\udfcc\ud990\udc1b\ud8d3\uddb6\u9d5e\ud9d9\udec7\udb6a\ude37\uda0a\udd4e\ud9ee\udcf6\uda56\udc2d\ud9d8\udf50",
        3, 84007, 843133641, -6329136693392691394L, -513L, true, false, (char) 16442, (char) 59975,
        Double.longBitsToDouble(0x3fd2ea7efe8415deL), Double.longBitsToDouble(0x3fef4a1c79fb985eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.NumericEntityUnescaper:",
    "C|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|<init>|",
    "M|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.NumericEntityUnescaper:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
