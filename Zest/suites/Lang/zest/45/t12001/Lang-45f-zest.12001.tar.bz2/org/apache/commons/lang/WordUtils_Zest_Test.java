package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class WordUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\uda64\udefb\udb10\udec4\udb6d\ude41\udbfa\udc55\ud93d\udd5f\udac1\udd07\uda84\udeb7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda64", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\ua014\uda9c\udfdc\ud999\udf22\u9667");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ua014", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\udb2f\udd93\udbb5\udd89\ud90f\udd9f\udbfa\udc55\ud93d\udd5f\udabf\udd07\ud9da\udeb5\udb39\udf49\ud947\udf6c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb2f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\uda64\udefb\udb10\udec4\udb6d\ude41");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda64", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\ud8f7\udd21\udae8\udde3\u5733\ud947\udd4d\ud9e8\udf89\udaf8\uddaa\u2862\udb5c\ude47\ud878\udf5e\ud86f\udc4c\udbfa\udcf4\ud917\ude63\ud8e4\udfec\udbd6\udd3e\udb24\udc21\ud9ee\udf23\ud9e0\udf84\ud844\udd98\ufbd7\ud9bb\udd60\udaaa\udd90\udbf3\ude0c\ud980\udcc5\udb1c\udd93\uda22\udcb0\udb17\ude52\ud949\udcc1\udbb5\uddc3\ud98a\udfe2\ud997\udf5a\ud966\udfb9\ud83e\udcc2\udb2a\udebf\ud9ca\udf88\uda6a\udf64\ud8a6\udcb1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8f7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\u46c9\udae6\udec3\udb6d\ude41\udbfa\udc55\ud93d\udd5f\udac1\udd07\uda84\udeb7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u46c9\udae6\udec3\udb6d\ude41\udbfa\udc55\ud93d\udd5f\udac1\udd07\uda84\udeb7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalize("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\uda64\udefb\udb10\udec4\uda3a\udc46\udb2a\udcf6\ud92f\udd65\udac1\udd07\uda84\udeb7\ud830\uded3\udae9\udf78\udb5a\udf2f\ud9b8\udfcf\ud854\udf93\uda7e\ude5a\uda4b\udeec\udbb0\uddca\udb7b\udeda\ud837\uddf6\uda76\uddef\ud879\udfc3\ud857\ude04\ud837\udfcc\uda39\udc7e\ud859\udcc9\ud930\udfa4\ud952\udc3f\u6ce4\ud9e7\uddeb\uda38\udc17\ud95e\udd1a\udb68\udd4c\ud836\udf43\ud952\udfd9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda64", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud836\udf25\udb63\ude78\uda9d\ude11\ud9c6\ude09\ud97a\udf2a\ud8bf\udfad\u2129\ud914\udfa3\udb58\udfe1\ud859\udc3c\udb54\udfb9\udabd\udc7c\uda97\udcf0\uda5c\uddbc\udaa7\udda0\udaf3\ude72\uda8a\udc2d\uda7e\udd34\udbe2\udf88\uda20\udc3c\udbca\udcd9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud836\udf25\udb63\ude78\uda9d\ude11\ud9c6\ude09\ud97a\udf2a\ud8bf\udfad\u2129\ud914\udfa3\udb58\udfe1\ud859\udc3c\udb54\udfb9\udabd\udc7c\uda97\udcf0\uda5c\uddbc\udaa7\udda0\udaf3\ude72\uda8a\udc2d\uda7e\udd34\udbe2\udf88\uda20\udc3c\udbca\udcd9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\udb3e\udc37\udb23\udfaf\ud87c\udcb1\ud93e\udcd8\udb7e\ude2b\udbe4\udc38\ud880\ude3c\udbed\udd8d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb3e\udc37\udb23\udfaf\ud87c\udcb1\ud93e\udcd8\udb7e\ude2b\udbe4\udc38\ud880\ude3c\udbed\udd8d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\uda64\ude8d\udb10\udec4\udb6d\ude41");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda64\ude8d\udb10\udec4\udb6d\ude41", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\uda64\udefb");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda64", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud81a\udf3d\udb10\udec4\ud836\udce4\ud87d\udc98\udb2b\udf34\ud8b2\ude3f\uda84\udeb6\udbe8\udfc2\u128d\uda34\ude22\uda0e\udd44\ud8ab\udd6b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud81a\udf3d\udb10\udec4\ud836\udce4\ud87d\udc98\udb2b\udf34\ud8b2\ude3f\uda84\udeb6\udbe8\udfc2\u128d\uda34\ude22\uda0e\udd44\ud8ab\udd6b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud97a\ude1c\udbf9\udc19\u6963\udbde\udda2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud97a\ude1c\udbf9\udc19\u6963\udbde\udda2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalize("\ud85c\udf6e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud85c\udf6e", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\udb30\udd40\udb69\uded9\ud8db\udf2e\udb2d\udc71\ud8c2\udc9c\ud8d4\udf3f\udac5\uded7\ud869\uddeb\udb9b\udea9\ud92a\uded5\udbf7\udfd4\ud855\udca6\udac0\udf62\udb3d\ude7c\udb6c\udf4a\udb69\udf48\udb2e\udeef\ud8f1\udc1a\ud800\udf63\ud985\uddc2\ud8aa\udfe7\udaad\uddb0\uda26\udde4\ud9d4\udc34\udbbe\uddc1\ud8c1\udf09\udae8\ude56\ud869\udc7b\ud99f\ude41\uda2c\udcf1\uda92\udc85\ud9d3\udee6\ud96b\udde6\udb1f\uddc5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb30\udd40\udb69\uded9\ud8db\udf2e\udb2d\udc71\ud8c2\udc9c\ud8d4\udf3f\udac5\uded7\ud869\uddeb\udb9b\udea9\ud92a\uded5\udbf7\udfd4\ud855\udca6\udac0\udf62\udb3d\ude7c\udb6c\udf4a\udb69\udf48\udb2e\udeef\ud8f1\udc1a\ud800\udf63\ud985\uddc2\ud8aa\udfe7\udaad\uddb0\uda26\udde4\ud9d4\udc34\udbbe\uddc1\ud8c1\udf09\udae8\ude56\ud869\udc7b\ud99f\ude41\uda2c\udcf1\uda92\udc85\ud9d3\udee6\ud96b\udde6\udb1f\uddc5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud975\ude5b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud975\ude5b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\udae5\udd71\udbfe\udde7\udbca\udc1e\ud840\udf8d\ud851\udc9a\ud85c\ude3a\ud9ee\udf4a\udaf1\udd2b\ud90c\udff0\ud85e\udce2\uf08b\ud967\udc96\ud907\udd16\udbee\udfc6\udb94\udc04");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udae5\udd71\udbfe\udde7\udbca\udc1e\ud840\udf8d\ud851\udc9a\ud85c\ude3a\ud9ee\udf4a\udaf1\udd2b\ud90c\udff0\ud85e\udce2\uf08b\ud967\udc96\ud907\udd16\udbee\udfc6\udb94\udc04", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud933\udfd5\uda64\udfbe\ud8d4\udc8b\uda54\ude9c\udafc\ude2e\u10ea\ud9a8\ude01\ud818\udc73\u1ff3\ud86f\udd8a\udab3\udf02");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud933\udfd5\uda64\udfbe\ud8d4\udc8b\uda54\ude9c\udafc\ude2e\u10ea\ud9a8\ude01\ud818\udc73\u1ffc\ud86f\udd8a\udab3\udf02", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud8e1\udec4\udb91\ude8c\ud97a\udf13\ud917\ude1c\ud96f\udfed\udaa1\udc35\ud991\ude7d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8e1\udec4\udb91\ude8c\ud97a\udf13\ud917\ude1c\ud96f\udfed\udaa1\udc35\ud991\ude7d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalize("\uda64\udefb\udb10\udeae");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda64\udefb\udb10\udeae", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\uc5e0\uda62\udd83\udb6d\ude41\ud8e6\udcc0\ud90d\udc7c\uda39\udde3\ud838\ude1f\udbc4\udca7\uf74c\udabd\udce9\ud8bf\uddde\ud838\udf25\ud909\udccb\ud99e\udd82\uda4d\udc09\udb1f\ude97\udb95\uddc8\ud8b5\udfac\udb89\udf2f\ud945\udda2\uda0e\udcbe\ua3db\ud9b8\udea2\ud825\uddf7\ud815\ude16\udbac\udd10\udbf9\udc07\ud82c\udf55\u4a86\uda53\udcfd\ud88f\udce1\ud9f0\udc89\ud8e5\uddd6\udafa\udd41\ud8b1\udf61\uda4d\uddc7\ud8de\udf75\uda56\udd5b\ud8db\uddc3\ud855\udd56\ud9db\udc64\udb51\udf56\uda5f\udf13\ud9bc\udea5\udb3d\udde4\udbf0\udd70\udba6\udcb0\uda88\uddd4\ud8d9\udd4d\udaeb\udf98\ud83f\udc28\ud888\udcad\udb71\udf54\ud9a7\udf44\ud9ab\udca8\ud897\uddc5\udaaa\udd2e\uda3a\udca4\ud959\udd40\udadb\udd56\ud8f0\udce5\udad6\udda6\udbfe\udcaa\udabf\ude30\ud918\uddfb\ud834\ude88\ud978\udf2c\ud93d\udf64\ud9c6\uded6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uc5e0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\u1abc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u1abc", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\u7e1b\udae6\udec3\udb6d\ude41\udbfa\udc55\ud93d\udd5f\udac1\udd07\uda9b\udd41\uda8d\udc68\udac2\udc1c\udba2\udf62\ud9ed\ude99\ud946\udd02\uda35\udf71\uda5e\uddc3\ud946\udc6e\udae8\udef8\ud848\udff5\ud968\udf20\udbc8\uded4\udb48\udc20\ud8fb\udc1c\udaad\ude69\udbd2\udd14\udab5\udc47\ud95c\udf4c\ud980\ude0b\ud969\udfb6\ud82c\udc75\ud9be\udc6a\ud943\udf98\udb63\udd02\ud9ee\udc0a\udbdc\udd7c\ud981\udebd\ud817\udf87\udaa6\ude9f\udbff\udd03\ud8c1\udf51\udb93\udf63\udb36\ude49\udb84\udc8b\udbfc\ude34\udbbc\udc4e\ud9e4\udefd");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7e1b\udae6\udec3\udb6d\ude41\udbfa\udc55\ud93d\udd5f\udac1\udd07\uda9b\udd41\uda8d\udc68\udac2\udc1c\udba2\udf62\ud9ed\ude99\ud946\udd02\uda35\udf71\uda5e\uddc3\ud946\udc6e\udae8\udef8\ud848\udff5\ud968\udf20\udbc8\uded4\udb48\udc20\ud8fb\udc1c\udaad\ude69\udbd2\udd14\udab5\udc47\ud95c\udf4c\ud980\ude0b\ud969\udfb6\ud82c\udc75\ud9be\udc6a\ud943\udf98\udb63\udd02\ud9ee\udc0a\udbdc\udd7c\ud981\udebd\ud817\udf87\udaa6\ude9f\udbff\udd03\ud8c1\udf51\udb93\udf63\udb36\ude49\udb84\udc8b\udbfc\ude34\udbbc\udc4e\ud9e4\udefd", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\u7993\ud967\ude45\ud862\udd13\uda50\udc8b\ud93d\udd5f\udac1\udd07\uda84\udeb7\ud806\udec6\ud8d9\udf49\uda34\udc7c\ud959\ude30\ud9c2\ude41\ud837\udd49\ud9d6\udd5d\uda6b\udeb8\udb2a\udffe\udbe5\udc1f\ud8a7\udc76");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7993\ud967\ude45\ud862\udd13\uda50\udc8b\ud93d\udd5f\udac1\udd07\uda84\udeb7\ud806\udec6\ud8d9\udf49\uda34\udc7c\ud959\ude30\ud9c2\ude41\ud837\udd49\ud9d6\udd5d\uda6b\udeb8\udb2a\udffe\udbe5\udc1f\ud8a7\udc76", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials(" \000\000\uda06\udfa2\udb9b\udc2a\ud9ec\udfb2\udbe2\udcbb\ud959\ude45\uda62\udf1c\u2a61\udaaf\udc0d\udb14\udf5f\uda12\ude57\ud9ff\udf35\ud88c\udd2d\udb0e\udf6b\ud9a7\uddbd\ud964\udcc1\ud971\udf7b\ud9c3\udf4f\ud927\udefa\ud843\uded4\ud874\udc90");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalize("\036\ud8cd\ude8c\ud9ca\udd67\udaa1\udc36\ud971\ude00\ud91d\udc27\ud932\ude33\ud9ae\udd63\udad5\udc9b\udb54\udeaa\u7200\ud9d3\udfdb\udae9\udfb0\udbe4\udfad");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\036\ud8cd\ude8c\ud9ca\udd67\udaa1\udc36\ud971\ude00\ud91d\udc27\ud932\ude33\ud9ae\udd63\udad5\udc9b\udb54\udeaa\u7200\ud9d3\udfdb\udae9\udfb0\udbe4\udfad", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud86f\udf59\uda98\udd32\u10d5\uda2f\udfb9\ud8f3\udd6b\ud808\uddd2\udb6e\udd6d\ud91e\uddce\ua739\uda1a\udd25\u10c7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud86f\udf59\uda98\udd32\u10d5\uda2f\udfb9\ud8f3\udd6b\ud808\uddd2\udb6e\udd6d\ud91e\uddce\ua738\uda1a\udd25\u2d27", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud879\udcfa\ud922\udd6e\ud883\uded9\ud8cd\uded4\udb4e\ude67\udaa8\ude54\ud84f\uddb1\uda1c\udfd9\udbf0\udf64\udbe6\udea9\udb00\udc31\udbb2\udef8\uda7a\udd1d\udb96\udc1a\ud898\udc6c\ud9fb\udf3a\ud8a9\udc56\ud803\udca7\udac7\udd6e\udb84\udd9f\ud83b\udf1a\udb53\udc20\udbf0\udd93\ud9c9\udc53\udb7f\udcfe\ud986\uddfb\udb11\uded8\ud8e1\udfaa\uda43\udd83\ud968\uddfb\udba0\udc8c\udb9b\udc2f\ud8cb\ude18\ud833\uddff\ud9fd\udf6d\uda23\udc1d\ud9ed\udf55\uaab0\udaa9\uddce\ud85a\udf91\ud875\udeef\ud962\udc7e\ud984\ude66\udbd3\ude7d\ud9dc\uddfc\uda35\udfe2\uda8d\udc85\ub5c5\udb22\udc5a\ud866\ude52\ud8fd\udc01\uda0e\udf0c\ud8a8\ude8c\ud801\udf5a\ud94a\udda1\udbbe\ude18\ud94e\udc12\ud858\udda8\udb15\udd07\ud9ca\ude07\uda3a\udf8d\ud904\udd4d\udbf9\udd9d\ud939\udf85\ud989\ude84\ud812\uddc4\ud811\udd6c\udb00\udde5\udbca\uddfc\udb13\udf48\ud921\udd66\udb56\ude46");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud879\udcfa\ud922\udd6e\ud883\uded9\ud8cd\uded4\udb4e\ude67\udaa8\ude54\ud84f\uddb1\uda1c\udfd9\udbf0\udf64\udbe6\udea9\udb00\udc31\udbb2\udef8\uda7a\udd1d\udb96\udc1a\ud898\udc6c\ud9fb\udf3a\ud8a9\udc56\ud803\udca7\udac7\udd6e\udb84\udd9f\ud83b\udf1a\udb53\udc20\udbf0\udd93\ud9c9\udc53\udb7f\udcfe\ud986\uddfb\udb11\uded8\ud8e1\udfaa\uda43\udd83\ud968\uddfb\udba0\udc8c\udb9b\udc2f\ud8cb\ude18\ud833\uddff\ud9fd\udf6d\uda23\udc1d\ud9ed\udf55\uaab0\udaa9\uddce\ud85a\udf91\ud875\udeef\ud962\udc7e\ud984\ude66\udbd3\ude7d\ud9dc\uddfc\uda35\udfe2\uda8d\udc85\ub5c5\udb22\udc5a\ud866\ude52\ud8fd\udc01\uda0e\udf0c\ud8a8\ude8c\ud801\udf5a\ud94a\udda1\udbbe\ude18\ud94e\udc12\ud858\udda8\udb15\udd07\ud9ca\ude07\uda3a\udf8d\ud904\udd4d\udbf9\udd9d\ud939\udf85\ud989\ude84\ud812\uddc4\ud811\udd6c\udb00\udde5\udbca\uddfc\udb13\udf48\ud921\udd66\udb56\ude46", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalize("\uda3c\uddef\udb9d\udd4d\udacb\ude44\udbba\ude27\udb29\uddcd\ud81f\ude84\ud9a2\uddbd\ud96e\udff4\ud998\udf85\ud9fa\udf04\uc915\udb6f\udc48\ud946\udc50\ud988\udc13\uda52\udc5f\udb3d\udd0b\ud9b4\udfa7\udb36\udd23\uda18\udec1\uda2f\udfb6\uda7c\udf6f\ud840\udc31\ud8d7\udc70\udba1\udca1\udb99\ude09\ud8f3\udcc3\ud875\uded5\uda8c\ude18\ud8d6\udf13\ud96c\udfe2\ud9da\udf85\ud8b8\udd75\ud8b5\uded1\ud9d8\udca5\ud929\udd90\ud9f4\udc73\udae2\udcb3\ud947\udfd3\uda41\udf05\ud8e2\udd52\udad3\udf99\ud9e7\ude96\udb83\udc6b\udb4e\udf8b\ud978\udd35\udbff\udda4\udb0b\uddd9\uda39\udc21\udbed\udcf6\uda52\udc7f\ud864\ude4f\udaab\udc3b\ud984\udf54\ud9dc\ude6c\udaf2\ude77\ud908\udc23\ud9ca\udea7\ud98e\udef5\ud8ed\udf99\udb40\udce8\ud9de\udfa1\udb70\ude8a\uda26\udd0d\uda73\udf49\udaa9\ude40\uda9e\udfbd\ud8b7\udc96\ud84b\udc40\ud820\udf6b\uf5ea\udb56\udef8\u09bb\u3ce4\udbd4\udc25\ud8a3\ude62\ud884\udd46\ud804\ude32\uda69\udc2c\ud8d8\udd47\ud912\udeb7\ud99e\udf32\ud95f\udda3\u3491\udb34\ude22\udb40\uddfe\udaeb\udc11\uda17\udf98\ud8a1\uddf3\ud878\udc57\ud91e\udf2e\udb53\udc29");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda3c\uddef\udb9d\udd4d\udacb\ude44\udbba\ude27\udb29\uddcd\ud81f\ude84\ud9a2\uddbd\ud96e\udff4\ud998\udf85\ud9fa\udf04\uc915\udb6f\udc48\ud946\udc50\ud988\udc13\uda52\udc5f\udb3d\udd0b\ud9b4\udfa7\udb36\udd23\uda18\udec1\uda2f\udfb6\uda7c\udf6f\ud840\udc31\ud8d7\udc70\udba1\udca1\udb99\ude09\ud8f3\udcc3\ud875\uded5\uda8c\ude18\ud8d6\udf13\ud96c\udfe2\ud9da\udf85\ud8b8\udd75\ud8b5\uded1\ud9d8\udca5\ud929\udd90\ud9f4\udc73\udae2\udcb3\ud947\udfd3\uda41\udf05\ud8e2\udd52\udad3\udf99\ud9e7\ude96\udb83\udc6b\udb4e\udf8b\ud978\udd35\udbff\udda4\udb0b\uddd9\uda39\udc21\udbed\udcf6\uda52\udc7f\ud864\ude4f\udaab\udc3b\ud984\udf54\ud9dc\ude6c\udaf2\ude77\ud908\udc23\ud9ca\udea7\ud98e\udef5\ud8ed\udf99\udb40\udce8\ud9de\udfa1\udb70\ude8a\uda26\udd0d\uda73\udf49\udaa9\ude40\uda9e\udfbd\ud8b7\udc96\ud84b\udc40\ud820\udf6b\uf5ea\udb56\udef8\u09bb\u3ce4\udbd4\udc25\ud8a3\ude62\ud884\udd46\ud804\ude32\uda69\udc2c\ud8d8\udd47\ud912\udeb7\ud99e\udf32\ud95f\udda3\u3491\udb34\ude22\udb40\uddfe\udaeb\udc11\uda17\udf98\ud8a1\uddf3\ud878\udc57\ud91e\udf2e\udb53\udc29", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud933\udfd5\uda64\udfbe\ud8d4\udc8b\uda54\ude9c\u00d2\000\000\ud817\udff0\u1fbc\ud86f\udd8a\udab3\udf02");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud933\udfd5\uda64\udfbe\ud8d4\udc8b\uda54\ude9c\u00f2\000\000\ud817\udff0\u1fb3\ud86f\udd8a\udab3\udf02", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud933\udfd5G\000\uda54\ude9c\udafc\ude2e\ud919\udee2\ud9a8\ude01\ud818\udc73\u1ff3F\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud933\udfd5g\000\uda54\ude9c\udafc\ude2e\ud919\udee2\ud9a8\ude01\ud818\udc73\u1ffcf\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials("\uc5e0\uda62\udd83\udb6d\ude41\ud8e6\udcc0\ud90d\udc7c\uda39\udde3\ud838\udd21\udbc4\udca7\uf74c\udabd\udce9\ud869\uddd3\ud838\udf25\ud909\udccb\ud99e\udd82\uda4d\udc09\udb1f\ude97\udb79\udebc\ud8b5\udfac\ud8c9\udff0\ud945\udda2\uda0e\udcbe\ua3db\ud9b8\udea2\ud825\uddf7\ud815\ude16\udbac\udd10\udbf9\udc07\ud82c\udf55\u4a86\uda53\udcfd\ud88f\udce1\ud9f0\udc89\ud8e5\uddd6\udafa\udd41\ud8b1\udf61\uda4d\uddc7\011\000\000\000\000\udb21\uddb0\uda5f\udf13\ud9bc\udea5\udb3d\udde4\udbf0\udd70\udba6\udcb0\uda88\uddd4\ud8d9\udd4d\udaeb\udf98\ud83f\udc28\ud888\udcad\udb71\udf54\ud9a7\udf44\ud9ab\udca8\u3360\000\uda3a\udc9d\udb8d\udd9a\000\ud8cd\ude85\udad6\udda6\udbfe\udcaa\udabf\ude30\ud918\uddfb\ud834\ude88\ud978\udf2c\ud93d\udf64\ud9c6\uded6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uc5e0\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\udb50\udf08\014\uda8b\udeb4\uda06\udfa9\udb70\udf75\ud9ec\udfb2\udbe8\udf4f\ud959\ude45\uda62\udf1c\u2a61\udaaf\udc0d\udb14\udf5f\uda12\ude57\ud9ff\udf35\ud88c\udd2d\udb0e\udf6b\ud9a7\uddbd\ud964\udcc1\ud971\udf7b\ud9c3\udf4f\ud927\udefa\ud843\uded4\ud874\udc90");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb50\udf08\014\uda8b\udeb4\uda06\udfa9\udb70\udf75\ud9ec\udfb2\udbe8\udf4f\ud959\ude45\uda62\udf1c\u2a61\udaaf\udc0d\udb14\udf5f\uda12\ude57\ud9ff\udf35\ud88c\udd2d\udb0e\udf6b\ud9a7\uddbd\ud964\udcc1\ud971\udf7b\ud9c3\udf4f\ud927\udefa\ud843\uded4\ud874\udc90", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\u04af\ud8b5\udc97\ud8d4\udfc3\u01c9\ud9d2\udf79");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u04ae\ud8b5\udc97\ud8d4\udfc3\u01c7\ud9d2\udf79", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud86f\udf88\uda98\udd32\u10d5\ud97b\ude5f\udb97\ude9c\ud808\uddd2\udb6e\udd6d\ud8eb\udd97\ua739\uda61\udd4a\ud961\udca2\udb55\ude42\ud902\udea8\uda6b\udf68\uda66\ude32\ud92f\uddd4\ud88c\udc96\ud905\uded8\ud98a\udcc6\ud8dc\udee4\uda4f\udd5f\u04f1\ud9c5\udc5a\uda85\ude6e\ud8b5\ude49\ud956\udee5\udb3c\udee7\ud971\ude84\udac6\udc93");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud86f\udf88\uda98\udd32\u10d5\ud97b\ude5f\udb97\ude9c\ud808\uddd2\udb6e\udd6d\ud8eb\udd97\ua738\uda61\udd4a\ud961\udca2\udb55\ude42\ud902\udea8\uda6b\udf68\uda66\ude32\ud92f\uddd4\ud88c\udc96\ud905\uded8\ud98a\udcc6\ud8dc\udee4\uda4f\udd5f\u04f0\ud9c5\udc5a\uda85\ude6e\ud8b5\ude49\ud956\udee5\udb3c\udee7\ud971\ude84\udac6\udc93", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud9a1\udfd4\ud8a6\uddae\udb4e\udff8\ud90f\udfd3\ud93d\udd5f\u07c9\uda84\ude02\ud8ff\udecc\udb74\udef4\udb17\udf6a\ud966\ude19\ud908\udd35\udb75\udfe0\ud9de\udfb5\udab1\udcb5\ud93c\udd71\uda13\udfe1\udb5e\udce9\u4870\udb3c\udd48\ud9a7\udcae\udb47\udff3\udbb7\udf92\ud89c\uddfe\udbed\udd7c\ud933\udd85\udbf6\ude23\ud8b5\udd2d\ud93d\udd98\udadb\ude93\ud933\udc65\ud998\uddf3\ud9df\udc00\ud852\udfdc\ud9e6\udc13\ud82a\ude95\udbad\udecf\udad7\udc92\ud822\udc64\udb38\udf7b\ud8a0\udda0\udbf4\udf0a\udae4\udd87\uda7a\ude8f\ud893\udf34");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9a1\udfd4\ud8a6\uddae\udb4e\udff8\ud90f\udfd3\ud93d\udd5f\u07c9\uda84\ude02\ud8ff\udecc\udb74\udef4\udb17\udf6a\ud966\ude19\ud908\udd35\udb75\udfe0\ud9de\udfb5\udab1\udcb5\ud93c\udd71\uda13\udfe1\udb5e\udce9\u4870\udb3c\udd48\ud9a7\udcae\udb47\udff3\udbb7\udf92\ud89c\uddfe\udbed\udd7c\ud933\udd85\udbf6\ude23\ud8b5\udd2d\ud93d\udd98\udadb\ude93\ud933\udc65\ud998\uddf3\ud9df\udc00\ud852\udfdc\ud9e6\udc13\ud82a\ude95\udbad\udecf\udad7\udc92\ud822\udc64\udb38\udf7b\ud8a0\udda0\udbf4\udf0a\udae4\udd87\uda7a\ude8f\ud893\udf34", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.initials(" \udba6\udeb2\037\uda06\udfa2\ud90c\udde2\udb2b\udce8\ud976\ude2a\udb04\udec8\uda4b\udf89\u2a61\udaaf\udc0d\udb14\udf5f\uda12\ude57\ud9ff\udf35\ud88c\udd2d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba6\uda06", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalize(" \udba6\udeb2\037\uda49\udcb1\ud91f\udda8\uda0a\udcd0\udb1c\uddd4\ud8ca\udd2a\ua927\ud98c\udf2f\udb0f\udf08\ud9b8\udfaa\u4282\ud9ff\udf35\ud88c\udd2d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals(" \udba6\udeb2\037\uda49\udcb1\ud91f\udda8\uda0a\udcd0\udb1c\uddd4\ud8ca\udd2a\ua927\ud98c\udf2f\udb0f\udf08\ud9b8\udfaa\u4282\ud9ff\udf35\ud88c\udd2d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.swapCase("\ud933\udfd5\uda64\udfbe\ud8d4\udc8b\uda54\ude9c\u00d2\000\000\ud817\udff0\u1fbc\ud86f\udd8a\udab3\udf02\ud806\udcc3\uda6b\udf19\uda4e\udcb3\ud96f\ude1c\ud8bc\udfc1\ud87c\ude12\ud814\udf44\u1f9e\ud927\udca8\udb3d\ude10\ud98c\udc8f\udbbe\udca6\uda27\udd84\udb30\udfe7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud933\udfd5\uda64\udfbe\ud8d4\udc8b\uda54\ude9c\u00f2\000\000\ud817\udff0\u1fb3\ud86f\udd8a\udab3\udf02\ud806\udcc3\uda6b\udf19\uda4e\udcb3\ud96f\ude1c\ud8bc\udfc1\ud87c\ude12\ud814\udf44\u1f96\ud927\udca8\udb3d\ude10\ud98c\udc8f\udbbe\udca6\uda27\udd84\udb30\udfe7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud9dd\udf6e\u03a3\uda92\udd7c\u59a5\ud8ff\udfb6\ud813\udd69\ud8a1\uddd8\uda11\udeca");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9dd\udf6e\u03c3\uda92\udd7c\u59a5\ud8ff\udfb6\ud813\udd69\ud8a1\uddd8\uda11\udeca", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud9dd\udf6e\u03a3\uda92\udd7c\u59a5\ud8ff\udfb6\udb29\uddb5\ud8a1\uddad\uda11\udeca");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9dd\udf6e\u03c3\uda92\udd7c\u59a5\ud8ff\udfb6\udb29\uddb5\ud8a1\uddad\uda11\udeca", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud867\udc5f\u03a3\uda92\udd7d\u59a5\ud8ff\udfb6\ud813\udd69\ud8a1\uddd8\uda11\udeca");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud867\udc5f\u03c3\uda92\udd7d\u59a5\ud8ff\udfb6\ud813\udd69\ud8a1\uddd8\uda11\udeca", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\u7d8f\u03a3\uda92\udd7c\ud91c\ude87\000\ud813\udd69\ud8a1\uddd8\uda11\udeca");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7d8f\u03c3\uda92\udd7c\ud91c\ude87\000\ud813\udd69\ud8a1\uddd8\uda11\udeca", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ub0d5\u03a3\uda92\udd7c\uda82\udcae\ud8b2\udc97\ud9af\udcff\uc651\ud8a1\udf22\ud8a6\udd7f\ud864\uddd6\ud983\ude84\udb69\udf87\ua063\ud931\ude4f\ud8c9\ude35\ud88a\udec5\udb6c\udcbd\udad9\ude1d\udbba\udf4f\uda21\udd87\ud818\udf9a\udaee\ude2d\ued5c\ud8c6\udd1b\uda33\udc6a\udb46\udcb4\ud9f7\udd07\udb06\udc8b\ud84b\udf7c\udbc7\udf33\uda70\udd7a\udba4\udfc8\ud8bd\udcec\ud8f1\udc1a\ud9cb\ude51\uda20\udc90\ud9a0\ude48\udaf4\udd24\uda68\uddb8\udbef\udecd\ud9a7\udd6f\ud8a2\ude8a\uda56\udfb0\ub995");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ub0d5\u03c3\uda92\udd7c\uda82\udcae\ud8b2\udc97\ud9af\udcff\uc651\ud8a1\udf22\ud8a6\udd7f\ud864\uddd6\ud983\ude84\udb69\udf87\ua063\ud931\ude4f\ud8c9\ude35\ud88a\udec5\udb6c\udcbd\udad9\ude1d\udbba\udf4f\uda21\udd87\ud818\udf9a\udaee\ude2d\ued5c\ud8c6\udd1b\uda33\udc6a\udb46\udcb4\ud9f7\udd07\udb06\udc8b\ud84b\udf7c\udbc7\udf33\uda70\udd7a\udba4\udfc8\ud8bd\udcec\ud8f1\udc1a\ud9cb\ude51\uda20\udc90\ud9a0\ude48\udaf4\udd24\uda68\uddb8\udbef\udecd\ud9a7\udd6f\ud8a2\ude8a\uda56\udfb0\ub995", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud841\udc06\u03a3\ud86b\ude55");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud841\udc06\u03c3\ud86b\ude55", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\u7d8f\u03a3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7d8f\u03c3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud841\udc06\u03a3\ud86b\ude55\ud906\udefd\udad8\ude84\udab9\udfed\ud86e\ude4c\ud9bc\udd5c\ubca7\uda81\uddb6\ud844\udda8\ud96a\uddd8\ud807\ude0e\ud9a3\ude88\udac7\udf11");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud841\udc06\u03c3\ud86b\ude55\ud906\udefd\udad8\ude84\udab9\udfed\ud86e\ude4c\ud9bc\udd5c\ubca7\uda81\uddb6\ud844\udda8\ud96a\uddd8\ud807\ude0e\ud9a3\ude88\udac7\udf11", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud841\udc06\u03a3\ud86b\ude55\ud855\ude4c\udbc8\udca6\ud9c6\udd05\ud86e\ude86\ud9bc\udd5c\ubca7\uda81\uddb6\ud92b\udc0a\ua08f\uda21\ude3d\uda15\uddd6\udb90\udff5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud841\udc06\u03c3\ud86b\ude55\ud855\ude4c\udbc8\udca6\ud9c6\udd05\ud86e\ude86\ud9bc\udd5c\ubca7\uda81\uddb6\ud92b\udc0a\ua08f\uda21\ude3d\uda15\uddd6\udb90\udff5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\u2124\u03a3\uda92\udd7c\ubae8\ud8ff\udfb6\udaa8\udd33\ud891\uded6\uda11\udeca");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u2124\u03c2\uda92\udd7c\ubae8\ud8ff\udfb6\udaa8\udd33\ud891\uded6\uda11\udeca", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\ud841\udc06\u03a3\ud86b\ude55\ud855\ude4c\ud878\udedd\ud9c6\udd05\ud86e\ude86\ud9bc\udd5c\ubca7\uda81\uddb6\ud92b\udc0a\ua08f\uda21\ude3d\uda15\uddd6\ud9ea\ude42");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud841\udc06\u03c3\ud86b\ude55\ud855\ude4c\ud878\udedd\ud9c6\udd05\ud86e\ude86\ud9bc\udd5c\ubca7\uda81\uddb6\ud92b\udc0a\ua08f\uda21\ude3d\uda15\uddd6\ud9ea\ude42", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang.WordUtils.capitalizeFully("\u2124\u03a3\ud85c\udfa2\udb00\udf51\ud8ff\udfb6\udaa8\udd33\ud891\uded6\uda11\udeca");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u2124\u03c2\ud85c\udfa2\udb00\udf51\ud8ff\udfb6\udaa8\udd33\ud891\uded6\uda11\udeca", String.valueOf(r));
  }
}
