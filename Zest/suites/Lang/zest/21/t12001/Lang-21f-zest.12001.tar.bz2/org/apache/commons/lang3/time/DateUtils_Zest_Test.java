package org.apache.commons.lang3.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.util.Date:Wed Sep 16 10:56:21 PDT 247553857\012",
        Z.run(T, 1, 2, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.Date:Wed Sep 16 10:56:21 PDT 247553857\012",
        Z.run(T, 1, 2, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u80c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, false, (char) 12381, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.Date:Sat Nov 06 21:13:05 PDT 232558094\012",
        Z.run(T, 1, 2, 9, 11, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6\uda6b\udd5c\ud89d\ude39\ud808\udf18\uda09\udd40\ud94f\udd0b", "\ua18c\u0226\u738e\u6b22\u928a", "\ud980\udea4\udbba\ude64\ud926\uddf4\ud99d\udc04\udacf\udd0f\udbf1\udda8",
        28, 97441, -660746287, 7338762466834385443L, 17118L, false, true, (char) 16199, (char) 24695,
        Double.longBitsToDouble(0x3fc1e0c2a0407ebcL), Double.longBitsToDouble(0x3fd2e4bde058d8d2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.Date:Tue Dec 23 02:58:48 PST 19482347\012",
        Z.run(T, 1, 2, 9, 0, "\uda52\udc08\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\000", "\uda2b\udd05\ud97e\udc14",
        20, 76270, -987152053, 614741350964328803L, 50094L, false, true, (char) 17649, (char) 39012,
        Double.longBitsToDouble(0x3fe9003d2000cb44L), Double.longBitsToDouble(0x3fce2000126cb800L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.Date:Tue Nov 22 05:00:00 PST 265588176\012",
        Z.run(T, 1, 2, 9, 15, "\ud866\uddc2\ud935\udf3c\ud95e\udd20\u9966\udb65\udfb5\ud8fe\udce6", "\uae3c\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u2000\ud704\u2fd0\u1ab6\uae29\u78ec\u5d05\u5a90\ud376\u9c52", "\ud840\udcac",
        27, 70789, -962459101, -8381387532913199486L, 10246L, true, false, (char) 30116, (char) 53558,
        Double.longBitsToDouble(0x3fd538095058d8d2L), Double.longBitsToDouble(0x3fdeb566d41f4564L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.Date:Wed Aug 26 09:54:18 PDT 248651305\012",
        Z.run(T, 1, 2, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99\udb0f\udc98\ud84e\udf34\ud8a9\udef2\uda38\udf91\udb81\udd43\ud941\udc6b\ud8aa\ude91",
        20, 77466, 1792261069, 7846615148259258391L, -3884L, true, true, (char) 64976, (char) 32238,
        Double.longBitsToDouble(0x3fee7386c1670152L), Double.longBitsToDouble(0x3fdcf73063da4b80L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.Date:Mon Aug 17 11:26:21 PDT 247553857\012",
        Z.run(T, 1, 5, 3, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\uda07\udcef", "\uaed1\u04c7\u50e0\u7b2d\u81e3\ua18c\u0226\u738e\u8dcd\u625e\u9928\u4a13\u4a01\u5d05\u5a90\u10a0\u9c52", "\ud91f\uddbe\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\udb89\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 40858, (char) 13420,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.Date:Wed Sep 16 10:56:21 PDT 247553857\0121=java.util.Date:Wed Aug 17 10:56:21 PDT 247553887\012",
        Z.run(T, 2, 2, 9, 15, "\ud8dd\udf9e\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u75ed\u1681\u50e0\u7b2d\u11c2\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 63487, (char) 59233,
        Double.longBitsToDouble(0x3fe73b50b0176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.Date:Tue Nov 15 21:01:29 PST 265588176\012",
        Z.run(T, 1, 4, 1, 15, "\ud8fb\udf6f\ud956\udd85\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u198e\u6484\u10a0\u9c52", "\ud91f\udd3d",
        28, 70789, -962459101, -8381387531127510910L, 10246L, false, false, (char) 5848, (char) 44990,
        Double.longBitsToDouble(0x3fd2e4bde058d8d2L), Double.longBitsToDouble(0x3fdeb566d41f4564L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.Date:Tue Aug 11 19:31:56 PDT 247553857\012",
        Z.run(T, 1, 2, 9, 15, "\uda2e\udd8c\ud935\udee0\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uae64\u04c7\u3841\u311b\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\uc183\u8602", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 55823, 1272877072, 7811983032287516716L, -95954L, true, true, (char) 12730, (char) 40187,
        Double.longBitsToDouble(0x3fdb87931ca66036L), Double.longBitsToDouble(0x3fd26c9f760d829cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u04c7\u50e0\u7b2d\u51f0\ua18c\u3254\u738e\u6b22\u59a6\u6806\u5847\u14a3\u5db5\u2fb3\u10a0\u9c52", "\ud91f\udd3d\ud98a\udf6a\ud9e4\udf95\ud9ff\udec1\ud8d3\uddb1\ud818\udfa2\ud8b4\udddc\udaa0\ude59",
        25, 2735, 1272877072, 7811983035366981676L, 82769L, true, true, (char) 9287, (char) 34728,
        Double.longBitsToDouble(0x3fe2ebf3a65fe473L), Double.longBitsToDouble(0x3fdb8a3c1ca66036L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.Date:Tue Aug 18 16:56:21 PDT 247553857\012",
        Z.run(T, 1, 3, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 40858, (char) 13476,
        Double.longBitsToDouble(0x3fec509008176cf4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.Date:Mon Feb 28 02:34:35 PST 204923149\012",
        Z.run(T, 1, 2, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfec\udb07\udd6c", "\uab8d\u04c7\u1729\uc180\u527b", "\ud921\uddd3",
        16, 54099, 1841749827, 6466687813161275758L, -84485L, false, true, (char) 36279, (char) 24114,
        Double.longBitsToDouble(0x3fe11b2ec472c6a2L), Double.longBitsToDouble(0x3fe4145d7930ffd2L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.Date:Sun May 29 19:08:24 PDT 105342394\012",
        Z.run(T, 1, 8, 9, 15, "\ud9bd\udfc7", "\ud3d0\ua611", "\ud89d\ude1b\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\udb9c\udc38\ud899\udf1b\ud921\uddd3\udaf8\udd85\uda9f\udf92\ud86b\uddbb\udba7\udf97\udbf0\udcfb\udbba\udeb8",
        11, 73098, 1180698858, 3324222710071704731L, 43407L, true, true, (char) 28667, (char) 6933,
        Double.longBitsToDouble(0x3fe4145d7930ffd2L), Double.longBitsToDouble(0x3fd5aedec87a0874L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.Date:Thu Dec 28 06:57:58 PST 112541474\012",
        Z.run(T, 1, 3, 4, 15, "\ud8c4\uddaa\udaa7\ude85\u92b6\uda68\udd76\udb65\udfb5\ud8ac\ude87", "\uaefe\u0be3\u50e0\u7b2d", "\udb04\udf7a\ud921\uddd3\udaf8\udd85\udb6d\uddc8\udb3b\udc23\ud949\udce6\ud980\udea4\udbba\uded3\udb53\udca3\ud98b\uddb2\udadf\udec0\udbf1\udda8\udb66\udc25\ud91f\udd3d\udb37\udee7\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99\udb0f\udcd9\u026d\uda57\udc88\uda38\udf91\udb81\udd43\uda05\udd69\ud8aa\ude91\uda75\ude3d\u9de7\uda88\ude18\udb49\udd51\ud957\udf3b\udb26\udc8d\ud94c\udda2\uda9d\udc92\ud9cf\udd2a\ubd2d\udad6\udfa0\ud903\ude22\udabc\udd69\ud99e\udc13\uda1d\udfe6\ud902\udecf\ud87f\udfdc\ud887\udd1a\udb60\ude99\ud959\udca4\udb01\ude34\ud82c\udd64\u5546\udb7e\udd2e\ud91f\udccb\uda1e\udeb6\uda23\udef9\udb47\udc5d\udab9\udf93\ud892\udcc9\udb3e\udcba\ud937\udf13\udac8\udcf8\udbf0\udd2f\uda63\ude55\uda32\udc65\uda8b\udff4\udaa2\ude60\ud845\udd42\udab0\uddd4\uda5a\udd8f\uda13\udc54\udb72\udc84\ud90b\ude44\udb40\udd50\ud8c0\udef9\ud9a7\udfe8\ud9e3\ude9c\ud92c\udd33\uda40\udcf4\udb1b\ude08\ud961\udc67\uda36\ude8f\uda61\ude0e",
        48, 10778, 1996385071, -3551600924643721575L, -77871L, false, false, (char) 13889, (char) 3147,
        Double.longBitsToDouble(0x3fe77636ea477061L), Double.longBitsToDouble(0x3fed29d096f0fcf3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfdf\ud8fe\udce6", "\uaed1\u04c7\u5321\u1192\u527b\u3fa3\u7994\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u2d4a", "\uda17\udf3b\udb4f\udd7e\ud9e4\udf95\udb87\udde6\uda98\udf5b\ud909\ude7f\ud88c\uddef\ud852\ude3d\ud959\udda7\ud8dc\udf77\ud93f\ude3c\udbcc\uddb5\udb81\udd43\ud941\udc6b\udb0a\ude8f\ud875\udd3d\u9de7\ud915\udca7",
        48, 51292, -45598497, -6260937712141602925L, -69665L, true, false, (char) 62818, (char) 9562,
        Double.longBitsToDouble(0x3fcd102980b1e8c4L), Double.longBitsToDouble(0x3fd7f5db6cc70410L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jul 17 13:27:00 PDT 169911675\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 9, "\ud903\udf21\ud935\udf20\ud95e\udd20\ud80d\udd66\uae79\ud94c\udfde", "\uc14e\ub44b\ud643\u425d\ud17c\uad84\u6a8c\u7ba1\u21a5\u8677\u0ca1\u702f\u2398\u4f6e\u5a90\u10a0\u6f3f", "\ud925\udd3d\udb4f\udd7e\ud814\udfce\udb7c\udd1f\uda95\ude68\ud909\ude43\ud8ee\udc1f\uda6f\udce6",
        12, 54385, 1272877072, 5361832422160020145L, -28049L, true, true, (char) 40801, (char) 40389,
        Double.longBitsToDouble(0x3fea494ac93fbc1fL), Double.longBitsToDouble(0x3fce6bca7a1a4440L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.Date:Mon Sep 19 21:49:40 PDT 36375921\012",
        Z.run(T, 1, 2, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6\uda6b\udd5c\ud89d\ude39\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\udb9c\udc38\ud899\udf1b\ud921\uddd3\udaf8\udd85\u5fcf\ud86b\uddbb\udba7\udf97\ud980\udea4\udbba\ude64\ud926\uddf4\ud99d\udc04\udacf\udd0f\udbf1\udda8\udb66\udc25\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1", "\u1bc3\ua65c\uab72\u3e1c\ua1fb\uc5ab\ud69a\u2355\uac49\uaa78\u7af9\u9a69\u9ff6\u37ba\ubebc\u0089\u90b2\u4752\uc8ac\u8106\u751c\u769f\u0ff4\ua434\u3736", "\ud949\udedf\uda5e\udecb\ud97a\udf7d\ud921\udf58\udae7\udf45\ud8ac\udfbd\ud868\udd68\u3707\uda7e\ude4c\ud8da\udd82\udbaf\udd1b\udaf9\udd36\ud934\ude3b\udacc\uddb2\udbee\udd6d",
        -3, 41299, 128856337, 1147851048660580903L, -64084L, true, false, (char) 18698, (char) 45806,
        Double.longBitsToDouble(0x3fd22342810548d2L), Double.longBitsToDouble(0x3fc472c5694d7630L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 0, 15, "\ud9bd\udfc7\udaa5\udf34\u1a76\000\000\ud8fe\udce6", "\000", "",
        -5, -1000, 0, 0L, -100000L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 9, 15, "\ud9bd\udfc7\ud981\udd2e\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u84ce\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u2e2c\u7979\u5d05\u5a90\u10a0\u9c52\u419e\u33d9\u7a4f\u7123", "\udbbd\uddf0\ud889\udc66\ud8ee\udc1f\udb14\udd99\udb0f\udc98\u026d\uda57\udc88\uda0f\udd38\udb81\udd43\ud903\udc6c\ud8aa\ude91\ud875\udd3d",
        21, 15069, 1239729895, 7903974473925896899L, 43223L, true, false, (char) 63281, (char) 44303,
        Double.longBitsToDouble(0x3fe39c23cc3d8b3bL), Double.longBitsToDouble(0x3feea2afc5753f34L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 9, 15, "\ud9bd\udfc7\udb57\udf67\uda24\udc72\ud95a\udd36\ud82c\ude7b\ud9c0\udf72\uda6b\udd5c\ud89d\uddba\ud808\udf18\uda09\udd40\ud94f\udd0b\ud98f\udeb9\udaa8\udf28\udb9c\udc38\ud899\udf1b\ud921\uddd3\udb51\udeaa\ud95a\udf41\ud86b\uddbb\udba7\udf97\ud980\udea4\udbba\ude64\ud926\uddf4\ud99d\udc04\udacf\udd0f\udbf1\udda8\ud985\uded0\ud91f\udd20\udb4f\udd7e", "\u6a96\u9e4b\ub616", "\ud970\udecf",
        42, 60038, 1450000428, -6723309183173488113L, -95954L, true, true, (char) 12730, (char) 40187,
        Double.longBitsToDouble(0x3fedc3c98e538399L), Double.longBitsToDouble(0x3febf74f100d03c0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.Date:Mon Dec 17 10:56:21 PST 247553860\0121=java.util.Date:Tue Aug 17 10:56:21 PDT 247553897\012",
        Z.run(T, 2, 6, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ue1fb\ud8ac\udcb9\ud8fe\udce6", "\uaed1\u04c7\u603a\u2559\u51ed\ua18c\u0226\u738e\u6b22\u928a\u7583\u1036\u78ec\u42ac\u3b6b\u4911\u9c52", "\ud91f\udd3d\udb4f\udd7e\udb2b\udeda\udbf5\udd27\ud8b5\udd7e\ud9f7\ude76\ud8ee\udc1f\udb14\udd99",
        40, 31240, 1272877080, 7811983035366981676L, 59217L, true, true, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 11, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\uda93\udd11", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u8c56\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud91f\udd3d\udb4f\udd7e\udb02\udc98\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.Date:Thu Nov 25 07:33:40 PST 258970928\012",
        Z.run(T, 1, 7, 2, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\ud96b\udfb8\ud8fe\udce6", "\u8716\u04f6\u50e0\u7b2d\u527b\uc1fb\u889a\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u108a\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 8172271005550390537L, 59217L, true, true, (char) 61248, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.Date:Mon Jan 04 10:50:57 PST 57064734\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 14, 10, "\ud8b1\udf2c", "\ud3d0\ua611\uca0e", "\ud82c\udf00\uda15\udfde\ud94f\udd0b\uda2b\udd05\ud97e\udc14\udb9c\udc38\ud899\udf1b\ud921\uddd3\udaf8\udd85\u5fcf\ud86b\uddbb\udba7\udf97\ud980\udea4\udbba\ude64\ud926\uddf4\ud99d\udc04\uda00\ude04",
        15, 94363, -2037361322, -1800888186460142137L, -56082L, false, false, (char) 52226, (char) 25325,
        Double.longBitsToDouble(0x3fae821d08f06150L), Double.longBitsToDouble(0x3f901fafa5c97bc0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 14, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 11, 6, "\ud9bd\udfc7\ud935\udf3c\udb2c\udf69\udbe8\ude09\udb3f\udd21\u00e8", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u4590\u10a0\u1727", "\ud91f\udd3d\udb4f\udd7e\udac1\udeae\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99\udb0f\udc98",
        45, 74072, 1818869038, -7751468824236084684L, -46243L, false, false, (char) 7332, (char) 12730,
        Double.longBitsToDouble(0x3f976ce4b70f2620L), Double.longBitsToDouble(0x3fe29980dac14c41L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 8, 13, "\ud823\udcb9\ud935\udf3c\ud812\udcc7\ud80d\udd66\udb65\udfb5\ud8fe\udce6\uda6b\udd5c\ud89d\ude39\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\uda0b\uddca\udb44\udef8", "\u928a\u995e\ua822\u943e", "\ud99d\udc04\ud8e8\udddd\uda22\ude43\udb66\udc25\ud91f\udd3d\ud814\ude41\udb67\udcea\ud826\ude1a\ud89f\udd97\ud909\ude7f\ud931\udf0e\ud827\udfdb\udb76\udf59",
        12, 99231, 1818869038, 6227872641159660011L, 45507L, false, false, (char) 7332, (char) 12730,
        Double.longBitsToDouble(0x3f97c236b70f2620L), Double.longBitsToDouble(0x3fe29980dd8ca81eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 10, 10, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8b9\udea5", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u835c", "\ud980\udea4\udbba\ude64\ud926\uddf4\ud99d\udc04\udacf\udd0f\udbf1\udda8",
        28, 97441, -660746287, 7338762466834385443L, 17118L, false, true, (char) 16199, (char) 24695,
        Double.longBitsToDouble(0x3fc1e0c2a0407ebcL), Double.longBitsToDouble(0x3fd2e4bde058d8d2L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.Date:Mon Aug 17 12:00:00 PDT 247553857\0121=java.util.Date:Mon Aug 17 11:05:21 PDT 247553857\012",
        Z.run(T, 2, 12, 5, 2, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u7ca7\u6f27\u50cb\u259e\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u6dd9\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud91f\udd3d\ud893\udd80\uda9d\udd92\udba3\udc39\ud89f\ude1e\ud909\ude7f\ud8ee\udc1f\ud92c\udc8d",
        9, 2840, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fd2dda31ca66196L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 15, "\u00ee\uda87\udfc3\000\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u04c7\u50e0\u7b2d\u008f\u8b42\u0226\u738e\u6b22\u928a\u995e\u3cab\000\000\u390e\u10a0\u9c52", "\ud91f\udd3d\ud907\udfda\ud9e4\udf00\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1fZ",
        -5, 58896, 0, 7782220157546217516L, 59217L, true, true, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe0000698170000L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.Date:Mon Mar 23 06:49:05 PDT 71361243\012",
        Z.run(T, 1, 2, 0, 15, "\ud866\uddc2\ud935\udf3c\ud95e\udd20", "\uca0e\u1111\u0ed7\uae3c\u00be\000", "",
        39, 76270, -1490468533, 2251881156523745234L, -57840L, false, true, (char) 17649, (char) 39012,
        Double.longBitsToDouble(0x3fa003d20ea00000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 15, 15, "\ud866\uddc2\ud935\udf3c\ud95e\udd20\u9966\uda24\udf21\ud914\udc61", "\ub4be\u4f66\ub87b\u7b2d\u527b\ua18c\u0226\u2000\ud704\u6068\u1ab6\ua628\u78ec\u5d05\u5a90\ud376\u9c52", "\ud840\udcac",
        27, 70789, -962459101, -8381387532913192555L, 10246L, true, false, (char) 50659, (char) 54600,
        Double.longBitsToDouble(0x3fe1678de02cf5b2L), Double.longBitsToDouble(0x3fdeb566d41f4564L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 3, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd81\ud934\uddd8\udabf\udde3\udaad\ude40", "\u74cd\u04c7", "\ud897\udf41\udb9c\udc38\ud963\udf0e",
        8, 22821, -2011828098, -1830168701346529582L, -52158L, true, true, (char) 22212, (char) 54318,
        Double.longBitsToDouble(0x3fe78a33030e3e22L), Double.longBitsToDouble(0x3fdaac28ffa37af0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 3, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\ud9f8\udf5f\ud9f1\udf6e", "\u9c11\u04c7\u50e0\u7b2d\u81e3\ubc4c\u318e\u19e0\u8dcd\u62d0\u9928\u4a13\u4a01\u5d05\u33bf\u01eb\u6a8c", "\ud91f\uddbe\udb96\udec8\ud955\udff0\ud89b\udc98\ud9ff\ude43\udb89\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2812, -369455856, -258467496880947156L, 59223L, false, true, (char) 63566, (char) 40056,
        Double.longBitsToDouble(0x3fb555a840bba0c8L), Double.longBitsToDouble(0x3fe5c3c98fae9773L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 3, 0, "", "", "\udb65\udfb5",
        32, 41779, -405678170, 750186318934246846L, -100000L, false, true, (char) 33771, (char) 40494,
        Double.longBitsToDouble(0x3e4d0e2054000000L), Double.longBitsToDouble(0x3fd60e699564f42cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 10, 15, "\ud8bb\udd74\ud82b\udda3\ud96e\udf6b\ud889\ude92\ud9ba\udefb\udae8\udf43\ud887\ude17\ud89d\ude39\udb92\uddd9\uda09\udd40", "\u81e3\u23df\ud39e\u1d81\u8de9\u625e", "\ud907\ude45\uda7f\udf6c\ud877\udc31\ud922\udc36\uda7f\ude0c\ud903\udc68\udac6\udf38",
        25, 38793, 1832132721, -4129770679514999694L, -28147L, true, false, (char) 27858, (char) 38764,
        Double.longBitsToDouble(0x3fe34def4310307fL), Double.longBitsToDouble(0x3fe07f1476fd08a1L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.util.Date:Tue Jul 28 17:37:22 PDT 247553857\0121=java.util.Date:Tue Jul 28 17:37:22 PDT 247553857\012",
        Z.run(T, 2, 3, 3, 15, "\udade\udfcc\udae1\udfcd\udb32\udee7\ud8f3\udcea\uda9b\udfd8\uda07\udcef", "\uaed1\u04c7\u50e0\u7b2d\u81e3\ua18c\u0226\u738e\u0448\u625e\u9928\u66a4\uc73d\u5d05\u5a90\u10a0\u9c52", "\udb26\udce0\ud9c7\udc93\uda01\udfbe\ud9ff\udec1\ud89f\udd97\udb89\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983033555042348L, 59217L, true, true, (char) 40858, (char) 13420,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 3, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud9ef\udfc6", "\u563a\u6d9c\u543c\ud2ec", "\ud899\udf1b\ud921\uddd3\uda15\uded3\udb98\udd6c\udb3d\uddc3\udb96\udc91\ud806\udfe6",
        28, 82289, -884715744, 5071062982308528881L, -44278L, true, true, (char) 24114, (char) 28667,
        Double.longBitsToDouble(0x3fbcb1a8b4145d78L), Double.longBitsToDouble(0x3fd30ffdc2b5dbd8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.util.Date:Fri Apr 08 07:47:08 PST 41275035\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 15, 15, "\ud9bd\udfc7\ud9d6\udd6c\ud95e\udd20\ud80d\udd66\udb65\udfb5\uda07\udcef", "\uaed1\u04c7\u50e0\u7b2d\u81e3\ua18c\u0226\u738e\u8dcd\u625e\u7ff9\u74f6\u9ded\u5d05\u5a90\u10a0\u9c52", "\ud91f\udda0\udb4f\udd7e\ud9e4\udf95",
        54, 77146, -2345342, -1302603313824771750L, 13966L, false, false, (char) 22616, (char) 29742,
        Double.longBitsToDouble(0x3fdfd08a10655ed0L), Double.longBitsToDouble(0x3fecabc6bee76ad3L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.util.Date:Sat Apr 26 13:39:32 PST 89542457\012",
        Z.run(T, 1, 5, 3, 15, "\ud9bd\udfc7", "\000", "\uda6b\udd5c",
        20, 36363, 2137982398, -2825807166758427588L, 3111L, false, true, (char) 16640, (char) 40494,
        Double.longBitsToDouble(0x3fbf98a23a1c40a8L), Double.longBitsToDouble(0x3fb839a650000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.util.Date:Sun Mar 07 18:26:58 PST 276733830\0121=java.util.Date:Sun Mar 07 18:26:58 PST 276733830\012",
        Z.run(T, 2, 2, 9, 15, "\ud8dd\udf9e\ud935\udf3c\ud95e\udd20\uda97\uddaa\udb65\udfb5\ud8fe\udce6\uda6b\udd5c\ud89d\ude39\udb90\udf7d\udb2e\udcab\ud821\udff4\uda2b\udd2f\ud9d8\uddd7\udb32\udc81\ud899\udf1b\ud921\uddd3\uda44\uddcc\u5fcf\ud86b\uddbb\udba7\udf97\ud980\udea4\udbba\ude64\ud926\uddf4\udbb6\ude49\udacf\udd0f\udbf1\udda8\udb66\udc25\ud91f\udd3d\udb4f\udd7e", "\u6a96\u9e4b\u1bc3\ua65c\uab72\u3e1c", "\udb81\uddac\ud941\udc6b\ud8aa\ude91\ud875\udd3d",
        0, 24863, 1826932455, 8732814028597618104L, 2066L, true, true, (char) 33255, (char) 55408,
        Double.longBitsToDouble(0x3fea1bed7d93c80aL), Double.longBitsToDouble(0x3fb23e307ea031b8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "\ud8dd\udf11", "\ud3d0\ua611", "\ud89d\ude39\udb90\udf7d\uda0d\udefa\udb45\udf66\uda2b\udcc9$\udb9c\udc38\ud899\udf1b\ud921\uddd3\udaf8\udd85\u5fcf\ud86b\uddbb\udba7\udf97n\udbba\ude64",
        4, 43256, 1180698858, 3324221674984586395L, 43407L, true, true, (char) 28667, (char) 6933,
        Double.longBitsToDouble(0x3e23000000000000L), Double.longBitsToDouble(0x3fd5aedec87a0874L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.util.Date:Wed Sep 16 10:56:21 PDT 247553857\0121=java.util.Date:Wed Sep 16 10:56:21 PDT 247553857\012",
        Z.run(T, 2, 2, 2, 15, "\ud8dd\udf9e\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u75ed\u1681\u50e0\u7b2d\u11c2\ua18c\u0226\u4ac5\u6b22\u928a\u995e\u3cab\u7005\u5355\uc963\u10df\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud8b2\udc97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 55471, 1272877072, 7811983035366981676L, -61871L, true, true, (char) 63487, (char) 59233,
        Double.longBitsToDouble(0x3fe73b50b0176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.util.Date:Sat Apr 25 02:36:31 PDT 247553874\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 11, 15, "\ud8dd\udf9e\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u75ed\u1681\u50e0\u7b2d\u0c21\u0631\u0226\u738e\u6b22\u928a\u995e\u3cab\u2268\u5d05\u5a90\u10a0\u9c52", "\udb66\udee1\ud8e9\ude77\ud936\ude32\ud928\udeb1\ud8b8\ude97\ud909\ude7f\uda2e\udee0\uda9b\udd2f",
        30, 72690, -318551062, 7811983559352991788L, 59217L, true, true, (char) 63487, (char) 59233,
        Double.longBitsToDouble(0x3fe73b50b0176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.util.Date:Sat Sep 23 15:21:45 PST 40964682\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 14, 4, "\ud8f0\udc87\ud851\udd27\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u6dce\u1681\u50e0\u7b2d\u11c2\ua18c\u0226\ua9b6\u25fd\u7b61\u6a31\u3cab\u78ec\u5d05\u5a90\u10a0\u9c52\u2408\u84e0\ubf36\u8472", "\u741e\ud937\ude85\ud8ee\udc1f\udb14\udd99\udb0f\udc98\u026d",
        7, 38166, 1878104847, -1292812459058294236L, 12489L, true, false, (char) 12541, (char) 40187,
        Double.longBitsToDouble(0x3fde18068c78d2b8L), Double.longBitsToDouble(0x3fe8e89435fc966bL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.util.Date:Mon Jul 05 15:47:52 PST 406376\0121=java.util.Date:Mon Jul 05 15:47:52 PST 406376\012",
        Z.run(T, 2, 9, 9, 15, "\ud8dd\udf9e\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u75ed\u1681\u50e0\u7b2d\u11c2\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u5d05\u5a90\u10a0\u7b4a", "\ud91f\udd3d\udb4f\udd7e",
        49, 69899, -1951443854, -12887917258327760L, -10851L, true, false, (char) 44990, (char) 2316,
        Double.longBitsToDouble(0x3fa636349eb566d0L), Double.longBitsToDouble(0x3fe07d1591fd08a1L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.Date:Mon Aug 17 11:26:21 PDT 247553857\0121=java.util.Date:Mon Aug 17 11:26:21 PDT 247553857\012",
        Z.run(T, 2, 5, 5, 15, "\ud8dd\udf9e\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u89e2\u1681\u50e0\u7b2d\u87fb\u995a\ua697\u7e58\u6b22\u78fc\u995e\u3cab\u78ec\u2e4c\uc453\u10a0\u9c52", "\ud8fb\udfed\udb56\udc06\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 63487, (char) 15500,
        Double.longBitsToDouble(0x3fe0657058176ce4L), Double.longBitsToDouble(0x3fdb87931ca66036L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.util.Date:Tue Nov 15 22:00:00 PST 265588176\012",
        Z.run(T, 1, 12, 8, 15, "\ud8fb\udf6f\ud956\udd85\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u074c\u04c7\ub9df\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u614e\u78ec\u198e\u6484\u10a0\u9c52", "\ud91f\udd8b",
        11, 70789, -962459101, -8381387531127510910L, 10246L, false, false, (char) 5848, (char) 44990,
        Double.longBitsToDouble(0x3fd2e4bde058d8d2L), Double.longBitsToDouble(0x3fdeb566d41f4564L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 12, 14, "\ud910\udf6f\ud956\udd85\uda47\ude26\ud996\ude5b\ud922\udfd9\ud8fe\udce6", "\uaed1\u04c7\u70d4\u37ec\u36a5\u4216\u27a0\u60ed\u6b22\u928a\u995e\u3cab\ubcc7\u1a37\u6484\u242e\u5185", "\ud961\uddb8\udb5e\udfb5\ud927\udf3b\udaec\udff7\ud9b9\udd11\uda8f\udc85\uda89\udeb3\uda8c\udc9e\udb52\udee2\uda8d\udd53\udb6f\uddcc\uda2b\uddfb\udb7a\uded0",
        55, 52735, -259455826, 3990138484923052537L, 29554L, true, false, (char) 17048, (char) 32013,
        Double.longBitsToDouble(0x3fe2666be3920a89L), Double.longBitsToDouble(0x3fb73846e7261340L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.util.Date:Fri Jun 27 02:38:09 PST 18087717\012",
        Z.run(T, 1, 4, 8, 9, "\ud9ac\udc35\ud956\udd85\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6\uda6b\udd5c\ud89d\ude39\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\udb9c\udc38\ud899\udf1b\ud921\uddd3\udaf8\udd85\u5fcf\ud86b\uddbb\udba7\udf97\ud980\udea4\udbe3\ude98\uda3b\udd5f\ud99d\udc04\udacf\udd0f\uda90\udcd7\udb66\udc25\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\uc6c5\ud8dc\udd44\uda29\udeff\udb52\udee2\u026d\uda57\udc88\uda38\udf91\udb81\udd43\ud941\udc6b\ud8b3\udcd3\uda51\udf6f\uda56\udd26\u88bb\uda3e\udd86\ud84a\ude29\udbd0\udc21\udad7\udc1a\udb0b\udd7b\uda13\udef4\udb1f\udf80\ud9ad\udc26\ud94d\udf12\udba0\udc3a\ud88a\udf91\ud9c8\udff3\udb0d\ude4d\ud990\udea2\udbf4\udd9c\ud8d0\ude96\ud81f\udf02\ud99d\ude7f\ud81e\udd1e", "\uc4c6\u236e\u8457\u4306\u0a17\ub854\uc677\u745c\u98e4\u5804\u380c\uac54\ubbac\ub9b0\u07ed\u5d6b\u8841\ua79a\u4166\u35af\u9364\ub5d8\ucd94\u7d8e\u7f1a\u41b3\u1c53\u2df4\ua9dc\u3124\uc8c1\u4fb0\u88c9\u2ac3\ud0f7\u6f8b\u644d\ubc89\u16a7\u13e1\u581d\u8b7f\uaf28\uada3\ud322\uaa2f\u16c8\u21fe\u465a\u36d4\uc0bf\u8a0d", "\uda43\udf67\uda52\udc86\uda1e\ude5c\uda34\udd50\ub9cd\udba6\udc5c\ud8a8\udf79\ud846\udce9\ud917\udcb0\udb9e\udc66\ud92f\ude44\uda2a\ude03\ud9f5\udd01\ud8bb\udf4e\udacf\udd10\udba8\udca2",
        7, 12975, -1651801532, -570867058416110335L, -36577L, false, false, (char) 36056, (char) 4068,
        Double.longBitsToDouble(0x3fedc0db26d50f2eL), Double.longBitsToDouble(0x3fefda943c3d7dd3L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.util.Date:Sun Mar 13 20:00:00 PDT 105342394\012",
        Z.run(T, 1, 12, 8, 15, "\ud9bd\udfc7", "\ua322\uba50", "\ud89d\ude1b\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\udb9c\udc38\ud899\udf1b\uda69\udcd6\ud84c\ude3c\uda9f\udf92\ud848\udebb\udba7\udf97\udbf0\udcfb\udbba\udeb8",
        11, 73098, 1180698858, 3324222710071704731L, 43407L, true, true, (char) 28667, (char) 6933,
        Double.longBitsToDouble(0x3fe4145d7930ffd2L), Double.longBitsToDouble(0x3fd5aedec87a0874L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 0, 15, "\ud9bd\udfc7", "\000\000", "\ud89d\ude1b\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\udb9c\udc38\ud899\udf1b\udb8b\udc85\udaf8\udd85\ud800\udd63\ud833\ude78\udba7\udf97\udbdb\udf8d\udbba\udeb8",
        11, 73098, 6293738, 0L, -100000L, false, false, (char) 0, (char) 21504,
        Double.longBitsToDouble(0x3fe4145d7830ffd2L), Double.longBitsToDouble(0x3e40f41000000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jan 01 00:00:00 PST 105342395\012",
        Z.run(T, 1, 12, 13, 15, "\ud9dc\udc68", "\ud3d0\ua611", "\ud89d\ude1b\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\udb9c\udc38\ud899\udf1b\ud921\uddd3\udaf8\udd85\udace\udd0c\ud86b\uddd1\udba7\udf97\udbf0\udcfb\ud8c4\ude5d",
        1, 73098, 1180698858, 3324222710071704731L, 43407L, true, true, (char) 28667, (char) 44786,
        Double.longBitsToDouble(0x3fe6ebe2c130ffd2L), Double.longBitsToDouble(0x3fd5aedec87a0874L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.util.Date:Sun Oct 18 23:19:53 PDT 137526995\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 9, "\ud903\udeb5\ud969\ude7a\ud95e\udd20\ud80d\udd66\uae79\ud94c\udfde", "\uc12b\uaf55\ud6b6\ud0e2\ud1a3\u6ec5\u6a5b\u7ba1\u21a5\u8677\u0ca1\ua01d\u2398\u58ce\u5a90\u10a0\u6f3f", "\ud8ed\udc83\udb4f\udd7e\ud814\udfce\udb7c\udd1f",
        7, 28238, 592305879, 4339870637926793571L, 67952L, false, false, (char) 32026, (char) 12312,
        Double.longBitsToDouble(0x3f8efcac7f5dbb40L), Double.longBitsToDouble(0x3fa95797cee60d70L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jun 11 13:35:47 PDT 257316963\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 9, "\ud903\udf21\uff25\ud95e\udd20\ud80d\udd66\ud9ea\udc73\ud94c\udfde", "\u508f\u06a8\ud643\u425d\ud17c\uad84\u6a8c\u7ba1\u8d32\u6838\u2ba8\u709d\uc2dc\u4f6e\u5a90\u10a0\u6f3f", "\ud966\udfdd\ud94d\ude73\ud814\udfce\udb7c\udd1f\uda95\ude68\ud909\ude43\ud8ee\udc1f\uda6f\udce6\udaa8\udd6e",
        20, 74072, -748089810, 8120076896982947797L, -18866L, true, true, (char) 57491, (char) 37147,
        Double.longBitsToDouble(0x3fe43604a2a0036dL), Double.longBitsToDouble(0x3fb475305473fc70L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.util.Date:Sun Dec 26 06:10:00 PST 138346410\012",
        Z.run(T, 1, 12, 10, 8, "\ud903\udf21\ud935\udf20\ud95e\udd20\ud80d\udd66\uae79\ud94c\udfde", "\u73d7\ub44b\ud643\u425d\ud17c\uad84\u6a8c\u7ba1\u21a5\u8677\u0cc7\u702f\u2398\u4f6e\u5a90\u55f6\u9b76", "\ud925\udd3d\udb4f\udd7e\ud814\udfce\udb7c\udd1f\uda95\ude68\ud909\ude43\ud8ee\udc1f\uda6f\udce6",
        12, 54385, 1272877072, -4365942772960251368L, -28049L, true, true, (char) 40801, (char) 40389,
        Double.longBitsToDouble(0x3fdff29596f7f828L), Double.longBitsToDouble(0x3fd4f9dc4d0d2220L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.util.Date:Sat Apr 24 18:16:19 PDT 280402573\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 4, 10, 9, "\ud903\udf21\ud935\udf20\ud95e\udd20\ud80d\udd66\udb67\ude76\ud94c\udfde", "\uc14e\ub44b\ud643\u425d\ud17c\uad84\u6a8c\u7ba1\u21a5\u8677\u0ca1\u702f\u2398\u63f8\ud0f1\u4b35\u3ad3", "\ud925\udd3d\udb4f\udd7e\ud814\udfce\ud9f5\ude0f\ud8c0\udcec\ud83d\udcc1\ud8e3\udfa7\uda6f\udce6",
        55, 63545, -1516827602, 8848588379562979611L, -28049L, true, true, (char) 40801, (char) 40389,
        Double.longBitsToDouble(0x3fea494ac93fbc1fL), Double.longBitsToDouble(0x3fce6bca7991e440L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jul 17 13:27:00 PDT 169911675\0121=java.util.Date:Wed Jul 17 13:27:00 PDT 169911675\012",
        Z.run(T, 2, 4, 4, 9, "\ud903\udf21\ud935\udf20\ud95e\udd20\ud80d\udd66\uae79\ud94c\udfde", "\uc14e\ub44b\ud643\u425d\ud17c\uad84\u6a8c\u1e65\u2139\u8677\u0ca1\u702f\u2398\u4f6e\u5a90\u7e69\u2f6d", "\ud925\udd3d\udb4f\udd7e\ud814\udfce\udb7c\udd1f\uda95\ude68\ud909\ude43\ud8ee\udc1f\uda6f\udce6",
        12, 54385, 1272877072, 5361832422160020145L, -28049L, true, true, (char) 40801, (char) 40389,
        Double.longBitsToDouble(0x3fc55d07d69fac30L), Double.longBitsToDouble(0x3fce6bca7a1a4440L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.util.Date:Wed Oct 26 00:15:52 PDT 267266918\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 9, "\ud8b5\uddc5\ud935\udfc0\ud95e\udd20\ud80d\udd66\uae79\ud94c\udfde\uda86\udcfc\udbdf\udf10\ud80d\udd95\udb7e\ude95\udaf1\udd7f\udba4\udce9\udba5\udc67\ud8ee\udc33\udb5f\udd8e\udb63\udffb\ud932\udf88\u53a0\udb31\udd7e\uda43\uded3", "\u5a90\u10a0\u6f3f\u419e\u33d9\u924f\u4fa8\ub1d7\u802a\u2ae6\u9e0f\u1bc3\uc0bb\ud24d\u2fdf\ua1fb\u2bb4\uaf74\u21cf\u9827\u3235\u7af9\ua900\u7166\u890a\u8d77\u733c\u6753\u4682\u3858", "\udbd2\udfa1\ud847\udf8e\udb0a\udd1a\ud9e2\ude03\ud963\ude2c\udb62\udc7e\udb00\udc90\udbc6\udd14\ud9f0\udc4b\ud900\udc4c\udaca\udc85\ud9f0\udf83\ud949\udfa2\ud9dd\udd16\udb8d\udf60\ud832\udee1\udb75\udfab\udb80\udff1\udb4d\udf77\udb05\ude94\ud8d8\ude6d\udb7d\udd6a\udb16\udfc6\udba5\udd18\ud90a\uddda\udb90\udc0a\uee7e\ud88e\udc9f\uda09\udf6f\udb88\udd37\uda4d\uddc6\ud840\udd6d",
        19, 1836, -50301774, 8434067161101352749L, -99550L, true, true, (char) 12373, (char) 63408,
        Double.longBitsToDouble(0x3fea9b09d913967eL), Double.longBitsToDouble(0x3fe49594b9cbdd70L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.util.Date:Thu Jan 05 14:47:11 PST 53404035\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 9, "\ud903\udf21\ud882\udc7d\ud81e\udfbf\uda71\udf89\udbf2\udf7b\udabd\udef7", "\ubc27\ub44b\ud643\u425d\uc0c7\u60b3\u6aa3\u31da\ud76d\u3c5f\u0ca1\u86d2\u3f34\uced1\u5a90\u10a0\u6f3f", "\ud925\udd3d\udb1d\udf7e\uda1d\udd86\ud85e\uddad\uda95\ude68\ud909\ude43\ud8ee\udc1f\uda6f\udce6",
        12, 94601, -1965295622, -1685365310279568838L, -28049L, true, true, (char) 50017, (char) 40389,
        Double.longBitsToDouble(0x3fea494ace0d5c57L), Double.longBitsToDouble(0x3febd55c94fa4584L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jul 17 13:28:00 PDT 169911675\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 10, 9, "\ud903\udf21\ud935\udf20\ud95e\udd20\ud80d\udd66\uae79\ud94c\udfde", "\uc14e\ub44b\ud643\u425d\ud17c\uad84\u6a8c\u7ba1\u21a5\u8677\u0ca1\u702f\u2398\u4f6e\u5a90\u10a0\u6f3f", "\ud925\udd3d\udb4f\udd7e\ud814\udfce\udb7c\udd1f\uda95\ude68\ud909\ude43\ud8ee\udc1f\uda6f\udce6",
        12, 54385, 1272877072, 5361832422160020145L, -28049L, true, true, (char) 40801, (char) 40389,
        Double.longBitsToDouble(0x3fea494ac93fbc1fL), Double.longBitsToDouble(0x3fce6bca7a1a4440L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jun 03 12:20:24 PST 151032480\0121=java.util.Date:Sun Jun 03 12:20:24 PST 151032480\012",
        Z.run(T, 2, 6, 6, 5, "\ud9bd\udfd4\ud935\udf3c\ud95e\udd20\ue1fb\ud8ba\udcb9\ud8fe\udce6\uda6b\udd5c\ud89d\ude39\ud808\udf18\uda09\udd40\udbad\udf9a\ud86c\udd33", "\u0226\u738e\u6b22\u928a\u7583\u6a70\u4f31\u42ac\u3b6b\u4911\u9c52\u419e\u33d9\ua6c1\u437d\u439a\ud65b\uc27d\u1d9b\u1bc3\u4d2d\u58b2\ua2ee\ua203\uc5ab\ud69a\u98b3\u2068\u1b42\ud33f\u99df\u9ff6\u37ba\ubebc\u562d\u5edc\u199f\ub733\u34ae\u651f\u4e0e\u3598\u901a\u3b9e\ua861\ubdbc\ud75f\u430a\ua3c4\u6276\u5a3d\u891b\u8e1b\u2860\u32f5\uc9e9\u61a2\ub407\u48ad\u1658\u43e9\u045b\uad7b\ub3f2\u80ae\u5409\u804c\u2109\ua407\u50d0\u21d1\u57e5\u9f89\ub315\u0cb8\u518a\ua562\ub75b\ud380\u4244\ua94e", "\ud91e\udcbf\ud99c\udfba\ud8df\ude7b\ud844\ude29\udbc2\uddb8\u5b4c\ud975\udfa8\udb82\udfe9\uda63\uddc3\udb25\udf80\ud845\udd23\udb71\udfa8\udb91\udca5\udad9\udd56\uda58\udeb8\ud8bb\udd10\udab7\udf38\udad7\udd88\ud97d\udf62\ud9ac\udd24\ud9e3\udea2\udb3b\udc24\udb9b\udc88\ud89b\udda6\udb92\udd31\udbd6\udec2\uda6f\uddc1\uebd6",
        23, 90505, 1815913416, -4766284773891575486L, -67085L, false, true, (char) 53368, (char) 20801,
        Double.longBitsToDouble(0x3fdeae2fb6a61910L), Double.longBitsToDouble(0x3fe877bb58f458a7L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.util.Date:Mon Jan 13 12:50:48 PST 276658510\012",
        Z.run(T, 1, 12, 14, 15, "\ud9bd\udf09\ud935\udf3c\ud95e\udd20\ud80d\udd66\ud9c0\udc8a\ud8d5\uddda\ud946\udfbc\ud997\udc83\ud97b\ude71\uda09\udd40\udbbd\udd81\uda2b\udd8b\ud97e\udc14\udb9c\udc38\ud899\udf1b\ud921\uddd3\ud901\udf2a\uda38\udce6\ud86b\uddbb\ud85f\udf94\ud980\udea4\udbba\ude64\ud926\uddf4\ud99d\udc04\udacf\udd0f\udbf1\udda8\udb66\udc25\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\udaf1\uded3\ud824\udf2b\ud8fb\ude24\u026d\uda57\udc88\ua2aa\udb81\udd44\ud8f8\udc6c\uda47\udc93\udaaa\uddb3\ud992\udce3\uda0c\udf47\udb1c\udfa7\ud957\udf3b\ud959\udee7", "\ua117\uca7e\u491b\u27ce\ud30d\uadd9\ua85c\u4f81\u3f25\u4d16\uc9ac\ud61f\u1144\u292a", "\ud883\udd35\uda68\udfee\ud805\udd1b\udb4e\udfc5",
        13, 88196, -1446486623, -8730740729876952325L, 22888L, false, true, (char) 51532, (char) 11218,
        Double.longBitsToDouble(0x3f5e6caa0d81a000L), Double.longBitsToDouble(0x3fddd3f2c7a47e1cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jul 11 20:48:53 PDT 2005046\012",
        Z.run(T, 1, 12, 8, 13, "\ud919\udcb5\uda1d\udff9\ud9a0\udd07\ud80c\udc3b\udb65\udfb5\ud8fe\udce6\ud8fc\udfc5\ud89d\ude61\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\ud801\udfc6\udb44\udfd7", "w\u9fe2\ucd59\u5a68", "\udbf5\udc8f\ud99b\udc63\ud919\ude8c\udb66\udc25\ud91f\udd3d\ud9ba\udd53\udb67\udcea\ud826\ude1a\ud89f\udd97\ud909\ude7f\ud931\udf0e\ud827\udfdb\udb76\udf59\uda1c\uddbb\udb77\udd09",
        14, 82596, -1565392405, 63210989792933987L, -82353L, true, false, (char) 62029, (char) 24297,
        Double.longBitsToDouble(0x3fe29980dd8ca81eL), Double.longBitsToDouble(0x3fe36bb2c5a7e7c3L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.util.Date:Tue May 13 00:00:00 PDT 248359670\012",
        Z.run(T, 1, 12, 5, 2, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\u7ca7\u6f27\u50cb\u259e\u527b\u5372\u0589\u75a4\u6b22\u928a\u995e\u6dd9\u78ec\u5d45\u5a90\u10a0\u9c52", "\ud91f\udd3d\ud893\udd80\uda9d\udd92\udba3\udc39\ud89f\ude1e\ud909\ude7f\ud8ee\udc1f\ud92c\udc8d",
        9, 2840, -1899221358, 7837412029193076780L, 59217L, true, true, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fd2dda31ca66196L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.util.Date:Mon Aug 17 12:00:00 PDT 247553857\0121=java.util.Date:Mon Aug 17 12:00:00 PDT 247553857\012",
        Z.run(T, 2, 12, 12, 14, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb3b\udf00\ud8d7\udf37", "\u7ca7\u6f27\u50cb\u259e\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u6dd9\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud890\udcd5\ud87c\udf8a\uda9d\udd92\udba3\udc39\ud89f\ude1e\ud909\ude7f\ud8ee\udc1f\ud92c\udc8d",
        9, 2840, 1272877072, 7811983035366981676L, -71855L, true, false, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fd2dda31ca66196L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.util.Date:Mon Aug 17 12:00:00 PDT 247553857\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 10, 2, "\ud9bd\udfc7\ud966\udc75\uda6c\udfab\ubd34\udb65\udfb5\ud8fe\udce6", "\u7ca7\u6f27\u50cb\u259e\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u6dd9\u78ec\u5d05\u8867\u42a6\u9c52", "\ud91f\udd3d\udac2\udcd3\udab9\udd5e\udba3\udc39\ud85b\udf9b\ud909\ude00\ud8ee\udc1f\ud92c\udc8d",
        9, 2840, 1272877072, 7811983035366981676L, 59052L, true, true, (char) 40858, (char) 7254,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fd2dda315230796L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 5, 2, "", "\ua883", "\u9c3c",
        -5, -1000, 193, -8476141736266039226L, -86831L, true, true, (char) 230, (char) 16715,
        Double.longBitsToDouble(0x3ea4963088800000L), Double.longBitsToDouble(0x3fea1b67c00000c6L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 15, "\ud8cf\udcd6", "\000\000", "\ud89d\ude1b\ud808\udf18\uda09\udd40\ud94f\udd0b\uda2b\udd05\ud97e\udc14\udb9c\udc38\ud899\udf1b\udb8b\udc85\udaf8\udd85\ud800\udd63\ud833\ude78\udba7\udf97\udbdb\udf8d\udbba\udeb8",
        11, 73098, 6293738, 0L, -100000L, false, false, (char) 27547, (char) 31760,
        Double.longBitsToDouble(0x3fe4145d7830ffd2L), Double.longBitsToDouble(0x3e40f41000000000L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.util.Date:Mon Feb 26 10:28:32 PST 173243207\0121=java.util.Date:Mon Feb 26 10:28:32 PST 173243207\012",
        Z.run(T, 2, 8, 8, 8, "\ud903\udf21\ud935\udf20\ud95e\udd9f\ud80d\uddc3\ua353\ud94c\udfde\udbd8\udec6\udbc9\udfa7\ud9b9\ude80\udb6c\udfd0\udaf1\udd7f\udba4\udce9", "\u6a77\u7ba1\u21a5\u8677\u0cc7\u702f\uc3c5\ud68a\uc10a", "\uda3b\udf6d\udb66\udc3e\uda4d\udcf7\ud923\udeae\ud846\udd7e\ud8a6\ude34\udab3\ude8c\ud909\ude43\ud8ee\udc1f",
        17, 63986, 531618385, 5466965395051712046L, 59750L, true, true, (char) 59279, (char) 59155,
        Double.longBitsToDouble(0x3fea4f208048a523L), Double.longBitsToDouble(0x3fd0f82a11f816feL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.util.Date:Mon Jan 10 05:18:00 PST 138346409\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 10, 8, "\ud903\udf21\ud935\udf20\ud95e\udd20\ud80d\udd66\uae79\udb55\udf83", "\ua369\u601a\uae7c\u41eb\u4cef\u44ae\u6a8c\u7ba1\u21a5\u8677\u0cc7\u702f\u2398\u4f6e\u5a90\u55f6\u9b76", "\ud925\udd3d\udb42\udc65\udbcf\udfee\udb7c\udd1f\uda95\ude68\ud909\ude43\ud8ee\udc1f\uda6f\udce6",
        12, 54385, 1623540588, -4365942771667328682L, -62526L, true, true, (char) 40801, (char) 40389,
        Double.longBitsToDouble(0x3fdff29596f7f828L), Double.longBitsToDouble(0x3fd4f9dc4d0d2220L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.util.Date:Wed Dec 03 16:26:00 PST 170345006\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 10, 9, "\uda26\udc3a\ud922\ude27\uda4f\ude96\ud94b\udc0a\ud838\uded9\udafa\udfe4", "\u088d\u5f42\u27d3\u425d\ud1a5\uad84\u791e\ucc50\u6d44\u2b40\u0ca4\u702f\u2398\u9a84\u2bfb\u10a0\u6f3f", "\udb1b\udd38\udb4f\udd7e\ud814\udfce\udb7c\udd1f\ud8ca\udd3b\ud905\ude57\ud8ee\udc1f\ud985\uddf2",
        12, 62845, 850148667, 5375507039684735665L, -28049L, true, true, (char) 40801, (char) 40389,
        Double.longBitsToDouble(0x3fed291acd7fa8deL), Double.longBitsToDouble(0x3fe8544a9fa7bd10L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jun 14 15:00:00 PST 86528985\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 10, 0, "\ud903\udf21", "\ud3d0\u152e", "\udbdf\udf10\ud80d\udd95\udb7e\ude95",
        11, 65509, -43463537, -2730709218533415604L, 88227L, false, false, (char) 43682, (char) 9813,
        Double.longBitsToDouble(0x3fd8194c7e400f48L), Double.longBitsToDouble(0x3fef565a22f1464fL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.util.Date:Mon Mar 07 00:00:00 PST 270450681\0121=java.util.Date:Mon Mar 07 00:00:00 PST 270450681\012",
        Z.run(T, 2, 12, 12, 14, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb3b\udf00\ud8d7\udf37", "\u200b\u6f27\u50cb\u259e\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u6dd9\u78ec\u5d05\u5a90\u10a0\u9c52", "\ud890\udcd5\ud87c\udf8a\uda9d\udd92\udba3\udc39\ud89f\ude1e\ud909\ude7f\ud8ee\udc1f\ud92c\udc8d",
        9, 2840, 1272877072, 8534536997164630060L, -71855L, true, false, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fd2dda31ca66196L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jul 26 00:00:00 PDT 247553857\0121=java.util.Date:Sun Jul 26 00:00:00 PDT 247553857\012",
        Z.run(T, 2, 12, 12, 14, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb3b\udf00\ud8d7\udf37", "\u7ca7\u6f27\u50cb\u259e\u527b\ua18c\u0226\u05dc\u6b22\u928a\u995e\u6dd9\u78ec\u7950\u5883\u10a0\u9c52", "\ud890\udcd5\ud87c\udf8a\uda9d\udd92\udba3\udc39\ud89f\ude1e\ud9f6\udddd\ud8ee\udc5e\ud92c\udc8d",
        9, 2840, 1261342736, 7811983033394610220L, -79887L, false, true, (char) 20296, (char) 53355,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fd2dda31ca66196L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jan 01 00:00:00 PST 1\0121=java.util.Date:Sat Jan 01 00:00:00 PST 1\012",
        Z.run(T, 2, 12, 12, 14, "\udbdd\ude9a\ud94f\ude12\ud95e\udd20\ud80d\udd66\udb3b\udf00\ud8d7\udf37", "\u99d7\u5b89\u3df0\u25e4\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u08ec\u78ec\u5d05\u5a90\u10a0\u9c52", "\udb2b\udfe3\ud996\udfb7\uda9d\udd12\udba3\udc39\ud89f\ude1e\ud909\ude7f\uda5d\ude02\udabb\udcd3",
        0, 35771, 687509520, 8534593216796704812L, -71855L, false, false, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b56981771e4L), Double.longBitsToDouble(0x3fd2dda31ca66196L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jan 01 00:00:00 PST 1\0121=java.util.Date:Sat Jan 01 00:00:00 PST 1\012",
        Z.run(T, 2, 12, 12, 14, "\udbdd\ude9a\ud94f\ude12\ud95e\udd20\ud80d\udd66\udb3b\udf00\ud8d7\udf37", "\u99d7\u5b89\u3df0\u25e4\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u08ec\u78ec\u5d05\u5a90\u10a0\u9c52", "\udb2b\udfe3\ud996\udfb7\uda9d\udd12\udba3\udc39\ud89f\ude1e\ud909\ude7f\uda5d\ude02\udabb\udcd3",
        0, 35771, 687509520, 8534593216796724268L, -71855L, false, false, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b56981771e4L), Double.longBitsToDouble(0x3fd2dda31ca66196L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.util.Date:Wed Sep 16 10:56:21 PDT 247553857\012",
        Z.run(T, 1, 2, 9, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb65\udfb5\ud8fe\udce6", "\uaed1\u04c7\u50e0\u7b2d\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u3cab\u78ec\u58fe\u5ae9\u10a0\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud89f\udd97\ud909\ude7f\ud8ee\udc1f\udb14\udd99",
        30, 2735, 1272877072, 7811983035366981676L, 59217L, true, true, (char) 40858, (char) 7332,
        Double.longBitsToDouble(0x3fe73b569e746ce4L), Double.longBitsToDouble(0x3fedf4b2ae214c8bL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.util.Date:Sat May 10 16:38:28 PDT 260299947\0121=java.util.Date:Sat May 10 16:38:28 PDT 260299947\012",
        Z.run(T, 2, 7, 7, 15, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ucd2d\ud8f0\udffb\ud8fe\udce6", "\u8716\u04f6\u50e0\u7b2d\u527b\uc1fb\u889a\u738e\u6b22\u928a\u995e\u3cab\u3864\u5d05\u5a90\u108a\u9c52", "\ud91f\udd3d\udb4f\udd7e\ud9e4\udf95\ud9ff\udec1\ud82a\udebd\ud909\udeaf\ud8ee\udc1f\udb14\udd99",
        30, 32239, 1272877072, 8214210777080278281L, 59217L, true, true, (char) 14366, (char) 33201,
        Double.longBitsToDouble(0x3fe73b5698176ce4L), Double.longBitsToDouble(0x3fdb827cfca66036L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.util.Date:Sat Aug 26 08:08:00 PST 24892279\0121=java.util.Date:Sat Aug 26 08:08:00 PST 24892279\012",
        Z.run(T, 2, 12, 12, 14, "\ud9bd\udfc7\ud935\udf3c\ud95e\udd20\ud80d\udd66\udb3b\udf00\ud8d7\udf37", "\u7ca7\u6f27\u50cb\u259e\u527b\ua18c\u0226\u05dc\u6b22\uc889\u995e\u6dd9\u78ec\u7950\u5883\u10a0\u4cea", "\ud890\udcd5\ud87c\udf8a",
        12, 59877, -1951443719, -785602699026744977L, 84731L, false, false, (char) 44990, (char) 2140,
        Double.longBitsToDouble(0x3fa63634ccbe0dd0L), Double.longBitsToDouble(0x3fd6f82013c41bf6L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 9, 15, "\ud978\udf1c\ud9f9\udec9\ud95e\udd20\ud80d\udd66\ud919\uddd2\ud8f8\uded2\ud8e1\udc36\udae3\uddf8\ud91d\udc08\ud815\udde1\ud941\udc03\ud96c\ude84\ud93b\ude25\ud837\uddf8\ud899\udf1b\udb77\udf3e\ud83e\ude0f\ud910\udd6e\ud9d9\udfd5\ud8c6\udcce\ud980\udf31\udb26\ude3d\udb56\udd2a\ud99d\udc04\udacf\udd0f\ud8d2\udd58\ud81b\udd49\ud964\udeb4\udb4f\udd7e\udb63\udc90\ud867\udc75\udabd\udf4f\udb00\udc86\udabd\udd18\udb08\ude48\ud968\udf1a\uda0b\ude28\ud904\ude45\uda10\udff9\uda77\udc3f\ud927\udc29\ud8aa\ude91\udbc3\uddc4\udaef\uded4\uda90\udc18\udb28\udf41\udb42\udccc\ua986\ud890\ude96\ud8ac\udf5e\udab2\udcae\udb56\udff4\uda01\udd45\ud97e\uddd7\ud98a\uddaf\ud952\udf91\udb37\udd04\udafd\udfba\ud801\udc57\ud8e9\udd8b\ud8d7\udc1a\ud9c4\udc1c\udb03\udca5\udb53\udf9e\udb9f\udff6\ucace\udb69\udee8\u1300\udb28\udea0\udbe1\udc16\ud850\udf0a\udb19\uded1\u9790\uda52\udd14\udae3\udea5\ud8d7\udf08\uda57\ude69\udb72\uded4\ud9a7\udc27\uda5f\ude69\udb44\udef5\udbe7\udf59\uda9f\udec7\udb96\udc45\udba8\udfc4\ud93c\ude44\ud81a\udc40\ud8a4\udfd4\ud951\udf64\udaa7\uddf1\ud9f7\ude3d\uda79\ude73\ud864\udffe\ud8a8\udf73\ud8b8\udfec\ud9f2\udc53\uda1b\ude98\ud977\udc61\udb6b\udd24\ud837\udf2e\uda11\udcf6\udb22\udd1a\uda9d\udfa0\ud812\uded2\udb49\ude82\uda6b\udea8\ud9fb\udd49\udb2c\udddd\uda95\udee1\uda98\udf97\ud8be\udc75\ud98e\udc4f\u7f77\uda18\udd47\ud8bb\ude1d\ud8f7\udccf\udbc7\udc35\ud9ba\udc07\udb8e\udc71", "\u34c5\u8d5d\u5bf5\uc2d1\u4938\u954a\u285c", "\ud92d\udcf8\udb25\udcb6\ud9c0\udcf1\ud9a7\udf1b\ud95b\udcd0\udb7c\udd11\ud9c6\uddef\ud909\udc63\ud849\udcd2\udb9d\udebe\udad1\udd93\udb97\udffb\udb39\udf4d\ub14e",
        -3, 17501, 204497936, -4827510275574833868L, -35933L, true, false, (char) 32687, (char) 12498,
        Double.longBitsToDouble(0x3fc70fedac0cc054L), Double.longBitsToDouble(0x3fe59e0627653d52L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.util.Date:Mon Jul 24 00:05:38 PST 406425\0121=java.util.Date:Mon Jul 24 00:05:38 PST 406425\012",
        Z.run(T, 2, 12, 12, 14, "\udbdd\ude9a\ud94f\ude12\ud95e\udd20\ud80d\udd66\udb3b\udf00\ud8d7\udf37", "\u99d7\u5b89\u3df0\u25e4\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u08ec\u78ec\u5d05\u5a90\u10d8\u744d", "\udb2b\udfe3\ud996\udfb7",
        14, 59877, -1951443719, -12887915673261694L, -65071L, true, true, (char) 44990, (char) 8266,
        Double.longBitsToDouble(0x3fa63b386bffda00L), Double.longBitsToDouble(0x3fe07c1662641ed7L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 9, 15, "\udab6\udf7a\uda2e\udd69\ud9b7\udd5d\ud80d\udd66\ud919\uddd2\ud8f8\uded2\ud8e1\udc36\udae3\uddf8\ud91d\udc08\ud815\ude8e\ud941\udc03\ud96c\ude84\ud93b\ude25\ud837\uddf8\ud899\udf1b\ud990\udca2\ud83e\ude0f\ud910\udd6e\ud9d9\udfd5\ud8c6\udcce\ud980\udf31\udb26\ude3d\udb56\udd2a\ud99d\udc04\udacf\udd0f\ud8d2\udd58\ud81b\udd49\ud964\udeb4\udaa2\udf27\ud98b\udc4a\ud867\udc75\udabd\udf4f\udb00\udc86\udabd\udd18\udb08\ude48\ud92c\udfbc\ud8b9\udff5\ud904\ude45\uda10\udff9\uda77\udc3f\ud927\udc29\ud8aa\ude91\udbc3\uddc4\udaef\uded4\uda90\udc18\udb28\udf41\udb42\udccc\ua986\ud9a4\udee5\uda59\udcf6\ud9e5\udef7\udb56\udff4\uda01\udd45\ud97e\uddd7\ud8e8\udf1d\ud952\udf91\udb37\udd04\udafd\udfba\ud801\udc57\ud8e9\udd8b\ud8d7\udc1a\ud9c4\udc1c\udaca\udc68\ud9ac\udfd7\uda73\udf84\ud8fe\udd2f\udb69\udee8\u1300\udb28\udea0\udbe1\udc16\ud850\udf0a\udb19\uded1\u9790\ud98d\uded3\udae3\udea5\ud8d7\udf08\uda57\ude69\udb72\uded4\ud9a7\udc27\uda5f\ude69\udb44\udef5\udbe7\udf59\uda9f\udec7\udb96\udc45\udba8\udfc4\ud93c\ude44\udbce\udf57\ud8a4\udfd4\ud951\udf64\udaa7\uddf1\ud9f7\ude3d\uda79\ude73\ud864\udffe\ud8a8\udf73\ud8b8\udfec\ud9f2\udc53\uda1b\ude98\ud977\udc61\udb6b\udd24\udb63\udf04\ud866\udc07\ud854\udd6b\uda53\udd40\ud9fa\uddfe\udb49\ude82\uda6b\udea8\ud9fb\udd49\udb2c\udddd\uda95\udee1\ud95a\ude52\uda47\udce2\ud98e\udc4f\u7f77\udbd6\udf26\ud8bb\ude1d\ud8f7\udccf\udbc7\udc35\ud9ba\udc07\udb8e\udc71", "\u34c5\u8d5d\u5bf5\u7361\uac58\u24bf\u22cc", "\ud92d\udcf8\udb25\udcb6\ud9c0\udcf1\ud9a7\udf1b\ud95b\udcd0\udb7c\udd11\ud9c6\uddef\ud909\udc63\udb5b\udd02\udbb8\udfdb\udad1\udd93\udb97\udffb\udb21\udf4d\ub14e",
        -3, 17501, 204497936, -4827510275833504460L, 98077L, true, false, (char) 32687, (char) 12498,
        Double.longBitsToDouble(0x3fc70fedac0cc054L), Double.longBitsToDouble(0x3fe59e0627653d52L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.util.Date:Mon Jul 24 00:05:39 PST 406425\0121=java.util.Date:Mon Jul 24 00:05:39 PST 406425\012",
        Z.run(T, 2, 12, 12, 14, "\udbd0\uddbf\ud94f\ude12\ud95e\udd20\ud80d\udd66\udb3b\udf00\ud8d7\udf37", "\u99d7\u5b89\u3df0\u25e4\u527b\ua18c\u0226\u738e\u6b22\u928a\u995e\u08ec\u78ec\u5d05\u5a90\u10d8\u8249", "\udb2b\udfe3\u0277",
        13, 59877, -1951443719, -12887915673261694L, -65071L, true, true, (char) 44990, (char) 8266,
        Double.longBitsToDouble(0x3fa63b386bffda00L), Double.longBitsToDouble(0x3fe07c1662641ed7L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.time.DateUtils|isSameLocalTime|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang3.time.DateUtils|add|java.util.Date,int,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addDays|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addHours|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addMilliseconds|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addMinutes|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addMonths|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addSeconds|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addWeeks|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addYears|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|ceiling|java.util.Calendar,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|ceiling|java.lang.Object,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|ceiling|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|getFragment|java.util.Calendar,int,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|getFragment|java.util.Date,int,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|getFragmentInDays|java.util.Calendar,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|isSameLocalTime|java.util.Calendar,java.util.Calendar|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
