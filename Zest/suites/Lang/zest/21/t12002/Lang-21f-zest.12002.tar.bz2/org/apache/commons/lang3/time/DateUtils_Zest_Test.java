package org.apache.commons.lang3.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u7ef8", "\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6",
        0, 88864, -1240506799, 8274663888167686999L, 66362L, false, false, (char) 38263, (char) 31772,
        Double.longBitsToDouble(0x3fe1307c3f65d5a4L), Double.longBitsToDouble(0x3fdd5e83b8cdf934L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u079c\u5ead\ub65b\uaac4\u47f4\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u8e96\u35cc\uca45", "\udb70\udcdf\ud9a5\ude12",
        -4, 71134, 1752307995, 5221333595731784876L, -45897L, false, false, (char) 20924, (char) 44974,
        Double.longBitsToDouble(0x3feaf0ac93dd403fL), Double.longBitsToDouble(0x3fe1307c3f65d5a4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\u1c8c\u9af5\ud226\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\uaefa\u625d", "\u38a6\udb15\udf3f\ud95d\udf57\udb9d\uddb3\uda5f\udca7\ud84d\udd46\ud8b9\ude46\ud8f9\udee6\udb8c\ude91\udae4\udc9b\ud9ef\udcf5",
        59, 82575, 1323042318, -7506088896841598447L, -89605L, true, true, (char) 43264, (char) 450,
        Double.longBitsToDouble(0x3fbe4f54b8af3be8L), Double.longBitsToDouble(0x3fd30979d3482036L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u5974\u8e0d", "\udb0c\udc4c\ud9a1\ude76\ud9b8\udde2\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6\udb96\udf91\udae4\udc9b\ud9e0\uddf5\udba9\udf9a\uac70\udaef\udf0b",
        25, 79434, 1077903454, -466338216746417626L, -29813L, false, false, (char) 46896, (char) 12744,
        Double.longBitsToDouble(0x3fe9f0363be4d4feL), Double.longBitsToDouble(0x3fc49e97d14d6bd8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\uda7f\udf7e\udbb3\udcd0\ud8cd\ude73\ud8c7\udd19\ud8a2\udf51", "\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1", "\uda6b\udfa8\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda5f\udca7",
        22, 65428, -1179363235, 3973352801090563704L, 63081L, true, true, (char) 60425, (char) 20924,
        Double.longBitsToDouble(0x3fe1d2bb285e151aL), Double.longBitsToDouble(0x3feeea01fa260f87L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u0dac\ua1a3\ucc5a\u71c3", "\ud880\uddd6\udb13\udebe\ud827\udd31",
        30, 6058, 1521741519, 7380076625677275369L, -46938L, false, false, (char) 57438, (char) 60447,
        Double.longBitsToDouble(0x3fcd6d31c46d7140L), Double.longBitsToDouble(0x3fcf83ef51f838dcL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07", "\u3ff7\u089a\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u3416\u387d\u33d6\ua3e1\u7ef1\u18c4\u7ef8\u8980\u33e4\u45b9\u5989\ua0c4\ud60f\u4798\u5e5d\u87d1\ub7ef\u80ac\ub17f\u8eae\u1b11\ud223\u3ee5\u25bb\u7b3d\u0127\u6178\u07b7\ub8cd\ud1ce\u41e6\uc444\uc014\u1680\u4e29\u479e\u8d15\u5c3e\u3bc9\u2f68\ubd10\ua06a\u87f9\u24b2\uab98\u73dc\u95ca\u7d8f\u4ce6\ua6b0\u732d\u22bd\uc404\u2150\u8c6e\ud247\u1e0c\uacdb\u36eb\uccb6\uac4f\u9db0\u1cf6\u7248\u1cef\ucc35\u319c\u7aa5\ubd4d\u82ee\u1f1a\u823a", "\udb47\udcbc\ud9f2\udefb\ud9b7\ude18\ud9e3\udec6\udb39\udeee\ud8cf\udf15",
        10, 31561, 1056798306, -8010029171996926219L, 29389L, true, false, (char) 12655, (char) 50188,
        Double.longBitsToDouble(0x3fea988cb94e2652L), Double.longBitsToDouble(0x3fd35c6c8b6e3efaL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 1, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u2e42\u4d18\u1b1f\u97cf\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u7ef8", "\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6",
        0, 88864, -1240506799, 8274663888167686999L, 66362L, false, false, (char) 9546, (char) 58201,
        Double.longBitsToDouble(0x3fe1307c3f65d5a4L), Double.longBitsToDouble(0x3fdd5e83b8cdf934L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.Date:Fri Mar 08 09:41:46 PST 262215630\0121=java.util.Date:Thu Apr 04 09:14:46 PDT 262215630\012",
        Z.run(T, 2, 5, 2, 10, "\ud8eb\ude2d\uda1a\udcc7\ud800\udc02", "\u389b\u5ead\u983f\u2587\u545f\u4d0a\ubb68\u0832\u387d\uc902\u8ec7\u7e69\u58c4\u5cee", "\udb70\udcdf\ud83b\udcaa\ud9d2\udfd2\udb9d\uddb3\udaf1\udcf1\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6",
        27, 22296, -1232310665, 8274663888167686999L, 66362L, false, true, (char) 8380, (char) 31772,
        Double.longBitsToDouble(0x3fe1307c3fc7d5a4L), Double.longBitsToDouble(0x3fdcf153b3ead3deL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\udb51\udd86\u7998\ud8cd\ude73\ud8c7\udd19\ud8a2\udf51\ud952\udcb8\udb2e\udd7a\ud93c\udf9b\udbcc\udcd9\uda7d\uddd3\u928e\u930f\udb4f\udd0b\ud982\udd32\ud91e\udd5b\udafd\udd81\udaf7\udc26\ud985\udf76\ud857\ude0c\ud956\udf68\udb5e\udfe2\ud9b8\uddde\udb9d\uddb3\ud8cd\ude9d\ud977\udeaa\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\ud989\udc78\uda17\udc01\udb3d\udd5a\ud8f5\udc27\ud8e5\udc10\udbc1\udfa6\udb53\udd73\udaef\udcb7\udace\udd16\uda1d\udf05\udb89\ude05\ud946\ude79\udba7\udcb8\ud88a\uddd9\udad2\udffa\uda1e\ude53\uda9a\udeed\ud8aa\udcf4\udbaf\udc7b\ud899\ude04\udb59\udfa6", "\ub728\ucd59\u3de8\ub757\u3d9d\u96b0\u25c7\u3d32\u960e", "\udbf7\udf15\ud8b8\ude6c\udbbd\udf37",
        21, 45928, 1725706125, -1562911229010143649L, 9918L, false, true, (char) 34879, (char) 50815,
        Double.longBitsToDouble(0x3fe66b7e3d8e023dL), Double.longBitsToDouble(0x3fef9608a62f1739L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\uda2c\udd7f\u69fa", "\u8dcf\u7075\u9893\u2e02\u30ec\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u47d7\u716b\u298d\u8980\u7af9\u45b9\u1693\ua0b2\ud60f\ub855\u9f66\u87d1\ub7ef\u92e3\u0567", "\ud807\udd34\uda69\udfe8\ud9cf\udfbe\ud978\udf78\ud8f5\udc27\udab5\ude0f\uda5d\udc72\ud924\udf5b\ud8ad\udfb5\udaa3\ude3c\udb51\udd7e\ud96c\udf15\ud95d\udc3c\udab2\ude24\ud989\udcca\udaac\udfed\ud82e\udd44\ud8c1\udeb4\udb75\udee3\udaa1\udf64\uda31\udea9",
        -5, 1998, 1124720803, -5503607461491773681L, -64753L, false, false, (char) 52160, (char) 18176,
        Double.longBitsToDouble(0x3fe765830efdcdd5L), Double.longBitsToDouble(0x3fe500536ea92974L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 10, 2, 10, "\ud917\udf03\udace\udc92\udaef\udedf", "\u389b\u5ead\ub65b\uaac4\u545f", "\udb13\udebe\ud8e9\uddd3",
        30, 6058, 440733647, -9004414331889561571L, -70513L, false, false, (char) 24359, (char) 65190,
        Double.longBitsToDouble(0x3faf34c711b5ca80L), Double.longBitsToDouble(0x3fcf968f52b12024L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 10, "\ud9e2\udd26\ud811\udff2\000", "\u598c\u5ead\000\ua9e6\ud625\u4cfd\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\000", "\000\uda09\udda4\ud956\udfb2\udbd9\udd6b\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud998\udf15",
        10, 88744, -1240506799, 8214565720759784279L, -34426L, false, false, (char) 0, (char) 15104,
        Double.longBitsToDouble(0x3fa307c380000000L), Double.longBitsToDouble(0x3fdd5e8008cdf934L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u7ef8", "\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6",
        0, 88864, -1240506799, 8274663888167686999L, 66362L, false, false, (char) 38263, (char) 31772,
        Double.longBitsToDouble(0x3fe1307c3f65d5a4L), Double.longBitsToDouble(0x3fdd5e83b8cdf934L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u501d", "\udb70\udcdf",
        16, 84826, 1554563134, -5442009594760404740L, -96680L, false, true, (char) 42396, (char) 33439,
        Double.longBitsToDouble(0x3fe7bdb07b5772d5L), Double.longBitsToDouble(0x3fe070cfe626db95L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.Date:Mon Aug 09 17:34:19 PDT 275609238\0121=java.util.Date:Mon Aug 09 17:34:19 PDT 275609238\012",
        Z.run(T, 2, 9, 2, 10, "\uda42\udebd\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\uabf4\u6915\ubb68\u0f03\u384d\u33d6\ua3e1\u0cde\u7fd8\u7ef8", "\udb70\udcdf\udb96\udeaa\udb04\udc47\udb9d\uddb3\ud977\udd93\udb36\udf20\ud8bc\ude0b\ud8f9\udee6",
        0, 88864, -1643159983, 8697325346267659207L, 958L, true, true, (char) 4525, (char) 44297,
        Double.longBitsToDouble(0x3fdd5e83b8cdf934L), Double.longBitsToDouble(0x3fde716bcf2661f4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.Date:Mon Nov 28 22:24:43 PST 125912507\012",
        Z.run(T, 1, 5, 2, 10, "\ud9e2\ude07\ud875\udea4", "\u089a\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u91f9\u5f92\u5dff", "\udafd\udd81\uda6b\udfa8\udbec\udc8a\ud9e2\uddc2\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda5f\udca7",
        22, 45124, -1176243448, 3973352801090563704L, 63081L, true, true, (char) 60228, (char) 20924,
        Double.longBitsToDouble(0x3fe1d2bb285e151aL), Double.longBitsToDouble(0x3feeea01fa260f87L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u215c\ua4bb", "\udbd7\uddcf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\ud83e\udd97\uda74\udd76\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91",
        49, 75201, 1926595319, 1836012168111575566L, -40038L, false, false, (char) 31772, (char) 4525,
        Double.longBitsToDouble(0x3feb2ead25d5e83bL), Double.longBitsToDouble(0x3fb9bf2681fbf2d0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.Date:Thu Feb 01 23:30:53 PST 214103202\0121=java.util.Date:Thu Feb 01 23:30:53 PST 214103202\012",
        Z.run(T, 2, 2, 2, 10, "\ud810\udf14\ud827\udf32\udbf3\udcd1\ud8cb\udc76\ud955\udf37\ud880\udce3\ud9f7\udf63\ud940\udd4a\udbe2\udf1a", "\ubb68\u5414\u0f09", "\ud91e\udcda\ud8c6\ude65",
        35, 52170, -1106959313, -6756645343480146218L, -50786L, true, false, (char) 59259, (char) 59601,
        Double.longBitsToDouble(0x3fd98343dea5732aL), Double.longBitsToDouble(0x3feb28b12651243bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 0, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\uc55f", "\udb70\udcdf",
        16, 84826, 1554563134, -5442009594749510608L, -96680L, false, true, (char) 42396, (char) 33439,
        Double.longBitsToDouble(0x3fe7bdb07b5772d5L), Double.longBitsToDouble(0x3fe870cfe626db95L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 10, "\udac3\ude0e\udace\udd10\u6a6b", "\u389b\u2e9e\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\ud3fa\ua3e1\u7ef1\u18c4\u7ef8", "\u4455",
        7, 84826, 1554563134, -5442009594760404740L, -96680L, false, true, (char) 42382, (char) 33439,
        Double.longBitsToDouble(0x3fe7bdb07b5772d5L), Double.longBitsToDouble(0x3fe070cfe626db95L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 13, 5, "\ud9e2\ude07\udace\udd10\u6a6b", "\u2d0c\u5ead\ub65b\uaac4\u545f\ua343\ubb8a\u0832\u3853\u36d6\ua3e1\ub275\ua3e2\u7ef8", "\udb70\udcdf\ud8c7\udd23\ud9e2\uddd6\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6",
        0, 88864, -1240506799, 8274663885632064599L, 66362L, false, false, (char) 38263, (char) 31772,
        Double.longBitsToDouble(0x3fe1307c3f65d5a4L), Double.longBitsToDouble(0x3fdd5e83b8cdf934L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.util.Date:Tue Mar 10 05:00:41 PST 160083942\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 10, 10, "\udaf7\udf0e\udb26\udd7e\u6a6b", "\u389b\u5ead\u33d7\ua656\u7d8a\u7275\ubb68\u5f0a\uc23a\u33d6\ua3e1\u7ef1\u18c4\u1915", "\udb70\udced\ud9a5\ude12\ud9b8\udde2\ud889\ude29",
        28, 74796, -748201812, -5051927140369158318L, -67643L, false, true, (char) 51311, (char) 32840,
        Double.longBitsToDouble(0x3fb785469d4c91f8L), Double.longBitsToDouble(0x3fe134389765d5a4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\udaf4\udd50\udace\udd10\udb5c\udc8b", "\u397f", "\udbe2\udf1a\ud93c\udf9b",
        22, 84826, -455075752, -7507003636407510169L, -30417L, true, true, (char) 54054, (char) 41523,
        Double.longBitsToDouble(0x3fe97af1361065d8L), Double.longBitsToDouble(0x3fb9e9fddd56c3a8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Tue Sep 22 05:57:49 PDT 48193739\012",
        Z.run(T, 2, 0, 2, 10, "\ud9e2\ude07", "\u3ff7\u089a\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1", "\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda58\udfa7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91x\000\ud9ac\udcc4",
        45, 9646, 1466267174, 1520785360097869918L, -100000L, true, true, (char) 54800, (char) 43264,
        Double.longBitsToDouble(0x3feae68d57a16972L), Double.longBitsToDouble(0x3fe49f1da13d00fdL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 2, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\ucb09\u6a44\uaac4\u545f\u76d1\uce3f\u08a6", "\udb9b\udff8\udb21\udeff\udb0a\ude87\uda81\udd8e\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud9bd\ude12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udd86\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\u6b04\ud975\ude78\ud8f5\udc27\uda0c\uddba\udbc1\udfa6\ud9a9\uddfe\ud8e0\udca6\udb8e\udcbf\udabb\udeac\udb3c\udd81",
        39, 65673, 147557780, 5205992246316249913L, 78561L, true, false, (char) 35777, (char) 2908,
        Double.longBitsToDouble(0x3fe14e57f344ac08L), Double.longBitsToDouble(0x3fc28158ebcb4b48L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.util.Date:Tue May 19 18:11:04 PST 168825537\012",
        Z.run(T, 1, 6, 2, 10, "\ud9e2\ude07\udace\udd10\ud9b7\ude4d", "\u389b", "\udb4e\udd42\ud8a1\udd07\udbcc\udcf9\ud880\uddd6\uda3f\udcd2\ud8e9\uddd3\udb5e\uddc9\ud982\udd32\ud91e\udd5b\udad7\udd81\ud894\ude3d\ud965\ude34\udb24\udd32\udb70\udd6f\uda27\udd33\udbf9\uddad\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b",
        54, 58290, -1543410056, -5327791032116935945L, -28890L, false, false, (char) 31716, (char) 4525,
        Double.longBitsToDouble(0x3feb2ead26d5e83bL), Double.longBitsToDouble(0x3fb9bf26a0ee3100L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 2, 10, "\ud9e2\udd76\udace\udd10\u6a6b\ud99e\udd79\ud8cd\ude73\ud8c7\udd19\ud8a2\udf51\ud952\udcb8\udbe2\udf1a\ud93c\udf9b\udbcc\udcd9\ud880\uddd6\udb13\udebe\ud8e9\uddd3\udb5e\uddc9\ud982\udd32\ud91e\udd5b\udafd\udd81\uda6b\udfa8\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6\udb84\udc91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda27\udf3d\ud9ec\udfac\ud978\udf78\ud8f5\udc27\ud8e5\udcc7\udbc1\udfa6\uda7d\udd58\udb15\udda1\ud995\udcfb\ud9cb\udf15\udb03\uddc2\ud8c7\udce1\ud94c\uddb8\ud9bf\uddda\udb0d\udfac", "\u7f5c\u3063\u10d8\ubcf3\u7a80\u7711\u2d19\u914d\ub2e0", "\ud912\udcec",
        41, 95899, -1973175085, -4025644990091855642L, 45899L, true, false, (char) 12895, (char) 37232,
        Double.longBitsToDouble(0x3fe5fc8359671c77L), Double.longBitsToDouble(0x3fe076c56c0562c1L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 3, 7, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u00d1\u3d30\ubb68\u0832\uc01a\u33d6\ua3e1\u29f2\u18c4\u7ef8", "\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\ud9d1\udc0d\udb1f\udcb4\udb37\udcfc\ud944\udecf\ud8c9\udcdf",
        32, 47968, -831838755, 8255064539351798615L, 96702L, true, true, (char) 37965, (char) 44364,
        Double.longBitsToDouble(0x3fdd5e83b8cdf934L), Double.longBitsToDouble(0x3fce70f908aea09cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 2, 10, "\ud9e2\ude07\udace\udce7\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\ucb28\u0ec6\u33d6\u1e40\u054e\u18c4\u7ef8", "\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udf1f",
        0, 88864, -1240506799, 8274663888167686999L, 66362L, false, false, (char) 19320, (char) 15725,
        Double.longBitsToDouble(0x3fe8bec3dc65e55dL), Double.longBitsToDouble(0x3fe43f001a496162L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.util.Date:Thu Mar 04 23:01:59 PST 290206658\0121=java.util.Date:Mon Jul 13 23:01:59 PDT 290206657\012",
        Z.run(T, 2, 8, 2, 10, "\ud9e2\ude07\u290f\udbd4\udf08", "\u389b\u5c4f\u17a3\u3b09\u3ea5\u4d0a\ubb68\u0832\u3786\u245c\ua3e1\uc492", "\ud985\udf76\ud9e0\udd2f\ud91b\udd00\udada\udc0e\ud9b8\udde0\udb9d\uddb3\udbc3\udf99\u0157\ud94a\udd1c\udbcb\udd0e\udba3\udf40\ud9fd\udc3a\uda7c\ude7d\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\ud9fc\ude75\ud978\udf78\ud82d\ude86\ud8e5\udcc7\ud8b4\udcee\ud9ad\udd29\ud95b\udda4",
        39, 7137, 1599953780, 9157975391282519921L, -53767L, true, true, (char) 60257, (char) 54552,
        Double.longBitsToDouble(0x3f66a0e9363c4300L), Double.longBitsToDouble(0x3fe0f46d6e847f8fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud864\ude08", "\u3ff7\u089a\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\uc809\u4a32\u387d\u33d6\ua3e1\u9795\u0d6e\u7ef8\u7392\u16f5\u4642\u5989\ua0c4\ud6ae\u4798\u5e5d\u87d1\u4cdb\u271e\ub17f\u8eae\u1b11\ud223\u3ee5\u25bb\u7b3d\u9483\u6644\u87f1\u033a\ud1ce\uc440\u9208\u1dde\u178e\u1b19\uc0be\u18e0\ubc89\u8696\u2df1\u2ba4\u2291\ua39b\ubbb3\ubf2d\u45f2\u85e8\u7b8d\u6952\uaa2a\u86d1\u82bb\ub2f0\u902f\u6163\u9293\u7721\u2200\ub8bd\u297a\u95c3\u060b\ub493\ud623\u76c1\u3646\uc2ae\ubbd5\u4f75\u1f4c\u9260\u3d30", "\uda66\udd0f\udaf0\udfec",
        6, 20594, -327895519, 513932922376464843L, 62461L, false, true, (char) 11943, (char) 3043,
        Double.longBitsToDouble(0x3fdc5df2a72ebcc8L), Double.longBitsToDouble(0x3fe8037060f775d7L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\000\ua9e6\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u7ef8", "\udb70\udcdf",
        16, 70714, 1543503872, -5442009594760404740L, -96680L, false, true, (char) 42396, (char) 24223,
        Double.longBitsToDouble(0x3e8e000000000000L), Double.longBitsToDouble(0x3fe070c80626db95L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.util.Date:Fri Nov 19 14:32:41 PST 146706888\0121=java.util.Date:Thu Apr 14 17:32:41 PDT 146706889\012",
        Z.run(T, 2, 3, 8, 10, "\ud9aa\udc41\ud909\ude02\u8416", "\u1ef2\ub0b1\ub5c9\uaac4\u545f\u4d0a\ubb68\u0832\ua555\u33d6\ua3e1\u1c46\uc50b\u9bd7", "\ud8ed\udf59\ud9a5\ude12\ud9b8\udde2\udb9d\uddf2\ud9f7\uddf3\udbe0\udc3a\ud8bc\ude0b\ud8f0\udfe6\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf",
        21, 49174, 354085434, 4629560083435961309L, -89605L, true, true, (char) 43264, (char) 60402,
        Double.longBitsToDouble(0x3fd3240e887d5e1eL), Double.longBitsToDouble(0x3fd1ea5d9ba07d7cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 11, 14, 15, "\ud9e2\uddaf\udace\udd10", "\u089a\u389b\u5ead\ub65b\uaac4\u94de\ucdf5\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u7ef8\u8980\u02b5\u379b\u9e69\ua0c4\ud60f\u4798\u5e5d", "\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\uc55f\ud807\udd2f\uda69\udfe8\ud9ec\udf4c\ud978\udf78\ud8f5\udc27\ud8e5\udcc7\ud877\udfa1\ud9a9\uddfe\udb15\udda1\ud807\udff4\uda78\ude3c\ud9e9\udfff\ud895\udeb9\uda30\udd81\uda1d\udd46",
        -1, 25990, 504217698, 5320290922595294527L, -92841L, true, false, (char) 57483, (char) 53012,
        Double.longBitsToDouble(0x3fc4cab9b877dc40L), Double.longBitsToDouble(0x3fee77bdc0ed065cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 12, 10, "\ud9e2\ude07\udace\udd10\u6a6b\uda26\ude56\uda2d\udc99\ud8c7\udd19\ua154\udbb1\udebb\udbe2\udf1a\udb02\udf38\udb57\udeb2\udb3f\uddee\ud8c0\udd4a", "\ua3e1\u7ef1\u18c4\u856c\u4660\u99cb", "\ud9b8\udde2\udb9d\uddb3\udb61\udca8\udb37\udd3a\u72db\ud8f3\udfe6\udae4\udc9e\udacf\udfcf\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\udba8\udf48\ud9e5\udf63\ud883\udd13\ud8f5\udc27\udb9f\udcc4\ud9b2\udcaa\ud9c7\udcf5\udbdb\udd17\uda69\udde4\udb57\udd48\ud949\uddca\ud883\udcf3\ud8a9\ude1b\ud81a\udd86\ud846\udce8\ud90b\ude6a\ud9a2\udcbb\uda75\udf9b\ub634\udbaa\udc49\udb1c\ude36\uda36\udc9b\udafb\ude6c\ud8f1\udc05\ud94c\udef1\ud927\udf95\udbff\udd86\ud9f6\uddb6\ud88a\udd3f\ud806\udee1\u478c\udb5c\udc86\ud9ab\udc32\ud94f\udc1a\ud828\uded1",
        40, 45625, 2112933467, 6114319026386930547L, -15662L, false, false, (char) 20451, (char) 7566,
        Double.longBitsToDouble(0x3fee9904df5b5db5L), Double.longBitsToDouble(0x3feed02b6ffbd30aL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.Date:Fri May 07 06:52:29 PST 168830139\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 12, 10, "\ud9e2\ude07\ud9eb\udd34\ud977\ude60\udb9c\ude0f\ud89d\udce8\ud8c7\udd19\ud9ce\uddd7\ud985\udf27\udbe2\udf1a\ud96d\udcd3\udbaa\udce5\ud880\uddd6\udb13\udebe\ud9ad\udc7b\ud97b\ude6c\ud863\udcb3", "\u7ef8\u8980\u98e4\u45b9\u5989\ub2f0\ud60f", "\uda47\udf91",
        18, 58290, 609119864, -5327936130244050185L, -12346L, false, false, (char) 16799, (char) 24610,
        Double.longBitsToDouble(0x3fe6ea01fe0286aaL), Double.longBitsToDouble(0x3feb2d1936d5e83bL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 2, 10, "\ud9e2\udd9c\udace\udd10\u6a6b\ud99e\udd79\ud9e5\udc3d", "\ub65b\u8485\u54c6\u4d0a\ubb68\uafec\u37ab\u33d6\ua3e1\u7ef1", "\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\ud969\udcab\u9e97\ud8bc\ude0b\udbf6\udffd\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb",
        45, 9646, 1466246985, -5474280128022378772L, -99450L, false, true, (char) 36319, (char) 10523,
        Double.longBitsToDouble(0x3fe034634ea02f88L), Double.longBitsToDouble(0x3fe083eeac7e8369L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u4978", "\uda1a\ude93\ud96b\udf1d\udb32\ude24\ud96a\uddad\uda93\udc09\udb37\udcf1\ud8bc\ude0b\ud8f9\udee6",
        0, 88864, -1240506799, -1211605776951105527L, 66362L, false, false, (char) 38263, (char) 31772,
        Double.longBitsToDouble(0x3fe1307c3f65d5a4L), Double.longBitsToDouble(0x3fc59d076e602668L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.util.Date:Sat Nov 27 00:01:34 PST 146706888\0121=java.util.Date:Fri Dec 24 00:01:34 PST 146706888\012",
        Z.run(T, 2, 4, 2, 10, "\ud9e2\ude07\udb2f\udf40\u7bba\ud99e\udd79\ud996\udf57\ud8c7\udd19\ud9a9\udc1e\u84d6\ud97e\udfaf\ud93d\udc39\udbcc\udcd9\udb6d\ude4b\ud8bf\udc54", "\u5cff\u7ef1", "\ud985\udedc\ud96e\ude14\udb70\udce7\ud9a5\ude12\ud9e5\udcb7\ud9bf\ude42\udb96\udd55\udbd9\udd41\udad9\udc95\udabb\udfb6\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf",
        27, 72838, 354085474, 4629560084150494415L, -24069L, false, true, (char) 45224, (char) 23447,
        Double.longBitsToDouble(0x3fd088c6a76db9d2L), Double.longBitsToDouble(0x3fe51d504c78148bL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\uc7e3\000", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\u41ee\u07da\u387d\u33d6J\u7e22\u00df\000", "",
        -5, -1000, 0, 0L, -99828L, false, false, (char) 12114, (char) 42396,
        Double.longBitsToDouble(0x3fe2892272f7b60fL), Double.longBitsToDouble(0x3feabb96aa0e19fcL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07", "\000", "\ue53c",
        -5, -1000, 1560612384, 55834574848L, 46441L, true, true, (char) 10663, (char) 4126,
        Double.longBitsToDouble(0x3fcbe348a0760c24L), Double.longBitsToDouble(0x3fdeaf84965ebc4cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Sat Sep 01 00:00:00 PST 168830120\012",
        Z.run(T, 2, 0, 12, 1, "\ud951\udf34\udba4\ude5e\u6a34\ud99e\udd79\ud8cd\ude73\ud8c7\udd19", "\uab6f\u545f\u4d0a\uc7b1\u0832\u607e\u33d6\ua3e1\u7ef1\u18c4\u7ef8\u143f\u45f9\ucad0\u2ed0\u1a97", "\udb37\udd3a\ud8b1\udd3a",
        2, 17959, 1637183224, -5327935511819091209L, -90028L, true, false, (char) 19986, (char) 20256,
        Double.longBitsToDouble(0x3fcba807e292bad0L), Double.longBitsToDouble(0x3feb2eaad8d5e83bL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 2, 10, "\ud9e2\ude07\udab7\udda5\ud901\uddda", "\u389b\u5ead\ub65b\uaac4\u72de\u616c\u345b\ub3b0\u37f8\u33d6\ua3e1\u4b63\u18c4\u7ef8", "\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\ud89e\udf64",
        41, 39972, -748161876, -5051927140369158318L, -75855L, false, false, (char) 37092, (char) 4718,
        Double.longBitsToDouble(0x3fe136dcaa3a5765L), Double.longBitsToDouble(0x3fdacbe5a7ba809eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.util.Date:Sat Feb 14 16:52:37 PST 262756901\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 11, 13, "\ud9e2\ude07\udace\udd10\u6a6b", "\u15a6\u4184\u3409\u2d17\uc248\u4de9\ubb68\u7c35\ud61f\u3462\ua83e\u2374\u5c04\u7ef8", "\udad8\udcf2\ud9a2\udf3c\uda99\ude5c\ud8b5\udc60\uda5c\uddd5\udb37\udc93\ud8bc\ude0b\ud9cc\ude6f\udb8c\ude5e\udae4\udc9b\ud9e0\uddf5\uda83\udf88\ud807\udcdf\udbe5\udc7c\udb5d\udf46\udbd8\udec6\ud8f5\udcba\ud8ea\udfd9\udbc1\udfa6\ud9a9\uddfe",
        29, 82665, -43102980, -8292039311045242287L, -69546L, false, false, (char) 48096, (char) 4711,
        Double.longBitsToDouble(0x3fdad36678017a5cL), Double.longBitsToDouble(0x3fd1f8b4fab4430cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.util.Date:Mon Oct 21 06:40:42 PDT 250123095\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 14, 8, "\ud956\udf22\udace\udd10\udb28\udf66\ud99e\udd79\ud9a4\udfdd\udad1\udca9\ud8a2\udf51\ud952\udcb8\udb35\udd3b\uef49\ud8ce\udcda\ud9f3\udc0e\ud955\udef5\ud8c1\udd00", "\u8e96", "\uda7b\udc5e",
        10, 56104, 336738407, 7893060361155642115L, 37410L, false, false, (char) 2702, (char) 59701,
        Double.longBitsToDouble(0x3fe201b92751244eL), Double.longBitsToDouble(0x3fe5ddf84b5772d5L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.util.Date:Sat Dec 21 02:49:40 PST 165459444\0121=java.util.Date:Wed Aug 21 02:49:44 PDT 165459444\012",
        Z.run(T, 2, 7, 6, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u079c\u5ead\ub65b\uaac4\u47f4\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u8e96\u35cc\uca45", "\udb70\udcdf\ud9a5\ude12",
        -4, 71134, 1752307995, 5221333595731784876L, -87886L, false, false, (char) 33439, (char) 54021,
        Double.longBitsToDouble(0x3feabb96aa0e19fcL), Double.longBitsToDouble(0x3fe506dcac4ffd08L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udb38\udc18\u69b7", "\u079c\u5ead\ub65b\uaac4\u47f4\u4d0a\ubb68\u969b\u387d\u33d6\ua3e1\u8e96\u57b5\u49d4", "\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\ud8e3\ude2c\ud886\udf83\udaf2\ude25\udb4c\udf6b\udb8c\ude62\uda1a\udc76\ud971\udec5",
        14, 11776, -507692147, -3465568651711590508L, 41467L, true, true, (char) 5511, (char) 16266,
        Double.longBitsToDouble(0x3feea159a9c7fda5L), Double.longBitsToDouble(0x3fd9d4f3926b2266L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 5, 15, "\ud9e2\ude07", "\u3ff7\ua664\u079c\u5ead\ub65b\uaac4\u47f4\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u8e96\u35cc\uca45\u15dd\u63cb\u45b9\u5989\ua0c4\ud60f\u24e5\u651f\u87d1\ub7ef\u80ac\ub17f\u3534\u1b11\u58f4\u3f9a\u76e9\uadd9\u9f83\u6644\u87f1\u522f\u9dc4\u64b2\uac35\u75bf\u9d99\uc30a\u7e5f\ub9fe\u902c\u49bf\u9cbf\u0d62\u3a46\u6d3e\u18b0\uc6b2\ucb57\ucfee\u68a6\u7c33\u62da\u7256\ubc01\u6bea\u667a\uae50\u769d\u8d8e\u8736\u2a8e\ua7bc\ub5be\u8691\u4b7c/\u33c8\u8f9f\u982b\u5ad0\u8495\u7cc3\ud583\uabb7", "\udbad\udd8f\udb9d\udf6e\ud91f\udecb\ud976\udd64\udbd4\udee4\udabb\udeaa\ud87e\udf9a\udb5e\udd44\uda12\ude82\u7fc9\ud9e8\udcd2",
        29, 17875, 425709235, -730275030468198123L, 10901L, true, true, (char) 5371, (char) 41545,
        Double.longBitsToDouble(0x3fd4b23d1664978cL), Double.longBitsToDouble(0x3fe3ffb05a619a42L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.util.Date:Mon May 21 02:49:44 PDT 165459449\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 15, 9, "\ud9e2\ude07\udace\udd10\u6a6b", "\u079c\u5ead\u57dd\uaac4\ua9cc\ud487\ubb68\u0832\uc78a\ua3d1\ud1ae\uad12\u55f3\uca98", "\ud862\udf27\udb30\udf98",
        53, 71134, 1752307995, 5221333595731784876L, -82684L, false, false, (char) 20924, (char) 44974,
        Double.longBitsToDouble(0x3feaf0ac93dd403fL), Double.longBitsToDouble(0x3fe1307c3f65d5a4L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.util.GregorianCalendar:java.util.GregorianCalendar[time=8396603237625691186,areFieldsSet=true,areAllFieldsSet=true,lenient=true,zone=sun.util.calendar.ZoneInfo[id=\"UTC\",offset=0,dstSavings=0,useDaylight=false,transitions=0,lastRule=null],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=1,YEAR=266079734,MONTH=4,WEEK_OF_YEAR=1...\0121=java.util.Date:Wed Jun 30 14:21:31 PDT 266079734\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b\ud99e\udd79", "\u5ead\ub65b\uaac4\u47f4\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u8e96\u35cc\uca45\u3ba5\u339d\uc690\u5939\ua0c4\ud60f\u24e5\u651f\u87d1\ub7ef\u80ac\ub17f\u3534\u1b11\ud223\u3ee5\u76e9\uadd9\u9f83\u6644\u87f1\u0844", "\udb3d\udc65\ud8d9\udfe6\udaf9\udc7f\udaa0\udd85\ud8a5\udecc\udb48\ude03\udbb3\udd75\ud9c9\udcdb\uda70\udf58\ud8e9\udd4f\uda16\udf74\ud952\udce5\ud8bc\udd2c\uda4e\udf98\udb26\ude5e\ud945\udf5c\ud8bb\udd73\ud8eb\udf3b\udba3\udccd\ud944\udf19\udb0b\udc1e\udb1c\udf60\udbfe\udeba\udb5f\udc32\udb3e\udcde\u0478\udb64\udd9b\ud912\uded0\udbc4\udf08\ud93f\ude15\ud82f\udcf7\ud8e7\udeed\u5d8b\ud9a8\uddb5\udbb3\udd5d\ud947\ude6a\ud900\udd6b\ud85e\udc13\ud8f4\udc73\ud85b\udf96\udb09\ude4b\ud959\udf16\ud8b7\udfd4\ubb1f\udbda\udddb\ud928\udebd\uda53\udf70\ud9c3\uddb7\udaeb\udcc2\ud934\udf2a\uda16\udc97\udafc\udc37\ud81d\udcfb",
        56, 14, 599697485, 8396603237625691186L, 25770L, true, false, (char) 50327, (char) 19308,
        Double.longBitsToDouble(0x3fd85b917bd6d118L), Double.longBitsToDouble(0x3fc1f7da7d02bd88L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.util.Date:Wed Nov 29 12:32:43 PST 187065703\0121=java.util.Date:Wed Nov 29 12:32:43 PST 187065703\012",
        Z.run(T, 2, 4, 4, 9, "\udb6b\udd96\udace\udc91\u6998\ud99e\udd79\ud9a4\udfdd\udad1\udca9\ud8a2\udf51\ud9e2\udeb4\udb65\ude25\udaa7\udd52\ud990\udfdd\ud880\uddce\udb13\udebe\ud8e9\uddd3\ud833\udce7\ud8d8\udff8\ud8b9\udd71\ud8d4\udeb6\ud880\udde9\ud867\ude04\ud9ec\udd16\udb70\udcdf\ud8e7\udc6f\udbac\udc78\udb74\udcc0\udad7\udf42\ud886\udf83\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91\ud9f0\udd93\udb48\udf08\ud9d9\udcd3\ud807\udcdf\uda69\udfe8\uda0f\uddde\uc93e\ud87f\udebc\ud8e9\ude17\ud881\uddcd\ud8ad\udd16\uda19\udfd6\udbf7\udc74\udbdc\udf45\ud883\udc55\ud842\udf26\ud8c5\uddb7\udb19\uddda\ud951\udd0f", "\u0541\u228f\u4f80\u7867\u635d\u24bc\u2875\u8b5c\u237b\u8d4b\u69a2\u7d20\u6b31\u8ecc", "\udb02\udd80\ud862\uddf5\udbb7\udd11",
        37, 82841, 994673499, -5903406736025236818L, 16568L, false, true, (char) 24487, (char) 62176,
        Double.longBitsToDouble(0x3fd75134067b4d7cL), Double.longBitsToDouble(0x3fedc972be3ae7fcL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 15, "\ud9e2\uddd9\udace\udd10\u6a6b\ud99e\udd79\ud9a4\udfdd\udad1\udca9\udab9\udfbc\ud94b\udd15\udbe2\udf1a\ud96f\udf2f\udbcc\udcd9\ud880\uddd6\udb13\udebe\uda46\uddc1\uda4b\udc35\udafe\udc23\ud893\udea3\udbd0\udfda\udb8b\ude62\ud855\udf1e\ud9ec\udd16\udb70\udcdf\ud9ae\ude12\ud9b8\udde2\udb9d\uddb3\udad7\udf42\ud886\udf83\ud8bc\ude0b\udbc6\uddcb\udb8c\udebe\udae4\udc9b\udb48\udf08\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\ud8c2\udc38\ud991\udd8e\ud8f7\udf27\ud8e5\udcc7\udbc1\udfa6\ud99f\udf39\ud8b6\ude37\ud89a\udc01\ud9d3\ude80\udb7f\udfb8\uda53\ude9a\ud9f2\udc3f\ud860\udc15\ud9d7\udea5\ud90c\udccc\ud907\ude00\udb12\udc2c\uda59\udd08", "\u730c\u7d09", "\u936e\uda0f\udccb\udb25\udfa6\udab2\udfd8\uda05\udef5\ud95c\udd51\uda7a\udec5\ud99d\udcb9\ud8ac\udc3f\uda71\ude39\uda9c\udeb7\udb8d\udfb6\u08d4\udb4a\udeb3\ud9f5\udef4\u784f\udac9\udf9e\ud8c8\udf38\ud98c\ude29\uda90\uddd8\udbac\ude8c\uda69\udddd\udb7a\udfb7",
        32, 5943, -799784615, -1737706718676858578L, -38960L, false, false, (char) 2499, (char) 56214,
        Double.longBitsToDouble(0x3fed31c72a32270eL), Double.longBitsToDouble(0x3feea8f1d2645fb9L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 0, "", "\000", "\000",
        7, 4416, 352494046, 1646742000893952L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc9e84000000000L), Double.longBitsToDouble(0x3fd0e84000c21d0eL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.util.Date:Wed Aug 17 10:35:40 PST 101822750\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 12, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u990c\ub5b6\u1c8c\u9af5\u6965\u42f3\u0832\u387d\u33d6\ua3e1\u7ef1\u2f76\ud080\u9c15\u73f4", "\ud95d\udf57",
        54, 22379, -1056317394, -3213343731446713592L, 59352L, true, true, (char) 14598, (char) 17964,
        Double.longBitsToDouble(0x3fe070cfe3eb4edcL), Double.longBitsToDouble(0x3fe08cbeae88d340L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jan 04 12:03:54 PST 18636448\012",
        Z.run(T, 1, 12, 12, 1, "\udb94\ude21\ud88d\udff1\ud9ba\udc0f", "\u389b\u5ead\u758e\u00b0\uaa5d\uc439\u2c75\u831f\u6c0b\u8356\ua3e1\u5a19\uae6c\ua6d5\u06fa\u7417\u9a76\u10e6\u9c2d\ud1e1\u480e\u07e9\u1b86\u8f0e\u8ae1\ua0e5\ucb29\u1acb\ud223\ud384\u1875\u034c\u787e\u276a\u87f1\u033a\ud1ce\u0aba\ua070\u8cf5\u4eb6\u50a6\u9c5b\u03de\u5fd0\ud6d5\u057d\u03d8\u73ae\ud013\u99d1\uc5d9\ud28e\u9932\u1de2\u8ec8\u2299\u4387\ud322\uc181\ua506", "\ud944\ude4b",
        13, 55393, 1158672318, 588047328129833191L, 92993L, true, false, (char) 54263, (char) 63205,
        Double.longBitsToDouble(0x3fa927b98279dad0L), Double.longBitsToDouble(0x3fd17a13bbd3def4L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\000", "\u3ff7\u089a\u389b\u5ead\000\000\000\u4b42\ubb68\u0832\u387d\u8bd5\u3639\u7ef1\u00df\000\u493d\u108b\u4b0f\u49ed\ua0c4\ud60f\u4798\u00fc\000\u9ce6\u5852\u6e78\u305d\ub049\u69b4\u1d8b\u00a9\000\000\000\u87cb\u033a\u868c\000\000\000\u9407\u8e8c\u3873\uaf6f\u92ae\u14ae\u8452\uafd1\uc06d\u1575\u145e\u9825\u68fc\u8115\u2ad2\ub94f\ube98\uc159\u3942\uc428\u028f\u5a09\u2fff\u228f", "\ud9a2\udc22",
        23, 13997, 1797354117, 5730598972729044633L, 22380L, false, false, (char) 40085, (char) 15392,
        Double.longBitsToDouble(0x3fdbe67306e24436L), Double.longBitsToDouble(0x3fe4cef4efec15f8L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\ud8cd\ude73",
        26, 30052, -344468114, -3276622697357553264L, -10218L, false, false, (char) 43223, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fcbe348a0760c00L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.util.Date:Tue May 07 04:55:06 PST 222080469\0121=java.util.Date:Tue May 07 04:55:06 PST 222080469\012",
        Z.run(T, 2, 5, 5, 10, "\ud8eb\ude2d\uda1a\udcc7\uda46\udff6", "\u389b\u54e6\u70ee", "\udbcc\udcd9",
        11, 56784, -1747860489, -7008388733330153023L, 24127L, true, true, (char) 13788, (char) 26646,
        Double.longBitsToDouble(0x3fe084ad6767a7f7L), Double.longBitsToDouble(0x3fd9ad18a07c8f1cL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.util.Date:Tue Nov 25 17:20:38 PST 285330704\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 4, 12, 10, "\udbce\ude09\udace\udc92\udaef\udedf", "\u389b\u5ead\ub65b\uaac4\u545f", "\udb13\udebe\ud8e9\uddd3",
        30, 6058, 440733647, -9004414331889561571L, -70513L, false, false, (char) 54227, (char) 48606,
        Double.longBitsToDouble(0x3fef3f1b811b5c27L), Double.longBitsToDouble(0x3fcf968f52b12024L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.util.Date:Fri Jul 28 20:39:19 PST 158360831\0121=java.util.Date:Fri Jul 28 20:39:19 PST 158360831\012",
        Z.run(T, 2, 8, 8, 15, "\udbd8\udd26\udac4\udd77\udaef\udedf\uda49\udf69\u1318\ud8c7\udd19\ud967\udd54\ud97d\ude79\ud891\udf4e", "\ubf43\ua2f4\ud04f\u497b", "\udaea\udc37\udadc\udd68\ud9eb\udf3e\udb13\udef1\udaad\udf61\udb00\udcf8\ud840\ude03\ud896\ude63\ud88f\uddb4\udb37\udd3a\udad6\udce3\ud98c\udde7\ud850\udd6e\ud8f4\udc83\uda3d\udf08\udaf2\ude51\udbf3\udfcb\ud9aa\udfed\udb40\udc2a\ud98b\udc66\ud9b6\udc25\ud84e\uded8\ud9ef\ude14",
        31, 87790, 727925280, -4997549896831240713L, 52230L, true, true, (char) 39331, (char) 12926,
        Double.longBitsToDouble(0x3fe636e91b85deb8L), Double.longBitsToDouble(0x3fef13ad8bafc719L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.util.Date:Mon Sep 23 19:06:42 PDT 235281889\0121=java.util.Date:Mon Sep 23 19:06:42 PDT 235281889\012",
        Z.run(T, 2, 6, 6, 10, "\u6652\udace\udd00\u6a6b", "\u7215\u4685\u5b00\uaac3\u545f", "\udb13\udebe\uda10\udec6",
        10, 6058, 440733647, 7424717107230402995L, -70513L, false, false, (char) 57438, (char) 60447,
        Double.longBitsToDouble(0x3faf34c711b5ca80L), Double.longBitsToDouble(0x3fcf968f52b12024L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.util.Date:Mon Aug 09 17:34:19 PDT 275609238\0121=java.util.Date:Mon Aug 09 17:34:19 PDT 275609238\012",
        Z.run(T, 2, 9, 9, 11, "\uda42\udebd\udace\udd10\u6a6b", "\u4938\u5d78\ub65b\uaac4\uabf4\u6915\ub0ca\u0f03\u384d\u33d6\ua3e1\u0cde\u6d03\u3736", "\udb79\udff1\udb96\udeaa\udb04\udc47\udb9d\uddb3\ud977\udd93\udb36\udf20\ud8bc\ude0b\ud8f9\udee6",
        0, 88864, -1643159983, 8697325346267659207L, 958L, true, true, (char) 4525, (char) 44297,
        Double.longBitsToDouble(0x3fdd5e83b8cdf934L), Double.longBitsToDouble(0x3fde716bcf2661f4L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.util.Date:Wed Oct 29 07:36:47 PDT 148188955\0121=java.util.Date:Wed Oct 29 07:36:47 PDT 148188955\012",
        Z.run(T, 2, 1, 1, 1, "\uda42\udebd\udace\udd10\udacc\udee3\ud87c\udf96\ud8bb\udc84\ud8c7\udd19\ud8a2\udf51\ud952\udcb8\udbe2\udf1a\udac9\udc61\udbdb\ude99\udac2\uddd7", "\u33d6\u6fe1\u9820", "\ud985\udf76\udbe8\udde3\uda82\udc74\udb96\udea5\udb04\udc47\udb9d\uddb3\ud977\udd93\ud85c\udf54\udbef\uddf1\ud8f9\udee6\udb8c\ude91\udae4\udc9b\ud98c\udc8b\udbc2\ude6e\ud8f2\udeff",
        3, 55678, 354085434, 4676295924686207965L, -89605L, true, true, (char) 43264, (char) 24739,
        Double.longBitsToDouble(0x3fec9987d2d45a16L), Double.longBitsToDouble(0x3fd55593fd9db81cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.util.Date:Sat Oct 13 14:58:01 PDT 57361173\0121=java.util.Date:Tue Oct 02 15:00:00 PDT 57361173\012",
        Z.run(T, 2, 2, 12, 10, "\udaf7\udf0e\udb26\udd7e\u6a6b", "\u389b\u5ead\u33d7\ua656\u2078\u0582\ubb68\u5f0a\uc23a\u33d6\u20eb\u7ef1\u18c4\u1915", "\ud85d\udca3\ud90b\uddf8\ud9b8\udde2\ud889\ude29",
        11, 17111, -1862577536, 1810081639605481298L, -62772L, false, true, (char) 62831, (char) 32840,
        Double.longBitsToDouble(0x3fb78546a786f8e8L), Double.longBitsToDouble(0x3fe25c937f65d5a4L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Thu Dec 01 02:10:03 PST 284581121\012",
        Z.run(T, 2, 0, 2, 10, "\ud9e2\ude07", "\u3ff7\u83d1\u396a\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1", "\ud985\udf76\ud9e0\udd2f\udb70\udcdf\uda95\udd8a\ud9b8\uddf4\udb9d\uddb3\uda58\udfa7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91x\000\ud9ac\udcc4",
        45, 5822, -1814202842, 8980450633300203000L, -100000L, true, true, (char) 54800, (char) 43264,
        Double.longBitsToDouble(0x3feae68d57a16972L), Double.longBitsToDouble(0x3fe49f1da13d00fdL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 15, 10, "\ud9e2\ude07\udab0\udd01\u6a6b\ud99e\udd79\ud8cd\ude73\ud8c7\udd19\ud8a2\udf51\ud952\udcb8\udbe2\udf1a\ud93c\udf9b\udbcc\udcd9\ud880\uddd6\udb13\udebe\ud8e9\uddd3\udb5e\uddc9\ud982\udd32\ud91e\udd5b\udafd\udd81\ud86e\udf5e\ud896\udf8f\ud9e0\udd2f\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda58\udfa7\udb67\udf3c\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91x\000\ud9ac\udcc4\ud807\udcdf\ud9b3\uddc8\ud87b\udfcf\ud932\udd72\ud8f5\udc98\000\udbc1\udd80\ud9a9\uddfe\udb15\udda1\udbf4\uddaa\udb32\udd92\ud835\uddf6\udbaf\udea1\udaeb\ude66\ud84b\udde4\ud8eb\udf49\u2a27\udb47\uddf6\udafc\udf8f\ud890\udc6a\ud8df\udeaa\ud8a3\ude14\ud804\udd0d\udabb\udfed\ud8b1\ude8f\ud89b\udced\ud9bd\ude08\ud8c0\udf33\ud854\udc3f\ud9aa\udfc4\ud92c\udfc2\udaf9\udf24\u04fd\uda9f\udffa\uda70\udd0d\ud8da\udcfd\ud834\udf33\u1256\uda9d\ude83\ud818\udec7\ud48c\u0e84\udb8b\udf89\udaa7\uddab\uda71\ude3f\u8183\ud897\udfa1\udabd\udc00\udbe8\udf18\ud976\udc0e\udbc3\udd92\ub8f1\uda3b\ude8f\ud942\ude32\ud90c\udeef\udb33\ude42\udb45\uddc8\ud822\ude8d\ud8d6\udef7", "\uaa93\u7a28\uc213\u8d05\u404f\ua55b\u8ef8\uba53\u3b78\uc32f\u44f0\u496f\u3c10\u4fac\uc2cf\uc099\u3f20\u9314\u8a86\uc3ea\u62ee\ubc1f\u0e46\u4de1\u202c\ud562\ua06f\ucf16\u930a\u76a8\u4c89\u7384\u7458\u180b\u520c", "\udb44\udc06\uda8c\udd27\udae9\udda8",
        36, 51038, -53549918, 216070838028720718L, -47618L, true, false, (char) 2019, (char) 7936,
        Double.longBitsToDouble(0x3fcc1a06623e2668L), Double.longBitsToDouble(0x3fc49e25d7a10144L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.util.Date:Tue Oct 28 22:00:00 PST 11055164\0121=java.util.Date:Fri Nov 07 21:06:58 PST 11055164\012",
        Z.run(T, 2, 12, 2, 13, "\ud9e2\ude07\u248c\ud9f2\udf7e\ud932\udd07\uda28\udd6b\ud857\udfe2\ud8ef\udcc1", "\u5084\u6c98\ua378\ucd85\uc018\u67f1\u4b3b", "\uda81\udd8e\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud9bd\ude12\uda53\udff0",
        10, 78403, 917794120, -348936553191181560L, 59352L, true, false, (char) 14598, (char) 54060,
        Double.longBitsToDouble(0x3fe4cdfaf626dbffL), Double.longBitsToDouble(0x3feb1d45cc7a2204L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.util.Date:Sun Dec 16 14:04:48 PST 164973296\0121=java.util.Date:Sun Dec 16 14:04:48 PST 164973296\012",
        Z.run(T, 2, 7, 7, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\ucb09\u807d\uaac4\u545f\u76d1\uce3f\u08a6", "\udb9b\udff8\udb21\udeff\udb0a\ude47\uda81\udd8e\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud8e6\udd67\ud846\udc67\ud84d\uddbf\uda5b\udc09\ud961\uded2\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\ud8b9\udd32\ud912\ude2c\ud8f5\udc27\uda0c\uddba\udbc1\udfa6\ud9a9\uddfe\ud8e0\udca6\udb8e\udcbf\udabb\udeac\udb3c\udd81",
        39, 65673, 147557780, 5205992246316249913L, 78561L, true, false, (char) 35777, (char) 60251,
        Double.longBitsToDouble(0x3fe14e57f344ac08L), Double.longBitsToDouble(0x3feca0563df22af8L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.util.Date:Tue May 14 18:13:00 PDT 164973297\0121=java.util.Date:Sun May 26 18:12:31 PDT 164973297\012",
        Z.run(T, 2, 12, 2, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\001\ucb09\u6a44\uaac4\u545f\u76d1\uce3f\u08a6", "\udb78\udf85\udb92\udc55\udb0a\ude87\uda81\udd8e\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud9bd\ude12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udddb\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\u6b04\ud975\ude78\ud8f5\udc27\uda0c\uddba\udbc1\udfa6\ud9a9\uddfe\ud8e0\udca6\udb8e\udcbf\udabb\udeac\ud8e0\udcb3",
        12, 65673, 147557780, 5205992259201151801L, 78561L, true, false, (char) 35777, (char) 2908,
        Double.longBitsToDouble(0x3fe14e57f244ac08L), Double.longBitsToDouble(0x3fc28158ebcb4b48L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.util.Date:Tue Jan 01 00:00:00 PST 164973297\0121=java.util.Date:Tue Jan 01 00:00:00 PST 164973297\012",
        Z.run(T, 2, 12, 12, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\u5aa3\u6a44\uaac4\u545f\u76d1\uce3f\u08a6", "\uda9a\udc97\udb21\udeff\udb0a\ude87\uda81\udd8e\ud99b\udc76\ud8f5\udc33\udb86\udf45\ud9bd\ude12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udd86\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91\udbb8\udee5\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\uda0a\udefb\ud975\ude78\ud8f5\udc27\udacc\udf94\udbd2\udcc5\ud9a9\uddfe\ud8e0\udca6\udb8e\udcbf\ud869\udc23\ud9c8\udf86",
        1, 65650, 147557780, 5205992246316249913L, -89879L, false, false, (char) 35777, (char) 50332,
        Double.longBitsToDouble(0x3fe7b2dac344ac08L), Double.longBitsToDouble(0x3fc293832bcb4b48L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.util.Date:Mon Dec 17 00:00:00 PST 164973296\0121=java.util.Date:Tue Dec 25 14:04:09 PST 164973296\012",
        Z.run(T, 2, 12, 2, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\ucb09\u6a44\uaac4\u94aa\u76d1\uce3f\u08a6", "\udb9b\udff8\udb21\udeff\udb0a\ude87\uda81\udd8e\ud985\udf1e\ud9e0\udd2f\udb70\udcdf\ud9bd\ude12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udd86\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\u6b04\ud975\ude78\ud8f5\udc27\uda0c\uddba\udbc1\udfa6\ud9a9\uddfe\ud8e0\udca6\udb8e\udcbf\udabb\udeac\uda80\udd63",
        9, 65673, 147557780, 5205992246316249913L, 78561L, true, false, (char) 35777, (char) 2908,
        Double.longBitsToDouble(0x3fe14e57f344ac08L), Double.longBitsToDouble(0x3fc28158ebcb4b48L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.util.Date:Wed Nov 10 02:11:17 PST 146706888\0121=java.util.Date:Wed Nov 10 02:11:17 PST 146706888\012",
        Z.run(T, 2, 3, 3, 8, "\udaa9\ude24\ud909\ude02\u8416", "\u1ef2\ub0b1\ub5c9\uaac4\u545f\u8453\ubb68\u0832\u2d18\u33d6\u4af8\u9040\uc50b\u9bd7", "\ud8ed\udf59\ud9a5\ude12\ud9b8\udde2\udb9d\uddf2\ud9f7\uddf3\udb9a\udc54\ud853\udd25\uda1c\uddeb\u4c24\ud9cb\udff3\uaa5a\u7ee7\ud807\udd56",
        21, 49174, 354085434, 4629560082613877725L, 75436L, false, false, (char) 47642, (char) 51043,
        Double.longBitsToDouble(0x3fed123bcdd03ebeL), Double.longBitsToDouble(0x3fe5fb33b5908602L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.util.Date:Fri Mar 05 06:52:29 PST 168830139\0121=java.util.Date:Fri Jan 01 12:00:00 PST 168830139\012",
        Z.run(T, 2, 8, 12, 10, "\ud9e1\udcd7\ud9eb\udd34\ud977\ude60\udb9c\ude22\ud89d\udce8\ud8c7\udd19\ud9ce\uddd7\ud985\udf27\udbe2\udf1a\ud96d\udcd3\udbaa\udce5\ud880\uddd6\udb13\udebe\udb7d\udc23\ud97b\ude59\ud863\udcb3", "\u2511\u74c2\ua3b7\u45b9\u5989\ub2f0\ud60f", "\uda47\udf91",
        9, 58272, 609119864, -5327936130244050185L, -12346L, false, false, (char) 16799, (char) 24610,
        Double.longBitsToDouble(0x3fe6ea01fe0286aaL), Double.longBitsToDouble(0x3feb2d1936d5de3bL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jan 01 00:00:00 PST 1\0121=java.util.Date:Sat Jan 01 00:00:00 PST 1\012",
        Z.run(T, 2, 12, 12, 12, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7e9a\u18c4\u4978", "\uda1a\ude93\ud96b\udf1d\ud8bd\udf29\ud96a\udded\uda93\udc09\udb10\udcf9\ud8bc\ude0b\ud8f9\udee6",
        0, 88864, 1904893521, -6604525034885318382L, 66362L, false, false, (char) 38263, (char) 31772,
        Double.longBitsToDouble(0x3fe1307c3f65d5a4L), Double.longBitsToDouble(0x3fc59d076e602668L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 0, 0, 1, "\000\000\ud857\udd8a\ud99e\udd79\ud8cd\ude73\ud8c7\udd19", "\uab6f\u545f\u4d0a\uc7b1\u0832\u607e\u336f\ua3e1\000\000\000\000\000\000\u2ed0\u008f", "\ue8fc\ud8b1\udd3a",
        24, 17959, 1637183224, 0L, -100000L, true, false, (char) 32886, (char) 32767,
        Double.longBitsToDouble(0x3eaf800000000000L), Double.longBitsToDouble(0x3f4aab6000000000L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jun 09 02:13:11 PDT 255365387\0121=java.util.Date:Sat Jun 09 02:13:11 PDT 255365387\012",
        Z.run(T, 2, 12, 12, 1, "\ud951\udf34\udba4\ude5e\u6a34\ud99e\udd79\ud936\udc67\ud8bf\udcd8", "\u9d9a\ud624\uc66c\ub745\u5bc0\u5174\u45c2\u995c\u7ef1\u18c4\u7ef8\u143f\u45f9\ucad0\u08d0\u1a97", "\udb37\udd3a\ud8b1\udd3a\uda8d\uddcb",
        14, 73224, -1240506655, 8058491106628391284L, 8601L, false, true, (char) 20256, (char) 23836,
        Double.longBitsToDouble(0x3fc495d69d97556cL), Double.longBitsToDouble(0x3fcabd076a8e58f4L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.util.GregorianCalendar:java.util.GregorianCalendar[time=8396603237625691186,areFieldsSet=true,areAllFieldsSet=true,lenient=true,zone=sun.util.calendar.ZoneInfo[id=\"UTC\",offset=0,dstSavings=0,useDaylight=false,transitions=0,lastRule=null],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=1,YEAR=266079734,MONTH=4,WEEK_OF_YEAR=1...\0121=java.util.GregorianCalendar:java.util.GregorianCalendar[time=8396603237625691186,areFieldsSet=true,areAllFieldsSet=true,lenient=true,zone=sun.util.calendar.ZoneInfo[id=\"UTC\",offset=0,dstSavings=0,useDaylight=false,transitions=0,lastRule=null],firstDayOfWeek=1,minimalDaysInFirstWeek=1,ERA=1,YEAR=266079734,MONTH=4,WEEK_OF_YEAR=1...\012",
        Z.run(T, 2, 10, 10, 10, "\ud9e2\ude07\udb30\ude17\u77b7\ud9df\ude49", "\u5ead\ub65b\uaac4\u47f4\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u8e96\u35cc\u5612\ua209\u42ac\u2550\u2679\uae69\ud60f\u24e5\u651f\u87d1\ub7ef\u80ac\ub17f\u3534\u1b11\ud223\u3ee5\u76e9\uadd9\u9f83\u6644\u87f1\u0844", "\udb3d\udc65\ud8d9\udfe6\udaf9\udc7f\udaa0\udd85\ud8a5\udecc\udb48\ude03\udbb3\udd75\ud9c9\udcdb\uda70\udf58\ud8e9\udd4f\uda16\udf74\ud952\udce5\ud8bc\udd2c\uda4e\udf98\udb26\ude5e\ud945\udf5c\ud8bb\udd73\ud8eb\udf3b\udba3\udccd\ud944\udf19\udb0b\udc1e\udb1c\udf60\udbfe\udeba\udb5f\udc32\udb3e\udcde\u0478\udb64\udd9b\ud912\uded0\udbc4\udf08\ud93f\ude15\ud82f\udcf7\ud8e7\udeed\u5d8b\ud9a8\uddb5\udbb3\udd5d\ud947\ude6a\ud900\udd6b\ud85e\udc13\ud8f4\udc73\ud85b\udf96\udb09\ude4b\ud959\udf16\ud8b7\udfd4\ubb1f\udbda\udddb\ud928\udebd\uda53\udf70\ud9c3\uddb7\udaeb\udcc2\ud934\udf2a\uda16\udc97\udafc\udc37\ud81d\udcfb",
        56, 14, 599697485, 8396603237625691186L, 25770L, true, false, (char) 50327, (char) 19308,
        Double.longBitsToDouble(0x3fd85b917bd6d118L), Double.longBitsToDouble(0x3fc1f7da7d02bd88L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.util.Date:Tue May 14 18:13:00 PDT 164973297\0121=java.util.Date:Tue May 14 18:13:00 PDT 164973297\012",
        Z.run(T, 2, 12, 12, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\uc898\ucac9\u6a44\uaac4\u545f\u76d1\uce3f\u913d", "\udb78\udf85\udb92\udc55\udb0a\ude87\uda81\udd8e\ud985\udf76\ud9e0\udd2f\udb70\udcdf\ud9bd\ude12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udddb\ud8bc\ude0b\ud8f9\udee6\ud9ca\udd90\uda04\udd1c\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\u6b04\ud96b\udf93\ud8f5\udc27\uda0c\uddba\udbc1\udfa6\ud9a9\uddfe\ud8e0\udca6\udb8e\udcbf\udabb\udeac\ud8e0\udcb3",
        12, 65673, 147557780, 5205992259201151801L, 78561L, true, false, (char) 35777, (char) 2908,
        Double.longBitsToDouble(0x3fe14e57f244ac08L), Double.longBitsToDouble(0x3fc28158ebcb4b48L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.util.Date:Fri Jan 01 00:00:00 PST 164973300\0121=java.util.Date:Fri Jan 01 00:00:00 PST 164973300\012",
        Z.run(T, 2, 12, 12, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\u5aa3\u6a44\uaac4\u545f\u76d1\uce3f\u08a6", "\uda9a\udc97\udb13\uddc9\udadf\udecc\uda81\udd8e\ud99b\udc76\ud8f5\udc33\udb86\udf45\ud9bd\ude12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udd86\ud8bc\ude0b\ud8f9\udee6\udb8c\ude91\udbb8\udee5\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\uda0a\udefb\ud95d\ude8d\ud8f5\udc27\udacc\udf94\u64bf\ud9a9\uddfe\ud8e0\udca6\udb8e\udcbf\ud869\udc23\ud9c8\udf86",
        1, 65650, 147557780, 5205992340805530425L, -89879L, false, false, (char) 35777, (char) 50332,
        Double.longBitsToDouble(0x3fe7b2dac344ac08L), Double.longBitsToDouble(0x3fc293832bcb4b48L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.util.Date:Sat Apr 18 12:00:00 PDT 241027733\0121=java.util.Date:Sat Apr 18 12:00:00 PDT 241027733\012",
        Z.run(T, 2, 12, 12, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\u5aa3\u6a44\uaac4\u545f\u76d1\uce3f\u08a6\u387d\ua904", "\udb0a\ude87\uda81\udd8e\ud99b\udc76",
        9, 18655, -663381913, 7606038443085512766L, 43032L, false, false, (char) 50799, (char) 59701,
        Double.longBitsToDouble(0x3fe3c1b926514b29L), Double.longBitsToDouble(0x3fe7bdb07a5772d5L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jan 01 00:00:00 PST 164973298\0121=java.util.Date:Wed Jan 01 00:00:00 PST 164973298\012",
        Z.run(T, 2, 12, 12, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\u7607\u6a44\uaac4\u5568\u76d1\uce3f\u08a6", "\ud95f\udd90\ud967\udfb2\udbd1\udfc1\uda81\udd8b\ud99b\udc76\ud8f5\udc33\udb86\udf45\uda54\udfdb\udb58\ude86\ud84d\uddab\uda5f\udcf4\udb33\udd86\ud8bc\ude0b\ud87b\udee7\udb8c\ude91\udbb8\udee5\ud92d\udcf7\u434f\ud9d5\ude3e\uda42\udc9d\uda0a\udefb\ud975\ude78\ud8f5\udc27\udacc\udf94\udbd2\udcc5\ud9a9\uddfe\udb1e\udfa9\udb00\udf42\ud869\udc5d\ud9c8\udf86",
        1, 65650, 147557780, 5205992248429529313L, -89879L, false, false, (char) 35777, (char) 50332,
        Double.longBitsToDouble(0x3fdf65b586895810L), Double.longBitsToDouble(0x3fc293832bcb4b48L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.util.Date:Mon Dec 17 00:00:00 PST 164973296\0121=java.util.Date:Mon Dec 17 00:00:00 PST 164973296\012",
        Z.run(T, 2, 12, 12, 7, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\ucb09\u6a44\uaac4\u94aa\u76d1\uce3f\u08a6", "\udb9b\udff8\udb21\udeff\udb0a\ude87\uda81\udd8e\ud985\udf1e\ud9e0\udd2f\udb70\udcdf\ud9bd\ude12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udd86\ud8bc\ude0b\ud8f9\udee6\uda83\udf98\udae4\udc9b\ud9e0\uddf5\ud9ac\uddbb\ud807\udcdf\uda69\udfe8\u6b04\ud975\ude78\ud8f5\udc27\uda0c\uddba\udbc1\udfa6\ud9a9\uddfe\ud8e0\udca6\udb8e\udcbf\udabb\udeac\uda80\udd63",
        9, 65673, 147557780, 5205992246316249913L, 78561L, true, false, (char) 35777, (char) 2908,
        Double.longBitsToDouble(0x3fe14e57f344ac08L), Double.longBitsToDouble(0x3fc28158f7cb4b48L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.util.Date:Fri Aug 04 12:00:00 PDT 164970958\0121=java.util.Date:Fri Aug 04 12:00:00 PDT 164970958\012",
        Z.run(T, 2, 12, 12, 10, "\ud9e2\ude07\ud8ad\udf3e\uda90\udd9b", "\u85a2\ucb09\u0328\uaac4\u94aa\u76d1\uce3f\u08a6", "\udb9b\udff8\udb21\udeff\udb0a\ude87\uda81\udd8e\ud985\udf1e\ud9e0\udd2f\udb70\udcdf\ud9bd\ude12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udd86\ud91e\udc3b\ud8d4\udf56\ud93c\uddd5\udae8\udede\ud9e0\uddf5\ud9ac\uddbb\ud97a\udc79\uda6a\udc17\u6b04\ud975\ude78\ud8f5\udc27\uda0c\uddba\udbc1\udfa6\ud94b\udcae\uda6f\udeb3\udb23\udebf\ud940\udcd0\ud8fd\udd9d",
        9, 65673, 1262668202, 5205918454483137337L, 78561L, true, false, (char) 35777, (char) 2908,
        Double.longBitsToDouble(0x3fe14e57f344ac08L), Double.longBitsToDouble(0x3fdeb0ac748a907eL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.util.Date:Thu Oct 16 06:59:21 PDT 59342425\0121=java.util.Date:Thu Oct 16 06:59:21 PDT 59342425\012",
        Z.run(T, 2, 12, 12, 8, "\ud9e2\ude07\ud8ad\udf3e\uda68\udf9b", "\u724e\u8b87\u6a44\uaac4\u545f\u76d1\uce3f\u913d\uaa75\ua904\u3b42\u5dfe\u0cbf\ud4de\u31b1", "\ud9ac\udf12\ud9b8\udde2\ud84d\uddab\uda5f\udca7\udb33\udddb\ud8bc\ude0b\ud8f9\udee6\ud9ca\udd90",
        13, 75201, 1926595319, 1872603915083960846L, -43366L, false, false, (char) 31772, (char) 26029,
        Double.longBitsToDouble(0x3feb2ead20a6263bL), Double.longBitsToDouble(0x3fe2117d7679a288L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\ud811\udff2\u6995", "\u389b\u5620\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u501d", "\udb70\udcdf\ud9a5\ude12\ud956\udfb2\udb6d\udd75\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6",
        10, 88744, -1240506799, 8274663888167686999L, 66362L, false, false, (char) 38263, (char) 31772,
        Double.longBitsToDouble(0x3fe1307c3f65d5a4L), Double.longBitsToDouble(0x3fdd5e83b8cdf934L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jul 10 05:25:50 PDT 216808349\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 15, 13, "\ud8ea\ude56\udab5\uddee\ud894\uddd2", "\u389b\u5ead\ube11\u9cbd\ub43c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\ud982\udd32\uda0d\udf3e\udb2b\udcfd\ud9a2\udd47\ud98c\udfab\udaf2\ude3b\udb85\udfff\u9ab5\ud850\uddb7\ud905\udd55\ud920\udea8\udb37\udd3a\ud890\udc9e\ud850\udca1\uda7d\udf49\ud8c8\udec3\u1ad5\ud9dc\udd7e\udb1d\udd7a\u3539",
        30, 3, -712655514, 6841748511865550309L, -32137L, true, false, (char) 17559, (char) 9568,
        Double.longBitsToDouble(0x3fedc8afa97c349aL), Double.longBitsToDouble(0x3fe94487aa30891eL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jul 10 05:25:50 PDT 216808349\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 14, 12, "\ud8ea\ude56\udab5\uddee\ud894\uddd2", "\u389b\u5ead\ube11\u9cbd\ub43c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\ud982\udd32\uda0d\udf3e\udb2b\udcfd\ud9a2\udd47\ud98c\udfab\udaf2\ude3b\udb85\udfff\u9ab5\ud850\uddb7\ud8ff\ude55\ud920\udea8\udbf3\udd58\udbb1\udf45\ud850\udc89\uda7d\udf49\ud8c8\udec3\u1ad5\ud9dc\udd7e\udb1d\udd7a\u3539",
        30, 3, -712655514, 6841748511865550309L, -32137L, true, false, (char) 17559, (char) 9568,
        Double.longBitsToDouble(0x3fedc8afa97c349aL), Double.longBitsToDouble(0x3fe94487aa30891eL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.util.Date:Sun Mar 10 19:06:21 PDT 232556222\012",
        Z.run(T, 1, 2, 4, 15, "\ud9e2\ude0e\u94fc\ud9e2\udd91", "\ud7b6\u49cc\ub65b\uaac4\u9ad5\u4d0a\ubb68", "\udb5e\uddc9\udb3d\udff1\udb42\udcd3",
        -3, 75865, -888347938, 7338703373978781200L, 42608L, true, true, (char) 46596, (char) 12515,
        Double.longBitsToDouble(0x3fc49e97d54d6bd8L), Double.longBitsToDouble(0x3fa01e8018aa4670L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 13, 10, "\ud9e2\ude07\udace\udd10\u6a6b\udad5\udd95", "\u5ead\ub65b\uaac4\uc413\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u8e96\u35cc\uca45\u3ba5\u339d\uc690\u5939\ua0c4\ud60f\u8762\u2c6b\u7a84\ub7ef\u80ac\ub17f\ub2d4\ua7a6\ud223\u3ee5\u76e9\uadd9\u9f83\u6644\u87f1\u0844", "\udb3d\udc65\ud8d9\udfe6\udaf9\udc7f\udaa0\udd85\ud8a5\udecc\udb48\ude03\udbb3\udd75\ud9c9\udcdb\uda70\udf58\ud8e9\udd4f\uda16\udf74\ud952\udce5\ud8bc\udd2c\uda4e\udf98\udb26\ude5e\ud945\udf5c\ud8bb\udd73\ud8eb\udf3b\udba3\udccd\ud944\udf19\udb0b\udc1e\udb1c\udf60\udbfe\udeba\udb5f\udc32\udb3e\udcde\u0478\udb64\udd9b\ud912\uded0\udbc4\udf08\ud93f\ude15\ud82f\udcf7\ud8e7\udeed\u5d8b\ud9a8\uddb5\udbb3\udd5d\ud947\ude6a\ud900\udd6b\ud85e\udc13\ud8f4\udc73\ud85b\udf96\udb09\ude4b\ud959\udf16\ud8b7\udfd4\ubb1f\udbda\udddb\ud928\udebd\uda53\udf70\ud9c3\uddb7\udaeb\udcc2\ud934\udf2a\uda16\udc97\udafc\udc37\udad4\udd19",
        56, 14, 599697485, 8396603237625691186L, 25770L, true, false, (char) 50327, (char) 19308,
        Double.longBitsToDouble(0x3fd85b917bd6d118L), Double.longBitsToDouble(0x3fc1f7da7d02bd88L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jul 10 05:25:50 PDT 216808349\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 15, 13, "\ud8ea\ude56\udab5\uddee\ud894\uddd2", "\u389b\u5ead\ube11\u9cbd\ub43c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\ud982\udd32\uda0d\udf3e\udb2b\udcfd\ud9a2\udd47\ud98c\udfab\udaf2\ude3b\udb85\udfff\u9ab5\ud850\uddb7\ud905\udd55\ud920\udea8\udb37\udd3a\ud890\udc9e\ud850\udca1\uda7d\udf49\ud8c8\udec3\u1ad5\u00a2\000\u3539",
        43, 0, -712655514, 6841748511865550309L, -32137L, true, false, (char) 17559, (char) 15200,
        Double.longBitsToDouble(0x3fc722a005f0d268L), Double.longBitsToDouble(0x3fe94487aa30891eL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 14, 12, "\ud8ea\ude56\udab5\uddee\ud894\uddd2", "\u389b<\u7d39\u9cbd\ub43c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\udb1b\uddec\ud9a2\udd47\ud98c\udfab\udaf2\ude3b\udb85\udfff\u9ab5\ud850\uddb7\ud8ff\ude55\ud920\udea8\udbf3\udd58\udbb1\udf45\ud850\udc89\uda7d\udf49\ud8c8\udec3\000\udaa8\uddd3\udb1d\udd7a\u3539",
        -5, 0, 102, 6841748511865550309L, -32137L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 14, 2, "\ud8ea\ude56\udab5\uddee\ud894\uddd2", "\u389b<\u7d39\u9cbd\ub43c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\udb1b\uddec\ud9a2\udd47\ud98c\udfab\udaf2\ude3b\udb85\udfff\u9ab5\ud850\uddb7\ud8ff\ude55\ud920\udea8\udbf3\udd58\udbb1\udf45\ud850\udc89\uda7d\udf49\udbeb\udd55\udbc6\uddfa\udaa8\uddd3\udb1d\udd7a\u3539",
        -3, 8, 102, 6841748511865550309L, -32137L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Long:14\012",
        Z.run(T, 2, 0, 14, 2, "\ud8ea\ude56\udab5\uddee\ud8a9\uddd2", "\u389b<\u7d39\u9cbd\ub43c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\ud9a2\udd47\ud98c\udfab\udaf2\ude3b\udb85\udfff\ud97d\udee0\ud854\udd0a\ud8ff\ude55\ud920\udea8\udbf3\udd58\ud933\udc26\ud850\udc89\uda7d\udf49\udbeb\udd55\ud8de\ude06\uda84\ude42\udb1d\ude1a\u3539",
        2, 5, -553648026, -4464251243521236682L, -57194L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 15, 2, "\ud8ea\ude56\udab5\uddee\ud894\uddd2", "\u389b<\u7d39\u9cbd\uc03c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\udb1b\uddec\ud9a2\udd47\ud98c\udfab\udaf2\ude3b\udb85\udfff\u9ab5\ud850\uddb7\ud8ff\ude55\ud920\udea8\udbf3\udd1f\udbb1\udf45\ud850\udc89\uda7d\udf49\udbeb\udd55\udbc6\uddfa\udaa8\uddd3\udb1d\udd7a\ud9bc\udc78",
        -2, 8, 102, 6841748511865550309L, -32137L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 14, 2, "\ud8ea\ude56\ud830\ude4b\ud8a9\uddd2", "\u389b<\ub158\u2981\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\udba6\udc36\udb29\uddaf\udaf2\ude3b\ud97c\udc5a\ud9be\udc4b\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbeb\udd55\ud8ef\udf06\uda84\ude42\udb1d\ude1a\u3539",
        4, 5, 580879336, 7886956221571445982L, -57194L, false, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.util.GregorianCalendar:java.util.GregorianCalendar[time=-4464251243510400000,areFieldsSet=true,areAllFieldsSet=true,lenient=true,zone=sun.util.calendar.ZoneInfo[id=\"America/Los_Angeles\",offset=-28800000,dstSavings=3600000,useDaylight=true,transitions=185,lastRule=java.util.SimpleTimeZone[id=America/Los_Angeles,offset=-288...\0121=java.lang.Long:0\012",
        Z.run(T, 2, 10, 15, 2, "\ud8ea\ude56\udab5\uddee\ud8a9\uddd2", "\u389b<\u7d39\u9cbd\ub43c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\ud9a2\udd47\ud98c\udfab\ud830\udc99\ud83d\udca8\ud97d\udee0\ud854\udd0a\ud8ff\ude55\ud920\udea8\udbf3\udd58\ud933\udc26\ud850\udc89\uda7d\udf49\udbeb\udd55\ud8de\ude06\uda84\ude42\udb1d\ude1a\u3539",
        2, 5, -553648026, -4464251243521236682L, -57194L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.Long:14\0121=java.lang.Long:14\012",
        Z.run(T, 2, 14, 14, 2, "\ud8ea\ude56\udab5\uddee\ud8a9\uddd2", "\u389b\u3ae6\u39c9\u9c7c\ub43c", "\ud9ff\udc7e\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\ud9ba\udf9c\ud9a2\ude0c\ud98c\udfab\udaf2\ude3b\udb85\udfff\ud9ed\udfe5\ud854\udd0a\ud8ff\ude55\ud920\udea8\udbf3\udd58\ud933\udc26\ud850\udc89\uda7d\udf49\udbeb\udd55\ud9f8\ude33\ud8b6\ude3b\udb1d\ude1a\u3539",
        2, 5, -553648026, -4464251243521236682L, -57194L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.util.Date:Fri Apr 27 08:44:05 PDT 249929663\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 14, 2, "\ud8ea\ude56\ud830\ude4b\uda63\ude0e", "\u389b\uab7e\u9195\u6570\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\udba6\udc36\ud897\udca6\udaf2\udd9a\ud97c\udc5a\ud9be\udc4b\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbeb\udd55\ud8ef\udf06\uda16\udc67\udb1d\udd7f\ud94b\udd42",
        10, 5, 580879336, 7886956221571445982L, -57194L, false, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 14, 2, "\ud93b\udd9f\ud830\udd92\ud8a9\uddd2", "\u5215\u0db3\ub158\u2981\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\uda5d\udf4e\ud9cd\udde5\udba6\udc36\udb29\uddaf\ud99b\udc0f\ud97c\udca3\ud9be\udc4b\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\udba5\udd84\udbeb\udd82\ud8ef\udf06\uda84\ude42\udb1d\ude1a\u3539",
        9, 5, 580879336, 7887005979069560030L, -95046L, true, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Long:0\012",
        Z.run(T, 2, 0, 14, 2, "\ud8ea\ude0e\ud830\ude4b\ud8a9\uddd2", "\u389b<\u9b9d\u2981\ub43c", "\u05d6\ud8d7\ude07\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\udba6\udc36\udb29\uddaf\udaf2\ude3b\ud97c\udc5a\ud9be\udc4b\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbeb\udd55\ud8ef\udf06\udb59\udd1a\udb1d\ude1b\udbe5\udfc3",
        13, 5, 580879336, 7886956221571445982L, -57194L, false, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 14, 2, "\ud8ea\ude6d\ud830\ude4b\ud8a9\uddd2", "\u389b<\u41fd\u2981\ub43c", "\ud943\ude14\ud85b\uddbb\udb5e\uddc9\ud800\udea7\ud98c\udc18\ud8c1\ude7e\uda40\udeac\udb29\udd75\ud850\udea9\uda3e\udf61\ud9be\udc5a\udbc6\uddbb\ud875\udfbf\uda9b\uddc1\udbf3\udd58\ud97d\udeeb\ud898\udcf9\ud854\udfb6\ud83d\ude5d\ud82e\udc1d\ud897\udedb\udb1d\ude1a\u3539",
        4, 5, 580879336, 7886956221638856414L, 73878L, false, false, (char) 63538, (char) 35269,
        Double.longBitsToDouble(0x3fdf675a3e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 15, 15, 2, "\ud8ea\ude56\ud830\ude4b\ud8a9\uddd2", "\u389b<\ub158\u2981\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\udba6\udc36\udb29\uddaf\udaf2\ude3b\udb6a\udff2\ud90d\udcf5\udbc6\uddbb\ud875\udfbf\ud831\uddc4\ud98f\udd66\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbeb\udd55\ud9f3\udf05\uda84\ude42\udb1d\ude1a\u3539",
        4, 5, 580879336, 1044581012712109278L, -57194L, false, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.util.Date:Wed May 02 03:44:05 PDT 249929663\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 14, 2, "\ud8ea\ude56\ud830\ude4b\uda63\ude0e", "\u389b\uab7e\u9195\u6570\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\udba6\udc36\ud897\udca6\udaf2\udd9a\ud97c\udc5a\ud9be\udc4b\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbeb\udd55\ud8ef\udf06\uda16\udc67\udb1d\udd7f\ud94b\udd42",
        7, 5, 580879336, 7886956221571445982L, -57194L, false, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3f96d962e1be6000L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test104() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jun 13 13:48:53 PDT 26155066\0121=java.lang.Long:0\012",
        Z.run(T, 2, 1, 14, 2, "\ud8ea\ude56\ud830\ude4b\uda63\ude0e", "\u0c73\uab7e\u9195\u6570\ub43c", "\ud848\udc6c\ud8ee\udd8c\udb5e\uddc9\ud95e\udc01\000\ud9e7\uddf2\udba6\udc36\uda40\udd7a\ud87b\udd82\udaeb\udedb\ud9e8\ude5a\ud940\udd2b\ud89f\udcd1\ud831\uddc4\uda9e\udeb2\udbe7\udcb3\ud8f1\udc9c\uda7a\ude70\udbeb\udd55\ud8ef\udf06\uda16\udc67\udb7c\ude2c\udbfd\udf03",
        12, 5, 580879336, 825312009300233226L, -57194L, false, false, (char) 38506, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test105() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Long:27\012",
        Z.run(T, 2, 0, 14, 2, "\ud93b\udd9f\ud830\udd92\ud8a9\uddd2", "\u5215\u0db3\ub158\u2981\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\uda5d\udf4e\ud9cd\udde5\udba6\udc36\udb29\uddaf\ud99b\udc0f\ud97c\udca3\ud9be\udc4b\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\udbac\uddc8\udbeb\udd82\ud8ef\udf06\uda84\ude42\udb1d\ude1a\u3539",
        1, 5, 580879336, 7887005979069560030L, -95046L, true, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test106() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 14, 14, 2, "\ud8ea\ude0e\ud830\ude4b\ud8a9\uddd2", "\u389b\u98d3\u9b9d\u2981\ub43c", "\u05d6\ud8d7\ude07\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\udba6\udc36\udb29\uddaf\udaf2\ude3b\ud97c\udc5a\ud9be\udc4b\udbc6\uddbb\ud894\udc45\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbeb\udd55\ud9dc\udc5d\udb40\udf48\udb1d\ude1b\udbe5\udfc3",
        13, 5, 580879336, 7886956221571445726L, -57194L, false, false, (char) 38161, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test107() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 14, 2, "\ud8ea\ude0e\ud830\ude4b\ud8a9\uddd2", "\u389b<\u9b9d\u2981\ucfe1", "\u05d6\ud8d7\ude07\udb5e\uddc9\udab9\udd4e\000\ud9e7\uddf2\ud814\udd0c\udb8a\udfd5\ud8f0\udcaa\ud97c\udc5a\ud9b1\udd01\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udb41\udc1a\ud97b\udf8a\udb50\udd3e\ud96b\uddc6\u381d\ud8ef\udf06\udb59\udd1a\udb1d\ude1b\udbe5\udfc3",
        32, 1, 580879336, 7886956224926889182L, -57194L, false, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test108() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jul 21 12:23:37 PST 116014288\0121=java.lang.Long:0\012",
        Z.run(T, 2, 1, 14, 2, "\ud8ea\ude56\ud830\ude4b\uda63\ude0e", "\u389b\uab7e\u08de\u6570\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4ej\udaaf\ude02\udba6\udc36\ud897\udca6\udaf2\udd9a\ud986\udd8e\ud9be\udc4b\udbc6\uddbb\udb62\udf6e\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbeb\udd55\ud957\ude1b\uda16\udc67\udb1d\udd7f\ud94b\udd42",
        6, 5, 580879336, -3661194613750582050L, -57194L, true, false, (char) 23110, (char) 30742,
        Double.longBitsToDouble(0x3f96d962e1be6000L), Double.longBitsToDouble(0x3fec2ffeb0001c95L)));
  }
  @Test(timeout = 4000)
  public void test109() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 14, 14, 2, "\ud8ea\ude56\ud830\ude4b\uda63\ude0e", "\u389b\uab7e\u08de\u6570\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4ej\udaaf\ude02\udba6\udc36\ud897\udca6\udaf2\udd9a\ud986\udd8e\ud9be\udc4b\udbc6\uddbb\udb62\udf6e\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbeb\udd55\ud957\ude1b\uda16\udc67\udb1d\udd7f\ud94b\udd42",
        6, 5, 580879336, -3661194613750582050L, -57194L, true, false, (char) 23110, (char) 30742,
        Double.longBitsToDouble(0x3f96d962e1be6000L), Double.longBitsToDouble(0x3fec2ffeb0001c95L)));
  }
  @Test(timeout = 4000)
  public void test110() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u7c9a\u071e\ubdc0\u6ef7\ua240", "\udb13\udebe\ud98d\ude84",
        26, 6058, 440733647, -9004414333651169251L, -70513L, false, false, (char) 44145, (char) 60382,
        Double.longBitsToDouble(0x3faf34c711b5ca80L), Double.longBitsToDouble(0x3fcf968f52b12024L)));
  }
  @Test(timeout = 4000)
  public void test111() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Long:0\012",
        Z.run(T, 2, 0, 14, 2, "\ud8ea\ude56\ud830\ude4b\ud8a9\uddd2", "\u389b<\ub158\u2981\ub43c", "\ud87b\udfd3\ud8d7\ude8a\u69e8\ud81c\udfcc\000\ud9e7\uddf2\udba6\udc36\udb29\uddaf\udaf2\ude3b\uda28\udd79\ud985\udc8c\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbc4\udec1\ud960\udcd9\uda84\ude42\ud833\ude24\ud922\ude2c",
        11, 5, 580879336, 7886956221571445982L, -57194L, false, false, (char) 23040, (char) 30971,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test112() throws Throwable {
    assertEquals("0=java.lang.Long:27\0121=java.lang.Long:27\012",
        Z.run(T, 2, 14, 14, 2, "\ud93b\udd9f\ud830\udd92\ud8a9\uddd2", "\u5215\u0db3\ub158\u2981\ub43c", "\ud87b\udfd3\ud8d7\ude8a\udb5e\uddc9\udab9\udd4e\uda5d\udf4e\ud9cd\udde5\udba6\udc36\udb29\uddaf\ud99b\udc0f\ud97c\udca3\ud9be\udc4b\udbfa\udd15\ud9e2\udccf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\udbac\uddc8\udbeb\udd82\ud8ef\udf06\uda84\ude42\udb1d\ude1a\u3539",
        1, 5, 580879336, 7887005979069560030L, -95046L, true, false, (char) 23040, (char) 30742,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d80001c95L)));
  }
  @Test(timeout = 4000)
  public void test113() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 2, 10, "\ud9e2\ude07\udace\udd10\u6a6b", "\u389b\u5ead\ub65b\uaac4\u545f\u4d0a\ubb68\u0832\u387d\u33d6\ua3e1\u7ef1\u18c4\u7ef8", "\udb70\udcdf\ud9a5\ude12\ud9b8\udde2\udb9d\uddb3\uda5f\udca7\udb37\udd3a\ud8bc\ude0b\ud8f9\udee6",
        13, 88864, -1240506799, 8274663888167686999L, 66362L, false, false, (char) 38263, (char) 31772,
        Double.longBitsToDouble(0x3fe1307c3f65d5a4L), Double.longBitsToDouble(0x3fdd5e83b8cdf934L)));
  }
  @Test(timeout = 4000)
  public void test114() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 14, 14, 2, "\ud8ea\ude56\ud830\ude4b\ud8a9\uddd2", "\u389b<\ub158\u2981\ub43c", "\ud87b\udfd3\ud8d7\ude8a\u69e8\ud81c\udfcc\000\ud9e7\uddf2\udba6\udc36\udb29\uddaf\udaf2\ude3b\uda28\udd79\ud985\udc8c\udbc6\uddbb\ud875\udfbf\ud831\uddc4\udbf3\udd58\ud97d\udeeb\ud898\udcf9\uda7a\ude70\udbc4\udec1\ud960\udcd9\uda84\ude42\ud833\ude24\ud922\ude2c",
        11, 5, 580879336, 7886956221571445982L, -57194L, false, false, (char) 23040, (char) 30971,
        Double.longBitsToDouble(0x3fdf67562e1be600L), Double.longBitsToDouble(0x3fec2a5d8569d82bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.time.DateUtils|isSameLocalTime|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang3.time.DateUtils|add|java.util.Date,int,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addDays|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addHours|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addMilliseconds|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addMinutes|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addMonths|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addSeconds|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addWeeks|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|addYears|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|ceiling|java.util.Calendar,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|ceiling|java.lang.Object,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|ceiling|java.util.Date,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|getFragment|java.util.Calendar,int,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|getFragment|java.util.Date,int,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|getFragmentInDays|java.util.Calendar,int|static",
    "M|org.apache.commons.lang3.time.DateUtils|isSameLocalTime|java.util.Calendar,java.util.Calendar|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
