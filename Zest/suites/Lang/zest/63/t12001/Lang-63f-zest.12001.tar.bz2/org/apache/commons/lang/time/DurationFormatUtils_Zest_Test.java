package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DurationFormatUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\u33fa\u090b\uc5ad", "\ud8de\udd54\uda58\udccc\udabb\udc01",
        19, 36747, 360909734, 6217650478919426294L, 34245L, true, true, (char) 51220, (char) 40993,
        Double.longBitsToDouble(0x3fc92a04388903a8L), Double.longBitsToDouble(0x3fdaacd277804d3aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 11, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\ud85c\udd76\ud9cc\ude2b", "\u33fa\u090b\uc5ad", "\ud8de\udd54\uda58\udccc\udabb\udc01",
        19, 36747, 360909734, 6217650478919426294L, 34245L, true, true, (char) 51220, (char) 40993,
        Double.longBitsToDouble(0x3fc92a04388903a8L), Double.longBitsToDouble(0x3fdaacd277804d3aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\u33fa\u090b\uc5ad", "\ud8de\udd54\uda58\udccc\udabb\udc01",
        53, 36784, 360909734, -3366009528124989194L, 34245L, true, true, (char) 51220, (char) 40993,
        Double.longBitsToDouble(0x3fc93764388903a8L), Double.longBitsToDouble(0x3fdaacd277804d3aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 5, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud867\udf16", "\u057c\u4fcd\u0e0d\u196f\u33fa\u090b\uc5ad", "\ud8b0\udf38\uda58\udccc\udabb\udc01\ue67c",
        27, 35734, 1447659563, 398464072438817525L, -34333L, false, true, (char) 40993, (char) 10474,
        Double.longBitsToDouble(0x3fe1120755aacd27L), Double.longBitsToDouble(0x3fb849a774297360L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud8b7\udd6f\ud9bb\udca2\ud9af\udfad\ud8b6\udffe\udb2f\uddb4\ud844\udf6f\ud977\udca4\udaa1\uddf0", "\u33fa\u86ab\u5b3d\u6240\u7604\ubda5\ucba0\u6bb2\u3228\ud4ab\u03cf\u75eb\ubeeb\u69a0\u1eec\u6f30\u6b18\u49d7\ua5b9\u41de\u936e\u61d3\ub596\u9c03\u64fa\u5b1b\u3ce3\u3efd\uc89e\u9425\ud638\ua8a3\u40cf\u216b\u3c42\u71b5\u908c\u9b48\u4f40\u996e\u7e5e\u07f2\u146b\ub75a\u5fb5\u1900\uaf55\u9105\uaf4e\u7b55\u9293\u3e44\u347d", "\ud945\ude3e\ud809\udd5b\ud896\udc94",
        3, 68899, -1705280844, -4300205399643177040L, 85455L, true, false, (char) 58514, (char) 25660,
        Double.longBitsToDouble(0x3fdd8569fca89618L), Double.longBitsToDouble(0x3fc9f8f0f165147cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\udbbe\udd05\uda36\udd5b\ud99a\ude48\udbc2\udc31\ud996\udfd8\udabb\ude0f\ud8a2\udc78\ud86a\uddfb\uda98\udd00\ud859\udf2a\ud857\udf34\udbe2\udc70", "\ud48a\u3eed\u4940\ud524\u8e6f", "\ud939\udc1f\udaa9\udd70\ub1ff\udb7d\udf97\ud95f\udc9c",
        27, 48194, 341323527, -1627907086452054008L, -86143L, true, false, (char) 40373, (char) 46438,
        Double.longBitsToDouble(0x3fe4b44b723d2cb0L), Double.longBitsToDouble(0x3fd440788f9ff706L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud8e7\ude46\ud90e\ude17\ud9af\udfad\ud81c\ude96\ud80b\udde2\ud8d3\ude99\ud889\ude96\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\udb68\uddfa\uda98\udd00\ud859\udf2a", "\u7965\u7f28\uc522", "\uda0d\udcea\udabe\udf79\udb76\ude32\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ud8fa\ude05\udb7d\udf97\ud95f\udc9c\udb88\udf22\ud925\udfc3\uda46\udc59\ud918\udde2\ud81e\udcab\ud99d\uddea\ud944\udc31\ud966\udeb0\uda2d\udc14\ud87d\ude98\ud83d\ude4c\ud9bc\udd13",
        5, 71544, -95004899, 7953632159337074323L, -64521L, false, true, (char) 23951, (char) 58670,
        Double.longBitsToDouble(0x3fe515b7b9a9f6a6L), Double.longBitsToDouble(0x3fee4efd2409093fL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:548279980:33:47.840\012",
        Z.run(T, 1, 5, 11, 1, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\uded0\udb2c\udc28\ud8d3\udf28\udbe8\udd7c\ud914\udd85", "\u33fa\u090b\uc5ad", "\udae2\udc75\ud82d\udf1f\ud810\udce4",
        19, 36747, 360909734, 6217650478701227840L, 56438L, true, false, (char) 10474, (char) 24332,
        Double.longBitsToDouble(0x3fdaacd27f51c33aL), Double.longBitsToDouble(0x3fe759b52b1b0fecL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud8e7\udf1b\ud90e\ude17\ud9af\udfad\udbb2\udd5d\ud940\udf47", "\u5d43\u0e0d\u77d8\u2f36\u0991", "\udaa7\ude30",
        7, 86302, 281253180, -2988425819866536364L, 59061L, true, false, (char) 43131, (char) 25309,
        Double.longBitsToDouble(0x3fd829d281b602f8L), Double.longBitsToDouble(0x3fe6fbaa10c95021L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\ude90\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\u6b14\ud905\udd82\ud9cc\ude2b\udad5\udd72\ud88e\udfe2\012",
        Z.run(T, 1, 2, 7, 2, "\ud8e7\ude90\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\u6b14\ud905\udd82\ud9cc\ude2b\udad5\udd72\ud88e\udfe2", "\uc5ad", "\ud981\udc63\udb61\udccf\udad3\udd86",
        19, 36747, 360909734, 6217650480780706038L, 27899L, true, true, (char) 51220, (char) 40787,
        Double.longBitsToDouble(0x3fc92a04325503a8L), Double.longBitsToDouble(0x3fa1ec30524266e0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\ud824\udce0\ud987\udd07\udb2e\udc6d\ud8f7\udc9c\012",
        Z.run(T, 1, 12, 2, 6, "\ud824\udce0\ud987\udd07\udb2e\udc6d\ud8f7\udc9c", "\u057c\u4fcd\u0e0d\u9cb0\u0145\u3f8e\uc5ad", "\ud8de\udd54\uda58\udccc\ud9aa\ude40",
        7, 36747, 517999526, 3119174598357789465L, 81093L, true, true, (char) 51220, (char) 40993,
        Double.longBitsToDouble(0x3fe8cf5286224062L), Double.longBitsToDouble(0x3fe556693ca8441fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[]]\012",
        Z.run(T, 1, 0, 7, 2, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2", "\u4fcd\u0e0d\u196f\u33fa\u090b\uc5ad\u7379\u38e8\u7965\ub83d\u3d55\u2c1b\u4940\ud524\u8e6f\uaf83\u3e2f\u1eec\u6f30\ud60f\u49d7\ua5b9\u41de\u936e\u1819\u471e\u7bfc\uc307\u68d6\uc32e\uc429\u4607\u59aa\uc08d", "\ud8ee\udd0d\ud827\udc20",
        16, 19686, -266050671, 7458076439267236398L, -31378L, true, true, (char) 53850, (char) 48271,
        Double.longBitsToDouble(0x3fe95d52705e39ecL), Double.longBitsToDouble(0x3fcbc850aba035bcL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\ud8f1\udda0\ud831\udfe9\uda4c\udd7c\012",
        Z.run(T, 1, 2, 10, 9, "\ud8f1\udda0\ud831\udfe9\uda4c\udd7c", "\ua4b9", "\udaae\udd1e\ud8af\udf97\udbb9\udda9\ud82d\udf2c\ud95f\udf29\udbd6\udeb3\uda64\udc50\ud8de\udd54\ud9c8\ude29\ud99d\udedc\ue635\ud91d\udcd3\uda0d\udcea\ud8c6\udffe\uda4f\udf70\udba5\udfb9\ud939\udc1f\udaa9\udd70\ue5ff\udb7d\udf97",
        20, 23074, 647873962, 4358600158709925111L, 98881L, true, false, (char) 28513, (char) 15048,
        Double.longBitsToDouble(0x3f833a28c0471780L), Double.longBitsToDouble(0x3fe227a638803e7bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\ud92c\udd3c\ud90e\ude17\udb72\uddf0\ud8b2\uddad\ud81c\udfe2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud86a\uddfb\uda98\udd00\012",
        Z.run(T, 1, 12, 7, 2, "\ud92c\udd3c\ud90e\ude17\udb72\uddf0\ud8b2\uddad\ud81c\udfe2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud86a\uddfb\uda98\udd00", "\u38e8", "\udabb\udc01\ue67c\ud91d\udcd3\uda0d\udcea\udb1b\udf40\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\udb7d\udf97\ud95f\udc9c\udb88\udf22\udbf5\ude2b\uda93\udc23\udb30\udd94\udb0f\udd30\udaaa\udf2f\ud80c\udcc4\udaeb\ude29\udb29\udde0\ud8b8\ude42\ud827\udc12\ud960\udd83",
        9, 65814, 15929805, -494655413904599168L, 25246L, true, false, (char) 48222, (char) 41293,
        Double.longBitsToDouble(0x3fe27e653bcf72f1L), Double.longBitsToDouble(0x3fedb7122007fd17L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud97e\ude4a\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud8a8\udfb5\ud922\ude85\udbe8\udd7c\ud9cc\ude2b", "\u33fa\u090b", "\udaa7\ude30",
        7, 55402, -349520580, 3611107930873507611L, 53739L, false, true, (char) 1057, (char) 57473,
        Double.longBitsToDouble(0x3fd224026a33c130L), Double.longBitsToDouble(0x3fee0134eece1395L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M1765910044DT20H46M50.276S\012",
        Z.run(T, 1, 6, 2, 10, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud86a\uddfb\uda98\udd00", "\u38e8", "\udabb\udc01\ue67c\ud91d\udcd3\uda0d\udcea\udb0f\udd40\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\udb7d\udf97\ud95f\udc9c\udb88\udf22\uda3f\udff0\ud8f5\udfe5\ud825\uddf4\ud8bf\udc37\udbe0\udf04\ud939\udc71\ud830\udd29\uda49\udf5e\ud918\udc00\udb29\udc5c\ud820\udd30",
        17, 11413, 1170348343, 1636915325374010276L, -7599L, false, true, (char) 47042, (char) 1545,
        Double.longBitsToDouble(0x3fe2742a32201566L), Double.longBitsToDouble(0x3fcb825f10e07c08L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 10, 3, "\ud9b1\uddbc\ud95b\ude14\ud9af\udfad\ud81c\uded0", "\u8cd1\ua2f4\u095f\u196f\u33fa\u090b\uc5ad", "\ud876\udc77\ud8cd\udce0\ud89b\udc01\ud959\udf7c\udbcf\udd98\uda0d\udc47\udb0f\udd40\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\udb7d\udf97\ud95f\udc9c\udb88\udf22\uda3f\udff0\ud954\udd8d\udaed\udc5d\uda4d\ude44\ud9b0\udfdf\udae9\uddb8\ud862\ude28\udbe7\ude79\ud8d4\udd69\ud850\udde4\ud8b5\udc9f\ud8cf\udca2",
        27, 50535, 1856085581, -1596335336168176408L, -92158L, false, true, (char) 43004, (char) 21314,
        Double.longBitsToDouble(0x3fe4b17c14af578dL), Double.longBitsToDouble(0x3f9df58fa915a6a0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:316885394 days 6 hours 20 minutes 17 seconds\012",
        Z.run(T, 1, 7, 7, 2, "\ud8e7\udefb\ud90e\ude22\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\u33fa", "\uda2d\udd7c\udaa7\ude30\ud8de\udd54\uda58\udccc\udabb\udc01\ue67c",
        27, 35734, 1447659563, 398464072438817525L, -34333L, false, true, (char) 40993, (char) 10474,
        Double.longBitsToDouble(0x3fe1120755aacd27L), Double.longBitsToDouble(0x3f94b99d096c3940L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\012",
        Z.run(T, 1, 10, 5, 1, "\udb33\udc20\ud90e\ude0d\ud9af\udfad\ud9e2\udff2\uda04\udfe0\ud943\udd3a\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\uda6e\uddbf\udb27\udd9f\udac7\udc4b\ud8b7\udd2b\udaf0\uddaf\ud873\ude1b", "\ud48a\u3eed\u4940\ud524\u8e6f\u848c\u5943\u2836\u2d9a\ud60f\u49d7\ua82e\u41de\u936e\uaa65\u54f9\u0091\u7f8a\uaa4f\u7470\u24bc\u99bd\uacc3\u32b0", "\ud9c8\udccd\ud814\udd77\udb5e\ude92\uda62\udea2\ud9a6\udcbb\ud8c7\udf3c\uda5c\uddf7\u82cc\udb08\udc96\uda14\udf8a\ud888\udf24\udbe9\udc64\udb36\udcd1\udb2a\udd87",
        29, 80715, -610635908, -8065547664961325799L, -41428L, false, true, (char) 33869, (char) 37857,
        Double.longBitsToDouble(0x3fea0c810c5041dcL), Double.longBitsToDouble(0x3fef7abddeea7933L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\udf35\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\012",
        Z.run(T, 1, 3, 6, 2, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\udf35\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\ub94c\u090b\uc5ad\u7379\u38e8\u7965\u7f28\ud48a\u3eed\u4940\ud524\u8e6f\uaf83\uaf5d\u361c\ubf89\ud60f\u49d7\ua5b9\u41de\u936e\u2ba6\uc045\ud099\u2e94\ub97c\uc929\u587c\ubd91\u9c53\u0d13\u30ca\u6b07\u81dc", "\uda59\udd97\ud83e\udec4\ud81a\ude71",
        52, 67085, -227489940, -8040246519586499030L, -87560L, false, false, (char) 6795, (char) 7259,
        Double.longBitsToDouble(0x3fe833d864b5841dL), Double.longBitsToDouble(0x3fd05bdb2eabd124L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:-1056027385 days -6 hours -31 minutes -5 seconds\012",
        Z.run(T, 1, 7, 9, 3, "\ud8e7\udefb\udbd7\udffb\udb0a\udeff\udaa3\udc10\u5a02\ud88a\ude7c\udb18\udd30\uda35\udf6a\udabb\ude0f\ud8a2\udc78\ud95a\udd73", "\u7379\u1acb\ucf75\u7f70\u4aee\u3eed\u03cd\u0316\uc001\u9868\u74fe\u3e33\u6f30\ub44d\u4991\ua5b9", "\ud91e\uddc8\uda80\udcc2\ud94f\udfb4\udb9f\udc48\ud840\udc5f\ud8e0\uddac",
        18, 54217, 995535358, -462325940461865692L, 38396L, false, false, (char) 800, (char) 41712,
        Double.longBitsToDouble(0x3fe84e01c2c3bbc1L), Double.longBitsToDouble(0x3fde6fcdceeb991cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[]]\0121=java.lang.String:978053818 days 20 hours 20 minutes 20 seconds\012",
        Z.run(T, 2, 0, 7, 2, "\ud8e7\udefb\udafc\udd64\ud83c\udcad\udb3d\ude5c\ud80b\udde2\ud8d3\ude99", "\u0e0d\u196f\u33fa\u090b\uc5ad\u7379\u38e8\u69fd\u7f28\ud48a\u3eed\u4940\ud524\u8e6f\uaf83\u3e2f\u1eec\u6f30\ud60f\u49d7", "\ud833\udcf6\uda1c\udcf2\uda7b\udcec",
        56, 75556, -2127940155, 455589024322820896L, 76710L, true, true, (char) 53182, (char) 27887,
        Double.longBitsToDouble(0x3fc40f96b348dbc0L), Double.longBitsToDouble(0x3fced38ceb88626cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:-608497818:47:04.694\012",
        Z.run(T, 1, 5, 0, 2, "\ud8e7\udefb\ud90e\ude4b\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udad4\udd7f\ud9cc\ude2b", "\u33fa\u090b\uc5ad", "\ud8de\udd54\uda58\udccc\udbf6\udfff",
        19, 36747, 360909734, 6259871725426024694L, 34245L, true, true, (char) 25620, (char) 28402,
        Double.longBitsToDouble(0x3fe89a810822c517L), Double.longBitsToDouble(0x3fe254ef73c026b7L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\ud8e7\ude7c\ud90e\ude17\ud9af\udfad\ud81c\udefd]]\0121=new org.apache.commons.lang.time.DurationFormatUtils:@?\012",
        Z.run(T, 2, 9, 10, 1, "\ud8e7\ude7c\ud90e\ude17\ud9af\udfad\ud81c\udefd", "\ub94c\u397b\u0e0d\u196f\u33fa\u5080\uc5ad", "\ud8db\udd34\ud94f\udcee\ud833\udfcb\ue67c\ud91d\udcd3\uda0d\udcea\udb0f\udd40\ud990\udd49",
        4, 5621, 1142955761, 8470804199789112031L, 77719L, true, false, (char) 34008, (char) 49004,
        Double.longBitsToDouble(0x3fc455243a7219ccL), Double.longBitsToDouble(0x3fd5520edaa3d344L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M1288717116DT-21H-27M-28.95S\012",
        Z.run(T, 1, 8, 7, 2, "\u00dc\000\ud98f\udf46\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\uddc8", "\u33fa\u090b\uacad", "\uda0a\udd4a\uda58\udccc\udabb\udc01",
        19, 36747, 360909734, 6197102805619548406L, -99899L, true, true, (char) 51220, (char) 40993,
        Double.longBitsToDouble(0x3fc92a04388903a8L), Double.longBitsToDouble(0x3fdaacd27780013aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\udefb\ud90a\udff6\ue8da\ud8b3\udd45\ud80b\ude65\ud9c6\udfc8\udbe8\udd69\ud9cc\ude2b\012",
        Z.run(T, 1, 4, 7, 2, "\ud8e7\udefb\ud90a\udff6\ue8da\ud8b3\udd45\ud80b\ude65\ud9c6\udfc8\udbe8\udd69\ud9cc\ude2b", "\u33fa\u17eb\u179c", "\ud8d4\udeaf\u2937\udb30\udcf9\ud92a\uddbb\ud91d\udcd3\uda0d\udcea\ud9d0\udd09\ud990\udcb9\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\udae8\udd4c\ud95f\udc3e\udb88\udf22\uda3f\udff0\udb07\ude88\udab6\udca2\uda8f\udcfa\ud9ea\udeaa\ud8b4\udc96\udbdd\udc73\udaee\udd6a\ud9f6\uddfd\ud80f\udfa9\uda59\udc10\ud9f4\udeb6\ud849\uddaf\ud971\udf80\uda39\udf21\udb5d\uddbe\udbe9\uddcd\ud9e8\ude7b\ud8d1\udd6f\ud891\udeac\ud95a\udc4d\udb79\udf30\ud945\udc89\ud95b\udc1c\uda8f\udf5d\ud857\ude64\udb0a\udd1a\ud999\uddad",
        22, 9498, -289848021, 3390511348263301993L, 96745L, true, false, (char) 35850, (char) 58994,
        Double.longBitsToDouble(0x3fec64235bcffe67L), Double.longBitsToDouble(0x3feb736556dbf7b2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:P-263995877Y5M24DT20H35M14.548S\0121=java.lang.String:764999052:-34:-58.12\012",
        Z.run(T, 2, 8, 5, 9, "\udac2\udcf2\uda8b\udcb6\ud9af\udfdb\ud81c\uded0\ud80b\udde2\ud9c8\udd3b\uda9f\udc24\udaa2\udcef", "\ucc23\u090b\uc5ad\u7379\u38e8", "\udabb\udc01\ue67c\uda31\udc7c\uda0d\udc9c\udb0f\udd40\ud990\udd49\ud8c4\udde1\udbd8\udd4e\udaa9\uddc5\ub0ff\udb7d\udf97\ud95f\udc9c\udb4e\udd56\uda3f\udfbf\ud9d9\udcc4\ue71d\udbe7\udf39\ud8a8\udfc7\uda73\udc32\ud91e\udec7\ud966\udf9b\ud9f4\udffa\ud860\udc48\ue547",
        13, 80109, -1204821283, -8331200544573298488L, 16060L, true, true, (char) 23609, (char) 20497,
        Double.longBitsToDouble(0x3fe485b4abe4543cL), Double.longBitsToDouble(0x3fe2138e42a828efL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud8e7\udefb", "\u0814\ud292\u7616\u057c\u4fcd\u0e0d\u196f\u33fa\u090b", "\uda80\udd0d",
        46, 55402, -349520580, 3611107930873507611L, 395L, false, false, (char) 43131, (char) 33245,
        Double.longBitsToDouble(0x3febefdb131664feL), Double.longBitsToDouble(0x3fe6fbaa10c95021L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 8, 2, "\000", "\u0814\ud292\u7616\u057c\u4fcd\u0e0d\u7de0\u8bf9\u090b", "\udaa7\ude30",
        -4, -1000, 0, 3611107930873507611L, 395L, false, false, (char) 43131, (char) 33245,
        Double.longBitsToDouble(0x3febefdb131664feL), Double.longBitsToDouble(0x3fe6fbaa10c95021L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M-813244652DT10H27M54.085S\0121=java.lang.String:1956964842:27:54.085\012",
        Z.run(T, 2, 6, 5, 2, "\ud8e7\udefb\ud940\ude17\uda2f\ude47\ud81c\udf2d\ud814\udf66\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\u33fa\u090b\u3ed0", "\ud8de\udd54\udbd3\udc1d\udb3f\udf8f\ue67c\ud91d\udcd3",
        24, 25563, 92774646, 8464694672716074085L, 56438L, true, false, (char) 52705, (char) 19676,
        Double.longBitsToDouble(0x3fd3728fd7804d3aL), Double.longBitsToDouble(0x3fb3078e5c8d3a58L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M-2009675041DT-11H-42M-35.91S\0121=java.lang.String:\udac7\uddeb\u6ea2\ud996\udcb1\ud80c\udec8\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\udaac\ude7a\012",
        Z.run(T, 2, 6, 1, 2, "\udac7\uddeb\u6ea2\ud996\udcb1\ud80c\udec8\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\udaac\ude7a", "\uc4c4\u090b\ub284\u7379\u0fd2\u8037\u4f24", "\ud91d\udcd3\ud871\udc7d\udb0f\udd40\ud9a3\ude7c\ud8c4\udde1\udb2c\udc59\udb0d\udcd2\ud9f5\ude16\udb7d\udf69\ud95f\udc9c\udb88\udf22\uda3f\udff0\ud99a\ude32\ud98b\udf95\ud8af\udce2",
        25, 94590, 1549588209, -3884487667328555809L, 82196L, true, false, (char) 4647, (char) 34332,
        Double.longBitsToDouble(0x3fe7ba1f8d02e8f1L), Double.longBitsToDouble(0x3fe7ac47555088edL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 2, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\udb38\ude0d\uda33\udf81\udb25\ude67\ud96f\udfa7\udba5\udd4d\udb96\udd5b", "\u73ee\u08e2\u6a42\u2322\ud4f5\u7b3e\uce98\ud524", "\ud8c4\udde1\ud939\udc1f\udb1a\udec9\ud975\udeb9\u03f1\ud893\udce8\udb4a\ude6e\ud95d\udeea\ud9e6\udd45",
        30, 94843, -273031965, 8949935407833346742L, 33241L, true, false, (char) 34833, (char) 42241,
        Double.longBitsToDouble(0x3fe7a9cb5c2096beL), Double.longBitsToDouble(0x3f92f36891180d00L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 9, 6, "\ud84a\udf13\ud818\udf91\ube53\ud81c\udf2d\ud80b\udde2\ud8d3\ude99\ud870\udc40\ud8c8\udffd\ud889\udcf1\ud8c8\uddc3", "\u1f54\u9b00\u8e4e\u7965", "\ue67c\ud91d\udcd3\uda0d\udcea\udb0f\udd40\ud990\udd49\ud8c4\udde1\ud939\udc1f\udad6\udda4\ud87d\udf20\udb7d\udf97\ud95f\udc9c\udb88\udf22\uda3f\udff0\udbe8\uddf8\ud9e2\udeb0\ud840\ude11\udbaf\udf94\uda53\udeff\udbdc\udcac\uda9a\udcf5\uda88\ude56\ud999\uddce\uda30\udd55\u2eca\ud9a0\udc38\udbda\udece\ud994\ude8d\udb08\uddad\ud9f0\udf99\ud86e\uddd0\uda12\ude63\ud8cf\ude4d\ud9e6\udcfc\ud8ec\udd2a\udab3\udf7a\uda63\udde9\uc922\udb27\udc36\ud80e\udd79\ud8dd\udef1\ud81e\udc15\ud8ae\udc13\udb6c\udef6\ud8c1\udc0f\udb32\uddfe\udbc2\ude39\ud87f\udfe2\ud937\ude26\udab6\udc24\ud86b\udf36\ud92d\udd26\ud99e\ude9e\u8da0\ud852\udca8\udad7\udcd0\udbdf\udd53\udb74\udd15\udb58\udd9d\uda5b\udcd2\uda8c\udcd0\uda0a\udfa5\udad4\udf66\udb19\udf83\ud960\udfe0\uda2f\udded\ud927\udcfb\udb27\udfe3\uda3a\udc2f\ud9be\udc91\udb3f\udd0e",
        27, 66891, 236379253, 8427497695276039448L, 52210L, false, false, (char) 4684, (char) 3972,
        Double.longBitsToDouble(0x3feaf40ff94416c4L), Double.longBitsToDouble(0x3f9dd9c195c29180L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\udbc9\udfbb\ud91b\udedd\ud9f7\udf25\ud81c\udf1e\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\udb82\ude65\udab1\udf47\udb34\udce1\ud8c8\ude13\ud8de\udfcc\ud9ac\udf20\ud9df\ude99\udb29\ude31\012",
        Z.run(T, 1, 2, 8, 8, "\udbc9\udfbb\ud91b\udedd\ud9f7\udf25\ud81c\udf1e\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\udb82\ude65\udab1\udf47\udb34\udce1\ud8c8\ude13\ud8de\udfcc\ud9ac\udf20\ud9df\ude99\udb29\ude31", "\uac3e\u0cda\u275f\ud524\u8e6f\uaf83\u3e2f\u1eec\u135fe\uc60f\u0224\u41de\u936e\u59ce\u2d4b\u9a35\u06bf\u59de\u4ed1\u8df9\u99f7\uca8e\ub9e7", "\udb89\udffb\udb35\udd4b\ud8ba\udfd0\ud887\udd36\ud8a5\udc7e\ud8ae\udea7\ud987\udfcf\udb1c\udc1d\ud82b\udc9a\ud8e2\udf8c\udb75\udc0f\udaf0\uddb4\udb7b\udfb5\u8be4",
        47, 74049, -1510273086, 6291781339947416119L, 41051L, true, false, (char) 26888, (char) 39727,
        Double.longBitsToDouble(0x3fd2309865e1a352L), Double.longBitsToDouble(0x3fe6290d513daaecL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:\uda31\ude2b\ud8e5\udca1\ud9af\udfad\uda6b\udcb6\ud83c\udf55\ud8d3\uded1\ud99b\udf28\ud995\udcb8\012",
        Z.run(T, 1, 2, 8, 3, "\uda31\ude2b\ud8e5\udca1\ud9af\udfad\uda6b\udcb6\ud83c\udf55\ud8d3\uded1\ud99b\udf28\ud995\udcb8", "\uc0b7\uc443\ucfcd", "\ud8de\udd54\ud8ac\udd36\udabb\udc01\ue67c\ud91d\udcd3\ud853\udce6\ud9a6\ude23\uda64\uddcf",
        54, 5740, 1922370941, -1272431725642700065L, 99559L, true, true, (char) 4166, (char) 10049,
        Double.longBitsToDouble(0x3fc5201966d0fca0L), Double.longBitsToDouble(0x3fef431980af724fL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 11, "", "\u92b7", "\ud8d3\ude99\ud85c\udd76",
        14, 57987, 0, 7805173118456037376L, 19552L, false, true, (char) 20795, (char) 9907,
        Double.longBitsToDouble(0x3fe8d80003a6d94fL), Double.longBitsToDouble(0x3e1ecac000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u92b7\u81c5\ud292\u7616\u74f2\000\000\u195d", "\000",
        41, 42699, -475671808, -7782414589262906112L, -34421L, false, false, (char) 41471, (char) 33245,
        Double.longBitsToDouble(0x3febefdb131664feL), Double.longBitsToDouble(0x3fe6fbaa10c95021L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\ude1f\012",
        Z.run(T, 1, 2, 7, 2, "\ud8e7\ude1f", "\u0814", "\udbe8\udd7c\ud9cc\ude2b\u467b\000\ud93d\ude5d\uda98\udd00\ud859\udf2a",
        26, -1000, -475671808, -7782414589615227588L, 395L, false, false, (char) 43131, (char) 33245,
        Double.longBitsToDouble(0x3febefdb100000feL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\uda55\udeb5\udab9\udcfd\ud9af\udf99\ud9c2\udf63\0121=java.lang.String:\uda55\udeb5\udab9\udcfd\ud9af\udf99\ud9c2\udf63\012",
        Z.run(T, 2, 3, 3, 1, "\uda55\udeb5\udab9\udcfd\ud9af\udf99\ud9c2\udf63", "\u057c\u4fcd\u0e0d", "\ud896\ude4d\ud882\udc41\ud826\ude6b\ud871\udf10",
        40, 32440, 885300698, 3611107930877308699L, 40906L, false, false, (char) 43131, (char) 26932,
        Double.longBitsToDouble(0x3fedcfdb15ef6acfL), Double.longBitsToDouble(0x3fc39d836327f810L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 5, "\udbee\udede\ud90e\udd60\ud9af\udfad\u5e4e", "\u4e13", "\udbb8\udf5b",
        21, -1000, -738197504, 7015535577130860544L, -54730L, false, true, (char) 9907, (char) 44799,
        Double.longBitsToDouble(0x3fed36ca782b1583L), Double.longBitsToDouble(0x3fcecac92bd4161cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\udacf\udfa0\udbd6\udf6b\ud9c5\udf91\ud867\udf16\ud80b\uddd8\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud933\udf60\uda87\udc68\ud859\udf2a\uda7b\udc24\ud963\uddda\ud97a\udc1c\ud90b\udcac\uda0d\udc0e\udadf\udd7a\udb25\ude4b\uda3c\udda3\udb06\udd8a\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\ud8a7\udd97\ud95f\udc9c\ud8a3\udcd6\ud860\udcc5\ud942\udf1d\ud820\udede\udbce\udd39\udaa2\ude8c\udba9\ude10\udafd\udeb0\ud896\udf37\udb14\udca6\udaaf\ude72\ud8de\udd5a\udaeb\ude17\udb9b\ude3a]]\0121=java.lang.String:\udacf\udfa0\udbd6\udf6b\ud9c5\udf91\ud867\udf16\ud80b\uddd8\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud933\udf60\uda87\udc68\ud859\udf2a\uda7b\udc24\ud963\uddda\ud97a\udc1c\ud90b\udcac\uda0d\udc0e\udadf\udd7a\udb25\ude4b\uda3c\udda3\udb06\udd8a\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\ud8a7\udd97\ud95f\udc9c\ud8a3\udcd6\ud860\udcc5\ud942\udf1d\ud820\udede\udbce\udd39\udaa2\ude8c\udba9\ude10\udafd\udeb0\ud896\udf37\udb14\udca6\udaaf\ude72\ud8de\udd5a\udaeb\ude17\udb9b\ude3a\012",
        Z.run(T, 2, 9, 12, 8, "\udacf\udfa0\udbd6\udf6b\ud9c5\udf91\ud867\udf16\ud80b\uddd8\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud933\udf60\uda87\udc68\ud859\udf2a\uda7b\udc24\ud963\uddda\ud97a\udc1c\ud90b\udcac\uda0d\udc0e\udadf\udd7a\udb25\ude4b\uda3c\udda3\udb06\udd8a\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\ud8a7\udd97\ud95f\udc9c\ud8a3\udcd6\ud860\udcc5\ud942\udf1d\ud820\udede\udbce\udd39\udaa2\ude8c\udba9\ude10\udafd\udeb0\ud896\udf37\udb14\udca6\udaaf\ude72\ud8de\udd5a\udaeb\ude17\udb9b\ude3a", "\u6ca6\ub711\ub613\u9af0", "\ud8af\udf3b\ud95f\udc79\udac0\udc23\ud863\udc6d\udb6b\udd3b\ud9f7\udf58\ud83b\udd53\ud827\ude73\ud983\ude9d\ud877\udcef\ud809\uddf9\uda55\uddc3\udb66\ude10\ud820\ude99\udad4\udf42",
        3, 35307, -1755603678, 7600930424980422739L, 51560L, false, true, (char) 25121, (char) 57318,
        Double.longBitsToDouble(0x3fe0aae20d9b992eL), Double.longBitsToDouble(0x3fd27d84e92d6944L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:1477126110:08:02.181\012",
        Z.run(T, 1, 5, 12, 5, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud8cf\udce9", "\u057c\u4fcd\u0e0d\u196f\u33fa\u090b\uc5ad\u43d4\ua6c5\u9b48\u7f28\ud48a", "\uda0d\udcea\udb0f\udd40\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\udb7d\udf97",
        20, 71602, 647873962, 3345084223366082181L, 77833L, false, true, (char) 9838, (char) 26059,
        Double.longBitsToDouble(0x3fe77944510ea1e9L), Double.longBitsToDouble(0x3fe4d5008bccc807L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\ud8c5\udd85\uda08\ude5f\012",
        Z.run(T, 1, 4, 2, 5, "\ud8c5\udd85\uda08\ude5f", "\u8dfd\u97e4\ub396\uc83e\u2e0d\u196f\u33fa\u090b\u721f\u2b2d\u822c", "\udbf5\udd94\ud8cb\ude12",
        41, 88382, 476615012, 7242596020944540654L, 89670L, true, true, (char) 40993, (char) 2667,
        Double.longBitsToDouble(0x3fe112026daacd27L), Double.longBitsToDouble(0x3fb877e774297360L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:316885394 days 6 hours 20 minutes 17 seconds\0121=new org.apache.commons.lang.time.DurationFormatUtils:@?\012",
        Z.run(T, 2, 7, 10, 5, "\ud8e7\udefb\ud90e\ude17\ud9af\udfad\ud867\udf16", "\u057c\u4f90\u5ef9\u5fe8\u0b56\uafd1\u5fc7", "\ud8b0\udf38\uda58\udccc\ud8c0\udd06\ue67c",
        27, 35734, 1447659563, 398464072438817525L, -34333L, false, true, (char) 40803, (char) 10474,
        Double.longBitsToDouble(0x3fe1120755aacd27L), Double.longBitsToDouble(0x3fb849a774297360L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:\ud8b7\udd6f\ud9bb\udca2\ud9af\udfad\ud8b6\udffe\udbfc\udcb9\ud844\udf60\ud977\udca4\udaa1\uddf0\0121=java.lang.String:1768711723 days -4 hours -52 minutes -57 seconds\012",
        Z.run(T, 2, 4, 7, 2, "\ud8b7\udd6f\ud9bb\udca2\ud9af\udfad\ud8b6\udffe\udbfc\udcb9\ud844\udf60\ud977\udca4\udaa1\uddf0", "\u9c23\u86ab\u5b3d\u6240\u7604\ubda5\ucba0\u6bb2\u3228\ud4ab\u03cf\u75eb\ubeeb\u6f9c\u27e6\u6f30\u6b18\u49d7\ua5b9\u41de\u936e\u61d3\ub596\u9c03\u7701\u5b1b\u3ce3\u3efd\uc89e\u9425\ud638\ua8a3\u40cf\u216b\u3c42\u71b5\u908c\u9b48\u4f40\u996e\u7e5e\u07f2\u146b\ub75a\u5fb5\u1900\uaf55\ud3fb\uaf4e\u7b55\u9293\u3e44\u347d", "\ud945\ude3e\ud809\udd5b\ud896\udc94",
        3, 68899, -1705280844, -4300205399643177040L, 85455L, true, false, (char) 58514, (char) 25660,
        Double.longBitsToDouble(0x3fdd8569fca89618L), Double.longBitsToDouble(0x3fc9f8f0f165147cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\ud8b7\udd6f\ud9bb\udca2\ud9af\udfad\ud894\ude40\udb66\uddfb\udb4b\udd4b\ud977\udca4\ud96d\udc37\ueb4c\udb1e\udcd3\ud86a\uddfb\ud860\ude85\ud980\udebd\udbc3\udd12\udb63\udd63\ud87d\udfc1\ud9b5\udea9\u031c\ud8ad\udc56\ud9c0\udea6\udb98\udf8b\udb41\udc8e\udb79\ude54]]\012",
        Z.run(T, 1, 9, 9, 5, "\ud8b7\udd6f\ud9bb\udca2\ud9af\udfad\ud894\ude40\udb66\uddfb\udb4b\udd4b\ud977\udca4\ud96d\udc37\ueb4c\udb1e\udcd3\ud86a\uddfb\ud860\ude85\ud980\udebd\udbc3\udd12\udb63\udd63\ud87d\udfc1\ud9b5\udea9\u031c\ud8ad\udc56\ud9c0\udea6\udb98\udf8b\udb41\udc8e\udb79\ude54", "\u6f30\u6b18\u49d7\u9485\ua764\u936e", "\udaed\udc6e\ud906\udc81\uda75\udce8\udb34\ude9a\ud94d\udd3a\udaa1\udf2d\ud83d\udeb2\udbc9\udf59\u160e\udb73\udc7d\ud8a6\udece\udb8c\udcc8\uda81\ude0d\udae6\uddb9\udbac\udc8c\ud93e\ude22\uda29\udd15\ud93a\udc14\udb97\udf1f\ud885\udd2e\ud87c\udf78\ud9c3\udde5\ud9a4\udcdf\ud9bf\udfca\uda48\udd97\udb18\udc7a\ud832\udff0\ud816\ude7d\udade\udd89\udb6a\udc80\ud95b\udd6b\uda88\udc77\ud945\ude3e\ud809\udd5b",
        22, 64008, -1052552101, -2063921091700406812L, 52912L, true, true, (char) 5813, (char) 58439,
        Double.longBitsToDouble(0x3fd30bf0cbb0ad3eL), Double.longBitsToDouble(0x3fe2a25860cfc787L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:548280180:29:04.192\0121=java.lang.String:-1050896817 days 12 hours 29 minutes 4 seconds\012",
        Z.run(T, 2, 5, 7, 4, "\ud986\udcca\ud8b8\udfc9\ud9bf\udef4\ud81c\uded0\udb83\udced\ud8d2\udcef\udbe8\udd7c\ud914\udd85", "\u33fa\u100b\uc5ad", "\udae2\udc75\ud84a\udf0e\ud845\udddc",
        35, 36747, 360909734, 6217650479420944192L, -1135L, true, false, (char) 64000, (char) 26641,
        Double.longBitsToDouble(0x3fb34dcfb11200f8L), Double.longBitsToDouble(0x3fdaacd27f51c33aL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\udf1b\ud93c\ude30\ud9af\udfad\udbb2\udd5d\ud940\udf47\0121=java.lang.String:314964639 days 3 hours 44 minutes 27 seconds\012",
        Z.run(T, 2, 2, 7, 2, "\ud8e7\udf1b\ud93c\ude30\ud9af\udfad\udbb2\udd5d\ud940\udf47", "\u5d35\ubf3b\u429e\u2f36\u984b\uc4d1", "\ud8b3\ude43\ud901\udf0d\ud9b7\udea5\ud8e9\udd1b",
        -2, 92150, 1447662251, 398298119197467381L, 42047L, true, false, (char) 6252, (char) 34434,
        Double.longBitsToDouble(0x3fee2af80944384dL), Double.longBitsToDouble(0x3fef263d81d23a26L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M-1050896801DT6H11M46.038S\0121=java.lang.String:-1050896801 days 6 hours 11 minutes 46 seconds\012",
        Z.run(T, 2, 6, 7, 2, "\ud8e7\ude90\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\u6b14\ud905\udd82\ud9cc\ude2b\udad5\udd72\ud88e\udfe2", "\uc5ad", "\ud981\udc63\udb61\udccf\udad3\udd86",
        19, 36747, 360909734, 6217650480780706038L, 27899L, true, true, (char) 51220, (char) 40787,
        Double.longBitsToDouble(0x3fc92a04325503a8L), Double.longBitsToDouble(0x3fa1ec30524266e0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:-1050896801 days 6 hours 11 minutes 46 seconds\0121=java.lang.String:-1050896801 days 6 hours 11 minutes 46 seconds\012",
        Z.run(T, 2, 7, 7, 2, "\ud8e7\ude90\ud90e\ude17\ud9af\udfad\ud81c\uded0\ud80b\udde2\udb46\udca7\ud8fc\udc23\ud9cc\ude2b\udad5\udd72\udbec\udf92", "\uc5ad", "\ud981\udc63\udb61\udccf\udad3\udd86",
        19, 24691, 360909734, 6217650480780706038L, 77051L, true, true, (char) 27803, (char) 16389,
        Double.longBitsToDouble(0x3fc92a04325503a8L), Double.longBitsToDouble(0x3fa1ec302f94a6e0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\ude90\udafd\ude0f\ud85b\udded\ud8c1\udf52\ud843\ude0e\udaa2\udc7f\udad2\ude29\ud9ad\ude08\udad5\udd72\ud88e\udfe2\0121=java.lang.String:-989969168 days 17 hours 23 minutes 1 second\012",
        Z.run(T, 2, 2, 7, 2, "\ud8e7\ude90\udafd\ude0f\ud85b\udded\ud8c1\udf52\ud843\ude0e\udaa2\udc7f\udad2\ude29\ud9ad\ude08\udad5\udd72\ud88e\udfe2", "\uc5ad\u7379\u41b5", "\udad3\udd86\ue67c\udbd5\udfd0\uda0d\udcea\udb0f\udd40\ud8ab\udca5",
        49, 16954, 1610547069, 8449425674558581265L, 97483L, true, true, (char) 41037, (char) 44845,
        Double.longBitsToDouble(0x3fe248e8277d1962L), Double.longBitsToDouble(0x3fe42a9681bfc843L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:\ud824\udce0\ud987\udd07\udb2e\udc6d\ud857\udf9d\0121=java.lang.String:\ud824\udce0\ud987\udd07\udb2e\udc6d\ud857\udf9d\012",
        Z.run(T, 2, 12, 2, 6, "\ud824\udce0\ud987\udd07\udb2e\udc6d\ud857\udf9d", "\u057c\u105c\u4f54\u3ac0\uba09\u317e\uc4f0\u11ec\u38e8\u7965\u3db0\u9540\u4e70\u2749\uc83d\uc412\u15bf\u9e2b", "\ud850\udd07\uda9a\udf61\ud92b\uded0\udb89\udd22\udaed\udead\ud83f\udd29\udb27\udd8b\ud8ca\udead\udb3f\udfe9\ud8d2\udc1f\udb3d\udfea\uda4c\udf13\udae6\ude1c\uda90\udd9e\ud8c0\udce5\ud880\udfbf\udb09\udebe\ud9b3\ude3f",
        15, 2900, 2003652734, -442854632857300093L, 42213L, true, false, (char) 18575, (char) 17902,
        Double.longBitsToDouble(0x3fed0f3e6938845eL), Double.longBitsToDouble(0x3fbd946909d64ae8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.String:\uc5d0\012",
        Z.run(T, 1, 3, 5, 11, "\uc5d0", "\u12b8\u638d\ud1a4\u9b23\uc721\ua77b\ucc87\u5e72", "\ud9d7\udf9a\udaa7\ude30\ud8b4\ude54\uda58\udccc\ud9aa\ude40\ud823\udcac",
        27, 84454, -1920543476, 8137555098956309214L, -2026L, true, true, (char) 40993, (char) 1929,
        Double.longBitsToDouble(0x3fe1120312aacd27L), Double.longBitsToDouble(0x3fc1ae83f9dc1890L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:\ud824\udce0\ud987\udd07\udb2e\udc6d\ud8f7\udc9c\0121=java.lang.String:\ud824\udce0\ud987\udd07\udb2e\udc6d\ud8f7\udc9c\012",
        Z.run(T, 2, 12, 2, 4, "\ud824\udce0\ud987\udd07\udb2e\udc6d\ud8f7\udc9c", "\u2f58\u4fc3\uabe1\u9d2f\u0145\u3f8e\uc5ad", "\ud825\udf57\uda58\udccc\ud9aa\ude40",
        7, 36747, 517999526, 3119174598357789465L, 81093L, true, true, (char) 51220, (char) 40993,
        Double.longBitsToDouble(0x3fe8cf5286224062L), Double.longBitsToDouble(0x3fe556693ca8441fL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:\ud991\uddaa\udb0c\udd00\ud900\ude8e\ud8f4\udc9b\ud813\udfe2\ud827\udda4\012",
        Z.run(T, 1, 2, 10, 8, "\ud991\uddaa\udb0c\udd00\ud900\ude8e\ud8f4\udc9b\ud813\udfe2\ud827\udda4", "\ucbe4\uc08b\u7266\u725f\uc5ad\u4a33\uca6a\u3c62\u64bd\ubdbd\uc8a7\u680b\u4292\u8565\u95cf\u9e2b\ua0c3\uce17\ua948\u6037", "\udaed\udead",
        48, 81423, -1063528443, -5614700631040353434L, -22004L, false, false, (char) 48481, (char) 62103,
        Double.longBitsToDouble(0x3fe44d1a6387072bL), Double.longBitsToDouble(0x3fd61f0a3ec7fd60L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String:\ud92c\udd3c\ud90e\ude17\udb72\uddf0\ud8b2\uddad\ud81c\udfe2\ud8d3\ude99\udbe2\udc7c\ud9cc\ude2b\u8182\ud8a2\udc78\ud86a\uddfb\uda98\udd00\ud859\udf2a\ud9df\ude99\udaa7\ude30\uda02\udc26\ud80e\udc45\u6676\ud80f\ude7c\ud91d\udcd3\uda0d\udcea\udb1b\udf40\ud990\udd49\ud82b\ude36\ud939\udc1f\udaa9\udd70\ub1ff\ud85d\udc48\ud95e\udfd5\ud93b\udcfa\udb26\ude0d\uda93\udc87\udb30\udd94\udb0f\udd30\udaaa\udf2f\ud80c\udcc4\udaa4\ude84\ud814\udfbf\uda89\udd66\uda6d\udde1\ud960\udd83\udb12\udfd0\udbf6\uddd8\ud922\udddb\0121=java.lang.String:\ud92c\udd3c\ud90e\ude17\udb72\uddf0\ud8b2\uddad\ud81c\udfe2\ud8d3\ude99\udbe2\udc7c\ud9cc\ude2b\u8182\ud8a2\udc78\ud86a\uddfb\uda98\udd00\ud859\udf2a\ud9df\ude99\udaa7\ude30\uda02\udc26\ud80e\udc45\u6676\ud80f\ude7c\ud91d\udcd3\uda0d\udcea\udb1b\udf40\ud990\udd49\ud82b\ude36\ud939\udc1f\udaa9\udd70\ub1ff\ud85d\udc48\ud95e\udfd5\ud93b\udcfa\udb26\ude0d\uda93\udc87\udb30\udd94\udb0f\udd30\udaaa\udf2f\ud80c\udcc4\udaa4\ude84\ud814\udfbf\uda89\udd66\uda6d\udde1\ud960\udd83\udb12\udfd0\udbf6\uddd8\ud922\udddb\012",
        Z.run(T, 2, 2, 2, 2, "\ud92c\udd3c\ud90e\ude17\udb72\uddf0\ud8b2\uddad\ud81c\udfe2\ud8d3\ude99\udbe2\udc7c\ud9cc\ude2b\u8182\ud8a2\udc78\ud86a\uddfb\uda98\udd00\ud859\udf2a\ud9df\ude99\udaa7\ude30\uda02\udc26\ud80e\udc45\u6676\ud80f\ude7c\ud91d\udcd3\uda0d\udcea\udb1b\udf40\ud990\udd49\ud82b\ude36\ud939\udc1f\udaa9\udd70\ub1ff\ud85d\udc48\ud95e\udfd5\ud93b\udcfa\udb26\ude0d\uda93\udc87\udb30\udd94\udb0f\udd30\udaaa\udf2f\ud80c\udcc4\udaa4\ude84\ud814\udfbf\uda89\udd66\uda6d\udde1\ud960\udd83\udb12\udfd0\udbf6\uddd8\ud922\udddb", "\u45cd\u4474\u9686\u933d", "\ud8fc\udf33\udb9b\ude10\uf4bd\ud8bc\udea9\ud9d9\ude13\ud8a2\ude31\udb8c\udc6d\ud89f\udd4a\udab4\ude6c\uda05\udcb8\udad9\ude47\ud93f\udd8e\uda78\udc7e\udb28\uddeb\ud95c\udf36\ud89e\udf68\ud9de\uddec\u3f58\udbfa\udd56\ud9c9\udd29\ud89b\udf92\udb16\udfd8\ud810\ude6e\ud852\udc08\udb1d\udef2\udad6\udc79\udb8e\udda7\udb42\udfba\udbe9\udea8",
        -1, 66299, 1590728892, 5227995374699074229L, 98704L, false, true, (char) 16464, (char) 36882,
        Double.longBitsToDouble(0x3fdc905e33a03da2L), Double.longBitsToDouble(0x3fefb2ba403a3422L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\udefb\ud90e\ude17\udbaf\udf84\uda38\ude7b\ud977\udcee\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud86a\udd94\uda98\udd00\ud8cd\udf23\ud9df\ude99\udaa7\ude30\ud8de\udd54\uda58\udccc\uda08\ude88\ue69f\ud91d\udcd3\uda0d\udcea\udb0f\udd40\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ud81f\udc0e\ud96a\udc44\udb96\udfc2\uda74\udf09\uda3f\udff0\ud8f5\udfe5\ud825\uddf4\012",
        Z.run(T, 1, 2, 11, 3, "\ud8e7\udefb\ud90e\ude17\udbaf\udf84\uda38\ude7b\ud977\udcee\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud86a\udd94\uda98\udd00\ud8cd\udf23\ud9df\ude99\udaa7\ude30\ud8de\udd54\uda58\udccc\uda08\ude88\ue69f\ud91d\udcd3\uda0d\udcea\udb0f\udd40\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ud81f\udc0e\ud96a\udc44\udb96\udfc2\uda74\udf09\uda3f\udff0\ud8f5\udfe5\ud825\uddf4", "\u1814\u4060", "\udb28\udff4\udb75\ude64\udb30\uddd9\ud8d0\udf98\udb4d\udccf\udacd\uddd0\uda06\udcd4\u4f4c\ud97b\udcd9",
        47, 36940, -2058998191, 1542041204025750048L, -63974L, true, true, (char) 5245, (char) 49523,
        Double.longBitsToDouble(0x3fd2787205a62202L), Double.longBitsToDouble(0x3fa051eb6e651bb0L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String:-1643411748 days 1 hour 37 minutes 50 seconds\012",
        Z.run(T, 1, 7, 7, 2, "\ud8e7\udefb\ud90e\ude22\ud965\udfdb\ud8ec\udf60\ud936\udf9f\udb8a\ude5c\udb3e\udef8\ud9cc\ude2b", "\u33fa", "\udb0d\uddcb\udb1a\udf55\udaa9\udf62\uda58\udced\ud9ae\udc9a\ud9a3\udc6f",
        15, 46811, -1644369734, 3568860968722670325L, -34333L, false, false, (char) 28449, (char) 10442,
        Double.longBitsToDouble(0x3fe795c44daacd27L), Double.longBitsToDouble(0x3f94b99de96c3940L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:-46728254 days 20 hours 35 minutes\012",
        Z.run(T, 1, 7, 7, 8, "\ud8e7\udefb\ud90e\ude22\ud9af\udfad\ud81c\uded0\udb24\udef9\ud8d3\ude99\udb5c\udf7f", "\u196f\u33fa\u090b\u10c3\u9133\u38e8\u7965\u7f28\ud48a", "\uda0d\udcea\ud80d\udd3f\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\udb7d\udf97",
        20, 71602, -1180842582, 7046580992042100811L, -44705L, true, true, (char) 18028, (char) 23377,
        Double.longBitsToDouble(0x3fe7a8053885187dL), Double.longBitsToDouble(0x3fd591f16d76d512L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:0 days\012",
        Z.run(T, 1, 7, 7, 2, "\ud8e7\udefb\ud90e\ude22\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\u33fa", "\uda2d\udd7c\udaa7\ude30\ud8de\udd54\uda58\udccc\udabb\udc01\ue67c",
        27, 35734, 4818987, 0L, -34333L, false, true, (char) 40993, (char) 10474,
        Double.longBitsToDouble(0x3fe1120755aacd27L), Double.longBitsToDouble(0x3f94b99d096c3940L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String:316885394 days 6 hours 20 minutes 17 seconds\0121=java.lang.String:316885394 days 6 hours 20 minutes 17 seconds\012",
        Z.run(T, 2, 7, 7, 2, "\ud8e7\udefb\ud90e\ude22\ud9af\udfad\ud8b3\udc3b\ud9ab\udfcd\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\u33fa", "\uda2d\udd7c\udaa7\ude30\ud8de\udd54\uda58\udccc\udabb\udc01\ue67c",
        27, 35734, 1447659563, 398464072438817525L, -34333L, false, true, (char) 40993, (char) 10474,
        Double.longBitsToDouble(0x3fd2240eab559a4eL), Double.longBitsToDouble(0x3f94b99d096c3940L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.String:2115407959 days -9 hours -48 minutes -41 seconds\012",
        Z.run(T, 1, 7, 7, 5, "\ud8e7\udefb", "", "",
        21, 51480, -631177216, -559399101126521582L, -41102L, false, false, (char) 0, (char) 13504,
        Double.longBitsToDouble(0x3fe801d9e72ae3a5L), Double.longBitsToDouble(0x3fd3c93ff601d654L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\ud8e7\udefb\uda66\udc43\udb0a\udeff\udaa3\udc10\u5a02\ud88a\ude7c\udb18\udd30\uda35\udf6a\udabb\ude0f\ud8a2\udc78\ud95a\udd73]]\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\ud8e7\udefb\uda66\udc43\udb0a\udeff\udaa3\udc10\u5a02\ud88a\ude7c\udb18\udd30\uda35\udf6a\udabb\ude0f\ud8a2\udc78\ud95a\udd73]]\012",
        Z.run(T, 2, 9, 9, 3, "\ud8e7\udefb\uda66\udc43\udb0a\udeff\udaa3\udc10\u5a02\ud88a\ude7c\udb18\udd30\uda35\udf6a\udabb\ude0f\ud8a2\udc78\ud95a\udd73", "\u7379\u1acb\ucf75\u7f70\u4aee\u3eed\u03cd\u0316\uc001\u9868\u74fe\u07ff\uccbd\u8c94\u4991\u1c99", "\ud91e\uddc8\uda80\udcc2\udb9a\udf79\uda0e\udf5f\ud840\udc5f\ud870\ude71",
        45, 24407, 1539979928, 7907010836496261732L, 38396L, false, false, (char) 800, (char) 41712,
        Double.longBitsToDouble(0x3fc6c1db0b0eedb0L), Double.longBitsToDouble(0x3fde6fcdceeb991cL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M978053818DT20H20M20.896S\0121=java.lang.String:P0Y0M-978053818DT-20H-19M-4.14S\012",
        Z.run(T, 2, 6, 8, 2, "\ud8e7\udefb\udafc\udd64\ud83c\udcad\udb3d\ude5c\ud80b\udde2\ud8d3\ude99", "\ua00c\u196f\u33fa\u090b\uc5ad\u7379\u38e8\u69fd\u7f28\ud48a\u3eed\u4940\ud524\u8e6f\uaf83\u3e2f\u1eec\u6f30\ud60f\u49d7", "\ud833\udcf6\uda1c\udcf2\uda7b\udcec",
        56, 75556, -2127940155, 455589024322820896L, 76710L, true, true, (char) 53182, (char) 27887,
        Double.longBitsToDouble(0x3fc40f96b348dbc0L), Double.longBitsToDouble(0x3fced38ceb88626cL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[]]\0121=java.lang.String: |a0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[]]\012",
        Z.run(T, 2, 0, 0, 10, "\ud8e7\udefb\udafc\udd64\ud83c\udcad\udb3d\ude5c\ud80b\udde2\ud8d3\ude99", "\u0e0d\u2206\u0b5e\u91e6\uc5ad\u7379\u3877\u69fd\u7f28\ud48a\u3eed\u4940\ud524\u8e6f\uaf83\u3e2f\u1eec\u6f30\u7e40\u49d7", "\ud833\udcf6\uda1c\udcf2\uda7b\udcec",
        56, 75556, -567659067, 482549672206146336L, 76710L, true, true, (char) 53182, (char) 27887,
        Double.longBitsToDouble(0x3fc40f96b348dbc0L), Double.longBitsToDouble(0x3fced38cfaac626cL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.String:\ud8d2\udcdc\udafc\udd64\ud83c\udcad\udb3d\ude5c\ud80b\udde2\ud8d3\ude99\0121=java.lang.String:\ud8d2\udcdc\udafc\udd64\ud83c\udcad\udb3d\ude5c\ud80b\udde2\ud8d3\ude99\012",
        Z.run(T, 2, 12, 1, 2, "\ud8d2\udcdc\udafc\udd64\ud83c\udcad\udb3d\ude5c\ud80b\udde2\ud8d3\ude99", "\u0150\u350b\ubcf7\u04e0\u4804\u7379\u38e8\u69fd\u9cdd\u299f\u3f3c\u4940\ud524\u8e6f\uaf83", "\udaa9\udd70\ub1ff\udb7d\udf97\ud862\udf1e\udb91\udd90",
        57, 65240, -616099534, -841872899929343908L, -6766L, false, true, (char) 47901, (char) 1104,
        Double.longBitsToDouble(0x3fd5bdb4a6a4c8d8L), Double.longBitsToDouble(0x3fca9c836281f2d4L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String:P-220041523Y11M25DT9H14M51.339S\0121=java.lang.String:P-220041523Y11M25DT9H14M51.339S\012",
        Z.run(T, 2, 8, 8, 2, "\ud8e7\udefb\udafc\udd64\ud910\udcf7\udb3d\ude29\ud80b\udde2\ud8d3\ude99", "\u0e0d\u1e30\u33fa\u090b\u17c2\u069c\u9dbd\u6ac9\u82ac\u6e37\ucf80\u4940\uca8c\u70d3\ud16e\u4d9c\u2545\u6f30\ud60f\u49d7", "\ud8d8\udda9\uda1c\udcf2\uda7b\udcec",
        15, 75556, -2127940155, -6944106638423614629L, 76710L, true, true, (char) 53182, (char) 27887,
        Double.longBitsToDouble(0x3fc40f96b348dbc0L), Double.longBitsToDouble(0x3fced38ceb88626cL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.String:978053818 days 20 hours 20 minutes 20 seconds\0121=java.lang.String:978053818 days 20 hours 20 minutes 20 seconds\012",
        Z.run(T, 2, 7, 7, 2, "\ud8e7\ude1f\udafc\udd64\ud83c\udcad\udb3d\ude5c\ud80b\udde2\ud8d3\ude99", "\u0e0d\u196f\u33fa\u090b\uc5ad\u7379\u38e8\u73c4\u2ffe\ud48a\u8baa\u7224\ud524\u8e6f\uaf83\u3e2f\u1eec\u277e\u72f9\u49d7", "\ud833\udcf6\uda1c\udcf2\uda7b\udcec",
        56, 75556, -2127940155, 455589024322820896L, 76710L, false, false, (char) 53182, (char) 27887,
        Double.longBitsToDouble(0x3fc40f96b348dbc0L), Double.longBitsToDouble(0x3fced38ceb88626cL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\ude7c\ud90e\ude17\ud9af\udfad\ud81c\udefd\0121=java.lang.String:\ud8e7\ude7c\ud90e\ude17\ud9af\udfad\ud81c\udefd\012",
        Z.run(T, 2, 2, 2, 11, "\ud8e7\ude7c\ud90e\ude17\ud9af\udfad\ud81c\udefd", "\ub6d4\u390a\u0e0d\u196f\u33fa\u5080\uc5ad\u5711\ua61c\u39e0\u3ad1\ua6e7\u3eed\u4940", "\ud990\udd49\ud8c4\udde1\ud939\udc1f\udb10\udef4\ud9f3\ude77",
        7, 5768, -1108953545, 9019480880569647021L, -86850L, false, false, (char) 9794, (char) 42739,
        Double.longBitsToDouble(0x3fa2af11fe7515e0L), Double.longBitsToDouble(0x3fd400584df57d44L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=new org.apache.commons.lang.time.DurationFormatUtils:@?\012",
        Z.run(T, 2, 10, 10, 1, "\ud8e7\ude7c\udbd3\ude3a\u77e6\ud81c\udefd", "\u5e01\u512f\u7735", "\udb0a\udcf9\udad5\udc28\ua98f\udac4\udfcd\ud8b1\udf32\ud94f\udcee",
        49, 51584, -649089253, 4336986289649060072L, -58283L, true, false, (char) 6740, (char) 39850,
        Double.longBitsToDouble(0x3fef8e7c71b44892L), Double.longBitsToDouble(0x3fe1b81f16df14e6L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.String:764999052:-34:-58.12\0121=java.lang.String:764999052:-34:-58.12\012",
        Z.run(T, 2, 5, 5, 9, "\udac2\udcf2\uda8b\udcb6\ud9af\udfdb\ud81c\uded0\ud80b\udde2\ud9c8\udd3b\uda9f\udc24\udaa2\udcef", "\ucc23\u090b\uc5ad\u7379\u38e8", "\udabb\udc01\ue67c\uda31\udc7c\uda0d\udc9c\udb0f\udd40\ud990\udd49\ud8c4\udde1\udbd8\udd4e\udaa9\uddc5\ub0ff\udb7d\udf97\ud95f\udc9c\udb4e\udd56\uda3f\udfbf\ud9d9\udcc4\ue71d\udbe7\udf39\ud8a8\udfc7\uda73\udc32\ud91e\udec7\ud966\udf9b\ud9f4\udffa\ud860\udc48\ue547",
        23, 80109, -1204821283, -8331200544573298488L, 16060L, true, true, (char) 23609, (char) 20497,
        Double.longBitsToDouble(0x3fe485b4abe4543cL), Double.longBitsToDouble(0x3fe2138e42a828efL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M-2009675041DT-11H-42M-35.91S\0121=java.lang.String:P0Y0M-2009675041DT-11H-42M-35.91S\012",
        Z.run(T, 2, 6, 6, 2, "\udac7\uddeb\u6ea2\ud996\udcb1\ud80c\udec8\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\udaac\ude7a", "\uc4c4\u090b\ud6aa\u1e60\u0fd2\u8037\u7b34", "\ud91d\udcd3\ud871\udc7d\udb0f\udd40\ud9a3\ude7c\ud8c4\udde1\udb2c\udc59\udb0d\udcd2\ud9f5\ude16\udb7d\udf69\ud95f\udc9c\udb88\udf22\uda3f\udff0\ud99a\ude32\ud98b\udf95\ud8ce\udde2",
        25, 94590, 1549588209, -3884487667328555809L, 82196L, true, false, (char) 4647, (char) 34332,
        Double.longBitsToDouble(0x3fe7ba1f8d02e8f1L), Double.longBitsToDouble(0x3fd10318dc83ed56L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e7\ude90\0121=java.lang.String:0 seconds\012",
        Z.run(T, 2, 2, 7, 2, "\ud8e7\ude90", "\000\u0256", "\ud9ad\ude08\udad5\udd72\ud8d6\udc86\ud9a9\ude6b\uda72\udc00\ud859\udf2a\ud9df\ude99\udb7b\ude3a\udac5\udd45\udb61\udccf\udad3\udd86\udad2\udf89\000\uda0d\udc44\ud92c\udc2f\000\000\ud8d8\udc7d\ud8d3\udd25",
        26, -1000, -1846880256, 0L, -44835L, true, false, (char) 35330, (char) 48959,
        Double.longBitsToDouble(0x3fefc0ed30bb8776L), Double.longBitsToDouble(0x3fd88913042fd078L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.String:\ud824\udce0\ud987\udd07\udb2e\udc6d\ud857\udf9d\0121=java.lang.String:\ud824\udce0\ud987\udd07\udb2e\udc6d\ud857\udf9d\012",
        Z.run(T, 2, 2, 2, 6, "\ud824\udce0\ud987\udd07\udb2e\udc6d\ud857\udf9d", "\u644c\u105c\u4f54\u3ac0\uba09\u317e\uc4f0\u11ec\u38e8\u7965\u3db0\u9540\u4e70\u2749\uc83d\uc412\u15bf\ua275\u1434\u6f30\u064f\u4bbf\uc753\u43de\u6b67\u5de8", "\udb3f\udfe9\ud8d2\udc1f\udb3d\udfea",
        41, 13608, -712811486, -5262336098557953281L, 74607L, true, true, (char) 60877, (char) 47207,
        Double.longBitsToDouble(0x3fe37d82eb02658dL), Double.longBitsToDouble(0x3fd172cd7743cf9aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.String:-46728254 days 20 hours 35 minutes\0121=java.lang.String:-46728254 days 20 hours 35 minutes\012",
        Z.run(T, 2, 7, 7, 8, "\ud8e7\udefb\ud90e\ude22\ud9af\udfad\ud81c\uded0\udb24\udef9\ud8d3\ude99\udb5c\udf7f", "\u196f\u3f48\u62c8\u30c3\u7296\u38e8\u7965\u7f28\ud48a", "\uda0d\udcea\ud80d\udd3f\ud990\udd49\ud8c4\udde1\ud939\udc1f\udaa9\udd70\ub1ff\udb7d\udf97",
        16, 46380, -1180842582, 7046580992042100811L, -44705L, true, true, (char) 18028, (char) 23377,
        Double.longBitsToDouble(0x3fe7a8053885187dL), Double.longBitsToDouble(0x3fd591f165b0d512L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:3 hours 12 minutes 14 seconds\012",
        Z.run(T, 1, 7, 7, 8, "\udbee\udede\ud902\udc60\ud9af\udfad\ud8ef\ude59\udb24\udebb\ud8d3\ude99\udb5c\udf7f", "\000\000\000\u104b\u9133\u38e8\u7965\u7f28\ud48a", "\000\000\000\ud8c4\udde1\ud939\udc1f\udaa9\udcf3\ub1ff\udb7d\udf97",
        20, 71602, -1180842582, 11534336L, -44705L, true, true, (char) 18028, (char) 20498,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String:0 days\0121=java.lang.String:0 days\012",
        Z.run(T, 2, 7, 7, 2, "\ud8e7\udefb\ud90e\ude22\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\u33fa", "\uda2d\udd7c\udaa7\ude30\ud8de\udd54\uda58\udccc\udabb\udc01\ue67c",
        27, 35734, 4818987, 0L, -34333L, false, true, (char) 40993, (char) 10474,
        Double.longBitsToDouble(0x3fe1120755aacd27L), Double.longBitsToDouble(0x3f94b99d096c3940L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000\0121=java.lang.String:0:00:00.000\012",
        Z.run(T, 2, 5, 5, 2, "\ud8e7\ude90", "\000\u0256", "\udba0\udd7e\ud88c\udcfb\ud8d6\udc86\udb1e\udc86\udac6\udd84\ud859\ude78\ud9df\ude99\udb7b\ude3a\udab7\ude5b\ud901\udf10\udad3\udd86\udafd\udc3e\000\uda0d\udc44\ud92c\udc2f\000\uda20\ude3e\ud8d8\udc7d\ud8d3\udd25",
        26, 12346, -1846880256, 0L, -69873L, true, false, (char) 30561, (char) 25602,
        Double.longBitsToDouble(0x3feeaa7fd2925cadL), Double.longBitsToDouble(0x3fefc0ed30bb8776L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.String:3 hours 12 minutes 14 seconds\0121=java.lang.String:3 hours 12 minutes 14 seconds\012",
        Z.run(T, 2, 7, 7, 8, "\udbee\udede\ud902\udc60\ud9af\udfad\ud8ef\ude59\udb24\udebb\ud8d3\ude99\udb5c\udf7f", "\000\000\000\u104b\u9133\u38e8\u7965\u7f28\ud48a", "\000\000\000\ud8c4\udde1\ud939\udc1f\udaa9\udcf3\ub1ff\udb7d\udf97",
        20, 71602, -1180842582, 11534336L, -44705L, true, true, (char) 18028, (char) 20498,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 10, 2, "\udbf0\udd2a\ud92d\udc3d\ud9af\udfad\ud954\uddc2\ud885\ude96\udb2e\udd6c\udb4f\udfef\ud80a\udcae", "\ub331\u09a0\uc5ad", "\ud8b7\udd43\ud9f4\udc44\ud9e8\udf6c",
        53, 36747, -1417475182, 1936940395975123190L, 27899L, false, true, (char) 51220, (char) 40993,
        Double.longBitsToDouble(0x3fda5ae47dc9d276L), Double.longBitsToDouble(0x3fdaacd276f0c73aL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:0 seconds\0121=java.lang.String:0 seconds\012",
        Z.run(T, 2, 7, 7, 2, "\ud8e7\udefb\ud90e\ude22\ud9af\udfad\ud81c\uded0\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b", "\u33fa", "\uda2d\udd7c\udaa7\ude30\ud8de\udd54\uda58\udccc\udabb\udc01\ue67c",
        27, 64990, 4809751, 0L, -8344L, true, false, (char) 41110, (char) 10474,
        Double.longBitsToDouble(0x3fe1120755aacd27L), Double.longBitsToDouble(0x3fbc2027425b0e50L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 7, 2, "\ud8b7\udd6f\ud9bb\udca2\ud9af\udfad\ud8b6\udffe\udb2f\uddb4\ud844\udf6f\ud977\udca4\udaa1\uddf0", "\u33fa\u86ab\u5b3d\u6240\u7604\ubda5\ucba0\u6bb2\u3228\ud4ab\u03cf\u75eb\ubeeb\u69a0\u1eec\u6f30\ub445\u9813\ua5b9\u41de\u936e\u61d3\ub596\u46af\ud0cc\u19eb\u3d51\u3efd\uc89e\u9425\u4da1\ubd23\u561d\u216b\u3c42\u71b5\u908c\u9b48\u4f40\u996e\u7e5e\u07f2\u146b\ub75a\u5fb5\u1900\uaf55\u9105\uaf4e\u7b55\u9293\u9643\u347d", "\ud930\udc3e\ud809\udd5b\ud896\udc94",
        39, 68899, -1705280844, -4300205399643177040L, 97702L, false, false, (char) 6057, (char) 53565,
        Double.longBitsToDouble(0x3fb506017c237260L), Double.longBitsToDouble(0x3feb60cfc168a92bL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 1, "\uda49\udfcc\ud894\udfce\ud83c\udcb0\udb3d\ude5c\ud80b\udde2\ud8d3\ude99\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud8a2\udc78\ud8e4\udc98\uda98\udd8f\ud86e\udd2a\ud9df\ude99\udaa7\ude30\udb32\udfbe\uda58\udccc\udabb\udc01\ue67c\udb71\udf3d\uda0d\udcea\udb0f\udd40\ud990\udd49\ud8b7\udd1b\ud939\udc1f\udaa9\udd70\u4873\udb17\udc37\ud963\uddf1\udb88\udf22\ud82f\udff6\uda1c\udcf2\udb20\udf9a\udae4\udc5e\uda41\udddd\ud9d9\ude4b\ud965\udc2d\udbb9\udfb9\udaea\udd9e\ud89a\udc1c\uc746\ud892\uddad\ud998\udc2d\udb46\udfdc\ud9ab\udef3\udba5\udf91\udbdf\udf1a\udaa1\udd8f\ud897\udff1\udb2e\udfcb\udb37\udfb1\uda77\udd25", "\u01db\uc99f\u025c\u0874\u9092\u64be\ubf5f\u7018\u7c9c\u43e7\u369b\u7160\u4814\u0708\uc8ba\u40e8\ud7b4\u5085\u9037\u1a16\u4a64\u16ae\u940a", "\ud8f9\udc71\udb50\ude8c\udaab\udec4\udb29\ude89\udb6b\udf25\ud9aa\udf64\uda5c\ude33\udb95\udf5a\uda9d\udc7a\ud979\ude9d\ud835\udd48\ud910\udc7e\uda7a\udc3b\udb4b\udce9\ud9ca\udd72\udb0b\ude7c\uda54\ude45\u530a\u2077\ud88a\uddc2\ud89e\ude5b\udb89\uddb7\ud87b\ude34\udb4c\ude16\ud924\udc20\udbf1\udc67\ud815\ude50\ud8ff\udf23\ud9d7\ude4f\ud90e\udd8b\uda7a\udf5a\ud9da\uddc0\ud890\udee7\ud9b5\udeed\ud9cd\ude35\udaf5\udd48\udbbc\udf58\ud9e5\ude51\ud8ec\udef7\ud870\udd75\udb07\udfef\uda9c\uded0\ud83a\udc74\ud868\udddc\ud891\udeb5\ud8cf\udfa8\ud976\ude2c\udab4\udc02\ud935\uddbb\ud8f1\udf86\udbbe\udd26\uda9d\ude3a\ud8eb\udf80\ud8b0\udc42\ud9de\uddcb\uda69\ude6e\u9124\udbe7\udc91\u72e0\uda5b\ude7b\ud962\udd3a\ud8b0\udcc6\udab7\udd0f\udaa3\udc66",
        19, 96245, 709887386, -2233963525468136853L, -2214L, false, true, (char) 5848, (char) 65046,
        Double.longBitsToDouble(0x3fe49450ad7d2704L), Double.longBitsToDouble(0x3fcaaa151b17f414L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.String:-1987122199\012",
        Z.run(T, 1, 4, 8, 2, "s", "\u3a27\u0dda\u39c5\u057c\u3ef0\u08e2\u7e8f\u8bf9\u3873", "\udaa7\ude30\ud300\000",
        52, 51584, -208160782, 1568331090815977515L, -58283L, true, false, (char) 64223, (char) 51220,
        Double.longBitsToDouble(0x3fe6fbaa10c95021L), Double.longBitsToDouble(0x3fdb9497e214c0d6L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:\uda55\uddea\udab9\udcfd-92810226\000\0121=new org.apache.commons.lang.time.DurationFormatUtils:@?\012",
        Z.run(T, 2, 1, 10, 2, "\uda55\uddea\udab9\udcfdS\000", "\u057c", "\ud9ab\udd5d\udb97\udef8\ud896\ude4d\ud882\udc41\ud826\ude6b\ud871\udf10\uda7c\ude93\u1364\ud822\udcf6",
        25, -1000, -553648128, 6217501404899549430L, -35580L, true, true, (char) 8382, (char) 43191,
        Double.longBitsToDouble(0x3e7296a88f000000L), Double.longBitsToDouble(0x3fc7dad24120696cL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:\udba5\udf9a\udab9\udcfd483659984\ubc20\012",
        Z.run(T, 1, 2, 6, 7, "\udba5\udf9a\udab9\udcfdS\ubc20", "\u057c", "\udb12\udfaa",
        1, 58518, -2020842837, 3729045886151146200L, -13400L, false, true, (char) 28748, (char) 35400,
        Double.longBitsToDouble(0x3fa384cc096df000L), Double.longBitsToDouble(0x3fe7b2b52af5cdc3L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.String:\uda55\uddea\udab9\udcfd-104526639\000\0121=java.lang.String:\uda55\uddea\udab9\udcfd-104526639\000\012",
        Z.run(T, 2, 1, 2, 2, "\uda55\uddea\udab9\udcfdS\000", "\u057c", "\ud9ab\udd5d\udb97\udef8\ud896\ude4d\ud882\udc41\ud826\ude6b\ud871\udf10\uda7c\ude93\u1364\ud822\udcf6",
        25, -1000, -553648128, 6217501404911265843L, -35580L, true, true, (char) 8382, (char) 43191,
        Double.longBitsToDouble(0x3e7296a88f000000L), Double.longBitsToDouble(0x3fc7dad24120696cL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:\uda55\uddea\udab9\udcfd1693021193\000\000\ud941\ude90\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud9ab\udd5d\udb97\udef8\ud896\ude4d\ud882\udc41\ud826\ude6b\ud871\udf10\uda7c\ude93\u1364\ud822\udcf6\u3b88\000\ud85d\ude0e\udaed\uddab\ud990\udd49\udbd4\udd69\ud800\udfa4\ud95d\ude04\udb95\udcc2\ud8f1\udc9c\udb47\udcc7\u2abc\uda8e\ude4b\uda15\udc39\ud9ed\ude56\ue7b0\ud9d4\uddc0\udb39\udfbf\uca20\udb58\udfe8\ud859\ude2f\ud99d\udf17\ud935\udf23\udb68\udcc7\udb06\udfa3\uda02\udc98\ud966\udfe9\ud8f1\udc6a\ud989\udce0\ud974\udca2\udb36\udf94\udbaa\udcea\udaf7\udc63\udba4\udef4\ud8cb\udf0d\uda7b\ude0b\udaec\ude7c\ud8d3\udfb4\ud9ff\ude53\udb80\ude05\ud9a0\udeb2\ud92b\udf6a\ud96f\udcaf\ud849\ude5e\udb8c\udef8\udb1c\ude98\udb1b\ude43\ud8d5\udeea\uda33\udc6b\udadb\udc16\udbab\udf1b\udabe\ude6e\u5360\0121=java.lang.String:\uda55\uddea\udab9\udcfd1693021193\000\000\ud941\ude90\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud9ab\udd5d\udb97\udef8\ud896\ude4d\ud882\udc41\ud826\ude6b\ud871\udf10\uda7c\ude93\u1364\ud822\udcf6\u3b88\000\ud85d\ude0e\udaed\uddab\ud990\udd49\udbd4\udd69\ud800\udfa4\ud95d\ude04\udb95\udcc2\ud8f1\udc9c\udb47\udcc7\u2abc\uda8e\ude4b\uda15\udc39\ud9ed\ude56\ue7b0\ud9d4\uddc0\udb39\udfbf\uca20\udb58\udfe8\ud859\ude2f\ud99d\udf17\ud935\udf23\udb68\udcc7\udb06\udfa3\uda02\udc98\ud966\udfe9\ud8f1\udc6a\ud989\udce0\ud974\udca2\udb36\udf94\udbaa\udcea\udaf7\udc63\udba4\udef4\ud8cb\udf0d\uda7b\ude0b\udaec\ude7c\ud8d3\udfb4\ud9ff\ude53\udb80\ude05\ud9a0\udeb2\ud92b\udf6a\ud96f\udcaf\ud849\ude5e\udb8c\udef8\udb1c\ude98\udb1b\ude43\ud8d5\udeea\uda33\udc6b\udadb\udc16\udbab\udf1b\udabe\ude6e\u5360\012",
        Z.run(T, 2, 1, 1, 2, "\uda55\uddea\udab9\udcfdS\000\000\ud941\ude90\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud9ab\udd5d\udb97\udef8\ud896\ude4d\ud882\udc41\ud826\ude6b\ud871\udf10\uda7c\ude93\u1364\ud822\udcf6\u3b88\000\ud85d\ude0e\udaed\uddab\ud990\udd49\udbd4\udd69\ud800\udfa4\ud95d\ude04\udb95\udcc2\ud8f1\udc9c\udb47\udcc7\u2abc\uda8e\ude4b\uda15\udc39\ud9ed\ude56\ue7b0\ud9d4\uddc0\udb39\udfbf\uca20\udb58\udfe8\ud859\ude2f\ud99d\udf17\ud935\udf23\udb68\udcc7\udb06\udfa3\uda02\udc98\ud966\udfe9\ud8f1\udc6a\ud989\udce0\ud974\udca2\udb36\udf94\udbaa\udcea\udaf7\udc63\udba4\udef4\ud8cb\udf0d\uda7b\ude0b\udaec\ude7c\ud8d3\udfb4\ud9ff\ude53\udb80\ude05\ud9a0\udeb2\ud92b\udf6a\ud96f\udcaf\ud849\ude5e\udb8c\udef8\udb1c\ude98\udb1b\ude43\ud8d5\udeea\uda33\udc6b\udadb\udc16\udbab\udf1b\udabe\ude6e\u5360", "\u83d3\u524b\u0ae1\u15dc\u953d", "\u6ce8\ud88b\ude25\uda17\uddfd",
        44, 82991, 945066961, -6841110543634622769L, 18136L, false, false, (char) 54858, (char) 8205,
        Double.longBitsToDouble(0x3fb7e8a90a2c3ae8L), Double.longBitsToDouble(0x3fdbc30c9f33cec0L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:755696911 days -4 hours\012",
        Z.run(T, 1, 7, 7, 8, "\udbee\udede\ud902\udc60\ud9af\udfad\ud8ef\ude59\udb24\udebb\ud8d3\ude99\udb5c\udf7f", "\000\000\000\u104b\u9133\u38e8\u7965\u7f28\ud48a", "\000\000\000\ud8c4\udde1\ud939\udc1f\udb90\udf99\udbff\ude71\udaf7\udd96",
        57, 49847, 1208561676, -3645559530648000656L, -44705L, true, true, (char) 18028, (char) 20498,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e44000000000000L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.String:\udb1a\udcdf\udab9\udcfd377473021\udb4c\udc05\000\ud941\ude90\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud9ab\udd5d\udb97\udef8\udbf8\udc1e\ud882\udc41\0121=java.lang.String:\udb1a\udcdf\udab9\udcfd-621071582\udb4c\udc05\000\ud941\ude90\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud9ab\udd5d\udb97\udef8\udbf8\udc1e\ud882\udc41\012",
        Z.run(T, 2, 4, 2, 0, "\udb1a\udcdf\udab9\udcfdS\udb4c\udc05\000\ud941\ude90\udbe8\udd7c\ud9cc\ude2b\udabb\ude0f\ud9ab\udd5d\udb97\udef8\udbf8\udc1e\ud882\udc41", "\u84fc\uc7c9\u6c64\u347b\u9620\u50e3\u06da\uaf83\u5cd0", "\udb95\udcc2\ud97f\udd69",
        33, 52565, 442174910, -6092868608914896899L, -6369L, false, false, (char) 13896, (char) 4343,
        Double.longBitsToDouble(0x3feea703373db6a7L), Double.longBitsToDouble(0x3febdb33e5b0ba72L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String:755696911 days -4 hours\0121=java.lang.String:755696911 days -4 hours\012",
        Z.run(T, 2, 7, 7, 8, "\udbee\udede\ud902\udc60\ud9af\udfad\ud8ef\ude59\udb24\udebb\ud8d3\ude99\udb5c\udf7f", "\000\000\000\u104b\u9133\u38e8\u7965\u7f28\ud48a", "\000\000\000\ud8c4\udde1\ud939\udc1f\udb90\udf99\udbff\ude71\udaf7\udd96",
        57, 49847, 1208561676, -3645559530648000656L, -44705L, true, true, (char) 22124, (char) 45077,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3f2f40d000000000L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\uda55\uddea\udab9\udcfd, S, \000]]\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\uda55\uddea\udab9\udcfd, S, \000]]\012",
        Z.run(T, 2, 9, 9, 2, "\uda55\uddea\udab9\udcfdS\000", "\u057c", "\ud9ab\udd5d\udb97\udef8\u0743\ud882\udc41\ud826\ude6b\ud871\udf10\uda7c\ude93\u1364\ud822\udcf6",
        25, -1000, -553648128, 6217501404899549430L, -35580L, true, true, (char) 8382, (char) 43191,
        Double.longBitsToDouble(0x3e7296a88f000000L), Double.longBitsToDouble(0x3fc7dad24120696cL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.lang.String:\uedff\ud9be\udfe8\ud849\ude9a\udbd2\udc2c\ud85b\ude7c\uc636\udbcb\udc01\012",
        Z.run(T, 1, 2, 10, 7, "\uedff\ud9be\udfe8'\ud849\ude9a\udbd2\udc2c\ud85b\ude7c\uc636\udbcb\udc01", "\u0414\u8fa5", "\ud80a\udd25\uda13\udebe\uda98\uddd0\ud874\udd6f",
        54, 69123, -553624537, 6243397101821302518L, 1347L, true, false, (char) 60790, (char) 53108,
        Double.longBitsToDouble(0x3febb42d49ee535cL), Double.longBitsToDouble(0x3fb1b9ccf55c4488L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.String:\uedff\ud9be\udfe8\ud849\ude9a\012",
        Z.run(T, 1, 2, 10, 7, "\uedff\ud9be\udfe8'\ud849\ude9a", "\ubff2\ua7d2\u9435\ud60e\u0414\u8fa5\ucffa\uc085\ub8ac\u6355\u4653\u1c46\uc6b5\ud591\uad0a\u0f47\u236b\uaa57\u13b3\u4611\u718b\u0a90\u6242\u2c8a\u22b9", "\udb90\udc3c\u7637\ud948\udcbb\udb50\uddfd\udb63\udc8c",
        29, 99548, -452852370, -4749064627784310709L, 63643L, true, false, (char) 25045, (char) 60718,
        Double.longBitsToDouble(0x3fd69f0b08c3ed1eL), Double.longBitsToDouble(0x3f909fd98b41d160L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.String:\uedff\ud9be\udfe8\ud849\ude9a\udbd2\udc2c\ud85b\ude7c\012",
        Z.run(T, 1, 2, 10, 7, "\uedff\ud9be\udfe8'\ud849\ude9a\udbd2\udc2c\ud85b\ude7c", "\u9435\ud632\u0414\u8fa5\u68bf\ub0c4\ud67f\uca75\u82df\u67d9\u9c20\ud591\uad0a\u54e8\u3c59\uaa57\ua4e1\u787d\u718b\u0a90\u6242\u2c8a\u22b9\ud42c", "\ud8a3\udd43\ud8e5\uded2\udaa9\udd54\ud9d0\udd7d\ud92a\udfe8\ud83e\udd7e\udb0b\udd91\ud924\udc77\udac0\ude2f\ud823\udc93\ud90b\udf64\ud89b\udeb2",
        3, 9302, -1775150299, 261166748075111521L, -75025L, false, true, (char) 27034, (char) 31100,
        Double.longBitsToDouble(0x3fe02cc1d462df95L), Double.longBitsToDouble(0x3fd4ad4c04041d18L)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.String:\uedff\ud9be\udfe8\ud849\ude9a\udbd2\udc2c\ud85b\ude7c\uc636\udbcb\udc01\u3200\udb12\udfaa\uda41\udc0d\uf08d\ud823\udc42\udae9\ude3c\ud80a\udd25\uda13\udebe\uda98\uddd0\ud874\udd6f\ud865\udd53\udae8\udec3\ud874\ude35\ud879\uddb1\ud81b\udc00\udaaf\udf58\udad9\ude7a\udbd1\uddf9\ud974\ude0b\ud931\udc59\uda5d\udc5f\udb8e\udc77\udb22\udf00\udbdc\udc6b\udbad\udd8c\udb3a\udd0b\ud923\udf61\ud956\udc26\udb14\udfaf\ud9be\udc74\ud8e5\uddaf\ud82b\udd59\uda63\uddff\udab1\udfc6\uda14\udc2f\udb4c\udc77\u255b\udae0\udffc\ud8ec\udcf9\udb84\udd61\ud994\uddaf\u247d\012",
        Z.run(T, 1, 2, 9, 1, "\uedff\ud9be\udfe8'\ud849\ude9a\udbd2\udc2c\ud85b\ude7c\uc636\udbcb\udc01\u3200\udb12\udfaa\uda41\udc0d\uf08d\ud823\udc42\udae9\ude3c\ud80a\udd25\uda13\udebe\uda98\uddd0\ud874\udd6f\ud865\udd53\udae8\udec3\ud874\ude35\ud879\uddb1\ud81b\udc00\udaaf\udf58\udad9\ude7a\udbd1\uddf9\ud974\ude0b\ud931\udc59\uda5d\udc5f\udb8e\udc77\udb22\udf00\udbdc\udc6b\udbad\udd8c\udb3a\udd0b\ud923\udf61\ud956\udc26\udb14\udfaf\ud9be\udc74\ud8e5\uddaf\ud82b\udd59\uda63\uddff\udab1\udfc6\uda14\udc2f\udb4c\udc77\u255b\udae0\udffc\ud8ec\udcf9\udb84\udd61\ud994\uddaf\u247d", "\uafb2\u1dcc\u7c1a\u906d\u8303\u2139\u780c\u697a", "\udaa3\ude21\udbb5\udc74\udad3\udf51\uda7c\udc72\ud8cf\udd29\ud8d1\udd1d\uda4d\udcab\ud805\ude74\udaf0\udec1\ud81f\udf11\udb36\uddc7\ud876\udf96\ud8d4\udd1c\ud95d\udd54",
        -1, 52686, 173936220, -8421855775296306482L, -35995L, false, true, (char) 13355, (char) 15650,
        Double.longBitsToDouble(0x3fe1461ef465b5d5L), Double.longBitsToDouble(0x3fe65dc5d9de93bfL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.time.DurationFormatUtils|format|[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;,int,int,int,int,int,int,int,boolean|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriod|long,long,java.lang.String|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriod|long,long,java.lang.String,boolean,java.util.TimeZone|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDuration|long,java.lang.String|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDuration|long,java.lang.String,boolean|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDurationHMS|long|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDurationISO|long|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDurationWords|long,boolean,boolean|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriodISO|long,long|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|lexx|java.lang.String|static",
    "C|org.apache.commons.lang.time.DurationFormatUtils|<init>|",
    "M|org.apache.commons.lang.time.DurationFormatUtils|format|[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;,int,int,int,int,int,int,int,boolean|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriod|long,long,java.lang.String|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriod|long,long,java.lang.String,boolean,java.util.TimeZone|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
