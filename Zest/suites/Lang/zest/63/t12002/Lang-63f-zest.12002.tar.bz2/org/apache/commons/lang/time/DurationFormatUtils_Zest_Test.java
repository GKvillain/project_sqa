package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DurationFormatUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\012",
        Z.run(T, 2, 10, 3, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\ua146\ua22e\u65b2\u0e68\ube2b\ud0c8\u8cc0", "\ud9a9\udf95",
        23, 60124, -557457493, -5089346621378959554L, -11128L, false, true, (char) 21968, (char) 57564,
        Double.longBitsToDouble(0x3fe3eec817697f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 8, "\ud99e\udede\ud8f2\ude68\ud87f\udc7c\uda68\ude7a", "\u9633\ua5f8\u6be7\u0dde\u55fa\u5f70\ubda2\u70f0", "\ud97e\udded\ud810\udf58\ud953\udf2c\ud9ad\ude0c",
        56, 65624, 132209448, 6682118090816965653L, 40670L, false, false, (char) 41754, (char) 53291,
        Double.longBitsToDouble(0x3fe7d9e41ca3d607L), Double.longBitsToDouble(0x3fee4b105f5e69b3L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\ua146\ua22e\u65b2", "\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc\ud880\udc37\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\udb6e\uddd9\udb84\udf9e\u6477\ud9ed\uddcb\udb0b\ude98",
        30, 60938, -737280355, -4661016277697640362L, -55763L, true, false, (char) 15928, (char) 15186,
        Double.longBitsToDouble(0x3fe14f6dbaeab082L), Double.longBitsToDouble(0x3fd0f962386ad52eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udd67\ud890\udfde\ud8af\ude8d\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 4, "\uda0b\udd67\ud890\udfde\ud8af\ude8d", "\u2da8\ua146\u28ff\ub98d\u0976\u624e\u965c\u8cc0", "\ud9a8\udef4\udbf3\ude67\udac9\udc4b\udacd\uddb5\ud9ad\ude0c\udb1a\udcbd\udb69\udf97\ud9ad\uddb3\u6477\ud9ed\uddcb\udb0b\ude98\ud6f9\ud8cd\udc46\udaef\udcb9\ud8a2\udf61",
        6, 35348, -593823512, 7587043446859043282L, -92747L, true, false, (char) 1597, (char) 653,
        Double.longBitsToDouble(0x3fd13f541d83ecd6L), Double.longBitsToDouble(0x3f84b5c03802b800L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:958777918:-34:-15.94\012",
        Z.run(T, 2, 10, 5, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\u6ca5\ua317\u6324\u0e68\ube2b\ud0c8\u8cc0", "\ud91b\ude2a",
        20, 60124, -557457493, -5593749779644455106L, -11128L, false, true, (char) 21968, (char) 57564,
        Double.longBitsToDouble(0x3fe3eec810791e44L), Double.longBitsToDouble(0x3fe44a7e8b64d40dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 10, 4, "\ud8c7\udcfe\ud909\udf25", "\uc7de\u8a99\u91bf", "\uda0b\udda2\u2e59\ud9c8\udc36\ud9ca\udf85\udae4\ude73\ud844\udd1f",
        49, 90373, -327885796, 1966779513170271615L, -41887L, false, false, (char) 15572, (char) 38401,
        Double.longBitsToDouble(0x3feab5e0477dd902L), Double.longBitsToDouble(0x3f9c7f4482f9c7a0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\ud9fd\udfce\ud989\udfda\ud98e\uddd5\012",
        Z.run(T, 2, 10, 3, 4, "\ud9fd\udfce\ud989\udfda\ud98e\uddd5", "\u532b", "\ud831\udf78\ud9ff\uddd7\udb6f\udc04",
        28, 25347, 270028695, 7949638056598046369L, 7292L, true, true, (char) 57595, (char) 8350,
        Double.longBitsToDouble(0x3fdb85ddf6508c3cL), Double.longBitsToDouble(0x3fe8003f09155cbbL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:P-159874641Y3M11DT20H45M27.479S\012",
        Z.run(T, 2, 10, 8, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u40ff\uc3c0\ua2fd\u2e57\u0e68\u8506\ud151\u8cc0", "\u7b81",
        35, 61947, -721708437, -5045384220900366530L, -39051L, false, true, (char) 60347, (char) 39759,
        Double.longBitsToDouble(0x3fe4ead72564d40dL), Double.longBitsToDouble(0x3fdb1c90abd6b1c2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 12, 0, "\uda0b\udde0\ud8f2\ude0e\001", "", "\ud9df\udf2c\ud831\udf78\udb2c\udf4e\ud9ab\ude00",
        28, -965, 0, -2005662047L, -100000L, true, true, (char) 709, (char) 8350,
        Double.longBitsToDouble(0x3f3777c000000000L), Double.longBitsToDouble(0x3e21500000000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:-663154443:-29:-19.46\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\012",
        Z.run(T, 2, 5, 3, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\ua146\ua22e\u65b2\u0e68\ube2b\ud0c8\u8cc0", "\ud9a9\udf95",
        23, 60124, -557457493, -5089346621378959554L, -11128L, false, true, (char) 21968, (char) 57564,
        Double.longBitsToDouble(0x3fe3eec817697f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:P-161267725Y8M7DT11H29M8.426S\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 11, 4, "\ud97f\udc49\ud8f2\ude0e\ud8af\ude7c", "\u9b07\ua146\u7260\u65b2\u0e68\ube2b\u976b\u3237", "\ud886\udca2",
        30, 26078, -557457638, -5089346621378959554L, -11128L, true, true, (char) 21968, (char) 57564,
        Double.longBitsToDouble(0x3fe3eec817697f44L), Double.longBitsToDouble(0x3fe4ead72164d40dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\uda0b\udde0]]\0121=java.lang.String:\uda0b\udde0\012",
        Z.run(T, 2, 9, 12, 4, "\uda0b\udde0", "\u5edd\u9bc8\u585c", "\udb01\udde0\ud9fc\udcd5",
        33, 66276, -1025047822, 1159697972713408946L, -31245L, false, true, (char) 52172, (char) 57595,
        Double.longBitsToDouble(0x3fe9f5cafdb85ddfL), Double.longBitsToDouble(0x3fe94230f70007e1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=new org.apache.commons.lang.time.DurationFormatUtils:@?\012",
        Z.run(T, 2, 10, 10, 11, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\u10f0\u22e2\u6cb2\u4536\u5192\ud0c8\u8cc0", "\u74af",
        31, 75205, 1794049130, -5367379435204904940L, -57014L, false, true, (char) 40467, (char) 17406,
        Double.longBitsToDouble(0x3fecd6939e704817L), Double.longBitsToDouble(0x3fe4ead4c664d40dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c]]\012",
        Z.run(T, 2, 1, 9, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\ua146\ua22e\u65b2\u0e68\ube2b\ud0c8\u8cbb", "\ud9a9\udf95",
        23, 60124, -557457493, -3236396849130016740L, -11128L, false, true, (char) 21968, (char) 57564,
        Double.longBitsToDouble(0x3fe3eec817697f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\ud80a\udf4a\ud904\udeb2\ud8af\ude7c\0121=java.lang.String:\ud80a\udf4a\ud904\udeb2\ud8af\ude7c\012",
        Z.run(T, 2, 2, 3, 4, "\ud80a\udf4a\ud904\udeb2\ud8af\ude7c", "\u27c6\u5261\u8b08\u620a\u0e68\u963e\u5242\u32d8\u3cd7\u2add\ud0f0\uaf0c\u838f\u7766", "\ud8cb\udc0f\udb84\udf9e\uda93\udda4\udbc6\udf9d\uda1b\udea0\uda48\udf26\ud947\udd7d\uda03\udfdc\uda27\udc7e\ud9c0\ude31\ud9d6\udc3a\ud97e\udca8\ud881\udf53\udae1\udcec\udb33\ude99\ud99e\udc3a\udbb9\udd68\udae0\udf19\udb96\udcbb",
        6, 79385, -1289617869, -8476373716700381275L, -4401L, false, true, (char) 45497, (char) 34168,
        Double.longBitsToDouble(0x3fd1c8ad8f5f93feL), Double.longBitsToDouble(0x3fe1a529d77be155L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udda3\ud912\udf0c\ud904\ude2a\0121=java.lang.String:\uda0b\udda3\ud912\udf0c\ud904\ude2a\012",
        Z.run(T, 2, 2, 3, 4, "\uda0b\udda3\ud912\udf0c\ud904\ude2a", "\u33eb\u6482\ua22e\u65b2\u0e68\ube2b\u5c7d\u8cc8", "\uda00\ude0d",
        8, 36894, -557457493, -5102012996954806387L, 73114L, false, true, (char) 3024, (char) 36824,
        Double.longBitsToDouble(0x3fe3eae377697f43L), Double.longBitsToDouble(0x3fe4ead720fa45f8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M1225076109DT-11H-18M-35.42S\0121=java.lang.String:\uda0b\udde0\udad2\udcfe\ud8af\udf33\012",
        Z.run(T, 2, 6, 12, 10, "\uda0b\udde0\udad2\udcfe\ud8af\udf33", "\u585c\ua146\u80e7\u64ec\u0e68\ube2b\ud0c8\u8cc0", "\ud8d3\udc6e",
        8, 60124, -500506709, -5089345865464715458L, -11128L, false, true, (char) 43292, (char) 52528,
        Double.longBitsToDouble(0x3fe3ec3c27697f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\uda84\ude00\ud8f2\ude0e\ud8af\ude7c]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 8, "\uda84\ude00\ud8f2\ude0e\ud8af\ude7c", "\u4353\u9a9d\ua22e\u65b2\u62c9\ud284\uc5cb\u8d29", "\ud9a9\udf95",
        13, 60158, -557457493, -5089346621378959554L, -11128L, false, true, (char) 4728, (char) 51933,
        Double.longBitsToDouble(0x3fe3eec815697f44L), Double.longBitsToDouble(0x3fd065ae49aad164L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:1225067360 days -11 hours -29 minutes -19 seconds\012",
        Z.run(T, 2, 10, 7, 0, "\udb0c\udd2e\udbf8\ude34\ud8af\ude7c", "\u6fec\ua0b2\ua22e\u65b2\u0e68\ube2b\u7bbf\u1c4b", "\ud9a9\udf95",
        7, 71228, -557457493, -5089346621378959554L, -11128L, false, true, (char) 23005, (char) 23804,
        Double.longBitsToDouble(0x3fe3eecd27697f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:213648467 days 19 hours 16 minutes 25 seconds\012",
        Z.run(T, 2, 10, 7, 1, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03", "\u1544\ub51a\u7a68\ua757", "\uda91\ude77\ud975\udf84\ud87c\udc91\udbf3\ude67\ud8d2\uddf0\ud8ce\udc39\udab2\udc07\ud896\udc57",
        4, -1000, -1367088235, 3729310971362185373L, -36663L, true, false, (char) 37489, (char) 55833,
        Double.longBitsToDouble(0x3fd372cc94ed54dcL), Double.longBitsToDouble(0x3fe9518818877544L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:914122436 days 15 hours 36 minutes 47 seconds\012",
        Z.run(T, 1, 7, 5, 5, "\uda0b\udd40\uda74\udcef\ud9ee\udeec\udbbe\ude85", "\ua446\ud430\u7933\u2d8f\u692b\ud124\u6dc4\u39dc\u9445\u6842", "\uda20\udf36\uda60\udcf2\uda5c\ude8e\ud893\udf6e\udb95\uddb2\ud87c\udfaa\ud9b5\uddf4\ud9be\udf3e\udbe8\udca1\ud8f7\udcca\ud859\udc74\uda20\udd8a\udb61\udf24\udb6a\udf33\ud9d1\udf14\ud99d\udfc8\ud840\udc25\udaeb\udcba",
        54, 54980, 1959671173, 5274172619768207410L, 60656L, true, true, (char) 64187, (char) 34141,
        Double.longBitsToDouble(0x3fe95f1240c718faL), Double.longBitsToDouble(0x3fdfc14e2b02a17cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\uda0b\udd16\ud8f2\ude0e\ud8af\ude7c\ud905\udd5f\ud84e\udca1\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud980\udfb8\udb50\udcc8\udbd0\ude61\ud9ca\udeb5\ud985\udcc9]]\012",
        Z.run(T, 2, 10, 9, 2, "\uda0b\udd16\ud8f2\ude0e\ud8af\ude7c\ud905\udd5f\ud84e\udca1\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud980\udfb8\udb50\udcc8\udbd0\ude61\ud9ca\udeb5\ud985\udcc9", "\u7d27\u838f\u6849\u3e80\u26c9\u30d3\ucc7e\u54e8\u97dd", "\ud8f7\udc82\u4406\udacf\udd53\udb80\ude90\ud841\udc70",
        4, 97092, 686299916, 5187553758744481793L, 36865L, true, true, (char) 55230, (char) 13976,
        Double.longBitsToDouble(0x3fd03743641bf846L), Double.longBitsToDouble(0x3fe869408a833751L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:P-283043690Y3M13DT5H37M44.694S\012",
        Z.run(T, 2, 10, 8, 8, "\uda39\udcb6\ud991\udd01\ud8af\udf50", "\ud5a8\ua146", "\ud9ff\uddd7\uda5a\udd39\ud802\udcc2\ud9ab\udff6\udb2b\udcbc\ud976\udc32\udac3\udfc2\udbc0\udfb5\ud8d2\uddf0\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\udb6e\uddd9\udb84\udf9e\u6477",
        12, 76877, -277473098, -8932303801719381754L, 82940L, false, true, (char) 4373, (char) 8945,
        Double.longBitsToDouble(0x3fba3e2940f93ca0L), Double.longBitsToDouble(0x3fe0cd439c6154e8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\ud9ab\udc02\udbd0\ude61\ud9ca\udeb5\uda8e\udd0e\ud976\udc32\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\udb6e\uddd9\udb84\udf9e\u6477\ud9ed\uddcb\udb0b\ude98\ue9fd\ud8f7\udcc4\u4406\udb9a\udf99\udaf0\ude1c\udbcf\udd27\ud88c\udf5d\udb27\udc34\udbcd\udf5f\udab9\udf78\ud9fa\udc35\012",
        Z.run(T, 2, 10, 3, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\ud9ab\udc02\udbd0\ude61\ud9ca\udeb5\uda8e\udd0e\ud976\udc32\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\udb6e\uddd9\udb84\udf9e\u6477\ud9ed\uddcb\udb0b\ude98\ue9fd\ud8f7\udcc4\u4406\udb9a\udf99\udaf0\ude1c\udbcf\udd27\ud88c\udf5d\udb27\udc34\udbcd\udf5f\udab9\udf78\ud9fa\udc35", "\u974d\u404d\u5901\uc293", "\uda39\udc74\ud871\udf54\udbd1\udee5\ud99f\udd9b\uda9c\udf94\udaa6\udd5b\ud925\udd60\ud832\ude21\u9464\uda1a\udc00\ud94c\ude61\udb8e\udc84\uda95\udcbf\ud91b\uded8\udaab\udf91\uda24\udd66\udb12\udfee\ud804\udf55\udbea\udd9f\uda24\udc91\ufb98\udbfd\udf2a",
        45, 12729, 2122375370, -4548280585458645796L, -74579L, false, true, (char) 53390, (char) 24850,
        Double.longBitsToDouble(0x3feccb52c87a9d3dL), Double.longBitsToDouble(0x3fc42170dc01e6fcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udde0\0121=java.lang.String:\uda0b\udde0\012",
        Z.run(T, 2, 3, 3, 4, "\uda0b\udde0", "\u5edd\u9bc8\ub6c2", "\ud831\udf78\udb5a\ude24\u754d",
        36, 25269, 270013386, 7949638056598046369L, 10387L, false, true, (char) 919, (char) 35142,
        Double.longBitsToDouble(0x3fe80261e1155cbbL), Double.longBitsToDouble(0x3fcca9ff09f76408L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 0, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\u74ab\ua22e\u65b2\ube67\ube2b\ud0c8\u80b4", "\udb35\udeba",
        23, 54382, -557457439, -5089346621378959554L, 61732L, false, true, (char) 22913, (char) 37489,
        Double.longBitsToDouble(0x3fd0270d27601c12L), Double.longBitsToDouble(0x3fe266bc3905f21dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\012",
        Z.run(T, 2, 10, 4, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\ua146\ua22e\u65b2\u0e68\ube2b\ud0c8\u8cc0", "\ud9a9\udf95",
        23, 60124, -557457493, -5089346621378959554L, -11128L, false, true, (char) 21968, (char) 57564,
        Double.longBitsToDouble(0x3fe3eec817007f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udde0\012",
        Z.run(T, 2, 10, 3, 4, "\uda0b\udde0", "\u5f9a\u9bc8\u585c", "\ud9f1\udc58\uda07\udf60\ud965\udd9d",
        28, 25347, 270013386, 7949638056598046369L, -11352L, false, true, (char) 44768, (char) 21968,
        Double.longBitsToDouble(0x3fcca9ff09f76408L), Double.longBitsToDouble(0x3feb4bfa269d5ae4L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M1225067360DT-11H-29M-19.46S\0121=java.lang.String:P0Y0M1225067360DT-11H-29M-19.46S\012",
        Z.run(T, 2, 6, 6, 0, "\ud9cd\udfe1\ud955\udf44\ud8af\udeb1", "\u0cdf\u5835\u24f7\u3715\u0e68\ube2b\ud0c8\u8cc0", "\ud9a9\udf95",
        23, 60124, -557457493, -5089346621378959554L, -11128L, false, true, (char) 21968, (char) 57564,
        Double.longBitsToDouble(0x3fe3eec817697f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udd13\u6729\ud9bc\udeef\udb06\udedc\ud84e\udd03\uda80\udda5\uda08\ude08\012",
        Z.run(T, 2, 10, 3, 4, "\uda0b\udd13\u6729\ud9bc\udeef\udb06\udedc\ud84e\udd03\uda80\udda5\uda08\ude08", "\u2f3c\ube2b\u51f8\u8cc0\u1edd\u7473\u6c35\u47fb\u2075\u6849\u0aa7\u5916\u37d0\ud47e\u54e8\u97dd\ucaae\u0954\u7323\ubcd6\u1e0c\ub0bc\u5c7c\u992b\ubc02\u2dd5\ua502\u2aa2\u55f7\u9686\u4a6a\u7de8\u384e\u5f26\ub2bb\u78e2\ud35e\u93b3\ub7ab\u75bd\u707c\ub8cf\u6fb3\u58b0\u1802\u6004\u8815\u0997\u9ec1", "\ud8fe\udf21\ud80e\udf76\ud936\udd5a\u64a3\uda4c\udd3f\ud960\udc25\uda14\udf0b\ud892\udda9\udb51\ude0b\ud8cf\uddb9\udba9\udc89\ud840\udd7b\ud899\uddef\udb44\uddfb\uda8d\ude15\u3693\udb23\ude97\ud841\udd04\ud959\uddad\udbb5\udf15\udbde\ude2d\uda8b\udfa8\ud8fb\udeb5\ufb74\udbf0\udd88\uda9a\ude12\udb18\udc41\ud9c1\ude21\udacb\udc95\udaee\udfad",
        17, 86517, -1130962790, -6173574126752925486L, -36403L, false, false, (char) 14426, (char) 15916,
        Double.longBitsToDouble(0x3fe43214c02b1454L), Double.longBitsToDouble(0x3fe6e1df836e88faL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u82be\ua146\ua22e\u6da3\u3db3\ube55\ud0c8\ucae8", "\ud960\ude23\ud98e\udcf1\uda62\udc56\udacd\uddb5",
        -5, 74126, 1176396257, -4795670424283553220L, 81087L, true, true, (char) 30407, (char) 22913,
        Double.longBitsToDouble(0x3fe326a06f39f5ecL), Double.longBitsToDouble(0x3fedf16b9968a51fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:\ud89e\udd6c\ud97a\udfa7\ud88b\udc52\ud8e9\uddcb\ud84e\udca4\ud8de\ude13\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\udb70\ude3c\udac3\udd9c\ud8ff\udfef\udbc3\udd01\ud9ff\udd25\ud9ec\udc7e\0121=java.lang.String:\ud89e\udd6c\ud97a\udfa7\ud88b\udc52\ud8e9\uddcb\ud84e\udca4\ud8de\ude13\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\udb70\ude3c\udac3\udd9c\ud8ff\udfef\udbc3\udd01\ud9ff\udd25\ud9ec\udc7e\012",
        Z.run(T, 2, 2, 3, 12, "\ud89e\udd6c\ud97a\udfa7\ud88b\udc52\ud8e9\uddcb\ud84e\udca4\ud8de\ude13\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\udb70\ude3c\udac3\udd9c\ud8ff\udfef\udbc3\udd01\ud9ff\udd25\ud9ec\udc7e", "\u6849\ua551\u44d6\u9647\u9c39\u6f04\ua278\ua2b3\u0954\u7323\u0ca1\u6cdd\ua5fa\u4e08\ua7b9\u8e61\uccd8\u2d52\u5cfb\uaf95\u4218\u4ae3\u6efc\ucea5\ub9d3", "\uda5d\udc44\ud9c1\udf7d\uda7d\udc5a\ud970\udfe9\ud874\udd99\u5e40\ud8c0\udf1e\u8c1a\ud94c\udcbd\udabc\udcbf\ud899\udd4f\udad2\udf7f\ud8be\ude47",
        56, 231, -1415368424, -3791975783909167167L, -36728L, false, true, (char) 4678, (char) 45129,
        Double.longBitsToDouble(0x3fdd153e8b83c8b2L), Double.longBitsToDouble(0x3fe48a5fb209d5eaL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\udb36\uddc8\ud9ef\udcdd\udb8a\udd8e\ud89f\udc91\ud976\udc32\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\ud814\udd16\udad4\udef4\udb80\udf27\ud9ed\uddcb\udb0b\ude98\ue9fd\ud8f7\udcc4\u4406\ud921\udcfb\udae6\uddb7\udab5\udc91\udb15\udcb0\udb7a\udf3e\ud8b1\udf5d\ud9c1\ude32\ud983\udd26\udba4\udef7\ud828\udd9f\udbe7\udf57\uda17\ude39\uda5d\udfef\udb33\udc54\ud923\udc2f\ud85b\ude45\012",
        Z.run(T, 2, 10, 3, 0, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\udb36\uddc8\ud9ef\udcdd\udb8a\udd8e\ud89f\udc91\ud976\udc32\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\ud814\udd16\udad4\udef4\udb80\udf27\ud9ed\uddcb\udb0b\ude98\ue9fd\ud8f7\udcc4\u4406\ud921\udcfb\udae6\uddb7\udab5\udc91\udb15\udcb0\udb7a\udf3e\ud8b1\udf5d\ud9c1\ude32\ud983\udd26\udba4\udef7\ud828\udd9f\udbe7\udf57\uda17\ude39\uda5d\udfef\udb33\udc54\ud923\udc2f\ud85b\ude45", "\uac43\ub7a8\u491c\uc32d\u8045\uc726\uad3f\u7c09\u0f4d\ub4ab\u2e4a\u6a1a\u00f9\u566f\u6068\u46cc\u0ecc\u3622\u4a43\u3fe3\u378b\u81e3\u9f44\u6e9a\ud4e0\u88d6\u00f4\u6f78\ucc25\ub1ec", "\ud839\udfe2\ud896\udf29\udbf7\udf3d\uda58\ude00\ud8d2\ude7c\udb99\udedf\uda5d\udd9a\ud84e\udd2f\ud974\udc01\ue4f0\ud8a5\udc2a\udb84\ude17\ud8a3\uddb5\ud9e6\udf44\ud93f\udf35\ud9de\udfae\udaf5\ude73\ud9b0\udd27\udb41\udc4a\ud8df\udecc\ud816\uddf7\ud9a0\udd00\udae8\ude50",
        51, 79364, 2099578710, -8189371196819687244L, -80524L, true, true, (char) 22264, (char) 22562,
        Double.longBitsToDouble(0x3fde8841d7e5057eL), Double.longBitsToDouble(0x3fe699bc29327984L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\ud931\udcca\uda95\udec0\ud9f2\udee1\uda7d\udf72\udb27\ude0b\ub9e9\uda3d\udf98\ud9a3\udda1\ud836\ude3b\ud9ff\uddd7\ud91a\udf0b\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc\0121=java.lang.String:P0Y0M698624033DT13H1M2.084S\012",
        Z.run(T, 2, 3, 6, 1, "\ud931\udcca\uda95\udec0\ud9f2\udee1\uda7d\udf72\udb27\ude0b\ub9e9\uda3d\udf98\ud9a3\udda1\ud836\ude3b\ud9ff\uddd7\ud91a\udf0b\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc", "\uaf5d\u23dc\u7ee0\u3e77\u2680\u30d3\u7666\u1da5\u1bd5", "\ud8d3\udec2\u43b0\udb6c\ude61\ud94d\udceb\ua4e4",
        21, 99201, -2116848982, 3771212860242062084L, 98404L, true, true, (char) 9104, (char) 43964,
        Double.longBitsToDouble(0x3fc8ed703d3b9a8cL), Double.longBitsToDouble(0x3fdf2bf79fa96d64L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:1046738848:-20:-50.52\0121=java.lang.String:1117355943 days -8 hours -20 minutes -50 seconds\012",
        Z.run(T, 2, 5, 7, 11, "\ud867\udfd7\udb4e\udf43\ud8af\ude7c", "\u39cb\u6729\u59e9\u97c5\u712a\ubeaf\u361e\u48e0", "\ud897\udf44",
        31, 30044, -557509890, -5469738062170850848L, -11128L, false, true, (char) 21968, (char) 51614,
        Double.longBitsToDouble(0x3fd8283504d2747cL), Double.longBitsToDouble(0x3fe1249d6e64d40dL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String: |a0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[]]\012",
        Z.run(T, 2, 10, 11, 10, "\uda0b\udde0\ud8af\udd5f\u7a71", "\u585c\ua146\ua22e\u65b2\u39aa\ucf62\u787f\ud1e5", "\ud9b9\udf95",
        44, 60149, -557476949, -5089346621378959554L, -11128L, false, true, (char) 11423, (char) 46406,
        Double.longBitsToDouble(0x3fc6bf7e9da5fd10L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 1, "\udb9d\udf9a\udbdd\udf12\udb95\udcf8", "\u585c\ua146\ua22e\u65b2\u0e68\ube2b\uac68\u978a\ua774\u5996\u165a\uafab\u838f", "\ud8ad\udcc6\udb6e\uddd9\uda8b\udd81\u64a2\ud9ed\uddcb\udb0b\ude98\ue9fd\udbbd\udd7b\ud935\udc50\udbcb\udd00\ud886\udc83\udb78\udc17",
        24, 18353, 1544468996, 5238440489834446158L, 47563L, false, true, (char) 57213, (char) 26811,
        Double.longBitsToDouble(0x3fdb66992f9d97c6L), Double.longBitsToDouble(0x3fe12495e10c2675L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\ud81e\udcef\ud8f2\ude0e\ud8af\ude7c\0121=java.lang.String:\ud81e\udcef\ud8f2\ude0e\ud8af\ude7c\012",
        Z.run(T, 2, 1, 1, 10, "\ud81e\udcef\ud8f2\ude0e\ud8af\ude7c", "\u9157\u3604\u3297\u2e1f\u5529\u29cb\ud184", "\ud81e\udff0\ud9a9\udf95\ud949\ude44\ud8e4\udcf7\ud97b\udd3d\udbd3\udd5b\ud903\udf85",
        54, -358, 1367684608, 6846700481072655308L, -89012L, true, false, (char) 41955, (char) 48214,
        Double.longBitsToDouble(0x3fe48202fc34d349L), Double.longBitsToDouble(0x3fdb8dabe113deb2L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\udaa0\ude42\udaff\udd7b\ud81f\udd00\uda68\ude7a\ud84e\udd03\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\udb6f\udc04\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc\ud976\udc32\ud9a9\udf95\udb4e\udf67\udae8\udd76\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\udb6e\uddd9\ud929\udc90\u0c7b\ud9ed\uddcb\udb0b\ude98\ue9fd\ud8f7\udcc4\u4406\ud802\udf6d\uda54\ude78\012",
        Z.run(T, 2, 10, 3, 0, "\udaa0\ude42\udaff\udd7b\ud81f\udd00\uda68\ude7a\ud84e\udd03\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\udb6f\udc04\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc\ud976\udc32\ud9a9\udf95\udb4e\udf67\udae8\udd76\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\udb6e\uddd9\ud929\udc90\u0c7b\ud9ed\uddcb\udb0b\ude98\ue9fd\ud8f7\udcc4\u4406\ud802\udf6d\uda54\ude78", "\u6f62\u913c\u9204\u7734\u200c\ucee3\u6958", "\ud9ad\udf7d\uda84\udea0",
        35, 94407, 2048937246, -2440192417383178419L, -12719L, false, true, (char) 41342, (char) 28201,
        Double.longBitsToDouble(0x3fd98f41f3e5ebaaL), Double.longBitsToDouble(0x3fe64fb9bcb0e588L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud81f\udd73\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud81f\udd73\012",
        Z.run(T, 2, 12, 2, 9, "\uda0b\udde0\ud8f2\ude0e\ud81f\udd73", "\u6a6f\u4409\ua22e\u65b2\u0e68\ube2b\ud0c8\u0397", "\ud9a9\udf3c",
        26, 55810, -557457493, -5089346621223901378L, -15667L, true, false, (char) 51636, (char) 36549,
        Double.longBitsToDouble(0x3fe3eec817697f44L), Double.longBitsToDouble(0x3fc1ab5c9990e984L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\ucfd5\000\000\012",
        Z.run(T, 2, 10, 3, 4, "\ucfd5\000\000", "", "",
        1, 75299, 723428173, -2933270064450022364L, -98303L, false, false, (char) 12946, (char) 52172,
        Double.longBitsToDouble(0x3fe1b6f628000000L), Double.longBitsToDouble(0x3fdb85d006508c3cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:-589616266:03:51.529\0121=java.lang.String:P0Y0M1098309169DT199591888H21M11.785S\012",
        Z.run(T, 2, 5, 8, 2, "\udafe\udf79\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a", "\ua146\ua22e\u65b2\u0e68\ube2b\ud0c8\u8cc0\u1edd\u7473\ud0f0\uaf5d", "\ud9ad\udece\ud8ad\udcc6\udb6e\uddd9\udb9c\ude9e",
        6, 31757, -654143259, 9182235447209031529L, -48302L, false, true, (char) 52990, (char) 63556,
        Double.longBitsToDouble(0x3fbe117bd4a5bbb8L), Double.longBitsToDouble(0x3fe19124465b3390L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\012",
        Z.run(T, 1, 10, 4, 1, "\uda0b\udde0\ud8f2\udec4\ud8af\ude7c", "\u585c\ua146\ua22e\u65b2\ucf63\u183f\u7609\ud6dd", "\ud9a9\udf95\udbf3\ude67\ud92d\udf3e\ud9e5\udf46\ud9ad\uddf2\ud8ad\udcc6\udb6e\uddd9\udb84\udf9e",
        6, 31757, -654143259, 9170694973163894633L, -83204L, false, true, (char) 48987, (char) 13855,
        Double.longBitsToDouble(0x3fb7619141b9f778L), Double.longBitsToDouble(0x3fede29fc772b508L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\012",
        Z.run(T, 2, 10, 3, 10, "", "\000\u017b\u9aea\u585c\ua146\034\000", "\uda1b\udc26",
        22, 39386, 178, 848491264L, 96608L, false, false, (char) 8350, (char) 919,
        Double.longBitsToDouble(0x3fa4230f00000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M-1992685456DT-2H-54M-36.61S\0121=java.lang.String:1992685456 days 2 hours 55 minutes 33 seconds\012",
        Z.run(T, 2, 8, 7, 4, "\ud94f\ude81\ud810\udcc5\ud85a\udc3b\uda68\ude7a\ud84e\udd03\uda80\udda5\ud89d\ude92\ud9df\udf2c\ud831\udf78\ud9ff\uddd7\ud842\udd0e\udab2\ude1e\udabe\udfda\ud9fb\udcf7\uda7c\ude96\ud818\ude82", "\u067b\u96bc\u8706\u3073\ud47e\u54e8\u97dd\ucaae\u0954\u7323", "\udb4d\udc92\udb5e\udcd3\ud836\udea9\ud973\udd41\ud8e8\udd6a\ud99f\udd49\ud962\uddb8\udb64\udd07",
        4, 7941, -1664236239, 7964956685271333697L, 57358L, false, true, (char) 51501, (char) 39144,
        Double.longBitsToDouble(0x3fee44688a17f868L), Double.longBitsToDouble(0x3fcc9f7960b20894L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udde0\ud89e\ude04\ud8af\ude7c\0121=java.lang.String:\uda0b\udde0\ud89e\ude04\ud8af\ude7c\012",
        Z.run(T, 2, 12, 2, 1, "\uda0b\udde0\ud89e\ude04\ud8af\ude7c", "\ud25b\ua146\u9602\u65b2\u0e68\ube2b\ud0c8\u8cc0", "\ud9a9\udf95\udaa8\udd6c\ud8d2\uddf0\udacd\uddb5\ud929\udf34\ud890\udf98\udb6e\udd28",
        28, 44519, 281435428, -2809524696737596445L, 30717L, false, false, (char) 1421, (char) 17171,
        Double.longBitsToDouble(0x3fa16cb44e24eeb0L), Double.longBitsToDouble(0x3fd42c5ba4ba4fa0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\ud99e\udede\ud8f2\ude68\ud87f\udc7c\udb2d\udfdd]]\0121=new org.apache.commons.lang.time.DurationFormatUtils:@?\012",
        Z.run(T, 2, 9, 10, 2, "\ud99e\udede\ud8f2\ude68\ud87f\udc7c\udb2d\udfdd", "\u9633\ua5f8", "\ud914\uddbe\udbea\udd08\uda77\udc3f\ud98a\udc67\uda25\udc9f\ud9a9\udf95\ud97e\udded",
        37, 45485, -1184955850, 6764238682495821240L, -45891L, true, true, (char) 28945, (char) 25870,
        Double.longBitsToDouble(0x3fe2cc419c8d9af1L), Double.longBitsToDouble(0x3fee5dd2a0bc6c19L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M-29918426DT-19H-48M-44.7S\0121=java.lang.String:\ud99e\udede\ud8f2\ude68\ud87f\udc7c\uda68\ude7a\012",
        Z.run(T, 2, 8, 2, 8, "\ud99e\udede\ud8f2\ude68\ud87f\udc7c\uda68\ude7a", "\u8116\u10ef\u6bbc\u0dde\u55fa\u5f70\ubda2\u70f0", "\ud97e\udded\ud810\udf58\ud953\udf2c\ud9ad\ude0c",
        56, 65624, 132209448, 6682118090816965653L, 40670L, false, false, (char) 41754, (char) 53291,
        Double.longBitsToDouble(0x3fe7d9e41ca3d607L), Double.longBitsToDouble(0x3fee4b105f5e69b3L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:164018607 days 18 hours 37 minutes 17 seconds\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 8, "\ud9fe\udc1d\uda39\ude1e\ud890\udc27\uda68\ude7a\ud86e\udd74\uda75\udcb4\udad9\ude12\ud8b2\udccf\udac5\udd28\udb6c\udc34\ud985\udddf", "\ub8e5\u2d14\ud0f0", "\ud953\udf2c\ud9bb\udce9\ud8ad\udcc6\udb6e\uddd9\udb84\udf9e\u6477\uda45\udced\uda2e\udcb6\udb66\udf1a\udbd0\udd39",
        47, 30337, -704122117, 7064789520825437129L, -6135L, true, true, (char) 19621, (char) 40983,
        Double.longBitsToDouble(0x3fdde9eaeae1bf1aL), Double.longBitsToDouble(0x3fc2fdf52699fc30L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.String:\ud99e\udede\ud8f2\ude68\ud87f\udc7c\uda68\ude7a\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 8, "\ud99e\udede\ud8f2\ude68\ud87f\udc7c\uda68\ude7a", "\u9633\uc480\u62ee\u0dde\u25a0\ua49b\ubda2\u70f0", "\ud97e\udded\ud810\udf58\ud953\udf2c\ud9ad\ude0c",
        34, 65624, 132209448, 6682118090816965653L, -24866L, false, false, (char) 41754, (char) 53291,
        Double.longBitsToDouble(0x3fe7d9e41ca3d607L), Double.longBitsToDouble(0x3fee4b105f5e69b3L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[]]\0121=java.lang.String: |a0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[]]\012",
        Z.run(T, 2, 11, 0, 8, "\ud99e\udede\ud8f2\ude68\ud87f\udc7c\uda68\ude7a", "\u9633\ua5f8\u6be7\u0dde\u55fa\u5f70\ubda2\u70f0", "\ud97e\udded\ud810\udf58\ud953\udf2c\ud9ad\ude0c",
        56, 83408, -777546458, 6682118090816965653L, 40670L, false, false, (char) 41754, (char) 53291,
        Double.longBitsToDouble(0x3fe7d9e41ca3d607L), Double.longBitsToDouble(0x3fe64b105de26aeeL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:813420917:01:08.382\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\udac2\udd02]]\012",
        Z.run(T, 2, 5, 9, 7, "\udac2\udd02", "\u5edd\u8bc5", "\ud8b1\udff7\udaaf\udf28\udb6c\udc34",
        35, 3387, 2079693496, 6636075807243668382L, -31245L, true, true, (char) 45754, (char) 57573,
        Double.longBitsToDouble(0x3fe9f5caff5c5ddfL), Double.longBitsToDouble(0x3fc9c0a19e2c698cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.String:29918426 days 19 hours 49 minutes 25 seconds\0121=java.lang.String:29918426 days 19 hours 49 minutes 25 seconds\012",
        Z.run(T, 2, 7, 7, 8, "\ud99e\udecc\ud9a2\ude80\ud87f\udc13\uda68\ude7a", "\u9633\u923a\u6baa\u0dde\u4e4d\u5f70\ubda2\u63e6", "\ud97e\udded\ud810\udf58\ud953\udf2c\udac5\uded7",
        -2, 76616, 132209535, 6682118090816965653L, 40793L, false, false, (char) 41754, (char) 53291,
        Double.longBitsToDouble(0x3fe7d9e41ca3d607L), Double.longBitsToDouble(0x3fee4b105f5e69b3L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\ud99e\udf60\ud8f2\ude68]]\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\ud99e\udf60\ud8f2\ude68]]\012",
        Z.run(T, 2, 9, 9, 4, "\ud99e\udf60\ud8f2\ude68", "\u8bc5\u1dfd\u9633\ua5f8", "\ud801\udf6f\u52ef\ud846\uddcc\ud962\udd37\uda25\udc9f\ud8a3\udf92",
        11, 34322, -558956253, -5089346622736958542L, -11128L, false, true, (char) 64719, (char) 31684,
        Double.longBitsToDouble(0x3fe5b60a4c628261L), Double.longBitsToDouble(0x3fc54b4e19904720L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M-29918439DT-13H-36M-26.82S\0121=java.lang.String:P0Y0M-29918439DT-13H-36M-26.82S\012",
        Z.run(T, 2, 8, 8, 4, "\udbb1\udcf2\ud8f2\udebe\ud8af\ude7c\ud800\udec6", "\u1aaf\ua22e\u65b2\u0e68\ube2b\u60b0\u4afa", "\ud9a9\udf95\udbfd\udfed\ud8d2\uddde\udacd\uddb5\ud9ad\ude0c",
        56, 65624, 132209448, 6682118091917818133L, 31715L, false, true, (char) 22781, (char) 37604,
        Double.longBitsToDouble(0x3fb5aff1fb0e2c20L), Double.longBitsToDouble(0x3fe99dbf5c0d620fL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String:\ucf5c\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 4, "\ucf5c", "\u5edd\u9bc8\u2da8\ua146\u07e2\ub98d\u0976\u624e\u965c\u8cc0\u13ca\000\000\uaef0\u1af8\u6849\u3e80\u7564\u9b6a\u6605\u54e8\u97dd\u00e5\u017b\u878a\u2e0b\u6606\u306c\u39c4", "\udba9\udc43\ud926\udfef",
        33, 13165, -357599432, -774311422975803392L, -95894L, false, false, (char) 65187, (char) 38645,
        Double.longBitsToDouble(0x3f53d62c9d34b400L), Double.longBitsToDouble(0x3fd1e43199716b50L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 0, "", "\u6e59\u5edd\uc169\u585c\u3c37\ua317\u6324\u0e68\ube2b\ud0c8\u8cc0\u1e3c", "\000",
        -5, 61507, -1302396362, 6764238682495821240L, 96608L, true, true, (char) 20701, (char) 45949,
        Double.longBitsToDouble(0x3fbe4791144a7e88L), Double.longBitsToDouble(0x3feb26a06805e89bL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String:980388237 days 22 hours 10 minutes 21 seconds\0121=java.lang.String:980388237 days 22 hours 10 minutes 21 seconds\012",
        Z.run(T, 2, 7, 7, 2, "\uda0d\udf2a", "\u8504\u9bb3\u585c", "\ud8e9\udf7e\ud9ff\uddd7\udb6f\udc04\ud83b\uddb7\ud9ca\udeb5\udb2b\udc1b\ud987\udc9c\ud9d5\udf48\udae8\udf61",
        32, 61507, -1302396362, 6764238682495821240L, 68165L, true, false, (char) 3773, (char) 11354,
        Double.longBitsToDouble(0x3feb26a069295363L), Double.longBitsToDouble(0x3fc50ddcfbbc78e4L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:788011447 days -12 hours -20 minutes -57 seconds\0121=java.lang.String:788011447 days -12 hours -20 minutes -57 seconds\012",
        Z.run(T, 2, 7, 7, 10, "\uda0b\udde0\ud8e0\udc0e\ud8af\ude7c", "\u6aba\u6ca5\ua317\u6324\u0e68\ub16e\u6e50\u8d1b", "\ud91b\ude2a",
        20, 60124, -555163733, -2900597206018857154L, -11128L, false, true, (char) 21968, (char) 55260,
        Double.longBitsToDouble(0x3fe3eec810792444L), Double.longBitsToDouble(0x3fe44a7e8b64d40dL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:2145428063 days 1 hour 15 minutes 23 seconds\012",
        Z.run(T, 1, 7, 5, 4, "\ud9f2\ude16\ud93f\uded4\udafe\uddb1", "\u585f\u0cf7\ua3d9\u29f5\u2461\u8318\ud108\u8cc0\u1e3c\u3b4b\u39c0", "\udb44\uddf1\ud846\udf0c\ud8ad\udcc6\u19c7\uda1d\udf79\udaba\ude74",
        49, 45142, 507828861, 5751642600263723657L, -85896L, true, false, (char) 2718, (char) 20936,
        Double.longBitsToDouble(0x3fe228b815edcbceL), Double.longBitsToDouble(0x3f9a7f75f05da020L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\ud8b0\udcac\u3989\ud828\udf0d\ud926\ude77\udbdd\udc71\ud8c3\udca8\ud9ff\ude6c\ud97e\uddfe\udbc4\udd94\ud9ca\udeb5\udacc\ude98\ud96a\udda3\ud91b\ude2a\uda7e\udd0d\uda1d\uddf6\ud9d7\udecc\udb59\udda2\ud8b1\udedc\udb6e\uddd9\udb21\udfcd\u6477\ud922\udccc\uda9b\ude20\udb4e\udd55\ud82b\udfdf\udbdb\udfb9\ud85f\udcf7\ud869\udcf2\ud9a6\udf23\ud8aa\udc3d\udaf9\ude32\udb0d\ude4c\u2bfd\ud85e\udfb6\ud9d1\udf07\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\ud8b0\udcac\u3989\ud828\udf0d\ud926\ude77\udbdd\udc71\ud8c3\udca8\ud9ff\ude6c\ud97e\uddfe\udbc4\udd94\ud9ca\udeb5\udacc\ude98\ud96a\udda3\ud91b\ude2a\uda7e\udd0d\uda1d\uddf6\ud9d7\udecc\udb59\udda2\ud8b1\udedc\udb6e\uddd9\udb21\udfcd\u6477\ud922\udccc\uda9b\ude20\udb4e\udd55\ud82b\udfdf\udbdb\udfb9\ud85f\udcf7\ud869\udcf2\ud9a6\udf23\ud8aa\udc3d\udaf9\ude32\udb0d\ude4c\u2bfd\ud85e\udfb6\ud9d1\udf07]]\012",
        Z.run(T, 2, 4, 9, 8, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\ud8b0\udcac\u3989\ud828\udf0d\ud926\ude77\udbdd\udc71\ud8c3\udca8\ud9ff\ude6c\ud97e\uddfe\udbc4\udd94\ud9ca\udeb5\udacc\ude98\ud96a\udda3\ud91b\ude2a\uda7e\udd0d\uda1d\uddf6\ud9d7\udecc\udb59\udda2\ud8b1\udedc\udb6e\uddd9\udb21\udfcd\u6477\ud922\udccc\uda9b\ude20\udb4e\udd55\ud82b\udfdf\udbdb\udfb9\ud85f\udcf7\ud869\udcf2\ud9a6\udf23\ud8aa\udc3d\udaf9\ude32\udb0d\ude4c\u2bfd\ud85e\udfb6\ud9d1\udf07", "\ub0ae\ud4f4", "\uda26\ude58\ud894\udf1d\ud9f3\udf21",
        7, 51452, -1322949136, 702223477713499431L, 78901L, true, true, (char) 16971, (char) 29548,
        Double.longBitsToDouble(0x3fead07b1c303868L), Double.longBitsToDouble(0x3fe693d2f21e6d6aL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\012",
        Z.run(T, 2, 2, 2, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u00c2\uc3c0\ua2fd\u2e57\u0e68\u8506\ud151\u8cc0", "\u7b81",
        35, 61947, -721708437, -5045384220900366530L, -39051L, false, true, (char) 60347, (char) 62090,
        Double.longBitsToDouble(0x3fe67bed65fc9dafL), Double.longBitsToDouble(0x3fdb1c90abd6b1c2L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[]]\0121=java.lang.String:351190573 days -20 hours -29 minutes\012",
        Z.run(T, 2, 11, 7, 11, "\uda0b\uddee\ud8f2\ude0e\ud9ed\udeda\uda68\ude7a\u7528\udaed\udde9\udaa6\udc9c\ud9df\udfbd\ud901\udf80\udb82\ude98\udbcd\udd39\udbd9\udc88\ud9ca\udeb5\u00e1\uda82\udf7b\udb46\uddb3\uda15\udf9b\ud9e2\udcba\udb17\udd83\udabc\udd0e\ud8a3\udd22\u72b4\ud87a\udd38", "\u1b80\ubdf1\u0a23\u5a87", "\ud805\udd1f",
        20, 67295, 189403884, -340742308940940914L, 42229L, true, true, (char) 40074, (char) 21627,
        Double.longBitsToDouble(0x3fed71794eab11f4L), Double.longBitsToDouble(0x3feb9eea80c68a6aL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.String:P-99429364Y10M25DT11H0M25.494S\0121=java.lang.String:P-99429364Y10M25DT11H0M25.494S\012",
        Z.run(T, 2, 8, 8, 4, "\ud837\udc66\uda32\udd3c\ud8ae\udeda", "\ua717", "\ud901\udf80\uda0d\udf5b\ud8e6\udf1f\udbd0\udeea",
        59, 39228, 542296498, -3137876366958099489L, -73995L, false, true, (char) 17977, (char) 60648,
        Double.longBitsToDouble(0x3fe8399527d9d6b7L), Double.longBitsToDouble(0x3fe0af45dfdab7dfL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 0, "", "", "\000",
        34, 42592, -551028245, -586074902728105139L, -100000L, true, false, (char) 38335, (char) 55753,
        Double.longBitsToDouble(0x3fe0900293dfd474L), Double.longBitsToDouble(0x3fe45e32f26be136L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\001\000\000\uda80\udda5\u00eb\ud9df\udf2c\ud831\udf78\udaa2\udd5d\udb1c\udc27\udb05\udde0\udbd7\udc27\000\000\ud79c-1855525989\ud8e5\uded2\uda8f\udfb6\012",
        Z.run(T, 2, 10, 4, 6, "\uda0b\udde0\ud8f2\ude0e\001\000\000\uda80\udda5\u00eb\ud9df\udf2c\ud831\udf78\udaa2\udd5d\udb1c\udc27\udb05\udde0\udbd7\udc27\000\000\ud79cm\ud8e5\uded2\uda8f\udfb6", "\000\000\000\u54a6", "\ud8e6\udd20",
        19, 17858, -452085246, -4264240762374084964L, -6855L, false, false, (char) 53418, (char) 29803,
        Double.longBitsToDouble(0x3fdd89218928867cL), Double.longBitsToDouble(0x3fb792e6ce94c560L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String:571:56:48.277\0121=java.lang.String:571:56:48.277\012",
        Z.run(T, 2, 5, 5, 8, "\uda0b\udde0\ud8f2\ude0e\001\000\ud802\udcd8\udb89\uddbf\u00eb\ud9df\udf2c\ud831\udf78\udb2c\udf4e\ud9ab\ude00\udbd0\ude61#\000", "m", "\ud9ad\uddd6",
        56, -1000, 0, 2059008277L, 97357L, true, true, (char) 21007, (char) 3180,
        Double.longBitsToDouble(0x3fa0f2982123f360L), Double.longBitsToDouble(0x3f9a5eb52d0d4bc0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03\uda80\udda5\udae8\ude2d\ud9a4\uded1\udb01\udde0\ud983\udf3a\udb6f\udc04\ud9a0\udc93\ud8cd\udf58\udb2b\udc1b\ud976\udc32\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\udadb\ude2b\ud8ad\udd0b\ud82d\udc9b\ud89c\udd5c\ud852\udd4a\udb87\udd6e\ud91f\udfe0\ud910\ude54\ud927\udc46\u4213\u92ba\udbca\udfa8\udabb\udcc9\ud806\udd61\uda07\udfbb\udac9\udfdb\ud873\ude7b\udbe9\ude19\ud860\udf33\ud95d\udd77\uda81\udfcb\udb9e\udd25\uda54\uddb8\ud862\ude84\ud92f\udcaf\uda1a\udf3b\ud843\udc92\u5ac2\udbb5\udc5f\ud995\ude3b\uea97\uda67\udc2e\ud82b\udcef\udb09\udde8\udb16\udcab\uda45\ude51\ud895\ude75\ud804\udf0a\ud8eb\udfcf\udb8f\udf05\uda1f\udc54\u6c5e\u24b0\ud92f\udc30\ud9e7\udcfb\udb76\udf42\ud8e6\ude52\uda26\uddc2\ud829\ude55]]\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03\uda80\udda5\udae8\ude2d\ud9a4\uded1\udb01\udde0\ud983\udf3a\udb6f\udc04\ud9a0\udc93\ud8cd\udf58\udb2b\udc1b\ud976\udc32\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\udadb\ude2b\ud8ad\udd0b\ud82d\udc9b\ud89c\udd5c\ud852\udd4a\udb87\udd6e\ud91f\udfe0\ud910\ude54\ud927\udc46\u4213\u92ba\udbca\udfa8\udabb\udcc9\ud806\udd61\uda07\udfbb\udac9\udfdb\ud873\ude7b\udbe9\ude19\ud860\udf33\ud95d\udd77\uda81\udfcb\udb9e\udd25\uda54\uddb8\ud862\ude84\ud92f\udcaf\uda1a\udf3b\ud843\udc92\u5ac2\udbb5\udc5f\ud995\ude3b\uea97\uda67\udc2e\ud82b\udcef\udb09\udde8\udb16\udcab\uda45\ude51\ud895\ude75\ud804\udf0a\ud8eb\udfcf\udb8f\udf05\uda1f\udc54\u6c5e\u24b0\ud92f\udc30\ud9e7\udcfb\udb76\udf42\ud8e6\ude52\uda26\uddc2\ud829\ude55\012",
        Z.run(T, 2, 9, 12, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03\uda80\udda5\udae8\ude2d\ud9a4\uded1\udb01\udde0\ud983\udf3a\udb6f\udc04\ud9a0\udc93\ud8cd\udf58\udb2b\udc1b\ud976\udc32\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\udadb\ude2b\ud8ad\udd0b\ud82d\udc9b\ud89c\udd5c\ud852\udd4a\udb87\udd6e\ud91f\udfe0\ud910\ude54\ud927\udc46\u4213\u92ba\udbca\udfa8\udabb\udcc9\ud806\udd61\uda07\udfbb\udac9\udfdb\ud873\ude7b\udbe9\ude19\ud860\udf33\ud95d\udd77\uda81\udfcb\udb9e\udd25\uda54\uddb8\ud862\ude84\ud92f\udcaf\uda1a\udf3b\ud843\udc92\u5ac2\udbb5\udc5f\ud995\ude3b\uea97\uda67\udc2e\ud82b\udcef\udb09\udde8\udb16\udcab\uda45\ude51\ud895\ude75\ud804\udf0a\ud8eb\udfcf\udb8f\udf05\uda1f\udc54\u6c5e\u24b0\ud92f\udc30\ud9e7\udcfb\udb76\udf42\ud8e6\ude52\uda26\uddc2\ud829\ude55", "\uc6e2\u1dba\uc1b2\u5f27\u0851\u5327\u6f02\ubfa1\ub814\u50c0\uc5cb\u6b24\u7cf0\ua00e\u295f", "\uda74\udcf4\ud966\ude73\ud875\udf2b\uca46",
        41, 10205, 1553523707, 3398157802524984096L, -96510L, true, true, (char) 55504, (char) 12351,
        Double.longBitsToDouble(0x3f8cf8452bf5ebc0L), Double.longBitsToDouble(0x3fe92b1c5e7275c0L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\udb46\udc4e]]\0121=java.lang.String:641241346 days 7 hours 1 minute 33 seconds\012",
        Z.run(T, 2, 9, 7, 4, "\udb46\udc4e", "\ud64c\u9bc8\u585c\u22b7\u8dd2\u45b2\u0166\u19ae\u9420", "\ud976\udc32\ud9a9\udf95\udbf3\ude67\ud8d2\uddf0\udacd\uddb5\ud9ad\ude0c\ud8ad\udcc6\udb6e\uddd9\udb84\udf9e\ud8ae\udf41\uaea2\udbd7\udefb\ud94f\uddf8",
        35, 40952, 129235410, 3024084647314893741L, 70012L, false, false, (char) 14514, (char) 62383,
        Double.longBitsToDouble(0x3fdf1de6898dd5daL), Double.longBitsToDouble(0x3fea5321f2c21211L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.String:\ud80a\udf2e\ud904\udeb2\ud8af\ude7c\0121=java.lang.String:\ud80a\udf2e\ud904\udeb2\ud8af\ude7c\012",
        Z.run(T, 2, 2, 2, 4, "\ud80a\udf2e\ud904\udeb2\ud8af\ude7c", "\u27c6\u06fb\u8b80\u620a\u0e68\u963e\u5242\u32d8\u3cd7\u2add\ud0f0\u6e4f\u838f\u7766", "\ud8cb\udc0f\udb84\udf9e\uda93\udda4\udbc6\udf9d\uda1b\udea0\uda48\udf26\ud8fa\udcf5\uda03\udfdc\uda27\udc7e\ud9c0\ude31\ud9d6\udc3a\ud97e\udca8\ud881\udf53\udb0d\udf96\udb33\ude99\ud99e\udc3a\udbb9\udd68\udae0\udf19\udb96\udcbb",
        6, 89929, -1289617869, -8476373716700381275L, -4401L, false, true, (char) 45497, (char) 49528,
        Double.longBitsToDouble(0x3fd1c8ad8f5e11feL), Double.longBitsToDouble(0x3fe1a529d77be155L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.String:-705821960 days 1 hour 11 minutes 1 second\0121=java.lang.String:\udb3b\ude7b\ud93a\uded6\udb8e\udcba\012",
        Z.run(T, 2, 7, 1, 9, "\udb3b\ude7b\ud93a\uded6\udb8e\udcba", "\u1eea\u61f5\uc462\u1d62\u0e6f\ube2b\ucd15\u7586\u47cb\u55ad\u677c\ucef2\u9bf0\u7b27\u8e84\u430a\ucd35\u34d1", "\ud92d\udcfa\ud9e4\udc35\ud9cd\uddc4\uda80\udebc\ud9c8\udcc2\udab8\udc26\ud805\udc8a\uda71\ude8d",
        8, 72482, -2040863870, 4763124249527461019L, -64445L, true, true, (char) 63012, (char) 64370,
        Double.longBitsToDouble(0x3fd050faf881c186L), Double.longBitsToDouble(0x3fa2eee90af3c090L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:0 days\012",
        Z.run(T, 2, 10, 7, 0, "\ud89a\uded5\udbd8\udc0b\ud8af\ude7b", "\u6fec\ua0b2\ua22e\u65b2\u0e68\ube2b\u7bbf\u1be0", "\000",
        -5, 82416, 0, 0L, -11128L, false, true, (char) 23005, (char) 23804,
        Double.longBitsToDouble(0x3fe006cd27697f44L), Double.longBitsToDouble(0x3fe4ead72000d40dL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:-1073336597:02:09.425\0121=java.lang.String:-1073336597:02:09.425\012",
        Z.run(T, 2, 5, 5, 12, "\udb06\udda5\udb41\udcc0", "\u9bc2\u6fec\ua0b2\ua22e", "\udb15\udd28\ud934\udfcc\ud8d9\udf21\udb2b\udcbc\udac5\uddf6\ud975\ude83\udbf1\udc35\ud9cc\uddfe\uda96\udc2a\udbda\udcdf\ued32\udaeb\udcda\ud850\udf48\ud90a\udd08\ud9a9\udffb\ud902\udfcf\ud91d\udc84",
        16, 26277, 1329839716, 4418234316212529425L, 58563L, false, false, (char) 23181, (char) 9396,
        Double.longBitsToDouble(0x3fdbbcc1c35e70bcL), Double.longBitsToDouble(0x3fd80fbac0889116L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:626308255 days 11 hours\012",
        Z.run(T, 2, 10, 7, 0, "\udb0c\udd2e\udbf8\ude34\ud8af\ude7c", "\u6fec\ua0b2\ua22e\u65b2\u0e68\ube2b\ud373\u5599", "\ud9a9\udf95",
        7, 71228, 1623899563, 8960157218257200958L, -11128L, false, true, (char) 23005, (char) 23804,
        Double.longBitsToDouble(0x3fe3eecd27697f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:0 seconds\012",
        Z.run(T, 2, 10, 7, 1, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03", "\u1544\ub51a\u243a\uc441", "\uda91\ude77\004\000\udbf3\uddfa\ud8d2\uddf0\ud8ce\udc39\udab2\udc07\ud896\udc57",
        4, -1000, 149, 0L, -100000L, true, false, (char) 54285, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe9518800877544L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.String:\ud99e\udede\ud8f2\ude68\ud87f\udc7c\ud958\udcf2\0121=java.lang.String:\ud99e\udede\ud8f2\ude68\ud87f\udc7c\ud958\udcf2\012",
        Z.run(T, 2, 2, 2, 8, "\ud99e\udede\ud8f2\ude68\ud87f\udc7c\ud958\udcf2", "\u8116\u10ef\u6bbc\u0dde\u55fa\ua703\ubda2\u9c2e", "\ud97e\udded\ud810\udf58\ud953\udf2c\ud9ad\ude0c",
        56, 59480, 132209448, 6682118090816965653L, 40670L, false, true, (char) 23006, (char) 21661,
        Double.longBitsToDouble(0x3fe7d9e60ca3d607L), Double.longBitsToDouble(0x3fe94fe9fa1eb4ceL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.String:351190573 days -20 hours -29 minutes\0121=java.lang.String:351190573 days -20 hours -29 minutes\012",
        Z.run(T, 2, 7, 7, 11, "\ud9f3\uddee\ud8f2\ude0e\ud9ed\udeda\uda68\ude7a\u7528\udaed\udde9\udaa6\udc9c\ud9df\udfbd\ud901\udf80\udb82\ude98\udbcd\udd39\udbd9\udc88\ud9ca\udeb5\u00e1\ud84e\udf21\ud857\udd34\uda2f\udfef\ud9e2\udcba\udb17\udd83\udabc\udd0e\ud8a3\udd22\udaf2\udeb5\ud87a\udd38", "\u1b80\ubdf1\u0a23\u5a87", "\ud805\udd1f",
        20, 67295, 189403884, -340742308940940914L, 42229L, true, true, (char) 40074, (char) 21627,
        Double.longBitsToDouble(0x3fed71794eab11f4L), Double.longBitsToDouble(0x3feb9eea80c68a6aL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.String:\uc3a1\ud960\udcb8\u00c8\udb2d\udc76\u00ea\uda80\udda5\udbc2\udfcc\ud84f\udcaf\ud998\udf97\ud8fd\ude5d\udaee\udec9\ud827\udfbb\udbda\udc05\u1e40\ud8d7\udef7\udb72\udd04512925205\udb2d\udd5a\udb79\udeaa\012",
        Z.run(T, 1, 12, 11, 7, "\uc3a1\ud960\udcb8\u00c8\udb2d\udc76\u00ea\uda80\udda5\udbc2\udfcc\ud84f\udcaf\ud998\udf97\ud8fd\ude5d\udaee\udec9\ud827\udfbb\udbda\udc05\u1e40\ud8d7\udef7\udb72\udd04m\udb2d\udd5a\udb79\udeaa", "\u3216\000\uca7e\u5558\uc424\u0757\u2933\ub7f1\u03f5", "\ud9a2\udc98\ud997\udd81\uda71\udde8",
        8, 11533, -1837436495, -4449976615813762345L, 36750L, false, false, (char) 14730, (char) 30634,
        Double.longBitsToDouble(0x3f90705a68e89b60L), Double.longBitsToDouble(0x3fd7756a56470a8cL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:-4 hours -52 minutes -26 seconds\012",
        Z.run(T, 2, 10, 7, 6, "\udb5c\udd44", "\u5edd\u4209\ucb10\ua146\u1f0b\u2974\u5ce3\uc4e1\u8586\ud58a\u0945\004\u9f44\uc2ba\u53e8\u20f8", "\udb58\uddc0\ud934\udc40\uda65\udfa1e\uda22\udca7\udadc\udcc5",
        -5, 94836, 0, -17546046L, 15498L, true, true, (char) 7943, (char) 64889,
        Double.longBitsToDouble(0x3fefe776d5323e42L), Double.longBitsToDouble(0x3fea979d03cd49e6L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.String:0 seconds\0121=java.lang.String:0 seconds\012",
        Z.run(T, 2, 7, 7, 1, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03", "\u1544\ub51a\u243a\uc441", "\uda91\ude77\004\000\udbf3\uddfa\ud8d2\uddf0\ud8ce\udc39\udab2\udc07\udb35\udc47",
        4, -1000, 16652233, 0L, -100000L, true, false, (char) 54285, (char) 0,
        Double.longBitsToDouble(0x3e4f580000000000L), Double.longBitsToDouble(0x3fed9e49b0873140L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:-4 hours -52 minutes -26 seconds\0121=java.lang.String:-4 hours -52 minutes -26 seconds\012",
        Z.run(T, 2, 7, 7, 6, "\udb5c\udd44", "\u5edd\u4209\ucb10\ua146\u1f0b\u2974\u5ce3\uadbc\u856f\ud58a\u0945\u0304\u9f44\uc2ba\u53e8\u20f8", "\udb58\uddc0\ud934\udc40\ud819\uddfd\udb90\udc2b\uda22\udd93\udadc\udcc5",
        -5, 94836, 0, -17546046L, 15498L, true, true, (char) 7943, (char) 64889,
        Double.longBitsToDouble(0x3fefe776d5323e42L), Double.longBitsToDouble(0x3fea979d03cd49e6L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String:0 days\0121=java.lang.String:0 days\012",
        Z.run(T, 2, 7, 7, 1, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\uda68\ude7a\ud84e\udd03", "\u1544\u2309\u555d\u4bdd", "\uda24\udc2f\ud9e0\ude0c\000\udbf3\uddfa\ud8d2\uddf0\ud8ce\udc39\udab2\udc07\ud8f7\udd48\udb73\ude26\udbec\udc91\udbe3\udfd8\000\000\000",
        14, 50047, 57, 0L, 10413L, false, true, (char) 28307, (char) 19793,
        Double.longBitsToDouble(0x3fe535a18cfc362bL), Double.longBitsToDouble(0x3fed919a61f77937L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c\012",
        Z.run(T, 2, 10, 3, 4, "\uda0b\udde0\ud8f2\ude0e\ud8af\ude7c", "\u585c\ua146\ua22e\u732b\u0e68\ube2b\ud0c8\u8cc0", "\ud9a9\udf95",
        55, 60124, -557457493, -5089346621378959554L, -11128L, false, true, (char) 21968, (char) 57564,
        Double.longBitsToDouble(0x3fe3eec817697f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\ud966\udddf\ud9d4\udc33\udbf3\udfdc\022\000\uda80\udda5\u00eb\udbf7\udd94\ud831\udf78\udaa2\udd5d\ud901\ude34\udb05\udde0\udbd7\udc27\000\000\ud79c, m, \ud8e5\uded2\uda8f\udfb6]]\0121=java.lang.String:\ud966\udddf\ud9d4\udc33\udbf3\udfdc\022\000\uda80\udda5\u00eb\udbf7\udd94\ud831\udf78\udaa2\udd5d\ud901\ude34\udb05\udde0\udbd7\udc27\000\000\ud79c1048858299\ud8e5\uded2\uda8f\udfb6\012",
        Z.run(T, 2, 9, 4, 6, "\ud966\udddf\ud9d4\udc33\udbf3\udfdc\022\000\uda80\udda5\u00eb\udbf7\udd94\ud831\udf78\udaa2\udd5d\ud901\ude34\udb05\udde0\udbd7\udc27\000\000\ud79cm\ud8e5\uded2\uda8f\udfb6", "\u40e3\000\u51d9\ud67f", "\ud8e6\udd20\udafc\udffd",
        58, 90754, -992845921, -7353350575983683526L, 60504L, true, true, (char) 53355, (char) 5104,
        Double.longBitsToDouble(0x3fc28867d1792e6cL), Double.longBitsToDouble(0x3fdd298acd0519aeL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:\uda0b\udde0\ud8f2\ude0e\001\000\000\uda80\udda5\u00eb\ud813\ude62\uda29\udc8c\ud989\udc6f\udb60\udc23\udb05\udde0\udbd7\udc27\000\000\ud79c1615154597\ud8e5\uded2\uda8f\udfb6\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\001\000\000\uda80\udda5\u00eb\ud813\ude62\uda29\udc8c\ud989\udc6f\udb60\udc23\udb05\udde0\udbd7\udc27\000\000\ud79c-1855525989\ud8e5\uded2\uda8f\udfb6\012",
        Z.run(T, 2, 1, 4, 6, "\uda0b\udde0\ud8f2\ude0e\001\000\000\uda80\udda5\u00eb\ud813\ude62\uda29\udc8c\ud989\udc6f\udb60\udc23\udb05\udde0\udbd7\udc27\000\000\ud79cm\ud8e5\uded2\uda8f\udfb6", "\000\000\000\u54a6", "\ud85c\ude89",
        19, 17858, -452085246, -4264240762374084964L, -6855L, false, true, (char) 53418, (char) 29803,
        Double.longBitsToDouble(0x3fdd89218928867cL), Double.longBitsToDouble(0x3fb792e6ce94c560L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.String:\ud969\udfdf\ud9d4\udc33\udbf3\udfdc\022\000\uda80\udda5\u00eb\udbf7\udd94\ud831\udf61\ud92c\udc30\ud898\udec6\ud97e\ude8d\udbd7\udc27\000\000\ud79c-2086813539\ud8e5\uded2\uda8f\udfb6\0121=java.lang.String:\ud969\udfdf\ud9d4\udc33\udbf3\udfdc\022\000\uda80\udda5\u00eb\udbf7\udd94\ud831\udf61\ud92c\udc30\ud898\udec6\ud97e\ude8d\udbd7\udc27\000\000\ud79c-1821253596\ud8e5\uded2\uda8f\udfb6\012",
        Z.run(T, 2, 12, 4, 6, "\ud969\udfdf\ud9d4\udc33\udbf3\udfdc\022\000\uda80\udda5\u00eb\udbf7\udd94\ud831\udf61\ud92c\udc30\ud898\udec6\ud97e\ude8d\udbd7\udc27\000\000\ud79cm\ud8e5\uded2\uda8f\udfb6", "\u40e3\000\u51d9\ud67f", "\ud8e6\udd20\udafc\udffd",
        58, 90754, 1708285843, -1301226667866056646L, 60504L, true, true, (char) 53355, (char) 43760,
        Double.longBitsToDouble(0x3fc2887ff1792e6cL), Double.longBitsToDouble(0x3fdd298acd0519aeL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\udae4\udcdc\ud8d3\ude85\001\ud94c\udf3a\u65cb\uda80\uddbc\u00eb\ud9df\udf2c\ud831\udf78\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud9b5\udc5d\012",
        Z.run(T, 2, 10, 12, 0, "\udae4\udcdc\ud8d3\ude85\001\ud94c\udf3a\u65cb\uda80\uddbc\u00eb\ud9df\udf2c\ud831\udf78\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud9b5\udc5d'", "\u096d", "\ud9ad\uddd6",
        56, -1000, 38818, -367068907L, 36274L, true, false, (char) 15923, (char) 31477,
        Double.longBitsToDouble(0x3fbab5b6aafa9650L), Double.longBitsToDouble(0x3fee82fbfe1bb165L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:626308255 days 11 hours\0121=java.lang.String:626308255 days 11 hours\012",
        Z.run(T, 2, 7, 7, 0, "\udb0c\udd2e\udbf8\ude34\ud8af\ude7c", "\u6fec\ua0b2\ua22e\u65b2\u0e68\ube2b\u8b5e\u5599", "\ud9a9\udf95",
        7, 71228, 1623899563, 8960157218257200958L, -11128L, false, true, (char) 22893, (char) 23804,
        Double.longBitsToDouble(0x3fe3eecd27d57f44L), Double.longBitsToDouble(0x3fe4ead72664d40dL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\u65cb\uda80\uddbc\u00eb\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud842\udcf4\uc3c3\ud9a9\udf95\u096d\ud8e5\uded2\uda8f\udfb6\ud9ad\uddd6\ud8ad\udcc6\000\ud876\udcea\udba9\udfca\uda62\ude2a\ud9f8\uddac\012",
        Z.run(T, 2, 10, 12, 5, "\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\u65cb\uda80\uddbc\u00eb\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud842\udcf4'\uc3c3\ud9a9\udf95\u096d\ud8e5\uded2\uda8f\udfb6\ud9ad\uddd6\ud8ad\udcc6\000\ud876\udcea'\udba9\udfca\uda62\ude2a\ud9f8\uddac", "\ub6f3\u9289\u9e8e\u02a7\u588c\u17d9\u7526\u7df0\ubd43\u1130\u6caf\ua6c2\u2c88\u2da4\u8e43\u8119\u234f\ube16\u9044", "\uda83\udf7e\ud855\udd94\udb52\udd1d\ud86f\udfb7",
        44, 25152, 605591671, 6139901861656471675L, 93782L, false, true, (char) 35652, (char) 54908,
        Double.longBitsToDouble(0x3fe4cf6570b09ff9L), Double.longBitsToDouble(0x3fcad2a7c534f8f0L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\ufed0\ud8d3\ude85\u8901\ua989\u65cb\uda80\uddbc\u00eb\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\000\000\000\000\ud9a8\udcf4\u096d\ud8e5\uded2\uda8f\udfb6\ud9ad\uddd6\ud8ad\udcc6\000\ud876\udcea\udba9\udfca\uda62\ude2a\ud9f8\uddac\012",
        Z.run(T, 2, 10, 12, 5, "\ufed0\ud8d3\ude85\u8901\ua989\u65cb\uda80\uddbc\u00eb\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\000\000\000\000\ud9a8\udcf4\u096d\ud8e5\uded2\uda8f\udfb6\ud9ad\uddd6\ud8ad\udcc6\000\ud876\udcea'\udba9\udfca\uda62\ude2a\ud9f8\uddac", "\u28bb\u921f\u9e8e\u02a7\u588c\u17d9\u387a\000\000\000\000\000\u2c88\u2da4\u00c6\u8119\u234f\ube16\u9044", "\uda83\udf7eb\ud861\udc2f\ud86f\udfb7",
        44, 25152, 605591671, 6139901861656471675L, 93782L, false, true, (char) 26368, (char) 54908,
        Double.longBitsToDouble(0x3fc33d95c0000000L), Double.longBitsToDouble(0x3e24d3e000000000L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\u65cb\uda80\uddbc\u00eb\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud842\udcf4\uc3c3\ud9a9\udf95\u096d\ud8e5\uded2\0121=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\u65cb\uda80\uddbc\u00eb\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud842\udcf4\uc3c3\ud9a9\udf95\u096d\ud8e5\uded2\012",
        Z.run(T, 2, 2, 12, 5, "\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\u65cb\uda80\uddbc\u00eb\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud842\udcf4'\uc3c3\ud9a9\udf95\u096d\ud8e5\uded2", "\u2680", "'",
        -2, 24370, -571020370, 246641622824736031L, 8438L, true, false, (char) 9343, (char) 34688,
        Double.longBitsToDouble(0x3fba3813c3d61638L), Double.longBitsToDouble(0x3f9b4e31ccb10180L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.lang.String:\ud931\udcca\uda95\udec0\ud9f2\udee1\uda7d\udf72\udb27\ude0b\ub9e9\uda3d\udf98\ud9a3\udda1\ud836\ude3b0\ud901\udda0\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc\0121=java.lang.String:P0Y0M698624033DT13H1M2.084S\012",
        Z.run(T, 2, 3, 6, 1, "\ud931\udcca\uda95\udec0\ud9f2\udee1\uda7d\udf72\udb27\ude0b\ub9e9\uda3d\udf98\ud9a3\udda1\ud836\ude3bM\ud901\udda0\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc", "\uaf5d\u23dc\u7ee0\u3e77\u2680\u30d3\u7666\u1da5\u1bd5", "\ud8d3\udec2\u43b0\udb6c\ude61\ud94d\udceb\ua4e4",
        21, 99201, -2116848982, 3771212860242062084L, 98404L, true, true, (char) 9104, (char) 43964,
        Double.longBitsToDouble(0x3fc8ed703d3b9a8cL), Double.longBitsToDouble(0x3fdf2bf79fa96d64L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\uda0b\udde0\ud8f2\ude0e\001\000\000\uda80\udda5\u00eb\ud9df\udf2c\ud831\udf780\udb1c\udc27\udb05\udde0\udbd7\udc27\000\000\ud79c145896634\ud8e5\uded2\uda8f\udfb6\012",
        Z.run(T, 2, 10, 4, 6, "\uda0b\udde0\ud8f2\ude0e\001\000\000\uda80\udda5\u00eb\ud9df\udf2c\ud831\udf78M\udb1c\udc27\udb05\udde0\udbd7\udc27\000\000\ud79cm\ud8e5\uded2\uda8f\udfb6", "\000", "",
        -5, 11144, -2142501327, 1118933633752009137L, 13154L, false, false, (char) 27292, (char) 45613,
        Double.longBitsToDouble(0x3feecb0ca2f81641L), Double.longBitsToDouble(0x3fdef62bb3e0a4f6L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.DurationFormatUtils:@?\0121=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\ud957\udc28\udb8e\udc7e\u00eb\ud49a\ud824\udef9\ud95e\udcce\ud9ab\ude00\udbfa\udfa2\ud842\udcf4\uc3c3\012",
        Z.run(T, 2, 10, 12, 5, "\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\ud957\udc28\udb8e\udc7e\u00eb\ud49a\ud824\udef9\ud95e\udcce\ud9ab\ude00\udbfa\udfa2\ud842\udcf4'\uc3c3", "\ua04b\uc2e5", "\000\ud876\udcea'\uda2f\udfcd",
        15, 58758, 57425728, -3797847449476091976L, -89275L, false, false, (char) 23105, (char) 40032,
        Double.longBitsToDouble(0x3fe19440612078feL), Double.longBitsToDouble(0x3fe4bfc8578efe64L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\udaa0\udf2e\ud8b5\ude05\002\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud842\udcf4\uc3c3\ud9a9\udf95\uda80\udf6e\udbfa\uddd9\udb19\udebb\ud9ad\ude14\ud8ad\udcc6\000\ud864\uddea\udba9\udfca\uda62\ude2a\ud9f8\uddac\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\udaa0\udf2e\ud8b5\ude05\002\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud842\udcf4, \uc3c3\ud9a9\udf95\uda80\udf6e\udbfa\uddd9\udb19\udebb\ud9ad\ude14\ud8ad\udcc6\000\ud864\uddea, \udba9\udfca\uda62\ude2a\ud9f8\uddac]]\012",
        Z.run(T, 2, 4, 9, 5, "\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\udaa0\udf2e\ud8b5\ude05\002\ud49a\udaee\udcdd\udb2c\udf79\ud9ab\ude00\udbfa\udfa2\ud842\udcf4'\uc3c3\ud9a9\udf95\uda80\udf6e\udbfa\uddd9\udb19\udebb\ud9ad\ude14\ud8ad\udcc6\000\ud864\uddea'\udba9\udfca\uda62\ude2a\ud9f8\uddac", "\ub6f3\u9289\u9e8e\u02a7\u588c\u17d9\u7526\u7df0\u989b\ua6cf\u6cd5\ucea3\u2c88\u2da4\u8e43\u8119\u234f\ube16\u9044", "\uda83\udf7e\u7abb\udb52\udd1d\ud86f\udfb7",
        44, 32728, 605591671, 6139901861656491583L, 93782L, false, true, (char) 35652, (char) 54908,
        Double.longBitsToDouble(0x3fe4cf6570b09ff9L), Double.longBitsToDouble(0x3fcad2a7c795b04cL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=java.lang.String:\ud931\udcca\udb96\udc88\udba6\udea8\udac8\udd1e\udb27\ude0b\ub9e9\uda3d\udf98\ud9a3\udda1\ud8b7\udd5b0\ud901\udda0\udbd0\ude61\ud9ca\udeb5\u376f\0121=java.lang.String:\ud931\udcca\udb96\udc88\udba6\udea8\udac8\udd1e\udb27\ude0b\ub9e9\uda3d\udf98\ud9a3\udda1\ud8b7\udd5b0\ud901\udda0\udbd0\ude61\ud9ca\udeb5\u376f\012",
        Z.run(T, 2, 3, 4, 1, "\ud931\udcca\udb96\udc88\udba6\udea8\udac8\udd1e\udb27\ude0b\ub9e9\uda3d\udf98\ud9a3\udda1\ud8b7\udd5bM\ud901\udda0\udbd0\ude61\ud9ca\udeb5\u376f", "\uaf5d\u23dc\u7ee0\u3e77\u2680\u30d3\u7666\u1da5\u1bd5\u6164\u101c\u6f4d\u5615\u26d7\u36b9\u6fb3", "\ud9bc\udf3a\uda2f\udd33\udbd5\udd11\ud96b\udfd1\ud9ff\udc7c\udb8c\udd1b",
        54, 3326, -425461591, -4649580352901071374L, 33675L, true, true, (char) 65525, (char) 36760,
        Double.longBitsToDouble(0x3fe93a795d034db7L), Double.longBitsToDouble(0x3fecd1ceddb8ae34L)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.lang.String:-1254649777:-20:-12.40\0121=java.lang.String:\ud931\udcca\uda95\udec0\ud9ea\udf7a\ud8f8\uddd5\udb27\ude0b\ub9e9\uda3d\udf98\ud980\udcf0\ud836\ude3b-1442145274\ud879\udcdc\udbea\udc5a\ud9ca\udeb5\uda31\udd5b\012",
        Z.run(T, 2, 5, 2, 3, "\ud931\udcca\uda95\udec0\ud9ea\udf7a\ud8f8\uddd5\udb27\ude0b\ub9e9\uda3d\udf98\ud980\udcf0\ud836\ude3bM\ud879\udcdc\udbea\udc5a\ud9ca\udeb5\uda31\udd5b", "\u5ee6\u3db2\u5e4a\ua84e\u2680\u30d3\u7666\u1da5\u1bd5\u2c21\uba05\u6f4d\u7835\ua976\u36b9\u07f1\ub72f\ub7af\uc2c9\ubf50", "\ud831\udfc0\udbba\udf94\ud929\ude78\ud94f\udcd4",
        -4, 53214, 1006864459, -3792677894270412460L, 39394L, true, true, (char) 16815, (char) 45496,
        Double.longBitsToDouble(0x3fe9518da894c016L), Double.longBitsToDouble(0x3fd063092747d428L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.lang.String:\ud944\ude14\udb88\udf9b\ud941\udeef\ud829\udd08\udb2f\ude4c\uda8b\udc85\uda41\udd61\ud97b\udca1\ud836\ude3b-1204072974\ud9f4\udfba\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc\ud976\udc32\0121=java.lang.String:\ud944\ude14\udb88\udf9b\ud941\udeef\ud829\udd08\udb2f\ude4c\uda8b\udc85\uda41\udd61\ud97b\udca1\ud836\ude3b-1204072974\ud9f4\udfba\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc\ud976\udc32\012",
        Z.run(T, 2, 1, 12, 11, "\ud944\ude14\udb88\udf9b\ud941\udeef\ud829\udd08\udb2f\ude4c\uda8b\udc85\uda41\udd61\ud97b\udca1\ud836\ude3bM\ud9f4\udfba\udbd0\ude61\ud9ca\udeb5\udb2b\udcbc\ud976\udc32", "\u23dc\u7ee0", "\ud98d\udc69\udb6c\udce4\u8879\udbff\udc95",
        17, 1301, 723121208, -3166595380939080162L, -32654L, false, false, (char) 4811, (char) 49591,
        Double.longBitsToDouble(0x3fe0f40adb043456L), Double.longBitsToDouble(0x3fc6136383f2b578L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\ud957\udc28\udb8e\udc7e\u00eb\ube60\ud824\udef9\ud95e\udcad\udb92\ude01\ud96c\udd1a\ud818\udebe\uc3c3\0121=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\ud957\udc28\udb8e\udc7e\u00eb\ube60\ud824\udef9\ud95e\udcad\udb92\ude01\ud96c\udd1a\ud818\udebe\uc3c3\012",
        Z.run(T, 2, 4, 12, 5, "\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\ud957\udc28\udb8e\udc7e\u00eb\ube60\ud824\udef9\ud95e\udcad\udb92\ude01\ud96c\udd1a\ud818\udebe'\uc3c3", "\ua04b\uc2e5", "\000\ud876\udcea\udb3b\udde4\ud801\udd8a",
        15, 58758, 57425728, -3797847449476091976L, -89275L, false, false, (char) 23105, (char) 40032,
        Double.longBitsToDouble(0x3fe19440612078feL), Double.longBitsToDouble(0x3fe4bfc8578efe64L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\udaa0\udf2e\ud8b5\ude05\ud9b4\udddc\ud49a\udaee\udcdd\ud8b3\udf66\ud9bc\udd00\udbfa\udfa2\ud85c\uddf5\uc3c3\ud9a9\udf95\uda80\udf6e\udbfa\uddd9\udafb\uddbb\ud9ad\ude14\ud8ad\udcc6\000\ud864\uddea\udb0c\ude8d\udae6\udd00\ud85c\udcd7\ud97d\uddae\ud8b0\ude63\ud8c4\udc49\ud8d3\udd4b\u0203\uda72\udd86\ud86e\udf2e\udbb9\udc3c\uda79\udd2c\uda87\udd15\ud94d\udd09\udb97\udfab\u66a6\udafb\udea4\udaa7\udddf\ud91d\udda9\udb55\ude66\uda7b\udda4\uda97\ude01\ud9a4\udd01\ud81a\udf22\ud892\udf22\udafe\uddaf\0121=java.lang.String:\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\udaa0\udf2e\ud8b5\ude05\ud9b4\udddc\ud49a\udaee\udcdd\ud8b3\udf66\ud9bc\udd00\udbfa\udfa2\ud85c\uddf5\uc3c3\ud9a9\udf95\uda80\udf6e\udbfa\uddd9\udafb\uddbb\ud9ad\ude14\ud8ad\udcc6\000\ud864\uddea\udb0c\ude8d\udae6\udd00\ud85c\udcd7\ud97d\uddae\ud8b0\ude63\ud8c4\udc49\ud8d3\udd4b\u0203\uda72\udd86\ud86e\udf2e\udbb9\udc3c\uda79\udd2c\uda87\udd15\ud94d\udd09\udb97\udfab\u66a6\udafb\udea4\udaa7\udddf\ud91d\udda9\udb55\ude66\uda7b\udda4\uda97\ude01\ud9a4\udd01\ud81a\udf22\ud892\udf22\udafe\uddaf\012",
        Z.run(T, 2, 2, 1, 7, "\udae4\udcdc\ud8d3\ude85\u8901\ud94c\udf3a\udaa0\udf2e\ud8b5\ude05\ud9b4\udddc\ud49a\udaee\udcdd\ud8b3\udf66\ud9bc\udd00\udbfa\udfa2\ud85c\uddf5'\uc3c3\ud9a9\udf95\uda80\udf6e\udbfa\uddd9\udafb\uddbb\ud9ad\ude14\ud8ad\udcc6\000\ud864\uddea\udb0c\ude8d\udae6\udd00\ud85c\udcd7\ud97d\uddae\ud8b0\ude63\ud8c4\udc49\ud8d3\udd4b\u0203\uda72\udd86\ud86e\udf2e\udbb9\udc3c\uda79\udd2c\uda87\udd15\ud94d\udd09\udb97\udfab\u66a6\udafb\udea4\udaa7\udddf\ud91d\udda9\udb55\ude66\uda7b\udda4\uda97\ude01\ud9a4\udd01\ud81a\udf22\ud892\udf22\udafe\uddaf", "\u3eb5\u21bb\uad7b\u51bf\u089b\u3238\u3d45", "\udabb\udca6\ud9ed\udcef\ud810\udc49\uda2a\udfbf\ud906\udcf0\ud982\ude65\udb13\udd40\uda94\udc5d\udb35\udfde\udb28\udd3c\uda6e\uddbe\ud8a8\ude00\ud87f\ude3c\ud9ea\ude60\udbc3\udd91\udb9c\ude3f\ud887\udfde\ud8f9\uddc3\uda82\udf23\ud883\udff9\uda18\udf5d\ud9df\ude62\u1539\uda43\udcec\udbb0\udd9c\udb56\udc2c\udb7d\udf22\udbe5\ude31\ud95f\ude59",
        9, 91565, 919078726, -3399984794531531546L, -54546L, true, false, (char) 2716, (char) 45097,
        Double.longBitsToDouble(0x3fe863adfbb5b88dL), Double.longBitsToDouble(0x3fdf55f50361a6c2L)));
  }
  @Test(timeout = 4000)
  public void test100() throws Throwable {
    assertEquals("0=java.lang.String:\ud917\ude1d\ud91d\udf00\ud903\udd65\ud94c\udf9d\udaa0\udf2e\ud8b5\ude05\ud9b4\udddc\ud49a\ud911\udc50\ud8c6\udf04\ud9d3\udc6b\udbfa\udf61\ud85c\uddf5\uc3c3\ud9a9\udf95\uda80\udf6e\udbfa\uddd9\udafb\uddbb\ud9ad\ude14\ud8c7\udfc6\000\ud864\uddea\udb0c\ude8d\uda6b\udd02\ud85c\udcf8\ud97d\uddae\ud8b0\ude63\ud8c4\udc49\ud8d3\udd4b\u0203\ud8cd\udece\ud86e\udf2e\udbb9\udc3c\uda79\udd2c\uda87\udd15\ud94d\udd09\udb97\udfab\u66a6\udafb\udea4\udaa7\udddf\ud91d\udda9\udb55\ude66\uda7b\udda4\ud8f0\ude7e\ud8c3\udda5\u4b1f\ud892\udf22\udafe\uddaf\0121=java.lang.String:-2074261195 days -3 hours -48 minutes -26 seconds\012",
        Z.run(T, 2, 12, 7, 4, "\ud917\ude1d\ud91d\udf00\ud903\udd65\ud94c\udf9d\udaa0\udf2e\ud8b5\ude05\ud9b4\udddc\ud49a\ud911\udc50\ud8c6\udf04\ud9d3\udc6b\udbfa\udf61\ud85c\uddf5'\uc3c3\ud9a9\udf95\uda80\udf6e\udbfa\uddd9\udafb\uddbb\ud9ad\ude14\ud8c7\udfc6\000\ud864\uddea\udb0c\ude8d\uda6b\udd02\ud85c\udcf8\ud97d\uddae\ud8b0\ude63\ud8c4\udc49\ud8d3\udd4b\u0203\ud8cd\udece\ud86e\udf2e\udbb9\udc3c\uda79\udd2c\uda87\udd15\ud94d\udd09\udb97\udfab\u66a6\udafb\udea4\udaa7\udddf\ud91d\udda9\udb55\ude66\uda7b\udda4\ud8f0\ude7e\ud8c3\udda5\u4b1f\ud892\udf22\udafe\uddaf", "\u3eb5\u21bb\uad7b\u51bf\u089b\u3238\u3d45", "\udabf\udc69\ud9ed\udcef\ud810\udc49\uda2a\udfbf\ud906\udcf0\udb0d\udca9\udb13\udd40\uda94\udc5d\udb35\udfde\udb28\udd3c\uda6e\uddbe\ud8a8\ude00\ud87f\ude3c\ud9ea\ude60\udbc3\udd91\udb9c\ude3f\ud887\udfde\udb6e\udff1\uda82\udf23\ud883\udff9\uda18\udf5d\ud859\ude5f\u1539\uda43\udcec\udbb0\udd9c\udb56\udc2c\udb7d\udf22\udbe5\ude31\ud95f\ude59",
        9, 91565, 919091700, -6858749306000906592L, 76852L, true, false, (char) 51403, (char) 60482,
        Double.longBitsToDouble(0x3fdf55f50361a6c2L), Double.longBitsToDouble(0x3fe2e8a24bbe1a30L)));
  }
  @Test(timeout = 4000)
  public void test101() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 9, 4, "\ud9cf\udc68\udb66\ude28\ud8a0\udd27\ud9bd\ude8f\ud84e\udd03\uda80\udda5\ud89d\ude92\ud851\udcda\u7897\u1bdb\ud983\ude1f\udbd0\ude61\ud997\udf14\ud9ec\udf45\ud953\udef8\u0196\udbf3\ude67\ud97d\udc84\udae0\udc42\ud99f\udffe\ud866\ude82\udb6e\uddb3\ud843\udfdd\ud941\uddd8\udb07\udd7d\udb0b\ude50\u2b27\ud82d\udcbf\u4406\ud9f1\udca3\udaa4\udeb7\ud825\udc2c\ud98f\udd59\udb73\udc6a\ud972\udee7\ud987\udc82\ud854\ude26\udbb5\udf58\udab7\udfad\ud828\udce9\uda2c\udc48\uda4f\udc40\ud8c5\udf0e\uda9c\udf57\u2ad8\uda6b\udfe9\ud9fe\udc50\ud92d\udf76\ud9e2\udf89\udb66\ude1d\ud936\ude5f\u308d\ud92d\udcc5\ud83f\udec7\udb60\udd15\ud85e\udcc7\ud9dc\udf35\uaf7c", "\u5306\u4b3a\u13c8\u0b8b\u1705\u83a2\ub8db\u64d7\u5d36\u78da\u69f7\ud55f\uc5a1\u6761\u6005\u8345\u90ec\u54cb\ud7c4\u2dbe\u3c1d\u2630\u54ef\ucf42\uacab\u9825\u6a8c\u3c79\u63e3\u881d\uc3df\u693e\u55eb\ua478\u0a71\u4d14\u1a0c\u3bfb\u6777\u04d6\u8cd2\u2ac2\u01c7\u8173\uca63\u2437\u590b\u8730\u19ea\u16a5\ua238\u3f06\ub363\uc962\u8cc6\ub3cc\u3820\u8f14\u1c57\u7e59\ud3eb", "\ud8b5\udd30\ueaa4\uda25\udf14\ud96e\udedc\udbf1\udce9\udb22\udd42\ud989\ude14\uda37\ude33\uda86\udf69\uda28\udd4c\ud968\udcb1\udbb1\udfed",
        28, 73451, -1963738924, 4599031305041701556L, 44768L, false, true, (char) 14514, (char) 58959,
        Double.longBitsToDouble(0x3fe3d547c2db618cL), Double.longBitsToDouble(0x3fd8d0a0ec382966L)));
  }
  @Test(timeout = 4000)
  public void test102() throws Throwable {
    assertEquals("0=java.lang.String:P0Y0M1480879252DT4H29M12.220S\0121=[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;:[[\udaa0\ude6e\ud8ab\udd4c\u3ccd\000\000\udbfe\udf846\ud9df\udf2c\ud831\udf78, M, \uda6b\udfc5\udb05\ude02\udbd7\udc27\000\uc4c5\ud79c, m, \ud8e5\uded2\uda8f\udfb6\000\ud8ad\udcc6\000]]\012",
        Z.run(T, 2, 6, 9, 2, "\udaa0\ude6e\ud8ab\udd4c\u3ccd\000\000\udbfe\udf846\ud9df\udf2c\ud831\udf78M\uda6b\udfc5\udb05\ude02\udbd7\udc27\000\uc4c5\ud79cm\ud8e5\uded2\uda8f\udfb6\000\ud8ad\udcc6\000", "\u3284", "\ud8e6\udd20",
        19, 17858, -452085246, 1612288664886552220L, -6855L, false, false, (char) 14738, (char) 29732,
        Double.longBitsToDouble(0x3fd65eb2eda8f204L), Double.longBitsToDouble(0x3fd20f1aac740318L)));
  }
  @Test(timeout = 4000)
  public void test103() throws Throwable {
    assertEquals("0=java.lang.String:\ud9e8\udef5\ud890\udfde\ud89a\ude8d\uda68\ude7a\ud84e\udd03\ud985\udea9\ud89d\ude92\ud813\udd86\ud879\udf57\ub189\udb71\udfc4\udbf7\udff4\ud9ca\udeb5\ud82d\udf7e\ud993\udfdd\ud9a8\udef4\udbf3\ude67\udac9\udc4b\udacd\uddb5\ud9ad\ude0c\udb1a\udcbd\udb69\udf97\ud9ad\uddb3\u6477\ud9ed\uddcb\udb0b\ude98\ud6f9\ud8cd\udc46\udaef\udcb9\ud8a2\udf61\udb8d\ude85\ud994\uddcb\u46d2\ud9d1\ude05\udba9\udc43\ud926\udfef\ud9a9\udf02\ud9b7\ude2c\ud99b\uddf6\udb81\udf3a\ud9a0\udc82\u141c\ud80e\udcae\ud89d\udfe0\ud87e\udced\udb17\udf6c\udb27\udc38\udb7d\udfeb\uda23\udf36\udaab\udcfc\ud963\udd8b\u0503\udb06\udd4b\ud9b2\udfb6\ud99a\udd5b\ud967\udd5d\udb1b\udddb\ud9d1\udcd1\ud84a\udcba\uda2f\udc97\ud922\udee9\ud8fb\udcd5\ud946\ude38\ud97e\udc7e\ud9e6\udcc6\ud94c\udd4b\udabf\udffd\ud92c\ude06\ud9d7\udeae\ud9b7\ude62\udbe7\udc5e\ud861\ude95\ud9c5\udd05\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 4, "\ud9e8\udef5\ud890\udfde\ud89a\ude8d\uda68\ude7a\ud84e\udd03\ud985\udea9\ud89d\ude92\ud813\udd86\ud879\udf57\ub189\udb71\udfc4\udbf7\udff4\ud9ca\udeb5\ud82d\udf7e\ud993\udfdd\ud9a8\udef4\udbf3\ude67\udac9\udc4b\udacd\uddb5\ud9ad\ude0c\udb1a\udcbd\udb69\udf97\ud9ad\uddb3\u6477\ud9ed\uddcb\udb0b\ude98\ud6f9\ud8cd\udc46\udaef\udcb9\ud8a2\udf61\udb8d\ude85\ud994\uddcb\u46d2\ud9d1\ude05\udba9\udc43\ud926\udfef\ud9a9\udf02\ud9b7\ude2c\ud99b\uddf6\udb81\udf3a\ud9a0\udc82\u141c\ud80e\udcae\ud89d\udfe0\ud87e\udced\udb17\udf6c\udb27\udc38\udb7d\udfeb\uda23\udf36\udaab\udcfc\ud963\udd8b\u0503\udb06\udd4b\ud9b2\udfb6\ud99a\udd5b\ud967\udd5d\udb1b\udddb\ud9d1\udcd1\ud84a\udcba\uda2f\udc97\ud922\udee9\ud8fb\udcd5\ud946\ude38\ud97e\udc7e\ud9e6\udcc6\ud94c\udd4b\udabf\udffd\ud92c\ude06\ud9d7\udeae\ud9b7\ude62\udbe7\udc5e\ud861\ude95\ud9c5\udd05", "\u0344\uc9dc\uafe0\ud029\u8e2a\u3754\u3796\u5d81", "\ud8a7\udc09\ud9cc\udc52\u2475\ud905\udd5c\ud95a\udc6b\udacb\udc1a\udab4\ude86\udbbd\ude5f\udb75\udd0a\udba1\ude2d\ud82a\udc1c\ud9e5\udd24\uda0d\udf81\ud963\uddda\ud8bd\udcd3\ud8e2\udd66\ud81d\udde5\ud901\udce1\ud9ac\udc1e\uda60\udfcf\udb64\udf07\u3fb0\ud9bc\udeb6\udaad\udc31\ud88f\udf38\udb64\udf53\udbe3\udfc6\udaed\udcce\udad1\udd81\ud895\udde9\ud8b7\udfb2\ud8e5\udfb8\udbea\ude57\uda38\udcc2\ud851\udd2c\ud8ba\udca8\udb65\udfaf\uf275\udb32\udc06\udb98\ude29\u42a0\udb34\udf23\uda27\udfd1\udbe2\ude89\ud890\ude23\udaaf\udf84\ud92d\udce7\uda1a\udd78\udb70\udf15\udad9\udc83\udbc7\udc9f\ud8fc\udc11\udb6d\udc60\udab9\ude95\ud892\udfce\uda30\ude9d\ud8df\udfcd\udb76\udc4c\u6f07\ud98d\ude01\ud8a0\udd71\udb17\udcb5\ud9c6\udc0e\udabf\udc1b\udad5\udf3b\uda33\udf49\ud8ca\udca4\udadd\udcdb",
        2, 70314, 189948973, 5529250916468733113L, -22703L, true, false, (char) 38262, (char) 46542,
        Double.longBitsToDouble(0x3fea956d26a00455L), Double.longBitsToDouble(0x3fd6c2c2d33df1fcL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.time.DurationFormatUtils|format|[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;,int,int,int,int,int,int,int,boolean|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriod|long,long,java.lang.String|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriod|long,long,java.lang.String,boolean,java.util.TimeZone|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDuration|long,java.lang.String|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDuration|long,java.lang.String,boolean|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDurationHMS|long|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDurationISO|long|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatDurationWords|long,boolean,boolean|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriodISO|long,long|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|lexx|java.lang.String|static",
    "C|org.apache.commons.lang.time.DurationFormatUtils|<init>|",
    "M|org.apache.commons.lang.time.DurationFormatUtils|format|[Lorg.apache.commons.lang.time.DurationFormatUtils$Token;,int,int,int,int,int,int,int,boolean|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriod|long,long,java.lang.String|static",
    "M|org.apache.commons.lang.time.DurationFormatUtils|formatPeriod|long,long,java.lang.String,boolean,java.util.TimeZone|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
