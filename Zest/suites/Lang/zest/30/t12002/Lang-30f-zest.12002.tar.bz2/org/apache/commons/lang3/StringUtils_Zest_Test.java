package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\udb7f\udd4f\ud93c\udd36\ua645\ud97c\ude41\udace\ude55\ud8a0\ude76\udb9f\ude7e\uda7c\udfb6\uda88\udcaa\uda8e\udd63\uda91\udc68\udb36\udd02");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb7f\udd4f\ud93c\udd36\ua645\ud97c\ude41\udace\ude55\ud8a0\ude76\udb9f\ude7e\uda7c\udfb6\uda88\udcaa\uda8e\udd63\uda91\udc68\udb36\udd02", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\udb00\udc55\udbdd\udf08\uda37\udec4\ud97c\ude41\udace\ude55");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb00\udc55\udbdd\udf08\uda37\udec4\ud97c\ude41\udace\ude55", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\ud911\udd8e\ud93c\udd36\ua645");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud911\udd8e\ud93c\udd36\ua645", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udaab\udfc4\udab6\udd37\ua645\ud95c\udc10\ud890\udc11\udbe4\ude38\udba1\udf0d\udad4\udf41\udbd0\ude2a\udab9\udfed");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaab\udfc4\udab6\udd37\ua645\ud95c\udc10\ud890\udc11\udbe4\ude38\udba1\udf0d\udad4\udf41\udbd0\ude2a\udab9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\ud8cb\udcc0\ud8cc\uddc6\uda3d\udfa4\ud97c\ude41\u5259\ud9cd\udfed\ud955\ude8c\uda8e\udcb6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\udbc0\udc62\ud953\udcaa\udb01\udcf0\ud97c\ude41\udbf4\udf47\ud96c\uddfc\ud976\ude72\ud815\udc02\ud921\ude78\udb82\ude32\ud8ed\udd2d\ud8f1\udef8\udacf\udce7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbc0\udc62\ud953\udcaa\udb01\udcf0\ud97c\ude41\udbf4\udf47\ud96c\uddfc\ud976\ude72\ud815\udc02\ud921\ude78\udb82\ude32\ud8ed\udd2d\ud8f1\udef8\udacf\udce7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ud9b9\udc8f\ud9a3\ude1a\uda2d\udddd\ud99b\ude1d\ud910\udee5\ud808\ude01\udb9f\ude57\uda7c\udfb6\uda88\udcaa\ud997\udda9\ud8ef\udf11\ud8db\udfd6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\ud84b\ude54\ud93c\uddef\uda29\udc55\ud975\udca5\udb6d\udf14\ud8a0\ude76\udb9f\ude7e\uda7c\udfb6\udb93\udf9d\uda8e\udd63\uda91\udc68\udb36\udd02");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\udb7f\udd4f\ud93c\udd36\udb09\ude3b\ud97c\ude41\uda47\udeba\ud894\uddeb\udb9f\ude7e\uda7c\udfb6\uda88\udcaa\uda8e\udd63\uda91\udc68\udb36\udd02\udb28\ude45\ud92c\udf1a\ud8fa\udcec\ud834\ude32");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb4f\udc16\udb88\ude49\ud86b\udd7a\udacb\udc97\udbef\udd81\ud883\uddd0\udb9f\ude7e\udbbe\udeb8\udab8\udd61\udb55\udd6d\ud8bd\udc0a\ud850\udd4e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u4800");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ud8e3\ude41\udb63\udec7\ua60f\ud97c\ude41\ud950\udd95\ud8a0\udec1\ud999\uddbc\udac5\ude45\udbf4\ude1a\udbcf\udeb2\uda91\udc68\ud88f\udc4d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ud91f\udc88\ud87a\ude68\uda6b\uddec\udbab\uddd9\ud896\uddd8\ud8a0\ude76\uda2d\ude06\udaa5\uddba\uc426");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\udb0e\udc3c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\uc1ee\ud93c\uddd5\ua645\ud97c\ude41\udace\ude55\ud8a0\ude76\u260d\uda7c\udfb6\uda7b\udca5\udafe\udcc8\udb8b\udea5\udb36\udd02\udbfa\udd32\udb94\ude73");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\udb02\udcbf\udbf7\ude9d\ud8af\udd4f\ud8c7\udfc2\ud8ee\udd9b\ud9d3\udf1f\udb82\udd19\ud8e9\udeae\ud819\udcb4\u0233\udb7a\udeca\udb57\ude4b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb02\udcbf\udbf7\ude9d\ud8af\udd4f\ud8c7\udfc2\ud8ee\udd9b\ud9d3\udf1f\udb82\udd19\ud8e9\udeae\ud819\udcb4\u0233\udb7a\udeca\udb57\ude4b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\udb7f\udd4f\ud93c\udd36\ua645\udaf5\ude41\udace\ude55\ud8a0\ude76\udab9\uddab\uda6f\udffd\ud907\udc01\udb60\udd1d\uda91\udcf4\udae3\udeca\udbd6\udebf\ud927\udf8d\udbbf\udcc2\u18ce\uda7e\udf1c\ud974\udcc6\u1fda\udb65\udc31\ud969\ude18\ud94e\udc51\ud983\udd65\uda97\udc3c\ud9c5\uddcf\ud813\udf96\ud81b\udc1f\udba7\udcb7\udb7b\udf87\uda8d\uddcc\ud8e3\udcdb\ud8c5\udcc3\udad6\udead\ud935\udcb1\u6d5b\udb41\udeca\ud87b\udf5d\uda02\udcfe\udb93\udcf4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb7f\udd4f\ud93c\udd36\ua645\udaf5\ude41\udace\ude55\ud8a0\ude76\udab9\uddab\uda6f\udffd\ud907\udc01\udb60\udd1d\uda91\udcf4\udae3\udeca\udbd6\udebf\ud927\udf8d\udbbf\udcc2\u18ce\uda7e\udf1c\ud974\udcc6\u1fda\udb65\udc31\ud969\ude18\ud94e\udc51\ud983\udd65\uda97\udc3c\ud9c5\uddcf\ud813\udf96\ud81b\udc1f\udba7\udcb7\udb7b\udf87\uda8d\uddcc\ud8e3\udcdb\ud8c5\udcc3\udad6\udead\ud935\udcb1\u6d5b\udb41\udeca\ud87b\udf5d\uda02\udcfe\udb93\udcf4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud989\ude4d\ud93c\udd36\ua645\ud97c\ude41\ud9e5\udfbc\ud9a9\udc3b\udb2d\udf13");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud989\ude4d\ud93c\udd36\ua645\ud97c\ude41\ud9e5\udfbc\ud9a9\udc3b\udb2d\udf13", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u7526\ud918\udf7b\udbb3\ude43\ud9d1\udcab\ud828\udc8a\udbd9\udd8e\udb9f\ude7e\uda7c\udffb\uda13\ude57\uda28\udd66\uda8e\udc53\udb47\udc3a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7526\ud918\udf7b\udbb3\ude43\ud9d1\udcab\ud828\udc8a\udbd9\udd8e\udb9f\ude7e\uda7c\udffb\uda13\ude57\uda28\udd66\uda8e\udc53\udb47\udc3a", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb7f\udd4f\ud93c\udd36\ua645\ud97c\ude41\udace\ude55\ud8a0\ude76\udb9f\ude7e\uda7c\udfb6\uda88\udcaa\uda8e\udd63\uda91\udc68\udb36\udd02\uda2c\udcc1\udadf\udf34\udad4\uddde\udbfa\udcfa\ud8ef\udfdc\udb42\udd62\udbb2\udc41\ud9ba\ude7c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb7f\udd4f\ud93c\udd36\ua645\ud97c\ude41\udace\ude55\ud8a0\ude76\udb9f\ude7e\uda7c\udfb6\uda88\udcaa\uda8e\udd63\uda91\udc68\udb36\udd02\uda2c\udcc1\udadf\udf34\udad4\uddde\udbfa\udcfa\ud8ef\udfdc\udb42\udd62\udbb2\udc41\ud9ba\ude7c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb7a\ude4f\ud93c\udd36");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb7a\ude4f\ud93c\udd36", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u5335");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udaf8\uddbb");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaf8\uddbb", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u2c03\udb3b\udcd1\udb59\udd87\ud8e5\udcd0\uda00\udde6\ud96a\uded9\udbd6\udfac\ud807\ude1f\udb44\udcc9\ud948\udc38\uda2a\udd61\ud0d0\udbea\uded1\u520d\udb21\ude99\uda9b\udfe7\ud856\udca6\ud865\udd1f\udb6d\uddcd\ud873\udf64");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u4605");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u4605", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udaa2\udc46\udbdd\udfbd\ud872\ude58\ud97c\udf33\udace\ude55\uda5e\udc64\udba9\udf66\uda14\ude7f\ud89e\udf1a\udb9f\udd6f\ud9e2\udfb8\ud861\udd6a\udabc\udca2\uda41\udf18\u33a4\ud95f\ude00\ud845\udc3f\uda4f\udd16\ud8b8\uddd6\udad3\udc54\ud8dc\udea2\ud93c\ude09\ud87c\udc3b\ucbd8\udada\udf29\ud813\udcd1\ud919\udee6\ud9a4\udf38\udb4a\ude10\ud871\udc31\udb66\udd61\udb55\udf2b\udaf8\udf9c\ud8cd\udd12\udb04\udc85\u4c2d\u21da");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaa2\udc46\udbdd\udfbd\ud872\ude58\ud97c\udf33\udace\ude55\uda5e\udc64\udba9\udf66\uda14\ude7f\ud89e\udf1a\udb9f\udd6f\ud9e2\udfb8\ud861\udd6a\udabc\udca2\uda41\udf18\u33a4\ud95f\ude00\ud845\udc3f\uda4f\udd16\ud8b8\uddd6\udad3\udc54\ud8dc\udea2\ud93c\ude09\ud87c\udc3b\ucbd8\udada\udf29\ud813\udcd1\ud919\udee6\ud9a4\udf38\udb4a\ude10\ud871\udc31\udb66\udd61\udb55\udf2b\udaf8\udf9c\ud8cd\udd12\udb04\udc85\u4c2d\u21da", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u85ca\udae3\udd17\ud900\udd6e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u7f43\ud9d9\udc06\uda3d\udfa4\ud97c\ude41\u5259\ud9cd\udfed\ud955\ude8c\uda8e\udcb6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ubf8b\u45fd\ud851\uddca\udbc9\udfcd\ud9a7\udcd9\udb60\udd28\udbf2\udea2\udae8\udec1\ud9fe\udf21");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud84b\ude79\ud93c\uddef\u1680\uda96\ude8a\udb6d\udf14\ud8a0\ude76\udb9f\ude7e\uda7c\udfb6\udb93\udf9d\uda8e\udd63\uda91\udc68\udb36\udcdc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud84b\ude79\ud93c\uddef\uda96\ude8a\udb6d\udf14\ud8a0\ude76\udb9f\ude7e\uda7c\udfb6\udb93\udf9d\uda8e\udd63\uda91\udc68\udb36\udcdc", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u0405");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u1d09\u5a3b\ud922\uddaf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u121b\u1f4a\udb40\ude0f\ud99e\udcb7\ud826\udff3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\ud9cf\udcd5\ud976\udd27\ud89e\udcc2\ud8c7\udfc2\ud8ee\udd9b\ud9d3\udf1f\udb82\udd19\ud8e9\udeae\ud819\udcb4\u0233\udb7a\udeca\udb57\ude4b\uda73\udf78\uda62\ude49\ud9f6\udd39\ud9cc\ude8b\udb9a\udd44\u8527\ud86b\udd8e\ud863\udc9f\ud92e\ude92\udae0\udcab\u28df\udabe\udd75\udad4\udc77\udacd\udf00\ud8b0\udd65\udbe4\ude08\udba3\udef5\ud88f\udf9f\ud9b9\ude02\ud8f5\udf96\ud99c\udc27\ud889\udd82\udb8a\udf6a\udbf3\udd2d\ud875\udc3e\udad9\udf36\u4317\uda13\udfeb\uda4e\udf2c\ud8fe\udd9f\ud84c\ude37\ud931\udcca\ud865\udf52\udb73\udd10\uda93\udf28\udbdb\udc3f\ud8dc\udcd3\ud956\udf08\ud8fe\uddcf\udb4b\udc1a\ud808\udc4a\udb98\udf7b\u9eb0\ud9f5\udd7f\ubcba\udb2a\udd5e\ud9e7\udf76\u6b4d\udb93\udd66\uda9b\udd8f\ud982\udcfb\ud8e8\ude9a\ud94e\udd75\ud868\udd25\ud87c\udf24\udbf4\udc73\ud871\udd62\uda60\ude2d\ud8b3\udfbb\udbbe\udd0d\ud886\udf04\ud8cc\ude01\uda58\udf05\ud9c8\udf44\ud9a5\ude19\ud93b\udc5c\uda84\uddac\ud906\udecd\u1e1b\ud9d9\ude45\ud802\udda0\udae7\udd5f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9cf\udcd5\ud976\udd27\ud89e\udcc2\ud8c7\udfc2\ud8ee\udd9b\ud9d3\udf1f\udb82\udd19\ud8e9\udeae\ud819\udcb4\u0233\udb7a\udeca\udb57\ude4b\uda73\udf78\uda62\ude49\ud9f6\udd39\ud9cc\ude8b\udb9a\udd44\u8527\ud86b\udd8e\ud863\udc9f\ud92e\ude92\udae0\udcab\u28df\udabe\udd75\udad4\udc77\udacd\udf00\ud8b0\udd65\udbe4\ude08\udba3\udef5\ud88f\udf9f\ud9b9\ude02\ud8f5\udf96\ud99c\udc27\ud889\udd82\udb8a\udf6a\udbf3\udd2d\ud875\udc3e\udad9\udf36\u4317\uda13\udfeb\uda4e\udf2c\ud8fe\udd9f\ud84c\ude37\ud931\udcca\ud865\udf52\udb73\udd10\uda93\udf28\udbdb\udc3f\ud8dc\udcd3\ud956\udf08\ud8fe\uddcf\udb4b\udc1a\ud808\udc4a\udb98\udf7b\u9eb0\ud9f5\udd7f\ubcba\udb2a\udd5e\ud9e7\udf76\u6b4d\udb93\udd66\uda9b\udd8f\ud982\udcfb\ud8e8\ude9a\ud94e\udd75\ud868\udd25\ud87c\udf24\udbf4\udc73\ud871\udd62\uda60\ude2d\ud8b3\udfbb\udbbe\udd0d\ud886\udf04\ud8cc\ude01\uda58\udf05\ud9c8\udf44\ud9a5\ude19\ud93b\udc5c\uda84\uddac\ud906\udecd\u1e1b\ud9d9\ude45\ud802\udda0\udae7\udd5f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u7937\ud171\u1d8a\ud842\udff4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u95e5\ub9c3\ud935\udd4b\udad3\ude79\udb66\udca5\uda6a\uddc4\ud877\udc49\ud887\udc6e\udbb0\ude20\udaf4\udf4c\ud99e\ude3a\ud955\udc6a\ud89b\ude7e\ud882\udd46\ud9b0\udeab\udb5a\udcd4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u0405\udbcc\uddf1\ud910\udf90\uda0e\udfa7\udb83\udea7\ud93c\udfa9\ud8f5\ude9f\udbec\udce6\ud970\ude7f\udb39\udf0d\ud82c\udfba\ud846\udc99\ud841\udd6e\ud974\ude90\u7dca\udb54\udf8f\ud84f\udcc3\ud93f\udf50\ud909\ude7c\udadc\udf7d\udbc9\udc6b\udb54\udd22\uda15\udec4\ud83e\udd25\ud8a7\uddbc\ud8e2\udc9c\uda95\udc75\ud82c\udcd1\udaa4\udc26\udbb8\udef5\ud862\udd68\ud9a2\udf8c\ud9ad\udc48\ud8d5\udd58\uda89\uddb9\uda68\udd75\uda84\ude4e\ud81d\ude43\udafb\udf5b\ud911\udf15\u75c5\udb4a\udf53\uda2c\udcc2\udb22\udc46\udb51\udc88");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u1d09\u5a3b\ud922\uddaf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\ud94d\udd55\ud93c\udd36\ua697\ud97c\ude41\udace\ude55\ud8be\ude76\udb9f\ude7e\uda7c\udfb6\uda88\udcaa\uda8e\udd63\uda91\udc68\ud817\ude71");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud94d\udd55\ud93c\udd36\ua697\ud97c\ude41\udace\ude55\ud8be\ude76\udb9f\ude7e\uda7c\udfb6\uda88\udcaa\uda8e\udd63\uda91\udc68\ud817\ude71", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u5335\u6803\u1192\uda8c\udf60\udaa9\udd0d\ud8c0\udeaa\udbfa\ude30\udaf8\ude26\uda4c\udc1d\udbb8\udc65\ud851\udc9c\ud8c0\udf2e\uda56\udedd\udbbc\uddc9\uda4c\ude19\ud829\udff0\udaca\ude73\ud9d1\udce9\ud861\udc22\udaf4\udea7\ud99e\udec0\ud952\udf9f\udb87\udc7a\ud89c\ude46\udadf\ude97\ud981\udffa");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u7937\ud171\u1d8a\u13b6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ubba1\u4ee8\uc4a4\uda06\udfa6\udbba\ude5c\udba4\ude67\udb37\udc47\u6525\udbfe\udc3f\udb85\udc60\udb8b\udea0\udb36\udd02\ud8fe\ude6e\udb6b\udcef");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda44\udd0d\udaf7\uddd8\ud836\udf9f\u0a3f\ud81e\udd18\udaa9\udc52\ud94f\uddab\ud9f7\udd0d\uda73\udc4e\ud8cb\udf11\ud9ab\udf63\ud9d2\udfdf\ud98e\udf69\ud861\udc89\udb8c\udf74\ud82e\udd96\uda00\udc20\ud9e1\ude20\udb47\udfc2\udae9\udcc5\ud825\udf1b\udab3\udcf0\ud958\udc71\udb27\udf92\ud99f\udc21\udbf9\udc1c\uda48\udd78\udb31\udf7f\ud975\udde6\ud92b\ude4d\ud879\udda4\ud8ff\udc73\ud9fe\udcb9\udb7d\udc1a\udad5\udefd\udaa5\udd2b\uda78\udc8b\ud8b3\udcdf\ud8d6\udc47\ud999\udcc7\uda6b\udf85\uda65\uddd6\ud86c\udeea\ud9e2\udddd\ud9d1\udfde\udb2d\udf39\ud8bd\udc2b\ud9b4\udf93\udbae\udd15\uda7d\udec0\udaa4\udc29\ud8ab\ude09\ud8e1\uddb1\u69f6\ud80d\ude12\ud8d9\udcc1\udaf5\ude2c\udb53\udd0d\ud8d9\udd06\ud9ed\udfc8\ud8e3\ude0d\ud93a\udd99\udbee\udfdb\udaf9\udc67\ud9d3\udc1c\udb7c\udfa7\ud88c\ude88\udb85\udf7f\udb18\udc18\u3222\udad4\udece\ud81c\udcfc\udb1c\udd09\udadc\udcdb\ud969\udc41\ud828\udfac\ud9d5\udd98\udaca\udf82\ud942\ude61\ud9c0\udd84\ud98f\udfe1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda44\udd0d\udaf7\uddd8\ud836\udf9f\u0a3f\ud81e\udd18\udaa9\udc52\ud94f\uddab\ud9f7\udd0d\uda73\udc4e\ud8cb\udf11\ud9ab\udf63\ud9d2\udfdf\ud98e\udf69\ud861\udc89\udb8c\udf74\ud82e\udd96\uda00\udc20\ud9e1\ude20\udb47\udfc2\udae9\udcc5\ud825\udf1b\udab3\udcf0\ud958\udc71\udb27\udf92\ud99f\udc21\udbf9\udc1c\uda48\udd78\udb31\udf7f\ud975\udde6\ud92b\ude4d\ud879\udda4\ud8ff\udc73\ud9fe\udcb9\udb7d\udc1a\udad5\udefd\udaa5\udd2b\uda78\udc8b\ud8b3\udcdf\ud8d6\udc47\ud999\udcc7\uda6b\udf85\uda65\uddd6\ud86c\udeea\ud9e2\udddd\ud9d1\udfde\udb2d\udf39\ud8bd\udc2b\ud9b4\udf93\udbae\udd15\uda7d\udec0\udaa4\udc29\ud8ab\ude09\ud8e1\uddb1\u69f6\ud80d\ude12\ud8d9\udcc1\udaf5\ude2c\udb53\udd0d\ud8d9\udd06\ud9ed\udfc8\ud8e3\ude0d\ud93a\udd99\udbee\udfdb\udaf9\udc67\ud9d3\udc1c\udb7c\udfa7\ud88c\ude88\udb85\udf7f\udb18\udc18\u3222\udad4\udece\ud81c\udcfc\udb1c\udd09\udadc\udcdb\ud969\udc41\ud828\udfac\ud9d5\udd98\udaca\udf82\ud942\ude61\ud9c0\udd84\ud98f\udfe1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u7937\ud171\u1d8a\u13b6\udae0\udfdc\ud83a\udcd2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u5335\u6803\u1192\uda8c\udf60\uda9d\ude16\ud8c0\udeaa\udbfa\ude30\udaf8\ude26\uda4c\udc1d\udbb8\udc65\ud851\udc9c\ud8c0\ude48\uda56\udedd\udbbc\uddc9\uda4c\udeaf\ud829\udff0\udaca\ude73\ud9d1\udce9\ud861\udc22\udaf4\udea7\ud99e\udec0\ud952\udf9f\udb87\udc7a\ud89c\ude46\udadf\ude97\ud981\udffa");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u7937\ud171\u1d8a\u13b6\udab3\udfa4\udb63\udfe9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u5335\u6803\u1192\u2c21\uda9d\ude16\ud990\udc12\ud97d\ude76\udaf8\ude26\uda4c\udc1d\ud933\udcc2\ud982\ude08\ud8c0\udefe\uda56\udedd\ud889\uddd0\uda4c\udeaf\ud829\udff0\udaca\ude73\ud9d1\udce9\ud861\udc22\udaf4\udea7\ud99e\udec0\ud952\udf9f\udb87\udc7a\ud89c\ude46\udadf\ude97\ud981\udffa");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u1d09\u2c35\ud922\uddaf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
