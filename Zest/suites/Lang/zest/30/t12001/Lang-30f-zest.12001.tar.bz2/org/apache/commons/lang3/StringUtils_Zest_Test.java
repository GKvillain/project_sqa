package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\ud895\udf6e\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\ud965\ude83\ud92a\udf68\udaf9\udeed");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\ud895\udf6e\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\ud965\ude83\ud92a\udf68\udaf9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\000\ud98e\udda6\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\ud895\udf6e\udb87\udd44\u8c76\ubae6\uadc2\ud89d\udd31\000\ud9b8\ude5c\u8162\u0090\udaf9\udeed");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\000\ud98e\udda6\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\ud895\udf6e\udb87\udd44\u8c76\ubae6\uadc2\ud89d\udd31\000\ud9b8\ude5c\u8162\u0090\udaf9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\000\000\uda67\udf00");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\udba0\udfc3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\udb4c\udf46\udbd2\udf01\uda24\udc24\ud9b5\udd24\uda85\udd52\ud980\ude67\udb2a\udcc0\u7e38\ud8b3\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\u6178\ud86e\ude39\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\udaab\udf8d\ud97b\udccf\uf5f1\udafa\udd7b\udb5d\udfae\ud82d\udf54\udaf6\udfed\udb1e\udf23\udb54\udeb9\uda90\ude96\ud942\udcb8\ud85e\udcde\uda4a\udf24\uda19\udf31\udb2e\uddfc\udb85\udf32\uda94\udc89");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\udb4c\udf46\udbd2\udf01\uda24\udc24\ud9b5\udd24\uda85\udd52\ud980\ude67\udb2a\udcc0\u7e38\ud8b3\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\u6178\ud86e\ude39\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\udaab\udf8d\ud97b\udccf\uf5f1\udafa\udd7b\udb5d\udfae\ud82d\udf54\udaf6\udfed\udb1e\udf23\udb54\udeb9\uda90\ude96\ud942\udcb8\ud85e\udcde\uda4a\udf24\uda19\udf31\udb2e\uddfc\udb85\udf32\uda94\udc89", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udba0\udfc3\udabe\ude08\uda67\udfdb\ud8e6\udc3e\ud898\udcac\ud93e\udfc5\ud98a\ude8c\ud9b5\udd18\uda85\udd52\ud934\udf61");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udabe\ude08\uda67\udfdb\ud8e6\udc3e\ud898\udcac\ud93e\udfc5\ud98a\ude8c\ud9b5\udd18\uda85\udd52\ud934", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\udba0\udfc3\uda6a\udfc8\uda67\udfdb\ud8e5\udfc7\ud994\ude0a\ud9e0\udd3b\ud95a\udfd1\u8d51\ud926\udcbb\ud931\ude76\udb2a\udcc0\u7e38\ud81a\udd2d\ud9d0\uddb1\uda6b\udea6\uda1b\udddb\udb5b\udcc0\udbf9\udcfa\ud9fc\udd3e\ud895\udf6e\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\u982a\ud92a\udf68\udaf9\udf39");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\uda6a\udfc8\uda67\udfdb\ud8e5\udfc7\ud994\ude0a\ud9e0\udd3b\ud95a\udfd1\u8d51\ud926\udcbb\ud931\ude76\udb2a\udcc0\u7e38\ud81a\udd2d\ud9d0\uddb1\uda6b\udea6\uda1b\udddb\udb5b\udcc0\udbf9\udcfa\ud9fc\udd3e\ud895\udf6e\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\u982a\ud92a\udf68\udaf9\udf39", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\ud884\udf51\ud937\uddc3\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud884\udf51\ud937\uddc3\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udba0\udfc3\udb91\udf9c\udb1e\udeda\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda90\udc16\ud934\udf61\udb2a\udcc0\u7d6e\ud855\uddcb\uda1f\udfa6\ud983\udd5d\udbde\udf52\ud821\udc59\ud82f\ude09\ud9fc\ude7a\ud895\udf6e\udb87\udd44\ua7fa\uba73\uadc2\udb4c\udd89\ud96d\ude20\ud9d9\udd97\ud965\ude83\ud92a\udf68\ud9cc\udd76");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb91\udf9c\udb1e\udeda\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda90\udc16\ud934\udf61\udb2a\udcc0\u7d6e\ud855\uddcb\uda1f\udfa6\ud983\udd5d\udbde\udf52\ud821\udc59\ud82f\ude09\ud9fc\ude7a\ud895\udf6e\udb87\udd44\ua7fa\uba73\uadc2\udb4c\udd89\ud96d\ude20\ud9d9\udd97\ud965\ude83\ud92a\udf68\ud9cc\udd76", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udba0\udfc3\udb91\udf9c\ud8a5\udcda");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb91\udf9c\ud8a5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udba0\udfc3\udb91\udf9c\uda44\udd29\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\uda7c\udf42\udb51\uded7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb91\udf9c\uda44\udd29\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\uda7c\udf42\udb51\uded7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\ud823\udd52\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\uda4f\uded1\udb0d\udd9c\u8c76\ubae6\uadc2\udb4c\udd89");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\ud823\udd52\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\uda4f\uded1\udb0d\udd9c\u8c76\ubae6\uadc2\udb4c\udd89", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\udba0\udfc3\udb94\uddd6\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\ud828\udc84\udb05\udebb\udb1c\udf1b\u7e38\ud8ea\udf55\ud81f\udf20\ud977\udc82\udbde\udf52\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\ud895\udf6e\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\ud965\ude83\ud92a\udf68\udaf9\udeed");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\uda66\udf19\udb5a\udd1f\uc2cf\ud8f7\udf3d\uda75\udf81\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\udb3a\udf7c\ud895\udf6e\udb87\udd44\u8c76\udbd4\udcf7\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\ud965\ude83\ud92a\udf68\udaf9\udeed");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ud868\udd73\uda03\udfa0\ud80c\udcbb\ud92d\uded4\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\ud81b\udf8a\udafe\udd3b\uda69\udd16\udb1c\udf5a\ud90b\udcd4\udb4a\udf67\ud88e\udcf9\ud9fc\ude3e\ud895\udf6e\udb87\udd44\u8c76\ud89a\ude79\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\ud965\ude83\ud92a\udf68\udaf9\udeed");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda14\uddc4\uda50\udfb2\ud855\udd64\udb88\udcbb\ud8f3\uddad\udba4\ude74\udbad\udfd5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda14\uddc4\uda50\udfb2\ud855\udd64\udb88\udcbb\ud8f3\uddad\udba4\ude74\udbad\udfd5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u0481\uda78\udc62");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u0481\uda78\udc62", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ucf6b\000\ud97c\udc4a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u6d35");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud8a3\udc60\ud91b\udc58\uda67\udf00");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8a3\udc60\ud91b\udc58\uda67\udf00", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ubaf8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\udb31\udc57\ud8e1\udedb\uda6c\uddaa\ud897\udc0b\udaec\udd15\ud9f4\udfaa\udbde\udc8c\udafc\uddf6\udb07\udcd4\uda79\udcce\udb7f\udc26\udb3d\udc0f\ud935\udf67\ud863\udd4f\ud9e9\udddd\ud9c9\uddf5\ud9b6\udf0c\ud8b9\udc4d\uda95\udd9d\ud84a\udd52\ud851\udf13\udb51\udf94\udacc\udefb\udaf6\ude0e\uda7e\udd5c\udb0c\udcbb\ud840\udcf0\ud8f6\udc01\ud813\udd04\ud9d8\udfe4\ud806\udd59\udb09\udd82\udb59\ude06\uda22\udea3\uda8a\udfda\udb00\udc92\uda3a\udc5d\uda11\udea4\udb4a\udee1\ua568\uda98\udd07\udaa8\udfc2\uda59\ude04\ud8ac\udee5\udad0\udcb2\uda2b\ude28\ud8d1\ude2a\ud96a\udd6e\uda45\udd55\udb6d\ude87\ud9fd\udc2f\udb14\ude34\udbf8\udc2b\u2e22\udb25\udc53\udacc\ude16\ud9a1\udd8f\ud9ff\udc2b\ud901\udc45\udb12\udf7b\udb64\ude96\udaca\udf9d\ud90d\udcf3\udbc5\udc9a\uda3f\uddc5\ud86c\udfda");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u16e9\uda4a\udd44\udae4\ude0d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\uc249\ud9f9\udfe1\uda2b\udde9\udbd9\uddf5\udb10\udd65\ud88a\udc7f\u1db2\ud8a8\udced\udbbc\ude9b\ud8e6\udfc9\udb32\udc74\udb8e\udd42\ud8d9\udc76\ud999\udeb6\ud91a\udd1a\udb7c\udcb1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u1002\u7425\udbb2\udd0d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udba0\udf65\ud9b9\udf59\ud8b6\udf03\udbe2\ude20\ud859\udc50\ud867\udee8\uda06\udfc5\ud9dc\udf15\ud9dd\udcce\uda60\ude2a\udb8e\ude0a\uda24\ude37\udbea\udd74\ud8b4\udf2b\udaed\udc3d\ud95e\udd3e\ud970\udc8a\udb0a\ude3b\udbc7\udf88\udb4c\udf30\ud811\udf3f\ud8ed\udf27\uda5d\ude32\udac4\udfe4\ud8ed\udc1d\ud990\udcc1\udbf9\ude39\ud94e\udf00\uda55\ude60\ud85b\udda0\ud997\ude53\ud97e\udc10\udb4e\udc69\ud890\udd99");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udf65\ud9b9\udf59\ud8b6\udf03\udbe2\ude20\ud859\udc50\ud867\udee8\uda06\udfc5\ud9dc\udf15\ud9dd\udcce\uda60\ude2a\udb8e\ude0a\uda24\ude37\udbea\udd74\ud8b4\udf2b\udaed\udc3d\ud95e\udd3e\ud970\udc8a\udb0a\ude3b\udbc7\udf88\udb4c\udf30\ud811\udf3f\ud8ed\udf27\uda5d\ude32\udac4\udfe4\ud8ed\udc1d\ud990\udcc1\udbf9\ude39\ud94e\udf00\uda55\ude60\ud85b\udda0\ud997\ude53\ud97e\udc10\udb4e\udc69\ud890\udd99", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u63ea\udb91\udf8f\ud8f3\uddc0\ud918\udc35\ud898\udcac\udbd2\udeef\uda9e\udc41\u9629\u2005\ud937\udf90\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\uda7c\ude5a\uda7e\udee2\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\uda4f\uded1\udb0d\udd9c\u8c76\ubae6\udb3f\udc6a\udb4c\udd8b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u63ea\udb91\udf8f\ud8f3\uddc0\ud918\udc35\ud898\udcac\udbd2\udeef\uda9e\udc41\u9629\ud937\udf90\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\uda7c\ude5a\uda7e\udee2\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\uda4f\uded1\udb0d\udd9c\u8c76\ubae6\udb3f\udc6a\udb4c\udd8b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u657a\ud82a\udc7f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("x\000\000\u00d2\ud898\udcac\udba5\ude32\udb66\uddc6\ud9b5\udd18\ud828\udc84\ud80b\udf9e\udb1c\udf1b\u7e38\ud8ea\udf55\u78e1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ucf6b\u1a00\ud97c\udc4a\udac9\udc07\ud8a0\ude98\ud81e\udca8\udbeb\uddce\ud82f\udf4e\udb91\uded5\udb98\ude85\ud864\udc6d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\ucf6b\u0e21\ud96c\udd36");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("Z\ud86f\udf96\ud96d\uddb7\ud93a\uddd0\u3ca3\udae6\ude66\udb63\uddf6\udb80\udf96\udb6b\udca4\udbda\ude07\udb32\udfba\uda7b\udc1a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u1002\u7425\udbb2\udd0d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("Z");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("ZG\000\000\u3c49\000\000\000\000\udbda\ude07\udb32\udfba\uda7b\udc1a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\udb1a\udd76\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\ud965\ude83\ud92a\udf68\udaf9\udeed");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb91\udf9c\uda67\udfdb\ud8e6\udc3e\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda85\udd52\ud934\udf61\udb2a\udcc0\u7e38\udb73\udd19\uda20\udc22\ud983\udd5d\udbde\udf52\udb4a\udf6d\ud88e\udcf9\ud9fc\ude3e\udb1a\udd76\udb87\udd44\u8c76\ubae6\uadc2\udb4c\udd89\ud85c\udef0\ud9bf\udd37\ud965\ude83\ud92a\udf68\udaf9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u63ea\udb91\udf8f\ud8f3\uddc0\ud918\udc35\ud898\udcac\udbd2\udeef\uda9e\udc41\u9629\u2005\ud937\udf90\ucaa5\u2e66\udb73\udd19\uda20\udc22\uda7c\ude5a\ud8b2\udd3c\000\ud90c\udd66\ud9fc\ude3e\uda4f\uded1\035\u8c76\ue9ca\000\uda71\udc58");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u63ea\udb91\udf8f\ud8f3\uddc0\ud918\udc35\ud898\udcac\udbd2\udeef\uda9e\udc41\u9629\ud937\udf90\ucaa5\u2e66\udb73\udd19\uda20\udc22\uda7c\ude5a\ud8b2\udd3c\000\ud90c\udd66\ud9fc\ude3e\uda4f\uded1\u8c76\ue9ca\000\uda71\udc58", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\uc249\ubcfc\u70eb\ud8a3\ude69\ud939\udd29\udb55\udfe0\u1db2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("xw\000\u00d2\ud898\udcac\ua435\ud851\udc45\udac5\udd4f\ud828\udc84\ud80b\udf9e\udb1c\udf1b\ud802\udc07\ud8ea\udf55\u78e1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ucf6b\u1a00\u9800\000\udb7d\uddc6\ud81e\udca8\udbeb\uddce\ud82f\udf4e\udb91\uded5\udb98\ude85\ud864\udc6d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udba0\udfc3\udb03\udcd5\udaa8\udd38\ud8e6\udc35\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda90\udca9\ud930\udcfe\udba8\ude5a\ud8fc\ude62\ud9bd\udf90\udb9b\udc62\u304f\udbde\udf52\ud821\udc59\ud82f\ude09\udb87\udc7f\ud895\udf6e\ud98c\udd45\ua7fa\u4304\udbb3\udea6\udb4c\udd89\ud84c\udc16\ud82a\ude7d\uda0a\udf42\udb4a\udef1\ud86a\udc32\uc578\uda1a\udda8\ud973\udfa5\uda02\udf84\udb6b\udf53\uda2a\udccb\ud835\ude56\uda56\udfa1\uda1d\udcaf\udb2e\udd5d\ud876\ude8e\udaec\ude0d\ud8d4\udd3a\udb11\ude71\udadf\ude60\udb0a\ude66\ud81b\udecd\udba5\udce6\ud9db\udd1a\ud813\ude98\udae0\udf27\udb79\ude16\uda61\uddc9\udb7e\udc8e\ud965\udfaa\u199d\uda5a\udca1\ud955\udcb8\ud875\udca9\udbad\udffa\udb3e\udef3\ud885\udecb\ud87d\udc37\udbf0\udcc3\ud98a\udd47\udb64\udff4\uda40\udc84\ud96b\ude15\ud96e\uddd9\ud8e7\udcd3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udba0\udfc3\udb03\udcd5\udaa8\udd38\ud8e6\udc35\ud898\udcac\udbd2\udeef\udb66\uddc6\ud9b5\udd18\uda90\udca9\ud930\udcfe\udba8\ude5a\ud8fc\ude62\ud9bd\udf90\udb9b\udc62\u304f\udbde\udf52\ud821\udc59\ud82f\ude09\udb87\udc7f\ud895\udf6e\ud98c\udd45\ua7fa\u4304\udbb3\udea6\udb4c\udd89\ud84c\udc16\ud82a\ude7d\uda0a\udf42\udb4a\udef1\ud86a\udc32\uc578\uda1a\udda8\ud973\udfa5\uda02\udf84\udb6b\udf53\uda2a\udccb\ud835\ude56\uda56\udfa1\uda1d\udcaf\udb2e\udd5d\ud876\ude8e\udaec\ude0d\ud8d4\udd3a\udb11\ude71\udadf\ude60\udb0a\ude66\ud81b\udecd\udba5\udce6\ud9db\udd1a\ud813\ude98\udae0\udf27\udb79\ude16\uda61\uddc9\udb7e\udc8e\ud965\udfaa\u199d\uda5a\udca1\ud955\udcb8\ud875\udca9\udbad\udffa\udb3e\udef3\ud885\udecb\ud87d\udc37\udbf0\udcc3\ud98a\udd47\udb64\udff4\uda40\udc84\ud96b\ude15\ud96e\uddd9\ud8e7\udcd3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u1002\u7425\u6361\uda67\udf9a\udb70\uddaa\udb89\ude9d\udafe\udd9c\ud9d2\udf3c\ud963\udc94");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ucf6b\u1a00\u9800\u7000\udb7d\uddc6\ud81e\udca8\udbeb\uddce\ud82f\udf4e\udb91\uded5\udb98\ude85\ud864\udc6d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ucf6b\u1a00\u9800\000\udb7d\uddc6\ud81e\udca8\udbeb\uddce\ud82f\udf4e\udb91\uded5\udb98\ude85\ud864\udc6d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ucf6b\u1a00\u9800\u7000\udb7d\uddc6\ud81e\udca8\udbeb\uddce\ud82f\udf4e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ucf6b\u1a00\u9800\uc7c3\udb7d\uddc6\ud81e\udca8\udbeb\uddce\ub32e\uda81\udf0f\udb98\ude85\uda60\udf4c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\uc249\ubcfc\u70eb\ud0d2\udaf1\udd04\uda76\udf09\u1db2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(" ");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace(" \uda6d\udf8b\uda10\udde2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace(" ");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace(" \ud925\udc1f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
