package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb72\udf5b\ud9a8\udf98\uda7b\udeb9\ud945\udcbe");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\udb72\udec3\uda43\udf26\ud8a9\udf1f\ud945\udcbe\ud82b\udd1d\uda3d\udce8\uda83\udeed\u853f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ud8c0\udce2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\ud8f8\udc19\udabb\ude88\ud874\udf13\ud9b8\udfd2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8f8\udc19\udabb\ude88\ud874\udf13\ud9b8\udfd2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ud80c\udd3d\u4115\udb23\uddb1\udb7b\udcc0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\udbd2\udf02\ud96e\udc8a\uda7b\ude4a\udbb5\udd2b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb72\udf4b\ud9a8\udf98\ud9f3\udd72\udaf3\udcc3\uda81\udcda\ud93f\udfda\udbe6\udd1f\ud96e\ude3b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\udb72\udf5b\ud9b6\udd40\ud881\udc3d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb72\udf5b\ud9b6\udd40\ud881\udc3d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\ud874\udd79");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud874\udd79", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ud8bd\udd61\udade\ude3b\ud9f6\udf95\ud899\udf43\udae9\udff2\uda5f\udcde\udae1\uddef\udbe5\udf67\udbb8\udd18\uda34\udd90\ud9af\udd8d\ud989\udf82\ud86c\udef1\u49fc\ud9ea\udc9f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ud80a\udf33\ud9a8\udf98\udac7\udcdf\ud844\udf0c\ud9c8\udd8c\ud8e5\udfba\uda60\udcce\ud941\ude74\ud829\ude40\udada\udf76\u9efd\ud8ba\udf6d\udb6e\udee6\udb38\uddbb\uda81\udcd9\udb21\udcf0\uda54\udd6a\udb13\udc27\ud847\udd9f\uc060\ud8f7\udfe5\uda3b\udcd1\ud827\udc38\ud8ae\udd2e\ud98d\udc32\udb50\udd81\uda31\udd83\ud818\udd57");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb72\udf5b\ud929\udff3\ud90c\udf95\ud857\udf26\u9fe4\udad2\udf1e\ud96e\uddd9\udbb0\udfee\udbef\udebf\ud994\udda6\udba5\udc7c\udbfa\udc48\uda13\ude50\uda31\ude6a\uda00\udedb\udbf1\udcf2\ud814\uddf5\ud882\udc84\ud805\udfbd\uda45\udce2\ud87f\udc4e\ud8cf\udef5\uda22\udf09\udb12\udca0\ud89a\udd1b\ud9e2\udf34\ud8b5\ude4d\ud935\udc33\udbbc\udd1c\udb89\udcb9\udbdd\udcfd\udabd\udcf6\uda2b\udf62");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ud8bb\udc81\udbb8\udeda\uda7b\udeb9\ud945\udcbe");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\ud9fc\udead");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9fc", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb72\udf5b\ud9a8\udf98\udad9\udcfe\ud945\udcbe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb72\udf5b\ud9a8\udf98\udad9\udcfe\ud945\udcbe", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud909\udf91\udbcc\udea3\uda98\udcf9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud909\udf91\udbcc\udea3\uda98\udcf9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb1b\udda1\ud8c4\udff1\udafb\uddbe\ud93a\udc44\ud941\ude59\udb4c\udc58\ud85e\udf00\uda68\udf7f\ud87d\udf8b\uac77\udaa0\ude8e\udb57\udd79\uda2e\udf7d\udb6a\udf9a\ud8b3\udda6\ud8b8\udd0f\udb13\udd94\ud972\udccd\ud9be\ude11\uda8a\udded\ud8e2\udcf1\ud8ae\udda2\udb38\udf0e\udb09\udcf9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb1b\udda1\ud8c4\udff1\udafb\uddbe\ud93a\udc44\ud941\ude59\udb4c\udc58\ud85e\udf00\uda68\udf7f\ud87d\udf8b\uac77\udaa0\ude8e\udb57\udd79\uda2e\udf7d\udb6a\udf9a\ud8b3\udda6\ud8b8\udd0f\udb13\udd94\ud972\udccd\ud9be\ude11\uda8a\udded\ud8e2\udcf1\ud8ae\udda2\udb38\udf0e\udb09\udcf9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\uaa94\udb78\udd9e\ud982\udca5\u2ce9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u514c\uafc5\uda8b\udc02\ud945\udcbe\ud843\udc2a\udbe5\ude99");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud8a8\udf57\udac8\udf99\ud896\udf65\ud86c\udf9e\udbfc\uddca\ud891\udfda\udaa4\udf19\ud89f\uddd2\uda6e\ude15\udb78\udf83\uda35\udcb2\uda8a\udc43\udb5d\udf96\udab2\udd53");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8a8\udf57\udac8\udf99\ud896\udf65\ud86c\udf9e\udbfc\uddca\ud891\udfda\udaa4\udf19\ud89f\uddd2\uda6e\ude15\udb78\udf83\uda35\udcb2\uda8a\udc43\udb5d\udf96\udab2\udd53", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb7e\udd77\ud91c\udf7f\udb63\ude24\udb1f\uddec\ud952\udd29\uda2f\uddbe\ud83c\udce2\ud8f0\udc92\uda23\ude06\ud9cf\udefd\ud92c\udc69\udaea\udfc6\udb2e\udf60\uda7a\udfcc\ud8a8\udf79\udad2\udf84\udb3b\udf19\ud833\udc13\ud834\udf37\uda95\ude57\uda4b\udeff\ud812\udd5f\ud882\udc21\uda08\udc81\ud9c4\udf7e\u14c8\ud809\uddfc\uda3c\udf73\ud85d\ude88\ud8d4\udeb6\ud854\uded1\ud976\udf51\udb28\udebe\ud9cc\udf4b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb7e\udd77\ud91c\udf7f\udb63\ude24\udb1f\uddec\ud952\udd29\uda2f\uddbe\ud83c\udce2\ud8f0\udc92\uda23\ude06\ud9cf\udefd\ud92c\udc69\udaea\udfc6\udb2e\udf60\uda7a\udfcc\ud8a8\udf79\udad2\udf84\udb3b\udf19\ud833\udc13\ud834\udf37\uda95\ude57\uda4b\udeff\ud812\udd5f\ud882\udc21\uda08\udc81\ud9c4\udf7e\u14c8\ud809\uddfc\uda3c\udf73\ud85d\ude88\ud8d4\udeb6\ud854\uded1\ud976\udf51\udb28\udebe\ud9cc\udf4b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u39cc\udba9\uddf4\uda61\ude54\ud945\udcbe\ud89e\udc36\uda1e\udc8d\uda83\udeed\u853f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u38d2\u022b\ud97e\ude01\udb46\udca9\ud826\udfa4\udae3\udf18\ud823\udebd\uebed\ud845\udd86\udb56\udf6e\ud893\udf19\ud8cc\udf9d\ud95f\udfbe\ud856\udf02\uda0f\ude23\udbfe\udd0a\ud864\udc65\udb0a\udf1e\ud9d3\uddcd\udbce\uddb5\ud9c7\uddbe\udb90\udcd3\ud97b\udc79\uda43\udfe4\ud831\udfc0\u3f05\ud996\udf5f\udb08\uddcb\uda39\ude6d\uda62\uddef\ud907\udd78\ud98b\ude7c\ud806\udd8d\uda2d\udd6b\udbe8\ude9f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb6a\udc9c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb6a\udc9c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\uda71\uddfe\udb9a\ude38\ub05f\uda1a\ude0a\ud91b\udefb\udb05\udeb0\ud9c4\udfa5\udbc7\udc88\udadd\udf5a\ud8ed\udf98\ud859\udf98\uda2a\udd5d\u3c18\ud9fc\udf2b\udb18\udfdf\ud964\udc32\ud952\ude35\ud81c\udcf8\uda9a\uddb0\udad8\udf2b\ud8ba\udefa\udb19\udca6\udb2f\udce1\uda26\udca2\udae1\uddf8\uda1c\udf58\udaea\udca8\ud911\udcd4\u2c47\ud903\ude09\ud829\udffd\ud9a8\udf1f\u8060\u62fe\ud839\udf6a\ud983\ude7a\udbb1\ude67\ud909\udcac\ud97d\udfd5\ud874\ude88\ud9f7\ude7a\udb0b\udc7c\udae4\udd63\udb93\udf36\udb89\udf64\udb67\udc14\uda89\udc58\udbb9\udebb\udb62\udd67\uda65\udddd\uda43\udc86\ud9c7\udd64\udadf\udf95\ud915\udfdf\udb38\uddf0\udac2\udc8d\udb03\udf39\udbe7\udc95\udacf\udc45\udb19\ude37\u5863\udba7\udd21\udaf2\udfd4\ud8b3\udf27\udb3b\uddca\uda3d\udd01\ud9e3\udec7\uda26\udd0b\udb52\udfbc\udb18\udea6\uda45\uddf3\udbd6\udcce\ud889\udc7d\udba4\udceb\ud921\udc4c\ud965\udfae\uda2f\udfb0\ud842\ude98\ud876\udde3\ud8c3\uddd6\ud988\ude32\uda2d\udc97");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u5e29");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\uc33d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u4482");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\uc9cd\udb14\udc66\udb0f\udf86");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u67a7\ud08e\uda7b\ude4a\udbb5\udd2b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u2c27\ud9a8\udf98\udad9\udcfe\ud945\udcbe\ud865\udf42\uf589\udb1b\udf9d\uda8c\udc71\ud95a\ude2f\udaf4\udf11\udb53\udd83\ud96e\udc4c\uda06\udcec\ud855\udd45\udb60\udd0f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u0e1c\u7f19\uda54\udc51\ud82d\udebd\udad0\uded7\ud8d4\udfd8\udadb\udf1f\ud940\udcb3\udae8\udf6c\ud967\ude3d\udac2\udcca\ud8b3\udcd6\ud85f\uddc4\udbd3\udc4b\ud9b5\udc44\udbb4\udddb\udad3\udce7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("f\udb08\ude7c\ud873\udc49\udbf2\udd36\ud860\udcc9\uda55\udcfa\ud9a7\ude04");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda3f\udc4c\ud864\ude98\ud82e\udfec\udba1\udfde\ud895\udf22\ud839\udd3a\udb76\udd8b\ud824\udf52\ud9b9\udc34\ud90e\ude51\ud967\udd0d\ud84e\udfa8\udab0\udf91\udbaa\ude17\udbe0\uddbb\uda1f\udc63\ud958\udc68\ud8fa\ude1f\udaa2\udf3b\udab8\udf3a\ucd70\u8197\ud915\udf4d\uef93\ud91e\udd09\ud821\udd8a\udb84\udda9\udb17\udcf3\ud9a7\udd52\ud926\udf39\ud86c\udf4b\ud998\ude03\ud953\uddde\uda5e\udd98\ud8ab\ude81\udad8\ude02\ud87a\udd7d\ud9a7\udee3\u8749\ud86b\ude52\udb36\ude23\udbf4\udf06\udb5e\udea3\udaf2\udf74\udba0\ude54\ud98d\ude69\udbaf\ude8a\udb42\udf79\udb8e\ude61\ud8ac\udf44\ud90a\udeef\uda85\udfe4\ud9e7\udd19\ud454\udac8\udcb2\udb3b\udd5d\udaa4\udffb\ud850\ude28\uda16\uddd7\ud8b2\ude40\ud917\udfe0\udbfe\udf8c\uda21\udd90\uda3b\udccb\ud9de\udd15\udb90\udfc4\udbea\udf17\uda2b\udcda");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda3f\udc4c\ud864\ude98\ud82e\udfec\udba1\udfde\ud895\udf22\ud839\udd3a\udb76\udd8b\ud824\udf52\ud9b9\udc34\ud90e\ude51\ud967\udd0d\ud84e\udfa8\udab0\udf91\udbaa\ude17\udbe0\uddbb\uda1f\udc63\ud958\udc68\ud8fa\ude1f\udaa2\udf3b\udab8\udf3a\ucd70\u8197\ud915\udf4d\uef93\ud91e\udd09\ud821\udd8a\udb84\udda9\udb17\udcf3\ud9a7\udd52\ud926\udf39\ud86c\udf4b\ud998\ude03\ud953\uddde\uda5e\udd98\ud8ab\ude81\udad8\ude02\ud87a\udd7d\ud9a7\udee3\u8749\ud86b\ude52\udb36\ude23\udbf4\udf06\udb5e\udea3\udaf2\udf74\udba0\ude54\ud98d\ude69\udbaf\ude8a\udb42\udf79\udb8e\ude61\ud8ac\udf44\ud90a\udeef\uda85\udfe4\ud9e7\udd19\ud454\udac8\udcb2\udb3b\udd5d\udaa4\udffb\ud850\ude28\uda16\uddd7\ud8b2\ude40\ud917\udfe0\udbfe\udf8c\uda21\udd90\uda3b\udccb\ud9de\udd15\udb90\udfc4\udbea\udf17\uda2b\udcda", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u38d2\u022b\u9d36\ud9fb\udc20\ud826\udfa4\udae3\udf18\ud823\udebd\ud9b0\ude28\ud821\ude3d\udb57\udc29\ud893\udf19\ud8cc\udf9d\ud95f\udfbe\ud856\udf02\ud852\udd06\udbeb\udf6d\ud864\udc65\ud9b4\udd8b\ud8e7\ude40\udad5\udd3a\ud9c7\uddbe\udb90\udcd3\uf47a\ud991\ude6b\ud8d9\udff3\u3f05\ud996\udf5f\udb08\uddcb\uda39\ude6d\uda62\uddef\ud907\udd78\ud98b\ude7c\ud806\udd8d\uda2d\udd6b\udbe8\ude9f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u38d2\u022b\u9d36\ud9fb\udc20\ud826\udfa4\udae3\udf18\ud823\udebd\udaf6\uddb6\ud836\ude59\ud817\udc89\ud8b0\udfe9\ud8cc\udf9d\u763d\ud856\udec6\ud852\udd06\udbeb\udf6d\ud864\udc65\ud9b4\udd8b\ud8e7\ude40\udaf0\uddb3\ud9c7\uddbe\udb90\udcd3\udb9f\udfb1\ud9c4\uddcc\ud8db\udf5a\u3f05\ud996\udf5f\udb08\uddcb\uda39\ude6d\uda62\uddef\udb65\udd99\ud98b\ude7c\ud856\udd74\uda2d\udd6b\udbe8\ude9f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u38d2\u0171\u9d36\ud9fb\udc20\ud826\udfa4\udae3\udf18\ud823\udeb1\udaf6\uddb6\ud836\ude59\ud817\udc89\ud8b0\udfe9\ud8cc\udf9d\u763d\ud856\udec6\udb9b\udc95\udbe6\uddec\udbaf\udc0b\ud9b4\udd8b\ud8e7\ude40\udaf0\uddb3\ud9f7\ude15\udb8f\uddd9\udb9f\udfb1\ud9c4\uddcc\ud802\udf4d\udbc5\udce4\ud996\udf5f\udb08\uddcb\uda39\ude6d\u2744\udb65\udd99\ud98b\ude7c\ud856\udd74\uda2d\udd6b\udbe8\ude9f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ud845\uddeb\ud985\ude75\uda7b\udeb9\udb35\ude14\ud8f7\udc2d\ud203\ud8bf\ude04");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u2c27");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u709d\u6f19\u7038\udb39\udd2a\udb8a\udf14\ud866\udd90\ud970\uddf7\ud96b\ude85\ud9ec\ude44\udbb2\udd40\ud856\udd9b\udbec\udf7b\ud841\udd20\ud908\udd2f\udba7\ude85\ubab6\udb27\udee0\ud9d3\udd20\ud95b\udcdf\ud800\udee0\uda67\udef3\uda9b\udc60\ud824\udd18\ud969\udc11\udaaa\udecf\udac1\udc11\udbd4\udf9b\udbc4\udd82\udba9\udd87\udb2b\udc78\ud929\udcb2\udb2d\udc56\ud9ef\ude21\udbee\uddd3\ud9e2\udf10\ua2f6\ud99d\udc88\ud8c5\udd5b\ud9c7\udc68\udbd2\udc15\ud894\udfbc\udae1\udd4c\udb3c\ude1a\udb07\udeba\ud8f6\udf71\ud839\udcee\ud9cc\udc43\ud98f\udde4\ud98a\udda6\ud474\ud9e6\udc5b\udb48\ude84\udb73\udc58\udba8\udc49");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udbd2\udf02\ud96e\udc8a\uda7b\ude4a ");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbd2\udf02\ud96e\udc8a\uda7b\ude4a", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udbd2\ude80\012\uda7b\ude10 ");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbd2\ude80\uda7b\ude10", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u38d2\u022b\u9d36R\ud826\udfa4\udae3\udf18\udb85\udcbc\ud9b0\ude28\ud821\ude3d\ud895\udc28\ud893\udf19\ud8cc\udf9d\ud95f\udfbe\ud856\udf02\ud852\udd06\udbeb\udf6d\ud864\udc65\ud9b4\udd8b\ud8e7\ude40\udad5\udd3a\ud9c7\uddbe\udb90\udcd3\uf47a\u33aa\ud8d9\udff3\u3f05\ud996\udf5f\udb08\uddcb\uda39\ude6d\uda62\uddef\ud907\udd78\ud98b\ude7c\ud806\udd8d\uda2d\udd6b\ud9be\udcea");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u709d\u6f19\u7038\ubd26\udb8a\udf14\ud866\udd90\ud970\uddf7\ud96b\ude85\ud9ec\ude44\udbb2\udd40\ud856\udd9b\udbec\udf7b\ud841\udd20\ud908\udd2f\udba7\ude85\ubab6\udb27\udee0\ud9d3\udd20\ud95b\udcdf\ud800\udee0\uda67\udef3\uda9b\udc60\ud824\udd18\ud969\udc11\udaaa\udecf\udac1\udc11\udbd4\udf9b\udbc4\udd82\udba9\udd87\udb2b\udc78\ud929\udcb2\udb2d\udc56\ud9ef\ude21\udbee\uddd3\ud9e2\udf10\ua2f6\ud99d\udc88\ud8c5\udd5b\ud97b\ude1c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u709d\u6f19\u7038\ubd26\ud8f1\udf69\ud866\udcfd\ud970\uddf7\ud96b\ude85\ud9ec\ude44\udbb2\udd40\ud856\udd9b\udbec\udf7b\ud841\udd20\ud908\udd2f\udba7\ude85\u9639\udb27\udee0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u38d2\u022b\u9d36\u0544\ud862\udda1\udae3\udf23\ud823\udebd");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
