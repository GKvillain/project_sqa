package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\uda03\udfa1\uda1c\udded\udbff\udd7a\udb67\udc41\ud9c6\ude30\udba0\udf0d\udba4\ude40");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ud9e3\udc5c\uda1c\udded\udbff\udd7a\udae7\udf15");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\uda03\udfa1\uda1c\udded\udbff\udd7a\ud829\udc02\ud9c6\ude30");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ud954\udc1b\udb50\udffc\ud849\uddbb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\ud844\udec1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\uda03\udfa1\uda1c\udded\udbff\udd7a\uda5f\udc3d\ud9c6\ude30\udba0\udf0d\udba4\ude40\ud87c\udf57");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ud92e\udc09\uda28\udf08\u3c50\udb67\udc41\ud9c6\ude30\udba0\udf0d\uda11\udcb7\udad6\udd04\udb4b\udd23\udb5b\udfdc\ud8e3\udfc1\ud807\udff8\uda8d\ude8d\ud8b1\udc5f\uda6c\ude76\ud888\ude58\ud984\uddf6\udaf9\udf90\udb7d\udec8\uda26\uddd5\ud893\udf87\ud88b\udfd9\udbcb\ude96\udb9b\udfb9\uda82\udc6e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\ud91d\udcd4\uda1b\udf82\uc5ff\udb75\udc28\ud9c6\ude30\udba0\udf0d\udbbb\ude52");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud91d\udcd4\uda1b\udf82\uc5ff\udb75\udc28\ud9c6\ude30\udba0\udf0d\udbbb\ude52", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\uda03\udfa1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda03\udfa1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\uda34\udc6e\ud970\udff6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda34\udc6e\ud970", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\uda03\udfa1\uda1c\udd2c\udbff\udd7a\uacc4\000\udbd5\udf4a\udbe0\ude3e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda03\udfa1\uda1c\udd2c\udbff\udd7a\uacc4\000\udbd5\udf4a\udbe0\ude3e", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\uda9b\udcc1\ud9ce\udf59\uda82\uddb5\udbc8\ude31\uda51\udf9d\udb78\ude25");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\ud2ba");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud2ba", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud855\udef6\uda1c\udded\u488f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud855\udef6\uda1c\udded\u488f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\udadb\udf9e\ud90b\udd34\ud940\udc07\udb71\ude29\ud9c6\ude30\udba0\udf0d\udba4\ude40\ud984\udf27\udabd\udf0d\uda25\udcf7\udb85\udfe1\ud9a1\udc3b\udbbe\ude92\ud851\udd9f\udb3d\udd77\udad2\udc88\udbb6\udf7b\ud9a5\uddd9\ud917\udcea\ud84e\udf63\uda65\udf06\uda24\udf5d\udbe6\udc8d\ub1a4\uda90\ude4d\ud910\uddce\ud9e3\udc9b\ue228\udb6f\udc78\uda92\udd4d\ud81f\uddc2\udbd9\ude37\ud849\udfdc\ud88f\udd59\ud928\udd6e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda03\udfa1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda03\udfa1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\udb02\ude3f\udbd1\ude2f\ud92f\udd06\uda59\udddf\ud9b3\udd53\udab8\udedc\udba4\ude40\udbc0\udefe\ud988\ude1c\ud8e1\udc3b\ud9d2\ude8f\ud9ce\udfc1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb1d\udd3d\ud9a0\udcb7\udba4\udc2a\ud872\udcf9\ud9a8\udd2c\uda48\udc6b\ud9d8\uded5\ud95e\udf58\uda25\udeed\udbc2\uddbf\ud926\udd36\uda15\udfb9\ud9ed\udfb3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb1d\udd3d\ud9a0\udcb7\udba4\udc2a\ud872\udcf9\ud9a8\udd2c\uda48\udc6b\ud9d8\uded5\ud95e\udf58\uda25\udeed\udbc2\uddbf\ud926\udd36\uda15\udfb9\ud9ed\udfb3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udbc3\udc81\uda1c\uddfb\udbff\udd7a\udb67\udc41\ud9c6\ude30\udb4d\udf43\udba4\ude92");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbc3\udc81\uda1c\uddfb\udbff\udd7a\udb67\udc41\ud9c6\ude30\udb4d\udf43\udba4\ude92", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda03\udfa1\uda1c\udded\udbff\udd7a\udb66\udfa2\udb2e\udf64\ud8e2\uddff\ud873\udda8\ud84a\udc31\ud88e\ude8e\ud81d\udf2e\ud90d\udd87\ud93e\udc8e\uda8b\uddb7\ud84c\udfc2\udbfd\udd5e\ud9da\udc80\ud930\udf08\ud988\udd8b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda03\udfa1\uda1c\udded\udbff\udd7a\udb66\udfa2\udb2e\udf64\ud8e2\uddff\ud873\udda8\ud84a\udc31\ud88e\ude8e\ud81d\udf2e\ud90d\udd87\ud93e\udc8e\uda8b\uddb7\ud84c\udfc2\udbfd\udd5e\ud9da\udc80\ud930\udf08\ud988\udd8b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\u3757");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u00ba");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u80e7\ud998\ude3c\uc04b\uda47\udd71\udbfb\udd54");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\u2be4\udb11\udfe2\udaa1\udebe\ud817\udf14\ud91e\udc3b\udbba\udc23\ud8e2\udd13\ud9b2\udc17\ud95d\udf08\ud805\udceb\udb99\ude65\ud93c\udd2c\ud861\ude39\ud161\ud91b\udc9a\ud96c\uddfe\ud99d\udc9d\udae1\udd08\ud87e\ude9b\ud834\udd96\ud9f5\udea2\uda33\udedf\u1072\udb62\ude24\udba6\udf6a\ud8e9\uddcf\ud9f7\ude6d\ud9cf\udc36\udb61\udefe\ud823\udf1c\udad5\udcec\uda7f\udfb5\udbd1\udedd\ud9f9\udcd7\udaaf\udfd8\udbfe\udcb9\ud83c\udcbf\ud921\udd1e\uda85\udf50\ud8c1\udf36\udb84\udceb]\uda54\ude08\uda76\udfc8\ud91d\udc3d\udbc6\udf0a\udb37\udd4d\ud81a\udf21\u902d\udae9\uddf6\ud8f5\uddeb\uda7d\udffc\udabd\uddfb\ud832\ude98\uda5c\udff1\ud87a\udfa9\uda6a\udf27\udba5\udd5d\ud98f\ude12\udbe4\ude28\uda8f\udc48\uda85\uded5\udbf9\udcc6\udbb2\ude7d\uda9f\udc7f\uda33\ude46\ud885\ude98\ud819\udcd8\udaf8\udc02\udbc1\udd2f\ud9b3\udfa9\uda1a\ude88\uda63\udfe5\ud90f\udcf4\u57e2\udab3\udf4c\ud8f3\ude6c\udbe3\udc67\ud86e\udf46\udb71\udd85\udbd7\udec4\ud8fe\udc9e\udbe1\udc5d\ud86b\udd8b\ud89c\udde3\udbcc\ude37\ud988\udd92\ud937\uddc1\udac7\udd48\ud824\uddc3\u716f\uda45\udcc4\ud922\udff1\uf25e\ud89e\udcda\ud89e\udea5\ud805\udff8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u2be4\udb11\udfe2\udaa1\udebe\ud817\udf14\ud91e\udc3b\udbba\udc23\ud8e2\udd13\ud9b2\udc17\ud95d\udf08\ud805\udceb\udb99\ude65\ud93c\udd2c\ud861\ude39\ud161\ud91b\udc9a\ud96c\uddfe\ud99d\udc9d\udae1\udd08\ud87e\ude9b\ud834\udd96\ud9f5\udea2\uda33\udedf\u1072\udb62\ude24\udba6\udf6a\ud8e9\uddcf\ud9f7\ude6d\ud9cf\udc36\udb61\udefe\ud823\udf1c\udad5\udcec\uda7f\udfb5\udbd1\udedd\ud9f9\udcd7\udaaf\udfd8\udbfe\udcb9\ud83c\udcbf\ud921\udd1e\uda85\udf50\ud8c1\udf36\udb84\udceb]\uda54\ude08\uda76\udfc8\ud91d\udc3d\udbc6\udf0a\udb37\udd4d\ud81a\udf21\u902d\udae9\uddf6\ud8f5\uddeb\uda7d\udffc\udabd\uddfb\ud832\ude98\uda5c\udff1\ud87a\udfa9\uda6a\udf27\udba5\udd5d\ud98f\ude12\udbe4\ude28\uda8f\udc48\uda85\uded5\udbf9\udcc6\udbb2\ude7d\uda9f\udc7f\uda33\ude46\ud885\ude98\ud819\udcd8\udaf8\udc02\udbc1\udd2f\ud9b3\udfa9\uda1a\ude88\uda63\udfe5\ud90f\udcf4\u57e2\udab3\udf4c\ud8f3\ude6c\udbe3\udc67\ud86e\udf46\udb71\udd85\udbd7\udec4\ud8fe\udc9e\udbe1\udc5d\ud86b\udd8b\ud89c\udde3\udbcc\ude37\ud988\udd92\ud937\uddc1\udac7\udd48\ud824\uddc3\u716f\uda45\udcc4\ud922\udff1\uf25e\ud89e\udcda\ud89e\udea5\ud805", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda8c\udecc\uda50\udfe0\ud878\udde0\udbfe\uddb7\ufd44\udb0d\udcdd\ud9ce\uddb4\ud861\uded8\udb66\uddd1\ud9cb\udca6\udbec\udc7b\udbb6\udc0b\ud8d5\uddf5\u3b2d\uda9a\udc03\ud83b\udf67\ud874\udcb0\udbc0\udcca\uda71\udd05\ud8ff\ude85\udbff\udc9e\uda5d\udc57\udbc5\udeba\udaf4\udda5\udbea\uded5\udbd0\udf26\uda8d\udd1b\uda9a\udfd6\udbad\ude70\ud8ab\udee9\udb1c\udffe\ud876\udc16\udac0\udde6\udbd0\udfbc\udb69\udc13\ud9fe\udff0\ud93b\udd3e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda8c\udecc\uda50\udfe0\ud878\udde0\udbfe\uddb7\ufd44\udb0d\udcdd\ud9ce\uddb4\ud861\uded8\udb66\uddd1\ud9cb\udca6\udbec\udc7b\udbb6\udc0b\ud8d5\uddf5\u3b2d\uda9a\udc03\ud83b\udf67\ud874\udcb0\udbc0\udcca\uda71\udd05\ud8ff\ude85\udbff\udc9e\uda5d\udc57\udbc5\udeba\udaf4\udda5\udbea\uded5\udbd0\udf26\uda8d\udd1b\uda9a\udfd6\udbad\ude70\ud8ab\udee9\udb1c\udffe\ud876\udc16\udac0\udde6\udbd0\udfbc\udb69\udc13\ud9fe\udff0\ud93b\udd3e", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u0e1e\udab7\udf2b\ud880\udf07\udbd5\uddd9\udb86\udf3a\udb7e\udd1f\ud846\udeb1\ud936\ude1b\udb15\udd6c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ub89c\uda97\udf3f\udb0c\uddb8\udaad\udc4f\uda90\uddb2\ud971\udd3b\uda42\udcb2\uda5d\udd76\ud82e\udff9\ud82c\udda0\uda58\udc9a\ud925\udf4e\ud877\udfd9\ud83b\udc25\ud9ec\udf33");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ub652");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ub433\udb6f\ude5b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u00ba");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\u4d56");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u4d56", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u1ec3\ud823\udfd9\ud966\udd15\udb79\udc4b\uda32\ude2d\udb28\udc5d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u407f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud752");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud752", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udbe6\udf81\ud830\udff4\udaf8\uded2\udbbd\udca5\udbbf\udf40\udbf7\udf8b\ud96c\uddbd\ud96a\udf2e\ud8e3\ude3c\udaa9\udd49\uda6c\udcfa\ud961\ude61\ud81d\udf58\ud9d4\udff8\uda8c\udf6c\udbe8\udff6\udb2f\udc63\ubcb5\udb04\udd95\u2357\ud827\ude73\uda10\udc48\udb83\udc96\udaf8\udecf\ud931\udd32\ud986\uddc5\ud83e\ude3e\uda08\udc02\udbc5\udc32\uda9a\udfc0\udadd\udfab\uc0d2\uda9d\udf36\ud8f9\udf0a\uda51\udc58\udb36\udef1\ud9f2\uddf6\udb2b\udf72\uda8a\udd08\udaf9\udfc9\udad4\udcaa\udb17\ude42\ud808\udd2b\uda0c\udfc8\udb91\udff8\uecd8\udb9f\udde7\ud8d3\udd1f\ue9c9\udbf2\udd66\udaf1\udcb9\ud931\udcec\ud8f9\udf14\ud65b\ud8f1\uddd9\udb02\udf42\ud9f6\udff4\ue25d\uae46\uda37\udd50\udade\uddd3\udb97\udf51\ud909\udee8\ud9c6\ude13\uda42\udc42\uda41\udfc9\u8165\uda2a\udecf\uda86\udc20");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbe6\udf81\ud830\udff4\udaf8\uded2\udbbd\udca5\udbbf\udf40\udbf7\udf8b\ud96c\uddbd\ud96a\udf2e\ud8e3\ude3c\udaa9\udd49\uda6c\udcfa\ud961\ude61\ud81d\udf58\ud9d4\udff8\uda8c\udf6c\udbe8\udff6\udb2f\udc63\ubcb5\udb04\udd95\u2357\ud827\ude73\uda10\udc48\udb83\udc96\udaf8\udecf\ud931\udd32\ud986\uddc5\ud83e\ude3e\uda08\udc02\udbc5\udc32\uda9a\udfc0\udadd\udfab\uc0d2\uda9d\udf36\ud8f9\udf0a\uda51\udc58\udb36\udef1\ud9f2\uddf6\udb2b\udf72\uda8a\udd08\udaf9\udfc9\udad4\udcaa\udb17\ude42\ud808\udd2b\uda0c\udfc8\udb91\udff8\uecd8\udb9f\udde7\ud8d3\udd1f\ue9c9\udbf2\udd66\udaf1\udcb9\ud931\udcec\ud8f9\udf14\ud65b\ud8f1\uddd9\udb02\udf42\ud9f6\udff4\ue25d\uae46\uda37\udd50\udade\uddd3\udb97\udf51\ud909\udee8\ud9c6\ude13\uda42\udc42\uda41\udfc9\u8165\uda2a\udecf\uda86\udc20", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u00ba\u049b\udb0a\udc5d\ud812\ude3e\ua295\udaac\udcd0\u1db1\udbe6\udcde\ud82b\udde3\uda81\udc03\ud9ed\udfd9\ud9c0\udf95\udbd0\udf8d\uda44\udc8e\ud984\udeb2\ud844\udecf\ud9f1\udc9a\ud8f4\uded6\ud8c4\ude8f\udaf9\uddf4\udbfc\udda2\ud9bc\udccd\udb87\ude6b\udb31\udf4f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u8077\u36b7\000\uda7b\udc07\udbab\ude95");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u80e7\u36b7\uc04b\uda47\udd71\udbfb\udd54");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u4f15\u71cb\ud9a1\ude5b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ub89c\u37bb\000\000\000\ud971\udd3b\uda42\udcb2\uda5d\udd76\ud82e\udff9\ud82c\udda0\uda58\udc9a\ud925\udf4e\ud877\udfd9\u8ffa\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ua7a4\udbdf\udf5a\ud9ee\udcd4\ud8b5\ude9b\ud840\udc23\ud983\udcaa\uda6f\udd5b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ua7a4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\udb3d\udd73\uda1c\udded\udb4d\ude7a\udb67\udc41\ud9c6\ude30\udba0\udf0d\uda28\udd47\uda7e\udd7a\ud8a9\udc2d\ud990\udce0\udbe9\udd50\udb1e\udc9f\ud94b\udc4f\ud8d5\udf47\uda36\udeac");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb3d\udd73\uda1c\udded\udb4d\ude7a\udb67\udc41\ud9c6\ude30\udba0\udf0d\uda28\udd47\uda7e\udd7a\ud8a9\udc2d\ud990\udce0\udbe9\udd50\udb1e\udc9f\ud94b\udc4f\ud8d5\udf47\uda36\udeac", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\015");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ub89c\u37bb\u8500\udaad\udc4f\u00ab\000\ud894\udf89\uda5d\udd76\ud82e\udff9\ud82c\udda0\uda58\udc9a\ud925\udf4e\u80ce\udb1e\udc0e\ud9ec\udebe");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u937f\u00e5\u6c93\uda81\udc66");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u00ba\u049b\udb0a\udc5d\ud812\ude3e\ud8b3\udf79\uda85\ude59\udbc5\udedf\ud8e8\udec0\ud8df\udf4e\udad5\udf9c\ud9ed\udfd9\ud82b\udf6a\uda43\udddd");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ua7a4\u039f\udba7\uddc4\ud8ec\udcd1\ud836\uddbb\ud992\udc07\ud9df\udc39");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u80e7\u36b7\uc04b\u00c4\udbfb\udca1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ua2ff\u112b\ubc76\udbda\ude1b\ud893\udd6c\ud8aa\udf7a\uda92\udd57\ud95a\udfd4\ud8af\udd3c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u937f\u00e5\u6c93\u00d6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ua2ff\u112b\ubc76\u00f9\uefa1\ud8aa\ude7e\000\ud98e\udda6\ud8af\udd3c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ua7a4\u039fV\000\ud833\udc39\000\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ua2ff\u112b\ubc76\u00f9\uefa1\ud8aa\ude7e\000\ud98e\udda6\ud83b\udc3e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
