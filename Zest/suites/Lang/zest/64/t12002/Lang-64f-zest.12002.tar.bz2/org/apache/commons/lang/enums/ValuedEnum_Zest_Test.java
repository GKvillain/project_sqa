package org.apache.commons.lang.enums;
import org.junit.Test;
import static org.junit.Assert.*;
public class ValuedEnum_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\ud986\udda0\udbca\udc30\ud860\udec8\ud9a6\ude18\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\uda8a\udd46\ud8ea\udc9d\udaae\udf08\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55", "\u8edd\u74c4\u3015\u48b1\ud184\ua012\u9793\u63cc\u4149\u8419\u2cb8", "\ud99e\ude4b",
        17, 45820, 1513619047, -1077487916226651734L, -42375L, false, false, (char) 50397, (char) 3037,
        Double.longBitsToDouble(0x3fd79c008fe55f9aL), Double.longBitsToDouble(0x3fd47d353123a944L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\ud891\udd99\ud986\udda0\udbca\udc30\ud860\udec8\ud9a6\ude18\ud88e\udf4f\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\udb00\udea2\ud8ea\udc9d\udaae\udf08\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55", "\u1837\uc3b5\u76e0\ud013\uc0c0\ua5b3\u978b\u63cc\u4149\u8419\u2cb8", "\ud99e\ude4b",
        17, 45820, 1513619047, -1077487916226651734L, -42375L, false, false, (char) 50397, (char) 3037,
        Double.longBitsToDouble(0x3fd79c0085e55f9aL), Double.longBitsToDouble(0x3fd095c281b9a944L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\ud949\ude94\ud986\ude0c\udbca\udc30\ud860\udec8", "\u58bf\u70e7\uca45\u3b5c\u2cac\uc47b\u6b36\u61ab\u73b3\u397e", "\udb74\udd59\ud9c3\udfcf\ud973\udf11\udae0\udf82\ud959\udc8d\ud868\udf50\u245c\uda40\udccb\uda7e\udd03\ud8f2\udfcd\udaf6\ude5d",
        49, 63855, 860927840, -1553307028313742646L, -99603L, false, true, (char) 22757, (char) 41798,
        Double.longBitsToDouble(0x3fe5f015dbed38f1L), Double.longBitsToDouble(0x3fe5d4891579c008L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udbbc\udd37\ud986\udde6\udbca\udc30\ud860\udec8\ud9a6\ude18\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\ud970\udd19\ud8fb\udca2\udaae\udf08", "\u73b3\u397e", "\udb74\udd59\ud907\udf50\ud973\udf11\udae0\udf82\udaf8\udf4f\ud8b0\udea3\ud86e\udf1b\ud9d3\udf45\udbf7\udeab\ud97c\udcce\ud963\udf60",
        49, 63855, -1441857700, 314288169891016252L, -61436L, true, true, (char) 42582, (char) 37182,
        Double.longBitsToDouble(0x3fe71583e579c008L), Double.longBitsToDouble(0x3fef957e6d473276L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u2b87\ud7c8\u9bee\ud334\u9950\u6979\u1bae\u3b5c\ua8ae\uc47b\u6b36\u61ab\u73b3", "\uda5c\uddd9\000\ud9b8\udf3c\u00ec\udae0\udf82",
        51, 7328, -1501275742, -1855163844503152384L, -100000L, false, false, (char) 62719, (char) 63555,
        Double.longBitsToDouble(0x3feb6d50763c045cL), Double.longBitsToDouble(0x3fe33f1bb6735a37L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\ud986\udda0\udbca\udc30\ud860\udec8\ud9a6\ude18\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\uda8a\udd46\ud8ea\udc76\udaae\udf08\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55", "\u8edd\u74c4\u3015\u48b1\ud184\ua012\u9793\u63cc\u4149\u8419\u2cb8", "\ud99e\ude4b",
        17, 45820, -533201305, -158173321341607923L, -42375L, false, false, (char) 50397, (char) 9692,
        Double.longBitsToDouble(0x3fd79c085fe55f9aL), Double.longBitsToDouble(0x3fd47b2535b824b0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda34\udcc4\ud986\udda0\udaa3\udd3e\ud926\udf29\ud9a6\ude18\udbce\udeb7\ud972\uddaa\udbe4\udc73\udb9d\udfa6\uda8d\udef0\ud8ea\udc9d\udaae\udf08\udbd7\ude05\ud9a2\udf62\udab2\udec0\ud9e4\udf55", "\u8edd\u74c4\u3015\u48b1\ub967\ua012\u9793\u63cc\u165b\u8419\u2d3d", "\ud8b8\udc79\ud8a6\udc67\udaeb\udf3f\ud8bd\udfa1\ud97d\udd91\uda46\udcb1\udb86\ude12\ud89b\udf10\ud836\ude19\ud9cb\uddf3\udbd3\udef4\ud840\udcbf\u8550\udb1e\udeb8",
        34, 65579, -1278958922, 4371176761684937048L, -6977L, true, false, (char) 39205, (char) 11814,
        Double.longBitsToDouble(0x3fe2725d1264c014L), Double.longBitsToDouble(0x3fc3d5a450a59918L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 0, "\ud802\ude81", "\003\u9bee\ud385\u9950\u6979", "\udb97\uded3",
        30, 45062, 1762000178, -555599894191539453L, -21710L, false, true, (char) 18040, (char) 3014,
        Double.longBitsToDouble(0x3fe852259f0b6fd7L), Double.longBitsToDouble(0x3f952c4d4e264bc0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\ud986\udda0\udbca\udc30\ud860\udec8\ud9a6\ude18\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\uda8a\udd46\ud8ea\udc9d\udaae\udf08\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55\udbff\udc6c\ud903\udd55\udb74\udd59\ud9c3\udfcf\udbb6\udc73\udae0\udf82\ud959\udc8d\ud868\udf50\u245c\uda40\udccb\uda7e\udd03\ud8f2\udfcd\ud963\udf59\ud94e\udd9d\udb4a\udc64\ud991\udf03\udb28\udfae\ud9af\udc8d\ud824\udfb8\ud97d\udd91\uda46\udcb1\udb86\ude12\ud89b\udf10\ud836\ude19", "\u666c\u6aff\uc9e1\u2b46", "\ud955\uddc6\uda38\ude42\udbd2\udd31\ud8c9\udffb\uda77\udc1e",
        2, 66649, -1260025892, 2042439534287660757L, 88600L, false, true, (char) 56501, (char) 18737,
        Double.longBitsToDouble(0x3fe936d411415bfdL), Double.longBitsToDouble(0x3fd666522b964102L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\ud986\udda0\udbca\udc30\ud860\udec8\ud9a6\ude18\udbce\udeb7\ud972\uddaa\uda1b\udd3f\ud8f2\ude35\uda8a\udd79\ud8ea\udc9d\uda4e\udc96\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55\udbff\udc6c\uda35\udf45\uda7a\udf3c\ud96d\udf15\ud960\udcf1\udae0\udf82\ud959\udc8d\ud868\udf50\u245c\uda40\udccb\uda7e\udd03\ud8f2\udfcd\ud963\udf59\ud94e\udd9d\udbe9\udc93\ud99e\ude4b\udb28\udfae\ud9af\udc8d\ud824\udfb8\ud97d\udd91", "\u8223\uc23b\u1887\u86e9\u666c\u6aff\uc9e1\u267c\u20d3\u6f4c\u1927\u4275\u2d3d\u5de4\uaa4b\u875d\ube68\u6195\u1491\u9f0a\u21d6", "\ud9ba\ude3b\uda99\udc91\udac7\udcf5\udae9\udd84\uda2b\udc38\ud903\udf09\ud81c\udfa8\udaf8\uddfe\ud8c4\udff2\ud909\udfd9\uda86\udf2f\uda71\udd93\udad9\udc06\udbc8\udd62\ud81f\udd7c\ud8af\udcb9\ud9b5\udc50\ud923\uddd4\ud9d2\ude36\u53cc\uda3c\udffa\udbba\udff0\udb44\udef4\ud868\udf1c\uda32\uddb4\udbdf\udd8d\ud9b5\udf42\ud979\udd92",
        -1, 47210, 1818148193, 6678301994712243208L, -82180L, true, true, (char) 29099, (char) 21712,
        Double.longBitsToDouble(0x3fea1a5488fa7475L), Double.longBitsToDouble(0x3fe3ba16336613eeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b", "\ud7c8\u9bee\ud334\u36f9\ucd87", "\uda0a\udc4b\uda6b\udd71\udab5\udf01\ud87f\udc90",
        11, 45128, 513769918, 6665663702506504464L, -39820L, true, false, (char) 46979, (char) 7300,
        Double.longBitsToDouble(0x3fba648cbdbe6e18L), Double.longBitsToDouble(0x3fdbae6410e0007aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda06\udf9e\ud986\udda0\udbca\udc30\ud860\udec8\ud9a6\ude18\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\uda8a\udd46\ud8ea\udc9d\udaae\udf08\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55", "\u4b47\u74c4\u3015\u48b1\ud184\ua012\u9793\u63cc\u4149\u8419\u2cb8", "\ud99e\ude4b\udb28\udfae\ud9af\udc8d\ud824\udfb8\ud97d\udd91\uda46\udcb1\udb86\ude12\ud89b\udf10\ud836\ude19\ud991\udd64\udbd3\udef4\ud840\udcbf\u8550\udb1e\udeb8\ud99a\udd8b\ud91f\uddb5\ud8b0\udfe2\ud903\ude77\udb18\udec6\ud89f\udc3d\ud973\uddf2\udae4\udd06\ud9d6\ude1b\udb83\udef6\udb77\udc6d\uda68\udc07\ud941\udd5c\udaff\udf34\ud86b\udd6c\ud920\udd09\ud96d\udf76\ud9ce\udd03\ud84d\udd55\ud882\uddf9\ud83e\udfa8\udb97\udf8b\udbfa\udd53\ud952\uddba\ud800\udfec\udb9f\udd2e\uda0c\uded2\udaef\udc7e\ud965\ude6c\uda44\udf78\ud9ef\udf7b\ud9a8\udd20\u7880\uda5b\udee3\udabd\ude2d\ud9e5\udcea\ud903\udfff\udaeb\udc85\ud9dc\udff5\udb35\udc98\ud886\udc49\udb86\udc87\u5433\udb62\udc65\ud951\udca7\ub555\uda52\ude32",
        -2, 90294, 1847353975, 8756103540367270379L, 21623L, false, true, (char) 15162, (char) 4715,
        Double.longBitsToDouble(0x3fee4e17f8fa6aaaL), Double.longBitsToDouble(0x3fe1e0e2127a4ad0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\uda42\uddbe\ud851\udede\ud860\udf16\ud9fa\ude77\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a", "\uc47b\ud336\u61ab\u73b3\u397e\u66ea\u1775\u8edd\u74c4\u1fc9\u80ea\u6468\u8438\u9739\u8ece\u4149\u8419\u2cb8\ub89b\u8c96\u3980\u78f8", "\ud8ac\udd5e\uda46\udcb1\udb86\ude12\ud89b\udf10\ud807\uddf2",
        44, 6899, -1345467015, -3219062243729445049L, 96929L, false, true, (char) 55487, (char) 35803,
        Double.longBitsToDouble(0x3fba4edbd87de7d8L), Double.longBitsToDouble(0x3fd2c321d86e5e30L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "", "\000\000",
        -5, 87560, 118, 0L, -100000L, false, false, (char) 7383, (char) 62285,
        Double.longBitsToDouble(0x3fe4f82bb9d21e9fL), Double.longBitsToDouble(0x3fd105c8192609caL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b", "\ud7c8\u9bee\ud334\u9950\u6979", "",
        -5, 61120, 1149831676, 7567733139926818007L, -1424L, true, false, (char) 19478, (char) 50896,
        Double.longBitsToDouble(0x3fc6c259dd03f538L), Double.longBitsToDouble(0x3fda2bd324014d08L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\ud9a1\udc73\ud8f0\udd75\udbca\udc30\ud859\udee4\ud9a2\uddb1\ud9e2\ude5b\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\udb5a\udf05\uc6b0\udad6\uddce", "\u73b3\u7f6a\ub3c2\u191c\u2ac5\u23ab\u3015\u48b1\u1efe\u38a1\u3075\u8aff\u5c76\ua20d\ucf07\u9f6f\u0221\ua557\u5098\u1469\u7154\u04ba\uc0d0\u3e8a\u9d98\u7d65\u4a0f\u27f6", "\udb3b\udec6\ud9b0\udfde\ud867\udf0e\ud940\udc02\udb7d\udd12\udb86\udd9e\ud9df\udce4\ud9a8\udcba\ud8ce\udf00\ud984\udd04\udb7c\udc7d\uda8c\udfc8\ud8af\udc06\ud9bb\udf82\udba5\udfd9\uda76\udd15\udb79\udd04",
        -3, 69810, 518977544, 2685634117066096101L, -30115L, true, false, (char) 6208, (char) 49752,
        Double.longBitsToDouble(0x3fc76401750778bcL), Double.longBitsToDouble(0x3fc7c1d6854c7180L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\000", "",
        22, 52916, 0, 0L, 96434L, false, true, (char) 5, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\000", "", "",
        -5, 20872, 53916, 0L, -100000L, false, false, (char) 64767, (char) 5,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\ud986\udda0\ud846\ude30\ud860\udec8\ud9a6\ude18\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\uda8a\udd46\ud8ea\udc9d\udaae\udf08\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55", "\u8edd\u74c4\u3015\u48b1\ud184\ua012\u9793\u63cc\u98fd\u83c8\ub8e2", "\ud99e\ude4b\udb28\udfae\ud9af\udc8d\ud824\udfb8\ud97d\udd91\uda46\udcb1\udb86\ude12\ud89b\udf10\ud87b\udd5d\ud9a3\udd03",
        21, 52687, -749496334, -3124674302367852399L, 4000L, true, false, (char) 60227, (char) 41824,
        Double.longBitsToDouble(0x3fe89b04e85dae41L), Double.longBitsToDouble(0x3fd39773e4acea7cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\ud986\udda0\udbca\udc30\ud860\udec8\ud9a6\ude18\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a\uda8a\udd46\ud8ea\udc9d\udaae\udf08\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55", "\u8edd\u74c4\u3015\u48b1\ud184\ua012\u9793\u3543\u4149\u8419\u2cb8", "\ud99e\ude4b\udb28\udfae\ud9af\udc8d\ud824\udfb8\ud97d\udd91\uda46\udcb1\udbb0\udc48\ud8a8\udd4b\ud836\ude19\ud991\udd64\udbd3\udef4\ud840\udcbf\u8550\udb1e\udeb8\udb97\ude48\udb65\udf0f\ud9ca\udeb9\udbe8\udf26\ud900\udc4f\ud8d1\udc13\udbd5\udd09\udb4c\udc75\ud92f\udedd\udbf0\udf42\uda2f\ude53\ud85a\uddcc\u98c0\ud8ca\udcd9\uda99\udd1a\u5840\ud919\udd39\u86ca\ud8c1\udf2b\udb8a\ude85\udb31\udf3d\ud8ca\uded4\ud913\ude28\uda10\ude9a\ud832\udc62\ud986\udf3e\udb0d\udc24\ud957\ude1b\ud99b\udfa1\ud9e3\udfee\ud9b5\udc91\udac8\udf9d\ud84f\udee1\ud832\ude92\uda16\uddde\ud80d\ude35\ud9a9\udcb4\udbb7\udce4\ud864\udd00\udb2c\udcec\uda3b\ude2a\ud8d0\udd62\ud8f6\udc68\uda64\udca5\ud99f\udc17\udb87\udc03\udbc9\ude36\ud944\ude14\udbc6\udfca\ud991\udf8a\uda58\udd95\uda58\uddd6\ud817\udd24\udbc2\ude51\ud8f1\uddd1\udbb4\udfa9\ud962\udd10\udba8\udeec\udb21\udd3a\uda09\udfdf\udb6f\ude42\udb7d\udd5e\ud963\ude57\udb64\udcf3\udbb1\ude00\ua951\ud97a\udf1c\u17cf\udaec\udf48\ud99f\udfa8\ud8e8\udda3\udbaa\udea4\ud9a3\udde6\ud8f0\udea1\udbe3\udeeb\ud896\udffe\ud9e2\udd0d\ud86b\udd6d\ud89a\udc23\ud97b\ude7a\ud9c8\udc0e\udba1\udec5\ud9ac\udf02\udb6e\udf25\ud9c8\udc0d\ud8db\ude2c\uda8c\udfa0\udbfd\udfaa",
        46, 12607, -1767297155, 2054984775870813176L, 23057L, false, false, (char) 65297, (char) 13414,
        Double.longBitsToDouble(0x3fe4c825737b2405L), Double.longBitsToDouble(0x3fdba4cc94159e82L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\ud986\udda0\udbca\udc30\ud860\udec8\ud841\udf26\u6ca4\udaf4\ude1c\ud8b0\udf59\uda7c\udd6a\uda8a\udd46\ud8ea\udc9d\udaae\udf08\udbd7\ude05\ud9a2\udf62\uda9f\udc62\ud9e4\udf55", "\u8edd\u74c4\u3015\u48b1\ud184\ua012\u9793\u3543\u4149\u8419\u2cb8", "\ud99e\ude4b\udb28\udfae\ud9af\udc8d\ud824\udfb8\ud97d\udd91\uda46\udcb1\udbb0\udc48\ud8a8\udd4b\ud836\ude19\ud991\udd64\udbd3\udef4\ud840\udcbf\u8550\udb1e\udeb8\udb97\ude48\udb65\udf0f\ud9ca\udeb9\udbe8\udf26\ud900\udc4f\ud8d1\udc13\udbd5\udd09\udb4c\udc75\ud92f\udedd\udbf0\udf42\uda2f\ude53\ud85a\uddcc\u98c0\ud8ca\udcd9\uda99\udd1a\u5840\ud919\udd39\u86ca\ud8c1\udf2b\udb8a\ude85\udb31\udf3d\ud8ca\uded4\ud881\udcef\uda10\ude9a\ud832\udc62\ud986\udf3e\udb0d\udc24\ud957\ude1b\ud99b\udfa1\ud9e3\udfee\ud9b5\udc91\udac8\udf9d\ud84f\udee1\ud832\ude92\uda16\uddde\ud80d\ude35\ud9a9\udcb4\udbb7\udce4\ud864\udd00\udb2c\udcec\uda3b\ude2a\ud8d0\udd62\ud8f6\udc68\uda64\udca5\ud99f\udc17\udb87\udc03\udbc9\ude36\ud944\ude14\udbc6\udfca\ud991\udf8a\uda58\udd95\uda58\uddd6\ud817\udd24\udbc2\ude51\ud8f1\uddd1\udbb4\udfa9\ud962\udd10\udba8\udeec\udb21\udd3a\uda09\udfdf\ud88b\udf72\udbc4\ude87\ud963\ude57\udb64\udcf3\udbb1\ude00\ua951\ud97a\udf1c\u17cf\udaec\udf48\ud9c2\udfa8\ud8e8\udda3\udbaa\udea4\ud9a3\udde6\ud8f0\udea1\udbe3\udeeb\ud896\udffe\ud9e2\udd0d\ud86b\udd6d\ud89a\udc23\ud97b\ude7a\ud9c8\udc0e\udba1\udec5\ud9ac\udf02\udb6e\udf25\ud9c8\udc0d\ud8db\ude2c\uda8c\udfa0\udbfd\udfaa\ud950\udc52\ud9f3\udee1\udb20\udd47\ud8cf\udf72\uda9b\udcf2\u7e9a\uffd3\ud8cd\udd26\uda99\udeb3\uda8d\ude36",
        27, 93187, -817763910, 3530894716976057301L, -29534L, false, true, (char) 25515, (char) 45969,
        Double.longBitsToDouble(0x3fe37b62987f5896L), Double.longBitsToDouble(0x3fe92414b7934d4aL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 0, "\ud91f\udd5d\ud982\udc6a\ud8cb\udd37\000\000\000\udbd9\udd6b\ud9b6\udd7d\ud9a0\uddc5\ud94a\udf3d\udbf7\udec1\udb97\udfab\ud934\ude32\udaab\udcfc\u1bcb\udaa1\udc2f\ud88c\uddcd\ud9a0\udd70\udbbc\udd1d\uda9b\uddb1\ud86d\udd6d\uda1b\uddfa\ud8d0\udf43\ud8a7\udd09\ud951\udda7\udbd6\udff2\udbe9\udc13\ud80a\udc44\udadd\uddca\udad5\udc7d\ud82f\ude6d\ud80c\udc96\udb9f\udd51\udb7c\ude0d\udb9f\udcef\udbef\udd00\u7689\udb30\udce0\ud866\udead\ud82c\uddf6\udb3b\uddd4\ud8fe\udc55\ud9a6\udf66\udbce\udd49\ud86e\udca1\ud809\udefd\udb98\udf7d\ud8ad\udea8\uda6b\ude96\udb43\ude1f\uda13\udc5b\ud808\udeaf\udb52\udd35\ud8e6\udfe9\uda72\udda0\ud864\ude23\ud86a\udd59\ud959\udfc4\udb5d\udc6b\uda29\uddb9\ud9c1\udf11\uda8f\udc8e\uda2e\udede\ud9cd\udc24\udaed\udc8e\ud89a\udf10\ud909\uddb1\ud974\udc0d\ud834\udd20\ud831\udf8c\udbb4\ude24\ud837\udf9a\ud85e\udc7b\ud841\udcc4\uda28\udf13\uda95\ude63\udabd\udf64\ud131\u9ed0\udb04\udf8a\ud8c6\udd72\ud8fd\udd98\udb45\udc76\uda64\udd4a\uda8f\udedf\ud9cc\udc57\ud960\udfab\ud8dd\ude38\udb39\udc59\ud92e\udcec\ud82f\udf4b\udb9c\ude38\ud875\uddad\ud966\udf8c\ud86a\udf8e\ud80f\udcf6\ud8d7\udf0b\udaf3\udf20\ud96f\udc22\udbd4\ude06\ud858\udf4e\ud935\udc05\udb6b\udc5a\ud9bd\udcf7\udad0\udd37\udbf0\ude9d\udac4\udfa4\uda5f\udcb8", "\ucf64\ua220\ud0f5\u30c0\ucc41\uc2e7\u49d6\u2d1f\u3bff\u5019\u0211\u92c8\u5a73\u8219\u7320\u2313\u5cdd", "\uda1d\udfb5\uda83\udf27\ud8af\udf7a\uda7d\udc2a\ud995\ude6a\ud925\udf1a\ud937\udd71\uda02\uddc6\ud076\u93f0\ud918\ude89\ud9ed\udffb\uda31\udced\uda73\udf98\udb61\udc05\uda96\uddb9\uda7b\udd11\ud929\udeae\ud988\udec8\udaa2\udc73\ud9e2\udf11\ud867\udc50\udba8\udd90\uda7c\udeda\uda67\udf15\uda94\udea7\ud959\udd7c\ud833\ude35",
        23, 73660, -1256148864, 98252271207569575L, 72708L, false, false, (char) 11621, (char) 14371,
        Double.longBitsToDouble(0x3fbd3fc7df68e4f0L), Double.longBitsToDouble(0x3fe19d730b8e3d44L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 0, "\ud91f\udd5d\ud982\udc6a\ud8cb\udd37\000\000\000\udbd9\udd6b\ud9b6\udd7d\ud9a0\uddc5\ud94a\udf3d\udbf7\udec1\udb97\udfab\ud934\ude32\udaab\udcfc\u1bcb\udaa1\udc2f\ud88c\uddcd\ud9a0\udd70\udbbc\udd1d\uda9b\uddb1\ud86d\udd6d\uda1b\uddfa\ud8d0\udf43\ud8a7\udd09\ud951\udda7\udbd6\udff2\udbe9\udc13\ud80a\udc44\udadd\uddca\udad5\udc7d\ud82f\ude6d\ud80c\udc96\udb9f\udd51\uda2b\udc65\ud854\uddab\udace\udc21\udafd\udfa4\udb30\udc76\ud866\udead\ud82c\uddf6\udb3b\uddd4\ud8fe\udc55\ud9a6\udf66\udbce\udd49\ud86e\udca1\ud809\udefd\udb98\udf7d\ud8ad\udea8\uda6b\ude96\udb43\ude1f\uda13\udc5b\ud808\udeaf\udb52\udd35\ud8e6\udfe9\uda72\udda0\ud864\ude23\ud86a\udd59\ud959\udfc4\udb5d\udc6b\uda29\uddb9\ud9c1\udf11\uda8f\udc8e\uda2e\udede\ud9cd\udc24\udaed\udc8e\ud89a\udf10\ud909\uddb1\ud974\udc0d\ud834\udd20\ud831\udf8c\udbb4\ude24\ud837\udf9a\ud85e\udc7b\ud841\udcc4\uda28\udf13\uda95\ude63\udabd\udf64\ud131\u9ed0\udb04\udf8a\ud8c6\udd72\ud8fd\udd98\udb45\udc76\uda64\udd4a\uda8f\udedf\ud9cc\udc57\ud960\udfab\ud8dd\ude38\udb39\udc59\ud92e\udcec\ud82f\udf4b\udb9c\ude38\ud875\uddad\ud966\udf8c\ud86a\udf8e\ud80f\udcf6\ud8d7\udf0b\udaf3\udf20\ud96f\udc22\udbd4\ude06\ud858\udf4e\ud935\udc05\udb6b\udc5a\ud9bd\udcf7\udad0\udd37\udbf0\ude9d\udac4\udfa4\uda5f\udcb8", "\ucf64\ua220\ud0f5\u30c0\ucc41\uc2e7\u49d6\u2d1f\u3bff\u5019\u0211\u92c8\u5a73\u8219\u7320\u2313\u5cdd", "\uda1d\udfb5\uda83\udf27\ud8af\udf7a\uda7d\udc2a\ud995\ude6a\ud925\udf1a\ud937\udd71\uda02\uddc6\ud076\u93f0\ud918\ude89\ud9ed\udffb\uda31\udced\uda73\udf98\udb61\udc05\uda96\uddb9\uda7b\udd11\ud929\udeae\ud988\udec8\udaa2\udc73\ud9e2\udf11\ud867\udc50\udba8\udd90\uda7c\udeda\uda67\udf15\uda94\udea7\ud959\udd7c\ud833\ude35",
        23, 73660, -1256148864, 98252271207569575L, 72708L, false, false, (char) 11621, (char) 14371,
        Double.longBitsToDouble(0x3fbd3fc7df68e4f0L), Double.longBitsToDouble(0x3fe19d730b8e3d44L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda15\udd9b\uda42\uddbe\ud92c\udfc7\ud860\udf16\ud9fa\ude77\udbce\udeb7\ud972\uddaa\ud8b0\udf59\uda7c\udd6a", "\ua13a\u7128\u61a8\u73b3\u397e\u42c4\u1245\u879c\u74c4\u1fc9\u80ea\u6468\u8438\u9739\u8ece\u4149\u8419\u6a54\u4ed4\u8c96\u3980\u78f8", "\ud8ac\udd5e\uda46\udcb1\udb86\ude12\ud97e\uddc2\ud811\udd0b",
        44, 6899, -1345467015, -3219062243729445049L, -21009L, true, false, (char) 6815, (char) 33788,
        Double.longBitsToDouble(0x3fe7bc192c860612L), Double.longBitsToDouble(0x3fe12abce58a93f8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.enums.ValuedEnum|getEnum|java.lang.Class,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
