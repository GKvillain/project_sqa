package org.apache.commons.lang.enums;
import org.junit.Test;
import static org.junit.Assert.*;
public class ValuedEnum_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud873\udce8\udbf4\udd64\ud972\udee7", "\ubcdd\u3bda\u79c7\u5f08\u0f89\u12ab\u80ee\u71b9\ubbf5", "\ud86f\udf93\ud940\udc8c",
        31, 45770, -1741671960, -3422048577591991079L, 67192L, true, true, (char) 60640, (char) 55084,
        Double.longBitsToDouble(0x3fe5770af743555eL), Double.longBitsToDouble(0x3fe4874789c9671bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc7a\ud873\udce8\udbf4\udd64\ud972\udee7", "\ua0b8\u3c41\u79c7\u5f08\u0f89\u9a68\u80ee\u71b9\ubbf5", "\ud86f\udf93\ud940\udc8c",
        31, 13890, 698921816, -3421920407177943847L, 67192L, true, true, (char) 60640, (char) 55084,
        Double.longBitsToDouble(0x3fe5770af743555eL), Double.longBitsToDouble(0x3fe4874789c9671bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd9\ude20\ud873\udce8\udbf4\udd64\ud972\udee7", "\ubcdd\u3bda\u79c7\u5f08\u0f89\u12ab\u80ee\u71b9\ubbf5\u6ef9\u9a30\u06b7\ua03e\u52c2\ud5a7\u26de\ua8a9\uc066\u464e", "\ud973\udf20\ud914\udfd2\udbc6\ude72\udb81\ude73\udba8\udfb5\ud851\udde7\ud9f6\udca3\ud9b7\udc87\ud8cf\udc6d\udb6e\udc00\ud9c1\udd26",
        13, 82931, 437395277, 62781897210057686L, 99573L, true, false, (char) 53735, (char) 47095,
        Double.longBitsToDouble(0x3fb9e393985844d0L), Double.longBitsToDouble(0x3febf8f1a6977b1dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud873\udce8\udbf4\udd64\ud972\udee7", "\ubcdd\u3bda\u79c7\u5e9b\u0fd8\u12ab\u80ee\u71b9\ubbf5", "\ud86f\udf93\udba0\udffe",
        31, 45770, -1741671960, -3422048577591991079L, -90491L, false, false, (char) 34316, (char) 29857,
        Double.longBitsToDouble(0x3fe4874789c9671bL), Double.longBitsToDouble(0x3fd1819c3dec3818L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udaea\udedd\uda40\udddd\ud8e7\udc80\u429e\ud908\udef4", "\ubc30\u3bda\u1a7e\u403d\u0f89\u12ab\u6f6b\uc057\u2ca5", "\ud86f\udf97\ud940\udc8c\udaa6\udccd\u0443\udb4e\udfc9\ud8fb\udfd5\udb9b\udd40\ud9a3\udcb1\ud86c\ude72\udaf2\udee0\ud973\udec2\ud914\udfd2",
        11, 85474, 1432247982, -1661512413169896816L, -45829L, false, true, (char) 53765, (char) 54509,
        Double.longBitsToDouble(0x3fee3e0361bcad5cL), Double.longBitsToDouble(0x3fe3c60a8c8e9587L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud873\udce8\udbf4\udd64", "\u9508\u818d\u1e2e\ub0cc", "\uda6a\udd40\udb63\ude97\ud8e4\udf3d\ud944\udf58\udb36\udc3b\udbdf\udcc2\ud813\ude44\ud914\udddc\udaa6\udccd\u0443\udbd1\udd49\uda0d\udf82\ud8f5\uddae\udb3b\udefd\uda47\udf88\uda6a\ude1c\u66b8\ud914\udf4a\udbc6\ude72\udb81\ude73\udba8\udfb5\ud851\udde7\ud9f6\udca3\ud9ca\udf70\ud9d0\ude9b\ud953\udd2b\ud846\udcde\uda82\ude72",
        51, 23194, 1329502522, -1688638188310420152L, -36052L, true, false, (char) 62704, (char) 37215,
        Double.longBitsToDouble(0x3f90b75e7a588740L), Double.longBitsToDouble(0x3fe3f7de10c83794L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud873\udce8\udbf4\udd64\ud972\udee7\udb15\udcd7\udbdb\udea0", "\u5f63\u2e06\ucef4\u12ab\u80ee\u71b9", "\udbcd\ude88\ud86f\udf93\ud940\udc8c",
        31, 45770, -1741671960, -3422048577592010805L, 67192L, true, true, (char) 60640, (char) 55084,
        Double.longBitsToDouble(0x3fe5770af72dad07L), Double.longBitsToDouble(0x3f9d6741392cf7e0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud873\udce8\udbf4\udd64\ud972\udee7", "\ubcdd\u3bda\u79c7\u5f08\u0f89\u12ab\u80ee\u71b9\ubbf5", "\ud86f\udf93",
        32, 14826, 259111770, -7480424109356977933L, -86425L, true, true, (char) 4698, (char) 46955,
        Double.longBitsToDouble(0x3fce7357d36e63b0L), Double.longBitsToDouble(0x3fb097bab5770af0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud92b\udee5\000\000", "\u5fff\u1807\000\000\000\u3d55\u80ee\u00f3\ua811", "",
        32, 97401, 0, 1112876576417001960L, -76665L, true, true, (char) 33803, (char) 188,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbbd\udf1b\ud873\udce8\udbf4\udd64\ud972\udee7", "\000", "",
        7, 47397, -146361086, 2230887365080996339L, -30077L, false, false, (char) 67, (char) 55880,
        Double.longBitsToDouble(0x3feb9352335a170bL), Double.longBitsToDouble(0x3fde80f711e73060L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud873\udce8", "\ub0a9\uca31\u94d8\u3bda\u79c7\u5f08\u0f89\ub502\u80ee\u71b9\ubbf5", "",
        59, 74297, 386596978, 1112876576417001960L, 67192L, true, true, (char) 60640, (char) 55084,
        Double.longBitsToDouble(0x3fe5770af743555eL), Double.longBitsToDouble(0x3ece200000000000L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud873\udce8\udbf4\udd64\ud972\udee7\udb15\udcd7\udbdb\udea0\udb52\udfdc\udba1\udfee\ud81d\udd18\uda7c\udded\udba9\udc89\ud967\udc7e\ud815\ude10\ud90c\udfed\ud922\udd21\udb36\udc3b\udbdf\udcc2\ud86f\udf93\ud940\udc8c\udaa6\udccd\u0443\udb4e\udfc9\uda03\ude26\udb9b\uddd1\ud9a3\udcb1\udbc6\udc48\ud83e\udc0a\ud973\udf20\ud914\udfd2", "\ucbdb\ubbee\ua4c3\u1afe\uabd7\u1259%\u753b\u2180\u833c\u4fe5\u4838\u585f", "\ud8d3\uded0\ud9fa\udf11\ud9e7\udfd6",
        53, 53245, -604083629, 3778421612727302037L, -84837L, true, true, (char) 41775, (char) 35376,
        Double.longBitsToDouble(0x3fd710d318bc3040L), Double.longBitsToDouble(0x3fe2e2b30eb74469L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\ud8e4\uddb0\ud873\udce8\udbf4\udd64\ud972\udee7\uda82\uddae\udb88\udd75\udb52\udfdc\udba1\udfee\ud81d\udd18\uda7c\udded\udb91\ude02\ud967\udc7e\ud815\ude10\ud90c\udfed\ud922\udd21\udb36\udc3b\udbdf\udcc2\ud86f\udf93\ud940\udc8c\udaa6\udccd\u0443\udb4e\udfc9\uda03\ude26\udb9b\uddd1\ud89d\udc2f\uda47\udf88\uda6a\ude1c\ud973\udf20\ud914\udfd2\udbc6\ude72\udb81\ude73\udbbb\udde0\ud84c\ude5c\ud9f6\udca3\udba5\udd7d\udb05\uddd9\uda1f\udcbd\udbc3\udef8\udb97\ude2c\uda33\udf41\ud96f\udf08\uda06\udea4\udaa2\uddda\uda66\udf6e\ud883\udd76\udaa7\uddd4\udb07\ude61\udb4f\udf18\ud833\udf7a\ud84f\udcad\ud930\udec6\ud865\udd6c\ud98f\udf7f", "\u6d17\ub036\ucea8\u22d2\uc041", "\udb21\udf2c\ud902\udc6d\ud9d2\udf8a\ud81d\udc96\udb22\udd14\udbb4\ude05\ud8c4\udde9\udbc1\udd21",
        56, 76520, -47974243, -2848678518264886165L, 24115L, true, true, (char) 51662, (char) 23952,
        Double.longBitsToDouble(0x3fe3e2bc3aba30eaL), Double.longBitsToDouble(0x3fcb3dd1b0cf1fd0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\000\000", "\ub7e9", "\udbf2\udc0b",
        -5, -1000, 13091015, 0L, -100000L, false, false, (char) 0, (char) 61440,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3eb1800000000000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb1f\udf9f\udbd3\udc7a\ud873\udce8\udbf4\udd64\ud972\udee7\udb15\udcd7\ufcd1\ud871\udc3f\uda64\udc14\udbb2\udfe7\uda7c\udded\udb91\ude02\ud821\udc7b\ud815\ude10\ud90c\udfed\udab9\udccd\udae1\uded1\udbdf\udcc2\ud86f\udf93\ud940\udc8c\uda8e\uddca\udbbb\udd18\ud9d7\uddcc\ud8a2\uddf8\udb82\udd23\ud9a3\udcb1\uda47\udf88\uda6a\ude1c\ud973\udf20\ud914\udfd2\udbef\udc46\uda9e\udffb", "\ua4c3\u6622\u5e96\ube4d", "\udb78\udd27\u375a\u3027\udadb\udcd2\ud855\ude5a\ud95b\udfe3\u3491\ud983\uddee\ud80a\udd0f\ud9e1\uddf8\uda4d\udd16\ud8ba\udc83\ud9dc\udc15\ud8c1\ude74\udbd2\udf83\u7336\ud965\udc51\uda3f\udfd4\ud948\uddb4\udbde\udec4\uda35\udc6f\ud99c\udf9c\uda0c\uddea\udbd3\udebe\ud84d\ude80\ud875\udccf\ud957\udca2\ud86a\udfa3\uda26\udc89\udb0d\ude4e\udaa7\udd4e\udba0\udd02\udbbd\udd6b\ud8b7\udc8a\udb5c\udef3\udac7\udf14\uda0c\uddec\uda89\udfa7\udbe6\udcd3\uda3c\uddee\ud82d\udf97\uda72\udd74",
        17, 39355, -1245785796, -1068127783246460077L, -66142L, false, false, (char) 16613, (char) 25118,
        Double.longBitsToDouble(0x3fb587d11e1bf888L), Double.longBitsToDouble(0x3fe99b13b1a4702dL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc7a\ud873\udce8\udbf4\udd64\ue7ca", "\ua0b8\ua1da", "\udb91\ude02",
        8, 75941, 563042803, 7858520438831124771L, -100000L, true, true, (char) 39136, (char) 30720,
        Double.longBitsToDouble(0x3fe5770af743555eL), Double.longBitsToDouble(0x3ece24019c6c0000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\u557d", "", "",
        36, 20479, 1845928410, 1323429380730896583L, 31072L, true, false, (char) 30952, (char) 13379,
        Double.longBitsToDouble(0x3fd236d0fd3de15aL), Double.longBitsToDouble(0x3fbd5a10c0078838L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfcc", "\u00df\u7d8a\ub0a9\uca31\ua0b8\u3c41\u79c7\u5f08\u0f89\u9a68\000", "",
        17, 21502, -251148171, 7658048223844171890L, -76665L, true, true, (char) 33803, (char) 4698,
        Double.longBitsToDouble(0x3fd182a54001357cL), Double.longBitsToDouble(0x3e0097ba80000000L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ud873\udce8\udbf4\udd64\ud972\udee7", "\ud5dd\u3bda\u79c7\u5f08\u0f89\u12ab\u80ee\u71b9\ubbf5", "\ud86f\udf93\ud940\udc8c",
        31, 45770, -1741671960, -3422048577843649319L, 67192L, true, true, (char) 60640, (char) 55084,
        Double.longBitsToDouble(0x3fe5770af743555eL), Double.longBitsToDouble(0x3fe4874789c9671bL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u00e4\000\000\u7834\u19a8\ubcdd\u3bda\u79c7\u5f08\u0f89\u12ab", "\000",
        0, 54464, 51317, 7658047910311606130L, -87224L, true, false, (char) 41983, (char) 17798,
        Double.longBitsToDouble(0x3eb5000000000000L), Double.longBitsToDouble(0x3fd182a543e7357cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "", "\u00e4", "",
        20, 46564, -1176739841, 7928201709633782787L, 58547L, false, true, (char) 43907, (char) 0,
        Double.longBitsToDouble(0x3e22300000000000L), Double.longBitsToDouble(0x3ec5a02418000000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbbd\udf1b\udbf5\udcc9\u31dc\uda34\udc68\u3875\000\000\000\000\ud93c\udd1e\ud909\udc3e\ud966\udc23\ud815\udea4\ud90c\udfed\uda7f\udd33\udb36\udc3b\udbdb\udea1\udacd\udd0c\ud92e\udece\udaa6\udccd\ud978\udf9a\udb4e\udf0a\ud89c\udd20\udb26\uded3\uda0f\udca8\ud926\udd64\uda2d\udf02\ud903\udf59\ud9dc\udf15\u8dae\ud8df\udec8\udba1\udca0\ud8b1\udfe4\ud878\udc37\uda65\udf97\ud925\ude4c\ud8a0\udd05\udb49\udd5b\u9d13", "\ubea4\u7d0c\ubf96\ubb5e\u9358\u60f5\u054c\u1d45\u93d1\ub048\u595e\ucfff\u5928\u8bb5\u0452\ua80c\u8c4d\u3fd0\uc6e1\ud086\u44fb\ua51b\u1058\u3ac6\ua0e8\u9ca1\u9e43\ub4a9\u1c37\u2241\u9f9a\u0ca6\ub65d\u4daf\u6625\u0ab0\u088c\u1718\ub006\u2ac2\u0c1d\ud414\u35e9\u6416\u45d8", "\ud9c2\uddc4\u236c\u2556\ud9e6\udd3e\udb19\udce9\uda82\udf4a\udbbb\udc7a\udbdd\udd61\ue229\udb58\udfb9\ud9ff\udcb1\udbc8\udf16\udbc5\udee0\udbdf\udd34\ud854\udc48\uda30\uddfc\udb20\udd1a\udafa\udfcc\ud93d\udd9b\udb9c\udf94\ud4a7\uda7b\ude43\udb29\udf01\udbf4\udd86\udb61\udecf\uda54\uddf5\ud9b6\ude51\u62e3\u6ab3\udb65\udf8b\ud8f4\udd3e\ucfba\ud8fa\udf7e\udbed\uddae\udb95\udfb7\udb9b\ude8c\udbab\udf5e\udb7a\udc34\udb49\udd54\ud8bf\udfc4\udbca\udfb5\udbb2\udfd0\udb96\udf80\ud8f8\udfa4\udbb9\udfb7\ud8ba\udf1f\udb91\udc36\udb5d\udd47\ud825\udcc2\ud937\ude5d\ud9ad\udffa",
        -3, 4620, -821803867, -6860653455998960915L, -69299L, false, false, (char) 16149, (char) 65012,
        Double.longBitsToDouble(0x3fa2d7c91c1ba3c0L), Double.longBitsToDouble(0x3fefaeab8656e914L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\udb01\udfe2\udbd3\udc1b\ue53e\uda79\ude15\ud972\udee7\ud95f\udf9c\u3f84\udb7a\udcdc\udadd\udfc1\ud932\udcfb\ud866\uddb9\ud8ed\uddc5\uda6f\udefb\ud9a6\udd15\ud954\udcfc\udb33\udc4f\ud880\udc47\udb05\udca1\ud8bd\uded2\udbbc\uddaa\ud9bf\udffa\udbd5\ude91\udaf0\ude82\uda03\ude26\udb9b\uddd1\ud9a3\udcb1\udaac\ude2d\ud81e\ude17\ud989\udf05\ud9a7\udee3\udbc6\udd9f\ud9c0\udf5e\udbbe\ude6a\uda2c\udd6b\ud9f6\udc5c\udac5\udf6e\ud9c9\udc20\udb0f\ude12\ud96c\udd97\udac1\udc45\uda37\udce5\uda9f\udd9d\ud98e\udeb8\ud849\udf49\udabf\ude87\udab7\udf95\udbed\udc58\udbe7\udfc4\ud9d4\udfee\udac8\udecb\udb0f\udcdd\ud831\udf2d\udae1\udee5\udadd\udfc3\ud885\udcc9\ud804\ude2c\ud93a\udf61\ud9db\uddaf\ue5e7\ud845\udc91\uda91\ude47\udbd4\ude0a\ud8f2\udeec\udad6\udfde\udb57\ude12\ud939\udd8e\ud8d6\udef7\ud882\udec3\uda24\udec7\ud8d3\ude66\udaa7\udf36\uda7f\udd08\uda74\udcfb\udb0a\udf2e\udb57\udefc\ud841\udf92\ud858\udebb\uda97\udc8b\uda89\udc65\uda27\udedf\udb1a\ude77\ud9d2\udc61\uda27\udd50\udb4e\udeb2\udbd1\uddf6\u51bc\ud876\udf30\ud9da\udd6a\ud946\udfdc\ud99d\ude7e\ud851\udc56\uda2e\ude52\udbaf\udf44\uda27\udd60\ud9cc\udc14\udbab\udf9d\ud81d\udd22\ud91e\udd87\udaea\udda2\udb3a\ude6e", "\u2cf5\u61e3", "\udae9\udd0a\udada\udfac\ud9d4\udf03\uda6b\udc7f\udb0b\udc5c\udbb7\ude58\uda5b\udc35\uda0b\udfe4\ud82a\ude3c\ud81a\udff7\ud929\ude04\ud853\ude70\ud9fa\udcc1\uda9d\udfa6\ud8f2\udfbb\udb31\udd4e\udba2\udf12\ud8ff\ude97\ud804\udf95\ud875\ude03\ud87d\udf8a\ud9ac\udf6b\ud98c\udfa2\udaa2\udd69\udbc9\ude58\ud9dc\ude99\ud9f9\udf86\ud9c7\udf58\udb05\udf33\udb6e\ude8e\uda45\udca4\ud914\udc59\ud970\udf13\ud9e3\uddab\u6f64\udb57\udd32\udbad\udfd8\udb28\ude8f\ud8dd\udd59",
        54, 35143, -451657039, -2936262944496855838L, -68056L, true, true, (char) 43935, (char) 63024,
        Double.longBitsToDouble(0x3fe43e3edd51a485L), Double.longBitsToDouble(0x3fddf7519a2a9b40L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.enums.ValuedEnum|getEnum|java.lang.Class,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
