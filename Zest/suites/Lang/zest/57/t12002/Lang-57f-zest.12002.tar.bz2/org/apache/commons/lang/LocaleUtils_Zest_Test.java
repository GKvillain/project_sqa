package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class LocaleUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\ud92f\udd89\uda48\udef8\u92a2\u43fb\ud81f\udec8\udbb1\udcdd\ud9de\udc6c\ud92d\udd75\udad7\ude75\udb2c\udeaa");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\ud980\udd4d\ud972\udfaa\udaf5\uddee\uda8a\ude1c\ud801\udd39\udbb1\udcdd\ud9a9\udef1\udbdd\udc0f\ud98c\udf02\ud923\udfe9");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("\ud945\udcc4\udab1\udd30\ud97e\udca7\udbfa\udc1e\uda0a\udc66");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\ud8b1\udd6b\ud88e\udcf5\udb6e\udcde\ud9e1\ude78\udac2\ude60\ud892\udd28\udbf9\udd38\udb00\udce3\uda03\udfde\ucd71\uda1b\udc40\udb3d\ude38\uda79\udf93\uda81\udd7e\ud809\ude78\ud890\udcda\ud812\udc95\udba4\udfa0\uda20\ude2f\udacf\udcd4\udbfa\udf6b\udb90\udf93\uda49\udf82\ud967\udca4\ud996\udd63");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\ud950\udccb\uda48\udef8\u92a2\u43fb\ud8ed\udd2e\udbc0\udc81\ud9de\udc6c\ud92d\udd75\ud980\udc49\u5208\udb73\udef5\uda68\udf0d\ud86a\udd2a\u9313\ud9b1\udcc4\u8729\udb95\udd6f\ud992\udf5a\ud993\udc90\ud909\udfe9\ud9fa\udf7f\uda94\ude10\udb98\udc70\udb85\ude8b\ud81f\udc2c\u81c1\udb83\udd43\udbb2\udffa\uda4a\udd1e\ud984\ude80\ud9da\udc33\udb10\ude35\udbff\ude4b\udaee\udec3\udb59\udd94\udad2\udfaa\uda5a\udf06\ud9d0\udd87");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\udb81\udebb");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\u575d\000");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\ud8b4\ude36\uda48\udecf\uf189\u43fb");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("\000");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\udad1\udc44\uda48\ude73\ud9a7\udfe1\ud899\udcea\udb11\udc64\udbb8\udf97\udbb3\udff7\udb51\udd6b\udad7\ude75\u335c\ud81c\udd56\udb2f\udf16\ud902\uddb5\u2708\ud8e5\udd0f\uc0c3\udb10\udc83\udbf7\ude34\udb0d\udde5\uda5b\udef9\udb1a\udee1\udbf6\udf48\udb0d\udd72\udb9b\udc74\uda03\udfe9\ud802\udeae\ud9d1\uded5\ud8cf\udea9\ud96f\udf14\udb50\udc4b\u5c4a\uda74\udd5b\ud992\udd00\ud902\udf21\ud99d\udf84\udb0d\udc7d\ud96e\udcec\u887d\ud8ab\uded2\udaa4\udef4\ud945\ude89\udbd6\udc2d\udad3\uddc9\uda61\udefc\ud907\udd13\ud866\udc40\udad0\ude00\ud9e8\udc0b\ud95a\udfda\uda25\udced\ud808\udd08\ud83a\ude6d\ubb11\udb23\udfec\udaff\udfee\ud91b\udcbf\udb93\ude0f\uda10\udeb2\udb03\udc8c\udad4\uded8\ud939\udf6d\ud843\ude2f\ud830\ude8c\udb01\udf75\udb73\udef4\ue592");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[, nn, bg, kea, nds, zu, hsb, lv, vo, kkj, mer, sah, br, sk, ml, sv, cs, el, af, smn, dsb, khq, ji, agq, ebu, zh__#Hans, mn, teo, eu, wo, shi__#Tfng, ru, az, fa, nd, kk, az__#Cyrl, tk, hy, shi__#Latn, ksb, luo, lb, ne, no, my, ka, mgh, shi, kl, zh, saq, az__#Latn, ta, lag, bo, bez, kln, kw, vai__#Latn, ksh, ln, pt, gl, sr__#Cyrl, to, ga, qu, et, mua, in, ps, sn, rof, km, zgh, be, gv, es, dua, jgo, gsw, guz, mfe, ja, or, brx, te, sl, ha, sbp, fi, uz, bs__#Cyrl, sr__#Latn, sw, nmg, rm, bn, vai__#Vaii, kn, nnh, gu, lo, zh__#Hant, bs__#Latn, ky, mas, os, am, rw, iw, dav, lrc, ses, ce, mg, mr, ko, ak, seh, kde, dz, mgo, pa__#Guru, ast, yue__#Hans, pa, rn, tg, rwk, hu, twq, bm, tr, cgg, ksf, cy, sq, fr, de, lg, ff, sd, xog, so, kab, ms, nus, prg, ug, hi, vai, vi, dyo, mt, yav, eo, kam, ro, ee, pl, ur, uz__#Arab, se, chr, yue__#Hant, luy, as, it, uk, mzn, ii, tt, naq, tzm, fur, om, asa, fil, uz__#Cyrl, fo, hr, lt, ccp, lkt, is, si, en, ca, ks, nyn, yue, jmc, mk, pa__#Arab, bs, fy, th, ar, haw, dje, bas, uz__#Latn, sg, nl, ckb, sr, bem, da, wae, ig, gd, cu, vun, lu, ki, yo, nb, ti, kok, ewo]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\ud926\udef5\uda10\ude8c\ud9a7\udfe1\ud899\udcea\udb11\udc64\udbb8\udf97\udbb3\udff7\udb51\udd6b\udad7\ude75\ud993\udcd7\udb82\udc68\ud815\uddea\udb6c\udd7a\u2708\ud8e5\udd0f\uc0c3\udb10\udc83\udbf7\ude34\udb0d\udde5\uda5b\udef9\udb1a\udee1\ud84a\udebe\udb42\udfc3\udb9b\udc74\uda03\udfe9\ud802\udeae\ud9d1\uded5\ud8cf\udea9\ud96f\udf14\udb50\udc4b\uda77\udc90\udb7b\udd96\uda1f\udcf5\ud902\udf21\ud99d\udf84\udb0d\udc7d\ud96e\udcec\u887d\udb1f\ude2f\udbea\udebc\ud97d\uddc0\udbe5\udd96\uda88\udf04\uda61\ude7b\ud907\udd13\ud866\udc40\udad0\ude00\ud9e8\udc0b\ud95a\udfda\udb5f\udfea\ud808\udd08\ud83a\ude6d\ud852\udd07\ud8f8\udf6a\ud90f\udc77\ud962\udca8\udb93\ude0f\uda10\udeb2\udb03\udc8c\udad4\uded8\ud939\udf6d\ud843\ude2f\ud830\ude8c\udb01\udf75\udb73\udef4\ue592");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\ud926\udef5\uda10\ude8c\uda3d\uddd3\udab6\udc5f\ud90c\udd8c\ud98d\udf4f\udae4\udf95\ud9e5\udd2e\udad7\udd38\ud993\udcd7\udb82\udc68\ud815\uddea\udb6c\udd7a\u2708\ud8e5\udd0f\udbb9\udc26\udb10\udc83\udbf7\ude34\udb0d\udde5\uda5b\udef9\udac9\udf98\ud859\udd67\udb42\udfc3\udb9b\udc74\uda03\udfe9\ud802\udeae\ud9d1\uded5\ud8cf\uded6\ud96f\udf14\udb50\udc4b\uda77\udc90\udb7b\udd96\uda1f\udcf5\ud902\udf21\ud99d\udf84\udb0d\udc7d\ud96e\udcec\udbd8\udcf5\uda32\ude92\udaed\udf4f\ud97d\uddc0\udbe5\udd96\uda88\udf04\uda61\ude7b\ud907\udd13\ud866\udc40\udad0\ude00\ud9e8\udc0b\ud95a\udfda\udb5f\udfea\ud808\udd08\ud83a\ude6d\ud852\udd07\ud8f8\udf6a\ud90f\udc77\ud962\udca8\udb93\ude0f\uda9b\uddd9\uda98\udebc\udad5\uddcf\ud939\udf6d\ud843\ude2f\ud830\ude8c\udb01\udf75\udb73\udef4\ue592");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("\udaa0\udf43");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
}
