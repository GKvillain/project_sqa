package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class LocaleUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\udab4\udcbd\udb0c\udcc0\uda78\ude09\ud9a5\udd5b\uda00\ude87\ud814\udcfa\ud804\udec8");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\udab4\udcbd\udb0c\udcc0\uda78\ude09");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("\udb64\udea5");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\udab4\udcbd\udb0c\udcc0\uda78\ude09\ud9a5\udd5b\uda00\ude87\ud814\udcfa\ud9c9\udcd3\udb6c\udf1b\ud88f\ude1a\ud85c\udc32\ud838\ude5b\uda57\udfcf\ud82f\udcd2\udaca\uddb6\ud98e\udd0f\ud9fe\udc07\udb51\udecf\uda4c\uddfb\udb90\ude8b\udaf2\uddd8\ud90b\udfac\uda7f\udfc6\uda45\udd33\ud86b\udca2\ud8b9\udea4\udb6b\uddf3\u84b4\ud8fe\udfa9\udbc6\uddb2\uda0f\udfce\ud914\udfa8\udaaa\udc2c");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\udab4\udcbd\ud851\udd84\ud8a9\udec8\udadd\uddf0\ud9d1\ude0f\ud915\ude7b\ubd77\udaa8\udc4a\ud9be\udf6c\u0296\ud807\udc36\ud985\udffd\udb0c\udfd8\uda0a\udc00\ud9a3\ude4b\uf83a\u45df\udb4b\udd7d\udb35\udf76\udb08\ude8d\ud91e\uddfe\ud84a\ude44\ud934\udc4c\ud8e4\udc3e");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("\ud560\ud802\udf22\ud8ed\udc83\ud86b\udd28\ud84a\udf62\udb9f\ude5d\ud98a\udfe1\ud8b0\udc4a\ud88d\udd28\udaf0\udf73\ud909\udc0f\udabd\udd9e");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\uacb8\udbc3\udc39\uda87\udc8a\ud9a5\udd5b\ud92e\udf7c\ud814\udcfa\udb56\udd70\ud952\udc71\ud8b1\udd9b\ud871\udc9a\u827d\ud8eb\udfb6\ud82f\ude69\udb3d\uddcf\ud8d4\udccc\uda71\udc27\uda70\udc90\udb74\udf58\ud953\udd35\ud874\udfbe\uda2e\udda0\udaae\udc56\u75bf\ud8c8\udd3f\udbf8\ude7e\udb20\udcfd\udb39\udca3\ud9e3\udd49\ud839\udde2\udaa2\udde4\udbd8\udf1d\ua680\udb6e\udcd6\udb40\udf63\uda8c\udf48\udb6a\udc1a\ud85f\udf74");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[, nn, bg, kea, nds, zu, hsb, lv, vo, kkj, mer, sah, br, sk, ml, sv, cs, el, af, smn, dsb, khq, ji, agq, ebu, zh__#Hans, mn, teo, eu, wo, shi__#Tfng, ru, az, fa, nd, kk, az__#Cyrl, tk, hy, shi__#Latn, ksb, luo, lb, ne, no, my, ka, mgh, shi, kl, zh, saq, az__#Latn, ta, lag, bo, bez, kln, kw, vai__#Latn, ksh, ln, pt, gl, sr__#Cyrl, to, ga, qu, et, mua, in, ps, sn, rof, km, zgh, be, gv, es, dua, jgo, gsw, guz, mfe, ja, or, brx, te, sl, ha, sbp, fi, uz, bs__#Cyrl, sr__#Latn, sw, nmg, rm, bn, vai__#Vaii, kn, nnh, gu, lo, zh__#Hant, bs__#Latn, ky, mas, os, am, rw, iw, dav, lrc, ses, ce, mg, mr, ko, ak, seh, kde, dz, mgo, pa__#Guru, ast, yue__#Hans, pa, rn, tg, rwk, hu, twq, bm, tr, cgg, ksf, cy, sq, fr, de, lg, ff, sd, xog, so, kab, ms, nus, prg, ug, hi, vai, vi, dyo, mt, yav, eo, kam, ro, ee, pl, ur, uz__#Arab, se, chr, yue__#Hant, luy, as, it, uk, mzn, ii, tt, naq, tzm, fur, om, asa, fil, uz__#Cyrl, fo, hr, lt, ccp, lkt, is, si, en, ca, ks, nyn, yue, jmc, mk, pa__#Arab, bs, fy, th, ar, haw, dje, bas, uz__#Latn, sg, nl, ckb, sr, bem, da, wae, ig, gd, cu, vun, lu, ki, yo, nb, ti, kok, ewo]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("\udab4\udcbd\udb0c\udcc0\uda78\ude09\ud9a5\udd5b\uda00\ude87\ud814\udcfa\ud804\udec8");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\000");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\uda2a\udec4\udb73\udc62\uda0d\udf03\udae9\ude12\ud8a4\udf2e\udaed\udfe5\ud895\udd3b\uda33\ude37\uda1e\udf41\ud817\uded6\udab8\udf74\ud9c6\udc4c\udbfe\udcdb\uda6b\udec2\ud911\ude6f\ud8cd\uddf2\ud9b1\udd61\udbff\udc24\uda57\ude8c\udbae\ude93\ud936\udc7c\udbf8\udd42\udb5a\uddf5\udbe1\udcb0\uda61\udd2c\uda8b\udec7\udb74\udecd\uda53\udf0f\udb08\udd13\udadd\udf52\udb24\udd2b\uda30\udf42\udb62\udc53\ud91e\ude6d\uda2e\udeb9\ud996\ude8d\udac6\udfa5\ud834\udceb\udbc9\udfad\udac6\udc77\udad9\udfd4\udae6\udec7\ud816\udfa7\uda6b\udca8\ud950\udc68\udbfe\udc09\ud811\udf37\ud8ef\udc0a\udb92\udfbe\udb0b\udc31\ud96c\udef4\ud87f\udd83\ud953\udd71\ud9da\udc33\udb9c\udfa7\ud9bf\udcb6\udbfb\udeca\ud949\udd03\uda3d\udd1c\udbe4\udd1f\ud99b\ude2c\u9b66\udaea\udcb5\ud84e\udc25");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.countriesByLanguage("\udaeb\udf40\udbfe\udf5b\ud89c\udc89\ud9e9\udf72\ud834\udfbe\uda71\udd66\uda6c\udeb2\udb17\udf46\udbdb\udec0\udac7\udd45\ud875\ude19\uda5e\uddfc\udbd6\udc9c\uda6e\udc54\udb57\udf2a\ud91c\udee8\uda12\uddcd\uda49\uddbc\udb2f\ude53\ud91d\udf44\uda6f\uded7\udaea\ude2a\ud815\uddac\ud9e9\udf3a\udb74\udec6\ud8d7\udfb8\ud8fb\udd25\ud95b\ude0c\uda2a\udde3\ud9e5\udcd7\ud8ee\udc92\uda0e\ude53\ud924\udf59\uda2d\udd7d\ud8ca\ude83\ud953\ude36\uda15\udf7c\ud9c7\udd99\ud9f8\udcc0\udaef\uddfe\udb1b\udd24\udb37\udef3\ud845\udf85\uda43\udee1\uda47\udcb6\ud91c\udfec\udb6c\udc81\u633d\uda83\udec2\uda72\ude10\udba0\uddf2\ud8d9\uddbe\udbd6\ude06\udb09\udfd6\udb76\ude23\uda0c\udd8b\ud811\udc1e\uda79\udde8\udbc9\uddbb\udb4b\udec9\udbe4\ude28\ud87d\udd3d\udae2\udcef\udbf1\udd9e\ud9fb\udf2c\ud850\uddc6\udb37\udc7b\ud84a\ude9d\udb57\udca1\udb5c\udef6");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.languagesByCountry("\udab4\udcbd\udb0c\udcc0\uda78\ude09\ud892\udc90\udbdd\udd5c\ud814\udcfa\ud804\udec8");
    assertNotNull(r);
    assertEquals("java.util.Collections$UnmodifiableRandomAccessList", r.getClass().getName());
    assertEquals("[]", String.valueOf(r));
  }
}
