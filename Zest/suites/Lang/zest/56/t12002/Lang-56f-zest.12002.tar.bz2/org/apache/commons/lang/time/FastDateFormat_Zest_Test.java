package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastDateFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\ud925\udc23\ud9f9\udc81\ud9d9\uddcc\uc63a\udb42\ude22\uda51\udd02\udacb\udf19\udb34\uddab\uda6c\udd4d\ud95a\uddaf\uda29\udd6b\ud9bb\udcca");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\ud925\udc23\ud9f9\udc81\ud9d9\uddcc\uc63a\udb42\ude22\uda51\udd02\udacb\udf19\udb34\uddab\uda6c\udd4d\ud95a\uddaf\uda29\udd6b\ud9bb\udcca]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud863\udf9c\ud925\udc6e\ud9f9\udc81\udabf\ude9f\uf2e9\udbff\udd46\ud878\ude04\udacb\udf69\udb34\uddab\uda6c\udd4d\ud95a\uddaf\uda29\udd6b\ud9bb\udcca");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud863\udf9c\ud925\udc6e\ud9f9\udc81\udabf\ude9f\uf2e9\udbff\udd46\ud878\ude04\udacb\udf69\udb34\uddab\uda6c\udd4d\ud95a\uddaf\uda29\udd6b\ud9bb\udcca]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda15\uddab\udb4a\udd45\uda80\udfdc\ud9c4\udcf2\uc63a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda15\uddab\udb4a\udd45\uda80\udfdc\ud9c4\udcf2\uc63a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\000\uaafa\ud9d9\udcff\ud9e0\uddf0\000\000\u489d\udb34\udd3cE\000\ucb00\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude7a\000\uaafa\ud9d9\udcff\ud9e0\uddf0\000\000\u489d\udb34\udd3cE\000\ucb00\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9e0\udf45");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9e0\udf45]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\ud925\udc23\ud9f9\udc81\ud9d9\uddcc\uc63a\udb42\ude22\uda51\udd02\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\uda29\udd6b\ud9bb\udcca\u4695\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\udb52\udef9\ud844\uded1\udadf\udf18\uda5a\ude5f\udbcb\udcb5\ud82e\udc44\ud8a3\udeac\udafb\udd8c\ud873\udf86\uda5d\uddd0\ud8a9\udc91\uda8d\udfdb\udb5c\udfc8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\ud925\udc23\ud9f9\udc81\ud9d9\uddcc\uc63a\udb42\ude22\uda51\udd02\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\uda29\udd6b\ud9bb\udcca\u4695\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\udb52\udef9\ud844\uded1\udadf\udf18\uda5a\ude5f\udbcb\udcb5\ud82e\udc44\ud8a3\udeac\udafb\udd8c\ud873\udf86\uda5d\uddd0\ud8a9\udc91\uda8d\udfdb\udb5c\udfc8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda3d\uddf6\uda5f\udc27\uda46\uddad");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda3d\uddf6\uda5f\udc27\uda46\uddad]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\ud925\udc23\ud9f9\udc81\ud9d9\uddcc\uc63a\ud97f\udf21\udb98\udd4b\udacb\udf19\udb34\uddab\uda6c\udd4d\ud9ca\udda7\ue332\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\ud925\udc23\ud9f9\udc81\ud9d9\uddcc\uc63a\ud97f\udf21\udb98\udd4b\udacb\udf19\udb34\uddab\uda6c\udd4d\ud9ca\udda7\ue332\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8b3\udc7b\udabd\udeb5\ud80e\udfac\uda02\udcfe\ud9e6\udcda\udb37\udefe\ud83e\udfdc\udbcb\udc26\udb34\udd7f\ud8d0\udde0\ud861\udcd6\ud9b6\udf1c\ud9a7\udfab\ud840\udfc8\ud80d\ude69\ud802\udcc2\udb4a\udd56\udbee\udd7a\ud92c\udd9b\ud9cd\udcae\udaab\udde8\udae0\udc23\ud822\udfbc\ud837\udf26\ud80e\uddca\udabe\udc8d\ud943\uddb9\udb47\udf4f\uda3f\udd92\ud80f\udc62\ud8a5\udc4e\ud84c\udc77\ud96b\udcdf\udaaa\udc80\ud8d4\udcf1\udb5f\udfc8\udb59\ude50\ud8ac\udf7d\udadc\udd5f\ud9a1\udc73\ud991\udd3e\ud874\uddcd\uda7b\udf88\uda6b\udc54\ud8e1\udc59\udbfb\udeb7\udaa7\udce7\udbad\udca5\ud9ce\udc3c\udbbf\ude2f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8b3\udc7b\udabd\udeb5\ud80e\udfac\uda02\udcfe\ud9e6\udcda\udb37\udefe\ud83e\udfdc\udbcb\udc26\udb34\udd7f\ud8d0\udde0\ud861\udcd6\ud9b6\udf1c\ud9a7\udfab\ud840\udfc8\ud80d\ude69\ud802\udcc2\udb4a\udd56\udbee\udd7a\ud92c\udd9b\ud9cd\udcae\udaab\udde8\udae0\udc23\ud822\udfbc\ud837\udf26\ud80e\uddca\udabe\udc8d\ud943\uddb9\udb47\udf4f\uda3f\udd92\ud80f\udc62\ud8a5\udc4e\ud84c\udc77\ud96b\udcdf\udaaa\udc80\ud8d4\udcf1\udb5f\udfc8\udb59\ude50\ud8ac\udf7d\udadc\udd5f\ud9a1\udc73\ud991\udd3e\ud874\uddcd\uda7b\udf88\uda6b\udc54\ud8e1\udc59\udbfb\udeb7\udaa7\udce7\udbad\udca5\ud9ce\udc3c\udbbf\ude2f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u4a76");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u4a76]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda54\udfc2\ud925\udc23\ud9f5\udec8\ud9d9\uddcc\ud848\udca4\udb42\ude22\uda51\udd02\udb12\udfbd\ud989\ude9c\uda55\udf6b\ud95a\uddaf\udb86\udf92\udbe3\udd0f\ud8dd\udd63\uda78\udc1a\ud854\udf97\udaab\ude9c\udaf6\ude9c\ud883\udf2a\ud947\udd8a\udbdd\uddcd\uda65\udd81\ud841\udda5\udb4f\ude9e\ud854\ude8d\u14b5\ud905\ude2d\ud90a\udd91\ud8aa\udce9\udbc9\uddf1\udb7d\udfc9\ud830\udce5\ud937\udcca\uda4f\udd8a\udace\udc41\udb9f\udc22\ud9ce\udfc7\udbd2\udc20\ud960\udd25\uda98\udc12\udacd\udcd6\ud80d\udd0c\udbf6\udd99\ud870\ude8d\ud8ab\udc30\uda5a\ude66\udac4\udef3\ud86e\udea7\ud8d0\udef5\ud80c\udc7a\ud86b\udfbd\udbc2\udd42\udafb\uddfa\ud84f\ude82\ud9c0\udf60\ud885\udfe4\ud9c3\udfef\ud990\uddf8\udbe7\uded9\ud9bb\ude49\udb65\udd98\ud925\uddc8\udb13\udd3c\ud8b7\udd95\ud906\udd07\uda36\udc28\udb8a\udff7\ud819\udc69\ud83e\udd11\u2b86\udbd5\uddc2\ud8ea\udf99\udb3f\udf68");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda54\udfc2\ud925\udc23\ud9f5\udec8\ud9d9\uddcc\ud848\udca4\udb42\ude22\uda51\udd02\udb12\udfbd\ud989\ude9c\uda55\udf6b\ud95a\uddaf\udb86\udf92\udbe3\udd0f\ud8dd\udd63\uda78\udc1a\ud854\udf97\udaab\ude9c\udaf6\ude9c\ud883\udf2a\ud947\udd8a\udbdd\uddcd\uda65\udd81\ud841\udda5\udb4f\ude9e\ud854\ude8d\u14b5\ud905\ude2d\ud90a\udd91\ud8aa\udce9\udbc9\uddf1\udb7d\udfc9\ud830\udce5\ud937\udcca\uda4f\udd8a\udace\udc41\udb9f\udc22\ud9ce\udfc7\udbd2\udc20\ud960\udd25\uda98\udc12\udacd\udcd6\ud80d\udd0c\udbf6\udd99\ud870\ude8d\ud8ab\udc30\uda5a\ude66\udac4\udef3\ud86e\udea7\ud8d0\udef5\ud80c\udc7a\ud86b\udfbd\udbc2\udd42\udafb\uddfa\ud84f\ude82\ud9c0\udf60\ud885\udfe4\ud9c3\udfef\ud990\uddf8\udbe7\uded9\ud9bb\ude49\udb65\udd98\ud925\uddc8\udb13\udd3c\ud8b7\udd95\ud906\udd07\uda36\udc28\udb8a\udff7\ud819\udc69\ud83e\udd11\u2b86\udbd5\uddc2\ud8ea\udf99\udb3f\udf68]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\ud9e0\udd09\000\000\000\udbf2\udf39\u6945\000\ud9f6\ude3b\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\ud9e0\udd09\000\000\000\udbf2\udf39\u6945\000\ud9f6\ude3b\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\ud925\udc23\ud9f9\udc81\ud9d9\uddcc\ud9e0\uddf0\ud984\udf01\uda51\udd02\udacb\udf19\udb34\uddabE\ud95a\uddaf\uda29\udd6b\ud9bb\udcca");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\ud925\udc23\ud9f9\udc81\ud9d9\uddcc\ud9e0\uddf0\ud984\udf01\uda51\udd02\udacb\udf19\udb34\uddabE\ud95a\uddaf\uda29\udd6b\ud9bb\udcca]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud863\udf9c\ud925\udc6e\ud9f9\udc81\udabf\ude9f\uf2e9\udbff\udd46\ud878\ude04\udacb\udf69o\uda6c\udd4d\ud95a\uddaf\uda29\udd6b\ud9bb\udcca"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("y\000\u1803\000\uf253\udbff\udd46\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[y\000\u1803\000\uf253\udbff\udd46\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud863\udf9c\ud925\udc6e\ud9f8\udff7\udabf\ude9f\uf2e9\udbff\udd46\ud878\ude04k\ud81a\udcea\ud86b\udee6\ud95a\uddaf\udbb2\udc45\ud879\uddb7");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud863\udf9c\ud925\udc6e\ud9f8\udff7\udabf\ude9f\uf2e9\udbff\udd46\ud878\ude04k\ud81a\udcea\ud86b\udee6\ud95a\uddaf\udbb2\udc45\ud879\uddb7]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\udbdd\udf0e\uaafa\ud9d9\udcff\udba8\udf41m\000\u489d\udb34\udd3c\uda67\uddf8\000\ucb00\u0a00");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude7a\udbdd\udf0e\uaafa\ud9d9\udcff\udba8\udf41m\000\u489d\udb34\udd3c\uda67\uddf8\000\ucb00\u0a00]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\uaafa\ud9d9\udcff\ud9e0\uddf0\000\000\u489d\udb34\udd3cE\000\ucb00\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\uaafa\ud9d9\udcff\ud9e0\uddf0\000\000\u489d\udb34\udd3cE\000\ucb00\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\000\ud909\ude69\u9bb2\ud9e0\uddf0B\000\u489d\udb34\udd3cE\ud860\udf8f\ud8e3\udd21\udb1a\udc0c"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\uda12\ude53\udbde\udc22\ud8c9\udc61\ud8b2\ude74\udb3f\udcdeR\000\u489d\udb34\udd9c\uda42\udfd3\ud9f5\udc45\u442aj"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("y\000\uaafa\ud9d9\udcff\ud9e0\uddf0\000\000\u489d\udb34\udd3cE\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[y\000\uaafa\ud9d9\udcff\ud9e0\uddf0\000\000\u489d\udb34\udd3cE\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud99d\udd06\u435f\uaafa\ud9d9\udcff\ud8b9\udcfd\uda5c\udc0d\000\u489d\udb34\udd3cE");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud99d\udd06\u435f\uaafa\ud9d9\udcff\ud8b9\udcfd\uda5c\udc0d\000\u489d\udb34\udd3cE]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\uda29\udfb4\u4c16\ud9d9\udcff\ud9e0\uddf0\000\000\udad1\udd0b\udb77\udf0ad\ud9bf\ude1e\uda75\udd13\udb89\ude6d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude7a\uda29\udfb4\u4c16\ud9d9\udcff\ud9e0\uddf0\000\000\udad1\udd0b\udb77\udf0ad\ud9bf\ude1e\uda75\udd13\udb89\ude6d]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud89d\udcb8\ud922\udfb2\udb38\udc8b\ud8d1\ude05\ud9e0\uddf0\000\000\uda74\udd54\ud8f4\udf63s\000\ucb00\ud991\udff1");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud89d\udcb8\ud922\udfb2\udb38\udc8b\ud8d1\ude05\ud9e0\uddf0\000\000\uda74\udd54\ud8f4\udf63s\000\ucb00\ud991\udff1]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\000\udb51\udeec\udb94\ude9c\udb0b\ude86\udb06\udf68N\uda6c\udd31\udb5c\udf7ap\ud89b\udc0d\uf66a\ud861\udd05"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7b\000\uda38\udf00\ud8a6\ude86\ud867\uddc4\ud96f\udf2ch\u489d\udb7b\ude13\udafb\uddf4\uda5c\udce4\ucb00\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude7b\000\uda38\udf00\ud8a6\ude86\ud867\uddc4\ud96f\udf2ch\u489d\udb7b\ude13\udafb\uddf4\uda5c\udce4\ucb00\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7aL\udb56\udcfd\udbaf\ude8e\ud82a\ude99\ud86c\udd07\000\u489d\udb34\udd3c\udab2\udcbd\u00d3\ucb00\udab6\udefa"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000'");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000']", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udb2e\ude3bA\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udb3a\udd3c\u7bc4Q"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\u00a8\000\ud9d9\uddcc\u00e7\ud984\udf01\000\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ucb30\000\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udba1\udff0\ubd01\000\000\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\ud8a8\udfe6\uda8d\udfdb\udb5c\udfc8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\u00a8\000\ud9d9\uddcc\u00e7\ud984\udf01\000\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ucb30\000\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udba1\udff0\ubd01\000\000\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\ud8a8\udfe6\uda8d\udfdb\udb5c\udfc8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda54\udfc2\ud925\udc23\ud9f5\udec8\ud9d9\uddcc\ud848\udca4\udb42\ude22\uda51\udd02\udb12\udfbd\ud989\ude9c\uda55\udf6b\ud95a\uddaf\udb86\udf92\udbe3\udd0f\000\uda78\udc1a\ud854\udf97\udaab\ude9c\udaf6\ude9c\ud883\udf2a\ud947\udd8a\udbdd\uddcd\uda65\udd81\ud841\udda5\udb4f\ude9e\ud854\ude8d\u14b5\ud905\ude2d\ud90a\udd91\ud8aa\udce9\udbc9\uddf1\udb7d\udfc9\ud830\udce5\ud937\udcca\uda4f\udd8a\udace\udc41\udb9f\udc22\ud9ce\udfc7\udbd2\udc20\ud960\udd25\uda98\udc12\udacd\udcd6\ud80d\udd0c\udbf6\udd99\ud870\ude8d\ud8ab\udc30\uda5a\ude66\udac4\udef3\ud86e\udea7\ud8d0\udef5\ud80c\udc7a\ud86b\udfbd\udbc2\udd42\udafb\uddfa\ud84f\ude82\ud9c0\udf60\ud885\udfe4\ud9c3\udfef\ud990\uddf8'\000\000\ud910\udf47\udb13\udd3c\ud8b7\udd95\ud906\udd07\uda36\udc28\udb8a\udff7\ud819\udc69\ud83e\udd11\udbed\udf96\udbd5\uddc2\ud8ea\udf99\udb3f\udf68");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda54\udfc2\ud925\udc23\ud9f5\udec8\ud9d9\uddcc\ud848\udca4\udb42\ude22\uda51\udd02\udb12\udfbd\ud989\ude9c\uda55\udf6b\ud95a\uddaf\udb86\udf92\udbe3\udd0f\000\uda78\udc1a\ud854\udf97\udaab\ude9c\udaf6\ude9c\ud883\udf2a\ud947\udd8a\udbdd\uddcd\uda65\udd81\ud841\udda5\udb4f\ude9e\ud854\ude8d\u14b5\ud905\ude2d\ud90a\udd91\ud8aa\udce9\udbc9\uddf1\udb7d\udfc9\ud830\udce5\ud937\udcca\uda4f\udd8a\udace\udc41\udb9f\udc22\ud9ce\udfc7\udbd2\udc20\ud960\udd25\uda98\udc12\udacd\udcd6\ud80d\udd0c\udbf6\udd99\ud870\ude8d\ud8ab\udc30\uda5a\ude66\udac4\udef3\ud86e\udea7\ud8d0\udef5\ud80c\udc7a\ud86b\udfbd\udbc2\udd42\udafb\uddfa\ud84f\ude82\ud9c0\udf60\ud885\udfe4\ud9c3\udfef\ud990\uddf8'\000\000\ud910\udf47\udb13\udd3c\ud8b7\udd95\ud906\udd07\uda36\udc28\udb8a\udff7\ud819\udc69\ud83e\udd11\udbed\udf96\udbd5\uddc2\ud8ea\udf99\udb3f\udf68]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("y\000\ud9f8\udf87\udabf\ude9f\uf2e9\u422f\000\udaef\ude77oE\ud931\udef80\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9be\udef3\udab6\udc18\u4466a\udbac\udd0a\ud82b\udd5d\udb2a\udc33\udaf4\udee6\ud8dc\udea9\u2778\ud88d\ude3b\ud86e\udef8\udad9\udd26\udb90\udf1a\udb30\udf3a\udb0a\udd91\udafa\udcea\ud902\ude87\ud8a9\uddea");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9be\udef3\udab6\udc18\u4466a\udbac\udd0a\ud82b\udd5d\udb2a\udc33\udaf4\udee6\ud8dc\udea9\u2778\ud88d\ude3b\ud86e\udef8\udad9\udd26\udb90\udf1a\udb30\udf3a\udb0a\udd91\udafa\udcea\ud902\ude87\ud8a9\uddea]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("S\000\u1803\ud89b\udc0d\ud8da\udfa9\udae6\udf8c\ud8ba\ude22");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[S\000\u1803\ud89b\udc0d\ud8da\udfa9\udae6\udf8c\ud8ba\ude22]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udaef\udef0O\uda5f\udcf8\000\uf253\ud941\udf17\ud99c\udc91\ud99c\udddc\uce7f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("y\ud872\ude96\ud8f9\udfa8P\uf253\udb8d\udfedd\ud83b\udff0\ud949\udf05\uda26\udeeb\uda10\udea0\ud809\udf53\ud839\udc76"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("J\000\u1803\udb77\uddf0\udb00\udf14\ud992\udc85\ud8dd\udd1b"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("Z\000\u1803\000\uf253\udbff\udd46\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[Z\000\u1803\000\uf253\udbff\udd46\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaf4\ude04\ud945\udc54\ud9e2\udc2fa\ud8b9\udd41\udbff\udd46\ud878\ude04k\ud81a\udcea\ud86b\udee6\ud95a\uddaf\udbb2\udc45\ud879\uddb7");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaf4\ude04\ud945\udc54\ud9e2\udc2fa\ud8b9\udd41\udbff\udd46\ud878\ude04k\ud81a\udcea\ud86b\udee6\ud95a\uddaf\udbb2\udc45\ud879\uddb7]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud863\udf9c\ud925\udc6e\ud9f8\udff7\udabf\ude9f\uf2e9\udbff\udd46\ud86f\udf49I\ud81a\udcea\ud98f\uddb8\udaae\uddd4\ud8c3\udc6d\udb2d\ude75"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbe0\udf4e\ud925\udc6e\udabc\udc57\uda5c\ude28\ud8f0\udd02\u4fcf\udb0f\ude61z\ud81a\udcea\ud86b\udee6\ud963\udc73\uda8d\udea4\ud828\ude20");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbe0\udf4e\ud925\udc6e\udabc\udc57\uda5c\ude28\ud8f0\udd02\u4fcf\udb0f\ude61z\ud81a\udcea\ud86b\udee6\ud963\udc73\uda8d\udea4\ud828\ude20]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\ud907\udd23\udaad\udc12\ud9d9\udcff\udba8\udf41\ud981\udf01C\ud93f\udc13\ud909\udc57\uda67\udea3\000\ucb00\u0a00"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\udbdd\udf0e\uaafa\ud942\udc53\udaa1\udd2c\udbd7\udcecW\u489d\udb34\udd3c\uda67\uddf8\000\ucb00\u0a00");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude7a\udbdd\udf0e\uaafa\ud942\udc53\udaa1\udd2c\udbd7\udcecW\u489d\udb34\udd3c\uda67\uddf8\000\ucb00\u0a00]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udba2\udd75\udb3d\udcda\uda98\udcc0\ud821\udf4b\ud85c\udf8dH\000\u489d\ud909\udf27\udac3\uddb1\ud96e\udf46\ud8f4\udfe7\udb1a\udc0c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udba2\udd75\udb3d\udcda\uda98\udcc0\ud821\udf4b\ud85c\udf8dH\000\u489d\ud909\udf27\udac3\uddb1\ud96e\udf46\ud8f4\udfe7\udb1a\udc0c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u153a\ud81a\uddbe\ud8f3\udc56\u9b74\ud9e0\uddf0\ud898\uddcdW\u489d\udb34\udd3cE\ud860\udf8f\ud8e3\udd21\udb1a\udc0c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u153a\ud81a\uddbe\ud8f3\udc56\u9b74\ud9e0\uddf0\ud898\uddcdW\u489d\udb34\udd3cE\ud860\udf8f\ud8e3\udd21\udb1a\udc0c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\uda12\ude53\udbde\udc22\ud8c9\udc61\ud8b2\ude74\ud8a3\uddd0\uda36\udcb1F\u489d\udb34\udd9c\uda42\udfd3\ud9f5\udc45\u442aj"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("y\000\ud9b6\udf5f\ud8f6\ude4d\udb04\udd19\034\000\ud8f7\udf76\ud8a5\udffe\udace\ude4e'\ucf5a\ud92d\udd54");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[y\000\ud9b6\udf5f\ud8f6\ude4d\udb04\udd19\034\000\ud8f7\udf76\ud8a5\udffe\udace\ude4e'\ucf5a\ud92d\udd54]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9d9\ude83\ud991\udcde\ud00a\ud9d9\udcff\ud9e0\uddf0K\udb64\ude07\udba8\ude2f\ud9d6\ude4d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9d9\ude83\ud991\udcde\ud00a\ud9d9\udcff\ud9e0\uddf0K\udb64\ude07\udba8\ude2f\ud9d6\ude4d]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbec\udd9e\000\udb1b\udcee\udae1\udf73\uda26\uddd4\udb05\udf69'\uda6c\udd31\udb5c\udf7a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbec\udd9e\000\udb1b\udcee\udae1\udf73\uda26\uddd4\udb05\udf69'\uda6c\udd31\udb5c\udf7a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud91f\uddcf\ud831\uded1\udaf9\udea6\ud8a6\udef8\uda75\ude43\udbbd\udd54w\u489d\udb7b\ude13\udafb\uddf4\ud903\udd37");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud91f\uddcf\ud831\uded1\udaf9\udea6\ud8a6\udef8\uda75\ude43\udbbd\udd54w\u489d\udb7b\ude13\udafb\uddf4\ud903\udd37]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8c9\udd3dm\uda38\udf00\ud8a6\ude86\ud867\uddc4\ud96f\udf2ch\u489d\u1eb7\udb7b\udc65\ud9e7\udf05\udbc6\udf09\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8c9\udd3dm\uda38\udf00\ud8a6\ude86\ud867\uddc4\ud96f\udf2ch\u489d\u1eb7\udb7b\udc65\ud9e7\udf05\udbc6\udf09\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb1d\udf3f\000'\u9188\uda3e\uddb1\ud9b8\udc3e\u6cf6\ud8b7\udc88\udb70\ude0b\ud848\udd07\ud8fb\udf6b\uda31\udf7a\udaa3\ude2b\uda2d\udf31\ud934\udf47\udbec\udc1c\ud8ca\ude2a\ud9fc\udd8f\uda41\udd4b\ud066\uda52\uddab\udb2c\udd43\ud803\ude41\ud8ad\ude3e\u1115\udada\udfca\ud917\udf74\uda5f\udcd4\uda0c\udf81\uda83\udf86\udb6f\udd10\uda6c\udfcf\ud9de\udfa6\ud90f\uddc5\uda90\ude82\ud8c7\ude38\ueff4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb1d\udf3f\000'\u9188\uda3e\uddb1\ud9b8\udc3e\u6cf6\ud8b7\udc88\udb70\ude0b\ud848\udd07\ud8fb\udf6b\uda31\udf7a\udaa3\ude2b\uda2d\udf31\ud934\udf47\udbec\udc1c\ud8ca\ude2a\ud9fc\udd8f\uda41\udd4b\ud066\uda52\uddab\udb2c\udd43\ud803\ude41\ud8ad\ude3e\u1115\udada\udfca\ud917\udf74\uda5f\udcd4\uda0c\udf81\uda83\udf86\udb6f\udd10\uda6c\udfcf\ud9de\udfa6\ud90f\uddc5\uda90\ude82\ud8c7\ude38\ueff4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u6ff5\000'\uda30\udd14\ud866\udfe7\udaf9\udd94\ub04e\ud84d\udd68");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u6ff5\000'\uda30\udd14\ud866\udfe7\udaf9\udd94\ub04e\ud84d\udd68]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\uc7b7'\ud87e\udfc5\ud8d2\udf0e\ud967\uddb3\ud884\udf1d\ud8f6\uddba\udaad\udc7b\udb53\udf1f\udb8b\udca5\uda6c\udc4b\ud9a9\ude4c\udab8\udfc1\ud981\udf8b\ud8db\ude98\ud933\udccd\ud858\udca6\ud819\uddb5\ud93d\udddb\ud8c1\ude58\uda4e\uddd8\ud864\ude15\uda92\udd42\udbc6\udc28\ud90a\udea4\ud817\udf40\ud8de\udc92\udba4\udc26\udb92\udda2\uda44\udd0a\ue133\udba0\udd2b\ud997\udfbd\ud993\udc5d\uda8a\udee5\ud971\ude63\udad4\ude7e\uda7b\udd1c\udbc0\udf36\udb3b\udc71\ud916\ude59\ud82b\uddc5\u52ec\uda79\uddcc\udb2f\udc22\ud8dd\udd35\ud812\udeda\ud964\udf4d\udb00\udc07\uda81\udd9a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\uc7b7'\ud87e\udfc5\ud8d2\udf0e\ud967\uddb3\ud884\udf1d\ud8f6\uddba\udaad\udc7b\udb53\udf1f\udb8b\udca5\uda6c\udc4b\ud9a9\ude4c\udab8\udfc1\ud981\udf8b\ud8db\ude98\ud933\udccd\ud858\udca6\ud819\uddb5\ud93d\udddb\ud8c1\ude58\uda4e\uddd8\ud864\ude15\uda92\udd42\udbc6\udc28\ud90a\udea4\ud817\udf40\ud8de\udc92\udba4\udc26\udb92\udda2\uda44\udd0a\ue133\udba0\udd2b\ud997\udfbd\ud993\udc5d\uda8a\udee5\ud971\ude63\udad4\ude7e\uda7b\udd1c\udbc0\udf36\udb3b\udc71\ud916\ude59\ud82b\uddc5\u52ec\uda79\uddcc\udb2f\udc22\ud8dd\udd35\ud812\udeda\ud964\udf4d\udb00\udc07\uda81\udd9a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud906\udce2\ud86a\udcd4G\udb3a\udc04\udbe2\udea3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud906\udce2\ud86a\udcd4G\udb3a\udc04\udbe2\udea3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\u00a8\000\ud9d9\uddcc\u00e7\ud984\udf01\000\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ucb30\000\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udba1\udff0\ubd01\udb42\udeffD\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\ud8a8\udfe6\uda8d\udfdb\udb5c\udfc8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\u00a8\000\ud9d9\uddcc\u00e7\ud984\udf01\000\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ucb30\000\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udba1\udff0\ubd01\udb42\udeffD\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\ud8a8\udfe6\uda8d\udfdb\udb5c\udfc8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udabb\udf1d\u00a8\000\ud99b\udfcd\000\000\000\000\udbf2\udf39\ud98a\uddbc\ubfa8\ucb30\000\000\000\000\000\000\000\udba1\udff0\ubd01\000\000\000\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\000\uda74\ude7a\u008e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udabb\udf1d\u00a8\000\ud99b\udfcd\000\000\000\000\udbf2\udf39\ud98a\uddbc\ubfa8\ucb30\000\000\000\000\000\000\000\udba1\udff0\ubd01\000\000\000\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\000\uda74\ude7a\u008e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9be\udef3\udab6\udc18\u4466a\udbac\udd0a\u4250\udb2a\udc33\udaf4\udee6\ud8dc\udea9\u2778E\udba5\ude11\u3962\udb90\udf1a\udb30\udf3a\udb04\udd8e\udafa\udcea\ud902\ude87\ud8a9\uddea");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9be\udef3\udab6\udc18\u4466a\udbac\udd0a\u4250\udb2a\udc33\udaf4\udee6\ud8dc\udea9\u2778E\udba5\ude11\u3962\udb90\udf1a\udb30\udf3a\udb04\udd8e\udafa\udcea\ud902\ude87\ud8a9\uddea]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("F\000\uda29\udd04\ud89b\udc0d\ud8cb\udda9\udae6\udf8c\ud8ba\ude22");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[F\000\uda29\udd04\ud89b\udc0d\ud8cb\udda9\udae6\udf8c\ud8ba\ude22]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\u00a8\ud889\udfdb\udbfd\uddac\ud890\udf8b\ud9d9\udc00S\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ud90a\ude79\udbfa\ude98\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udb10\uddc7\ud883\udf77\ud8af\uded4D\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\u81f3\udba1\udd14\udb5c\udfd9");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\u00a8\ud889\udfdb\udbfd\uddac\ud890\udf8b\ud9d9\udc00S\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ud90a\ude79\udbfa\ude98\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udb10\uddc7\ud883\udf77\ud8af\uded4D\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\u81f3\udba1\udd14\udb5c\udfd9]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\ud9e1\udf1cD\ud9d9\uddcc\u00e7\ud984\udf01\000\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ucb30\000\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udba1\udff0\ubd01\udb42\udeffD\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\ud8a8\udfe6\uda8d\udfdb\udb5c\udfc8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\ud9e1\udf1cD\ud9d9\uddcc\u00e7\ud984\udf01\000\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ucb30\000\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udba1\udff0\ubd01\udb42\udeffD\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\ud8a8\udfe6\uda8d\udfdb\udb5c\udfc8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("y\000\ud889\udfdb\udbfd\uddac\ud890\udf8b\ud9d9\udc00S\ud867\udd86\uda4e\udd50\ud98a\uddbc\uda63\uddb7\ud90a\ude49\udbfa\ude98\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udb10\uddc7\ud883\udf77\ud8af\uded4D\ud82e\udc31\ud8a3\udeac\udbd7\udfba\ud873\udf5eM\udb3a\udd3c\udba1\udd14\udb5c\udfd9");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[y\000\ud889\udfdb\udbfd\uddac\ud890\udf8b\ud9d9\udc00S\ud867\udd86\uda4e\udd50\ud98a\uddbc\uda63\uddb7\ud90a\ude49\udbfa\ude98\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udb10\uddc7\ud883\udf77\ud8af\uded4D\ud82e\udc31\ud8a3\udeac\udbd7\udfba\ud873\udf5eM\udb3a\udd3c\udba1\udd14\udb5c\udfd9]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbd2\ude53\ud960\udccd\ud9f9\udc81\ud9d9\uddcc\uc63a\udb42\ude22\uda51\udd02\udacb\udf19\udb34\uddab\uda6c\udd4d\ud877\udc8f\uda21\udd5a\udb3d\udc30");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbd2\ude53\ud960\udccd\ud9f9\udc81\ud9d9\uddcc\uc63a\udb42\ude22\uda51\udd02\udacb\udf19\udb34\uddab\uda6c\udd4d\ud877\udc8f\uda21\udd5a\udb3d\udc30]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udd98\u00a8\000\ud9af\udf3cM\ud984\udf01\000\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ucb30\000\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udba1\udff0\ud9fe\udec7\u8b9b\u00ab\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\ud8a8\udfe6\uda8d\udfdb\udb5c\udfc8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udd98\u00a8\000\ud9af\udf3cM\ud984\udf01\000\ud867\udd86\uda4e\udd50\ud98a\uddbc\ud805\udca8\ucb30\000\udbdb\udccd\uda41\udc66\uda99\udc8b\uda76\udf90\udb07\udd27\ubde9\udba1\udff0\ud9fe\udec7\u8b9b\u00ab\ud82e\udc31\ud8a3\udeac\udafb\udd8c\ud873\udf5eM\ud8a8\udfe6\uda8d\udfdb\udb5c\udfc8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("y\ud921\uddee\udb59\udd00\020\udbc8\udf63\ud8ea\uded3y\ud9e2\udfa4\ud940\udc34\ud920\udc08\udbf0\udef7\ud812\udf8c\ud984\ude9c\udad8\ude10");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[y\ud921\uddee\udb59\udd00\020\udbc8\udf63\ud8ea\uded3y\ud9e2\udfa4\ud940\udc34\ud920\udc08\udbf0\udef7\ud812\udf8c\ud984\ude9c\udad8\ude10]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda12\ude53\udbde\udc22\ud8c9\udc61\ud8b2\ude74\udb15\udc29\uda36\udcfbF\u489d\udb34\udd9c\uda42\udfd3\ud9f5\udc45\u442aF");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda12\ude53\udbde\udc22\ud8c9\udc61\ud8b2\ude74\udb15\udc29\uda36\udcfbF\u489d\udb34\udd9c\uda42\udfd3\ud9f5\udc45\u442aF]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000'\u1210");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000'\u1210]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\uda42\udf04\000\ud909\ude69\u9bb2\ud9e0\uddf0BB\u489d\udb34\udd3cE\ud860\udf8f\ud8e3\udd21\udb1a\udc0c"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud95a\udeedh\uda38\udf00\ud8a6\ude86\ud91a\ude7e\ud96f\udf3ch\u489d\udb7b\ude13\udafb\uddf4\uda5c\udce4\ucb00\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud95a\udeedh\uda38\udf00\ud8a6\ude86\ud91a\ude7e\ud96f\udf3ch\u489d\udb7b\ude13\udafb\uddf4\uda5c\udce4\ucb00\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\udbdd\udf0e\uaafa\ud942\udc53\udaa1\udd2c\udbd7\udcecW\u489d\uda85\udf5b\uda02\ude26W\ucb00\ud912\udd87");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude7a\udbdd\udf0e\uaafa\ud942\udc53\udaa1\udd2c\udbd7\udcecW\u489d\uda85\udf5b\uda02\ude26W\ucb00\ud912\udd87]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud89d\udcb8\ud922\udfb2\udb38\udc8b\ud88e\udec4\udb15\udd14s\000\uda74\udcbf\ud8f4\udf63s\000\uf600\ud7e4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud89d\udcb8\ud922\udfb2\udb38\udc8b\ud88e\udec4\udb15\udd14s\000\uda74\udcbf\ud8f4\udf63s\000\uf600\ud7e4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\u64ccH\000r\uda75\ude43\udbbd\udd54w"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda54\udfc2\ud925\udc23\ud9f5\udec8\ud9d9\uddcc\ud848\udca4\udbec\udf1a\ud964\uddb5\udb3e\uddeb\ud989\ude9c\uda55\udf6b\ud95a\uddaf\udbd3\udf97\udbe3\udd0f\000\ud9f4\udc18\udb20\udf05\ud8cb\uded4\ud971\udded\u5132\udba9\ude3b\udb61\uddc4\uda65\udd81\ud841\udda5\udb4f\ude9e\ud854\ude8d\u14b5\udb2c\uddc1\ud9fe\udee1\ud8aa\udce9\udbc9\uddf1\udb7d\udfc9\ud886\udf09\ud8dd\udfa0\uda4f\udd8a\udace\udc41\udb9f\udc22\ud9ce\udfc7\uda44\udf19\ud960\udd25\uda98\udc12\udacd\udcd6\ud80d\udd0c\udbf6\udd99\ud870\ude8d\uda46\udf9e\uda5a\ude66\udac4\udef3\ud86e\udea7\ud8d0\udef5\ud80c\udc7a\ud86b\udfbd\ud87b\udc1e\udafb\udea6\ud84f\ude82\ud9c0\udf60\ud885\udfe4\ud9c3\udfef\ud990\uddf8'\ud80c\udf05'\ud910\udf47\udb1b\udd3c\udbf3\udd93\ud906\udd07\uda21\udf95\udb8a\udff7\ud819\udc69\ud83e\udd11\udbed\udf96\udbd5\uddc2\ud8f1\udfdb\ud863\udce8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda54\udfc2\ud925\udc23\ud9f5\udec8\ud9d9\uddcc\ud848\udca4\udbec\udf1a\ud964\uddb5\udb3e\uddeb\ud989\ude9c\uda55\udf6b\ud95a\uddaf\udbd3\udf97\udbe3\udd0f\000\ud9f4\udc18\udb20\udf05\ud8cb\uded4\ud971\udded\u5132\udba9\ude3b\udb61\uddc4\uda65\udd81\ud841\udda5\udb4f\ude9e\ud854\ude8d\u14b5\udb2c\uddc1\ud9fe\udee1\ud8aa\udce9\udbc9\uddf1\udb7d\udfc9\ud886\udf09\ud8dd\udfa0\uda4f\udd8a\udace\udc41\udb9f\udc22\ud9ce\udfc7\uda44\udf19\ud960\udd25\uda98\udc12\udacd\udcd6\ud80d\udd0c\udbf6\udd99\ud870\ude8d\uda46\udf9e\uda5a\ude66\udac4\udef3\ud86e\udea7\ud8d0\udef5\ud80c\udc7a\ud86b\udfbd\ud87b\udc1e\udafb\udea6\ud84f\ude82\ud9c0\udf60\ud885\udfe4\ud9c3\udfef\ud990\uddf8'\ud80c\udf05'\ud910\udf47\udb1b\udd3c\udbf3\udd93\ud906\udd07\uda21\udf95\udb8a\udff7\ud819\udc69\ud83e\udd11\udbed\udf96\udbd5\uddc2\ud8f1\udfdb\ud863\udce8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude7a\000\uaafa\ud9d9\udcff\ud9e0\uddf0E\000\u489d\udb34\udd3cE\000\ucb00\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude7a\000\uaafa\ud9d9\udcff\ud9e0\uddf0E\000\u489d\udb34\udd3cE\000\ucb00\000]", String.valueOf(r));
  }
}
