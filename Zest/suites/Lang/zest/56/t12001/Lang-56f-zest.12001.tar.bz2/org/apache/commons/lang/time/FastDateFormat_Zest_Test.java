package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastDateFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\uda76\udcf9\ud9f4\ude19\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\uda76\udcf9\ud9f4\ude19\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\ud802\udfe9\udae8\ude04\udaf1\udfab\ud8a1\uddcd\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\ud802\udfe9\udae8\ude04\udaf1\udfab\ud8a1\uddcd\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\ud9d4\udc64\uda76\udcf9\ud9f4\ude19\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud85b\uddd8\ufbb6\ud99a\udc49");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\ud9d4\udc64\uda76\udcf9\ud9f4\ude19\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud85b\uddd8\ufbb6\ud99a\udc49]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda5c\ude62\uda0b\udec8\udbdf\udefe\ud83e\ude9f\ud80c\udcb5\uda2b\uded0\udb59\ude80\udacc\udd31\ud99e\uddc1\ud881\udd4c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda5c\ude62\uda0b\udec8\udbdf\udefe\ud83e\ude9f\ud80c\udcb5\uda2b\uded0\udb59\ude80\udacc\udd31\ud99e\uddc1\ud881\udd4c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8fb\uddca\udaf8\udf94\ud06c\ud84b\udc4f\ud882\udec0\uda50\udeb7\uda68\ude3d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8fb\uddca\udaf8\udf94\ud06c\ud84b\udc4f\ud882\udec0\uda50\udeb7\uda68\ude3d]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\uda76\udcf9\000\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\uda76\udcf9\000\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udf2e\udb3b\udc32\udb69\udf7d\uda25\udc8f\u58e9\uda6a\ude05\uda76\udcf9\u8c52\ud881\udd31\udab8\udf87\uda2b\udf20\ud93a\udf5a\ud87e\udcd8\ud8fd\udf07\udbbd\udd3b\ud9f1\udf77\udb73\ude56\u74d2\ud986\udd72\ud890\udccd\ud989\udc00\ud86e\udd83\ud80c\udc62\u1e99\udab2\ude3e\uda53\udca4\ud8f2\udd54\ud8c7\udc44\udb0e\ude3b\ud8cf\udf93\uda76\udc15");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udf2e\udb3b\udc32\udb69\udf7d\uda25\udc8f\u58e9\uda6a\ude05\uda76\udcf9\u8c52\ud881\udd31\udab8\udf87\uda2b\udf20\ud93a\udf5a\ud87e\udcd8\ud8fd\udf07\udbbd\udd3b\ud9f1\udf77\udb73\ude56\u74d2\ud986\udd72\ud890\udccd\ud989\udc00\ud86e\udd83\ud80c\udc62\u1e99\udab2\ude3e\uda53\udca4\ud8f2\udd54\ud8c7\udc44\udb0e\ude3b\ud8cf\udf93\uda76\udc15]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u00b2\uda0b\ude7f\000\000\ud9ec\uddb5\u58e9\udae8\ude04\uda5f\udd8e\000\ud881\udd4c\ud9f2\udda6\uda1c\udc74\udb4e\udda4\000\000\ud9cb\udfa5\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u00b2\uda0b\ude7f\000\000\ud9ec\uddb5\u58e9\udae8\ude04\uda5f\udd8e\000\ud881\udd4c\ud9f2\udda6\uda1c\udc74\udb4e\udda4\000\000\ud9cb\udfa5\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\000\uda76\udcf90\000\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\000\uda76\udcf90\000\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39!\u58e9\udae8\ude04\uda76\udcf9\u8330\ud943\udee1\uda67\udd20\ud9f5\udd0e\ud93a\udf5a\uaa8f\000\000\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39!\u58e9\udae8\ude04\uda76\udcf9\u8330\ud943\udee1\uda67\udd20\ud9f5\udd0e\ud93a\udf5a\uaa8f\000\000\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbd3\udcbc\ud9b1\ude10\u3813\uda68\uddc2\uda98\udfa7\ud909\udc1b\udada\udf4c\ud94a\udc8b\ud9f4\ude09\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\uda5b\udd0d\uda33\udd2c\ud99d\udc70\u945e\udb6b\udd8d\ud950\ude35\udb1d\udf26\udb4a\udf21\ud8ba\udcee\ud952\udfd8\ud8b6\uddc0\ud89b\udc32\ud9fe\ude6d\uda00\udc49\udaec\udef8\ue6c5\ud8d7\uddfe\ud863\ude8c\uda65\udd50\udbd9\ude16\udb2e\udeb8\udb7e\ude81\ud97d\udfb9\u5b21\udb49\udddc");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbd3\udcbc\ud9b1\ude10\u3813\uda68\uddc2\uda98\udfa7\ud909\udc1b\udada\udf4c\ud94a\udc8b\ud9f4\ude09\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\uda5b\udd0d\uda33\udd2c\ud99d\udc70\u945e\udb6b\udd8d\ud950\ude35\udb1d\udf26\udb4a\udf21\ud8ba\udcee\ud952\udfd8\ud8b6\uddc0\ud89b\udc32\ud9fe\ude6d\uda00\udc49\udaec\udef8\ue6c5\ud8d7\uddfe\ud863\ude8c\uda65\udd50\udbd9\ude16\udb2e\udeb8\udb7e\ude81\ud97d\udfb9\u5b21\udb49\udddc]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebdI\uda7a\udf71\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\u5d8b\000\\\000\uda04\udea2\ud93a\udf5a\ud87e\udcd8\u2fd0\000\000\ud874\udc22"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u2fb2");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u2fb2]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9d7\uddbe\uda01\udc8d\ud9ff\udf82\ud9f4\udd39\ud882\udde3\ud9f9\ude63\ud82f\ude74\uda76\udcf9\ud9f4\ude19\udab3\udfe0\udb89\udc8d\ud8c0\udc66\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\uda92\udecb\ud988\udfad\udb1a\udd44\ud942\uddff\ud9fd\uddd2\ud836\ude35\udbe8\uddaf\uda6e\uddaa\udb92\udccd\udb3b\udfd0\ud922\udc4c\ud886\uddba\udac6\udd94\ud986\udcc8\ud888\udce0\ud9d2\udce9\ud81c\udc2c\ud8f2\udf91\udbbf\udc8f\udaac\udc6a\ud8c7\udd21\uda87\udd8b\ud9f7\udf23\ud8ca\udf57\ud893\udc31\udac6\udfe6\uac4f\udaff\ude02\ud883\udddb\udb59\udc04\ud8f0\udfd9\udb21\udc97\udb7d\udcb4\ud830\udf0a\udaa9\udc92\uda50\ude2e\ud852\udfb5\ud926\udedf\ud9af\udc09\ud907\uddc4\uda0f\ude63\ud962\ude99\ud823\udeed\uda31\udc3c\udaef\udc33\udb90\uddde\udba5\udca6\udbb9\udd7a\ud89d\udc29");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9d7\uddbe\uda01\udc8d\ud9ff\udf82\ud9f4\udd39\ud882\udde3\ud9f9\ude63\ud82f\ude74\uda76\udcf9\ud9f4\ude19\udab3\udfe0\udb89\udc8d\ud8c0\udc66\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\uda92\udecb\ud988\udfad\udb1a\udd44\ud942\uddff\ud9fd\uddd2\ud836\ude35\udbe8\uddaf\uda6e\uddaa\udb92\udccd\udb3b\udfd0\ud922\udc4c\ud886\uddba\udac6\udd94\ud986\udcc8\ud888\udce0\ud9d2\udce9\ud81c\udc2c\ud8f2\udf91\udbbf\udc8f\udaac\udc6a\ud8c7\udd21\uda87\udd8b\ud9f7\udf23\ud8ca\udf57\ud893\udc31\udac6\udfe6\uac4f\udaff\ude02\ud883\udddb\udb59\udc04\ud8f0\udfd9\udb21\udc97\udb7d\udcb4\ud830\udf0a\udaa9\udc92\uda50\ude2e\ud852\udfb5\ud926\udedf\ud9af\udc09\ud907\uddc4\uda0f\ude63\ud962\ude99\ud823\udeed\uda31\udc3c\udaef\udc33\udb90\uddde\udba5\udca6\udbb9\udd7a\ud89d\udc29]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\ud9ec\uddb5\udb57\udcf4\udac3\udee1\udaf1\udfab\ud989\uddc1\udb3d\ude6a\000\000\000\000\udac8\udfe3\000\udad2\ude88\uda70\udfa2");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\ud9ec\uddb5\udb57\udcf4\udac3\udee1\udaf1\udfab\ud989\uddc1\udb3d\ude6a\000\000\000\000\udac8\udfe3\000\udad2\ude88\uda70\udfa2]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\uda31\udc02m\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\uda31\udc02m\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udac9\udd8a\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\ude87\udb4d\udc65\uda97\udcc4\udb56\udcdeQ\udbb5\udc1f\uda4c\udf7e\uda03\udf47\udbe6\udc54\ud87e\udd2e\ud927\udd0f\ud8e7\uded0\udb83\udc6d\udb40\udff2\uda44\udebb\udb71\udca4\uda39\uddf1\ud81a\udcbb\ud8da\udf6e\udbce\udc07\ud8ec\udf5e\uda75\udebe\ud951\udc4f\ud930\udcaf\ud817\uddea\ud93a\udfea\ud8ae\udcc4\ud8f5\ude11\ud825\udf85\udb9f\udf3b\udb34\udc2f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud861\udf71\uda30\uded1\u58e9\udae8\ude04\udaa1\udca0H\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud861\udf71\uda30\uded1\u58e9\udae8\ude04\udaa1\udca0H\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u00b2\uda0b\ude7f\uda20\udd0fa\ud9ec\uddb5\u58e9\udae8\ude04\uda5f\udd8e\000\ud881\udd4c\ud9f2\udda6\uda1c\udc74\udb4e\udda4\000\000\ud9cc\udc09\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u00b2\uda0b\ude7f\uda20\udd0fa\ud9ec\uddb5\u58e9\udae8\ude04\uda5f\udd8e\000\ud881\udd4c\ud9f2\udda6\uda1c\udc74\udb4e\udda4\000\000\ud9cc\udc09\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("A\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\udb83\udc4a\ud84c\udff4\ud985\udc660\000\ud9e5\udc92\uda1c\udc74\u2ae4\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\udbd5\ude94\udb83\udf11\ud8f5\udcaa\udbc9\udcd0\ud9b5\ude2a\udb90\ude38\udbe5\udc4e\ud925\udde2\uda99\udcce\u0798\ud87f\udda0\u4480\ud90e\udd11\udb07\udd95\ud82b\uddda\ud95a\udf1f\udbdd\udf75\ud838\ude45\udaa3\udeb3\udbb0\udc2c\ud8c3\udf1f\ud91b\udc8f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\000\uda76\udcf90D\ud9e5\udc92\uda1c\udc74\ud974\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\000\uda76\udcf90D\ud9e5\udc92\uda1c\udc74\ud974\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("d\ud94c\udfa9\uda90\udd2e\ud9f4\udd39\ud882\udde3\u58e9\000\udae7\ude520\000\u6b50\ud923\udd77\ud93a\udfaa\ud87e\udcd8\udad8\uddf5\ud9ff\udfb0\ud820\udc11\ud874\udcc3\udabb\udd34\ud883\ude5a\ud828\udf1b\udbc8\udcf5");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[d\ud94c\udfa9\uda90\udd2e\ud9f4\udd39\ud882\udde3\u58e9\000\udae7\ude520\000\u6b50\ud923\udd77\ud93a\udfaa\ud87e\udcd8\udad8\uddf5\ud9ff\udfb0\ud820\udc11\ud874\udcc3\udabb\udd34\ud883\ude5a\ud828\udf1b\udbc8\udcf5]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9a1\udef0\udbd0\udffb\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\000\uda76\udcf9\ud998\udffbz\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a1\udef0\udbd0\udffb\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\000\uda76\udcf9\ud998\udffbz\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9b7\udda4\uda0b\udf04\uda7b\udc0c\ud9f4\udd39\ud866\udca0\udb48\udf5a'\ud990\udc26\udab3\udf7c\uda14\udd0c\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb2\ud99a\udc49\udbdf\udecb\uda8f\udedc");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9b7\udda4\uda0b\udf04\uda7b\udc0c\ud9f4\udd39\ud866\udca0\udb48\udf5a'\ud990\udc26\udab3\udf7c\uda14\udd0c\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb2\ud99a\udc49\udbdf\udecb\uda8f\udedc]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\uda13\udec8\uda7b\udc0c\ud9f4\udd39\ud9ea\udc69\u58e9\uda16\ude87\ud90b\ude9dy\ufdff\udb24\udcd9\uda1a\ude45\ud93a\udf5a\ud87e\udcd8\uda54\udd74\ud9c9\udd0c\ud8c5\udd9e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\uda13\udec8\uda7b\udc0c\ud9f4\udd39\ud9ea\udc69\u58e9\uda16\ude87\ud90b\ude9dy\ufdff\udb24\udcd9\uda1a\ude45\ud93a\udf5a\ud87e\udcd8\uda54\udd74\ud9c9\udd0c\ud8c5\udd9e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udbd3\udcbc\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1b\udada\udf4c\ud94a\udc8b\ud9f4\ude09\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\uda5b\udd0d\u9146\ue57b\uda45\udd6d\udb34\ude19\ud950\ude35\udb1d\udf26\uf4da\000\udb19\udf2c\u2129\ud89a\udf8a\ud9fe\ude6d\uda00\udc49l\000\ud8d7\uddfe\ud863\ude8c\uda65\udd50\udbd9\ude16\udb2e\udeb8\udb7e\ude81\ud97d\udfb9\u5b21\udb49\udddc"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("N"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("H");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[H]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udad2\uddbdL\ud8f2\udc3f\ud844\udf82\uda96\udc23\ud96a\udc7c\udab0\ude97\udaf9\uddca\udb97\udf8d\udb28\udcd2\ud995\ude38\ud9db\udf4f\ud8aa\udcb7\ud986\uddfe\ud9c1\udd7d\udbda\udf63\ud8bc\udd06\ud874\udc22"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\udac3\udee1\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\udac3\udee1\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\uda2b\udea0C\uda7a\udf71\ud9f5\udc39\ud882\udde3\u58e9\udae8\ude04\ud963\udc27\000\\\000\uda04\udea2\ud93a\udf5a\ud87e\udcd8\u2fd0\000\udaea\udc9e\ud874\udd1a"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud940\udeech\uda7a\udf71\uda62\udc51\ud869\ude6c\u5852\udad3\udd04\u5d8b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud940\udeech\uda7a\udf71\uda62\udc51\ud869\ude6c\u5852\udad3\udd04\u5d8b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud805\udd99\uda0b\udf36\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\udb7d\udd94s\ud881\udd4c\ud9f2\udda6\udb01\udd7f\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud850\uddc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud805\udd99\uda0b\udf36\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\udb7d\udd94s\ud881\udd4c\ud9f2\udda6\udb01\udd7f\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud850\uddc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\ud887\udc41\udb15\udde4\udac1\udeccF\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8d6\udf9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\udde3\ud887\udc41\udb15\udde4\udac1\udeccF\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8d6\udf9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udac9\udd8a\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\ude87\udb4d\udc65\uda97\udcc4\ud83b\udfb1'\ud9e5\udc58\uda4d\udc39\uda03\udf47\udbe6\udc54\ud87e\udd2e\ud927\udd0f\ud8e7\uded0\udb83\udc6d\udb40\udff2\uda44\udebb\udb71\udca4\uda39\uddf1\ud81a\udcbb\ud8da\udf6e\udbce\udc07\ud8ec\udf5e\uda75\udebe\ud951\udc4f\ud930\udcaf\ud817\uddea\ud93a\udfea\ud8ae\udcc4\ud8f5\ude11\ud825\udf85\udb9f\udf3b\udb34\udc2f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udac9\udd8a\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\ude87\udb4d\udc65\uda97\udcc4\ud83b\udfb1'\ud9e5\udc58\uda4d\udc39\uda03\udf47\udbe6\udc54\ud87e\udd2e\ud927\udd0f\ud8e7\uded0\udb83\udc6d\udb40\udff2\uda44\udebb\udb71\udca4\uda39\uddf1\ud81a\udcbb\ud8da\udf6e\udbce\udc07\ud8ec\udf5e\uda75\udebe\ud951\udc4f\ud930\udcaf\ud817\uddea\ud93a\udfea\ud8ae\udcc4\ud8f5\ude11\ud825\udf85\udb9f\udf3b\udb34\udc2f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udac9\udd8a\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\ude87\udb4d\udc65\uda97\udcc4\ud980\udc2dw\udbb5\udc1f\uda4c\udf7e\uda03\udf47\udbe6\udc54\ud87e\udd2e\ud927\udd0f\ud8e7\uded0\udb83\udc6d\udb40\udff2\ud822\udec9\ud879\udd92\ud9d6\udd4c\ud81a\udcbb\ud8da\udf6e\udbce\udc07\ud8ec\udf5e\uda75\udebe\ud951\udc4f\ud930\udcaf\ud817\uddea\ud93a\udfea\ud99c\udcbb\ud8f5\ude11\ud825\udf85\udaa5\ude3e\ub4df");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udac9\udd8a\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud882\ude87\udb4d\udc65\uda97\udcc4\ud980\udc2dw\udbb5\udc1f\uda4c\udf7e\uda03\udf47\udbe6\udc54\ud87e\udd2e\ud927\udd0f\ud8e7\uded0\udb83\udc6d\udb40\udff2\ud822\udec9\ud879\udd92\ud9d6\udd4c\ud81a\udcbb\ud8da\udf6e\udbce\udc07\ud8ec\udf5e\uda75\udebe\ud951\udc4f\ud930\udcaf\ud817\uddea\ud93a\udfea\ud99c\udcbb\ud8f5\ude11\ud825\udf85\udaa5\ude3e\ub4df]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udbf1\uded9\uda38\udea1\ud84b\udc3f\uf853\udaf3\udc25\udb4d\udcab\udb65\udec3\udb56\udcdeB\ud9c8\udf73\uda58\udd2c\uda54\udeb0\udb0d\udc47\udb34\uddef\udaa3\ude02\u82cd\ud94d\ude93\udbc8\uded2\ud87f\udf01\udb71\udca4\uda39\uddf1\ud817\udc98\ud8da\udf6e\ud89c\udc0e\ud8ec\udf5e\udb2e\udcbb\ud9ff\ude7a\ud9e9\udc2c\ud817\ude7b\ud980\udd97\udab4\udf04\ud8f5\ude11\ud861\udf83\ud93b\udde9\udb34\udcd4"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\ud870\ude83\ud92b\ude36\ud861\udf71\ud87e\uddd6\u58e9\udbec\ude97\uda25\udd7fk\ud881\udd4c\ud9f2\udda6\ud902\udc47\ud979\udf7f\ud87e\udcd8\udad4\udfb3\uc7d5\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\ud870\ude83\ud92b\ude36\ud861\udf71\ud87e\uddd6\u58e9\udbec\ude97\uda25\udd7fk\ud881\udd4c\ud9f2\udda6\ud902\udc47\ud979\udf7f\ud87e\udcd8\udad4\udfb3\uc7d5\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\u00b2\uda0b\ude7f\uda20\udd0fa\uda22\udfb5\u58e9\udae8\ude04\uda5f\udd8e\000\ud881\udd4c\ud9f2\udda6\uda1c\udc74\udb4e\udda4\udb7b\udc7cn\ud9dc\udc11\ud8c5\udd9e\ud874\udcc3"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\u00b2\udb03\udd7f\uda20\udd0fa\ud9ec\uddb5\udad0\udc85\ud9e4\udf79\ud877\udd0c\u008f\ud9c1\ude0c\ud9f2\udda6\uda8d\udead\udb4e\udcb4J\uda12\ude68\udbf8\uddf3\ud8c5\udd9e\ud874\udcc3"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\u00b2\ud8e7\udfad\uda20\udd39\ud9a1\udf51\udb36\udc9d\u58e9\udae8\ude04\uda5f\udd8e\ud927\udde1\ud9ed\udd42\ud981\udf2e\ud930\ude05\ud864\udcc3P\ud96e\udff6\udaa6\udcc5\ud8c5\udd9e\ud874\udcc3"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud874\udd79\uda20\udd0fa\000\ud8ab\udef4\udae8\ude04\u008b\000\ud861\udef0\ud9f2\udda6\uda1c\udc74\udb4e\udda4\000\000d\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud874\udd79\uda20\udd0fa\000\ud8ab\udef4\udae8\ude04\u008b\000\ud861\udef0\ud9f2\udda6\uda1c\udc74\udb4e\udda4\000\000d\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("K\uda0b\ude7f\uda20\udd0f\uda22\udf31\ud845\udf45\ud96b\uded2\udae8\ude04\uda5f\udd8e\000\udb75\udd46\ud9f2\udda6\uda1c\udc74\udb67\udcea\000\ud917\udcf7\ud9ff\udd86\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[K\uda0b\ude7f\uda20\udd0f\uda22\udf31\ud845\udf45\ud96b\uded2\udae8\ude04\uda5f\udd8e\000\udb75\udd46\ud9f2\udda6\uda1c\udc74\udb67\udcea\000\ud917\udcf7\ud9ff\udd86\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("E\uda0b\ude7f\uda20\udd0f\ud985\udeda\ud896\udfc1\u58e9\ud94c\udc3f\udb06\udf76\udbc8\ude84\ud8a1\udcf7\ud80f\ude41\ud830\udc0a\uc253\ud964\udfc0\u2da8\ud9eb\udcd7\udb56\udc86\ud870\udd7a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[E\uda0b\ude7f\uda20\udd0f\ud985\udeda\ud896\udfc1\u58e9\ud94c\udc3f\udb06\udf76\udbc8\ude84\ud8a1\udcf7\ud80f\ude41\ud830\udc0a\uc253\ud964\udfc0\u2da8\ud9eb\udcd7\udb56\udc86\ud870\udd7a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\udae2\udd13\udab6\uddc3G\udae4\udc310\ud9cc\uded5\ud9b5\udefe\udb93\udcc8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\udae2\udd13\udab6\uddc3G\udae4\udc310\ud9cc\uded5\ud9b5\udefe\udb93\udcc8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("F\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud9ac\udc35\u58e9\000\ud923\udc17\uda67\udff0D\ud9e5\udc92\udaca\udc6b\udad9\ude4c\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\uda5c\udc81");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[F\uda0b\udec8\uda7b\udc0c\ud9f4\udd39\ud9ac\udc35\u58e9\000\ud923\udc17\uda67\udff0D\ud9e5\udc92\udaca\udc6b\udad9\ude4c\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\uda5c\udc81]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\u0f92\ud932\udc9a\uda81\uddf2\ud84e\ude27\ud882\udde3\uda74\udeb7\000\udae7\ude52R\000\u6b50\ud923\udd77\ud93a\udfaa\ud93f\udcd4\udad8\uddf5\ud9ff\udfb0\ud820\udc11\ud8c3\uddac\udab9\uddd4\ud883\ude5a\ud828\udf1b\udbc8\udcf5"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("d\ud800\ude36\ud912\ude71\udb7b\udf7e\ud98f\uddd7\u58e9\ud86c\udcb1\ud87e\udd15\ud91d\ude21W\u6b50\ud923\udd77\udb5e\udf1d\ud91f\udd82\udb67\udccb\udb20\uddbc\ud81f\udfef\ud874\udcc3\udabb\udd34\ud9e7\udfb1\udb96\udffb\udbab\udfc0\ud940\udd93");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[d\ud800\ude36\ud912\ude71\udb7b\udf7e\ud98f\uddd7\u58e9\ud86c\udcb1\ud87e\udd15\ud91d\ude21W\u6b50\ud923\udd77\udb5e\udf1d\ud91f\udd82\udb67\udccb\udb20\uddbc\ud81f\udfef\ud874\udcc3\udabb\udd34\ud9e7\udfb1\udb96\udffb\udbab\udfc0\ud940\udd93]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9b7\udda4\uda0b\udf04\uda7b\udc0c\ud9f4\udd39\uda3f\ude0d\udb48\udf42'\ud990\udc26\udab3\udf7c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9b7\udda4\uda0b\udf04\uda7b\udc0c\ud9f4\udd39\uda3f\ude0d\udb48\udf42'\ud990\udc26\udab3\udf7c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb35\udec2\uda3b\ude67\udb9f\ude2d\ud9f4\udd34\ud866\udca0\udb48\udf5a'\ud990\udc26\udae8\udf81\uda14\udd0c\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud87e\udcd8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb35\udec2\uda3b\ude67\udb9f\ude2d\ud9f4\udd34\ud866\udca0\udb48\udf5a'\ud990\udc26\udae8\udf81\uda14\udd0c\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud87e\udcd8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb70\udd9c\ud98b\udc9a\uda7b\udc0c\uda0f\udc80\ud866\udca0\udb48\udf5a'\ud990\udc26");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb70\udd9c\ud98b\udc9a\uda7b\udc0c\uda0f\udc80\ud866\udca0\udb48\udf5a'\ud990\udc26]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbd3\udcbc\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1b\udada\udf4c\ud94a\udc8b\ud9f4\ude09\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\udad1\udd08\u9146\ue57b\uda45\udd6d\udb34\ude19\ud950\ude35");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbd3\udcbc\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1b\udada\udf4c\ud94a\udc8b\ud9f4\ude09\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\udad1\udd08\u9146\ue57b\uda45\udd6d\udb34\ude19\ud950\ude35]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\udbd3\udcbc\000\udbf8\udc9bS\uda3d\udcfe\ufa56\udada\udf4c\ud94a\udc8b\ud9f4\ude09P\udb22\udc10\udb52\udc04\udb40\udffd\uda5b\udd0d\u9146\ue57b\ue567\000\000\udaf8\udf26\u00da\000\udb19\udf2c\u2129\ud89a\udf8a\ud9d5\ude4a\u0082l\000\ud8d7\uddfe\ud863\ude8c\uda5a\udc50\udbd9\ude16\udb2e\udeb8\udb7e\ude81\ud953\udf04\ud86a\uded4\udb49\udddc"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud805\udd99\uda0b\udf36\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\udb7d\udd94Z\ud881\udd4c\ud9f2\udda6\udb01\udd7f\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud850\uddc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud805\udd99\uda0b\udf36\uda7b\udc0c\ud9f4\udd39\ud882\udde3\u58e9\udae8\ude04\udb7d\udd94Z\ud881\udd4c\ud9f2\udda6\udb01\udd7f\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud850\uddc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("O\ud8e7\udfad\uda20\udd39\ud9a1\udf51\udb36\udc9d\u58e9\udae8\ude04\uda5f\udd8e\ud927\udde1\ud9ed\udd42\ud981\udf2e\uda7d\ude2c\uda6b\udfce\ud93b\udf86\ud99a\udc9d\udaac\ude51\ud8c5\udd9e\ud874\udcc3"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb70\udd9c\ud98b\udc9a\udb44\udcf0\ud93f\udedb\ud852\udf69\udb48\udee1'");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb70\udd9c\ud98b\udc9a\udb44\udcf0\ud93f\udedb\ud852\udf69\udb48\udee1']", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbd3\udcbc\udaa1\udf79\udb8a\ude4cM\uda3d\udcfe\ud909\udc1b\udada\udf4c\udb8b\uddab\ud934\udd9a\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\udad1\udd08\u9146\ue57b\uda45\udd6d\udb34\ude19\ud950\ude35");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbd3\udcbc\udaa1\udf79\udb8a\ude4cM\uda3d\udcfe\ud909\udc1b\udada\udf4c\udb8b\uddab\ud934\udd9a\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\udad1\udd08\u9146\ue57b\uda45\udd6d\udb34\ude19\ud950\ude35]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb70\udd9c\udb29\udc81\ud93d\ude70\ud8d9\udc19\ud852\udf00\udb48\udee1'\uda5d\udf2b\ud828\udd63\udacb\udf1c\ud8eb\udd9f\udba3\udf93\ud813\udda9\ud845\uddab\ua754\uda2b\udc4e\ud997\ude71\uda89\udc5c\ud8cd\ude2b\udb36\udc08\ud82e\udcca\ud873\udd19\udb9c\udd7d\ud9d3\udc27\uda3d\udc68\udb21\udfdf\ud873\udecc\udbb9\udc8d\u1679\udb78\udced\ud929\ude61\udb76\udcf5\udb9a\uddd3\udb85\ude86\ud861\ude0d\udb87\ude53\uda1e\udcba\uda38\udc61\ud9b8\udd8b\udbf2\ude4d\udbf5\udc45");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb70\udd9c\udb29\udc81\ud93d\ude70\ud8d9\udc19\ud852\udf00\udb48\udee1'\uda5d\udf2b\ud828\udd63\udacb\udf1c\ud8eb\udd9f\udba3\udf93\ud813\udda9\ud845\uddab\ua754\uda2b\udc4e\ud997\ude71\uda89\udc5c\ud8cd\ude2b\udb36\udc08\ud82e\udcca\ud873\udd19\udb9c\udd7d\ud9d3\udc27\uda3d\udc68\udb21\udfdf\ud873\udecc\udbb9\udc8d\u1679\udb78\udced\ud929\ude61\udb76\udcf5\udb9a\uddd3\udb85\ude86\ud861\ude0d\udb87\ude53\uda1e\udcba\uda38\udc61\ud9b8\udd8b\udbf2\ude4d\udbf5\udc45]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udafd\udcce\ud8b6\udd5e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udafd\udcce\ud8b6\udd5e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb53\udfd4\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1b\udada\udf4c\ud94a\udc8b\ud9f4\ude09\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\uda5b\udd0d\u9146\ue57b\uda45\udd6d\udb34\ude19\ud950\ude35\udb1d\udf26\uf4da\000\udb19\udf2c\u2129\ud9ef\ude86\ud9fe\ude6d\udb09\uddaeS\000\ud863\udd04\ud9f2\udcfa\uda65\udd50\udbd9\ude16\udb2e\udeb8\udb7e\ude81\ud97d\udfb9\u5b21\udb49\udddc");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb53\udfd4\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1b\udada\udf4c\ud94a\udc8b\ud9f4\ude09\ud8cd\udcf8\udb3d\ude7c\udb52\udc04\udb40\udffd\uda5b\udd0d\u9146\ue57b\uda45\udd6d\udb34\ude19\ud950\ude35\udb1d\udf26\uf4da\000\udb19\udf2c\u2129\ud9ef\ude86\ud9fe\ude6d\udb09\uddaeS\000\ud863\udd04\ud9f2\udcfa\uda65\udd50\udbd9\ude16\udb2e\udeb8\udb7e\ude81\ud97d\udfb9\u5b21\udb49\udddc]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb53\udfd4\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1bk\000\000\000\000\ud857\udd8a\ud936\udef7\u8130F\ue57b\000\udb34\ude19\ud9dc\udd1a\000\000\000\000\000\000\ud9fe\ude4f\udb09\uddaeS\000\ud863\udd04\ud9f2\udcfa\uda65\udd50\udbd9\ude16\udb2e\udeb8\udb7e\uddb6\ud97d\udfb9\u5b21\udb49\udddc");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb53\udfd4\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1bk\000\000\000\000\ud857\udd8a\ud936\udef7\u8130F\ue57b\000\udb34\ude19\ud9dc\udd1a\000\000\000\000\000\000\ud9fe\ude4f\udb09\uddaeS\000\ud863\udd04\ud9f2\udcfa\uda65\udd50\udbd9\ude16\udb2e\udeb8\udb7e\uddb6\ud97d\udfb9\u5b21\udb49\udddc]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb53\udfd4\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1bk\000\000\000\000\ud857\udd8a\ud936\udef7\u8130F\ue57b\000\udb34\ude19\ud9dc\udd1a\000\000\000\000\000\000\ud9fe\ude4f\udb09\uddaeS\ud9d9\uddac\ud941\udf64\ud9f2\udd7d\uda65\udd04\udbd9\ude16\udb2e\udeb8\ud954\udf3d\udb3a\udff0\udb81\udd96\udb49\udddc");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb53\udfd4\000\udbf8\udc9bS\uda3d\udcfe\ud909\udc1bk\000\000\000\000\ud857\udd8a\ud936\udef7\u8130F\ue57b\000\udb34\ude19\ud9dc\udd1a\000\000\000\000\000\000\ud9fe\ude4f\udb09\uddaeS\ud9d9\uddac\ud941\udf64\ud9f2\udd7d\uda65\udd04\udbd9\ude16\udb2e\udeb8\ud954\udf3d\udb3a\udff0\udb81\udd96\udb49\udddc]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u00b2\udbde\udc97\uda20\udd0fa\ud92d\udc55\udaf7\udec6\ud9e4\udf79\uda61\udc81\u008f\ud9c1\ude0c\ud9f2\udda6\uda8d\udead\udb4e\udcb4a\uda12\ude68\udbf8\uddf3\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u00b2\udbde\udc97\uda20\udd0fa\ud92d\udc55\udaf7\udec6\ud9e4\udf79\uda61\udc81\u008f\ud9c1\ude0c\ud9f2\udda6\uda8d\udead\udb4e\udcb4a\uda12\ude68\udbf8\uddf3\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb70\udd9c\ud98b\udc9a\uda7b\udc0c\uda0f\udc80\ud866\udca0\udb48\udf5a'\uc7f8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb70\udd9c\ud98b\udc9a\uda7b\udc0c\uda0f\udc80\ud866\udca0\udb48\udf5a'\uc7f8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9a1\udef0\udbd0\udffb\uda7b\udc0c\ud9f4\udd39\ud882\udde3\ud986\udee2z\uda76\udcf9\ud998\udffbz\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud888\uded8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a1\udef0\udbd0\udffb\uda7b\udc0c\ud9f4\udd39\ud882\udde3\ud986\udee2z\uda76\udcf9\ud998\udffbz\ud9e5\udc92\uda1c\udc74\ud93a\udf5a\ud888\uded8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9b7\uddaa\uda03\udfe1\udad3\udf95\ud951\udda7\ud866\udca0\udb4f\udd5a'\ud990\udc26\uda46\udf3a\uda14\udd0c\uda39\ude88\ud9de\ude75\ud9d1\udf45\ud87e\udd08\udad4\udfb2\uda05\udf92\udb19\udda8\uda8f\udeda\u3365\ud8cb\udd03\uda07\udf15\ud82b\udc89\ud9c6\udea7\udbd4\udd5d\ud9f4\ude8a\ud914\uddd0\uda1e\udc3d\ud9ca\udf90\udbfa\udc80\uda33\udc7e\ud8a1\ude28\ud87c\udea8\uda11\udebb\udb8e\udfbb\ud871\udcd6\udad8\udee4\udb24\udeac\ud966\ude0a\udb66\udd13\ud9b3\udd51\udaa4\ude64\udbcd\udfad\ud9c5\ude7a\ud934\udea8\udb28\uddfb\ud906\udec9\ud8a2\udd5f\ud872\uddf2\udb8b\ude8e\ud99e\udcae\ua3bb\uda72\ude8a\ud9f6\udfa2\udabd\udcf1\udaa5\udcb0\ud8da\udd86\udbe7\udd44\ud86e\udd8f\uda06\udf1a\uda23\udc17\ud876\udd89\ud8a5\udf46\udb3f\udef2\ud87d\udd22\udbcb\udeb0\ud837\udf07\uc075\ud960\ude75\ud8b5\ude8e\udaf1\udc8d\udafd\udedb\ufdca\uda6c\udd17");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9b7\uddaa\uda03\udfe1\udad3\udf95\ud951\udda7\ud866\udca0\udb4f\udd5a'\ud990\udc26\uda46\udf3a\uda14\udd0c\uda39\ude88\ud9de\ude75\ud9d1\udf45\ud87e\udd08\udad4\udfb2\uda05\udf92\udb19\udda8\uda8f\udeda\u3365\ud8cb\udd03\uda07\udf15\ud82b\udc89\ud9c6\udea7\udbd4\udd5d\ud9f4\ude8a\ud914\uddd0\uda1e\udc3d\ud9ca\udf90\udbfa\udc80\uda33\udc7e\ud8a1\ude28\ud87c\udea8\uda11\udebb\udb8e\udfbb\ud871\udcd6\udad8\udee4\udb24\udeac\ud966\ude0a\udb66\udd13\ud9b3\udd51\udaa4\ude64\udbcd\udfad\ud9c5\ude7a\ud934\udea8\udb28\uddfb\ud906\udec9\ud8a2\udd5f\ud872\uddf2\udb8b\ude8e\ud99e\udcae\ua3bb\uda72\ude8a\ud9f6\udfa2\udabd\udcf1\udaa5\udcb0\ud8da\udd86\udbe7\udd44\ud86e\udd8f\uda06\udf1a\uda23\udc17\ud876\udd89\ud8a5\udf46\udb3f\udef2\ud87d\udd22\udbcb\udeb0\ud837\udf07\uc075\ud960\ude75\ud8b5\ude8e\udaf1\udc8d\udafd\udedb\ufdca\uda6c\udd17]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("d\ud94c\udfa9\uda90\udd2e\ud9f4\udd39\ud90c\ude37\udadb\udcedd\udae7\ude520\000\u6b50\ud923\udd77\ud93a\udfaa\ud87e\udcd8\udad8\uddf5\ud9ff\udfb0\ud820\udc11\ud874\udcc3\udabb\udd34\ud883\ude5a\ud828\udf1b\udbc8\udcf5");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[d\ud94c\udfa9\uda90\udd2e\ud9f4\udd39\ud90c\ude37\udadb\udcedd\udae7\ude520\000\u6b50\ud923\udd77\ud93a\udfaa\ud87e\udcd8\udad8\uddf5\ud9ff\udfb0\ud820\udc11\ud874\udcc3\udabb\udd34\ud883\ude5a\ud828\udf1b\udbc8\udcf5]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaa2\udebd\udb32\udfbb\uda7b\udc0cm\ud882\udde3\u58e9\ud8c3\udf8b\ud814\udf87m\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaa2\udebd\udb32\udfbb\uda7b\udc0cm\ud882\udde3\u58e9\ud8c3\udf8b\ud814\udf87m\ud881\udd4c\ud9f2\udda6\uda1c\udc74\ud93a\udf5a\ud87e\udcd8\udad4\udfb3\ud99a\udc49\ud8c5\udd9e\ud874\udcc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("K\udbca\udc31\uda20\udd0f\udbb3\udd91\ud82e\udfda\ud96b\uded2\udae8\ude04\uda5f\udd8eK\udb75\udd46\ud9f2\udda6\uda1c\udc74\udb67\udcea\000\ud917\udcf7\udad2\udfaa\uda5b\udddc\uda6b\ude1e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[K\udbca\udc31\uda20\udd0f\udbb3\udd91\ud82e\udfda\ud96b\uded2\udae8\ude04\uda5f\udd8eK\udb75\udd46\ud9f2\udda6\uda1c\udc74\udb67\udcea\000\ud917\udcf7\udad2\udfaa\uda5b\udddc\uda6b\ude1e]", String.valueOf(r));
  }
}
