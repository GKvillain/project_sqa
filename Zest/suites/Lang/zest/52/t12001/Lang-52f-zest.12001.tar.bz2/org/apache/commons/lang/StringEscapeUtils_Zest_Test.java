package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringEscapeUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\ud9d4\udc35\ud85d\udf22\ud96c\udf26\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\ud66b\udab8\udcc6\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#56050;&#57242;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#55764;&#56373;&#55389;&#57122;&#55660;&#57126;&#56059;&#57152;&#55540;&#57158;&#55991;&#56854;&#56280;&#56447;&#54891;&#55992;&#56518;&#55611;&#56572;&#56237;&#56645;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\uda83\udfcc\ud80d\udce8\udac8\udd2e\ud960\udc65\ud8e4\udd6c\uda99\ude37\ud9d4\udc35\ud85d\udf22\ud96c\udf26\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\ud8c5\udf32\udb93\udf0a\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55939;&#57292;&#55309;&#56552;&#56008;&#56622;&#55648;&#56421;&#55524;&#56684;&#55961;&#56887;&#55764;&#56373;&#55389;&#57122;&#55660;&#57126;&#56059;&#57152;&#55540;&#57158;&#55991;&#56854;&#56280;&#56447;&#55493;&#57138;&#56211;&#57098;&#55611;&#56572;&#56237;&#56645;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud89e\udf5a\udaf2\udef0\ud898\udda1\ud95d\udd2b\udbb7\ude2e\uda04\udcdb\ud9d4\udc35\ud85d\udf22\ud96c\udf26");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55454;&#57178;&#56050;&#57072;&#55448;&#56737;&#55645;&#56619;&#56247;&#56878;&#55812;&#56539;&#55764;&#56373;&#55389;&#57122;&#55660;&#57126;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\uda6f\ude66\ud8b6\udc1c\uda02\udf39\ud8eb\udc2f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55919;&#56934;&#55478;&#56348;&#55810;&#57145;&#55531;&#56367;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\ud9d4\udc35\ud85d\udf22\ud96c\udf26\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\u0088\udab8\udcc6\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#56050;&#57242;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#55764;&#56373;&#55389;&#57122;&#55660;&#57126;&#56059;&#57152;&#55540;&#57158;&#55991;&#56854;&#56280;&#56447;&#136;&#55992;&#56518;&#55611;&#56572;&#56237;&#56645;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\000\000\000\000\000\000\000\uda58\udc0b\000\ud9eb\udd01\ud9ab\udd95\ud8f4\udf46\000\000\000\u00fb\000\udbad\udd1a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000\000\000\000\000\000\000&#55896;&#56331;\000&#55787;&#56577;&#55723;&#56725;&#55540;&#57158;\000\000\000&#251;\000&#56237;&#56602;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\u7c3f\ud8c1\udccb\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd\udbd8\udc3f\udaea\udfc5\ud92c\ude08\ud85e\ude42\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7c3f\ud8c1\udccb\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd\udbd8\udc3f\udaea\udfc5\ud92c\ude08\ud85e\ude42\udbad\udd45", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud8e9\ude86\ud8c1\udccb\ud9a3\udd33\ud898\udd13\uda64\udeee\ud8d8\udfd5\uda99\ude37\ud9d4\udc35\ud85d\udf22");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55529;&#56966;&#55489;&#56523;&#55715;&#56627;&#55448;&#56595;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#55764;&#56373;&#55389;&#57122;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\u8b23\ud9bb\udcf8\ud91d\udfef\ud955\uddfc\uda7c\udf97\ud903\udf75\udad8\ude42\ud9cd\udefc\ud85d\udf22\ud96c\udf26\uda10\udcc1\udb9f\udec5\udaa4\udc3a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#35619;&#55739;&#56568;&#55581;&#57327;&#55637;&#56828;&#55932;&#57239;&#55555;&#57205;&#56024;&#56898;&#55757;&#57084;&#55389;&#57122;&#55660;&#57126;&#55824;&#56513;&#56223;&#57029;&#55972;&#56378;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeSql("\udbea\udd7d\ud8ff\udd2d\udaf4\udc2e\ud998\udc40\uda64\udf31\ud8d4\udee5\uda99\ude37\ud838\ude3f\ud9ca\ude90\uda2a\uddc6\u6048\uda19\udf98\ud855\uddd9\ud9b8\udf2f\udaf0\udfed\udb5f\udcc1\udadb\udc0e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbea\udd7d\ud8ff\udd2d\udaf4\udc2e\ud998\udc40\uda64\udf31\ud8d4\udee5\uda99\ude37\ud838\ude3f\ud9ca\ude90\uda2a\uddc6\u6048\uda19\udf98\ud855\uddd9\ud9b8\udf2f\udaf0\udfed\udb5f\udcc1\udadb\udc0e", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud996\ude90\ud8c1\udd22\ud960\ude6b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55702;&#56976;&#55489;&#56610;&#55648;&#56939;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud8b7\udd52");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55479;&#56658;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\ud98e\udf39\ud9f3\ude2a\udba5\udc6f\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\ud9d4\udc35\ud8e5\udf50\ud84b\udd45\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\ud66b\udab8\udcc6\ud962\uddbc\udbad\udd45\ud996\udc79\udbe1\udc76\ud834\udda4\ud8bd\udf5e\ud9c2\udddb\udade\udf82\u0f8e\ud85f\udfa8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55795;&#56874;&#56229;&#56431;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#55764;&#56373;&#55525;&#57168;&#55371;&#56645;&#56059;&#57152;&#55540;&#57158;&#55991;&#56854;&#56280;&#56447;&#54891;&#55992;&#56518;&#55650;&#56764;&#56237;&#56645;&#55702;&#56441;&#56289;&#56438;&#55348;&#56740;&#55485;&#57182;&#55746;&#56795;&#56030;&#57218;&#3982;&#55391;&#57256;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud8c1\udccb\ue4bd\000\000\ud8ca\udda5\u813b\000\000\000\ud90c\udc05\000\udab7\ude16\udbd8\udc7f\ud66b\ub0c1\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#58557;\000\000&#55498;&#56741;&#33083;\000\000\000&#55564;&#56325;\000&#55991;&#56854;&#56280;&#56447;&#54891;&#45249;&#55611;&#56572;&#56237;&#56645;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\ud9d4\udc35\ud85d\udf22\ud96c\udf26\ud912\uddab\000\000\udbd8\udc7f\ud66b\udab8\udcc6\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#56050;&#57242;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#55764;&#56373;&#55389;&#57122;&#55660;&#57126;&#55570;&#56747;\000\000&#56280;&#56447;&#54891;&#55992;&#56518;&#55611;&#56572;&#56237;&#56645;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\uda60\udcfc\udb49\ude8f\udaef\udcc5\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\udbca\udd7e\ud9c0\udf63\udb5a\udf34\ud888\udc67\ud8f4\udf46");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55904;&#56572;&#56137;&#56975;&#56047;&#56517;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#56266;&#56702;&#55744;&#57187;&#56154;&#57140;&#55432;&#56423;&#55540;&#57158;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\ud9d4\udc35\ud85d\udf22\ud96c\udf26\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\ubb88\000\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#56050;&#57242;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#55764;&#56373;&#55389;&#57122;&#55660;&#57126;&#56059;&#57152;&#55540;&#57158;&#55991;&#56854;&#56280;&#56447;&#48008;\000&#55611;&#56572;&#56237;&#56645;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud8c1\udccb\ud8c2\udd61\ud898\udda1\udaf4\uddb2\u7758\uda99\uded8\ud9d4\udc35\uda0a\udc25\ud96c\udf26\udabf\ude84\uaaef\udab7\ude16\ud87d\udf53\ud66b\ud98d\uddb2\udb89\udd03\udbad\udd45\uda8a\udcdb\uda51\udd9c\uda70\udd40\ud8c8\udd29\ue11e\udb8f\ude5a\ud9cf\udcd0\ud854\udeb6\ud800\udf80\u658e\ud8b7\udf03\udbb2\udc41\ud93b\udd30\ud9eb\ude81\udb1c\udfa4\udae6\ude74\ud9e9\udef9\ud9bb\udda6\ub3ac\ud82a\udd83\udb7b\udf91\ud972\udea2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#55490;&#56673;&#55448;&#56737;&#56052;&#56754;&#30552;&#55961;&#57048;&#55764;&#56373;&#55818;&#56357;&#55660;&#57126;&#55999;&#56964;&#43759;&#55991;&#56854;&#55421;&#57171;&#54891;&#55693;&#56754;&#56201;&#56579;&#56237;&#56645;&#55946;&#56539;&#55889;&#56732;&#55920;&#56640;&#55496;&#56617;&#57630;&#56207;&#56922;&#55759;&#56528;&#55380;&#57014;&#55296;&#57216;&#25998;&#55479;&#57091;&#56242;&#56385;&#55611;&#56624;&#55787;&#56961;&#56092;&#57252;&#56038;&#56948;&#55785;&#57081;&#55739;&#56742;&#45996;&#55338;&#56707;&#56187;&#57233;&#55666;&#56994;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJavaScript("\udbcf\udc54\udbd6\udc6f\ud897\udc5a\udb57\udfd9\udb32\udc36\ud8fb\udc9e\uda99\ude37\ud9d4\udc35\ud947\ude16\ud96c\udf67\udafb\udf40\udbe2\udc38\udb25\ude73\udbd8\udc7f\ud66b\udab8\udcc6\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbcf\udc54\udbd6\udc6f\ud897\udc5a\udb57\udfd9\udb32\udc36\ud8fb\udc9e\uda99\ude37\ud9d4\udc35\ud947\ude16\ud96c\udf67\udafb\udf40\udbe2\udc38\udb25\ude73\udbd8\udc7f\ud66b\udab8\udcc6\ud93b\udcfc\udbad\udd45", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\u617f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#24959;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\ud98e\udf39\ud8c1\udccb\ud9d6\ude8c\udb98\udd03\ud9b6\udfa5\ud8d8\udfd5\uda99\ude37\udb20\udf5e\ud9d2\udc4a\ud9df\udfc4\udafb\udf40\ud8d3\udcb4\udb77\ude3d\udb09\udf41\ue657\udab8\udcc6\udb34\udd0d\udbb0\udf43");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud98e\udf39\ud8c1\udccb\ud9d6\ude8c\udb98\udd03\ud9b6\udfa5\ud8d8\udfd5\uda99\ude37\udb20\udf5e\ud9d2\udc4a\ud9df\udfc4\udafb\udf40\ud8d3\udcb4\udb77\ude3d\udb09\udf41\ue657\udab8\udcc6\udb34\udd0d\udbb0\udf43", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8b2\udf83\ud9fb\udf1b\uda2b\udf83\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\udbd8\ude92\ud89a\uddd9\ud8c6\udf33\uda42\udd7d\ud9c0\udc47\udab7\ude16\ud903\udef6\ud8e1\ude01\udab8\udcc6\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8B2\\uDF83\\uD9FB\\uDF1B\\uDA2B\\uDF83\\uD898\\uDDA1\\uDA64\\uDEEE\\uD8D8\\uDFD5\\uDA99\\uDE37\\uDBD8\\uDE92\\uD89A\\uDDD9\\uD8C6\\uDF33\\uDA42\\uDD7D\\uD9C0\\uDC47\\uDAB7\\uDE16\\uD903\\uDEF6\\uD8E1\\uDE01\\uDAB8\\uDCC6\\uD93B\\uDCFC\\uDBAD\\uDD45", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\udaae\udc4c\udbf0\udf6a\ud866\udc94\uda99\udee6\ud9d4\udc35\ud8e5\udfe6\ud96c\udf26\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\ud66b\udab8\udcc6\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD98E\\uDF39\\uD8C1\\uDCCB\\uDAF2\\uDF9A\\uDAAE\\uDC4C\\uDBF0\\uDF6A\\uD866\\uDC94\\uDA99\\uDEE6\\uD9D4\\uDC35\\uD8E5\\uDFE6\\uD96C\\uDF26\\uDAFB\\uDF40\\uD8F4\\uDF46\\uDAB7\\uDE16\\uDBD8\\uDC7F\\uD66B\\uDAB8\\uDCC6\\uD93B\\uDCFC\\uDBAD\\uDD45", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud98e\udf39\ud8c1\udccb\ud836\ude55\ud896\ude11\ud93c\ude43\ud8d8\udfd5\uda93\udd31\udb04\udd22\ud948\udd30\ud94f\udcf2\u038c\ud902\uddb2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD98E\\uDF39\\uD8C1\\uDCCB\\uD836\\uDE55\\uD896\\uDE11\\uD93C\\uDE43\\uD8D8\\uDFD5\\uDA93\\uDD31\\uDB04\\uDD22\\uD948\\uDD30\\uD94F\\uDCF2\\u038C\\uD902\\uDDB2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud98e\udf39\ud8d9\udf1f\udaf2\udf9a\ud898\udda1\udb3c\udddd");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD98E\\uDF39\\uD8D9\\uDF1F\\uDAF2\\uDF9A\\uD898\\uDDA1\\uDB3C\\uDDDD", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udbb7\udffa\ud8a1\udeca\uda02\udf39\ud910\udc58\ud86c\udfb5\ud911\uddb8\udb7e\udedd\ud89e\uded1\uda29\udef2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbb7\udffa\ud8a1\udeca\uda02\udf39\ud910\udc58\ud86c\udfb5\ud911\uddb8\udb7e\udedd\ud89e\uded1\uda29\udef2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud98e\udef5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD98E\\uDEF5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud85c\uddee\uda38\udfbe\udbc7\udd9e\ud853\udd3e\uda64\udeee\ud82a\udc7d\uda99\ude09\ud9d4\udc35\ud85d\udf22\ud96c\udf26\udafb\udf40\ud918\udf77\ud89b\udf07\udbd8\udc3e\u0088\udab8\udcc6\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD85C\\uDDEE\\uDA38\\uDFBE\\uDBC7\\uDD9E\\uD853\\uDD3E\\uDA64\\uDEEE\\uD82A\\uDC7D\\uDA99\\uDE09\\uD9D4\\uDC35\\uD85D\\uDF22\\uD96C\\uDF26\\uDAFB\\uDF40\\uD918\\uDF77\\uD89B\\uDF07\\uDBD8\\uDC3E\\u0088\\uDAB8\\uDCC6\\uD93B\\uDCFC\\uDBAD\\uDD45", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\ud9d4\udc35\ud85d\udf22\ud96c\udf26\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\u0088\udab8\udcc6\udafc\udd5e\ud9d4\udccf\udac7\udc8b\ud9ae\udfe0\ub498\uda06\udd1f\udb93\ude4f\udbde\udf0c\ud9fc\udd3a\udb5e\ude5c\u78d5\udbdc\udec5\uda32\udede\ud8b3\ude1d\ud84e\udccf\ud8cf\uddf8\ud908\udf33\uf693\uda2d\udee6\udabd\ude38\udbae\udf30\ud9a6\udda0\ud9bc\uddae\ud95e\udda5\ud97b\udf55\udb28\udfa7\udb2e\udf11\ud804\ude71\uda07\udd21\ud849\udc59\udb8c\udc95\ud937\udd3d\udbad\udee7\ud853\udfa5\ud829\udf3b\udb57\udc5e\ud983\udf69\uda48\udf26\udbf8\udd89\ud83b\udc5f\ud8e6\udd6c\ud901\udc20\udb33\udd3e\udb03\ude59\ud4b9\ud80f\udd02\ud9ee\uddc8\uda63\uddcf\ubb08\udbf5\udce1\ud82a\udd10\udb84\udf41\ud9df\ude74\udab8\udd0a\udb3c\ude81\uda78\udd5f\ud8ec\udc46\ud91b\udc9e\udaaa\udd47\ud9e0\uddfe\uda9d\udf8d\uda90\udf36\udad3\udcd4\uda4b\uddaf\udbb0\ude2b\udba3\udfe0\uda7a\uddd3\uda50\udd60\ud946\udebe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#56050;&#57242;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#55764;&#56373;&#55389;&#57122;&#55660;&#57126;&#56059;&#57152;&#55540;&#57158;&#55991;&#56854;&#56280;&#56447;&#136;&#55992;&#56518;&#56060;&#56670;&#55764;&#56527;&#56007;&#56459;&#55726;&#57312;&#46232;&#55814;&#56607;&#56211;&#56911;&#56286;&#57100;&#55804;&#56634;&#56158;&#56924;&#30933;&#56284;&#57029;&#55858;&#57054;&#55475;&#56861;&#55374;&#56527;&#55503;&#56824;&#55560;&#57139;&#63123;&#55853;&#57062;&#55997;&#56888;&#56238;&#57136;&#55718;&#56736;&#55740;&#56750;&#55646;&#56741;&#55675;&#57173;&#56104;&#57255;&#56110;&#57105;&#55300;&#56945;&#55815;&#56609;&#55369;&#56409;&#56204;&#56469;&#55607;&#56637;&#56237;&#57063;&#55379;&#57253;&#55337;&#57147;&#56151;&#56414;&#55683;&#57193;&#55880;&#57126;&#56312;&#56713;&#55355;&#56415;&#55526;&#56684;&#55553;&#56352;&#56115;&#56638;&#56067;&#56921;&#54457;&#55311;&#56578;&#55790;&#56776;&#55907;&#56783;&#47880;&#56309;&#56545;&#55338;&#56592;&#56196;&#57153;&#55775;&#56948;&#55992;&#56586;&#56124;&#56961;&#55928;&#56671;&#55532;&#56390;&#55579;&#56478;&#55978;&#56647;&#55776;&#56830;&#55965;&#57229;&#55952;&#57142;&#56019;&#56532;&#55883;&#56751;&#56240;&#56875;&#56227;&#57312;&#55930;&#56787;&#55888;&#56672;&#55622;&#57022;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\ud98e\udf39\ud8bb\udfcb\ud973\udc20");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud98e\udf39\ud8bb\udfcb\ud973\udc20", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\000\ud8e7\udc88\u00b4\000\ud801\ude00\000\uda58\udc0b\000\uda62\ude47\u2747\udb1c\udcc1\ud84d\udee5\udafc\udf3d\uda63\ude9d\uda5d\udfb2\ud914\udfea\uda89\udf3b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\uD8E7\\uDC88\\u00B4\\u0000\\uD801\\uDE00\\u0000\\uDA58\\uDC0B\\u0000\\uDA62\\uDE47\\u2747\\uDB1C\\uDCC1\\uD84D\\uDEE5\\uDAFC\\uDF3D\\uDA63\\uDE9D\\uDA5D\\uDFB2\\uD914\\uDFEA\\uDA89\\uDF3B", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\000\000\000\000\000\000\uda58\udc0b\000\ud9eb\udd01\ud9ab\udd95\ud8df\udc03\000\000\000\u00fb\ud85c\udfbd\ud878\uddc4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uDA58\\uDC0B\\u0000\\uD9EB\\uDD01\\uD9AB\\uDD95\\uD8DF\\uDC03\\u0000\\u0000\\u0000\\u00FB\\uD85C\\uDFBD\\uD878\\uDDC4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\u00c2\000\000\ud820\ude9b\000\ud878\udf41\u5628\uda58\udc0b\000\ud936\udd47\ud9ec\uddf4\ud8e0\udd26\udadc\ude8e\ud9b5\udc95\u00ad\u00fb\000\u9a1f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&Acirc;\000\000&#55328;&#56987;\000&#55416;&#57153;&#22056;&#55896;&#56331;\000&#55606;&#56647;&#55788;&#56820;&#55520;&#56614;&#56028;&#56974;&#55733;&#56469;&shy;&ucirc;\000&#39455;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\000\000\000\000\000\000\000\uda58\udc0b<\ud9eb\udd01\ud9ab\udd95\ud8f4\udf46\000\000\000\u00fb\000\udbad\udd1a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000\000\000\000\000\000\000&#55896;&#56331;&lt;&#55787;&#56577;&#55723;&#56725;&#55540;&#57158;\000\000\000&#251;\000&#56237;&#56602;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udaae\ude57\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaae\ude57\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udbbe\udef1\ud992\udf56\uda7c\udf95\000\ud9b5\udc3a\u0890\udb31\udeb7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbbe\udef1\ud992\udf56\uda7c\udf95\000\ud9b5\udc3a\u0890\udb31\udeb7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("o\000\ud813\udd01\udb83\udccc\ud95c\udc0d\000\000\udb94\udf03\000\ud9eb\udd58\ud9ab\udd95\uea69\uc3dd\udbf2\udf39\uda39\udf52\udb90\udd22\ud8de\ude57\ud87f\udea3\udbb8\udd2f\ud8bd\uded1\ud952\udfad\udbf0\udc40\ud933\udda9\ud808\udc3b\udad9\uddf3\ud845\udd2d\udbf4\udf15\ud919\udf6b\uda38\udce3\ud92f\udd34\udb66\udc92\udb90\udc70\uda4c\udcfb\ud857\ude46\ud977\udd1b\udae0\udc1a\ud985\udc29\ud83c\udfe9\ud8b4\udd75\udbd6\udfff\ud8dc\udfe5\ud882\udf61\ud882\ude23\ud944\udd2c\u4436\uda4e\ude91\udb6a\udfd5\ud88b\udcf8\ud984\udf9a\udacc\udf4c\ud9f5\uddcd\ud86d\udd4a\uda8f\udc3e\ud9ad\ude89\udb2f\udce3\ud86d\udf90\ud980\udd9e\ud95c\udf44\udbbc\udcdc\ufe6d\ud83d\udd16\ud892\udc0f\ud9f4\udd75\udbc6\ude60\udbb4\udd6d\ud833\udff1\uda2a\udea1\ud9a8\udcc7\udbc1\udca6\udb34\ude28\udb29\udf78\u4706");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("o\000\ud813\udd01\udb83\udccc\ud95c\udc0d\000\000\udb94\udf03\000\ud9eb\udd58\ud9ab\udd95\uea69\uc3dd\udbf2\udf39\uda39\udf52\udb90\udd22\ud8de\ude57\ud87f\udea3\udbb8\udd2f\ud8bd\uded1\ud952\udfad\udbf0\udc40\ud933\udda9\ud808\udc3b\udad9\uddf3\ud845\udd2d\udbf4\udf15\ud919\udf6b\uda38\udce3\ud92f\udd34\udb66\udc92\udb90\udc70\uda4c\udcfb\ud857\ude46\ud977\udd1b\udae0\udc1a\ud985\udc29\ud83c\udfe9\ud8b4\udd75\udbd6\udfff\ud8dc\udfe5\ud882\udf61\ud882\ude23\ud944\udd2c\u4436\uda4e\ude91\udb6a\udfd5\ud88b\udcf8\ud984\udf9a\udacc\udf4c\ud9f5\uddcd\ud86d\udd4a\uda8f\udc3e\ud9ad\ude89\udb2f\udce3\ud86d\udf90\ud980\udd9e\ud95c\udf44\udbbc\udcdc\ufe6d\ud83d\udd16\ud892\udc0f\ud9f4\udd75\udbc6\ude60\udbb4\udd6d\ud833\udff1\uda2a\udea1\ud9a8\udcc7\udbc1\udca6\udb34\ude28\udb29\udf78\u4706", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\000\000\000\000\000\000\000\000\000\000\ud9ab\udd95\ud8f4\ude5c\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000\000\000\000\000\000\000\000\000\000&#55723;&#56725;&#55540;&#56924;\000\000\000\000\000\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud967\udc17\u0636\uda20\udd0f\udafa\udeb3\udb7b\uddfe\uda26\udd87\u8b00\ud8c8\udc03\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD967\\uDC17\\u0636\\uDA20\\uDD0F\\uDAFA\\uDEB3\\uDB7B\\uDDFE\\uDA26\\uDD87\\u8B00\\uD8C8\\uDC03\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\uda55\udfbd\u2853\ud88b\udce4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA55\\uDFBD\\u2853\\uD88B\\uDCE4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeSql("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJavaScript("\uba00");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uba00", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJavaScript("\ud998\udc59\udbd0\udd7c\ud897\udc5a\udb57\udfd9\udb8c\udeaf\uf16f\ud883\udd4b\udb1d\uddeb\ud947\uddbd\ud96c\udf67\udafb\udf40\udbe2\udc38\udb25\ude73\udbd8\udc7f\ud66b\udab8\udcc6\ud93b\udcfc\udbad\udd45\ud95d\udd0a\udaa2\udc20\ud971\uddec\udba3\ude3d\udb17\udd22\ud9ae\ude18\udaf4\udf19\uda47\udcb5\ud801\uddd5\udb08\ude18\ud896\udf60\u2a1c\uda79\udcee\u242a\uda4a\udea6\ud82e\udc58\ud98b\udfc3\ud81d\udf7d\udba3\ude30");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud998\udc59\udbd0\udd7c\ud897\udc5a\udb57\udfd9\udb8c\udeaf\uf16f\ud883\udd4b\udb1d\uddeb\ud947\uddbd\ud96c\udf67\udafb\udf40\udbe2\udc38\udb25\ude73\udbd8\udc7f\ud66b\udab8\udcc6\ud93b\udcfc\udbad\udd45\ud95d\udd0a\udaa2\udc20\ud971\uddec\udba3\ude3d\udb17\udd22\ud9ae\ude18\udaf4\udf19\uda47\udcb5\ud801\uddd5\udb08\ude18\ud896\udf60\u2a1c\uda79\udcee\u242a\uda4a\udea6\ud82e\udc58\ud98b\udfc3\ud81d\udf7d\udba3\ude30", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("M");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("M", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8b2\udf83\000\u00a5\000\uda64\udeee\ud8d8\udfa5\uda99\ude37\udbd8\ude92\ud89a\uddd9\ud8c6\udf33\uda42\udd7d\000\udac5\uddc2\ud903\udef6\ud8e1\ude01\udab8\udcc6\ud93b\udcfc\udbad\udd1a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8B2\\uDF83\\u0000\\u00A5\\u0000\\uDA64\\uDEEE\\uD8D8\\uDFA5\\uDA99\\uDE37\\uDBD8\\uDE92\\uD89A\\uDDD9\\uD8C6\\uDF33\\uDA42\\uDD7D\\u0000\\uDAC5\\uDDC2\\uD903\\uDEF6\\uD8E1\\uDE01\\uDAB8\\uDCC6\\uD93B\\uDCFC\\uDBAD\\uDD1A", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8b2\udf83\ud9fb\udf1b\uda2b\udf83\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\udbd8\ude92\ud89a\uddd9\ud8c6\udf33\uda42\udd7d\ud9c0\udc47\udab7\ude16\ud903\udef6\ud8e1\ude01\udab8\udcc6\ud93b\udcfc\ud8d8\udf99\udac5\udc1d\ud8b8\udd03\ud940\udd54\ud97b\udd70\udad8\uddc9\udbcb\udf64\udb5c\udcf1\ud804\uded9\ud915\udd2f\ud9bf\ude2c\u92d4\ud8ad\ude20\udbae\udca2\ud8bf\udfe9\udbe4\ude8c\ud9d7\udeb8\ud845\uddcd\udbc2\udc72\udab3\udd9b\ud89d\udd89\ud8e5\udc61\udb6e\udfb6\udb96\udeb3\ud8ad\udf49\uf5a1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8B2\\uDF83\\uD9FB\\uDF1B\\uDA2B\\uDF83\\uD898\\uDDA1\\uDA64\\uDEEE\\uD8D8\\uDFD5\\uDA99\\uDE37\\uDBD8\\uDE92\\uD89A\\uDDD9\\uD8C6\\uDF33\\uDA42\\uDD7D\\uD9C0\\uDC47\\uDAB7\\uDE16\\uD903\\uDEF6\\uD8E1\\uDE01\\uDAB8\\uDCC6\\uD93B\\uDCFC\\uD8D8\\uDF99\\uDAC5\\uDC1D\\uD8B8\\uDD03\\uD940\\uDD54\\uD97B\\uDD70\\uDAD8\\uDDC9\\uDBCB\\uDF64\\uDB5C\\uDCF1\\uD804\\uDED9\\uD915\\uDD2F\\uD9BF\\uDE2C\\u92D4\\uD8AD\\uDE20\\uDBAE\\uDCA2\\uD8BF\\uDFE9\\uDBE4\\uDE8C\\uD9D7\\uDEB8\\uD845\\uDDCD\\uDBC2\\uDC72\\uDAB3\\uDD9B\\uD89D\\uDD89\\uD8E5\\uDC61\\uDB6E\\uDFB6\\uDB96\\uDEB3\\uD8AD\\uDF49\\uF5A1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8b2\udf83\ud9fb\udf1b\uda2b\udf83\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\udbd8\ude92\ud89a\uddd9\ud8c6\udf33\udaea\udd71\u0093\000\ud8e0\udd90\ud838\udf2d\uda99\udccb\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8B2\\uDF83\\uD9FB\\uDF1B\\uDA2B\\uDF83\\uD898\\uDDA1\\uDA64\\uDEEE\\uD8D8\\uDFD5\\uDA99\\uDE37\\uDBD8\\uDE92\\uD89A\\uDDD9\\uD8C6\\uDF33\\uDAEA\\uDD71\\u0093\\u0000\\uD8E0\\uDD90\\uD838\\uDF2D\\uDA99\\uDCCB\\uD93B\\uDCFC\\uDBAD\\uDD45", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\ud8c1\udccb\udaf2\udf9a\udaae\udc4c\017\ud845\udee1\uda99\udee6\ud9d4\udc35\ud8e5\udfe6\udb81\ude24\ud912\uddab\ud8f4\udf46\udab7\ude16\udbd8\udc7f\udb8c\udf96\udab7\udfcb\ud93b\udcfc\ue02b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uD8C1\\uDCCB\\uDAF2\\uDF9A\\uDAAE\\uDC4C\\u000F\\uD845\\uDEE1\\uDA99\\uDEE6\\uD9D4\\uDC35\\uD8E5\\uDFE6\\uDB81\\uDE24\\uD912\\uDDAB\\uD8F4\\uDF46\\uDAB7\\uDE16\\uDBD8\\uDC7F\\uDB8C\\uDF96\\uDAB7\\uDFCB\\uD93B\\uDCFC\\uE02B", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud98e\udf39\ud8c1\udccb\u00bd\udab2\udc78\udbf0\udf6a\u00b3\uda99\uddfc\uda96\udcd7\000\000\000\ud8ae\udd57\u7800\udbd8\udc7f\ud66b\u7bfb\udbf3\udf06\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD98E\\uDF39\\uD8C1\\uDCCB\\u00BD\\uDAB2\\uDC78\\uDBF0\\uDF6A\\u00B3\\uDA99\\uDDFC\\uDA96\\uDCD7\\u0000\\u0000\\u0000\\uD8AE\\uDD57\\u7800\\uDBD8\\uDC7F\\uD66B\\u7BFB\\uDBF3\\uDF06\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ub6c9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uB6C9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud961\udc70\ud8c1\udccb\ud836\ude55\ud896\ude11\ud92a\ude54\ud8d8\udfd5\uda93\udd31\udb04\udd22\ud948\udd30\020\000\ud8de\udd2e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD961\\uDC70\\uD8C1\\uDCCB\\uD836\\uDE55\\uD896\\uDE11\\uD92A\\uDE54\\uD8D8\\uDFD5\\uDA93\\uDD31\\uDB04\\uDD22\\uD948\\uDD30\\u0010\\u0000\\uD8DE\\uDD2E", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud961\udd39\u733a\u0ebd\000\000\000\ud9f9\udd24\udb04\udd22\ud948\udd30\ud94f\udcf2\u038c\ud902\uddb2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD961\\uDD39\\u733A\\u0EBD\\u0000\\u0000\\u0000\\uD9F9\\uDD24\\uDB04\\uDD22\\uD948\\uDD30\\uD94F\\uDCF2\\u038C\\uD902\\uDDB2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud85c\uddee\u5b8e\ud887\udec3\ud853\udd3ef\000\000\ud9d4\udc35\ud85d\udf22\ud9eb\udd45\000\ud8d2\udd88J\ud9e2\udf10\u0088\udab8\udcc6\udbf3\udff9\ud9a5\udd11");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD85C\\uDDEE\\u5B8E\\uD887\\uDEC3\\uD853\\uDD3Ef\\u0000\\u0000\\uD9D4\\uDC35\\uD85D\\uDF22\\uD9EB\\uDD45\\u0000\\uD8D2\\uDD88J\\uD9E2\\uDF10\\u0088\\uDAB8\\uDCC6\\uDBF3\\uDFF9\\uD9A5\\uDD11", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\ud9d4\udc35\ud85d\udf22\ud96c\udf26\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\u0088\udab8\udcc6\udafc\udd5e\ud9d4\udccf\udac7\udc8b\ud9ae\udfe0\ub498\uda06\udd1f\udb93\ude4f\udbde\udf0c\ud9fc\udd3a\udb5e\ude5c\u78d5\udbdc\udec5\uda32\udede\ud8b3\ude1d\ud84e\udccf\ud8cf\uddf8\ud908\udf33\uf693\uda2d\udee6\udabd\ude38\udbae\udf30\ud9a6\udda0\ud9bc\uddae\ud95e\udda5\ud97b\udf55\udb28\udfa7\udb2e\udf11\ud804\ude71\uda07\udd21\ud849\udc59\ud8bc\ude2d\ud89e\udd25\udbad\udee7\ud853\udfa5\ud829\udf3b\udb57\udc5e\ud983\udf69\uda48\udf26\udbf8\udd89\ud83b\udc5f\ud8e6\udd6c\ud901\udc20\udb33\udd3e\udb03\ude59\ud4b9\ud80f\udd02\ud9ee\uddc8\uda63\uddcf\ubb08\udbf5\udce1\ud82a\udd10\udb84\udf41\ud9df\ude74\udab8\udd0a\udb3c\ude81\uda78\udd5f\ud8ec\udc46\ud91b\udc9e\udaaa\udd47\ud9e0\uddfe\uda9d\udf8d\uda90\udf36\udad3\udcd4\uda4b\uddaf\udbb0\ude2b\udba3\udfe0\uda7a\uddd3\uda50\udd60\ud946\udebe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#56050;&#57242;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#55764;&#56373;&#55389;&#57122;&#55660;&#57126;&#56059;&#57152;&#55540;&#57158;&#55991;&#56854;&#56280;&#56447;&#136;&#55992;&#56518;&#56060;&#56670;&#55764;&#56527;&#56007;&#56459;&#55726;&#57312;&#46232;&#55814;&#56607;&#56211;&#56911;&#56286;&#57100;&#55804;&#56634;&#56158;&#56924;&#30933;&#56284;&#57029;&#55858;&#57054;&#55475;&#56861;&#55374;&#56527;&#55503;&#56824;&#55560;&#57139;&#63123;&#55853;&#57062;&#55997;&#56888;&#56238;&#57136;&#55718;&#56736;&#55740;&#56750;&#55646;&#56741;&#55675;&#57173;&#56104;&#57255;&#56110;&#57105;&#55300;&#56945;&#55815;&#56609;&#55369;&#56409;&#55484;&#56877;&#55454;&#56613;&#56237;&#57063;&#55379;&#57253;&#55337;&#57147;&#56151;&#56414;&#55683;&#57193;&#55880;&#57126;&#56312;&#56713;&#55355;&#56415;&#55526;&#56684;&#55553;&#56352;&#56115;&#56638;&#56067;&#56921;&#54457;&#55311;&#56578;&#55790;&#56776;&#55907;&#56783;&#47880;&#56309;&#56545;&#55338;&#56592;&#56196;&#57153;&#55775;&#56948;&#55992;&#56586;&#56124;&#56961;&#55928;&#56671;&#55532;&#56390;&#55579;&#56478;&#55978;&#56647;&#55776;&#56830;&#55965;&#57229;&#55952;&#57142;&#56019;&#56532;&#55883;&#56751;&#56240;&#56875;&#56227;&#57312;&#55930;&#56787;&#55888;&#56672;&#55622;&#57022;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\000\ud8e7\udc88\u00b4\udb7b\udd5c\udb68\uddd9\003\uda58\udc0b\ud8b7\udee1\uda62\udea8\u2747\udb1c\udcc1\ud84d\udee5\udafc\udf3d\uda63\ude9d\uda5d\udfb2\ud914\udfea\ud9ea\udf0c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\uD8E7\\uDC88\\u00B4\\uDB7B\\uDD5C\\uDB68\\uDDD9\\u0003\\uDA58\\uDC0B\\uD8B7\\uDEE1\\uDA62\\uDEA8\\u2747\\uDB1C\\uDCC1\\uD84D\\uDEE5\\uDAFC\\uDF3D\\uDA63\\uDE9D\\uDA5D\\uDFB2\\uD914\\uDFEA\\uD9EA\\uDF0C", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\u0b65\udb91\udd8d\uda92\udccb\ub709\uda82\udfb8/\udb7f\udcfe\uf300\uda62\ude47\ud878\udc3c\udb1c\udcc1\ud84d\udee5\udafc\udf3d\uda63\udf4e\uda5d\udfb2\ud914\udfea\uda89\udf3b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0B65\\uDB91\\uDD8D\\uDA92\\uDCCB\\uB709\\uDA82\\uDFB8\\/\\uDB7F\\uDCFE\\uF300\\uDA62\\uDE47\\uD878\\uDC3C\\uDB1C\\uDCC1\\uD84D\\uDEE5\\uDAFC\\uDF3D\\uDA63\\uDF4E\\uDA5D\\uDFB2\\uD914\\uDFEA\\uDA89\\uDF3B", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\u00c2\000\000\ud820\ude9b\u00ed\ud878\udf41\u5628\uda58\udc0b\000\ud936\udd47\ud9ec\uddc8\ud8e0\udd26\udadc\ude8e\ud9b5\udc95\u00ad\u00fb\000\u9a1f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&Acirc;\000\000&#55328;&#56987;&iacute;&#55416;&#57153;&#22056;&#55896;&#56331;\000&#55606;&#56647;&#55788;&#56776;&#55520;&#56614;&#56028;&#56974;&#55733;&#56469;&shy;&ucirc;\000&#39455;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\u00c2\000\000\udaeb\udf60\u2663\ud878\udf41\u5628\uda58\udc0b\000\ud936\udd47\ud9ec\uddf4\ud8e0\udd26\udadc\ude8e\ud9b5\udc95\u00ad\u00fb\ud88a\udee5\u9a1f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&Acirc;\000\000&#56043;&#57184;&clubs;&#55416;&#57153;&#22056;&#55896;&#56331;\000&#55606;&#56647;&#55788;&#56820;&#55520;&#56614;&#56028;&#56974;&#55733;&#56469;&shy;&ucirc;&#55434;&#57061;&#39455;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud961\udc70\ud8b3\udfcb\ud836\ude55\ud896\ude11\ud9e6\ude72\ud8c3\udd9b\uda93\udd7e\udb01\uddd5\ud948\udd30\004\ud9cb\udfa5\ud819\udc00");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD961\\uDC70\\uD8B3\\uDFCB\\uD836\\uDE55\\uD896\\uDE11\\uD9E6\\uDE72\\uD8C3\\uDD9B\\uDA93\\uDD7E\\uDB01\\uDDD5\\uD948\\uDD30\\u0004\\uD9CB\\uDFA5\\uD819\\uDC00", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\001\ud8e7\udc88\u00b4\udb7b\udd5c\udb68\uddd9\003\uda58\udc0b\udabb\ude02\udb80\udd93\u9567\udb83\udf1d\udad3\udfe1\udafc\udf3d\uda63\ude9d\uda5d\udfb2\ud914\udfea\ud9ea\udf0c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0001\\uD8E7\\uDC88\\u00B4\\uDB7B\\uDD5C\\uDB68\\uDDD9\\u0003\\uDA58\\uDC0B\\uDABB\\uDE02\\uDB80\\uDD93\\u9567\\uDB83\\uDF1D\\uDAD3\\uDFE1\\uDAFC\\uDF3D\\uDA63\\uDE9D\\uDA5D\\uDFB2\\uD914\\uDFEA\\uD9EA\\uDF0C", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("'\u479e\ud8e7\udc88\u00b4\udb7b\udd5c\ud80f\udd2d\u09e0\uda58\udc0b\ud919\udd6c\ud880\ude77\udaed\udd8a\udb05\udc1e\ud84d\udee5\udafc\udf3d\uda63\ude9d\uda5d\udfb2\ud914\udfea\uda20\udea8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\'\\u479E\\uD8E7\\uDC88\\u00B4\\uDB7B\\uDD5C\\uD80F\\uDD2D\\u09E0\\uDA58\\uDC0B\\uD919\\uDD6C\\uD880\\uDE77\\uDAED\\uDD8A\\uDB05\\uDC1E\\uD84D\\uDEE5\\uDAFC\\uDF3D\\uDA63\\uDE9D\\uDA5D\\uDFB2\\uD914\\uDFEA\\uDA20\\uDEA8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("'\udbee\udfa2\ud9b7\ude90\udb5a\ude28\ud8c7\udd7f\ud80f\udef5\u09e0\uda58\udc0b\ud97e\udddd\ud880\ude6e\udb7d\udc35\ud89e\ude3b\uda54\udc69\udb18\udcc4\uda63\ude9d\u8f59\u165b\udb0d\udfaa");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("'\\uDBEE\\uDFA2\\uD9B7\\uDE90\\uDB5A\\uDE28\\uD8C7\\uDD7F\\uD80F\\uDEF5\\u09E0\\uDA58\\uDC0B\\uD97E\\uDDDD\\uD880\\uDE6E\\uDB7D\\uDC35\\uD89E\\uDE3B\\uDA54\\uDC69\\uDB18\\uDCC4\\uDA63\\uDE9D\\u8F59\\u165B\\uDB0D\\uDFAA", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeSql("'\udbee\udfa2\ud8d1\uddbd\uda0e\udfc4\ud857\udf40\udb37\udff1\u09e0\uda58\udc0b\ud97e\udddd\ud880\udee0\udb7d\udc35\udade\udfdd\uda54\udc69\ud9b7\udee0\uda2e\udff9\u8f59\u165b\udb0d\udfaa");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("''\udbee\udfa2\ud8d1\uddbd\uda0e\udfc4\ud857\udf40\udb37\udff1\u09e0\uda58\udc0b\ud97e\udddd\ud880\udee0\udb7d\udc35\udade\udfdd\uda54\udc69\ud9b7\udee0\uda2e\udff9\u8f59\u165b\udb0d\udfaa", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\udba7\udcd4\ud889\udc05\ud888\udef0\uda64\udeee\ud8d8\udfd5\uda99\ude37\udaca\udd31\udb8e\udfba\ud8a8\udf5d\ud8d7\udfca\udada\udc13\udaa7\udef6\udbd8\udc97\ud8e7\udf44\udad4\ude5d\udafd\udf61\udb1e\udd54");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#56231;&#56532;&#55433;&#56325;&#55432;&#57072;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#56010;&#56625;&#56206;&#57274;&#55464;&#57181;&#55511;&#57290;&#56026;&#56339;&#55975;&#57078;&#56280;&#56471;&#55527;&#57156;&#56020;&#56925;&#56061;&#57185;&#56094;&#56660;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\ud898\udda1\uda64\udeee\udb9a\udf15\ud9f7\udc03\ud9bb\udd43\ud85d\udf22\ud96c\udf26\udafb\udf40\ud8f4\udf46\udab7\ude16\udbd8\udc7f\u0088\udab8\udcc6\udafc\udd5e\ud9d4\udccf\udac7\udc8b\ud9ae\udfe0\ub498\uda06\udd1f\udb93\ude4f\udbde\udf0c\ud9fc\udd3a\udb5e\ude5c\u78d5\udbdc\udec5\uda32\udede\ud8b3\uddc1\ud89e\ude17\ud972\ude3d\ud908\ude95\uf693\udbd8\ude3a\udb8f\udd4c\ud9f2\ude47\ud9d3\udea0\ud9bc\uddae\udab3\udd9f\ud97b\udf55\udb28\udfa7\udb2e\udf11\uda4b\ude24\uda07\udd21\ud849\udc59\udb8c\udc95\ud937\udd3d\udbad\udee7\ud853\udfa5\ud829\udf3b\udb57\udc5e\ud983\udf69\uda48\udf26\udbf8\udd89\ud83b\udc5f\ud8e6\udd6c\ud901\udc20\udb33\udd3e\udb03\ude59\ud4b9\ud80f\udd02\uda0e\udfc8\uda63\uddcf\ubb08\udbf5\udce1\ud82a\udd10\udb84\udf41\ud9df\ude74\udab8\udd0a\uda9d\ude52\uda78\udd5f\ud8ec\udc46\ud91b\udc9e\udaaa\udd47\ud9e0\uddfe\uda9d\udf8d\uda90\udf36\udad3\udcd4\ud8a5\udffc\udbb0\ude2b\udba3\udfe0\uda7a\uddd3\uda50\udd60\ud946\udebe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD98E\\uDF39\\uD8C1\\uDCCB\\uDAF2\\uDF9A\\uD898\\uDDA1\\uDA64\\uDEEE\\uDB9A\\uDF15\\uD9F7\\uDC03\\uD9BB\\uDD43\\uD85D\\uDF22\\uD96C\\uDF26\\uDAFB\\uDF40\\uD8F4\\uDF46\\uDAB7\\uDE16\\uDBD8\\uDC7F\\u0088\\uDAB8\\uDCC6\\uDAFC\\uDD5E\\uD9D4\\uDCCF\\uDAC7\\uDC8B\\uD9AE\\uDFE0\\uB498\\uDA06\\uDD1F\\uDB93\\uDE4F\\uDBDE\\uDF0C\\uD9FC\\uDD3A\\uDB5E\\uDE5C\\u78D5\\uDBDC\\uDEC5\\uDA32\\uDEDE\\uD8B3\\uDDC1\\uD89E\\uDE17\\uD972\\uDE3D\\uD908\\uDE95\\uF693\\uDBD8\\uDE3A\\uDB8F\\uDD4C\\uD9F2\\uDE47\\uD9D3\\uDEA0\\uD9BC\\uDDAE\\uDAB3\\uDD9F\\uD97B\\uDF55\\uDB28\\uDFA7\\uDB2E\\uDF11\\uDA4B\\uDE24\\uDA07\\uDD21\\uD849\\uDC59\\uDB8C\\uDC95\\uD937\\uDD3D\\uDBAD\\uDEE7\\uD853\\uDFA5\\uD829\\uDF3B\\uDB57\\uDC5E\\uD983\\uDF69\\uDA48\\uDF26\\uDBF8\\uDD89\\uD83B\\uDC5F\\uD8E6\\uDD6C\\uD901\\uDC20\\uDB33\\uDD3E\\uDB03\\uDE59\\uD4B9\\uD80F\\uDD02\\uDA0E\\uDFC8\\uDA63\\uDDCF\\uBB08\\uDBF5\\uDCE1\\uD82A\\uDD10\\uDB84\\uDF41\\uD9DF\\uDE74\\uDAB8\\uDD0A\\uDA9D\\uDE52\\uDA78\\uDD5F\\uD8EC\\uDC46\\uD91B\\uDC9E\\uDAAA\\uDD47\\uD9E0\\uDDFE\\uDA9D\\uDF8D\\uDA90\\uDF36\\uDAD3\\uDCD4\\uD8A5\\uDFFC\\uDBB0\\uDE2B\\uDBA3\\uDFE0\\uDA7A\\uDDD3\\uDA50\\uDD60\\uD946\\uDEBE", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\udbcb\udceb\ud905\ude83\ud899\udf4f\\\ud969\udd73\ud801\ude1a\000\uda58\udc0b\ud4e5\ud931\ude09\udbba\udf33\udb1c\udcc1\ud8b5\uddee\udb06\udde2\ud99c\udd32\ud93c\udd13\ud914\udfea");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDBCB\\uDCEB\\uD905\\uDE83\\uD899\\uDF4F\\\\\\uD969\\uDD73\\uD801\\uDE1A\\u0000\\uDA58\\uDC0B\\uD4E5\\uD931\\uDE09\\uDBBA\\uDF33\\uDB1C\\uDCC1\\uD8B5\\uDDEE\\uDB06\\uDDE2\\uD99C\\uDD32\\uD93C\\uDD13\\uD914\\uDFEA", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\005\udbb1\udc6b\ud89a\udc7d\udb4c\udff9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0005\\uDBB1\\uDC6B\\uD89A\\uDC7D\\uDB4C\\uDFF9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\udb37\udce1\udb09\udd2a\ud949\udd2b\002\ud969\uddf3\ud801\ude1a\000\uda58\udc0b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB37\\uDCE1\\uDB09\\uDD2A\\uD949\\uDD2B\\u0002\\uD969\\uDDF3\\uD801\\uDE1A\\u0000\\uDA58\\uDC0B", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJavaScript("\udbb9\udd2f\ud905\ude83\ud899\udf4f\\\ud969\udd73\ud801\ude1a\000\uda58\udc0b\ud4e5\udb21\udde0\udb3f\udd9c\uda1c\ude20\uda97\udf9e\uda24\udd32\udb7b\udc58\ud93c\udd13\ud914\udfea\ud8f7\udeea\ud942\udec8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbb9\udd2f\ud905\ude83\ud899\udf4f\ud969\udd73\ud801\ude1a\000\uda58\udc0b\ud4e5\udb21\udde0\udb3f\udd9c\uda1c\ude20\uda97\udf9e\uda24\udd32\udb7b\udc58\ud93c\udd13\ud914\udfea\ud8f7\udeea\ud942\udec8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJavaScript("\ud8b8\uded3\uda92\udd01\ud899\udf4f\\");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8b8\uded3\uda92\udd01\ud899\udf4f\\", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud98e\udf39\ud8c1\udccb\udaf2\udf9a\ud898\udda1\uda64\udeee\ud8d8\udfd5\uda99\ude37\u9536\udafd\udc51\uda3a\udce4\udafb\udedd\ud8f4\udf46\udab7\ude16\udbd8\udc7f\ud66b\udab8\udcc6\ud93b\udcfc\udbad\udd45");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55694;&#57145;&#55489;&#56523;&#56050;&#57242;&#55448;&#56737;&#55908;&#57070;&#55512;&#57301;&#55961;&#56887;&#38198;&#56061;&#56401;&#55866;&#56548;&#56059;&#57053;&#55540;&#57158;&#55991;&#56854;&#56280;&#56447;&#54891;&#55992;&#56518;&#55611;&#56572;&#56237;&#56645;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud85c\uddee\uda1d\udf90\ub931\ud853\udd3e\uda64\udeee\ud82a\udc7d\udb7f\udedc\udb88\ude05\ud810\udfe4\ud934\udc33\udafb\udee6\ud918\udf77\udb43\udefb\ud8f6\udc8d\"\ud8d5\uded6\uda15\uded7\udb44\udcd8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD85C\\uDDEE\\uDA1D\\uDF90\\uB931\\uD853\\uDD3E\\uDA64\\uDEEE\\uD82A\\uDC7D\\uDB7F\\uDEDC\\uDB88\\uDE05\\uD810\\uDFE4\\uD934\\uDC33\\uDAFB\\uDEE6\\uD918\\uDF77\\uDB43\\uDEFB\\uD8F6\\uDC8D\\\"\\uD8D5\\uDED6\\uDA15\\uDED7\\uDB44\\uDCD8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\021\ud8c1\udccb\udaf2\udf9a\udaae\udc4c\017\ud87d\udc38\uda99\udee6\ud9d4\udc35\udbb1\udd4b\u1b3e\ud912\uddab\ud8f4\udf46\udab7\ude16\uda5c\udd75\udbcd\udc42\udab7\udfcb\ud93b\udcfc\ue02c\udaf8\udd84\ud828\udfb9\ud8a6\ude7c\ud93e\udc33\ud8c4\udffa\ud9e5\udc3b\uda2f\uddf3\ud9f9\udf20\ud9ab\udf74\ud93e\udff7\uda29\udde7\udaee\udcfc\udb29\uddfd\uda64\udc3f\u931f\ud8d1\udce2\uda27\udf05\udb76\udd6c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0011\\uD8C1\\uDCCB\\uDAF2\\uDF9A\\uDAAE\\uDC4C\\u000F\\uD87D\\uDC38\\uDA99\\uDEE6\\uD9D4\\uDC35\\uDBB1\\uDD4B\\u1B3E\\uD912\\uDDAB\\uD8F4\\uDF46\\uDAB7\\uDE16\\uDA5C\\uDD75\\uDBCD\\uDC42\\uDAB7\\uDFCB\\uD93B\\uDCFC\\uE02C\\uDAF8\\uDD84\\uD828\\uDFB9\\uD8A6\\uDE7C\\uD93E\\uDC33\\uD8C4\\uDFFA\\uD9E5\\uDC3B\\uDA2F\\uDDF3\\uD9F9\\uDF20\\uD9AB\\uDF74\\uD93E\\uDFF7\\uDA29\\uDDE7\\uDAEE\\uDCFC\\uDB29\\uDDFD\\uDA64\\uDC3F\\u931F\\uD8D1\\uDCE2\\uDA27\\uDF05\\uDB76\\uDD6C", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\001\001\ud8e7\udc88\u00b4\udb7b\udd5c\udb68\uddd9\003\uda58\udc0b\udabb\ude02\udb80\udd93\u9567\udb83\udf1d\udad3\udfe1\udafc\udf3d\uda63\ude9d\uda5d\udfb2\ud914\udfea\ud8c2\ude1d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0001\\u0001\\uD8E7\\uDC88\\u00B4\\uDB7B\\uDD5C\\uDB68\\uDDD9\\u0003\\uDA58\\uDC0B\\uDABB\\uDE02\\uDB80\\uDD93\\u9567\\uDB83\\uDF1D\\uDAD3\\uDFE1\\uDAFC\\uDF3D\\uDA63\\uDE9D\\uDA5D\\uDFB2\\uD914\\uDFEA\\uD8C2\\uDE1D", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\u7c3f\ud8c1\udccb\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\udaea\udfc5\ud92c\ude08\ud85e\ude42\udb77\udd1a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7c3f\ud8c1\udccb\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\udaea\udfc5\ud92c\ude08\ud85e\ude42\udb77\udd1a", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\ucfc9\000\000\000\ud97d\udc0b\ud812\udda9\uda99\ude37\u00cc\000\000\000\000\000&\000\000\ud8c6\udc08\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ucfc9\000\000\000\ud97d\udc0b\ud812\udda9\uda99\ude37\u00cc\000\000\000\000\000&\000\000\ud8c6\udc08\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\003\ud962\udf43\ud905\udd09\ud8bd\ude32\uda89\udd5c\udb68\uddd9\003\udab1\udf78\ud8f0\udfb8\udbff\uddfd\u194a\udb1c\udcc1\ud84d\udee5\udafc\udf3d\uda63\ude9d\uda5d\udfb2\ud914\udfea\udbb4\udd23\udadc\uddf7\uda4d\ude41\ud83b\udd6b\ud84d\udf32\ud86e\uddd2\udba5\udff1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0003\\uD962\\uDF43\\uD905\\uDD09\\uD8BD\\uDE32\\uDA89\\uDD5C\\uDB68\\uDDD9\\u0003\\uDAB1\\uDF78\\uD8F0\\uDFB8\\uDBFF\\uDDFD\\u194A\\uDB1C\\uDCC1\\uD84D\\uDEE5\\uDAFC\\uDF3D\\uDA63\\uDE9D\\uDA5D\\uDFB2\\uD914\\uDFEA\\uDBB4\\uDD23\\uDADC\\uDDF7\\uDA4D\\uDE41\\uD83B\\uDD6B\\uD84D\\uDF32\\uD86E\\uDDD2\\uDBA5\\uDFF1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\u00c9\000\000\000\000\000\uda99\ude37\uda96\udcd7\udbff\ude5f\ud96c\udf26\udaf5\ude40\udb6b\udc40\ud847\udcb0&");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u00c9\000\000\000\000\000\uda99\ude37\uda96\udcd7\udbff\ude5f\ud96c\udf26\udaf5\ude40\udb6b\udc40\ud847\udcb0&", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\u7c3f\ud8c1\udccb\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\udaea\udfc5\ud92c\ude08\ud85e\ude42\udb77\udd1a\udbdb\udc04\udadc\udfb0\uda1c\udeb9\ud875\udf42\udbfe\udd94\ud98f\ude01\ud996\udc71");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7c3f\ud8c1\udccb\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\udaea\udfc5\ud92c\ude08\ud85e\ude42\udb77\udd1a\udbdb\udc04\udadc\udfb0\uda1c\udeb9\ud875\udf42\udbfe\udd94\ud98f\ude01\ud996\udc71", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\ud867\ude53\ud8c1\udccb\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\udaea\udfc5\ud92c\ude08\ud85e\ude42\udb77\udd1a\ud83b\udde8\uda53\udc97\uda47\udf01\udb5c\udf70\ub38d\udb37\udc87\uda53\udfdd\udaca\udec0\udac3\udced\uda61\ude3c\ud879\udd4c\udbda\udf64");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud867\ude53\ud8c1\udccb\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\udaea\udfc5\ud92c\ude08\ud85e\ude42\udb77\udd1a\ud83b\udde8\uda53\udc97\uda47\udf01\udb5c\udf70\ub38d\udb37\udc87\uda53\udfdd\udaca\udec0\udac3\udced\uda61\ude3c\ud879\udd4c\udbda\udf64", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\uda1e\udc73\ud8ad\udf81\ud886\udc9f\uda2c\ude99\ud989\udfd1\udadb\udd0a\uda54\ude87\udb07\ude30\ud860\udf5a\ud96c\udf26\udafb\udf40\ud8d6\udc9d\ud859\udd51&\udaea\udfc5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda1e\udc73\ud8ad\udf81\ud886\udc9f\uda2c\ude99\ud989\udfd1\udadb\udd0a\uda54\ude87\udb07\ude30\ud860\udf5a\ud96c\udf26\udafb\udf40\ud8d6\udc9d\ud859\udd51&\udaea\udfc5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\ud867\ude53\ud8c1\udccb\udad3\udef9\ud99a\udef8\ud9b0\udfa5\udbd7\udcf3\udb88\udcaa\udbef\udc7d\ud8e2\udf10\ud974\udcb5\udb67\ude96\ud99a\udd71\uda13\ude37&\ud93f\udeaa\ud920\udfcf\ud9cf\ude7b\ud980\uddc0\udba1\udec8\uda34\udd38\udbc3\udd5e\ud8ce\udeb4\ud804\udda9\udb37\udc87\uda53\udfdd\uda22\udc3a\udac3\udd44\uda61\ude3c\ud879\udd4c\udbda\udf64");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud867\ude53\ud8c1\udccb\udad3\udef9\ud99a\udef8\ud9b0\udfa5\udbd7\udcf3\udb88\udcaa\udbef\udc7d\ud8e2\udf10\ud974\udcb5\udb67\ude96\ud99a\udd71\uda13\ude37&\ud93f\udeaa\ud920\udfcf\ud9cf\ude7b\ud980\uddc0\udba1\udec8\uda34\udd38\udbc3\udd5e\ud8ce\udeb4\ud804\udda9\udb37\udc87\uda53\udfdd\uda22\udc3a\udac3\udd44\uda61\ude3c\ud879\udd4c\udbda\udf64", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\uda1e\udc73\ud8ad\udf81\ud886\udc9f\uda2c\ude99@\ud84d\udee5\u0095\udb07\udd64\000\ud945\udde2\udafb\udf40\ud8d6\udc9d\ud859\udd51&\u0088");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda1e\udc73\ud8ad\udf81\ud886\udc9f\uda2c\ude99@\ud84d\udee5\u0095\udb07\udd64\000\ud945\udde2\udafb\udf40\ud8d6\udc9d\ud859\udd51&\u0088", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\u7c3f\u733a\000\000\ud9e4\udeff\ud83c\uddcd\ud85c\udc48\ud995\udf69\udbff\ude5f\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\udaea\udfc5\ud92c\ude08\ud85e\ude42\udb77\udd1a\udbdb\udc04\udadc\udfb0\uda1c\udeb9\ud99d\udf36\udbfe\udd94&\ud98e\udd66");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7c3f\u733a\000\000\ud9e4\udeff\ud83c\uddcd\ud85c\udc48\ud995\udf69\udbff\ude5f\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\udaea\udfc5\ud92c\ude08\ud85e\ude42\udb77\udd1a\udbdb\udc04\udadc\udfb0\uda1c\udeb9\ud99d\udf36\udbfe\udd94&\ud98e\udd66", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\000\000\udaa8\uddd3f\000\000\000\000\000\000\000\000\000\000\000\000\ud9ca\udc09");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\u0000\\uDAA8\\uDDD3f\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uD9CA\\uDC09", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\u7c3f\udbee\udde3\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\ud9ac\udec5\ud90a\uddde\uda88\udf02\udb51\udd47\ud87a\udd0c\ud927\udcd0\ud8fb\uddc3\ud971\uded3\udb57\udf51\ud93c\ude3b\udb0d\udcc7\ud9c3\udce6\uda46\udcad\ud978\udd90\uda81\udf40\ud903\udd21\udb95\udc56\ud84b\udf23\uda64\udde3\udbba\ude77\udbce\ude4a\ud94a\udf2e\udafc\udf71\ud8a0\udef7\ud81a\udf0c\udbb7\udff7\ud9cf\udcfb\ud9f9\udf64\udadf\udf50\udb23\uddd4\ud842\udccd\ud97d\udc2b\udb5e\udf81");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u7c3f\udbee\udde3\udad3\udef9\ud96d\udd57\ud9e4\udeff\ud83c\uddcd\uda99\ude37\ud9d4\udc35\ud870\uddb8\ud96c\udf26\udafb\udf40\udb6b\udc40\ud8a1\udcbd&\ud9ac\udec5\ud90a\uddde\uda88\udf02\udb51\udd47\ud87a\udd0c\ud927\udcd0\ud8fb\uddc3\ud971\uded3\udb57\udf51\ud93c\ude3b\udb0d\udcc7\ud9c3\udce6\uda46\udcad\ud978\udd90\uda81\udf40\ud903\udd21\udb95\udc56\ud84b\udf23\uda64\udde3\udbba\ude77\udbce\ude4a\ud94a\udf2e\udafc\udf71\ud8a0\udef7\ud81a\udf0c\udbb7\udff7\ud9cf\udcfb\ud9f9\udf64\udadf\udf50\udb23\uddd4\ud842\udccd\ud97d\udc2b\udb5e\udf81", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\000\u5300\000\000\000\000\000\000\000\000\000\000\000\000\uda4a\udc04\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\u5300\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uDA4A\\uDC04\\u0000\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\020\udb09\udd2a\ud949\udd2b\002\ud969\uddf3\032\000\uda58\udc0b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0010\\uDB09\\uDD2A\\uD949\\uDD2B\\u0002\\uD969\\uDDF3\\u001A\\u0000\\uDA58\\uDC0B", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud848\udc63\udb85\udc01if\uda6a\udf0c\ud82a\udc7d\udb7f\udedc\udb88\udd91\ud810\udfe4\ud934\udc33L\ud918\udf77\udb43\udefb\ucfcd\000\ud8b6\udedb\uda15\uded7,");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD848\\uDC63\\uDB85\\uDC01if\\uDA6A\\uDF0C\\uD82A\\uDC7D\\uDB7F\\uDEDC\\uDB88\\uDD91\\uD810\\uDFE4\\uD934\\uDC33L\\uD918\\uDF77\\uDB43\\uDEFB\\uCFCD\\u0000\\uD8B6\\uDEDB\\uDA15\\uDED7,", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\u00c2\u3a00\000\ud97f\udd09\u00a3\udb7e\udee8\udad4\udd82\ud9f9\udda9\u00d8\uef0a\ud9e2\udf23\ud8e0\udd26\udadc\ude8e\ud9b5\udc95\ud9be\udf4c\u00fb\000\u9a1f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u00C2\\u3A00\\u0000\\uD97F\\uDD09\\u00A3\\uDB7E\\uDEE8\\uDAD4\\uDD82\\uD9F9\\uDDA9\\u00D8\\uEF0A\\uD9E2\\uDF23\\uD8E0\\uDD26\\uDADC\\uDE8E\\uD9B5\\uDC95\\uD9BE\\uDF4C\\u00FB\\u0000\\u9A1F", String.valueOf(r));
  }
}
