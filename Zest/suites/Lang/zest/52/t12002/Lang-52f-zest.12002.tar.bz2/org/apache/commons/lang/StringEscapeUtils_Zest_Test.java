package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringEscapeUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udbdc\udc9b\udbd7\udf23\udb69\udfef\udb63\udcfd\ud985\ude9d\ud9c8\ude2e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbdc\udc9b\udbd7\udf23\udb69\udfef\udb63\udcfd\ud985\ude9d\ud9c8\ude2e", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udb60\udd2f\udabe\udea9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb60\udd2f\udabe\udea9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\ud8c6\udcc8\000\000\000\000\udab8\udcfc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55494;&#56520;\000\000\000\000&#55992;&#56572;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udad9\udea5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udad9\udea5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeSql("\udb98\udc59\udbd6\udeda\uda67\udc5c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb98\udc59\udbd6\udeda\uda67\udc5c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJavaScript("\udbdc\udc9b\udb33\udd16\ud899\ude8c\udb82\udde0\udb34\ude96\ud896\udd07");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbdc\udc9b\udb33\udd16\ud899\ude8c\udb82\udde0\udb34\ude96\ud896\udd07", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb0d\udee2\ud9bb\udffd\uda83\udfb3\uda31\udfae\ud81e\udc16\ud836\ude25");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB0D\\uDEE2\\uD9BB\\uDFFD\\uDA83\\uDFB3\\uDA31\\uDFAE\\uD81E\\uDC16\\uD836\\uDE25", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\udbdc\udc9b\ud8ad\udd3d\ud9c1\udd34\ud915\udf1e\ubf2a\ud830\uddc2\ud9d1\ude09");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#56284;&#56475;&#55469;&#56637;&#55745;&#56628;&#55573;&#57118;&#48938;&#55344;&#56770;&#55761;&#56841;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udbb3\udf77\ud8da\udfe4\ud949\udcaf\uda8a\udede\udb0a\udd45\uda77\udc0e\ud825\udc1f\u0fef\ud999\ude9d\udb4f\ude93\udb61\udece\ud812\udc6b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbb3\udf77\ud8da\udfe4\ud949\udcaf\uda8a\udede\udb0a\udd45\uda77\udc0e\ud825\udc1f\u0fef\ud999\ude9d\udb4f\ude93\udb61\udece\ud812\udc6b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\ud80e\uddaf\udbba\udca4\udb4f\udd8d\udaaf\udedb\uda67\udcaf\udbf0\uddf6\ud904\udc76\ud9cc\udf52\ud9a7\udfd6\udb24\ude01\udb3f\udc19\udbae\udd7c\udb46\ude8e\udae6\udcf5\uda06\udf87\ud80f\udc16\ud994\udc2d\udbb8\udcc3\udbbd\ude83\u6be6\udbfb\uddd7\ud8d4\udefe\udbe3\ude45\ubd68\ud97e\udf79\udb97\udce1\ud992\udeeb\ud8aa\udeee\ud858\udd11");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud80e\uddaf\udbba\udca4\udb4f\udd8d\udaaf\udedb\uda67\udcaf\udbf0\uddf6\ud904\udc76\ud9cc\udf52\ud9a7\udfd6\udb24\ude01\udb3f\udc19\udbae\udd7c\udb46\ude8e\udae6\udcf5\uda06\udf87\ud80f\udc16\ud994\udc2d\udbb8\udcc3\udbbd\ude83\u6be6\udbfb\uddd7\ud8d4\udefe\udbe3\ude45\ubd68\ud97e\udf79\udb97\udce1\ud992\udeeb\ud8aa\udeee\ud858\udd11", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\ud967\udc21\ud88b\udc9a\udb68\udfbe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55655;&#56353;&#55435;&#56474;&#56168;&#57278;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\ud9a7\udc68\udba7\udf7c\uda53\ude2e\ud9de\udc25");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9a7\udc68\udba7\udf7c\uda53\ude2e\ud9de\udc25", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udaf0\udee5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDAF0\\uDEE5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\u00c6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&AElig;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud93e\udc58\ud90c\udd3a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD93E\\uDC58\\uD90C\\uDD3A", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\udaa8\uddd3\udbd7\udf23\udb69\udfef\ud845\uddaf\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55976;&#56787;&#56279;&#57123;&#56169;&#57327;&#55365;&#56751;\000\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb60\uddf3\udb2b\udc6c\ud9f8\ude3a\u8b3b\uda43\ude9c\ud980\udc51\ud8af\udeeb\u1239\ud8af\uddd5\ud8b1\udc90\udbaa\ude8e\ud816\udc3a\ud9f9\udf12\ud8e7\udde6\ud8e3\udeca");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB60\\uDDF3\\uDB2B\\uDC6C\\uD9F8\\uDE3A\\u8B3B\\uDA43\\uDE9C\\uD980\\uDC51\\uD8AF\\uDEEB\\u1239\\uD8AF\\uDDD5\\uD8B1\\uDC90\\uDBAA\\uDE8E\\uD816\\uDC3A\\uD9F9\\uDF12\\uD8E7\\uDDE6\\uD8E3\\uDECA", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\udbdc\udc9b\udbd7\udf23\ud863\ude1f\udb63\udd46\ud985\ude9d\ud9c8\ude2e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#56284;&#56475;&#56279;&#57123;&#55395;&#56863;&#56163;&#56646;&#55685;&#56989;&#55752;&#56878;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud89d\udea1\ud8c2\udc7a\ud87f\udf48\udaca\udd52\udb06\ude8a\ud9ce\udda4\ud8a2\udf65\udb0f\ude2b\ud88c\ude8f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55453;&#56993;&#55490;&#56442;&#55423;&#57160;&#56010;&#56658;&#56070;&#56970;&#55758;&#56740;&#55458;&#57189;&#56079;&#56875;&#55436;&#56975;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\ud96e\udc96\ud8a0\udd8c\udb69\udfef\udb63\udcfd\ud985\ude9d\udb46\udf26\udaba\udc09\ud8a0\ude04\ud86e\udf0c\ud97c\udd1d\ud98a\udcd9\udb6e\udc0c\ud8b8\uddb0\uf3f4\udac3\udcc4\uda08\udc91\ud8dc\ude49\udb50\udf52\udb11\ude9d\uda9c\ude8e\ua9fb\ub873\udb74\ude48\ud8db\udc40\ud9d0\udc30\ud86a\udefe\udb48\ude87\udabc\uded1\ud989\udde2\udb30\udc02\udb79\udc4b\ud9a3\ude4b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud96e\udc96\ud8a0\udd8c\udb69\udfef\udb63\udcfd\ud985\ude9d\udb46\udf26\udaba\udc09\ud8a0\ude04\ud86e\udf0c\ud97c\udd1d\ud98a\udcd9\udb6e\udc0c\ud8b8\uddb0\uf3f4\udac3\udcc4\uda08\udc91\ud8dc\ude49\udb50\udf52\udb11\ude9d\uda9c\ude8e\ua9fb\ub873\udb74\ude48\ud8db\udc40\ud9d0\udc30\ud86a\udefe\udb48\ude87\udabc\uded1\ud989\udde2\udb30\udc02\udb79\udc4b\ud9a3\ude4b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udbdc\udc9b\udb74\udea8\ud995\udf97\udb63\udcb3\uda1f\udcab\ud9c8\ude2e\udb9d\uddf4\ud89c\udec0\ud8b0\udfdd\udac7\ude96\uda66\udedf\ud8f5\udda7\ud949\udf7d\udb13\udc20\ud86e\uddb4\ud963\udf08\ud91a\udd3d\ud925\udc52\udb0e\ude30\udbbc\udfea\ud87e\udeae\ud8b2\udd31\udb63\udf33\ud96f\udcc8\udb0e\udfb3\udacc\udcd4\ud827\udedb\ud98c\udcaf\ud859\udf5d\u68ec\udb7e\udfbb\udb21\udf44\ud972\udcd5\ud868\udf2a\uda1e\ude6c\ud87e\udca0\uda90\ude48\udac7\udee6\udae0\udccb\ud9a8\udd76\ud870\ude80\udb55\udc40\udbc8\udc42\ud8cd\udd2c\uda68\udee7\ud9a9\udd4c\ud83a\udfbd\udb8c\udd15\ue005\ud977\udf59\ud917\udf82\uda85\udd5d\udad7\udc0a\uda8a\udec7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbdc\udc9b\udb74\udea8\ud995\udf97\udb63\udcb3\uda1f\udcab\ud9c8\ude2e\udb9d\uddf4\ud89c\udec0\ud8b0\udfdd\udac7\ude96\uda66\udedf\ud8f5\udda7\ud949\udf7d\udb13\udc20\ud86e\uddb4\ud963\udf08\ud91a\udd3d\ud925\udc52\udb0e\ude30\udbbc\udfea\ud87e\udeae\ud8b2\udd31\udb63\udf33\ud96f\udcc8\udb0e\udfb3\udacc\udcd4\ud827\udedb\ud98c\udcaf\ud859\udf5d\u68ec\udb7e\udfbb\udb21\udf44\ud972\udcd5\ud868\udf2a\uda1e\ude6c\ud87e\udca0\uda90\ude48\udac7\udee6\udae0\udccb\ud9a8\udd76\ud870\ude80\udb55\udc40\udbc8\udc42\ud8cd\udd2c\uda68\udee7\ud9a9\udd4c\ud83a\udfbd\udb8c\udd15\ue005\ud977\udf59\ud917\udf82\uda85\udd5d\udad7\udc0a\uda8a\udec7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\000\000\000\000\000\ud9c8\ude07");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000\000\000\000\000&#55752;&#56839;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud820\udfa9\ud982\ude7f\ud9b4\ude4b\udb0e\udf05\ud8c3\udeb5\udb69\udca7\udac3\uddca\udb6c\udf8b\ud8cc\udf91\ud855\udd41\ud9a0\ude75\udbe2\udd65\ud90e\udee6\ud9a5\udc15\ud8ba\udceb\ud9ea\uded3\udab5\udd14\udb13\udc11\ud804\udc96\uda4d\udd7f\ud91b\ude46\udb92\udd19");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55328;&#57257;&#55682;&#56959;&#55732;&#56907;&#56078;&#57093;&#55491;&#57013;&#56169;&#56487;&#56003;&#56778;&#56172;&#57227;&#55500;&#57233;&#55381;&#56641;&#55712;&#56949;&#56290;&#56677;&#55566;&#57062;&#55717;&#56341;&#55482;&#56555;&#55786;&#57043;&#55989;&#56596;&#56083;&#56337;&#55300;&#56470;&#55885;&#56703;&#55579;&#56902;&#56210;&#56601;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\ud9ce\udd43");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55758;&#56643;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\ud90b\udc4b\udaef\uded6\ud8a9\udf2f\ud888\udf6d\ud8c6\udf01\udacf\udd92\udab7\udfcc\udbe8\uddf5\udb98\udf7f\udbb0\udf4d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55563;&#56395;&#56047;&#57046;&#55465;&#57135;&#55432;&#57197;&#55494;&#57089;&#56015;&#56722;&#55991;&#57292;&#56296;&#56821;&#56216;&#57215;&#56240;&#57165;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\ud8c6\udcc8\ud94c\udc05\000\ud861\udf54\ud91d\udd1d\udab8\udd76\ud922\udf1a\ud8e2\udd48\udae1\ude1d\udbd8\udd4d\ud8e7\udead\ud8fc\udd28\ud6ec\ud811\udeb4\udbd6\udee9\ud985\udc20\ud929\udd5c\ud948\uddea\uda35\udca1\uda1d\udfa6\udac1\uddd1\ud9aa\udc81\udb6a\udc79\udb50\udd1b\uda56\uded7\uda31\ude85\udbf3\ude37\udb09\ude69\ud961\udef6\ud956\udf00\ucce3\udb82\udcab\ud842\udf89\udbed\udeea\u50f8\uda83\udd6b\ud823\udd3e\ud8eb\udc45\ud843\ude0f\udaa7\udc60\uda3a\udfa6\uef33\ud81c\uded1\udb3e\udda1\ud95d\udd1d\ud9c2\udf16");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55494;&#56520;&#55628;&#56325;\000&#55393;&#57172;&#55581;&#56605;&#55992;&#56694;&#55586;&#57114;&#55522;&#56648;&#56033;&#56861;&#56280;&#56653;&#55527;&#57005;&#55548;&#56616;&#55020;&#55313;&#57012;&#56278;&#57065;&#55685;&#56352;&#55593;&#56668;&#55624;&#56810;&#55861;&#56481;&#55837;&#57254;&#56001;&#56785;&#55722;&#56449;&#56170;&#56441;&#56144;&#56603;&#55894;&#57047;&#55857;&#56965;&#56307;&#56887;&#56073;&#56937;&#55649;&#57078;&#55638;&#57088;&#52451;&#56194;&#56491;&#55362;&#57225;&#56301;&#57066;&#20728;&#55939;&#56683;&#55331;&#56638;&#55531;&#56389;&#55363;&#56847;&#55975;&#56416;&#55866;&#57254;&#61235;&#55324;&#57041;&#56126;&#56737;&#55645;&#56605;&#55746;&#57110;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\udacc\udff8\udb1c\udc4c\udab3\udc41\udb2d\ude54\uda32\udf22\ud844\udd02\udb44\udf70\ud9c3\udfbf\uda8f\udf8e\udbba\ude52\udafc\udfe7\uda0e\uddc7\udaa0\udd60\uda30\ude7d\udad8\udd2e\ud956\udd2f\ud97d\udf42\uda39\udf60\ud9f1\udffa\udaef\udcea\ud938\udf2a\ud9fb\udf19\udb5b\udddd\ud961\udde0\udb02\udf8f\uda24\udf1f\uda75\udf6b\udb5c\udd07\ud9a5\ude38\u8420\ud8bf\udc5d\udac3\udcee\ud8a0\udd92\udaf5\uddd4\uda50\udf47\ud8e5\udeec\ud8cf\udf3f\ud9dd\ude43\udbc0\udec1\udb38\udea7\ud881\ude0d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#56012;&#57336;&#56092;&#56396;&#55987;&#56385;&#56109;&#56916;&#55858;&#57122;&#55364;&#56578;&#56132;&#57200;&#55747;&#57279;&#55951;&#57230;&#56250;&#56914;&#56060;&#57319;&#55822;&#56775;&#55968;&#56672;&#55856;&#56957;&#56024;&#56622;&#55638;&#56623;&#55677;&#57154;&#55865;&#57184;&#55793;&#57338;&#56047;&#56554;&#55608;&#57130;&#55803;&#57113;&#56155;&#56797;&#55649;&#56800;&#56066;&#57231;&#55844;&#57119;&#55925;&#57195;&#56156;&#56583;&#55717;&#56888;&#33824;&#55487;&#56413;&#56003;&#56558;&#55456;&#56722;&#56053;&#56788;&#55888;&#57159;&#55525;&#57068;&#55503;&#57151;&#55773;&#56899;&#56256;&#57025;&#56120;&#56999;&#55425;&#56845;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udac7\udcbc\ud9e7\udc55\ud9d4\udd23\000\udb9e\udc0e\udab8\udcfc\ud91c\ude3f\udadd\udc6d\u1461\udb9f\ude8e\uda32\udf4c\udada\udfa4\udb63\udd6f\udb3e\udfe3\udb23\udc6c\u76f2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDAC7\\uDCBC\\uD9E7\\uDC55\\uD9D4\\uDD23\\u0000\\uDB9E\\uDC0E\\uDAB8\\uDCFC\\uD91C\\uDE3F\\uDADD\\uDC6D\\u1461\\uDB9F\\uDE8E\\uDA32\\uDF4C\\uDADA\\uDFA4\\uDB63\\uDD6F\\uDB3E\\uDFE3\\uDB23\\uDC6C\\u76F2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\uda80\udd2a!\000\000\ud93b\udc9c\udaef\ude1b\uda67\udf06\uda4f\udc0d\ud944\udcfd\uda5a\udc7d\ud876\udcfa\ud9d4\udd21\uda70\uddcf\ud898\udc54\uda58\udc84\udb87\uded4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA80\\uDD2A!\\u0000\\u0000\\uD93B\\uDC9C\\uDAEF\\uDE1B\\uDA67\\uDF06\\uDA4F\\uDC0D\\uD944\\uDCFD\\uDA5A\\uDC7D\\uD876\\uDCFA\\uD9D4\\uDD21\\uDA70\\uDDCF\\uD898\\uDC54\\uDA58\\uDC84\\uDB87\\uDED4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\udb8d\udd34\u039a\000\000\ud9a9\ude94\udb11\udc85\ud933\udf81\ud891\udf4f\u9ba3\udaa3\udf1e\udac9\ude70\ud9d0\uddca\ud975\udf42\ud964\uddf7\ud96b\udee2\ud90b\uddd6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#56205;&#56628;&Kappa;\000\000&#55721;&#56980;&#56081;&#56453;&#55603;&#57217;&#55441;&#57167;&#39843;&#55971;&#57118;&#56009;&#56944;&#55760;&#56778;&#55669;&#57154;&#55652;&#56823;&#55659;&#57058;&#55563;&#56790;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8c6\udcc8\000\udb40\udcd5\uab2e\u00f4\udab8\udcfc\ud9de\udee3\ud8ba\ude68\ud875\udd97");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8C6\\uDCC8\\u0000\\uDB40\\uDCD5\\uAB2E\\u00F4\\uDAB8\\uDCFC\\uD9DE\\uDEE3\\uD8BA\\uDE68\\uD875\\uDD97", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud8c6\udcc8\ud934\udd07\000\u63c5\uda21\udc50\udab8\udd71\ud9e8\udd8d\ud804\uddb9\ud92f\udde1\ud89e\udd90\ud92a\udec8\ud9d7\udc61\udb2e\udef5\udaaf\udf78\udb7f\uddc4\uda7a\udd0f\ud81f\udca0\uda41\ude6c\ud87e\udca2\udb97\udd19\udab8\udd4c\udb31\udd8d\uda44\udf31");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8C6\\uDCC8\\uD934\\uDD07\\u0000\\u63C5\\uDA21\\uDC50\\uDAB8\\uDD71\\uD9E8\\uDD8D\\uD804\\uDDB9\\uD92F\\uDDE1\\uD89E\\uDD90\\uD92A\\uDEC8\\uD9D7\\uDC61\\uDB2E\\uDEF5\\uDAAF\\uDF78\\uDB7F\\uDDC4\\uDA7A\\uDD0F\\uD81F\\uDCA0\\uDA41\\uDE6C\\uD87E\\uDCA2\\uDB97\\uDD19\\uDAB8\\uDD4C\\uDB31\\uDD8D\\uDA44\\uDF31", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\ud8c6\udcc8\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55494;&#56520;\000\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeSql("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\uda65\udeab\ud9c3\udd78\ud876\ude86\uda44\udcaa\ud961\udd0d\ud840\ude5d\udb55\udf9d\udb9d\udcc4\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud899\udca2\udb1e\udc09\ud9c7\ude08\udbf7\udf07\udb5a\udd4d\ud90e\udf41\uda86\udc16\uda6d\ude2c\udbe3\udf55\ud971\udf3c\ud910\ude1c\ud8c4\ude36\uda51\udc72\udb7f\uddfd\ud85c\udd92\udb1a\udfed\ud941\udd2a\ud962\ude9b\uda2e\udc66\uda0f\uddd7\ud897\udd6e\udadb\udcb0\udb30\udce5\ud98f\udcc0\ud9ff\udc36\uda3d\uded9\ud996\udd2f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA65\\uDEAB\\uD9C3\\uDD78\\uD876\\uDE86\\uDA44\\uDCAA\\uD961\\uDD0D\\uD840\\uDE5D\\uDB55\\uDF9D\\uDB9D\\uDCC4\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD899\\uDCA2\\uDB1E\\uDC09\\uD9C7\\uDE08\\uDBF7\\uDF07\\uDB5A\\uDD4D\\uD90E\\uDF41\\uDA86\\uDC16\\uDA6D\\uDE2C\\uDBE3\\uDF55\\uD971\\uDF3C\\uD910\\uDE1C\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDDFD\\uD85C\\uDD92\\uDB1A\\uDFED\\uD941\\uDD2A\\uD962\\uDE9B\\uDA2E\\uDC66\\uDA0F\\uDDD7\\uD897\\uDD6E\\uDADB\\uDCB0\\uDB30\\uDCE5\\uD98F\\uDCC0\\uD9FF\\uDC36\\uDA3D\\uDED9\\uD996\\uDD2F", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeSql("\uda98\udf70\ud8ac\udef1\uda67\udc5c\ud9c5\udff5\uda31\udffc\udbd6\udc7b\ud9a6\ude45\uda1e\udf4b\ud92c\ude47\ud830\ude70\udbe5\udf98\udae9\udf1b\udb9e\udf41\udbb8\udd23\uce28\ub08e\ud986\udfae\udaeb\ude92\uda12\udd7f\ud9ed\udf79\ud830\udfd5\udaa6\uddfe\udb3d\ude81\ud84c\udcb5\uda0c\udf4e\udb92\udf9c\uda58\udef2\udbe4\udeeb\udafc\udf9f\ud908\uddb5\ud981\udfec\udb09\ude33\ud828\udec6\uccfa\udadb\udfde\udb8e\udc93\udad2\udc3d\udb61\ude3e\ud958\ude42\udacb\udcf3\udbe8\udff8\udb2f\udd6e\udb60\udd12\ud894\uddb2\udb28\uddf0\udba5\udc5d\uda64\uddbd\u6931\ud8e5\udca8\ud912\udf02\uda1c\udf6b\ud9c5\udd6b\uda0b\udf30\uda83\udcba\uda29\udfa0\ud9ca\udf5e\ud929\udc9e\u8240\udb2e\udee5\udbc8\ude08\ud902\udd0b\ud9ff\ude6e\ud923\udf04\uda19\udfa3\udab1\udeae\u70dd\uda10\udc8f\udaa5\udc00\uda2e\udd0c\ud9c0\udfc9\ud884\udf53\ud9d8\udd46\ud8d1\udf19\ud886\udf7b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda98\udf70\ud8ac\udef1\uda67\udc5c\ud9c5\udff5\uda31\udffc\udbd6\udc7b\ud9a6\ude45\uda1e\udf4b\ud92c\ude47\ud830\ude70\udbe5\udf98\udae9\udf1b\udb9e\udf41\udbb8\udd23\uce28\ub08e\ud986\udfae\udaeb\ude92\uda12\udd7f\ud9ed\udf79\ud830\udfd5\udaa6\uddfe\udb3d\ude81\ud84c\udcb5\uda0c\udf4e\udb92\udf9c\uda58\udef2\udbe4\udeeb\udafc\udf9f\ud908\uddb5\ud981\udfec\udb09\ude33\ud828\udec6\uccfa\udadb\udfde\udb8e\udc93\udad2\udc3d\udb61\ude3e\ud958\ude42\udacb\udcf3\udbe8\udff8\udb2f\udd6e\udb60\udd12\ud894\uddb2\udb28\uddf0\udba5\udc5d\uda64\uddbd\u6931\ud8e5\udca8\ud912\udf02\uda1c\udf6b\ud9c5\udd6b\uda0b\udf30\uda83\udcba\uda29\udfa0\ud9ca\udf5e\ud929\udc9e\u8240\udb2e\udee5\udbc8\ude08\ud902\udd0b\ud9ff\ude6e\ud923\udf04\uda19\udfa3\udab1\udeae\u70dd\uda10\udc8f\udaa5\udc00\uda2e\udd0c\ud9c0\udfc9\ud884\udf53\ud9d8\udd46\ud8d1\udf19\ud886\udf7b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\000\000\000\000\000\uf100");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000\000\000\000\000&#61696;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb0d\udee2\ud9bb\udffd\u407b\000\u0200\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB0D\\uDEE2\\uD9BB\\uDFFD\\u407B\\u0000\\u0200\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\000\000(\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\u0000(\\u0000\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeXml("\uda06\udc50\ud8ad\udc79\udbc9\udc87\udaf3\udf7f\udbdd\udeea\ud80c\udd92\ud9f2\udeed\ud917\udf4c\ud9de\udd3c\udad6\udcb5\udbec\udca3\udb71\uddbe\ud98f\udea7\uda85\uddc4\ud805\udc88\ud8d1\uddb0\udb2e\udebb\udab4\udc51\ud817\udf2e\udbc4\udf5d\ud983\uded0\uda93\udefe\ud813\udfab\ud8e6\ude6b\udb53\ude04\udaf3\udfd6\ud8b4\udef0\udbc7\udf35\uda78\udc31\ud86c\udc97\udbc7\udd68\ud94b\ude59\uda47\ude90\ud90c\ude25\ud8d7\udc2f\ud959\udcf5\ud896\udc2f\ud869\ude37\udb79\udf6d\udb38\ude10\ud90e\udd07\ud89a\udf6e\u3cde\ud98c\ude56\ud889\udfbc\udac7\uddf2\uda73\udf84\udb86\udff7\uda7b\ude64\udac6\udca3\ud871\udc4b\udb35\udca9\udbad\udeba\ud937\udc31\udae3\udd9f\udadf\udcf8\ud9a4\udf8e\ud983\udd1e\ud86d\udf63\uda5a\udc0f\udb27\uddc3\udb58\udd49\u6550\udb88\udfbc\udbb5\uddb0\udbd5\uddb0\udb7d\udffc\udae1\udcfe\ud9a5\udcc4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55814;&#56400;&#55469;&#56441;&#56265;&#56455;&#56051;&#57215;&#56285;&#57066;&#55308;&#56722;&#55794;&#57069;&#55575;&#57164;&#55774;&#56636;&#56022;&#56501;&#56300;&#56483;&#56177;&#56766;&#55695;&#56999;&#55941;&#56772;&#55301;&#56456;&#55505;&#56752;&#56110;&#57019;&#55988;&#56401;&#55319;&#57134;&#56260;&#57181;&#55683;&#57040;&#55955;&#57086;&#55315;&#57259;&#55526;&#56939;&#56147;&#56836;&#56051;&#57302;&#55476;&#57072;&#56263;&#57141;&#55928;&#56369;&#55404;&#56471;&#56263;&#56680;&#55627;&#56921;&#55879;&#56976;&#55564;&#56869;&#55511;&#56367;&#55641;&#56565;&#55446;&#56367;&#55401;&#56887;&#56185;&#57197;&#56120;&#56848;&#55566;&#56583;&#55450;&#57198;&#15582;&#55692;&#56918;&#55433;&#57276;&#56007;&#56818;&#55923;&#57220;&#56198;&#57335;&#55931;&#56932;&#56006;&#56483;&#55409;&#56395;&#56117;&#56489;&#56237;&#57018;&#55607;&#56369;&#56035;&#56735;&#56031;&#56568;&#55716;&#57230;&#55683;&#56606;&#55405;&#57187;&#55898;&#56335;&#56103;&#56771;&#56152;&#56649;&#25936;&#56200;&#57276;&#56245;&#56752;&#56277;&#56752;&#56189;&#57340;&#56033;&#56574;&#55717;&#56516;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud8e1\ude30\ud9f0\ude8e\ud8be\udf7c\ud87c\udc76\ud8e7\udcd3\ud81a\ude7e\ud8cb\uddbd\ud8c6\uddea\u03a9\u4bbe\ud990\uded7\ud9af\udcfd\uda54\udfc6\ud98c\udd3b\udab9\udc55\udbcd\udcb1\ud8c8\ude60\uda50\udcb2\ud9b3\uddcd\ud8b5\udca1\ud9d8\udf1f\ud80e\udf5b\ud870\udc51\ud967\udcbf\ud943\udd23\ud95a\ude05\udae6\udc24\udaf9\udcf9\ud85b\udc3d\udb48\udcde\ud9bf\udc9e\ud84c\udef0\ud8f4\uddda\udb5a\udf9a\ud917\udff8\uda5a\uddb8\udb31\ude86\udac4\udf3b\ud991\udeff\udade\ude0d\uda5c\udc92\uda21\ude7c\ud8f0\udf5e\udbe0\udc0b\udb59\udd1e\ud993\ude3c\u0963\ue070\ud9b3\udd72\ud892\udd43\ud8bb\udf51\udb10\udfd0");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8E1\\uDE30\\uD9F0\\uDE8E\\uD8BE\\uDF7C\\uD87C\\uDC76\\uD8E7\\uDCD3\\uD81A\\uDE7E\\uD8CB\\uDDBD\\uD8C6\\uDDEA\\u03A9\\u4BBE\\uD990\\uDED7\\uD9AF\\uDCFD\\uDA54\\uDFC6\\uD98C\\uDD3B\\uDAB9\\uDC55\\uDBCD\\uDCB1\\uD8C8\\uDE60\\uDA50\\uDCB2\\uD9B3\\uDDCD\\uD8B5\\uDCA1\\uD9D8\\uDF1F\\uD80E\\uDF5B\\uD870\\uDC51\\uD967\\uDCBF\\uD943\\uDD23\\uD95A\\uDE05\\uDAE6\\uDC24\\uDAF9\\uDCF9\\uD85B\\uDC3D\\uDB48\\uDCDE\\uD9BF\\uDC9E\\uD84C\\uDEF0\\uD8F4\\uDDDA\\uDB5A\\uDF9A\\uD917\\uDFF8\\uDA5A\\uDDB8\\uDB31\\uDE86\\uDAC4\\uDF3B\\uD991\\uDEFF\\uDADE\\uDE0D\\uDA5C\\uDC92\\uDA21\\uDE7C\\uD8F0\\uDF5E\\uDBE0\\uDC0B\\uDB59\\uDD1E\\uD993\\uDE3C\\u0963\\uE070\\uD9B3\\uDD72\\uD892\\uDD43\\uD8BB\\uDF51\\uDB10\\uDFD0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u6426");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u6426", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udbdc\udc9b\udb74\udea8\ud995\udf97\\\uda1f\udcab\ud9c8\ude2e\udb9d\uddf4\ud89c\udec0\ud8b0\udfdd\ud6ce\uda66\udedf\ud8f5\udda7\ud949\udf7d\udb13\udc20\ud86e\uddb4\udbf5\udf71\000\000\udae6\udcf2\udbbc\udfea\ud87e\udeae\ud8b2\udd31\udb63\udf33\ud96f\udcc8\udb0e\udfb3\udacc\udcd4\ud827\udedb\ud98c\udcaf\ud859\udf5d\u68ec\udb7e\udfbb\udb21\udf44\ud972\udcd5\ud868\udf2a\uda1e\ude6c\ud87e\udca0\uda90\ude48\udac7\udee6\u193f\ud9a8\udc99\ud870\ude80\udb55\udc40\udbc8\udc42\ud8cd\udd2c\uda68\udee7\ud9a9\udd4c\ud83a\udfbd\ue22b\ud891\udd68\ud977\udf59\ud917\udf82\uda85\udd5d\udad7\udc0a\uda8a\udec7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbdc\udc9b\udb74\udea8\ud995\udf97\uda1f\udcab\ud9c8\ude2e\udb9d\uddf4\ud89c\udec0\ud8b0\udfdd\ud6ce\uda66\udedf\ud8f5\udda7\ud949\udf7d\udb13\udc20\ud86e\uddb4\udbf5\udf71\000\000\udae6\udcf2\udbbc\udfea\ud87e\udeae\ud8b2\udd31\udb63\udf33\ud96f\udcc8\udb0e\udfb3\udacc\udcd4\ud827\udedb\ud98c\udcaf\ud859\udf5d\u68ec\udb7e\udfbb\udb21\udf44\ud972\udcd5\ud868\udf2a\uda1e\ude6c\ud87e\udca0\uda90\ude48\udac7\udee6\u193f\ud9a8\udc99\ud870\ude80\udb55\udc40\udbc8\udc42\ud8cd\udd2c\uda68\udee7\ud9a9\udd4c\ud83a\udfbd\ue22b\ud891\udd68\ud977\udf59\ud917\udf82\uda85\udd5d\udad7\udc0a\uda8a\udec7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\uda9a\ude0c\u00fe\000\000\000\ud844\udd02\udb44\udf70\ud9c3\udfbf\uda8f\udf8e\udbba\ude52\000\uda0e\uddc7\udaa0\udd60\uda30\ude7d\udad8\udd2e\ud956\udd2fh\000\000\036\ud938\udf2a\ud9fb\udf19\udb5b\udddd\u0a11\udb02\udf8f\uda24\udf1f\uda75\udf6b\udb5c\udd07\ud84e\udc0c\000\ud8bf\udc5d\udac3\udcee\ud8a0\udd92\udaf5\uddd4\uda50\udf47\ud80c\udedf\ud8cf\ude49\ud9dd\ude43\udbc0\udec1\u00b5\ud84a\udcc4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55962;&#56844;&thorn;\000\000\000&#55364;&#56578;&#56132;&#57200;&#55747;&#57279;&#55951;&#57230;&#56250;&#56914;\000&#55822;&#56775;&#55968;&#56672;&#55856;&#56957;&#56024;&#56622;&#55638;&#56623;h\000\000\036&#55608;&#57130;&#55803;&#57113;&#56155;&#56797;&#2577;&#56066;&#57231;&#55844;&#57119;&#55925;&#57195;&#56156;&#56583;&#55374;&#56332;\000&#55487;&#56413;&#56003;&#56558;&#55456;&#56722;&#56053;&#56788;&#55888;&#57159;&#55308;&#57055;&#55503;&#56905;&#55773;&#56899;&#56256;&#57025;&micro;&#55370;&#56516;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8ed\ude50\000\000\000\000\000\ud8b5\udd99\u4d8a\000\000\000\udb43\udfe1)\udb2d\udf36\u151f\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8ED\\uDE50\\u0000\\u0000\\u0000\\u0000\\u0000\\uD8B5\\uDD99\\u4D8A\\u0000\\u0000\\u0000\\uDB43\\uDFE1)\\uDB2D\\uDF36\\u151F\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udac7\udcbc\uda38\udd50\ud9d4\udef5\025\udb9e\udc0e\udab8\udcfc\ud917\udc53\udadd\udc6d\u1461\udb9f\ude8e\uda32\udf4c\udada\udfa4\udb63\udd6f\udb3e\udfe3\udb23\udc6c\u76f2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDAC7\\uDCBC\\uDA38\\uDD50\\uD9D4\\uDEF5\\u0015\\uDB9E\\uDC0E\\uDAB8\\uDCFC\\uD917\\uDC53\\uDADD\\uDC6D\\u1461\\uDB9F\\uDE8E\\uDA32\\uDF4C\\uDADA\\uDFA4\\uDB63\\uDD6F\\uDB3E\\uDFE3\\uDB23\\uDC6C\\u76F2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\uda80\udd2a!\ud8fc\udfdb|\ud93b\udc9c\udaef\ude1b\uda67\udf06\uda4f\udc0d\ud944\udcfd\uda5a\udc7d\ud876\udcfa\ud9d4\udd21\uda70\ude3a\ud898\udc54\uda58\udc84\udb87\uded4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA80\\uDD2A!\\uD8FC\\uDFDB|\\uD93B\\uDC9C\\uDAEF\\uDE1B\\uDA67\\uDF06\\uDA4F\\uDC0D\\uD944\\uDCFD\\uDA5A\\uDC7D\\uD876\\uDCFA\\uD9D4\\uDD21\\uDA70\\uDE3A\\uD898\\uDC54\\uDA58\\uDC84\\uDB87\\uDED4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud864\udfb2\"\ud93e\ude12\ud804\udc95\ud93b\udc9c\udaef\ude1b\uda67\udf06\uda4f\udc0d\ud944\udcfd\uda5a\udc7d\ud876\udcfa\ud9d4\udd21\uda70\uddcf\ud898\udc54\uda58\udc84\udb87\uded4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD864\\uDFB2\\\"\\uD93E\\uDE12\\uD804\\uDC95\\uD93B\\uDC9C\\uDAEF\\uDE1B\\uDA67\\uDF06\\uDA4F\\uDC0D\\uD944\\uDCFD\\uDA5A\\uDC7D\\uD876\\uDCFA\\uD9D4\\uDD21\\uDA70\\uDDCF\\uD898\\uDC54\\uDA58\\uDC84\\uDB87\\uDED4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\ud92a\udff5\u00ab\u00e4\000\ud93b\udc9c\udb4d\ude2a\ud935\udef3\uda4f\udc0d\ud944\udcfd\uda5a\udc7d\ud876\udcfa\ud9d4\udd21\ud81c\udcee\ud95f\udf17\ud8d0\udd0b\udb87\ude23");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD92A\\uDFF5\\u00AB\\u00E4\\u0000\\uD93B\\uDC9C\\uDB4D\\uDE2A\\uD935\\uDEF3\\uDA4F\\uDC0D\\uD944\\uDCFD\\uDA5A\\uDC7D\\uD876\\uDCFA\\uD9D4\\uDD21\\uD81C\\uDCEE\\uD95F\\uDF17\\uD8D0\\uDD0B\\uDB87\\uDE23", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\ud9c3\udd78\ud876\ude86\uda44\udcaa\ubb75\ud840\ude5d'\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud899\udca2\udb1e\udc09\udbd6\udc06\udbf7\udf07\udb5a\udd4d\u00f4\uda85\udfad\ud936\ude10\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\uddfd\ud85c\udd92\udb1a\udfed\ud941\udd2a\ud8c8\udee3\uda2e\udc66\uda0f\uddd7\ud897\udd6e\udadb\udcb0\033\ud8c5\udcc2\ud9ff\udc36\uda3d\uded9\ud996\udd2f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uD9C3\\uDD78\\uD876\\uDE86\\uDA44\\uDCAA\\uBB75\\uD840\\uDE5D\\'\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD899\\uDCA2\\uDB1E\\uDC09\\uDBD6\\uDC06\\uDBF7\\uDF07\\uDB5A\\uDD4D\\u00F4\\uDA85\\uDFAD\\uD936\\uDE10\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDDFD\\uD85C\\uDD92\\uDB1A\\uDFED\\uD941\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDA0F\\uDDD7\\uD897\\uDD6E\\uDADB\\uDCB0\\u001B\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDA3D\\uDED9\\uD996\\uDD2F", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udaaf\uded3\ud9bb\udffd\udaf2\ude2c\ud9b2\udc9c\udae5\udce1\\");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDAAF\\uDED3\\uD9BB\\uDFFD\\uDAF2\\uDE2C\\uD9B2\\uDC9C\\uDAE5\\uDCE1\\\\", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeSql("\udabf\udd3e\ud9e2\udc12\ud876\ude86\uda44\udcaa\ubb75\ud840\ude5d'\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud899\udca2\udb1e\udc09\udbd6\udc06\udbf7\udf07\udb5a\udd4d\u00f4\uda85\udfad\ud942\udd4f\u82ed\uda2e\udebe\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\uddfd\ud85c\udd92\ud901\udd1f\ud830\udda2\uda41\udc71\ud9a0\udcce\uda1b\udf60\ud897\udd6e\udadb\udcb0\033\ud8c5\udcc2\ud9ff\udc36\ud828\uddfd\udba3\ude9c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udabf\udd3e\ud9e2\udc12\ud876\ude86\uda44\udcaa\ubb75\ud840\ude5d''\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud899\udca2\udb1e\udc09\udbd6\udc06\udbf7\udf07\udb5a\udd4d\u00f4\uda85\udfad\ud942\udd4f\u82ed\uda2e\udebe\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\uddfd\ud85c\udd92\ud901\udd1f\ud830\udda2\uda41\udc71\ud9a0\udcce\uda1b\udf60\ud897\udd6e\udadb\udcb0\033\ud8c5\udcc2\ud9ff\udc36\ud828\uddfd\udba3\ude9c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\ud9c3\udd78\ud876\ude86\uda44\udcaa\ubb75\ud840\ude5d'\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud899\udca2\udb1e\udc09\udbd6\udc06\udbf7\udf07\udb5a\udd4d\u00f4\uda85\udfad\ud936\ude10\034\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\uddfd\ud85c\udd92\udb1a\udfed\ud941\udd2a\ud8c8\udee3\uda2e\udc66\uda0f\uddd7\ud897\udd6e\udadb\udcb0\033\ud8c5\udcc2\ud935\udfec\udb16\udcea\uda97\udf95");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uD9C3\\uDD78\\uD876\\uDE86\\uDA44\\uDCAA\\uBB75\\uD840\\uDE5D\\'\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD899\\uDCA2\\uDB1E\\uDC09\\uDBD6\\uDC06\\uDBF7\\uDF07\\uDB5A\\uDD4D\\u00F4\\uDA85\\uDFAD\\uD936\\uDE10\\u001C\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDDFD\\uD85C\\uDD92\\uDB1A\\uDFED\\uD941\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDA0F\\uDDD7\\uD897\\uDD6E\\uDADB\\uDCB0\\u001B\\uD8C5\\uDCC2\\uD935\\uDFEC\\uDB16\\uDCEA\\uDA97\\uDF95", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\udb37\udd72\udbe4\ude7d\uda44\udcaa\ubb75\ud840\ude5d'\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\u349d\udb13\udee9\000\ud9c5\udf21\udb5a\udd4d\u00f4\ud8af\udfa2\004\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\ud85c\udd92\udb1a\udfed\ud925\udd2a\ud8c8\udee3\uda2e\udc66\uda0f\uddd7\u00a0\udadb\udc49\033\ud8c5\udcc2\ud9ff\udc36\udaf9\udef7\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uDB37\\uDD72\\uDBE4\\uDE7D\\uDA44\\uDCAA\\uBB75\\uD840\\uDE5D\\'\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\u349D\\uDB13\\uDEE9\\u0000\\uD9C5\\uDF21\\uDB5A\\uDD4D\\u00F4\\uD8AF\\uDFA2\\u0004\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uD85C\\uDD92\\uDB1A\\uDFED\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDA0F\\uDDD7\\u00A0\\uDADB\\uDC49\\u001B\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDAF9\\uDEF7\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\ud9c3\udd78\uda9d\ude1a\uda44\udd21\ubb75\ud840\ude5d'\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud899\udca2\udb1e\udc09\udbd6\udc06\uda7a\udc63\udbb2\udec5'\uda85\udfad\ud936\ude10\000\ud971\ude89\udb6b\udeea\udbb8\udead\udbb0\ude3d\ud983\udf05\u3e6b\uda4a\udfcb\ud941\udd2a\ud8c8\udee3\uda2e\udc66\uda0f\uddd7\ud897\udd6e\uda46\ude31\uc14b\ud8c5\udcc2\ud9ff\udc36\uda3d\uded9\ud996\udd2f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uD9C3\\uDD78\\uDA9D\\uDE1A\\uDA44\\uDD21\\uBB75\\uD840\\uDE5D\\'\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD899\\uDCA2\\uDB1E\\uDC09\\uDBD6\\uDC06\\uDA7A\\uDC63\\uDBB2\\uDEC5\\'\\uDA85\\uDFAD\\uD936\\uDE10\\u0000\\uD971\\uDE89\\uDB6B\\uDEEA\\uDBB8\\uDEAD\\uDBB0\\uDE3D\\uD983\\uDF05\\u3E6B\\uDA4A\\uDFCB\\uD941\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDA0F\\uDDD7\\uD897\\uDD6E\\uDA46\\uDE31\\uC14B\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDA3D\\uDED9\\uD996\\uDD2F", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\ud9c3\udd78\ud876\ude86\uda44\udcaa\ubb75\ud840\ude5d'\ucf5a\ud85c\udd18\udac6\udfb7\udb8b\udcfa\ud899\udca2\udb1e\udc09\udbd6\udc06\udbf7\udf07\udb5a\udd4d\u00f4\uda85\udfad\ud936\ude10\000\udb51\udd79\ud82a\udcb4\udb84\udec4\ud860\udc2e\udb7f\uddfd\ud85c\udd92\udb1a\udfed\ud941\udd2a\ud8c8\udee3\uda2e\udc66\uda0f\uddd7\ud897\udd6e\udadb\udcb0\033\ud8c5\udcc2\ud9ff\udc36\uda3d\uded9\ud996\udd2f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uD9C3\\uDD78\\uD876\\uDE86\\uDA44\\uDCAA\\uBB75\\uD840\\uDE5D'\\uCF5A\\uD85C\\uDD18\\uDAC6\\uDFB7\\uDB8B\\uDCFA\\uD899\\uDCA2\\uDB1E\\uDC09\\uDBD6\\uDC06\\uDBF7\\uDF07\\uDB5A\\uDD4D\\u00F4\\uDA85\\uDFAD\\uD936\\uDE10\\u0000\\uDB51\\uDD79\\uD82A\\uDCB4\\uDB84\\uDEC4\\uD860\\uDC2E\\uDB7F\\uDDFD\\uD85C\\uDD92\\uDB1A\\uDFED\\uD941\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDA0F\\uDDD7\\uD897\\uDD6E\\uDADB\\uDCB0\\u001B\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDA3D\\uDED9\\uD996\\uDD2F", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJavaScript("\udb4b\udc62\ud9bc\udc84\udaf2\ude2c\u3e4c\udae2\udf6c\\");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb4b\udc62\ud9bc\udc84\udaf2\ude2c\u3e4c\udae2\udf6c\\", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\udb37\udd72\u00b7\uda28\udc53\ubb75\ud906\udd20\000\000\udb1e\udc1c\udac6\udfdd\"\000\000\000\ud9c5\udf21#\000\ud8af\udfa2\004\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\ud85c\udd92\u33e7\ud925\udd2a\ud8c8\udee3\uda2e\udc66\uda0f\uddd7\u00a0\000\000\ud8c5\udcc2\ud9ff\udc36\udaf9\udef7\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uDB37\\uDD72\\u00B7\\uDA28\\uDC53\\uBB75\\uD906\\uDD20\\u0000\\u0000\\uDB1E\\uDC1C\\uDAC6\\uDFDD\\\"\\u0000\\u0000\\u0000\\uD9C5\\uDF21#\\u0000\\uD8AF\\uDFA2\\u0004\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uD85C\\uDD92\\u33E7\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDA0F\\uDDD7\\u00A0\\u0000\\u0000\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDAF9\\uDEF7\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u0086\udb37\udd72\udbe4\ude7d\uda44\udcaa\uda79\udd39\ud864\udfde\005\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud99f\udd65\ub4d3\ud9f3\ude88\ud9c5\udf21\udb5a\udd4d\u00f4\ud8af\udfa2\004\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\ud85c\udd92\udb1a\udfed\ud925\udd2a\ud8c8\udee3\uda2e\udc66\udb4d\ude35\ud82d\udc89\uda03\uddbe\033\ud8c5\udcc2\ud9ff\udc36\udaf9\udef7\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0086\\uDB37\\uDD72\\uDBE4\\uDE7D\\uDA44\\uDCAA\\uDA79\\uDD39\\uD864\\uDFDE\\u0005\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDB5A\\uDD4D\\u00F4\\uD8AF\\uDFA2\\u0004\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uD85C\\uDD92\\uDB1A\\uDFED\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDB4D\\uDE35\\uD82D\\uDC89\\uDA03\\uDDBE\\u001B\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDAF9\\uDEF7\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\000\uda8c\udc05\000\ud998\udc4b\ubb75\ub915\000\000\000\000\udb8b\udcfa\u009d\ud99c\udd28\000\000\u1100\000\ud8af\udfa2\u7204\000\udab2\udc78\ud82a\udc2b\000\000\000\000\udb1a\udf8a\u0098\ud8c8\udee3\uda0f\ude66\u0087\000\000\033\ud8c5\udcc2\ud9ff\udc36\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000&#55948;&#56325;\000&#55704;&#56395;&#47989;&#47381;\000\000\000\000&#56203;&#56570;&#157;&#55708;&#56616;\000\000&#4352;\000&#55471;&#57250;&#29188;\000&#55986;&#56440;&#55338;&#56363;\000\000\000\000&#56090;&#57226;&#152;&#55496;&#57059;&#55823;&#56934;&#135;\000\000\033&#55493;&#56514;&#55807;&#56374;\000\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\udb16\udd72\ud876\ude86\ud86e\udc5f\000\udb68\ude51\000\000\000\000\000\000\udb13\udee9\u00bc\000\udb5a\udd4d\u00f4\uda85\udfad\ud936\ude10\000\u7500\000\udb84\ude06\ud83a\udf2e\udb7f\uddfd\ud85c\udd92\u1b63\000\000\uda2e\udc66\uda0f\uddd7\ud84a\udd64\udb3a\udda3\033\000\000\uda3d\udded");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uDB16\\uDD72\\uD876\\uDE86\\uD86E\\uDC5F\\u0000\\uDB68\\uDE51\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uDB13\\uDEE9\\u00BC\\u0000\\uDB5A\\uDD4D\\u00F4\\uDA85\\uDFAD\\uD936\\uDE10\\u0000\\u7500\\u0000\\uDB84\\uDE06\\uD83A\\uDF2E\\uDB7F\\uDDFD\\uD85C\\uDD92\\u1B63\\u0000\\u0000\\uDA2E\\uDC66\\uDA0F\\uDDD7\\uD84A\\uDD64\\uDB3A\\uDDA3\\u001B\\u0000\\u0000\\uDA3D\\uDDED", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u0086\udb37\udd72\u53b7\000\uda79\udcc4\ud864\udfde\005\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\000\ub4d3\ud9f3\ude88\ud9c5\udf21#\u00f4\000\000\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\ud85c\udd92\udb1a\udfed\ud925\udd2a\ud8c8\udee3\uda2e\udc66\udb4d\ude35\u00fb\uda03\udd17\033\ud8c5\udcc2\u00a8\udad8\udc0b\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0086\\uDB37\\uDD72\\u53B7\\u0000\\uDA79\\uDCC4\\uD864\\uDFDE\\u0005\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\u0000\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21#\\u00F4\\u0000\\u0000\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uD85C\\uDD92\\uDB1A\\uDFED\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDB4D\\uDE35\\u00FB\\uDA03\\uDD17\\u001B\\uD8C5\\uDCC2\\u00A8\\uDAD8\\uDC0B\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u0086\udb37\udd72\udbe4\ude7d\uda44\udcaa\uda79\udd39\ud864\udfde\005\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud99f\udd65\ub4d3\ud9f3\ude88\ud9c5\udf21\udb5a\udd4d\001\ud8af\udfa2\004\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\udb5f\udd78\udb1a\udff9\ud925\udd2a\ud8c8\udee3\uda2e\udc66\uda4c\udfd6\ud82c\udfa0\ud8cf\udfc3\udbcf\udc97\uda86\udc11\udac2\udc32\udaf9\udef7\uda9b\ude2d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0086\\uDB37\\uDD72\\uDBE4\\uDE7D\\uDA44\\uDCAA\\uDA79\\uDD39\\uD864\\uDFDE\\u0005\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDB5A\\uDD4D\\u0001\\uD8AF\\uDFA2\\u0004\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uDB5F\\uDD78\\uDB1A\\uDFF9\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDA4C\\uDFD6\\uD82C\\uDFA0\\uD8CF\\uDFC3\\uDBCF\\uDC97\\uDA86\\uDC11\\uDAC2\\uDC32\\uDAF9\\uDEF7\\uDA9B\\uDE2D", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\udb16\udd72\u53b7\ud86e\udc5f\000\udb68\ude51\000\000\000\000\000\000\udb13\udee9\u00bc\000\udb5a\udd4d\u00f4\uda85\udfad\000\000\u7500\000\udb84\ude06\ud83a\ude7c\udb7f\uddfd\ud85c\udd92\u1b63\000\000\uda2e\udc66\uda0f\uddd7\ud84a\udd64\udb3a\udda3\033\000\000\udb43\udfe1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uDB16\\uDD72\\u53B7\\uD86E\\uDC5F\\u0000\\uDB68\\uDE51\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uDB13\\uDEE9\\u00BC\\u0000\\uDB5A\\uDD4D\\u00F4\\uDA85\\uDFAD\\u0000\\u0000\\u7500\\u0000\\uDB84\\uDE06\\uD83A\\uDE7C\\uDB7F\\uDDFD\\uD85C\\uDD92\\u1B63\\u0000\\u0000\\uDA2E\\uDC66\\uDA0F\\uDDD7\\uD84A\\uDD64\\uDB3A\\uDDA3\\u001B\\u0000\\u0000\\uDB43\\uDFE1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\udbdc\udc9b\udbd7\udf23\udb69\udfef\udb63\udcfd\ud985\ude9d\ud9c8\ude2e\uda65\ude47\ud937\udc0f\ud820\ude7f\udbb6\udc44\udbd5\udf27\udb45\udecf\ud85e\udf24\ud97b\udedf");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbdc\udc9b\udbd7\udf23\udb69\udfef\udb63\udcfd\ud985\ude9d\ud9c8\ude2e\uda65\ude47\ud937\udc0f\ud820\ude7f\udbb6\udc44\udbd5\udf27\udb45\udecf\ud85e\udf24\ud97b\udedf", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\uda1f\ude49\udab2\udf9c\udae1\udf3f\000\udb9e\udc0e\ud84a\udcc4\ud9ba\udeb1\udadd\udcd8\udb86\ude2e\udb9f\ude5b\uda32\udf46\ud8fb\udcf6\udb10\udc7b\udb2f\udde3\ud831\ude79\uda1a\udead\ud912\ude7e\ud979\uddf5\ud95c\udf73\ud9d3\udffb\ud8d8\udd94\ud817\udf04\ud8d8\udfaa\udabd\udfdf\ud954\udc53\udbd4\udf95\ud859\ude4b\udb30\udd9e\ud929\udcfd\ud894\udf78\ud8b6\udc4f\ud8c3\udd77\uda87\udee6\ud885\udd32\udab0\udeb0\udb77\udf37\udb7f\udd20\ud9e0\uded5\udb14\uddde\ud919\ude72\udae2\udd6d\ud955\udd01\ucdd1\udb3d\udf86\udbf8\udd92\ud9b2\udf90\udaff\udd90\udbde\udc89\ud8ea\udf6f\ud851\udf66\ud84b\udfcc\udbcd\ude55\ud8ff\udc4a\udac6\udec4\u769f\ud97c\ude93\udb13\udf2d\udaa3\udf8b\ud8eb\udd96\u346f\uda5a\udd7f\ud858\udc4b\uda7c\udcc8\udb0f\udef9\ud8a9\udc99\ud977\udf2c\ud940\ude8e\ud955\udc02\ud93d\udc09\uda6d\udd00\uda35\udd8d\ud989\uddf3\udb44\udec0\udac8\udcc4\ud80f\udd7c\ud8ff\udddd\uda93\udd1f\ud914\udda4\udb2f\udd91\udbae\udf7d\udaf1\udc19\udbcd\udc99\udb8e\udfe9\uda2d\udcc1\udb98\uddd3\ud821\udee4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA1F\\uDE49\\uDAB2\\uDF9C\\uDAE1\\uDF3F\\u0000\\uDB9E\\uDC0E\\uD84A\\uDCC4\\uD9BA\\uDEB1\\uDADD\\uDCD8\\uDB86\\uDE2E\\uDB9F\\uDE5B\\uDA32\\uDF46\\uD8FB\\uDCF6\\uDB10\\uDC7B\\uDB2F\\uDDE3\\uD831\\uDE79\\uDA1A\\uDEAD\\uD912\\uDE7E\\uD979\\uDDF5\\uD95C\\uDF73\\uD9D3\\uDFFB\\uD8D8\\uDD94\\uD817\\uDF04\\uD8D8\\uDFAA\\uDABD\\uDFDF\\uD954\\uDC53\\uDBD4\\uDF95\\uD859\\uDE4B\\uDB30\\uDD9E\\uD929\\uDCFD\\uD894\\uDF78\\uD8B6\\uDC4F\\uD8C3\\uDD77\\uDA87\\uDEE6\\uD885\\uDD32\\uDAB0\\uDEB0\\uDB77\\uDF37\\uDB7F\\uDD20\\uD9E0\\uDED5\\uDB14\\uDDDE\\uD919\\uDE72\\uDAE2\\uDD6D\\uD955\\uDD01\\uCDD1\\uDB3D\\uDF86\\uDBF8\\uDD92\\uD9B2\\uDF90\\uDAFF\\uDD90\\uDBDE\\uDC89\\uD8EA\\uDF6F\\uD851\\uDF66\\uD84B\\uDFCC\\uDBCD\\uDE55\\uD8FF\\uDC4A\\uDAC6\\uDEC4\\u769F\\uD97C\\uDE93\\uDB13\\uDF2D\\uDAA3\\uDF8B\\uD8EB\\uDD96\\u346F\\uDA5A\\uDD7F\\uD858\\uDC4B\\uDA7C\\uDCC8\\uDB0F\\uDEF9\\uD8A9\\uDC99\\uD977\\uDF2C\\uD940\\uDE8E\\uD955\\uDC02\\uD93D\\uDC09\\uDA6D\\uDD00\\uDA35\\uDD8D\\uD989\\uDDF3\\uDB44\\uDEC0\\uDAC8\\uDCC4\\uD80F\\uDD7C\\uD8FF\\uDDDD\\uDA93\\uDD1F\\uD914\\uDDA4\\uDB2F\\uDD91\\uDBAE\\uDF7D\\uDAF1\\uDC19\\uDBCD\\uDC99\\uDB8E\\uDFE9\\uDA2D\\uDCC1\\uDB98\\uDDD3\\uD821\\uDEE4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb66\uddd8/\udb40\udcd5\uab2e\uda63\udffc\ud9f9\udf7b\uda92\ude70\ud904\ude47\ud875\udd97\ud8fd\ude2f\ud801\udf4d\ud990\udc59\ud808\ude91");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB66\\uDDD8\\/\\uDB40\\uDCD5\\uAB2E\\uDA63\\uDFFC\\uD9F9\\uDF7B\\uDA92\\uDE70\\uD904\\uDE47\\uD875\\uDD97\\uD8FD\\uDE2F\\uD801\\uDF4D\\uD990\\uDC59\\uD808\\uDE91", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\ud9c3\udd78\uda9d\udd63\uda44\udd21\ubb75\ud840\ude5d'\ucf5a\udaf9\udd3a\udac6\udfdd\ud960\udef2\ud899\udca2\udb1e\udc09\000\u4d4ag\000\000\ud936\ude10\000\000\udb6b\ude6c\u009a\uda50\ude48\u68f2\udbeb\ude74?\ud941\udc92\ud8c8\udee3`\000\ud80f\udcaa\000\000\ud8c5\udcc2\ud9ff\udc36\uda3d\uded9\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uD9C3\\uDD78\\uDA9D\\uDD63\\uDA44\\uDD21\\uBB75\\uD840\\uDE5D\\'\\uCF5A\\uDAF9\\uDD3A\\uDAC6\\uDFDD\\uD960\\uDEF2\\uD899\\uDCA2\\uDB1E\\uDC09\\u0000\\u4D4Ag\\u0000\\u0000\\uD936\\uDE10\\u0000\\u0000\\uDB6B\\uDE6C\\u009A\\uDA50\\uDE48\\u68F2\\uDBEB\\uDE74?\\uD941\\uDC92\\uD8C8\\uDEE3`\\u0000\\uD80F\\uDCAA\\u0000\\u0000\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDA3D\\uDED9\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u0086\udb37\udd72\ud86d\udda2\udb5f\udfb8\udb6c\udd64\ud965\udc1b\002\uda3d\ude5b\ud9fa\udc48\udac6\udfdd\udb8b\udcfa\ud99f\udd65\ub4d3\ud9f3\ude88\ud9c5\udf21\udb5a\udd4d\ud847\udc57\ud89d\udd13\udaff\udd50\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\ud85c\udd92\udb1a\udfed\ud925\udd2a\ud8c8\udee3\uda2e\udc66\udb4d\ude35\ud82d\udc89\ud913\ude46\033\udacb\udec2\ud9ff\udc36\udaf9\udef7\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0086\\uDB37\\uDD72\\uD86D\\uDDA2\\uDB5F\\uDFB8\\uDB6C\\uDD64\\uD965\\uDC1B\\u0002\\uDA3D\\uDE5B\\uD9FA\\uDC48\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDB5A\\uDD4D\\uD847\\uDC57\\uD89D\\uDD13\\uDAFF\\uDD50\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uD85C\\uDD92\\uDB1A\\uDFED\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDB4D\\uDE35\\uD82D\\uDC89\\uD913\\uDE46\\u001B\\uDACB\\uDEC2\\uD9FF\\uDC36\\uDAF9\\uDEF7\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\003\udb37\udd72\udbe4\ude7d\uda44\udcaa\uda79\udd39\ud864\udfde\005\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud99f\udd65\ub4d3\ud9f3\ude88\ud9c5\udf21\udb5a\udd4d\001\ud8af\udfa2\004\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\udb5f\udd78\udb1a\udff9\ud925\udd2a\ud8c8\udee3\uda2e\udc66\udb7e\uddae\ud84e\udd0a\ud8cf\udfc3\udbcf\udc97\uda86\udc11\udac2\udc32\udaf9\udef7\uda9b\ude2d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0003\\uDB37\\uDD72\\uDBE4\\uDE7D\\uDA44\\uDCAA\\uDA79\\uDD39\\uD864\\uDFDE\\u0005\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDB5A\\uDD4D\\u0001\\uD8AF\\uDFA2\\u0004\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uDB5F\\uDD78\\uDB1A\\uDFF9\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDB7E\\uDDAE\\uD84E\\uDD0A\\uD8CF\\uDFC3\\uDBCF\\uDC97\\uDA86\\uDC11\\uDAC2\\uDC32\\uDAF9\\uDEF7\\uDA9B\\uDE2D", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u0086\udb60\ude5a\udbe4\ude7d\uda44\udcaa\uda79\udd39\udbea\udde0\001\ud815\udde7\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud99f\udd65\ub4d3\ud9f3\ude88\uda6c\udef5\udbe3\udef7\001\ud8af\udfa2\004\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\ud988\udf4c\udb7f\udd3b\uda99\udd9e\udb1a\udff9\ud925\udd2a\udbb9\udfd7\ud8b7\uddb6\uda32\uddd6\ud82c\udfa0\ud8cf\udfc3\udbcf\udc97\uda86\udc11\udac2\udc32\udaf9\udef7\uda9b\ude2d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0086\\uDB60\\uDE5A\\uDBE4\\uDE7D\\uDA44\\uDCAA\\uDA79\\uDD39\\uDBEA\\uDDE0\\u0001\\uD815\\uDDE7\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uDA6C\\uDEF5\\uDBE3\\uDEF7\\u0001\\uD8AF\\uDFA2\\u0004\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uD988\\uDF4C\\uDB7F\\uDD3B\\uDA99\\uDD9E\\uDB1A\\uDFF9\\uD925\\uDD2A\\uDBB9\\uDFD7\\uD8B7\\uDDB6\\uDA32\\uDDD6\\uD82C\\uDFA0\\uD8CF\\uDFC3\\uDBCF\\uDC97\\uDA86\\uDC11\\uDAC2\\uDC32\\uDAF9\\uDEF7\\uDA9B\\uDE2D", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\ud881\ude5b\udbd3\ude71\udac4\udebe\udb4a\udeee\ud985\ude9d\ud9c8\ude13");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud881\ude5b\udbd3\ude71\udac4\udebe\udb4a\udeee\ud985\ude9d\ud9c8\ude13", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\uda9a\ude0c\u00fe\000\000\000\ud844\udd02\udb44\udf70\ud9c3\udfbf\u00cd\u0cd8\000\udb02\udfc1\udaa0\udd60\u00ac\udad8\udd2e\ud956\udd2fh\000\000\036\ud938\udf2a\ud9fb\udf19\udb5b\udddd\u0a11\udb02\udf8f\uda24\udf1f\uda55\udc6a\udb5c\udd07\ud84e\udc0c\000w\000\000\000\000\u00da\000\000\000\000\ud84a\udcc4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55962;&#56844;&thorn;\000\000\000&#55364;&#56578;&#56132;&#57200;&#55747;&#57279;&Iacute;&#3288;\000&#56066;&#57281;&#55968;&#56672;&not;&#56024;&#56622;&#55638;&#56623;h\000\000\036&#55608;&#57130;&#55803;&#57113;&#56155;&#56797;&#2577;&#56066;&#57231;&#55844;&#57119;&#55893;&#56426;&#56156;&#56583;&#55374;&#56332;\000w\000\000\000\000&Uacute;\000\000\000\000&#55370;&#56516;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u0086\udb37\udd72\udbe4\ude7d\udaa6\udd1b\uda37\udd07\ud9c0\udf76\005\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud99f\udd65\ub4d3\ud9f3\ude88\ud9c5\udf21\udbe8\udfa1\ud80a\udd57\udafd\udf37\005\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda46\ude46\udb7f\udd3b\ud85c\udd92\ud884\udd07\ud925\udd13\ud8c8\udee3\uda2e\udc66\udb4d\ude35\ud82d\udc89\uda03\uddbe\033\ud8c5\udcc2\ud9ff\udc36\uda37\udc29\"");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0086\\uDB37\\uDD72\\uDBE4\\uDE7D\\uDAA6\\uDD1B\\uDA37\\uDD07\\uD9C0\\uDF76\\u0005\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDBE8\\uDFA1\\uD80A\\uDD57\\uDAFD\\uDF37\\u0005\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA46\\uDE46\\uDB7F\\uDD3B\\uD85C\\uDD92\\uD884\\uDD07\\uD925\\uDD13\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDB4D\\uDE35\\uD82D\\uDC89\\uDA03\\uDDBE\\u001B\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDA37\\uDC29\\\"", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\004\udb37\udd72\udbe4\ude7d\uda44\udcaa\uda79\udd39\ud864\udfde\005\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud99f\udd65\ub4d3\ud9f3\ude88\ud9c5\udf21\udb5a\udd4d\001\ud8af\udfa2\004\uda5a\udced\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\ud90d\udee2\udb67\udfd4\udb1a\udff9\ud925\udd2a\ud8c8\udee3\uda2e\udc66\uda4c\udfd6\ud82c\udfa0\ud8cf\udfc3\udbcf\udc97\uda86\udc11\udac2\udc32\udaf9\udef7\uda9b\ude2d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0004\\uDB37\\uDD72\\uDBE4\\uDE7D\\uDA44\\uDCAA\\uDA79\\uDD39\\uD864\\uDFDE\\u0005\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDB5A\\uDD4D\\u0001\\uD8AF\\uDFA2\\u0004\\uDA5A\\uDCED\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uD90D\\uDEE2\\uDB67\\uDFD4\\uDB1A\\uDFF9\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDA4C\\uDFD6\\uD82C\\uDFA0\\uD8CF\\uDFC3\\uDBCF\\uDC97\\uDA86\\uDC11\\uDAC2\\uDC32\\uDAF9\\uDEF7\\uDA9B\\uDE2D", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\ud9c3\udd78\uda9d\ude1a\uda3d\udf55\ubb75\ud840\ude5d'\ucf5a\ud85a\udf78\udac7\udc13\udb34\udd2d\uda3a\uded1\udb16\udd1d\ud854\udc25\ud807\ude6e\udbb2\udec5'\uda86\udc7e\ud936\ude10\u7614\ud971\ude89\udb6b\udeea\udbb8\udead\udbb0\ude3d\ud983\udf05\ud96b\udc78\uda4a\udfcb\ud941\udd2a\ud8c8\udee3\ud871\udde9\uda0f\uddd7\ud897\udd6e\uda46\ude31\uc14b\ud8c5\udcc2\ud9f1\udcd2\uda3d\uded9\ud996\udd2f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uD9C3\\uDD78\\uDA9D\\uDE1A\\uDA3D\\uDF55\\uBB75\\uD840\\uDE5D'\\uCF5A\\uD85A\\uDF78\\uDAC7\\uDC13\\uDB34\\uDD2D\\uDA3A\\uDED1\\uDB16\\uDD1D\\uD854\\uDC25\\uD807\\uDE6E\\uDBB2\\uDEC5'\\uDA86\\uDC7E\\uD936\\uDE10\\u7614\\uD971\\uDE89\\uDB6B\\uDEEA\\uDBB8\\uDEAD\\uDBB0\\uDE3D\\uD983\\uDF05\\uD96B\\uDC78\\uDA4A\\uDFCB\\uD941\\uDD2A\\uD8C8\\uDEE3\\uD871\\uDDE9\\uDA0F\\uDDD7\\uD897\\uDD6E\\uDA46\\uDE31\\uC14B\\uD8C5\\uDCC2\\uD9F1\\uDCD2\\uDA3D\\uDED9\\uD996\\uDD2F", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeJava("\ud9cf\udd90\ud80c\udf67\ud81c\udead\ud93a\udda1\udae2\udee0\ud994\udd07\udab2\udf36\udaed\udcd4\uda48\udf22\udb77\udd8b\uda72\udcba\ud914\ude5c\ud8ec\udcbd\udb52\udd2f\uda74\udf70\ud8c4\udc91\ue0c7\ud85f\udf5b\udb02\udc35\uda3e\udfef\ud88d\udcb7\ud894\udfe8\ud9dc\udd6e\ud885\udc3b\ud811\ude55\udb37\udca7\uda6b\ude11\udbd7\ude10\uda52\ude51\uda94\uded6\uda28\udcf6\ud8d4\udcae\uda92\udf72\ud87f\udc8f\uda6e\ude66\ud9a0\udee4\udae1\udeaf\ud9d5\uded3\udaaf\udc3a\udaa2\ude02\ud8b1\udd1c\udb3a\ude3c\udb36\udcab\udb09\udfe5\ud86e\udf62\ud9f5\udc90\udae8\udd2b\udaf4\ude82\ud817\ude04\ud9f1\udf45\ud981\udc29\udae6\ude91\ud966\udced\ud832\udc65\uda44\udff8\udacc\ude9f\udb63\udca0\udb55\ude5d\udb1c\udc13\udbfe\udddd\udb9b\udf91\ud829\udf1a\uda53\udd8e\ud933\udcb3\uda2e\uddf0\ud94a\ude7a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9cf\udd90\ud80c\udf67\ud81c\udead\ud93a\udda1\udae2\udee0\ud994\udd07\udab2\udf36\udaed\udcd4\uda48\udf22\udb77\udd8b\uda72\udcba\ud914\ude5c\ud8ec\udcbd\udb52\udd2f\uda74\udf70\ud8c4\udc91\ue0c7\ud85f\udf5b\udb02\udc35\uda3e\udfef\ud88d\udcb7\ud894\udfe8\ud9dc\udd6e\ud885\udc3b\ud811\ude55\udb37\udca7\uda6b\ude11\udbd7\ude10\uda52\ude51\uda94\uded6\uda28\udcf6\ud8d4\udcae\uda92\udf72\ud87f\udc8f\uda6e\ude66\ud9a0\udee4\udae1\udeaf\ud9d5\uded3\udaaf\udc3a\udaa2\ude02\ud8b1\udd1c\udb3a\ude3c\udb36\udcab\udb09\udfe5\ud86e\udf62\ud9f5\udc90\udae8\udd2b\udaf4\ude82\ud817\ude04\ud9f1\udf45\ud981\udc29\udae6\ude91\ud966\udced\ud832\udc65\uda44\udff8\udacc\ude9f\udb63\udca0\udb55\ude5d\udb1c\udc13\udbfe\udddd\udb9b\udf91\ud829\udf1a\uda53\udd8e\ud933\udcb3\uda2e\uddf0\ud94a\ude7a", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u6426\udbc4\udf47\ud9d8\ude04\udab4\udd80\ud98a\udf9d\ud895\udce9\udb0a\ude38\ud905\udce7\u8bc7\ud81e\ude8e\ud94d\udf43\ud9da\udfe4\uda4f\uddc3\udbd1\udc83\udaaa\udeab\uda79\udcd6\udbfc\udfaf\uda59\udfd6\uda0a\udc3a\udadc\ude83\uda74\udf65\ud98a\udc2b\udaad\uddaf\ud883\uddfb\ud872\udd86\uda5a\udeb8\udbaa\udc3a\ud843\udf8c\ud082\uc517\ud811\udd26\ud918\udc7a\ud83b\uddbb\ud907\udccd\udaff\udf2e\udbda\udf75\ud9fe\udc41\ud859\udcfe\u2802\ud8e1\udc0a\uda15\ude6b\ud895\udd5b\udb03\udd4e\ud838\udde1\udb4e\udd70\ud9c0\udeca\ud990\udcc4\ud86e\udec4\ud813\udc9a\ud8df\udc1c\ud806\ude3c\ud885\uddfc\uda50\udfea\u28d2\udb68\udf69\ud81e\udc04\uda0c\ude9c\ud96f\uddc4\ud86e\udc9e\uda8d\udff7\udaf5\udd44\ud89c\uddf2\ud91e\udfb8\ud8be\udd81\udab6\udd2d\udbd8\udf0b\uda96\udcd9\uda35\udf51\ud9e9\udc0d\ud9dc\udd0e\ud932\udefc\ud963\udd65\ud92a\udc82\ud9a0\udfe3\udb85\udd1a\ud86e\udc5e\ud9d6\ude96\udb2b\udf9b\ud9d6\udf68\ud8ef\ude16\udba8\udf68\udb0e\ude73\ud9f5\udd1f\ud96a\udf64\ud9c7\udc99\ud85c\udf7a\ud85e\udc4b\u2929\ud82e\udf08\udb65\ude75\ud986\udd97\uda6a\uddff\ud8ad\udf0c\udae3\uddbc\udaf7\ude35\uda10\udc81\udb8b\udd83\ud965\udc07\uda15\udef4\ud8f3\uddf7\ud9bc\udcab\u7c73\ud8ec\udd7c\u2cf0\udb25\udf00\udbe5\udc50\udbcc\udc39\udb42\ude22\ud933\udfbe\uda5b\udd60\u7a6b\ud810\udd47\udb26\udc59\ud98f\uddb9\ud930\udc25\ud84c\udf24\ud941\udc1a\ud9d8\ude99\ud880\udc4d\udbaa\udd37\udacc\udeb5\udb29\udcba\ud984\udc43\ucb23\ud988\udfbb\ud922\udecb\ud871\ude4f\ud955\ude1a\ud961\udd17\udb00\udcc2\ud9e0\udf83\uda4e\udcce\ud99d\udfec\udbe8\udff7\ud944\udc2f\ud9a9\udf11\udaeb\udcc0\udaf5\udeb7\udb50\udffb\ud91c\udffc\udbf3\udceb\ud818\ude01\uda8c\udcfb\ud97e\udc2f\u47ef\udbc4\udff8\ud823\udc39\udb4c\ude3e\u0e95\ud985\udf5c\ud881\ude1b\ud85c\udf39\ud9ff\uded4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u6426\\uDBC4\\uDF47\\uD9D8\\uDE04\\uDAB4\\uDD80\\uD98A\\uDF9D\\uD895\\uDCE9\\uDB0A\\uDE38\\uD905\\uDCE7\\u8BC7\\uD81E\\uDE8E\\uD94D\\uDF43\\uD9DA\\uDFE4\\uDA4F\\uDDC3\\uDBD1\\uDC83\\uDAAA\\uDEAB\\uDA79\\uDCD6\\uDBFC\\uDFAF\\uDA59\\uDFD6\\uDA0A\\uDC3A\\uDADC\\uDE83\\uDA74\\uDF65\\uD98A\\uDC2B\\uDAAD\\uDDAF\\uD883\\uDDFB\\uD872\\uDD86\\uDA5A\\uDEB8\\uDBAA\\uDC3A\\uD843\\uDF8C\\uD082\\uC517\\uD811\\uDD26\\uD918\\uDC7A\\uD83B\\uDDBB\\uD907\\uDCCD\\uDAFF\\uDF2E\\uDBDA\\uDF75\\uD9FE\\uDC41\\uD859\\uDCFE\\u2802\\uD8E1\\uDC0A\\uDA15\\uDE6B\\uD895\\uDD5B\\uDB03\\uDD4E\\uD838\\uDDE1\\uDB4E\\uDD70\\uD9C0\\uDECA\\uD990\\uDCC4\\uD86E\\uDEC4\\uD813\\uDC9A\\uD8DF\\uDC1C\\uD806\\uDE3C\\uD885\\uDDFC\\uDA50\\uDFEA\\u28D2\\uDB68\\uDF69\\uD81E\\uDC04\\uDA0C\\uDE9C\\uD96F\\uDDC4\\uD86E\\uDC9E\\uDA8D\\uDFF7\\uDAF5\\uDD44\\uD89C\\uDDF2\\uD91E\\uDFB8\\uD8BE\\uDD81\\uDAB6\\uDD2D\\uDBD8\\uDF0B\\uDA96\\uDCD9\\uDA35\\uDF51\\uD9E9\\uDC0D\\uD9DC\\uDD0E\\uD932\\uDEFC\\uD963\\uDD65\\uD92A\\uDC82\\uD9A0\\uDFE3\\uDB85\\uDD1A\\uD86E\\uDC5E\\uD9D6\\uDE96\\uDB2B\\uDF9B\\uD9D6\\uDF68\\uD8EF\\uDE16\\uDBA8\\uDF68\\uDB0E\\uDE73\\uD9F5\\uDD1F\\uD96A\\uDF64\\uD9C7\\uDC99\\uD85C\\uDF7A\\uD85E\\uDC4B\\u2929\\uD82E\\uDF08\\uDB65\\uDE75\\uD986\\uDD97\\uDA6A\\uDDFF\\uD8AD\\uDF0C\\uDAE3\\uDDBC\\uDAF7\\uDE35\\uDA10\\uDC81\\uDB8B\\uDD83\\uD965\\uDC07\\uDA15\\uDEF4\\uD8F3\\uDDF7\\uD9BC\\uDCAB\\u7C73\\uD8EC\\uDD7C\\u2CF0\\uDB25\\uDF00\\uDBE5\\uDC50\\uDBCC\\uDC39\\uDB42\\uDE22\\uD933\\uDFBE\\uDA5B\\uDD60\\u7A6B\\uD810\\uDD47\\uDB26\\uDC59\\uD98F\\uDDB9\\uD930\\uDC25\\uD84C\\uDF24\\uD941\\uDC1A\\uD9D8\\uDE99\\uD880\\uDC4D\\uDBAA\\uDD37\\uDACC\\uDEB5\\uDB29\\uDCBA\\uD984\\uDC43\\uCB23\\uD988\\uDFBB\\uD922\\uDECB\\uD871\\uDE4F\\uD955\\uDE1A\\uD961\\uDD17\\uDB00\\uDCC2\\uD9E0\\uDF83\\uDA4E\\uDCCE\\uD99D\\uDFEC\\uDBE8\\uDFF7\\uD944\\uDC2F\\uD9A9\\uDF11\\uDAEB\\uDCC0\\uDAF5\\uDEB7\\uDB50\\uDFFB\\uD91C\\uDFFC\\uDBF3\\uDCEB\\uD818\\uDE01\\uDA8C\\uDCFB\\uD97E\\uDC2F\\u47EF\\uDBC4\\uDFF8\\uD823\\uDC39\\uDB4C\\uDE3E\\u0E95\\uD985\\uDF5C\\uD881\\uDE1B\\uD85C\\uDF39\\uD9FF\\uDED4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\000\ud9c3\udd78\uda9d\udd63\uda44\udd21\ubb75\ud840\ude5d'\ucf5a\udaf9\udd3a\udac6\udfdd\ud960\udef2\ud899\udca2\udb1e\udc09\000\u4d4ag\000\000\ud936\ude10\ud949\udc64\000\udb6b\ude6c#\uda50\ude48\u68f2\udbeb\ude74?\ud941\udc92\ud8c8\udee3`\000\ud80f\udcaa\000\000\ud8c5\udcc2\ud9ff\udc36\uda3d\uded9\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uD9C3\\uDD78\\uDA9D\\uDD63\\uDA44\\uDD21\\uBB75\\uD840\\uDE5D\\'\\uCF5A\\uDAF9\\uDD3A\\uDAC6\\uDFDD\\uD960\\uDEF2\\uD899\\uDCA2\\uDB1E\\uDC09\\u0000\\u4D4Ag\\u0000\\u0000\\uD936\\uDE10\\uD949\\uDC64\\u0000\\uDB6B\\uDE6C#\\uDA50\\uDE48\\u68F2\\uDBEB\\uDE74?\\uD941\\uDC92\\uD8C8\\uDEE3`\\u0000\\uD80F\\uDCAA\\u0000\\u0000\\uD8C5\\uDCC2\\uD9FF\\uDC36\\uDA3D\\uDED9\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\003\udb37\udd72\udbe4\ude7d\uda44\udcaa\uda79\udd39\ud864\udfde\005\ucf5a\udaa4\udc3d\udac6\udfdd\udb8b\udcfa\ud99f\udd65\ub4d3\ud9f3\ude88\ud9c5\udf21\udb5a\udd4d\001\ud8af\udfa2\003\ud8a5\udd0f\ud971\udef5\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\udb5f\udd78\udb1a\udff9\ud925\udd2a\ud8c8\udee3\uda2e\udc66\udb7e\uddae\ud84e\udd0a\ud8cf\udfc3\udbcf\udc97\uda86\udc11\udac2\udc32\udaf9\udef7\uda9b\ude2d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0003\\uDB37\\uDD72\\uDBE4\\uDE7D\\uDA44\\uDCAA\\uDA79\\uDD39\\uD864\\uDFDE\\u0005\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\uDB8B\\uDCFA\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDB5A\\uDD4D\\u0001\\uD8AF\\uDFA2\\u0003\\uD8A5\\uDD0F\\uD971\\uDEF5\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uDB5F\\uDD78\\uDB1A\\uDFF9\\uD925\\uDD2A\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDB7E\\uDDAE\\uD84E\\uDD0A\\uD8CF\\uDFC3\\uDBCF\\uDC97\\uDA86\\uDC11\\uDAC2\\uDC32\\uDAF9\\uDEF7\\uDA9B\\uDE2D", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\udae1\udcd8\udb79\udd8a\ud809\udd10&\ud806\ude95\uda99\udf5d\udb70\udd6d\udb54\udc1d\ud8da\udc81\udb40\udcf0\u6e3c\udad6\uddbf\ud926\udc3a\uda27\udcd6\udb61\udcbe\uc0ab");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udae1\udcd8\udb79\udd8a\ud809\udd10&\ud806\ude95\uda99\udf5d\udb70\udd6d\udb54\udc1d\ud8da\udc81\udb40\udcf0\u6e3c\udad6\uddbf\ud926\udc3a\uda27\udcd6\udb61\udcbe\uc0ab", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\udaf9\ude05\uda2f\udff5\ud88d\udc28&\ud806\ude95\uda79\udd4d\udb5f\udc08\udb8b\udc5f\uda68\uddc1\udac2\udf0c\ud953\udd80\ud9ba\udd54\u8654\uda27\udcd6\udb61\udcbe\ud956\ude3d\udac7\udcd9\ud969\udfb4\udb1d\udcca\udbad\udc53\udb83\udea0\ud9be\udde7\ud8bb\udd8c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaf9\ude05\uda2f\udff5\ud88d\udc28&\ud806\ude95\uda79\udd4d\udb5f\udc08\udb8b\udc5f\uda68\uddc1\udac2\udf0c\ud953\udd80\ud9ba\udd54\u8654\uda27\udcd6\udb61\udcbe\ud956\ude3d\udac7\udcd9\ud969\udfb4\udb1d\udcca\udbad\udc53\udb83\udea0\ud9be\udde7\ud8bb\udd8c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\ud9fb\udc05\udba3\udcfc\ud809\udd10&");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9fb\udc05\udba3\udcfc\ud809\udd10&", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\udae1\udcd8\udb71\udd8a\ud809\udd10&\ud806\ude95\uda99\udf5d\udb70\udd6d\udb54\udc1d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udae1\udcd8\udb71\udd8a\ud809\udd10&\ud806\ude95\uda99\udf5d\udb70\udd6d\udb54\udc1d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\udae1\udcd8\udb71\udd8a\ud809\udd10&\ud806\ude95\uda99\udf5d\udb70\udd6d\u0b76");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udae1\udcd8\udb71\udd8a\ud809\udd10&\ud806\ude95\uda99\udf5d\udb70\udd6d\u0b76", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\ud8d3\udf12\ud959\udfe0\uda83\udd0d&\ud806\ude95\uda99\udf5d\udb70\udd6d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8d3\udf12\ud959\udfe0\uda83\udd0d&\ud806\ude95\uda99\udf5d\udb70\udd6d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\udae1\udcd8\udb79\udd8a\ud809\udd10&\ud806\ude95");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udae1\udcd8\udb79\udd8a\ud809\udd10&\ud806\ude95", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\uda14\uddd3\uda4a\udc7f\ud825\udc62&\uf4e7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda14\uddd3\uda4a\udc7f\ud825\udc62&\uf4e7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeHtml("\ud903\udfce\ud98a\udd5e\000\udb1c\ude05\ud80f\ude09\udbcf\udfc8\ud830\udc83\ud99f\udd6f\ud997\udd57\ud845\udc41\ud9eb\udf72\ud9f9\udcd0\ud89f\udfa5\ud9ad\udea3\ud944\ude39\udaa0\udc1a\udb50\udeae\udb3a\ude96\uda66\ude05\ud8a5\udcd3\ud9b9\udf39\ud901\ude88\ud965\udf80\ud97b\udf9b\udb67\udf55\ud8c6\udeda\uda73\udea7\udb25\udfac\ud85d\udf6b\udb2e\uddbf\udbf3\udf1a\uda29\udf79\uda68\udc85\udbbb\udcfb\ud959\udc8d\ud8cc\udebb\udafc\udf68\udacf\udd1d\uda40\ude7c\udb44\udebd\ud8de\ude23\ud9b9\ude7b\ud87f\udc5f\udac1\udfea\udb55\udfa4\ud8c7\udd10\ud809\udf8b\ud927\udd63\udb0b\udec8\udabd\udec2\ud940\udfca\udacb\udfe4\udb59\ude68\uda05\udf94\udb43\udca9\udb26\udd31\ud91c\udd19\ud8fd\udfcf\ud8ac\udcea\udb22\udcc5\ud9f8\udd4c\uda09\udf27\udbd6\uddb9\ud85c\udef1\udaca\udd49\udb4c\udd61\uda29\udc4a\udb19\udeee\ud901\udf95\ud941\ude63\udac9\udcb7\uf44e\udaf4\udd39\ud8b8\ude09\ud998\udfb4\udbe2\udd19\uda7c\udf48\ud86a\udc82\udbf1\ude29\udad4\udd88\uda78\udf74\ud856\ude0d\ud8bd\uded4\ud9d8\udea4\udae3\udf3c\ud8db\udf8b\udac4\udc13\u2034\ud850\udf3d\udac9\udfdd\ud9fc\udecb\udb40\udefd\udb8b\udc6d\ud98e\udf51\udbff\udefc\udb8d\ude05\ud8de\udd74\ud919\udcd3\ud856\udced\udb91\udc91");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("&#55555;&#57294;&#55690;&#56670;\000&#56092;&#56837;&#55311;&#56841;&#56271;&#57288;&#55344;&#56451;&#55711;&#56687;&#55703;&#56663;&#55365;&#56385;&#55787;&#57202;&#55801;&#56528;&#55455;&#57253;&#55725;&#56995;&#55620;&#56889;&#55968;&#56346;&#56144;&#57006;&#56122;&#56982;&#55910;&#56837;&#55461;&#56531;&#55737;&#57145;&#55553;&#56968;&#55653;&#57216;&#55675;&#57243;&#56167;&#57173;&#55494;&#57050;&#55923;&#56999;&#56101;&#57260;&#55389;&#57195;&#56110;&#56767;&#56307;&#57114;&#55849;&#57209;&#55912;&#56453;&#56251;&#56571;&#55641;&#56461;&#55500;&#57019;&#56060;&#57192;&#56015;&#56605;&#55872;&#56956;&#56132;&#57021;&#55518;&#56867;&#55737;&#56955;&#55423;&#56415;&#56001;&#57322;&#56149;&#57252;&#55495;&#56592;&#55305;&#57227;&#55591;&#56675;&#56075;&#57032;&#55997;&#57026;&#55616;&#57290;&#56011;&#57316;&#56153;&#56936;&#55813;&#57236;&#56131;&#56489;&#56102;&#56625;&#55580;&#56601;&#55549;&#57295;&#55468;&#56554;&#56098;&#56517;&#55800;&#56652;&#55817;&#57127;&#56278;&#56761;&#55388;&#57073;&#56010;&#56649;&#56140;&#56673;&#55849;&#56394;&#56089;&#57070;&#55553;&#57237;&#55617;&#56931;&#56009;&#56503;&#62542;&#56052;&#56633;&#55480;&#56841;&#55704;&#57268;&#56290;&#56601;&#55932;&#57160;&#55402;&#56450;&#56305;&#56873;&#56020;&#56712;&#55928;&#57204;&#55382;&#56845;&#55485;&#57044;&#55768;&#56996;&#56035;&#57148;&#55515;&#57227;&#56004;&#56339;&#8244;&#55376;&#57149;&#56009;&#57309;&#55804;&#57035;&#56128;&#57085;&#56203;&#56429;&#55694;&#57169;&#56319;&#57084;&#56205;&#56837;&#55518;&#56692;&#55577;&#56531;&#55382;&#56557;&#56209;&#56465;", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u0086\udb37\udd72\udbe4\ude7d\u7057\000\"\000\ucf5a\udaa4\udc3d\udac6\udfdd\"\ud992\udcc8\ub4d3\ud9f3\ude88\ud9c5\udf21\udb5a\udd4d\001\000\000\000\ud971\ude89\uda5a\udf82\ud8c4\ude36\000\000\000\000\000\000\000\000\ud94d\udd86\ud8cf\udfc3\udbcf\udc97\uda86\udc11\udac2\udc32\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0086\\uDB37\\uDD72\\uDBE4\\uDE7D\\u7057\\u0000\\\"\\u0000\\uCF5A\\uDAA4\\uDC3D\\uDAC6\\uDFDD\\\"\\uD992\\uDCC8\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDB5A\\uDD4D\\u0001\\u0000\\u0000\\u0000\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uD94D\\uDD86\\uD8CF\\uDFC3\\uDBCF\\uDC97\\uDA86\\uDC11\\uDAC2\\uDC32\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.unescapeHtml("\udae1\udcd8\udb79\udd8a\ud809\udd10&\ud806\ude95\uda99\udf5d\udb70\udd6d\udb54\udc1d\ud8da\udc81\udb40\udcf0\u6e3c\udad6\uddbf\ud926\udc3a\uda27\udcd6\udbc1\udd25\udaa9\udf08\uda59\udda0\udb91\ude5e\udb5b\udd24\udb13\udc20\ud83b\udf28\ud995\uddea\udb5d\udf92\udaef\udf47\ud933\udf8d\ud852\udc62\ud9af\udd0d\udb01\udc00\udaad\ude4c\ud80f\udc13\ud9f9\udfb2\udb9f\udd5c\udb62\udf13\ud8aa\udef1\ud95e\udc5f\ud9aa\udd3a\udaac\udd46\udba5\udeb0\udbff\udd91\uda44\udd8d\udb11\uddc0\ud907\udfa5\ud97b\udc2f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udae1\udcd8\udb79\udd8a\ud809\udd10&\ud806\ude95\uda99\udf5d\udb70\udd6d\udb54\udc1d\ud8da\udc81\udb40\udcf0\u6e3c\udad6\uddbf\ud926\udc3a\uda27\udcd6\udbc1\udd25\udaa9\udf08\uda59\udda0\udb91\ude5e\udb5b\udd24\udb13\udc20\ud83b\udf28\ud995\uddea\udb5d\udf92\udaef\udf47\ud933\udf8d\ud852\udc62\ud9af\udd0d\udb01\udc00\udaad\ude4c\ud80f\udc13\ud9f9\udfb2\udb9f\udd5c\udb62\udf13\ud8aa\udef1\ud95e\udc5f\ud9aa\udd3a\udaac\udd46\udba5\udeb0\udbff\udd91\uda44\udd8d\udb11\uddc0\ud907\udfa5\ud97b\udc2f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJavaScript("\u0086\udb37\udd72\udb67\udc12\udb5f\udfb8\udb6c\udd64\ud965\udc1b\002\uda3d\ude5b\ud9fa\udc48\udac6\udfdd\udbf9\udef1\ud99f\udd65\ub4d3\ud9f3\ude88\ud9c5\udf21\udb5a\udd4d\uda26\udf47\udb8f\udf32\ud8fe\udecf\002\ud971\ude89\uda5a\udf82\ud8c4\ude36\uda51\udc72\udb7f\udd3b\ud85c\udd92\udb1a\udfed\ud8b0\udfc1\ud8c8\udee3\uda2e\udc66\udb4d\ude35\ud82d\udc89\ud913\ude46\033\udacb\udec2\ud9ff\udc36\udaf9\udef7\u00bc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0086\\uDB37\\uDD72\\uDB67\\uDC12\\uDB5F\\uDFB8\\uDB6C\\uDD64\\uD965\\uDC1B\\u0002\\uDA3D\\uDE5B\\uD9FA\\uDC48\\uDAC6\\uDFDD\\uDBF9\\uDEF1\\uD99F\\uDD65\\uB4D3\\uD9F3\\uDE88\\uD9C5\\uDF21\\uDB5A\\uDD4D\\uDA26\\uDF47\\uDB8F\\uDF32\\uD8FE\\uDECF\\u0002\\uD971\\uDE89\\uDA5A\\uDF82\\uD8C4\\uDE36\\uDA51\\uDC72\\uDB7F\\uDD3B\\uD85C\\uDD92\\uDB1A\\uDFED\\uD8B0\\uDFC1\\uD8C8\\uDEE3\\uDA2E\\uDC66\\uDB4D\\uDE35\\uD82D\\uDC89\\uD913\\uDE46\\u001B\\uDACB\\uDEC2\\uD9FF\\uDC36\\uDAF9\\uDEF7\\u00BC", String.valueOf(r));
  }
}
