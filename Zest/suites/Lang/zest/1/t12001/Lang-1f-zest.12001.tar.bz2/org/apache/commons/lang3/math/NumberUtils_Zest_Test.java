package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("+5275851l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0xBA2dadf22dDAf");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("3275285673991599", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+527555.3456d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("527555.3456", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+8e+10");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("8.0E10", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("-0xC4ddL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+5275851824915.683909f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("5.2758519E12", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+5005800");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("5005800", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("+527.20L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("044135318257246713.2L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+38058.656185e5");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("3.80586573E9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0xdEd91D");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("14604573", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0X451E-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0701449862698.9867F");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("7.0144983E11", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0XE414adf22aE8C1fdl"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+71.865653D");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("71.865653", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#Bd18028d95C4D99L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#F103fBAF9");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("64697121529", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("341765039550006.");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("3.41765043E14", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+93118518166481290.3440667");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("9.3118516E16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("-0x76aA1D324aFBda3cA9eE-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("500.26L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#ee0F97EF");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("3993999343", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+0000D");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x12a8BEA791B5B148d");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("21512545850936202381", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+3514558903564980");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("3514558903564980", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0XBCa");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("3018", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("03507984263333621027l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0X0BfC6Ff2l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x0c1B7df22e5");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("832013542117", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x000d00002dD0f");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("893353385231", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x9EfBC463D020e2FF");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("11455966010119611135", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("077850L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x000");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("454782500481898l");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("454782500481898", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x1E35bc09911De9CF");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("2176852744178887119", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0xda9c97F42c3A0fC0013F");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("-1032364534766303275123007", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+0f");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("000.20000");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#EdD728F30BDd691aeAe5");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("1123169857131179906099941", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("766790348940L");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("766790348940", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-83955538549L");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("-83955538549", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+0e+10");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0E+10", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0x6daE3Ce5");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("-1840135397", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("1L");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("044L");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("36", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("01969222001014640"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0x00000F");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("-15", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0000000000.8d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("0.8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0e5");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0E+5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+5233143672000e+10");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("5.2331436E22", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+52000510000.93012f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("5.200051E10", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0X000000000a0");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("160", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("9263760393757744027");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("9263760393757744027", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0x0000000000000000FBL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("000.00000");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0000000000.0d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("9263760393757744975L");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("9263760393757744975", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("000000000000000000e5");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0E+5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("000.00000f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
}
