package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#Bb");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("187", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#3f14F8");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("4134136", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("-0xBbDdF21602B8L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("2792878106377.1956049e5");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("2.79287808E17", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-95588506592306062e5");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("-9.558851E21", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+864855.5");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("864855.5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#2A362ad527EaAaa0cC5D");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("199338602877513885600861", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#083f136D");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("138351469", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#3524FEbaFF");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("228253940479", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0xFB6CCbf3a6f");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("17277793548911", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("227057827739161.06e+10");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("2.2705783E24", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("-0x7bd87dE45Ae40666D36L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0x5D03eE-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#0");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("019323758823836367.26F");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("1.93237579E16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0XB70EaF");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("11996847", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+750445093.839D");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("7.50445093839E8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#Ec1d7BAFfa9Ba2e5");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("17013890963029598949", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#Eca5caEL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("375251612437374");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("375251612437374", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-343655.88f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("-343655.88", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#000E0A55d5c136b8bCAe+10"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0XBf6b1ece25379a0Bf2Fe+10"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("-6.69L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#3cADBdbc1fde5E-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0060.16F");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("60.16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0987602279050164d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("9.87602279050164E14", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0x1fEdd38615679c27f");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("-36811640919910105727", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-971756230590737857l");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("-971756230590737857", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0xC5Ad2CF9");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("-3316460793", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("1400.d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("1400.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x3EFcc0E0fBEDae8c");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("4538714597014482572", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-56822l");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("-56822", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0574592321604391l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-651L");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("-651", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0x7B1dFFEf");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("-2065563631", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0x000000160200");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("-1442304", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("5l");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("3.");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("3.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0.95f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.95", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("+43104279841242236L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test42() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("04277842L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test43() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0700808000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test44() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0000000000e5");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0E+5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0000000000000D");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0000000000000000f");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-95000006590306000e5");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("-9.500001E21", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-9558850680230606247L");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("-9558850680230606247", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+000000590200051");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("590200051", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#00000003b1dF");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("242143", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#000000004e5");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("1253", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("019320000020000000.00");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("1.93199998E16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0.0000000");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Exception {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#0000000000000002l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test55() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0.00d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0000000000000000.482d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("-0.482", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0.F");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#5DF3af7E04");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("403520323076", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Exception {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#0000000000000000005");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("5", String.valueOf(r));
  }
}
