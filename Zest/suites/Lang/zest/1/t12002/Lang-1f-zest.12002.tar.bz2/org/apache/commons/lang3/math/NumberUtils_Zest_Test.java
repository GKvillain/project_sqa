package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+61712278063839585f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("6.1712276E16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+10306999835649585f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("1.03070002E16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x65DEcEF4e5CDc13a");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("7340531993883296058", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("+011L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+6171247806383.4e+10");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("6.171248E22", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+60867278063839585.9786e5");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("6.086728E21", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#Ea0d039E-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("+31225656008.184l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+61712366166300793.7");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("6.1712366E16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("717404073794695140.4533l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+24615e5");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("2.4614999E9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+619593580599995.1D");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("6.195935805999951E14", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("-0xb2be1DeB67D621c229E-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+9182F");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("9182.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+61712278063834750.e+10");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("6.1712276E26", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("+61712278063859700.313531l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+61263");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("61263", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+2d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("2.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0Xdf");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("223", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+00000000000839585");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("839585", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+0000000000.85E-3");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("8.5E-4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#46f");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("1135", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("45253539.");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("4.525354E7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#8b0A7Cc6FbDda4CdDD");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("2564853123868176731613", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+00000000d");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0Xe7FF02d54b04813cL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-594822780638802828L");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("-594822780638802828", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+6170000000.85E-3");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("6170000.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-6111l");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("-6111", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x2CCF02e5");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("751764197", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#0bCE4Dbb7f2cad2A77F");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("3484478862571355678591", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x65bcae9d74CB6012f");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("117294820555918541103", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0.5047294");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.5047294", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x000EcEF4e5CDc13f");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("4168200896758079", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0xb5DB2BC48Cb90E-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x00");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0xa59EcEF4e5CDc1b5");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("11934203613801202101", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0x69BEcEF7e5CDc13a2A");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("-1950657327018283186730", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0x000000000000000");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0xE224aee5");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("3794054885", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0L");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("000.0f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0595322439215L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("742l");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("742", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#00000090a31F88d5D");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("9939392695645", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("+31225656000.184l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+0f");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+0.");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("00000000.");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("0e5");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0E+5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-9852000085042439800L");
    assertNotNull(r);
    assertEquals("java.math.BigInteger", r.getClass().getName());
    assertEquals("-9852000085042439800", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-5000000000000000E-3");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("-4.9999999E12", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("#000000000000000000");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("00.D");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("0.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("+740999770638395858d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("7.409997706383959E17", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("-0000000000000000E-3");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0.000", String.valueOf(r));
  }
}
