package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() {
    Number n = NumberUtils.createNumber("#Bb");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("187", n.toString());
  }
  @Test(timeout = 4000)
  public void test1() {
    Number n = NumberUtils.createNumber("#3f14F8");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("4134136", n.toString());
  }
  @Test(timeout = 4000)
  public void test2() {
    try { NumberUtils.createNumber("-0xBbDdF21602B8L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() {
    Number n = NumberUtils.createNumber("2792878106377.1956049e5");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("2.79287808E17", n.toString());
  }
  @Test(timeout = 4000)
  public void test4() {
    Number n = NumberUtils.createNumber("-95588506592306062e5");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("-9.558851E21", n.toString());
  }
  @Test(timeout = 4000)
  public void test5() {
    Number n = NumberUtils.createNumber("+864855.5");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("864855.5", n.toString());
  }
  @Test(timeout = 4000)
  public void test6() {
    Number n = NumberUtils.createNumber("#2A362ad527EaAaa0cC5D");
    assertEquals("java.math.BigInteger", n.getClass().getName());
    assertEquals("199338602877513885600861", n.toString());
  }
  @Test(timeout = 4000)
  public void test7() {
    Number n = NumberUtils.createNumber("#083f136D");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("138351469", n.toString());
  }
  @Test(timeout = 4000)
  public void test8() {
    Number n = NumberUtils.createNumber("#3524FEbaFF");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("228253940479", n.toString());
  }
  @Test(timeout = 4000)
  public void test9() {
    Number n = NumberUtils.createNumber("0xFB6CCbf3a6f");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("17277793548911", n.toString());
  }
  @Test(timeout = 4000)
  public void test10() {
    Number n = NumberUtils.createNumber("227057827739161.06e+10");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("2.2705783E24", n.toString());
  }
  @Test(timeout = 4000)
  public void test11() {
    try { NumberUtils.createNumber("-0x7bd87dE45Ae40666D36L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() {
    try { NumberUtils.createNumber("0x5D03eE-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() {
    Number n = NumberUtils.createNumber("#0");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("0", n.toString());
  }
  @Test(timeout = 4000)
  public void test14() {
    Number n = NumberUtils.createNumber("019323758823836367.26F");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("1.93237579E16", n.toString());
  }
  @Test(timeout = 4000)
  public void test15() {
    Number n = NumberUtils.createNumber("0XB70EaF");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("11996847", n.toString());
  }
  @Test(timeout = 4000)
  public void test16() {
    Number n = NumberUtils.createNumber("+750445093.839D");
    assertEquals("java.lang.Double", n.getClass().getName());
    assertEquals("7.50445093839E8", n.toString());
  }
  @Test(timeout = 4000)
  public void test17() {
    Number n = NumberUtils.createNumber("0");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("0", n.toString());
  }
  @Test(timeout = 4000)
  public void test18() {
    Number n = NumberUtils.createNumber("#Ec1d7BAFfa9Ba2e5");
    assertEquals("java.math.BigInteger", n.getClass().getName());
    assertEquals("17013890963029598949", n.toString());
  }
  @Test(timeout = 4000)
  public void test19() {
    try { NumberUtils.createNumber("#Eca5caEL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() {
    Number n = NumberUtils.createNumber("375251612437374");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("375251612437374", n.toString());
  }
  @Test(timeout = 4000)
  public void test21() {
    Number n = NumberUtils.createNumber("-343655.88f");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("-343655.88", n.toString());
  }
  @Test(timeout = 4000)
  public void test22() {
    try { NumberUtils.createNumber("#000E0A55d5c136b8bCAe+10"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() {
    try { NumberUtils.createNumber("0XBf6b1ece25379a0Bf2Fe+10"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() {
    try { NumberUtils.createNumber("-6.69L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() {
    try { NumberUtils.createNumber("#3cADBdbc1fde5E-3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() {
    Number n = NumberUtils.createNumber("0060.16F");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("60.16", n.toString());
  }
  @Test(timeout = 4000)
  public void test27() {
    Number n = NumberUtils.createNumber("0987602279050164d");
    assertEquals("java.lang.Double", n.getClass().getName());
    assertEquals("9.87602279050164E14", n.toString());
  }
  @Test(timeout = 4000)
  public void test28() {
    Number n = NumberUtils.createNumber("-0x1fEdd38615679c27f");
    assertEquals("java.math.BigInteger", n.getClass().getName());
    assertEquals("-36811640919910105727", n.toString());
  }
  @Test(timeout = 4000)
  public void test29() {
    Number n = NumberUtils.createNumber("-971756230590737857l");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("-971756230590737857", n.toString());
  }
  @Test(timeout = 4000)
  public void test30() {
    Number n = NumberUtils.createNumber("-0xC5Ad2CF9");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("-3316460793", n.toString());
  }
  @Test(timeout = 4000)
  public void test31() {
    Number n = NumberUtils.createNumber("1400.d");
    assertEquals("java.lang.Double", n.getClass().getName());
    assertEquals("1400.0", n.toString());
  }
  @Test(timeout = 4000)
  public void test32() {
    Number n = NumberUtils.createNumber("0x3EFcc0E0fBEDae8c");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("4538714597014482572", n.toString());
  }
  @Test(timeout = 4000)
  public void test33() {
    Number n = NumberUtils.createNumber("-56822l");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("-56822", n.toString());
  }
  @Test(timeout = 4000)
  public void test34() {
    try { NumberUtils.createNumber("0574592321604391l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() {
    Number n = NumberUtils.createNumber("-651L");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("-651", n.toString());
  }
  @Test(timeout = 4000)
  public void test36() {
    Number n = NumberUtils.createNumber("-0x7B1dFFEf");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("-2065563631", n.toString());
  }
  @Test(timeout = 4000)
  public void test37() {
    Number n = NumberUtils.createNumber("-0x000000160200");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("-1442304", n.toString());
  }
  @Test(timeout = 4000)
  public void test38() {
    Number n = NumberUtils.createNumber("5l");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("5", n.toString());
  }
  @Test(timeout = 4000)
  public void test39() {
    Number n = NumberUtils.createNumber("3.");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("3.0", n.toString());
  }
  @Test(timeout = 4000)
  public void test40() {
    Number n = NumberUtils.createNumber("0.95f");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("0.95", n.toString());
  }
  @Test(timeout = 4000)
  public void test41() {
    try { NumberUtils.createNumber("+43104279841242236L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test42() {
    try { NumberUtils.createNumber("04277842L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test43() {
    try { NumberUtils.createNumber("0700808000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test44() {
    Number n = NumberUtils.createNumber("0000000000e5");
    assertEquals("java.math.BigDecimal", n.getClass().getName());
    assertEquals("0E+5", n.toString());
  }
  @Test(timeout = 4000)
  public void test45() {
    Number n = NumberUtils.createNumber("0000000000000D");
    assertEquals("java.math.BigDecimal", n.getClass().getName());
    assertEquals("0", n.toString());
  }
  @Test(timeout = 4000)
  public void test46() {
    Number n = NumberUtils.createNumber("-0000000000000000f");
    assertEquals("java.math.BigDecimal", n.getClass().getName());
    assertEquals("0", n.toString());
  }
  @Test(timeout = 4000)
  public void test47() {
    Number n = NumberUtils.createNumber("-95000006590306000e5");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("-9.500001E21", n.toString());
  }
  @Test(timeout = 4000)
  public void test48() {
    Number n = NumberUtils.createNumber("-9558850680230606247L");
    assertEquals("java.math.BigInteger", n.getClass().getName());
    assertEquals("-9558850680230606247", n.toString());
  }
  @Test(timeout = 4000)
  public void test49() {
    Number n = NumberUtils.createNumber("+000000590200051");
    assertEquals("java.math.BigInteger", n.getClass().getName());
    assertEquals("590200051", n.toString());
  }
  @Test(timeout = 4000)
  public void test50() {
    Number n = NumberUtils.createNumber("#00000003b1dF");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("242143", n.toString());
  }
  @Test(timeout = 4000)
  public void test51() {
    Number n = NumberUtils.createNumber("#000000004e5");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("1253", n.toString());
  }
  @Test(timeout = 4000)
  public void test52() {
    Number n = NumberUtils.createNumber("019320000020000000.00");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("1.93199998E16", n.toString());
  }
  @Test(timeout = 4000)
  public void test53() {
    Number n = NumberUtils.createNumber("0.0000000");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("0.0", n.toString());
  }
  @Test(timeout = 4000)
  public void test54() {
    try { NumberUtils.createNumber("#0000000000000002l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test55() {
    Number n = NumberUtils.createNumber("0.00d");
    assertEquals("java.lang.Double", n.getClass().getName());
    assertEquals("0.0", n.toString());
  }
  @Test(timeout = 4000)
  public void test56() {
    Number n = NumberUtils.createNumber("-0000000000000000.482d");
    assertEquals("java.lang.Double", n.getClass().getName());
    assertEquals("-0.482", n.toString());
  }
  @Test(timeout = 4000)
  public void test57() {
    Number n = NumberUtils.createNumber("0.F");
    assertEquals("java.lang.Float", n.getClass().getName());
    assertEquals("0.0", n.toString());
  }
  @Test(timeout = 4000)
  public void test58() {
    Number n = NumberUtils.createNumber("#5DF3af7E04");
    assertEquals("java.lang.Long", n.getClass().getName());
    assertEquals("403520323076", n.toString());
  }
  @Test(timeout = 4000)
  public void test59() {
    Number n = NumberUtils.createNumber("#0000000000000000005");
    assertEquals("java.lang.Integer", n.getClass().getName());
    assertEquals("5", n.toString());
  }
}
