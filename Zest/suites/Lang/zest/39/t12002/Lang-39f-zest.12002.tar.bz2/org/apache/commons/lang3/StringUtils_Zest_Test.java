package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ud9cf\ude22\ud925\udfcf\uda1d\udc5b\ud9c2\udf5b\uda86\udc52\u984d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ud8cf\udfdd\u79c8\ud82b\udd63\ud81f\udf81\udb61\ude06\u98d7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\uda25\udc12\udbd4\udcaa\uda03\udc1e\udb57\udc3d\udad4\udffe\ud96b\udec2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda25\udc12\udbd4\udcaa\uda03\udc1e\udb57\udc3d\udad4\udffe\ud96b\udec2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\ud9cf\ude4d\udb7f\ude1c\udbbe\uddd2\uda67\udcb1\udb38\udc0b\udbdd\udc6d\ud91e\udcd3\uda68\udd91");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\ud9cf\ude22\ud925\udfcf");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9cf\ude22\ud925\udfcf", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\uda7d\udcd9\ud8c6\udea7\ufc2a\ud814\udcc1\ud97e\udf2a\ud982\udf2f\ud8e4\udeef\ud86d\ude74\uda94\udc45\udb29\udcc3\ud86b\udfb7\ud924\udf7b\ud8d1\udfac\udbfb\ude7b\uda15\udcd8\ud977\ude49\ud983\udc52\udb9e\udf65\u6921\ud8c0\udf61\uda41\udc0f\ud81e\udd14\ud9e5\udf09\udb59\udfe5\udb81\ude47\ud9d1\udf22");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udbe8\udd78\udb4e\udf5c\ud851\udc89\u94d3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbe8\udd78\udb4e\udf5c\ud851\udc89\u94d3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\ud9fd\udc22\uda7d\uddfb\ud9fd\udfa4\uda02\udfd5\ud9fd\udf8e\ud976\udd5b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9fd\udc22\uda7d\uddfb\ud9fd\udfa4\uda02\udfd5\ud9fd\udf8e\ud976\udd5b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ud9cf\udeb2\udb12\udf85\uda1d\udc5b\ud9c2\udf5b\uda86\udc52");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ud9cf\udec4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ud968\udf9f\udb87\udc4b\udbeb\ude98\ud8aa\udc83\udb76\udf0c\udb83\udda7\uda28\ude4b\udb0f\udc9f\udb12\uddcc\ud8ec\udf7e\udbc6\uddb1\uda77\udf88\ud9a2\udfc2\udaa0\udc85\ud83b\udc5a\ud8d9\udd2c\ud9ab\udd3b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\ud9cf\ude22\ud861\udccb\uda1d\udc5b\ud93a\ude97\ud92d\udd59\ud84a\udc8d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9cf\ude22\ud861\udccb\uda1d\udc5b\ud93a\ude97\ud92d\udd59\ud84a", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ud9e7\udc7f\ud925\udfcf\ud8f3\udc66\ud9c2\udf5b\uda86\udc52\ud898\udc45\udbfa\ude5c\ud845\udf45\ud8eb\udda5\u78eb\uda23\udcc3\ud88f\udd38\ud8f3\udf99\ud8af\udee5\ud91c\udcd9\uda74\ude89\ud8a7\udc50\u80b5\ud84a\udc4f\ud94b\udf55\ud9b4\udf3f\uda11\udea8\ud92a\udd65\u61af\ud8c0\uddfd\ud9de\udfcc\u8b94\ud928\udf37\ud8b6\udf7c\udb66\udcd8\ud915\udfad\ud897\uddf3\ud86b\udd3c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud897\udfa2\udb17\udcdd\uda1d\udc12\ud95b\udc90\uda86\udc52\udb97\udc7f\udb51\udf64\ud92b\uddf2\ud88a\udf2c\ud9c2\udcc5\ud842\udf93\ud844\udd23\udb7f\ude42\ud92a\udc50\ud90a\udc18\udab9\udc9e\ud85c\udde1\uda2f\udced\uda8d\udfd4\udb68\udf3c\ud9f7\udc76\ud989\udc48");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud897\udfa2\udb17\udcdd\uda1d\udc12\ud95b\udc90\uda86\udc52\udb97\udc7f\udb51\udf64\ud92b\uddf2\ud88a\udf2c\ud9c2\udcc5\ud842\udf93\ud844\udd23\udb7f\ude42\ud92a\udc50\ud90a\udc18\udab9\udc9e\ud85c\udde1\uda2f\udced\uda8d\udfd4\udb68\udf3c\ud9f7\udc76\ud989\udc48", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u973d\ud825\udfa2\ud970\udcd6\udb70\udfeb\u5e5d\ud8be\udd6e\ud8a2\udefc\ud8d9\udcd6\ud892\udea8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u973d\ud825\udfa2\ud970\udcd6\udb70\udfeb\u5e5d\ud8be\udd6e\ud8a2\udefc\ud8d9\udcd6\ud892\udea8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\ud837\udcd6\ud888\uddee\ud904\udd26\ud987\udd88\ud9e0\udccf\ud9f6\ude22\ud970\udfa1\ud9c1\udfde\ud81f\udd39\ud93b\ude15\uda90\udf48\ud953\udc25\uda65\udf1c\udb89\udca3\udb23\udd11\udbd3\udc7e\udb56\udd39\ud908\ude9e\uda98\udefb\ud9c3\udf6e\uda80\udc76\ud9d8\udff7\ud937\udf19\uda9d\udebc\ud97f\udc38\ud8db\udc78\uda4d\udea5\ub8f5\ud988\udd75\ud8b6\udde3\udadf\udc00\udbf0\udfcb\ud968\udd70");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud837\udcd6\ud888\uddee\ud904\udd26\ud987\udd88\ud9e0\udccf\ud9f6\ude22\ud970\udfa1\ud9c1\udfde\ud81f\udd39\ud93b\ude15\uda90\udf48\ud953\udc25\uda65\udf1c\udb89\udca3\udb23\udd11\udbd3\udc7e\udb56\udd39\ud908\ude9e\uda98\udefb\ud9c3\udf6e\uda80\udc76\ud9d8\udff7\ud937\udf19\uda9d\udebc\ud97f\udc38\ud8db\udc78\uda4d\udea5\ub8f5\ud988\udd75\ud8b6\udde3\udadf\udc00\udbf0\udfcb\ud968\udd70", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud93f\udd33\udb93\udf28\uda1d\udcd7\ud9c2\udf5e\ud93c\udcbc\ud835\ude5c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud93f\udd33\udb93\udf28\uda1d\udcd7\ud9c2\udf5e\ud93c\udcbc\ud835\ude5c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda03\udeae");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda03\udeae", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u700a\ud90d\ude62");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u9614\uda81\udfd1\ueb10\ud88d\ude78");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\u6780");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u6780", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud666");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud666", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u3e23\uda88\udc40");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\ucc8a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u5c50\uc70e\ud933\udd2e\udbf0\uddaf\udb6e\udc00\ud96a\udcd6\u657d\ud81b\ude84\ud804\udd87\udb73\udedb\ud9fd\udcd6\udb05\ude53");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud915\udde5\ud965\udfe2\uda47\udc9f\uda18\udd4e\ud88c\udf67\uf178\udad5\udd04\udb7b\udc02\ud959\udf63\ud83b\udd7b\ud8ba\udde4\udb45\udf55\udbfc\uddca\udb06\uddc9\ud9fd\udfe2\udac2\udcaf\ud8af\udf30\ud893\udf81\uda43\udd25\udbd8\udeb1\udab2\udcda\uda76\udf07\ud801\udf75\ud912\udea8\udab8\udfaf\udaf1\ude62\ud9d3\udf89\u4c4c\ud964\udc4c\ud901\udcc0\udb55\udddb\udbb2\uded9\udb1e\ude2c\udb00\udc25\udb58\udd94\udbaf\udeef\ud815\udcc1\udbb8\udce8\ud9d2\udd45\ud92b\udd57\ud8a8\ude14\udb0f\uddd5\udb3f\udc21\ud9aa\udc43\ud8f1\udf27\udae9\udf3c\ud81f\udf08\uda7b\udff8\udad1\udee1\ud8b3\udd3f\udae8\udff8\u3a5f\udb6e\udcbf\u5215\ud81a\udc20\udb9c\udfd9\uda6c\udf7b\udbb2\udda4\ud9d4\udeae\ud95e\ude15\udb28\ude4e\udb27\udfeb\ud8be\udfac\ud936\udef5\udbc1\ude1e\ud852\udf96\uda3e\udcdb\uda4a\udf32\uda59\udd5f\udb1d\udc37\uda34\udc98\udbed\udd21\u7a67\udb57\udfbd");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud915\udde5\ud965\udfe2\uda47\udc9f\uda18\udd4e\ud88c\udf67\uf178\udad5\udd04\udb7b\udc02\ud959\udf63\ud83b\udd7b\ud8ba\udde4\udb45\udf55\udbfc\uddca\udb06\uddc9\ud9fd\udfe2\udac2\udcaf\ud8af\udf30\ud893\udf81\uda43\udd25\udbd8\udeb1\udab2\udcda\uda76\udf07\ud801\udf75\ud912\udea8\udab8\udfaf\udaf1\ude62\ud9d3\udf89\u4c4c\ud964\udc4c\ud901\udcc0\udb55\udddb\udbb2\uded9\udb1e\ude2c\udb00\udc25\udb58\udd94\udbaf\udeef\ud815\udcc1\udbb8\udce8\ud9d2\udd45\ud92b\udd57\ud8a8\ude14\udb0f\uddd5\udb3f\udc21\ud9aa\udc43\ud8f1\udf27\udae9\udf3c\ud81f\udf08\uda7b\udff8\udad1\udee1\ud8b3\udd3f\udae8\udff8\u3a5f\udb6e\udcbf\u5215\ud81a\udc20\udb9c\udfd9\uda6c\udf7b\udbb2\udda4\ud9d4\udeae\ud95e\ude15\udb28\ude4e\udb27\udfeb\ud8be\udfac\ud936\udef5\udbc1\ude1e\ud852\udf96\uda3e\udcdb\uda4a\udf32\uda59\udd5f\udb1d\udc37\uda34\udc98\udbed\udd21\u7a67\udb57\udfbd", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udbe8\udd78\udb4e\udf5c\uda38\udcd8\ud876\udc0f\ud83e\udcfd\ud8ee\ude45\uda9d\udd72\ud876\udf86\ud958\udc64\ud935\ude37\udbbc\udf28\ud9aa\udc85\ud92d\udce3\udacf\udeb9\udba0\udc14\udb1c\udecb\ud826\udd02\udb12\udf60\udb8b\ude67\ud8e1\udc8a\uda64\udd0c\ud86b\udd41\ud9e4\ude4f\udb17\udd8d\ud9bc\udcb4\udbdf\ude79\uda45\ude60\uda38\udd07\uda88\udfb2\u67f1\uda30\ude79\udac5\ude8b\udae0\udd82\ud8f1\udf6f\udbf5\ude21\udadf\udf7c\uda42\udd70\udbc0\udc46\udafd\udd08\ud8b1\udf5d\uda61\uddcc\ud8bc\udf35");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbe8\udd78\udb4e\udf5c\uda38\udcd8\ud876\udc0f\ud83e\udcfd\ud8ee\ude45\uda9d\udd72\ud876\udf86\ud958\udc64\ud935\ude37\udbbc\udf28\ud9aa\udc85\ud92d\udce3\udacf\udeb9\udba0\udc14\udb1c\udecb\ud826\udd02\udb12\udf60\udb8b\ude67\ud8e1\udc8a\uda64\udd0c\ud86b\udd41\ud9e4\ude4f\udb17\udd8d\ud9bc\udcb4\udbdf\ude79\uda45\ude60\uda38\udd07\uda88\udfb2\u67f1\uda30\ude79\udac5\ude8b\udae0\udd82\ud8f1\udf6f\udbf5\ude21\udadf\udf7c\uda42\udd70\udbc0\udc46\udafd\udd08\ud8b1\udf5d\uda61\uddcc\ud8bc\udf35", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u5e00\000\000\udbf1\udf57");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u538e\ub508\ud955\udd1e\uda02\udfbb\uda65\ude42\ud930\ude7b\udac1\ude8e\udbc7\udd21\ud8ac\udd53\uda00\udde5\ud9f1\uded5\ud891\udf87\ud827\udf6c\ud94a\udd64\u70fe\udbf3\udf50\udbb4\udfd6\ucbe7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u4353");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u9614\u39cc\ud873\udfe2\ud858\udf29");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u1e80");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u3e23\u90ae");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u1e97\u852b\ubf76\udbc6\udd3d\ud988\udef5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u5c50\uc70e\u405d\udbea\udfaf\udb6e\udc00\ud95b\udd16\u6584\ud81b\ude84\ud804\udd87\udb73\udedb\ud9fd\udcd6\udb05\ude53");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u1e80\ud860\udc2c\ud96b\udc71\ud8f5\udff1\uda41\udd70");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u1e97\u84bb\ubf76\udbc6\udd3d\ud988\udef5\ud89b\udcdb\uda7f\ude2e\udaa7\udd5a\uda3e\udf71\uda93\udc28\ud977\udd0c\ud924\udeb6\ud91e\udf96\uda08\udf85\udaa1\udfd2\uca7e\ud89c\udf6c\u300a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u1e97\u852b\ubf76\ud877\udf96\ud988\ude91\ud98c\ude85\udba5\udc17\ud9ce\udc7e\ud842\udc5d\udb11\udca5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u1e97\u852b\ubf76\udbc6\udd3d\ud988\udef5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb1b\ude2b\udadb\udd89\ud8c7\ude46\u2e75\udab2\udfbf\ud910\udf4f\udaf3\ude4a\ud98d\udc7a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u5c50\uc70e\uc502\u9ea9\ud829\ude1e\udb09\ude13\u657d\ud81b\ude84\ud804\udd87\udb73\udedb\ud9fd\udcd6\ud954\udcbb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\uab54\u852b\ubf76\u6aa8\ue64e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb13\udf80\udbfe\udfe9\uda66\udc44\012\udb7f\udc7e\ud9f3\udc5a\ud96d\udea5\uda3b\udec9\uda9e\udd3a\uda59\udc97\udac6\udf6f\ud8fc\udda8\ud8c5\udc34\ud801\ude3c\u01b8\uda76\udca0\ud95c\udf7e\udbd1\uddca\ud9c6\ude08\ud86d\udc32\ud9ec\udc70\udb66\ude63\ud8c7\udcd6\udbe8\udc2e\ud8ab\udd09\uda63\udf13\uda7a\udfb7\ud8cd\udfd4\uda25\udfc8\u7592\udbbe\ude4f\ud847\udf49\ud9f6\udec6\ud8af\uddf7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb13\udf80\udbfe\udfe9\uda66\udc44\udb7f\udc7e\ud9f3\udc5a\ud96d\udea5\uda3b\udec9\uda9e\udd3a\uda59\udc97\udac6\udf6f\ud8fc\udda8\ud8c5\udc34\ud801\ude3c\u01b8\uda76\udca0\ud95c\udf7e\udbd1\uddca\ud9c6\ude08\ud86d\udc32\ud9ec\udc70\udb66\ude63\ud8c7\udcd6\udbe8\udc2e\ud8ab\udd09\uda63\udf13\uda7a\udfb7\ud8cd\udfd4\uda25\udfc8\u7592\udbbe\ude4f\ud847\udf49\ud9f6\udec6\ud8af\uddf7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u6578\u744f\u6ed0\u6ab9\ud988\udef5\ud8a3\udca4\udbfb\udc71\udbad\uddf3\udb97\udf69\ud9ce\ude41");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb13\udf80\udbfe\udfe9\uda66\udc44\012\udb7f\udc7e\014\ud96d\udddf\uda3b\udec9\uda9e\udd3a\uda59\udc97\udac6\udf6f\u68f7\ud8c5\udc34\ud801\ude3c\u01b8\uda76\udca0\ud95c\udf7e\udbd1\uddca\ud9c6\ude08\ud86d\udc32\u80eb\udb66\uddb9\ud8c7\udcd6\udbaa\ude2f\000\000\000\000\ud8b5\udd99\u7592\udbbe\ude4fT\000\ud8af\udd76");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb13\udf80\udbfe\udfe9\uda66\udc44\udb7f\udc7e\ud96d\udddf\uda3b\udec9\uda9e\udd3a\uda59\udc97\udac6\udf6f\u68f7\ud8c5\udc34\ud801\ude3c\u01b8\uda76\udca0\ud95c\udf7e\udbd1\uddca\ud9c6\ude08\ud86d\udc32\u80eb\udb66\uddb9\ud8c7\udcd6\udbaa\ude2f\000\000\000\000\ud8b5\udd99\u7592\udbbe\ude4fT\000\ud8af\udd76", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\udbcb\udfb8\ud8c2\udd35\uda3a\udfde\012");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbcb\udfb8\ud8c2\udd35\uda3a\udfde", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udbcb\udfb8\ud8c2\udd35\uda3a\udfde\012");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbcb\udfb8\ud8c2\udd35\uda3a\udfde", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u1e80\u13e6\udaac\udff2\ud854\udef9\udbd5\udfd0\ud962\udf6e\ud864\ude8e\ud994\udd00\ud8f5\udfe4\uda3b\ude0e\ud9be\udc25\uda12\udea9\ud92c\udc08\ud943\ude5a\ud89b\udca2\udb4a\ude26\udbc6\ude66");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u1e97\u1d8e\ud1fa\uda1d\udfde\ud988\udef5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u1e97\u852b\ubf76\ub600\ud988\udef5\uda97\udc0b\ud85c\udcf2\uda09\udef5\uda97\ude05\ud81b\udd2f\uda84\udfbf\udb49\udfdb\ud8fe\ude45\uda25\udc8b\ud94d\uddfa\ud8e7\udfe8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\ua6c0\ud80a\udf12\udbe0\udec6\uda57\udf91\udb6e\udc00\ud8d9\udd0d\ud8c6\ude90\ud848\udf28\uda4d\uddc8\ud9f0\udc70\udbda\udfc8\udafc\udd5f\udb3c\udc16\ud84d\udfba\ud869\udd14\udada\uddb4\uda1c\udd88\udb96\udde8\ud88b\ude3d\ud986\udc27\udbcf\udfa3\udb5a\uddff\ud955\udd71\ud8f8\udd1d\uda3d\ude71\udafb\uddeb\udb11\uddec\u0968\ud892\ude58\udafc\udea9\ud884\uddf2\udad8\udf32\ud889\uddde\ud857\udc3f\ufd41\uf9ec\ud88e\udf47\ud890\uddc0\uda36\udc75\udb16\udef5\ud882\ude1c\ud9bf\ude46\udb07\uddae\ud808\udedf\ud848\udfa1\udb4b\udec6\udbaa\udf21\ud931\ude10\uda48\udfe8\udac6\udfdc\ud829\udd4c\ud8c3\udc09\ud95e\ude9b\udae7\uddb8\ud87c\udc42\udb0b\ude25\ud95a\udf9b\udab3\ude09\uda17\udc3b\ud953\uddb1\ud8ab\udfde\uda6d\ude12\u828b\ud83c\udcc3\ud907\udf64\udab8\udc30\ud91d\udf38\ud835\ude5a\ud9d7\udfe8\ud933\udfab\ud930\udf96\uda5c\udfa9\udb68\udcf5\uda23\udc53\udab6\udf34\udac5\udee5\uda5f\udd90\ud9fc\ude95\uda8b\udfef\udb43\udd61\ud83a\udcf1\ueede\udaa3\ude17\udb2d\udd36\udaf2\udcfe\udaf8\udda4\udb96\udfab\u0535\ud854\uddbb\udbc3\udc56\ud834\udf6a\uda54\udf38\ud8d5\udc4c\udb89\ude55\ud815\udf40\udabe\udf41\udaf8\udc61\udb40\udd70\uda88\ude94\ud9a9\udd15\ud9e5\udfea\ud96e\udd56\udb75\udf77\udb3e\udd05\udb52\udd7b\ud8a6\uddba\udb9f\udd3d\ud97e\udc60\udbfb\uddec\udb5e\udc0c\uda28\udefd\ud848\udc96\ud9f4\udd67\udb41\udd22\ud86c\udf13\udb25\udd2c\ud975\udd6c\ud955\uddbc\ud84d\udd7d\ud87d\uddc4\uda7d\udcc5\ud880\ude13\ud800\udc15\ub866\udb13\udfc6\uda73\ude5e\ud99a\udd49\ud823\udea1\udba9\udfff\udb3a\udc5e\ud904\udc45\ud91d\uddaa\ud88d\ude55\uda44\ude57\ud8f0\udcec\udb47\udcdc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ua6c0\ud80a\udf12\udbe0\udec6\uda57\udf91\udb6e\udc00\ud8d9\udd0d\ud8c6\ude90\ud848\udf28\uda4d\uddc8\ud9f0\udc70\udbda\udfc8\udafc\udd5f\udb3c\udc16\ud84d\udfba\ud869\udd14\udada\uddb4\uda1c\udd88\udb96\udde8\ud88b\ude3d\ud986\udc27\udbcf\udfa3\udb5a\uddff\ud955\udd71\ud8f8\udd1d\uda3d\ude71\udafb\uddeb\udb11\uddec\u0968\ud892\ude58\udafc\udea9\ud884\uddf2\udad8\udf32\ud889\uddde\ud857\udc3f\ufd41\uf9ec\ud88e\udf47\ud890\uddc0\uda36\udc75\udb16\udef5\ud882\ude1c\ud9bf\ude46\udb07\uddae\ud808\udedf\ud848\udfa1\udb4b\udec6\udbaa\udf21\ud931\ude10\uda48\udfe8\udac6\udfdc\ud829\udd4c\ud8c3\udc09\ud95e\ude9b\udae7\uddb8\ud87c\udc42\udb0b\ude25\ud95a\udf9b\udab3\ude09\uda17\udc3b\ud953\uddb1\ud8ab\udfde\uda6d\ude12\u828b\ud83c\udcc3\ud907\udf64\udab8\udc30\ud91d\udf38\ud835\ude5a\ud9d7\udfe8\ud933\udfab\ud930\udf96\uda5c\udfa9\udb68\udcf5\uda23\udc53\udab6\udf34\udac5\udee5\uda5f\udd90\ud9fc\ude95\uda8b\udfef\udb43\udd61\ud83a\udcf1\ueede\udaa3\ude17\udb2d\udd36\udaf2\udcfe\udaf8\udda4\udb96\udfab\u0535\ud854\uddbb\udbc3\udc56\ud834\udf6a\uda54\udf38\ud8d5\udc4c\udb89\ude55\ud815\udf40\udabe\udf41\udaf8\udc61\udb40\udd70\uda88\ude94\ud9a9\udd15\ud9e5\udfea\ud96e\udd56\udb75\udf77\udb3e\udd05\udb52\udd7b\ud8a6\uddba\udb9f\udd3d\ud97e\udc60\udbfb\uddec\udb5e\udc0c\uda28\udefd\ud848\udc96\ud9f4\udd67\udb41\udd22\ud86c\udf13\udb25\udd2c\ud975\udd6c\ud955\uddbc\ud84d\udd7d\ud87d\uddc4\uda7d\udcc5\ud880\ude13\ud800\udc15\ub866\udb13\udfc6\uda73\ude5e\ud99a\udd49\ud823\udea1\udba9\udfff\udb3a\udc5e\ud904\udc45\ud91d\uddaa\ud88d\ude55\uda44\ude57\ud8f0\udcec\udb47", String.valueOf(r));
  }
}
