package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udaa2\uddcb\ud8bd\udd01\uadb4\udb80\udd6e\ud94f\ude0d\ud928\udc5e\ud9a9\uddef\ud8c5\uddad\udbaa\ude2a\ud823\udd09\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\ud89e\ude30\ud93e\ude7c\uadb4\ud83a\udc27\ud94f\uddc1\ud928\udc5e\ud9a9\uddef\ud8c5\uddad\udbe2\udf4e\udbc2\uddc0\ud801\udc21\ud8ba\udce3\udbb8\ude23\ud9e5\udc70\ud93a\udc8e\ud933\udcf8\udac8\udfb6\ud8c9\udd39\udb5c\udc3d\ud9dc\udc95");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud89e\ude30\ud93e\ude7c\uadb4\ud83a\udc27\ud94f\uddc1\ud928\udc5e\ud9a9\uddef\ud8c5\uddad\udbe2\udf4e\udbc2\uddc0\ud801\udc21\ud8ba\udce3\udbb8\ude23\ud9e5\udc70\ud93a\udc8e\ud933\udcf8\udac8\udfb6\ud8c9\udd39\udb5c\udc3d\ud9dc\udc95", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udaa2\uddcb\ud8bd\udd01\uadb4\udb80\udd6e\ud9ba\udee2\ud913\udcf8\ud9a9\uddef\ud8c5\uddad\udbaa\ude2a\ud823\udd09\ud946\udf86\ud8a9\ude15");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaa2\uddcb\ud8bd\udd01\uadb4\udb80\udd6e\ud9ba\udee2\ud913\udcf8\ud9a9\uddef\ud8c5\uddad\udbaa\ude2a\ud823\udd09\ud946\udf86\ud8a9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ud883\uded8\ud980\udef0\uda2a\udfc6\uda46\uddc7\ud94f\uddd5\udb99\udeb7\ud8b1\udcbd\udabd\udca0\udbac\udfa1\udb92\udd22\uda41\udcee\ud99c\uded2\udaa9\udcf3\ud84b\uddfb\ud944\ude4d\uda89\udf97\ud9e3\uddd4\udb16\ude9d\u451f\udb33\udf40\ud878\udd35\udad8\ude2d\ud829\udf92\ud9d2\udded");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\udbe5\ude3b\udbf3\udc6a\ud8ba\ude59\ud8cd\udc4f\ud85e\udd19");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbe5\ude3b\udbf3\udc6a\ud8ba\ude59\ud8cd\udc4f\ud85e\udd19", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\uda8d\udc92\ud93b\udf0e\uda5a\udfb7\ud94b\udf5d\udab8\udd46\ud928\udc5e\ud95c\udd2c\ud821\udee6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda8d\udc92\ud93b\udf0e\uda5a\udfb7\ud94b\udf5d\udab8\udd46\ud928\udc5e\ud95c\udd2c\ud821\udee6", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\udaa2\uddcb\ud8bd\udd01\uadb4\udb49\ude3c\ud982\udc63\u056c\ud9a9\ude95\ud8c5\uddad\udba1\udd2a\ud823\udd09\ud90f\udec2\ud844\udff6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udaa2\uddcb\ud8bd\udd01\ud986\udda1\ud9a5\ude2e\udb3f\udc74\ud933\udf5f\udbd6\udde2\ud8bb\udee4\udbaa\ude2a\ud823\ude09\uda1f\uddd2\ud8ea\ude11");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaa2\uddcb\ud8bd\udd01\ud986\udda1\ud9a5\ude2e\udb3f\udc74\ud933\udf5f\udbd6\udde2\ud8bb\udee4\udbaa\ude2a\ud823\ude09\uda1f\uddd2\ud8ea\ude11", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\udaa2\uddcb\udbb5\udf0f\udb23\udca4\ud9b6\udf42\ud94f\ude0d\udacc\udf93\ud9a9\ude83\ud8c5\uddad\udbaa\ude2a\udb69\udcf5\ud886\udf15\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaa2\uddcb\udbb5\udf0f\udb23\udca4\ud9b6\udf42\ud94f\ude0d\udacc\udf93\ud9a9\ude83\ud8c5\uddad\udbaa\ude2a\udb69\udcf5\ud886\udf15\ud9c0\ude10", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\udb96\udc20\ud96c\udc59\uad55\udb80\udd6e\ud94f\ude0d\ud928\udc5e\udb7c\udd10\ud8c5\udd54\udbaa\ude2a\ud9d8\udec6\ud86d\udc8a\udb05\udd41");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udbfc\udcb8\uda91\udc3c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\ud976\uddc7\udb5c\uddeb\ud826\udd5f\udb80\udd6e\uda55\udde1\ud928\udc5e\ud9f9\udc24\udbcc\udd90\ud824\udca5\ud821\udfc5\uda9d\uded2\udac9\udf7f\udb3d\udf3b\ud8a4\udf73\ud8b5\udc8c\ud927\udc16\uda8a\udd32\uda58\udceb\ud8e7\udef4\ud828\udd04\udb81\ude00\udade\udfd3\udb7d\ude28\ud9ba\udc8e\udb80\udeb1\ud995\uddb0\ud91b\udf11\ud856\udee4\ud852\udc9b\ud8f2\uddc3\udae4\udcba\ud98a\udfd7\uda0a\udd80\udac4\udea4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ubc54\ud748\uda12\ude5e\udb78\udcc5\ud94f\ude0d\ud928\udc5e\ud9a9\uddef\udb61\udcbb\udbaa\ude2a\ud823\udcea\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udaa2\uddcb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udaa2\udd5b\ud8bd\udd01\uadb4\udb80\udd6e\ud94f\ude0d\ud91a\udf98\udb8e\udf1b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaa2\udd5b\ud8bd\udd01\uadb4\udb80\udd6e\ud94f\ude0d\ud91a\udf98\udb8e\udf1b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u1fe8\ud8bd\udd01\uda80\udf0f\udb93\udea7\ud94f\ude0d\udb0f\udfbb\ud860\udd47\ud8c5\uddad\udbf9\udfd1\ud823\udd22\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda9c\udc61\uda0a\uddb3\uadb4\uda1d\udf4d\u63fd\ud8e3\udd3f\ud88c\udd22\ud8c5\udcea\udbc7\ude19\ud859\udf7f\ud886\udf86\ud9c0\ude10\udbd6\udfbf\uda3e\ude85\udafa\udfb9\udb85\udd57\ud924\uddc8\ud8da\udf86");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda9c\udc61\uda0a\uddb3\uadb4\uda1d\udf4d\u63fd\ud8e3\udd3f\ud88c\udd22\ud8c5\udcea\udbc7\ude19\ud859\udf7f\ud886\udf86\ud9c0\ude10\udbd6\udfbf\uda3e\ude85\udafa\udfb9\udb85\udd57\ud924\uddc8\ud8da\udf86", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda85\udee7\ud8bd\udd01\uadb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda85\udee7\ud8bd\udd01\uadb4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\udbde\udf5c\ud93e\udef3\uadb4\ud83a\udc27\ud94f\uddc1\ud928\udc5e\ud9a9\uddef\uda36\udca4\ud985\udc22\udbc2\uddc0\ud801\udc21\ud8ba\udce3\udbb8\ude23\ud9e5\udc70\ud93a\udc8e\ud911\udef1\udac8\udfb6\ud8c9\udd39\udb5c\udc3d\ud9dc\udc95\ud902\udc29\ud824\udc00\udb4b\udef3\ud91a\udff8\udb92\uddb7\ua04f\ud8d1\udd03\ud913\uded6\udb2f\udff5\u1852\ud8ce\uddda\ud838\ude3b\udbcc\uddcf\u0101\uda75\udc56\ud903\udf6e\udb95\udeff\ud9d9\uddfd\udbd5\udf9f\uda90\udf99\ud8e2\udd42\ud91d\udd3d\udb03\ude38\ud9dd\udf81\ud87a\udf31\udbfc\udfe8\udad5\udf1f\ud887\udcef\ud8de\udeb3\udaf5\udd7c\udaa8\udc27\ud82d\ude54\ud9d5\udf89\ud90d\udf7f\ud809\udc63\ud89b\udf41\uda66\ude62\ud9e9\udd56\ud8a7\udcda\u84b6\ud836\udc45\ud9ec\udd0f\udad4\udcde\ud812\uddbd\ud94d\udec3\ud92b\udd05\uda6b\udedd\ud92b\udf74\uda2a\udfbd\ud921\udefa");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbde\udf5c\ud93e\udef3\uadb4\ud83a\udc27\ud94f\uddc1\ud928\udc5e\ud9a9\uddef\uda36\udca4\ud985\udc22\udbc2\uddc0\ud801\udc21\ud8ba\udce3\udbb8\ude23\ud9e5\udc70\ud93a\udc8e\ud911\udef1\udac8\udfb6\ud8c9\udd39\udb5c\udc3d\ud9dc\udc95\ud902\udc29\ud824\udc00\udb4b\udef3\ud91a\udff8\udb92\uddb7\ua04f\ud8d1\udd03\ud913\uded6\udb2f\udff5\u1852\ud8ce\uddda\ud838\ude3b\udbcc\uddcf\u0101\uda75\udc56\ud903\udf6e\udb95\udeff\ud9d9\uddfd\udbd5\udf9f\uda90\udf99\ud8e2\udd42\ud91d\udd3d\udb03\ude38\ud9dd\udf81\ud87a\udf31\udbfc\udfe8\udad5\udf1f\ud887\udcef\ud8de\udeb3\udaf5\udd7c\udaa8\udc27\ud82d\ude54\ud9d5\udf89\ud90d\udf7f\ud809\udc63\ud89b\udf41\uda66\ude62\ud9e9\udd56\ud8a7\udcda\u84b6\ud836\udc45\ud9ec\udd0f\udad4\udcde\ud812\uddbd\ud94d\udec3\ud92b\udd05\uda6b\udedd\ud92b\udf74\uda2a\udfbd\ud921\udefa", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb9b\udc82");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb9b\udc82", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u105a\udac6\udd18\udb11\udf16");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\u00bb");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u7164\udb10\udd57\uda5d\udd7b\uda46\uddc7\ud94f\uddd5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u4b80\u1873\uda2a\udfc6\uda46\uddc7\ud94f\uddd5\udb99\udeb7\ud8b1\udcbd\udabd\udca0\udbac\udfa1\udb92\udd22\uda41\udcee\ud99c\uded2\udaa9\udcf3\ud84b\uddfb\ud944\ude4d\uda89\udf97\ud9e3\uddd4\udb16\ude9d\u451f\udb33\udf40\ud878\udd35\udad8\ude2d\ud829\udf92\udb2b\udedd");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u4004");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda8d\udc92\ud947\udd0e\ud80c\uddd1\udb5b\udec1\ud848\ude6e\ud810\udd42\ud882\udd05\uda49\udcfc\udace\ude55\ud9d3\ude25\uda0b\udc36\uda39\udcc7\ud99d\udc3a\ud997\udd79\udafa\udfcc\udb23\ude6f\ud81b\ude41\ud96f\udcdc\udaf3\udd22\uda28\udcae\udaf0\udc4a\udb57\ude01\ud9df\udfe3\ud838\udc5a\udba7\udde6\udadd\uddf9\ud86a\udd83\uda9f\ude3b\ud9b4\udfac\ud98a\udfd7\udbf9\uddf9\uda7a\uddad\ud88d\udd55\uda9b\udfdf\ud9c1\udda7\uda2d\udcbe\udad7\udd6b\uda2b\ude53");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda8d\udc92\ud947\udd0e\ud80c\uddd1\udb5b\udec1\ud848\ude6e\ud810\udd42\ud882\udd05\uda49\udcfc\udace\ude55\ud9d3\ude25\uda0b\udc36\uda39\udcc7\ud99d\udc3a\ud997\udd79\udafa\udfcc\udb23\ude6f\ud81b\ude41\ud96f\udcdc\udaf3\udd22\uda28\udcae\udaf0\udc4a\udb57\ude01\ud9df\udfe3\ud838\udc5a\udba7\udde6\udadd\uddf9\ud86a\udd83\uda9f\ude3b\ud9b4\udfac\ud98a\udfd7\udbf9\uddf9\uda7a\uddad\ud88d\udd55\uda9b\udfdf\ud9c1\udda7\uda2d\udcbe\udad7\udd6b\uda2b\ude53", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\u2d53");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u2d53", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u8023\ud86d\uded4\ud962\udd25\udb92\udccc\uda4c\udcef\ud928\udc5e\ud9f9\udc24\udbcc\udd90\uda80\ude0e\ud821\udfc1\uda9d\uded2\udac9\udf7f\ud991\udfa5\ud8a4\udf73\ud8b5\udc8c\udb75\udf79\uda2e\udfb4\ud9c7\udd41\ud93c\udd65\ud828\udd04\udb81\ude00\ud91f\udd94\udb7d\ude28\ud9ba\udc9b\udbe9\udc30\uda5c\udca9\ud914\uddef\udb5f\udc69\ud851\udfbf\ud9cb\uddd0\udac0\udc74\ud990\udc6a\uda0a\udd80\udac4\udea4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ubc54\ud748\u9e0a\udb78\udccc\ud94f\ude0d\ud928\udc5e\ud9a9\uddef\udb61\udcbb\udbaa\ude2a\ud823\udcea\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\ubc19\ud748\uda12\ude5e\ud9ff\udf98");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ubc54\ud748\uda12\ude5e\udb78\udcc5\udb15\udd3d\ud90b\udfad\udb55\udf99\ud90c\udf04\ud9d8\ude64\ud823\udcea\ud886\udf86\uda69\udf50");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\ubbaa\ud748\uacb8\ud8f3\udd71\ud93d\udf6c\ud928\udc5e\ud9a9\uddef\udb61\udcbb\udbaa\ude2a\ud823\udcea\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u1fe8\ud8bd\udd01\uda80\udf0f\udb93\udea7\ud94f\ude0d\udb9b\udee1\ud82e\udf46\ud8c5\uddad\udbf9\udfd1\ud823\udd22\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda9c\udc61\uda0a\uddb3\uadb4\uda1d\udf4d\u63fd\ud8e3\udd3f\ud88c\udd22\ud8c5\udcea\udbc7\ude19\ud859\udf7f\ud886\udf86\ud9c0\ude10\ud88b\udce4\000\000\udb85\udd10\037\ud957\udc2b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda9c\udc61\uda0a\uddb3\uadb4\uda1d\udf4d\u63fd\ud8e3\udd3f\ud88c\udd22\ud8c5\udcea\udbc7\ude19\ud859\udf7f\ud886\udf86\ud9c0\ude10\ud88b\udce4\000\000\udb85\udd10\ud957\udc2b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u1fe8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uc24d\uda9b\udd0d\uadb4\uda1d\udf4d\u63fd\ud8e3\udca5\ud88c\udd22 \000\000\000\ud9c0\udd8e\ud88b\udce4\000\000\udb85\udd10\037\ud957\udc2b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uc24d\uda9b\udd0d\uadb4\uda1d\udf4d\u63fd\ud8e3\udca5\ud88c\udd22\000\000\000\ud9c0\udd8e\ud88b\udce4\000\000\udb85\udd10\ud957\udc2b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\udbbe\udee1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbbe\udee1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\ubc54\ud748\u6c24\udb78\udc50\udb15\udd3d\ud90b\udfad\udb55\udf99\ud90c\udf04\ud9d8\ude64\ud823\udcea\ud886\udf86\uda69\udf50");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u1fe8\u1f68\udb48\udc94\udad7\udc0d\udba6\udd93\uac0b\udb23\udfbd\udad7\uddf9\ud9e3\udd1a\ud879\uded8\udb70\ude88\udbe9\udf44");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\uff56\ud9a9\uddd5\ud8e4\udf3f\ud9ed\udffa");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ubc54\ud748\u9e7e\udb78\udccc\ud94f\ude0d\ud928\udc5e\ud9a9\uddef\udb61\udcbb\ud86f\udeed\ud9a4\udc96\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udbde\udf5c\ud963\udc77\ud8db\ude9b\ud81d\udfc6\ud94f\uddc1\ud928\udc5e\ud9a9\uddef\uda36\udca4\ud985\udc22\udbc2\uddc0\ud801\udc21\ud8ba\udce3\udbb8\ude23\ud8a5\udff0\ud91b\udd31\ud911\udef1\ud928\udd85\ud8c9\udda0\udb5c\udc3d\ud9de\udf2b\ud902\udc29\ud90f\udeba\udb6e\udca4\udb2e\ude42\udbf5\udc26\udb99\udd52\ud8d1\udd03\ud913\uded6\udb30\udc6f\u1852\ud8ce\uddda\ud838\ude3b\udbcc\uddcf\u0101\uda75\udc56\ud903\udf6e\udb95\udeff\ud9d9\uddfd\udbd5\udf9f\uda90\udf99\ud8e2\udd42\ud91d\udd3d\udb03\ude38\ud9dd\udf81\ud87a\udf31\ud80e\ude32\udacd\udc70\uda0e\udf5a\ud8de\udeb3\udaf5\udd7c\ud984\udd55\ud834\udf35\ud9d5\udf89\ud90d\udf7f\ud809\udc63\udafa\udc50\uda66\ude62\ud9e9\udd56\ud8a7\udcda\u84b6\ud836\udc45\ud9ec\udd0f\udad4\udcde\ud812\uddbd\ud913\udee5\ud822\udd95\uda6b\udedd\ud92b\udf74\uda2a\udfbd\ud921\udefa");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbde\udf5c\ud963\udc77\ud8db\ude9b\ud81d\udfc6\ud94f\uddc1\ud928\udc5e\ud9a9\uddef\uda36\udca4\ud985\udc22\udbc2\uddc0\ud801\udc21\ud8ba\udce3\udbb8\ude23\ud8a5\udff0\ud91b\udd31\ud911\udef1\ud928\udd85\ud8c9\udda0\udb5c\udc3d\ud9de\udf2b\ud902\udc29\ud90f\udeba\udb6e\udca4\udb2e\ude42\udbf5\udc26\udb99\udd52\ud8d1\udd03\ud913\uded6\udb30\udc6f\u1852\ud8ce\uddda\ud838\ude3b\udbcc\uddcf\u0101\uda75\udc56\ud903\udf6e\udb95\udeff\ud9d9\uddfd\udbd5\udf9f\uda90\udf99\ud8e2\udd42\ud91d\udd3d\udb03\ude38\ud9dd\udf81\ud87a\udf31\ud80e\ude32\udacd\udc70\uda0e\udf5a\ud8de\udeb3\udaf5\udd7c\ud984\udd55\ud834\udf35\ud9d5\udf89\ud90d\udf7f\ud809\udc63\udafa\udc50\uda66\ude62\ud9e9\udd56\ud8a7\udcda\u84b6\ud836\udc45\ud9ec\udd0f\udad4\udcde\ud812\uddbd\ud913\udee5\ud822\udd95\uda6b\udedd\ud92b\udf74\uda2a\udfbd\ud921\udefa", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumericSpace("\u1fe8\u3f22\u4690\ub54a\ud910\udda1\ud865\udf9f\udac9\udd83");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\uff56\u1ee5\ud907\udfe1\ud848\ude7c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ubc54\ud748\u6c24u\udb8e\udea6\ud928\udc5e\ud9a9\uddef\udb61\udcbb\udbaa\ude2a\ud823\udcea\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ubc54\ud748\u6c24u\000\000\000\u00e3\000\ud823\udc8f\ud886\udf86\ud9c0\ude10");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u1fe8\u3f22\u4690\ub54a\ud910\udda1\ud865\udf9f\udac9\udd83\ud943\udc93\ud831\udf9b\udb19\udfe3\ud8ce\udd40\uda2b\udeb3\ud903\udc49\uda43\udebe\ud9fd\udca0\ud9a2\ude10\ud916\udf2b\udb2c\udc07\uda49\udee7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
