package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class CharSequenceTranslator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 6, "\ud9d9\udca5\ud807\udfc6", "\u4648\u4d4a\u453b\u775b\u6bd8\u22de\u48b0\u5575", "\udae6\udd2f\uda4a\ude43\ud83c\ude02\ud931\udc17\ud97a\uddc1\ud9cf\ude73\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udf52\ud937\udfc6\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b",
        3, 17853, -1389001490, 2950103799850039641L, -83528L, false, true, (char) 62810, (char) 59599,
        Double.longBitsToDouble(0x3fe123d4fb9297a1L), Double.longBitsToDouble(0x3feb1cc9175e285cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 5, "\ud9d9\udca5", "\ub0f2\u4648\u4d4a\u453b\u775b\u6bd8", "\ud939\udc60\u1ed1",
        22, 64463, -2672058, -6351905937294380746L, -32363L, false, false, (char) 62105, (char) 51030,
        Double.longBitsToDouble(0x3fda5a1d97b5296aL), Double.longBitsToDouble(0x3fd8ebad25b10c38L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 4, 1, "\ud9d9\udca5\ud807\udfc6\udb8d\udcca\udb24\udf6d\ud9e7\udd6c\ud816\udce7\ud85c\udce8\udb83\udc97\ud9a0\uddb2\ud8c1\udd5a\u0f79\ud9e4\udd70\u7576", "\uaf6a\ua5f8\ucb22\ubb69\u54ce\u8cd7\u4777\u829e\ubeaf\u0cd4\u1d17\u3c1c\ud34c\u719a\u322e\u168c\u5cb9\u456d\ub32f\u4194\u2cfe", "\ud8bf\udec8\ud871\udec8\ud93d\udc4e\uda5b\udf2d",
        59, 13918, -1750995420, -1719544298634154108L, 16751L, false, true, (char) 2223, (char) 22366,
        Double.longBitsToDouble(0x3fd7b4450912d842L), Double.longBitsToDouble(0x3fc1b988080f3ce8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 2, "\ud9d9\udca5\ud807\udfc6", "\u4648\u4d4a\u453b\u775b\u6bd8\u22de\u48b0\u5575", "\udae6\udd2f\uda4a\ude43\ud83c\ude02\ud931\udc17\ud97a\uddc1\ud9a5\udf73\ud8e4\udee6\ud924\udedd\uda49\udca8\udb18\udce0\ud937\udf51\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\uda6e\ude65\udaec\udcb1\udb16\udd62\udb85\udf7b",
        3, 17853, 1999996142, 2950091954330237273L, 62208L, false, true, (char) 26819, (char) 35635,
        Double.longBitsToDouble(0x3feb1cc9175e285cL), Double.longBitsToDouble(0x3fe56d5c811a23f8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 0, 6, "\ud9d9\udd59\ud807\udfc6", "\u4648\ub2eb\u6362\u775b\u6bd8\u22de\u48b0\u5575", "\udae6\udd2f\uda4a\ude43\ud83c\ude02\ud931\udc17\ud805\udcfe\ud9cf\ude73\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udf52\ud937\udfc6\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b",
        3, 17853, -1389001490, 2950103799850039641L, 47544L, false, true, (char) 56546, (char) 57385,
        Double.longBitsToDouble(0x3fd60e461b1eef68L), Double.longBitsToDouble(0x3feb1ccc8375285cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 6, "\uda9f\udfae\ud807\udfc6", "\u4648\u4a18\u98f5\u3c60\u6bd8\u22de\u48b0\u926b\u7aa6\ua2b4\u03ac\u9215\u06ba\ucb22\ud112", "\ud924\udedd\uda49\udca8\ud925\udf52\ud937\udfc6",
        57, 92848, -888851342, 8251757571626099903L, -48131L, true, true, (char) 59383, (char) 24021,
        Double.longBitsToDouble(0x3fb17ae8677510e0L), Double.longBitsToDouble(0x3fee3d69a95928f0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 6, "\ud9d9\udca5\ud807\udfc6", "\u330e\u4d4a\ub0c2\u775b\u5aaa\u847d\u6e4c\u9848", "\udb48\udd7c\ud807\udfb9\ud83c\ude02\ud88e\uddc7",
        12, 70555, -1705606940, 4405284882332879413L, 46982L, false, true, (char) 22772, (char) 6212,
        Double.longBitsToDouble(0x3fd27645197ee508L), Double.longBitsToDouble(0x3fea2d6b4d63ad51L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 6, "\ud9d9\udca5\ud913\udc26", "\ua1b4\u0d2d\u453b\u775b", "\u0f79",
        27, 35804, 663415767, 4765482724210719302L, -79830L, true, true, (char) 54719, (char) 14623,
        Double.longBitsToDouble(0x3fe11957ea35ff1eL), Double.longBitsToDouble(0x3fda5a1d97b5296aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 6, "\ud9d9\udca5\ud807\udfc6", "\u4648\u4d4a\u453b\u775b\u6bd8\u22de\u48b0\u5575", "\udae6\udd2f\uda4a\ude43\ud83c\ude02\ud931\udc17\ud97a\uddc1\ud9cf\ude73\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udf52\ud937\udfc6\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b",
        3, 17853, -1377401618, 2950103799850039641L, 75997L, false, true, (char) 34949, (char) 16314,
        Double.longBitsToDouble(0x3fd0bf4875f239c2L), Double.longBitsToDouble(0x3fef589357203a4aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 6, "\ud9d9\udca5\ud807\udfc6", "\u4648\u4d4a\u453b\u775b\u6bd8\u144b\u630f\000", "\udae6\udd2f\uda4a\ude43\udb39\udf40\000\000\ud9cf\ude73\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udf52\ud937\udfc6\u458e\ud904\udc1f\udace\udd52",
        17, 48911, 46917, -6756748541084321288L, 88160L, true, false, (char) 9994, (char) 44487,
        Double.longBitsToDouble(0x3fd00000012f212eL), Double.longBitsToDouble(0x3f3a448f30000000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 0, 6, "\ue5ec\ud80e\udc53", "\u4648\u4d4a\u453b\u775b\u6bd8\u22de\u48b0\u1fd7\u264d\u3caf\u03ac", "\ud931\udc85\udbe0\udf07\ud9cf\ude1b\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udf52\ud937\udfc6\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a",
        26, 80405, -1573178013, 5982955105796547758L, 39321L, true, true, (char) 49454, (char) 43370,
        Double.longBitsToDouble(0x3fde6bb7c340f774L), Double.longBitsToDouble(0x3fd4e3f82c48f53eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 6, "\ud9d9\udca5\ud807\udfc6", "\u4648\u4d4a\u453b\u775b\u6bd8\u22de\u48b0\u5575\u7a84\ua2b4\u03ac\u9215", "\ud97a\uddc1\ud9cf\ude73\ud8e4\udee6\ud98c\ude20\uda49\udd08\ud925\udf52\ud937\udfc6\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b\ud807\ude37\uda1b\udf17\udbde\udc0c\uda8c\ude30\ud8bc\udec8\ud871\udec8\ud93d\udc4e\uda86\udd30\ud85d\udd5e\udbe0\udc87\ud9ad\udffd\ud85d\udd82\udbbe\uddc3\ud953\udf04\udb2f\udf83\ud914\udffa",
        2, 36603, 1081459122, -1755393868896252682L, -91992L, false, true, (char) 26498, (char) 30957,
        Double.longBitsToDouble(0x3fba9f00756ac198L), Double.longBitsToDouble(0x3fe075107cbdcb12L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 2, "\ud9d9\udca5\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda4a\ude43", "\ubb69\u54ce\u5866\u47b8\u829e\u1e03\u79dc\u1d17\u3c1c\u7860\u7bf1\u54d5\ua63d\u4e40\u4627\ub32f\u4194\u9369\u578c\ud15f\u18e0\ub1a0\ua723\u148b\ua7cf\u82a3\u7a71\uc1a7\u8f39\u8668\u8195\u67b5", "\udb92\ude7b\uda00\udd0f\ud856\udc4b\uc75c\udb76\udd70\ud82b\udc70\ud879\ude10\udbb1\udcf1\ud8cd\udd93\ud845\udd64\ud8f8\udd3f",
        0, 50450, -1447676848, -2361263453030523520L, -77449L, true, false, (char) 65289, (char) 36043,
        Double.longBitsToDouble(0x3fe27d3295a79c55L), Double.longBitsToDouble(0x3fdd433938eac39aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:F\012",
        Z.run(T, 1, 3, 4, 2, "\ud9d9\udca5\ud80c\udfc6\udbe9\udc98\ud9c5\udf4b\u8f48\ud833\udedc\ud874\udd13\ud860\udf30\ud9bf\ude61", "\u5575\u7a84", "\uda4a\ude43\ud9cd\udef5\ud931\udc17\ud97a\uddc1\ud9cf\ude73\ud8e4\udee6\ud92d\udddd\uda49\udca8\ud987\udd82\ud937\udfc6\u9416\ud90d\udc71\udace\udd52\uda90\udc00\uf7e1\ud9bc\ude6c\ud93f\udfdc\ud8e1\udc90\udb85\udf7b\ud8f0\udc6b\uda1b\udf56",
        15, 73567, -1869121191, 7571167346639519832L, -68864L, true, true, (char) 59841, (char) 1076,
        Double.longBitsToDouble(0x3fc7cbe09c88de94L), Double.longBitsToDouble(0x3f78120d5c70a500L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 6, 0, 5, "\ud9d9\udc92\udb95\udda6\udb90\udeeb\ud9fd\udc3d", "\u453b\u775b\u6bd8\u341d\u48b0\u1292", "\udae6\udd2f\uda4a\ude43\ud839\udf02\ud931\udc17\ud97a\uddc1\ud9ab\udf1e\ud8e4\udee6\udb1a\udfe0\uda31\udc7c\ud925\udf52\ud937\udfc6\ud86a\udfda\udb79\udc5f\ud9c1\udfb0\ud9d0\udd0c\u8bd2\uda6e\ude65\udbc7\udda6\uda0b\udce2\udb61\uded1",
        59, 10976, -886044775, 2156835426316810542L, -89537L, false, false, (char) 8767, (char) 55325,
        Double.longBitsToDouble(0x3feb1cc9175e285cL), Double.longBitsToDouble(0x3fd746908dc7d6d8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 2, 0, ":\ud807\udfaf", "\ub90e\000\000\000\u9ea1\u0f50\uc5ed\u5575", "\u754c\uda3c\udc43\ud902\udef5\ud931\udc17\u71b3\ud9cf\ude73\ud8e4\udee6\ud924\udedd\udb2f\udc9b\000\ud918\udfec\uda95\udd8f\ud8cf\udd47\udace\udd52\uda8a\udc8a\udb36\udfda\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b",
        29, 17853, -1389001490, 2950103799840143705L, -83528L, false, true, (char) 62810, (char) 16336,
        Double.longBitsToDouble(0x3fe123d4fb9297a1L), Double.longBitsToDouble(0x3feb1cc9175e285cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 0, 6, "\ud9d9\udca5\ud807\udfc6", "\u4648\u4d4a\u453b\u775b\u6bd8\u22de\u48b0\u5575", "\udae6\udd2f\uda4a\ude43\ud83c\ude02\ud931\udc17\ud97a\uddc1\ud9cf\ude73\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udf52\ud937\udfc6\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b",
        3, 17853, -1389001490, 2950103799850039641L, -83528L, false, true, (char) 62810, (char) 59599,
        Double.longBitsToDouble(0x3fe123d4fb9297a1L), Double.longBitsToDouble(0x3feb1cc9175e285cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 0, 6, "\ud9d9\udca5\ud807\udfc6", "\u32ef\u7f1d\u7551\uc0f4", "\u0f79",
        27, 35804, 663415767, 4765482724210719302L, -51509L, true, true, (char) 54719, (char) 7591,
        Double.longBitsToDouble(0x3fe8fea90a6f51dbL), Double.longBitsToDouble(0x3fed850f7f7841c7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 6, "\ud9b5\udd3f\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u0f79\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda4a\ude43", "\ubb69\u54ce\u5866\u47b8\u829e\u1e7b\u79dc\u1d17\u3c1c\u3da7\u9184\u32dd\u7d46\u4e40\u4627\ub32f\u4194\u2cfe\u22ceM\u3d4e\uc51e\ua723\u148b\u8ce5\u82a3\u7a71\uc1a7\u8f39\u1abb\ucafd\u85b8", "\ud9dc\uddf8\udbe2\udc63\ud8a2\udcec\udbe7\udf67\ud8b2\udfa6\udacb\udf9d\ud8be\ude3c\uda71\udd39\udbbf\udf19\udb8f\udeec\ud893\udf36\uda8e\udd5e\ud806\udcea\ud8e6\udec9\ud9da\udfee\uda2e\udd23\ud9a0\udee3\ud8e2\udf61\ud8e6\udfaf",
        39, 75230, 1971891258, 3941042463021474559L, -60345L, true, false, (char) 21755, (char) 15785,
        Double.longBitsToDouble(0x3fecd5e925646920L), Double.longBitsToDouble(0x3fe233deae610a82L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 0, 6, "\ud937\udda0\ud807\udff0\udb90\udeeb\ud9fc\udfb9\ud877\udeb1\ud833\udedc\ud828\udc2d\uda9e\ude83\ud9bf\ude84\ud911\udd5f\udbfa\udcd3\udaf1\udddf\uda7a\udfa2\ud94b\udd83\ud912\udcb6\uda5f\udf77\ud83c\ude02\ud931\udc17\ud97a\uddc1\ud9cf\ude73\ud8e4\udee6\ud924\udedd\uda49\udca8\ud9e1\udf70\ud94d\udcd3\ud943\udffe\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\uda6f\udc65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b", "\ua880M\u3d4e\u75b6\ua6d1\u148b\uc8ca\u8309\u7a71\uc1a7\u070a\ud5bc\u4087\ucdac\ub09b\ud109\ub4d6\u3e9f\ucf38\u24db\u38c6\ub2ce\ub85e", "\uda95\udfc6\ud890\udd50\ud850\udfd9\ud96e\udf05\udbfd\udc32\uda2c\ude97\udbdf\udf78\ud806\udfdd\ud8ce\udffe\ud849\udf03",
        38, 14414, 1917637161, 7269547792507711741L, 82707L, false, true, (char) 12721, (char) 15051,
        Double.longBitsToDouble(0x3fda0c80bec77776L), Double.longBitsToDouble(0x3fe247c5dca0c599L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 5, 3, "\ud9d9\udca5\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ud833\udfbf", "\u6ca0\ud044\u59d4\u8f6d\u09c8\ub347\u62b6", "\udb24\ude54\ud97a\uddc1\ud9cf\ude73\ud8e1\udfe6\ud924\udedd\uda3f\udea8\ud94b\ude52\ud82e\ude80",
        47, 92848, -873057166, 8251757571626099903L, -48131L, false, true, (char) 59383, (char) 24021,
        Double.longBitsToDouble(0x3fb1648f277510e0L), Double.longBitsToDouble(0x3fe63d69ac0fa8f3L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 0, 0, 6, "\000\000", "\u4648\u4d4a\u453b\u9bcc\000\000\000\u5575", "\udae6\udd2f",
        -1, 23652, 819966262, -2453067878547916853L, -100000L, false, false, (char) 65422, (char) 22772,
        Double.longBitsToDouble(0x3fbcb4744e5e5828L), Double.longBitsToDouble(0x3fc7ee5080000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 0, "\ud9d9\udca5", "\ub0f2\u4648\003\u44a1\u775b6", "",
        22, 35584, 663415767, 4765482724210719302L, -79830L, true, true, (char) 54719, (char) 27166,
        Double.longBitsToDouble(0x3fea1cd2b2353d22L), Double.longBitsToDouble(0x3fda5a1d97b5296aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 0, 6, "\ud9d9\udca5", "", "",
        38, 77298, 1862270989, -8351462383029578051L, 62160L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe000000734ffd7L), Double.longBitsToDouble(0x3fd36a7d978661beL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 6, "\ud9a2\udffc\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u901e\ud8ae\udfc6\ud8ad\udf61\udb5e\udf89\ud9bf\ude61\ud8c1\udd5a\u0f79\uda35\udcb9\ua798\uda25\ude1c\udb8d\udedb\uda1b\uded8\uda1b\udced\udb8f\udcec\ud97a\uddc1\u2ff2\ud974\udff9", "\u5566\u84d8\ud350\u6c01\u3d74\u3bf1\ua1dd\u7d46", "\udb85\udf7b",
        3, 45778, -1389001490, 2950103799850039641L, -92744L, false, true, (char) 62846, (char) 59721,
        Double.longBitsToDouble(0x3fee83d4fb9297a1L), Double.longBitsToDouble(0x3feb1cc9134600d2L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |a2=java.io.StringWriter:\ud9d9\udca5\ud807\udfc6 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 0, 3, 6, "\ud9d9\udca5\ud807\udfc6", "\u4648\u4d4a\u453b\u708a\u71e0\u22de\u48b0\ua4b7", "\udae6\udd2f\udb47\ude81\udbf2\udf15\ud931\udc17\udb0f\uddec\udba8\udff8\ud8e4\udee6\ud924\udedd\uda49\udca8\ud959\udeac\udba9\udc4b\ud826\ude56\ud904\udc1f\udace\udd52\uda8a\udc8a\ud8be\udc01\uda23\uded2\ud889\ude03\udade\ude0d\udb85\udf3b\udaa2\udc85\uda1b\udebc\udbde\udc0c\uda8c\ude30\ud8bc\udec8\ud871\udec8\ud93d\udc4e\uda86\udd30\ud84e\udd5e\ud885\udf78\udb23\ude68\ud85e\udf1b",
        0, 96782, 958677638, 1037459164773696266L, 72946L, true, false, (char) 43303, (char) 27357,
        Double.longBitsToDouble(0x3fbc14ea9dc7b900L), Double.longBitsToDouble(0x3fe2e8be75aa2121L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud829\udcad", "\u8f70\ud1de\u1a5d\u59b2\ucdcb\u6c79\u671d\uca13\u4ccd\u7a61\ua2b4\u03e1\u9215\u06ba\ucb22", "\ud8e4\udee9\uda73\udf03\ud939\udfb9\ud866\udd58\udb85\udd76\uda62\ude19\ud991\udd25",
        10, 81678, -388083996, 2477274550179607154L, 92049L, false, false, (char) 22379, (char) 10581,
        Double.longBitsToDouble(0x3fd429e6371095d2L), Double.longBitsToDouble(0x3fe5970b3fd40e26L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 4, 5, "\ud9d9\udca5\ud807\udfc6\udb8d\udcca\udb24\udf6d\ud8b5\ude73\udb64\ude57\ud85c\udce8\udb6d\udc9e\ud948\ude50\ud8c1\udca8\u0f79\ud9e4\udd70\u7576\uda25\ude2b\udae6\udd2f\uda5d\udf8d\ud9fa\udf47\ud931\udc17\ud97a\uddc1\ud9cf\ude73\udbdc\udde1\ud924\ude9c\uda49\udca8\udbc5\udda2\udaf4\ude43\ud833\ude5f\ud904\udc1f\udb96\ude6b\uda88\udcb3\uf732\udb6a\udc6d\u844b\ud81a\udd4e\udb85\udefd\udaa2\udc85\uda1b\udebc\ud87c\udc69\uda8c\udd7d\ud8bf\udec8\ud871\udec8\ud93d\udc4e\ud8cc\udc66\ud85d\udd08\udbe0\udc87\ud9ae\udc62\udbec\ude29", "\u6eef", "\uda8e\ude17\uda3f\udde6\uda0d\udf15\uda6e\ude5f\udac2\ude23\ud80f\udd32\udb95\ude99\uda6c\udd0b\ud8f6\udd2a\ud975\udf72\ud901\udcda\ud8ca\udc45\uda88\udce3\ud880\udec6\ud980\ude51\udb97\udd9b\udb9d\udce3\udbbc\uddfb\ud863\udff7\uf46e\ud889\ude9e\uda5c\uddb0\udb89\udc33",
        56, 94660, 921233252, -1997915834671485651L, -15098L, false, false, (char) 53123, (char) 12008,
        Double.longBitsToDouble(0x3fe4df41912afa62L), Double.longBitsToDouble(0x3fe68932493ef571L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 5, 0, 4, "", "\uced4", "\ud833\udedc\ud874\udd13",
        30, 75638, -394520899, -4016829603269998960L, -29303L, false, true, (char) 31848, (char) 32524,
        Double.longBitsToDouble(0x3fd36a7d978661beL), Double.longBitsToDouble(0x3fc97bbe8393a4e8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 2, "\ud917\udfe5\ud9f7\udcbd\udb90\udeeb\ud9fc\udfb9\uda53\udd60\ud833\udfb2\ud977\uddd5\ud85c\uddac\ud9bf\ude61\ud8c1\udd5a\u4e4a\udb11\udee7\uda01\ude13\uda0c\udc9b\udae6\udd2f\uda4a\ude43\ud83c\ude02\uda05\udf8f\udbd2\udc95\ub938\ud913\udec5\ud9a6\udd68\ud8a1\udd3b", "\u1d17\u3c1c\u3da7\u68ef\u0661\u7d6e\u6163\u2ce2\u0d0c\u17c6\u358b\u7a37\ucd86\u3d4e\u84fc\ua723\u8aef\u9c4d\uad96\u7a71\uc1a7\u42c7\u94ea\u094f\u61bf\u1295\u65a3\uca1d\u7b2a\u4e22\ub379\ua611\ubc17\u3161\u08eb\u45e2\u742d\u2114", "\ud9f4\ude9a\ud833\udd9f\udb47\udd6a",
        4, 72041, 357290751, -1330526969307423360L, -2129L, false, false, (char) 55268, (char) 39740,
        Double.longBitsToDouble(0x3fc969297518d12cL), Double.longBitsToDouble(0x3fe6e558999ce633L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\u00ee\000 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 1, 0, 6, "\u00ee\000", "\u4648\ub2eb\u6362\u775b\u6bd8\u22de\000\u54e5", "\udae6\udd2f\uda4a\ude43\ud83c\ude02\ud931\udc17\ud805\udcfe\ud9cf\ude73\ud8e4\udee6\ud924\udedd\udb3c\ude0c\ud925\udead\ud937\udfc6\ud833\ude5f\ud904\udc1f\udace\udce0\uda8a\udc8a\uf7e1\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b",
        3, 17853, -1389001490, 2950103799850039641L, 47544L, false, true, (char) 56546, (char) 57385,
        Double.longBitsToDouble(0x3fd60e461b1eef68L), Double.longBitsToDouble(0x3feb1ccc8375285cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 4, 5, "\ud9cc\udd05", "\ua029\ua1b4\u0d2d\u453b", "\udaf8\udeb5\u7507\ud946\udf01\udbd3\udedc\uda25\ude2b\udbb5\ude97\udb82\udc04\uda59\udca2\udb18\udf91\ud97a\uddc1\ua962\uda26\uddd3\udab5\ude15\ud8d8\udcae\ud899\uddfa\udb14\udcab\udbd7\uded4\ud9a8\udf06\ud991\udc93\uda4f\udd81\udbac\ude0f\udb10\ude94\ud88b\udf5b",
        27, 72567, -1728405657, -3491424777562083913L, 11229L, true, false, (char) 35820, (char) 14117,
        Double.longBitsToDouble(0x3fb597145a119f60L), Double.longBitsToDouble(0x3fd0f18291d99b5eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:1D\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 0, 0, "\ud890\udef9\ud868\udc75\uda63\udeb3\udae4\udd56\ud96a\udf6f\udad6\udde0\u361c\udaac\ude83\uda37\udfcf\ud9d1\udc38\ud91a\udf73", "\u3182\u5829\ucf35\u5b0f\uc1e1\u8b14", "\ud9bc\udcbf\uda89\ude06\udae9\udec0\udb34\udc58\uda92\udee7\ud938\ude32\ud985\ude21\udb5a\udf5c\ud8da\udcd9\udb61\udf34\ud971\udc2d\ud9ac\uddd1\uda84\udea7\uda53\udc77\ud8a9\udc72\uda06\udecc",
        29, 8535, -373598944, -1017450182733395097L, -40955L, false, false, (char) 21473, (char) 5938,
        Double.longBitsToDouble(0x3fd27a993610df7aL), Double.longBitsToDouble(0x3fc418a3579e04c4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:16\0121=java.lang.String:16\012",
        Z.run(T, 2, 3, 3, 0, "\ud9d9\udca5\ud913\udc26", "\u714b\u9c61\u44c0\u775b\u6bd8", "\udb11\udee7\u1f98",
        22, 64410, -2672058, -6351905825625231050L, 33173L, false, true, (char) 60234, (char) 35155,
        Double.longBitsToDouble(0x3fda5a1d97b5296aL), Double.longBitsToDouble(0x3febab5939a28bf6L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |a1=java.io.StringWriter:\ue5ec\u797d |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 2, 4, 2, "\ue5ec\u797d", "\u911b\u141b\u8b47\u775b\u6bd8\u22de\u48b0\u7dff\u2826\u46e0\u03ac", "\ud931\udc85\udbe0\ude39\ud9cf\ude1b\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udf52\udbfc\udda8\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a",
        38, 64418, -1573178013, 5982955105796547758L, -57317L, false, true, (char) 45427, (char) 10091,
        Double.longBitsToDouble(0x3fe9cf86920580d8L), Double.longBitsToDouble(0x3fde6bb7c340f774L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:29 |a2=java.io.StringWriter:\udb29\udc6e\uda21\udff9\udb90\udeeb\ud9fc\udfb9\u8f48\udb57\udeae\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda6e\ude54 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 2, 2, "\udb29\udc6e\uda21\udff9\udb90\udeeb\ud9fc\udfb9\u8f48\udb57\udeae\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda6e\ude54", "\ubb69\u54ce\u5866\u47b8\u829e\u1e03\u79dc\u1d17\u3c1c\u7860\u7bf1\u54d5\ua63d\u4e40\u4627\ub32f\u4194\u9369\u578c\ud15f\u865e\u2bff\u7b9f\u9e04\ua77b\ub511\u651f\uc1a7\u8f39\u8668\u8195\u67b5", "\udb92\ude7b\uda00\udd0f\ud856\udc4b\uc75c\udb76\udd70\ud82b\udc70\ud879\ude10\udbb1\udcf1\ud82a\udd9b\ud845\ude1d\ud8f8\udd3f",
        0, 67370, -1447648848, -2361263453030523520L, -77449L, true, false, (char) 65289, (char) 36043,
        Double.longBitsToDouble(0x3fccfeca57cad2ecL), Double.longBitsToDouble(0x3fbfaf70a00c0d60L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\000 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 2, 2, "\000", "\ub0f2", "\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7",
        24, 46767, 1109550410, -11476403201933516L, -37597L, true, true, (char) 59934, (char) 46914,
        Double.longBitsToDouble(0x3fe1a9e9152da1d9L), Double.longBitsToDouble(0x3feed4a5ad8ebad2L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.Integer:29 |a2=java.io.StringWriter:\ud9d9\udca5\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda4a\ude43 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 5, 1, "\ud9d9\udca5\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda4a\ude43", "\ubb69\u54ce\u5866\u47b8\u829e\u1e03\u79dc\u1d17\u3c1c\u7860\u7bf1\u54d5\ua63d\u4e40\u4627\ub32f\u4194\u9369\ub65c\u217f\u18e0\u7273\ua727\u148b\ua7cf\u82a3\u3073\u7cb1\u8f39\u8668\u8195\u67b5", "\udb92\ude7b\uda00\udd0f\ud856\udc4b\udaa4\udd74\ud865\udf3c\udbf2\udfbf\ud879\ude10\udbb1\udcf1\ud8cd\udd93\ud845\udd64\ud8f8\udd3f",
        0, 50450, -1447676848, -2361263455041888896L, -77449L, true, false, (char) 65289, (char) 36043,
        Double.longBitsToDouble(0x3fe27d3295a79c55L), Double.longBitsToDouble(0x3fe2119c9c75618bL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 6, 0, 5, "\ud9d9\udca5\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud915\udec4\000\udaf0\udc57\u1f98\uda25\ude2b\u754c\000", "\ubb69", "\ud924\udedd\uda49\udca8\ud925\udeda\ud978\udfe6",
        -4, 92848, 851131456, -5742139674733536294L, -48131L, false, true, (char) 59383, (char) 24021,
        Double.longBitsToDouble(0x3fe22f5d0ceea277L), Double.longBitsToDouble(0x3fc623a6be12d94cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:29 |a2=java.io.StringWriter:\ud8bb\ude57\uda6b\udf94\ud85f\udf3f\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda4a\ude43 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.Integer:29 |a2=java.io.StringWriter:\ud8bb\ude57\uda6b\udf94\ud85f\udf3f\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda4a\ude43 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 5, 5, 2, "\ud8bb\ude57\uda6b\udf94\ud85f\udf3f\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda4a\ude43", "\ubb69\u54ce\u5866\u47b8\u3f63\ucb11\u79dc\u1d17\u3c1c\u7860\u7bf1\u54d5\ub60b\ucff9\ub079\ub32f\u4194\u9369\u578c\ud15f\u18e0\ub1a0\ua723\u148b\ucc40\u830a\u7a71\uc1a7\u8f39\u8668\u8195\u67b5", "\udb92\ude7b\uda00\udd0f\ud856\udc4b\uc75c\udb76\udd70\ud82b\udc70\ud879\ude10\udbb1\udcf1\ud8cd\udd93\ud845\udd64\ud8f8\udd3f",
        0, 50450, -1447676848, -2361263453030523520L, -77449L, true, false, (char) 65289, (char) 36043,
        Double.longBitsToDouble(0x3fc994ca569e7154L), Double.longBitsToDouble(0x3fdd433938eac39aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 2, "\ud9d9\udca5\ud807\udfc6\udb90\udeeb\udb2d\udcae\u8f48\ud833\udedc\ud874\udd13\015\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\u654a\000", "", "\ud8e4\udee6",
        0, 24792, -1800065747, 934257885184L, -49888L, false, false, (char) 19497, (char) 2109,
        Double.longBitsToDouble(0x3fd63ad513f14476L), Double.longBitsToDouble(0x3fef896039b93c1cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 0, ":", "\u401c\u4648\u4d4a\u453b\u775b\000", "",
        29, 35804, 663415767, 4765482724213406278L, -79830L, true, true, (char) 54475, (char) 27166,
        Double.longBitsToDouble(0x3fea1cd2b0000022L), Double.longBitsToDouble(0x3fd2da1d9001296aL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 2, "\ud9d9\udca5\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\ud851\uddc7\u2e4b\udaf9\udd39\udace\udcc4\uda4a\ude43", "\ubb69\u54ce\u5866\u47b8\u829e\u1e03\u79dc\u1d17\u3c1c\u7860\u7bf1\u54d5\ua63d\u4e40\u4627\ub32f\u4194\u9369\u578c\u7be6\u5f22\ub1a0\ua723\u148b\ua7cf\u82a3\u7a71\uc1a7\u8180\u8668\u8195\u67b5", "\udb92\ude7b\uda00\udd0f\ud856\udc4b\uc75c\ud90b\udd37\ud859\udeac\ud879\ude10\udbb1\udcf1\ud8cd\udd93\ud845\udd64\ud8f8\udd3f",
        -4, 50450, -929760944, 1171109481619185024L, -77449L, true, false, (char) 65289, (char) 36043,
        Double.longBitsToDouble(0x3fe27d3295a79c55L), Double.longBitsToDouble(0x3fdd433938eac39aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 1, "\ud9d9\udca5\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\udae6\udd2f\uda4a\ude43\ud98f\ude9e\ud931\udcdb\ud97a\uddc1\ud9cf\ude73\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udeda\ud937\udfc6\ud833\ude5f\ud904\udc1f\ud94b\udf3d\udb0f\uddb1\ud885\udd89\uda42\udf5d\ud93f\udfdc\ud8e1\udc90\udb85\udf7b\udaa2\udc85\udb91\udcc1\uda93\udea6\uda0f\udc59\udbe4\udc60\ud9b6\udeab\ud93d\udc4e\uda86\udd30\ud864\udc48\udbe0\udc87\ud9ad\udffd\ud85d\udd82\udbbe\uddc3\ud9bf\uddba\u88f9\uda82\udd7d\ud9df\uded7\ud9a5\ude0d\udb92\ude7b\uda00\udd0f\ud856\udc4b\uc75c\udb76\udd70\ud82b\udc70\ud879\ude10\udbb1\udcf1\ud8cd\udd93\ud845\udd64\ud8f8\udd3f\udba2\udf34", "\u5c8f\u9d35\u187a\u2843\u99c3\ucb2b\u0af0\u202f", "\ud859\ude3a\ud9c9\udf87\ud9d1\udc9c\ud887\udedd\udafc\udc66\uda73\ude5a\ud88b\udca3\ud993\udfef\ud889\udfa1\udabd\udfc1\udab8\udd6c\ud941\udf33\ud86d\ude65\uda9e\udd10\u67c6\udbff\udfac\ud9ae\ude0e\uda29\uddcf\ud9a8\udcc9\udb0a\ude13\ud91d\udff8\udaf0\udfdd",
        23, 75532, -866270452, 3237464465985671701L, 2684L, false, false, (char) 58894, (char) 30790,
        Double.longBitsToDouble(0x3fead62b245a977bL), Double.longBitsToDouble(0x3fe1e2d4eef43f48L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:1B\0121=java.lang.String:1B\012",
        Z.run(T, 2, 3, 3, 4, "\ud9d9\udca5\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48", "\u775b", "\u38b1",
        27, 14044, -2056370323, 4765482724210719302L, -79830L, true, true, (char) 54719, (char) 27166,
        Double.longBitsToDouble(0x3fea1cd2b2353d22L), Double.longBitsToDouble(0x3fd2da1d9575296aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 6, 6, 3, "\udb23\ude60\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\u8f48\ucd19\ud874\udd13\ud85c\udda1\ud9bf\ude61", "\u5575\u7a84", "\udb27\udc71\udaa7\udf01\udb2c\udc21\ud97a\uddc1\ud9cf\ude2a\ud8e4\udee6\uda48\uddaf\uda49\udce0\ud925\udf52\ud937\udfc6\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b\udaa2\udc85\uda1b\udebc",
        15, 73567, -1869121191, -1709694852772888809L, 62208L, false, true, (char) 37524, (char) 15509,
        Double.longBitsToDouble(0x3fde435b8ebc7828L), Double.longBitsToDouble(0x3fde2570d003194eL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.String:\u00ee\u6700 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.String:\u00ee\u6700 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 1, 6, 6, "\u00ee\u6700", "\u4648\ub2eb\u6362\u775b\u6bd8\u22de\000\u54e5", "\udae6\udd2f\uda4a\ude43\ud83c\ude02\ud931\udc17\ud805\udcfe\ud9cf\ude73\ud8e4\udee6\ud924\udedd\ud945\udff8\ud9b8\udfab\ud937\udfc6\udb0f\udc9f\uda2c\udeff\ud835\ude2c\ud8f1\udc80\uf7e1\uda6e\ude65\ud9a9\udd58\ud90d\udf84\ud9f1\ude82",
        29, 17853, -1389001490, 2950103799850039641L, -83528L, false, true, (char) 56546, (char) 57385,
        Double.longBitsToDouble(0x3fe307230d8fb2efL), Double.longBitsToDouble(0x3feb1ccc8375285cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Integer:28 |a2=java.io.StringWriter:\"\ud9d9\udca5\ud823\ude53\ud911\uddff\udb40\ude2d\udad9\udc98\ud83f\udc39\ud874\udd13\015\ud9bf\ude61\ud8c1\udd5a\ud9e7\udd1c\udb05\udefa\u1f98\uda25\ude2b\u654a\000\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 2, 2, "\ud9d9\udca5\ud823\ude53\ud911\uddff\udb40\ude2d\udad9\udc98\ud83f\udc39\ud874\udd13\015\ud9bf\ude61\ud8c1\udd5a\ud9e7\udd1c\udb05\udefa\u1f98\uda25\ude2b\u654a\000", "", "\ud8e4\udee6",
        0, 24792, -290116307, 31538943536922624L, -49888L, false, false, (char) 19497, (char) 2109,
        Double.longBitsToDouble(0x3fd77a551012d032L), Double.longBitsToDouble(0x3fde6c5212719d4aL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:0\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 1, 5, "\ud9d9\udca5\udb61\udfdc\udb90\udeeb\udb2d\udcae\u8f48\ud833\udedc\ud874\udd13\015\ud9bf\ude61\ud8c1\udd5a\u38b1\udb11\udee7\u1f98\uda25\ude2b\uda6d\uddb3\"", "", "\ud8e4\udee6",
        0, 24792, -1800065747, 934257885184L, -49888L, false, false, (char) 19497, (char) 2109,
        Double.longBitsToDouble(0x3fe7956a8ecf61e1L), Double.longBitsToDouble(0x3fc7ef9e7255ed20L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:28 |a2=java.io.StringWriter:\"\udb71\udef1\udb61\udf15\udb90\udeeb\udb2d\udcae\u8f48\ud833\udedc\ud874\udd13\015\ud835\udc7a\ud8c1\udd5a\udadc\udeb2\udb11\udee7\u1f98\ud91c\udf26\ud884\uddc6\"\"\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 5, "\udb71\udef1\udb61\udf15\udb90\udeeb\udb2d\udcae\u8f48\ud833\udedc\ud874\udd13\015\ud835\udc7a\ud8c1\udd5a\udadc\udeb2\udb11\udee7\u1f98\ud91c\udf26\ud884\uddc6\"", "", "\ud8e4\udee6",
        0, 24792, -1800065747, 934257885184L, 15648L, true, false, (char) 40330, (char) 38748,
        Double.longBitsToDouble(0x3fedcf1aa6cf3e8cL), Double.longBitsToDouble(0x3fc7ef9e7255ed20L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 6, 0, 6, "\ud9d9\udca5\ud9b5\udf5d", "\u7656\u4d4a", "\ud9bf\ude61\udb4b\udd5f\u0f79",
        22, 35804, 663415767, 4765482724210719302L, -79830L, true, true, (char) 54671, (char) 27166,
        Double.longBitsToDouble(0x3fd439a5643c810eL), Double.longBitsToDouble(0x3fd275dd9cdf9668L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 2, "\ud917\udfe5\ud9f7\udcbd\udb90\udeeb\ud9fc\udfb9\uda53\udd60\ud833\udfb2\ud977\uddd5\ud85c\uddac\ud9bf\ude61\ud8c1\udd5a\u4e4a\udb11\udee7\uda01\ude13\uda0c\udc9b\udae6\udd2f\uda4a\ude43\ud83c\ude02\uda05\udf8f\udbd2\udc95\ub938\ud913\udec5\ud9a6\udd68\ud8a1\udd3b\udbdb\udd6b\ud937\udf51\ud833\udea9\ud904\udc1f\udace\udd52\udbb1\udd5f\udaa2\udd8e\uda6e\ude8d\ud82f\udf93\ud89e\udd52\ud852\uddf5\udb7d\udd00\ud8a3\udd09\uda7c\uddc8\uda89\udf6a\ud8bc\udec8\udb99\udfa0\ud942\udd89\uda20\udd16\uda46\udef3\ud81c\udd08\ud9ad\udffd\ud85d\udd82\udb5c\udf93\ud889\udc03\udaa2\udccb\udae4\udf2a\udb3f\ude4a\ud858\uddb7\udba1\ude8a\udaa3\udccd\ud9c1\uddf4\ud996\udd84\ud807\ude7b\udaaa\udc1a\uda49\udfba\uda7a\udffc\ud8ea\udcea\ud9d9\udcfc\ud96b\udc3d\uda4f\udf33\uda1c\udc8f", "\u8623\ud768\uc8dd\u743c\u76e2\uc3d8\u1206", "\u654c\udb0a\udd20\udbbb\udfdf\udb2a\udc44\udafa\udd56\ud9ea\uddb9\udb5c\uddf6\ud92d\udead\uda2b\udf6d\udba2\udd5a\ud9f7\udf25\u87b7\udbdc\udd78\ud93f\udebe\udb55\udd9f\uda3f\udf9e\ud9ab\udc8f\ud929\udd4a\udbe7\udf6e",
        38, 52794, -1579671146, -8884418268901970420L, 88232L, true, false, (char) 38369, (char) 40587,
        Double.longBitsToDouble(0x3fd38b372f317202L), Double.longBitsToDouble(0x3fecb478d3c41779L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |a1=java.io.StringWriter:\ue5ec\u797d |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\ue5ec\u797d |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ue5ec\u797d", "\u911b\u141b\u8b47\u775b\u6bd8\u22de\u48b0\u7dff\u2826\u46e0\u03ac", "\udb5b\ude3a\udbe0\ude39\ud9cf\ude1b\ud8e4\udee6\ud924\udedd\uda49\udca8\ud925\udf52\uda52\udf3d\ud833\ude5f\ud904\udc1f\udace\udd52\uda8a\udc8a",
        44, 35246, -1907229578, -7924132746495204209L, -57317L, false, true, (char) 45427, (char) 10091,
        Double.longBitsToDouble(0x3fe9cf86920580d8L), Double.longBitsToDouble(0x3fe735dbe1a07bbaL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 1, 4, 1, 6, "\ud9d9\udca5\ud913\udc26", "\ud542\u0ceb", "\ud9bf\ude61\udaae\udc7a\u0f79\udb11\udee7\u1f98\uda23\udd2b\udae6\udd2f\uda4a\ude43\ud915\udecc\udbbe\udd12\ud97a\udd35\ud969\udca0\uda3f\udfc9\ud851\udd42\uda49\uded6\uda18\ude2a\ud851\udfb2\ud88d\udf6e\udaa0\udcf4\ud996\ude0f\udb93\uddcd\udb93\udca2\ud885\udc9f\ud92e\udf11\udb9d\udc04\ud92f\udf1d\ud82a\ude38\udbb6\udc34\ud9b3\udc50\udba2\udd89\ud824\udde9\udae1\ude58\uda7e\udf80\ud881\ude7f\ud9df\udfef\udb0d\udc96\ud9e4\udc6b\uda93\udec2\uda35\udfca\ud9e5\udced\ud9d2\udcd1\ud8fb\udc78\ud850\udf8e\ud91d\ude44\udb00\udf9b\udbf0\udce2\ud8e8\udd59\ud98e\udc96\ud8bc\udc9f\ud865\uddfd\ud92d\udc1c\udb86\udee0\ud95a\udf6b\ud8b0\uddd1\ud91c\udf3c\ud8ab\udeda\ud964\udd54\ud844\udf37\udb89\udc2b\uca14\udbb0\ude19\ud964\udda4\uda41\udee6\ud859\udf2a\ud807\udd1b\udbc2\udd25\ud9e3\udd5c\uda06\uded9\u8774\u4b24\udbdf\udc3f\uda72\uddac\ud943\udde2\uda68\udf22\ud8c7\udf03\udbae\ude51\udb80\udf51\ud997\ude9c\ud99c\udf8e\udab3\udc41\ud859\ude2f\udb54\udd2d\uda0c\udd26\udb8e\udf54\udbce\udc30\uda0d\udf9a\uda46\udd4e\udac7\udfd9\udb0d\udc4a\ub22b\ud868\ude13\uda07\udd32\ud859\udc8f\udbb4\ude81\ud870\udfcf\ud824\udd73\ud8a2\udcc0\udb75\uddf3\udb62\udf45\ud97b\udcf5\udb47\ude49\udb77\udf89\ud92d\uddf7\udb13\ude02\ud86d\udc96\ud838\udd19\udb2c\udeec\udbb6\udd3d\uda70\ude7e\ud97b\udc39\udb98\udd02\u4511\uaf41\udb3c\udf93\ud906\udd19\udbd6\udf5f\udaa3\udce3\ud89e\udf86\ud9f3\udfc3\ud911\udf60\ud838\udc0f\udb6a\udd2e\ud8c9\ude31\ud953\udee3\udb1a\uddfd\uda45\udf87\ud8bf\udf46\udbd3\udd80",
        2, 92449, 1220517510, -5042867799429221967L, 43231L, true, true, (char) 55380, (char) 6085,
        Double.longBitsToDouble(0x3fe8946deb192ed4L), Double.longBitsToDouble(0x3fb83bdcb362c620L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 0, 6, "\015\000\udb90\uddf2\ud9fc\udfb9", "\u6362\u775b\u6bd8\u22de\000\u54e5", "\udae6\udd2f\uda4a\ude43\ud83c\ude02\ud931\udc17\ud805\udcfe\ud9cf\ude73\ud8e4\udee6\ud924\udedd\udb3c\ude0c\udbea\udcaf\ud88d\udcc2\ud833\ude5f\ud904\udc1f\udace\udce0\uda8a\udc8a\uf7e1\uda6e\ude65\ud93f\udfdc\ud8e1\udc90\udb85\udf7b",
        3, 17853, -1389001490, 2950103799850039641L, 47544L, false, true, (char) 56546, (char) 57385,
        Double.longBitsToDouble(0x3fd60e461b1eef68L), Double.longBitsToDouble(0x3feb1ccc8375285cL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 2, "\ud9d9\udca5\uda8a\udd06", "\u4648\u27f4", "\udb1f\udf11\ud9c8\udc45\uda6d\udec7\udb11\udedf\u1f98\uda25\ude2b\ud936\udf78\uda4a\udeaa\ud83c\ude02\ud931\udc17\ud97a\uddc1\ud9a5\udf73\ud8e4\udee6\udb22\udedc\uda49\udca8\udb18\udce0\ud937\udf51\udb77\ude61\ud904\udc1f\udace\udd52\uda8a\udc8a\uf7e1\udbda\udf3a\ud955\udd82\udb16\udd62\udb85\udf7b\udaa2\udc85\ud840\udc2e\ud874\udee3\ud8c0\udc6a\ud8bc\udec8\ud8f7\ude0d\ud93d\udc4e\uda20\udd16\ud836\udf42\udbe0\udc87\ud998\udcfd\ud85d\udd82\ud8de\udc74\ud85d\ude27\udaa2\udccb\udb61\ude87\uda4c\udd85\ud849\udfcb\ud8b5\udc25\uda14\udfa6\ud8d3\udfdc\uf816\ud9f2\udd14\ud98e\udf3a\uda1b\ude54\ud9cc\udf36\udab6\ude92\ud956\udf83\udaaf\udd63\ud9fd\udfa7\udb76\udc8f\uda69\udfca\udac8\ude75\ud96e\udd81\ud96d\uddb5\ud843\udfee\ud8a7\uddcf\ud80f\udd94\udb0c\udefc\ua2ad\ud8bb\udc1f\udae1\ude5a\ud896\udd84\udb56\uddeb\ud961\udda6\ud844\udd4e\ud909\udd57\uda5a\udd72\udba4\udd46\ud8f3\udfea\uda20\udd4d\ud992\udf08\udbb7\udd57\udb2c\udeec\ud822\udfc7\ud96b\udd11\udbcd\udc05\ud8a0\ude31\ud84a\udda3\udb4a\ude5a\ud9a5\udc1e\u1907\ud85e\udfcc\udabe\udf5b\udadb\ude53\udb9d\udd3e\udab7\ude05\udb13\ude89\uda5b\udf0d\udbbc\uddcf\udb62\udde3\udaf5\udef7\ud8da\uddfc\ud8ec\udefd\udbfa\udeae\ud81b\udc02\ud82e\udfd3\uda7a\udceb\udaf5\uddb8\ud9d8\udea3\udafa\uddc5\ud8ae\udede\udbf4\ude86\ud951\udc59\ud905\udec2\ud8a5\ude9a\uda42\udd23\ud982\udcc2\udab7\ude01\udac1\udfb0\uda52\udf37\ud9b3\uddfa\uda02\udca2\udaae\uddfe\ud8b6\udd94\ud865\ude67\ud89f\ude44\ud9f8\ude0a\udbdd\udcff\ud8ca\uddfc\ud97e\udc1a\ud8a3\ude63\ud938\udf47\udad4\udd67\ud897\udf46\ud9df\udd65\udb2e\ude81\ud837\udf15\ud9dd\udeae\ud870\udf6c\udb26\udef4\udb8a\ude70\ud925\udd74\ud896\udf80\uda75\ude7c\ud9c0\ude74\udab7\udc0c\ud80d\udc05\udbdd\udeea\ufd28\udaaa\udfe9\ud892\udf43\udb62\udf42\udbb2\udf51\ud9b2\udf2e\ud837\udc2c\ud959\udd88\udb5e\ude3a\ud8ef\udcf1\ud807\udf7c\udad2\udc8e\ud8b5\udd7b\ud87b\udeda",
        -4, 99695, 707443548, -8938069454850833297L, -39066L, false, true, (char) 35957, (char) 63293,
        Double.longBitsToDouble(0x3fe5c196c1a7e5fbL), Double.longBitsToDouble(0x3fe67f055b56782dL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Integer:28 |a2=java.io.StringWriter:\"\udb71\udef1\udb61\udf15\udb90\udeeb\udb2d\udcae\u8f48\ud833\udedc\ud874\udd13\"\"\ud835\udc7a\ud8c1\udd5a\udadc\udeb2\udb11\udee7\u1f91\uda13\udecd\ud884\uddc6\"\"\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 5, "\udb71\udef1\udb61\udf15\udb90\udeeb\udb2d\udcae\u8f48\ud833\udedc\ud874\udd13\"\ud835\udc7a\ud8c1\udd5a\udadc\udeb2\udb11\udee7\u1f91\uda13\udecd\ud884\uddc6\"", "", "\ud8e4\udee6",
        0, 33360, -1803390629, 934257885184L, 15648L, true, false, (char) 62244, (char) 10965,
        Double.longBitsToDouble(0x3fedcbe7c6cf3e8cL), Double.longBitsToDouble(0x3fc7ef9e7255ed20L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 2, 2, "\ud9c0\udfa0\ud807\udfc6\udb90\udeeb\ud9fc\udfb9\ud97d\udd7d\ud833\udedc\ud874\udd13\ud85c\udda1\ud9bf\ude61\ud8c1\udd5a\u38b1\ud851\uddc7\u2e4b\udaf9\udd39\udace\udcc4\uda4a\ude43\ud9ce\udfca\ud931\udc83\ud97a\uddc1\ud997\udd18\ud8e4\udee6\ud924\udedd\uda49\udca8", "\u1d17\u3c1c", "\ud885\udd89\uda42\udf5d\ud93f\udfdc\ud8e1\udc90\udb85\udf7b\udaa2\udc85\udb91\udcc1\uda93\udea6\udaa2\udfa2\udbbf\udea3\ud9b6\udeab",
        52, 81854, 1065522314, 8835967144647585316L, 51886L, false, false, (char) 17154, (char) 65384,
        Double.longBitsToDouble(0x3fddec894b002080L), Double.longBitsToDouble(0x3fe8232807e9953cL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 2, 1, "\"\ud89c\ude2d", "\u472a\ub2eb\u9bfd\u775b\u6bd8\u22de\000\u54e5\u7a84\u8320\u03ac\u7215", "\ud805\udcfe\ud9cf\ude73\udb2e\ude56",
        30, 49954, 1677650515, 1340800375269251148L, 64891L, true, true, (char) 55281, (char) 29062,
        Double.longBitsToDouble(0x3fd63ad6a3f14476L), Double.longBitsToDouble(0x3fef896039b93c1cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,int,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|hex|int|static",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|with|[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,int,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
