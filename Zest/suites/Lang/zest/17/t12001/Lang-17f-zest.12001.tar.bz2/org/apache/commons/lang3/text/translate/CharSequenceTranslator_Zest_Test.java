package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class CharSequenceTranslator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u7a2d\u6cb2\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\udb15\udfd7\ud894\udc33\ud808\udc04",
        10, 84327, 705429957, 8459050911732637330L, 70747L, false, false, (char) 28402, (char) 11125,
        Double.longBitsToDouble(0x3fcbbadb773bca54L), Double.longBitsToDouble(0x3fefbd0e5b8c000fL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9fb\ude63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u214f\u70e0\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b",
        41, 42791, -1455930123, 8583888574515792426L, 61307L, true, false, (char) 49104, (char) 28402,
        Double.longBitsToDouble(0x3fefccdbe4ddd6dbL), Double.longBitsToDouble(0x3fdcef295fef4396L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\udabd\ude26\ud932\udd72\udb42\uddfc\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8b5\ude65\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud984\udd1e\ud965\udf3e\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u7a2d\u6cb2\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\udb15\udfd7\ud92a\uddb3\ud808\udc04",
        10, 75127, -1901471789, -8602915656146051438L, 70747L, false, false, (char) 28402, (char) 11125,
        Double.longBitsToDouble(0x3fcbbadb773bca54L), Double.longBitsToDouble(0x3feeaef38e52890fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\uda6f\udccd\ud949\udc69\udb5f\udd37\ud860\uddb7\udaba\udd37\ud938\udef0\ud8c9\udd60\ud96a\udc47\ud9cb\udcb0\udbd8\udf0f\udb54\udf46\ud8a9\udc49\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\udb6d\udd7c\udb29\udcae\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\udadf\udcb1\ud87b\udcf7\uda72\ude75\uda37\ude51\udbaa\uddac\udb27\udce1\uda3c\udf5e", "\u53cb\u3be7\ucdd1", "\ud882\udc76\ud9c9\udcd1\ud9d3\udf6b\udb7c\udedd\uda6b\udcb2\uda8c\udef9\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\ud825\udfdf\ud894\udc33\ud808\udc04\udad4\udd42\ud9ce\ude59\ud937\udc3f\ufce7\ud863\uddce\ud885\udced\ud9a3\udc59\ud944\udef1\uda37\udcc9",
        14, 71485, -1592765290, 4441987965899660L, -23417L, false, false, (char) 44442, (char) 17922,
        Double.longBitsToDouble(0x3fdadd21c795e606L), Double.longBitsToDouble(0x3fe9a34b99d23974L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 0, 3, "\ud842\udf2f\ud9d3\ude7b\ud9a3\udd9f\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udacb\udd55\ud89b\ude85\ud831\udeaa\uda02\udd38\uc7a4\udb10\udcc4\uda87\udebe\uda53\udd1f\udaa8\udfc4\udbbf\udf93\ud927\udd06\u0b38\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\uddd6\udb1e\udce3\ud955\udc43\udb27\udcf3\uda55\uddef", "\u3b64\u3be7\ucdd1\u7a2d\u6cb2\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud8d2\udc84\u12c5\udb15\udfd7\ud894\udc33\ud808\udc04",
        10, 84327, 705429957, 8459050911732637330L, 70747L, false, false, (char) 28402, (char) 11125,
        Double.longBitsToDouble(0x3fcbbadb773bca54L), Double.longBitsToDouble(0x3fefbd0e5b8c000fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 3, 6, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06", "\ua996\u86df\u4539\u6d5f\u5b1e\u647d\u6e1e\u57d7\uba7e\ud57b", "\uda5e\ude7c\uda5e\udf48\ud8ef\ude98",
        35, 30266, -1311589651, 2422991568606125383L, -35466L, false, false, (char) 38182, (char) 4447,
        Double.longBitsToDouble(0x3fb17f648e22c870L), Double.longBitsToDouble(0x3fa33390b5b6f500L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 1, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud9ff\uddf6\uda0b\udf24\ud9d5\ude4b\udbd8\udf0f\u05bd", "\u5083\uc6a2\u483d\u4817\u5f04", "\ud977\udf47\udba0\uddb3\udbc6\udd8d\ud93c\uddc8\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb80\udfb0\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c\ud87e\udda8\udbd8\udf07\ud9aa\udffd\ud951\udea3\uda22\udd84\ud94f\udf09\udae3\udfe4",
        1, 89715, 420902385, 1160057246397687643L, -43879L, false, true, (char) 48281, (char) 39237,
        Double.longBitsToDouble(0x3fd2ea938454ee40L), Double.longBitsToDouble(0x3fbbf6e3113c3240L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:33\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 0, 3, "\ud892\udd17\udb92\udf16\ud99b\udda2\ud94e\udfb6\ud949\udc56", "\uc608\ua0e5\u4291\u531e\ub3eb\ucdf9\uaae6\u54ff\u9349\u8317\uc6a2", "\ub985\udb6b\udf9e\udbda\udee9\uda80\udce8\ud8f2\ude24\udb88\ude97\ud95d\udc2f\ud893\uddd0",
        51, 73837, 1041370091, 8611930473533559502L, 6990L, true, true, (char) 2720, (char) 1462,
        Double.longBitsToDouble(0x3fe76cb861feb1d2L), Double.longBitsToDouble(0x3fd8bfaa0868f910L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:6\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 1, 6, "\uda96\udfda\udb14\udf3e\ud930\udd1e\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69", "\uaae6\u54ff\u9349\u5083\uc6a2", "\ud8e8\udc44\ud84c\ude7e\ud8bf\udc66\udae1\udeff\uda56\udfae\udb34\udc36\uda79\udd76\ud95d\ude47\udb10\udc1b\uda42\ude85\udb97\udf9d\uda55\udebc\uda49\udead\uda5e\ude7c\uda5e\udf48",
        6, 190, -1760802734, 3518079785914442167L, 69012L, false, true, (char) 37413, (char) 38182,
        Double.longBitsToDouble(0x3fe64554b445fd92L), Double.longBitsToDouble(0x3fec32c873d43b9dL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\udb66\udd45\udb7e\udee6\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338", "\u86df\u4539\u6d5f\u6133", "\udb10\udc1b\udaa8\ude98\ud995\udf93",
        49, 93268, -596493163, 1655532382467365781L, 69012L, false, true, (char) 37413, (char) 38182,
        Double.longBitsToDouble(0x3fe64554b445fd92L), Double.longBitsToDouble(0x3fec32c873d43b9dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:A\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 4, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\u7c00\uda8c\udf5d\ud85a\udfa6\uda54\uddf2\ud9ee\udd9d\u3949\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\udb1a\udf49\uda46\udc02\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u7a2d\u6cb2\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\udb15\udfd7\ud894\udc33\ud808\udc04",
        10, 84327, 705429957, 8459050911732637330L, 70747L, false, false, (char) 28402, (char) 11125,
        Double.longBitsToDouble(0x3fcbbadb773bca54L), Double.longBitsToDouble(0x3fefbd0e5b8c000fL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\000 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\000 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 1, 2, 4, "\000", "\ucd67", "\ud860\udd09\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\ud997\uddef\u04da\ud8a8\udf92\u5574\udaa8\udfc4\u8b65\000\ud82d\udcd5\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\uda77\udd7b\ud995\udf93\udb0e\ude52",
        53, 11837, 385458670, 3683834083347223646L, -100000L, false, true, (char) 55339, (char) 4284,
        Double.longBitsToDouble(0x3fef5664d072d9b3L), Double.longBitsToDouble(0x3fd06a420d91552cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\ud97a\ude44\ud986\udd90\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda21\udd6a\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u8b34\u3be7\ucdd1\u7a2d\u6cb2\u720e", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\udb15\udfd7\ud894\udc33\ud8ef\udcd8\udad4\udd42\ud9ce\ude59\ud937\udc3f\ufce7\udba0\udf6e\ud885\udd54\ud9a3\udc59\ud944\udef1\uda37\udcc9\ud90b\udd8c\uda59\udc12\udb18\udc40\udbb3\udff7\udac9\udf15\uc9b2\udbd8\udd0b\ud96b\udf66\uda7d\ude4b\ud8b1\ude44\ud9bd\udefe\udbc8\udc5c\udb67\udd1a\ud98e\udf87\ud9e5\udfb4",
        50, 76515, -1682700184, 2894233564665343676L, -62035L, false, false, (char) 28044, (char) 14011,
        Double.longBitsToDouble(0x3fde896c8b0fd98aL), Double.longBitsToDouble(0x3fedb67424f84bebL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 5, 3, "\udad2\ude88", "\000\ud782\ub1a5\uca65\u01d3\u68cb\u9d1c\u9b71\ub3eb\ucdf9\uaae6\u54ff\u9349\u5083\uc6a2", "\udb29\udce2\u2bb0\000\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47",
        42, 73837, 1041370091, 1450925591037760212L, 55154L, true, true, (char) 34685, (char) 1462,
        Double.longBitsToDouble(0x3fe76cb861feb1d2L), Double.longBitsToDouble(0x3fd8bfaa0068f910L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 2, 0, "\ud892\udd17", "\u445a\ub2eb\ub1a5\uca65\u01d3\u68cb\u9d1c\u9b71\ub3eb\ucdf9\uaae6\u54ff\u9349\u3097\uc63d", "\udb29\udce2\u2bb0\000\000\udba0\uddb3\ud89c\udc2a\uda79\udd76",
        12, 1052, -716520163, 4472650484215363875L, 46581L, false, true, (char) 45709, (char) 34685,
        Double.longBitsToDouble(0x3fb4af58d76cb860L), Double.longBitsToDouble(0x3fdfeb1d2b17f540L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.String:29\012",
        Z.run(T, 2, 1, 3, 3, "\uda6d\udee5\udb1a\udd98\ud986\ude16\ud94e\udf4f\ud949\udc56\udb2b\udddd\ud860\udde2\ud955\ude45\udba0\udde0\ud933\udd08\ud8c8\udd6f\udb81\ude45\udbd8\udf0f\u04ef\udafd\udd08\udbe8\udca4\udb3d\uddae\udb59\udc44\udadb\udfb5\udb72\ude51\udb29\udcc3\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddef\ud89c\udc6e\uda79\udd76\uda4d\uddbf\ud8c7\udc88\udb11\ude32\udbc4\udf69\ud93d\udefe\ud9c5\udc7e\uac2a\udab8\uddbf\ud8ef\udeaf\udad2\udf1b\udbb0\udeb1\ud8e5\ude63\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53ea\u3be7\u61f5\u7a2d\ua914\u8f24\u347d\ucbac\u8cff\ud2cb\uc912\ub6da\u6779\ub279\uc30b\ub924\u19f4\u0ca0\u5b69\ub032", "\udbc2\uddc9\ud863\uddf2\ud885\udced\ud9a3\udc59\ud944\udef1\uda37\udcc9\ud90b\udd8c\uda59\udc12\udb18\udc40\udbb3\udff7\udb70\udc69\ud916\udf9e\udb8e\udc73\ud8da\udf7d\udae5\udda3\ud800\ude48\ud9b4\udd0b\ud81a\udd91",
        41, 84312, -1917753712, -6449789053872203558L, -37157L, false, true, (char) 45124, (char) 34148,
        Double.longBitsToDouble(0x3fe661d6d45f1afcL), Double.longBitsToDouble(0x3fcc5ce3d8aab474L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7", "\u9d1c\u9b71\ub3eb\ucdf9\uaae6\u54ff\u9349\u5083", "\u9338\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udb0a\ude30\u167b\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48",
        6, 190, -1760802734, -5633234656907218434L, 69012L, false, true, (char) 37413, (char) 38182,
        Double.longBitsToDouble(0x3fe64554b445fd92L), Double.longBitsToDouble(0x3fec32c873d43b9dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2", "\ub1a5\uca65\u01d3\u68cb\u9d1c\u9b71\ub3eb\ucdf9\uaae6\u54ff\u9349\u5083\uc6a2\u483d\u4817\u5f04\ua996", "\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\ud972\udd59\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c\ud87e\udda8\udbd8\udf07\ud9aa\udffd\ud951\udea3\uda22\udd84\ud94f\udf09\udae3\udfe4\ud882\udc76\ud9c9\udcd1\ud9d3\udf6b\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\udb15\udfd7\ud894\udc33\ud808\udc04\udad4\udd42\ud9ce\ude59\ud937\udc3f\ufce7\ud863\uddce\ud885\udced\ud9a3\udc59\ud944\udef1\uda37\udcc9\ud90b\udd8c\uda59\udc12\udb18\udc40\udbb3\udff7\ud8e8\udec5\uda68\udedc\uda33\udfbf\uda65\udc7c\uda3d\ude90\uda87\udd2d",
        -5, 34187, 1419441444, -4080021431582475552L, 57051L, true, false, (char) 56104, (char) 42852,
        Double.longBitsToDouble(0x3feadaed082074f5L), Double.longBitsToDouble(0x3fc8f017d8740364L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 0, 3, "\ud892\udd17\udbdd\udddb\uda8b\udd29\udbab\ude96\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd04\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\uda32\uddcd\ud9a5\udc4f\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\ud89c\udc2a\ud98f\udda0\ud9be\ude1a\uee73\uda86\uddf3\ud995\udf93\udb0e\ude52\uda49\udead\ud95f\udc59\uda5e\udf30\ud8ef\ude98\uf071\ud9e4\udcda\uda26\udfc3\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u2b29\u850a\ua05f\u7a2d\u6cb2\uc1d0", "\udb7c\udedd\uda6b\udcb2\uda62\ude44\ud9d6\udea2\udae7\udc69\ud7ed\u0e8d\u3deb\udb15\udfd7\udace\udd11\ud8c0\udc4c",
        10, 50455, 997798122, -970621783172145518L, 69467L, false, false, (char) 28402, (char) 11125,
        Double.longBitsToDouble(0x3fdd300dbb0dbf5aL), Double.longBitsToDouble(0x3fefbd0e5b8c000fL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62", "\ud782\ub1a5\uca65\u01d3\u68cb\u9d1c\u9b71\u1696\u6d58\u509e\u54ff\u9349\u5083\ub572", "\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3",
        48, 64690, -1781166197, -1560003228272661116L, 46581L, false, true, (char) 45709, (char) 31739,
        Double.longBitsToDouble(0x3fb4af58d76cb860L), Double.longBitsToDouble(0x3fdfeb1d2b15f540L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 1, 6, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud90c\udfb5\ud949\udc56\udb5f\udd37\ud890\udf19\udaba\udd37\udb42\uddd1\udab0\udc49\ud96a\udc69\ud968\udce6\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\ud8cd\udc0b\ud829\udf57\ud8ea\udebe\ud9f4\udf63\ud977\udf47\uda18\ude4e\ud934\udd11\uda42\udea9\ud817\udc68\udb10\udc1b\udaa8\ude98\ud995\udf93\ud84a\uddb1\ud81d\udd63\uda9c\uddc3\uda5e\udf48\udbd2\udc9d\uf071\u2d36\uda37\udd8e\udbc6\udfac\udb27\udce1\ud9ec\ude04", "\u5434\u3be7\ucdd1\u6eeb\u6c29\uc1d0", "\udb7c\udedd\udaf0\udfac\udad3\udf9d\uda1d\ude2a\udb77\udc11\uda94\udfe3\ud995\udd98\u122f",
        -3, 3302, -611562966, -8770557487367019993L, 3932L, false, true, (char) 42563, (char) 51089,
        Double.longBitsToDouble(0x3fbd3bcad5b33cc8L), Double.longBitsToDouble(0x3fdf99b7c35cf778L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 0, 3, "", "\000", "",
        51, 69798, 1912602624, -4672029811258901713L, -64315L, true, true, (char) 14454, (char) 10591,
        Double.longBitsToDouble(0x3fed832aaba077baL), Double.longBitsToDouble(0x3fe2efdfef5f5369L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\000 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 0, 3, "\000", "\ucd67\u0d70\u0367\uca65\u01d3\u68cb\u9d1c\u9b71\ub3eb\000\uaa03\u54ff\u9349\u5083\uc6a2", "\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\udb95\udf47\uda79\udd1c\ud95d\ude47",
        25, 73837, 1041370091, 1450925591037760212L, -100000L, true, true, (char) 34685, (char) 1462,
        Double.longBitsToDouble(0x3fe76cb861feb1d2L), Double.longBitsToDouble(0x3fd8bfaa0868f910L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37", "\u68cb\u9d1c", "\udbd8\udf0f\u05bd\ud8a8\udf92",
        -5, 7991, -1086551195, -8495420601157702052L, 42089L, false, false, (char) 32346, (char) 13000,
        Double.longBitsToDouble(0x3fea34fe865a0f20L), Double.longBitsToDouble(0x3fec5f8769ccea8cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\ud97c\udec6\ud94b\ude23\udaed\udc71\ud8a5\udf3d\ud95d\uddf5\ud96a\udc69\uda54\udfaa\ud87c\udf62\uda9b\ude01\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udbcd\udeac\ud8ea\ude4e\ud9fb\ude63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\ud813\udf71\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\ubbed\u70e0\uc1d0", "\udb7c\udedd\uda6b\udcb2\udb31\udfac\ud8fe\ude0c\udbf8\uddbd\uc17b",
        41, 88439, -175783591, 8583888574515792426L, 50572L, false, false, (char) 5109, (char) 51630,
        Double.longBitsToDouble(0x3fed125e1ab62ce5L), Double.longBitsToDouble(0x3fefccdbe4ddd6dbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud99d\udec5\udbf2\udec9\udb05\udcdc\udbed\udede\u05bd\ud8a8\udf92\udb79\udcb8\udb3d\udee6\udbac\udd63\ud927\udd06\u9338\udb29\udce2\udaa0\ude04\ud8af\udcc2\ud977\udf15\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u214f\u70e0\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b",
        41, 42791, -1455930123, 8583888574515792426L, -71321L, true, false, (char) 49251, (char) 27074,
        Double.longBitsToDouble(0x3fe6b8f0ff7aaaf6L), Double.longBitsToDouble(0x3fef82c5958097d0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:29\012",
        Z.run(T, 1, 3, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\uda24\uddef\uda46\udc2e\ua034\udbc0\udc1a\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9fb\ude63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u214f\u70e0\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b",
        41, 42791, -1455930123, 8637087345114106410L, -12291L, false, false, (char) 11103, (char) 35768,
        Double.longBitsToDouble(0x3fdcef295fef4396L), Double.longBitsToDouble(0x3fd5a2b5177cef6cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\u5e35\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9fb\ude63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda8e\udf40\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\u9e69\u98c0\u70e0\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\udbbc\udc5c\uda94\udfa0\ud995\udd98",
        58, 44413, 1998592302, -8463308057528977336L, -99547L, false, false, (char) 5133, (char) 61663,
        Double.longBitsToDouble(0x3fb7adaf82b47f58L), Double.longBitsToDouble(0x3fe5b161e66a9b7cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:30\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 4, 4, "\udb60\udcc5\ud9d7\uddfc\udbaa\udda4\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\ud8ba\udc7d\udb34\uddc4\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\ud9e2\udf20\udbe5\uddfd\ud9e8\udf3e\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udbd1\udcfa\uda91\uddf8\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\u69b8\ue73a\udb8b\udccf\udb27\udce9\uda56\udd2c", "\u53cb\u3be7\ucdd1\u214f\u70e0\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud9b3\udf13\udafa\ude1a\ud8e6\udcd1\ud995\udd98\u122f\udb15\udfd7\ud894\udc33\ud808\udc04\udad4\udd42\ud9ce\ude59\ud937\udc3f\ud96e\udf18\udb64\udd4f\ud885\udd23\ud9a3\udc59",
        48, 40726, -690253831, -966667685300810290L, -37927L, false, false, (char) 53935, (char) 46989,
        Double.longBitsToDouble(0x3fbdf661c17f3658L), Double.longBitsToDouble(0x3feb7c853bbe27d7L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 5, 1, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9fb\ude63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\ud8e1\ude0f\udb5d\udd52\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\udab1\ude4e\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u214f", "\udb83\udc3e\udb14\udce6\udb7c\udedd\uda6b\udcb2",
        59, 58620, -223088836, -4030962702477965560L, -82347L, false, true, (char) 49482, (char) 37883,
        Double.longBitsToDouble(0x3fe13c3241c50358L), Double.longBitsToDouble(0x3fa61506692757b0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 3, 6, "\ud892\udc8c\uda14\ude56", "", "",
        -5, 13728, 0, -2314850207112395866L, 94019L, true, true, (char) 20612, (char) 55005,
        Double.longBitsToDouble(0x3fc2feed8d94d7bcL), Double.longBitsToDouble(0x3fefcdf9e05c8a1aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.String:23\0121=java.lang.String:23\012",
        Z.run(T, 2, 3, 3, 6, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud95b\udc77\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06", "\ua996\u86df\u4539\u6d5f\u5b1e\u6488\u6e1e\u57d7\uba7e\ud57b", "\uda5e\ude7c\uda5e\udf48\ud8ef\ude98",
        35, 30266, -1311589651, 1630358032013661108L, -35466L, false, false, (char) 38182, (char) 4447,
        Double.longBitsToDouble(0x3fb17f648fa97870L), Double.longBitsToDouble(0x3fa33390b5b6f500L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:0\0121=java.lang.Integer:9 |a2=java.io.StringWriter:\udba3\ude3e\ud858\ude61\ue1f9\uda36\udeb0\ud87a\udd71 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 0, 3, "\udba3\ude3e\ud858\ude61\ue1f9\uda36\udeb0\ud87a\udd71", "\u3d6e\u6f6e\u2597\u531e\ub3eb", "\ud943\udd94\udb21\udcbd\udbf0\udded\udbbf\udf93\udbfa\udd8f\u92dc",
        0, 23974, -323007898, 7337574486954412906L, -24605L, true, true, (char) 27721, (char) 43272,
        Double.longBitsToDouble(0x3fef5eaa5123bc0aL), Double.longBitsToDouble(0x3fe673bc1e954154L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 0, 0, "\000", "\ucd67", "\u61a6\ud848\udc03",
        17, 88186, 241, 5580980285102620899L, -100000L, false, false, (char) 0, (char) 35684,
        Double.longBitsToDouble(0x3fefcdf9e65c8a1aL), Double.longBitsToDouble(0x3feafa93ab0e6855L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:FFFFFFFB\0121=java.lang.String: |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 1, 1, "", "\u2520\ucd67\ud782\ub1a5\uceb8\u0fc9\ua0e5\uc9ad\000\000\u1de4\u7503\u54ff\u9349\u2a68\uc6a2", "\uab64",
        -5, 82104, 1702175470, 889726363974500444L, -100000L, false, false, (char) 58376, (char) 57653,
        Double.longBitsToDouble(0x3fd233e1259cee00L), Double.longBitsToDouble(0x3fe4aa0aa0005c00L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 4, 3, "\ud893\udc37\ud847\udd4f\ud99b\udda2\uda45\ude4a\udb9f\udd5d", "\uc654", "\udb45\udd9f",
        4, 96387, -42256925, -9121668276166224652L, -61278L, true, true, (char) 63094, (char) 39291,
        Double.longBitsToDouble(0x3fe7ad6d91e2ec2cL), Double.longBitsToDouble(0x3fe09c63016a6575L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:26\0121=java.lang.String:26\012",
        Z.run(T, 2, 3, 3, 6, "\uda96\udfda\udb14\udf3e\ud930\udd1e\ud94e\udfb6\udb93\udced\ud83b\ude95\uda5a\ude6c\uda3e\udcd3\uda99\udf4c\ud966\uddf2\ud96a\udc69", "\uaae6\u550e\u9e3c\u5040\uc6a2", "\ud8e8\udc44\ud84c\ude7e\ud8bf\udc66\udae1\udeff\uda6b\udcd9\udb34\udca5\uda79\udd76\ud95d\ude47\udb10\udc1b\uda42\ude85\udb97\udf9d\udbbd\udfcf\udb31\udf98\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\udb0a\udc78\udb9e\udd89\udaf0\udd6b\ud883\udef9\udbfe\udd96\uda56\udd2c\ud87e\udda8\ud9e5\udecd\ud83d\udfc7\ud8fd\udf60\ud84b\udc69\ud95a\udf35\ud9b4\udff2\uda05\udd74\udaa3\udda2",
        38, 98526, -1331372364, -5237638417830935976L, 78079L, false, true, (char) 14421, (char) 7017,
        Double.longBitsToDouble(0x3fc94cb9376deaa0L), Double.longBitsToDouble(0x3fd6d8f4f24ce48eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:39\0121=java.lang.String:\ua251 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 1, 6, "\ua251", "\ucd67\ud782", "\udaba\udd37",
        57, 43815, -1112738188, -2473013310776183389L, 75352L, false, true, (char) 10244, (char) 49491,
        Double.longBitsToDouble(0x3fefcdf9e6b0071aL), Double.longBitsToDouble(0x3fe214d5db2c65f6L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 4, 5, "\udaa5\udf61\udad8\udeef\u725e\ud9f3\udd7b\ud8c6\ude74\uda4b\udfed\ud860\uddb7\udaba\udd37\u7c00\uda8c\udf5d\ud85a\udfa6\uda54\uddf2\ud9ee\udd9d\u3949\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\udb1a\udf49\uda46\udc02\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda04\udeea\uda2b\udc12\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u1fce\uab11\uc1d0", "\udb7c\ude97\ud92e\udcd5\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\udb15\udfd7\ud894\udc33\ud808\udc04",
        43, 84505, -1945370171, 8459050911732637330L, 70747L, false, false, (char) 28402, (char) 11125,
        Double.longBitsToDouble(0x3feeeeb6ddcef295L), Double.longBitsToDouble(0x3fefbd0e5b8c000fL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:d |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.String:d |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 1, 1, 5, "d", "\ucd67", "\ud860\udd09\udaba\udd37\udb81\udfc5\uda10\udf8b\ud96a\udc69\udb0e\udfb1\ud997\uddef\u04da\ud8a8\udf92\u5574\udaa8\udfc4\u8b65\000\ud92b\uddf5\ud942\udf4d\ud8ea\udeb8\ud8af\uddd7\udab9\uddd6\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\uda77\udd7b\ud995\udf93\udb0e\ude52",
        53, 45653, 385458448, 3683834083095565406L, -99920L, false, true, (char) 55339, (char) 4284,
        Double.longBitsToDouble(0x3fe4c0dfb8fdecf5L), Double.longBitsToDouble(0x3fd06a420d91552cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |a1=java.io.StringWriter:\000 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\000 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 2, 2, 1, "\000", "\ucf2b\u1bee\u79d4", "\ud8e4\udcdd\ud983\udddd\ud912\udd93\ud9cb\udcf6\ud997\uddef",
        58, 23104, 754996596, 8316577885437165925L, 17557L, true, false, (char) 37145, (char) 54933,
        Double.longBitsToDouble(0x3fe381f1175f5369L), Double.longBitsToDouble(0x3fea34fe865a0f20L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:9 |a2=java.io.StringWriter:\udba3\ude3e\ud85e\udca4\ue1f9\uda36\udeb0\ud87a\udd71 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.Integer:9 |a2=java.io.StringWriter:\udba3\ude3e\ud85e\udca4\ue1f9\uda36\udeb0\ud87a\udd71 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 0, 5, 3, "\udba3\ude3e\ud85e\udca4\ue1f9\uda36\udeb0\ud87a\udd71", "\u3d6e\u6f6e\u2597\u531e\ub3eb", "\ud943\udd94\udb25\udebd\udbf0\udded\udbbf\udf93\udbfa\udd8f\u92dc",
        0, 23974, -323007898, 7337574486954412906L, -24605L, true, true, (char) 27721, (char) 43272,
        Double.longBitsToDouble(0x3fef5eaa5123bc0aL), Double.longBitsToDouble(0x3feddbbc1e954154L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 6, "\ua251\uec92\ud930\udc8f\ud835\udd27\ud946\ude95\ud915\uddec\ud96b\ude48\uda7e\udebf\ud869\udfc4\udbac\udc1d\ud96c\ude8b\ud8bb\udd79\ud91a\udca5\ud9f7\udce5\udbef\udc5d\udb1a\udfd8\udaa8\udfc4\ud813\udd9f\ud865\udc64\ud947\udc51\udaa9\uddd7\udb78\udca6\ud916\udc5b\udaa4\udf95\uda64\udd4e\ud9c5\uddd5\ud9e2\uddb3\uda3f\udec4\ud9e3\ude78\udbe6\udd73\udbb6\ude4c\ud9cf\uded0\ud98c\udfe4\udb71\udcd7\udbca\udced\u0510\ud9f3\udcc4\uda19\udc3d\uda2e\udf9e\ud810\ude92\udbd9\udd1e\ud983\udf38\ud8b6\udd82\uda68\udf4a\ud996\udd9f\udb6a\udff6\ud86b\ude84\u2330\udae5\ude48\udaf6\ude6d\uda67\udf44\udb48\ude5f\ud885\udc94\ud9b9\udc72\ud8c8\udf32\ud83a\udc8a\uda10\udf58\ud965\udcdd\udb4c\ude20\udb6c\udc28\ud973\ude9b\ud8df\udc90\udacb\udc4b\ud8e8\udc7c", "\u3f59\u3d2c\u9625\u2473\u1276\u0478\u1012\ub766\u361f\uaf95\u8716\u682f\u00db\u2635\u019e\u4656\ua8e1\u9e86\u2fb0\u28e8\u88c5\u4108\u9abf\u8be5\u8a8b\u6de2\uc8c7\ua97a\ub017\u7ac5\u7834\u57cb\uc608\u1726\u0bcd\ub681\u0d1a\ua136\u59dc\ua582\u64e3", "\ud851\udefe\ud876\udd2a\udaaa\udd15\ud9de\uddd1\ud9e5\udda4\ud9b6\uddef\ud91b\udf95",
        59, 66550, -1580618308, 6331962803457321L, 65889L, false, true, (char) 25328, (char) 60070,
        Double.longBitsToDouble(0x3f679667f33ce200L), Double.longBitsToDouble(0x3fe5ef2732eabb81L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\u9338\udb29\udce2\ud8ea\udebe\ud9f4\udf63\uda98\udd45\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u7a2d\u6cb2\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\udb15\udfd7\ud894\udc33\ud808\udc04",
        10, 84327, 705429957, 8459050911732637330L, 70747L, false, false, (char) 28402, (char) 11125,
        Double.longBitsToDouble(0x3fcbbadb773bca54L), Double.longBitsToDouble(0x3fefbd0e5b8c000fL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 5, "\ud92f\uddaa\udb36\udd8a\ud99b\udda2\ud94e\udfb6\udb66\udd45\udb7e\udee6\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\udb31\udd56\uda53\udcbe\udaa8\udfc4\udbbf\udf93\ud927\udd06\ud8e9\udffa\udb29\udcc1\ud8ea\udebe\ud9f4\udf63\udaae\uddd6\uda83\udcdb\ud9ea\ude6f\uda75\udc5a\ud8b3\udd42\ud81e\ude70\udaa8\udee0\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\udb50\ude32\uda4a\udf5e\uda1d\udf42\uda6a\udd9e\ud8e1\uddc5\udb4c\udf7e\udb2d\udc93\uda56\uddf6\ud87e\udda8\udbd8\udf07\ud9aa\udffd\ud951\udea3\uda22\udd84\ud94f\udf09\udb14\ude7b\uda90\udc49\udb11\udc09\ud916\uddbc\uda56\udc7b\udbab\udf30\ud817\udc67\uda4a\udfd9\ue80c\ud864\udd9c\ud926\ude14\uda0c\ude3c\ud930\udfb5\ud98e\udf88\ud965\udf35\ud8b8\udf49\udbf1\udc1f\udb5b\udeaf\ud9ce\udc9b\uda4c\udc10\udabe\udd6a\udaac\udde1\ud8ee\ude4d\udb7f\udc9b\ud9af\udf37\ud87f\ude69\udab1\uddd6\udb8c\udfd2\udabc\udfc9\ud8a0\udd2e\ud88d\ude84\ud8eb\uddaa\ud817\ude4f\udb3f\udf03\ud8a8\uddbe\ud933\udf1c\ud992\uddbd\ud870\udf4d\ud833\udf8c\uda1e\ude71\ud848\udf14", "\u6fcd\u592d\u1599\u2ac8", "\ud8d4\udf75\udbc6\udec2\u2fc5\ud89e\ude06\ud846\udc1d\ua9b7\uda91\udf40\ud92f\uddc6\ud81d\uded3\ud85d\udf77\udb08\udcc2\uda5b\udc73\ud8f0\udc06\udb8b\udf9c\uda32\udfbd\udb32\udfe5\udada\udc79\u4caa\uda24\udd2c\uda9c\udc7b\udb92\ude8c\ud9ee\uddfb\ud980\ude76\u0c6e\ud83d\udf85\udace\udf8f\ud946\udddf",
        8, 23487, 1660085040, 6928754939876266557L, -30050L, true, true, (char) 40128, (char) 30549,
        Double.longBitsToDouble(0x3feaf8e6955bb2f1L), Double.longBitsToDouble(0x3fe873d8cca89433L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 6, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\uda4e\udca6\ud807\udeb4\udb5a\ude0d\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\012\ud97a\ude44\ud986\udd90\ud927\udd06\ud8be\ude64\udb29\udce2\ud8ea\udebe\ud9f4\udf63\ud977\udf31\u434c\ud88b\udeb5\uda72\udcb3\udb88\uddc1\ud999\udc0d\ud984\udf8c\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\udb06\udf03\ud808\ude6c\udafb\udc42\udbdf\udc94\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u8b34\u1fd7\ua0e9\ud033\u5f26\u71b1", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud99f\udd9d\udbb9\udc35\udb29\udfb4\ud894\udc33\ud8ef\udcd8\udad4\udd42\ud826\udce4\ud937\udc3f\ufce7\udba0\udf6e\ud885\udd54\ud9a3\udc59\ud944\udef1\uda37\udcc9\ud90b\udd8c\uda25\udc18\udb18\udc40\udbb3\udff7\udac9\udf15\uc9b2\udbd8\udd0b\ud96b\udf66\uda7d\ude4b\ud8b1\ude44\ud9bd\udefe\udbc8\udc5c\uda17\uded2\ud9bc\udcbb\ud9fb\ude4c",
        50, 5747, 66023016, -337711857942663560L, -62035L, false, false, (char) 28044, (char) 14011,
        Double.longBitsToDouble(0x3fde896c8fe23f8aL), Double.longBitsToDouble(0x3fc79e7084abec58L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 6, "\ud892\udd17\udb2b\udc62\ud99b\udda2\udb74\udff2\ud9cd\udfcd\ud94d\ude25\ud9b1\udcf7\ud807\udeb4\udb5a\ude0d\udb22\udd48\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\012\ud97a\ude44\ud986\udd90\ud927\udd06\ud8be\ude64\udb29\udce2\ud8ea\udebe\udae8\udcfc\udaf4\udcd1\udab8\udf44\ud88b\udec5\uda72\udcb3\udb88\uddc1\ud999\udc0d\ud984\udf8c\ud995\udf93\uda50\ude9b\uda49\udead\uda5e\ude7c\uda5e\udf48\ud953\udf2b\ud800\uded9\udafb\udc42\udbdf\udc94\udbaa\uddac\ud9ba\udf8a\ud89a\udf5d", "\u8b34\u1fd7\ua0e9\ud033\ua734\u71b1", "\udb7c\udedd\uda59\udcea\udb20\ude68\ud9bb\udc94\ud94b\udc63\uc17b\ud99f\udd9d\udbb9\udc35\udb29\udfb4\ud894\udc33\ud8ef\udcd8\udad4\udd42\ud826\udce4\ud937\udc3f\ufce7\udba0\udf6e\ud885\udd54\ud9a3\udc59\ud944\udef1\uda37\udcc9\ud90b\udd8c\uda25\udc18\udb18\udc40\udbb3\udff7\udac9\udf15\uc9b2\ud81f\udf6d\ud8b9\udda7\udbd8\ude98\ud8b1\ude9c\ud9bd\udefe\udbc8\udc5c\uda17\uded2\ud9bc\udcbb\ud9fb\ude4c",
        59, 5747, 66023016, -337711857942663560L, -62035L, false, false, (char) 28044, (char) 14011,
        Double.longBitsToDouble(0x3fde896c8fe23f8aL), Double.longBitsToDouble(0x3fc79e7084abec58L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 3, "\ud892\udd17\udb2b\udc62\ud99b\udda2\ud94e\udfb6\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\udb42\uddd1\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\uda30\udf96\uda53\udcf2\udaa8\udfc4\udbbf\udf93\ud927\udd06\uda92\udf32\udb28\udff9\ud8ea\udebe\ud9f4\udf63\ud977\udf47\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udb10\udc1b\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\udb6f\udd60\uda9f\udd50\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u7a2d\u6cb2\uc1d0", "\udb7c\udedd\uda6b\udcb2\udad3\udf9d\ud88c\ude20\ud96b\ude73\uc17b\ud995\udd98\u122f\udb15\udfd7\ud894\udc33\ud808\udc04",
        10, 84327, 705429957, 8459050911732637330L, 70747L, false, false, (char) 28402, (char) 11125,
        Double.longBitsToDouble(0x3fcbbadb773bca54L), Double.longBitsToDouble(0x3fefbd0e5b8c000fL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 2, "\ud892\udd17\ubbdc\ud9d3\udd41\udb64\udcba\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\ud8f8\udf2c\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\udbd8\udf0f\u05bd\ud8a8\udf92\udb1d\udcf7\udaa8\udfc4\udbbf\udf93\udad6\udebd\ud91c\udf3d\ud907\udd01\ud8f4\uded7\ud9f4\udf63\udb74\ude4a\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\ud820\udf03\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u7a2d\u6cb2\uc1d0", "\udaf7\udec2\udbfd\udeee\ud9c2\udf00\ud88c\ude20\ud8d0\udd8d\uda72\udca9\u307d\u5c03\udb15\udfd7\ud896\ude00\ud808\udc2d\udad4\udd42\ud98c\ude58\ud937\udc3f\udb17\udfe8\ud86c\udf63\ud885\udced\ud9a3\udc59\ud944\udef1\uda37\udcc9\ud90b\udd8c\uda59\udc12\udb18\udc40\udbb3\udff7\udb68\ude05\uda43\udd25\udb91\udecb\ud8d4\udc09\ud9e8\udd42\uda35\udde0\udb6b\udf3f\ud90c\udc94\u7c33\udb5b\uded4\u0606\uda5d\udf31\udbfc\udc54\uda16\ude3b\ud9eb\udd4c\ud8a5\ude1a\ud920\ude0f\uda3f\udea8\u973d\udb08\udd05\udac5\udfea\udb3a\udf1d\ud93c\ude41\ud943\udc04\uda87\udebe\uda61\uded2\ud8a6\udf82\ud876\udd8d\udb89\udffc\uda81\udeff\udbeb\udc33\ud874\udcc5\udbc8\udc72\udad2\udf7f\ud97a\udc93\ud8b6\udfb4\uda57\udff3\ud862\ude89\udb55\udd6d\ud917\udd08\udb01\udca1\ud9b0\udc3a\ud911\udd7f\uda20\ude79\udb5e\udf82\ud8db\udd2a\ud9b7\udd17\udaa4\udf62\udaf6\udfdb\u3dcc\uda31\udd22\ud9ce\udfcc\udb96\udde1\ua6ae\u9b03\ud97f\udefc\uda23\udd00\ud8ad\udc3c\uda56\udcc7\uda5f\udea9\ud9dd\udfab\udb7c\udfcf\ud927\uded7\ud9d4\udf5d\uda58\udfef\ud9b6\udd33",
        21, 64057, -952715269, 7992921497526151206L, -40886L, false, true, (char) 2828, (char) 61587,
        Double.longBitsToDouble(0x3fe74ea9f4f9e567L), Double.longBitsToDouble(0x3fb076a62da98b90L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 0, 2, "\ud892\udd17\ubbdc\ud9d3\udd41\udb5c\udfba\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\ud8f8\udf2c\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\uda72\udd0a\u05bd\ud8a8\udf92\udb1d\udcf7\udaa8\udfc4\udbbf\udf93\udad6\udebd\ud91c\udf3d\ud907\udd01\ud8f4\uded7\ud9f4\udf63\udb74\ude4a\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\ud820\udf03\udaa8\ude98\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u3be7\ucdd1\u7a2d\u6cb2\uc1d0", "\udaf7\udec2\udbfd\udeee\ud9c2\udf00\ud88c\ude20\ud8d0\udd8d\uda72\udca9\u307d\u5c03\udb15\udfd7\ud896\ude00\ud808\udc2d\udad4\udd42\ud98c\ude58\ud937\udc3f\udb17\udfe8\ud86c\udf63\ud885\udced\ud9a3\udc59\ud944\udef1\uda37\udcc9\ud90b\udd8c\uda59\udc12\udb18\udc40\udbb3\udff7\udb68\ude05\uda43\udd25\udb91\udecb\ud8d4\udc09\ud9e8\udd42\uda35\udde0\udb6b\udf3f\ud90c\udc94\u7c33\udb5b\uded4\u0606\uda5d\udf31\udbfc\udc54\uda16\ude3b\ud9eb\udd4c\ud8a5\ude1a\ud920\ude0f\uda3f\udea8\u973d\udb08\udd05\udac5\udfea\udb3a\udf1d\ud93c\ude41\ud943\udc04\uda87\udebe\uda61\uded2\ud8a6\udf82\ud876\udd8d\udb89\udffc\uda81\udeff\udbeb\udc33\ud874\udcc5\udbc8\udc72\udad2\udf7f\ud97a\udc93\ud8b6\udfb4\uda57\udff3\ud862\ude89\udb55\udd6d\ud917\udd08\udb01\udca1\ud9b0\udc3a\ud911\udd7f\uda20\ude79\udb5e\udf82\ud8db\udd2a\ud9b7\udd17\udaa4\udf62\udaf6\udfdb\u3dcc\uda31\udd22\ud863\udd37\ud946\udc24\udbb6\udf25\ud8b9\udccd\ud8b9\udfd0\uda23\udd00\ud8ad\udc3c\uda56\udcc7\uda5f\udea9\ud9dd\udfab\udb7c\udfcf\ud927\uded7\ud9d4\udf5d\uda58\udfef\ud9b6\udd33",
        21, 64057, -952715269, 7992921497526151206L, -40886L, false, true, (char) 2828, (char) 61587,
        Double.longBitsToDouble(0x3fe74ea9f4f9e567L), Double.longBitsToDouble(0x3fb076a62da98b90L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 0, 2, "\ud892\udd20\ubbdc\u29bd\udb5d\udc12\ud949\udc56\udb5f\udd37\ud860\uddb7\udaba\udd37\ud8f8\udf2c\ud966\udd4a\ud96a\udc69\ud9cb\udcb0\uda72\udd0a\ud90e\udc20\udb46\ude3a\udb31\udef5\udaa8\udfc4\udbbf\udf93\udad6\udebd\udadc\ude3f\udbf6\udde3\ud8f4\uded7\ud9f4\udf63\udb74\ude4a\udba0\uddb3\ud89c\udc2a\uda79\udd76\ud95d\ude47\udac2\udcb4\uda83\udc31\ud995\udf93\udb0e\ude52\uda49\udead\uda5e\ude7c\uda5e\udf48\ud8ef\ude98\uf071\uda72\ude22\uda37\ude51\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53cb\u7382\ucdd1\u7a2d\u6cb2\uc1d0", "\udaf7\udec2\udbfd\udeee\ud9c2\udf00\ud88c\ude20\udafa\udf42\uda13\udec6\ud818\udeea\u5c24\udb15\udfd7\ud896\ude00\ud808\udc2d\udad4\udd42\ud98c\ude58\udb47\udc68\udb82\ude5a\ud86c\udf63\ud885\udced\ud9a3\udc59\ud944\udef1\uda37\udcc9\ud90b\udd8c\uda59\udc12\udb18\udc40\udbb3\udff7\udb68\ude05\uda43\udd25\udb91\udecb\ud8d4\udc09\ud9e8\udd42\uda35\udde0\udb6b\udefc\ud90c\udc94\u7c33\udb5b\uded4\udb1b\udd32\ud9b9\uddcf\uda76\udd22\uda9c\udd85\ud842\uddab\u9fdd\ud920\udd80\uda3f\udea8\u973d\udb08\udd05\udac5\udfea\udb3a\udf1d\ud93c\ude41\ud950\udc04\uda87\udebe\uda61\uded2\ud8a6\udf82\ud876\udd8d\udb89\udffc\uda81\udeff\udbeb\udc33\ud874\udcc5\udbc8\udc72\udad2\udf7f\ud97a\udc93\ud9a6\udf2c\uda57\udff3\ud862\ude89\udb55\udd6d\ud917\udd08\udb01\udca1\ud9b0\udc3a\ud911\udd7f\uda20\ude79\udb5e\udf82\ud8db\udd2a\ud9b7\udd17\udaa4\udf62\udaf6\udfdb\u3dcc\uda31\udd22\ud879\udd37\ud946\udc24\udbb6\udf25\ud8b9\udccd\ud8b9\udfd0\uda23\udd00\ud8ad\udc3c\uda56\udcc7\uda5f\udf4e\ud9dd\udfab\udb7c\udfcf\ud927\uded7\ud9d4\udf5d\uda58\udfef\ud9b6\udd33\udb1d\udcb6\ud9a3\udf68\ud8fd\udca2\ud9b9\ude4a\udb1d\udeec\ud886\udf9d\ud82a\udcfa\ud980\udd48\udacf\udcba\udaa3\udd17\udb8f\udd10\udbe8\uddce\udae2\udd57\udaaa\udec4\udbea\udf2a\ud916\udfc4\udbe9\ude62\udaf5\udf68\uda88\uddb0\udb0f\udd43\udba2\udd8c\ud933\udf94\udb2c\udff5\udaeb\uddac\ud9e9\udc9a\u77d7\udaac\udebd\ud006",
        17, 31320, -30858911, -1153866053467781641L, -82634L, true, true, (char) 65405, (char) 20846,
        Double.longBitsToDouble(0x3fc2832d29efd448L), Double.longBitsToDouble(0x3fa1b16efa2ee860L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 3, "\uda6d\udee5\"\ud986\udd2b\ud94e\udf4f\udb1f\udca1\udaff\udf9f\ud860\udde2\ud955\ude45\udba0\udde0\ud933\udd08\ud8c8\udd6f\ud8ae\uddbc\udb9b\udd2c\u04ef\udafd\udd08\udbe8\udca4\udb3d\uddae\udb59\udc44\udadb\udfb5\udb72\ude51\udb29\udcc3\000\ud9f4\udf63\ud977\udf47\udba0\uddef\ud89c\udc6e\uda79\udd76\uda4d\uddbf\ud8c7\udc88\udb11\ude32\udbc4\udf69\ud93d\udefe\ud9c5\udc7e\uac2a\udab8\uddbf\ud8ef\udeaf\udad2\udf1b\udbb0\udeb1\ud8e5\ude63\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53ea\u3be7\u61f5\u7a2d\ua914\u8f24\u347d\ucbac\u8cff\ud2cb\uc912\ub6da\u6779\ub279\uc30b\u2596\u19dc\u0ca0\u174c\ub800", "\udbc2\uddc9\ud863\uddf2\ud885\udced\ud9a3\udc59\ud944\udef1\uda26\udec9\ud90b\udd8c\uda59\udc12\udb18\udc40\udbb3\udff7\udb70\udc69\ud916\udf5d\udb8e\udc73\ud8da\udf7d\udae5\udda3\ud800\ude48\udbb4\ude0b\000",
        -5, -1000, -1917779968, -6449789053872203558L, -37157L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe00000045f1afcL), Double.longBitsToDouble(0x3fcc5ce3d8aab474L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 6, "\uda6d\udee5\"\ud986\udd2b\ud94e\udf4f\udb1f\udca1\udaff\udf9f\ud860\udde2\ud955\ude45\udba0\udde0\ud933\udd08\ud8c8\udd6f\ud8ae\uddbc\udb9b\udd2c\u04ef\udafd\udd08\udbe8\udca4\udb3d\uddae\udb59\udc44\udadb\udfb5\udb72\ude51\udb29\udcc3\000\ud9f4\udf63\ud977\udf47\udba0\uddef\ud89c\udc6e\uda79\udd76\uda4d\uddbf\ud8c7\udc88\udb11\ude32\udbc4\udf69\ud93d\udefe\ud9c5\udc7e\uac2a\udab8\uddbf\ud8ef\udeaf\udad2\udf1b\udbb0\udeb1\ud8e5\ude63\udbaa\uddac\udb27\udce1\uda56\udd2c", "\u53ea\u3be7\u61f5\u7a2d\ua914\u8f24\u347d\ucbac\u8cff\ud2cb\uc912\ub6da\u6779\ub279\uc30b\ub855\u1a27\u024f\u174c\ub800", "\udbc2\uddc9\ud863\uddf2\ud885\udced\ud9a3\udc59\ud944\udef1\uda26\udec9\ud90b\udd8c\uda59\udc12\udb18\udc40\udbb3\udff7\udb70\udc69\ud916\udf5d\udb8e\udc73\ud8da\udf7d\udae5\udda3\ud800\ude48\udbb4\ude0b\000",
        -5, -1000, -1917779968, -6449789053872203558L, -37157L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe00000045f1afcL), Double.longBitsToDouble(0x3fcc5ce3d8aab474L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:51 |a2=java.io.StringWriter:\"\uda6d\udee5\"\"\ud986\udd2b\ud94e\udf4f\udb1f\udca1\udaff\udf9f\ud860\udde2\ud955\ude45\ud81d\udfcf\ud917\uddcd\ud8c8\udd6f\ud8ae\uddbc\udb9b\udd2c\u04ef\udafd\udd08\udbe8\udca4\udb3d\uddae\udb59\udc44\udadb\udfb5\udb72\ude51\udb29\udcc3\000\ud9f4\udf63\ud977\udf47\udba0\uddef\ud89c\udc6e\uda79\udd76\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 2, 6, "\uda6d\udee5\"\ud986\udd2b\ud94e\udf4f\udb1f\udca1\udaff\udf9f\ud860\udde2\ud955\ude45\ud81d\udfcf\ud917\uddcd\ud8c8\udd6f\ud8ae\uddbc\udb9b\udd2c\u04ef\udafd\udd08\udbe8\udca4\udb3d\uddae\udb59\udc44\udadb\udfb5\udb72\ude51\udb29\udcc3\000\ud9f4\udf63\ud977\udf47\udba0\uddef\ud89c\udc6e\uda79\udd76", "\uaf72\u4804\uc662\uce1b\u3f8e", "\udac9\ude13\udba4\udcb1",
        0, 27262, 2089344395, -3703484793447947780L, -30661L, false, false, (char) 60922, (char) 29844,
        Double.longBitsToDouble(0x3feea1dce959262eL), Double.longBitsToDouble(0x3fee17191df1c3deL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:\"\012\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 5, 1, "\012", "\u85f0", "\udba3\udd1a\udaba\udd37\udb42\uddd1\udb3f\udfb6\u4676\udba4\udc71\ud803\ude73\u05cd\ud901\udd92\u5574\udaa8\udfc4\u8b65\000\udaca\udda5\ud856\ude1f\ud8ea\ude47\udbd4\ude53",
        23, 50607, 8739447, 556882504301960618L, 31072L, true, true, (char) 37551, (char) 40128,
        Double.longBitsToDouble(0x3fa6243a623d87d0L), Double.longBitsToDouble(0x3feca8b7c875331fL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.String:\"\012\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\"\012\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 1, 2, 3, "\012", "\u85f0", "\udba3\udd1a\ud9e2\udccc\udb42\uddd1\udb3f\udfb6\u4676\udba4\udc71\ud803\ude73\u05cd\ud901\udd92\udb61\udeea\udad9\ude82\ud960\udc06\000\udaca\udda5\ud856\ude1f\ud8ea\ude47\udbd4\ude53",
        23, 50607, 8739447, 556882504301960618L, 31072L, true, true, (char) 37756, (char) 40128,
        Double.longBitsToDouble(0x3fa6244f623d87d0L), Double.longBitsToDouble(0x3feca8b7c875331fL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 5, 6, "\015\000\uda1f\udf78\ud932\uddb1", "\u4cc5\u01d3\u68cb\u9e4c\u4779\u5664\u58e3\uaaf6\u0701\u5574\u5083\u8023\u01cf\u2db7\u0f37\ua91f\u298a", "\udb66\ude7e\uda46\ude24\ud951\udc66",
        27, 23376, -343536661, 6883935826186878264L, 49981L, true, true, (char) 60307, (char) 64978,
        Double.longBitsToDouble(0x3fe06ed7b25652f5L), Double.longBitsToDouble(0x3fe8c89aac906544L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String:1B\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 0, 3, "\u03af\udb56\udee8\ud9a7\udf45\ud91b\udd11\ud9fb\udd67", "\u961e\u0bda\u7f9b\ub02b\ub3eb\ucdf9\u6dbb\u9179\u92e5\u8317\uc6a2", "\udbf5\ude7f\udb6b\udf9e\udbda\udee9\ud93f\udce9\ud9e6\udfd1\udb0a\udcd1\udb68\udf4f\ud9b3\udca4",
        27, 83316, -619789622, 3705666687066885947L, 70946L, true, true, (char) 47381, (char) 43973,
        Double.longBitsToDouble(0x3fd54538ca5db6f4L), Double.longBitsToDouble(0x3fec40e6cdb80b74L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 6, ",\000\ud8a4\udd1b\ud94e\udfb6\ud949\udc56[\ud86e\udd09", "\u9d1c\uae7a\u73ed\u5f8a\u964d\u1ed5\ub768\u2cc9", "\ud82d\udcd5",
        22, 91600, -67259488, -3068778336747904627L, 30650L, true, true, (char) 44120, (char) 58201,
        Double.longBitsToDouble(0x3fef5eaa51233e12L), Double.longBitsToDouble(0x3fe6a0a594954154L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,int,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|hex|int|static",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|with|[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,int,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
