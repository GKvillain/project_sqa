package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class ClassUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud9ff\udf8d\ud89b\ude81\udbb5\ude6d\ud87e\udd80\udbc1\udff5\udae5\udcd0\ud931\ude23\udadd\udf1f\uda9f\ude15");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud9ff\udf8d\ud883\uddf5\uda79\ude2d\ud879\udcc0\udbc1\udff5\ud8fb\udf3b\ud949\udc66\ud9cd\udc60\ud8c1\ude40");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud9ac\udf2b\u0f51\uda8b\uddd6\uda86\udf3a\ud9ef\udd7c\ud9c2\ude53\ud823\udcfb\ud999\udead\udb4e\udc39\ud96e\udd6e\ud995\udf5b\ud957\udf7f\udb03\udec9\ud8ee\udf6e\ud85a\ude05\udb3a\udf6d\ue1ec\ud8de\udd43\ud8bf\ude9f\u0932");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud9ff\udfbc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud9ff\udf8d\ud864\udd06\ud832\udcab\ud8a1\uddf3\uda1c\udd57");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\udb98\uddd9\ud89b\ude99");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud90a\udd55\ud89b\ude81\udbe7\udc56\udaa9\ude9d\udb5f\udc45\udae2\udf7c\ud85e\ude5e\udbf5\udfd0\uda2e\udfd8\ud999\udf10\udaab\udd11\ud850\uddbb\udabe\udfb6\uda82\udd87\ud8a0\udea0\uda93\udced\ud811\uded9\uda47\ude54\ub519\udad1\udf19\udb17\uddb9\udb3c\udd5d\ud8e2\ude1c\ud954\udf02\udbb8\ude7c\udb1d\udddf\ud8fc\udce5\udad1\udf46\u5afa\udb27\udcbe\ud95e\udfc5\udbaf\udedd\ud9b7\udc56\ud861\udcac\ud977\udf74\udb2a\uddb9\uda60\udd13\udb16\udf4a\u0620\uda8d\udd19");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud93a\udcf1\ud87f\udeb0\ud91f\udd1f\udb02\ude8a\ud945\udf13\uda61\udd54\udb6b\udf36\uda03\udf12\udb7e\ude16\ud8be\udc17\udb42\udee5\udac9\udd9d\ud8e4\uddff\ud8ef\udf10\udaba\ude5f\uda5e\ude62\udaf2\ude84\ud98f\udf6d\uda3b\ude2a\ud942\udff8\udbac\udd44\udb48\udc23\ud801\ude82\ud8a7\ude45\ud8c9\udee1\udb11\udefc\ud806\udd0f\uda25\udd71\udb5a\udcbe\ud839\udce0\udbc4\udf50\uda08\udd46\ud960\ude24\udb47\udee3\udb4b\udf37\uda7f\udfa7\uda0e\udd8f\udb0e\udeca\ud858\uddfc\uda5c\udf0f\udbc3\udd66\ud870\udf20\uda07\ude1a\udb55\udf61\uf8b6\udbba\udcce\ud91a\uddcd\ud9a8\udd45\udb01\udc2c\udb01\udea0\uda1d\uddb3\udbb5\udc60\udab2\udec6\uda2f\udc93\uda8f\ude45\ud895\udd49\udb76\udeed\udacd\ude2c\udabe\udc17\udaca\ude08\ud8b2\udc2a\ud967\udc7f\ud94c\uddb9\ud984\udf1b\ud84f\udd3a\ud841\ude48\ud977\ude6b\uda5c\udfeb\ud9b3\udcbf\ud800\udf0d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud829\udf42\ud966\udffb\udbb5\ude6d\u6e79\ud847\udff8\udae5\udcd0\ud931\ude23\udadd\udf1f\uda9f\ude15");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("[\ud8b8\udd37\ud97f\uddb1\ud9a2\udee0\udb24\udc8f\uf66f\ud86e\ude88\ud90a\udd91\udbc5\udcf4\udb7c\udeff\uda30\udff9\ud935\udd1a\uda18\udfda\ud9e3\udd07\ud92d\udd73\ud88c\uddb2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("L\udbc3\udebd\ud97f\uddcd\uda44\ude40\udb24\udc8f\uf66f\udb60\udf69\ud8f9\udd6d\ud806\ude55\udb7c\udeff\uda30\udff9\ud911\udd1c\uda18\udfda\ud9e3\udd07\ud92d\udd73\ud88c\uddb2\ud83e\udd5c\u52ff\uda83\ude57\ud80c\ude9a\udbe0\ude14");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName(".\udbc3\udebd\ud97f\uddcd\ud985\udf00\uda79\ude03\ud807\udf04\udb60\udf69\ud8f9\udd6d\ud939\ude9c\ud99e\uded6\udb47\uddac");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
}
