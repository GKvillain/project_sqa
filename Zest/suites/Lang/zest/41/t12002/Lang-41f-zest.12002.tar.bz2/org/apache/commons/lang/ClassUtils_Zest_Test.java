package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class ClassUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\uda09\udfa3\ua2b1\ue052\ud9d1\udfef\ud8c6\udfd3\ud94d\udcac");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud988\udf43\ud885\udefc\udb83\udca7\ud9d2\udc37\ud8c6\udfd3\ud8ba\uddbc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud969\udf9e\ud939\udf9a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud8d9\udc0b\u9956\udb46\udfda\ud9d3\udd38\ud8d6\udefc\udb51\udeb8\udb69\udca8\uda7e\udd3c\ud934\udd8b\uda3b\udf2c\ud812\udeb1\u43b4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\uda0a\udc00\uda2e\udd73\ue052\uda67\udd79\udadc\udc77\ud895\udc2d\ud878\ude78\udadc\uddd8\u3933\uda5b\uddc8\uda49\udd8f\ud93a\udf7c\uda2b\udf96\uda4b\udf9a\ud97b\udc89\uda46\udc2f\ud8e9\udee5\uda2f\udf1d\udadc\uddce\ud916\udd67\udadc\udd70\ud935\udf03\ud8df\udfa0\ud983\ude42\uda5b\ude7f\ud9b2\ude47");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\uda09\udffb\ud9ca\udf1b\udbaf\udd45\ud916\uddd7\udb9c\udfac\ud90b\udfe5\udb46\udf4b\udb0f\ude8e\ud853\udd75\udbb2\udea6\ud803\ude86\udb41\udeb2\uda12\udd8f\ud9ae\uddae\uda0f\udd36\ud8b3\udc2c\udb18\udeb3\ud941\udce4\udbe5\ude6a\ud8e9\udccd\ud840\udc9a\ud84d\udd50\ud9b1\udce3\ud9ba\udebc\uda45\udf5c\udbb8\udfbd\ud984\udc47\ud8c2\udf03\ud874\uddd1\udbd3\ude65\udbd0\udc2d\ud9ad\udf7e\ud963\uddc1\ud88d\udef8\uda20\udca3\udafd\uddfa\udaad\udea6\ud82e\udeeb\udad0\udd78\uda54\ude9b\ud84b\ude1b\ud991\udc75\ud912\udd5b\ud81f\ude5f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\udb78\ude59");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\ud8ac\udffe\ud93c\udc07\ud7fa\udabe\udf79\udb2c\udeb3\uc322\ud8f4\udcd1\ua879\ud846\udc36\ud8a4\udcba\uda6a\ude5e\uda15\udc49\uda74\udef7\ud9bc\uddf6\u1ecc\udbda\uded6\ua79b\udb36\udf10\ud8e6\ude68\ud84c\udef7\ud922\udd5b\ud81f\udff5\udb5f\udd0f\udbd6\udeb8\ud886\udf8a\ud8ed\udcc7\ub100\ud833\udd18\ud809\udd83\ud885\udcfb\uda71\udf5e\ud9c0\udfa8\ud95f\udcd3\udaaf\udd79\ud9c4\udfdd\ud894\udf2f\ud94a\udee1\ud843\udc0f\ud9f4\udfea\udb36\udd97\ud957\ude55\udb4f\udc0a\ud8d6\udde7\udb0e\udcc6\uda7c\udff4\ud947\udeb1\uda81\ude6a\udb52\udf93\udb45\uddf7\ud875\udef4\u2bdb\uda65\udc4f\ud85e\uded4\udbeb\uddff\udbcf\udcc9\udadb\udde0\uda3c\ude47\udbac\ude8e\udbcc\ude18\ud86d\udca4\uda92\udcd9\udba7\ude45\u92ea\ud962\udfed\uda00\udceb\ud9f6\uded8\ud9b6\udc79\ud89f\ude0e\ud86d\udc66\ud9d0\udcb5\ud8d7\udd91\ud942\ude6a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("\uda09\udf81\ua2b1\ue052\ud9d1\udfef\ud896\ude7e\ud94d\udcac");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName(".");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("[\udbd3\udfe2\ud9ca\udc50\ud812\udc9e\udb0f\udc86\ud824\udc38\udbaf\udd7a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.ClassUtils.getPackageName("L\udbd3\udfe2\udae6\udef2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
}
