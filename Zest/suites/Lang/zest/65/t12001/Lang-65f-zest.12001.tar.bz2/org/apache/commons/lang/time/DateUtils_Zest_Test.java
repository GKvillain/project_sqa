package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d\u81a9\uadda\uc8a1\u2372\u4f6a\u63b9\u556d\u7ecb\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u3d76\u0eff\u438e\ud476\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -37444L, true, false, (char) 20701, (char) 14807,
        Double.longBitsToDouble(0x3fe28fc6eae692bdL), Double.longBitsToDouble(0x3fd2c468cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.util.Date:Tue Feb 18 18:06:52 PST 92467941\0121=java.util.Date:Tue Feb 18 18:06:52 PST 92467941\012",
        Z.run(T, 2, 8, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udb3b\udfbe\ud961\udf47\ud9aa\udde3", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d\u81a9", "\uda69\uddc3",
        0, 93479, -1632341826, 2917944212724412400L, 89129L, true, false, (char) 24436, (char) 3125,
        Double.longBitsToDouble(0x3fc8e92be6bc18b4L), Double.longBitsToDouble(0x3fd649070a39da34L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.Date:Fri Feb 21 02:52:28 PST 66615547\0121=java.util.Date:Fri Feb 28 02:51:28 PST 66615547\012",
        Z.run(T, 2, 8, 5, 12, "\uda91\uddf0\ud87d\udd58\ud93b\uddb1\ud8ab\ude26\ud913\udc35\udb39\udf35\udafe\udc4c\ud81d\udd9e\ud83d\uded8\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a", "\u4e33\u675c\u62cb\u40e8\u8984\u626c\ua4ec\u2a74", "\ud90c\udf0b\udac2\ude60\ud8fc\udc2a\u0eab\udb06\udf3f\udadd\udc27\ud962\uddbe\ud965\ude0e\udb77\udf5c\ud98f\udc9b\uda63\udc24\uda69\uddc3\ud948\uddd5\uda87\udce6\ud95f\udd3e\udb9e\udd19\udbfc\udedf\ud961\udc49\udbe5\udc3f\uda8a\udcb9\ud86c\udfae\udbc0\uddae\ud88b\udd24\udbc2\udf1b\udbc1\udc46\udad4\udd9c\udb04\udff8\ucdd0",
        -1, 86790, 1432112461, 2102121456951148366L, -24251L, true, true, (char) 40885, (char) 55397,
        Double.longBitsToDouble(0x3fc30969395be09cL), Double.longBitsToDouble(0x3fe632bf7a271072L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.Date:Mon Jul 04 20:29:55 PST 200875455\0121=java.util.Date:Mon Jan 09 20:29:55 PST 200875454\012",
        Z.run(T, 2, 8, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0", "\u3dce\ub921\u0232\u2781\u43d9\u509e", "\ud812\udd2b\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda18\udddf\ud9d9\uddf2\uda9c\udf11\ud886\udc8d\ud90c\udf0b\udac2\ude60\ud8fc\udc2a\ud8ba\uddb9\ud9b0\udf8f\ud975\udf48\ud9f8\uddf2",
        8, 40508, -934772764, -6339209383337404068L, -9581L, false, true, (char) 35261, (char) 16346,
        Double.longBitsToDouble(0x3fe2bc88d2329542L), Double.longBitsToDouble(0x3fe818c994c7495fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Sun Jun 09 04:13:08 PDT 113819799\012",
        Z.run(T, 2, 10, 2, 11, "\ud885\ude52\ud87d\udd58\udab6\udc74\ud991\udca2\ud83b\udee1\uda9d\udc77\ud80e\udd50\ud957\udcd1\ud844\udf69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\udb6b\udcac\udac2\udc60\udbcd\udf15\ud952\udf06\udaad\ude76\ud99f\ude63\uda0f\udc51", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46", "\ud828\udd54\ud8cf\udc54\uda63\udc24\uda69\uddc3\ud948\uddd5",
        -4, 25087, 679386829, 3591743780661188581L, -8439L, false, false, (char) 3125, (char) 34342,
        Double.longBitsToDouble(0x3fdaf062dac920e0L), Double.longBitsToDouble(0x3fd1ced1a49a76e0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\ud9ef\udd59\000\000\000\ud901\udcc0\uda9d\udc1c\ud80c\udee6\ud957\udcd1\ud83d\ude69\uabd0\000\udb05\udc0a\000\000\ud87b\udcb7\u31fe\u31d6\u9a00\000\000\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u00a1\000\000\034\u2b46\u9b74\u0904\u6565\uadda\uc8a1\u2372\u4f6a\u63b9", "\udbfc\udedf\udbe5\udfec\000\uda6a\uddb5\ud86c\udfae\udbe3\udf55\u00c7\udbc2\udf1b\udbc1\udc46\u2d1c\udb66\uddb2",
        -4, -826, 448931790, 6150876184191974484L, -89876L, false, false, (char) 207, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb5be09d0af3800L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\udb86\ude8c\ud971\udd71\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude1a\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\ud94a\udd15\ud9d9\uddb3", "\u948a\u65df\u93f1\u8ce1\u1071\u2b53\u9b74\u438d\u8222\uadda\uc8a1\u2372\u4f6a\u63b9\u556d\u7ecb\ua303\u8a95\u134b\u2e1c\uc8de\uaa13\u1419\u3d76\u0eff\u2901\ud476\u15d7", "\udbbc\udec3\udac7\uded5\u187d\udb56\udfc2\ud827\udc50\udae8\udd7f\uec00\udb53\udebf\uda88\udc21",
        20, 58979, -1430781401, 2776199824359099533L, -57852L, false, false, (char) 41998, (char) 49385,
        Double.longBitsToDouble(0x3fea321280a526b3L), Double.longBitsToDouble(0x3fe9d1fe43b2a9b3L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.Date:Wed Apr 09 08:24:43 PDT 188962966\0121=java.util.Date:Sat Apr 18 08:24:43 PDT 188962967\012",
        Z.run(T, 2, 8, 6, 11, "\uda7e\ude88\ud874\udc58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc64\ud80e\udd50\ud957\udcd1\ud982\udf7d\ud86d\udd95\ud9fd\udcdf\udb05\udc0a\uda57\ude24\uda94\udde4\udb41\udd2d\udb1b\uddf7\udac1\udfda\udbcd\udf15\udb04\udc38", "\u2a9d\u7e41\ub4e6\u5caf\u283f\ud5df\u8ce1\u1071\u2b46\u9b74\ud432\u81a9\uadda\uc8a1\u65f5\u8904\u15a5\u556d\u7ecb\ua303\ud039\u075a\ua3d4\u700f\uba2a\u1419\u3d76\u0eff\u438e\u8525\u15d7\u5b44\ub784\u6a78\u56e7\u14fe\u69b5\uaef3\u309e", "\uda88\udc21\udaab\udcdd\ud8cb\udc36\udb55\udc44\ud8cf\udde9\ud916\udc95\udab3\udda2\ud94a\udeba\uda6c\udfe0\ud925\udf0e\udb73\udf48\uda8a\udcdb\udb37\udfc0\ud98a\uded0",
        16, 45637, -217288614, 5963033079534283890L, -75593L, false, false, (char) 4616, (char) 37774,
        Double.longBitsToDouble(0x3fe464872e2209b3L), Double.longBitsToDouble(0x3fc9faa568ff9a8cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.util.Date:Mon Dec 04 13:28:46 PST 222750975\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 12, 1, "\ud9ef\ude47\ud866\udd58\udab6\udc74\ud991\udca2\udb94\udd1e\uda4f\ude88\ud828\udffa\udb3f\udc9b", "\u2781\u43d9", "\ud87b\udd6a\uda92\udc9f\ud897\udefb\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud973\udf5f",
        6, 93740, 262785567, 7029279684419326500L, -11395L, false, true, (char) 28487, (char) 19634,
        Double.longBitsToDouble(0x3fe53e4207b9194bL), Double.longBitsToDouble(0x3fee977de6af9a69L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udc1f\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d\u81a9\u103a\uc139\ua05a\u4f6a\u63b9\u556d\u7ecb\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u3d76\u0eff\u438e\ud476\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -37444L, true, false, (char) 20701, (char) 14807,
        Double.longBitsToDouble(0x3fe28fc6eae692bdL), Double.longBitsToDouble(0x3fd2c468cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.util.Date:Thu Dec 26 23:50:04 PST 113819799\0121=java.util.Date:Fri Nov 06 23:50:04 PST 113819801\012",
        Z.run(T, 2, 8, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud8fe\udedb\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3", "\u6ef0\u4e33\u675c\u62cb\u40e8\u8984\u626c\ua4ec\u2a74\u3855\ub4e6\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d", "\uda63\udc24\uda69\uddc3\ud948\uddd5",
        29, 19174, 679386829, 3591743780127004645L, -8439L, false, false, (char) 3125, (char) 34342,
        Double.longBitsToDouble(0x3fdaf3b7dac920e0L), Double.longBitsToDouble(0x3fd1ced1a49a76e0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.Date:Tue Mar 14 23:34:01 PDT 57761684\012",
        Z.run(T, 1, 8, 5, 3, "\ud9ef\ude47\uda02\ude5a\udb77\udf1f\ud991\udca2\ud901\udcc0", "\uc1a6\u90f6\ud02e\u2dfd\ubb52\u509e", "\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udb79\uddbd\ud96a\udcbc\udabf\uddcb\ud9b3\udc69\udb96\uddc4\ud90c\udf0b\uda84\udc5a\ud8fc\udcdd\ud8c1\ude3f\ud9b0\udf8f\udadd\udcfc\ud901\udd88",
        21, 93319, -934772952, 1822720515978841785L, -9581L, false, true, (char) 24253, (char) 34320,
        Double.longBitsToDouble(0x3fe2be58d119cd10L), Double.longBitsToDouble(0x3fe818c994c7495fL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Sat Mar 14 03:23:14 PDT 73043942\012",
        Z.run(T, 2, 11, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c", "\u3bf3\u0232\u2781\u43d9\u688e", "\ud98c\ude4e",
        6, 59346, -1094971681, 2304981994990994257L, 89024L, false, true, (char) 1791, (char) 5194,
        Double.longBitsToDouble(0x3fe1230c6f3a663aL), Double.longBitsToDouble(0x3fe7c7ba2deaaf18L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.Date:Mon Mar 16 10:05:51 PST 37135685\0121=java.util.Date:Mon May 20 10:06:34 PST 37135686\012",
        Z.run(T, 2, 8, 7, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\ud865\udec1\ud9d2\udf37\uda26\uddd8\udb3b\udfbf\ud956\udc62\ud9db\udd7c\uda65\udfdb\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udabf\udd96\udb7e\udd6f\udac2\udc91", "\u5caf", "\ud8c8\udd33\ud93b\udd91\ud91d\udd0c\ud886\uddc6\ud965\ude0e",
        43, 82236, 424385191, -1171975248251648046L, -71138L, true, false, (char) 39022, (char) 46455,
        Double.longBitsToDouble(0x3fe64a517257911aL), Double.longBitsToDouble(0x3fe754aa13a5a632L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 1, 6, "\uda54\udee4\ud87d\udd58\ud9f3\udfd2\ud9ba\udda2\uda11\udcc5\uda9d\udc1c\udaad\udd4b\ud8ff\udf53\uda07\udc5d\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\ud9ec\udd4f\udab7\udda6\ud87b\udd6a\uda92\udc9f\udac1\udfef\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5118\u6612\u9411\u8ce1\ucafe\u2b24\u9b74\u438d\u8454\u3722\u2813\u22dd\u9180\u630f\u556d\u7ec7\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u3d76\u43b4\ubb8d\ud476\u4ddc", "\udb24\ude54\ud841\ude0c\ud97b\udd33\ud86e\udcf0\udb3c\udd3d\uda3a\udc15\ud811\udd12\udb53\ude72",
        -4, 58350, -1671159275, -6145159324370927964L, 50572L, true, true, (char) 13103, (char) 56739,
        Double.longBitsToDouble(0x3fd2c468c91e47b2L), Double.longBitsToDouble(0x3fefec48089f2c03L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.Date:Sun Oct 15 06:03:33 PST 17909846\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 10, 11, "\ud84e\udec2\udb5c\udfed\ud9ba\udc76\ud991\udca2\ud901\udcc0\ud9b5\uddb4\ud9bd\udfd1\ud957\udcd1\ud83d\ude69\ud805\udc1c\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\udb59\udc6e\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\udbbb\udf6e\ud9d9\uddf2", "\u5caf\u283f\ud4c8\ud71f\u1071\u997e\u9b74\u438d\u5173\u4df2\uc8a1\u2372\u4bdf\uaa01\u3756\u7ecb\u0e1b\u656b\ua577\u5e62\u505e\ub9f9\u1419\u3d76\u0eff\u438e\u9f19\u9dd4", "\ud843\udf4d\uda2f\udfd2\udb38\udcc8\ud878\udcf5\udb3c\udd3d",
        17, 17994, 1263127043, -565253877376586154L, -99297L, false, true, (char) 13076, (char) 20701,
        Double.longBitsToDouble(0x3feb8db33251f8ddL), Double.longBitsToDouble(0x3fe734910c6a563fL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\ud9ef\udd59\ud87d\udd58\udab6\udc74\000\ud901\udcc0\udbb7\udc49\ud9be\udedf\000\ud960\uded0\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\udac8\udfe3\uda94\udde4\uda8e\udfb4\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud818\udc0b\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "", "",
        24, 8610, 1632340, 1098032384L, 38308L, false, true, (char) 25327, (char) 26628,
        Double.longBitsToDouble(0x3f4df782be680000L), Double.longBitsToDouble(0x3e48000000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 13, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud910\udc2d\ud83d\ude44\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud9c5\uded0\uda0e\udc3a\uda81\udfa7\udbde\udda4\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\u98c9\u17d8\ua0f3\u5efb\u9b74\u438d\u81a9\uadda\uc8a1\u2372\u4f6a\u63b9\u7a45\uc73a\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u3d76\u0eff\u438e\ud476\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -43189L, true, false, (char) 46684, (char) 13076,
        Double.longBitsToDouble(0x3fbc011b5b8db330L), Double.longBitsToDouble(0x3fe28fc6eae692bdL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 9, 11, "\udac2\ude6f\ud88c\ude18\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\u934d\u8ce1\u6ceb\u2b46\u9b74\u438d\u81a9\uadda\u28bd\u2372\u4f6a\u63b9\u556d\u7ecb\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u375c\ub27d\u438e\ud476\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -37444L, true, false, (char) 18687, (char) 14807,
        Double.longBitsToDouble(0x3fe28fc6eae692bdL), Double.longBitsToDouble(0x3fd2c468cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Fri Feb 13 09:56:28 PST 211572515\012",
        Z.run(T, 2, 13, 6, 13, "\ud9ef\ude16\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\udaa0\uddb9\ud953\ude0e\ud83d\uded5\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\ud8d0\udf87\ud8a9\ude6d\ud933\udfb8\ud815\ude2f\ud812\udcae\udbcf\udf14\ud952\udf06\udaad\ude76\udbcd\ude1b\ud9d9\uddf2\uda9c\udf11\ud886\udc8d\ud90c\udf0b\udac2\ude60\ud8fc\udc2a\ud919\udeb6\ud9b0\udf8f\udadd\udcfc\ud962\uddbe\ud965\ude0e\udb77\udf5c\ud98f\udc9b\uda63\udc24\uda69\uddc3", "\u556d\u7ecb\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419", "\ud91b\udcea\ud8ad\udfe3",
        -1, -699, 448931790, -6676782928956211976L, -89876L, true, false, (char) 51476, (char) 4887,
        Double.longBitsToDouble(0x3fe0187318984b49L), Double.longBitsToDouble(0x3fe2b7c13a15e70eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.Date:Fri Apr 24 00:06:13 PST 221790510\0121=java.util.Date:Fri Apr 24 00:06:13 PST 221790510\012",
        Z.run(T, 2, 8, 8, 11, "\ud9ef\ude47\ud8dd\ude87\ud9d3\uddde\udab0\ude26\ud8a9\udc2d\uda9d\udcc2\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\ud81c\udc48\ud934\udd04\uda78\udf0f\ud943\udc86\u6ac1\udac2\udfc3\ud820\ude42\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u65c7\u65a0\u9e9a\u1071\u2b46\u9b74\u438d\uc218\uad41\uc8a1\ub325\u168c\u63b9\u556d\u7ecb\ua303\ud039\u075a\ucff8\ud604\ub9f9\u1419\u3d76\u0eff\u438e\ud476\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323410075, -6999238344959626183L, -37444L, true, false, (char) 20701, (char) 14807,
        Double.longBitsToDouble(0x3fe28fc6eae692afL), Double.longBitsToDouble(0x3fd2c468cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\000\udba7\udc53\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u1bc8\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d\u81a9\u7fe4\uc7fa\u2372\u4f6a\u63b9\u54af\u7ecb\ua303\ud039\u0aca\000\u700f\ub9f9\u1419\u3d76\u0eff\u438e\ud476\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -37444L, true, false, (char) 20701, (char) 14807,
        Double.longBitsToDouble(0x3fe28fc6eae692bdL), Double.longBitsToDouble(0x3fd2c468cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 11, "\ud9ef\ude47\000\udab6\udc74\ud991\udca2\ud8e2\udd51\uda9d\udc1c\ud80e\udd50\u6272\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udae1\udf0a?\udaa1\ude03\ud9ec\uddb5\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d\u81a9\uadda\uc8a1\000\u4e98\u63b9\u00be\u6f68\u70f0\000\u0691\ua3d4\u700f\ub9f9\u1419\u3d76\uc583\u4ded\ud476\u3f9e", "\udb24\ude54",
        52, -1000, -2133862400, 1389035143936456143L, 17251L, false, false, (char) 26238, (char) 2340,
        Double.longBitsToDouble(0x3fe13ce323a4aab8L), Double.longBitsToDouble(0x3fc1a4d0f1c011b4L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 10, 11, "\ud9ef\ude4d\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\ud890\udcd9\uda47\udd49\uda0f\udd2f", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u884c\u816d\uadda\uc8a1\u2372\u4f6a\u63b9\u556d\u7ecb\ua303\ud039\u075a\ua3d4\ubf77\uba81\u1419\u3d76\u0eff\u438e\ud476\u5b78", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -37444L, true, false, (char) 20701, (char) 14807,
        Double.longBitsToDouble(0x3fe28fc6eae692bdL), Double.longBitsToDouble(0x3fd2c468cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.Date:Thu Feb 06 11:59:56 PST 171916212\0121=java.util.Date:Thu Jul 25 11:59:56 PDT 171916239\012",
        Z.run(T, 2, 8, 9, 11, "\ud9ef\ude47\ud881\udf58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d\u81a9\u9736\u4bcc\u2372\u4f6a\u63b9\u556d\u7ecb\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u3d76\u107a\u87ec\u38de\u1331", "\udaba\udeb3\ud841\ude0e\uda94\udc91\ud80b\udd08",
        28, 97831, -472834503, 5425089469095596184L, -38069L, false, false, (char) 46684, (char) 13076,
        Double.longBitsToDouble(0x3fbc011b5b8db330L), Double.longBitsToDouble(0x3fe28fc6eae692bdL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 6, 4, "\ud9ef\ude47\ud87d\udd58\uda8b\udcf4\udb4c\udf61\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\ud8db\uddb3\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u8c62\u81a9\ubfa2\uc8a1\u2372\u4f6a\u63b9\u556d\u42cd\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u3d76\u0eff\u438e\u6440\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -37444L, true, false, (char) 20701, (char) 14807,
        Double.longBitsToDouble(0x3fe74056eae692bdL), Double.longBitsToDouble(0x3fd2c468cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 13, 7, "\ud9d2\udd14\ud85e\uddd7", "\u01d1\u27a1\u58da\u8409\u545a\u8bf9\u328e\u2611\uad05\u6ef0\u3f1e\u675c\u9baf\u40e8\u8984\u626c\u9bd5\u2ab8\u3855\ub4e6", "\ud8fc\udc2a\ud919\udeb6\uda6c\udfad\udbf1\udc44\ud962\uddbe\ud994\udc3f",
        38, 82236, 424385191, -1171975248251648046L, -80396L, true, false, (char) 39093, (char) 35142,
        Double.longBitsToDouble(0x3fe64a543a57911aL), Double.longBitsToDouble(0x3fe194aa13031932L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\udae6\udeb5\udada\udd3a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\ub398\u6095\u35a9\u2b46\u9b74\u438d\u81a9\uadda\uc8a1\u2372\u4f6a\u63b9\u99cb\u7ecb\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u3d76\u0eff\u438e\ud476\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -37444L, true, false, (char) 20701, (char) 14807,
        Double.longBitsToDouble(0x3fe28fc6eae692bdL), Double.longBitsToDouble(0x3fd2c468cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.util.Date:Sat Jul 15 22:55:16 PDT 9499\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 0, 0, "\ufbee\000\000\ud991\udc35o\000\000\ud93e\ude5f\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\000\000\u934d\u8ce1\u1071\u2b46\ua5e3\ub262\u81a9\uadda\uc8a1\u2372\u4f6a\u63b9\u556d\u0f63\u3313\ud039\u075a\ua3d4\u700f\u9b74\uaf51\u3d76\u0eff\u438e\ud476\u15d7", "\ud947\udd02",
        -2, 79934, -2133862284, 237610475716608L, 17251L, false, false, (char) 0, (char) 8725,
        Double.longBitsToDouble(0x3fe13ce323a4aab8L), Double.longBitsToDouble(0x3fc1a4d0f1c011b4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.Date:Thu Jan 02 04:13:08 PST 113819800\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 8, 15, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\ud8aa\udcae\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u16f4\ua4fb\u8ce1\u1071\u2b46\u9b74\u438d", "\uda63\udc24\uda69\uddc3\ud948\uddd5",
        29, 19174, 679386829, 3591743780661188581L, 17042L, false, false, (char) 25443, (char) 1549,
        Double.longBitsToDouble(0x3fdaf062dac920e0L), Double.longBitsToDouble(0x3fd1ced1a49a76e0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.util.Date:Mon Dec 14 23:38:55 PST 1970\0121=java.util.Date:Mon Apr 15 23:38:55 PDT 1974\012",
        Z.run(T, 2, 8, 6, 11, "\ud9b2\ude59", "\u2e67\u2d0a\u7179", "\ud83d\ude69",
        52, 93798, -479556166, -1354864985L, 54475L, true, true, (char) 33252, (char) 6169,
        Double.longBitsToDouble(0x3fdc40bc643f4f0aL), Double.longBitsToDouble(0x3fc421f528918634L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.Date:Thu Sep 19 03:19:58 PDT 882075\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 0, 11, "", "\u864f", "\udbb7\udc49",
        -5, -1000, -1466684672, 27773456897998848L, -98583L, true, false, (char) 17631, (char) 5194,
        Double.longBitsToDouble(0x3fe1230c6f3a663aL), Double.longBitsToDouble(0x3fb53dd1475578c0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.util.Date:Thu Oct 26 04:36:20 PDT 222750975\0121=java.util.Date:Fri Feb 26 04:36:20 PST 222750979\012",
        Z.run(T, 2, 4, 6, 11, "\ud9ef\ude47\ud913\udcbb\udba0\uddd2\udab5\udd91\ud901\udcc0\uda9d\udc1c\udbdf\ude98\ud957\udcd1", "\u2781\u43d9", "\ud87b\udd6a\uda92\udc9f\ud987\udce3\udb74\udffe\ud83a\udff4\udb3b\udffd\ud961\udf47\ud892\udd55",
        40, 59530, 262785567, 7029279684646580772L, -11395L, false, true, (char) 28487, (char) 11443,
        Double.longBitsToDouble(0x3fe53e4246b9194bL), Double.longBitsToDouble(0x3fee977de6af9a69L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Wed Jul 22 15:47:04 PDT 170181835\012",
        Z.run(T, 2, 14, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udbc6\udcb2\udbcd\udf15\ud952\udf06\udb3b\udfbe\ud987\ude47\ud9aa\udde3", "\u4c75\u283f\u934d\u4ef3\u10c8\u2b46\u9b74\u2c19\u4318", "\ud979\udc95\ud95f\udda0\uda87\udce6",
        49, 59829, 836268016, 5370357719861224137L, -20690L, true, true, (char) 25802, (char) 3606,
        Double.longBitsToDouble(0x3fe1b7841dafa63fL), Double.longBitsToDouble(0x3fb29d0a25fd0360L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda78\udc34\udb86\udd1f\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udb3b\udfbe\ud961\udf47\ud9aa\udde3", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u5812\u1101\u81a9", "\uda69\uddc3",
        0, 93479, -1632341826, 2917944212724412400L, 89129L, true, false, (char) 24395, (char) 3125,
        Double.longBitsToDouble(0x3fe9799281af0692L), Double.longBitsToDouble(0x3fd649070a39da34L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.util.Date:Wed Dec 03 09:26:29 PST 194688034\0121=java.util.Date:Fri Feb 07 04:26:29 PST 194688034\012",
        Z.run(T, 2, 8, 3, 12, "\ud9ef\ude47\ud87d\udd58\ud8c6\udd1c\ud984\ude48\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\udaf3\uddc6\udacf\udf4a", "\u2754\u39f2\u5295\u62cb\u8bdf\u6e23\u54e0\u8398\u0d21\u3168\u6c1b\uaa64", "\ud919\udeb6\ud9b0\udf8f\udadd\udcfc\uda95\udfb9\ud973\udcec",
        43, 62492, 2029655858, -6143949234484410414L, -13462L, true, false, (char) 39022, (char) 6078,
        Double.longBitsToDouble(0x3fe64a543a57911aL), Double.longBitsToDouble(0x3fe194aa13031932L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 0, 14, "\ud9ef\ude47\ud87d\udd58\ud937\udfb4\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud936\uded5\ud9c3\udc71\udb05\udc0a\uda47\udc1d\ud927\uddee\ud87b\udcd8\ud847\udcda\udac2\udcb0\ud94d\udc71\ud952\ude98\uda74\udd99\ud9d5\udf5c\ud85d\udd87", "\u5caf\u8689\u2203\u46bc\u1071\u9a45\u9b74\u438d\ub5bb", "\uda69\uddc3",
        45, 7394, 1357735225, 2917944212724412400L, 89129L, false, true, (char) 1990, (char) 38618,
        Double.longBitsToDouble(0x3fc8e92be6bc18b4L), Double.longBitsToDouble(0x3fd649070a39da34L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.util.Date:Tue Dec 24 16:39:51 PST 156325799\0121=java.util.Date:Sun Dec 22 06:38:51 PST 156325799\012",
        Z.run(T, 2, 3, 5, 15, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udb3b\udfbe\ud945\udef9\ud862\udf0e", "\u5caf\u283f\u52db\u8ce1\u1071\u2b46\uafc9\ua5d9\u81e0", "\uda69\udd3a\ud948\uddd5\uda87\udce6\ud864\udf02\ud87d\udc97\udbfc\ude16\ud961\udc49\udbe5\udc3f\uda91\udc0c\ud86c\udfae\udbe3\udf55\ud88b\udd24\udbc2\udf1b\uda5f\ude37\ud863\udeeb\udbb0\udf19\ud878\udca4\ud85a\udf43\ud913\udcc2\ud873\ude4d\ud944\udf20\udbfc\udc55\ud9bb\udea0\ud808\udebd\ud971\udcb4\ud952\udc9f\udb12\udca6\udba6\udd8c\udab7\ude5b\ud94e\udfb0\udb7b\uded7\ud848\uddd4\u3830\udbce\udd36\uda45\ude73\udbd2\udd7f\ud941\udcc1\uda8a\udc0f\ud88a\ude5e\ud9df\uddb9\udbee\udf53\udb11\udf61\ud947\udcc4\ud93c\ude7d\ud953\udea9\ud942\udc58\ud920\udd43\ud86c\udd9c\ud957\ude04\udbae\uded7\ud9bd\udd88\u7af8",
        59, 59100, 527791109, 4933103598970791181L, 55032L, false, false, (char) 6694, (char) 40136,
        Double.longBitsToDouble(0x3fec5ac71cf9657aL), Double.longBitsToDouble(0x3fda32ef856791faL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.util.Date:Sat Feb 09 09:57:44 PST 75719895\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 0, 4, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda8c\udd42\ud80e\udd50\ud957\udcd1\udad6\udf06\ud917\ude80\uda4e\udc35\ud8a9\udda5\ud81f\udce1\ud843\udd02\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udb3b\udfbe\ud961\udf47\ud9aa\udde3", "\u5d01", "\ud919\udeb6\u33de\ud84f\udd43\ud959\ude13\ud965\udebb",
        43, 82236, 424385191, 2389426902205064302L, -71138L, true, false, (char) 39022, (char) 35261,
        Double.longBitsToDouble(0x3fe64a543a57911aL), Double.longBitsToDouble(0x3fe194aa13031932L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.util.Date:Thu Dec 16 12:47:48 PST 112065943\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 0, 11, "\ud9ef\ude47\uda39\udfd5\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud9ce\ude4e\udbb3\udf81\ud83d\ude69\ud8c7\ude21\udafc\udfe0\ud9dd\udcd5\ud93d\ude47\uda80\udf00\udb50\udf87\ud907\udc65\uda63\udd98\ud85c\ude09\ud95f\udf82\udb3b\udfbe\ud961\udf47\ud9aa\udde3", "\u5d58\u27d5\u934d\u7bea\u103a\u2b46\u9b74\u2419\u81a9\uadda\uc8a1\u2372\u0d1b\u68e3\u5559\u7ecb\u3903", "\uda91\udc0c\ud86c\udfae\udbe3\udf55\ud88b\udd24\udbc2\udf1b\udbc1\udc46\udb70\udd61\uda4d\udffb\uda8c\ude52\udbef\udc24",
        18, 90002, -444849585, 3536397436189668592L, 65289L, true, false, (char) 27208, (char) 60077,
        Double.longBitsToDouble(0x3fe2a645868b1a17L), Double.longBitsToDouble(0x3fe6362f08b53b5eL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.util.Date:Tue Feb 18 18:06:52 PST 92467941\0121=java.util.Date:Tue Feb 18 18:06:52 PST 92467941\012",
        Z.run(T, 2, 6, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udb3b\udfbe\ud961\udf47\ud9aa\udde3", "\u5caf\u283f\u934d\u8ce1\u0944\u2b46\u9b74\u4c9a\u81a9", "\uda69\uddc3",
        0, 93479, -1632341826, 2917944212724412400L, 89129L, true, false, (char) 24436, (char) 3125,
        Double.longBitsToDouble(0x3fc8e92be6bc18b4L), Double.longBitsToDouble(0x3fd649070a39da34L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.util.Date:Fri Feb 21 02:52:28 PST 66615547\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 0, 0, "\uda91\uddf0\ud87d\udd58\ud93b\uddb1\ud8ab\ude26\ud913\udc35\udb39\udf35\udafe\udc4c\ud81d\udd9e\ud83d\uddd9\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a", "\u4e33\u675c\u62cb\u40e8\u8984\ua495\u797a\u2a74", "\ud90c\udf0b\udac2\ude60\ud8fc\udc2a\u0eab\udb06\udf3f\udadd\udc27\u00e3\ud94b\udce4\ud861\udc50\000\uda62\udf7d\uda69\uddc3\ud948\uddd5\uda25\udeb6\000\ud9a7\udebe\udbfc\uddef\udbe5\udfec\000\uda8a\udcb5\ud83a\uddae\udbc0\uddae\ud88b\udd24\udbc2\udf1b\udbc1\udc46\udad4\udd9c\udb04\udff8\ucdd0",
        -1, 98174, 1432112461, 2102121456951148366L, -24251L, true, true, (char) 40740, (char) 99,
        Double.longBitsToDouble(0x3fc30960195be09cL), Double.longBitsToDouble(0x3fe000077a271072L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 14, 12, "\uda91\uddf0\ud87d\udd58\ud93b\uddb1\ud8ab\ude26\ud913\udc35\udb39\udf35\udafe\udc4c\ud81d\udd9e\ud83d\uded8\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a", "\u4e49\u675c\u62cb\u25e1\u8984\u626c\ua4ec\u2a74", "\ud90c\udf0b\udac2\ude60\uda76\udec9\u42eb\udb06\udf3f\udadd\udc27\ud962\uddbe\ud965\ude0e\udb77\udf5c\udadd\udca2\uda63\udc24\uda69\uddc3\ud948\uddd5\uda87\udce6\ud95f\udd3e\udb9e\udd19\ue2be\ud961\udc49\udbe5\udc3f\uda8a\udcb9\uda55\udd82\udbc5\uddf3\ud88b\udd24\ud899\udc48\u9cf3\udbc1\udc95\udbf5\udf1b\ucdd0",
        -1, 86790, 1432112461, 2102121457085366094L, -24251L, true, true, (char) 40885, (char) 55397,
        Double.longBitsToDouble(0x3fc30969395be09cL), Double.longBitsToDouble(0x3fd5039ff5522e32L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.util.Date:Thu Jan 16 12:32:47 PST 26893490\0121=java.util.Date:Thu Jan 16 12:32:47 PST 26893490\012",
        Z.run(T, 2, 5, 5, 12, "\uda91\uddf0\ud87d\udd58\ud93b\uddb1\ud8ab\ude26\ud8c8\udc70\ud827\ude8b\udae2\udf28\ud81d\udd9e\ud83d\uded8\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a", "\u4e33", "\udba7\udf38\ud952\udf06",
        -4, 6425, 901319368, 848614407251807684L, -33279L, false, false, (char) 58740, (char) 5781,
        Double.longBitsToDouble(0x3fd1531d4bc7e08aL), Double.longBitsToDouble(0x3fd2a4172a88a606L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.util.Date:Thu Feb 04 17:05:52 PST 1971\0121=java.util.Date:Tue Oct 01 17:05:52 PDT 1974\012",
        Z.run(T, 2, 8, 6, 11, "\u00ee", "", "",
        57, 23698, 282849747, 90352592L, -5210L, true, false, (char) 43207, (char) 56049,
        Double.longBitsToDouble(0x3fe110e8e1d6efa1L), Double.longBitsToDouble(0x3fe617647edfc1b0L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 11, 3, "\ud885\ude52\ud87d\udd58\udab6\udc74\ud991\udca2\ud83b\udee1\uda9d\udc77\ud80e\udd50\ud957\udcd1\ud844\udf69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\udb6b\udcac\udac2\udc60\udbcd\udf15\ud952\udf06\udaad\ude76\ud99f\ude63\uda0f\udc51", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46", "\ud828\udd54\ud8cf\udc54\uda63\udc24\uda69\uddc3\ud948\uddd5",
        -4, 25087, 679386829, 3591743780661188581L, -8439L, false, false, (char) 3125, (char) 34342,
        Double.longBitsToDouble(0x3fdaf062d6c920e0L), Double.longBitsToDouble(0x3fd1ced8c49a76e0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Sun Jan 11 03:19:21 PST 1970\012",
        Z.run(T, 2, 10, 2, 11, "\ud885\ude52\ud97a\udd96\udbd2\udd29\ud991\udca2\ud83b\udee1\uda9d\udc77\ud80e\udd50\ud957\udcd1\ud844\udf69\uabd0\ud9c2\udfad\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\udb6b\udcac\u3186\udba7\udc53\ud952\udf06\udaad\ude76\ud99f\ude63\uda0f\udc51", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46", "\000\ud8cf\udc54\uda63\udc24\uda69\uddc3\ud948\uddd5",
        -4, 25087, 40653, 1250361344L, -8439L, false, false, (char) 6450, (char) 0,
        Double.longBitsToDouble(0x3fd000000ac920e0L), Double.longBitsToDouble(0x3fd1ced1a49a76e0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jul 01 23:05:54 PDT 167547038\0121=java.util.Date:Sun Jul 01 23:05:54 PDT 167547038\012",
        Z.run(T, 2, 2, 2, 11, "\ud885\ude52\ud87d\udd58\udab6\udc74\ud991\udca2\ud83b\udee1\uda9d\udc77\ud80e\udd50\ud957\udcd1\ud844\udf69\ud8cf\udc21\ud9c2\udfe3\ud8d2\udca3\uda70\ude1b\uda4e\udf47\ud845\uddb7\udb6b\udcac\udac2\udc60\ud820\udefe\ud933\udd0f\udaad\ude76\ud99f\udc63\uda0f\udc51", "\u1c16\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d", "\uda63\udc24\uda69\uddc3\ud948\uddd5\ud9c1\uddf1\ud9f4\udc14\udbae\udd2f\udbfc\udedf\ud961\udc49",
        52, 32775, 422758962, 5287211679967554503L, 91844L, false, true, (char) 34237, (char) 40140,
        Double.longBitsToDouble(0x3fcf3e7c9bb75984L), Double.longBitsToDouble(0x3fef9e2862e1e9a9L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 0, 3, 0, "\ud9ef\udd59\000\000\000\ud901\udcc0\uda9d\udc1c\ud920\ude8f\ud957\udcd1\ud83d\ude69\uabd0\000\ud9db\udcb4{\000\ud87b\udcb7\ud968\ude8e\u314d\u9a00\u83f1\udb93\udca8\ud904\uddbc\udb23\udeb8", "\u383e\u1c9a\000\000\u4264\u0229\u9659\u0904\u6565\uadda\uc8a1\u2372\u4f6a\u797c", "\udbfc\udedf\ud9e3\udceb\ud961\udfd4\ud976\udf9b\ud86c\udfae\udbe3\udf55\u00c7\udbc2\udf1b\udbc1\udc46\u2d1c\udb66\uddb2",
        -4, -826, 448931790, 9184332008202714196L, -89876L, false, false, (char) 207, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb5be09fb55a000L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\ud9ef\udd59\000\000\000\uda61\ude21\uda9d\udcc3\ud80c\udee6\ud957\udcd1\ud83d\ude69\uabd0\000\udb05\udc0a\000\000\ud87b\udcb7\u31fe\u31d6\u9a00\000\000\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u00a1\000\000\034\u2b46\u9b74", "\ud98f\udc9b",
        56, 29249, -1704392750, 7602171478988320958L, -71344L, true, true, (char) 135, (char) 0,
        Double.longBitsToDouble(0x3fe194aa13031932L), Double.longBitsToDouble(0x3fc8e92be6bc0000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 4, "\ud9ef\udd59\000\ud9e8\udf94\u4522\ud901\udcc0\uda9d\udc1c\ud80c\udee6\ud957\udcd1\ud83d\ude69\uabd0\000\udb05\udc0a\udb7e\udd7e\udaf7\udd22\ud972\udc62\uda6c\udc4f\ud814\udd7a\u6c8b\000\000\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u0256\000\000\034\u2b46\u9b74\u0904\u6565\uadda\uc8a1\u2372\u4f6a\u63b9", "\udbfc\udedf\udbe5\udfec\000\uda6a\uddb5\ud86c\udfae\udbe3\udf55\u00c7\udbc2\udf1b\udbc1\udc46\u2d1c\udb66\uddb2",
        -4, -826, 448931790, 6150876184201673812L, -89455L, true, true, (char) 39375, (char) 0,
        Double.longBitsToDouble(0x3e39381800000000L), Double.longBitsToDouble(0x3fc5f12528579c00L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 11, 13, 13, "\ud8f9\udd5d\000\000\000\ud901\udcc0\uda9d\udc1c\ud80c\udee6\ud957\udcd1\ud83d\ude69\uabd0\000\udb05\udc0a\udb65\ude3e\udacd\udd25\ud8a7\ude46\u31fe\uda15\udf7a\ud8e7\udcfe\000\000\uda8a\udfd6\ud9d9\uddf2\u1306\ud886\udc8d", "\u12e2\000\034\u2b46\u9b74\u6d96\u6565\uadda\u7e4b\u4a44\u4f6a\u63b9\u3c3e\u6dad\ua303\u5885\000\u097d\u700f\ub9f9\u00c7\u3d76\u0eff\u1c84", "\ud880\udd16\udab2\udd61\udb24\ude54",
        40, 3457, 13606772, 207L, -100000L, false, false, (char) 63613, (char) 2326,
        Double.longBitsToDouble(0x3fd887ccc27416e2L), Double.longBitsToDouble(0x3fd9f947735876deL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\ud9ef\udd59\000\000\000\ud901\udcc0\uda9d\udc1c\ud80c\udee6\ud957\udc5f\ud83d\ude69\uda1d\ude09\000\udb05\udc0a\000\000\ud8ac\udfb7\u31fe\u31d6\u9a00\000\000\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u00a1\000\000\034\u2b46\u9b74\u0904\u6565\uadda\uc8a1\u2372\u4f6a\u63b9", "\udbfc\udedf\udbe5\udfec\000\uda6a\uddb5\ud86c\udfae\udbe3\udf55\u00c7\udbc2\udf1b\udbc1\udc46\u2d1c\udb66\uddb2",
        -4, -826, 448931790, -1368446345306100508L, -89876L, false, false, (char) 207, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fb5be09e0af3800L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.util.Date:Thu Sep 03 07:42:05 PST 289735456\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 5, 0, 0, "\ud9ef\udd59\000", "", "\ud80c\udee6\ud957\udcd1\ud83d\ude69\uabd0\000\udb4c\udcaeu\000\ud87b\udcb7\u31fe\u31d6",
        29, -1000, -1946157056, -9143417740812414121L, 18212L, true, false, (char) 4170, (char) 0,
        Double.longBitsToDouble(0x3f3b7fd800000000L), Double.longBitsToDouble(0x3feae465f2d2f2f2L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\udb86\ude8c\ud971\udd71\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude1a\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\ud94a\udd15\ud9d9\uddb3", "\u948a\u65df\u93f1\u8ce1\u1071\u2b53\u9b74\u438d\u8222\uadda\uc8a1\u2372\u4f6a\u63b9\u556d\u7ecb\ua303\u8a95\u134b\u2e1c\uc8de\uaa13\u1419\u3d76\u0eff\u2901\ud476\u15d7", "\udbbc\udec3\udac7\uded5\u187d\udb56\udfc2\ud827\udc50\udae8\udd7f\uec00\udb53\udebf\uda88\udc21",
        20, 58979, -1430781401, 2776199824359099533L, -20170L, true, false, (char) 37348, (char) 11869,
        Double.longBitsToDouble(0x3fb352b95c055058L), Double.longBitsToDouble(0x3fe0934048c8c1aeL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.util.Date:Mon Oct 02 20:09:47 PDT 222750975\0121=java.util.Date:Mon Oct 02 20:09:47 PDT 222750975\012",
        Z.run(T, 2, 3, 3, 1, "\ud9ef\uddb8\udb39\udde1\ud95b\udce4\ud991\udca2\udb94\udd1e\uda4f\udf15\ud828\udffa\udb3f\udc9b", "\u2781\u43d9", "\ud87b\udd6a\uda92\udc9f\ud897\udefb\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud973\udf5f",
        6, 93740, 262785567, 7029279682607387172L, 45962L, true, true, (char) 20265, (char) 4409,
        Double.longBitsToDouble(0x3fb10aeaff256670L), Double.longBitsToDouble(0x3fe53e420352dc3dL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 12, 1, "\ud9ef\ude47\ud866\udd58\udab6\udc74\ud991\udc7d\udb94\udd1e\uda4f\ude88\ud828\udffa\udb3f\udc9b", "\u2781\u43d9", "\ud87b\udd6a\uda92\udc9f\ud897\udefb\uc71e\udb5a\udfb0\udb9f\udec2\udb90\ude7d\ud973\udf5f",
        6, 93740, 262785567, 7029279684419326500L, -11395L, false, true, (char) 28487, (char) 19634,
        Double.longBitsToDouble(0x3fe53e4207b9194bL), Double.longBitsToDouble(0x3fee977de6af9a69L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 13, 8, "\ud9ef\ude47\ud866\udd58\udab6\udc74\ud991\udca2\udb94\udd1e\uda4f\ude88\ud828\udffa\udb3f\udc9b", "\u2781\u43d9", "\ud87b\udd6a\ud866\udc09\udba7\udee1\ud9fa\uddc9\ud952\udf06\udaad\ude76\uda8a\udfd6\ud973\udf5f",
        6, 93740, 262785567, 6991911682237731364L, -11395L, false, true, (char) 28487, (char) 19634,
        Double.longBitsToDouble(0x3fe53e4207e9cc4bL), Double.longBitsToDouble(0x3fee977de6af9a69L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 11, "\ud9ef\ude47\uda9e\udc68\udab6\udc37\ud991\udca2\ud901\udcc0\uda9d\udc1c", "\u3bf3\u0232\u2781\u43d9\u688e", "\ud98c\ude4e",
        6, 59346, -1094971681, 2304981998399696977L, 89792L, false, true, (char) 1791, (char) 32815,
        Double.longBitsToDouble(0x3fe1230a7f3a663aL), Double.longBitsToDouble(0x3fee6fba2dea7a41L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 13, 11, "\udabb\udd2c\ud879\udd6f\ud925\ude2d\ud98c\udfc8\ud877\udd1a\ud9e5\udedf", "\u3bf3\u0232\u2781\u5b8f\u9d2a\u57c1", "\udac2\udcb0\udbcd\udf23\ud988\udec0\udb28\udf9f",
        43, 40184, 726658612, -1980046447941705095L, -50355L, false, true, (char) 11074, (char) 34257,
        Double.longBitsToDouble(0x3fe8f46237e2c2e9L), Double.longBitsToDouble(0x3fd7d4600112b8c4L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.util.Date:Fri Sep 11 23:26:31 PDT 131836207\0121=java.util.Date:Fri Sep 11 23:26:31 PDT 131836207\012",
        Z.run(T, 2, 7, 7, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud8d3\udfb7\ud901\udd1a\ud976\udf19\ud9d2\udf69\uda26\uddd8\udb3b\udfbf\ub40f\ud8dc\uddd5\ud95f\udeb6\uda30\udea7\ud87b\udc3e\udb2c\udd87\ud938\udee2\udac2\udc11\udbcd\udf15\ud952\udf06\udabf\udd96\udb7e\udd6f\udac2\udc91", "\u5caf", "\ud8c8\udd49\udb97\udde4\udb8e\udc8b\uda4c\udd4b\ud90a\udc57",
        38, 37622, 424385191, 4160286710893553958L, 63027L, false, true, (char) 11511, (char) 11121,
        Double.longBitsToDouble(0x3fe754aa13a5a632L), Double.longBitsToDouble(0x3fca8246d9154664L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 10, 11, "\udbc6\udde6\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud910\udc2d\ud83d\ude44\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud9c5\uded0\uda0e\udc3a\uda81\udfa7\udbde\udda4\ud952\udf06\ud94b\ude25\udaa8\uddd6\ud9d9\uddf2", "\u0250\u2ac3\u98c9\u17d8\ua0f3\u5efb\u9b74\u438d\u81a9\uadda\uc8a1\u111a\u4f6a\u63b9\u7a45\uc73a\ua303\ud039\u075a\ua3d4\u700f\ub9f9\u1419\u3d76\u5073\u2657\ud476\u15d7", "\udb24\ude54\ud806\udce0",
        41, 86252, 323410170, -6999238344959626183L, -43189L, true, false, (char) 46684, (char) 13076,
        Double.longBitsToDouble(0x3fbc011b5b8db330L), Double.longBitsToDouble(0x3fe28fc6eae692bdL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.util.Date:Mon Apr 17 05:10:04 PST 56124627\0121=java.util.Date:Mon Apr 17 05:10:04 PST 56124627\012",
        Z.run(T, 2, 9, 9, 11, "\udac2\ude6f\ud88c\ude18\udab6\udc74\ud991\udcef\ud901\udcc0\uda9d\udc36\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud8b4\udcf0\udb45\udd94\ud84c\udfb3\udbf4\udd74\ud81c\udee7\ud98b\udcda\uda0c\udfd5\ud92e\udd74\ud957\udf47\udaad\ude76\uda8a\udfd6\udabf\uddc0", "\u0549\u12d8\u8254\u080a\ub96f\u2b46\u9b74\uab0f\u81a9\uadda\u28bd\u2372\uc84e\u592f\ud43d\u782d\u6a1f\ucfeb\u06dd\ua3d4\u700f\ub9f9\u1419\u375c\ub27d\u438e\ud476\u15d7\u20e4\ub784\u6a78\u56e7\u14fe\u1461\uaef3\u0264\u8da2\u5b3e\ubf4b\ua8c5\u54bd\u997d", "\ud89b\uddf4\ud94a\udf05\ud824\udf5b\ud925\udf0e\udb73\udf48\ud918\udfe2\udbb8\udea1\udbf4\udcb4\ud9c4\udc49\udafc\udd9e",
        15, 2283, -1182344924, -1771221128986195338L, -46792L, true, true, (char) 3481, (char) 38391,
        Double.longBitsToDouble(0x3fdf0a86f25d9d08L), Double.longBitsToDouble(0x3feee86ce63c5097L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.util.Date:Tue Jan 14 13:28:23 PST 187397881\0121=java.util.Date:Tue Jan 14 13:28:23 PST 187397881\012",
        Z.run(T, 2, 4, 4, 11, "\ud9ef\ude47\ud913\udcbb\udba0\uddd2\udab5\udd91\ud901\udcc0\uda9d\udc1c\uda95\udd32\ud89d\udd19", "\u2781\u43d9", "\ud8c8\udc41\uda91\udfa6",
        37, 2174, 1741614550, -5913889504079496385L, -35730L, false, false, (char) 17631, (char) 5194,
        Double.longBitsToDouble(0x3fe1230c6f3a663aL), Double.longBitsToDouble(0x3fb53dd159841f40L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.util.Date:Sun Aug 05 22:00:24 PDT 252014221\0121=java.util.Date:Sun Aug 05 22:00:24 PDT 252014221\012",
        Z.run(T, 2, 1, 1, 5, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udde4\ud856\udc30\ud985\udfcd\ud8ce\udfa8\uda62\udc12\udb05\udc0a\uda78\udc34\uea75\uda29\udf13\uda91\udfdd\udac2\udcb0\udb99\udf3b\ud952\udf06\ubfb9\ud961\udf47\ud9aa\udde3", "\ucec2\u0246\ub8b0\u8ce1\u9ce3\u549d\u3a89\u1101\u81a9", "\udb71\uddc6\ud8f0\udd1d\uda9c\udc50",
        14, 59829, 836268016, 7952738526997164285L, -98873L, true, true, (char) 25983, (char) 6393,
        Double.longBitsToDouble(0x3fd320d20a39db88L), Double.longBitsToDouble(0x3fd5005c05219db8L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 10, "\ud9ef\ude47\ud87d\udd58", "\u2d0a\u2285\u6885\u59a6\u1ddd\uc107\u280f\u5cbd\u31ca\u7a8a\u6fa1\u0b82\u62cb\u3e6c\u31a2\ud2f5\ubb6d\ub7f1\ua9e8\u27cb\u5caf\u17c1\u2463\u475a\u1071\u9a45\u9b74\u438d\ub5bb\uadda\uc8a1\u2372\u3bf1\u35ba\u5523", "\udac0\uddd5\udaef\udc43",
        17, 84688, 1230967797, 445078761704040879L, 85060L, false, true, (char) 3320, (char) 15822,
        Double.longBitsToDouble(0x3fe99321088e4d51L), Double.longBitsToDouble(0x3fd048a8daf499dcL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 11, "\ud885\ude52\ud97a\udd96\udbd2\udd29\uda94\udc44\ud83b\ude9e\uda9d\udc77\ud80e\udd50\ud957\udcd1\ud844\udf69\ud88b\udfff\ud994\udc15\ud8e1\ude92\udaf8\ude52\uda94\udde4\udbc7\udd70\udb6b\udcac\u3186\udba7\udc53\ud952\udf06\udaad\ude80\ud99f\ude63\uda0f\udc51", "\u5caf\u283f\u4ac7\u96b7\u1071\u2b46", "\000\ud8cf\udc54\uda63\udc24\ud852\ude32\ud968\uddba",
        -4, 25087, 40653, 1248460800L, -8439L, false, false, (char) 6450, (char) 0,
        Double.longBitsToDouble(0x3fd000000ac920e0L), Double.longBitsToDouble(0x3fd1ced1a49a76e0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 6, 11, "\ud9ef\ude47\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\ud80e\udd50\ud957\udcd1\ud83d\ude69\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude76\uda8a\udfd6\ud9d9\uddf2", "\u5caf\u283f\u934d\u8ce1\u1071\u2b46\u9b74\u438d\u81a9\uadda\uc8a1\u2372\u4f6a\u63b9\u556d\u00cd\000\000\000\000\u700f\ub9f9\u1419\u3d76\u0eff\u438e\ud476\u15d7", "\udb24\ude54\ud841\ude0c",
        34, 64716, 323409947, -6999238344959626183L, -37444L, true, false, (char) 20701, (char) 14807,
        Double.longBitsToDouble(0x3fe28fc6eae692bdL), Double.longBitsToDouble(0x3fd2c008cd6c47b2L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 14, 2, "\ud998\ude7a\uda66\ude0f\udab6\udc74\ud991\udca2\udb94\udd1e\uda4f\ude88\ud828\udffa\udb3f\udc9b\ud8c2\udd0b\udbb7\ude35\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a", "\u4055\u8984", "\ud973\udf5f\udb3e\udec8\ud886\udc8d\ud90c\udf0b\udac2\ude60\udbb9\udf5d\udb1f\udca2\ud9b0\udfe4\udadd\udcfc\uda0c\udd14\udb0a\udda0\u02ff\u6e3b\uda37\ude86\uda6b\udec3\ud84c\udee7\ud95a\udff0\ud87d\udee9\udb94\udec1\uda6d\udce0\udbc4\udeed\ud8c1\udcb0\uda3b\uddcc\ud8f0\udfbb\udaa6\udf7a\udb20\udf3d\ud8d9\udc8e\ud938\udd9a\ud9d6\udfc0\ud8c9\udd3b\udb05\udf03\ud90f\udc72\ud909\udc52\ud80c\ude39\udbbd\udc66\ud8c9\udde6\ud9b2\udc57\uda98\udd6f\ud837\udced",
        -3, 80401, 749525118, 3706120091282046006L, -24994L, true, true, (char) 31834, (char) 62045,
        Double.longBitsToDouble(0x3faa54ffb44b43d0L), Double.longBitsToDouble(0x3fdd14d606fe774aL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 2, "\ud998\ude7a\uda66\ude0f\udab6\udc74\ud991\udca2\udb94\udd1e\uda4f\ude88\ud828\udffa\udb3f\udc9b\ud8c2\udd0b\udbb7\ude35\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\ud87b\udd6a", "\u4055\u51a9", "\ud973\udf5f\udb3e\udec8\ud886\udc8d\ud90c\udf0b\udac2\ude60\udbb9\udf5d\udb1f\udca2\ud9b0\udfe4\udadd\udcfc\uda0c\udd14\udb0a\udda0\u02ff\u6e3b\uda37\ude86\uda6b\udec3\ud84c\udee7\ud95a\udff0\ud87d\udee9\udb94\udec1\uda6d\udce0\u72ca\ud8c4\udc45\uda3b\uddcc\ud8f0\udfbb\udaa6\udf7a\udb20\udf3d\ud8d9\udc8e\ud938\udd9a\ud9d6\udfc0\ud8c9\udd3b\udbcd\udec9\ud90f\udc72\ud909\udc52\ud80c\ude39\udbbd\udc66\ud8c9\udde6\ud9b2\udc57\uda98\udd6f\ud837\udced",
        -3, 80401, 749525118, 3706120091282046006L, -24994L, true, true, (char) 31834, (char) 62045,
        Double.longBitsToDouble(0x3faa54ffb44b43d0L), Double.longBitsToDouble(0x3fdd14d606fe774aL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.util.Date:Mon May 10 10:50:56 PDT 256841632\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 10, 11, "\ud87b\udec2\ud936\udc7a\ud9ba\udc76\uda6f\uded2\ud901\udcc0\ud9b5\uddb4\ud9bd\udfd1\ud957\udcd1\ud83d\ude69\ud805\udc1c\ud9c2\udfe3\udb05\udc0a\uda57\ude24\uda94\udde4\udb59\udc6e\uda92\udc9f\udac2\udcb0\udbcd\udf15\ud952\udf06\udaad\ude25\udbbb\udf6e\ud9d9\uddf2\uda9c\udf11\ud886\udc8d\ud90c\udf0b\udac2\ude60\uda8e\uddb1\ud92c\udcf4\ud9b0\udf8f\ud8f0\udfe6\ud962\uddbe\ud965\ude0e\uda5a\udd62\ud959\udc54\u6d47\udac1\udd3b\udb50\udd61\ud97c\udf36\ud8c9\udd95\udbae\udd2f\udb3d\udeac\ud9f5\udfaa\ud9d9\udd59\udb68\ude70\ud91c\udcfd\udbe3\udf55\ud88b\udd24\udbc2\udf1b\udbc1\udc46\udace\udc9c\udaf2\udc1b\udab7\udf10\udb6e\udfe0\udab2\udd61\ud843\udf4d\uda2f\udfd2\udb38\udcc8\ud878\udcf5\ud835\udf39\ud880\udc5e\ud81b\udcbb\udb53\ude72\uda88\udc21\udaab\udcdd\ud81c\udc76\ud8bf\udefe\ud8cf\udde9\udb09\udccf\uda66\udc19\ud94a\udf05\ud99a\udfd7\ud87f\udffb\ud970\udf43\uda71\ude65", "\u1765\u8169\u3972", "\ud86b\udedd\ud841\udea8\ud82a\udcf9\udaca\udcbc\ud977\udc6c\ud963\udcea\udaa5\ude2d\udad0\udf71\ud89c\udc96\udbdd\udc51\ud83a\uddba\udb7a\udc62\uda64\udc89\udbef\udc4a\udbe7\udfeb\uda0b\udc7f\udb01\udc00\ud9b3\udca2\ud973\udc8f\udbb4\udd82\ud97f\udcd8\udafc\udf51\udba4\udc75\ud9a0\udec6\ud8fe\udff1\u6f3b\uda02\udc3d\u204a\udb5f\udd7d\ud8da\udeea\ud96e\udd6c\udbcd\ude89\udb1b\udf1d\udb10\ude11\ud83e\udc80\ud941\ude85\ud9d8\udd02\udb7d\uddb4\uda5a\udc56\udb0d\uddfe\ud815\udfe2\udb47\uddab\ud9dd\udeca\ud815\ude03\ud937\udfed\uda65\udde9\ud998\uddda\ud914\udcf9\udbf0\udc9a\udaca\ude11\ud963\uddaa\uda01\udf9d\ud835\udc3f\uda22\ude0e\udb4b\udd81\ud814\udf03\ud908\ude90\u0edf\udb1c\ude26\u95c8\ud84c\udd7d\uda95\udde3",
        43, 13935, -1456112557, 8105076870717056305L, 76939L, false, false, (char) 58470, (char) 4690,
        Double.longBitsToDouble(0x3fd63c5abcd1e63cL), Double.longBitsToDouble(0x3fe092f4da288a3aL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.util.Date:Tue Jul 04 14:33:32 PDT 150994209\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 14, 11, "\u3800", "\u9998\000\ua507", "\ud83d\ude14",
        47, 53296, -479556166, 4764854854474412455L, 92455L, false, false, (char) 2701, (char) 38591,
        Double.longBitsToDouble(0x3ec78cfeb7b40000L), Double.longBitsToDouble(0x3fe5c8000277adf8L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 11, "\u3800", "\u9998\ubdfa\u3c95", "\ud83d\udeb6",
        47, 53296, -479556114, 4764854854474412455L, 92455L, false, false, (char) 2701, (char) 38591,
        Double.longBitsToDouble(0x3ec78cfeb7b40000L), Double.longBitsToDouble(0x3fae0000277432e0L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 0, 8, "\ud9ef\ude54\ud87d\udd58\udab6\udc74\ud991\udca2\ud901\udcc0\uda9d\udc1c\udaa0\uddb9\uda4b\ude29\ud83d\uddfb\ud8cf\udc21\ud9c2\udfe3\udb05\udc0a\udac3\uddea\ud8a9\ude95\ud933\udfb8\ud815\ude2f\ud812\udcae\udbcf\udf14\ud952\udf06\ucfba\udbcd\ude1b\ud9d9\uddf2\uda9c\udf11\ud886\udc8d\ud90c\udf0b\udac2\ude60\ud8fc\udc2a\ud919\udeb6\ud9b0\udf8f\udadd\udcfc\ud962\uddbe\ud965\ude0e\udb77\udf5c\ud98f\udc9b\uda63\udc24\udb53\udcb7", "\u556d\u7ecb", "\udbe5\udc3f\uda91\udc0c\ud86c\udfae\udbe3\udf55\ud88b\udd24\udbc2\udf1b",
        -1, 7862, 1678344702, -1021994231909189899L, 14510L, false, false, (char) 22762, (char) 24505,
        Double.longBitsToDouble(0x3fd3dc14548bb8e6L), Double.longBitsToDouble(0x3fc30969256be09cL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 10, 10, 11, "\udaae\ude57\ud97a\udd96\udbd2\udd29\uda94\udc44\ud83b\ude9e\uda9d\udc77\ud80e\udd50\ud957\udcd1\ud844\udf69\ud88b\udfff\ud994\udc15\ud8e1\ude92\udaf8\ude52\uda94\udde4\udbc7\udd70\udb6b\udcac\u3186\udba7\udc53\ud952\udf06\udaad\ude80\ud878\udd70\uda0f\udc51", "\u5caf\u283f\u4ac7\u96b7\u1071\u2b46", "\000\ud8cf\udc54\uda63\udc24\ud852\ude32\ud968\uddba",
        -4, 25087, 40653, 0L, -8439L, false, false, (char) 6450, (char) 0,
        Double.longBitsToDouble(0x3d920e0000000000L), Double.longBitsToDouble(0x3e32680000000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.time.DateUtils|modify|java.util.Calendar,int,boolean|static",
    "M|org.apache.commons.lang.time.DateUtils|add|java.util.Date,int,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addDays|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addHours|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMilliseconds|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMinutes|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMonths|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addSeconds|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addWeeks|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addYears|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameDay|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameDay|java.util.Date,java.util.Date|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameInstant|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameInstant|java.util.Date,java.util.Date|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameLocalTime|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|iterator|java.lang.Object,int|static",
    "M|org.apache.commons.lang.time.DateUtils|modify|java.util.Calendar,int,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
