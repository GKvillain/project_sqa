package org.apache.commons.lang.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud9dd\uddcd\uda81\udf8d\udb25\ude73\ud99f\udf67\ud84b\ude78\udaaf\udf9f\ud912\ude05\ud9ef\uddec\ud90c\udc25\uda9c\udfb9\udbaa\ude10\udb4b\udf84\ud8d1\udffa"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud9dd\ude4f\uda81\udf8d\udb25\ude73\udba3\udf69\ud84b\ude78\udaaf\udf9f\ud912\ude05"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\udaf2\udd84"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud843\uddc8\uda6e\udc4f\ud9c2\udfbd\u7201\uda00\udeb7\udb8a\udffe\udb68\udf38\ud99e\udd28\ud8ad\udcff\udbc3\udec8\ud9e6\ude0e\ud831\udf51\uda00\udd52\udb00\udcbe\ud9dd\udf5f\ud9a6\udfc8\uda75\udc05\ud88d\udddb\udb17\udd4e\udbc0\ude18\ud87f\udd03\ud9b0\udfc5\udab8\udcae\uda03\uded3\udb3b\ude74\ud9de\udf12\udb41\ude8f\ud9b9\udd9d\ud90e\udff3\udb3d\udc68\udbcd\udf03\u09b4\udb49\udf80\uda98\ude1c\ud977\udd36\uda6a\udc39"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud9aa\udcf4\ud8a8\udc80\udbf1\udda4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u1f83\udaa5\udc73\ud87d\uddda\ud99f\udf85\ud84b\ude78\ud92c\udcf8\ud9cb\udfba\ud9ef\ude58\ud90c\udc25\uda37\udf68\ud993\udd26\udb4b\udf84\udab5\udd0b\ud80c\udc44\udad6\udfba\ud82e\udd1b\ud9bb\ude0b\ud873\udd55"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u5b6b\uda81\udf8d\uda2c\udc56\000\000\uda94\udd6a\u00a4\ud9ef\uddec\ud90c\udc25\uda9c\udfb9k\ud9be\udedfD"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u5b6b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\011"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uda31\udca0\uda2f\udc38\ud9aa\udefb\ua184\ud809\udcd1\udaa7\udca6\ud825\udc3f\ud876\udfcb\uda67\udd75\udab8\udd60\uda6e\udecc\ud93d\udd3e\udb05\ude9e\ud970\udf6a\udad3\udf72\ud90b\udf59\ud94b\udf1f\udbc1\udcda\ud9b4\udefb\ud925\udea7\u21ca\udafc\ude97\udb90\udd99\udba5\udfd4\ud81b\udfc5\udab1\udfe0\udae6\udcb7\udb10\ude46\ud897\udfe3\ud863\udfc6\udab3\udea8\ud8f7\ude1e\udb65\udf2f\ud91c\udd5d\ud963\udf85\u0e87\ud8b9\udeb8\udb6b\uddd4\ud83a\uddfb\udba7\udfda\ue7a0\uda80\udd3e\ud9dc\udf27\ud804\ude09\udbee\ude55\udbe3\udf95\ud9bb\udea5\udb68\udf44\ud82e\ude0b\u1f1d\ud8bf\udfc2\ud8f5\udebc\uda18\udd3c\ud91c\ude52\ud888\udc8e\uda13\ude8f\ud8b3\udc30\ud830\udf12\uda4a\udf23\udb84\udfc5\uda29\udc69\ud9ec\ude62\ud951\udceb\udac8\udfa8\ud897\udf2e\udb59\udf6a\ud936\udd8d\uda44\udd1b\udb96\udcb6"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u5b6b\ud9b5\udca6\ud9f1\udc41\ud936\udcb7\000\uda94\udd6a\u00a4\ud9ef\uddec\ud90c\udc25\uda9c\udfb9k\ud9be\udedfe"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("e\udace\udfd0\udb36\udf5c\ud8f4\udc6d\ud84c\udfbe\ud8f8\udd7a\uda4d\udfe0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\udad6\udc88\ud9e2\udca8\udb52\udd12\ud936\udcaf\uda8a\udf45\uda94\udd70\u00a4\ud9ef\uddec\ud90c\udc25\uda9c\udfb9\udbbf\udc4a\ud8b0\udfa41"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uc8d9\ud9c1\udd71\udb52\udd12\udb06\udc76\uda8a\udf5b\uda94\udd70\ud887\ude06\u0a78\udbff\udc67\ud840\udd98\uda70\ude11\ud90a\ude78F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("6");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("6", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uda8f\udec8\udb08\ude88\uda36\udd5b\ud99f\udeb5\udbfe\uddee\ud80b\udceb\udb45\udfce\ud901\udfd0\udb1c\udc1e\udaa9\udf26\uda76\udc57\ud9b7\udd3a\uda10\udc25"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("\uff13");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(".\ud861\uddde\udb36\udf49\ud8f4\udc6d\ud98c\udc57\ud9ce\ude57\udb4b\uddf3\uff9f\udaa5\uddc2"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u5b6b\ud9b5\udca6\ud9f1\udc41\udb34\ude9a\ud8a7\udcb9\ud975\udc1a.\ud9ef\uddec\uda43\udf80\uda9c\udefdk\ud9be\udedfe"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uc8d9\ud9c1\udd71\udb52\udd12\udb06\udc76\uda8a\udf5b\uda94\udd70\ud9d5\udd8d\ud93e\udd96\udbff\udc5e\ud840\udd98\uda70\ude11\ue8f0f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("l"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uc8d9\ud9c1\udd71\udb52\udd12\udb06\udc76\uda8a\udf5b\uda94\udd70\ud9bb\udc87\ud93e\udd96\udbff\udc5e\ud840\udd98\udb3b\udc6f\ue8f0L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uda31\udca0\ud96d\udd3f\ud9aa\udf7d\ua184\ud809\udcd1\udaa7\udca6\ud825\udc3f\ud876\udfcb\uda67\udd75\udab8\udd60\uda6e\udecc\ud93d\udd3e\u8872\udad8\udcda\udba8\ude26\ud90b\udf59\uda23\udeb6\uda62\udccf\ud9e9\udf84\ud925\udea7\u21ca\udafc\ude97\udb71\udf99\udb88\udfe5\udbc4\udc0a\udab1\udfe0\udae6\udcb7\ud9fc\ude9d\udb86\uddfd\ud863\udfc6\udab3\udea8\ud8f7\ude1e\udb65\udf2f\ud91c\udd5d\ud963\udf85\udbfa\udf42\udbc1\udd96\udb6b\ude0d\ud811\udffb\udba7\udfda\ud97d\udc03\ud8a1\udf9d\ud9ed\udd2b\ud841\ude59\udbee\ude55\udb2b\udc39\ud8bd\ude7c\udb68\udf44\ud82e\ude0b\u1f1d\ud8bf\udfc2\uda7a\ude90\uda18\udd3c\ud91c\ude52\ud888\udc8e\uda13\ude8f\ud8b3\udc30\ud8f9\udff6\uda4a\udf23\udb84\udfc5\uda29\udc69\u25b7\udad7\udf5e\udac8\udfa8\udbee\udd6d\uda8b\ude60\udb72\udd75\uda44\udca9\udb96\udcb6\ud968\udd30\udadd\udd8c\uda82\udcc0\udb98\udfa9\ud90d\ude99\ud8d8\ude70\udb86\udf9c\udae0\udef6\udb36\udf98\udb37\udf34\ud82a\ude0b\ud8c2\udc9e\uda7a\udcdd\udb1a\udc08\udac4\udcb8\uda9f\udd68\uda76\udf9e\ud93f\udc6e\uda72\udf78\ud9bf\udf95\udaad\udda6\udbc0\udce2\udbfe\udff6\ud933\udf7e\udb4f\udc21\ud9d5\udfe9\udb76\udecf\udb17\udc69\udb3f\udc59\ud889\udd1e\udbbe\udf2a\ud8d9\udff7\udafe\udca1\ud997\udf94\ub488\uda3a\udda8\uda50\udf76\udb9c\uded1\ud95b\udc41\udbdb\udc9e\udaae\uddb0\ud970\ude40\u5324\udb18\udeb8\udb6f\uddf9\udbb5\ude54\uda86\udca4\ud97a\udeb6\udadd\uddcd\ud930\uddfb\udb30\udc47\uda7f\udd39\udaa1\udc5c\ud819\uded3\udb9d\udfca\udb5a\udd7a\uda72\udf05\ud943\udcdd\ud83f\udc2f\udad5\udc58\ud8dc\udc5d\uda4e\udf00\udafe\udd05\ud992\udd2b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u5b6b\ud9b5\udca6\ud9f1\udc41\udad9\udcf4\ud8a7\udcb9\udac2\udfa1.\ud9ef\uddec\uda43\udf80\uda9c\udefdk\ud9be\udedf3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u5b6b\ud9b5\udca6\ud9f1\udc41\ud936\udcb7\000\udbdc\udfb3\u00c5\ud9ef\uddec\ud90c\udc25\udbb3\udd05\ud9a9\udd1a\udac0\uddbed"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uda31\udca0\ud96d\udd3f\ud9c9\udded\ud9d7\uddee\ud809\udcd1\udaa7\udca6\ud825\udc3f\ud876\udfcb\uda67\udd75\udab8\udd60\uda6e\udecc\ud93d\udd3e\u8872\udad8\udcda\udba8\ude26\ud90b\udf59\uda23\udeb6\uda62\udccf\ud9e9\udf84\ud925\udea7\u21ca\udafc\ude97\udb71\udf99\udb88\udfe5\udbc4\udc0a\uda53\udfd1\udad7\udf05\ud9fc\ude9d\udb86\uddfd\ud863\udfc6\udab3\udea8\ud8f7\ude1e\udb65\udf2f\ud9f2\udf07\ud964\udc7a\udbfa\udf42\udbc1\udd96\udb6b\ude0d\ud811\udffb\udba7\udfda\ud97d\udc03\ud8a1\udf9d\ud922\udd66\ud841\ude59\udbee\ude55\udb2b\udc39\ud8bd\ude7c\udb68\udf44\ud82e\ude0b\u1f1d\ud8bf\udfc2\uda7a\ude90\uda18\udd3c\ud916\udd3b\ud888\udc8e\uda13\ude8f\ud8b3\udc30\ud8f9\udff6\uda4a\udf23\ud81f\udcd3\ud9e9\udd43\ud80d\udc3c\ud8b2\udde7\udac8\udfa8\udbee\udd6d\uda8b\ude60\udb72\udd75\uda44\udca9\udb96\udcb6\ud968\udd30\udadd\udd8c\uda82\udcc0\ud913\udc5c\ud90d\ude87\ud8d8\ude70\udb86\udf9c\udae0\udef6\udb36\udf98\uda1d\udf07\ud82a\ude0b\ud8c2\udc9e\uda7a\udcdd\udb1a\udc08\udac4\udcb8\udb2e\udf09\uff16\ud919\udc8d\udbdf\uddee\ud8e5\udc8c\udaad\udd5d\udbc0\udce2\udbfe\udff6\ud933\udf7e\udb4f\udc21\uda0a\uddc8\ud866\udfb8\udb17\udc09\udb3f\udc59\ud889\udd1e\udbbe\udf2a\ud8d9\udff7\udafe\udca1\ud997\udf94\ub488\uda3a\udda8\uda50\udf76\udb9c\uded1\ud95b\udc41\udb5a\udf9a\udaae\uddb0\ud970\ude40\u5324\udb18\udeb8\udb6f\uddf9\udbb5\ude54\udb96\udff6\ud966\udf8e\udadd\uddcd\ud930\uddfb\udb30\udc47\uda7f\udd39\udaa1\udc5c\ud819\uded3\udb9d\udfca\udb5a\udd7a\uda72\udf05\ud943\udcdd\ud83f\udc2f\udad5\udc58\ud8dc\udc5d\uda4e\uded4\udafe\udd05\ud992\udd2b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u5b6b\ud9b5\udca6\ud9f1\udc41\udad9\udcf4\ud8a7\udcb9\udac2\udfa1e\ud9ef\uddec\uda43\udf80\uda9c\udefdk\ud9be\udedf3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u5b6b\ud9b5\udca6\ud9f1\udc41\udad9\udcf4\ud8a7\udcb9\udac2\udfa1e\uda48\udeaa\ud909\uddc0\uda9c\udefdk\udb9e\uded4L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ua8d9\ud9c1\udd71\u25ee\000\udbf2\udf39\uda94\udd6a\ud9bb\udc87\ud93e\udd96\udbff\udc5e\u972c\ud951\udeda\ud8fc\ude3dL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u2000\000\000\000\uda8a\udf45\ud94a\udc0a\ud887\udd16\u0a78\udbff\udc67\ud840\udd98\uda70\ude11\ud90a\ude78F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud915\udfea\ud9b5\udd56\ud9f1\udc41\udb34\ude9a\ud8a7\udcb9\ud975\udc1a.\ud9ef\uddec\uda43\udf80\uda9c\udefdE\ud9be\udedfe"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ua8d9\ud9c1\udd71\ud9a8\udd99.\udbf2\udf39\uda94\udd6a\ud9bb\udc87\udb1e\udc86\udaff\udc0b\udb04\udd68\ud951\udeda\ud8fc\ude3dL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud915\udfea\udaa7\udc65\ud966\udfdb\ud861\ude8d\ud8a7\udcb9\ud975\udc1a\ud85a\udd1d\ud9ef\uddec\uda43\udf80\uda9c\udefdE\ud993\udfe4e"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\udb21\udeaf\uda81\udfe7\udb25\ude73\u7768\ud9ed\udf69\udaa0\udf31\ud912\ude05\udb78\udd0f\ud885\udff7\uda7c\ude8c\udbaa\ude10\udb4b\udf84\ud8d1\udffa"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uda8a\udc7f\udaa7\udc65\ud966\udfdb\ud861\ude8d\ud8a7\udcb9\ud968\udea1\ud85a\udd1d\ud9ef\uddec\ud947\udea3\uda9c\udf31E\ud993\udfe4.\ud887\ude65\ud9bc\udc14\ud93f\udd8e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud8e9\udcd4\ud8cf\udccd\udb3a\udcf6\udafe\udf2c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
