package org.apache.commons.lang.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud86b\ude9b\udbae\udd45\uda09\udf81\ud904\ude9a\udb21\udcf4\uda17\udfd1\ud81e\udd79\ud896\udf17\ud904\udc11"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud86b\ude9b\udbae\udd45\uda09\udf81\ud904\ude9a\udb21\udcf4\ud8a1\udfab\udbcb\udeb0\ud844\udd0f\uda0a\uddd1"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\udab6\ude00\ud865\udd75\ud8f2\udd4c\ud84a\udeac\udbe8\ude81\uda78\udcf6\u5976\udae6\udfe0\u3778\ud856\udfd1\ud9ca\udffd\ud8d8\udd62\ud885\uddfd\ud899\udd1b\ue723\ud9b3\udcd6\udbf3\udc69\udbe0\udfe9"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud8a6\udeb7\ud9aa\udfdd"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud86b\ude9b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud86b\ude9b\udaf2\udd27\udba6\udf71\udaee\uddcf\ud999\udf3d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud91a\udedf\udbae\udd39\udb0b\udf01\udbc9\uddc2\ud954\udef4\udbe6\udcac\udb88\udf6a\ud896\udf17\udbee\udc06\ud8da\udd87\uda20\udf12\udab6\udc6a\udba1\ude0d\ud809\udd62\u62c1\ud897\udca7\ud89c\uddd8\udb2e\ude0c\uda8f\uddec\ud98d\udeb4\ud850\udde5\uda06\udc9e\udb69\ude5c\ud84b\udc37\ud8cb\udd9c\uda31\udf80\udb09\udfef\udab1\udf5b\uda74\udebe\ud899\uddfa\ud9b4\uddfa\ud8e0\udde4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\000e\000\000\000\000\ud801\udf79"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud833\udcf1\udb1b\udc57\uda01\ude94\udb96\udf03\ud9d4\udc25\ud837\udf96\ud8b9\udf1b\uda75\udd0e\ud976\uddaa\u5035\uda87\udd6d\ud8e8\udd2d\udb79\udc98\ud93e\udcdb\uda72\udddd\udb0c\udf04\ud879\uddb8\ud918\uded0\ud945\udcf9\udbdb\udc9b\uda3a\udf13\uda06\udd07\ud82b\udf37\ud899\ude16\ud8e1\udf51\ud99b\udcaa\ud9cf\udcc5\ud897\udf2e\ud9f8\udd1c\uda91\udf53\ud9c7\udd34\ud89f\uddba\ud8f9\uddda\ud9dd\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\u00c1"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uda7e\udfe4\udb47\udf39\udb32\ude58\ud8d5\udd7b\ubd05\ud8a3\udd04\ud907\udf9a\udbb5\udcdb\udaae\udf2f\udb9f\ude29\udb52\uded4\ud8e9\udf59\ud884\udd25\uda92\udeaf\uda4f\ude47\uda1e\ude17\udbba\udea6\udb57\ude98\uda4c\udeec\uda58\udc3b\ud8be\udfc6\ud842\udd89\udb09\ude26\ud9d0\udd19\uda38\udf3e\ud9e2\ude9a\ud98f\udeb4\udaf6\udcac\ud8ab\ude27\uda91\ude10\udb29\uddb5\ud90e\udf80\udb2d\udf1a\ud87a\udebf\ud93f\uded7\udb23\udc30\uda9a\udc1c\ud848\udeab\ud822\udccd\uda94\udfb7\ud81d\udc8a\udb47\uddc9\ud826\udc15\uda5d\ude34\ud89f\udcf5\udb13\udf1b\udada\udda9\udbb4\udd8a\udb8c\udc64\ud8e6\udf22\ud8da\udcda\udaf0\udcb3\udaa6\ude55\ud8d8\ude24\udb43\ude02\ud9c6\uddb3\uda5e\udd50\ud9e7\udd52\ud93b\ude3d\udb90\udf1d\ud828\udfe0\uda06\udd5b\udbe8\udd8c\ud836\udc35\udbfe\ude3a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\010e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud9cb\udfa5\u80aa\000\ud8c2\udc81\udadc\udec6.\ud801\udf79"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\012e\000\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("0e\000\000\000\000\uda69\udf2d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\udaf6\udc2b\ud92e\udce6\ud88c\uddc1\udaff\udcf0\ud89e\udc94\ud832\udcab\udb4d\ude17\ud803\udcc0\ud94c\udce2\uda09\udc3f\ud996\udc2b\u4537\udb98\ude3f\u1b57"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\012"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("0");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("0e\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("0e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\udaf7\udd6a\udb64\udeb1D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\udab4\udeb5d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\udab4\udeb5l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(" d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("\u1091d");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud8e9\udf20\udb96\udfdf\uda09\udf81\ud904\ude9a\udb21\udcf4\uda17\udfd1\ud81e\udd79\ud896\udf17\ud904\udc11"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\000\ud92e\udce6\uda11\udec3\udaff\udcf0\ud89e\udc94\ud832\udcabe\ud8ae\udd57\u00b2\000\000\000\udb90\udee7\u1b57"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("0\000D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("6d");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("6.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(" \u7965D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\000\ud88e\udcc5f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud98e\uddacL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("l"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\ud969\uddd6\ud95e\ude01F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\000\uda8a\ude73\017\ud904\uddff\ue100\000\000\000\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(".e\ua800\udaa5\udd2a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("09");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\uda96\udccb\000\000\ud87a\uddfd\udb21\udcf4\uda17\udfd1\u7200\ud896\udf17\ud8cc\udf26"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\012e\udbdf\udc6eL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("0e\uaa55");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0E+5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\000\ud92e\udce6\uda11\udec3\udaff\udcf0\ud89e\udc94\ud83c\udfabe\ud8ae\udd57\ud8c8\udc34\udacc\udeb0.\000\udb90\udee7\u1b57"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("9e\uaa55");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("9E+5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\000\ud834\udec9\uda6a\ude0a\ud80d\udc6c\udbe3\udc05\ud97a\udc6c\ud87c\ude9f\ud8ae\udd57\ud8c8\udc34\udacc\udeb0.\ud99f\udcd4\ud8e2\udebb\u1b57"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("0d");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("\000\ud92e\udce6\uda11\udec3\udaff\udcf0\ubd8e\ub55ae\udb0c\udc70E\000\ud8ce\udc06\000\ud81a\udf2d\ud984\udee9"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("0f");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber(".9");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("0.9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(".e\udad8\udf0cE"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("0\u0aebD");
    assertNotNull(r);
    assertEquals("java.math.BigDecimal", r.getClass().getName());
    assertEquals("5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(" \ud92e\udce6\uda11\udec3\udaff\udcf0\ubd8e\ub55ae\udb0c\udc70E\000\ud8ce\udc06\000\ud81a\udf2d\ud984\udee9"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    try { org.apache.commons.lang.math.NumberUtils.createNumber(".e\ud88f\udf67L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("7f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("7.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.math.NumberUtils.createNumber("7l");
    assertNotNull(r);
    assertEquals("java.lang.Long", r.getClass().getName());
    assertEquals("7", String.valueOf(r));
  }
}
