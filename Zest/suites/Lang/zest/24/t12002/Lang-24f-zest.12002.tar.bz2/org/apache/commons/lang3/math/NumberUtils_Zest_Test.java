package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\uda49\udfa2\ud74a\ud811\udf2e\ufc60");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\ud840\udeec\ud9de\udc7a\udb0e\udf39\ud8f7\udf68");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udbeb\udd02\u671d\ud811\udeac\ud8fa\udfde\ud8b4\udf42\ud97c\udc0b\udbeb\udf34\ud847\udf4a\ub551\udbb4\udd53\ud83e\udfde\u42cf\ud8bf\udfba\udb1f\udf0d\udb2b\ude1d\ud927\udc1f\ud90b\udfc2\uda43\udc82\uda0b\udd08\ud860\uddf5\uda43\udef7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\uda49\udfa2\ud74a\ud811\udf2e\uda8e\udf5b\udb99\udc69\ud905\ude34\ud81f\udff1\udbe7\udd56\ud9ca\udcef\udb59\udd50\ud9e8\udf81\udb36\udffd\ud982\ude23\ud9fe\udec8\ud8e5\udf57\ud908\udc6c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udb72\ude6c\udbc6\ude2e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\uda49\udfa2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udadf\udf16\ud8bc\ude55\ud99d\udd84\ud950\udca7\ud997\udeea\udba3\ude6e\uda4e\udd86\ud944\udff9\ud8a4\udd30\u8a5d\udbc5\udebc\ud911\ude05");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\000\000\ud809\udd64\ufc60");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\ud8f9\udf06\ud829\uddb1\ud8e9\ude76\uda03\udf0c\udba1\udfe3\uda3d\uddc3\ud854\udeb4\uda4f\ude26\ud8ad\ude24\ud877\udc9d\ud9ae\udc16\ud837\ude9d\u6a97\uda42\uddfd\uda91\udc2f\uda8c\udf1a\ud969\uddf1\udb05\udcf0\ud92c\udfcb\ud834\udd3e\ud89f\udedb\ud884\udca6\udb1f\udf35\ud811\ude22\udb8d\udd1e\uda93\ude32\ud94c\udee9\ucc0b\uda5d\udf94\ud82d\uddd1\ud911\udd56\ud8fc\udd9a\udbe6\udef5\uda7c\ude99\ud8b7\udedd\u3f61\ud908\udc98");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\u3905");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\ud933\udd4e\udb69\udc44\ud871\udd67\ud8d2\udf3b\uda99\ude7d\udbe8\ude0c\ud998\udfa5\uda0a\udf46\uda0b\udff6\ud830\ude81\udbde\udc35\ud9e8\udedc\ud822\udd83\u7832\udb58\udcd9\ud98f\udcf8\ud943\ude19\udbf2\udf8f\ud8e3\udfe2\ud934\udc99\udada\udcca\ud8a9\udc65\udadf\udcc9\udb64\udc7d\uda4d\udf8b\udb0e\udcba\ud80d\udef3\uda62\udce5\u40f4\ud9ed\udc0a\ud9e8\udedf\ud9ea\udfcb\ud865\udd3c\u4434\uda1b\ude50\ud9f3\udf45\udae2\udcec\udb7e\udf7c\ud818\ude2d\udbf7\ude9a\uda92\udd3b\uda69\udc99\ud81c\udf98\uda5d\udf62\ud8fe\udfc4\ud96e\udfd9\ud9ec\uddb8\ud80a\udefe\udb43\udf53\u86fc\ud9ad\udfd8\uda4f\udeed\uda4f\udd2f\ud984\udea6\ud85f\ude60\ud9a7\udf8c\udbad\uddf0\udae8\udeae\u31e9\ud9ce\udefe\udbf0\udcfb\udb06\uddce\udacb\udc6b\ud87f\udf71\udb7c\udcf1\ud908\udc74\ud837\udd70\ud933\udfc1\ud82d\udd66\ud845\udcc1\udb25\udcd9\udbf9\ude08\ud9d2\udec9\udb88\udf0f\udb3a\udcb5\ud8b4\udf2c\ud801\ude39\udb07\uddb8\udb36\udc6b\ud98c\udd11\ud9ac\udd12");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("6\u8a5b\ud9a1\udc1c\udbff\udca9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("E");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("E\ud9b8\udf8b\uda2c\udff1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber(".");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("F");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber(".\udb43\udf8a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("e\udb45\udf8b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udb73\uddb4\ud8d2\udd61\uda48\udfee\udaa4\ude70\udad0\udfa8\udada\ude58\u2224");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("+\ud800\udd8b\ud853\udf01\udb4d\ude40\udabd\ude20\udb6f\udc7b\udb7c\ude7d\ud9f4\uddd8\uda0d\udcec\udb37\udd0f\udbc6\udfcb\uda16\udf09\uda21\udecc\ud879\udcdd\ud95c\udedb\ud985\udf11\ud88c\udeac\ud943\udeb0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("0\u8a5b\udad5\udfac\uda5a\udd37");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("D");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("L");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("-\ud9f2\udc58\ud97f\udf3b\ud9cb\udfce");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("-");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber(".\000\ud809\udd64\ufc60");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("l");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
