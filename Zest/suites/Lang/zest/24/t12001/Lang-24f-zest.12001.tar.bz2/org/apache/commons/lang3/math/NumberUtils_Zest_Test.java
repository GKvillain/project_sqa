package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udbf6\udc65\ud98d\udf20\uda61\ude16\uda5a\udc26\udbfa\udfad\uda66\udf03\ud82e\udcfb\udac9\udd5d\udbe9\ude8b\udaa6\uded8\udb32\udf47\udb17\udfa1\uda78\udef8\uda0f\udcbe\uda86\uddca\uda9a\udfbe\udb43\udf93\udba1\udfc6\ud860\udd09\udbef\udd78\udb1a\uddd3\udad7\udc11");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udb50\udeff\ud98d\udf20\ud8df\udfe0\uda5a\udc26\udbfa\udfad\ud888\ude14\ud826\udd9b\udac9\udd5d\udbe9\ude8b\udab8\uded8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udbfd\uddcb\u8dab\uda2f\udc71\ud957\udf39\ud858\udd98");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udbf6\udc65\ud98d\udf20\uda61\ude16");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udb77\ude46");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\ud88a\udd58\ud8c6\udcf2\uda41\uddad\udb49\udf7d\udbfa\udfad\udb08\udd95\ud9ba\udfbc\udb24\uddd7\udbe2\udf75\udaa6\uded8\udace\udeb4\udb64\udd55\uda78\udf15\uda0f\udcbe\ud9f9\udc90\ud919\udede\uda7a\ude25\udba1\udf7c\udbf6\udd35\ud83c\udffd\udb1a\uddd3\udad7\udc11\ud84e\udd13\ud9a3\ude1c\udb16\udf2e\ud973\udc14\ud800\udd14\udbcb\udc84\udb68\udd5c\u72e0\ud851\ude43\udae2\udc10\uda87\udf1c\ud8f5\uddc8\ud87b\udf00\uf82c\udafb\uddd0\uda73\udfad\uda71\udf0a\udb1d\ude51\uda4e\udf18");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\u6e39");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("9\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\000\000\000\000\000\udb69\udf0d\000\udac9\udcd9\000\000\u8600\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("9\ud98d\udf20\uda61\ude16\uda5a\udc26\udbfa\udfad\uda66\udf03\ud82e\udcfb\udbe3\udd8a\000\000\000\000\000\000\uda86\uddca\uda9a\udfbe\udb43\udf93\udba1\udfc6\ud860\udd09\udbd3\udd6a\udb1a\uddd3\udad7\udc11");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\ud9c7\udc53\uda0b\ude85\udbff\udd57\ud827\udf2f\udb3c\ude8f\uda60\udd4e\udbbe\udd93\udbf4\ude94\udbbd\ude91\uda68\udf48\ud924\ude03\ud8c5\udf8b\uda76\udfde\udbde\udf4d\ud92e\udf58\ud886\udf38\udb48\udf63\ud95e\udf27\ud8a2\udf39\ud814\ude93\udb12\udf1a\ud8b0\udc69\ud958\ude11\uda82\udc24\udb03\ude12\udae8\ude11\ud8da\udc99\uda1e\ude7e\udb72\udcfd\ud946\udfd0\udb57\udfde\udbac\ude7a\uba46\uda6f\udd70\uda0c\udd8c\udbe0\udecb\udaa2\udde7\uda38\udfeb\udadf\udc43\udb25\udeb6\ud83f\uded7\udb82\ude09\ud9d0\udcd3\uda82\udc0b\uda30\udf62\udbf6\udeb7\udab9\udd97\ud8f4\udf74\ud8bd\udc4e\udad0\udc88\udacb\udc9b\ud89f\udccc\uda68\ude62\uda45\udf0d\ud86d\udfe2\ud9c1\udf6f\ud949\udc2b\ud921\udcf9\ud968\udf68\uda1e\uded5\u2c3f\ud9b5\udd47\udbe3\udcf1\ud8dd\udc5f\ud936\ude00\udbae\udf7d\udb9b\udfd2\ud887\uddec\ud94c\udc73\ud83a\udea2\udbb5\udd41\ud947\udfae");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("-\udada\udd0b\udb5f\udfe4\ud9ec\udd5e\ud91d\udd88\ud89c\udd88\ud837\udec8\udbfb\udf67\ud905\udfaa\udbb7\udf31\ud94d\udf3c\udacd\udec5\uda38\udd3a\ud939\ude27");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("-");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber(".\udada\udd0b\udb5f\udfe4\ud9ec\udd5e\ud91d\udd88\ud994\udea5\ud837\udec8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("0\ud8f2\udf1a\ud810\udc9a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber(".");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber(".\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("\udbf6\udc65\ud98d\udf20\uda61\ude16\uda5a\udc26\udbfa\udfad\uda66\udf03\ud8c0\udc64\udacb\udff5\udbe9\ude8b\udaa6\uded8\udb32\udf47\udb17\udfa1\uda78\udef8\uda0f\udcbe\uda86\uddca\uda9a\udfbe\udb43\udf93\udba1\udfc6\ud860\udd09\udbef\udd78\udb1a\uddd3\udad7\udc11");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("9L");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("+\000\u00e0\000\000\udb69\udfa9\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("e\udada\udd0b\udb5f\udfe4\ud9ec\udd5e\ud957\udd66\ud99f\udc51\ud837\udec8\udb77\udfb9\ud919\udda3\ud9b6\udf65\ud851\udedd\udadc\udf45\ud84e\udea7\uda04\udddd\ud98b\udfcd\ud87e\udc9a\ud98b\udc82\uda60\udf8f\ud97a\udfae\ud956\udd69");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("E\000\u00e0\000\000\udb69\udfa9\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("L");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("E");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("F");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("l");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("0\uda05\udf05\udaf0\udd4e\udadb\udc74\ud8dd\udca2\udb19\udd1a\ud826\udc0a\udb0d\ude23\udb4b\ude2e\ud808\udf12\ud851\udfa3\udb38\ude2d\ud9e0\udc06\udbac\udd79\ua189\uda6d\udd90\udb86\udec4\ud84b\udfc8\ud92a\udcf9\ud8c7\udd37\uda46\uddaa\ue25e\udaf7\udd2a\udb9b\udd45\uda0e\udd31\udac3\udf74\ud82e\ude68\udb6e\udd11\uda12\udd1e\udbcb\udf03\ud989\udef4\udb28\udffd\ud924\udf95\udbb0\udd92\u09a6\ud913\udddd\ud94f\udfe0\ud8a4\udd74\uda53\udd0f\ud8dc\udfc5\uda21\udd9f\ud80a\uddf2\udb6d\udd76\ud8cd\udd68\udb33\udfdd\udab0\udf24\ud990\udd2c\ud885\udded\ud9a8\udee2\ud862\udda9\udb65\uddb2\udb07\udf66\udbbf\udf77\ud91e\udd36\ud8b8\udcb9\ud8b0\udf01\udb58\uddb4\ud983\uddf6\ud8fe\udcad\udb9d\udea5\uda54\udfb7\udad0\udfce\ud913\udee6\ud9a6\udc39\udaab\udcbc\ud8a9\udc47\udbf4\udd59\ud84b\udde0\udb5d\udcdb\uda08\udc31\ud8bc\udc98\ud920\udeb5\ud92a\udea3\ud97d\udfc1\ud9a4\udc90\udafb\udfc6\udb5d\udd26\uda49\udc78\u2f48\uda54\udc36\uda5d\udc3f\ud935\udf12\udaa7\uddc9\udb8d\udff6\ud8f4\udd6d\ud852\udd4b\ud83b\udd3a\ud9c6\udebf\ud974\ude05\ud851\udf8f\ud864\udf69\ud821\udd6c\u3539\udbbb\uddda\uda27\udd70\ud8f1\udd5a\udab8\udcd7\ud935\udc6f\udb8f\udf30\udb48\ude57\udb68\udf38\ud83c\udced\udbd4\udf2c\ud816\ude2b\ud816\udc15\uda43\ude8e\uda7e\udff0\ud842\udece\ud9d8\udea3\ud86c\udde6\ud9d8\udd57\udaf8\udc25\ud902\udc2b\udbf6\udf3b\udbd0\uddbd\ud9a4\udfae\ud975\ude98\ud804\udc99\ud961\udd27\udacf\udee8\udb0b\ude81\udbf2\udc52\udb6b\udf70\uda8f\udc96\udbfa\udf37\udbe0\udcc8\ud812\ude57\udb3a\ude6d\udadd\udffc\ud826\udff9\uda42\udd56\uda79\udcc9\ud96f\udd4f\udb4b\ude93\ud985\udd7d\ud99d\udc8e\ud9d4\uded4\udb33\uddf6\udbbd\udd64\uda6b\udeaf\uda91\udf9e\udb2d\udccb\u84ca\udbea\udf06\ud854\udc87\uda0e\udccd\ud9c9\udf52\ud8cd\ude85\uda81\udde4\udad2\uddd5\uda7e\udc72\udaaa\udf20");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("D");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.isNumber("98\uda7b\uddd5\udb8d\udd4d\ud8f3\udee3\uda4c\udd6e\u8239\uda36\udc5b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
