package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class ClassUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\uda7c\ude7e\ud8b5\udebf\ud968\udfca\ud81f\udfee\ufcb5"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\udba6\uddd4\udba8\ude0d\ud97f\udc6d\ud98e\udd5a"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\udae2\udf29\uda93\udf56");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udae2\udf29\uda93\udf56", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass(""); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\udbb3\ude9a\000\000\000\000"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\uda7c\ude7e\uda59\udc50\uee69\udb8e\udfc8\ud968\ude3c\uda2a\udfb7\ud851\ude81\ud95d\udfbc\ud88f\udd18"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\000\000\000"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\uda56\udfea"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\udba2\udfa8\udac3\udc91\ud96c\udc67\ud835\udcc8\ud927\udc73\udae8\ude2d\uda78\udfdb");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\uda08\udd9e\udb0d\udeb4\ud8f1\ude73\udaa5\udc91\uda0f\udc2a\udb02\udda8\udbd9\udd94\uda57\udc0f\uda08\udf7a\ud9f4\udff6\udb7c\udf66\udb36\udef3\ud8f9\udfed\ud8b0\udea0\uda41\udf7c\uda3d\ude87\ud8e6\ude19\ud854\udd5f\ud87f\udc09\udbd2\udfb1\udb3f\udfb6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda08\udd9e\udb0d\udeb4\ud8f1\ude73\udaa5\udc91\uda0f\udc2a\udb02\udda8\udbd9\udd94\uda57\udc0f\uda08\udf7a\ud9f4\udff6\udb7c\udf66\udb36\udef3\ud8f9\udfed\ud8b0\udea0\uda41\udf7c\uda3d\ude87\ud8e6\ude19\ud854\udd5f\ud87f\udc09\udbd2\udfb1\udb3f\udfb6", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\ud94e\uddb8\udb3b\udf50\udb0a\udc2e\ud893\uddad\ud9f2\udf57\ud972\ude48\udb76\udcc8\ud9cf\udfd2\ud890\udded\udb2e\udfcb\ud917\udd7b\uda5b\uddce\udac6\udeaa\ud982\udd80\ud9f4\ude15\uda05\udd14\ud8a0\ude36\udb9e\udce3\ud97f\udefb\udbaa\udda5\udb53\udcbd\uda51\udf3a\ud834\udde2\udb35\udcc4\udb04\udd08\udbbc\ude8c\uda52\uded2\udb0a\udf82\ud8a9\udd80\ud861\ude1c\ud8e8\udfcc\udba3\uddab\uc403\uda0e\udc66\ud84f\udc50\ud91e\udf0e\udb04\udfe7\udbc7\udc49\ud821\udc3f\udb36\udf37\udb7a\udc53\ud9a5\udc04\udb67\udcb8"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\udbc6\uddfe\udb34\udd7b\ud968\udfe5\ud81f\udfee\ud9f2\ude36");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\000"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\uda7c\uddea\udbbe\udfdf\035\000\000"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\uda0f\udd06\uda8a\ude16\u4e0a\udb92\udf5b\udba1\udf47\uda45\udcc4\ud8e4\udedd\udbd1\udd01\ud8f5\udc72\uda65\udc10\udb74\udf8c\ud932\udc0b\u8185\ud937\uddc5\ud894\udd18\ud90d\udfc3\udb02\udfdb\ud87b\ude4e\udae8\udeed\ud914\udefb\udb05\udd6b\ud817\uddfc\ud8e0\uded3\ud9a8\ude8c\udafe\udde3\udb6f\udf31\ud922\udc2a\ud928\udce9\udadd\udf3e\udb64\udd35\ud8a5\uddec\uda4c\udf0a\ud8f4\udf23\uda39\uddc1\ud86a\udeb2\ud8ec\udd05\ud8c3\udc6d\ud8fc\udeda\uf6b8\ud806\udf18\ud95f\ude1c\ud9a7\udd27\ud9f5\udf26\ud984\udd77\ud979\udeac\uda3b\udd24\ud843\udd4a\ud9db\udc73\udbb8\udc8e\uda7f\udd26\ud8fc\udf6a\ud95f\udf35\u769d\ud930\udc08\ud9f5\udf13\udacd\udf06\ud995\udcff\ud9cf\ude92\udabc\ude68\ud857\ude25\ud891\udc86\ud916\ude16\ud86c\udcde\ud83e\udfe1\ud973\udfa9\uda4f\udf58\ud943\udc41\uda7e\ude3b\ud816\udf17\ud9bf\udc61\ue5e4\ud906\udd43\ud87e\udfee\uda2b\udd6a\uda5d\udcd2\ud8a7\udd98\ud9b5\udde5\ud928\ude52\ud9bb\udc96\ud992\ude37\udb56\udda6\ud982\udf91\udb63\udf53\udba6\udc27\uda17\udc02\ud946\udc29\udb02\udcaf\uda00\uddf4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\u7401\ud8d5\udfc2\ud88d\udffd\udb13\udec0");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\ud999\udc7a\udbde\udc77\035\udbce\udda7\034"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\ud8e3\ude37\uda76\udf55\udb3c\udcb3\udb39\udfad\ud8ae\udd09$\ud865\ude48");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8e3\ude37\uda76\udf55\udb3c\udcb3\udb39\udfad\ud8ae\udd09.\ud865\ude48", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\udbab\ude71\u08c9.\udb31\ude00\000\ud897\udddc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbab\ude71\u08c9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\udbab\ude71\u08c9.\uda5e\ude77\ud8d2\uddf8\udb7e\udd99");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda5e\ude77\ud8d2\uddf8\udb7e\udd99", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\uda56\udfea\ud8b5\udebf\ud968\udfca\ud81f\udfee\ufcb5"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
}
