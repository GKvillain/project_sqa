package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class ClassUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\ud931\ude3e\ud96a\udcf9\udb6b\udd9c\ud8c3\ude12\ud8e0\udf0d\ud9f8\udfff\ud8a3\udfa7\udba0\udeb8\ud8ad\udf6b\u9a9d\ud849\udd8c\ud955\udd98\ud956\uddc1\ud9e3\ude18\ud997\udd14\uc74b\u03fe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\ud931\ude3e\ud96a\udcf9\udb6b\udd9c\ud8c3\ude12\udbe7\udef0\uda1e\udf2e\ud87c\uded9\udb3d\udce7\udbcf\ude60\ud8b5\udeda\ud91e\udeba\ud955\udd98\ud956\uddc1\udb4e\udd8e\ud9a7\udc17\uc74b\u03fe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\ud931\ude3e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\ud931\ude3e\ud96a\udcf9\udb6b\udda3\ud8c3\ude12\ud8e0\udf0d\ud9f8\udfff\ud8a3\udfa7\uda73\udd41\ud9b8\udc2a\ud861\udd65\ud849\udd8c\ud955\udd98\ud956\uddc1\ud9e3\ude18\ud997\udd14\uc74b\ud8ea\udf04");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass("\ud931\ude3e\ud96a\udcf9\u18de\udbcb\udfb2\udb1c\udfe7\ud9f8\udfff"); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\uda3e\uddeb\ud96a\udcf9\udb6b\udd9c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\ud931\ude3e\ud819\udf0f\udb6b\udd9c\ud8c3\ude12\ud8e0\udf0d\ud9f8\udfff\ud8a3\udfa7\udba0\udeb8\ud8ad\udf6b\u9a9d\ud849\udd8c\ud92b\udce3\ud956\udda3\ud91f\ude96\ud997\udd14\uc74b\u03fe\udb8c\udde7\udbe9\udce6\ud8dd\udd3a\udb2b\udd4e\ud8d1\udcf9\uda2d\udfee\uda44\udce6\u9201\ud81d\ude42\ud8bb\udc32\ud88f\ude53\udaac\udf65\ud8b3\udf5b\udbf1\ude4e\uda49\udc66\uda4d\udec9\ud918\ude48\ud975\ude57\udb08\udf54");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\udb09\udf9e\uda1a\udc90\ud862\udd15\ud8c0\udf2d\ud8e0\udf0d\ud9f8\udfff\ud9b5\udcc3\udb30\udcb1\ud8a8\udc02");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\ud931\ude3e\uda3f\ude75\uda40\ude6d\ud8c3\udea2\udb7d\udeae\udbc2\udd5c\ud8a3\udfa7\udbf6\udec3\ud8ad\udf6b\ud914\udf14\uda46\udff2\udb8b\ude0e\ud956\uddc1\uda06\udeaa\ud9c9\udeb8\uc74b\u03fe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\ud8c8\udd43\ud96a\udcf9\ud9a9\udfda\ud85b\udd23\ud8e0\udf0d\ud9f8\udfff\ud9d8\udd71\ud8a5\udd6c\ud8ad\udefb\ud86b\udc3f\udbbf\udc3e\ud860\uddb3\udbdc\udef6\udb29\ude8f\ud8fc\udd83\uc74b\udb7e\udf67\udb73\udc95\udb75\ude76\udb93\udfc7\uda6f\udd7c\udb9b\udcef\ud9b8\ude06\ud995\ude46\ud814\udf98\ud82c\udf5d\uda75\ude28\ud969\udd22\ud832\ude8d\uc033\ud876\udd7f\uda33\udc81\ud8f1\ude4b\udaa8\ude0b\uda66\udc6b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\ud931\ude3e\ud96a\udcf9\ud9d3\udd90\ud990\ude04\ud8e0\udefe\ud9f8\udfff\ud8a3\udfa7\udb48\udf2d\ud8a0\udc5b\u9a1a\ud849\udd8c\ud955\udd98\uda74\udc0f\ud856\udd78\ud9fe\udfc8\uc74b\u03fe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud931\ude3e\ud96a\udcf9\ud9d3\udd90\ud990\ude04\ud8e0\udefe\ud9f8\udfff\ud8a3\udfa7\udb48\udf2d\ud8a0\udc5b\u9a1a\ud849\udd8c\ud955\udd98\uda74\udc0f\ud856\udd78\ud9fe\udfc8\uc74b\u03fe", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\uda9a\udc23");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda9a\udc23", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\ud912\uddf2\ud96a\udcf9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud912\uddf2\ud96a\udcf9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\u2079");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u2079", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.ClassUtils.getClass(""); fail("expected ClassNotFoundException"); }
    catch (java.lang.ClassNotFoundException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\ud8d5\udf44\uda1a\udc90v\000\000\ufe00\013\udaf8\ude1c\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\udb09\udf9e\uda1a\udc90\ud906\ude0e\uda08\udedf\udb71\udfa2\udbf6\uded7\udb52\udc5f\ud83f\udfec\ud8c2\udefe\ud986\udf36\udaa2\udef7\ud934\udc89\ud80c\udd4a\uda91\udf21\udbc9\udd4a\udac9\udfc3\udb5b\udc1d\ud8d3\udc3d\ud9de\udc7a\uda99\udc26\ud89b\ude12\ud903\udc05\u5fb3\ud895\udc6c\ud866\udf62\udb86\uddfe\ud857\udddb\ud964\udc08\ud91a\udcd4\ud85f\udf6d\ud99f\udf55\uda7e\udcd7\ud92f\udf34\ud97e\ude7a\ud871\udd0b\ud887\udc75\uda40\ude0a\uda2f\uded9\udb29\udd95\ud82b\udf2a\ud945\udcfc\ud80a\udd60\udbd5\udcd3\udbd1\udcdc\udbee\udd57\ud848\ude5c\ud84c\udd14\udab1\udcdf\u7096\uda90\udc9d\udb94\ude5d\udade\udca9\uda3a\udd6c\uda0e\udfe1\uda5f\udfe5\ud816\ude86\u41ee\ud9a2\udf7c\uda96\ude1b\udade\udd57\uda3c\udf40\ud8db\udc7e\u0cfd\uda00\udc5e\udb56\uddce\ud8e5\udf53\udaf9\ude23\ud82c\udeb5\udb2e\udcca\ud861\udcd9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\ud8d5\udf44\uda1a\udc90\011\ud9e4\udd49\udb6e\udd04\uda6d\udce6\013\udaf8\ude1c\ud94c\udc05");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\ud931\ude57\ud8bb\udd40\udb6b\udd9c\ud8c3\ude12\ud83d\udfbc\udac4\udcc0\ud8a6\ude50\udba0\udeb8\udae9\udf69\uda86\ude67\uda02\udf9a\ud955\udd98\ud956\uddc1\ud8dc\udf35\u7262\uc6e6\u03fe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageCanonicalName("\ud8d5\udf44\ud81c\udc91v\000\000\ufe00\013\udb83\udd1c.\uda0e\uddeb");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8d5\udf44\ud81c\udc91v\000\000\ufe00\udb83\udd1c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\ud8d5\udf55\ud81c\udc91v\000\000\udaa9\udde9\u25f2\udb83\udd1c.\uda0e\uddeb\uda9f\udf72\udbd6\uddd3\udba5\udec9\ud9cf\udcd1\ud8cc\udca3\udbb6\udd8c\udb80\udd4f\udbda\udf86\ud80a\udefe\ud9c8\uded0\ud8a6\udd93\udaa1\udca7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda0e\uddeb\uda9f\udf72\udbd6\uddd3\udba5\udec9\ud9cf\udcd1\ud8cc\udca3\udbb6\udd8c\udb80\udd4f\udbda\udf86\ud80a\udefe\ud9c8\uded0\ud8a6\udd93\udaa1\udca7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getPackageName("\ud931\ude3e\ud96a\udcf9\udb6b\udd9c\ud8c3\ude12\ud8e0\udf0d\ud9f8\udfff\ud8a3\udfa7\udba0\udeb8\ud8ad\udf6b\u9a9d\ud98a\udc4d\ud9c4\udc9d\ud8c4\udd7b\ud9f9\udd64\ud997\udd14\uc74b\u03fe");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.ClassUtils.getShortCanonicalName("\udaa1\udca7\ud969\udfdev$\000\udaa9\udde9\udbef\udef9\udacb\udc13\udb94\udf58\udb5a\udc7f\ud8fc\udd93\ud950\udd30\udacd\udfdc\ud9cf\udc6e\ud8cc\udca3\udbb6\udd8c\udb80\udd4f\udbda\udf86\ud80a\udefe\ud9c8\uded0\ud8ee\udd97\udaa1\udca7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udaa1\udca7\ud969\udfdev.\000\udaa9\udde9\udbef\udef9\udacb\udc13\udb94\udf58\udb5a\udc7f\ud8fc\udd93\ud950\udd30\udacd\udfdc\ud9cf\udc6e\ud8cc\udca3\udbb6\udd8c\udb80\udd4f\udbda\udf86\ud80a\udefe\ud9c8\uded0\ud8ee\udd97\udaa1\udca7", String.valueOf(r));
  }
}
