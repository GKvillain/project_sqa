package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class LocaleUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud9b7\udfcc\udae9\uddb0"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud9b7\udfcc\udad3\udd34\ud9d8\udfc5\ud91a\udcec\ud9c9\udd87\ud903\udfeb\ud9cc\udef0\udbd5\udd88\ud819\udc6c\ud914\udc1d\udbcf\udfb4\udbef\udee9\udad0\udc15\ud9c4\udc37\ud971\ude80\udb30\udffb\udbd7\udec3\ud8b8\udd32\ud924\ude09\ud8fa\udf2a\uda51\udc87\ud841\ude2b\u6deb\ud9f1\udfbc\uda40\udff2\udbac\udd5d\ud9fc\udc27\ud890\ude3e\ud970\udd39\udb3f\udd64\ud935\udd33\udb5a\ude08\uda06\udfb1\ud808\ude86\udb99\udf58\ud924\udd1c"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud95f\ude81\ud913\udfbc\uda05\udc77\u6970\ud845\udc8e\ud971\udc82\udbbb\udcea\udb72\udd94\uda6c\udfac"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud817\udcc7\udaf6\udce3\udbea\udcbd\udbcb\udf1a\udaf1\udf6a\udb9b\udc6d\uda56\ude37\ud986\ude9f\udb07\udd2a\udbb0\udd41\udba7\udc58\udaf8\udd4c\uda78\udd0e\udbb0\udca9\u3339\udbeb\udcbf"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud9b7\udfcc"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud934\udc52\udae7\udfef\uda41\udefe\ud8f1\udf38"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud92b\udf27\ud8a4\udfba\ud86d\uddd5\uda38\udd22\uda95\udcb4\uda6e\udfa4\ud816\udd3f\ud96a\udccd\ud9ed\ude17\udb22\udebc\udb5c\uddb7\u1b7b\ud950\udfbc\udb9c\udd8f\uf86b\uda1c\udf95\udae7\udcab\ud87a\uddeb\ud9cd\udd01\uda41\udd41\udab7\udd91\uda01\udc49\ud868\udfcd"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale(""); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\uabb1\udb2f\udee8\udbe4\udda9\udb6e\udc64\uda32\udcdf\udaa6\udc79\ud9ef\ude17\ud954\udc82\uda1c\uddee\ud9e1\udec1\udb58\udd82\ud964\ude8d\uda06\udc72\ud812\udd76\udaac\udfcf\uf374\uda16\udc46\ud815\udf4b\ud935\ude7d\udabe\udf0f\ud93a\ude11\ud9dc\udfef\ud8cb\udf29\udaef\udf68\ud85d\udfa2\ud93f\udd34\ud9e9\udf4b\uda38\udd5b\uda3a\udc1a\ud9b3\udcce\ud984\udf25\udb46\udc06\udb6a\udd22\uc85f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\uabb1\uab7d\udbe4\udda9\udb6e\udc64\uda32\udcdf\udaa6\udc79\ud9ef\ude17\ud8c6\udf86\ud9b6\udc65\ud9e1\udec1\udb58\udd82\ud964\ude8d\uda06\udc72\ud812\udd76\udaac\udfcf\uf374\uda16\udc46\ud815\udf4b\ud935\ude7d\udabe\udf0f\ud93a\ude11\ud9dc\udfef\ud8cb\udf29\ud88a\udf68\ud838\udccf\ud93f\udd34\udbf5\udef1\uda38\udd5b\uda71\udd95\udb6d\udd79\ud984\udf25\udb46\udc06\udb6a\udd22\uc85f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\uabb1\udb2f\udeb5\udbed\udf0e\udae3\udede\ua305\u0d7d\u2c0a\ud8b1\ude53\ud804\udde1\ud9e1\udf1d\udb59\ude47\ud886\ude0a\ud9cb\udc41\uda45\udd7d\uda3f\udc26\udb71\udfd4\ud80a\udff0\udaf4\udf2f\udb73\udffc\ud8d5\udd56\ud83f\udf32\ud9a2\udc4c\ud8cb\udf5a\udaef\udf68\ud85d\udfa2\ud86f\uddef\ud9e4\udf0e\udaff\udcf0\uda3a\udc1a\ud9b3\udcce\ud984\udf25\udb52\udc06\udb6a\udd22\udb63\udc0e\u916b\uda5c\udc84\ud953\udfef\udbe1\udffc\ud8b8\udcbc\uda10\uddf9\udb34\udfc7\udabb\udf93\ud8cf\uddbf\ud880\udf7f\ud8a7\udee2\ud905\udc5d\ud878\udf2d\ud84e\udfa9\ud9b9\udda6\ud901\udf39\udaa7\udef2\ud9a4\udcb8\ud845\udea3\uda4a\udfc9\uda68\udcd8\ud8f7\udfce\ud940\udc67\udbe5\udd82\ud9bb\udc28\udb68\udf1f\udb32\ude50\ud84c\udcb6\ud98d\udfbc\uda25\udea6\u40fc\udbfd\udf99\udb36\ude00\ud905\ude89\ud93d\udc53\ud883\udfe5\udbb1\udee1\udb7f\udfa1\uda05\udfe5\udb6d\uddfd\udb3c\udc69\ud8f7\udc37\uda09\udc1a\udb05\udc6b\udb59\udd77\ud8d1\uddee\uda20\ude1b\udb65\udcde\uda7a\ude22\ud98b\udeda\ud9b5\udf62\udbb4\ude49\udbd5\udd76\uda54\ude56\ud917\ude84\ud993\udee7\ud9e6\uddd7"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.LocaleUtils.toLocale("\uabb1\uab7d");
    assertNotNull(r);
    assertEquals("java.util.Locale", r.getClass().getName());
    assertEquals("\uabb1\uab7d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\uabb1\uab7d\udbe4\udda9"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\udbec\udd47\udb91\udd2e\udabe\udfe5\uda73\ude27\ud800\udef7\udaee\udeef\ud91b\udc9b\udae0\udfbf\ud882\udeb9\ud801\udc93\ud885\ude88\udb95\udc12\uda4c\udec3\ud90b\udf1c\ud804\ude7e\udb47\udd92\udbc1\ude50\ud95d\ude4d\ud82f\udf40\ud87c\udcef\ud9c3\udd17\ud9ec\udf6e"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
}
