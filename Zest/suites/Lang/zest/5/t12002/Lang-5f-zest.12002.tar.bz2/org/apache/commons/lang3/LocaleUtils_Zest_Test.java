package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class LocaleUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud853\udd8c\uda17\uddb6\udab7\uddd3\ud9b1\udd90\ud9c1\udf20\udb3a\uddcd\uda0e\udd91\ud941\uddb3\ud928\udc34\ud83b\udf38\ud81b\udca4\udaa8\ude66\udadb\udfb5\ud8cd\udc21\ud8f9\ude63\udab1\udce6\ud9f3\udea8\ud953\udc10\ud81d\udce0\ud894\udeff\ud8b4\udf1f\ud8c4\udd1f\u89d2\ue35c\ud88c\ude65\ud9c0\udcf1\ud9cb\ude05\ud83f\udcd6\ud993\udfbd\uda46\udf07\udbd3\udfd9\uabc0\uda13\udc41\ud9f1\ude43\udae8\ude29\udb75\udc27\ud892\udf21\ud981\ude25\ud9d9\udf69\udabe\ude88\udb91\uddd2"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud853\udd8c\uda17\uddb6\udab7\uddd3\ud822\udccd\udb74\udf8c\udb3a\uddcd\ud82c\udd9d\ud927\udeb8\ud928\udc34\ud83b\udf38\ud958\udd44\udae7\udc76\ud820\udcfd\ud8cc\udfff\ud8f9\ude63\udab1\udce6\ud9f3\udea8\ud953\udc10\ud83a\udccf\ud9ae\udd2c\udb57\udd0b\uda92\udf64\u8a79\ue35c\ud88c\ude65\ud9c0\udcf1\ud9cb\ude05\udb97\udc02\udb84\udd05\uda17\udf5b\udbd3\udfd9\uabc0\uda13\udc41\ud98e\udeb1\ud9da\udee0\uf8d1\ud893\ude26\ud981\ude25\ud9d9\udf69\udabe\ude88\udb91\uddd2"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud8d7\udd37\ud9ac\udc80\udac4\ude3c\ud9b1\udd90\ud9c1\udf20\udb3a\uddcd\uda0e\udde1\ud941\uddb3"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud853\udd8c\uda17\uddb6\udab7\uddd3\udaec\udece"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud857\ude8f\ud908\udd8f\ud9d0\udd82\ud9b1\udd90\ud920\udc8e\udb2c\udc5b\uda0e\udd91\ud941\uddb3\ud922\udc34\udb97\udc85\udb19\ude66\udb21\udc22\udadb\udfb5\udb2e\udf51\ud8f9\udd7e\udab1\udce6\ud9f3\udea8\ud9ec\udefd\udbfd\udc55\ud8a4\udde9\ud8b4\udf1f\ud8c4\udd1f\ud9a7\udccc\ue35c\ud937\udf3b"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud919\udc88\uda17\uddb6"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\u00fd\000\udab7\uddd3\ud9b1\udd90\ud9c1\udf20\udb3a\uddcd\uda0e\udd91\ud941\uddb3\ud928\udc34\ud83b\udf38\ud81b\udca4\udaa8\ude66\udadb\udfb5\ud8cd\udc21\ud8f9\ude63\udab1\udce6\ud9f3\udea8\ud953\udc10\ud81d\udce0\ud894\udeff\ud8b4\udf1f\ud8c4\udd1f\u89d2\ue35c\ud88c\ude65\ud9c0\udcf1\000\ud821\udc50\ud993\udfbd\uda46\udf07\udbd3\udfd9\uabc0\uda13\udc41\ud9f1\ude43\udae8\ude29\udb75\udc27\ud892\udf21\ud981\ude25\ud9d9\udf69\udabe\ude88\udb91\uddd2"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\000\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud8a5\udf58"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale(""); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\u00fdq\udab7\uddd3\ud990\udf80\ud84a\udeab\ud802\udcd5\udb37\udd9e\udacf\udecf\udbe3\udff1"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.LocaleUtils.toLocale("\u00fdq");
    assertNotNull(r);
    assertEquals("java.util.Locale", r.getClass().getName());
    assertEquals("\u00fdq", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\u00fdq\udab7\uddd3"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\uda61\udf40\ud873\udf10\udac8\udd24\ud970\udd49\u44f7\ud947\udf81\ud810\udc67\udbf1\udf4b\udbdb\udf1f\ud9d0\udc05\udad9\ude1a\ud8c4\udca4\uda55\udc47\ud95c\udcfb\ud8aa\udef1\ua640\uf912\ud8db\udca1\udaa8\udf4a\ud9e0\udffb\udbf9\ude8b\uda0e\udedc\ud9fa\udce5\udbe3\udcb0\ud93e\udfce\udafe\udd61\ud8d4\udfa0\udbba\udc12\ud9b7\udee0\udb85\udd96\udab2\udcf8\udb60\udf71\ud9d5\udc99\udb96\udc6c\udb2c\udd41\uda8e\udfab\udbb0\udf4b\ud8c2\ude76\udafb\udcf6\ud995\udc2f\udab4\udc41\ud9e7\udd5e\ud896\udf86\udad6\udd78\ud8ba\udfea\ud8eb\ude87\udb3a\udcbe\udada\udd8e\udbce\udd2c\udac0\udd25\ud80a\udd82\ud8a0\udf41\u4657\uda61\udece\ud9be\uddf5\udb3a\udc2d\uda04\udfc4\uda22\udcc8\udaf8\uddcf\uda02\udc0c\udb33\udd51\ud8b3\udc49\ud8f8\uddd6\uda19\udc58\u8885"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\uda61\udf40\ud873\udf10\udac8\udd24\ud970\udd49\u44f7\ud947\udf81\ud810\udc67\udbf1\udf4b\udbdb\udf1f\ud9d0\udc05\udad9\ude1a\ud8c4\udca4\uda55\udc47\ud95c\udcfb\ud8aa\udef1\ua640\uf912\ud8db\udca1\udaa8\udf4a\ud9e0\udffb\udbf9\ude8b\uda0e\udedc\udb0a\udfa1\ud88c\udd46\ud93e\udfce\udafe\udd61\ud8d4\udfa0\udbba\udc12\ud9b7\udee0\udb85\udd96\udab2\udcf8\udb60\udf71\ud9d5\udc99\udb96\udc6c\udb2c\udd41\uda8e\udfab\udbb0\udf4b\ud8c2\ude76\udafb\udcf6\ud995\udc2f\udab4\udc41\ud9e7\udd5e\ud896\udf86\udad6\udd78\ud8ba\udfea\ud8eb\ude87\udb3a\udcbe\udada\udd8e\udbce\udd2c\ud889\udd2e\ud80a\udd82\ud8a0\udf41\ud8d5\ude58\uda61\udece\ud9be\uddf5\udb3a\udc2d\uda04\udfc4\uda22\udcc8\udaf8\uddcf\uda02\udc0c\udb33\udd51\ud8b3\udc49\ud8f8\uddd6\uda19\udc58\ud912\udc32"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\uda61\udf40\udb16\udd19\udac8\udd24\ud970\udd49\udbc7\udea7\udba1\udc07\udb2b\udfbf\udbf1\udf27\udbdb\udf1f\ud9d0\udc05\udad9\ude1a\ud8c4\udca4\uda55\udc47\ud95c\udcfb\uda0f\udde3\ua689\uf912\ud8db\udca1\udaa8\udf4a\ud9e0\udffb\udbf9\ude8b\uda0e\udedc\ud9a8\udcc2\ud88c\udcad\ud93e\udfce\udafe\udd61\ud8d4\udfa0\udbba\udc12\ud9b7\udee0\udb85\udd96\udab2\udcf8\udb60\udf71\ud9d5\udc99\udb96\udc6c\uda6c\udc97\uda8e\udfab\uda4a\udefc\ud8a5\udcea\udafb\udcf6\ud995\udc2f\udab4\udc41\ud9e7\udd5e\ud896\udf86\udad6\udd78\ud8ba\udfea\ud8eb\ude87\udb3a\udcbe\uda5f\udf86\udbce\udd2c\ud889\udd2e\ud80a\udd82\ud8a0\udf41\ud8d5\ude58\uda4f\uddce\ud9be\uddf5\udb3a\udc2d\uda04\udfc4\udae2\udcc8\udaf8\uddcf\uda02\udc0c\udb33\udd51\ud8b3\udc49\ud805\udc3d\uda19\udc51\ud912\udc32"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud853\udd8c\uda17\uddb6\udab7\uddd3\ud9b1\udd90\ud9c1\udf20\udb3a\uddcd\uda0e\udd91\ud941\uddb3\ud928\udc34\ud83b\udf38\ud81b\udca4\udaa8\ude66\udadb\udfb5\ud8cd\udc21\ud8f9\ude63\udab1\udce6\ud9f3\udea8\ud953\udc10\ud81d\udce0\ud894\udeff\uda69\udca7\ud8c4\udce0\u89d2\ue35c\ud88c\ude65\ud9c0\udcf1\ud9cb\ude05\ud83f\udcd6\ud993\udfbd\uda46\udf07\udbd3\udfd9\uabc0\ud857\udce3\ud9f1\ude43\udae8\ude29\udb75\udc27\ud892\udf21\ud981\ude25\ud9d9\udf69\udabe\ude88\udb91\uddd2"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("_\udb06\ude53\uda93\udfd8\ud9ad\ude8f\udbab\ude35\ud880\udc79\ud8ba\uddec\udaef\udc08"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("_q"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud853\udd8c\uda75\uddc5\ud875\udedc\ud814\udfee\ud9bb\udc20\udb63\udfc3\uda33\udfa2\ud941\uddb6\ud928\udc34\ud041\udb1e\ude66\udace\udc10\udadb\udfb5\ud8cd\udc21\ud8fc\udea5\udab1\udce6\ud9bc\udd2d\udacf\udd14\ud81d\udcee"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("_P\ud981\udc7d\ud8a8\udd8c"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\udacb\udf36\udbeb\udeb7\ud94d\udce3\udb3d\udfbe\udb3c\udd60\udbc9\ude58\uda10\udd1b\ud84e\ude6c\ud8a2\udf43\ud89c\udeb9\ud8b3\udfb7\ud9d3\udeab\ud9eb\udcf2\udbc2\udc3d\ud9fe\udca7\udb16\ude9c\udbde\udcd8\udb39\udead\ud83e\udf0b\uda01\udc40\udb6b\udd01\udaf2\ude1a\ud9a5\ude12\ud98a\udec2\udaf2\udc35\u873c\ud8a4\udcbc\ud923\udd24\u5c32\udb41\udec1\udb1e\udf55\udbcb\udc81\ud891\uddbd\ud804\udc5d\ud8c0\ude23\ud93b\udf2b\ud9f4\udf98\ud998\udd16\udae4\udff1\udae7\uddca\udade\udd4b\ud817\udf9c\uda0b\ude28\ud893\ude67\udba8\ude46\ud91f\ude2f\udb7f\udcc8\udb75\udea2\ud814\udebc\ud9a6\udfba\ud9bb\udde8\ud945\udefe\udab8\ude36\uda8d\udc3a\udbb5\udf47\ud850\udc34\ud949\udca9\uda01\udf7c\udae1\udcc9\ud9e5\udede\udb76\udfff\u6cbe\udbc8\ude2c\udb0b\ude91\ud8ce\udcfc\udb91\udd5e\udb0c\ude57\ud91a\udf9e\ud99e\udf1d\ud98c\udf03\udb1e\udd1f\uda0c\udea3\udb0e\udc6f\u63b1\ud8fb\udfe1\udbeb\ude0f\ud8a9\ude4c\uda5b\uddf3\ud92a\udf68\uda21\udd24\ud920\udf4f\uda34\udeed\udb74\udfe6\udb81\udca7\uda97\uddce\uda90\udd71\udb18\udf8c\ud878\udfb6\uda8a\udde0\ud802\uddcd\ua775\ud875\udfa4\ud8fe\udfb8\ud85a\udcf3\ud95c\udf96\udaae\udc55\ud8f6\udc83\uda29\uddd6\udb71\uddec\ud8c3\udc00\ud925\ude10\udadf\udee4\udaf4\udfe8\ud9e5\udd49\ud8b0\udc33\udb69\udcef\udb20\udd10\ud8ee\ude33\ud942\udcfa\ud824\udf3b\udb82\ude20\udac8\udc75\ud98d\udecf\ua5ef\ud908\udc19\ud9a8\udf21\ud93f\udc22\ud948\udca7\ud859\udc37\ud965\udf61\udafe\ude18\udb96\udc8e\uda19\udf6a\udb53\udcbc\ud893\udf1e\udaab\udc65\udbeb\udced\uda3a\udee7\uda10\udfa5"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\udacb\udf36\udbeb\udeb7\ud94d\udce3\udb3d\udfbe\udb3c\udd60\udbc9\ude58\uda10\udd1b\ud84e\ude6c\ud8a2\udf43\ud89c\udeb9\ud8b3\udfb7\ud9d3\udeab\ud9eb\udcf2\udbc2\udc3d\ud9fe\udca7\udb16\ude9c\ud929\ude3a\udb3b\udd15\ud83e\udf0b\uda01\udc40\udb6b\udd01\udaf2\ude1a\ud915\udd0a\ud98a\udf20\uda70\udc73\u6a02\ud8a4\udcbc\ud923\udd24\u5c32\udb41\udec1\udb1e\udf55\udbcb\udc81\ud867\udd08\ud804\udc46\ud8c0\ude23\ud93b\udf2b\ud9f4\udf98\ud998\udd16\udae4\udff1\udae7\uddca\udade\udd4b\ud817\udf9c\uda0b\ude28\ud893\ude67\udba8\ude46\ud91f\ude2f\udb7f\udcc8\udb75\udea2\ud814\udebc\ud9a6\udfba\ud9bb\udde8\ud945\udefe\udab8\ude36\uda8d\udc3a\udbb5\udf47\ud850\udc34\ud949\udca9\uda01\udf7c\udae1\udcc9\ud88c\udf6f\ud8e6\udd37\uda97\uddc5\u0eb4\udb0b\ude91\ud8ce\udcfc\udb91\udd5e\udb0c\ude57\ud834\udc8b\ud99e\udf1d\ud98c\udf03\udb1e\udd1f\uda0c\udea3\udb0e\udc6f\ud84f\udf2b\ud8fb\udfe1\udaf8\udd18\ud88f\udd6c\uda5b\uddf3\ud92a\udf68\uda21\udd24\ud920\udf4f\uda34\udeed\udb74\udfe6\udb81\udca7\uda97\uddce\uda90\udd71\udb18\udf8c\ud878\udfb6\uda8a\udde0\ud802\uddcd\ua775\ud875\udfa4\ud8fe\udfb8\ud85a\udcf3\ud95c\udf96\udaae\udc55\ud8f6\udc83\uda29\uddd6\udb71\uddec\ud8c3\udc00\ud925\ude10\ud851\udc9c\udae7\ude4d\ud9e5\udd49\ud8b0\udc33\udb69\udd0f\udb20\udd10\ud8ee\ude33\ud942\udcfa\ud824\udf3b\udb82\ude20\ud8fc\udfe9\ud98d\udf39\ua5ef\ud908\udc19\ud9a8\udf21\ud93f\udc22\ud948\udca7\ud859\udc37\ud965\udf61\udafe\ude18\udb96\udc8e\uda19\udf6a\udb53\udcbc\ud893\udf1e\udaab\udc65\udbeb\udced\uda3a\udee7\uda10\udfa5\udacb\udd13\udb2c\udde9\ud8e8\udd06\ud9a7\udfec\uda79\udc7b\udb56\udca4"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("_P\u1e64\ud8a9\uddcf\ud9c9\ude26\udbc4\udd02\uda75\udffd\ud93e\udc14\ud914\udd0a\ud928\udf9a\udaa3\udc8c\ud851\udf9f\ud9d8\udfd1\uda6b\udc3b\ud93d\udeda"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.LocaleUtils.toLocale("_P\u1e64");
    assertNotNull(r);
    assertEquals("java.util.Locale", r.getClass().getName());
    assertEquals("_P\u1e64", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.LocaleUtils.toLocale("\ud853\udd8c\uda17\uddb6\udab7\uddd3\ud9b1\udd90\ud9c1\udf20\udb3a\uddcd\uda0e\udd91\ud9c3\uddb4\ud928\udc34\ud83b\udf38\ud81b\udca4\udaa8\ude66\udadb\udfb5\udb5f\udd6a\ud903\udce7\udab1\udce6\udbe4\udcc4\udb8f\ude14\ud8ee\udfe1\uda57\uded6\ud8b4\udf1f\ud8c4\udd1f\ud87a\uddc5\uda7c\udf6b\ud9e0\uded7\ud9c0\udcf1\udbe5\udcd3\ud8e5\ude07\ud993\udfbd\uda46\udf07\udbd3\udfd9\uabc0\uda13\udc41\ud9f1\ude43\udae8\ude29\udb75\udc27\ud892\udf21\ud981\ude25\ud9d9\udf69\ud9e7\uddc9\udb91\uddd2"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
}
