package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class StopWatch_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\udb7e\udc7a", "\u9691\u63a3\u7c06\u1c0d\u5d4c\u6610\ud1f4\u534c\uc5fa\ucf2a\ub558\ua1b7\u7295\u132b\u01be\ucfc4\u6f1d\ub370\ud1c3\ua766\u6417\u880f\u9d06\u58f9\u9e05\ubc27", "\uda76\udfd6\udbe4\udd98\udaf7\udc1f\ud93d\udd7a",
        7, 33821, -214407155, 7310447381036076894L, -48459L, true, true, (char) 30138, (char) 7073,
        Double.longBitsToDouble(0x3febfcf78d5a804aL), Double.longBitsToDouble(0x3fdf5e405454d7deL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 2, 2, 6, "\udbfb\udca5\ud909\udce8\udaf4\ude8b\u49dc\udae2\udedd\udae8\udd8f\ud8dd\udc19\ud996\ude1e\uda49\udc33\ud8c9\udf74", "\u8108\u8569\ua1b7\u7295", "\udb3c\ude5d\udb51\udeff\udaa6\udcf7\uda54\uddc3\ud86f\udd38",
        18, 82436, -1588928747, 189140040093389410L, 95759L, false, true, (char) 28387, (char) 61628,
        Double.longBitsToDouble(0x3fe9d179b845eff9L), Double.longBitsToDouble(0x3fe86d91cbe9e50dL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 11, 0, "\udb7e\udc7a", "\u9691\u63a3\ub205\u9587\000\u65a2m\u534c\uc5fa\u6f8a\u34be\ua1b7\u7295\u132b\u01be\ucfc4\u6f1d\ub370\ud1c3\ua766\u6417\u7eac\ucd89\u1d01\u9da3\ubc27", "\000\udbe4\udd98\udaf7\udc1f",
        30, 8514, 0, -920986122095170263L, -21421L, false, false, (char) 5524, (char) 30138,
        Double.longBitsToDouble(0x3fee1c9ef37f9ef1L), Double.longBitsToDouble(0x3fd5a804abebc80aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 2, "\udae7\ude37\uda28\udd3f", "\u63be\ua618\u1bb6\u5d4c\uafa9\u3c96\u534c\ucfbb\u3120\ub558\ua1b7\u7295\u4a81\u016c\ucfc4\u6f1d\ub370\ud1c3\u097d\u6417", "\uda50\udc21\uda87\ude8a\ud819\udf2f\ud893\uddd4\ud8c3\udd55\uda7e\udcd6\udbe4\udd98\udaf7\udc1f\ud8cd\udd2d\ud8d1\ude48\ud807\udea7",
        27, 43169, 534187870, 7108143606497069397L, 59713L, true, true, (char) 25200, (char) 57252,
        Double.longBitsToDouble(0x3fe27f202a2a6bacL), Double.longBitsToDouble(0x3fd988d58d22b5aeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 11, 10, "\udb7e\udc7a", "\u9691\u63a3\u7c06\u1c0d\u5d4c\u6610\ud1f4\u534c\uc5fa\ucf2a\ub597\ua1b7\u7295\u132b\u01be\ucfc4\u6f1d\ub370\ud1c3\ua766\u6417\u1481\u7b9b\u58f2\u61ce\u11eb", "\uda76\udfd6\ud9a0\ude15\udaf6\udfdd",
        30, 19842, -1304885179, -920871717051306711L, -21421L, true, true, (char) 15757, (char) 30138,
        Double.longBitsToDouble(0x3fee1c9ef37f9ef1L), Double.longBitsToDouble(0x3fd5a804abebc80aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\udb7e\udc7a", "\u9691\u63a3\u7c06\u1c0d\u5d4c\u6610\ud1f4V\000\ucea0\ub558\ua1b7\u7295\u63ec\000\u4973\u6f1d\u5cec\000\000\ub530\u880f\u9d06\u58f9\ud262\000", "\uda76\udfd6",
        -3, 43263, 792177330, -1154663982733653947L, -95177L, false, true, (char) 21194, (char) 11258,
        Double.longBitsToDouble(0x3fefc8aca7e105d9L), Double.longBitsToDouble(0x3fee1c9ef37f9ef1L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\udb7e\udc7a\uda28\uddbe\udae3\udee7\u49dc\udae2\udedd\udae8\udd8f\ud8dd\udc19", "\ud1f4\u534c\u52d5\ucf33\ub558\ua1b7\u7295\u132b\u875f\ucfc4\u6f1d\ub370\ud1c3\ua766\u6417\u880f\u4248\u827a\u9df5\ubc27\ubc0b\uada1\u8baf\u2c3a\uc303\u3af4", "\ud899\udf4c\uda32\udf23\ud946\udd3e\ud882\uddac\uda3e\udf3b\ud8bc\udc51\uda9c\udd81\udaf0\ude0a\uda64\ude77\uda8a\udd38\ud953\udfae\ud884\udc78\uda71\udc21\uda93\udd17\udba4\ude45\ud91e\uddf8\ud884\udd35\ud9e1\udd42\uda29\ude0f\ud82c\ude1d\ud8ae\udf91\udb95\udc80\udac0\udd91\uda11\udd05\udb37\udedb\udad7\ude1d\ud9de\udc0c\udb0c\udecb\udb1c\udec8\ud8d5\ude8d\udb19\udfb6\uda51\udfcc\ud862\udc48\uda00\udf86\udb6c\udd27\uda54\uddfd\ud880\ude4a\ud865\udfcb\ud947\udde6\u5748\udb40\udd60\ud8b7\ude2d\ud958\udfe5\udb84\udd2c\ud9af\ude7e\udb81\udeda\udae8\udea9\ud99d\ude54\uda90\udd53\uda52\udc6a\ue48f\ud842\udebb\uda4d\ude6b\udbc6\uddaf\ud9c0\ude09",
        5, 18597, 377900672, 6074345951338817540L, -45013L, false, false, (char) 37056, (char) 1607,
        Double.longBitsToDouble(0x3fee6c3691e68fb8L), Double.longBitsToDouble(0x3fa027eeefa94130L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 11, 6, "\udbc8\ude47", "\u962f\u63a3\u7c06\u1c0d\u5d4c\u4067\u4b38\ub892\uc65e\ucf2a\ubb59\u929a\ua8a3\u1826\u01be\ucfc4\u6f1d\ub38d\u43c0\ua7b7\u18d5\u10b6\ua533\u506c\u9e05\ubc27", "\uda76\udfd6\udbe4\udd98\udaf7\udc1f\ud93d\udd7a\ud8d1\ude48\uda56\udfaf\u8f52\uda15\udd95\ud946\udd3e\ud8b0\udcc3\udbf4\udedc\u9b5f\udb49\ude95\udaf0\ude0a\udb8f\udecc\ud9ca\udcb2",
        53, 81618, 740718090, 4255845614008717974L, -57276L, true, false, (char) 32525, (char) 6747,
        Double.longBitsToDouble(0x3fe705c2c938ea8aL), Double.longBitsToDouble(0x3fea38f478c0aae0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\udb7e\udc7a", "\u9691\u63a3\u7c06\u1c0d\u5d4c\u6610\ud1f4\u534c\uc5fa\ucf2a\ub558\ua1b7\u7295\u132b\u01be\u7b46\u6f0a\ub370\ud1c3\ua766\u6417\u880f\uac8b\u0a26\u38e7\ub834", "\uda76\udfd6\udbe4\udd98\udaf7\udc1f\ud93d\udd7a\ud8d1\ude48\uda56\udfaf\ud899\udf4c\uda32\udf23\ud946\udd3e\ud8b0\udcc3\uda3e\ude9a\ud8bc\udc51\uda9c\udd81\udaf0\ude0a\ud922\udff8\udb8c\udfb3\ud94d\udc51",
        2, 70440, -733500405, -8852807078239425156L, 13057L, false, true, (char) 32946, (char) 37707,
        Double.longBitsToDouble(0x3fdad42a8274b3b4L), Double.longBitsToDouble(0x3fd92e159db75b1aL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 3, 6, "\udb7e\udc7a", "\u9691\u63a3\u7c06\u1c0d\u7d4c\u0811\u5f8a\u534c\uac80\u9c28\u821e\u3952\u7295\u7ece\u01af\ucfc4\u6f1d\uccd3\u2f5a\u253f\u97d3\u880f\u6775\u58f9\u9e05\u109a", "\uda8a\udd2c\udb24\udc83\uda61\udc6a\uda81\udebb\ud82f\udd4b\ud906\udc5c\ud899\udf4c\uda32\udf23\ud946\udd3e\ud8b0\udcc3\udae2\udcb2\ud8bc\udc51\ud8c0\udf4f\udaf0\ude05\ud922\udff8\udb8c\udfb3\ud94d\udc51\uda0d\ude1c",
        23, 2384, 315152122, 3725475673083779897L, 20379L, false, true, (char) 34434, (char) 13836,
        Double.longBitsToDouble(0x3fd077e6abb51032L), Double.longBitsToDouble(0x3fd97928930b9dc6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 1, 6, "\udb7e\udc7a", "\u96bc\uc632\u0f06\u94a0\u8468\u25fb\u49f2\ubf5c\uc5fa\ucf2a\ub558", "\ud8cc\udde5\ud9ff\udcd3\udb3c\ude5d\udb51\udeff",
        1, 3179, 1462540309, 3234014331887386284L, -97405L, false, false, (char) 22130, (char) 21570,
        Double.longBitsToDouble(0x3fdeca92e1292242L), Double.longBitsToDouble(0x3faf6920fff9ee40L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 7, 7, "\udb7e\udc7a\uda28\uddbe\udae3\udeb7\u9cef\u0e02\uda46\uddc9\ud826\udc7c\udb31\udc27\ud988\udfbb\udae0\udd46", "\ud4a5\uc794\uc3ea\u7cce\u50d4\u103d\uc40b\u08d7\ub2f5\ud1c3\ua766\u83eb\u880f\u9d06\u0099", "\ud9ba\udf9c\ud8bf\ude08\ud964\udf3b\u9c87\udbd0\uddec\ud93d\udcdd\ud8d1\ude48",
        47, 1997, 1702096169, 2294319433141037368L, 71808L, false, false, (char) 7073, (char) 25200,
        Double.longBitsToDouble(0x3fd5a804abebc80aL), Double.longBitsToDouble(0x3fe66b5f7f9b678fL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 9, 6, "\udbb0\udd0e", "\u9691\u63a3\u7c06\u1c0d\u7a0c\u6610\ud1f4\u532e\uc5fa\ucf2a\ub558\u396b\ua762\u132b\u01be\ucfc4\u6f1d\ub370\ud1c3\ua766\u6417\u880f\u9d06\u6c87\uad49\u4e3a", "\uda76\udfd6\udbe4\udd98\udaf7\udc1f\ud93d\udd7a",
        7, 33821, -214407155, 7310447381036076894L, -48459L, true, true, (char) 61757, (char) 20129,
        Double.longBitsToDouble(0x3febfa18055a804aL), Double.longBitsToDouble(0x3fdf5e4054b590c8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 2, 9, 4, "\udb7e\udc7a", "\u9691\ua51e\u9262\u1c5a\u5d4c\u6610\ud1f4\u534c\uc5fa\ucf2a\ub558\ua1b7\u7295\u132b\u01be\ucfc4\u6f1d\ub370\ud1c3\ua766\u6417\u880f\u9d06\u58f9\u9e05\ubc27", "\uda76\udfd6\udbe4\udd98\udaf7\udc1f\udb60\udd0b",
        56, 33821, -214407155, 7310447381036076894L, -48459L, false, true, (char) 18717, (char) 7073,
        Double.longBitsToDouble(0x3febfcf78d5a804aL), Double.longBitsToDouble(0x3fdf5e405454d7deL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 11, 3, 6, "\udb7e\udc7a", "\u9691\u125e,\u1c0d\u5d4c\u6610\u27dc\u534c\uc5fa\ucf2a\ub558\ua1b7\u7295\u132b\u8d4b\u95b3\u8a43\uc350\ud292\ua766\u6417\u880f\u9d06\u46f8\u9e05\ubc27", "\uda76\udfd6\udbe4\udd98\udaf7\udc1f\ud93d\udd7a",
        7, 33821, -214407155, -7877042963949037475L, -48459L, true, true, (char) 17615, (char) 7073,
        Double.longBitsToDouble(0x3febfcf78d5a804aL), Double.longBitsToDouble(0x3fdf5e405454d7deL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\udb7e\udc7a", "\ub211", "\uda06\udeb9\ud996\ude1e\uda49\udc33\ud87c\udd2d\ud9ad\udf77\ud9b8\ude28",
        34, 60814, 558078539, -7148092046717393940L, 62223L, true, true, (char) 60807, (char) 21071,
        Double.longBitsToDouble(0x3f959574dccae580L), Double.longBitsToDouble(0x3fe561670d157aabL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 6, 8, 2, "\udb7e\udc96", "\u9691\u64ca\u809b\u056f\u5d4c\u6610\ud1f4\u534c\uc5fa\ucf2a\u5615\u0604\u63eb\u132b\u01be\u29d8\u6ea2\ub370\ud1c3\ua766\u6417\u880f\u9d06\u58f9\u9e05\ubc27", "\uda76\udfd6\udbe4\udd98\udaf7\udc1f\ud93d\udd7a",
        7, 33821, -208115699, 7310447382361476958L, -48459L, true, true, (char) 30138, (char) 7073,
        Double.longBitsToDouble(0x3febfcf78d5a804aL), Double.longBitsToDouble(0x3fdf5e4054749f64L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 7, 10, "\udb7e\udc7a\uda28\uddbe\ud8e1\udf62\u49dc\udae2\udedd\udae8\udd5e\ud8dd\udc19\ud996\ude1e\uda49\udc33\ud917\udc6b\u477c\ud9b8\ude36\ud8e1\udc4b\udac8\uddfa\uda25\uded1\ud971\ude14\ud8e6\udcdc\ud9ff\udcd3", "\ub370\ud1c3", "\ud8f7\udf58\ud909\udc25\uda4d\ude22\uda5c\ude46\ud819\udf2f\ud893\uddd4\ud8a9\udf55\uda76\udfd6\udbe4\ude0a\udaf6\udfda\ud93d\udd7a\ud8d1\ude48\uda49\uddf3\ud88d\udee5\ud962\udf22",
        46, 31838, 362072405, 7555113801660713740L, 81119L, false, true, (char) 46330, (char) 16447,
        Double.longBitsToDouble(0x3fcce5fc87562e80L), Double.longBitsToDouble(0x3fdb9b84ae5e64a0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 6, 3, 6, "\udb7e\udc7a", "\u9691\u2d18\u7c99\u1c0d\u5d4c\u6610\ubc06\u537f\uc5fa\u9e4e\ub558\ua172\u7295\u132b\u01be\ucfc4\u6f1d\ub370\ud1c3\u9540\u63b3\u880f\u9d06\u1e95\u9e05\ubc27", "\uda73\ude12",
        -3, 43263, 792177330, -1154663982733653947L, -95177L, false, true, (char) 21194, (char) 48428,
        Double.longBitsToDouble(0x3fefc8aca72563c4L), Double.longBitsToDouble(0x3fd08d12e6ff3cb2L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\ud8dd\udcbb\ud974\ude0b\udae3\udee7\ub4dc", "\ucbe0\u8a28\u6610\ud61a\u56f6\u6bd6", "\udb35\udcd1\ud958\udcf5",
        -1, 48470, 1152996807, 4102053190982481051L, -97405L, false, false, (char) 28768, (char) 34993,
        Double.longBitsToDouble(0x3fea7ebffd2aaa5fL), Double.longBitsToDouble(0x3fda4969bfff3dc8L)));
  }
  @Test
  public void test20() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test20() throws Throwable {
//     assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
//         Z.run(T, 2, 6, 5, 10, "\udb7e\udc7a\udaa4\uddbc\udae3\udee7\u49dc\udae2\udedd\udae8\udd8f\ud8dd\udc19\ud996\ude1e\uda49\udc33\ud834\udefa\ud9ad\udf77\ud9b8\ude28\ud8e1\udc4b", "\u7295", "\udb3c\ude5d\udb51\udeff\udaa6\udcf7\uda54\uddc3\ud86f\udd38",
//         18, 82436, -1586207467, 189140040093389410L, 46162L, false, true, (char) 20176, (char) 20731,
//         Double.longBitsToDouble(0x3feffcf722b2460bL), Double.longBitsToDouble(0x3fe9d179bd89fff9L)));
//   }
  @Test
  public void test21() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test21() throws Throwable {
//     assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
//         Z.run(T, 2, 6, 6, 11, "\udb7e\udc7a\uda28\uddbe", "\u63a3\u7c06\u1c0d\u5d4c\u6610\ud1f4\u534c\u9355\ub7d9\ub558\ua1b7\u7295\u132b\u01be\ucfc4\u6f1d\ub370\ub2c7\ua766\u6417", "\uda4d\ude04\ud988\udf72\uda28\udd6e\ud893\uddd4\ud8c3\udd55\uda76\udfd6\ud9a8\udd9a\udaf7\udc1f\ud93d\udd7a\ud8d1\ude48\udb26\udfb7",
//         20, 37449, 534187870, 7108143606494710101L, 59713L, true, false, (char) 56037, (char) 58788,
//         Double.longBitsToDouble(0x3fdf5e405454d7deL), Double.longBitsToDouble(0x3fefbab945c4742aL)));
//   }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 6, 4, 4, "\udb7e\udc7a", "\u9691\u63a3\u7c06\u1c0d\u5d4c\u6610\ud1f4\u17ea\u7ca2\ucf2a\ub558\ua1b7\u7295\u132b\u01be\ucfc4\u5d22\ub370\ud1c3\ua766\u6417\u880f\u9d06\u58f9\u9e05\ua473", "\uda76\udfd6",
        -3, 43263, 792177330, -1188629463840520123L, -95177L, false, true, (char) 21194, (char) 11258,
        Double.longBitsToDouble(0x3fefc8aca7e105d9L), Double.longBitsToDouble(0x3fee1c9ef37f9ef1L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\000", "\u9691", "\ud8dd\udc19\u5a5f\000m\000\000",
        10, 60814, 558078539, 171211489280L, 62223L, true, true, (char) 237, (char) 0,
        Double.longBitsToDouble(0x3f959500dccae580L), Double.longBitsToDouble(0x3fe56167080000abL)));
  }
  @Test
  public void test24() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test24() throws Throwable {
//     assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
//         Z.run(T, 2, 6, 0, 0, "\udba4\udf0e", "\000", "\ud8dc\udf88\ud996\ude1e\uda49\udc33\000\ud9ad\udf21\ud9b8\ude28",
//         34, 60814, 558078539, -7148092046717393940L, -53765L, true, false, (char) 11657, (char) 56849,
//         Double.longBitsToDouble(0x3fe561670d157aabL), Double.longBitsToDouble(0x3fddda1744c4053eL)));
//   }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\u96e6", "\u9691\u63a3\u7c06\u1c0d\u5d4c\u6610\ud1f4\u534c\uc5fa\ucf2a\ub558\ua1b7\u06f3\u132b\u01be\ucfc4\u6f1d\ub370\ud1c3\ua766\u6417\u880f\u9d06\u58f9\u9e05\u6551", "\uda76\udfd6",
        -3, 43263, 792177330, 1583524590707668033L, -95177L, false, true, (char) 21194, (char) 11258,
        Double.longBitsToDouble(0x3fefc8aca4e105d9L), Double.longBitsToDouble(0x3fef15eb2b7f9ef1L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 10, 6, "\udbc5\udd1e\ud84e\udfd7\ud812\udc1f\uda11\udee0\ud945\udd0c\udbeb\ude66\ud91a\udd0f\udbc4\uddc8\uda49\udcbe\udb04\udd62\ud875\udf4f\udb6a\udd31\ud8e1\udc90\udbfd\ude57\ud92e\udfbe\ud986\ude2a\ud8cc\udde5\ud820\udd8b\udb3c\ude83\udb51\udeff\udaa6\udcf7\ud916\ude97\uda60\udd39\ud82e\udd8b\uda97\udde6", "\u9e05\ubc27\ubc0b\uada1\u0b3f", "\ud93d\udd7a\ud939\udcfc\uda71\udffb\ud899\udf4c\udaf8\udf36\ud946\udd3e\uda41\udecd\uda3e\ude9a\ud8bc\udc51\udab6\udf54\udaf0\ude0a\ud922\udff8\udb8c\udfb3",
        -5, 22914, 1841553681, 6356272882730382604L, -10619L, false, false, (char) 18542, (char) 30903,
        Double.longBitsToDouble(0x3fe4e1a6e4f648b2L), Double.longBitsToDouble(0x3fded631be1e43c4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 0, 6, "\udb7e\udc7a", "\u02c4\u48f6\u9fd8", "\uda49\udc33\ud87b\udff4\ud914\udca5\ud83f\udd11\ud8e1\udc4b\udac3\udefa\udb53\udc40\ud986\ude4f\ud8cc\udde5\ud9ff\udcd3\udb3c\ude5d\udb51\udeff\ud8b5\udeb8\udbd1\udf0d\ud941\udf2f\ud81d\udfed\uda97\udde6\u9b5b\udb04\udc80\uda64\udc78\ud993\udd9c\ud893\uddd4\ud8c3\udd55\uda76\udfd6\udbe4\udd98\udaf7\udc1f\ud93d\udd7a\ud8d1\ude48\udb55\ude2a\ud899\udf4c",
        54, 98870, 1654993651, 1555089138357184343L, 77928L, false, true, (char) 32379, (char) 24962,
        Double.longBitsToDouble(0x3fb57e0996077e80L), Double.longBitsToDouble(0x3fe883becdf7dbb6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 5, 5, "\udb7e\udc7a", "\u9691\u6448\u7c06\ud765\u5d4c\u6690\ud1f4\u534c\uc5fa\ucf2a\ube2f\u7fb0\u693e\u12b3\u01be\ucfc4\u6f1d\ub370\ud1c3\ua766\uae29\u66c3\u834d\u58f9\u9e05\ubc27", "\u7d4c\udbe4\udd4c\udaf7\udc1f\ud93d\udd7a",
        11, 67190, -214407155, 7310447381036076894L, -48459L, true, true, (char) 9798, (char) 7073,
        Double.longBitsToDouble(0x3febfcf78c5a804aL), Double.longBitsToDouble(0x3fe32e2f022a6b39L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\u1b00", "\u9691", "\ud8dd\udc19\ud996\ude1e",
        8, 41893, 891266134, -8456571445174112374L, 71028L, false, true, (char) 31865, (char) 45150,
        Double.longBitsToDouble(0x3fc3671da02f0910L), Double.longBitsToDouble(0x3f959574dccae580L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\udb7e\udc7a", "\u1c97\000\000\ucf7b\u5d4c\u6610\ud1f4\u534c\uc5fa\ucf2a\ub558\ua1b7\u7295\u00ec\000\000\u0378\ub370\ud1c3\ua766\u6417\u880f\u9d06\u58f9\ub30e\000", "",
        -5, -1000, 0, -268894208L, -100000L, true, true, (char) 30138, (char) 7073,
        Double.longBitsToDouble(0x3febfcf78d5a804aL), Double.longBitsToDouble(0x3fdf5e4054540000L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 9, "\udb7e\udc7a\uda28\udd9a\udae3\udeaf\u49dc\udae2\udedd\udac5\ude3b\udad5\udfe0\udb02\udec4\udba6\ude7e\udb2f\udd6b\uda64\udfc4\ud9b8\ude28\ud8e1\udc4b\udac3\udefa\udb53\udc40\ud986\ude4f\udb4e\udc52\ud9ff\udcf4\udb1e\ude67\udb51\udeff\udaa6\udcf7\uda54\uddc3\ud86f\udd38\ud82e\udd8b\uda97\udde6\uf0a5\uda4d\ude04\uda87\ude8a\ud819\udf2f", "\u8baf\u40f8\uc303\u52a8", "\ud899\udf4c\uda32\udf5d\ud946\udd3e\ud8b6\uddc2\udac0\ude9b\ud8bc\udc51\uda9c\udd81\udaf0\ude0a\uda94\udfb0\udbca\udd00\uda34\udd97\ud944\udc18\udaec\ude5a\udb3a\udce6\ud860\udde0\ud8ba\ude3b\ud9b0\udcac\uda66\udcc4\udb86\udeca\udb8c\udd4f\uda23\udd17\uda42\uddbf\ud956\ude7a\udad4\udcbb\ud95c\udf32\uda3a\udfb3\udbff\udd34\ud864\ude92\udaf3\udc79\uda4e\udd33\ud896\udd8d\uda95\udc9c\udad2\udd99\ud97d\udd7a\uda12\ude59\ud99f\udf60\ud946\udc56\ud9c3\ude23\udb4a\ude6d\uda75\uddbb\ud943\udd93\ud8db\udcaa\udb17\udf70\ud962\udc1b\udb07\udcec\ud8d8\udf03\udaf2\udddf\ud8ab\ude28\ud840\udc7c",
        0, 94266, -1766600301, -6601523946108809135L, -9110L, true, false, (char) 65383, (char) 470,
        Double.longBitsToDouble(0x3fee6e75b749f41dL), Double.longBitsToDouble(0x3fdecc05a9c51a8eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 2, 2, 0, "\u26a5", "\u1c97", "\ud8d4\udc19",
        4, 32118, 577430893, 3819052854579312915L, -100000L, false, false, (char) 296, (char) 0,
        Double.longBitsToDouble(0x3fd000000ca3ec50L), Double.longBitsToDouble(0x3ec7326c00000000L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 9, 2, 6, "\udbfb\udca5\ud909\udce8\ud974\udd2d\udbf3\udc86\udae2\udedd\udae8\udd8f\ud8dd\udc19\ud996\ude1e\uda49\udc33\ud8c9\udf74", "\u8108", "\ud986\ude4f",
        37, 23576, 1153009233, 4102053190982481051L, 94491L, true, true, (char) 20727, (char) 52794,
        Double.longBitsToDouble(0x3fa11a493b3870a0L), Double.longBitsToDouble(0x3fc4fd019be64e64L)));
  }
  @Test
  public void test34() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test34() throws Throwable {
//     assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
//         Z.run(T, 2, 6, 7, 6, "\udbfb\udca5\ud909\udce8\ud9c7\ude8b\ud8dd\udf22\udabd\udd76\udaf2\udf49\ud8dd\udc19\ud9af\uddc9\uda49\udc33\ud8c9\udf74\ud879\uddbe\udb3f\udd6a\ud9a2\ude12\ud895\udef7\udb35\udf62\ud986\ude4f\ud8cc\udde5\ud9ff\udcd3\udaf2\udd18\ud9ac\udebf\uda31\ude3d\ud967\udf20\ud8b8\uddae", "\u4847\u58f9\u9e05", "\ud985\udca9\udb92\udfd8\udbe4\udd98\udaf7\udc1f\ud93d\udd7a\ud8d1\ude48",
//         54, 44303, 1029991401, -8639729185268511250L, -6567L, true, true, (char) 43626, (char) 27848,
//         Double.longBitsToDouble(0x3fe921ee9f0479c9L), Double.longBitsToDouble(0x3fef3d1a464f7ff1L)));
//   }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 1, 11, 10, 8, "\udbfd\ude83\ud909\udce8\udaf4\ude17\udab7\udf0f\udac5\udf99\udae8\udd8f\ud8dd\udc19\ud996\ude1e\uda49\udc33\ud8c9\udf74", "\u8108\u8569\ua1b7\u7295", "\udb3c\ude5d\udb51\udeff\udaa6\udcf7\uda54\uddc3\ud86f\udd38",
        46, 78003, -1588928689, 189140040093389410L, 95759L, false, true, (char) 28387, (char) 61628,
        Double.longBitsToDouble(0x3fe9d179b845eff9L), Double.longBitsToDouble(0x3fe86d91cbe9e50dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 9, 9, 4, "\udb7e\udc7a\uda28\uddbe\udae3\udee7\u49dc\udae2\udedd\ud920\ude0c\ud8d5\udd90\ud996\ude1e", "\ua4e8\uc6c4\ucf2a\ub597\u37f0\u7295\u132b", "\uda41\udfdf\uda86\udcce\udb54\udf2e\ud86f\udd38\ud81a\ude99\udade\ude8a\ud840\udfba\uda34\uddfd\ud934\uddd6\ud953\ude28\u3498\ud8c3\udd55\uda76\udfd6",
        11, 19133, 792177330, -1154663982733653947L, -95177L, false, true, (char) 64978, (char) 11319,
        Double.longBitsToDouble(0x3fefc8aca7e105d9L), Double.longBitsToDouble(0x3fee1c9ef37f9ef1L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=new org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 11, 11, 10, "\uda94\udfcf", "\u9691\u63a3\u7c06\u1c0d\u5d4c\u6610", "\ud9b8\ude28\ud8e1\udc4b\udac3\udf39\udb53\udc40",
        28, 23172, -165110424, 4952136948676127653L, 62074L, false, false, (char) 14533, (char) 17378,
        Double.longBitsToDouble(0x3fe5b014fbc256fcL), Double.longBitsToDouble(0x3fe801d991ec7d14L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 2, 0, 0, "", "\uafb8\u96bc\uc632", "\000",
        27, 39704, 897777664, -8456571445174112374L, -100000L, false, false, (char) 63097, (char) 45150,
        Double.longBitsToDouble(0x3fc3671da0000110L), Double.longBitsToDouble(0x3f959500dccae580L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 2, 9, 0, "\udba4\udf0e", "", "",
        -5, -1000, 0, -5097210759596236974L, -39624L, false, true, (char) 56733, (char) 0,
        Double.longBitsToDouble(0x3fc4a897326ce3b4L), Double.longBitsToDouble(0x3f48488056540000L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 1, 11, 9, 6, "\udbb0\udd0e", "\u6b9a\u8820\u382c\u1c0d\u7a0c\u6610\ud1f4\u532e\uc5fa\ucf2a\ub558\u396b\ua762\u132b\u01be\ucfc4\u6f1d\ub370\u6668\ua766\u6417\u880f\u9d06\u8f7d\uad49\u4e3a", "\uda9f\uddb1\udbfd\udd98\udaf7\udc1f\ud93d\udd7a\ud908\udfc3\udb6e\udd08\ud899\udf4c\uda32\udf23\ud946\udd3e\ud8b0\udcc3\uda3e\ude9a\uda1a\udc81\uda9c\udd90\udb55\udeb5\ud922\udff8\uda96\udfb7",
        50, 28468, -1849446935, 2615050149889690182L, -90858L, true, true, (char) 3854, (char) 14814,
        Double.longBitsToDouble(0x3fdfca4e785fb904L), Double.longBitsToDouble(0x3fdd70eb9d4b03f8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 7, 11, 10, "\udb7e\udc7a\ud814\udf74\udbad\udf7e\u49dc\udae2\udedd\ud9ce\udd31\ud8dd\udc19\ud996\ude1e\uda49\udc33\ud917\udc6b\u477c\ud9b8\ude36\ud8e1\udc4b\udac8\uddfa\uda25\uded1\udaf9\ude18\ud8e6\udcdc\ud9ff\udcd3\udb3c\ude5d\ud9d5\udf81\uda4e\udd6f\uda34\uddca\ud825\uddf3\ud82e\udd8b\udb05\udd1e\ud9fb\udc8c\udb00\udc38\ud8dc\udcf1\ud819\udf2f\ud893\uddd4\ud8a9\udf55\uda76\udfd6\udbe4\ude0a\udaec\ude15\ud93d\udd61", "\u09b4\u33eb\u6935\u0c6a\u02e9\u443d\ud3cd\u39f3\ua422\ub430\u3211\u77f5\u65c9\uc4d7\u8d5a\u850d\u1aee\u69f8\u3763\u96fa\u9fbe\u2412\u6103\u2af5\u42a6\u9b44\ucdeb\u452b\u4579\u59d1\ua67b\u0798\u2a7a\u5d82\u79e8\u7458\u2806\ub23e\uc626\u92e7\uacb1\u3c52\uc3ad\u2485\ucf3c\u8778\u6325\u9339\u2c20", "\ud867\udcc1\ud850\udeb4\ud8b7\udc36\ud9aa\udf26\udbc5\uded2\ud9e5\udf4b\udbbd\udd4c\uda29\udfe4\uda7e\uded8\uda63\udc29\ud808\udf7d\udb23\udd54\ud839\uddc6\ud8e8\udf8a\ud989\ude14\ub391\uda5e\udf98\udbf1\udd42\udac7\udc51\ud883\udeed\ud887\udfa2\ud850\udcae\ud929\uddf1\ud860\ude75\uda41\uddb8\ud943\udf8f\udaaf\ude42\ud889\udf5d\ud80f\udd68\ud916\udc7f\ud9be\udf7f\ud853\udec4\ud9c8\udd3b\ud874\udc4c\udaad\ude04\ud943\udc02\ud86f\udf6d\udb31\udc73\udbe4\udc68\ud969\udde2\ud8ba\udc98\ud89f\uded5\udbab\udc34\uda7c\udfe2\ud84e\udc8a\u9c3f\uda39\udf70\ud831\udc4f\ud8b3\udebb\uda0a\udfd5\uda6c\udf37\ud882\udc21\ud9fe\udc6c",
        48, 7920, -2087114118, -5806924143413093449L, 12066L, false, true, (char) 54763, (char) 41171,
        Double.longBitsToDouble(0x3fef03ed5bd744caL), Double.longBitsToDouble(0x3feccc75ab099ca7L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 3, 6, "\udb7e\udc7a", "\u9691\u63a3\u7c06\u1c0d\u5d4c\u6610\ud1f4\u534c\uc5fa\ucf2a\u8345\u45dd\u15f7\u128e\u01be\ucfc4\u6f1d\ub370\ud1c3\ua766\u6417\u880f\u9d06\u58f9\u9e05\ubc27", "\uda76\udfd6\udbe4\udd98\udaf7\udc1f\ud93d\udd7a",
        7, 33821, -214407155, 7310447381036076894L, -48459L, true, true, (char) 30138, (char) 7073,
        Double.longBitsToDouble(0x3febfcf78d5a804aL), Double.longBitsToDouble(0x3fdf5e405454d7deL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 9, 2, 6, "\udad1\udd4f\udb84\udf85\uda5c\udd82\udbf3\udc86\udae2\udedd\udae8\udd8f\ud8dd\udc19\ud9de\udfad\udaf4\udd93\ud9e6\udd86", "\u8108", "\ud96b\ude2d",
        37, 23576, 1153009233, 4102053189995246747L, 58697L, false, false, (char) 25780, (char) 45757,
        Double.longBitsToDouble(0x3fc4fd019be64e64L), Double.longBitsToDouble(0x3febde62503ab027L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.time.StopWatch|stop||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|getSplitTime||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|getTime||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|reset||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|resume||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|split||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|start||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|suspend||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|toSplitString||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|toString||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|unsplit||new:org.apache.commons.lang.time.StopWatch:",
    "C|org.apache.commons.lang.time.StopWatch|<init>|",
    "M|org.apache.commons.lang.time.StopWatch|stop||new:org.apache.commons.lang.time.StopWatch:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
