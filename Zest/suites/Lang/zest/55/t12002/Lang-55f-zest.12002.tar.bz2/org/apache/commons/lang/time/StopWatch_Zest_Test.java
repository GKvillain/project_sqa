package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class StopWatch_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u7395\u4366\ubab2", "\ud934\udc53\udb6b\udf4a\uda7c\udc00\udb04\udf26\udba1\udd40\ud9aa\udd35",
        44, 99751, 649119976, -4824378155475821460L, 84534L, false, true, (char) 31607, (char) 63379,
        Double.longBitsToDouble(0x3fd2c42dcac2fe1cL), Double.longBitsToDouble(0x3fca266cd67ace78L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 9, 5, "\udbcb\ude33\ud856\udd7c\u8f9f\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\udb23\udcf3\uda30\udd50\uda4c\udfd6\u6896\ud997\udd2a\ud873\udd3e\udb94\udc1c", "\u7395\u4366\ubab2", "\ud934\udc53\udb6b\udf4a\uda7c\udc00\udb04\udf26\udba1\udd40\ud9aa\udd35",
        44, 36711, 649119976, 8553074157112587309L, 84534L, false, true, (char) 31607, (char) 63379,
        Double.longBitsToDouble(0x3fe94266e5617f30L), Double.longBitsToDouble(0x3fe6619b35d96598L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 9, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\ub706\udadb\uded3\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\u7476\ud84d\udd62\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\000\u4366\ubab2", "\ud934\udc53\udb6b\udf4a\uda7c\udc00\udb04\udf26\udba1\udd40\ud9aa\udd35",
        44, 99751, 649119976, -4824378155475821460L, 84534L, false, true, (char) 31607, (char) 63379,
        Double.longBitsToDouble(0x3fd2c42dcac2fe1cL), Double.longBitsToDouble(0x3fca266cd67ace78L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 5, "\udbcb\ude33\udb92\udccd\u4a93\uda53\udd60\udac7\udc25", "\u6fc1\u241f\uad04\ub354\u7fba\u97d2\u36da\ub4d0\u9091\u4d42\u7e4d\u373f\u573d\u4538\u4291\u73a5\u4366\ubab2\u916f\u2e1b\u76ad\ucdab\u3efe\uca8e", "\uda5a\udc49\ud8b5\udfe2\udac2\udf2f\udbb2\uddae\udb8c\uddde\ud916\udd0a\udbef\udfcd\udb9a\udd8b\udbca\udfe9\udbe8\udf24\udb08\udcd4\udadb\ude41\udb73\udca8\ud9bc\udcc9\udaa6\udc50\uda09\udc09\udb73\udd4e\ud966\udc8c\udb91\udcbb",
        -5, 67730, 2007054219, -4058525354763764419L, 46818L, true, false, (char) 25213, (char) 27037,
        Double.longBitsToDouble(0x3febca9cf9a76b09L), Double.longBitsToDouble(0x3fe814a7a4ea051dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 7, 9, "\udbcb\ude33\ud89a\udf7e\u4b3c\ud992\udf4b\udac7\udc82\uda10\udf77\ud9b7\udfe1\udbeb\udded\udaa5\ude2b\udbab\udf32", "\uccbd\u365d\ub4d0\u9091\u4d42\u7e4d\u373f\u573d\u4538\u4291\u7395\u4366\ubab2\u916f\ub407\u76bb\ucdab\u3efe\uca8e\ud4a8\u31f6\u492e\u3d60\u4695\u5696\u111d\uab55\u2138\u593f\u3dcc\u73a5\u28c7\u0990\u0bc3\ua24c\u2a4a\ua8cd\u442d\u6ec8\u5600\u7d36\u700e\u693d\u768c\uc2bb\u9f88\u0e34\ud374", "\u1051\udb4f\udd9f\udaae\ude32\ud8e3\ude9c\uda8e\udc48\udb18\udec1\udb79\udf7f\ud92e\udc71\ufb13\udab9\ude86\ud927\udec0\udb43\udd3f\udb0c\uddfa\udb1d\udd46",
        49, 75190, 1033896512, -4862877259562315683L, -46875L, true, true, (char) 52725, (char) 7531,
        Double.longBitsToDouble(0x3fd71d66b778430aL), Double.longBitsToDouble(0x3fc241c33004cef4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 1, 0, "\udb0a\udc06\ud9cc\udc89", "\ubcb0\u580b\u9140", "\udbb4\udf17",
        8, 99398, 1817253746, -4018749136614815623L, -36703L, false, false, (char) 9801, (char) 57806,
        Double.longBitsToDouble(0x3feb1636f858f2abL), Double.longBitsToDouble(0x3fc18d54a50cdeecL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\000\uda48\udfa4\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u7395\u4366\ubab2", "\ud934\udc53\ud878\udcb1\ud847\udf03\000\udb90\udf07\ud9aa\udd35",
        44, 99751, 649119976, -4824378155475821460L, -100000L, false, false, (char) 8200, (char) 11375,
        Double.longBitsToDouble(0x3fca200cd67ace78L), Double.longBitsToDouble(0x3fee0549ec8a5164L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\ud8c2\udeea", "\u7395\u4366\ubab2\u916f", "\udb6b\udf4a\uda7c\udc00\udb04\udf26\udba1\udd40\ud9aa\udd35\uda5a\udc49\ud8b5\udfe2\udac2\udf2f\udbb2\uddae\udb8c\uddde\ud916\udd0a\udbef\udfcd\udb9a\udd8b\udbca\udfe9\udbe8\udf24\udb08\udcd4\udadb\ude41",
        26, 28073, -1281450799, 5153170885794835497L, 75082L, false, true, (char) 25519, (char) 36962,
        Double.longBitsToDouble(0x3feaa8e68a307875L), Double.longBitsToDouble(0x3fe63b5eab30ce29L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 1, 7, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\ud9ac\udc33", "\u7c20\uad04\u8bed", "\uda4f\uddaa\uda6c\udf1e\ud973\udfc9\u68d7\uda58\udc32\uda14\ude2e\udb3a\udf9a\uda1a\udf85\ud878\udee8\udb90\ude98",
        4, 12684, -1244929694, -3798933052095125185L, 43740L, true, true, (char) 2209, (char) 30712,
        Double.longBitsToDouble(0x3fbe5d4f50f8ef50L), Double.longBitsToDouble(0x3fcd0c3916849ac0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 10, 11, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u3595\u4366\ubab2", "\uda64\udd4a\udb46\udf0a\uda7b\udf6b\udb04\udf26\udba1\udd40\ud9aa\udd35",
        44, 99751, 649119976, -4824378155475821460L, 84534L, false, true, (char) 31607, (char) 22895,
        Double.longBitsToDouble(0x3fe05eefc5617f0eL), Double.longBitsToDouble(0x3fca266cc27ace78L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 5, 7, "\udbcb\ude33\ud89a\udf7e\udace\udc37\ud95d\udd64\udac7\udc25\udae0\udcdf\ud91c\udda0\udbeb\ude72\udaa5\ude2b\udb44\udc7e\uda6c\udef4\ud994\udc70\ud84d\udd73\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\ud87e\ude62\ud9ab\udff3", "\u7f32\u4366\ubab2", "\ud934\udc53\udb6b\udf4a\uda7c\udc00\udb04\udf26\udba1\udd40\udaa0\ude9e",
        -2, 99751, 649119976, -4824399046196749204L, 1334L, false, true, (char) 11727, (char) 63379,
        Double.longBitsToDouble(0x3fd2c42dcac2fe1cL), Double.longBitsToDouble(0x3fecec33352dd313L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 0, 1, 3, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25", "\u3c13\u241f\uad04\u3ba0\u7fba\u70d3", "\uda83\ude8d",
        5, 36232, 300742505, -2104987892332498601L, -70146L, true, false, (char) 4304, (char) 7636,
        Double.longBitsToDouble(0x3fe5be55a1675c1aL), Double.longBitsToDouble(0x3fc5de0c368dc0d4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 3, 9, 5, "\u0baf\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\u078d\udbd5\udcb0\udb61\udd92\uda4b\udc08\udb3a\udf9a", "\ucdf4\u43a8\ube8c", "\ud934\udc53",
        36, 4611, -962191736, 3705972357282481290L, -76031L, false, false, (char) 38638, (char) 47671,
        Double.longBitsToDouble(0x3fe80eb51f2aa365L), Double.longBitsToDouble(0x3fd42c8d9f28c7e6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u7395\u4939\u64d1", "\udbc4\udc5b\udb6b\udf4a\uda7c\udc00\udb04\udf26\udba1\udd40\ud9aa\udd35\uda5a\udc49\ud8b5\udfe2\udac2\udf2f\udbb2\uddae\udb8c\uddde\ud916\udd0a\udbef\udfcd\udb9a\udd8b",
        15, 62170, 356718484, 4817974541031497004L, 71217L, false, true, (char) 55172, (char) 53281,
        Double.longBitsToDouble(0x3fd0b2d049bd2b82L), Double.longBitsToDouble(0x3fd8202f1cc83f1aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u7395\uc262\uc3ae", "\ud934\udc53\udb6b\udf4a\uda7c\udc00\udb04\udf26",
        39, 52306, 489987729, 7046077463883991272L, 56564L, true, false, (char) 46573, (char) 46379,
        Double.longBitsToDouble(0x3fefea136d42c8d9L), Double.longBitsToDouble(0x3feca31f1a511543L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60", "\u8649\u80e6\u241f\uad04\ub354\u7fba\u97d2\u36da\ub4d0\u9091\u7e82\u7e4d\u373f\u573d\u0fe6\u669e\u7395\u7b47\u05ce\u916f\ub407\u76bb\ucdab\u3efe\uca8e\u712e\u7860\u0383\uc610\ua6a8\u5b27\u111d\uab55\u2138\u593f\u3dcc\u73a5\u28c7\u0990\u0bc3\ua24c\u2a4a\ub4fb\u0db5\ud081", "\ua003\uda56\udc72\ud91d\udef7\ud99c\udc7b\uda3d\ude93\ud9d2\udfff\uda9b\udd14\ud80d\udc1d",
        44, 36325, -1759260214, 515054792957320286L, -96751L, true, false, (char) 14735, (char) 40206,
        Double.longBitsToDouble(0x3fe14b4d727d60eeL), Double.longBitsToDouble(0x3fd2aeab727242d4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 4, 5, "\udaec\udda2\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\udb5f\udf32\u8971\udb81\ude15\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u7395\u3414\ubab2", "\ud93c\udedc\udb6b\udf4a",
        51, 34264, 862863929, 5709795262561820305L, -48568L, true, true, (char) 22904, (char) 38638,
        Double.longBitsToDouble(0x3fe1f39d7f01d6a3L), Double.longBitsToDouble(0x3fe9551b2d42c8d9L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 5, 5, "", "\u3c91\ud185\u7594\u577f\u8649\u6fc1\u241f\uad04\ub354\u7fba\u80d2", "\000",
        48, 29808, -1024657502, 3815376250323988823L, -70146L, false, false, (char) 3212, (char) 43475,
        Double.longBitsToDouble(0x3fe425ae593fcb47L), Double.longBitsToDouble(0x3fc5de0c3e8dc0d4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 5, "\udbcb\ude33", "\ud185\u7594", "",
        34, 45432, 801711202, 70114101380084736L, -100000L, false, false, (char) 46428, (char) 17,
        Double.longBitsToDouble(0x3fec449407a26436L), Double.longBitsToDouble(0x3fbf30bb0ab9a790L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.Long:0 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 9, 2, 5, "\udbcd\udd37\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\ud820\ude08\udbae\udc8a\uda6c\udee6\udb20\udd36\ud9cf\udcff\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\udb64\ude95\udb61\udd6f\udbc2\ude44\udbcb\udfc2", "\u1ee9\u442d\ubab2", "\ud934\udc53\udb6b\udf4a\udab3\udd7b\udb04\uded4\udba1\udd40\ud9aa\udd35",
        57, 99751, -989512132, -4777371276030796692L, -17506L, true, false, (char) 53832, (char) 19995,
        Double.longBitsToDouble(0x3fc74c7c75dbf934L), Double.longBitsToDouble(0x3fd2c42a0ac2fe1cL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\ud964\udf4f", "\u7395\u4366\ubab2", "\ud934\udc53\udb6b\udf4a\uda7c\udc00\ud904\udf26\ud97f\udd70\ud9aa\udd8a",
        44, 99751, 650496232, -4824378155475821460L, 84534L, true, false, (char) 25239, (char) 15003,
        Double.longBitsToDouble(0x3fd2c4242ac2fe1cL), Double.longBitsToDouble(0x3fca266cd67ace78L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 8, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\udaa5\udee9\udb37\udc06\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud902\uddb0\uda4f\udcbd\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\udb18\udd9a", "\u7395\u4366\ubab2", "\ud934\udc53\ud845\udf02\udaa1\udd38\udb04\udf26\udba1\udd40\uda3d\udcb5",
        10, 17416, 649119976, -4824378155475821460L, 84534L, false, true, (char) 31607, (char) 63379,
        Double.longBitsToDouble(0x3fd2c42dcac2fe1cL), Double.longBitsToDouble(0x3fca266cd67ace78L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 9, 9, 7, "\udbcb\ude33\ud89a\udf7e\ud99a\udf05\ud953\udc68\udac7\udc25\uda27\udee2\ud8a3\udca4\udba3\udd96\udaa5\ude2b\udbab\udf32\uda6c\udefa\ubf7f\u4cf6\ud938\udcfb\uda6c\udf1e\uda19\udc39\u6cc1\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u7395\u54e6\ubab2", "\ud934\udc53\udb6b\udf4a\uda7c\udc00",
        9, 19929, 1329442186, 2104481273136853535L, -76031L, false, false, (char) 33006, (char) 13520,
        Double.longBitsToDouble(0x3fe80c251f2aa365L), Double.longBitsToDouble(0x3fd42c8d9f28c69aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 11, 6, 3, "\udbcb\ude33\ud89a\udf7e\ud9f2\udc2b\uda53\udd60\udac7\udc25\uda11\udc25\udb56\uded1\ud913\ude61\udaa5\ude79\ud940\udf8a\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\udb3c\udf4e\udb34\udcb3\udb82\uddb1\uda2c\udd10\udb32\ude92", "\u48dc\u25eb\u8282", "\ud906\udd32\udb64\uddfc\udaeb\uddd7",
        3, 20035, 1329415306, 2104481273136853535L, -38429L, false, false, (char) 38638, (char) 46573,
        Double.longBitsToDouble(0x3fe80eb51f2aa3e7L), Double.longBitsToDouble(0x3fd42c8d9f28c7c6L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 9, 9, "\udbe1\udce1\ud856\udd7c\u8f9f\uda53\udd60\udac7\udc12\uda10\udf77\udb56\uded1\udbeb\udded\ud879\ude36\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\udb23\udca9\uda30\udd50\udaa4\udd42\u68d6\ud997\udd2a\ud873\udd3e\udb94\udc1c\uda1a\udf85\ud85b\udfc3\udb90\ude98\udbc8\udf48\udb36\udd45\ud9f9\udd02\uda67\udf68\ud923\udc35\uda70\udee9\uda7b\udf76\udb04\udf26\udba1\udd40\ud9aa\udd35\uda5a\udc49\udbf3\udcdf\ud8af\udce5\udb72\udd34\uda34\ude1d\ud923\udf8b\udbef\udfcd\udb9a\udd8b\udbca\udfe9\udbe8\udf24\udb08\udcd4\uda49\uded8\udb62\udea6\uda36\uddb3\udadd\ude05\udaca\udeb9\ud808\uded5\udad1\udc34\uda19\udfd6\ud845\udf2c\uda61\udec1\uda37\udd9c\ud8e5\udce1\uda96\udd2d\udb3d\ude5f\ud822\udf95\udbc2\udcec\ud883\udf52\ud9d1\ude1d\udaad\udfb2\ud97d\udfe7\udb4f\udcbd\uda1a\ude67\udb7a\udede\uda08\udc59\ud9a1\udde5\ud873\udcf5\ud860\ude80\ud937\udde4\ud91f\udf14\uda41\udc06\udb23\udf0e\ud939\udc5f\udb57\udc31\udbf0\ude0d\udb29\udf0d\u3649\ud833\udc39\uda55\uddb1\ud970\udc61\uda67\ude7d\udbf3\udece\udbcb\udf18\uda0b\uddaa\ud80b\udc4f\uda90\udc06\ud9dd\udfb6\ud97e\udc37\ud9a6\udc67\ud964\udfd7\udbe0\udf17\udbe8\udf2f\ud897\udca6\ud8d4\udfaf\udaf4\udfa0\ud9c8\udc31\udbb4\udcb2\ud968\ude94\udbb2\udd03\ud864\udc3e\ud90e\udec0\udaf3\uddcd\u1253\ud96b\udeb1", "\u4036", "\udadf\uddbc\udb0d\uddc9\uda10\udffd\udb34\udf80\uda07\udeb1\ud8c9\udc45\uda15\udfa8\udbc6\udfe6\udb5e\udd76\udb92\udf70\udbc2\udf2c\udac9\udf5d",
        5, 39766, 1947641523, -2162768872437454536L, -72199L, false, false, (char) 35362, (char) 12683,
        Double.longBitsToDouble(0x3fe1bdaefebe6ad9L), Double.longBitsToDouble(0x3fd16004f193adb4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 9, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\ude1a\udac7\udc25\ub706\udadb\uded3\u21dd\udaa5\ude2b", "\u7476\u9760\u36da\ub4d0\u9091\u4d42\uaeb4\u373f\u573d\u4538F\u7e88\uc014\u617b\u916f\ub407\u76bb\ucdab\u3efe\uca8e\u9f2d\u3274\u492e\uc603\u2ec3\ud646\u111d\uab55", "\udbca\udfe9\udbe4\udc24\udb08\udcd4\udadb\ude41\udb73\udca8\ud9bc\udc68\udaa6\udc50\ud8a5\udd38\udb42\udc93\ud9c8\udee3\udb5d\udfaa",
        48, 92058, -1472807978, -7919931843823017736L, 83779L, false, false, (char) 38696, (char) 64875,
        Double.longBitsToDouble(0x3fbaabc2043ef848L), Double.longBitsToDouble(0x3fc8565824a3825cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 1, 11, 9, 5, "\udbcb\ude33\udab8\udc6d\u4abc\uda53\udd60\udac7\udc25\ud9f4\udf48\udadb\uded3\udbeb\udded\udaa5\ude2b\udbc2\ude32\uda6c\udefa\u7476\ud91d\uddec\uda56\udd76\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\ud8bf\udc02\udb3a\udf9a", "\u18c5\u9145\u3f26", "\ud934\udc53\udb6b\udf4a\uda7c\udc00",
        9, 20937, 181834122, 2104481271157142047L, 99389L, false, false, (char) 38638, (char) 46573,
        Double.longBitsToDouble(0x3fe80eb51f2aa365L), Double.longBitsToDouble(0x3fd42c8d9f28c7c6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 9, 5, "", "", "\u8d54",
        -5, 3755, -330303721, 3451722524898436194L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fbf30bb00000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:0:00:00.000 |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 9, 0, 5, "\udbcb\ude33\udb92\udccd\u4a93\uda53\udd60\udac7\udc25", "\u6fc1\u241f\u3f32\u0610\u7fba\u97d2\u36da\ub4d0\u9091\u4d42\u7e4d\u373f\u573d\u70af\u4a03\u73a5\u4366\ubab2\u916f\u2e1b\u76ad\ucdab\u3efe\uca8e", "\uda5a\udc49\ud8b5\udfe2\udac2\udf2f\udbb2\uddae\udb8c\uddde\ud916\udd0a\udbef\udfcd\udb9a\udd8b\udbca\udfe9\udbe8\udf24\udb08\udcd4\udadb\ude41\udb73\udca8\ud9bc\udcc9\udaa6\udc50\uda09\udc09\udb73\udd4e\ud966\udc8c\udb91\udcbb",
        -5, 67730, 2007054219, -4058525354763764419L, 46818L, true, false, (char) 25213, (char) 27037,
        Double.longBitsToDouble(0x3febca9cf9a77526L), Double.longBitsToDouble(0x3fe814a7a4ea051dL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 11, 10, 9, "\udbcb\ude33\ud89a\udf7e\u4b3c\ud992\udf4b\udac7\udc82\uda10\udf77\ud9b7\udfe1\udbce\uddfe\u6438\udbab\udedd", "\uccbd\u365d\ub4d0\ud1b5\u6925\u7e4d\u373f\u56dd\u4538\u4291\"\u8f90\ubab2\u916f\ub407\u76bb\ucdab\u3efe\uca8e\ud4a8\u31f6\u492e\u3d60\u5931\u6a25\u111d\uab55\u2138\u593f\u3dcc\u73a5\u28c7\u0990\u0bc3\ua24c\u2a4a\ua8cd\u442d\u846b\u0ff9\ud3e7\u700e\u693d\u768c\uc2bb\u9f88\u0e34\ud374", "\udb8c\udc54\udb4f\udd9f\udaae\ude32\ud8e3\ude9c\uda8e\udc48\udb18\udec1\ud87c\udeac\ud8b2\ude4c\uda0c\ude5b\uda72\udf9c\udb2a\udcbf\udb43\udd7a\udb0c\uddfa\udb30\udc14",
        49, 75190, 1033896512, -4862877259562315683L, -46875L, true, true, (char) 52725, (char) 7531,
        Double.longBitsToDouble(0x3fd71d66b778430aL), Double.longBitsToDouble(0x3fc241c33004cef4L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 6, 7, 9, "\udbcb\ude33\ud89a\udf7e\u4b3c\ud992\udf4b\udac7\udc82\uda10\udf77\ud9b7\udfe1\udbeb\udded\udaa5\ude2b\udb81\udc62", "\uccbd\u365d\uc6e3\u90e8\u4d42\u7e4d\u373f\u573d\u4538\u4291\u7395\u4366\ubab2\u916f\ub407\u76bb\u2061\u511e\uca8e\ud4a8\u31f6\u492e\u3d60\u4695\u5696\u111d\uab55\u2138\u593f\u3dcc\u73a5\u2acf\ua16d\u0bc3\ua24c\u2a4a\ua8cd\u442d\u6ec8\u5600\u7d36\u700e\u693d\u768c\uc2bb\u9f88\u0e34\ud374", "\u1051\udb4f\udd9f\udaae\ude32\ud8e3\ude9c\uda8e\udc48\udb18\udec1\udb79\udf7f\ud92e\udc71\ufb13\udab9\ude86\ud927\udec0\uda3a\udfcd\uda57\udf35\udb1d\uddc3",
        49, 75190, 1033896512, -4862877259562315683L, -46875L, true, true, (char) 58613, (char) 59173,
        Double.longBitsToDouble(0x3fd71d66b778430aL), Double.longBitsToDouble(0x3fc241c33004cef4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=new org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 2, 11, 11, 0, "\udb0a\udc06\ud9cc\udc89", "\ubcb0\u580b\u9140", "\udbb4\udf17",
        8, 99398, 1817253746, -4018749136614815623L, 61021L, false, false, (char) 9801, (char) 24991,
        Double.longBitsToDouble(0x3fd2a8662d8380d2L), Double.longBitsToDouble(0x3fc194e0850cdeecL)));
  }
  @Test
  public void test32() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test32() throws Throwable {
//     assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
//         Z.run(T, 2, 6, 0, 0, "\udb0a\udc06\ud9cc\udd75", "\ubcb0\u8878\u9140", "\udae8\udfd0\udbb7\ude15\ud994\ude26",
//         56, 76052, -693467015, -5327459079105278198L, -20725L, true, false, (char) 21057, (char) 54019,
//         Double.longBitsToDouble(0x3fc82d54b50cdfacL), Double.longBitsToDouble(0x3fd109857570fc74L)));
//   }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.time.StopWatch:0:00:00.000\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 6, 6, 11, "\ud9a5\udd52\udb80\udee6", "\u3d95", "\udbeb\uddf1\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud974\udccb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\udb0d\udd2e\udb61\udd6f\uda4b\udc08\udb3a\udf9a\ud9e5\udd4b\ud878\udee8\udb9f\udd98\ud9b1\udceb",
        29, 24945, 2017973919, -186522783807119502L, 96894L, true, false, (char) 11113, (char) 61225,
        Double.longBitsToDouble(0x3fda1262c8d873f0L), Double.longBitsToDouble(0x3fb11b4753a78248L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.time.StopWatch:0:00:00.000\012",
        Z.run(T, 1, 11, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\uda53\udd60\udac7\udc25\uda10\udf77\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u947f\uc262\uc3ae", "\ud934\udc53\udb6b\udf4a\uda7c\udc00\udb04\udf26",
        39, 52306, 489987729, 7046077463883991272L, 56564L, true, false, (char) 46573, (char) 46379,
        Double.longBitsToDouble(0x3fc7284db50b2364L), Double.longBitsToDouble(0x3feca31f1a511543L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 5, 5, "\udbcb\ude33\ud89a\udf7e\u4b3c\ud8bf\udc04\ud9a1\udfb0\uda11\udc50\udb56\uded1\udbeb\udded\udaa5\ude2b\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\uda4f\uddaa\uda6c\udf1e\uda4c\udfd6\u6896\udb61\udd6f\uda4b\udc08\udb3a\udf9a", "\u7395\u4366\ubab2\u916f\ub407\u76bb\u7aab\u3efe\uca8e\u9f2d\u3274\u492e\uc603\u2ec3", "\uda22\udd9c\udbef\udfdb\udb9a\udd8b",
        33, 62170, 356718484, 2270663385195404588L, 71217L, false, true, (char) 50768, (char) 60054,
        Double.longBitsToDouble(0x3fc3fdd9f4a713e8L), Double.longBitsToDouble(0x3fd81910a37232f2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 9, 9, "\udbe1\udce1\ud856\udd7c\u8f9f\uda53\udd60\udac7\udc12\uda10\udf77\udb56\uded1\udbeb\udded\ud879\ude36\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\udb23\udca9\uda30\udd50\udaa4\udd42\u68d6\ud997\udd2a\ud873\udd3e\udb94\udc1c\ud9e3\udef6\ud85b\udfc3\udb90\ude98\udbc8\udf48\udb36\udd45\ud9f9\udd02\uda67\udf68\ud923\udc35\uda70\udee9\uda7b\udf76\udb04\udf26\udba1\udd40\ud9aa\udd35\uda5a\udc49\udbf3\udcdf\ud8af\udce5\udb72\udd34\uda34\ude1d\ud923\udf8b\udbef\udfcd\udb9a\udd8b\udbca\udfe9\udbe8\udf24\udb08\udcd4\uda49\uded8\udb62\udea6\uda36\uddb3\udadd\ude05\udaca\udeb9\ud808\uded5\udad1\udc34\uda19\udfd6\ud845\udf2c\uda61\udec1\uda37\udd9c\ud8e5\udce1\uda96\udd2d\udb3d\ude5f\ud822\udf95\udbc2\udcec\ud883\udf52\ud9d1\ude1d\udaad\udfb2\ud97d\udfe7\udb4f\udcbd\uda1a\ude67\udb7a\udede\uda08\udc59\ud9a1\udde5\ud873\udcf5\ud860\ude80\ud937\udde4\ud91f\udf14\uda41\udc06\udb23\udf0e\ud939\udc5f\udb57\udc31\udbf0\ude0d\ud85f\udd9f\u3649\ud833\udc39\uda55\uddb1\ud970\udc61\uda67\ude7d\udbf3\udece\udbcb\udf18\uda0b\uddaa\ud80b\udc4f\uda90\udc06\ud9dd\udfb6\ud97e\udc37\ud9a6\udc67\ud964\udfd7\udbe0\udf17\udbe8\udf2f\ud897\udca6\ud8e8\udcf9\udb29\udc7f\ud9c8\udc31\udbb4\udcb2\ud968\ude94\udbb2\udd03\ud864\udc3e\ud90e\udec0\udaf3\uddcd\u1253\ud96b\udeb1", "\u4036", "\udadf\uddbc\udb0d\uddc9\uda10\udffd\udb34\udf80\uda07\udeb1\ud8c9\udc45\uda15\udfa8\udbc6\udfe6\udb5e\udd76\udb92\udf70\udbc2\udf2c\udac9\udf5d\uda6f\udda9\udb7f\udf16\ud95b\udd8a\ud88a\udf66\ud8f9\ude96\ud6c8\ud91c\udf02\uda12\udf66\uda85\udeda\udaaf\udf53",
        22, 74174, -690349802, -4815596184030987721L, -19787L, true, true, (char) 36515, (char) 6870,
        Double.longBitsToDouble(0x3fd85931dd06ffcaL), Double.longBitsToDouble(0x3fe1b1480deebf94L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 9, 9, "\udbe1\udce1\ud856\udd7c\u8f9f\uda53\udd60\udac7\udc12\uda10\udf77\udb56\uded1\udbeb\udded\ud879\ude36\udbab\udf32\uda6c\udefa\ud98a\uddcb\ud84d\uddd4\udb23\udca9\uda30\udd50\udaa4\udd42\u68d6\ud997\udd2a\ud873\udd3e\udb94\udc1c\ud9e3\udef6\ud85b\udfc3\udb90\ude98\udbc8\udf48\udb36\udd45\ud9f9\udd02\uda67\udf68\ud923\udc35\uda70\udee9\uda7b\udf76\udb04\udf26\udba1\udd40\ud9aa\udd35\uda5a\udc49\udbf3\udcdf\ud8af\udce5\udb72\udd34\uda34\ude1d\ud923\udf8b\udbef\udfcd\udb9a\udd8b\udbca\udfe9\udbe8\udf24\udb08\udcd4\uda49\uded8\udb62\udea6\uda36\uddb3\udadd\ude05\udaca\udeb9\ud808\uded5\udad1\udc34\uda19\udfd6\ud845\udf2c\uda61\udec1\uda37\udd9c\ud8e5\udce1\uda96\udd2d\udb3d\ude5f\ud822\udf95\udbc2\udcec\ud883\udf52\ud9d1\ude1d\udaad\udfb2\ud97d\udfe7\udb4f\udcbd\uda1a\ude67\udb7a\udede\uda08\udc59\ud9a1\udde5\ud873\udcf5\ud860\ude80\ud937\udde4\ud91f\udf14\uda41\udc06\udb23\udf0e\ud939\udc5f\udb57\udc31\uda49\ude45\ud85f\udd9f\u3649\ud833\udc39\uda55\uddb1\ud970\udc61\uda67\ude7d\udbf3\udece\udbcb\udf18\udb3e\uddfb\ud9a7\udfdb\u85fb\ud855\udf37\ud97e\udc37\ud9a6\udc67\ud964\udfd7\udbe0\udf17\udbe8\udf2f\ud897\udca6\ud8e8\udcf9\udb29\udc7f\ud9c8\udc31\udbb4\udcb2\ud968\ude94\udbb2\udd03\ud864\udc3e\ud90e\udec0\udaf3\uddcd\u1253\udb17\ude47", "\ua29b\uc212", "\udb3f\udea9\uda10\udffd\udb34\udf80\uda07\udeb1\ud8c9\udc45\uda15\udfa8\udbc6\udfe6\udb5e\udd76\udb92\udf70\udbc2\udf2c\udac9\udf5d\uda6f\udda9\udb7f\udf16\ud95b\udd8a\ud88a\udf66\ud8f9\ude96\ud6c8\ud91c\udf02\uda12\udf66\uda85\udeda\udaaf\udf53\u0083\udab9\udec2\ud8ad\udea9\udb03\udcd8\ud8e4\udca1\ud886\udeb8\uda54\uded8",
        -2, 15840, -1826777872, 9215839854611521155L, -52366L, false, false, (char) 9165, (char) 50110,
        Double.longBitsToDouble(0x3fe5efe3f816c2d0L), Double.longBitsToDouble(0x3fbfaee190d48e20L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.time.StopWatch|stop||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|getSplitTime||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|getTime||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|reset||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|resume||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|split||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|start||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|suspend||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|toSplitString||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|toString||new:org.apache.commons.lang.time.StopWatch:",
    "M|org.apache.commons.lang.time.StopWatch|unsplit||new:org.apache.commons.lang.time.StopWatch:",
    "C|org.apache.commons.lang.time.StopWatch|<init>|",
    "M|org.apache.commons.lang.time.StopWatch|stop||new:org.apache.commons.lang.time.StopWatch:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
