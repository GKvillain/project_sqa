package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        36, 45935, 1441587154, 3464081543584061915L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 3, "\udba4\udef6", "\ud4d2\u475f\u4b96\u72fa\ua0fd\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud9a0\ude1c\ud8f2\udc83\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        36, 45935, 1441587154, 3464081543590067321L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.Date:Wed Mar 07 01:26:13 PST 69132642\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 11, 3, "3", "\u3ef7\u60e8\000\u7285\u0bb7\uc0d8\u7cfa\000", "",
        8, 21893, 16576152, -2181735634228426750L, -100000L, false, false, (char) 6144, (char) 21,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fddb00006f0eca0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Sun Dec 22 23:42:07 PST 287402165\012",
        Z.run(T, 2, 12, 3, 10, "\udbeb\udd1d\udbc8\uddb4\u94f4\uda00\udc96\u88ee\udbe1\udddf\ud93a\uddba\ud87d\udf34\udba2\udf7f\udba8\udff2\ud8ac\udfce\udb14\uddf2\uda1f\udf89\udb23\udf9a\udb7f\udfcf\uda98\udf45\ud8aa\ude1d\ud920\udc98", "\u5a9f\u10ad\u29c2", "\udafc\ude59\ud9ac\udd09\udb27\udef0\udba2\udc8a\ud852\udf30\udab2\udfa2\ud91f\uddef",
        9, 29616, -762170, 9069474189220927686L, 44081L, false, false, (char) 12317, (char) 31907,
        Double.longBitsToDouble(0x3fedf9d53b0cc3f4L), Double.longBitsToDouble(0x3fec3bc7e8b75aaaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 3, "\udba4\udef6\udba9\udfed", "\u8502\u4b96\u72fa\ua0fd\ud234\ud629\u8d56\u50e7\u01f3\u9dc4\u6770\u5c81\u5003\u2bd1\u01c9\ua21b\u63c2\ua7b8\u29c2\ub5a8\u90b7\u3615\ud2d6", "\ud852\udf30\udab2\udee4\ud91f\uddef\udbfc\ude9a\udac4\ude61\ud90d\udd28\uda1a\udfeb\ud9ed\udd26\udb8f\ude0c\ud882\udcb8",
        22, 80063, -527783472, -4093222899377652622L, -37780L, true, true, (char) 22725, (char) 39172,
        Double.longBitsToDouble(0x3fed9f1a389d50e5L), Double.longBitsToDouble(0x3fe32194539510d9L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 11, 0, "\000", "", "",
        14, -1000, -1291845632, -5712833530428607499L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e3f300000000000L), Double.longBitsToDouble(0x3ec71c0000000000L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 3, "\u7af4", "\u0190\uc804\u4b96\u5df1\u6339\ud234\u8ae7\u6438\u5190\u34b2\ud3b4\u9ccc\u0725\ua027\u897f", "\uda0d\udd49\ud99d\udc0d\ud923\udc33\ud907\udd90\ud8e5\uddde",
        25, 4424, -762263110, 5521082223983973507L, -32351L, false, true, (char) 62552, (char) 27709,
        Double.longBitsToDouble(0x3fcd22c9c67efa14L), Double.longBitsToDouble(0x3feef308974bd3bbL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.Date:Sun Mar 01 02:30:55 PST 183722505\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 11, 3, "\ud908\ude68", "\u3ef7\u8502\u4b96", "\udba2\udf7f\ud8d5\udc48",
        0, 35950, 552049984, 5797660109567455325L, -39610L, false, false, (char) 12656, (char) 33553,
        Double.longBitsToDouble(0x3feb712fa8839447L), Double.longBitsToDouble(0x3fe6b9e0afd2d336L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 0, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\000\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        36, -785, 1441529856, 3464081543584061915L, -48358L, false, true, (char) 8481, (char) 29066,
        Double.longBitsToDouble(0x3fedf8000136e143L), Double.longBitsToDouble(0x3fd9f17a9001920eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 3, "\udba4\udef6", "\ubf52", "\udb33\udfb2\ud87d\udf34",
        42, 76069, 483088260, -2150146741626810816L, -39610L, false, false, (char) 48618, (char) 38215,
        Double.longBitsToDouble(0x3fcfbedea20ea06cL), Double.longBitsToDouble(0x3fe6b9e0afd2d336L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 11, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\u0fa0\uc2c0\u79a4", "\ud851\udf51\ud8c6\udc4b\ud8d3\udee3\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        15, 45935, 1441587154, 3464081543584061915L, -48358L, false, true, (char) 8481, (char) 11724,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966c440eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 11, 3, "\uda58\udd88", "\uabb2\u1fd1\u0951\u72fa\ua0fd\ua334\u8ae7\u79a4\u5190\u08b9\u13af", "\ud8b1\udd38\ud90f\ude86\ud80a\udd3a\udb8b\udf85\udb7d\udcec\ud8cd\udea5\uda56\uddc2\udbea\udcf6\udb07\ude83",
        59, 9192, -756102907, 5521082222479834755L, -97887L, false, true, (char) 5448, (char) 14645,
        Double.longBitsToDouble(0x3fdb30e878706ff0L), Double.longBitsToDouble(0x3fe2dc750c89c9bbL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 11, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u0702\u913e\u5fc5\ub891\u4337", "\ud851\udf51\ud8c6\udc51",
        46, 54318, 167168002, -7641720737141232354L, 90333L, true, false, (char) 45832, (char) 14779,
        Double.longBitsToDouble(0x3fddb30126f0eca0L), Double.longBitsToDouble(0x3fdc84e6f611a520L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 0, "", "", "",
        25, 11285, -785325451, -5548422647622668244L, -100000L, false, false, (char) 60159, (char) 43450,
        Double.longBitsToDouble(0x3fbe827da8000000L), Double.longBitsToDouble(0x3ecea20e511c0000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.Date:Thu Sep 14 06:12:00 PST 80579777\0121=java.util.Date:Thu Sep 14 05:26:00 PST 80579777\012",
        Z.run(T, 2, 5, 4, 15, "\ud9c0\udd7d\udb39\udc89", "\u553f\u4b96\u72fa\u017b\u2011", "\ud9a5\uddbc\uda9e\udfc6\ud851\udf58\ud8c6\udc51",
        46, 54318, -502758027, -2542966484236439266L, 90333L, false, false, (char) 22949, (char) 14779,
        Double.longBitsToDouble(0x3fd143012349bc64L), Double.longBitsToDouble(0x3fc29e848c234a50L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jun 20 03:15:50 PDT 270164286\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 13, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u8ae7\u1e3a", "\ud851\udf51\ud9c1\udd28\ud8d3\udfe5\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14\ud99d\udc0d",
        3, 26440, 806543833, 8525483262065750904L, 88666L, false, true, (char) 30375, (char) 5313,
        Double.longBitsToDouble(0x3fe9b64839baa19aL), Double.longBitsToDouble(0x3fc9b01855957b18L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 11, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d\ud920\udc98\ud808\udf4b\udaad\udf3b\udb7d\udd14",
        36, 45935, 1441587154, 3464081543584028379L, -48358L, false, true, (char) 8450, (char) 8074,
        Double.longBitsToDouble(0x3fdbfc6f926dc3d4L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 6, 3, "\udba4\udef6\ud8db\udd1c", "\u71bf\u4b0f\u72fa\u5181\ud234\u8ae7\u9b62\u84fd\u01f3\u17f9\u6770\u5c81\u5003\u2bd1\u01c9\u181e\u63c2\ua7b8\u29c2\u7478\u65b7\ubb49\ud2d6", "\ud852\udf02\uda64\udce9",
        30, 28121, -1282901564, -8109114628623644382L, 56065L, true, true, (char) 53339, (char) 50451,
        Double.longBitsToDouble(0x3fe75e1edac61aceL), Double.longBitsToDouble(0x3fde37b57dd2382eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 3, "\uda04\udd9a", "\u3285", "\udbf9\ude75",
        25, 11661, 98332288, 2074848277280924910L, -94700L, true, false, (char) 6865, (char) 28194,
        Double.longBitsToDouble(0x3fc6364a3de825ecL), Double.longBitsToDouble(0x3fd1e95f3fa84beaL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 11, 3, "\udb77\udeb2", "\u3ef7\u8502\u143c\u72fa\ua0fd\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udbcb\ude86\udba7\udc6d",
        12, 45956, 1441587154, 3464081543584061915L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fdbfc6f937e3c60L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 11, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u8a63\u3fa0\ud234\u8ae7\u79a4", "\ud851\udf51\u2754\ud8d3\udee3\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        56, 45935, 1441587154, 3464081543584061915L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Mon Mar 30 01:08:10 PST 248320975\012",
        Z.run(T, 2, 14, 8, 0, "\udba6\udcf6", "\u3ef7\ud7d0\u7c13\u72fa\u6362\uc5c4\010\u8508\u0a7b\u01f3\u0ba3\u343e\u91bd\u5003\u61bc\ubf6a\ua21b\u63c2\u59cb", "\ud93e\udfcd\udbda\udcd3\uda59\udd01\ud814\uddea\ud9bb\udcda\ud852\udf30\ud80c\udee3\ud989\ude67\uda91\udd13\udb64\uddaa\ud9d2\ude9f\udb14\udd8d",
        34, 14508, -1839602529, -7836476149378309127L, -20416L, true, false, (char) 21735, (char) 62818,
        Double.longBitsToDouble(0x3fddfd2dc1abd398L), Double.longBitsToDouble(0x3fe3caef9d179011L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 13, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ub01a\ud294\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udec7\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        57, 45935, 1148182226, 786105669950413097L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 12, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        36, 45935, 1831460818, 3464081445406046247L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.Date:Fri Dec 19 14:46:16 PST 109769242\0121=java.util.Date:Tue Apr 11 14:46:16 PDT 109769245\012",
        Z.run(T, 2, 8, 6, 9, "\ud808\uddeb", "\u3f63\u8502\u4b96\u5ad3\ua0fd\ud234\u8ae7\u79a4", "\udb00\udfa9\udbbb\udd3f\ud8b5\udcf8\udb55\ude38\udafb\ude83\udbf2\udfaa\udab5\udfda\udb7d\udd14",
        36, 45935, -1192435758, 3463920542439976155L, -48358L, false, false, (char) 8574, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c9366143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.util.Date:Tue Mar 14 18:47:41 PDT 109774350\0121=java.util.Date:Mon Mar 20 18:47:41 PDT 109774344\012",
        Z.run(T, 2, 9, 2, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\u6b2c\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        6, 45935, 1429764050, 3464081543584061915L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c836e143L), Double.longBitsToDouble(0x3fd8c79c766d920eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 3, "\udba4\udef6", "\000", "\udb33\udfb2",
        28, 60484, 14417920, 566935683072L, 96608L, false, false, (char) 65488, (char) 0,
        Double.longBitsToDouble(0x3e4de82400000000L), Double.longBitsToDouble(0x3f9e95f300000000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.Date:Sun Jan 02 23:28:12 PST 109774316\012",
        Z.run(T, 2, 10, 7, 8, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud858\udee5\udba9\ude37\ud916\udd62\ud80a\udc29\ud8f4\udfed\udb7d\udd14",
        36, 22831, -1032050204, 3464080653770856923L, -48358L, false, true, (char) 19251, (char) 8135,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 11, 3, "", "", "",
        11, 11285, -785325451, -5515770763015032788L, -100000L, false, false, (char) 61665, (char) 57784,
        Double.longBitsToDouble(0x3e44780000000000L), Double.longBitsToDouble(0x3feb712fa8839447L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.Date:Tue Feb 16 18:52:44 PST 2016\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 11, 0, "\udba4\udef6", "", "\ud89f\uddf1\udb33\udfb2\u00b7\000\000\ud97c\udcb2\udb44\udf2b",
        9, 33708, -13078435, -508035072L, 73783L, false, true, (char) 14779, (char) 39404,
        Double.longBitsToDouble(0x3febc3b281ba5df7L), Double.longBitsToDouble(0x3fe8469484834c9eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u8ae7\u0084", "",
        8, 88784, 83685016, -2181734646218831870L, 35906L, false, true, (char) 44234, (char) 58091,
        Double.longBitsToDouble(0x3fee9699b3cf55ecL), Double.longBitsToDouble(0x3fddb30126f0eca0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jan 27 23:33:55 PST 22753889\0121=java.util.Date:Sun Jan 27 23:33:55 PST 22753889\012",
        Z.run(T, 2, 6, 6, 8, "\udba5\ude07", "\u3ef7\u8502\u4b96", "\udba2\udfd4\ud99f\udc4d\ud97c\udd36\udb44\udf2b\udba4\udd37\ud851\udf51",
        45, 21976, -507974682, 717981099748435834L, 73721L, false, true, (char) 14779, (char) 51683,
        Double.longBitsToDouble(0x3fed13b281ba5df7L), Double.longBitsToDouble(0x3fe8469484834c9eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.util.Date:Wed Nov 21 11:28:29 PST 88531923\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 1, 11, 15, "\udba4\udef6\ud8db\udd79\ud8dc\udf85\ud93a\udea2\udb98\udde7\udbf3\ude10\udba4\udedc\ud82f\ude39\udba2\udf7f\u3080\ud97c\udd36\udb44\udf2b\udba4\udd37\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d\ud920\udcff\ud80a\udd3a\udab5\udf5a\udb7d\udd14\ud9b6\udc69\ud923\udc33\ud905\udfe2\ud8e5\udea4\udbda\udcd3\uda82\udd01\uda17\udf0c\udbbd\udf8b\ud852\udf30\u92de\ud91f\uddef\udbfc\ude9a\udac4\ude61", "\u34bc\u32fa\u37d1\u309f\ucb4c\u3472\u1c09\u2f84\u1320\u9f75\u895f\u3cb4\ud09c\uccf1\u3ea8\u6d4f", "\uda6b\udccc\udac5\udfd4\ud9f8\ude8c\uda73\udeac",
        3, 71319, -1926463240, 2793692371663709744L, -56327L, false, false, (char) 58882, (char) 14054,
        Double.longBitsToDouble(0x3fcddbc81eaf9e48L), Double.longBitsToDouble(0x3fbbd1954df61bc0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jan 17 08:04:37 PST 245961619\0121=java.util.Date:Wed Jan 17 08:04:37 PST 245961619\012",
        Z.run(T, 2, 8, 8, 3, "\ud9bd\udfc4\udb5b\udd61\ud8dc\udf85\ud93a\udea2", "\u22e6\ua0fd\ud234", "\udb44\udf2b\udba4\udd37\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d",
        11, 52621, -868969698, -7762020528758122365L, -60613L, false, true, (char) 10161, (char) 42392,
        Double.longBitsToDouble(0x3fc06993d905c524L), Double.longBitsToDouble(0x3fee4dd9e163189fL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.Date:Mon Feb 22 16:00:00 PST 2016\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 1, 11, 3, "\000", "", "\ud89f\uddf1\udb33\udfb2\ud87d\udf34\udba2\udf7f\ud99f\udc4d\ud97c\udd36\udb44\udf2b",
        9, 33708, 28765, 0L, -44448L, false, true, (char) 59746, (char) 38090,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fee7aaf61db3012L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.util.Date:Thu Aug 05 09:10:31 PDT 13387824\012",
        Z.run(T, 1, 1, 11, 3, "3", "", "\ud89f\uddf1",
        6, 74543, -1330122708, 422410330397431684L, -21728L, false, false, (char) 231, (char) 60927,
        Double.longBitsToDouble(0x3fef3007e002e1b8L), Double.longBitsToDouble(0x3fbe827da8f4af98L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 11, 3, "\udba4\udef6", "\u6686\u267a\u4b96\u72fa\ubb2b\u291d\u8ae7\u79a4", "\uda26\udc16\uda7a\udee2\udac9\udd45\ud841\udd96\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        36, 45935, 1441587154, 3464081543584061915L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a9833920eL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.util.Date:Tue Jan 17 04:17:48 PST 110037719\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 12, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u4a44\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d\ud812\ude8b\ud831\udf4e\uda8c\ude5a\udb7d\udd14",
        36, 45935, 1689116626, 3472392850762668507L, -48358L, false, true, (char) 8481, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 5, "\udb8b\uddf6", "\u4ae4\u3ad3\u4b96\ud61b\ubfb2\u40af\u6aea\u79a4\u5190", "\ud8c6\udc51\ud8d3\udee3\ud9a0\ude1c\ud8f2\udc83\ud80a\udd3a\udab5\udf5a\udb7d\udd14\ud894\udf80\ud923\udc33",
        59, 58335, 1990999161, 6771077893115818682L, 19852L, true, false, (char) 48824, (char) 11191,
        Double.longBitsToDouble(0x3fe323f781534207L), Double.longBitsToDouble(0x3fefa9659930b6d1L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.util.Date:Wed Mar 07 01:26:13 PST 69132642\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 3, "3", "\u3ef7\u60e8\000\u7285\u0bb7\uc0d8\u7cfa\000", "",
        8, 21893, 152, -2181735634228426750L, -100000L, false, false, (char) 6144, (char) 21,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fddb00006f0eca0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 3, "\ud9d7\udcdd\ud8d2\udf28\ud8dc\udf85\ud93a\udea2\u60e8\000\ud9ea\udda1\udbb6\ude59\ud8b7\udd67\udad3\udcee\000\uba00\u0200\udbd7\udff1\ud823\uddad\udac2\uddcf\ud977\udf1d\udb70\udffd\ud85b\udd9f\ud938\udfde\000\ud9b4\udd36", "\u1102\u6204\u4823\u7e02\u0914\u38fb\u2c47", "\ud948\uddb6\uda31\udc30\udb78\ude8f\ud8f4\udf85\udb47\udda4\ud9cb\udd96\u6ec0\ud93a\udd5c",
        47, 15736, 1095290951, 2228229003960541132L, -95575L, true, true, (char) 50510, (char) 18805,
        Double.longBitsToDouble(0x3fe943a565f820a5L), Double.longBitsToDouble(0x3fe9845442bc7201L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 3, "3\ud8db\udc97\ud8dc\udf85\ud9b5\udea0\uda60\udd52\udbb0\ude39\udb33\udf3d\u0bb7\udb16\udc0a", "\000\000\u725e", "\udbcf\uded6\uc802\000\000\000\ud905\udc4e\000\000\000\ud98c\udfad\ud923\udfdd\udb12\udda0\udad2\udcde\ud9a3\udd78\uda75\udf72\ud94a\uddfa",
        8, 82156, 79502352, 1431790864678575370L, -89608L, true, true, (char) 2852, (char) 26395,
        Double.longBitsToDouble(0x3f7e9169afed4800L), Double.longBitsToDouble(0x3fd972f3d2b8fbd4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 11, 3, "3\ud8db\udc97\ud8dc\udf85\udb94\udeaf\u60e8\uda60\udf3c\udb1f\udc01\udb74\udde9\uda0c\udd5e\ud9f0\udfe9", "\u4993", "\uda70\udca9\ud88b\udf60\uc802\000\udb91\udf9b",
        42, 68400, 0, -6616332362750611374L, -4380L, true, false, (char) 47175, (char) 58503,
        Double.longBitsToDouble(0x3fc4e46288aeb21cL), Double.longBitsToDouble(0x3fe1d058a438eb3dL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 11, "3", "\u10a9\u4e20\u349f\u7285\u0bb7\uc0d8\u7cfa\u215a", "\uda91\udd62\ud99c\udd72\udb99\udea6",
        19, 56076, -1951788032, 0L, -100000L, false, false, (char) 0, (char) 39386,
        Double.longBitsToDouble(0x3febc3ca879166e6L), Double.longBitsToDouble(0x3fe4153752ca0184L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.util.Date:Wed Mar 07 01:26:13 PST 69132642\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 15, 3, "\u878e", "\u3ef7\u60e8\000\u0885\u0bb7\u2bd9\u7cfa\000", "",
        8, 21893, 16576152, -2181735634228426750L, -100000L, false, true, (char) 36798, (char) 10906,
        Double.longBitsToDouble(0x3e38230800000000L), Double.longBitsToDouble(0x3fc431e01aa440c4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 11, 3, "3", "\u3ef7\u60e8\000\u7285\u0bb7\uc0d8\u7cfa\000", "",
        8, 20392, 16576152, -2181735634215884030L, -100000L, false, false, (char) 63740, (char) 25478,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fa72d002f8e09e0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 11, 3, "\000", "\ubee7", "\udafb\udd3d",
        4, 74088, 14463989, 0L, -100000L, true, false, (char) 65488, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.Date:Wed Mar 07 01:26:13 PST 69132642\0121=java.util.Date:Wed Mar 07 01:26:13 PST 69132642\012",
        Z.run(T, 2, 1, 1, 3, "3", "\u402f\ubfd0\000\u7285\u0bb7\uc0d8\u7cfa\000", "",
        8, 21893, 16576152, -2181735634228426750L, -100000L, false, false, (char) 6144, (char) 21,
        Double.longBitsToDouble(0x3e46bf4a64000000L), Double.longBitsToDouble(0x3fddb00006f0eca0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 3, "\ud805\udf20", "\u27f2\u3228e\u71a0\u0bb7\uc0d8\u7cfa\000\000\000\u725e\ucf6f\ub3c3\u401d\uc802\u55f8\000\000\031\u48b5\u2489\000\u3615\uc397\u9492\u8584\u41d8\u9f21\u4220\u60e9\u78e3\u647d\ud4fe\u2056", "\ud8b4\ude10\uda4c\udc4f\uf3f7\ud8ac\ude7d\uda16\udc9d\ud9fd\udd93\ud99d\ude30\ud837\udde4\udab2\udc4a\uda4a\udcfd\udbd3\udd9b\udb70\udeb1\ud8fa\udcba\udadd\ude11\udb7e\udecb\ud925\udf43\uda8d\ude63\uac51\udafc\udf07\ud9cf\udff8\udb6c\ude73\ud911\udc71\ud8dd\udd64\udb78\udd3b\ud830\udf77\uc300\ud946\udd51\ud8f8\udc4c\ud820\udfe1\u1d07\ud9f2\udc26\ud87d\udf04\ud941\udcc6\udb9a\udddb\ud967\uded1\uda66\udde6\ud93d\uded0\ud806\udd07\ud86b\udd22\udaac\ude54\udbe5\uddcf\udba5\uded1\uda46\udf15\udaa1\udd9a\udace\uddaf\ud8cf\udd28\udabf\udecd\ud8eb\ude90\ud95a\udc4a\ue4cd\ud9c5\udd1b\ud884\ude74\ud80e\udd82\ud68f\ud861\udf4c\ud876\udd87\udbeb\udea1\ud970\udd36\u6bcc\udbc3\uddeb\ud8ae\ude73\udabc\udf99\uda38\udd7e\ud931\udf69\ud8ff\ude3b\udb6f\udfec\udb21\udcb7\udbca\ude8b\ud80f\ude0e\ud9fd\udd05\ud929\udef0",
        -1, 58736, -215707577, -3163406518283011938L, -38521L, false, true, (char) 52657, (char) 65324,
        Double.longBitsToDouble(0x3fcd6dc60d19baf8L), Double.longBitsToDouble(0x3fd85154866f847eL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 5, 10, "\udb3d\udf61", "\u3eef", "\udbb5\udf5d",
        25, 62808, -1744792493, 47253553152L, -99887L, false, false, (char) 39386, (char) 10696,
        Double.longBitsToDouble(0x3fb9c66591aac258L), Double.longBitsToDouble(0x3fec8a42437331c5L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 3, "\udbfb\udfb0", "\u3e8a", "\udb3b\ude7a",
        23, 74088, 14463989, 0L, 23692L, true, false, (char) 50198, (char) 60411,
        Double.longBitsToDouble(0x3f670dc000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 0, 3, 10, "\000\udbc8\udccd\000\uda00\udc96\u88ee\udbe1\udddf\ud93a\uddba\ud87d\udf34\udba2\udf7f\udba8\udff2\ud8ac\udfce\u00ee\uda1f\udf89\udb23\udf9a\u0093\000\ud8aa\udd37\ud920\udc98", "\u5a9f\u10ad\u29c2", "\udafc\ude59\ud9ac\udd09\udb11\udd48\udba2\udc8a\ud852\udf30\udab2\udfa2\ud91f\uddef",
        9, 4592, -762368, 9069474188885383366L, 44081L, false, false, (char) 13746, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fec3bc7e8b75aaaL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 12, 0, 10, "\udbeb\udd1d\udbc8\udccd\u94f4\uda00\udc96\ud91c\udcea\udbe1\udddf\ud93a\uddba\ud87d\udf34\udba2\udf7f\udba8\udff2\ud8ac\udfce\ud947\uddf0\uda1f\udf89\u4c92", "\u5003\u2bd1\u7909\ua8ed\u5a9f\u10ad\u29c2", "\udafc\ude59\ud9ac\udd09\udb27\udef0\udba2\udc8a\ud852\udf30\udab2\udfa2\ud91f\uddef",
        9, 29616, -762170, 9069474188885383366L, 18063L, false, false, (char) 12317, (char) 31907,
        Double.longBitsToDouble(0x3fedf9d5380cc3f4L), Double.longBitsToDouble(0x3e16e00000000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 10, "\udbeb\udd1d", "\ucc7a\u0ee0\u1e1a\u291c\ua0fd\ud234\u23cb\u5784\u38be\u8e50\u38b4", "\ud8aa\ude1d\ud920\udc98\u69b9\udbf8\udd0b\ud9cb\udd51\ud9ad\udd01\ud923\udc33\uda19\udce1",
        19, 67039, -1102664471, -3320461720888606720L, 10335L, true, true, (char) 43641, (char) 17811,
        Double.longBitsToDouble(0x3fe6352c16b9fff4L), Double.longBitsToDouble(0x3fc8cfbbabf40058L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 10, "\udbeb\udd1d\u00e7\u94f4\uda00\udc96\u88ee\udbe1\udddf\ud93a\uddba\ud87d\udf34\udb52\udc36\000\000\udb14\uddf2\u0094\u0092\udb78\ude3c\uda98\udf45\ud8aa\ude1d\ud920\udc98", "\u5a9f\000\000", "\udafc\ude59",
        9, 48760, 1277664270, 8163289457734823679L, -85974L, false, true, (char) 1097, (char) 16046,
        Double.longBitsToDouble(0x3f3f7757e8a00000L), Double.longBitsToDouble(0x3fd2ff5914f0d042L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 13, 7, "\udbeb\udd1d\udbc8\uddb4\u94f4\uda00\udc96\u88ee\udbe1\udddf\ud93a\uddba\ud87d\udf34\udba2\udf7f\udba8\udff2\uda30\uded1\udb30\uddb3\uda1f\udf89\udb23\udf9a\udb7f\udfcf\uda98\udf45\ud8aa\ude1d\ud920\udc98", "\u5a9f\u10ad\u5d05", "\uda9f\udd26\udadc\udee6\udb27\udea6\udba2\udc8a",
        39, 56735, -515639361, 3439563972674721240L, 80551L, false, false, (char) 65298, (char) 49856,
        Double.longBitsToDouble(0x3fe3c3410ceab6e5L), Double.longBitsToDouble(0x3fea196b07bf3aa7L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 10, "\udbeb\udc2f", "\ucc7a\u0ee0\u261b\u0d92\u9546\ud234\u23cb\u5784\000\000\000", "\ud8aa\ude1d",
        22, -1000, 1904955995, -7849901980610373257L, -91762L, true, false, (char) 41360, (char) 60872,
        Double.longBitsToDouble(0x3fda8be4681da3d6L), Double.longBitsToDouble(0x3fc06984fbfdc400L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.util.Date:Wed May 22 00:05:54 PST 150069895\0121=java.util.Date:Wed May 22 00:05:54 PST 150069895\012",
        Z.run(T, 2, 3, 3, 10, "\ud94d\udc4c\udbc4\udfdc\u94f4\uda00\udc96\u88ee\udb0e\ude56\ud93a\ude34\ud87d\udf34\udba2\udf7f\udba8\udff2\ud8ac\udfce\udb14\uddf2\uda1f\udf89\udb23\udf9a\udb7f\udfcf", "\u2bd1", "\ud9cb\udd51\ud9ad\udd01\ud923\udc33",
        41, 50279, 1088444039, -4735907842179245656L, 19939L, true, false, (char) 48824, (char) 43641,
        Double.longBitsToDouble(0x3fdd82fbbd8d4b04L), Double.longBitsToDouble(0x3fe5cfffa0c67dddL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 0, "\udbeb\udd1d\udbc8\uddb4\u86f4\uda00\udc96\u88ee\udbe1\udddf\ud93a\uddba\ud87d\udf34\udba2\udf7f\udba8\udff2\ud8ac\udfce\udb14\uddf2\uda1f\udf89\udb23\udf9a\udb7f\udfcf\uda98\udf45\ud8aa\ude1d\ud920\udc98", "\u5a9f", "\uda19\udce1",
        19, 67039, -1102664471, -3320461720888566770L, 10335L, true, true, (char) 43641, (char) 17811,
        Double.longBitsToDouble(0x3fe6352c16b9fff4L), Double.longBitsToDouble(0x3fc8cfbbabf45058L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 1, "\ud870\udf58", "\u0800\ub073\uc1ec\u00b7\u2cbd\u3306\u0131\u0cf1\u0bc4\u1c3e\u5d56\u78c5\u871d\u24c1\u789a\uc48b\ud313\u12fc", "\udadd\uded3\ud817\udf29\ud9b1\udf5b\uda5c\uded1\udba6\udde9\uda54\udc80\ud90e\udd7f\ud892\udc6e\uda32\udf07\udb9d\udc20\ud810\udc4a\uda05\udd75\ud8d0\uddd2",
        -1, 80856, -1602872598, 6620969030180791746L, -74202L, true, true, (char) 20893, (char) 9927,
        Double.longBitsToDouble(0x3fe512ff33a79e49L), Double.longBitsToDouble(0x3fe6f1470a6817ffL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.util.Date:Sat Mar 20 13:44:00 PST 77683458\0121=java.util.Date:Sat Mar 20 13:44:00 PST 77683458\012",
        Z.run(T, 2, 9, 9, 15, "\ud96b\udcbc\ud9c0\udcab\uda62\udd3f\ud90b\udf19\ud8a6\udf1a\ue9bd\000\ud967\uddc0\udba2\udf7f\u1c02\udb8c\udcbc\ud887\ude57\ud877\udfcc\uda75\uddee", "\uc81c\000", "\ud8fb\ude0d\udb3e\udfe2\ud949\udec1\udbd8\ude38",
        59, 69416, 1379985403, -2451567485009759523L, 34420L, false, false, (char) 36562, (char) 52907,
        Double.longBitsToDouble(0x3fb0dbaead5da0c8L), Double.longBitsToDouble(0x3fe2e5a4f821e34dL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 14, 0, "\udb18\udc8a", "\u140e\000\u088d", "\udba2\udf7f",
        59, 21404, 0, 0L, -99828L, false, true, (char) 184, (char) 9984,
        Double.longBitsToDouble(0x3fc4050a3e9af204L), Double.longBitsToDouble(0x3fedf1b3c069069dL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 1, "\ud9d6\udd28\ud910\udc8d\uda56\udc23\000\u00ba\udad4\udea6\udaf8\udc25\ud842\udc8d\udba2\udf7f\ud941\udc3e\udbf2\udc19\u009f\ud9eb\udc4e\ud8a5\udee4", "\uccf3\u1b7b\u6a42\u9179\ubbb7\u2af3\ud568\u9242\u29e5\u068e\u89d7\uc537\u43d5\u5777\uc2a9\u3444\u5fa2\ub14b", "\udad3\udea7\ud90b\udf39\ud87e\udea2\ud835\udf01\udbe6\udc45\uda40\udfe4",
        11, 85321, 1827685673, -2933992811575858642L, 22021L, true, false, (char) 25228, (char) 8338,
        Double.longBitsToDouble(0x3fec6ec6e2bcc7d9L), Double.longBitsToDouble(0x3fe919c30b572657L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.util.Date:Fri Apr 02 19:53:13 PDT 183722506\0121=java.util.Date:Fri Apr 02 19:53:13 PDT 183722506\012",
        Z.run(T, 2, 4, 4, 3, "\ud908\ude68", "\u3ef7\u8502\ua664", "\udb79\udf16\ud8d5\udc48",
        0, 35950, 552049984, 5797660143927193693L, -39610L, false, false, (char) 53984, (char) 10607,
        Double.longBitsToDouble(0x3feb712fa8839447L), Double.longBitsToDouble(0x3fe6b9e0ab4db7e1L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.util.Date:Mon Sep 06 12:32:46 PST 219291151\0121=java.util.Date:Mon Sep 06 12:32:46 PST 219291151\012",
        Z.run(T, 2, 5, 5, 0, "\udba4\udef6", "\ua72f\u28dd\u5b25\u7f76\u13a8\u99ff\u19bd\ud6ef", "\udbfd\udfe7\ud9ce\ude94\udaf7\udf76",
        -5, 12002, -1779226758, -6920364541087333463L, 36835L, false, true, (char) 30009, (char) 47507,
        Double.longBitsToDouble(0x3fe6dc0851bab3f8L), Double.longBitsToDouble(0x3fe8469484834c9eL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.util.Date:Thu Mar 05 05:26:59 PST 258416056\0121=java.util.Date:Thu Mar 05 05:26:59 PST 258416056\012",
        Z.run(T, 2, 2, 2, 10, "\udba4\udef6", "\u51b5\u7ee8\u57c0\u107c\ua063\u84e2\u8ae7\u7958", "\ud851\udf51\ud8c6\udc51\u5a03\udba8\udd65\udbeb\ude8a\uda12\udc63\udb64\udf79\ud8c2\udc4e",
        49, 42984, -1549306275, -8155052663337180366L, -48358L, false, true, (char) 8450, (char) 34192,
        Double.longBitsToDouble(0x3fda5ae02de59f94L), Double.longBitsToDouble(0x3fdd0025866d920eL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.util.Date:Fri Feb 02 00:19:12 PST 171927844\0121=java.util.Date:Fri Feb 02 00:19:12 PST 171927844\012",
        Z.run(T, 2, 7, 7, 3, "\udb77\udeb2\ud8ae\udd95\ud831\udd06\udbc6\udf70", "\u72fa\ua0fd\ud234", "\udb44\udf2b\udba4\udd37\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d",
        14, 52019, -1876146336, 5425456556132338300L, -60613L, true, true, (char) 10161, (char) 42392,
        Double.longBitsToDouble(0x3fc06993d905c524L), Double.longBitsToDouble(0x3fdbfc6f937e3c60L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 12, "\udba6\udcf6", "\u3ef7\u3e95\u8ee1\u737d\u04d8\uc552\010\u8508\u0a7b\u01f3\u0ba3\u417d\u3af9\u4fa2\u61bc\ubf72\ua21b\u63c2\u59cb", "\ud93e\udfcd",
        25, 63440, 53463482, 5490161025980945539L, -32226L, true, false, (char) 12275, (char) 34709,
        Double.longBitsToDouble(0x3fdf4f6c0c767a32L), Double.longBitsToDouble(0x3feae462bc9f2cbfL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 11, 11, 3, "\000", "", "\ud89f\uddf1\udb33\udfb2\ud947\udf39\udba2\udf7f\ud99f\udc4d\ud97c\udd36\udb44\udf2b",
        9, 33708, 28765, 0L, -44448L, false, true, (char) 59746, (char) 38090,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fee7aaf61392407L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 11, 5, "\udb8b\uddf6", "\u4ae4\u3ad3\u4b96\ud61b\ubfb2\u40af\u6aea\u79a4\u5190", "\ud8c6\udc51\ud841\udeda\ud9a0\ude1c\ud8f2\udc83\ud80a\udd3a\udab5\udf5a\udb7d\udd14\ud894\udf80\ud923\udc33",
        59, 58335, 1990999161, 6771077891945752705L, 19852L, true, false, (char) 48824, (char) 11191,
        Double.longBitsToDouble(0x3fe323f781534207L), Double.longBitsToDouble(0x3fefa9659930b6d1L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 8, "3\ud8db\udc97\ud8dc\udf85\ud93a\udea2\u60e8\000\ud8b9\udf96\u0bb7\udb16\udc0a\u1c02\000\000\000\ud9df\udcef\ud8aa\udc51\u0098\ud8aa\udd37\uc802\000\000\000\ud8ca\udc01\000\000\000\udbda\udcd3\udabb\udc1e\ud819\uddbc\udb9e\ude29\ud938\udfef\ud91d\udcd5\uda09\uded9\udbca\udfaf\ud863\udfd1\ud881\udf1e\uda78\ude0b\ud8fd\udea3\udab5\udcfc\ud8e5\udd01\ud905\udd15\ue505\uda15\ude4b\udac4\ude83\ud8f3\ude1c\udb7a\udcda\ud9f9\udd6e\udb1b\udcad", "\u5346\u9eda\u5046\ua3d3\uae39\u7e01\u4993\ua55b\u0b3f\uc5e3\u4c08\u2b3a\uc717\u225e\u7b33\u4d61\u30eb\ua376\u5434", "\ud9d9\udccb\uda2d\udca9\ubea1\ud8da\ude3a\ud88b\ude76\uda18\udde3\ud9dc\udf30\ud92a\udd98\u28f1\ud805\ude49\udab9\udf51\udbe1\udf7d\ud976\ude54\ud85f\udecb\ud802\udd6a\ud8a3\ude86\ud867\udf43\udb88\udc2d\ud808\udcea\uda40\udc35\ud90b\ude75\ud9c1\udc03\ud8b2\ude42\uda1f\ude23\udaed\udd62\ud8a1\udc28\udbbc\udc04\ud93e\uddc9\udbd2\udde4\uda9d\uddfa\ud837\udc21\uda2b\ude56\ud99f\ude7b\udacd\udf2b\ud8b6\udd6b\ud8c1\ude5e\uda36\udfcd\ud907\udd29\ud8fc\ude79\ud81d\udf4a\ud959\udfff\ud890\uddef\ud94f\udcd0\uda4b\ude3e\udb60\udcbd\ud893\udcca\uda53\udde1\ud90c\udc75\ud943\udd45\ud924\uddd8\uda6f\udcf7\udaeb\ude0b\ud8f6\udfad\udaa6\udfeb\ud8c9\ude4c\udaf6\udeb6\uda1f\udfe5\u3159\udb55\udd24\uda6c\udf20\ud8ab\udf1a\ud8a3\udd6f\udb36\udd1e\ud978\ude3e\udba9\ude33\ud99f\ude6b",
        0, 5658, 1906418801, -6822925580801085955L, 10241L, true, false, (char) 7361, (char) 7325,
        Double.longBitsToDouble(0x3fe4fc61e8818bfeL), Double.longBitsToDouble(0x3feb53c91ebf5e64L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 3, "3\ud8db\udc97\ud8dc\udf85\ud9b5\udea0\uda60\udd52\udbb0\ude39\udb33\udf3d\u0bb7\udb16\udc0a\u1c02", "", "\ud8aa\udc51",
        19, 86798, 51202, -2068278887L, -39413L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fddb00007843dd4L), Double.longBitsToDouble(0x3fece5ef7ee72241L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 14, 15, 3, "\ud800\udc9c", "\ubee7", "\udafb\udd3d",
        42, 74088, 14463989, 0L, -100000L, true, false, (char) 60015, (char) 8314,
        Double.longBitsToDouble(0x3f003eaf2e784000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 3, "\udba4\udef6", "\u3ef7\u8502\u4b96\u72fa\ua0fd\ud234\u8ae7\u79a4", "\ud851\udf51\ud8c6\udc51\ud8d3\udee3\ud8aa\ude1d\ud920\udc98\ud80a\udd3a\udab5\udf5a\udb7d\udd14",
        36, 45935, 1441587154, 8220164223290067437L, -48358L, false, true, (char) 8434, (char) 8074,
        Double.longBitsToDouble(0x3fedfe37c936e143L), Double.longBitsToDouble(0x3fd9f17a966d920eL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 11, 3, "\udba4\udef6", "\u0db2\u0b3b\u4b96\u72fa\ubb2b\u291d\u8ae7\u79a4\u5190\u18f1\uc111\uaf1b\uae49\u4367\u2bd1", "\udb7d\udd14\ud99d\udc0d\ud923\udc33\ud91b\udce2\ud8e5\udea4\udbda\udcd3\uda82\udd01",
        10, 49128, 1900663939, -4109061591318440799L, 48919L, true, true, (char) 632, (char) 48104,
        Double.longBitsToDouble(0x3fec25efa96e04a3L), Double.longBitsToDouble(0x3fce9c64ea5283b0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.time.DateUtils|modify|java.util.Calendar,int,boolean|static",
    "M|org.apache.commons.lang.time.DateUtils|add|java.util.Date,int,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addDays|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addHours|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMilliseconds|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMinutes|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMonths|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addSeconds|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addWeeks|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addYears|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameDay|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameDay|java.util.Date,java.util.Date|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameInstant|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameInstant|java.util.Date,java.util.Date|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameLocalTime|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|iterator|java.lang.Object,int|static",
    "M|org.apache.commons.lang.time.DateUtils|modify|java.util.Calendar,int,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
