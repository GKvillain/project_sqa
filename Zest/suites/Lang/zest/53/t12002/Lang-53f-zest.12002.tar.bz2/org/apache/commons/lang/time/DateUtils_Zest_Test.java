package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class DateUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903394298803350L, 41950L, false, true, (char) 28777, (char) 51333,
        Double.longBitsToDouble(0x3fecd4a242b7acf4L), Double.longBitsToDouble(0x3f9cb12a68b5d2e0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1",
        47, 90312, 546378117, 5636356888537130663L, -99548L, false, true, (char) 57943, (char) 14515,
        Double.longBitsToDouble(0x3fe4a29f027e61d0L), Double.longBitsToDouble(0x3fd62dc42bace526L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\ud8f1\udff3\udaea\udc22\uda5b\udc52\ud928\udff2\ud940\udecb\ud9f5\udf96\ud92e\udca7\ud9cb\udca6\uda95\udc4e\ud93b\udd47\udabb\uddcd\ud9b1\udf7b\ud9de\udf1e\udb53\udda3\udb0a\udddf\ud9ff\ude7e\ud99b\ude4a\ud8a6\ude80", "\ub247\uca2d\u4663\u1a8b", "\udb7c\udf82\ud91c\udf70\ud812\udd56\uda66\uddfc\ud86b\udd03\ud8c7\ude27",
        55, 63229, 1407236081, 8696027104019622526L, 30518L, true, true, (char) 62434, (char) 34731,
        Double.longBitsToDouble(0x3f9cb12a68b5d2e0L), Double.longBitsToDouble(0x3fc910bd93565638L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.Date:Wed May 12 00:33:16 PST 139961254\012",
        Z.run(T, 1, 2, 15, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903394298803350L, 41938L, false, true, (char) 28777, (char) 51333,
        Double.longBitsToDouble(0x3fecd4a242b7acf4L), Double.longBitsToDouble(0x3f9cb12a68b5d2e0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.Date:Tue May 06 14:47:06 PDT 66072679\012",
        Z.run(T, 1, 2, 5, 13, "\udb78\udfed\ud92a\udf1a", "\uaf08\uc1cb\u7579\uaaba\u93d3\ub23a\u5d66n\uaede", "\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud842\udfa3\ud847\udd7a\ud9d2\ude0e\ufa32\ud9c4\udc52",
        18, 8297, 801617079, 2084990201848026959L, 92123L, false, false, (char) 13535, (char) 42180,
        Double.longBitsToDouble(0x3fe9c0ad536a30faL), Double.longBitsToDouble(0x3fda37b61fe3fb84L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 7, 13, "\uda49\udd46", "\u32fd\uaf08\u3b7d\u7ff9\ub869\u25c8\ub23d\u5d66\u4ee9", "\ube68",
        9, 63859, 1112547524, 500759282712010896L, -46392L, true, false, (char) 52537, (char) 36979,
        Double.longBitsToDouble(0x3fea30ffbaeddd7cL), Double.longBitsToDouble(0x3fe093775a2423b6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.Date:Thu Jun 27 10:28:17 PDT 280800644\012",
        Z.run(T, 1, 4, 10, 12, "\ud868\udf83\ud9e3\uddb1\udbe7\udf2c\ud8e1\udc44\udb1c\udf82\ud98a\udebd\ud9ff\udef3\ud9ba\udfdb", "\u70e8\ud7ed", "\ua4bd",
        -3, 53815, 188828138, 8861150292485297395L, -57710L, false, false, (char) 35841, (char) 3334,
        Double.longBitsToDouble(0x3fcdeddd6959d924L), Double.longBitsToDouble(0x3fd3733851725898L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda93\udcf0\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360\u728b\u4663\u1a8b\u424a\u64f2\u50f2\u201e\u016f\u81b6\u8cc6\ua11d\u0717\ub814\u835a\u2282\u7821\ud52d\u6f24\u59c2\ucd2c\u2548\u8f9f\u2a95\u5802\uadc9\u2f39\u99bc\ua710\u9a71\u32d1\ud5a3\u0664\u6edb\u5605\u52bd\u2e30\uaa55", "\uda16\udcd1\ud870\udd81\udb36\udcfc\ud8e6\udff7\udabe\udf62\uda93\udf8b\ud84c\udca1\ud92b\udcd0\udb3b\ude1d\ud88c\uddee\ud916\udeb8\ud8ea\udd42\ud86a\uddce\ud848\udddb\udbbf\udead\ud9ad\udc04\ud920\ude12\u949a\ud9de\udfb5\udb44\udcba\uda35\udf6b\udbeb\udf22\udbd6\udf68\uda4a\udc3e\ud91e\udf4d\ud90c\uddad\udb1d\udd6c\ud867\udc73",
        39, 34555, 1561463382, 5494175770775158802L, -63768L, false, false, (char) 55391, (char) 25062,
        Double.longBitsToDouble(0x3fe04081b7f4f43fL), Double.longBitsToDouble(0x3fd2702b4494a0a4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\ud98b\udf8b\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\uc268\udb3d\udc93\uda47\udf14\udb4e\uded0\ud8ca\udc7d\ud9ff\udea7\udbfc\udf8a\udadd\udc5f", "\u6eef\u728b", "\ud9d7\udcc1\ud8a1\udd2f\udb7d\udc1c\ud91c\udf70\ud812\udd56\uda66\uddfc\ud86b\udd03\ud8c7\ude27\ud9bb\udf9e\ud886\ude9b\ud993\udce2\udaa9\udc57\udb14\udc62\uda29\udc22\ud900\udd15\ud86f\udf52\ud84e\udeb5\udaab\ude11\ud942\ude08\uda93\udcaf\udb23\uddf5\udba2\udd2b\uda22\udd2c\udb23\udcbb\udbf7\udc43\ud8dd\udcdd\uda7d\udd28\uda7e\uddb7\uda80\ude77\ud874\uddb7\ua848\ud881\uddf5\udba3\udc3a\uda92\udc00\ud91b\uddca\ue2fe\uda37\udcb5\ud8ad\uddb3",
        38, 68575, 1202949510, 6647762274705674521L, 4099L, true, false, (char) 23858, (char) 9514,
        Double.longBitsToDouble(0x3fde61e73a8e63fcL), Double.longBitsToDouble(0x3fe69b906c93ffb5L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 5, 10, "\udbe6\udca8", "\u847f\u3508", "\ud955\udcf2\ud940\udecb\ud82b\udfe6\ud930\udc2e\ud9cb\udca6\udaaf\udedb",
        39, 55900, 1290248562, 3239779096201513423L, 18792L, false, false, (char) 1332, (char) 17447,
        Double.longBitsToDouble(0x3fe31492611992f8L), Double.longBitsToDouble(0x3feba0fba2eddd7cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 5, 6, "\ud945\udc48\ud92a\udef9\udbe7\udf2c\uda7a\udef1\ud9d4\udfe4\ud92a\ude2c\uda5f\udf04\ud928\udff2\ud9e2\udf5e\ua7f1\udae3\udc14\ud9cb\udc62\uda95\udc4e\ud93b\udd47\ube68\udb54\udf54\ud97c\udc04\uda80\ude1a\udaf4\udceb\ud9ff\udea7\ud891\udef7\uda46\udf8a\udbf1\udcbe\ud97f\udebd\ud8fe\udda5\ud8f0\uddb0\uda80\udf82\uda2a\udd73\ud9cb\udec3\ud955\udf0a\ud894\udc89\ud91c\udf70\ud8d9\udc14\uda59\udc13\ud86b\udd03\uda63\ude94\ud9b7\udd50\ud886\ude9b\uda71\udc4b\udaa9\udc57\udb14\udc62\udaee\udc9c\ud8bb\udeac\udab0\udfb0", "\u49fe\u811a\u0e2b", "\ud87f\udd79\uda02\udfd3\uaca4\uda47\udee0\ud91d\udebc\udbe3\udce2\uda65\udeda\ud96e\udee3\uda04\udfba\ud83c\udf86\udb39\udc26\udbb3\udfbd\ud85c\ude0c\udb9b\udda5\uda29\udcfb\ud834\udc2e\udb1e\uddd9\udabe\uddd0\ud98b\udd65\ud82a\uded1\ud98e\udc9a\udac0\udd68\ud9b5\udd7d\udb94\udc2d\ud8fc\udd2d\ud895\udc8f\udbd2\uddba\uda09\udfd7\ud9a2\udebc\ud9c3\ude48\ud837\udd4c\ud8c8\ude28\udbf5\ude0a\ud969\uddde\udb02\udf5d\ud8f7\udf12\ud92c\udc0b\ud9d5\udfc6\ud9d6\udf81\ud936\udda9\udaef\udc21\udbd3\uddf6",
        39, 64035, 1656435079, 5256871532455394958L, 66373L, true, false, (char) 63317, (char) 30157,
        Double.longBitsToDouble(0x3fab1087070f6a60L), Double.longBitsToDouble(0x3fb6808e16fccad8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc52\ud928\udff2\ud940\udecb\u7aa9\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud86f\uddf7\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1\uda08\ude83\ud9f3\uddb5\ud99b\udcac",
        7, 83471, 234818608, -4416903394298803350L, 41950L, false, true, (char) 28777, (char) 51333,
        Double.longBitsToDouble(0x3fecd4a245b7acf4L), Double.longBitsToDouble(0x3fd373fa968b3b1eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.util.Date:Sat Apr 24 12:21:01 PST 139961254\012",
        Z.run(T, 1, 7, 13, 5, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\udb1a\udf65\udb03\udd3b\udace\ude12\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\udb24\udeae\udae6\udf9a\ube93\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903395206745944L, -26146L, false, true, (char) 28777, (char) 51333,
        Double.longBitsToDouble(0x3fe494a242094a2aL), Double.longBitsToDouble(0x3f9cb12a68b5d2e0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jan 07 03:33:07 PST 179962318\012",
        Z.run(T, 1, 5, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\ud8f2\udd9d\udae8\ude93\udace\ude12\uda2f\udcae\ud960\udeff\ud9cc\uddb0\uda11\udeed\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udb2d\udc5d", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud80f\uddc6\ub94d\udb19\ude4f",
        50, 72680, 1375668508, -5679240981772612843L, -82339L, false, false, (char) 35918, (char) 29099,
        Double.longBitsToDouble(0x3fdd672932da6e32L), Double.longBitsToDouble(0x3fecd37a42b7acf4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 5, 13, "\uda28\udeeb", "\u32a6", "\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e",
        -5, 21880, -1482579511, 4181183656783641850L, 7826L, true, false, (char) 8936, (char) 12394,
        Double.longBitsToDouble(0x3f926eebc49f6ac0L), Double.longBitsToDouble(0x3fef2f4000402cc3L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 5, 3, "\ud8b4\udcb8\ud9ba\udc2b\ud85c\udfc1\uda7a\udeba\uda62\udf8b\udbc8\udd8b\udb48\udc89\ud85e\udfb5\ud904\udca6\ua7f1\ud930\udc2e\udae8\udef4\ud8a8\udf82\ud8b1\udece\udb26\udc6f\u9212\ud8f9\udf53\udb45\udd9a\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udb41\udd3d", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud912\ude88\ud97d\udc0e\ud95d\udf90",
        58, 16620, -1607001705, 219709270755153215L, 20194L, false, true, (char) 28777, (char) 60037,
        Double.longBitsToDouble(0x3fe860ab42c7a75fL), Double.longBitsToDouble(0x3fef33b8b345ae97L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.util.Date:Thu Feb 15 11:07:36 PST 25704712\012",
        Z.run(T, 1, 8, 4, 13, "\uda4d\udfdb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\ud98a\udf3f\ud946\udc2c\udbba\ude72\ud928\udff2\udb3d\uddaa\udb8f\uddce\udafc\ude19\u7ed2\ud963\udebe\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfe0\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03\udbf1\udc7e\ud97f\udebd\uda1b\udff3\ud8f0\udd77\ud96a\udd76\uda81\udfcb\ud9d7\udcc1\uda86\ude82\udb7c\udf82\udb0f\udfaa\uda74\udf88\ud81b\udf1a\ud86b\udd03\ud8c7\ude27\uda42\udc60\uda78\uded0\ud993\udce2\udac1\udc9c\udb14\udc62\uda29\udc22\ud977\udef2\udbb0\udf13", "\u8f9f\u7849\u09bc", "\uda3c\udcf8\ud96d\ude46\udbcd\udeac",
        51, 51930, -159999501, 811100168593656865L, 6290L, true, true, (char) 56219, (char) 12192,
        Double.longBitsToDouble(0x3fd82f662fb4f91aL), Double.longBitsToDouble(0x3fe8f95549a5bb9bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\ud9ef\udd0a\udad9\udfe3\udace\ude12\uda5b\udc52\udbf6\ude4e", "\u5d66\ub672\u6a47\u6cbc\u7078\ub10c\u9927\ua251\u8afd\u2f3e\u1cc9\ud368\u0996\uc25d", "\ud96a\udd76\udb00\udef0\ud9fa\udda7\ud912\ude88\udb7c\udf82\ud91c\udf70\ud812\udd56\uda66\uddfc\ud86b\udd03\ud8c7\ude27\ud962\ude58\udb00\udf50\udb2f\udf61\uda93\udff4\uda5d\udfd6\uda14\udc22\ud900\udd15\ud9c6\udd70\ud9e7\udcb1",
        12, 16972, 79475525, 483084762985060899L, 18766L, true, true, (char) 36929, (char) 40619,
        Double.longBitsToDouble(0x3fd2df5f572d4c7eL), Double.longBitsToDouble(0x3fd5adcef9207842L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.Date:Fri Aug 06 00:23:17 PST 123915423\012",
        Z.run(T, 1, 6, 12, 13, "\uda80\udf04\ud84e\udf27\ud8e8\udcb9\uda7a\udef1\uda19\ude47\ud864\udffc\uda5b\udc52\ud953\uddf2\uda47\uddae\ud9f4\udf83", "\u112b\ucd92\u7078\u2be8\u0f9a\u9560\u8afd\u2f0f", "\udbf1\udc7e\uda99\udd85\uda1b\udfdb\ud8f0\udd6b\ud969\ude76\uda81\udfcb\ud9d7\udcc1\ud912\ude88\ud9ca\udf68\ud91c\udf70\ud9d2\udf17\uda40\udf3b\uda35\udfa1\ud8c7\ude27",
        55, 62213, 1399693944, -3910535614424202022L, 39453L, true, true, (char) 62434, (char) 34731,
        Double.longBitsToDouble(0x3f9cb12a68b5d2e0L), Double.longBitsToDouble(0x3fec039800a6832cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 9, 13, "\uda4d\udc8b\udbce\udd83\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc4b\udad4\udef0\ud931\udf25\ud8a5\udd1d\ud930\udc2e\ud9cb\udca6\ud8c5\udf53\udb16\uddd4\u5c4a\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud846\udd4f\ud891\udef7\udaf9\udd03", "\u7c1c\u72d8\u4663\u1a8b\u424a\u64f2\u0f77\u080a", "\uda67\udfe2\ud8c7\ude56\ud9bb\udf9e\ud886\ude9b\ud993\udce2\udaa9\udc57\udb14\udc62\uda29\udc22\ud8e9\udca9\u863b\ud8ae\udce9\ud87e\udcbf",
        57, 726, 532512547, -8834043728504525003L, -48300L, true, false, (char) 38907, (char) 44163,
        Double.longBitsToDouble(0x3feefabb399dc757L), Double.longBitsToDouble(0x3fce91ba56fc3ff0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.Date:Thu Jan 27 16:12:21 PST 74910276\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 14, 9, "\uda28\udeeb\ud92a\udf1a\udbca\udf3d\uda7a\udf47\udb03\udd3b\udace\ude12\u1b4b\udae4\udeb1\ud940\ude7a\ua7f1\ud803\ude9a\uda77\udd9b\uda95\udc15\uda53\udc2d\ud8b2\udc8c\udb3d\udc93\ud97b\udfcd\ud983\udddc\udb29\udc3d\ud846\uddc1\ud9ca\udfed\udaf9\udd03", "\ud360", "\uda81\udfcb\udb3c\udd6d\ud912\ude88\ud841\udf8f\uda94\udd6a",
        47, 83663, 234868465, -2364050659502858090L, 66774L, false, false, (char) 35918, (char) 29092,
        Double.longBitsToDouble(0x3fdd672892da6e32L), Double.longBitsToDouble(0x3fecd4a2404ea3f4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\uda28\udeeb\ud8bf\ude45\000\udaf4\udeb1w\ud8fb\udfe8\ud97b\udc5c\u17c2\ud940\udecb\u1b84\udb67\udea9\udbbe\udfdf\uda95\udc4e\ud93b\udd47\u627c\udb14\udeca\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud833\udd01\ud891\udef7\udaf9\udd03", "\ud360", "\uda81\udfcb",
        40, 51237, -1349066688, 2346676145077378234L, 99728L, false, true, (char) 3615, (char) 9047,
        Double.longBitsToDouble(0x3fef8fee169453e0L), Double.longBitsToDouble(0x3fe3f30e8562dc42L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903394298803350L, 41950L, false, true, (char) 28777, (char) 51333,
        Double.longBitsToDouble(0x3fecd4a242b7acf4L), Double.longBitsToDouble(0x3f9cb12a68b5d2e0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 5, 0, "", "\u874c", "\udaac\ude36\u17e9\000\000",
        48, 39195, -1164908354, 901943132160L, -100000L, false, false, (char) 14848, (char) 0,
        Double.longBitsToDouble(0x3fce6f40011073bcL), Double.longBitsToDouble(0x3fe9edb802236204L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 13, "\uda0c\udfc5", "\u32a6\uaf08\u3b7d\u20a7\u1c00\u4c43\ub23d\u5d66\ub672", "\ube68",
        24, 68682, 188873978, 70123819842404352L, 7826L, true, false, (char) 8936, (char) 12394,
        Double.longBitsToDouble(0x3f926eebc49f6ac0L), Double.longBitsToDouble(0x3fef2f4400402cc3L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 14, 13, "\ud955\udc88", "\u6e3d\u2af4\u5f90\u58dc\ua8f9\u4c43\ub23d\ua55b\ub672", "\ud8fe\udc58",
        4, 50574, -1232759100, 8861150292485297395L, 29969L, false, false, (char) 40312, (char) 29272,
        Double.longBitsToDouble(0x3fca0856dfe76270L), Double.longBitsToDouble(0x3fe9305c3cff16d1L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 5, 13, "\uda28\udf61\ud92a\udf1a\udbe7\udf2c\uda9f\udc8d\udb03\udd3b\uda45\udd0c\uda5b\udc52\ud928\udff2\ud940\udecb", "\ub672\u48a7\u760a\u427c\ub10c\u9927\u7027\u0ea3\u70b9\u81ae\uad42\uc946\u03c0\ud360\u728b\u7bd7\u1a8b\u424a\u64f2\u63f2\u5b1e\u016f\u81b6\u8cc6\ua11d\u0717\u643b\u1d6f\uc4c0\u7857\u8365\u50ef\u5a00\ucd2c\u2548\u8bac", "\ud8a1\udd99\uda72\udcc2\ud907\ude56\udac1\udf95\uda50\udf81\udbda\udec3\ud93f\udd4b\uda3f\udc09\ud80d\udd9d\ud983\ude8b\uda41\udc2b\ud9cb\udd9c\uda9b\udd77\udb42\udc75\ud8a9\ude83\udb2f\udf88\ud8d8\uddbd\ud911\ude18\ub542\udbb2\udf89\uda9e\udecf\ud9aa\ude60\ud8e3\udec9\udbb9\udf60",
        32, 25699, 280679580, 8809136774824463830L, 99468L, true, true, (char) 45728, (char) 4846,
        Double.longBitsToDouble(0x3fee925864ccb5e8L), Double.longBitsToDouble(0x3fca27419a0c3fe8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 6, 10, "\ud970\uddc8\ud960\udf5e", "\uaf08\u3b7d\u439d\u8c82\u101e", "\ud9cb\udca6\ud860\udff4\ud93b\uddae\ube68\udb3d\udc93\ud97b\udfcd\ud90b\udfff\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\uda34\udda2\udbfa\udf15\ud9a4\ude2c\udbe0\udeec\ud8f0\udd6b\ud96a\udd76\uda81\udfcb\ud9d7\udcc1\ud96e\ude36\uda8b\ude98\ud91c\udf70\ud812\udd56\uda66\uddfc\ud913\udfd7\ud84e\udce2\ud9f1\udfb3\udbce\udf94\ud907\ude25\udaa9\udc57\udb14\udc62\ud83f\ude5d\ud900\udc5e\udbb0\udf13\ud855\udef7\ud9ac\udc5f\udb2d\udefb",
        11, 97705, 286235925, 8666805633304742750L, 31899L, false, true, (char) 9459, (char) 41987,
        Double.longBitsToDouble(0x3fea3c8968b5384fL), Double.longBitsToDouble(0x3fdc62e48e6e56f2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.util.Date:Fri May 05 00:33:16 PST 139961247\012",
        Z.run(T, 1, 9, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc52\udaae\udef6\ud802\udee8\ud9b1\ude98\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud808\udcb4\ud8f3\udc8a\udb45\udd7b\uda0f\udd45\ud891\udef7\udaf9\udd03", "\ud360", "\ud993\udec7\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903394298803350L, -91504L, true, false, (char) 35918, (char) 29189,
        Double.longBitsToDouble(0x3fdd672932da6e32L), Double.longBitsToDouble(0x3fecd4a242b7acf4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 6, 13, "\uda28\udeeb\uda26\udef2\ud993\udef8\uda7a\udef1\ud8f1\udff3\udaea\udc22\uda5b\udc05\ud91c\ude83\udb61\udf38\uda6d\udcdb\ud92e\udca7\ud9cb\udca6\ub4ee\u146d\udada\udc1e\ud9b1\udf7b\ud9de\udf1e\udb53\udda3\u81ce\udaf4\udcce\udb69\ude25\udaa8\udca1", "\ub247\uca2d\u4663\u1a8b", "\udb83\uded3\ud846\uddd5\ud92e\udc4f",
        18, 46964, 743309572, -4640313624760278339L, 63476L, false, false, (char) 29092, (char) 59208,
        Double.longBitsToDouble(0x3fda03719f352890L), Double.longBitsToDouble(0x3fe5bd67a01cb12aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.util.Date:Wed May 12 00:33:16 PST 139961254\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 15, 13, "\uda28\udeeb\ud92a\udf1a\ud976\udcd3\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc52\ud928\udff2\uda10\udea6\uda84\udf5d\ud94a\udfeb\ud99a\udda6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud878\udcf7\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud932\udf88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903394298803350L, -38878L, true, false, (char) 18934, (char) 52585,
        Double.longBitsToDouble(0x3fdd699bf2da6e32L), Double.longBitsToDouble(0x3fef94a242b7acf4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 13, "\000\000\udbe7\udf2c\u493d\udb03\udcc4\ud9b6\ude06\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93b\udb53\udda3\ud8c1\udf7d\ud833\udd01\udaa4\udfb2\udacf\ude03", "", "\ud96a\udd76\uda81\udfcb\ud9d7\udc9d\ud912\ude88\udb7c\udf82\ud91c\udf70\ud812\udd56\uda66\uddfc0\uda71\udc58\ud9bb\udf9e\000\ud992\udff1\u7494\udb09\udde4\u9562\000\udb8c\udda6\ud84e\udeb5",
        21, -1000, 250806272, -1758890120366508922L, 24668L, true, true, (char) 39761, (char) 39353,
        Double.longBitsToDouble(0x3fcaf0fa7ab04df0L), Double.longBitsToDouble(0x3fbfa9b6dd5f3df0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 15, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c=\000\000\uda5b\udc52\u17c2\ud940\ude3d\u8c6d\ud92f\udf93\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360", "\uda81\udfcb",
        55, 62733, 9887808, 1312316602L, 99728L, false, true, (char) 3615, (char) 57943,
        Double.longBitsToDouble(0x3fef8fee149453e0L), Double.longBitsToDouble(0x3fe391c9a562dc42L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.util.Date:Wed May 05 07:33:16 PST 139961254\0121=java.util.Date:Wed May 05 00:33:23 PST 139961254\012",
        Z.run(T, 2, 3, 7, 9, "\udb53\udcc1\udb1d\udcfb\ud8d3\ude03\ud9fd\udd45\udbbb\udf3d\udaea\udc21\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\ud9b0\udff9\ud93b\udd47\ube68\ud812\udd42\udb32\udfb0\udb53\udda3\ud8ca\udc7d\u3af0\ud893\udd55\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903394298803350L, 3183L, false, true, (char) 44075, (char) 54841,
        Double.longBitsToDouble(0x3fd458e932db8264L), Double.longBitsToDouble(0x3fecd4a242b7acf4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 15, 13, "\uda28\udeeb\ud92a\udf1a\udb61\udf29\udafd\udcd2\udab8\ude1b\udace\ude12\uda17\udc50\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\udae3\udfb9\ud9e1\udfdf\udb04\udf0c", "\ud360", "\ud96b\udffa\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70",
        34, 23364, 234816407, -4416903394298803350L, 41938L, false, true, (char) 28777, (char) 51333,
        Double.longBitsToDouble(0x3fecd4a242b7acf4L), Double.longBitsToDouble(0x3f9cb12a68b5d2e0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 11, 9, "\uda28\udeeb\udbcd\udffe\udbc5\uded0\uda7a\udef1\ud83a\ude5e\ud839\udca6\uda6a\udf06\uda4f\ude01\udaca\udedd\ud968\udc2a\ud930\udc0f\ud952\udcf0\udb1e\udc74\ud9f7\udd94\uc758\udb3d\udc93\udb00\udf9d\udaee\ude7a\ud8ca\udd1a\ud9ff\udea7\udb0b\udc38\uda39\udd9c", "\ud360\u427d", "\ud973\udeb0\ud897\ude8a\udb6d\udc4d\ud8f8\udf3f\udbb2\udea4\uda66\ude08\ud93b\udea1\uda5b\udccc\ud9d7\udcf4\ud886\ude9b\uda4e\udc81",
        39, 71426, -244148004, -8845627929820048741L, -24802L, true, true, (char) 40054, (char) 25068,
        Double.longBitsToDouble(0x3fef8f0b194ae22aL), Double.longBitsToDouble(0x3fb2de96b1e8ea18L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 7, 0, "\000", "\u32fd", "\udb64\udfa7",
        19, 27042, -1276605331, -7855361869757486914L, 74733L, false, false, (char) 56726, (char) 37238,
        Double.longBitsToDouble(0x3fc895fe37a90940L), Double.longBitsToDouble(0x3ece7bd870000000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.ArithmeticException\012",
        Z.run(T, 1, 0, 10, 12, "\ud868\udf83\ud9e3\uddb1\udbe7\udf2c\ud8e1\udc44\udb3d\udd92\ud98a\udebd\ud9ff\udef3\ud9ba\udfdb", "\u70e8\ud7ed", "\ua4bd",
        -3, 53815, 188828138, 8861150292485275648L, -57710L, false, false, (char) 35841, (char) 3334,
        Double.longBitsToDouble(0x3fcdeddd6959d924L), Double.longBitsToDouble(0x3fd3733851725898L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 4, 12, "\uda7f\udf44\uda41\udc29\udbb0\udcf1\ud8e1\udc44\udacd\udd9a\udb43\udd68\ud9ff\udf67\ud9ba\udfdb", "\ud0e8\ucb1e", "\ua4bd",
        49, 52791, 625035754, 8861150092127174899L, 6292L, false, true, (char) 64758, (char) 5652,
        Double.longBitsToDouble(0x3fe3a62c6aedba18L), Double.longBitsToDouble(0x3fcdeddd76209f98L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 9, 0, "\ud868\udf83\ud9e3\uddb1\ud95b\udf47\udb3b\udef8\udb1c\udf82\ud98a\udebd\ud9ff\udef3\ud8d6\ude57", "\u70e8", "\ud84b\uddcf\ua4bd\ud949\udf30\uda21\udca1\ud806\udde3\udb1b\udea2\ud8ba\udd62\ud891\udef7\udb0b\uddc0\udbc6\ude4e\ud95a\udfc9\ud8c6\udeca\ud974\ude55\ud96a\udd76\uda16\udfe7\ud8dd\udd5f\ud90b\udfd3\udbe4\udd2f\uda56\udff5\ud8b9\udfc3\ud8c5\udf8b",
        17, 48613, -265203222, 4772005850155946988L, -88366L, true, true, (char) 48397, (char) 58453,
        Double.longBitsToDouble(0x3f959782b614dec0L), Double.longBitsToDouble(0x3feafbdc47427a8cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\000", "\ud9c4\udfe1\ud861\udcd9\uda7f\udd11",
        39, 77624, 190, 0L, -100000L, true, true, (char) 46070, (char) 62,
        Double.longBitsToDouble(0x3e3a20e778000000L), Double.longBitsToDouble(0x3fefd5b847000004L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 10, 12, "\ud868\udf83\ud9e3\uddb1\udbe7\udf2c\ud8e1\udc44\udb1c\udf82\ud98a\udebd\ud9ff\udef3\ud9ba\udfdb", "\u70e8\ud7ed", "\udb69\udcbc",
        -1, 53815, 1282492906, 8861150292485297395L, -57710L, false, false, (char) 35841, (char) 3334,
        Double.longBitsToDouble(0x3fd186eeb76a53e0L), Double.longBitsToDouble(0x3fd3733851725898L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 13, 4, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\ud98b\udf8b\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\uc268\udb3d\udc93\uda47\udf14\udb4e\uded0\ud8ca\udc7d\ud9ff\udea7\udbfc\udf8a\udadd\udc5f", "\u5499\uabab", "\ud9d7\udcc1\ud956\udd0b\uda7c\uded1\udb31\udfd1\ud85f\udde2\uda56\ude25\ud86b\udd03\ud8c7\ude27\ud9bb\udf9e\ud9e6\udfd9\ud993\udce2\udaa9\udc57\udb14\udc62\udb56\udf77\ud8fc\udff6\ud9ca\udf9f\ud86b\udc89\udaab\ude11\ud942\ude08\uda93\udcaf\udb23\uddf5\udba2\udd2b\uda22\udd2c\udb23\udcbb\udbf7\udc43\ud8dd\udcdd\uda7d\udd28\uda7e\uddb7\uda80\ude77\ud874\uddb7\ua848\ud881\uddf5\udba3\udc3a\uda92\udc00\ud91b\uddca\ue2fe\uda37\udcb5\ud8ad\uddb3",
        38, 68575, 1202949510, 6647762274705674521L, 4099L, false, true, (char) 50811, (char) 9514,
        Double.longBitsToDouble(0x3fde61e73a8e63fcL), Double.longBitsToDouble(0x3fe69b906995f2b5L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 12, 7, "\uda28\udf7c\ud890\udfed\udbe7\udee8\uda7a\udef1\udb03\udd3b\udace\ude12\ud98b\udf8b\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\uda28\udc17\uda95\udc4e\ud93b\udd47\uc268\udb3d\udc93\uda47\udf14\uda9b\uddd8\ud81d\udf88\ud9ff\udea7\udbfc\udf8a\udadd\udc5f", "\u6eef\u728b", "\ud9d7\udcc1\ud8a1\udd2f\udb7d\udc1c\ud91c\udf70\ud812\udd56\uda66\uddfc\ud86b\udd03\ud8c7\ude27\ud9bb\udf9e\ud886\ude9b\ud993\udce2\udaa9\udc57\udb14\udc62\uda29\udc22\ud900\udd15\uda86\udfbd\udbc8\udf22\udaab\ude11\ud920\udf08\ud8ad\udee8\ud85b\uddfe\udba2\udd2b\uda22\udd2c\ud95e\udd3b\udbf7\udc43\ud8dd\udcdd\uda7d\udd28\uda7e\uddb7\uda80\ude77\ud874\uddb7\ua848\ud8df\ude04\udba3\udc3a\uda92\udc00\ud91b\uddca\ue2fe\uda37\udcb5\ud8ad\uddb3",
        38, 68575, 1202949510, 6647762274705674521L, 4099L, true, false, (char) 23858, (char) 9514,
        Double.longBitsToDouble(0x3fde61e73a8e63fcL), Double.longBitsToDouble(0x3fe69b906c93ffb5L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 15, 5, 10, "o", "\000", "",
        51, 36450, -216460402, 13199003885764608L, -100000L, true, true, (char) 7096, (char) 18397,
        Double.longBitsToDouble(0x3fdec000039e59ecL), Double.longBitsToDouble(0x3fe7e21e98080a8fL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 11, 10, "\uda28\udf19\ud92a\udf1a\udbe7\udf2c\udaf9\ude65\udb03\udd3b\udace\ude12\uda5b\udc52\uda6d\udcd4\ud964\udf0a\ua7f1\ud930\udc2e\ud937\udf3b\ud99c\udf8a\udae6\udf9a", "\u496c\ua251\u8afd\u2f3e\u95f8\ud368\u0996\u035e\ud360\u728b\u4663\u1a8b", "\udba6\uddc8\ud956\ude38",
        7, 83471, 234818608, -4416903395206745944L, -26146L, false, true, (char) 32194, (char) 32529,
        Double.longBitsToDouble(0x3fe494a242094a2aL), Double.longBitsToDouble(0x3f9cb12a68b5d2e0L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 13, 5, "\uda28\udeeb\ud92a\udf1a\udab1\udc51\ud82b\udcfe\ud9a6\udd31\ud847\udd8f\ud919\udf70\ud8b5\uddd0\ud940\udecb\ua7f1\ud930\udc2e\ud808\udc8a\udbcd\uddfb\udae6\udf9a\ube93\udb3d\udc93\ud97b\udfcd\ud8d9\udda6\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360", "\ud8df\udeda\ud9d7\udcf0\ud912\ude88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903395206745944L, -26146L, false, true, (char) 28777, (char) 51333,
        Double.longBitsToDouble(0x3fe494a242094a2aL), Double.longBitsToDouble(0x3f9cb12a68b5d2e0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.Date:Wed Jan 07 03:33:07 PST 179962318\0121=java.util.Date:Wed Jan 07 03:33:07 PST 179962318\012",
        Z.run(T, 2, 5, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\ud8f2\udd9d\udae8\ude93\udace\ude12\uda2f\udcae\ud960\udeff\ud9cc\uddb0\uda11\udeed\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udb2d\udc5d", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud80f\uddc6\ub94d\udb19\ude4f",
        50, 72680, 1375668508, -5679240981772612843L, -82339L, false, false, (char) 35918, (char) 29099,
        Double.longBitsToDouble(0x3fdd672932da6e32L), Double.longBitsToDouble(0x3fecd37a42b7acf4L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 14, 5, 9, "\ud987\udda2\udb0e\ude1d\ud980\udeae\uda73\udf78", "\u181c\u8529\u4bf0\ub23d\u5d66\u025b\u1da3", "\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8a2\ude44\u065f\ud9fa\udc0a\udbd9\udf23\ud9f6\udfea",
        41, 8274, 719233396, 7941847116498221074L, -36453L, false, true, (char) 9003, (char) 61148,
        Double.longBitsToDouble(0x3fe82fa75de18614L), Double.longBitsToDouble(0x3fe215215c149902L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 11, 5, 3, "\ud8b4\udcb8\ud9ba\udc2b\ud85c\udfc1\u4906\000\udbc8\udd61\udb48\udc89\ud85e\udfb5\ud904\udca6\ua7f1\ud930\udc2e\udae8\udef4\ud8a8\udf82\ud8b1\udece\udb26\udc6f\u5c2c\ud8f9\udf53\udb45\udd9a\ud8ca\udc7d\ud9a3\ude99\ud891\udef7\udb41\udd3d", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud912\ude88\ud97d\udc0e\ud95d\udf90",
        58, 16620, 3611031, 0L, 20194L, false, true, (char) 28777, (char) 60037,
        Double.longBitsToDouble(0x3fe860ab42c7005fL), Double.longBitsToDouble(0x3fef33b8b345ae97L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 5, 3, "\ud8b4\udcb8\ud9ba\udc2b\ud85c\udfc1\uda7a\udeba\uda62\udf8b\udbc8\udd8b\udb48\udc89\ud85e\udfb5\ud904\udca6\ua7f1\ud9c8\ude1f\udae8\udef4\udb24\udc80\udba5\ude11\udb26\udc6f\u9212\ud8f9\udf53\udb45\udd9a\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udb41\udd3d", "\ud360", "\uda81\udfcb\ud9d7\udcc1\u27e5\u7840\000",
        59, 16620, 151, -315097088L, 20194L, false, false, (char) 28777, (char) 60037,
        Double.longBitsToDouble(0x3fe860ab42c7a75fL), Double.longBitsToDouble(0x3fef33b8b345ae97L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 5, 0, "\ud8b4\udcb8\ud9ba\udc2b\ud84b\udf04\uda7a\udeba\uda62\udf8b\udbc8\udd8b#\000\ud904\udca6\ua7f1\ud930\udc2e\udae8\udef4\ud8a8\udf82\ud800\udcb6\udb26\udc6f\u9212\ud8f9\udf53\000\ud8c1\udf3f\000\000\000", "\031", "\uda81\udfcb",
        14, 51237, 1083572288, 7390707726430123995L, -100000L, true, false, (char) 38986, (char) 3897,
        Double.longBitsToDouble(0x3fef8fee100053e0L), Double.longBitsToDouble(0x3fe000000562dc42L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.util.Date:Fri Jul 14 12:03:22 PDT 82204884\012",
        Z.run(T, 1, 6, 0, 0, "", "", "\ud9e0\uded0",
        16, 62169, 194, 2594073386142202057L, 43104L, false, true, (char) 3428, (char) 0,
        Double.longBitsToDouble(0x3e443c0000000000L), Double.longBitsToDouble(0x3f82b3c84f82d040L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.util.Date:Mon Apr 17 19:00:33 PST 141800203\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 0, 13, "\ub37c\udbe1\ude72\udbe7\udf2c\uda7a\udef1\uda19\udd46\udace\ude12\uda5b\udc4b\udad4\udedc\ud931\udf25\ud981\udf4b\ud930\udc2e\ud9e7\udff6\udba6\udc11\udb22\uddbb\u5c4a\uda85\ude97\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud86e\ude7f\ud891\udef7\udaf9\udd03", "\u6a9f\ua61b\u4663\u8d43\u9b30\u647e\ud20f\u0730", "\uda67\udfe2\ud81b\udff3\ud9cb\udd82\ud87c\udeb6\ud9da\udd20\udaa9\udc57\udb14\udc62\uda83\ude10\ud9ba\udd3a\uda70\udcb7\ud8f3\udc52\ud87e\udcbf",
        55, 726, -1564639453, -4474937948417966720L, 16647L, true, false, (char) 38907, (char) 44163,
        Double.longBitsToDouble(0x3feefabb399dc757L), Double.longBitsToDouble(0x3fb56f020dff2c10L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.util.Date:Thu Jan 27 16:12:21 PST 74910276\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 0, "\uda0c\udfc5\ud92a\udf1a\udbca\udf3d\uda7a\udf47\udb03\udd3b\udace\ude12\u1b4b\udae4\udeb1\ud940\ude7a\ua7f1\ud803\ude9a\uda0c\udcc6\000\000\udbbe\udfdf\udb3d\udc93\ud97b\udfcd\ud983\udddc\udb29\udc3d\u00e8\000\ud9cf\uddc6", "\ud360", "\uda81\udfcb\udb3c\udd6d\ud912\ude88\ud841\udf8f\uda94\udd6a",
        47, 83663, 234868465, -2364050659502858090L, 66774L, false, false, (char) 35918, (char) 38209,
        Double.longBitsToDouble(0x3fdd672892da6e32L), Double.longBitsToDouble(0x3fecd4a2404ea3f4L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 14, 9, "\uda28\udeeb\ud92a\udf1a\udbca\udf3d\uda7a\udf47\udb03\udd3b\udace\ude12\u1b4b\udae4\udeb1\ud884\ude5c\ua78e\ud803\ude9a\uda77\udd9b\uda0b\udc4f\uda74\ude6e\ud80c\udfd9\udb3d\udc93\udb3b\udfcd\ud983\udddc\udb29\udc3d\ud846\uddc1\ud9ca\udfed\udaf9\udd03", "\ud360", "\uda81\udfcb\udb3c\udd6d\ud912\ude88\ud841\udf8f\uda94\udd6a",
        47, 83663, 226742001, -2364050658760925034L, -8728L, false, false, (char) 35918, (char) 29092,
        Double.longBitsToDouble(0x3fdd672892da6e32L), Double.longBitsToDouble(0x3fecd4a2404ea3f4L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.util.Date:Mon May 28 06:12:20 PDT 291078474\0121=!java.lang.ArithmeticException\012",
        Z.run(T, 2, 3, 0, 9, "\uda28\udf95\ud92a\udf1a\udbca\udf3d\ud85a\udf6b\udb03\udd34\ud810\ude13\udaae\udfbf\udae4\udeb1\ud940\ude7a\ua7f1\ud803\ude9a\uda77\udd9b\udaab\udf15\udbeb\udc4e\ud8b2\udc8c\udb3d\udc93\ud97b\udfcd\ud983\udddc\udb29\udc3d\ud846\uddc1\ud9cb\udc2f\udaf9\udd03\ud819\udf4e\ud90c\ude32\ud8a9\udc2c\ud91c\udc1d\ud965\udfb5\uda81\udfcb\udb44\udf6d\ud912\ude88\ud844\ude71\ud82e\udf06\ud993\ude85\udad7\udefd\udb33\udc70\ud81d\udd89\uda4f\udda6\ud804\udc78\udb74\udd74\udaa9\udc57\ud9e0\udc7b\udbb3\udd50\ud8fd\udfa4\udbb0\udf13\ud93e\ude2d\uda4a\udfc1\udad8\udc03\udb24\udd2e\ud9f0\ude29\ud88d\ude16\uda3b\udef7\ud864\uddf7\ud95c\udd90\ud90e\ude60\uda90\udc92", "\u9ab7\u5a35\u723c\u8b29\u2b5b\u3201\u724b\u3ccf\u4719\uc49c\u83f0\u2263\u3f85\u9c8c\u9d3e\u4157\ua4be\u6e12\u8717\u6385\ub914", "\u015d\ud975\udd3f\uda8f\ude0e\uda90\udefa",
        11, 70914, -2006374947, 9185487277831940559L, 58894L, true, false, (char) 62736, (char) 24787,
        Double.longBitsToDouble(0x3fc3889a71f2c6e8L), Double.longBitsToDouble(0x3fea90b1ceeaeb64L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.util.Date:Fri Jul 23 13:57:05 PST 238457991\0121=java.util.Date:Fri Jul 23 13:57:05 PST 238457991\012",
        Z.run(T, 2, 4, 4, 4, "\uda5e\udcd0\ud87f\udfcc\udbca\udf3d\uda87\ude47\udb03\udd3b\ud904\ude0d\u1b4b\uda06\udfb5\ud879\udf98\udbc6\udf70\ud803\ude6d\udb6b\udf36\uda95\udc1f\udb07\udc18\ud8b2\udc8c\udb3d\udc93\ud98b\udf84\ud983\udddc\udb29\udc3d\ud846\uddc1\udb88\udd09\udb9c\uddaf", "\u7811\u27eb\u3d94", "\udb42\udf00\ud980\ude3f\udbd5\ude19\ud993\ude85\udabd\udce9\ud89b\udfc4\uba84\uda4f\udd60\ud804\udc78\udb74\udd74\udb3a\udfc0\uda20\udc6d\ud991\udd99\ud9d1\ude02\udab8\udcd7\ud93e\ude06\ud937\udd37\ud9d2\udcd1\ud96a\udef7",
        20, 25845, 88955901, -7525224014954574475L, -3827L, false, false, (char) 35613, (char) 31332,
        Double.longBitsToDouble(0x3fe5b5c8ee1db174L), Double.longBitsToDouble(0x3fdb9ca10946dd22L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.util.Date:Sun Jul 17 11:31:21 PST 100293284\0121=java.util.Date:Sun Jul 17 11:31:21 PST 100293284\012",
        Z.run(T, 2, 3, 3, 13, "\udabd\udca3\ud903\udd8e\udbca\udf21\uda7a\udf47\udb03\udd3b\udace\ude12\u1b4b\udae4\udeb1\ud940\udf14\ud9a1\ude2c\ud92e\udec8\ud861\udc8e\ud854\udc8c\uda6e\udcf6\ud800\udf8e\udb3d\udc1d\ud97b\udfcd\ud983\udddc\udb29\udc3d\ud86e\udfc1\ud9ca\udfed\udaf9\udd03", "\ud360\u728b\u4663\u1a8b\u1446\u64f2\uc33e\uc2d3\ud5a5\u4bc0\u7788\u9590\ua0f2\u6904", "\udb14\udc62\udbe7\udc21\ud900\udd15\udbd1\udea9\uda24\udf00\udb03\udd9e\uda01\udeb5\ud8bf\udf0a\ud936\udec5\ud82e\ude40\udb6a\udf63\uda3d\udda9\udbd0\udce9\uda9e\udc2e\ud8f7\ude3f\udb81\udc66\u4dc9\ud86f\udc55\ud92d\udc5f",
        41, 63057, 1881396576, -3165077457984518744L, 55495L, true, false, (char) 63706, (char) 27961,
        Double.longBitsToDouble(0x3fc9c1776d7910dcL), Double.longBitsToDouble(0x3fd1a0d589d5841aL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.util.Date:Sun Oct 10 17:53:28 PDT 162656951\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 0, "\uda0c\udfe7\uc63f\000\000\000\000\000\u17c2\ud940\ude7a\ua7f1\uda9f\udda8\000\uda94\udf7c\uda53\udc2d\u549e\000\u8c62\000\udb29\udc3d\u4ce8\000\udaf9\udd03", "\u26a3", "\uda81\udfcb",
        0, 88504, 2080374848, 5132895452441608237L, -100000L, true, false, (char) 49095, (char) 20813,
        Double.longBitsToDouble(0x3e128a6e20000000L), Double.longBitsToDouble(0x3e45880000000000L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.util.Date:Mon Oct 09 18:18:50 PST 74236948\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 3, 14, 9, "\uda28\udeeb\ud92a\udf1a\udbca\udf3d\ud953\ude30\udb03\udd8e\udace\ude12\u1b4b\udae4\udeb1\ud940\ude7a\udb81\udd1c\ud983\udc8e\uda77\udd9b\uda95\udc15\uda53\udc2d\ud8b2\udc8c\udb3d\udc93\ud97b\udfcd\u048b\udb1e\ude3d\ud846\uddc1\ud8b0\ude21\udaf9\udd03", "\u2bcd", "\uda81\udfcb\udb3c\udd6d\ud912\ude88\uda61\udfe0\uda94\udd3f",
        47, 42039, -1669214479, -2342802021770469226L, 66774L, false, false, (char) 35918, (char) 29092,
        Double.longBitsToDouble(0x3fdd672892da6e32L), Double.longBitsToDouble(0x3fecd4a245c1bf02L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 0, 0, "\ud899\ude31\ud855\udd02\udb1e\udecf\ud9b4\uded2\u17fa\ud8fb\udfe8\ud97b\udc5c\u17c2\ud956\udffb\u1b84\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud87f\uddf5\ud871\udcd6\ud86a\uddeb\udaf9\udd03", "\ud360", "\uda82\udc3a\ud9bb\udec1\ud912\ude88\udb6d\udf89",
        3, 22602, 949282304, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 13, "\udbc1\udcdf\udad0\ude66\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda65\udd4b", "\ub23d\u5d66\ub672\u112b\ucd92\u7078\ub10c\uad80\u81cb\u3a65\u792f\u1cc9\ud368\u0996", "\ud8f0\udd6b\ud96a\udd76\uda81\udfcb\ud9d7\udcc1\ud912\ude88\udb66\udeb6\udb7a\udff8\ud8eb\udc0b\ud852\udcb6\ud9cc\uded6",
        53, 36039, -120831405, 8680446859034858820L, 2822L, true, false, (char) 58367, (char) 4949,
        Double.longBitsToDouble(0x3fe50f653f43a664L), Double.longBitsToDouble(0x3fea1ac008f1ae00L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 13, "\ud955\udc88", "\u6e3d\u2af4\u5f90\u58dc\ua8f9\u4c43\ub23d\ua55b\ub672", "\ud8fe\udc58",
        4, 50574, -1232759100, 8861150292485297395L, -47433L, false, true, (char) 41351, (char) 8387,
        Double.longBitsToDouble(0x3fb3e11004b0c6f0L), Double.longBitsToDouble(0x3fb1bb4c974f3b78L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.util.Date:Sat Sep 04 05:41:01 PST 147036087\0121=java.util.Date:Sat Sep 04 05:41:01 PST 147036087\012",
        Z.run(T, 2, 9, 9, 12, "\uda28\udeeb\udb0d\udcbd\ud916\udf74\ud84c\udf7a\udb03\udd9c\udace\ude12\uda5b\udc52\ud928\udff2\uda10\udea6\uda84\udf5d\ud94b\udc49\ud85d\udd06\udaf6\udd4c\ud93b\udd47\ubecd\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8fd\udc71\ud9ff\udea7\ud878\udcf7\udaf9\udd03", "\ucc45", "\uda82\udc0c\uda96\udca1\ud932\udebf\uda83\uddc4\ud91b\udff9\ud921\udd83",
        50, 97275, -189529660, -4640169711435538499L, 11105L, false, false, (char) 27799, (char) 38805,
        Double.longBitsToDouble(0x3feb69b8ce58111dL), Double.longBitsToDouble(0x3fc9538cd7388508L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.util.Date:Fri Aug 13 22:23:09 PDT 74365176\0121=java.util.Date:Fri Aug 13 22:23:09 PDT 74365176\012",
        Z.run(T, 2, 2, 2, 13, "\uda28\udeeb\uda51\udc20\uda36\udeef\ud994\ude5e\udad0\udfb2\uda14\udc01\uda5b\udc52\ud928\udff2\ud864\udf10\uda2d\udd19\ud94a\udfeb\uda4f\udee3\uda95\udc4e\ud836\udc43\udb47\udc17\ud99e\udeb4", "\u8afd\u2f3e\u7142\u9c7d\u0996\u91c5\ua62e", "\uda81\udfcb",
        -3, 21726, -191438774, 2346676142073789114L, 99728L, false, true, (char) 3615, (char) 18745,
        Double.longBitsToDouble(0x3feebb63f0ed9194L), Double.longBitsToDouble(0x3fd5b0f7f1031d2aL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.util.Date:Fri Sep 27 16:48:41 PST 102120270\012",
        Z.run(T, 1, 2, 15, 13, "\uda9a\udeac\ud92a\udf1a\udb61\udf29\udafd\udcd2\udab8\ude1b\udace\ude12\uda17\udc50\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud8e8\ude1e\ube52\udb3d\udc93\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\udae3\udfb9\ud9e1\udfdf\udb04\udf0c\udbf1\udc7e\ud97b\uddbd\uda1b\udff3\ud8f0\udd6b\u9c76\ud96b\udffa\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70\uda67\udf12\ud846\udee0\ud869\udc6a\ud8c7\ude27\ud9bb\udf9e\ud886\ude9b\ud993\udc6c\u6ff3\udb28\udc60\uda29\udc22\ud900\udd15\ud80e\udd15\ud84e\udeb5\udaab\ude11\udb44\udf4f\udbdc\ude9c\udace\udee3\ud517\udb80\udc42\udabc\uddbb\ud8d9\udebd\ud833\udf36", "\u15bf\uaf98\u1604\u185d\u3881\ua56e\u9272\u7c89\u2500\u6a92\u8c78\u3f6a\u03da\u2582\ubff9\u6273\u5dd3\u69ca\uc65b\ud449\u708c\u6593\u4625\u73a3\ub92a\u48d0\u451f\u4b45\u4da3\ubae6\ubadb\u2302\u3049\ud751\u5f90\u3128\u0459\u2757\u2f27\ubaa4\u9ba8\ud104\u81ea\u8c22\u4b1a\u8885\u865c\u76b2\u3dae\u138a\u5711\u9e2d\u12d6\u16eb\u7a73\u8ff2\u1530\u1387\u5df9\ub6ee\u01c9\ud297\u60a5\u6a1f\u2c22\u942c\ub37c\u6c67\ub687\u67d6\u1938\ud7c0", "\udbac\udcf7\ud9ed\udfae\ud9e8\ude10\uda17\udd18\udbb2\udc94\ud918\udf68\uda1d\udd29\ud88d\udef3\udb90\udf79\ud818\udc2d\ud86c\udefd\ud94a\udc02\udad6\ude4f\udb1a\udc43\ud879\udf6e\udad9\udf84\udaea\udd07\udae8\udd3c\ud82f\udcc5\udb17\udce7\uda07\udf12\uc764",
        45, 59006, 1651590336, -3222732748921878525L, -82306L, true, true, (char) 47168, (char) 45488,
        Double.longBitsToDouble(0x3feb7812c7900148L), Double.longBitsToDouble(0x3fd0af16f731cf52L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 3, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\ud81f\udc87\ud8c7\udfce\ud9b5\udfe6\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\uc268\udb3d\udc93\uda47\udf14\udb4e\uded0\ud8ca\udc7d\ud997\udff3\udba0\udc16\udb3f\uddf1", "\ubc2f\uabab", "\ud9d7\udcc1\ud956\udd0b\uda35\ude2d\udb32\udc6e\ud88e\udd38\udbfd\udc7d\ud890\udf1f\udbd4\ude8e\udb2f\udd37\ud9e6\udfee\ud993\udce2\udaa9\udc57\udb14\udc62\udb56\udf77\ud9d7\udd03\udaef\udeb9\uda48\ude7b\udaab\ude11\ud942\udea3\uda93\udcaf\ud992\udfe6\udba2\udded\uda22\udd2c\ud83f\udd69\udac1\udf44\ud90a\ude8c\udad0\udd9c\uda7e\uddb7\uda80\ude77\ud874\uddb7\ufdb2\ud936\ude39\udba2\udfdb\uda92\udc00\ud91b\uddca\ue2fe\uda37\udcb5\ud8ad\uddb3",
        1, 12797, 1202949420, 6647762272275130649L, 86198L, false, false, (char) 50811, (char) 25924,
        Double.longBitsToDouble(0x3fde61e73bb863fcL), Double.longBitsToDouble(0x3fe69b906995f2b5L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 12, 7, "\uda28\udf7c\ud890\udfed\udbe7\udee8\uda7a\udef1\udb03\udd3b\udace\ude12\ud98b\udf8b", "\u91c9\u1671\u9519\u112b\ucd92\u7478\ub10c\u81be\u331c\ubed6\u2f3e\u88af\u62c4\ubb6e", "\ud8f0\udd6b\ue1be\ud822\udf08\ud9d7\udcc1\ud8a1\udd2f\udbcb\udca3\ud926\udcb0\ud812\udd56\uda66\uddfc\ud86b\udd03",
        59, 25056, -37603628, 6044032947287260820L, -72706L, false, true, (char) 51333, (char) 48984,
        Double.longBitsToDouble(0x3fe5bd62c51c9a2aL), Double.longBitsToDouble(0x3fe07f6d8bc60a27L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.util.Date:Tue Apr 17 19:01:28 PST 141800258\0121=java.util.Date:Tue Apr 17 19:01:28 PST 141800258\012",
        Z.run(T, 2, 7, 7, 13, "\ub37c\udbe1\ude72\udbe7\udf2c\udabd\udc63\uda03\udf62\udace\ude12\uda5b\udc4b\udad4\udedc\ud931\udf25\ud981\udf4b\ud930\udc2e\ud9e7\udff6\udba6\udc11\ud816\uddb5\u5c4a\uda85\ude97\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud86e\ude7f\ud891\udef7\udaf9\udd03", "\u6a9f\ua61b\u4663\u39a5\ucfd8\u882a\ud20f\u0730", "\uda67\udfe2\ud81b\udff3\ud9cb\udd82\ud87c\udeb6\ud9da\udd20\udaa9\udc57\udb14\udc62\uda83\ude10\ud9ba\udd3a\uda70\udcb7\ud8f3\udc52\uda47\ude92",
        55, 50221, 989718427, -4474937948417966720L, 16647L, true, false, (char) 38907, (char) 52478,
        Double.longBitsToDouble(0x3fa89e88567f6a50L), Double.longBitsToDouble(0x3fe6405a99d24e47L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.util.Date:Thu Nov 17 19:00:33 PST 141800254\0121=java.util.Date:Thu Nov 17 19:00:33 PST 141800254\012",
        Z.run(T, 2, 6, 6, 13, "\ub37c\udbd5\udfdd\udbe7\udf2c\uda7a\udef1\uda19\udd46\uda31\udda3\uda5b\udc4b\udad4\udedc\ud931\udf25\ud981\udf4b\ud930\udc2e\ud9e7\udff6\u9c94\udb22\ude3b\u5c4a\uda85\ude97\ud97b\udfcd\udb53\udda3\ud8ca\udc7d\ud86e\ude7f\ud891\udef7\udaf9\udd03", "\u6a9f\ua61b\u99cb\u8d94\u9b30\u647e\ud20f\u0730", "\ud930\ude2b\ud81b\udf7c\ud9cb\udddd\ud87c\udeb6\ud9da\udd20\u6832\ud991\udc64\u623c\udabd\udf4a\uda70\udcb7\udb59\udec3\ud84b\udc47",
        55, 726, -1564639453, -4474937948417966720L, 16647L, true, false, (char) 38907, (char) 44163,
        Double.longBitsToDouble(0x3feefabb399dc757L), Double.longBitsToDouble(0x3fa0de041bfe5e50L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.util.Date:Fri Dec 31 08:40:13 PST 74910277\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 0, "\ud9d5\udeef\ud92a\udf1a\udbca\udf3d\uda7a\udf47\udb03\udd3b\udace\ude12\u1b4b\udae4\udeb1\ud940\ude7a\ud91d\udfea\ud803\ude9a\uda0c\udcc6\000\000\udbbe\udfdf\udb3d\udc93\udb0d\udfd6\ud983\udddc\udb29\udc3d\u00e8\ud9f9\ude2f\ud9cf\uddc6", "\u30a3", "\uda81\udfcb\udb3c\udd6d\ud857\udfb6\uda46\udfdd\ud9e3\udf2d",
        -2, 83663, 234868349, -2364050661686386538L, 66774L, false, false, (char) 35918, (char) 38209,
        Double.longBitsToDouble(0x3fdd672892da6e32L), Double.longBitsToDouble(0x3fecd4a2404ea3f4L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 15, 5, 13, "\uda28\udeeb\ud92a\udf1a\udbe7\udf2c\uda7a\udef1\udb03\udd3b\udace\ude12\uda5b\udc52\ud928\udff2\ud940\udecb\ua7f1\ud930\udc2e\ud9cb\udca6\uda95\udc4e\ud93b\udd47\ube68\udb3d\udc93\ud97b\udf6b\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03", "\ud360", "\uda81\udfcb\ud9d7\udcc1\ud912\ude88\udb7c\udf82\ud91c\udf70",
        7, 83471, 234818608, -4416903394298803350L, 41950L, false, true, (char) 28777, (char) 51333,
        Double.longBitsToDouble(0x3fecd4a242b7acf4L), Double.longBitsToDouble(0x3f9cb12a68b5d2e0L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.util.Date:Sat Feb 10 04:38:50 PST 234307229\0121=java.util.Date:Sat Feb 10 04:38:50 PST 234307229\012",
        Z.run(T, 2, 8, 8, 0, "\uda28\udf95\ud92a\udf1a\udbca\udf3d\ud85a\udf6b\udb03\udd34\ud810\ude13\udaae\udfbf\udae4\udeb1\ud940\ude7a\ua7f1\ud803\ude9a\uda77\udd9b\udaab\udf15\udbeb\udc4e\ud8b2\udc8c\udb3d\udc93\ud97b\udfcd\ud983\udddc\udb29\udc3d\ud846\uddc1\ud9cb\udc2f\udaf9\udd03\ud819\udf4e\ud90c\ude32\ud8a9\udc2c\ud91c\udc1d\ud965\udfb5\uda81\udfcb\udb44\udf6d\ud912\ude88\ud844\ude71\ud82e\udf06\ud993\ude85\udad7\udefd\udb33\udc70\ud81d\udd89\uda4f\udda6\ud804\udc78\udb74\udd74\udaa9\udc57\ud9e0\udc7b\udbb3\udd50\ud8fd\udfa4\udbb0\udf13\ud93e\ude2d\uda4a\udfc1\udad8\udc03\udb24\udd2e\ud9f0\ude29\ud88d\ude16\ud887\udefd\ud864\uddf7\ud95c\udd90\ud90e\ude60", "\u2110\u9ab7\u5a35\u723c\u8b29\u2b5b\u3201\u724b\u3ccf", "\uda4f\udceb\uda2a\udfe6\udbdf\udc74\udbea\udfea\ud832\udfd7\udb0e\uddd8\ud8fd\udec0\ud9ce\udd09\udbea\udc25\ud9bf\udfe6\ud957\udf27\udaaa\udf01\ud913\uddda\u015d",
        13, 27842, -2026554855, 7393959807309530530L, 69981L, true, true, (char) 40231, (char) 24757,
        Double.longBitsToDouble(0x3fe2bedfcf9c8574L), Double.longBitsToDouble(0x3fe0a415fc9c44d3L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.util.Date:Thu Nov 15 12:57:33 PST 31961274\0121=void\012",
        Z.run(T, 2, 8, 0, 0, "\ud899\ude31\ud855\udd02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\ud956\udffb\u1b84\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud87f\uddf5\ud871\udcd6\ud86a\uddeb\udaf9\udd03", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda19\udda9\ud819\ude7e",
        15, 2, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.util.Date:Fri Nov 09 07:17:35 PST 31961274\0121=void\012",
        Z.run(T, 2, 8, 0, 0, "\ud899\ude31\ud855\udd02\udb1e\udecf\ud9af\ude8d\u17b4\ud9aa\udc89\ud97b\udd22\u17c2\ud956\udffb\u1b84\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8d5\udd37\udab5\udce3\ud904\udc98\ud996\uddbd\uda09\udd95\ud9df\ude8f", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda19\udda9\ud819\ude7e",
        15, 2, 944488579, 1008538240285055172L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e727d02813aL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.util.Date:Thu Nov 15 12:57:33 PST 31961274\0121=void\012",
        Z.run(T, 2, 8, 0, 0, "\ud899\ude31\ud855\udd02\udb1e\udecf\ud997\ude81\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\ud956\udffb\u1b84\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud87f\uddf5\ud871\udcd6\udb09\udc13\udaf9\uddaf", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda19\udda9\ud819\ude7e",
        15, 2, 944488579, 1008538240823853508L, 285L, false, false, (char) 18900, (char) 58516,
        Double.longBitsToDouble(0x3fef0bd8a4018424L), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud899\ude31\ud855\udd02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\ud956\udffb\u1b84\udb67\udea9\000\udb2d\udc76\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud87f\uddf5\ud871\udcd6\ud86a\uddeb\udaf9\udd03", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda19\udda9\ud819\ude7e",
        15, 2, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.util.Date:Thu Nov 15 12:57:33 PST 31961274\0121=void\012",
        Z.run(T, 2, 8, 0, 0, "\ud899\ude31\ud848\udc02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\udb2f\udca7\u1c2a\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud9ee\udc82\ud871\udcd6\ud86a\uddeb\udaf9\udd03", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda64\udc6e\ud819\udef1",
        15, 9, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud899\ude31\ud855\udd02\udb1e\udecf\ud9af\ude8d\000\000\ud97b\udd22\u17c2\ud956\udffb\u1b84\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8d5\udd37\udab5\udce3\ud904\udc98\ud996\uddbd\uda09\udd95\ud9df\ude8f", "\ud360", "\uda82\udc3a\ud95d\ude8e\uda19\udda9\ud819\ude7e",
        15, 2, 944488579, 1008538240285055172L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e727d02813aL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\000\ud855\udcd3\udb1e\udecf\000\u1700\ud9aa\udc6c\ud97b\udc5c\000\ud956\udffb\uda9c\udc0d\udb67\udea9\ud82a\udd14\uda85\udd80\ud93b\udd47\u627c\000\ud8c6\udc83\udab5\udce3\ud904\udc98\ud996\uddbd\uda09\udd95\ud833\udef9", "\ud347", "\000\000\000\ud819\ude7e",
        15, 2, 944488579, -1567188992L, 39965L, true, false, (char) 53652, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc4216f4a3eL), Double.longBitsToDouble(0x3fd000000d02813aL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud899\ude31\ud855\udd02\udb1e\udecf\ud997\ude81\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\ud956\udffb\u1b84\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud87f\uddf5\ud871\udcd6\udb09\udc13\udaf9\uddaf", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda19\udda9\ud819\ude7e",
        15, 2, 944488579, 1008538240823853508L, 285L, false, false, (char) 18900, (char) 58516,
        Double.longBitsToDouble(0x3fef0bd8a4018424L), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.util.Date:Tue Apr 15 06:02:09 PST 192438940\0121=void\012",
        Z.run(T, 2, 8, 0, 0, "\ud899\ude31\ud848\udc02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\udb2f\udca7\u1c2a\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud9ee\udc82\ud871\udcd6\ud86a\uddeb\udaf9\udd03", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda64\udc6e\ud819\udef1",
        15, 9, 944488579, -6072973228749470857L, 39961L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.util.Date:Thu Jul 05 12:57:33 PDT 31961274\0121=void\012",
        Z.run(T, 2, 8, 0, 15, "\ud899\ude31\ud848\udc02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\udb2f\udca7\u1c2a\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud9ee\udc82\ud871\udcd6\ud86a\uddeb\udaf9\udd03", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda64\udc6e\ud819\udef1",
        -4, 9, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fdd22e36f6f4a3eL), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.util.Date:Thu Nov 15 12:57:33 PST 31961274\0121=void\012",
        Z.run(T, 2, 8, 0, 0, "\ud98d\udc36\udad9\udd4b\udb50\udcf4\ud977\udfd1\uda44\udd63\ud8d8\uddd9\ud90f\udf67\udb55\udeed\uda71\udde9\ud91c\udc1e\udb5f\udcef\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud9ee\udc82\ud871\udcd6\ud86a\uddeb\udaf9\udd03", "\ud360", "\ud9d4\ude5b\ud95d\udeb2\ud8c4\udfc2\ub76e",
        15, 14, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e7270996208L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud899\ude31\uda41\udfff\udb1e\udecf\ud9af\ude8d\u17b4\ud805\udeac\ud9ab\udc4d\u17c2\udb2f\udca7\u1c2a\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\ud8dd\udc4d\ud8ed\uddf0\udab5\udcea\udb56\udd95\ud870\udfe8\ud86a\uddeb\udaf9\udd03", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda64\udc6e\ud819\udef1",
        15, 9, 944488579, 1008538240823853508L, 39965L, true, false, (char) 8801, (char) 51315,
        Double.longBitsToDouble(0x3fe2af2dc9d34518L), Double.longBitsToDouble(0x3fee00c970b5632fL)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud899\ude31\ud83a\udf3c\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\udb2f\udca7\u1c2a\udb67\udea9\000\uda85\udc82\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud9ee\udc82\u00f0\000\000", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda64\udc6e\udb7b\udcc2",
        56, 9, 944488579, 1008538241852244420L, 39965L, true, false, (char) 21329, (char) 0,
        Double.longBitsToDouble(0x3e4ede947c000000L), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 15, "\ud899\ude31\ud848\udc02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\udb2f\udca7\u1c2a\u269b\uda20\udd0f\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud9ee\udc82\ud871\udcd6\ud86a\uddeb\udaf9\udd03", "\ud360", "\000\ud95d\ude8e\uda64\udc6e\ud819\udef1",
        -4, 9, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fdd22e3616f4a3eL), Double.longBitsToDouble(0x3e16a00000000000L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud98d\udc36\udad9\udd4b\udb50\udcf4\ud977\udfd1\uda88\udf0c\uda20\udcce\ud9d5\udc5b\udb65\ude7b\uda71\udde9\ud91c\udc1e\udb5f\udcef\ud82a\udd14\ud8a3\udc9d\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud9ee\udc82\ud871\udcd6\uda51\udd1d\u8aef", "\ud360", "\ud9d4\ude5b\ud954\udc27\uda85\udca8\uda41\udc42",
        15, 14, 944488579, 1008701797546525124L, -25571L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e7270996208L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud87a\udf38\ud956\udc7f\uda57\udefb\ud9af\ude8d\u17b4\ud805\udeac\ud9ab\udc4d\u17c2\udb2f\udca7\u1c2a\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\ud8d1\udd67\udbc8\udfd3\ud965\udc51\udb46\udfad\udaaa\udc04\ud86a\uddeb\udaf9\udd03", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda64\udc6e\ud819\udef1",
        15, 9, 944488579, 1008538243259170500L, -53016L, false, true, (char) 9358, (char) 57838,
        Double.longBitsToDouble(0x3fe1374749d34518L), Double.longBitsToDouble(0x3fee00c970b5632fL)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.util.Date:Wed Sep 14 16:52:42 PDT 181626844\012",
        Z.run(T, 1, 8, 4, 13, "\uda4d\udfdb\ud8fd\udd1a\udbe7\udf2c\uda7a\udef1\ud98a\udf3f\ud946\udc2c\udbba\ude72\ud928\udff2\udb3d\uddaa\udb8f\uddce\udafc\ude19\u7ed2\ud963\udebe\ud93b\udd47\ube68\udb3d\udc93\ud97b\udfe0\udb53\udda3\ud8ca\udc7d\ud9ff\udea7\ud891\udef7\udaf9\udd03\udbf1\udc7e\ud97f\udebd\uda1b\udff3\ud8f0\udd77\ud96a\udd76\uda81\udfcb\ud9d7\udcc1\ud9e1\udd70\udb82\uddf6\udb0f\udfaa\uda74\udf88\ud81b\udf1a\ud86b\udd03\ud8c7\ude27\uda42\udc60\uda78\uded0\ud993\udce2\udac1\udc9c\udb14\udc62\uda29\udc22\ud977\udef2\udbb0\udf13", "\u331b\u7849\u09bc\u211c\u56b3\u5652\ud589\u787d\u0100\ubcde\u5e2e\u40a5\u1da7\ud725\uc080\u7516\u5d82\u230e\u6120\u594e\ua654\u0b13\u646a\u4856\ua1f2\u8c22\u6245\u6daf\uaabb", "\uacde\uda38\udf22\ud91d\udfaf\ud8b2\udfd4\udace\ude17\udaef\udc93\udb38\udc48\udb68\udd5e\udbad\udcab\ud81b\udda5\udb54\udc75\udbed\udd6c\ud903\udd15\uda29\ude7f\udba2\udf2a\ud9f2\ude1a\ud8e0\udd32\udbc9\udff8\udacc\udd23\ud94b\udcc7\udb8c\ude4f\ud8f2\uddbf\udba7\udf5f\uda19\udfc9\udaa4\udf9a\uda22\udecf\uc998\udb0a\udf71\ud983\udec9\ud86d\udc95\uda43\udd7b\uda14\ude37\udb61\udc03\ud88f\udfd2\udb14\udd12\udb9c\udc08\uda92\udca3\uda98\udd15\ud828\udc97\udb19\udf3d\ud8e2\udf3b\udbbf\udd11\ud9ce\uded5\udb0e\udf7c\ud9ce\ude26\ud895\udd60\ud9e4\uddf3\udb41\udcde\uda34\udc44\ud82b\udf4f\uda14\ude65\ud894\udef6\udbda\udcfb\udac3\udce9\ud908\udca5\ud91d\udcc6\ud87d\udd25\uda51\udd41\uda7d\udc8f\udbc4\udf85\udaef\udee2\udb69\uddbe\ud9e6\udf0a\udb85\udea3\ud9f7\udd0f\ud8bd\udd96\uda8f\udcd8\ud854\uddef\u30e4\uda13\udf6d\ud950\udda9\ud843\udd7d\ud9b5\udc0e\udbe7\ude3f\ud80f\udc20\udada\uddea\uda69\udf82\ud989\udf49\uda7f\udc8b\udb09\udea8\ud9ec\udc6e\ud8b2\ude1b\ud9d0\udc0b\u8127\ud8e9\udefd\ud9d7\ude7f\ud843\ude8b\ud9e4\ude9b\ud9c3\udc11\udb0a\udc41\uda18\udf80\ud8ae\udef9\udb41\udc36",
        11, 4915, -1354542389, 5731527446466762690L, -4501L, true, true, (char) 25598, (char) 28220,
        Double.longBitsToDouble(0x3fec3b09ed5614e7L), Double.longBitsToDouble(0x3fef766bee67a41aL)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=java.util.Date:Thu Aug 02 12:58:18 PDT 31961274\0121=void\012",
        Z.run(T, 2, 7, 0, 0, "\ud899\ude31\ud855\udd02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\ud956\udffb\u1b84\udb67\udea9\udb71\ude18\udabe\udfbb\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud87f\uddf5\ud871\udcd6\ud86a\uddeb\udb00\udd11", "\ud360", "\uda82\udc3a\ud95d\udeb2\uda19\udda9\ud819\ude7e",
        45, 5, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 35918,
        Double.longBitsToDouble(0x3fd62dc42f6f4a3eL), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=java.util.Date:Thu Jun 28 12:57:33 PDT 31961274\0121=void\012",
        Z.run(T, 2, 8, 0, 0, "\ud84d\ude35\ud855\udd02\udb1e\udecf\ud997\ude81\u17b4\ud8fb\udfe8\ud97b\udc5c\ud8a0\udfcf\ud956\udffb\u1b84\ud8a4\udcd0\ud854\udc90\udabf\udc80\udb72\udc44\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud87f\uddf5\ud871\udcd6\udb09\udc13\udaf9\uddaf", "\u4657", "\uda82\udc3a\ud95d\udeb2\uda19\udda9\ud819\ude7e",
        -5, 10, 463847555, 1008538240823853508L, 285L, false, false, (char) 18900, (char) 58516,
        Double.longBitsToDouble(0x3fef0bd8a4018424L), Double.longBitsToDouble(0x3fe0073938b5d836L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 9, "\uda28\udeeb\ud92a\udf1a\udbca\udf3d\ud953\ude30\udb03\udd8e\udace\ude12\uda20\udc18\ud8bd\udeb5\ud940\udf34\udb81\udd1c\ud983\udc8e\uda77\udd9b\uda95\udc15\uda53\udc2d\ud8b2\udc8c\udb3d\udc93\ud97b\udfcd\u048b\udb1e\ude3d\ud846\uddc1\ud8b0\ude21\udaf9\udd03", "\u2bcd", "\uda81\udfcb\udb3c\udd6d\ud912\ude88\uda61\udfe0\uda94\udd3f",
        47, 42039, -1669214479, -2342802021770469226L, 66774L, false, false, (char) 35918, (char) 29092,
        Double.longBitsToDouble(0x3fdd672892da6e32L), Double.longBitsToDouble(0x3fecd4a245c1bf02L)));
  }
  @Test(timeout = 4000)
  public void test94() throws Throwable {
    assertEquals("0=java.util.Date:Thu Aug 08 12:57:33 PDT 31961275\0121=void\012",
        Z.run(T, 2, 8, 0, 15, "\ud899\ude31\ud848\udc02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\udb2f\udca7\u1c2a\udb67\udea9\ud82a\udd14\udabf\udc80\ud93b\udd47\ud864\ude81\udb14\udeca\ud8ed\ude63\udab5\udcea\ud9ee\udc82\ud871\udcd6\ud86a\uddeb\ud866\udca6", "\ud360", "\u5c9c\ud95d\udef8\uda64\udc6e\u2a8a",
        53, 12, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 60237,
        Double.longBitsToDouble(0x3fe81c27e7b7a51fL), Double.longBitsToDouble(0x3fd00e72716bb13aL)));
  }
  @Test(timeout = 4000)
  public void test95() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 15, "\ud899\ude31\ud848\udc02\udb1e\udecf\ud9af\ude8d\u17b4\ud8fb\udfe8\ud97b\udc5c\u17c2\udb2f\udca7\u1c2a\udb67\udea9\ud82a\udd14\udb9f\udccf\ud93b\udd47\ud864\ude81\udb14\udeca\udad0\uddb4\uda46\ude31\ud9ee\udc82\ud871\udcd6\ud86a\uddeb\ud866\udca6", "\ud360", "\u5c9c\ud95d\udef8\uda64\udc6e\u2a8a",
        53, 12, 944488579, 1008538240823853508L, 39965L, true, false, (char) 53733, (char) 60237,
        Double.longBitsToDouble(0x3fe81c27e7b7495cL), Double.longBitsToDouble(0x3fd00e7272b5356cL)));
  }
  @Test(timeout = 4000)
  public void test96() throws Throwable {
    assertEquals("0=java.util.Date:Mon Oct 02 21:24:42 PDT 267615426\0121=java.util.Date:Mon Oct 02 21:24:42 PDT 267615426\012",
        Z.run(T, 2, 1, 1, 10, "\uda7e\udf49\ud9e3\udd49\udaf9\ude56\ud95e\udfc9\udb90\udfd0\ud98a\udebd\ud8fc\ude31", "\u430f\u704a\ud7ed\u9010", "\ud8b8\ude28\ud80d\udd0e\udb28\udcba\ud8ca\udcdb\uda19\udca7\ud91e\ude6f\ud8b3\udc6f\ud972\udf21",
        11, 70228, -1323776367, 8445064756494282296L, -87551L, true, false, (char) 44834, (char) 15306,
        Double.longBitsToDouble(0x3fba1aa93715ef70L), Double.longBitsToDouble(0x3feeeabaf0b625a1L)));
  }
  @Test(timeout = 4000)
  public void test97() throws Throwable {
    assertEquals("0=java.util.Date:Sat May 22 13:35:50 PDT 279438528\0121=void\012",
        Z.run(T, 2, 8, 0, 0, "\ud899\ude9a\ud855\udd02\udb1e\udecf", "\ucb0b\u42ea\u17c2\ua573\uccec\ub7c5\u95b0\u71d0\u9992\u7b60\u410b\u10ad\u935b\u5dda\u203d\ua8be\ud368\u722d\u032c\ud360\ud7e4\u0efd\u1b0e\u531a\u5320\u8f85\u718e\u4710\uc33b\u8cc6\ua11d\u8445\ub814\u2b7b\u2282\u63d6\u0dc1\u3d80\uadcf\u921a\u50e8\u9402\uaf3d\u25f3\ub66a\ud7a3\u8112\u909b\u26c6\u8133\u23b4\u6c76\u92f1\ua34a\u41e2\ucc70\ua982", "\ud8d9\udc77\udb51\udd05\uda53\udd41\udbdf\udedc\udbce\uddad\udbe1\udd75\ud937\udf68\ud978\udef7\uda9e\udd69\uda5b\udf5b\ud874\udc7e\ud927\udd24\ud8e7\udec7\ud809\udde8\udbd2\udcfd\ud8c6\udf73\ud9d6\udf4d\ud8d2\udc68\uda3f\udfe8\ud9c3\udc36\udae5\udde2\ud8a9\udc3e\udacb\ude22\udae8\udc38\udbf3\udef9\u7edd\ud9c0\uddff\udb83\ude23\ud9f6\udd66\uda25\uddd5\ud8a0\udc8b\uc543\ud929\udcca",
        29, 13, 1122535446, 8818166042627750415L, -75687L, true, false, (char) 29690, (char) 41787,
        Double.longBitsToDouble(0x3fe2bd87852f39b2L), Double.longBitsToDouble(0x3fc838fd7b66d708L)));
  }
  @Test(timeout = 4000)
  public void test98() throws Throwable {
    assertEquals("0=java.util.Date:Wed Feb 07 02:19:04 PST 249791663\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 15, "\ud899\ude31\ud848\udc02", "\u05a1\ub15d\u47d1\u983e\ub44f\u2676\ub7c5\u95b0\ua79a\ucd92\u7ae3\u2efc\uc4ab\u1ed1\u9ed0\u203d\u57bc\u9f76\u808a\u88cd\ud360\ud176\u9336\u3f3c\u9323\u6efa\u7d81\ua99a\u56d0\ud35c\u8cbc\ua11d\u8445\u20d8\uc957\u2282\u17b2\u9f4d\uca44\u4e52\u3b86\u2c9d\ub118\u731b", "\udbf7\udf35\ud885\udd57\udb9f\udf78\ud8ec\ude73\ud926\uddae\ud920\udefc\udb85\udcc0\udb57\udcb6\udb4e\ude81",
        -3, 32301, -649870519, 7882601363054344516L, -36597L, false, true, (char) 35325, (char) 43146,
        Double.longBitsToDouble(0x3f9a62f233638920L), Double.longBitsToDouble(0x3fd62c5ac2fecd46L)));
  }
  @Test(timeout = 4000)
  public void test99() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 0, 0, 0, "\ud899\ude9a\ud855\udd02\ud902\udec1", "\ucb0b\u42ea\u17c2\ua573\uccec\ub7c5\u95b0\u71d0\u9992\u00f9\u410b\000\u930e\u5dda\u203d\ua8be\ud368\u722d\u032c\ud360\ud7e4\u0efd\u1b0e\u531a\u5320\u8f85\u718e\u4710\uc33b\u8cc6\ua11d\u8445\ub814\u2b7b\u2282\u63d6\u0dc1\u5e54\uadcf\u921a\u50e8\u9402\uaf3d\u25f3\u2600\ud7a3\u8112\u909b\u26c6\u8133\u23b4\u6c76\u92f1\ua34a\u6320\ucbda\ua982", "\ud8d9\udc77\udb51\udd05\021\udbdf\udedc\udbce\uddad\udb6c\uddfb\ud937\udef7\ud978\udef7\uda9e\udd69\uda5b\udf5b\ud874\udc7e\ud927\udd24\u57a0\ub1d6\udbd2\udcfd\ud8c6\udf73\ud9d6\udf4d\ud8d2\udc68\uda3f\udfe8\ud9c3\udc36\udae5\udde2\ud8a9\udc3e\udacb\ude22\udae8\udc38\udbf3\udef9\u7edd\ud9c0\uddff\udb83\ude23\ud9f6\udd66\uda25\uddd5\ud8a0\udc8b\uc543\ud929\udcca",
        29, 13, 1122535446, 8818166042627735567L, -75687L, true, false, (char) 29690, (char) 41787,
        Double.longBitsToDouble(0x3fe2bd87852f39b2L), Double.longBitsToDouble(0x3fc838fd7b66d708L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.time.DateUtils|modify|java.util.Calendar,int,boolean|static",
    "M|org.apache.commons.lang.time.DateUtils|add|java.util.Date,int,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addDays|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addHours|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMilliseconds|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMinutes|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addMonths|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addSeconds|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addWeeks|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|addYears|java.util.Date,int|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameDay|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameDay|java.util.Date,java.util.Date|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameInstant|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameInstant|java.util.Date,java.util.Date|static",
    "M|org.apache.commons.lang.time.DateUtils|isSameLocalTime|java.util.Calendar,java.util.Calendar|static",
    "M|org.apache.commons.lang.time.DateUtils|iterator|java.lang.Object,int|static",
    "M|org.apache.commons.lang.time.DateUtils|modify|java.util.Calendar,int,boolean|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
