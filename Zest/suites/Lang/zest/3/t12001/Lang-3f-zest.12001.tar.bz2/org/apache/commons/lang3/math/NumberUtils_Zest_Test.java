package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\u7d9e\udaec\udf24\udbcc\uddae\uda40\udeaa\uda95\udd79\ud934\udd1a\uda90\udf15\udbd1\udc13\ud8c3\udd19\ud961\udd09\udb32\udd04\ud98a\udda8\ud9b3\ude5c\uda60\ude20\ud8ed\uddf4\udb09\udde3\u8fb9\uda67\uddb5\udba9\udc50\ud8b1\ude58\ud861\uddee"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\udb53\udfdb\ud9be\udf61\ud8b9\udf5f\ud4fa\ud9d3\udcbe\ud9fa\udd9f\uda90\udf15\udbd1\udc13\ud8c3\udd19\ud961\udd09\ud884\udd0d\uda48\udea6\ud9b3\ude5c\udab4\udcd3\uda28\udd42\udb09\udde3\ud91f\udf0c\ud93a\udccb\ud950\udc59\ud8b1\udefd\ud861\uddee"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\udbcb\udfb4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\u7d9e\udaec\udf24\udbcc\uddae\uda40\udeaa\uda95\udd79\ud934\udd1a\uda90\udf15\udbd1\udc13\ud8c3\udd19\ud961\udd09\udb32\udd04\ud96b\udd1d\ud9b3\ude5c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udbe6\udf8b\u7d9e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb26\udd4c\ud93d\udc10\udaec\udf23\ud846\udfac\uda40\udeaa\uda95\udd79\ud934\udd1a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud84d\udf00"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb24\udcaa\udb22\udfa4\udaec\udf24\uda77\udde5\u1a26\udb2d\udd9b\udb80\udcfc\uda32\udc76\ud870\ude2d\ud87f\ude2d\udb73\ude90\uda30\udd7e\ud893\udcbb\ud8fb\udfec\ud942\udc07\ud8ed\uddf4\udb09\udde3\u8fb9\uda06\udc9b\ud855\udf21\udb9f\udd4d\udb8c\udc4e\ud9b3\udee9\udbec\udde7\ud86a\uddfc\ud9d1\udceb\ud994\udebb\udb9c\udd72\ud8e7\ude28\uda3a\udc3e\ud8bc\udec6\ud8d7\udf4b\udb2b\udf2f\ud9f6\udc78\ud910\uddb3\ud95b\udfcc\udb1d\udf62\uda7e\udeca\ud920\udc1a\udb1d\udf2a\ud809\udd6a\ud815\udf61"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\u7d9e\udaec\udf24\udbcc\uddae\uda40\udeaa\uda95\udd79\ud934\udd1a\uda90\udf15\udbd1\udc13\uda0d\udf22\udaa4\udf73\ud868\udee9\udaf9\udcfc\udab6\udfa9\ud947\udd84\udabe\udd5d\udb09\udde3\u8fb9\uda67\uddb5\udba9\udc50\ud945\udc62\u1097"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud84d\udf00\ud8fe\ude4b\udb41\udd2f\ud94a\udf57\ud893\udee4\uda64\udf61\uda96\ude5c\ud9c8\udec7\udb89\uddff\ud959\udec0\ud8de\udf4e\ud9e4\ude06\uda45\udc7a\udbd8\udd59\udb75\udced\ud903\udc51\udbf7\udf0d\ud8de\udc82\uda5e\udc17\udb58\udc49\ud84a\udfce\udbec\udeb3\ud870\udf20\ud9ce\udc37\uda85\udf17\uda16\udfed\ud856\uded7\udaa8\udf55\ud81f\udc83\udbe6\udf1f\ud9d0\udef0\uda13\udf95\ud8f8\udf4a\udb47\udf27\ud8a5\udc60\ud943\udf40\uda93\udebd\uda2f\udd24\udb7f\ude81\udb61\udfa3\udad1\udf22\ud8f1\udd01\udb10\uddcc\udb36\udeb6\ud8dd\udfe8\udbd6\udc02\ud955\ude8e\udb6e\ude7d\ud846\udd95\ud96b\ude9a\ud84e\ude9d\udb4c\uddee\ud8de\udce7\udb20\udcaa\ud820\udf18\ud99b\udd94\udaa8\udc4f\ud9f3\udec0\uda18\udee0\uda2d\udf78\udb02\udcc0\udbfd\ude85\udb30\udde8\udad4\uddab\u15a6\udbc6\udc68\ud8c9\udc57\ud9c8\udfff\uda56\ude41\ud984\uded2\ud889\ude8b\uda28\ude8f\ud839\udf6b\uda83\udcf6\uda48\udc4b\ud823\udf5b\ud881\udfa5\uda91\ude25\udb1f\udf7d\udba2\udc2d\uda7f\ude67"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\u7d9e\udaec\udf24\udbcc\uddae\udbb0\udea2\uda95\udd79\ud934\udd1a\uda90\udf15\udbd1\udc13\uda0d\udf22\udaa4\udf73e\udaf9\udcfc\udb86\udd11\000\000\000\u8f2b\uc55b\ud92c\udf76\ud945\udc62\u1097"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud84d\udf00\ud8fe\ude4b\u3c97\000\ud863\ude90\uda64\udf61\uda96\ude5c\ud9c8\udec7\udb89\uddffE\000\ud9e4\ude06\uda45\udc7a\udbd8\udd59\udb75\udced\ud903\udc51\udbf7\udf0d\ud8de\udc82\uda5e\udc17\udb58\udc49\ud84a\udfce\udbec\udeb3\ud870\udf20\ud9ce\udc37\uda85\udf17\uda16\udfed\udb54\uded6\udaa8\udf55\ud81f\udc83\udbe6\udf1f\ud9d0\udef0\uda13\udf95\ud8f8\udf4a\udb47\udf27\ud8a5\udc60\ud943\udf40\uda93\udebd\uda2f\udd24\udb7f\ude81\udb61\udfa3\udad1\udf22\ud8f1\udd01\udb10\uddcc\udb36\udeb6\ud8dd\udfe8\udbd6\udc02\ud955\ude8e\udb6e\ude7d\ud846\udd95\ud96b\ude9a\ud84e\ude9d\udb4c\uddee\ud8de\udce7\udb20\udcaa\ud820\udf18\ud99b\udd94\udaa8\udc4f\ud9f3\udec0\uda18\udee0\uda2d\udf78\udb02\udcc0\udbfd\ude85\udb30\udde8\udad4\uddab\u15a6\uda57\uded1\000\000\ud836\udf7a\ud984\uded2\ud889\ude8b\uda28\ude8f\ud839\udf6b\uda83\udcf6\uda48\udc4b\ud823\udf5b\u1b08\uda91\ude25\udb1f\udf7d\udba2\udc2d\uda7f\ude67"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\u7d9e\udaec\udf24\ud9c5\udc6c\ud8e0\udfd7\uda95\udd79\ud934\udd1a\uda90\udf15\udbd1\udc13\uda0d\udf22\udaa4\udf73e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda9f\ude7a\u7dbe\uda1f\udfd3\udbcc\uddae\udb80\uddd8\udae9\udee3\ud93a\uddd7\uda90\udfc4\udbd1\udc13\ud8a4\udd2e\ud8a3\udd03\ud8fb\udd64\udb0e\udd47\ud8ce\udcc0\ud88b\udd99.\ud8b5\udd99\ud8d2\udde6\uc55b\u8390\ud94e\uddfb\ud8c5\udc86"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\u7d9e\udac1\ude5b\ue738\ud91d\udefd\uda95\udd46\ud934\udd1a\uda90\udf15\udbd1\udc13\uda0d\udf22\udaa4\udf73.\udaf9\udcfc\udb86\udd11\000\ud923\udee3\u0081\u8f2b\uc55b\ud92c\udf76\ud945\udc62\u1097"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda9f\ude7a\u7dbe\uda1f\udfd3\udbcc\uddae\udb80\uddd8\udae9\udee3\ud93a\uddd7\uda90\udfc4\udbd1\udc13\ud8a4\udd2e\ud8a3\udd03\ud8fb\udd64\udb0e\udd47\ud8ce\udcc0\ud88b\udd99."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud8ec\udde8\ud803\udd00\udac1\ude5b\ue738\ud91d\udefd\uda95\udd46\udac8\udcc3\uda90\udf15\udbd1\udc13\uda0d\udf22\udaa4\udf73.\udaf9\udcfc\udb86\udd11\000\ud923\udee3\uda26\ude14\ud808\udd8f\uc55b\ud92c\udf76\ud945\udc62\u1097"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9dc\udf12\u7d96\udaec\udf24\udbcc\uddae\uda40\udeaa\uda95\udd79\ud934\udd1a\uda90\udf15\udbd1\udc13\ud905\udd1a\ud961\udd09\udb32\udd04\ud98a\udda8\ud9b3\ude5c\uda60\ude20\ud8ed\uddf4\udb09\udde3\u8fb9\uda67\uddb5\udba9\udc50\ud8b1\ude58\ud861\uddee"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud8e4\uddab\udad2\uddff\ud9e7\ude78\ue738\ud91d\udefd\udb21\udcab\ud932\udef5\uda90\udf15\udbd1\udc13\ud9e6\udf22\udaa4\udf73.\udaf9\udcfc\udb86\udd11\uda11\udf32\ud8bc\udf78E\u8f2b\ufa5b\ud92c\udf76\ud909\ude43\ud830\udfb5"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda9f\ude7a\u7dbe\uda1f\udfd3\udbcc\uddae\udb80\uddd8\udae9\udee3\ud93a\uddd7\uda90\udfc4\udbd1\udc13\ud8a4\udd2e\ud8a3\udd03\ud8fb\udd64\udb0e\udd47\ud9bf\udfed\udbdd\uddc0l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda0d\udf84\ud8ac\udd81\uda1f\udfd3\udbcc\uddae\ud9bd\udd36\udbf6\uddf8\uda1c\uddb9\ud8b7\udd58\udbd0\udf95\ud8a4\udd2e\uda24\udfe4\ud868\udfec\ud90f\udd16\ud91e\udf9c\udbdb\udda1f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9d3\udfa6\ud858\ude20\ud801\udc1f\udac6\udfc3\ud9bd\udd34\udbf6\uddf8\uda1c\uddb9\ud915\udd67\udbc5\udd43\ud8a4\udd2e\uda24\udfe4\udb02\udf7f\ud90f\udce1\ud92a\ude9c\ud952\udebcF"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9d3\udfa6\udb99\udc22\ud801\udc1f\udac6\udfc3\ud9bd\udd34\udbf6\uddf8\udb8e\udc63\ud915\udcd3\ud83b\udc49\ud8a4\udd2e\uda24\udfe4\udb02\udf7f\ud90f\udce1\udb0a\udd8c\udaed\udeb8D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9d3\udfa6\udb99\udc22\ud801\udc1f\udac6\udfc3\ud9bd\udd34\udbf6\uddf8\ud9f3\udfa9\ud915\udcd3\ud83b\udc49\ud8a4\udd2e\uda24\udfe4\udb02\udf7f\ud90f\udce1\udb0a\udd8c\u0eafd"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud84d\udf00\ud8fe\ude4b\u3c97\000\ud802\ude93\uda64\udf61\ud8c6\ude95\udb55\udd17\udb89\uddffE\000\ud9e4\ude06\ud941\udfb8\udbd8\udd0f\udb75\udced\ud903\udc51\udbf7\udf0d\ud9c4\udd55\ud9d3\udf4b\udb58\udc4a\udac6\ude91\udbec\udeb7\ud870\udf20\ud9ce\udc37\uda85\udf17\uda16\udfed\udb54\uded6\udaa8\udf55\ud81f\udc83\udbe6\udf1f\ud9d0\udef0\uda13\udf95\ud8f8\ude9b\udb47\udf27\ud8a5\udc60\udabb\ude1d\uda6f\udfa0\uda2f\udd24\ud821\ude4d\udb61\udf52\udad1\udf22\ud8f1\udd01\udb10\uddcc\udb36\udeb6\ud8dd\udfe8\udbd6\udc02\ud955\ude8e\udb6e\ude7d\ud846\udd95\ud96b\ude9a\ud84e\ude9d\udb4c\uddee\ud8de\udce7\udb20\udcaa\ud820\udf18\ud99b\udd94\udaa8\udc4f\ud9f3\udec0\uda18\udee0\uda2d\udf78\udb02\udcc0\ud98e\udd29\udbd2\udf33\udad4\uddab\u15a6\uda57\uded1\000\000\ud836\udf7a\ud984\uded2\udae4\udcf8\uda22\udf18\u2f1a\ud900\ude52\uda1f\udd43\udb11\udf0e\ud9b1\udd31\ud8b7\udc94\ud8c0\udf32\udac6\udd60\uda7f\ude66\ud8f8\udf3d\ud91c\udd3d\udbc2\udff6\udaba\udf48\ud9da\ude0d\ud91a\udc56\ud9fe\udf62\uda85\udec6\udae7\ude44\ud8c8\udcdb\ud873\uddc5\udaa1\ude82\u57e5\ud85a\udc2f\udb50\ude5a\ud8d3\udeee\udb92\uddb0\u1d07\udbaf\udc24\u8d17\uda10\udf81\udbec\udde0\udb8b\udf6f\uda44\udeea\ud8eb\udec2\udac0\ude2a\ud9d9\udf60\ud92e\udc5d\udbef\udcb6\ud978\udfbb\ud8a4\udc4a\udaf8\udc93\udbb0\udc64\udb33\uddec\ud85f\udf95\ud81e\udf21\uda7a\udc0e\uda47\udc3f\udba4\ude82\ud90c\udf54\udae5\udf83\ud854\udca4\ud811\udd20\udb7c\udd35\udb75\udca1\udb72\udf83\ud930\udc4c\udbf1\uded8\udbdd\udc98"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u2001"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9d3\udfa6\udb99\udc22\ud801\udc1f\udac6\udfc3\ud9bd\udd34\ud8de\udc1a\udaaf\udec7\ud915\udcd3\ud83b\udc49\ud8a4\udd2e\uda24\udfe4\udb02\udf7f\ud90f\udce1\uda85\udee9\ud923\ude7eL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("7");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\u7d9e\udaec\udf24\udbcc\uddae\udbb0\udea2\udb81\udfbb\ud934\udd1a\uda90\udf15\udbd1\udc13\udbc3\udd5d\udaa4\udf67e\udaf9\udcfc\uda01\udc0f\uda99\udfa4E\000\u8f2b\uc55b\ud92c\udf76\ud945\udc62\u1097"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud84d\udf00\ud937\udcbe\u3cbd\000\ud802\ude93\uda64\udf61\ud8c6\ude95\udb55\udd3f\udb89\uddff\u00a2\000\ud9e4\ude06\ud808\udce6\ud984\udd51\udb75\udc79\ud903\udc51\udbf7\udf0d\ud9c4\udd55\ud9d3\udf4b\udb58\udc4a\udac6\ude91\udbec\udeb7\ud870\udf20\ud9ce\udc37\uda85\udf17\uda16\udfed\udb54\uded6\udaa8\udf55\ud81f\udc83\udbe6\udf1f\ud9d0\udef0\uda13\udf95\ud8f8\ude9b\udb47\udf27\ud8a5\udc60\udabb\ude1d\uda6f\udfa0\uda2f\udd24\ud98f\udfe4\udbd4\udfd7\udadd\uddf7\ud8f1\udd01\udb10\uddcc\udb36\udeb6\ud8dd\udfe8\udbb5\udc02\ud955\ude8e\udb6e\ude7d\ud846\udd95\ud96b\ude9a\ud87d\udc81\udb4c\uddee\ud8de\udce7\udb20\udcaa\ud820\udf18\ud99b\udd5d\udaa8\udc4f\ud9f3\udec0\uda7c\udf73\uda2e\udc20\udb02\udcc0\ud98e\udd29\udbd2\udf33\udad4\uddab\u15a6\uda57\uded1\000\000\ud836\udf7a\ud984\uded2\udba9\udfbb\udaa8\udef6\u2f1a\ud900\ude52\uda1f\udd43\udb11\udf0e\ud9b1\udd31\ud8b7\udc94\ud8c0\udf32\udac6\udd60\uda7f\ude66\ud8f8\udf3d\ud91c\udd3d\udbc2\udff6\uda5f\udd01\ud9da\ude8f\ud91a\udc56\udbe4\ude74\uda85\udec6\udae7\ude44\ud8c8\udcdb\udb2a\udca0\udbb2\udf54\udb47\udeb4\ud869\ude6a\udb50\ude5a\ud8d3\udeee\udb92\uddb0\u1d07\udbaf\udc24\u8d17\uda10\udf81\uda05\udc4c\udb99\uddae\uda44\udeea\ud8eb\udec2\udac0\ude2a\ud9d9\udf60\ud92e\udc5d\udbef\udcb6\ud978\udfbb\uda1d\udef4\ud834\udd26\uda57\udfa4\udb1a\uddf9\ud85f\udf95\ud81e\udf21\u4824\uda47\udc3f\udba4\ude82\ud90c\udf54\udae5\udf83\ud854\udca4\ud811\udd20\udb7c\udd35\udb75\udca1\udb72\udf83\ud930\udc4c\udbf1\uded8\udbdd\udc98\udb75\udca4\uda60\uddd2\ud91f\udc07\ud889\uddb7\uda7d\ude58\udb5a\ude0b\udb06\udd97\uda6f\udf05\udb6f\udefc\ud8b1\ude65\udaa7\udd74\ud9e6\udd41\udb7a\udfc6\u4286\ud839\udd32\udb03\udce3\ud82b\udd0b\ud918\udf41\udaf2\udd0f\ud96e\udef2\ud873\udfd5\uda2c\udd96\u3aa2\ud80c\udc5e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud845\udd7c\u7d9e\ud874\udc89\udbcc\uddae\udbb0\udea2\ud9b1\udfb3\ud934\udd1a\uda90\udf15\udbd1\udc13\uda0d\ude28\ud935\udd27e\ud9bc\udc5c\uda01\udc0f\ud9e4\udc0a\ud8e9\udd23.\udb8c\udc6c\ud909\udfec\ud903\udd38\udbd2\udd9f\ud941\udeff"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("l"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#\udbbe\udd23"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#\udbbe\udd23\ud878\udc5a\udac6\udc49\udaaf\udfc3\uda94\udf41\udb79\udf3c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#\udbbe\udd23\ud9ba\udecc\udb6f\udd93\uf8f8\udabf\udd4b\udbf6\udc50\uda63\udd3e\udbbd\udce0\uda5f\udd93\udbdf\udd9b\uda55\udc32\ud930\ude06\udae7\udc83\udbb8\ude70\ud93e\udeef"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udaa3\udd8b\ud9dc\ude7d\udadd\ude43\udb26\ude24\uda40\ude3c\ue18a\udbb4\ude08\ud9ba\udcca\udbd1\udc13\udb2b\udccd\ud985\udeb8\udad4\udc13\udafe\udeab\udb13\udf30\uda60\udde3\ud967\ude2f\ueeb3\u7573\uda32\udf52\udba8\udf92\ud8b1\ude58\ud861\uddee"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u2001\ud8ac\udd09\uda1f\udfd3\udbcc\uddae\ud9bd\udd36\udbf6\uddf8\uda1c\uddb9\ud8b7\udd58\udbd0\udf95\ud8a4\udd2e\uda24\udfe4\ud868\udfec\ud90f\udd16\ud91e\udf9c\udbdb\udda1f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
}
