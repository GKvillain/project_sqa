package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda3b\ude17\udb4c\ude4e\ud8c6\ude8b\udb83\ude5f\udb92\ude9f\ud96f\ude7b\u62b0\udb5a\udc4c\ud94a\udddc\udb55\ude3f\udba3\udf67\udbec\udd90\ud808\udfb0\ud9da\udd2f\ud92f\udc98\ud98d\udcae\ud939\udfcc\udbe0\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda3b\ude17\udb4c\ude4e\ud856\ude93\udb83\ude5f\uda30\uddf4\ud967\udf7d\ud9f1\udc23\udb5a\udc4c\ud94a\udddc\udb55\ude3f\udba3\udf67\udbec\udd90\ud808\udfb0\ud9da\udd2f\ud92f\udc98\ud98c\udffe\ud939\udfcc\udbe0\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda3b\ude17\udb4c\ude4e\ud8c6\ude8b\udb83\ude5f\udb92\ude9f\ud96f\ude7b\u62b0\udb5a\udc4c\uda58\udf86\udb55\ude3f\udba3\udf67\udbec\udd90\ud808\udfb0\ud94a\ude34"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb40\udfc5"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud8f4\udcf5\ud8dc\udfeb"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda3b\ude17\udbfc\udd51\ud8b6\uddfc\udb83\udea2\ud9eb\udd22\ud96f\ude7b\ud859\udfee\ud80e\udd8a\ud803\udd8b\udbfc\ude1a\udba3\udf67\ud9cb\udf46\ud83a\udd11\ud9da\udd2f\ud92f\udc98\udbad\udfbe\udbae\udd2b\u0f20"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda3b\ude17\udb4c\ude4e\ud8c6\ude8b\udb83\ude5f\udb92\ude9f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda3b\ude17\udb4c\ude4e\ud8c6\ude8b\udb83\ude5f\ud9f0\udf9e\ud96f\ude7b\u62b0\ud918\udf2c\udac7\udecd\udbc7\udf63\udba1\uddbe\udbec\udd90\uda5b\udc64\ud855\udf2b\ud9c7\udfa7\udba7\udefa\udabd\udf61\ud83d\udd10\ud868\uded1\u05df\u48ce\ud82c\uddc1\uda84\udfda\ud907\ude8e\udb94\udc29\udb0d\udc2d\uda2e\ude92\udbb1\udd41\udb5f\udc4a\udac8\udff1\uda20\udce8\udbcf\ude02\ud952\ude52\ud84a\udedc\udbb1\udc90\udae9\ude40\ud995\udd05\ud9f2\udfd2\ud9b7\udfe2\uda24\udd8e\ud8e9\udd09\udbd4\udd6c\ud8aa\udefe"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\035\udb4c\ude4e\ud8c6\ude8b\uf53b\000\ud96f\ude7b\u62b0\udb5a\udc4c\ud94a\udddc\udb55\ude3f\udba3\udf67\udbec\udd90\ud808\udfb0\ud9da\udd2f\ud92f\udc98\ud98d\udcae\ud939\udfcc\udbe0\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\035"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(".\udb4c\ude4e\ud8c6\ude8b\uf53b\000\ud96f\ude7b\u62b0\udb5a\udc4c\ud94a\udddc\udb55\ude3f\udba3\udf67\udbbc\udd8e\ud808\udfd9\u4fb7\ud92f\udded\ud98d\udcae\udb4d\udfd6\udbe0\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e\ud849\udfaf\ud986\udedb\ud9f0\udf61\udb00\udf2e\ud9fc\udcd6\ud809\uded2"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("\ua8d8");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud934\udc82\ud96f\ude4a\ud8d3\udee6\ud89f\uddb9\udb00\udf2e\uda62\ude4e\ud8f6\ude00\ud924\uddd6\ud9d0\udd6d\ud8a2\udda7\udbfe\udef5\uc40f\uda06\udc78\udbab\udf54\ud8de\udf34\ud976\udf7d\ud95a\udebf\udb72\udc03\udb9b\udd1e\uc582\udaa8\udc92\ud801\udffe\u520c\ud9e9\udd37\ub015\udbcf\udd99\uda59\udc58\udbab\udde2\uda32\ude17\ud8fd\udfba\ud80b\uded1\ud9c8\udf96\ud8b4\udfb4\ud950\ude26\ud8a1\udf2d\ud8da\udf2d\ud8da\ude7d\udbc8\udcf9\udb0a\uddb4\udbfc\udd78\ud894\udc04\uda69\udfc8\ucb3a\udb9c\udc87\ud881\udc83\udaeb\udfb7\udb3a\udf36\ud956\udf71\udb5b\udf8a\u3a78\ud824\udd86\ud869\udf8f\uda17\udc7e\ud9ac\udc9d\ud82f\udf9f\ud846\udcd8\udbf8\udcef\uda72\ude7d\ud93e\ude40\ud968\udf86\ud8b9\udc8b\udb67\udcc4\uda45\ude70\uda66\udfbd\ud8d0\udffd\ud953\udecd\uda83\ude64\udb9e\ude53\ud84a\udd3e\udb4c\udccc\uda22\uddfd\ud836\udd08\ud8cc\ude98\u6201"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud945\ude1b\udb4c\uddc7\ud8c6\ude8b\udb83\ude5f\udb92\ude9f\ud96f\ude7b\u62b0\udb5a\udc4c\ud94a\udddc\ud93a\uddb3\udba3\udf67\udbec\udd90\ud808\udfb0\ud9da\udd2f\ud92f\udc98\ud98d\udcae\ud939\udfcc\udbe0\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#\ud9da\udf8a\ud986\udedb\ud81e\udcf1\uda09\udf87\uda21\udfc8\uda93\udf84\udaff\udc95"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000\000f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#\ud9da\udf8a\ud986\udedb"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("#\ud9da\udf8a\ud986\udedb\udb72\uddb9\uda09\udf87\uda21\udfc8\uda93\udf84\udaff\udc95\ud865\udec0\ud897\ude6d\udbd1\udf93\ud9dc\udfbb\ud91e\udca4\udba7\udde3\ud929\udf10\ud90c\ude01\udbd7\ude50"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\012\000f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000\ud9ca\udde1L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000\ud8dd\udf15l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("8\ud8dd\udf15l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(".\udb4c\ude4e\ud8c6\ude8b\udb20\udd69E\ud96f\ude7b\u62b0\udb5a\udc4c\ud94a\udddc\udb5d\ude3f\udba3\udf67\udbbc\udd8e\ud808\udfd9\u4fb7\ud92f\udded\ud853\udd24\udb4d\udf7f\udbe0\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("l"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e\ud8dd\udf15l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda5e\udd7d\udad6\udfb3\ud8d1\udd05\ud929\ude75\ud99c\udf67\uda05\udda9\u38af\udb4e\udfd2\ud860\ude23\udaea\udea0\ud935\udec8\udbec\udd90\ud808\udfb0\ud9da\udd2f\ud92f\udc98\ud98d\udcae\ud939\udfcc\ud8eb\udf8b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(".\udb86\udc01l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("7\000f");
    assertNotNull(r);
    assertEquals("java.lang.Float", r.getClass().getName());
    assertEquals("7.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda3b\ude17\udb4c\ude4e\ud8c6\ude8b\udb83\ude5f\udb92\ude9f\ud96f\ude7b\u62b0\udb5a\udc4c\ud94a\udddc\udb55\ude3f\udba3\udf67\uaf10\u8c28\ud9da\udd2f\udb17\udc8c\ud98d\udcae\ud939\udfcc\udbe0\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e\ud8b3\udf83\ud986\udedb\ud9f0\udf61\udb00\udfcd\ud8f4\udcfa\ud822\ude74\uda85\uded6\u42c2\udb6d\udfb1\ud8d5\udcc3\ud8b2\udc89\u3a2f\u19d9"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(".\ud89c\udcc1\ud986\udedb\ud937\udcc5\ud9bb\udc44\ud8f4\udcfa\ud822\ude74\uda85\uded6\u42c2\udb6d\udfb1\ud8d5\udcc3\ud8b2\udc89\u3a2f\u19d9"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("\uff10");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("7D");
    assertNotNull(r);
    assertEquals("java.lang.Double", r.getClass().getName());
    assertEquals("7.0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("-\ud9ca\udde1L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("0\ud8b3\udf83\ud986\udedb\ud9f0\udf61\udb00\udfcd\ud8f4\udcfa\ud822\ude74\ud928\ude67\u42c2\udb6d\udfb1\ud8d5\udcc3\ud8b2\udc89\u3a2f\u19d9"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
