package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class SystemUtils_Zest_Test {
  @Test
  public void test0() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test0() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u438a\u4c63\u049d\u4399\u9d78\u9191\u8685\u7917\uc1cb\u6dbc\u3cd2\u0691\u5e9f\u00b8\u2f9c\uc8bb\u4a47", "\ud836\udf1a\ud89a\udc5c",
//         11, 8799, 104400683, -5700610191384614431L, 79787L, true, false, (char) 31451, (char) 58520,
//         Double.longBitsToDouble(0x3fd692291f8e5faaL), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
//   }
  @Test
  public void test1() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test1() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud9ca\udceb\ud9c2\ude45\udb71\uded8\uda60\udf77", "\u438a\u4c63\u049d\u4399\u9d78\u9191\u8685\u7917\u7842\uae8f\u3cd2\u0691\u5e9f\u00b8\u2f9c\uc8bb\u4a47", "\ud836\udf1a\ud89a\udc5c",
//         11, 8799, 104400683, -5700610191384614431L, 79787L, true, false, (char) 31451, (char) 58520,
//         Double.longBitsToDouble(0x3fd692291f8e5faaL), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
//   }
  @Test
  public void test2() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test2() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud966\udc58", "\uc40e\u41ff", "\u88db\uda00\udff4\ud9cd\udf52\ud995\udc32\udbd3\udebd\ud861\udf6f\ud8fe\udcfe\udb72\udd29\udaa0\udc9a\ud834\udd53\u9e9f\ud9a1\udd6e\ud904\udc11\udbb4\udd21\udb42\uded2\uda8b\udd22\ud9d9\uddd9\udbd7\uddfe\udb69\udf51",
//         16, 11906, 2075761799, 448397517837786428L, 71260L, true, true, (char) 49102, (char) 63194,
//         Double.longBitsToDouble(0x3fe0b82d01692291L), Double.longBitsToDouble(0x3fe18237e4ca74a2L)));
//   }
  @Test
  public void test3() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test3() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u438a\u4c63\u049d\u4399\u9d78\uadae\ubd0d\uc45d\u3552\u6dbc\u3cd2\u0691\u5e9f\u00b8\u2f9c\uc8bb\u4a47\ubea8\ua93f\ucc6a\u05f8\u020e\ua72a\u0e8b\u5f78\ua1a3\ucd15\ub936", "\uda0c\udd20\uda81\udc3a\udbf4\ude09\uda29\udf10\uda6a\udf16",
//         35, 88116, 45039730, -2166469674416961867L, 56735L, true, true, (char) 11167, (char) 23647,
//         Double.longBitsToDouble(0x3feea45ac989477aL), Double.longBitsToDouble(0x3fed2bbd5be9aad6L)));
//   }
  @Test
  public void test4() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test4() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\ud940\udc88\ud95e\uded8\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u5a9d\u4c63\u049d\u4489", "\udb13\udef8\udbfe\udcfe",
//         16, 59072, -1973794750, 5626625432668206109L, 80320L, true, false, (char) 51736, (char) 48890,
//         Double.longBitsToDouble(0x3fdd3b485b8e6446L), Double.longBitsToDouble(0x3fa7e8635e616d60L)));
//   }
  @Test
  public void test5() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test5() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u5a74\u4c63\u049d\u4399\u9d78\u9191\u8685\u7917\uc1cb\u6dbc\u3cd2\u0691\u5e9f\u00b8\u2f9c\uc8bb\u4a47", "\ud836\udf1a\ud89a\udc5c",
//         11, 47519, 104400674, -5700610191384614431L, 79787L, true, false, (char) 31451, (char) 58520,
//         Double.longBitsToDouble(0x3fd372291f8e5faaL), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
//   }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 14, 1, 1, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u438a\u4c63\u049d\ua9a4\u9d78\u9191\u8685\u7917\uc1cb\u6dbc\u3cd2\u0691\u5e9f\u00b8\u2f9c\uc8bb\u4a47", "\ud836\udf1a\ud89a\udc5c",
        11, 8799, 104400683, -5700659274270873119L, 79787L, true, false, (char) 11734, (char) 58520,
        Double.longBitsToDouble(0x3fd692291f8e5faaL), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
  }
  @Test
  public void test7() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test7() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8c5\udf5a\udb71\udee4\udbbf\udc19\ud9fb\udff0\u0477\ud9e3\udf0d\u88db\uda7e\ude6d\uda02\udd3e\ud995\udc32\udbd3\udebd\uda79\ude75\udbfe\udcfe\udb72\udd29\udaa0\udc9a", "\u5e9f\u00b8\u2f9c\uc8bb\u4a47\ubea8\ua93f\ucc6a\u05f8", "\udb7d\udf88\ud9c4\udc92\ud9b2\udcac\udaaf\udfef\ueda9\ud96d\udfdf\ud839\uddbb\ud8c8\udc3e\uda81\udc07\udbf4\ude09\uda29\udf10\ud98a\udca5\uece4\udb54\udee7\udad1\udf27\ud88d\uddc2\udab6\ude24\ud928\udf2d\udbcf\udf12\ud8cd\udc3d\ud94b\uddf3\ufc6f\udb5b\udea6\uda67\udeae\ud845\udd6a\u6c03",
//         42, 87679, -1187753285, -2926023320025574806L, -12670L, false, false, (char) 2765, (char) 35342,
//         Double.longBitsToDouble(0x3fcfd278fc10b260L), Double.longBitsToDouble(0x3fe6e4195b6b497cL)));
//   }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 14, "\udb46\ude62\ud9f0\udcdd\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\ua35a\ud4e5\ub60a\u4399\u9d78\uc8b2\u8685\u5c75\uc1cb\u9adb\ub575\u0691\u5e9f\uaf21\u2cb1\uc8bb\u4a47\ubea8\ua93f\u34d3\u05f8\u020e\uc332\u1f05\u4e64\ua1a3\ucd15\u3775", "\ud8af\udf58\ud981\udf38\ud84b\udd0a\ud920\udfcc\ud9c6\udd55",
        11, 19190, 978334756, 2291813409624748711L, 69232L, true, true, (char) 23575, (char) 14087,
        Double.longBitsToDouble(0x3fdff268b6e943acL), Double.longBitsToDouble(0x3fe6e6429adf61acL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 5, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u438a\u4c63\u049d\u4399\u9d78\u9191\u8685\u7917\uc1cb\u6dbc\u3cd2\u0691\u5e9f\u00b8\u2f9c\uc8bb\u4a47", "\ud836\udf1a\ud89a\udc5c",
        11, 8799, 104400683, -5700610191384614431L, 79787L, true, false, (char) 31451, (char) 58520,
        Double.longBitsToDouble(0x3fd692291f8e5faaL), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 2, "\udbb1\udc73\ud939\ude40\ud928\ude70\udb71\udee4\udbbf\udc19\ud9fb\udff0\u0477\ud9e3\udf0d\u88db\uda00\udff4\ud9cd\udf52\ud995\udc32\udbd3\udebd\u74e8\udbef\ude2b\udb72\udd29\udaa0\udc9a\ud834\udd3e\u9e9f\ud9a1\udd6e\ud904\udc11\udbb4\udd21\udb28\udde2\ud96d\udc73\ud8fc\udfab\ud8e4\udec6\uac93\ud992\udf27\ud922\udcf9\uda3f\udc46\udb7d\udf88\ud9c4\udc92\ud9a1\ude34\udaaf\udfef\ueda9\ud96d\udfdf\ud839\uddbb\uda0c\udd20\uda81\udc3a", "\u03a3\u5fac\u32b7\u1910\u9944\u3dec\u3a8e\ubfb3\u82db", "\u4c4f\ud828\udfd9",
        5, 79786, -542768982, 7350479827054042840L, -67199L, false, false, (char) 41592, (char) 39528,
        Double.longBitsToDouble(0x3fc27934209753d0L), Double.longBitsToDouble(0x3fda88e9acc2d1faL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Float:11.032\012",
        Z.run(T, 1, 3, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\ud82b\udf9b\udbbf\udca1", "\u438a\u4c63\u049d\u78dc\u9ce4\u9191\u8685\u7917\uc1cb\ucdbc\u3cd2\u0691\u5e9f\u00b8\u66aa\uc8bb\u4a47", "\ud836\udf1a\ud89a\udc5c",
        11, 18671, 103976959, -5700610191384614431L, 79787L, true, false, (char) 31451, (char) 58520,
        Double.longBitsToDouble(0x3fd692291f8e5faaL), Double.longBitsToDouble(0x3f804c4b754cde40L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 0, 14, 2, "\000\000\000\000\udbbb\udebd", "\u188a", "\ud9cd\udf52\000\udb3e\udd0c\uda59\udc08\000\000\udabf\udd3e\u4842\ud8f6\ude06",
        17, 39294, 14336096, 0L, -70771L, true, true, (char) 21393, (char) 17854,
        Double.longBitsToDouble(0x3fc0fa76fcadeee4L), Double.longBitsToDouble(0x3e2e1b0000000000L)));
  }
  @Test
  public void test13() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test13() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 0, 2, "\udb3f\udc3d\ud966\udc58\000", "\ubacb\u7fcd\001\u485d", "\ud994\udf64",
//         30, 69077, -951927721, -5077802734396431536L, -48288L, false, false, (char) 16214, (char) 12954,
//         Double.longBitsToDouble(0x3fe46866d141b0d7L), Double.longBitsToDouble(0x3e474c0000000000L)));
//   }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 8, 11, 2, "\udb3f\udc3d\ud955\udc60\ud8af\udd5a\udb71\udee4\udbd7\udc19", "\u4473\u4c63\u049d\u4431\u9d29\u9191\u8685\u7917\uc1cb\u95e5\u3d0c\u0691\u5e9f\u00b8\u2f9c\u334b\u4a47\ub144\ua952\ucc6a\u05f8\u749e\u02e1\u0eaf\u5f78\ua1a3\ucd15\ub936\ua412\ub174\u543f\ud355\u1674\u4109\u176d\ubc75\ubf9e\u50fe\u616c\u8cc1\u8eed\u0140\u0709\u806b\u3832\u5273\uaf3c\ud1ff\u53d2\u0f1f\u442a\u9faf\u7997", "\ud8ed\uddc9\ue394\udb5e\udc03\uda72\udee0\ud85c\uddb0",
        -2, 99073, 682083919, -283187418194851475L, -99761L, false, true, (char) 42963, (char) 16029,
        Double.longBitsToDouble(0x3fdb116591bc8f9aL), Double.longBitsToDouble(0x3fea0c67c86b82dbL)));
  }
  @Test
  public void test15() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test15() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 9, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udad0\udf82\uda07\udf22", "\u438a", "\ud996\udc3f",
//         59, 60775, 596778077, -3512037678729657007L, 95138L, true, false, (char) 16946, (char) 16307,
//         Double.longBitsToDouble(0x3fb81c8eb46866d0L), Double.longBitsToDouble(0x3fd03b0d75fa6dbaL)));
//   }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 14, 2, "\udb3f\udc3d\ud966\udc58\ud9ef\ude3a\udb71\udee4\udbbf\udc19", "\u438a\u0958\uad99\u4719\u8b6e\u6991\u8685\u7917\u865f\uc8b9\u3cd2\u7b9a\u0a14\u00b8\u2f9c\uc8bb\u865b", "\ud836\udf1a\udad7\udf5b",
        -3, 27979, -2098431775, -5700610049985582623L, 85418L, true, false, (char) 31451, (char) 58520,
        Double.longBitsToDouble(0x3fba48a474a96048L), Double.longBitsToDouble(0x3f804c32b48cde40L)));
  }
  @Test
  public void test17() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test17() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udf5a\uda13\udc83", "\uabd6\u5e83\u65fe\u4399\uadf4\u168f\u8685\u7917\uc1cb\u6dbc\u3cd2\u80c2\u6d73\u00b8\u2f9c\u6024\u4ac5\ubea8\ua93f\u1a0c\u0663\u616c\ua6f8\u0e8b\u5f78\u863b\ucd15\ub936\ua412\u63ef\uc80f\u521a\u4543\uc109\u8d8b\u2c24\ua3b4\u2397\u2170\u11cf\u329d\u990d\u5c1f\u219b\uaee8\u86a0\u10ba\u2d25\u3dba\u9b69\uac44\ub3a6\u01ba\ucba0\ubea7\uc0ce\u2857\u8b24\u2bb7", "\ud8b9\udfdb",
//         14, 99596, -1866432542, -8434324523466101779L, -33496L, false, false, (char) 64868, (char) 38801,
//         Double.longBitsToDouble(0x3fb85c8c0d2db258L), Double.longBitsToDouble(0x3fea99a73bb7da8eL)));
//   }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:11.0.32.1\012",
        Z.run(T, 1, 6, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u438a\u4c63\u049d\u4399\u9d78\u9191\u8685\u7917\uc1cb\u6dbc\u3cd2\u3ec4\u5f51\u00b8\u2f9c\uc8bb\u4a47", "\ud836\udf1a\ud89a\udc5c",
        11, 8799, 104400683, 7023466132689217771L, 79787L, true, false, (char) 31451, (char) 58566,
        Double.longBitsToDouble(0x3fd6992c6f8e5faaL), Double.longBitsToDouble(0x3f804cc0c0e07f80L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 7, 11, 2, "\udb3f\udc3d\ud813\udce6\ud8af\udc87\udb71\udee4\udbbf\udc19", "\u13c1\u4c63\u54bd\ucdd4\022\uaea8\ub4a7\u97a6\u7087\u6e07\uac4e\u4d63\u6593\u45eb\ubd7f\ub62c\u4a47", "\ua4ae\u2c9d",
        52, 95414, 1664681771, 350770614376360417L, 79787L, true, true, (char) 23641, (char) 17665,
        Double.longBitsToDouble(0x3fe4c385c1c72fadL), Double.longBitsToDouble(0x3fd9064095a4670aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:1132\012",
        Z.run(T, 1, 4, 11, 9, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u438a\u4c63\u049d\u4399\u9d78\u9191\u8685\u7917\uc1cb\u6dbc\u3cd2\u06fd\u5e9f\u00b8\u2f9c\uc8bb\u4a47", "\uda8e\ude44\ud899\udee0",
        11, 8799, 104400683, -5700610191384614431L, -21096L, true, true, (char) 31451, (char) 58520,
        Double.longBitsToDouble(0x3fd692291f8e5faaL), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
  }
  @Test
  public void test21() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test21() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\0121=java.lang.Boolean:false\012",
//         Z.run(T, 2, 10, 7, 2, "\ud82d\udddf\ud96f\uddc8\ud8c5\udd08\ud9d8\udff8\uda5e\udfee\ud9f7\uddec\ud913\udc7f\ud9e3\udf0d\ud94c\udf2f\uda00\udff4", "\u409c\u3040\u7127\u4c2a\u6e51\ucdf0", "\ud853\udf22\udb8f\udd36\udb14\udcb0\udabf\udc7c\ud9c8\udfad\ud98e\udcc7\udb65\udce9",
//         45, 11906, -880687568, 2665447588645010364L, -59812L, true, true, (char) 41500, (char) 53772,
//         Double.longBitsToDouble(0x3fd3930356c43770L), Double.longBitsToDouble(0x3fee397eac1f6e60L)));
//   }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 9, 14, 2, "\ud987\udff3\udaf1\udee8\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u438a\u4c63\u726a\u943f\u9d5f\u9191\u8685\u7917\uc1cb\u6dbc\u2ea2\u7e43\u5e9f\u00b8\u2f9c\uc8bb\u1272", "\ud836\udf1a\ud89a\udc5c\udbac\udfed",
        28, 66683, -1327276740, -1473686563845086460L, 22647L, true, true, (char) 59291, (char) 33384,
        Double.longBitsToDouble(0x3fd26bd2207b4b82L), Double.longBitsToDouble(0x3fea725e85ad846cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 14, 3, 2, "\udb3f\udc3d\ud966\udc58", "\ubbb0\u4a4c\u80c3\u438a\u4c63", "\ud9be\udc32",
        6, 50981, 2118351768, -5077802616939142196L, 51219L, false, false, (char) 53124, (char) 48020,
        Double.longBitsToDouble(0x3f9e365b5a7690a0L), Double.longBitsToDouble(0x3fdc732a6bd02cf4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:11.0.32.1\012",
        Z.run(T, 1, 6, 6, 2, "\udb4e\ude17\ud9c9\udf67\ud8af\udd32", "\u4a4c\u80c3\u438a\u4c63", "\ud995\udc32\udbd3\udebd\uda79\ude75\udbfe\udcfe\udb72\udd29\udaa0\udc9a\ud834\udd53\u9e9f\ud9a1\udd6e\ud904\udc11\udbb4\udd21\udb28\udde2\udabf\udc7c\uda93\udf6d\ud98e\udc92\ud9ce\udf51\udaeb\udcc4\udbac\udfed\uda3e\udfd1\udbbe\udfa8\ud9ae\udf5a\ud9b2\udcac\udbea\ude2c\ud830\ude5e\udb7b\udf26\ud82b\udde5\uda0c\udd20",
        48, 97711, 863591432, -5212674618834723719L, 42416L, true, true, (char) 8249, (char) 14086,
        Double.longBitsToDouble(0x3fc6549f94837d14L), Double.longBitsToDouble(0x3fde357127bc2cceL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=null\012",
        Z.run(T, 2, 7, 9, 2, "\udb3f\udc3d\ud956\udc50", "\ub7f9\uc581\u7fee\u438a\u4c63", "\ud995\udc23\ud9be\udf22\ud818\udc8f\udbfe\udcfe\udb72\udd29\udaa0\udc9a\ud834\udd53\u9e9f\ud9a1\udd6e\ud904\udc11\udbb4\udd21\udb28\udde2\udb43\udf1f\ud8fd\ude5e\ud98e\udcc7\ud836\udf1a\ud89a\udc5c\udbac\udfed\uda3e\udfd1\udb7d\udf88\ud9c4\udc92\ud9b2\udcac\udaaf\udfef\ueda9\ud9d5\ude58\ud897\udcf4\udb05\udcd5",
        48, 97711, 863591432, -3167627919954423271L, 57095L, true, true, (char) 56090, (char) 21541,
        Double.longBitsToDouble(0x3f8fc091673ed0c0L), Double.longBitsToDouble(0x3fd24a61577540a8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 0, 14, 0, "\udb37\udf3b\ud966\udc58\udb13\udeed\udb71\ude97\udbbf\udc19", "\000\000\000\u2931\000\000\u1c5d\u94bf\u992a\u6dbc\u3cd2\u0691\u5e9f\u00b8\u3963\uc82e\u4a47", "\000\000",
        18, 39071, 0, -5700610448730330655L, -100000L, true, false, (char) 31451, (char) 58520,
        Double.longBitsToDouble(0x3fd000000f8e5faaL), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 13, 12, 2, "\udb12\udc7e\udb2b\udd7d\udba5\ude56\ud834\udd44\uf8e8", "\u438a\u4c63\u04f0\u4399\uc8ba\ua7bb\u34d0\u9337", "\uda7a\udc84\u9e9f\ud9a1\udd8b\uda38\udd0f",
        28, 51845, 417143105, -5438791313218368045L, 46711L, false, false, (char) 28734, (char) 56791,
        Double.longBitsToDouble(0x3fd3c06393c361c6L), Double.longBitsToDouble(0x3fe8275c61b5cbbfL)));
  }
  @Test
  public void test28() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test28() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\0121=java.lang.Boolean:true\012",
//         Z.run(T, 2, 10, 14, 2, "\udb3f\udc3d\ud954\udc4f\ud8af\udd5a", "\u4a4c\u80c3\u438a\u4c63", "\ud9b1\udef9\udbd3\udebd\uda79\ude75\udbfe\udcfe\udb72\udd29\udaa0\udc82\ud834\udd53\u9e9f\ud9a1\udd6e\udb2e\ude47\ud97a\udf2f\udb28\udde2\udabf\udc7c\ud8fc\udfab\ud98e\udcc7\ud836\udf23\udbd4\udf99\ud9ad\udc9b\uda3e\udfd1\udb7d\udf88\ud95c\udefe\ud9b2\udc59\udaaf\udfef\uf4a9\ud96d\udfdf\ud839\uddbb\uda0c\udd20",
//         48, 97711, 1177705480, 8169778982320122476L, 43773L, true, false, (char) 30880, (char) 17886,
//         Double.longBitsToDouble(0x3fd583432a335ef4L), Double.longBitsToDouble(0x3fe31aed3cf3c9b7L)));
//   }
  @Test
  public void test29() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test29() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud8c7\udc29\ud8af\udd5a\ud8fd\udf6a\udbbf\udc19", "\u438a\u4c63\u049d\u4399\u9d78\uadae\ubd0d\uc45d\u2006\ud01b\uaeef\u30a3\ucd64\uabe6\uad09\uc8bb\u4a47\ubea8\ua93f\ucc6a\u05f8\u020e\ua72a\u0e8b\u5f78\ua1a3\ucd15\ub936", "\uda0c\udd20\uda81\udc3a\udbf4\ude09\uda29\udf10\uda6a\udf16\udad7\udebd\udb50\uddae\ud9e2\udc9a\ud97f\udd89\ud926\ude76\ud8e3\udc50\ud96a\udd2f\udaac\udcbf\udab8\udcad\udaad\ude8f\ud941\udeff",
//         33, 42596, 2007753097, -6136541910799455255L, 53101L, false, true, (char) 60878, (char) 42111,
//         Double.longBitsToDouble(0x3fe7c90b0d9519c5L), Double.longBitsToDouble(0x3fd28f3467d3b052L)));
//   }
  @Test
  public void test30() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test30() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "", "\u408cM\000\u96ac\u80c3\u438a\u4c63E\u4399\u9d78\uadae\ubcdb\uc45d\u7978", "\u9e9f",
//         38, 39294, 201326688, -5703819317590622208L, -100000L, false, true, (char) 5777, (char) 0,
//         Double.longBitsToDouble(0x3fc0fa76fcadeee4L), Double.longBitsToDouble(0x3fd3c06393c361c6L)));
//   }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 14, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbde\ude19\ud9fb\udff0\ud8a6\udca9\ud8b4\uddc9\u88db\uda00\udff4\ud9cd\udf52\ud995\udc32\udbd3\udebd\uda79\ude75\udbfe\udcfe", "\u1145\ub182\u4bfc\u5ca8\ucf6d", "\ud81e\ude8b\ud9a4\udc73",
        55, 43983, -742943094, -1830279461019759656L, 79787L, true, false, (char) 58931, (char) 16732,
        Double.longBitsToDouble(0x3fe1b9148cc66c79L), Double.longBitsToDouble(0x3fd8766d75a46744L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 0, 14, 2, "\udb19\udf2c", "\u8aac", "",
        -5, -1000, 0, -4052527984789673679L, 59449L, true, false, (char) 48127, (char) 52371,
        Double.longBitsToDouble(0x3fea85cc400059cbL), Double.longBitsToDouble(0x3fe02c52d41d4e15L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 14, 1, 1, "\udbda\udcb5\ud806\udc28\ud9ef\ude7e\udb71\udee7\udbbf\udc19\ud9fb\udff0\u0477\ud9e3\udf0d\u88db\uda00\udff4\ud8e6\udf3f\ud995\udc32\udbd3\udebd\uda79\ude75\udbfe\udcfe\udbe7\udca3\udaa0\udc59\ud834\udd53\u9e9f\ud9a1\udd6e\ud904\udc11\udbb4\udd21\udb28\udde2\udabf\udc7c\ud8fc\udfab\ud98e\udcc7\ud836\udf1a\ud89a\udc5c\udbac\udfed\uaaf8\ud944\udfb4\uda9f\udc2f\ud9b2\udcac\udaaf\udfef\ueda9\ub0bf", "\u8eea\u9d68\uc109\u9aec\u84c4", "\udb84\udebd\ud8b9\ude48\ud979\ude7a\ud8c9\ude69\ud87c\udfd3\udb30\udc37\ud81d\udf97\ud968\udef2\uda8c\ude68\udbbf\udcb0\udb39\udf6b\ud81b\udc35\ud8f6\udeb4\uda08\udff2\ud916\ude4c\udaf1\udf2e\udb07\udc53\udb5e\udc25\udb39\udf46\udbab\udeb5\ud847\uddf6\udbf3\udfd6\udaa8\udcf4\ud82c\ude4a\udba3\udf31\udb96\ude19\ud8c9\uddb8\udbe4\udf56\udafb\udeea\uda35\udc14",
        40, 4279, 2027828660, -6151228598805897030L, -31875L, true, true, (char) 55014, (char) 36783,
        Double.longBitsToDouble(0x3fedfbec3c8c2d8aL), Double.longBitsToDouble(0x3fd020a5eee62128L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 14, 1, 1, "\ud9eb\udc32\uda66\udc4e\ud8af\udd01\udb71\udee4\udbbf\udc19\ud9fb\udff0\u0477\ud9e3\udf0d\u88db\uda00\udff4\ud8e6\udf3f\udb15\udc12\ud8dd\udf02\uda79\ude75\udbfe\udcfe\udb72\udd29\udaa0\udc9a\ud834\udd53\u9e9f\ud9a1\udd6e\ud904\udc11\udbb4\udd21\udb28\udde2\udabf\udc7c\ud8fc\udfab\ud98e\udcc7\ud836\udf1a\ud89a\udc5c\udbac\udfed\uda3e\udfd1\udb7d\udf88\ud9b8\udfee\ud9b2\udcac\udaaf\udfef\ueda9\ub0bf\ud945\udc95\ud9e3\uddb7\ud80d\udd0d\udbf4\ude09\uda29\udf10\udad7\udf6c\udb20\udee0", "\uab7b\u5611\u755b\u1a3f\u7cc4\u42ef\u69b2\ucd30\u7c01\u34cb\u58f5", "\udae3\udf68\uda25\udc98\ud8bd\udf5b\uda33\udd98\ud93c\ude91\ud8e0\uded6\ud893\ude56\uda1c\udf2c\udba3\ude5d\uda2f\udeee\udb1c\udf4e\uda8e\ude1e\uda9a\udcf8\u3c8b\udaf3\udc57\udaf1\udd8e\uda54\ude09\ud969\udc18\ud827\udcd3\ud89d\udd16\udb65\udce7\uda5a\ude77\udad3\udd20\udae3\udcb0\uda74\udf2e",
        57, 51958, 1846554783, -4255012291471486549L, -27086L, false, true, (char) 48873, (char) 50531,
        Double.longBitsToDouble(0x3fcde599e3fb913cL), Double.longBitsToDouble(0x3fe60792ab948b30L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:1132\0121=java.lang.Integer:1132\012",
        Z.run(T, 2, 4, 4, 12, "\udb46\ude62\ud9f0\udcdd\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\ua35a\ud4e5\ub60a\u4399\ua434\u6cc7", "\udb72\uddb4\ud9ed\udeb8\ud8c4\udd5b\udb89\udc90\ud9a1\udd6e\udb3f\udef5\ud27d\udb52\udc9f",
        49, 58457, 841190815, 1644440476897393943L, -66393L, false, true, (char) 6455, (char) 19256,
        Double.longBitsToDouble(0x3fcfc3d3ff0c1d68L), Double.longBitsToDouble(0x3fe4ff3e6dd50e9eL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 15, 2, "\udb3f\udc3d\ud9f4\udda0\udaf5\udc00\udba9\udca0\uda60\ude2a", "\u438a\u4251\u9dc3\u982c\ubf75\uc0ab\u07c0\ua2e3\uc1cb\u6dbc", "\uda61\udc64\ud904\udc11\uda76\udfac\udb28\ude02\udabf\udc7c\ud8fc\udfab\ud98e\udcc7\ud836\udf1a\ud89a\udc5c",
        11, 8799, -2047408341, -5700541570692126239L, 79787L, true, false, (char) 31451, (char) 58520,
        Double.longBitsToDouble(0x3f71fe47e3dcd880L), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 5, 6, 0, "\udb6d\uded3\udb16\udc70\ud8af\ude2a\udaa8\udc35\uaab6\ud9ed\udf2b\ud8db\udcf8\ud96e\udc3e\u8929\uda00\udff4\ud905\ude07\ud995\udc32\udb29\udd7c\uda94\udf85\udbf8\udf75\udb3c\udda2\udaa0\udc9a\udb82\udda8\u01e8\ud9a1\udd6e\ud904\udc11\udab7\udcf0\uda7c\udec9\ud8fa\udd2f\u285b\ud98e\udcc7\ud836\udf05\udab0\udd55\udbf7\udc87\uda3e\udf55\udb7d\udf88\ud9b8\ude78\udb91\udf9c\udaa3\udc3e\ud9ad\ude33\udaa4\udf01\udac6\udf42\uda0c\udda1", "\u858a\u44df\ub4d0\u6633\u76b1\u6c71\u58ca\ubdac\u6270\ua14d\u4915\uc994\ubd5d\u7973\ub207\u423d\u3f7f\ua162\ud756\u02d3\uc36b\u839e\u3c92\u155e\u17ab\u2fee\u121e\u6853\u2e80\u4570\ucf3a\u6b1c\u73d8\u5766\u424a\ubed7\u93ba\u783c\ub09e\u4ba3\u9f28\u252f\uab21\u0548\u20ab\u4880\u4f78\uc4e0\u27fd\u212e\u4d14\u5454\u5279\u359b\u1d6e\u0256\u0d7f\ub32c\u79a7\u6270\u9270\u2d6e\ua474\u10b4\u5c7d\ua4cc\u75a6\u815b\u166c\u22a9\u89c7\u33d0", "\udad0\udd4a\udb11\udd35\ud89f\ude99\udacc\udc33\ud979\udee3\ud810\udd9a\ud9bc\udd1e\ud8e7\uddef\ud9c7\uddb0\ud9ea\udf4a\ud9b6\ude00\ud9c3\ude84\udb40\udc31\udbb9\udcc4\udbc3\udd90\ud8b8\ude9d\ud866\udcb9\ud9b8\udfae\ud907\udceb\ud93b\ude41\u7c63",
        14, 47161, 1619717270, 2019399257146743721L, 2645L, false, false, (char) 42325, (char) 52039,
        Double.longBitsToDouble(0x3fd96582cfa6312aL), Double.longBitsToDouble(0x3fe6795ce6593155L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Float:11.032\012",
        Z.run(T, 1, 3, 14, 2, "\000", "", "",
        17, 53038, 0, -943552699L, -88422L, true, true, (char) 31542, (char) 146,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 0, 14, 2, "", "", "",
        45, -1000, 1845493760, -4831236496867468283L, 2656L, false, false, (char) 146, (char) 0,
        Double.longBitsToDouble(0x3e00964000000000L), Double.longBitsToDouble(0x3fe0280000000015L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 0, 15, 9, "\u009d\ue885\000\000\udbbb\udebd\000\ud9f9\ude7b\ud9d9\udc0d\udad8\udc12\uda0d\udde1\ud9cd\udf52\000\udb3e\udd0c\uda59\udc08\ud8e3\udc48\000\ud9d5\udd91\udbd7\udd82\ud8f6\ude06\udb06\udde2\udb64\ude9d\ud829\udfc1\000\uda4d\udd4a\ud8db\udfef\ud8d5\udf5a\ud91e\udc5e\uda63\udfd4\ud8cd\udf83\udb4d\uddab\u072b\udb7b\udd5c\ud9b3\udc50\udba6\udd1c\ud96a\uddff\ud9a3\udd9e\ud999\udc3e", "\u1bb3\u2efa\u1e3d\u7602\u7f2a\u71ef\u47ee", "\ud9f2\udcff\ud9a7\udf94\udb2a\uddb6\udaea\ude57\uda33\ude08\ud9e1\udd56\ud9e1\udcde\ud925\udf77\udb81\udf86\ud82a\udd42\udb0c\udded\ud964\udc17\ud9dc\udd27\ud88f\ude7e\u5df2\ud9c2\udea5\ud961\udd7c\udae7\udc00\ud890\udda7\ud992\ude98\ud9ce\udfc2\ud305\ud8ba\udc97\ud94a\udf89\udb3c\udd93\ud917\udcd0\ud810\udd2d\ud9da\uddda\udaea\ude4f\uda80\ude49\ud9b9\ude65\udba1\udf7e\uda1f\udfae\ud992\udd37\udbbc\ude44\u75c7\udb13\udd72\ud9b4\udcf6\ud81e\uddd9\ud824\udd42\udb39\udea1\u6a18\u49d7\ud988\udc40\ud853\uddd7\udafd\udf85\ud9f6\ude86\uda02\udedf\ud957\uddd1\udb43\udcfd\ud8ab\udcbf\ud9b2\udeb1\ud8fc\ude3e\ud83f\ude44\uda1d\ude18\udbee\udece\udb4d\udff1\ud813\udd28\uda22\uddf0\ud919\udc4f\ud9a2\ude48\ud8ad\udcd0\uda1c\udeac\uda07\udc3e\ud8e2\udd0d\ud998\ude73\udb04\udfa5\u042e",
        18, 26849, 1920008718, -8086999534026455203L, 85027L, true, true, (char) 54381, (char) 37058,
        Double.longBitsToDouble(0x3febd1fcd1528182L), Double.longBitsToDouble(0x3fe6781b315e0823L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 0, 14, 2, "\000\000\000\000\udbbb\udebd", "\u3340\ua1e1\u049d\u4399\uc805\uba01\u24ad\u5462\000\u2ca4\u4842", "\ud904\udc11\udb8a\udc6c\000\000\ud98a\udf85\ud98e\udcc7\ud836\udf1a\udbf1\ude5e\udbac\udf63\uda3e\udfd1\u072b\ud812\udf49\ud8f0\udd4a\udb47\uddc0\ud8cd\udd86",
        37, 17195, -1954912778, -2468838865482786525L, -77925L, true, false, (char) 36764, (char) 63971,
        Double.longBitsToDouble(0x3fc56a2b02475440L), Double.longBitsToDouble(0x3f8ddf1198476800L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 15, 11, "\udb3f\udc3d\ud813\udce6", "\u23c0\u2e00\u80c3\ud30d\u6f61", "\ud9a3\udecb\ud86f\udc45\ud8a9\udff5\udb98\uddf3\ud8c7\udcd5\udaa0\udd0a\udbdb\uddd9\u9985\ud836\udd5e\udba7\udd50\uda7f\udca0\uda20\uddaa\udabf\udc7c\ud803\udd8e\uda79\udf2f\ud806\uddae",
        29, 38577, 1146070102, -2440133188935340028L, 25638L, true, false, (char) 11104, (char) 1083,
        Double.longBitsToDouble(0x3febfa210a95d7b8L), Double.longBitsToDouble(0x3fdc72fadb20c812L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 7, 11, 2, "", "\u3fb9\u8aac\uc40e\u6f98\u80c3\u13c1\u97ff\u54bd\ucdd4\022\uaea8\ub4a7\u00f5\u64d7", "\ud82a\udf5b\ud956\ude0f\000\000\uda10\udca7\udab8\udf3b",
        5, 15903, -797307013, -1690752018975087199L, -32629L, false, false, (char) 28351, (char) 23296,
        Double.longBitsToDouble(0x3fdb5c63716e862aL), Double.longBitsToDouble(0x3e4dfc0000000000L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 8, 2, "\ud987\udff3\udaf1\udee8\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\uc408", "\ud852\udcc5\ud9a9\udd09\udbd3\udebd\uda79\ude75\udbfe\udcfe\udb72\udd29\udaa0\udc9a\udb45\udefb",
        43, 40093, 1916414294, 926264190599427725L, 53951L, false, true, (char) 27626, (char) 21393,
        Double.longBitsToDouble(0x3fe4557df187d3b7L), Double.longBitsToDouble(0x3fe95bddcd3c0639L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Float:11.032\0121=java.lang.Float:11.032\012",
        Z.run(T, 2, 3, 3, 2, "\udb3f\udc3d\ud966\udc58", "\ubbb0\u4a4c\u2534\u8223\u0fc0", "\ud9be\udc32",
        6, 50981, 2118351768, -5077802616939142196L, 51219L, false, false, (char) 53124, (char) 48020,
        Double.longBitsToDouble(0x3f9e365b5a7690a0L), Double.longBitsToDouble(0x3fdc732a6bd02cf4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 9, 2, "\udb3f\udc3d\ud956\udc50", "\u42a5\uc581", "\u88db\uda00\udff4\u15ce\ud995\udc23\ud9be\udf22\ud818\udc8f\ud885\udfc2\ud9fe\udc7c\udaa0\udcf1",
        55, 56837, 375256161, 8230936718532591712L, 90143L, true, false, (char) 16984, (char) 27626,
        Double.longBitsToDouble(0x3fd17167ad155f7cL), Double.longBitsToDouble(0x3fc0fa76fcadeee4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 0, 0, 2, "\udb3f\udc3b\ud954\udc4f\ud8af\udd5a", "\u4a4c\u80c3\000\000", "\ud9b1\udef9\udbd3\udebd\uda79\ude75\udbfe\udcfe\udb72\udd29\udaa0\udc82\u4842\000\udb98\udd4b\udb2e\ude47\ud97a\udf2f\uda9a\udc99\000\ud8fc\udfab\ud98e\udcc7\ud836\udf23\udbd4\udf99\ud821\udf15\uda81\udf3f\udb7d\udf88\ud95c\udefe\ud9b2\udc59\udaaf\udfef\uf4a9\ud96d\udfdf\ud839\uddbb\uda0c\udd20",
        48, 97711, 1177705480, 8169778982320122476L, 43773L, true, false, (char) 30880, (char) 17886,
        Double.longBitsToDouble(0x3fd583432a335ef4L), Double.longBitsToDouble(0x3fe31aed3cf3c9b7L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 13, 14, 8, "\udb3f\udc3d\ud954\udc4f\ud8e5\udf5a", "\u4a4c\u80c3\u438a\u4c63", "\ud9b1\udef9\udbd3\udebd\uda79\ude75\udbfe\udcfe\udb72\udd2a\udaa0\udc82\ud834\udd53\u9e9f\ud9a1\udd6e\udb2e\ude47\ud97a\udf2f\udb28\udde2\udabf\udc7c\ud8fc\udfab\ud98e\udcc7\udb23\udd7a\udbd4\udf99\ud9ad\udc9b\uda3e\udfd1\udb7d\udf88\ud95c\udefe\ud9b2\udc59\udaaf\udfef\uf4a9\ud96d\udfdf\udbea\udf94\uda0c\udd9c",
        48, 97711, 1177705480, -5304991102772382644L, 76111L, true, false, (char) 25296, (char) 18050,
        Double.longBitsToDouble(0x3fd589357a335ef4L), Double.longBitsToDouble(0x3fe31aed3cf3c9b7L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:100\012",
        Z.run(T, 1, 0, 0, 2, "\uda18\ude0a\000\ud97b\udece\000\udbbb\udebd\udb5a\udc5b\ud9f9\ude7b\ud9d9\udc0d\u88db\ud9da\uddbf\ud929\udccb\ud958\udc23\ud9a6\udd6c\ud912\udfbc1\000\udabf\udd3e\ud828\udeaf\ud8f9\udd06\udb44\udc41\ud83f\udcbf\ud824\udcf6\ud934\udc71\ud836\udcc9", "\uc289\u97fa\u8145\u1c89\u1410", "\udb61\ude7d\udb63\ude5b\ud9a3\udd87\udae1\udfc3\ud99f\udceb\ud9fd\udf25\udba2\uddc7\u7c9e\udbe3\uddb5",
        26, 28618, 1743434851, -668051073636428636L, -26952L, false, false, (char) 24235, (char) 41135,
        Double.longBitsToDouble(0x3fa795dc1b9a43d0L), Double.longBitsToDouble(0x3fd5638043fe31f0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 7, 5, "\ud987\udff3\udaf1\udee8\ud8af\udd5a\udb71\udee4", "\u15a6\uc408\ucb6d\u8662\u2b00\u1650\u9191\u8685\u7917\uc1cb\u6dbc", "\ud9a1\udd6e\ud904\udc11\udbb4\udd21\udb28\udde2\ud995\udff1\ud88b\udc51\ud98e\udcd8\ud836\udf1a\ud89a\udc5c",
        11, 86503, 104400683, -7293477085275466802L, -38286L, false, true, (char) 40000, (char) 55368,
        Double.longBitsToDouble(0x3fd23af7c4eba16aL), Double.longBitsToDouble(0x3fda4321c02442a8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 0, 0, 0, "\u8b00\000\u00e8\000\000", "\000", "\ud852\udcc5\ud9a9\udd09\ud857\udd8a\uda79\ude75\udbfe\udcfe\udb72\udd29\udaa0\udc9a",
        -4, 54363, 375256093, 8230936718532591712L, 42015L, true, false, (char) 26281, (char) 27626,
        Double.longBitsToDouble(0x3fd17167ad155f7cL), Double.longBitsToDouble(0x3fd87d3b7e56f772L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 9, 9, 2, "\udb3f\udc3d\ud956\udc50", "\u42a5\u0c96", "\uda13\udf97",
        52, 66458, -457691713, 2430769688461481591L, 24407L, true, true, (char) 41485, (char) 21599,
        Double.longBitsToDouble(0x3fd6150418a54cf0L), Double.longBitsToDouble(0x3fd5c89099c82494L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 0, 0, 0, "", "\u72fb\u53e0\u4976\000\u7fee\001\u4c63\u049d1\u3e99\000\u481d\uc033\ucaa8", "\uca05\ud9a1\uddb2\ud904\udc11\uc000\000\udb43\udede",
        14, 91107, 8010183, -742981632L, -34464L, true, true, (char) 16065, (char) 48468,
        Double.longBitsToDouble(0x3fd291082d5935b8L), Double.longBitsToDouble(0x3fdeffa8fff7826cL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 9, 2, "", "", "\udaa1\udc8d\u1158",
        28, 44312, 56325, 0L, -40903L, true, false, (char) 57174, (char) 31834,
        Double.longBitsToDouble(0x3fed3b63c84259cbL), Double.longBitsToDouble(0x3fe02c52d4615041L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:100\0121=java.lang.Integer:100\012",
        Z.run(T, 2, 0, 0, 2, "\uda18\ude0a\000\ud97b\udece\000\udbbb\udebd\udb20\uddbe\uda39\udf46\uda63\ude52\udb28\ude2e\udb4d\udd1b\ud937\ude59\ud958\udc23\ud9a6\udd6c\ud912\udfbc1\000\udabf\udd3e\ud828\udeaf\udaff\ude8a\udb44\udc90\ud83f\udcbf\ud824\udcf6\ud934\udc71\ud9b0\udd27", "\uc289\u97fa\u8145\u1c89\u1410\uadb5", "\udb63\ude5b\ud9a3\udd87\udae1\udfc3\ud99f\udceb\ud9fd\udf25\udba2\udde5\u7c9e\ud930\udf3c\uda6c\udc23",
        48, 72851, -155542761, -8640977614801391340L, 97994L, true, true, (char) 41135, (char) 2023,
        Double.longBitsToDouble(0x3fdb9a43daac7008L), Double.longBitsToDouble(0x3fdff18f829aed84L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 12, 5, "\udac1\uddf0\udacc\udd27\ud8af\udd5a\udb71\udee4", "\u15a6\uc408\ucb6d\uaa93\ua8ab\u073c\u737b\u5181\u7917\u8f6d\u6dbc", "\ud9a1\udd6e\ud904\udc11\udbb4\udd21\udb28\udde2\ud995\udff1\ud88b\udc51\ud98c\udd96\ud836\udf1a\ud89a\udc5c",
        11, 86503, 104400683, -7293477085275466802L, -38286L, false, true, (char) 40000, (char) 55368,
        Double.longBitsToDouble(0x3fd23af7c4eba16aL), Double.longBitsToDouble(0x3fda4321c02442a8L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 7, 5, "", "\u72fb\u53e0\u42a5\uc581\u5123\u8905\u0406\u93e5\u5c88\u792b\ud576\uc837\u572e\u5c18\u748d\u3c2a\u1783\ud7c8\u57e9\u9cc3", "\u1383\udbe8\ude80\ud893\udf81\ud951\udcdb\udb80\udfc7",
        40, 31268, 1600851292, -6287260671200602919L, 59944L, false, true, (char) 15278, (char) 58944,
        Double.longBitsToDouble(0x3fed9a86212fd00cL), Double.longBitsToDouble(0x3feb4d73719a4241L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.String:11.0.32.1\0121=java.lang.String:11.0.32.1\012",
        Z.run(T, 2, 6, 6, 4, "", "", "\udaa1\udc8d\u1158",
        28, 44312, 56325, 0L, -40903L, true, false, (char) 57174, (char) 31834,
        Double.longBitsToDouble(0x3fed3b63c84259cbL), Double.longBitsToDouble(0x3fe02c52d4615041L)));
  }
  @Test
  public void test59() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test59() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud966\udc58\ud8af\udd5a\udb71\udee4\udbbf\udc19", "\u438a\u4c63\u049d\u4399\u9d78\u9191\u8685\u7917\u3241\u6dbc\u3cd2\u0691\u5e9f\u00b8\u2f9c\uc8bb\u4a47", "\ud836\udf1a\ud89a\udc5c",
//         11, 8799, 104400683, -5700610189740447263L, -17643L, true, false, (char) 31451, (char) 58520,
//         Double.longBitsToDouble(0x3fd8e2291f8e5faaL), Double.longBitsToDouble(0x3f804cc0b48cde40L)));
//   }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 5, 6, "\udb80\udc45", "\u6257", "\ud87b\ude32\udb73\udf92\ud02d\000\udac5\udd91\ud99c\uddf0\ud88e\udcf8\ud8df\udd21\udbfd\udccf\ud9fe\udd36\uda9e\udff1\ud834\udd53\udb29\udebf\udb57\udd4e\ud9b8\udd1d\udba2\udf03\ud840\ude15\ud917\udfac\udace\ude6c\uda7a\udfc0\ud850\udf48\ua2af\ud8b9\udcdb\uda86\ude66\udb80\ude59\u1529\ud8b8\udfa0",
        13, 43057, 1810671043, 7833847423274091309L, -18774L, true, false, (char) 41258, (char) 24349,
        Double.longBitsToDouble(0x3fee9c47f9f430d2L), Double.longBitsToDouble(0x3fd0d7f63e1591b8L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 7, 7, 6, "", "", "\udaa1\udc8d\u1158",
        43, 44457, 56325, 0L, -40903L, true, true, (char) 29424, (char) 20423,
        Double.longBitsToDouble(0x3fed3b63a94259cbL), Double.longBitsToDouble(0x3fef6dbad46150e1L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 13, 13, 12, "\ucab7\ud870\udf58\udba9\udf70\udb25\udda8", "\u450b", "\ud827\udc9a\000\ud989\ude64\ud9be\udf22\u8287\ud885\udfc2\ud9fe\udc7c\ud8e2\udffc\ud94e\udddc\udb29\udf09\udba1\udc92\uda6c\ude22\udac0\udcd0\ud813\udf90",
        16, 11732, 173231311, 8207189167949078209L, 90324L, false, true, (char) 54757, (char) 15932,
        Double.longBitsToDouble(0x3fe5eb0a25eaff6aL), Double.longBitsToDouble(0x3fa0b0db9d050b70L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:200\012",
        Z.run(T, 1, 0, 0, 2, "\udad8\ude8c\udb2b\udd7d\u1ee8\ud831\uddf72", "\u2b01", "\ud8ca\udc04",
        20, 70914, 89425535, 7351281966755767422L, -100000L, false, false, (char) 16975, (char) 8371,
        Double.longBitsToDouble(0x3fb81c87400066d0L), Double.longBitsToDouble(0x3fd41b01403c31baL)));
  }
  @Test
  public void test64() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test64() throws Throwable {
//     assertEquals("0=java.io.File:/home/pilaiphon/zest-d4j\012",
//         Z.run(T, 1, 10, 14, 2, "\udb3f\udc3d\ud8c7\udc29\ud8af\udd5a\ud8fd\udf6a\udbbf\udc19", "\u038a\u4c63\u049d\u4399\u9d78\uadae\ubd0d\uc45d\u2006", "\ud8df\udc9c\ud9cd\udf0e\udb1d\ude09\ud8d5\ude4c\udb28\udde2\udabf\udc7c\ud8fc\udfab\ud98e\udcc7\ud836\udf1a\ud89a\udc5c\udbac\udfed\uda3e\udfd1\udb7d\udf88\ud9c4\udc92\ud9b2\udcac\udaaf\udfef\uedca\udabd\udec8\udaf8\ude17\uda0c\udd20\uda81\udc3a\udbf4\ude09\ud863\uddee\udb58\udd21\udad7\udebd\udb50\uddae\ud9e2\udc9a",
//         15, 72579, -1720065445, -3727704598146502661L, 53101L, false, true, (char) 60878, (char) 42111,
//         Double.longBitsToDouble(0x3fe7c90b0d5866c5L), Double.longBitsToDouble(0x3fdd5f3467d34860L)));
//   }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 6, 2, "\ud80b\udfd7\ud9d5\udf3b\udba5\ude56\ud835\udd48\ud875\udcd5\udacd\udcea\uda83\udcd0\ud9e3\udf44\u88db\uda01\udc47\ud93c\udc5c\udaec\ude5e\ud972\udee2\ud983\udefe\ud86c\udc50\ud802\udc52\udaa0\udc9a\ud943\udc68\udabf\udcda\udb65\udfda\uda38\udd8c\udbb4\udd21\ud8ff\udcd7\ud836\udeb8\ud89e\udd1c\ud9d7\udfb5\ud81d\udfad\u0f5a\udbac\udfed\ud90a\ude18\udb7d\udf7b\ud9c4\udc92\ud925\ude3f", "\u6565", "\ud9ba\udf48\uda31\udd97\udb96\udc60\uad7d\udaf8\uddfb\udb61\udeae\uda37\ude55\udb1c\udc7c\ud8e6\udcbc\udab7\udd21\udb1f\udd94\uda42\udc1d\ud8c2\udc54\ud80e\udc7a\ud8c7\udc7f\ud987\udc73\ud917\uddb8\udaa4\ude0a\ud9ff\ude76\ud8ec\uddeb\udb2e\ude31\ud9bb\udcf9\u1aff\ud971\uddb6\ud887\udf5b\ud9f2\udc11\ud835\ude80\udb30\ude16\ud843\udf94\ud929\ude3c\ud8a1\udf3c\ud804\udf4a\ud99f\ude57\udb20\udd51\udbf1\udde3\udaca\udd01\ud9ec\ude5e\udb30\udeeb\udbe6\uddcc\udbf4\udf74\uda13\udd12\ud951\udee3\ud89e\ude4e\udbf3\udfaf\uda2c\uddea\ud885\udeb1\uda0f\udcaa\u2fbf\udb0a\udfd4\udab7\uddff\ud981\udde3\ud8ec\udf19\u9226\ud837\udc69\udbe4\udc8c\ud916\udfb2\udae0\ude23\uda91\udf8a\uda12\ude48\ud957\ude27\ud8c9\udd0b\ud906\udff8\uda21\ude1a\uda77\ude35\ud950\uddde\ud9f7\udf21\uda6f\udc8c\ud85b\ude19\ud9df\udef3\ud9cc\udf01\ud891\udc77\uda18\udf53\udb93\udc4e\udb71\udc1d\ud83e\udf62\ud990\udcaf\uda1b\uddf4\udacd\ude36\uda93\ude9b\ud81e\udf03\ud8cf\udda8\udb78\udc52\udb1a\udf50\udb47\udd9e\uda6a\udcb7\uda01\udd44\ud80b\udfea\ud85f\udcc4\uda64\udeed\ud806\udd6c\udac7\udf90\ud819\udc34\ud9fe\udcea\udb25\ude35\ud9df\udc8e\udaf0\udc20\uda57\ude0f\ud8b5\ude4e\uda15\udf0f\udb9b\udec2",
        21, 50927, 67226239, 6857846654307074359L, -86671L, true, false, (char) 31217, (char) 16269,
        Double.longBitsToDouble(0x3fd5eb0ef9d8f190L), Double.longBitsToDouble(0x3fc521244a6c0ba4L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 12, 6, 14, "\ud80b\udfd7\ud9d5\udf3b\udba5\ude56\ud835\udd48\ud875\udcd5\udacd\udcea\uda83\udcd0\udb53\udfc6\udaca\udf17\ud852\udfe0\ud813\ude53\udaec\ude5e\ud972\udee2\ud983\udefe\ud86c\udc50\ud802\udc52\udaa0\udc9a\ud943\udc68\udabf\udcda\udb65\udfda\uda38\udd8c\udbb4\udd21\udb73\udf45\uda0c\ude2e\ud89e\udd1c\ud9d7\udfb5\uda85\udf61\udbd4\udf92\udbac\udfed\ud90a\ude18\udb7d\udf7b\ud9c4\udc92\ud925\ude3f", "\u6565", "\ud9ba\udf48\uda31\udd97\udb96\udc60\ud9f3\udf01\udae9\udd23\udb61\udeae\uda37\ude55\udb1c\udc7c\ud8e6\udcbc\udab7\udd21\udb1f\udd94\uda42\udc1d\ud8c2\udc54\ud80e\udc7a\ud8c7\udc7f\ud987\udc73\ud917\uddb8\udaa4\ude0a\ud9ff\ude76\ud8ec\uddeb\udb2e\ude31\ud9bb\udcf9\u1aff\ud971\uddb6\ud887\udf5b\ud9f2\udc11\ud835\ude80\udb30\ude16\ud843\udf94\ud929\ude3c\ud8a1\udf2f\ud804\udf4a\ud99f\ude57\udb20\udd51\udbf1\udde3\udaca\udd01\ud9ec\ude5e\udb30\udeeb\udbe6\uddcc\udbf4\udf74\uda13\udd12\ud951\udee3\ud89e\ude4e\udbf3\udfaf\uda2c\uddea\ud885\udeb1\uda0f\udcaa\u2fbf\udb0a\udfd4\udab7\uddff\ud981\udde3\ud90f\udd19\u9226\ud837\udc69\udbe4\udc8c\ud916\udfb2\udae0\ude23\uda91\udf8a\uda12\ude48\ud957\ude27\ud8c9\udd0b\ud906\udff8\uda21\ude1a\uda77\ude35\ud950\uddde\ud9f7\udf21\uda6f\udc8c\ud85b\ude19\ud9df\udef3\ud9cc\udf01\ud891\udc77\uda18\udf53\uda33\udebe\uda74\udf61\ud83e\udf62\ud990\udcaf\uda1b\uddf4\udacd\ude36\uda93\ude9b\ud81e\udf03\ud8cf\udda8\udb78\udc52\udb1a\udf50\udb47\udd9e\uda6a\udcb7\uda01\udd44\ud80b\udfea\ud85f\udcc4\uda64\udeed\ud806\udd6c\udac7\udf90\ud819\udc34\ud9fe\udcea\udb25\ude35\ud9df\udc8e\udaf0\udc20\uda57\ude0f\ud8b5\ude4e\uda15\udf0f\udb9b\udec2",
        21, 50927, 67226239, 6857846654307074359L, -86671L, true, false, (char) 31217, (char) 16269,
        Double.longBitsToDouble(0x3fd5eb0ef9d8f190L), Double.longBitsToDouble(0x3fc521244a6c0ba4L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Integer:800\0121=java.lang.Integer:800\012",
        Z.run(T, 2, 0, 0, 2, "\uda18\ude0a\000\ud97b\udece\ud9e7\udfdd\udbbb\udebd\ud9df\udefd\ud8a3\udeb2\ud910\uddb6\uda9f\udcf6\udb4d\udd1b\ud937\ude59\ud975\udf6b\ud9a6\udd7c\ud912\udfbc\udaf6\udf2b8\udabf\udd3e\ud828\udeaf\udaff\ude8a\udb44\udc90\udb7f\udcc1\ud824\udcf6\ud934\udc71\ud9b0\udd27", "\uc289\ua1f9\u8145\u1c89\u1410\uadb5", "\uda02\udcb6",
        -3, 54022, 875682264, -5127203766442992848L, -14869L, true, false, (char) 20109, (char) 62625,
        Double.longBitsToDouble(0x3fe8bb3f54a4f6baL), Double.longBitsToDouble(0x3fd148815be64b52L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.SystemUtils|toJavaVersionInt|java.lang.String|static",
    "M|org.apache.commons.lang3.SystemUtils|getJavaHome||static",
    "M|org.apache.commons.lang3.SystemUtils|getJavaIoTmpDir||static",
    "M|org.apache.commons.lang3.SystemUtils|getJavaVersionAsFloat||static",
    "M|org.apache.commons.lang3.SystemUtils|getJavaVersionAsInt||static",
    "M|org.apache.commons.lang3.SystemUtils|getJavaVersionMatches|java.lang.String|static",
    "M|org.apache.commons.lang3.SystemUtils|getJavaVersionTrimmed||static",
    "M|org.apache.commons.lang3.SystemUtils|getOSMatches|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.lang3.SystemUtils|getOSMatchesName|java.lang.String|static",
    "M|org.apache.commons.lang3.SystemUtils|getSystemProperty|java.lang.String|static",
    "M|org.apache.commons.lang3.SystemUtils|getUserDir||static",
    "M|org.apache.commons.lang3.SystemUtils|getUserHome||static",
    "M|org.apache.commons.lang3.SystemUtils|isJavaAwtHeadless||static",
    "M|org.apache.commons.lang3.SystemUtils|isJavaVersionAtLeast|float|static",
    "M|org.apache.commons.lang3.SystemUtils|isJavaVersionAtLeast|int|static",
    "M|org.apache.commons.lang3.SystemUtils|isJavaVersionMatch|java.lang.String,java.lang.String|static",
    "M|org.apache.commons.lang3.SystemUtils|toJavaVersionInt|java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
