package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud869\udd4e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\uda0d\udcad"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud805\udd01\ud91e\udeff\ud910\udf7f\u460d\ud8fa\udd84"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud907\udd00\ud997\udf16\udac3\udcc8\udb99\udeb3\ud8dc\udceb\uda7d\uddc4\ud921\uddfe\udba0\udda3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud869\udd4e\ud825\udf33\udaa7\ude99\ud983\udf7d\ud8ef\udcea\udab6\udea7\udb67\udc03\uda1e\udc19\ud9b0\udfc8\ud8e1\udc12\udab8\ude17\ud8c1\udc9a\uda59\udfc3\ud9f0\udcc8\uda10\udcd8\ud871\udd45\ud9b7\udfc6"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud9c1\udce4\ud9ec\udd1b\ud828\udcc9"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udaf9\udc91\uda47\udcf6\udaa3\udce9\udb12\udc0d\uda13\ude36\ud94b\udc49\udb1a\udd00\ud827\udf18\ud917\ude22\udaf6\ude7b\uda5e\udd92\ud9ec\ude5e\ud9e8\udeb8\udb97\udcc7\ud8e2\udd6c\u0d6f\ud818\udfc2\ud8f2\ude11\ud8b0\ude45\ud9bb\udd38\ud8a4\ude69\udbe1\udde5\ud8ec\udd6e\udacf\udcb6\u588b\uda6e\udd26\ud88d\udddd\ud910\udd4a\ud8a7\uded5\udb5a\uddab\uda73\udd10\ud90d\uddc1\uda13\uddc9\uda27\udc2a\uda04\ude22\udb50\udd29\ud92b\udf4b\udbf7\udcf8\udb16\udc27\ud927\udeb9"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud869\udd4e\uda2b\udf58\udbb6\ude62\udbcd\ude09\udb60\udd54\ud8d2\udc30\udb76\udd9f\udbae\ude54\uda23\ude72\ud96f\udf10\ud94a\ude50\udbd1\udd72\ud8ac\udee3\udae7\udc49\uda9c\udebe\uda6a\udf7a\udb26\udfb4\ud971\udfd3\udb29\udf83\uda30\uddea\udb22\uddad\udbab\udddb\ud834\udffc\ud9d7\udd43\uda01\udffa\udadd\udcc1\uda5b\udd1c\udb31\ude67\ud88a\udc36\udbee\udff4\udafd\udffa\ud937\udd77\ud874\udd9b\ud893\udcfd\u974c\ud99e\uddb9\ud8ee\udfdb\udb78\udd5a\ud8e1\ude65\udb06\udf76\udb61\ude42\udaf7\udd73\udaf8\udd51\ud8e0\udc79\uda53\udd5d\ud883\udf7f\ud982\udeb6\uda52\udc1b\ud80d\udebc\uda41\udc08\udba7\udd77\ud804\udf93\u95f7\ud833\ude6b\udad8\udde1\udb8a\udfae\ud9ed\udf58\ud986\udd3f\udab8\udef4\ud868\udf02\udb56\udf1f\ud825\udc6d\udb82\uddd9\udb84\udfb2\udbd9\udff9\udaf9\udec3\udb1e\udc41\ud91d\ude79"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.NumberUtils.createNumber("\uaa55");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8cb\uddd3\udb71\ude2d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8c6\udd0d\ud85a\uddbe\uda41\ude6e\ud982\udc14\uda9b\udf38\ud999\udc7f\ud9a7\udee7\uda3c\udf59\ud9a6\ude86\ud9df\udd02\uda3a\uddf0\udaf6\udc93\udafc\udc97\udbb8\udd56\udab6\udcdd\ud8a9\udd2c\udbe2\udd5e\uda73\udc7ef"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8c6\udd0d\ud85a\uddbe\uda41\ude6e\ud982\udc14\uda9b\udf38\ud999\udc7f\ud9a7\udee7\uda3c\udf59\ud9a6\ude86\ud9df\udd02\uda3a\uddf0\ud991\udda1\udb5a\udef2\udbb8\udd56\udab6\udcdd\ud8a9\udd2c\udbe2\udd5e\udbc3\ude26d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8c6\udd0d\ud8d3\udc7a\ud9b3\udfad\ud982\udc14\uda9b\udf38\ud999\udc7f\ud9a7\udee7\ud9f9\udf5c\uda45\udeb5\ud9db\udda7\uda3a\uddf0\udaf6\udc93\udafc\udc97\udbb8\udd56\udab6\udcdd\udb22\udc90\udbe2\udcf9\udb9f\udd54l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8c6\udd0d\ud85a\uddbe\uda41\ude6e\ud982\udc14\uda9b\udf38\ud999\udc7f\ud9a7\udee7\uda52\udced\ud9a6\ude86\ud9df\udd02\uda3a\uddf0\udaf6\udc93\udafc\udc97\udbb8\udd56\udab6\udcdd\ud8a9\udd2c\udbe2\udd5e\uda73\udc7e8"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud88a\udcaf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8f7\udd6a\uedcc\udacf\udf7b\ud9c5\udc0e\ud887\udc9d\ud8e8\udf7d\udb6b\uddfc\ud803\udcaa\ud9bb\udf27\u66f5\u5d20\ud86c\ude69\ud90a\udd0e\ud9de\ude77\ud91d\udc25\ud83e\udc42\ud869\udd71\ud954\ude17\ud98d\udcd1e\udada\udf7c\uda14\udedf\uda5b\udef6\uda94\ude5f\ud9b7\udcf2\udb3c\ude01\udbff\udf34\udba2\udcb0\u5ace"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud982\udd0b\ud85a\uddbe\uda41\ude6e\ud982\udc14\uda9b\udf38\ud999\udc7f\udb49\udfd8\000\ud9a6\ude86\ud9df\udcda\uda3a\uddf0\ud991\udda1.\000\udab6\udc38\ud8a9\udd2c\udbe2\udd5e\udbc0\udc05d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8f7\udd6a\uedcc\udacf\udf7b\ud9c5\udc0e\ud887\udc9d\ud8e8\udf7d\udb6b\uddfc\ud803\udcaa\ud9bb\udf27\u66f5\u5d20\ud86c\ude69\ud90a\udd0e\ud9de\ude77\ud91d\udc25\ud83e\udc42\ud869\udd71\ud954\ude17\ud98d\udcd1e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\uda82\udebd\ud85a\uddbe\uda41\ude6e\ud982\udc14\uda9b\udf38\ud999\udc7f\udb48\uddc6\000\ud9a6\ude86\ud9df\udced\ud94e\udf19\ud991\uddcb.\000\udad3\udfbd\ud8a9\udd2c\udbe2\udd2b\ud892\uddea5"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udaef\udf4b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb95\udd40\ud97f\udc89\ud8f7\udf27\ud981\udfde\uda9b\udf38\ud999\udc7f\ud9a7\udee7\uda52\udced\udbc7\ude76\ud9df\udd4f\uda3a\uddf0\udaf6\udc93\ud9b7\udfb5\ud8e8\udc92\udab6\udcdd\ud87b\udfee\udbe2\udd5e\ud94f\udd6cD"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8d5\udfcf\ud85a\uddbe\uda41\ude6e\ud982\udc14\uda9b\udf38\ud999\udc7f\uda81\udc36E\ud9a6\ude86\ud9df\udcda\uda3a\uddf0\ud991\udda1.\udb71\udc28\udab6\udd2b\ud8a9\udd2c\udbe2\udd5e\udbc0\udc05d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud982\udd0b\ud9a2\udfaf\udbd8\udec5\udb33\udc40\uda9b\udfc4\ud999\udc7f\udb49\udfd8\u4c00\ud9a8\udd06\ud82b\udc7f\ud9ff\udfe5\udbc0\udcca\ud830\uddc8\000\udab6\udc38\ud8a9\udd2c\udbe2\udd5e\udbd6\udf70F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud982\udd0b\ud9a2\udfaf\udbd8\udec5\udb33\udc40\uda9b\udfc4\ud999\udc7f\udb49\udfd8\u4c00\ud924\udca0\ud82b\udc7f\ud9ff\udfe5\udbc0\udcca\ud813\uddc8\000\udab6\udc38\ud8a9\udd2c\udbe2\udd5e\u2319L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud982\udd0b\uda51\udcd9\u1a51\ud982\udc14\uda9b\udf38\ud999\udc7f\udb49\udfd8\000\ud9a6\ude86\ud9df\udcda\uda3a\uddf0\ud991\udda1.\000\udab6\udc38\ud8a9\udd2c\udbe2\udd5e\udaed\udc91E"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\uda82\udebd\ud85a\uddbe\uda41\ude6e\ud932\ude4c\uda90\ude1d\udabf\udcf6\ud932\udec4\000\ud828\ude87\ud9df\udced\ud94e\udf19\udb26\uddf6e\000\udad3\udfbd\ud8a9\udd2c\udbe2\udd2b\udbc2\udc445"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8d5\udfcf\ud85a\uddbe\uda41\ude6e\ud982\udc14\ud8c7\uddae\uda02\udef4\uda80\udfa9E\ud9a6\ude86\ud9df\udcda\uda64\udea5\uda98\udd7d\020\udb71\udc28\udab6\udd2b\ud9f3\udc9f\udbe2\udd5e\ud8e3\udcd7l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber(".\udad5\udd32\uda19\udddc\udadb\ude40\ud83f\udc82\ud9bc\udf30\udb7c\uddc0\uda94\uddfd"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb12\udfdd\uda73\udc90\ud9fd\udeb2\ud982\udc14\uda9b\udf19\ud999\udc7f\udb48\uddc6\000\ud9a6\ude86\ud9df\udced\ud94e\udf19\ud991\uddcb.\ud92e\udfb3\udad3\udfbd\ud8a9\udd2c\udbe2\udd2b\ud892\uddeal"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\uda82\udebd\ud85a\uddbe\uda41\ude6e\uda52\udefd\uda86\udd3a\udabf\udcf6\udaf5\uddc5E\ud828\ude87\ud9df\udced\ud94e\udf19\udb26\uddf6e\ud998\udc4b\udad3\udfbd\ud8a9\udd2c\udbe2\udd2b\udbc2\udc445"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\u1817\uda5c\uddd9\ud9d7\udc1e\udaa8\udeb7\ud9e6\udc53\ud823\udc4a\udb17\ude0b\ud942\udc00\ud9b2\udd88\ud9df\uddad\ud94e\udf19\ud97d\ude05\udb78\udcea\uda94\udca3\uda57\udfbf\ud8a9\udd2c\udbe2\udd2b\ud892\uddeal"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\uda82\udebd\ud85a\uddbe\udb1e\udc9c\u0100\000\000\000E\ud828\ude87\ud9df\udced\ud94e\udf19\udb26\uddf6e\ud998\udc4b\udad3\udfbd\ud8a9\udd2c\udbe2\udd2b\udbc2\udc445"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\uda82\udebd\ud85a\uddbe\udb1e\udc9c\u0100\udb49\udf95\uda4a\udd800E\ud828\ude87\ud9df\udced\ud94e\udf19\ud926\udcf6\udbac\udd35\ud998\udcc4\udad3\udfbd\ud8a9\udd2c\udbe2\udd2b\udbc2\udc445"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud9c0\udf7a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud86a\ude50\ud9fa\udc56\ud918\udd83\udae2\udd53\ud826\udf6e\uda8a\udec2\uda51\udf31\udab7\udd69\u4ccb\udbda\udc12\ud864\udecc\udb7f\ude04\uda0d\udeeb\udb82\udc9a\udb0f\udf1c\ud8ca\udd73\udb65\udcbf\ud9b0\udefa\ud9bd\udf77\ud5b6\ud83a\udce7\ud8c3\udef7\ud93f\udd33\ud86c\udfcb\udbed\udc1c\ud95c\udedb\ud828\udd3a\udb21\uddeb\ud93e\udc45\ud830\uddc1\uda66\udd25\ud91f\udeb9\udbc5\udda4\ud846\ude2f\udb1d\udebb\ud8db\udd44\udb71\udc32\uda96\udd5c\ud8e0\udce6\udb4e\udd53\udafc\udcf6\ud952\udcc5\ud8bc\udd64\ud813\udfa5\ud93a\udce2\ud94a\udd63\ud910\udf5f\udb9b\udf08\udaf6\udcb4\udbd3\ude59\udb84\udd80\ud9e0\udc6e\udb8a\udfa4\ud843\ude20\udae2\udd55\ud9b6\udc3e\uda87\ude42\uda16\udfd1\ud806\ude4a\ud8f0\udd66\u3a5e\udb65\uddac\udaa5\udde6\uda70\ude00\ud853\ude2d\udaea\udf45\ud8dd\udd93\udbce\udd81\udbb7\ude5a\udbab\udde2\ud99b\udd79\udb14\udd5a\udabe\uddd3\ud831\udf30\udb3f\udf1f\uda5c\uddcd\ud91b\udc8d\udb94\udd27\ud9b8\udeae\udb3a\udee5\u1064\ud899\uddb7\udab5\udcc5\ud979\udffd\udacb\udcb4\ud819\udea9\udafb\udda1\ud8db\uded2\udb13\udea3\udaaa\udca5\uda18\udcb3\ud9f2\udc48\ud87f\udd69\uda3e\udd60\udaaf\udd1f\udb88\ude7a\uda4b\udd52\ud879\udc9d\ud8cf\udcaa\udb37\udd9b\ud9be\udd68\udaa1\udcc8\ud96e\ude85\udb45\udc0a\ud9a5\udcbd\ud843\ude80\ud96b\udd47\udafd\udc21\ud822\udd73\ud9ff\udcd3\udac4\udf08\ud841\udeb2\ud924\udc7d\uda32\udcb4\udac0\udea6\ud99e\udf23\uda18\udf50\ud964\ude81\udb9c\ude39\ud87b\udf54\uda38\uddd9\udb51\ude28\u21c1\ud8b2\ude8b\udb08\udc16\udaa1\udfb5\ud81a\udd6b\ud8a1\udd1a\ud971\udeb6\ud907\udf01"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud86a\ude50\ud9fa\udc56\ud918\udd83\udae2\udd53\ud826\udf6e\uda8a\udec2\uda51\udf31\udab7\udd69\u4ccb\udbda\udc12\ud864\udecc\udb7f\ude04\uda0d\udeeb\udb82\udc9a\udb0f\udf1c\udb9f\uddde\ud983\ude2e\ud9b0\udea8\ud9bd\udf77\ud5b6\ud83a\udce7\ud8c3\udef7\ud93f\udd33\ud86c\udfcb\udbed\udc1c\ud95c\udedb\ud828\udd3a\udb21\uddeb\ud93e\udc45\ud830\uddc1\uda66\udd25\ud91f\udeb9\udbc5\udda4\ud846\ude2f\udb1d\udebb\ud8db\udd44\udb71\udc32\uda96\udd5c\ud8e0\udce6\udb4e\udd53\udafc\udcf6\ud952\udcc5\ud8bc\udd64\ud813\udfa5\ud93a\udce2\ud94a\udd63\ud910\udf5f\udb9b\udf08\udaf6\udcb4\udbd3\ude59\udb84\udd80\ud9e0\udc6e\udb8a\udfa4\ud843\ude20\udae2\udd55\ud9b6\udc3e\uda87\ude42\uda16\udfd1\ud873\udd30\udb84\udc08\ufd44\udb65\uddac\udaa5\udde6\uda70\ude00\ud853\ude2d\udaea\udf45\ud8dd\udd93\udbce\udd81\udbb7\ude5a\udbab\udde2\ud99b\udd79\udb14\udd5a\udabe\uddd3\ud831\udf30\udb3f\udf1f\uda5c\uddcd\ud91b\udc8d\udb94\udd27\ud9b8\udeae\udb3a\udee5\u1064\ud899\uddb7\udab5\udcc5\ud979\udffd\udacb\udcb4\ud819\udea9\udafb\udda1\ud8db\uded2\udb13\udea3\udaaa\udca5\uda18\udcb3\ud9f2\udc48\ud87f\udd69\uda3e\udd60\udaaf\udd1f\udb88\ude7a\uda4b\udd52\ud879\udc9d\ud8cf\udcaa\udb37\udd9b\ud9be\udd68\udaa1\udcc8\ud96e\ude85\udb45\udc0a\ud9a5\udcbd\ud843\ude80\ud96b\udd47\udafd\udc21\ud822\udd73\ud9ff\udcd3\udac4\udf08\ud841\udeb2\ud924\udc7d\uda32\udcb4\udac0\udea6\ud99e\udf23\uda18\udf50\ud964\ude81\udb9c\ude39\ud87b\udf54\uda38\uddd9\udb51\ude28\u21c1\ud8b2\ude8b\udb08\udc16\udaa1\udfb5\ud81a\udd6b\ud8a1\udd1a\ud95c\udf5d\ud907\udee7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud86a\ude50\ud9fa\udc56\ud918\udd83\udae2\udd53\ud826\udf6e\uda8a\udec2\uda51\udf31\udab7\udd69\u4ccb\ud8a2\udef6\ud864\udf30\udb7f\ude04\uda0d\udeeb\udb82\udc9a\udb0f\udf1c\ud8ca\udd73\udb65\udcbf\ud9b0\udefa\ud9bd\udf77\ud5b6\ud83a\udce7\ud8c3\udef7\ud93f\udd33\ud86c\udfcb\udbed\udc1c\ud95c\udedb\ud828\udd3a\udb21\uddeb\ud93e\udc45\ud830\uddc1\uda66\udd25\ud91f\udeb9\udbc5\udda4\ud846\ude2f\udb1d\udebb\ud8db\udd44\udb71\udc32\uda96\udd5c\ud8e0\udce6\udb4e\udd53\udafc\udcf6\ud952\udcc5\ud8bc\udd64\ud813\udfa5\ud93a\udce2\ud94a\udd63\ud910\udf5f\udb9b\udf08\udaf6\udcb4\udbd3\ude59\udb84\udd80\ud9e0\udc6e\udb8a\udfa4\ud843\ude20\udae2\udd55\ud9b6\udc3e\uda87\ude42\uda16\udfd1\ud806\ude4a\ud8f0\udd66\u3a5e\udb65\uddac\udaa5\udde6\ud8fe\ude48\udb1e\udd95\udaea\udf3d\ud8dd\udd93\udbce\udd81\udbb7\ude5a\udbab\udde2\ud99b\udd79\udb14\udd5a\udabe\uddd3\ud831\udf30\udb3f\udf1f\uda5c\uddcd\ud91b\udc8d\udb94\udd27\ud9b8\udeae\udb3a\udee5\u1064\ud899\uddb7\udab5\udcc5\ud979\udffd\udacb\udcb4\ud819\udea9\udafb\udda1\ud8db\uded2\udb13\udea3\udaaa\udca5\uda27\udcb3\ud9f2\udc48\ud87f\udd69\uda3e\udd60\udaaf\udd1f\udb88\ude7a\uda4b\udd52\ud879\udc9d\ud8cf\udcaa\udb37\udd9b\ud9be\udd68\udaa1\udcc8\ud96e\ude85\udb45\udc0a\ud9a5\udcbd\ud843\ude80\ud96b\udd47\udafd\udc21\ud822\udd73\ud9ff\udcd3\udac4\udf08\ud841\udeb2\ud924\udc7d\uda32\udcb4\udac0\udea6\ud99e\udf23\uda18\udf50\ud964\ude81\udb9c\ude39\ud87b\udf54\uda38\uddd9\udb51\ude28\u21c1\ud8b2\ude8b\udb08\udc16\udaa1\udfb5\ud81a\udd6b\ud8a1\udd1a\ud971\udeb6\ud907\udf01\udaa2\udde5\ud896\ude96\ud867\udd86\ud900\udc5a\udbaa\uddda\uda1a\udc1e\uda9f\udca4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud9f5\udcc2\udb4f\uddbd\uda41\ude6e\ud8b9\udf6f\ud8f3\udf01\ud8c7\ude20\udaf5\ude44E\ud828\ude87\ud9df\udced\ud94e\udf19\udb26\uddf6e\ud998\udc4b\udad3\udfbd\ud8a9\udd2c\udbe2\udd2b\uda13\ude4b."); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
}
