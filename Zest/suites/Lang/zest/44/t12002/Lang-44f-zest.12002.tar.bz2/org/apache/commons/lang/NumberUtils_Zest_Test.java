package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udafc\uddba\ud84e\udd26\ud945\ude59\ud9a5\udecb\ud9e3\udd65"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud858\uddfe\ud9d4\udcc4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udac2\udd76"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb6e\udfc3\udaa0\udc6f\udb5a\udd88\uda52\udd46\udad2\ude94\udb0c\udca2\ud986\udc89\udae8\udf22\udbc0\uddeb\udab7\udfd6\ud855\udd25\ud1f2\udb1f\uddc6\ud911\udeb5"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\uda9d\uddf0\udbc9\udec3\uda2c\udf32\udb39\udd7b\ud815\udd6e\udb37\udf4b\ud93b\udd63\ud92a\ude38\ud9d5\ude2a\ud880\udf42\uda77\udee0\u4fac\udb03\udf4a\ud814\udf04\ud813\ude15\uda3f\udc00\udb11\udfdc\ud836\udca7\uda9c\ude9f\ud856\udefb"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb5a\udcd2\ud848\uddf0\ucbc1\ud891\uddea\uda67\ude75\ud92e\udd6e\ud94c\udc41\uda80\udc24\uda8f\udfdf\ud948\ude85\u3de0\uda43\ude02\uda97\udea0\udbd7\udc83\ud929\udef0\ud919\udd7f\udab9\udc20\udb70\udfd5\u40be\ud8f9\udf21\ud991\udef5\udb59\udc32\ud9ee\udf95\uda90\udf19\ud804\uddf3\ud86c\ude7c\udacd\udcc8\udac0\ude0c\udaae\udd22\ud982\udd38\ud826\udda3\ud8e5\ude49\ud8aa\udf49\ud957\ude01\ud9f8\udfd1"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("$"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud919\udca9\udb4f\udf22\uda60\udf0d\ud8cd\udd56\udad4\udea5\udb55\ude4c\ud86f\ude72\udb0e\ude6f\udb71\udfef\ud852\udf0b\ud810\udddf\ud96d\ude49\ud864\udeff\ud9bb\udfc6\ud808\ude18\udbdb\udde8\udad9\uded6\u589b\ud99f\udef8\ud989\udf28\ud82c\udca9\udabd\uddee\ud865\udd4a\uda99\udcd2\udba8\uddc8\ud8d3\udc42\ud8ab\ude55\udb0a\uddf9\ud826\ude04\udb01\uddcc\uda11\ude8e\ud99e\udc29\uda3c\udf15\udb57\udd5f\ud97e\udc31\ud873\udc6c\ud9b8\udcf0\ucf36\ud994\udd76\udb00\ude10\udb5f\udd3a\udb53\ude06\udb90\udef7\ud846\udd2f\ud853\ude58\uda6f\uddff\ud912\uddd3\ud8dd\udc11\udbd7\udcc9\ud8a9\uddc1\ud890\udc19\ud84a\udc95\ud98a\udd27\ud8b8\udfbe\ud9f1\udc37\ud94c\ude1c\udb29\udd5d\uda1c\udd40\ud9c3\ude52\udbfb\uddec\uda6d\udd6f\udb9d\udf42\ud866\udfeb\ud832\ude07\ud968\udc41\ud9e8\udd5b\ud8cf\ude20\uda1d\udf1b\u974b\ud930\udcab\ud881\ude7e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud9df\udf69\ud8bf\udc10\ud945\ude2f\ud9a5\udee8\ud896\udf68\uda93\udc35\ud8db\udd73"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb5a\udcd2\ud848\uddf0\ucbc1\ud891\uddea\uda67\ude75\ud92e\udd6e\ud94c\udc41\uda6c\udeda\uda8f\udfdf\ud948\ude85\ud9c4\ude1a\u887d\uda97\udea0\ud9cd\udcde\uda06\ude69\ud87a\udd4b\udb1b\udcde\ud949\udf7f\ud8d5\udd70\ud8f9\udf21\ud991\udef5\udb59\udc32\ud9ee\udf95\uda90\udf19\ud804\uddf3\ud86c\ude7c\udacd\udcc8\ud82e\udda3\udb4e\udd99\uda02\udc3d\ud826\udde0\ud8e5\ude49\ud8aa\udf49\ud957\ude01\u0be6"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.NumberUtils.createNumber("\u1095");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("$\000\000\ud885\udc81\uda67\ude75\ud92e\udd6e\ud94c\udc41\ud928\uddf8\000\000\000\udbd2\udd29\uda97\udea0\ud9cd\udcde\ud9d6\udd2a\ud87a\udc54\udb1b\udcde\ud949\udf7f\udbfc\udf63\ud8f9\udf21\ud991\udef5\ud1c0\000\uda90\udec7\ud804\uddf3\ud86c\ude7c\000\000\udb46\ude02E\000\000\ud8aa\udf31\ud957\ude01\u0be6"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb5a\udcd2\ud848\uddf0\ucbc1\ud891\uddea\uda67\ude75\ud92e\udd6e\ud94c\udc41\uda6c\udeda\uda8f\udfdf\ud948\ude85\ud9db\udd85\udbea\udd35\uda97\udea0\u7887\uda06\ude2a\ud87a\udd4b\udb1b\udcde\udb81\uddfa\000\000\000\udb0c\ude66\ud9ee\udf95\uda90\udf19\ud804\uddf3\ud86c\ude7c\udacd\udcc8\ud82e\udda3\udb4e\udd99E\u00cf\ud8e5\ude49\ud8aa\udf49\000\u0bc6"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("$\000\000\udb0b\udf04\uda67\ude75\ud92e\udd6e\ud94c\udc41\ud928\uddf8\000\000\000\ud9d5\udf49\uda97\udea0\ud9cd\udcde\ud9d6\udd2a\ud87a\udc54\ud50c\ud949\udf73\udbfc\udf63\ud882\udd44\u46f0\ud9f4\ude46e\uda09\udfd2\ud804\uddf3\ud86c\ude7c\u8210\uda68\udf43\udb46\ude02E\ud819\udc0c\011\ud8aa\udf31\u5dc3\u0be6"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8e7\udc73\000\000\ud885\udc81\uda67\ude75\udb2b\udc4d\udb64\udc69\ud928\uddf8\000\000\000\udbd2\udd29\uda97\udea0\ud9cd\udcde\ud9d6\udd2a\ud87a\udc54\udb1b\udcde\ud949\udf7f\udb5f\udf04\udb8e\udebe\ud991\udebb\udade\udd14\ud96d\ude96\uda90\udec7\ud8b3\udd4b\ud86c\ude7c\000\000\ud858\ude0bE"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb5a\udcd2\udaff\udcfa\ud845\udf03\ud891\ude3e\udbe4\uded5\udbe8\udfe9\u394c\ud8d2\uddb7\ud934\udcad\udba6\udf94\ud9c0\udf52\udbea\udd35\uda97\udea0\u7887\uda06\ude2a\ud87a\udd4b\udb1b\udcde\udb81\uddfa\000\000\000\udb7f\ude0c\ud9ee\udfe1\uda90\udf19\uda8c\udf99\udabc\ude4a\udad4\udeb7\ud82e\udda3\ud955\udffd.\ud823\udeff\ud8ec\ude7a\ud8aa\udf49\000\ud9f9\udc20"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb5a\udcd2\ud848\uddf0\ucbc1\ud891\uddea\uda67\ude75\ud92e\udd6e\ud94c\udc41\uda6c\udeda\uda8f\udfdf\ud948\ude85\ud9db\udd85\udbea\udd35\udabb\udc20\u7887\uda06\ude2a\ud87a\udd4b\udb1b\udcde\udb81\uddfa\000.\000\udb0c\ude66\ud9ee\udf95\uda90\udf19\ud804\uddf3\ud86c\ude7c\udacd\udcc8\ud82e\udda3\udb4e\udd99E\u00cf\ud8e5\ude49\ud8aa\udf49\ucf5a\ud993\udc5e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udafc\uddba\udb5e\udfae\ud945\udd8a\ud9a5\udecb\ud9e3\udd65"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("E\000\udaf3\udc98\udb07\udd8e\uda67\ude5a\ud92e\udd6e\ud94c\udc41\ud928\uddf8\000\000\000\udbd2\udd29\uda97\udea0\ud9cd\udcde\ud9d6\udd2a\ud890\udc54\udb1b\udcde\ud949\udf7f\udbfc\udf63\ud8f9\udf21\ud991\udef5\ud1c0\uda5d\udf0e\uda90\uded3\ud804\uddf3\ud86c\ude7c\uf2e6\000\udb46\ude02E\000\000\ud8aa\udf31\ud976\ude74\udbf5\ude5e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb5a\udcd2\udab0\ude24\uda54\udcd7\udaa6\udc0d\udb76\udcdd\ud909\udc1e\ud94c\udc41\uda6c\udeda\uda8f\udfdf\ud948\ude85\ud9db\udd85\udbea\udd35\uda97\udea0\u7887\uda06\ude2a\ud87a\udd4b\udb1b\udcde\udb81\uddfa\000\000\000\udb0c\ude66\ud9df\ude95\uda90\udf19\ud804\uddf3\ud86c\ude7c\udacd\udcc8\ud82e\uddc5\udb4e\udd99E\u00cf\ud8e5\ude49\udada\udcf8."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("$\000\000\udb12\udf04\uda67\ude75\ud92e\udd6e\ud94c\udc41\ud928\uddf8\000\000\uda46\udfa3\ud9d6\udc24\uda97\udea0\ud9cd\udcde\ud9d6\udd2a\ud87a\udc54\uda99\udc9e\ud949\udf73\udbfc\udf63\ud882\udd44\u46f0\ud9ed\udc30\uf5a3\udba0\udfb1\ud9a3\udda4\ud86c\ude7c\u8210\uda68\udf43\ud8c4\udcc2\udb1e\udc0d\udb80\uddf3.\ud8aa\udf31\u5dc3\u0be6"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8e7\udd4c\000\000\ud885\udc81\ud960\udf92\ud91c\udda9\udb64\udc5b\ud928\uddf8\ud921\udc0f\ud9b8\ude4a\ub11f\udbfd\udf39\uda97\udea0\ud9cd\udcde\ud9d6\udd2a\ud87a\udc54\udb1b\udcde\ud9c2\udf8d\uda50\uded5\udb42\udf4f\ud991\udebb\udb91\udd0e\udb2b\udf7f\ud861\udd53\ud8b3\uddc1\ud86c\ude7c\ud8df\ude4e\udb7b\udef1\ud858\udee0F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8e7\udd4c\000\000\ud885\udc81\ud960\udf92\ud91c\udda9\udb64\udc5b\ud923\udcaa\ud8bb\udca6\ud9b8\ude4a\u1904\udbfd\udf39\ud81f\udc3b\ud9cd\udcde\ud9d6\udd2a\ud87a\udc54\udb1b\udcde\ud85e\udc9b\ud9e1\ude00\udbea\udd7a\ud98e\udcbb\ud9d6\udf02\uda4a\udf1f\ud895\udfc8\ud8b3\uddc1\ud86c\ude7c\ud8df\ude4e\udab2\ude4d\udaeb\udf89f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8c0\udde3\000\uda69\uddb9\uda71\udc97\ud960\udf32\uda29\udd10\udb64\udc5b\ud948\udc26\ud909\udd43\ud82f\udddc\udab5\udfad\udbfd\udfe4\ud81f\udc3b\ud87b\udcd5\udb17\udd83\ud87a\udc54\udb1b\udcde\ud85e\udc9b\u5dfc\udbea\udd7a\ud9cb\udeba\ud9d6\udf29\uda4a\udf1f\ud895\udfc8\ud8b3\uddc1\ud86c\ude7c\ud9b7\ude5a\udab2\ude4d\udaeb\udf63L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8c0\udde3\000\uda69\uddb9\uda71\udc97\ud960\udf08\u00dc\000\ud933\udd78\ud909\udd43.\ud891\udd68\udbfd\udfe4\ud81f\udc3b\000\000\ud86a\udf54\udbfd\udf90\ud83c\udd9d\u5d44\udbea\udd7a\000\000\000\000\ud88a\udce4\ud86c\ude7c\ud9b7\ude5a\udab2\ude4d\udaeb\udf63L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8c0\udde3\000\uda69\uddb9\uda71\udc97\ud8fc\udcfb\u00dc\000\ud933\udd78\ud909\udd43\udb7f\ude26\udaa5\udecf\uda18\udc0c\ud869\udfa7\ufba9\000\u7bec\udb45\udd93\ud881\udf3c\udbcb\udc49\udbea\uddba\ud8d8\ude0cE\udb44\udea2\ud84d\ude36\ud88a\udce4\udaeb\udd9b\ud8b7\udc24\ud85b\udec1\udaeb\udf6dL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8e7\udc73\000\000\ufb9e\ud924\udf1d\udb2b\udcc2\udb64\udc69\ud928\uddf8\000\u7d07\ud9fc\ude96\udbd2\udd29\uda97\udea0\ud9cd\udcde\ud9d6\udd2a\ud87a\udc54\udb1b\udcde\ud949\udf7f\udb5f\udf04\udb8e\udebe\ud991\udebb\udade\udd14\ud96d\ude96\uda90\udec7\ud8b3\udd4b\ud86c\ude7c\000\000\ud9bd\udcfdd"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb5a\udda3\udab0\ude24\uda54\udcd7\udaa6\udc0d\udb76\udcdd\ud909\udc1e\ud94c\udc41\uda6c\udeda\ud88e\udd6f\ud960\udf8d\ud9db\udd85\udbea\udd35\ud980\udd16\udb1b\udc12\udbe0\udd3d\ud87a\udd4b\udb1b\udcde\udb81\uddfa\000\000\000\udb0c\ude66\ud9df\ude95\uda90\udf19\ud804\uddf3\ud86c\ude7c\udacd\udcc8\ud82e\uddc5\udb4e\udd99E\u00cf\ud8e5\ude49\udada\udcf8D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud8e7\udc73\000\000\ufb9e\ud924\udf1d\udacb\ude58\ud84a\udc07\udbd7\udc2e\ud819\udeb2\udb09\udc49\uda05\udf6b\udaae\udff6\udac1\udc08\udbf1\udc30\ud9d6\udd2a\ud87a\udc54\udb44\udfd4\u7e5a\ud803\ude0b\udb8e\udebe\udac6\udc74\ud80e\udd6e\uda6a\udf78\u159b\ud8b3\udd4b\ud86c\ude7c\000\ud89f\udf7e\udbf8\udc18l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("$\000\000\udb0b\udf04\ud991\udccb\ud918\udfc6\ud94c\udc41\ud928\uddf8\udb06\udde2.\000\udb11\udf47\uda7a\udfb3\ud8bc\udf56\ud9d6\udd2a\ud87a\udc54\udaad\udd07\ud949\udf73\udbfc\udf63\ud882\udd44\u46f0\ud9f4\ude46e\uda09\udfd2\ud804\uddf3\ud86c\ude7c\u8210\uda68\udf43\udb46\ude02E\ud952\udfdb\ud9a7\udc26\udad7\udff0\u5dc3\ud850\udecb"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\udb5a\udcd2\ud848\uddf0\ucbc1\ud891\uddea\ud8cf\udee9\ud92e\uddeb\ud94c\udc41\uda6c\udeda\uda8f\udfdf\ud948\ude85\ud9db\udd85\udbea\udd35\udabb\udc20\u7887\uda06\ude2a\ud87a\udd4b\udb1b\udcde\udb78\ude410.\uda6a\udd6f\udb1f\udde9\ud8b7\udf79\ud956\udf9e\uda59\uddf8\ud86c\ude7c\udb05\udfdf\uda3e\ude4c\udb4e\udd99E\u00cf\ud8e5\ude49\ud8aa\udf49\ucf5a\ud993\udc5e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang.NumberUtils.createNumber("\ud91d\ude2a\ud84e\udd26\ud945\ude59\ud9a5\udecb\ud9e3\udd65"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
