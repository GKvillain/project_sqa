package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\ud98a\udc67\ud95a\udeb2\uda1d\udcda\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\uda02\udec7\uda7e\udfc8\uff78\udb73\ude8e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb4a\udf4b\udac7\udc8d\ud953\udc47\ud835\udcb5\ud8d7\udde5\ud98a\udc67\ud95a\udeb2\uda1d\udcda\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\udaa5\udd2f\udb70\udfc1\uda7e\udfc8\uff78\udb73\ude8e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\ud98a\udc67\ud95a\udeb2\uda1d\udcda\udb74\udfa3\ud905\udeaf\ud8c6\udd4d\uda2e\ude34\uda02\udec7\uda7e\udf83\uff78\udb73\ude8e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udb4a\udf4b\udbf4\ude04\ud84a\udf42\udaf1\udcb3\ud8d7\udde5\ud996\udd3b\uda3c\udeb6\uda1d\udcda\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\u5fca\ud9f5\udfd4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb4a\udf4b\udbf4\ude04\ud84a\udf42\udaf1\udcb3\ud8d7\udde5\ud996\udd3b\uda3c\udeb6\uda1d\udcda\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\u5fca\ud9f5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\udb4c\ude5f\ud96f\ude32\udaf3\uddc9\uda24\udf9d\udb26\udf40\udbfb\udd7b\udb08\ude43\uda2e\ude34\ud84d\udc8c\uda7e\udef4\uff78\udb73\ude8e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb04\udea4\udbe8\udc97\ud876\ude42\u896c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\udb4a\udf4b\udac7\udc8d\ud9b5\udeb8\ud83f\udc9f\ud948\udce0\ud98a\udc67\ud95a\udeb2\udbba\ude2c\udb5c\uddb1\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\uda02\udec7\ud88f\udf29\ufefe\udb73\ude8e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb4a\udf4b\udac7\udc8d\ud9b5\udeb8\ud83f\udc9f\ud948\udce0\ud98a\udc67\ud95a\udeb2\udbba\ude2c\udb5c\uddb1\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\uda02\udec7\ud88f\udf29\ufefe\udb73\ude8e", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\ud98a\udc6f\ud95a\udeb2\uda1d\udcda\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\uda02\udec7\uda7e\udfc8\uff78\udbf8\udd31");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\ud98a\udc6f\ud95a\udeb2\uda1d\udcda\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\uda02\udec7\uda7e\udfc8\uff78\udbf8\udd31", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\udaa9\udf39\udac7\udc8d\ud84a\udf42\ud846\uddb5\uda33\ude53\ud98a\udc4a\u50e9\ud823\udf48\ud9a2\udc6d\ud88a\ude6a\ud8c6\udd4d\uda2e\ude34\udaaf\udcbc\udb97\udf1d\uffa2\udb73\ude8e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\udb4a\udf4b\udac7\udc8d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb4a\udf4b\udac7\udc8d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\ud9d9\udf10\ud95a\udf3f\udaa3\udcdd\udb74\udfa3\ud960\udc9d\ud8d6\udf4d\uda1e\ude5f\uda02\udec7\ud889\udfad\udab2\uddf1\udb73\ude8f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\udb4a\udf4b\udac7\udc8d\ud84a\udf42");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\udb4a\udf4b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\udaea\udf71\ud8a7\ude48\uda5a\udc4e\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\uda02\udec7\uda7e\udfc8\uff78\u00fc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\udaea\udf71\ud8a7\ude48\uda5a\udc4e\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\uda02\udec7\uda7e\udfc8\uff78\u00fc", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb4a\udf4b\udbd8\udd15\ud84a\ude88\ud83a\udfb5\ud8d7\udde5\ud98a\udc67");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udb4a\udf4b\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\ud8bc\ude09\ud95a\udeb2\uda1d\udcda\udb74\udfa3\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\uda02\udec7\uda7e\udfc8\uff78\udb73\ude8e\udbd8\ude26\udb48\udfd8\ud9a5\udf38\ud801\uddd9\ud812\udf32\udb19\udcfa\ud838\udd91\u0c56\uda6b\ude6f\udb7e\udf0c\ud9b6\udcc5\uda63\udfcf\uda2a\udcc4\u7c38\udb3c\udc19\ud8bb\ude21\udb69\udeb2\udb62\uddbc\ud967\udc58\udb0e\udeaf\udaa2\udd37\udafc\udf41\ud888\udc4a\ud949\udea0\uda95\uddc0\uda07\udf83\udafa\udcaa\udaf4\udcd3\uafe6\ud98a\udcd5\udb30\ude9b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\uda9b\ude3a\udac7\udc8a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u5030\udb89\udf76\ud9ec\udc51\udba7\udc9f\ud8b5\udf1e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\uda8a\udda3\ud82e\uddbf\ud868\udd2c\ud84b\udc71\udbd8\udc40\ud8b8\udd80\ud8ea\ude46\uda9d\udd52\ud8b8\ude04\uda5c\udc32\udb6b\udec8\ud82b\udcc1\ud953\udeaa\ud839\udf8f\uff78\udab4\udc4f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud88b\udd11\ud96b\udc63\ud911\ude65\ud87b\udd09\ud810\udd65\ud905\udd91\ud925\udec0\ud9a8\ude32\uda0d\udc10\ud849\udf05\udb00\ude1a\uda18\ude70\uda02\udec7\ud87d\ude27\udb8d\uddfc\udbb2\ude79");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud88b\udd11\ud96b\udc63\ud911\ude65\ud87b\udd09\ud810\udd65\ud905\udd91\ud925\udec0\ud9a8\ude32\uda0d\udc10\ud849\udf05\udb00\ude1a\uda18\ude70\uda02\udec7\ud87d\ude27\udb8d\uddfc\udbb2\ude79", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud958\udcbb\udbc6\ude68\udb49\uddbc\ud835\udd4f\uda52\udde2\ud991\udfa6\udbcd\uddc2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud958\udcbb\udbc6\ude68\udb49\uddbc\ud835\udd4f\uda52\udde2\ud991\udfa6\udbcd\uddc2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\udb28\udd76");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\uda6b\udeba\uda0d\udedd\udb3d\udd8e\ud843\udf1e\uda1b\udde7\ud98a\udc67\ud95a\udeb2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud90f\ude0c\udb34\udd35\ud94b\udd9c\uda7f\udd30\udad5\udccc\udbf7\udcb4\udb9f\udd66\uda21\ude0b\udb74\udfa3\ud90a\udd72\udb6b\udeda\ud8a9\udd4f\ud952\udea5\uda94\udfef\uff78\ud8fe\udff4\udb45\udd19\ud82c\udd09\ud909\udf7d\uda09\udd5d\ud901\uddaa\udb05\uddaf\udb6c\udcb3\udb9f\udcc9\ue0f5\uda33\udda4\ud84b\udec3\udb1d\udd56\udb48\udced\uda44\udd84\ud9ab\udf4d\udb28\udf62\ud966\udded\ud9e2\ude40\udb3f\udcba\ud89a\ude17\ud830\udd05\ud9ef\udcd0\ue2ce\uda08\udc4c\udb87\udd21\ud9a2\udef3\udb1d\udf12\ud97c\uddd7\udb59\udd3b\u2d0a\udb39\ude73\ud8a9\udca9\ud906\uddf9\uda24\uddcc\udbf7\udd43\ud959\udcaf\ud802\udec9\ud91e\udc76\ud821\ude3a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udac9\udd45\udac7\udc8d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udac9\udd45\udac7\udc8d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u97e2\udac7\udc8d\ud859\udc9c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud8d1\udf0e\u6fbb\uda0f\udc80\ud835\udcb5\uda5f\udce2\ud98a\udc67\uda75\udffa\uda14\udeef\ud828\udc9e\ud905\udf06\ud8c6\udd4d\uda2e\ude34\udb61\udd35\uda75\udd9f\ud9b4\udf84\uda46\udf2a\udac0\udecb\ud9b4\udd93\uda5a\udedb\ud9a1\udea8\udb1a\ude9e\ud95e\udd30\udae3\udd0e\ud930\udcda\udb2e\udf04\udbda\udc50\ud93b\udced\ud9f7\ude17\udb38\udefd\ud95a\uddc9\ud87f\udeca\udb30\udd1f\ud9bf\udca3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8d1\udf0e\u6fbb\uda0f\udc80\ud835\udcb5\uda5f\udce2\ud98a\udc67\uda75\udffa\uda14\udeef\ud828\udc9e\ud905\udf06\ud8c6\udd4d\uda2e\ude34\udb61\udd35\uda75\udd9f\ud9b4\udf84\uda46\udf2a\udac0\udecb\ud9b4\udd93\uda5a\udedb\ud9a1\udea8\udb1a\ude9e\ud95e\udd30\udae3\udd0e\ud930\udcda\udb2e\udf04\udbda\udc50\ud93b\udced\ud9f7\ude17\udb38\udefd\ud95a\uddc9\ud87f\udeca\udb30\udd1f\ud9bf\udca3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("%");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("%", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u500b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud823\ude32");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud823\ude32", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\uda52\udcda\ud8d7\ude44\uda58\udd08\ud892\udfe4\ud944\udf86\udabe\ude4f\ud841\udd76\uda69\uded2\udb89\udc50\ud960\udc9d\ud8c6\udd4d\ud9df\udfd3\uda22\udf51\udacf\ude25\udb0f\udf16\uda37\ude4f\udbfd\uddf8\udbcf\uddd4\ud9b2\udf69\ud9bc\udf41\ud912\udcdc\udb85\ude93\ud949\udee2\ucd33\ue862\uda34\udec4\ud91d\udd14\ud972\udd6d\ud849\udd1b\uda7d\udcac\uda67\udcc6\ud90e\uddfe\uda39\udcd5\udbcd\udf88\udbee\ude0d\ud8ea\udf25\ud878\udcc2\uda97\uddc8\ud815\udeb3\ud9e2\udfa2\udaf2\udc07\udb25\ude92\ud84f\ude58\u0afb\ud8ca\udc52\ud9e2\ude37\udb7f\udcfd\udb4f\udc42\ud930\uded6\udb89\udc4e\ud996\udcd0\ud826\uddcb\ud94d\udf26\udbc7\ude4c\udb3d\ude57\uda54\udcff\ud993\ude60\ud8b0\udf62\ud93c\udef8\uda17\ude7d\udb58\udeb7\udb81\udf37\ud901\udf1f\udb79\udf77\udaf3\uddce\udaeb\udfc2\udb7e\uddc9\udbb1\udd5d\udb48\udd41\ud814\udfd6\uda3a\udce3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u5030");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("%");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u3f18\udaca\udc44\udadc\udd2b\udaf9\udc86\udb8e\udc27\udb7f\udda5\udafb\udfea\ud81f\udc65");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud993\udf67\uda95\udc6c\udaae\udcee\ud835\udcb5\ud8d7\udde5\ud9d5\udf10\uda1c\udc73\udaa1\udc33\uda46\udfc3\ud967\udd9d\ud8d6\udf4d\ud82f\uddc6\ud8ee\udd7c\u955a\udab2\uddf1\udb73\ude8f\udb32\udedf\ud9ac\udc49\uda3d\ude43\ud97f\udd7c\ud988\udfb7\udb76\udec2\u7c05\ud895\udd3e\ud9d6\udd77\ud8dc\udfd8\udb3d\udc50\ud9d4\udf38\udace\udd1a\uda62\udd2e\ud8fd\udc7e\uda2a\udd46\ud96d\udd7c\udac5\udde8\ud8fb\udd11\uda65\ude66\ud9fa\udf1c\ud965\udd0c\ud8cc\udc17\ud87e\udf78\ud804\udfa2\ud859\udd6f\u6027\u9547\udb49\udd84\uda32\udf74\ud10d\u7b29\udbe0\udf3d\udbe6\udf8c\udad8\udc39\uda14\uded9\ud972\udfd1\uda87\udf71\ud89f\udf09\udba7\udcdc\udaad\udd7d\uda3a\udd62\ud8c3\udf1c\udae2\uddeb\u7751\ud841\udf8f\udab2\udfb6\ud879\uded9\udae5\udd98\ud896\udde2\u9167\udab7\udcb5\ud9a9\udc2d\uda9a\udce3\u9309\ud83f\udf30\udb7c\udf98\ud885\ude1f\udbe9\uddb6\uda2b\udc8b\ud8fb\udf84\uda38\uded0\udabc\udd7a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u8358");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u5030\u60bf\ud9e4\udc51\udba7\udc9f\ud8b5\udf1e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u5030\ub1cd\udb55\udf56\ud90c\udf0e\uda51\udd38");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u97e2\u804e\udaa9\udf4b\ud9d8\udf78\udb9d\udd71\uda5b\udfbf\ud962\ude63\uda6d\udc45\ud91a\udf0c\uda3e\udca5\ub68b\ud8f5\udcbc\udbf8\udca2\ud99e\ude0e\ud9f9\udf41\ud96f\udec0\udabd\ude87\udab4\udc84\ud969\udeb8\ufba7\ud8d5\ude60\ud9ff\udfd1\ud807\ude44\ue6df\udb21\udf12\ud894\udcb0\udb40\ude3c\ud750\udb56\udfc2\udaf8\uddb6\ua1d8\uda3f\udddd\udab9\udc15\ud88f\udded\ud8bb\udd23\ud99a\udc67\ud870\udfea\ud931\udde4\ud99a\udc0a\ud92b\udcdb\udb55\udf27\ud9c3\udc0b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u2c75\ud1e5\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud993\udf67\uda95\udc6c\udaae\udcee\ud835\udcb5\ud8d7\udde5\ud9d5\udf10\uda1c\udc73\udaa1\udc33\uda46\udfc3\uda26\uddfa\ud8d6\udf4d\ud82f\uddc6\ud8ee\udd7c\u955a\udab2\uddf1\udb73\ude8f\ud880\udec6\ud9c6\udcf9\udb1c\udf0b\uda63\udeb1\ud989\udc3d\udb76\udec2\udb87\udc6a\ud878\udd2b\ud9d6\udd77\ud8dc\udfd8\udb3d\udc50\ud90d\ude3a\udaca\udd68\uda62\udd2e\ud8fd\udc7e\uda2a\udd46\ud96d\udd7c\udac5\udde8\ud8fb\udd11\uda65\ude66\ud9fa\udf1c\ud965\udd0c\ud8cc\udc17\udbbf\udd5a\ud827\uddce\ud859\udd6f\u6027\udb89\ude59\udb34\udcf4\uda32\udf74\ud10d\u7b29\udbe0\udf3d\udbe6\udf8c\udad8\udc39\uda14\uded9\ud972\udfd1\uda87\udf71\ud89f\udf09\udba7\udcdc\udaad\udd7d\uda3a\udd62\ud8c3\udf1c\udae2\uddeb\u7751\ud841\udf8f\udab2\udfb6\ud879\uded9\udae5\udd98\ud896\udde2\u9167\uda0b\udd5e\ud9d6\udf61\u9361\u92b3\ud83f\udf30\u77da\ud885\ude1f\ud8b5\udebb\uda2b\udc2d\ud8fb\udf84\uda38\uded0\udabc\udd7a\ud8a3\udde4\ud95e\udea2\udad3\udc4f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud993\udf67\uda95\udc6c\udaae\udcee\ud835\udcb5\ud8d7\udde5\ud9d5\udf10\uda1c\udc73\udaa1\udc33\uda46\udfc3\uda26\uddfa\ud8d6\udf4d\ud82f\uddc6\ud8ee\udd7c\u955a\udab2\uddf1\udb73\ude8f\ud880\udec6\ud9c6\udcf9\udb1c\udf0b\uda63\udeb1\ud989\udc3d\udb76\udec2\udb87\udc6a\ud878\udd2b\ud9d6\udd77\ud8dc\udfd8\udb3d\udc50\ud90d\ude3a\udaca\udd68\uda62\udd2e\ud8fd\udc7e\uda2a\udd46\ud96d\udd7c\udac5\udde8\ud8fb\udd11\uda65\ude66\ud9fa\udf1c\ud965\udd0c\ud8cc\udc17\udbbf\udd5a\ud827\uddce\ud859\udd6f\u6027\udb89\ude59\udb34\udcf4\uda32\udf74\ud10d\u7b29\udbe0\udf3d\udbe6\udf8c\udad8\udc39\uda14\uded9\ud972\udfd1\uda87\udf71\ud89f\udf09\udba7\udcdc\udaad\udd7d\uda3a\udd62\ud8c3\udf1c\udae2\uddeb\u7751\ud841\udf8f\udab2\udfb6\ud879\uded9\udae5\udd98\ud896\udde2\u9167\uda0b\udd5e\ud9d6\udf61\u9361\u92b3\ud83f\udf30\u77da\ud885\ude1f\ud8b5\udebb\uda2b\udc2d\ud8fb\udf84\uda38\uded0\udabc\udd7a\ud8a3\udde4\ud95e\udea2\udad3\udc4f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u2c75");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\udaf3\udffa\udaa8\udc8d\ud84a\udf42");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud800\udc25\u00e5\000\000\ud8d7\udde5\036\000\000\000\ud960\udc9d\ud8c6\udd4d\uda2e\ude34\u00b4\uda7e\uded7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u0566\ud960\udc9c\ud87e\udd87\uda47\udd97\ud8c7\udd0a\udbcf\udec9\uda26\udf59\u80ad\ud945\ude87\ud8c0\uded7\udae3\ude49\udbe3\ude34\ud93a\ude5b\ud8db\udea8\ud961\udc4c\udb73\ude8e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("%\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\udaea\udf71\015\000\udb74\udfa3\uda87\udd90\ud8c6\udd4d\uda2e\udda8\uda02\udec7\uda7e\udfc8\udb81\udde0\u00fc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("%\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\udaea\udf71\000\udb74\udfa3\uda87\udd90\ud8c6\udd4d\uda2e\udda8\uda02\udec7\uda7e\udfc8\udb81\udde0\u00fc", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u5030\u60bf\u528b\ud97d\udc4d\ud8b5\udf1e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\036\uda76\udfe6\udbbd\udfe7\ud835\udcbe\ud8d7\udde5\udaea\udf71\015\udafb\udc9d\ud81a\uddda\udb2f\udec7\uda9a\udcc2\ud903\udc8f\udaaa\udd84\u8ca1\uda31\udd30\ud8fa\ude1d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda76\udfe6\udbbd\udfe7\ud835\udcbe\ud8d7\udde5\udaea\udf71\udafb\udc9d\ud81a\uddda\udb2f\udec7\uda9a\udcc2\ud903\udc8f\udaaa\udd84\u8ca1\uda31\udd30\ud8fa\ude1d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("%\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\udaea\udf71\015");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("%\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\udaea\udf71", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u5030\ub1cd\u4656\ud90c\udecd\uda51\udd38");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\uab65\u00e5\ucc00\000\ud8d7\udde5\udb11\udc24\udafd\udf84\ud94f\ude3d\udbb4\udfce");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u2c95\ud1e5s\ud565");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u3f18\u5363\u656f\ud836\udde6\udb8e\udc27\udb6b\udd63\uda02\uddcd\udb0f\udd0b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("%\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\udaeb\udf6a\012");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("%\udac7\udc8d\ud84a\udf42\ud835\udcb5\ud8d7\udde5\udaeb\udf6a", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("%\udac7\udc8d\ud84a\udf42\ud8ed\ude15\ud8d7\udde5\udaeb\udf6a\012");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("%\udac7\udc8d\ud84a\udf42\ud8ed\ude15\ud8d7\udde5\udaeb\udf6a", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u2c90\uff22\uda86\udfcb\uda9d\udcd2\udbf5\udfa5\udbb2\ude73\ud9de\udc76");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
