package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\uda4f\udcac\uda3a\udea4\uda68\udecf\udb81\udfe2\udacf\udfcf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\uda4f\udcac\uda3a\udea4\ud94d\udfcb\udb81\udfe2\udac7\udfcb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda4f\udcac");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda4f\udcac", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\u7b3f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\ud8e7\udcaf\ud824\udeaf\udb91\udf9f\uc59d\udb25\udd8a\uda04\ude94\udbea\udf6e\ud9d1\udcd0\ud951\udf68\ud910\ude63\ud8d9\udef1\udb1b\udf9c\ud9bd\udea1\udbf0\udda4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8e7\udcaf\ud824\udeaf\udb91\udf9f\uc59d\udb25\udd8a\uda04\ude94\udbea\udf6e\ud9d1\udcd0\ud951\udf68\ud910\ude63\ud8d9\udef1\udb1b\udf9c\ud9bd\udea1\udbf0\udda4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\udbcd\udd89\ud75c\udb0f\ude9e\uda20\udf86\ud8a7\udff5\ud8f1\udd10\udaf4\udc7f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbcd\udd89\ud75c\udb0f\ude9e\uda20\udf86\ud8a7\udff5\ud8f1\udd10\udaf4\udc7f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\uda4f\udcac\uda3a\udea4\uda68\udecf\udb81\udfe2\udacf\udfcf\ud917\ude92\ud973\ude58\u2e74\uda4c\ude6f\udaa1\udda8\uda4f\ude2b\ud8da\udfa8\uda0d\udcd4\ud826\udeff\uda86\udc14\udad4\udc5c\uda98\ude6d\u6701\ud9c4\udd6a\udaee\uddc7\ud9c3\udfea\ud8ef\udfb1\ud84d\udf05\ud9ad\udd81\u5914\ud93b\ude36\udb89\udce6\ud873\udc5f\ud890\ude0c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\ud93a\udc3c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud93a\udc3c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\uda4f\udcac\ud910\udd90\ud83f\udee6\udb81\udfe2\ud851\udc91");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\uda4f\udcac\uda3a\udea4\uda68\udecf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ud989\udde9\u12f7\uda68\udecf\udb13\udcec\udacf\udfcf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda4f\udcac\uda3a\udea4\udb2e\udd92\ud993\udcd0\ud925\udfbc\ud969\udc8d\udbd3\uddeb\uda1b\udefd");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda4f\udcac\uda3a\udea4\udb2e\udd92\ud993\udcd0\ud925\udfbc\ud969\udc8d\udbd3\uddeb\uda1b\udefd", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udab2\udf7e\ud9e8\udf3a\uda7d\ude87\uda10\udc2a\ud956\udf18\udbdc\udf89\ud81a\udc85\udb89\ude8b\udba8\udfc9\ud8c4\udd10\ud95d\udf7b\ud999\udd41\ud98b\udcfd");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udab2\udf7e\ud9e8\udf3a\uda7d\ude87\uda10\udc2a\ud956\udf18\udbdc\udf89\ud81a\udc85\udb89\ude8b\udba8\udfc9\ud8c4\udd10\ud95d\udf7b\ud999\udd41\ud98b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u6115\ud89d\udcfb\u0372\ud8d7\udd2a\udb24\ude21\ud88e\udd4b\ud8c7\udd43\udb6e\uddb4\uda3f\udcea");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud93b\udca2\uda3a\udea4\uda68\ude63\u9ab6\udaba\udfdc");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda7a\udf6f\ud930\udc2d\ud85c\ude8e\ud801\ude60\udbf0\uddb5\udbe8\uddbb\u88c7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda7a\udf6f\ud930\udc2d\ud85c\ude8e\ud801\ude60\udbf0\uddb5\udbe8\uddbb\u88c7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u802d\uda31\udeab\ud9cb\udf31\ud999\udcbe\udb03\uddd9\ud864\udd85\udb65\ude6c\udb97\udc67\uda2d\udf3b\ud9db\udcf9\ud84e\udf74\ud8a3\udffb\udbc5\udd12\ud9ca\uded8\uda1d\udcf8\ud8f3\ude68\ud952\udd9c\uda61\uddd2\udb71\udfd9\ud8fa\udedc\ud85d\udf3b\ud9e0\udde7\ud897\udf8f\u2a85\ud8a3\ude5f\udaa7\udfee\ud9bd\udcfc");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\udb9d\udfcf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\udbdd\udf51\uda75\udeb9\u795b\uda13\ude63\udacf\udfcf\udac1\udd31\ud830\udf98\ud883\ude71\ud90e\ude9b\uda68\ude0c\udbb3\udcbc\udbc0\udfc9\u0e3e\udbeb\udd0c\uda1d\udd29\uda77\udde6\uda1a\udc16\ud9f3\ude7f\ud968\udff6\u529c\ud912\ude38\ud9e4\udf19\ud949\udd2b\ud873\udc48\uda6e\ude09\ud84e\udccf\ud9f6\ude3a\ud8d9\udfe7\udaad\ude60\ud9ef\udf6e\ud977\udcc2\ud9fa\udc5a\udb0d\udcae\ud8fa\udf4b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ud813\udc66\uda3a\udebc\udb28\udd0e\uda57\ude44\ud8ba\ude8f\ud9c1\ude1f\uda75\udf78\ud805\ude69\ud940\uddba\ud84d\ude8e\u8d28\ud964\udc31\uda73\udf7c\ud9bd\ude23\ud999\udccb\ud82b\uddd1\ud8ce\ude04\ud8c6\udd00\udb21\udc04\ud80d\udc74\ud9ee\udce5\ud801\udde9\ud883\udd08\ud89c\udefe\ud8c6\udf97\uda4b\udea0\ud8bf\udf2b\udbc9\udf47\udb9e\udfa5\ud8b4\udea4\ud910\udd28\udbc7\udec6\ud84f\udce1\udac3\udfdc\ud858\udcf1\udb2c\udda1\udb74\udf2a\udb3d\udc37\ud908\uded8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u0466\000\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud995\udc12\udadf\ude20\uda56\uddcf\udb81\udfe2\udacf\udfcf\ud881\ude40\udbfc\uddb6\uda65\udc5d\udad5\udd34\ud9f8\udc21\udb90\udfa0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\uda4f\udce4\u3043\uda68\udf0b\udb81\udfe2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\uda2c\udf75\ud801\ude5d\u9868\ud8b5\ude5c\ud9b2\uddb7\udb41\udf67\udbd5\udcb9\udbb0\udfe2\ud860\udd16\udb32\ude38\udbc7\udd89\uda1d\udcb2\u5fa3\udb40\udd61\udb61\udd9d\udb4e\udf6a\ud9cb\udf9f\ud9fe\udfbe\ud88f\udddb\ud911\udd1d\udb3a\udfe0\ud9ee\ude39\udb93\udd89\u4767");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb37\udcbe\uda6d\udf37\ud969\udddc\ud925\ude76\ud8bb\udd41\uda8a\uddd8\ud846\udc66\ud880\uddff\udb08\udca6\ud8c0\udcfa\uda96\udc06\uda17\udea0\udbb0\udfcb\ud87f\udda3\ud974\udf1e\ud87d\udfbd\udae2\udfbf\udada\udfe8\ud8b6\udf45\udae8\udfe5\ud9a4\udf9f\ud8f7\udc70\ud98b\udc1c\uda8e\udefe\ud96b\ude3e\uda2a\udd15\ud96a\udc48\uda32\udc63\ud923\udd3d\ud9e2\udea0");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb37\udcbe\uda6d\udf37\ud969\udddc\ud925\ude76\ud8bb\udd41\uda8a\uddd8\ud846\udc66\ud880\uddff\udb08\udca6\ud8c0\udcfa\uda96\udc06\uda17\udea0\udbb0\udfcb\ud87f\udda3\ud974\udf1e\ud87d\udfbd\udae2\udfbf\udada\udfe8\ud8b6\udf45\udae8\udfe5\ud9a4\udf9f\ud8f7\udc70\ud98b\udc1c\uda8e\udefe\ud96b\ude3e\uda2a\udd15\ud96a\udc48\uda32\udc63\ud923\udd3d\ud9e2\udea0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udbf3\uddee\ud8dd\ude2c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbf3\uddee\ud8dd\ude2c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u9b38");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u9b38", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\udbe9\udcea\ud9d4\udc6c\ud9bd\udcaf\ud8ec\udede\ud955\uddd9\uda34\uddea\ud9e8\uddcb\ud836\udd40\udb6b\udef6\ud85c\udef8\udbf7\uddd1\udb6a\udd5b\u42e6\udb0f\udde6\ud99b\udccc\ud8cd\udc6f\ud9b8\udf95\ud80a\udd29\ud97e\ude64\uda2b\udd3a\udabf\udc19\uda63\udec3\ud8aa\udd23\uda89\udcc8\udad1\udf8a\udace\ude34\ud807\udc9d\ud940\udf28\ud9f4\udd1b\uda6a\ude92\ud950\udd54\ud9cf\udd5f\ud9c5\uded6\udb97\udd8b\ud973\ude08\udab5\ude83\udba1\udef7\ud842\udd11\udbcc\udc88\ud8d4\ude84\udaa7\udecd\ud8dd\udc62\uda80\udcc2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u7b3f\udafb\udf29\ud9ba\ude60\ud9c9\udc22\udb91\udfd8\udacc\udfa3\uda75\udebf\ud925\udd0e\udbc8\udd35\ud8ae\udfb7\ud809\udcf6\ud860\udff0\udb14\ude48\ud994\udcf3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u9134\ud8c6\udfd8\u682d\ud9f0\udcad\udb83\ude61\u7046\ud8db\ude07\uda5b\uddba\udb78\udc8b\u301e\udbdd\ude12\ud8e6\ude55\udb18\udf53\udb89\udf90\ud9b3\udf4b\udb9d\ude9e\uda35\udf38\udbf1\udeac\ud912\udf32\uda36\ude1a\uda57\udce1\ud964\udd98\ud8f2\ude3d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u3a3f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\ud8e7\udcaf\ud824\udeaf\udaa2\udee8\uc568\udb25\udd8a\uda04\ude94\udbea\udf6e\ud9d1\udcd0\ud992\ude44\uda74\udd8f\ud869\udf76\udba1\udf81\ud9ac\ude3e\udbf0\udda4\ud826\udcc6\udb17\udff0\ud8a4\udc38\udb34\udee0\ud942\uddf6\ud92b\udf49\uda47\udece\udbb6\udddd\udaea\uddc3\u26ed\ud8ed\udd16\ud8f6\udcfc\uda8e\udc17\u2960\udb97\ude85\ud938\udfc1\ud845\ude09\ud821\udd2c\uda5a\udc8d\ud993\udcea\ud915\udd07\ud91f\udd06\ud9de\udf85\udb14\udcd6\uda58\ude2b\uda49\udd22\ud8c7\udfc5\udaac\ude66\ud8d5\udd1b\udb19\udd99\ud926\udc97\udb77\udebe\ud910\udcd1\ucbd5\udb6d\udd6b\ud916\ude43\udb9f\udc5e\ud9dc\uddc9\u1fa3\uda8b\uddf9\ud9c2\udc0f\ud9c3\udeb9\ud8b8\udd61\ud9c3\uddf2\ud9b5\udc9e\uda60\udea6\udbc7\udfcd\udbf8\udd75\ud8c7\udca5\u6e69\ud9a0\uddfb\ud951\udf1b\ud9f1\udf8d\ud90f\udd5f\ud9e7\udc62");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8e7\udcaf\ud824\udeaf\udaa2\udee8\uc568\udb25\udd8a\uda04\ude94\udbea\udf6e\ud9d1\udcd0\ud992\ude44\uda74\udd8f\ud869\udf76\udba1\udf81\ud9ac\ude3e\udbf0\udda4\ud826\udcc6\udb17\udff0\ud8a4\udc38\udb34\udee0\ud942\uddf6\ud92b\udf49\uda47\udece\udbb6\udddd\udaea\uddc3\u26ed\ud8ed\udd16\ud8f6\udcfc\uda8e\udc17\u2960\udb97\ude85\ud938\udfc1\ud845\ude09\ud821\udd2c\uda5a\udc8d\ud993\udcea\ud915\udd07\ud91f\udd06\ud9de\udf85\udb14\udcd6\uda58\ude2b\uda49\udd22\ud8c7\udfc5\udaac\ude66\ud8d5\udd1b\udb19\udd99\ud926\udc97\udb77\udebe\ud910\udcd1\ucbd5\udb6d\udd6b\ud916\ude43\udb9f\udc5e\ud9dc\uddc9\u1fa3\uda8b\uddf9\ud9c2\udc0f\ud9c3\udeb9\ud8b8\udd61\ud9c3\uddf2\ud9b5\udc9e\uda60\udea6\udbc7\udfcd\udbf8\udd75\ud8c7\udca5\u6e69\ud9a0\uddfb\ud951\udf1b\ud9f1\udf8d\ud90f\udd5f\ud9e7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u00e3\u1a04\ud981\udce0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\uda4f\udcac\uda3a\udea4\uda68\udecf\udb81\udfe2\udacf\udf43\ud917\ude92\ud973\ude58\u2e74\uda4c\ude6f\udaa1\udda8\uda4f\ude2b\ud8da\udfa8\uda0d\udcd4\uda85\uddee\uda85\udfd1\udbaf\ude92\uda98\ude6d\u6701\udb6e\udd5f\udaee\uddc7\ud9c3\udfea\ud8ef\udfb1\ud84d\udf05\ud9ad\udd81\u5914\ud93b\ude36\udb89\udce6\ud873\udc5f\ud890\ude0c\udbf9\udd21\uda16\ude1a\udb0c\udf58\ud984\udf49\udb09\ude59\udbed\udfb9\ud9ca\udcdb\ud8f8\udd55\udb3f\udccf\ud94c\ude72\udb3a\ude22\ud902\ude41\ud88d\udd55\udb35\udd3c\udac3\udef6\ud886\udcaa\ud874\udcf5\ud8a2\udda5\udaff\udc17\ud9bc\uddf3\ud85a\udf5b\ud99a\udf49\u66d8\ud9a0\udeca\udb90\ude2a\ud840\udfdd\uda97\udd25\u4275\uda37\udee0\udaa7\udf52\udb50\udf2a\uda89\uddbb\ud90b\udf08\ud93e\udffe\udb6c\udecf\ud824\udcbf\ud847\udf21\uda35\udf7a\udb66\udc18\ud914\udc90");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud9f5\udf65\ud870\uded2\ud83c\ude4c\ud90d\udda0\ud854\udf2e\ud8a0\udc6c\ud8d0\udcdf\ud89b\udd1e\uda07\ude80\ud8ae\udc63\uda9a\ude84\ud868\uddc4\ud8f4\udf43\udb6d\udcba\ud9db\udd9d\udbee\udc27\udb1c\ude92\ud94b\udeae\uda12\udff6\u6707\uda0f\udfdb\udb62\ude2e\ud88d\udc82\ud949\uddce\udabf\udc90\ue384\udbc8\udfdc\ud98b\ude8f\u5b8f\ud90d\ude4a\ud8b9\udeff\uda66\ude49\ud8f4\udf83\uda45\uddfe\udaa5\udfed\ud92f\udcc9\udb2e\uddfb\ud9b2\ude48\udb0a\udf6c\udacd\udd6c\ud8e1\ude0d\ud9b7\udc63");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9f5\udf65\ud870\uded2\ud83c\ude4c\ud90d\udda0\ud854\udf2e\ud8a0\udc6c\ud8d0\udcdf\ud89b\udd1e\uda07\ude80\ud8ae\udc63\uda9a\ude84\ud868\uddc4\ud8f4\udf43\udb6d\udcba\ud9db\udd9d\udbee\udc27\udb1c\ude92\ud94b\udeae\uda12\udff6\u6707\uda0f\udfdb\udb62\ude2e\ud88d\udc82\ud949\uddce\udabf\udc90\ue384\udbc8\udfdc\ud98b\ude8f\u5b8f\ud90d\ude4a\ud8b9\udeff\uda66\ude49\ud8f4\udf83\uda45\uddfe\udaa5\udfed\ud92f\udcc9\udb2e\uddfb\ud9b2\ude48\udb0a\udf6c\udacd\udd6c\ud8e1\ude0d\ud9b7\udc63", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("f\u12f7\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u6115\u4196\u12d3\ud8d7\udc68\udb24\ude21\ud88e\udd4b\ud8c7\udd43\udb6e\uddb4\uda3f\udcea");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u802d\u7661\ud9d8\udeea\ud999\udcbe\udb03\uddd9\ud864\udd85\udb65\ude6c\udb97\udd2e\uda2d\udf3b\udad4\udf16\ud9f1\uddc8\ud8a3\udfd6\udbc5\udd12\ud9ca\uded8\uda1d\udcf8\ud8f3\ude68\ud952\udd9c\uda61\uddd2\udb71\udfd9\ud8fa\udedc\ud85d\udf3b\ud985\udebf\ud898\udc3d\u2a85\ud8a3\ude5f\udaa7\udfee\ud977\ude16");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u041a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u0443\000\ud822\uddf6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u041a\u1f08\ud82e\udf58\ud82b\udfb2\uda45\udf0b\ud9bd\udc25\udad8\udc2b\ud85c\udcad\udbb9\udec8\ud977\udd2d\u58cc");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\uec56\uda3a\udeb4\ud9bb\udd69\ud8f3\udde8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u0466\ub100\u8d7f\udb1d\udc62\udb47\udfdd\uda1f\ude46\udb2e\udc86\ud962\uddb6\udaf6\udffd\ud896\udfdf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud807\udebe\uda45\udf35\udb56\uddaf\udba0\ude73\uda03\udd44\ud998\udde9\ud948\uded8\udb1e\udc3b\ud994\udce8\ud961\udece\uda54\udf05\ud91b\udd9a\ud93a\uded0\ud80f\udf72\ud938\udeed\udbba\udcd9\udb6c\udc48\ud803\udda2\uda70\udf82\ud899\udc09\udb83\udfff\ud92f\udee5\ud90e\udfbf\ud8a7\udda8\udb25\udf65\ud8b5\ude7b\ud84d\udfe1\udbe3\udd08\udb62\udef7\ud8b6\udc39\udb6f\udf43\ud85a\udc10\ud965\udda3\udbaf\udf30\ud8ba\udf73\ud9c3\udd8b\ud993\udc3e\ud8ac\ude9f\ud998\udebc\ud92e\udc13\ud11e\uda2c\udc89\ud9b4\udf9f\udb24\ude77\ud8cd\ude7b\ud959\udee8\udade\udd7e\u9a61\udb83\udd71\udaa5\udea1\udb3f\udef0\uda8f\udfbf\udb9e\uddc2\udba6\udcaf\udb14\udc55\ud923\udce3\ud841\udfa4\udb78\udf9d\ud8b8\udd83\ud8ec\udf05\uda14\udc80\uda86\udcf9\udb8a\udf6c\ud89b\udc86\udb75\udc63\uda70\ude96\ud9fd\udc63\ud80a\uddcb\udb01\udfe3\ud90e\udfa5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb24\ude73\udae4\ude87\ud873\uddd6\ud956\udeb1\udb25\udd8a\uda04\ude94\udbea\udf6e\ud9d1\udcd0\ud992\ude44\uda74\udd8f\ud869\udf76\udbb6\udf81\ud9ac\ude3e\udbf0\udda4\ud826\udcc6\ud82e\udedc\ud8a3\udfc0\ub74c\udaf6\uddc1\ud92b\udeae\uda6b\udd71\udbb6\udddd\udaea\uddc3\u26ed\ud8ed\udd16\ud8f6\udcfc\uda8e\udc17\ud931\udc52\udbd3\udc0f\ud933\udd21\udba6\udfda\uda68\udd71\udac3\udc56\uda76\udff1\ud915\udd07\ud947\udd06\uda93\ude1f\udbbd\udc8f\udbfe\udd41\udbdc\uddd3\ud8c7\udfc5\udaac\ude66\ud8d5\udd1b\udb19\udd99\ud926\udc87\udb77\udebe\ud910\udcd1\ucbd5\udb6d\udd6b\ud916\ude43\udb9f\udc5e\ud9dc\uddc9\u1fa3\uda8b\uddf9\ud9c2\udc0f\ud9c3\udeb9\ud91c\udd5f\ud9c3\uddf2\ud9b5\udc9e\uda60\udea6\udba8\udd2b\udb81\udf18\udbce\udeda\udaf7\uddcb\ud9a0\udebb\ud951\udf1b\ud9f1\udf8d\ud90f\udd5f\ud9e7\udc62");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb24\ude73\udae4\ude87\ud873\uddd6\ud956\udeb1\udb25\udd8a\uda04\ude94\udbea\udf6e\ud9d1\udcd0\ud992\ude44\uda74\udd8f\ud869\udf76\udbb6\udf81\ud9ac\ude3e\udbf0\udda4\ud826\udcc6\ud82e\udedc\ud8a3\udfc0\ub74c\udaf6\uddc1\ud92b\udeae\uda6b\udd71\udbb6\udddd\udaea\uddc3\u26ed\ud8ed\udd16\ud8f6\udcfc\uda8e\udc17\ud931\udc52\udbd3\udc0f\ud933\udd21\udba6\udfda\uda68\udd71\udac3\udc56\uda76\udff1\ud915\udd07\ud947\udd06\uda93\ude1f\udbbd\udc8f\udbfe\udd41\udbdc\uddd3\ud8c7\udfc5\udaac\ude66\ud8d5\udd1b\udb19\udd99\ud926\udc87\udb77\udebe\ud910\udcd1\ucbd5\udb6d\udd6b\ud916\ude43\udb9f\udc5e\ud9dc\uddc9\u1fa3\uda8b\uddf9\ud9c2\udc0f\ud9c3\udeb9\ud91c\udd5f\ud9c3\uddf2\ud9b5\udc9e\uda60\udea6\udba8\udd2b\udb81\udf18\udbce\udeda\udaf7\uddcb\ud9a0\udebb\ud951\udf1b\ud9f1\udf8d\ud90f\udd5f\ud9e7\udc62", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\012");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\012\ud84f\udfe3\udb49\uded8\uda81\ude5c\udbc5\udfe3\ud808\udc66\udba3\udde4\udaad\udd06\udb99\udf56\ud986\udd67\ud83e\udd2d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud84f\udfe3\udb49\uded8\uda81\ude5c\udbc5\udfe3\ud808\udc66\udba3\udde4\udaad\udd06\udb99\udf56\ud986\udd67\ud83e\udd2d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u0443\u00f3\udb8b\udc83\ud8f1\ude1a\udb3d\udfc5\ud9a7\udc02");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\012 \udb21\ude30\uda81\ude5c\udbc5\udfe3\u00fc\000\udaad\udc1e\udb99\udf56\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb21\ude30\uda81\ude5c\udbc5\udfe3\u00fc\000\udaad\udc1e\udb99\udf56\000\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u0466\ub100\u8d7f\udb1d\udc62\udb47\udfdd\uda1f\ude46\udb2d\udfbb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u0466\ub100\u8d7f\ua469\udb47\udfdd\uda1f\ude46\udb2d\udfbb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u0466\ub100\u8d7f\u5a80\ud825\udd39\uda05\udd72\udb2e\udc86\ud962\uddb6\udaf6\udffd\ud896\udfdf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u0466\ub100\u8d7f\ua469\udb45\udfdd\uda1f\ude46\udb3c\udfbb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
