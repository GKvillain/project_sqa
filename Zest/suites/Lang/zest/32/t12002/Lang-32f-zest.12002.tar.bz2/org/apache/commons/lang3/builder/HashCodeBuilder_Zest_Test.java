package org.apache.commons.lang3.builder;
import org.junit.Test;
import static org.junit.Assert.*;
public class HashCodeBuilder_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde973635be8730L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 15, 17, 8, "\ud9a7\udf9f\ud944\udee1\ud80f\udc96\ud9fe\udc42\ud843\udcf2\uda8f\udf5a\ud86a\udeab\ud94a\ude6b\ud90c\udf24\ud884\udcdb\ud861\ude39\ud83c\udc31\uda02\ude49\ud982\udec0\ud9c9\udd4f\udb91\uddfa\u1bd8\udb67\uddfb\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u1cbb\ua8a2\uac76\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1",
        -4, 45743, 1418827965, 4771392186513575713L, 43771L, false, false, (char) 46404, (char) 14164,
        Double.longBitsToDouble(0x3fe6c3d212849048L), Double.longBitsToDouble(0x3fd956047b9cef70L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 7, 17, 8, "\uc164\udb93\udeb0\ud86e\uddc6\ud811\udf29\ud818\udcda\uda8f\udf5a\udbdf\uddc6\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udb07\ude32\udb43\udd75\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\uacae\u6f2d\u9c13\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        51, 32254, 1870944033, -981783613660101583L, -38509L, false, true, (char) 14800, (char) 62172,
        Double.longBitsToDouble(0x3fd9560477166418L), Double.longBitsToDouble(0x3fdd41963404e330L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 1, 6, "\ud9a7\udf9f", "\u343e\u7d64\u3286\u0422\ucd34\u5598\u0b67\ua470\u90c7\u3ba4\u07ff\u1f4a\u766b\ua260\u5811\u80f9\u35db\ub0fd\u015d\u8d7a\u5e00\u0645\uc12f\u2cb4\u45d3\u2a6d\ub572\u2c4c", "\uda23\udc52\uda12\udcc6\uc154\udbc3\udfff\udad4\udd9c\udaad\udd75\udb5f\uddb8\udbe7\udfd0\ub5cd\ud923\udea0\ud8b1\udece\udb38\udf54",
        37, 95735, -1262131749, 6937622071237939605L, 95072L, true, true, (char) 41737, (char) 53517,
        Double.longBitsToDouble(0x3fd0dff3a1b9dd66L), Double.longBitsToDouble(0x3fb613a62f2d1e28L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[true, true, false, true, false, false, false, false]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 16, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud810\udef0\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u161f\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313\uc928\u89ac\ua482\u49c6\u44dc\u9302\uc264", "\udb9e\udd25\ud996\ude63\udb34\uddf2\ud9e9\ude84",
        36, 79847, 1175196053, 8314607725440412137L, 97806L, true, true, (char) 49461, (char) 35818,
        Double.longBitsToDouble(0x3fe25677b148be50L), Double.longBitsToDouble(0x3fce84c3ce77f808L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27788.0, 28550.0, 27785.0, 28327.5, 27679.0, 28363.0, 27913.0, 28282.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 1, 12, 17, 8, "\ud948\udf3c\ud942\udd7f\ud86e\uddc6\uda42\udd25\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud963\ude93\ud973\udee4\ud80d\udc67\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udb62\ude5a\udae7\udc22\udbf6\udeda\ud8ac\ude4b\ud982\udc77\uda13\udf46\ud8a6\udcd8", "\u2cb4\u45d3\u2a6d\ub572\u91ed\u6222\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75\udb5f\uddb8\udbe7\udfd0",
        55, 12495, -1303437894, 5518657630652112429L, 47515L, true, true, (char) 63262, (char) 18641,
        Double.longBitsToDouble(0x3fde97363404e330L), Double.longBitsToDouble(0x3febdb69e2c9433dL)));
  }
  @Test
  public void test7() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test7() throws Throwable {
//     assertEquals("0=java.lang.Boolean:true\0121=void\012",
//         Z.run(T, 2, 16, 17, 16, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\udab5\udff6\uda8f\udfed\ud86a\udeab\uda13\ude47\ud814\ude3c\ud884\udcdb\ud875\ude3b\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udbab\udffa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b", "\ud7b9\u0911\uc12f\u2cb4\u45d3", "\ud9f5\udcda\u2764\uf93b\uda23\udc52\uda81\udf6d\ud819\udcf9",
//         43, 84920, -962281257, 6093819709446190324L, 17280L, true, false, (char) 14164, (char) 35030,
//         Double.longBitsToDouble(0x3fc09209042a8c1cL), Double.longBitsToDouble(0x3fed623061e97363L)));
//   }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\ud9b5\udf86\ud885\udca0\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u421b\u2afd\u2c4c\u6210\u5e8d\u3360\ub71c\u89ea\ua482\u49c6\u44dc\u34f8\uc264\u2d50\u5712", "\udb34\uddf2\ud9e9\ude84\uda44\udc42\ud9f4\udc30\udb07\uddb5\udb36\ude78\udaf0\udc9a\uda7a\udcb0\ud8f6\udda0",
        11, 80083, 1121499369, -8555494983936586986L, -21354L, false, false, (char) 7913, (char) 43229,
        Double.longBitsToDouble(0x3fca48d5a9ed32c8L), Double.longBitsToDouble(0x3fc37b4001e6c7d4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 16, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\ud8c1\udffe\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27668.0, 28382.0, 27797.0, 28534.5, 27793.0, 28377.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 3, 6, "\ud9a7\udf9f\ud858\uddec\ud95a\udf1d\ud952\udde2\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udbc7\udc20\uda5a\udf1d\udbe3\udf75",
        33, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 57445,
        Double.longBitsToDouble(0x3fd9560207588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud9a7\udf9f\ud90e\udde7\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u0183\uc959", "\ud9c9\udf23\udad4\udda4\udaad\udd75\udb5f\uddb8\udbe7\udfd0\ub5cd\ud923\udea0\udb9e\udd25\ud996\ude63\udb34\uddf2\ud9e9\ude84\uda44\udc42\ud9f4\udc30\udb07\uddb5\udb36\ude78\udaf0\udc9a\uda68\udfa9\udb5b\udcb8\udb6c\udd87\ud805\udf54\udb38\ude92\udbe1\udc84\ud840\udd24\ud8c1\udee6\udad7\udf07\ud993\ude33\uda9e\udcc6\udbe6\udde2\ud81d\udd36\udbcd\udd33\ud8b0\ude72\ud8d6\udeb6\udafd\ude42\ud900\udd21\udafd\udd85\ud8fb\udc18\udbdd\udd64\udae5\udda3\udacc\udff6\uda64\udcaa\udabf\ude57\uda9c\udfef\ud92b\udf66\udbda\udd9b\ud93f\ude64\ud87e\udeca\udbf7\udd47\u19ca\ud9d6\udcd9\udb5b\udead\ud8aa\udc64\ud8e9\udfe0\ud9fe\uddef\uda86\udc9d\ud9e7\udfcc\ud936\udce8\ud9f7\ude21\uda16\udd61\u3cc1\uda7f\ude8b",
        5, 14887, 912703722, -6378572062478168913L, 13364L, false, true, (char) 39279, (char) 10565,
        Double.longBitsToDouble(0x3fefd919a2dd0bdeL), Double.longBitsToDouble(0x3fa3af624a12fb90L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 11, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\udb07\udf56\ud86a\udeab\ud9ff\ude47\ud8e3\udfe2\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub4fa\u2c4c\u7a6f\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        55, 24047, -2026625137, -3680856195963347466L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477590390L), Double.longBitsToDouble(0x3fde973634ab3b5eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[3886.5, 28095.5, 28138.5, 27679.0, 28343.5, 27793.0, 28381.0, 27730.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\u1e8d\udbaf\udc05\ud86e\udd9f\ud952\uddea\ud8d4\udf23\ud97a\udeaf\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\udaf5\udc33", "\u07ff\u1f4a\u8162\ua1c0", "\udbf6\udf02\ud92b\udc6a\uda28\udd58",
        36, 40160, 1715584991, 7780866882868571474L, 71028L, true, true, (char) 21946, (char) 62326,
        Double.longBitsToDouble(0x3fe07ef6db811719L), Double.longBitsToDouble(0x3fcab0c4910cf418L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 7868.0, 27636.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 9, 12, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\u3da8\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\udb42\udee6\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\ud895\udfd4\uda8e\udf9d\ud992\uddcd\udbfb\ude05\ud8bc\ude6d\udbf6\udeda\ud8ac\ude4b\udbc5\udfd7\ud855\udc13\udbe5\ude45", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 26260, 1899450145, -2018808598073729529L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 13, 12, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\udbc2\udd48\ud842\udfe8\ud98f\udcf4\udbf1\ude92\ud96c\uddcf\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\ud875\udde3\ud956\ude46\ud991\udda8\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2f89\uab5a\ud4a7\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\uda60\udc4d",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, false, (char) 14788, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=void\012",
        Z.run(T, 2, 12, 17, 10, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\udaf7\uddac\ud9ff\ude47", "\u2b6b\u19f7\u3ba4\u07ff\u1f4a\u8162\ua1c0\u5811\u5b28\u6404\u3949\u015d\ud4b5\u93e1\u5f85\uc1bd\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313\uc928\u89ac\ua482\u49c6\u44dc\u34f8\uc264\u2d50\u5712\u79a5\u23e7\u188b\u46be\u62cd\u5322\ua433\u6b6a\u008b\u93a6\u630e\u2525\u1959\u7d73\u3a47\u205a", "\udb62\udf96\ud957\udd7e\ud986\udc48\ud9cd\udde0",
        59, 51345, -232800309, 1758883541100667248L, -11932L, false, true, (char) 44265, (char) 64445,
        Double.longBitsToDouble(0x3fec6d39a4431a0fL), Double.longBitsToDouble(0x3fe9d6f8935e2eebL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[B:[[-20, -8, 5, -19, 62, -106, -18, -22]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[27894.0, 28412.0, 27778.5, 28278.5, 27679.0, 28363.0, 27767.0, 28149.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 6, 10, 8, "\uda1c\ude28\ud935\udd1d\ud86e\uddc6\ud91e\udc1a\ud822\uddfb\uda8f\udf5a\ud86a\ude93\ud9c1\udd1a\uda00\udfdc\ud9d0\udc11\uda41\udfec", "\u5d45\uc9b4\u8162\ua1c0", "\udbf6\udeda\ud8ac\ude4b\udb75\udfa9",
        28, 40304, 1715584991, 7780866882868571474L, -14082L, false, false, (char) 1382, (char) 8353,
        Double.longBitsToDouble(0x3fc0f724910cf418L), Double.longBitsToDouble(0x3fe544228e07f349L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud9a7\udf9f\ud942\udde1", "\uabef\u3671\uc63a\ucd6a", "\ud861\ude39\ud9aa\uddc8\udbb1\udcb8\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\udb64\uddf1\ud93b\udda4\udb6b\udcb3\udabf\udde5\ud809\udf92\ud879\ude21\uda11\udd9c\udbe5\udf12\udbbd\udd8b\ud9f5\udcda\u2764\uf93b\uda23\udc52\000\000\udb74\udef9\udad4\udda4\udaad\udd75\udb5f\uddb8\udac8\udfe3\ub5cd\ud923\udea0\uda91\uddbe\ud996\ude63\udb34\uddf2\ud9e9\ude84\uda44\udc42\ud9f4\udc30\udb07\uddb5\udbcf\udec6\udaf0\udc9a\ud861\udc24\ud943\ude99\uda98\udea4\udbb3\udfb6\udbed\udd59\ud962\udfc8\udb97\udd86",
        10, 33239, -519545572, 479809025330386183L, -48846L, true, false, (char) 56780, (char) 61078,
        Double.longBitsToDouble(0x3fecfc9a4e0286f8L), Double.longBitsToDouble(0x3fe9440c725034e5L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@2a1 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@2a1\012",
        Z.run(T, 2, 0, 13, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\ud899\udcff\udbd6\udd8c", "\u0b67\u2b6b\u19f7\u1c51\uc178\u1f4a\u8162", "\udae7\udc22",
        44, 99066, 1829096291, 1893064937597933112L, -91408L, false, true, (char) 50542, (char) 21946,
        Double.longBitsToDouble(0x3fd582a1f8b3bdacL), Double.longBitsToDouble(0x3fec0a96d8d58624L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[I:[[55671, 57199, 55570, 56753, 55358, 56726, 55586, 56762]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 14, 10, 3, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\udab7\udf53\uda0b\udd10\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\ud941\uddad\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3\uda29\ude2e\udb38\uddb0\ud8ff\ude55\uda11\udd9c\udbe5\udf12\udbbd\udd8b\ud89a\udc8d\u2764\uf93b\uda23\udc52\uda95\udc6d\ud819\udcf9", "\u44dc\u34f8\uc264\u2d50\u023b\u2001\u0b46\uc2cb\ua037\u54cf", "\udb36\ude78",
        9, 74466, -2038248365, 4446365483782296061L, -11727L, false, false, (char) 58331, (char) 17744,
        Double.longBitsToDouble(0x3fbd94a82dfb5a48L), Double.longBitsToDouble(0x3febbf3b95d2e29cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud9a7\udf9f\ud942\udde1", "\uabef\u3671\uc63a\ucd6a", "\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3\udabf\udde5\ud809\udf92\ud879\ude21\uda11\udd9c\udbe5\udf12\udbbd\udd8b\ud82e\udfb8\u2764\uf93b\ud9cb\udf8b\uda7e\ude16\ud819\udcf9\udb8a\udfa1\udad4\udda4\udaad\udd75\udb5f\uddb8\udbe7\udfd0\ub5cd\ud923\udea0\udb9e\udd25\ud996\ude63\udb34\uddf2\ud9e9\ude84\uda44\udc42\ud9f4\udc30\udb07\uddb5\udb36\ude78\udaf0\udc9a\udae8\udfa9\udb44\udf8b\uda37\udeb5\ud989\ude2e\uda2a\udf65\udb2b\udfb8\ud932\udeca",
        59, 95394, 1028793548, 195911063586625506L, -55433L, true, false, (char) 12278, (char) 35592,
        Double.longBitsToDouble(0x3fecf163edfa6e53L), Double.longBitsToDouble(0x3fbc0e7bc6824898L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[true, true, true, true, false, false, false, false]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 4, 3, 7, "\ud9a7\udf9f\uda9d\ude4d\ud86e\uddc6\ud952\uddea\ud818\udc64\uda8f\udf5a\ud86a\udeab\ud94e\udd2d\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\udb0b\udca6\ud8a9\udd9e\uda57\ude77\ud9bf\udd0c", "\u6404\u393f", "\udb42\udcba\udabf\udd07\ud83d\udc4c\udb5e\udc18\udab5\udc7e",
        46, 76753, 1546754938, -2388093796205524391L, -38403L, false, true, (char) 61628, (char) 24417,
        Double.longBitsToDouble(0x3fef52a48a56d9b5L), Double.longBitsToDouble(0x3fd4771b9b75c7f6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 2, 17, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud957\udcfb\ud92b\udf69\udb21\udf7e\ub9ad", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udf6c\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 10, 4, 8, "\ud9a7\udf7a\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\udb94\udf63\udae4\udc86\ud9ae\udc89\udaeb\udd37\uda67\ude9e\ud82d\udf2b\udb3a\ude68\ud992\uddcd\udbfb\ude05\udae7\udc22\udb10\ude07\ud8da\udf05\ub418\ud91e\udfb9\u28e3", "\u3bc1\u45d3\u4250\u00d1\u8ecc\u6227\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 67152, 442433495, -2018988561498432070L, 25145L, true, true, (char) 14207, (char) 45496,
        Double.longBitsToDouble(0x3fde97363404e330L), Double.longBitsToDouble(0x3fe11e4b56b74c25L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 0, 2, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud843\ude27\uda1a\udebf\ud86a\udeab\uda1d\udc50\uda3d\udde2\ud89c\uddaa\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u4b74\u2a49\ub572\u2c4c\u6210\u5e8d\u4313\uc928\u89ac\ua482\u49c6", "\u28c3\ub5cd\ud923\udea0",
        16, 90608, 1074044461, 8809875742185275096L, -95499L, false, true, (char) 40268, (char) 56218,
        Double.longBitsToDouble(0x3fed2963a80dd67eL), Double.longBitsToDouble(0x3fdae01876f143e2L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\012",
        Z.run(T, 1, 12, 17, 8, "\ud9a7\udf9f\udb5f\ude1d\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\ud85f\ude29\udb4c\udcd5\ud989\ude56\udb91\uddfa\ud992\uddcd\udaca\ude6d\ud869\udc0e\ud898\udf86\ud853\udfd2\uda67\udedd\ud93b\udda4\udaa1\udfcf", "\u2cb4\u45d3\u2a6d\u66f9\u806a\u2c6d\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 9330, -1237889247, 8418009528033811898L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[27753.0, 28163.5, 27785.0, 28376.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 10, 17, 8, "\ud902\udc37\ud942\udde1", "\uabef\u3671\uc63a\ucd6a", "\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\uda5c\udeb2\ud9bf\ude1f\ud97e\udef6\udbfb\ude05\udae7\udc22\udae3\udeef\ud898\udd40\uda6a\udf8a\ud93b\udda4\udb6b\udcb3\udabf\udde5\ud809\udf92\uda35\ude2e\uda0c\udf79\uda70\udfd7\ud835\udc74\ud9f5\udcda\u2764\uf93b\uda23\udc52\ud9eb\udef6\ud819\udcf9\udb8a\udfa1\udad4\udda4\ud98d\udc26\udb97\udc5a\udbdd\ude5c\ub5cd\uda17\udcf8\udb9e\udc9c\ud996\ude63\ud962\udd1e\ud9e9\ude84\uda44\udc42\ud9f4\udc30\udb07\uddb5\udb36\ude78\udaf0\udc9a\uda9d\udea2\uda37\udc26\udb6e\udd38\ud9af\udf46\udaa3\udf55\udbb0\udcc0\uda76\udc1a",
        21, 9677, -2014649467, 4394232093372888058L, 35699L, true, false, (char) 3478, (char) 13316,
        Double.longBitsToDouble(0x3feddd0e41591246L), Double.longBitsToDouble(0x3fc0f58b67d03068L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 15, 5, 17, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\u9130\u2c4c\u6210\u5e8d\u4313", "\ud9c0\udf9c\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fe74b9b1a027121L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 1, 17, 8, "\udbbf\udd45\ubd72\ud86e\uddc6\ud952\uddea\ud818\udc27\uadc9\ud86a\udeab\ud8fa\udce1\udb33\uddcd\ud862\udfd4\ud84f\udce5\ud83c\udc31\udbbe\ude47\ud880\udc36\ud805\udc76\uda58\ude84\u8082\ud94c\ude09\udb72\udce6\udbb9\udd3c\ud8c3\udda0\ud9aa\udd3a\ud93b\udd8e\udb6b\udcb3", "\u2cb4\u181f\u82a4\ua37d\u1e87\u6210\u5e8d\u4313\uba2e\u89ac\u7940\u2dc5\u4fb9\u34f8\uc264\u89b9\u5712\u79a5\u58a5\uc20c", "\ud9f4\udc30\udb07\uddb5\udb36\ude78\udaf0\udc9a\uda40\udc73\udbc2\ude73\ud9de\udf88\udb96\ude83",
        56, 64872, 749546659, 6160239788864227818L, 64808L, false, false, (char) 12985, (char) 55415,
        Double.longBitsToDouble(0x3fea332015e14b69L), Double.longBitsToDouble(0x3fefee4fd73c0a97L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\012",
        Z.run(T, 2, 16, 8, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud94d\uddbf\ud843\udc81\ud83c\udc31\udbbe\ude47\ud982\udec0x\udb8e\udf86\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\uce38", "\u2cb4", "\udbbd\udd8b\ud9f5\udcda\u2764\uf93b\uda23\udc52\uda95\udc6d\ud819\udcf9",
        24, 74856, -962281257, 6093819709436158954L, 17280L, true, false, (char) 14164, (char) 14618,
        Double.longBitsToDouble(0x3fe4248241956047L), Double.longBitsToDouble(0x3fed623061e97363L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 2, 2, 8, "\ud9a7\udf9f\udb6f\uddf9\u5d35\udb6d\udc76\udbb2\udc85\uda2d\udd08\ud86a\udeab\udb7a\udd83\ud8e3\udfa4\ud884\udcdb\ud96b\udf3d\udad3\udcc1\udbbe\ude47\ud982\udec0\udbcb\udd50\udabc\udd7c\ud9cf\udece\ud820\udc72\udae7\udc22\udbf6\udeda\udb46\ude85\uda4a\udc8a\ud93b\udda4\udbe3\udfbf", "\u2d15\u45d3\u2a6d\ub572\u2c4c\u95e8\u2537\u7f67", "\udb8a\udfa1\udb04\udedd\u4f3a\udaa9\udc16\udbb1\ude85\udb8c\udfe0\ud8f8\udfbf\udb9e\udd25\ud996\ude63\ud837\udce5",
        -4, 39456, 1615291012, 2155836179439190153L, 84066L, true, false, (char) 24680, (char) 59041,
        Double.longBitsToDouble(0x3fe87767504ecf58L), Double.longBitsToDouble(0x3fd94a0ad1d8cb32L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\uda7e, \udd49, \ud918, \udd1b, \ud86e, \uddc6, \ud952, \uddea, \ud818, \udc27, \uda8f, \udf5a, \ud86a, \udeab, \ud9ff, \ude47, \ud8e3, \udfa4, \ud884, \udcdb, \ud861, \ude39, \ud83c, \udc31, \udb7e, \udf1e, \udab8, \udcce, \udbcb, \udd50, \udb91, \uddfa, \ud992, \uddcd, \udbfb, \ude05, \udae7, \udc22, \udbf6, \udeda, \ud8ac, \ude4b, \uec02, \ud93b, \udda4, \udb6b, \udcb3]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 8, 3, 8, "\uda7e\udd49\ud918\udd1b\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udb7e\udf1e\udab8\udcce\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uec02\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fdb673634b5ebb4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27855.5, 28634.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 12, 16, 5, "\ud9cf\udfe5", "\u34a6", "\udb12\ude51",
        4, 4154, 14727893, -4274079998277197882L, -175L, false, false, (char) 47701, (char) 58662,
        Double.longBitsToDouble(0x3fdbb5c4b93691b0L), Double.longBitsToDouble(0x3fd7ef807b651ec2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@11 |a0=[I:[[]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@11\0121=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@11 |a0=[C:[[]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@11\012",
        Z.run(T, 2, 14, 8, 10, "", "", "\000\000\000\ud9dc\udeee",
        2, 78999, 184, -1933854286322453105L, -8232L, false, false, (char) 63541, (char) 60933,
        Double.longBitsToDouble(0x3fc3691b05fbe000L), Double.longBitsToDouble(0x3fdb28f613218c8eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud9a7, \udf9f, \ud942, \udde1, \ud86e, \uddc6, \ud890, \udde9, \ud818, \udc27, \uda8f, \udf5a, \ud833, \ude4d, \ud9ff, \ude17, \ud8e3, \udfa4, \ud884, \udcdb, \ud861, \uddad]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 8, 9, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud890\udde9\ud818\udc27\uda8f\udf5a\ud833\ude4d\ud9ff\ude17\ud8e3\udfa4\ud884\udcdb\ud861\uddad", "\u07ff\u1f4a\u8162\u9518", "\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a",
        36, 40160, 1715584991, 7780866882868571474L, 71028L, true, true, (char) 21946, (char) 62326,
        Double.longBitsToDouble(0x3fb677b6dc0a96d8L), Double.longBitsToDouble(0x3fcab0c4910cf418L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 0, 17, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud807\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\u0096\ud884\udc1c\ud861\ude39\ud83c\udc31\u008f\udbcc\udca5\udbcb\udd50\udb91\uddfa\u21c9\udbfb\ude05\udae7\udc22~\000\000\000\000", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808596770324480L, -59552L, false, false, (char) 0, (char) 25088,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[28132.5, 28244.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 9, 9, "\udbf9\udcd9\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47", "\u2b6b\u7b72\u3ba4\u07ff\u1f4a\u8162\ua1c0\u5811\u3457\u7f0a\u07b0\u015d\u1b3b\ud7b9\uadef\u2318\u2c8c\u45d3\u2a6d\ub572\u6025\uad76\u5e8d\u0f3a\u2f2d\u8a48\ua482\u49c6\u44dc\ucbc7\u77ac%\u7bee\u5197\u58a5\uc20c\ua037\ud26f\u34a0\u2c9a\u446e\u008b\ua1a6\u8165\u7b7d\u914b\u2e57\u23d5\u1778", "\ud8f3\udef4\udb66\udd61\uda97\udc7f\ud9a8\udcfd\ud8c7\ude67\ud8c8\udc11\ud878\udde1\uda2a\udc87\ud9dd\udfd8\ud997\udd79\ud8c7\ude55\uda14\udf22\ud9c9\udc6a",
        14, 88969, -292693005, -470077264731727428L, 28940L, true, true, (char) 49614, (char) 61130,
        Double.longBitsToDouble(0x3fc1bb31f78a3048L), Double.longBitsToDouble(0x3fd189e5deb80a04L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 16, 0, 8, "\ud9a7\udf9f\ud942\udde1\udb14\udf48\ud952\uddea\ud868\udfe7\udbd6\udd62\ud909\udff6\ud9ea\ude31\ud8e3\udf82\ud884\udcdb\ud861\ude39\ud83c\udc31\udb75\udd4f\ud982\udec0\ud972\uddc4\udb92\udc19\ud90e\udc47\u1c49\udae7\udc22\udbf6\udeda\udab3\udc4d\udba8\ude16\ud922\udfcc\udb6b\udcb3", "\u2cb4\u45d3\u29a2\ub572\u0fa3\ud08d\u7369\uc001", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        53, 70606, 1899490977, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 21708,
        Double.longBitsToDouble(0x3fd9560247588c18L), Double.longBitsToDouble(0x3fde97363405c152L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 3, 0, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\udbdd\udc81\uda0e\udd82\udb79\ude7d\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udb50\ude17\ud970\udf2f\ud817\udde9\udb91\uddeb\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2058778044766675526L, 1643L, true, true, (char) 62640, (char) 19422,
        Double.longBitsToDouble(0x3fd9560478ac5008L), Double.longBitsToDouble(0x3fde2c887404e330L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 12, 11, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udac9\udca2\ud88f\udd7c\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u9901", "\udb8a\udfa1\udad4\udda4\ud8f3\udd78",
        30, 75530, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[false, false]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 4, 7, 11, "\ud9d0\ude92", "\u34a6", "\ud86a\udeab",
        11, 38622, -1392104001, 6939304545297459724L, 62512L, false, false, (char) 63205, (char) 5174,
        Double.longBitsToDouble(0x3fdbb5c4b93691b0L), Double.longBitsToDouble(0x3fd7ef807b651ec2L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27853.5, 28408.5, 27785.0, 28376.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud9cb\ude21\ud942\udde1", "\uabef\u3671\uc63a\ucd6a\u5598\u0b67\u2b6b", "\ud985\udf2f\udbcb\udd50\udb91\uddfa\ud992\uddcd",
        10, 88731, -1889404546, -4159103177623023216L, 18328L, true, true, (char) 19966, (char) 24521,
        Double.longBitsToDouble(0x3fe3842fdbadf1fbL), Double.longBitsToDouble(0x3fed8d6dea5f635bL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 8, 15, 5, "\ud8ca\ude27\ud8e2\uded9\udbb4\udee5\ud96e\udeee\ud818\udc27\uda8f\udf5a\udb89\ude3a", "\u0b67\u2b6b\u19f7\u3ba4\u07ff\u1f4a\u8162", "\udae7\udc22",
        44, 20330, 563401104, 1893064456561610296L, -91408L, false, true, (char) 50542, (char) 21946,
        Double.longBitsToDouble(0x3fd582a1f8b3bdb6L), Double.longBitsToDouble(0x3fec0a96d8d58624L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 14, 3, 8, "\ud9a7\udf9f\uda30\uddec\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\uda15\udcd7\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83b\udfc7\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud9e1\udc04\ud905\udfe5\ud93b\uddcd\udb6b\udcb3", "\u2f66", "\udbbd\udd8b\ud9f5\udcda\u2764\uf93b\uda23\udc52\uda95\udc6d\ud819\udcf9",
        24, 78744, -1904942725, 6093819438853219306L, 80295L, false, true, (char) 59439, (char) 60098,
        Double.longBitsToDouble(0x3fea820026655b42L), Double.longBitsToDouble(0x3fe58e07d995600bL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[B:[[6, 105, 18, -79, 62, -106, 34, -70]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[B:[[6, 105, 18, -79, 62, -106, 34, -70]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 6, 6, 14, "\ud836\udc99\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\ud9ae\udf6c\uda16\udf14\udb56\udd6f", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb3c\udebb\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[I:[[55671, 57199]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 0, 0, "\ud9a7\udf9f", "\u34a6", "\ud86a\udeab",
        11, 38622, -1392104001, -4274063690620628538L, -160L, false, false, (char) 63205, (char) 63541,
        Double.longBitsToDouble(0x3fdbb5c4b93691b0L), Double.longBitsToDouble(0x3fd7ef807b651ec2L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[true, true, false, true]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 4, 1, 4, "\ud9a7\udf9f\ud942\udde1", "\uabef\ud724\uc60c\ucd6a", "\uda4a\udfce\ud9e5\udca5\udb19\udc4b\udbf0\udf55\uda94\udd34\ud967\udc45\udac9\udef2\udb0c\udd4e\udb04\udfa3\ud86a\udd80\ue251\uda6a\udf8a\ud93b\udda4\udb6b\udcb3\udabf\udde5\ud809\udf92\ud879\ude21\uda11\udd9c\udbe5\udf12\udbbd\udd8b\uda5c\ude43\u2764\uf46d\uda23\udc52\udae1\udc73\ud819\udcf9\udb8a\udfa1\udad4\udda4\udaad\udd75\udb5f\uddb8\udaf0\uddf5\ud82f\ude59\ud923\udea0\uda74\uddcf\ud802\udcb8\uda31\udd5b\uda80\udeea\uda0e\udfdb\ud80b\udf25\udb07\uddbf\ud85b\udde8\udb2b\udfbb\ud81e\udc7b\ud92d\udfec\udb91\udf22\udb05\ude69\udb08\udfd7\udbae\udfa8\ud93b\udee3",
        19, 74016, 1768133779, -6801181702796136107L, 66575L, true, true, (char) 62678, (char) 33641,
        Double.longBitsToDouble(0x3fe43403dca33744L), Double.longBitsToDouble(0x3fe1888e2828b5d3L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 16, 16, 17, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\udb88\udd6a\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\uda71\uded6", "\u5b28\uc6af\u4b88\u54b8u\u22fa\ua43c\uaf6b\u3c02\u45d3\u2a6d", "\u2764\ud9a8\udce5\ud93a\udd07\uda95\udc6d\ud819\udcf9\udb8a\udfa1\udad4\udda4\udaad\udd75\udb5f\uddb8\udbe7\udfd0\ub5cd\ud923\udea0\udb9e\udd25\ud996\udf63\udb34\uddf2\ud9e9\ude84\uda44\udc42\ud9f4\udc30",
        13, 5708, 1134035322, -5076283699188449094L, 11374L, false, true, (char) 9672, (char) 36630,
        Double.longBitsToDouble(0x3fecdab93946fba0L), Double.longBitsToDouble(0x3fe79b21c04b6488L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[I:[[55671, 57199, 55570, 56753, 55358, 56726, 55586, 56762]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[I:[[55671, 57199, 55570, 56753, 55358, 56726, 55586, 56762]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 14, 14, 8, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde973635be8730L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[27981.5, 28258.5, 28001.5, 28377.5, 28044.5, 28435.5, 27841.0, 28179.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[27981.5, 28258.5, 28001.5, 28377.5, 28044.5, 28435.5, 27841.0, 28179.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 10, 10, 9, "\udacb\udcf5\udaf3\udde3\udb49\ude57\ud9b2\udc56\udbf3\udcd8\uda8f\udfef\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\uda92\udd31\ucb8d\udbbe\ude58\ud982\udec0\udbcb\udd50\uc0b5\ud8ae\udc15\udb9d\ude8e\ud80b\udc3c\ud8a5\udff0\ud89e\udec3\uda6a\udf8a\udbe3\udc98\ud9f1\udcfa", "\u8606\u0c3b\u2a6d\u062f\u2c4c\uab94\ua981\u5a12", "\uda13\udde6\udad4\ude37\udaad\udd75",
        30, 26314, 962572577, -1598665611062844937L, -58917L, false, true, (char) 33586, (char) 8396,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde9a0d85be8730L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 15, 15, 8, "\ud9a7\udf9f\ud944\udee1\ud80f\udc96\ud9fe\udc42\ud843\udcf2\uda8f\udf5a\ud86a\udeab\udb85\udc89\ud90c\udf24\ud884\udcdb\ud861\ude39\ud83c\udc31\uda02\ude49\ud982\udec0\ud9c9\udd4f", "\u967b\uaf68\u6404\u3949\u018b\u3d050\u0911\u3fff\u5770\ua8a2\uac76\uac29\u2cca\u6210\u5e8d\u4313\u2d53\ub439\ua482\u49c6\u44dc\u34f8\uc264\u0c20\ud4c7\ub9d5\u7715\u7a9b\ua037\ud26f\u34a0", "\udaba\uddd0\ud9ad\udf90\ud9a4\udf5e\ud8a3\udcf1\ud924\udea6\udb89\ude2c\ud8f1\udf6f\uda65\ude1b\uda4d\uddd8\ud9a6\udf96\ud91a\udd9f\uda52\ude13\ud874\udcaa\udb26\udc7f\udb48\udf44\ud93d\udf72\ud848\udc75\ud84c\udcef\udaac\uddc2\udb29\ude0f\udb8f\udf22\ud9db\udff3\ud865\udff5\uda61\udff0\ud97e\udc93\udb47\udc98",
        5, 78734, 987793081, 7701303129414215209L, 48489L, false, false, (char) 47674, (char) 7947,
        Double.longBitsToDouble(0x3fd500e9e59b3d14L), Double.longBitsToDouble(0x3fed3e0df705c134L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud9a7, \udf9f, \ud944, \udee1, \uda43, \udcf0, \ud804, \uddd3, \ud816, \udd1f, \uda8f, \udf5a, \ud86a, \udeab, \ud94a, \ude6b, \ud90c, \udf24, \ud884, \udcdb, \ud861, \ude39, \ud83c, \udc31, \uda02, \ude49, \ud982, \udec0, \ud9c9, \udd4f, \udb91, \uddfa, \u1bd8, \udb67, \uddfb, \udae7, \udc22, \udbf6, \udeda, \ud8ac, \ude4b, \uda6a, \udf8a, \udb07, \udf4a, \ud8c0, \uddbc, \ud84c, \udcbe, \ud80d, \ude84, \ud92c, \uddca, \uda63, \udfa4, \ud9e1, \udd4b, \udb49, \udcb0, \ud8fa, \udc69, \ud839, \udfc2, \uda87, \udcd6, \uda23, \udc52, \uda44, \udec6, \ud91e, \udf3b, \ud929, \udc71, \udad4, \uddd9, \ud937, \udd7a]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 15, 8, 16, "\ud9a7\udf9f\ud944\udee1\uda43\udcf0\ud804\uddd3\ud816\udd1f\uda8f\udf5a\ud86a\udeab\ud94a\ude6b\ud90c\udf24\ud884\udcdb\ud861\ude39\ud83c\udc31\uda02\ude49\ud982\udec0\ud9c9\udd4f\udb91\uddfa\u1bd8\udb67\uddfb\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\udb07\udf4a\ud8c0\uddbc\ud84c\udcbe\ud80d\ude84\ud92c\uddca\uda63\udfa4\ud9e1\udd4b\udb49\udcb0\ud8fa\udc69\ud839\udfc2\uda87\udcd6\uda23\udc52\uda44\udec6\ud91e\udf3b\ud929\udc71\udad4\uddd9\ud937\udd7a", "\u0c20\ua87b", "\udb34\ude66",
        5, 76256, 1615291012, 8626791961697977806L, -48842L, true, true, (char) 34010, (char) 16304,
        Double.longBitsToDouble(0x3fe31b96d3cd88e1L), Double.longBitsToDouble(0x3fee6102edb3fb3aL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@271 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@271\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 13, 13, 8, "\ud9a7\udf9f\ud944\udee1\ud80f\udc96\ud975\udc05\ud843\udcf2\uda23\ude13\ud857\udf47\ud94a\ude6b\ud90c\udf24\ud884\udcdb\ud861\ude39\ud83c\udc31\uda02\ude49\ud982\udec0\ud939\ude47\udb91\ude76\ud9c2\udc96\udb67\uddfb\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u1cbb\u923f\u53bf\u5ab3\u2c89\ub70f\u5e8d\u4313", "\ud94d\udda7",
        -4, 45743, 1418827965, 4771392186513575713L, 43771L, false, false, (char) 42594, (char) 6128,
        Double.longBitsToDouble(0x3fe6c3d212849048L), Double.longBitsToDouble(0x3fd956047b9cef70L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\u6d64, \000]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 0, 8, 8, "\u6d64\000", "", "\udbdf\uddc6",
        11, 38622, -1392104001, -4274063690620628538L, -175L, false, false, (char) 63205, (char) 217,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc8000016c93fb4L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 7, 5, 0, "\uc164\ud93b\udde4\ud86e\udceb\ud811\udf29\ud818\udcda\ud94b\udf58\ud846\ude7a\ud9ff\ude47\ud8e3\udfa4\ud871\ude70\udb8e\udce2\ud998\udd22\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\udbbc\udf82\udbfb\ude3b\udb07\ude32\ud8f3\udd71\ud8ac\ude4b\ud85d\uddc4\ud94c\udfb0\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\uacae\u6f2d\u9c13\u5e8d\u1c4a", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        51, 32254, 1870944033, -981783613660101583L, -38509L, false, true, (char) 12474, (char) 62172,
        Double.longBitsToDouble(0x3fd9560477166418L), Double.longBitsToDouble(0x3fdd41963404e330L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[I:[[49460]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 14, 13, 0, "\uc164", "\ud621\uaca2\u3671\u8bdb", "\u2dbf\ud843\udc81\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa",
        43, 51635, 453467291, 5759357080133697714L, -648L, false, false, (char) 42532, (char) 26230,
        Double.longBitsToDouble(0x3fd520000ce10bf6L), Double.longBitsToDouble(0x3fef678fdf8fadbdL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 7, 17, 8, "\000", "", "\uda8f\udf5a",
        48, -1000, 0, 0L, 17361L, true, false, (char) 29242, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc360000300001cL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 7, 7, 12, "\uc1ac\udb93\udeb0\udaaa\udc6b\ud811\udf1d\udb2f\udf25\u7ba9\udbdf\uddc6\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\udb0c\udc86\udbfb\ude05\ud9e9\udc64\udb43\udd75\ud8ac\ude4b\uda6a\udf8a\udacf\uddef\udb6b\udd78", "\u2cb4\u45d3\u2a6d\uacae\u6f2d\u9c13\uca1a\u14d7", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        51, 90822, 1866529927, -981783613660101583L, -51144L, false, true, (char) 59508, (char) 12545,
        Double.longBitsToDouble(0x3fe2be9358618c63L), Double.longBitsToDouble(0x3fe6e5a2bd84d031L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 17, 17, 8, "\uc164\udb93\udeb0\ud86e\uddc6\ud811\udf29\ud818\udcda\uda8f\udf5a\udbdf\uddc6\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\ud9d7\ude74\u6607\udb43\udd63\uda86\udf8a\uda6a\udff0\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\uacae\u6f2d\u9c13\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        51, 32254, 1870944033, -981783615304268751L, -38509L, false, true, (char) 14800, (char) 62172,
        Double.longBitsToDouble(0x3fd9560476ae6418L), Double.longBitsToDouble(0x3fdd4196318d0530L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[35.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 1, 6, "v", "\u343e\u7d64\u3286\u0422\ucd34\u5598\u0b67\ua470\u90c7\u3ba4\u07ff\u1f4a\u3375\000\000\u245e\u35db\u2e07\u015d\u8d7a\u5e00\u0645\uc12f\u2cb4\u45d3\u2a6d\ub572\u2c4c", "\uda23\udc52\uda12\udcc6\uc154\udbc3\udfff\udad4\udd9c\udaad\udd75\udb5f\uddb8\udbe7\udfd0\ub5cd\ud923\udea0\ud8b1\udece\udb38\udf54",
        37, 95735, -1262131749, 6937622070062743552L, 95072L, true, true, (char) 41737, (char) 53517,
        Double.longBitsToDouble(0x3fd0dff3a1b9dd66L), Double.longBitsToDouble(0x3fb613a62f2d1e28L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[B:[[-67, -110]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 6, 1, 4, "\udbed\udec2", "\u343e\u7d64\u1286\u586b\ucd43", "\uda6d\udf58\ud823\udf02\ud8f3\ude21\ud8b6\ude39\ud994\uddb9\ud913\ude1e\udb98\uddd1\ud9be\udff3\ud8ec\ude69\udbeb\udcb1\uda65\udea7\ud931\udece\udbcf\udc0e\udad9\udfc5\udbd0\ude3d\ud801\udd9f\ud879\udde9\udb10\udc9b\udbe5\udf12\udbbd\udd8b\ud9f5\udcda\ub163\ud9b0\udd56\udab1\udebd\uda12\udcc6\uc154\udbc3\udfff\udad4\udd9c\udaad\udd75\udacf\ude00\uda2b\udc17\u7abe\ud926\ude4e\udbab\udd74\udb38\udf54\udb34\ude20\udb4d\udcbf\udab7\udf37\udb0d\udfcd\udb07\uddb5\udabd\uddb1\udbc6\udc81\ud976\udff6\ud820\udccb\ud947\udd87\u7c08\udae9\udd7d\uda4d\udee8\udad7\ude94",
        7, 33991, 1736336706, 5687265579004937923L, -57324L, false, false, (char) 7594, (char) 19680,
        Double.longBitsToDouble(0x3fea595d017cd0a6L), Double.longBitsToDouble(0x3fb3204af0c84ff0L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[true, true, true, false, false, false, false, true]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[true, true, true, false, false, false, false, true]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 4, 4, 8, "\ud9a7\udf9f\ud90b\ude24\udae6\udcc2\ud9f2\ude39\ud818\udc27\000\000\000\u0096\ud884\udc1c\ud810\udef0\u00c6\000\ud982\udec0\udbcb\udcd8\udb91\uddfa\ud992\uddcd\udafe\uddc7\udacf\udf87\udbf6\udeda\u00b2\uda6a\udf8a\ud8f3\udda0\udb6b\udcb3", "\u2cb4\000\000\000\000\000\000\u932a\000\000\000\u22a6\u44dc\u9302\uc264", "\udb9e\udd25\u35e0\ud8e9\ude00\ud9e9\ude84",
        13, 79847, 1175196053, 8314607725440412137L, 97806L, true, true, (char) 49461, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fce80000e740000L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[false, false, true, true]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[B:[[2, -98, 63, -101]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 4, 6, 7, "\uda32\udece\ud96f\uddcb", "\ubb0c\u3561\uccda\ucd95", "\udad0\udcf4\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\ud8fb\udf70\udb30\ude53\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3\uda59\uddf2\u705c\uda3e\udeb3\ud9c0\udee8\ud8d4\udfcb\udb07\udee1\ud9f5\udcf2\u2764\ud880\udffd\uda22\udfe5\uda95\udc6d\ud819\udcf9\udb96\udee8\u7e7a\ud911\ude97\udb9c\udd6d\udbe7\udfd0\ub5cd\ud9cf\ude96\udb9e\udd25\ud996\ude63\udb34\uddf2\ud9e9\ude84\udb6b\udd35\ud9e2\udd3b\udb07\uddb5\ud818\udf2a\udb88\udc4f\uda8b\udd52\udb1a\ude5e\udafd\udf8a\udb8a\udcc2\ud89f\udef7\u566b\ud82e\udf87",
        52, 89765, 780004445, -2686293700605681254L, 12469L, false, false, (char) 53043, (char) 10493,
        Double.longBitsToDouble(0x3fbb18a791008318L), Double.longBitsToDouble(0x3fdb8e12e208f062L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[false, false, false, true, false, false, false, false]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 16, 16, "\uda50\udfd2\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud810\udef0\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\udb7b\udc4c\ud93b\udf19\udb6b\udcb3", "\u2cb4\u161f\u2a6d\u4d5d\u2c4c\u6210\u5e8d\u4313\uc928\u4517\ua482\uc29f\u381f\u9870\uc256", "\udb9e\udd25\udbda\udde6\udb2a\uddec\ud9e9\ude84",
        36, 79847, 1175196053, 8314607725440412137L, 97806L, true, true, (char) 49461, (char) 35818,
        Double.longBitsToDouble(0x3fe25677b148be50L), Double.longBitsToDouble(0x3fce84c3ce77f808L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud9a7, \udf9f, \ud942, \udde1]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 0, 8, 17, "\ud9a7\udf9f\ud942\udde1", "\uabef\u3671", "\ud8e3\udfa4\ud884\udcdb\udbb9\udd65\udbd9\ude68\udbbe\ude09\ud982\udec0\udbcb\udd50\udb91\uddfa\udbc6\udec1\ud919\udefe\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4",
        45, 8375, 1811624245, -8792313650414861968L, -40529L, true, false, (char) 62326, (char) 14133,
        Double.longBitsToDouble(0x3fea8d98e8d58624L), Double.longBitsToDouble(0x3fe5489836085ae8L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@11 |a0=[Z:[[]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@11\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 16, 14, "", "", "\ud818\udc27",
        57, 35471, -1442870439, -1154583323335053889L, 2854L, true, true, (char) 17010, (char) 29242,
        Double.longBitsToDouble(0x3fe3a7638c5d3bd9L), Double.longBitsToDouble(0x3fdbb5c4b93691b0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@245 |a0=[B:[[-48]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@245\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 16, 8, "\000", "\u00a2", "\ud86a\udeab",
        11, 38622, -1392104001, 1490543832413606342L, -100000L, false, false, (char) 113, (char) 0,
        Double.longBitsToDouble(0x3fdbb000093691b0L), Double.longBitsToDouble(0x3fd7ef807b651ec2L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 28046.0, 28379.0, 27679.0, 28363.0, 27659.5, 28173.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud9a7, \udf9f, \udb4c, \udde6, \ud86e, \uddc6, \ud847, \udc4b, \ud818, \udc07, \uda8f, \udf5a]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 8, 8, "\ud9a7\udf9f\udb4c\udde6\ud86e\uddc6\ud847\udc4b\ud818\udc07\uda8f\udf5a", "\u5598\u0b67\u323c\u19f7\u3ba4\u07ff\u1f4a\u8162\u1680\u5811\u5b28\u6404\u3949\u015d\u1b3b", "\ud809\udf92\ud879\ude21\ud9c0\udee8\udbe5\udf12\udbbd\udd29\ud9d5\udf03\u2764\udbc7\uddc0",
        20, 421, 944878659, 3639005978210084640L, 33433L, false, true, (char) 37208, (char) 12670,
        Double.longBitsToDouble(0x3fdbae3fbbc1649eL), Double.longBitsToDouble(0x3fd6e4c96cb27158L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[27835.5, 28599.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 10, 1, 5, "\ud9a7\udf9f", "\u34a6", "\ud81e\udcb4",
        16, 4470, -1392103346, -6293639218226163258L, -175L, false, false, (char) 63205, (char) 63541,
        Double.longBitsToDouble(0x3fdbb5c4b93691b0L), Double.longBitsToDouble(0x3fd7ef807b651ec2L)));
  }
  @Test
  public void test70() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test70() throws Throwable {
//     assertEquals("0=java.lang.Boolean:true\012",
//         Z.run(T, 1, 16, 17, 0, "\ud9a7\udf9f\ud93e\udfc0\000\000\000\uda8f\udfed\ud86a\udeab\uda13\ude47\ud814\ude3c\ud884\udcdb\ud875\ude3b\ud83c\udc31\000\ud982\udec0\udbcb\udd50\u7474\ud963\udd70\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b", "\ud7b9\u0911\u3135\000\u45d3", "\ud9f5\udcda\u2764\uf93b\000\000\ud819\udcb6",
//         5, 84920, -962281257, 6093819709446190324L, 17280L, true, false, (char) 14164, (char) 35030,
//         Double.longBitsToDouble(0x3fc09209042a8c1cL), Double.longBitsToDouble(0x3fed623061e97363L)));
//   }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[-24.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 0, 0, "\000", "\u98cc", "\ud86a\udeab",
        48, -1000, -1392104001, -4274063690620628538L, -100000L, false, false, (char) 63205, (char) 63541,
        Double.longBitsToDouble(0x3fdbb5c4b93691b0L), Double.longBitsToDouble(0x3fd7ef80700000c2L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[I:[[55816, 56674, 55570, 56753, 55358, 56726]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[27908.0, 28337.0, 27785.0, 28376.5, 27679.0, 28363.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 14, 10, 8, "\uda38\udd92\ud942\udde1\ud86e\uddc6", "\u4d67\uc618\ucd6a\u5598\u9fad\u2b6b\u8e79\ua7eb\u07ff\u1f4a\u8162\u643c&\u5cb0", "\udb2b\udc18\ud97c\udcf9\udb4c\udee8\udbe3\udc9f\ud817\udceb\ud879\ude21\ud8a3\ude9e\ud8c4\udde0\u155b\uda34\udcb3\ud8ac\udd41",
        25, 72377, 1023863853, 4495343683175773437L, -36041L, true, false, (char) 47227, (char) 32322,
        Double.longBitsToDouble(0x3fe17ec1a3485729L), Double.longBitsToDouble(0x3fcfa91658b53008L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@276 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@276\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 3, 3, 6, "\ud9a7\udf9f\ud858\uddec\ud95a\udf1d\ud952\udde2\ud818\udc27\uda8f\udf5a\uda60\udd86\udbf9\udce4\ud819\udd74\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u4313", "\udbc7\udc20\uda5a\udf1d\udbe3\udf75",
        33, 26314, 1899450145, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 57445,
        Double.longBitsToDouble(0x3fd9560207588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 11, 11, 2, "\ud8fd\udf64\ud978\ude9d\ud95a\udeb9\uda7a\udecb\udb3e\uddb9\uda79\udfb6\ud9ed\udc49\ud9ff\ude62\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud8c1\udeb3\ud814\ude6e\uda37\udd85\ud99a\ude28\ud9fb\udd05", "\u3949", "\udb6b\udcb3\udabf\udde5\ud809\udf92\ud879\ude21\uda11\udd9c",
        46, 9225, 706736735, -2388093796205470631L, -3957L, false, false, (char) 56569, (char) 49950,
        Double.longBitsToDouble(0x3fe2057064cd8ccbL), Double.longBitsToDouble(0x3fef53bba8214237L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 9, 9, 7, "\ud9a7\udf9f\ud90e\udde7\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u0183\uc959", "\ud9c9\udf23\udad4\udda4\udaad\udd75\udb5f\uddb8\udbe7\udfd0\ub5cd\ud923\udea0\udb9e\udd25\ud996\ude63\udb34\uddf2\ud9e9\ude84\uda44\udc42\ud9f4\udc30\udb07\uddb5\udb36\ude78\udaf0\udc9a\uda68\udfa9\udb5b\udcb8\udb6c\udd87\ud805\udf54\udb38\ude92\udbe1\udc84\ud840\udd24\ud8c1\udee6\udad7\udf07\ud993\ude33\uda9e\udcc6\udbe6\udde2\ud81d\udd36\udbcd\udd33\ud8b0\ude72\ud8d6\udeb6\udafd\ude42\ud900\udd21\udafd\udd85\ud8fb\udc18\udbdd\udd64\udae5\udda3\udacc\udff6\uda64\udcaa\udabf\ude57\uda9c\udfef\ud92b\udf66\udbda\udd9b\ud93f\ude64\ud87e\udeca\udbf7\udd47\u19ca\ud9d6\udcd9\udb5b\udead\ud8aa\udc64\ud8e9\udfe0\ud9fe\uddef\uda86\udc9d\ud9e7\udfcc\ud936\udce8\ud9f7\ude21\uda16\udd61\u3cc1\uda7f\ude8b",
        5, 14887, 912703722, -6378572062478168913L, 13364L, false, true, (char) 39279, (char) 10565,
        Double.longBitsToDouble(0x3fefd919a2dd0bdeL), Double.longBitsToDouble(0x3fa3af624a12fb90L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 14, 14, 8, "\ud9a7\udf9f\ud90e\udde7\ud86e\uddc6\ud952\uddea\ud818\udc27\ud93f\udf08\ud87f\udc7a\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\udafb\udd7d\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u0183\uc959", "\uda04\ude41\udad4\udda4\udaad\udd75\udb07\udd36\udbe7\udfd0\ub5cd\ud923\udea0\udb9e\udd25\uda66\udc32\udb34\udea1\ud9e9\ude84\uda44\udc42\ud9f4\udc30\udb07\uddb5\ud846\ude00\udaef\udfe5\uda68\udfa9\udb5b\udcb8\udb6c\udd87\ud805\udf54\udb38\ude92\udbe1\udc84\ud8d5\udc86\ud8c1\udee6\udad7\udf07\ud993\ude33\uda9e\udcc6\udbe6\udde2\ud81d\udd36\udbcd\udd33\ud8b0\ude72\ud8d6\udeb6\udafd\ude42\ud900\udd21\udafd\udd85\ud8fb\udc18\udbdd\udd64\udae5\udda3\udacc\udff6\uda64\udcaa\ud831\udd02\uda9c\udfb7\ud92b\udf66\udbda\udd9b\ud93f\ude64\ud87e\udeca\udbf7\udd47\u19ca\ud9d6\udcd9\udb5b\udead\ud914\udcb8\ud8e9\udfe0\ud9fe\uddef\uda86\udc9d\ud9e7\udfcc\ud936\udce8\ud9f7\ude21\uda16\udd61\u3cc1\uda7f\ude8b",
        5, 14887, 912703722, -6378572062478168913L, 13364L, false, true, (char) 39279, (char) 10565,
        Double.longBitsToDouble(0x3fefd919a2dd0bdeL), Double.longBitsToDouble(0x3fa3af624a12fb90L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud9a7, \udf9f, \ud942, \udde1]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud9a7, \udf9f, \ud942, \udde1]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 8, 8, 12, "\ud9a7\udf9f\ud942\udde1", "\uabef\u3671\uc63a\ucd6a", "\ud8fd\udf2a\udad2\udfa4\ud856\udd4b\ud90d\udce4\ud895\udfd4\uda8e\udf9d\u1027\udb44\udec1\ud8bc\ude6d\udbf6\udeda\ud8ac\ude4b\udbc5\udfd7\ud8a9\udd7d\udbdd\udf6f\ud977\udee2\uda04\udc33\uda30\udd0f\uda11\udd9c\udbe5\udf12\udbbd\udd8b\ud9f5\udcda\u2764\uf93b\uda33\udf52\uda95\udc6d\ud819\udcf9\udb8a\udfa1\udada\udc3e\udb0b\udd84\ud847\udfc1\ud853\udcda\udba6\udc90\ud926\udd30\udbbe\udd72\ud996\ude63\udb34\uddf2\udbb2\udef6\uda44\udc42\ud9f4\udc30\udb07\uddb5\udb36\ude78\ud94d\udfa9\udaef\udea3\uda67\udcc9\u4fac\ud936\udcf9\ud8d0\udd73\udad8\ude69\udb45\udc72",
        -2, 51009, -1624941203, 4113347296819998915L, 90866L, true, true, (char) 4878, (char) 52413,
        Double.longBitsToDouble(0x3fe0becc3957b6c1L), Double.longBitsToDouble(0x3fe67069196a7c99L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 15, 15, 8, "\udb06\udd1c\ud85f\udecf\ud9f8\ude02\ud91e\udc1a\ud822\uddfb\uda8f\udf5a\ud86a\ude93\ud9c1\udd1a", "\u14ef\u685f\ub480\u670c\u69b0\u8162\ua1c0\u5811\u5b28\u6404", "\uda18\udee9\udb6b\udc83\udabf\udde5\ud809\udf92\ud879\ude21\uda11\udd9c\uda25\ude31\ud9a9\ude51\ud9e6\udfcb",
        0, 42808, -1188795447, 4397325809221743683L, -52391L, false, false, (char) 2442, (char) 37790,
        Double.longBitsToDouble(0x3fdd9016c0d8bedcL), Double.longBitsToDouble(0x3fe82b6af9a43eacL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 6, 6, 8, "\uda1c\ude28\ud935\udd1d\ud86e\uddc6\udbd8\udd2c\ud822\udd33\uda8f\udf5a\ud86a\ude93\ud9c1\udd1a\uda00\udfdc\ud9d0\udc11\uda41\udfec", "\u5d45\uc9b4\ub3cf\ua142", "\udbf6\udeda\ud8ac\ude4b\udb75\udfa9",
        28, 8128, -1994403614, 4429261154009224678L, -14082L, false, false, (char) 1382, (char) 8353,
        Double.longBitsToDouble(0x3fc0f7249eb2a808L), Double.longBitsToDouble(0x3fe544257607f349L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 4, 4, 8, "\ud9a7\udf7a\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\udb94\udf63\udae4\udc86\ud99d\udda2\udb00\ude71\uda67\ude9e\ud82d\udf2b\udb3a\ude68\ud992\uddcd\udbfb\ude05\udae7\udc22\udb10\ude07\ud8da\udf05\ub418\ud91e\udfb9\u28e3", "\u3bc1\u45d3\u4250\u00d1\u8ecc\u6227\u5e8d\u4313", "\udb70\udeb5\ud990\udea8\udaad\udd75",
        30, 67152, 442433495, -2018988561498432070L, 25145L, true, true, (char) 14207, (char) 51945,
        Double.longBitsToDouble(0x3fde97363404e330L), Double.longBitsToDouble(0x3fe11e4b556f4c25L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[D:[[-24.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[false]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 10, 4, 10, "\000", "", "\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\udb94\udf63\udae4\udc86\000\000\uda36\udedb\ud82d\udf2b\udb3a\ude68\ud992\uddcd\udbfb\ude05\udae7\udc22",
        30, 51690, -1848202602, 1892939203621539384L, 43669L, true, false, (char) 4238, (char) 6171,
        Double.longBitsToDouble(0x3fbcd88240000578L), Double.longBitsToDouble(0x3e41677b6c000000L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 10, 10, 5, "\ud81b\udf13\ud942\udd8d\ud9af\udce6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud9ff\ude47\ud8e3\udfa4\udb94\udf63\udae4\udc86\ud9e6\udfe7\udaeb\udde7\ud8c0\udfb7\uda0a\udfa9\udb1d\udcfd\ud848\ude68\udbfb\ude05\udab9\udd4c\ud9f6\udeb4\ud8f2\udcca\ud838\udedf\udb7f\udf1a\ud999\udfe4", "\u3bc1\u2232\u4328\u00d1\u8ecc\u6227\u5e8d\u4313\uc928", "\udbe5\udc68",
        43, 79965, 1065269744, 5534727455404399737L, 26752L, false, true, (char) 14164, (char) 16411,
        Double.longBitsToDouble(0x3fd27311d32a4bd4L), Double.longBitsToDouble(0x3fed623061e97363L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@280 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@280\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 5, 5, 17, "\ud9a7\udf9f", "\u34a6", "\ud86a\uddf4",
        11, 38622, -1392104001, -4274063690620628538L, -160L, false, false, (char) 63205, (char) 63541,
        Double.longBitsToDouble(0x3fdbb5c0013691b0L), Double.longBitsToDouble(0x3fd7ef800b651ec2L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 8, 8, 2, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\uda5b\udc78\ud9fb\udc95\ud912\udda4\ud94d\uddbf\ud843\udc81\ud83c\udc31\udbbe\ude47\udbe6\udedf\u1fd0\udb8e\udf86\udabc\udd23\udbfb\ude05\udae7\udc31\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud9c9\uddcb\udb56\ude98", "\u9630", "\udbbd\udd95\ud9f5\udcda\ud80f\udcd7\ud800\udc61\ud828\udf5e\uda95\udc6d\u6eed",
        57, 74856, -962281257, 6093819709436158954L, 17270L, true, false, (char) 14164, (char) 14618,
        Double.longBitsToDouble(0x3fe4248581956047L), Double.longBitsToDouble(0x3fed623063666a63L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[I:[[43918]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\uabbe]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 14, 8, 10, "\uabbe", "\u98cc", "",
        58, 79888, -268822378, -5979041156925751112L, 17361L, true, false, (char) 26426, (char) 63205,
        Double.longBitsToDouble(0x3fb74ef64ddae258L), Double.longBitsToDouble(0x3fc3691b05fbe000L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 12, 12, 11, "\ud9a7\udf9f\ud942\udde1\ud86e\uddc6\ud986\udd44\ud9ad\udccf\udadb\udddf\udafb\udc9e\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\ud8e9\udf9d\ud982\udec0\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbf9\udd05\udae7\udc13\udac9\udca2\ud88f\udd7c\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u2cb4\u45d3\u2a6d\ub572\u2c4c\u6210\u5e8d\u9901", "\udb8a\udfa1\udad4\udda4\ud8f3\udd78",
        35, 14861, -2043981891, 1490489431504678712L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde973634eb3f30L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud8a1, \udda2, \uda56, \udc45, \udbb4, \udee5, \ud96e, \udeee, \ud818, \udc27, \uda8f, \udf5a, \udb89, \ude3a, \ud9ff, \ude47, \ud8e3, \udfa4, \ud884, \udcdb, \ud861, \ude39, \ud83c, \udc31, \udbbe, \ude47, \uda72, \udc61, \udbcb, \udd7c, \udb91, \uddfa, \ud992, \uddcd, \udbfb, \ude05, \udae7, \udc22, \udbf6, \udeda, \ud8ac, \ude4b, \uda6a, \udf8a, \ud93b, \udda4, \udb6b, \udcb3, \ud965, \ude77, \ud826, \udcea, \udac4, \udde6, \ud92b, \ude91, \udbe5, \uded8, \udbbd, \udd8b, \ud9f5, \udcda, \u2764, \uf93b, \uda23, \udc52, \uda73, \udcbc, \ud88f, \udd16, \ud931, \udc76, \uda6f, \udccb, \ud99e, \udf17, \udb96, \udded, \ud970, \uddfb, \udad4, \udf9f, \ud9f6, \udf47, \udb58, \udc12, \ud987, \udfa6, \udb36, \udc84, \uda42, \udfa9, \udb93, \udc61, \ud816, \udd8c, \udb66, \udec3, \ud889, \ude69... |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 8, 15, 5, "\ud8a1\udda2\uda56\udc45\udbb4\udee5\ud96e\udeee\ud818\udc27\uda8f\udf5a\udb89\ude3a\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\uda72\udc61\udbcb\udd7c\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3\ud965\ude77\ud826\udcea\udac4\udde6\ud92b\ude91\udbe5\uded8\udbbd\udd8b\ud9f5\udcda\u2764\uf93b\uda23\udc52\uda73\udcbc\ud88f\udd16\ud931\udc76\uda6f\udccb\ud99e\udf17\udb96\udded\ud970\uddfb\udad4\udf9f\ud9f6\udf47\udb58\udc12\ud987\udfa6\udb36\udc84\uda42\udfa9\udb93\udc61\ud816\udd8c\udb66\udec3\ud889\ude69\ud9bd\udd6f\ud836\udede\udb09\udeb7\ud8e8\udcee\ud97d\udc86\udab2\udca7", "\u8518\u98fc\u1823\u5131\u88e6\u6b6c\u733d", "\ud846\udefb\udb1c\ude40\ud901\udcb4\udb10\udf07\ud85d\udfae\ubaa3\uda27\uddfe\udbb0\udc78\uda6f\udc40\ud8ab\udddc\udbff\udfc3\ud910\udde1\udbb8\udd41\ud968\udf10\udad4\udd12\ud80a\udfe1\ud922\udc2c\uda0a\udf5e\udada\ude75",
        24, 15981, 1639141968, 5785471212754901684L, 1119L, false, false, (char) 652, (char) 23914,
        Double.longBitsToDouble(0x3fec7dc63a0467fcL), Double.longBitsToDouble(0x3feced1a7458b1d3L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud8a1, \udda2, \uda56, \udc45, \udbb4, \udee5, \ud96e, \udeee, \ud818, \udc27, \uda8f, \udf5a, \udb89, \ude3a, \ud9ff, \ude47, \ud8e3, \udfa4, \ud884, \udcdb, \ud861, \ude39, \ud83c, \udc31, \udbbe, \ude47, \u300f, \udbcb, \udcd8, \udb91, \uddfa, \ud992, \uddcd, \udbfb, \ude05, \udae7, \udc22, \udbf6, \udeda, \ud8ac, \ude4b, \uda6a, \udf8a, \ud93b, \udda4, \udb6b, \udcb3, \ud965, \ude77, \ud826, \udcea, \udac4, \udde6, \ud92b, \ude91, \udbe5, \uded8, \udbbd, \udd8b, \ud9f5, \udcda, \udbd7, \ude0b, \uf93b, \uda23, \udc52, \uda73, \udcbc, \ud88f, \udd16, \ud931, \udc76, \uda6f, \udccb, \ud99e, \udf17, \udb96, \udded, \ud970, \uddfb, \u00af, \ud9f6, \udeea, \udb58, \udc12, \ud987, \udfa6, \udb36, \udc84, \uda42, \udfa9, \udb93, \udc61, \ud816, \udd8c, \udb66, \udec3, \ud889, \ude69, \ud9bd... |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[C:[[\ud8a1, \udda2, \uda56, \udc45, \udbb4, \udee5, \ud96e, \udeee, \ud818, \udc27, \uda8f, \udf5a, \udb89, \ude3a, \ud9ff, \ude47, \ud8e3, \udfa4, \ud884, \udcdb, \ud861, \ude39, \ud83c, \udc31, \udbbe, \ude47, \u300f, \udbcb, \udcd8, \udb91, \uddfa, \ud992, \uddcd, \udbfb, \ude05, \udae7, \udc22, \udbf6, \udeda, \ud8ac, \ude4b, \uda6a, \udf8a, \ud93b, \udda4, \udb6b, \udcb3, \ud965, \ude77, \ud826, \udcea, \udac4, \udde6, \ud92b, \ude91, \udbe5, \uded8, \udbbd, \udd8b, \ud9f5, \udcda, \udbd7, \ude0b, \uf93b, \uda23, \udc52, \uda73, \udcbc, \ud88f, \udd16, \ud931, \udc76, \uda6f, \udccb, \ud99e, \udf17, \udb96, \udded, \ud970, \uddfb, \u00af, \ud9f6, \udeea, \udb58, \udc12, \ud987, \udfa6, \udb36, \udc84, \uda42, \udfa9, \udb93, \udc61, \ud816, \udd8c, \udb66, \udec3, \ud889, \ude69, \ud9bd... |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 8, 8, 5, "\ud8a1\udda2\uda56\udc45\udbb4\udee5\ud96e\udeee\ud818\udc27\uda8f\udf5a\udb89\ude3a\ud9ff\ude47\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\u300f\udbcb\udcd8\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3\ud965\ude77\ud826\udcea\udac4\udde6\ud92b\ude91\udbe5\uded8\udbbd\udd8b\ud9f5\udcda\udbd7\ude0b\uf93b\uda23\udc52\uda73\udcbc\ud88f\udd16\ud931\udc76\uda6f\udccb\ud99e\udf17\udb96\udded\ud970\uddfb\u00af\ud9f6\udeea\udb58\udc12\ud987\udfa6\udb36\udc84\uda42\udfa9\udb93\udc61\ud816\udd8c\udb66\udec3\ud889\ude69\ud9bd\udd6f\ud836\udede\udb09\udeb7\ud8e8\udcee\ud97d\udc86\udab2\udca7", "\u8518\u98fc\u1823\u5131\u88e6\u6b6c\u733d", "\ud846\udefb\udb1c\ude40\ud901\udcb4\udb10\udf07\ud85d\udfae\ubaa3\uda27\uddfe\udbb0\udc78\uda6f\udc40\ud8ab\udddc\udbff\udfc3\ud910\udde1\udbb8\udd41\ud968\udf10\udad4\udd12\ud80a\udfe1\ud922\udc2c\uda0a\udf5e\udada\ude75",
        24, 15981, 11752016, 5785471212754901684L, 1119L, false, false, (char) 652, (char) 23914,
        Double.longBitsToDouble(0x3fec7dc63a0467fcL), Double.longBitsToDouble(0x3feced1a7458b1d3L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27825.5, 28599.5, 27785.0, 28376.5, 27679.0, 28363.0, 27793.0, 28381.0]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud993\udf9f\ud942\udde1\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud86a\udeab\ud99e\udc15\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc5e\ud896\udf52\ud982\udf7e\udbcb\udd50\udb91\uddfa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\ud943\ude97\udacd\udd96\uda54\uded5", "\u2cb4\u45d3\ubd19\ud106\u2c4c\u6210\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        30, 70298, 1899473176, -2018808598073762374L, -59507L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275 |this=org.apache.commons.lang3.builder.HashCodeBuilder:org.apache.commons.lang3.builder.HashCodeBuilder@275\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 4, 4, 8, "\u4ab0\ud932\ude80\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud82b\uddab\ud9ff\ude47\ud8e3\udfa4\udb94\udf63\udae4\udc86\ud99d\udda2\udb00\ude71\uda67\ude9e\ud82d\udf2b\udb3a\ude68\ud992\uddcd\udbfb\ude05\udae7\udc22\udb10\ude07\ud8da\udf05\ub418\ud91e\udfb9\u28e3", "\u3bc1\u45d3\u4250\u00d1\u8ecc\u6227\u5e8d\u4313", "\udb70\udeb5\ud990\udea8\udaad\udd75",
        30, 67152, 442433495, -2018988561498432070L, 25145L, true, true, (char) 14207, (char) 51945,
        Double.longBitsToDouble(0x3fde97363404e330L), Double.longBitsToDouble(0x3fe11e4b556f4c25L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[false, false, false, false, false, false, false, false]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[false, false, false, false, false, false, false, false]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 4, 4, 8, "\u4ab0\ud932\ude80\ud86e\uddc6\ud952\uddea\ud818\udc27\uda8f\udf5a\ud854\udc53\ud9ff\udea5\ud8e3\udfa4\uda6b\udf54\udae4\udc86\ud99d\udda2\ud9ea\ude66\uda67\ude47\ud82d\udf2b\udb3a\ude68\ud981\udccd\udbfb\ude05\udae7\udc22\udb10\ude07\ud96c\udf6d\ub3fb\ud91e\udfb9\ud98b\uddc3", "\u3bc1", "\uda8b\udd8e\udb2e\udc9e\ud8a1\udd65\u6169\uda4f\udff2\uda95\udc6d\ud819\udcf9",
        12, 31465, -962281244, 6093819706331863792L, 35392L, false, true, (char) 14164, (char) 16411,
        Double.longBitsToDouble(0x3fe02468ee9e0608L), Double.longBitsToDouble(0x3fed62fd01e97363L)));
  }
  @Test(timeout = 4000)
  public void test92() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[Z:[[true, true, false, true, false, true, false, false]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=org.apache.commons.lang3.builder.HashCodeBuilder:@? |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\012",
        Z.run(T, 2, 4, 9, 1, "\ud9a7\udf9f\ud942\udde1\ud8b4\uddc1\ud928\udd22\udab5\udff6\uda8f\udfed\ud86a\udeab\uda13\ude47\ud814\ude3c\ud884\udcdb\ud875\ude3b\ud83c\udc31\udbbe\ude47\ud982\udec0\udbcb\udd50\udbab\udffa\ud992\uddcd\udbfb\ude05\udae7\udc22\udbf6\udeda\ud8ac\ude4b\uda6a\udf8a\ud93b\udda4\udb6b\udcb3\udabf\udde5\ud809\udf92\ud89c\ude00\uda11\udd9c\udbe5\udf12\udbbd\udd8b\ud9f5\udcda\u2764\uf93b\uda23\udc52\uda81\udf6d\ud819\udcf9\uda07\udf3b\ud876\udcd4\udaad\udd75\udb5f\uddb8\udbfe\udce3\ub5cd\uda61\udf38\udb9e\udd25\ud996\ude63\udb2f\udff2\ud8e1\udc21\uda44\udc42", "\u446e\uc009\u485e\u2b12\u4842\ud39e\ubfe3\uca19\u4e3b\u5cd3\u3050\u97d2\ud505\u06e2\u0a8f\ub8bc\u2ca5\u0df3\u96cb\ubde0\ub742\ud770\u95ec\uac58\ud6f7\u0465\u374b\u2bf2\u418f\u3449\u9796\u5e14\u12f7\ud00c\u74af\uaab4\u076a\u50db\u727d\u8c77\u1dea\u0657\u5990\u4a45\u58b1\u07b4\u60fe", "\ud9ce\udd31\ud944\udc2b\udb85\udf0a\ue5cf\ud953\udd6c\ud86d\udd42\uda24\udfd7\uda44\ude9e\uda64\ude51\ud959\udd9e\ud9bc\udd19\ud98d\udd68\ud904\udfad\udaba\udc08\udbf3\udd8e\uda7e\ude51\uda7d\uddef\udb9c\udd6f\ud8ea\udd21\uc1b0\uda8c\udc92\udbeb\udc4e\udb20\udc5c\udba4\udf71\udbc3\uddf1\ud925\udef4\ud804\ude0b\uda39\uddcd\ud9e0\udec6\ud83e\udff3\ud813\udec4\udaeb\ude43\udbab\udea3\ud8bc\ude41\ud919\udea1\uda5a\udef1\uda19\udfe3\udace\ude8c",
        38, 59555, -1786978574, 9068910079010541998L, -87852L, false, true, (char) 37645, (char) 53665,
        Double.longBitsToDouble(0x3fc7479fa78ce270L), Double.longBitsToDouble(0x3fe36b721abcce27L)));
  }
  @Test(timeout = 4000)
  public void test93() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.builder.HashCodeBuilder:@? |a0=[F:[[27835.5, 28599.5, 27674.5, 28609.5, 27987.5, 28259.5, 27917.0, 28214.5]] |this=org.apache.commons.lang3.builder.HashCodeBuilder:@?\0121=void\012",
        Z.run(T, 2, 12, 17, 8, "\ud9a7\udf9f\ud865\udfb3\udad7\udcf7\uda4a\udc9d\udb02\udc1b\ud9a6\udd50\uf86a\ud930\ude38\ud8e3\udfa4\ud884\udcdb\ud861\ude39\ud83c\udc31\udbbe\ude47\udae8\udff4\udbcb\udd50\udb91\uddfa\ud993\udecd\udbfb\ude05\udae7\udc22\udab5\udef0\ud8ac\uddeb\uda6a\udf8a\ud93b\udda4\udb6b\udcb3", "\u867a\u2ad5\u4943\ub589\u2c4c\u917e\u5e8d\u4313", "\udb8a\udfa1\udad4\udda4\udaad\udd75",
        50, 5535, 1899459311, -2018808598066029126L, 71565L, false, true, (char) 14618, (char) 62156,
        Double.longBitsToDouble(0x3fd9560477588c18L), Double.longBitsToDouble(0x3fde97363404e330L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|isRegistered|java.lang.Object|static",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|register|java.lang.Object|static",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|unregister|java.lang.Object|static",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|boolean|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|[Z|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|byte|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|[B|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|char|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|[C|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|double|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|[D|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|float|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|[F|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|int|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|[I|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|append|java.lang.Object|new:org.apache.commons.lang3.builder.HashCodeBuilder:",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|isRegistered|java.lang.Object|static",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|register|java.lang.Object|static",
    "M|org.apache.commons.lang3.builder.HashCodeBuilder|unregister|java.lang.Object|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
