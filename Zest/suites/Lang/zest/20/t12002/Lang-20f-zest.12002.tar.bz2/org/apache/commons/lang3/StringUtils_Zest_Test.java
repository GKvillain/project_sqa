package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u69c5\udbef\udc6e\ud9b1\udc82\uda67\udcc3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u69c5\udbef\udc6e\ud9b1\udc82\uda67\udcc3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\udbc5\ude59\ua360\ud970\ude48\udb85\udc35");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u6a32\udbef\udc6e\udaf2\udd63");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb16\ude6c\udbef\udc6e\ud98f\udf07\uda67\udcc3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb16\ude6c\udbef\udc6e\ud98f\udf07\uda67\udcc3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\ud9e7\udeb8\ud941\udc17\ud93a\udff7\uda66\udfee");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9e7\udeb8\ud941\udc17\ud93a\udff7\uda66", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udb6b\ude6c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb6b\ude6c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\uda31\udd1a\udbe1\ude21\udb92\ude7d\udb4b\udc84\udab7\udef6\ud950\udc98\udaab\udfc8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda31\udd1a\udbe1\ude21\udb92\ude7d\udb4b\udc84\udab7\udef6\ud950\udc98\udaab\udfc8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\ud850\uddb1\udb0b\udf6b\uda94\udd93\ud97e\udecf");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\udac8\udff9\ud922\udc0c\udb3b\udd11\udb8b\udfbb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u69df\udbef\udc6e\ud9b1\udc82\udac5\udcd2\ud849\udf69");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u69c5\udbef\udc6e\ud82b\udec4\u7130\udbb2\udc18\ud9fe\uded1\udb12\udfba\udb89\udcf4\ud848\udd11");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\ud89a\udcb6\udaef\udf92\ud9b6\uddd1\uda4c\udea3\uf228");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\u69c5\ud911\udfa9\ud8a9\udf91\uda67\udcc3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u69c5\ud911\udfa9\ud8a9\udf91\uda67\udcc3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\udbd4\uddde\udbf8\ude6e\ud980\udfea\udaa6\ude4a\u3c4b\ud8fd\uded1\udac1\ude8b\ud8f7\udefa\ud96e\udd44\udb78\udf4e\ud87f\uded8\uf0d6\ud89a\ude5d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbd4\uddde\udbf8\ude6e\ud980\udfea\udaa6\ude4a\u3c4b\ud8fd\uded1\udac1\ude8b\ud8f7\udefa\ud96e\udd44\udb78\udf4e\ud87f\uded8\uf0d6\ud89a", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud940\ude35\udbef\udcdd\ud82f\udda4\ud9b6\udfa5\uda5d\uddb9\ud94e\udd48\uda74\udf43\uda2b\udca5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud940\ude35\udbef\udcdd\ud82f\udda4\ud9b6\udfa5\uda5d\uddb9\ud94e\udd48\uda74\udf43\uda2b\udca5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\uce0f\udb43\udeab");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uce0f\udb43\udeab", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\u6a27\ud8b0\udcae\ud98c\udc35\uda67\udcc3\ud9a3\udf2a\ud8b7\udeec\udbdc\udce8\udad1\udff2\ud849\udcf2\udaa6\udec8\ud86a\udd00\udbcb\ude72\udba5\udee1\udb5f\udd87\udb34\udcb1\ud9df\ude4d\ud82b\udd63\ud9f9\ude1e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udab7\udf01\uda98\udfeb\udbdf\udd8d\ud8c7\udee7\ud9d3\udf40\uda78\udce6\udbf3\udc60\uda1b\udfc4\ud91f\udfd9\u7c67\uda34\udcfc\ud92c\udfda\ud851\ude72\ud84d\udc19\u7ee9\ud860\uddab\ud8ce\udfd2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udab7\udf01\uda98\udfeb\udbdf\udd8d\ud8c7\udee7\ud9d3\udf40\uda78\udce6\udbf3\udc60\uda1b\udfc4\ud91f\udfd9\u7c67\uda34\udcfc\ud92c\udfda\ud851\ude72\ud84d\udc19\u7ee9\ud860\uddab\ud8ce\udfd2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\ud8e9\udc81\udbef\udc6e\ud9b1\udd2e\uda67\udcc3\udaa7\ude99\ud9c5\udfb8\ud98c\udfd6\udb35\udc7c\ud9ce\ude52\uda5a\udfda\ua898\ud878\udedd\udab6\udd14\ud929\udd33\ud9ad\ude70\udb59\ude17\u7802\ud832\udfc3\ud845\udd08\uda38\udd93\ud9ef\udcfb\ud9ff\ude4c\udaa9\udc49\ud8af\udd30\udbc7\udc1a\udb71\ude58\ud8e1\udd03\uda4a\udd24\uda46\ude28\udbf8\udcba\ud93b\udf05\ud98b\udf8c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8e9\udc81\udbef\udc6e\ud9b1\udd2e\uda67\udcc3\udaa7\ude99\ud9c5\udfb8\ud98c\udfd6\udb35\udc7c\ud9ce\ude52\uda5a\udfda\ua898\ud878\udedd\udab6\udd14\ud929\udd33\ud9ad\ude70\udb59\ude17\u7802\ud832\udfc3\ud845\udd08\uda38\udd93\ud9ef\udcfb\ud9ff\ude4c\udaa9\udc49\ud8af\udd30\udbc7\udc1a\udb71\ude58\ud8e1\udd03\uda4a\udd24\uda46\ude28\udbf8\udcba\ud93b\udf05\ud98b\udf8c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u69c5\udbef\udc6e\ud9b1\udc82\uda67\udcc3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ud9dc\udfb6\udaee\uddac\ud8e3\udebd\uda6c\udcb2\udb99\udc06\ud961\udcac\udab7\udc33\ud91c\udda6\ud864\udf37\udb22\udfae\ud8bf\udc30\uda81\uddb5\udaaf\udee2\udb51\udf35\ud8e8\udd8c\ud869\udc17\ud8ba\udd39\udaa9\ude46\udb8f\udf3a\ud872\udc2a\ud91b\uddac\ud98d\udcf9\uda76\udd67\udb7a\udcb3\udb2a\udc05\uda01\ude20\ud95d\udd80\udada\udd11\ud910\udc1a\ud832\udc6e\udb40\udfb3\ud8df\udd0e\uda40\uddc2\udb86\udf41\ud9f7\udf89");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud8f5\ude03\ud9b2\udefa\u30ff\uda23\ude21\ud843\udd29\ubd72");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\udb1d\ude03\ud8ac\udffb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\udba6\udcc7\ud9a5\udf39\ud9be\udd5e\udb28\ude5f\ud999\udda7\udb75\udd1e\ud8fd\udfd0\udbc9\udc10\ud8bb\udfb5\udb7e\udc45\udbc8\udd3a\udb0e\udd51\ud969\udc6f\uda1e\udf98\uda7d\uddfe\ud94f\udd20\uda22\udc51\ud816\ude0f\u71f5\uda59\udde8\ud815\udf52\udafd\udfb4\udade\udea5\ud98d\udf96\udb93\udeb9\ud9bf\udf9b\uda7d\udc5d\ud8ba\udfa7\udb21\udedb\ud915\udf19\ud8c0\udd8e\udad7\udff6\ud8e8\udeba\udac8\udd7c\udb8c\uddb4\ud95a\udefc\ud90b\udc1a\ud8e5\ude24\udb7e\udd11\ud974\udf3a\uda0a\udf2f\udaf6\udc7b\ud888\ude99\udaa4\udf18\ud95e\udf34\ud937\udc0c\ud8d5\udd29\udb9e\udd28\ud867\udfed\udb56\ude70\ud914\udfbe\ud8d0\udf4e\udaa4\udc8e\udbb4\udece\ud8f6\ude31\ud97f\udddd\ud983\udf65\ud8fa\udf7a\udbba\uddab");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\u89cb");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\u69c5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud992\udc00\ud904\uddf9\uda96\ude87\udb49\udccf\uda95\udeaf\ud89c\uded7\ud819\udc25\ud37f\ud90a\ude1d\ud8e2\udefc\u27c7\ud88c\udd4b\ud84c\udf6d\ud8d4\udf81\ud9fd\udd74\udab9\udc40\ud879\uddfd\udad0\uddb5\udbbd\uddba\ud980\ude26\ud86c\udd67\ud821\ude2d\udb89\ude38\ud99c\udd1b\udb14\uddfe\udaeb\ude81\uda39\ude08\ud8bb\udf15\u6772\ud9be\ude09\ud825\udff8\ud8ca\udc9f\udb60\udf41\udb5c\udd33\ud949\udcd6\udbad\udf80\ud8d1\udf20\ud869\udec5\ud822\ude76\ud9a6\udfea\ud84a\udd93\ud851\udd4a\udb2f\udc7d\uda06\udf8f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud992\udc00\ud904\uddf9\uda96\ude87\udb49\udccf\uda95\udeaf\ud89c\uded7\ud819\udc25\ud37f\ud90a\ude1d\ud8e2\udefc\u27c7\ud88c\udd4b\ud84c\udf6d\ud8d4\udf81\ud9fd\udd74\udab9\udc40\ud879\uddfd\udad0\uddb5\udbbd\uddba\ud980\ude26\ud86c\udd67\ud821\ude2d\udb89\ude38\ud99c\udd1b\udb14\uddfe\udaeb\ude81\uda39\ude08\ud8bb\udf15\u6772\ud9be\ude09\ud825\udff8\ud8ca\udc9f\udb60\udf41\udb5c\udd33\ud949\udcd6\udbad\udf80\ud8d1\udf20\ud869\udec5\ud822\ude76\ud9a6\udfea\ud84a\udd93\ud851\udd4a\udb2f\udc7d\uda06\udf8f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud8d4\ude6f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud80c\udf87\udb48\udc18\ud82a\ude2e\udbf2\uddb6\ud967\udcf6\ud931\udfff\ud96f\udc88\u13ea\uda71\udf54\udbb0\udc49");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u82a0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\u6a32");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u6a32", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\uba9c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u69ca\u71db\udaf2\udd63\udb4b\udc16\ud90b\udc62\ud811\udd08\ud960\udd1c\u05a8\uda96\udf32\uf1f4\ud8df\uddbd\ud9ab\udf7c\ud851\udd03\udb94\udeb9\ud9cd\udf08\ud8f4\udd46\ud8b8\udd54\ud9dd\udc9b\ud8a4\udd35\udab8\udc97\ud938\udc62\udb8f\ude1c\ud863\udf78\udbe5\ude3a\uda43\udd9d\udb50\udc31\ud82f\udf6d\ud874\udcc7\uda7b\udf6e\udb38\udd32\udad5\ude58\ud8ed\udc35\ud9fe\ude98\udb7b\udd10\udb90\udcda\ud8bb\ude71");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u9794");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u69df\u608a\ud9e6\uddb5\udac5\udcd2\ud9e4\udf64");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u69c5\u3f80\uda6d\udc21\udb1a\ude5a\ud974\udf3f\ud9d0\ude26\uda4c\udc94\udb89\udc4b\ud804\udf51");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u69c5\udbef\udc6e\ue6cb\ud97b\udcaf\ud883\uddfd\ud9fe\uded1\ud8c1\udf71\udbf1\udf21\u0f82\ud9c6\udc45\uda59\udf8f\udaf8\uddc4\ud8cd\udda4\ud9e9\udd9c\uda38\udf2e\udb3b\ude8d\ud92e\udf83\udb99\ude43\ud81b\udf3e\uda0c\udcdc\udbe9\udc1f\ud846\udd56\udb05\udc50\ud9bc\udca8\ud83b\uddb6\udb3f\udc54\ud97b\udce6\ud942\udc5b\udb2c\udf4c\udbc8\udc8d\ud8ac\ude38\udafb\ude6a\udb00\uddb6\udadd\udc79\udaf0\udf01\uda45\udc4f\ud932\udc08\ud9d5\udc84\udb78\uddfb\udbfb\udc54\ud948\ude33\udad4\udd8d\udb40\udd26\uda6e\udefd\ud9a5\ude25\ud8fe\udf86\ud91f\ude8b\ud8ba\udd3f\ud880\ude0f\ud9a9\uddfc\ud91c\udf2d\udbde\uddae\ud84b\udfd9\udbbb\uddb0\ud909\udf93\udac8\ude93\udaeb\udd76\uda2a\ude79\ud833\udf6f\ud95c\udd62\ud8f1\udc4b\ud955\ude09\ud81c\udfa0\uda22\udc8b\udb22\ude6b\ud93a\udf08\udb3f\udc06\udbab\udf34\ud808\ude8b\uda75\udd69");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud9a8\udf6b\ud911\udfa9\u9bef\ud82b\udf1d\ud934\ude41\ud807\ude28\udbba\udc82\ud9f1\udf8c\ud812\udefb\ud8c6\udc35\u30c8\ubc4a\ud893\udf6c\uda49\udffa\ud946\udf40\uda9f\ude04\ud91e\udde7\uda5f\ude53\ud8e8\ude3a\udb85\udded\udb41\udd31\ud912\udfd0\ud912\udcfd\uda0c\udd9d\udbd0\udf5c\ud9e7\ude3b\uda50\udc14\ud8f1\ude66\udaa9\udf8a\ud81a\udde7\ud9c8\ude7d\ud909\udfe9\udae4\udd8d\uda9d\udf98\udb4e\udf48\uf726\udac3\udc0a\ud808\ude25\ud88b\ude43\uda88\ude50\udb2c\udd97\uda55\udc40\ud853\udf53\ud8b9\udc2f\udbc4\udf86\ud82e\udf58\ud8bd\udfb4\ud858\udf99\udace\ude92\uda5b\udf77\udad6\udfc0\uda6c\udc08\ud95c\ude67\ud99f\ude04\ud992\udeb4\ud96d\udc60\ud911\udcce\ud87b\udd9a\ud97a\udd85\uda9f\udcef\uda0d\ude6f\ud901\udd16\ud803\udc66\udb81\udf5a\udb4c\udd7c\ud952\uddec\udace\udc4d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\u6a27\ud8b0\udcae\ud98c\udc35\uda67\udcc3\ud9a3\udf2a\ud8b7\udeec\udbdc\udce8\udad1\udff2\ud849\udcf2\udaa6\udec8\ud86a\udd00\udbcb\ude72\udba5\udee1\udb5f\udd87\udb34\udcb1\035\ud81d\udcee\ud9f9\ude1e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\uda1f\udef2\ud9a5\udd3e\udac0\udc13\udab2\udd4d\ud8a0\udfd4\udacb\udf86\ud8af\udf75\ud893\udfaa\ud86c\udc99\ud8d0\udc68\ud88b\uddcb\ud96e\udd78\uda47\uddc4\ud9c3\udf73\ud882\udc32\ud807\udd85\ud9b9\udca2\udac9\udf21\ud94e\udd03\uda87\udc06\u2e7d\ud94d\udc13\udaea\udec3\udb7a\udffa\udbbc\udf55\uda3a\udf1c\uda4e\ude5f\ud8ea\udc6d\ud8a5\udc6b\udb73\udcad\udbf9\udd02\uda34\udeb0\ud9b8\udf09\ud900\udf6d\udbff\udd75\ud84a\ude56\udb27\udfc9\ud87f\udc65\udbde\uddfe\ud871\udc26\ud9df\udf93\udb8a\udf81\ud805\udf8c\ud9a4\udf1b\udbe9\udd22\uda44\udf22\ud8b5\udfac\udb6a\ude56\udb1c\udcb7\ud849\udf4b\ud9fc\udfcf\ud920\udc96\ud839\udfb1\ud969\udcac\uda56\udc28\ud9f5\udc22\ud801\udce1\udbeb\udfc4\uda03\udee7\ud84c\udd97\ud8c6\uddd0\ua1ce\udbab\udffe\ud82d\udd2b\udacc\udcf4\udac7\udec0\udab7\ude84\ud920\uddbb\uda08\udf70\udb3f\udc91\ud8bf\udd7c\udbbb\udfc3\ub086\ud927\udc25");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda1f\udef2\ud9a5\udd3e\udac0\udc13\udab2\udd4d\ud8a0\udfd4\udacb\udf86\ud8af\udf75\ud893\udfaa\ud86c\udc99\ud8d0\udc68\ud88b\uddcb\ud96e\udd78\uda47\uddc4\ud9c3\udf73\ud882\udc32\ud807\udd85\ud9b9\udca2\udac9\udf21\ud94e\udd03\uda87\udc06\u2e7d\ud94d\udc13\udaea\udec3\udb7a\udffa\udbbc\udf55\uda3a\udf1c\uda4e\ude5f\ud8ea\udc6d\ud8a5\udc6b\udb73\udcad\udbf9\udd02\uda34\udeb0\ud9b8\udf09\ud900\udf6d\udbff\udd75\ud84a\ude56\udb27\udfc9\ud87f\udc65\udbde\uddfe\ud871\udc26\ud9df\udf93\udb8a\udf81\ud805\udf8c\ud9a4\udf1b\udbe9\udd22\uda44\udf22\ud8b5\udfac\udb6a\ude56\udb1c\udcb7\ud849\udf4b\ud9fc\udfcf\ud920\udc96\ud839\udfb1\ud969\udcac\uda56\udc28\ud9f5\udc22\ud801\udce1\udbeb\udfc4\uda03\udee7\ud84c\udd97\ud8c6\uddd0\ua1ce\udbab\udffe\ud82d\udd2b\udacc\udcf4\udac7\udec0\udab7\ude84\ud920\uddbb\uda08\udf70\udb3f\udc91\ud8bf\udd7c\udbbb\udfc3\ub086\ud927\udc25", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u82a0\ub3a4\uce72\ud967\udca0\ud8cd\uded9\udb3b\ude0a\ud880\ude6d\ud9cc\udde4\ud99a\udd23\udb5f\ude1a\udafd\udc6d\udb2a\udf88\uda29\udf0d\udb04\udd6c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud96b\uddce\ud850\uddf2\ud97a\ude99\uda67\udcc3\ud9a3\udf2a\ud8b7\udedc\udbdc\udce8\udad1\udff2\ud849\udcf2\udaa6\udec8\uda8f\udef3\ud9f2\ude2c\udba5\udee1\udb5f\udd87\udb34\udcb1\035\ud81d\udcee\ud926\ude95");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud96b\uddce\ud850\uddf2\ud97a\ude99\uda67\udcc3\ud9a3\udf2a\ud8b7\udedc\udbdc\udce8\udad1\udff2\ud849\udcf2\udaa6\udec8\uda8f\udef3\ud9f2\ude2c\udba5\udee1\udb5f\udd87\udb34\udcb1\ud81d\udcee\ud926\ude95", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u82a0\ub3a4\uce72\ud967\udca0\uda12\udc5f\udb4a\udd45\ud880\ude6d\ud9cc\udde4\ud99a\udd23\ud9e3\udfbd\ud89b\udf16\uda24\udca5\uda55\udecc\udb46\udd6d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u69c5\u9ee2\u1587\uda67\udcc3");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u69c5\u9ee2\u1587\uda67\udcc3", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ua69a\udbef\udc6e\ud9b1\udc82\uda67\udcc3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud96b\uddce\ud98a\uddef\udaf8\udf59\000\ud9a3\uded5\ud8b7\udedc\udbdc\udce8\udad1\udf14\ud849\udcf2\014\ud923\udcd1\ud9b8\udd3c\udba5\udee1\udb5f\udd87\udb34\udcb1\035\ud81d\udcee\ud926\ude95");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud96b\uddce\ud98a\uddef\udaf8\udf59\000\ud9a3\uded5\ud8b7\udedc\udbdc\udce8\udad1\udf14\ud849\udcf2\ud923\udcd1\ud9b8\udd3c\udba5\udee1\udb5f\udd87\udb34\udcb1\ud81d\udcee\ud926\ude95", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ua69a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\ua649\udb5d\ude61\udaf9\udd5d\udb87\udd1b\ud9b4\udebf\udbf8\udeb4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u69c5\u3f80\u00e4\udae7\uddb3\000\000\uda11\udc67\udb89\udc4b\ud804\udf51");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ua69a\u1e0c\ud9b1\udc82\udb47\udd12");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u82a0\ub3a4\uce72\u7b24\ud94e\udcb5\udb81\udf29\ud875\ude22\ud9cc\udde4\ud99a\udd23\udb5f\ude1a\udafd\udc6d\udb2a\udf88\uda29\udf0d\udb04\udd6c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u82a0\ub3a4\uce72\u7b24\ud94e\udcb5\udb6c\udc29\ud875\ude22\ud9cc\udde4\ud99a\udd23\udb5f\ude1a\udafd\udc6d\udb2a\udf88\uda29\udf0d\udb04\udd6c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u82a0\u00f1\uce19\u5278\uda11\udf69\udb4a\udd45\ud848\udd6d\000\000\uf3e9\000\000\000\udb27\udef3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\ua649\u2d18\udaf9\udd5d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
