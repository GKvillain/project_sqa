package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud92e\uddf1\ud941\udc18\udb20\udc68\udbf1\ude1a\ud81f\udfd1\ud9c1\udd8f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud92e\uddf1\ud941\udc18\udb20\udc68\udbf1\ude1a\ud81f\udfd1\ud9c1\udd8f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud82e\udf23\ud90f\udef4\ud9f7\udf2e\udbfc\udf81\ud8f0\udd72\ud92e\uddf1\ud941\udc18\udb20\udc68\udbf1\ude1a\ud81f\udfd1\ud9c1\udd8f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud82e\udf23\ud90f\udef4\ud9f7\udf2e\udbfc\udf81\ud8f0\udd72\ud92e\uddf1\ud941\udc18\udb20\udc68\udbf1\ude1a\ud81f\udfd1\ud9c1\udd8f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\ud82e\udf23");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud82e\udf23", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\ud8fe\ude15\ud909\uddcf\ud8c3\udebb\ud993\udcca");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\ud8fe\ude15\ud909\uddcf\ud8c3\udebb\ud993\udcca", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\udbd2\udcd9\uda2d\udebb\ud9c0\udc9c\udb92\udff1\ud907\ude71");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\ud82e\udf23\ud8bd\udf60\ud92c\udc48\uda6f\udd7b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud82e\udf23\ud8bd\udf60\ud92c\udc48\uda6f\udd7b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud896\udff7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\u69c2\uda94\udffd\ud9bd\ude13\udbfc\udfe6\ud92d\udf71\udb9f\uddca\ud853\udff4\udae6\udc6b\udbe4\udf75\ud814\udead\ud996\ude8c\ud8d7\udf12\udbd1\ude22\ud8bb\udcfa\u127f\ud930\udf82\udbfa\udebc");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u69c2\uda94\udffd\ud9bd\ude13\udbfc\udfe6\ud92d\udf71\udb9f\uddca\ud853\udff4\udae6\udc6b\udbe4\udf75\ud814\udead\ud996\ude8c\ud8d7\udf12\udbd1\ude22\ud8bb\udcfa\u127f\ud930\udf82\udbfa\udebc", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud8a3\udec6\ud963\udf2e\ud9c0\udc86");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\ud89f\uded9\ud81e\udc9d\ud9b8\udcd5\ud8cd\udf8e\udb31\ude7e\uda31\udfc2\ud8de\udc4a\udb4c\udeba\udaaf\ude40\udbb9\ude16\uda64\udeab");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud92e\uddf1\ud941\udc18\ud8b6\udfc3\udbd3\udc2c\ud86c\udfb8\ud903\ude2f\u2082\udb5b\ude47\ud93a\udc0a\ud9e5\udd1f\ud863\udfca\ud809\ude67\ud892\udcc3\ud9ce\udebf\ud80d\udd23\udb3e\ude5b\udbba\udd46\ud821\udce3\udbe7\udf7d\uda2b\udee4\udadc\udc62\udb16\ude85\ud8da\udf45\udbd9\udcd6\ud9e4\udee2\udbd8\ude10\ud835\udcc7\uda06\udea7\udb71\ude71\u6df0");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud92e\uddf1\ud941\udc18\ud8b6\udfc3\udbd3\udc2c\ud86c\udfb8\ud903\ude2f\u2082\udb5b\ude47\ud93a\udc0a\ud9e5\udd1f\ud863\udfca\ud809\ude67\ud892\udcc3\ud9ce\udebf\ud80d\udd23\udb3e\ude5b\udbba\udd46\ud821\udce3\udbe7\udf7d\uda2b\udee4\udadc\udc62\udb16\ude85\ud8da\udf45\udbd9\udcd6\ud9e4\udee2\udbd8\ude10\ud835\udcc7\uda06\udea7\udb71\ude71\u6df0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\ud94d\udd05\uda0a\udf93\udb35\udc59\udbf1\udf51\ud8f0\udd72\ud970\udceb\ud941\udc18\udb20\udc68\udbf1\ude1a\ud80f\uded1\ud9c1\udd8f\udbc9\udeb4\ud88e\udfa3\udba9\ude54\udb6c\udc70\uda49\udc59\uda6b\udf0a\ud9ca\udec8\udbcd\uddf5\ud991\udc2f\ud825\udc3f\udba9\ude7a\udac4\udfa1\udbba\udc01\ud9bd\udcc3\ud93f\udcea");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud94d\udd05\uda0a\udf93\udb35\udc59\udbf1\udf51\ud8f0\udd72\ud970\udceb\ud941\udc18\udb20\udc68\udbf1\ude1a\ud80f\uded1\ud9c1\udd8f\udbc9\udeb4\ud88e\udfa3\udba9\ude54\udb6c\udc70\uda49\udc59\uda6b\udf0a\ud9ca\udec8\udbcd\uddf5\ud991\udc2f\ud825\udc3f\udba9\ude7a\udac4\udfa1\udbba\udc01\ud9bd\udcc3\ud93f\udcea", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\udbac\udd87\ud8a4\ude1f\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud92e\uddf1\ud941\udc18\ud976\udfdf\u415d\ud81f\udfd1\ud9c1\udd8f\uda9c\udfea\ud8de\udf1c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud80a\udea8\ud945\ude94\udaf6\udc16");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud80a\udea8\ud945\ude94\udaf6\udc16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("\ud82e\udf23\ud8a4\ude1f\u9b71\000\ud8b6\uddba\ud92e\uddf1\ud941\udc18\udb20\udc68\udb94\udf2a\u00fc\ud9c1\udd8f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud82e\udf23\ud8a4\ude1f\u9b71\000\ud8b6\uddba\ud92e\uddf1\ud941\udc18\udb20\udc68\udb94\udf2a\u00fc\ud9c1\udd8f", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\ud82e\udf23\ud8a4\ude1f\udae6\udd05\udbfd\udcbe\uda54\ude91\ud8e3\udf74\ud82f\udc32\ud8f5\udd4a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\ud8ac\udea4\ud902\udfe8\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud92e\uddf1\ud941\udc18\u4e02\ud806\udf07\ud95e\udf2f\ud9c1\udd8f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8ac\udea4\ud902\udfe8\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud92e\uddf1\ud941\udc18\u4e02\ud806\udf07\ud95e\udf2f\ud9c1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ud88a\udda5\u1bc0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud90b\ude56");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud90b\ude56", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\udb95\udd32\u371e\ud92e\uddf1\ud941\udc18\udb20\udc68\udbf1\ude1a\ud81f\udfd1\ud9c1\udd8f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\014\udb06\udde2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb06\udde2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud82e\udf42\ud8a4\ude1f\ud9c0\udc9c\udbfc\udfe6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chop("\ub417");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud9af\udf34\uda6e\udc83\u1a75\uda9d\udf52\ud8e4\ude24\ud9eb\udcc3\udb59\udd77\ud8dc\udfb0\udb7e\udeb2\ud873\ude42\uda96\udc4a\udb6b\udf62\ud95f\udead\uda5d\udeb7\uda90\udcc1\udb6f\udc0a\u2f02\uda79\ude57\udb21\uded3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\u03f5\uda89\udc73\ud85a\udef5\uda11\udea2\ud8e2\udcee\udb01\udfe3\udb92\udcc7\ud8f3\ude70\udb6a\uddbd\udae2\udf77\ud867\ude34\udac1\ude28\ud979\udc66\ud945\ude5b\udb10\udfe6\udb7b\udc21\udbe1\udec6\ud9f2\udcd4\ud929\udf38\udaa1\udc17\ud92b\udee5\ud897\udc93\ud8d7\udfc5\udb77\uddcf\udb68\ude0e\udbf4\udf8e\uda10\uddb3\udaf2\udfaf\ud89d\udc7c\ud872\udfd5\udadf\ude27\ud9d1\ude18\ud9d1\udd08");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u9e92\udbe2\udc4b\ud88c\udf17\u281d\ud845\udf66\udbc4\udca6\udb60\udd83\uda83\udd1e\udb1f\ude6f\uda9c\udf6e\udad5\uddff");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\uc0d8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\ud62d\ud8b9\udff2\ud8c1\udf99\udb98\udf9e\ud8fb\udd3d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\ubc45\ud9e8\uddd3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u9782");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\u3fab");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\ud9fb\udcc9\ud977\ude21\u9b4c\ud913\ude2a\ud84d\udf63\ub1e2\uda5b\udc9a\ud945\udd51\udb94\udf2a\034\udb2f\udf26");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u217a\ud817\udfce\u9b71\ud940\udcc0\ud88a\udc1f\udb64\uddf5\ud941\udc18\udb20\udc68\ud971\ude85\udaf8\udcb1\uda77\udd6c\ud91a\udd54");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\uf9c4\ucec7\udbba\udc4f\ud977\ude78\ud994\udd76\udabb\ude32\ud9df\udd53\ud88a\udc38");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u4394\u1d0b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\uc4c3\u8994\uda98\ude5f\ud95f\udc94\udb82\ude2e\ud8cc\udc4c\ud90e\ude3d\ud9d9\udccb\uda5d\udec2\ud815\udc54\udb6e\udda5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.defaultString("\uda3b\udd61\ud9e4\udc11\udaa7\udde4\ud9ab\ude80\ud86e\uddda\uda76\ude30\ud89a\uddb4\udaa8\udd2a\ud885\ude6a\udb77\udeca\udaac\udd2d\ud907\udc4b\ud9b2\udfb2\uda32\udd84\uca2e\ud8b9\udcd8\udaa8\udc52\uda37\uddb1\udbd8\udc53\ud8f2\udd4f\uda40\udd32\ud964\udfe7\ud949\udf57\udace\udeeb\udb0a\udfab\ud8e2\udec9\udb26\udeb8\ud85f\udc99\ud870\udfb7\uda5e\udcb2\udb7a\udd99\ud8a4\udf37\udb5b\udf18\udb7d\udcda\ud971\udca1\uda44\udf3e\ud9d6\udf01\ud90d\uddb4\ud9b3\udf64\udabe\udc70\uda6c\uddf3\uda1a\ude8f\udba5\udc98\uda9d\udd17\uda4e\udee7\udb1a\uddf4\udba8\udd7e\ubb57\uf83b\ud857\udefa\udafa\udd7b\ud9e6\uded4\u54da\ud8f4\udc48\udb08\udec7\uda9e\udc23\udbed\udc72\udbba\udfb8\udb7f\udeb6\udbcf\udfcd\ud8bc\udd10\ud9b8\udca0\ud9d9\udc27\udba9\ude20\udbc4\udf2e\udbd0\udf0c\udbd1\udf42\udb8e\udc86\ud90a\udd72\ud845\udeb4\ud807\udf6f\udbf4\udd96\udae3\ude50\uda19\udfd2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda3b\udd61\ud9e4\udc11\udaa7\udde4\ud9ab\ude80\ud86e\uddda\uda76\ude30\ud89a\uddb4\udaa8\udd2a\ud885\ude6a\udb77\udeca\udaac\udd2d\ud907\udc4b\ud9b2\udfb2\uda32\udd84\uca2e\ud8b9\udcd8\udaa8\udc52\uda37\uddb1\udbd8\udc53\ud8f2\udd4f\uda40\udd32\ud964\udfe7\ud949\udf57\udace\udeeb\udb0a\udfab\ud8e2\udec9\udb26\udeb8\ud85f\udc99\ud870\udfb7\uda5e\udcb2\udb7a\udd99\ud8a4\udf37\udb5b\udf18\udb7d\udcda\ud971\udca1\uda44\udf3e\ud9d6\udf01\ud90d\uddb4\ud9b3\udf64\udabe\udc70\uda6c\uddf3\uda1a\ude8f\udba5\udc98\uda9d\udd17\uda4e\udee7\udb1a\uddf4\udba8\udd7e\ubb57\uf83b\ud857\udefa\udafa\udd7b\ud9e6\uded4\u54da\ud8f4\udc48\udb08\udec7\uda9e\udc23\udbed\udc72\udbba\udfb8\udb7f\udeb6\udbcf\udfcd\ud8bc\udd10\ud9b8\udca0\ud9d9\udc27\udba9\ude20\udbc4\udf2e\udbd0\udf0c\udbd1\udf42\udb8e\udc86\ud90a\udd72\ud845\udeb4\ud807\udf6f\udbf4\udd96\udae3\ude50\uda19\udfd2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u0416\udb52\ude04\udb4e\udcdb\uda79\udf40\udb10\udec3\ud8e4\udd3e\uda09\udc2f\udaab\udf46\udb73\udc3b\ud956\uddf8\u5175\udb0b\udea9\udace\udd82\ud883\udcd9\ud94a\udd76\ud82d\udf03\ud9f0\udd4e\udb45\udea3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u217a\u00e2\000\000\u4d4a\000\u44c2\u8e00\ud8b1\udf78\000\000\udae2\uddb1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u0416");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud995\ude72\ud887\udc1f\ud99c\ude1c\udba2\udf22\ud816\udcfb\udbef\udda1");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud82e\udf23\ud8a4\ude1f\ud9c0\udc9c\udbfc\udfe6\ud8f0\udd72\ud995\ude72\ud887\udc1f\ud99c\ude1c\udba2\udf22\ud816\udcfb\udbef\udda1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.containsWhitespace("\udab8\udfb5\ud859\ude3c\ud971\udf97\uda1f\udfe7\ud9c1\ude6b\ud989\udd39\ud8cd\udd4a\ud92a\udd2b\udb72\udf4b\u3c29\u2425\ud847\udd05\ud82b\udddb\ud9d6\ude18\udb4b\udff1\udaea\ude11\ud97b\udf27\udbec\ude38\ud9f6\udf9f\ud9e0\udf57\ud891\udead\udb35\udeb5\uda48\udd07\udb28\udfed\ud8f5\udc4e\udaff\udfe9\udac4\udcd0\u283f\ud97f\udf0a\ud9b7\uddb3\udbcf\udf26\udb93\udf88\ud93a\uddba\u9d60\ud9dc\udeef\udba3\udd09\uda11\udcc6\ud825\uddab\ud92f\ude3c\ud8ae\uddfd\uda15\udc2a\ud89c\udecf\udbb5\udc1b\uda7f\udfb9\uda3c\udf3b\uda46\uddce\uda67\udd63\uda95\udcf0\udaf5\udea1\udb03\udc6a\ud984\udc58\ud9e5\ude5f\udbad\udc7b\uda1e\udd6c\ud9b7\ude07\udbf3\udd8e\ud813\udd1d\ud88c\uddd5\u7bce\ud92c\udc7d\ud88d\udeb7\uda43\uded9\uda4f\udcca\ud94d\udf6c\ud968\udd98\uda1f\udd4c\ud9d3\udeec\ud948\udf93\udb46\udc1b\ud99a\udd52\udbea\udc57\udb18\udff7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.deleteWhitespace("\udab8\udfb5\ud859\ude3c\ud971\udf97\uda1f\udfe7\ud9c1\ude6b\ud989\udd39\ud8cd\udd4a\ud819\udfa3\ud922\udc95\u3c29\u4325\ud847\udd05\ud82b\udddb\ud9d6\ude18\udb4b\udff1\udaea\ude11\ud97b\udf27\udbec\ude38\uda12\udcec\ud9e0\udf57\ud891\udead\udb35\udeb5\uda48\udd07\udb28\udfe2\ud8f5\udc4e\uda7b\udfc5\udad5\ude18\udbd8\udc8a\udb13\udfee\ud9b7\udd3f\ud961\udf2f\udb93\udf88\ud93a\uddba\u9d60\ud877\udc1d\udb4c\udf6d\uda11\udd26\ud971\udc8f\ud92f\ude3c\ud8ae\uddfd\uda15\udc2a\uda61\udcfe\uda10\udf67\uda7f\udfb9\uda65\udeae\u0f76\uda1c\udd3e\uda95\udcf0\udaf5\udea1\udb03\udc6a\ud984\udc58\ud9e5\ude5f\udbad\udc7b\uda1e\udd6c\ud9b7\ude07\udbf3\udd8e\ud813\udd1d\ud88c\uddd5\u7bce\ud92c\udc7d\ud8a6\udcb7\uda43\uded9\uda4f\udcca\ud94d\udf6c\ud968\udd98\udbb1\udf14\ud9d3\udeec\ud948\udf93\udb46\udc1b\ud99a\udd52\udbea\udc57\udb18\udff7\uda46\udcee\ud84c\ude26\udb50\udf00\udaa7\udfd2\ud845\ude5a\ud8d4\udc0e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udab8\udfb5\ud859\ude3c\ud971\udf97\uda1f\udfe7\ud9c1\ude6b\ud989\udd39\ud8cd\udd4a\ud819\udfa3\ud922\udc95\u3c29\u4325\ud847\udd05\ud82b\udddb\ud9d6\ude18\udb4b\udff1\udaea\ude11\ud97b\udf27\udbec\ude38\uda12\udcec\ud9e0\udf57\ud891\udead\udb35\udeb5\uda48\udd07\udb28\udfe2\ud8f5\udc4e\uda7b\udfc5\udad5\ude18\udbd8\udc8a\udb13\udfee\ud9b7\udd3f\ud961\udf2f\udb93\udf88\ud93a\uddba\u9d60\ud877\udc1d\udb4c\udf6d\uda11\udd26\ud971\udc8f\ud92f\ude3c\ud8ae\uddfd\uda15\udc2a\uda61\udcfe\uda10\udf67\uda7f\udfb9\uda65\udeae\u0f76\uda1c\udd3e\uda95\udcf0\udaf5\udea1\udb03\udc6a\ud984\udc58\ud9e5\ude5f\udbad\udc7b\uda1e\udd6c\ud9b7\ude07\udbf3\udd8e\ud813\udd1d\ud88c\uddd5\u7bce\ud92c\udc7d\ud8a6\udcb7\uda43\uded9\uda4f\udcca\ud94d\udf6c\ud968\udd98\udbb1\udf14\ud9d3\udeec\ud948\udf93\udb46\udc1b\ud99a\udd52\udbea\udc57\udb18\udff7\uda46\udcee\ud84c\ude26\udb50\udf00\udaa7\udfd2\ud845\ude5a\ud8d4\udc0e", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u213f\u71ce\u9bd2\udbab\ude95\ud873\udcb4\udba6\udfe4\ud940\udf9a\udb20\udc68\ud971\ude85\udaf8\udcb1\uda77\udd6c\ud91a\udd54");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u213f\u71ce\u9bd2\udbab\ude95\ud885\udc7c\udba6\udfe4\ud940\udf9a\udb20\udc68\ud971\ude85\udaf8\udcb1\uda77\udd6c\ud91a\udd54");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllLowerCase("\u217a\u00e2\u00df\000\u4d4a\udbd8\udf2e\ud910\udd4d\ud876\udf87\ud8f1\udcd3\udafc\udca0\000\udae2\uddb1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphanumeric("\u2c3c\u71ce\u9bd2\udbab\ude95\ud885\udc7c\udba6\udfe4\ud940\udf9a\udb20\udc68\ud971\ude85\udaf8\udcb1\uda77\udd6c\uda68\udcdb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlpha("\u213f\u71ce\u9bd2\u9599\ud873\udcb4\udba6\udfe4\ud940\udf9a\udb20\udc68\udbd7\udfd9\udaf8\udcb1\uda77\udd6c\ud91d\udd55");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAlphaSpace("\u213f\ud5ce\u9bd2\u9599\ud873\udcb4\udba6\udfe4\ud940\udf9a\udb20\udc96\udbd7\udfd9\udaf8\udcb1\uda77\udd6c\ud91d\udd55");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.StringUtils.isAllUpperCase("\u0416\u1f3f\udb4e\udcdb\uda79\udf40\udb10\udec3\ud8e4\udd3e\uda09\udc2f\udaab\udf46\udb73\udc3b\ud956\uddf8\u5175\udb0b\udea9\udace\udd82\ud883\udcd9\ud94a\udd76\ud82d\udf03\ud9f0\udd4e\udb45\udea3\ud989\udd7b\uda37\udf4e\udbf5\udc0b\ud90a\udfdc\uda0a\ude11\ud82c\udd75\uda34\udc55\udb5c\uddaf\ud970\ude48\uda62\udda1\uabe5\u082a\ud9ee\uddcd\udafb\udc5f\udac1\udd42\ud8fd\udfd6\uda22\udf43\udb4d\udf00\uda1f\udc5b\udad7\ude49\u6928\ud985\udd16\uda1b\uddc4\udaba\ude08\uda15\udd03\u2485\udb70\udd49\udacf\udfb8\ud95f\udc13");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
