package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class LocaleUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\udb83\udf1b\udb75\udcd8"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\ud872\udeba\ud8c2\udd9f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\uda52\udf18\udbd4\udc11\ud9fb\ude6e\ud93f\udc5d\ud869\udc3e\udaec\udc70"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\u62de\ud83d\udd68"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\ud980\uddd4\ud8f4\ude64\udb54\udce3\udba3\udd33\udb41\udf53\uda95\udc4b\udb39\udcfe\ud86e\udef8\udaef\udcb8\ud82b\udecd\ud88f\ude9a\udada\udd33\udadd\udda0\udaa1\udec9"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\udb83\udf1b\ud83b\udc7b\ud9bc\ude1e\ud9cf\ude78\uda29\udc74\ud92a\udf1c\udb36\udf3d\udb2b\udc61\u0697\udb02\udeba\udb4e\udc22\uda3b\udd6c\udb12\ude96\uda81\ude33\ud8a5\ude71\udac8\ude03\udb5c\ude83\udb91\udc78\udbd7\ude04"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\uda25\udc00\ud906\udfb0\udb71\ude24\ud8e3\udcae\ud856\ude47\udac4\udd1b\ud8dd\ude67\udafc\udf1a\udbb6\ude7c\uda93\udc7d\udabb\ude7c\uda6f\udde6\udb88\udfd5\ud827\udebf\uda0c\ude9f\ud8be\ude1f\ud80b\udecc\udaf8\udc2a\u99ba\ud88b\udd82\uda31\udd44\uda7a\ude42\ud8d1\udc39\ud903\udee0\udbae\udf19\ud892\udec5\udb0d\udeb5\udb61\udfd1\udb4a\ude3a\ud911\udd09\ud9ac\ude5c\udb6f\udcc5\uda95\udc99\ud803\ude72\ud9ef\udcd0\ud949\udf60\udae7\udd40\udb93\udc6a\ud810\ude63\udae2\udee1\uda9e\udce5\ud85d\udc7a\ud994\udfa4\ud861\udc62\ud938\udd77\udb26\udd9e\ud829\uddae"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\u42e1\udbcb\udcbb\ud8cf\udfb8"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\ud81c\udc48\udb89\udf39\ud8b6\uddf3\ud871\udebe\ud86f\udea4\udbc1\udc9b\ud922\udcfc\uda7d\udcbc\udb15\ude67\udb8e\udf54\ud873\udfa4\udb43\udce2\ud804\udc3e\ud884\uddda\u69a6\ud859\udfd2\ud803\udf11\ud984\ude1a\ud9cc\udf7a\ud97f\udcae\ud88c\udd71\u8562\ud92f\udceb\u61df\ud828\ude56\udbe0\ude74\ud91a\ude26\uda5d\udd01\uda2b\udc28\udaaf\udc09\udb2b\ude7a\udbdf\udd93\ud8f4\ude12\ud897\udc4a\ud9ee\udefd\ud8c2\udf1e\uda8b\udef4\ud82b\ude5c\ud832\udf0d\ud8ac\udfae\ud8f4\uddad\ud8ed\udef1\ud9b3\udf39\ud87d\udf65\ud9e9\udfb9\ud935\udeda\ud9a1\uddde\ud955\ude47\ud974\udf9e\ud9d2\udf18\ud90f\udf1c\udad9\udecc\ud909\udc11\ud9e1\udc3f\udb33\ude93\uda59\udf0f\ud833\udd48\udbd8\ude88\ud869\udc73\udb53\udca7\ud953\udfd4\uda53\udf65\ud8ba\udce3\ud98e\udc9c\ud9f2\udcee\udbff\udd36\udbb9\udd37\ud885\udc3c\udba2\udf29\udbcc\ude4f\udaa5\udc8a\uda8f\udc32\udac8\udee9"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("i\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("i\ud8dc\udc46\ud83a\udf1d\u31e0\ud813\udfce\ud8a8\udcc9\uda92\udf4e\ud808\uddec\ud8d4\ude63"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\udb19\udd63\ud987\udcf1\ud9c3\uddaa\ud822\udc94\udb1c\udd21\ud912\udfdf\ud921\udf19\ud902\udc65\ud95b\udea7\ud99b\ude59\uda21\udf8f\udb51\uddae\udaa6\uddb2\ud868\udd37"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("ig\uda83\udf6f\uda23\ude52\udb7f\udf4e\udaab\udc33\ud92e\uddff\udbb1\udca8\uda2f\udd2d\uda77\udd7c\udad6\udc01\udb67\udc2c\udbc9\udfcf\udbb3\uded6\ud99c\uddb6\ud955\udf9b\udae6\udc5e\ud8d6\ude47\ud9d3\udd3d"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.toLocale("ic");
    assertNotNull(r);
    assertEquals("java.util.Locale", r.getClass().getName());
    assertEquals("ic", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\uccc0\u18f3\ud95a\udc18\uda2a\udeab\ud94b\udcb1\ud992\udf2c\uda8f\ude2e\udb34\ude88"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
}
