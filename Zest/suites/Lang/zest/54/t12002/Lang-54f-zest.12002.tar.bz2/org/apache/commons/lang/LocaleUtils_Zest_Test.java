package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class LocaleUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\udb44\udd5d\udb47\udc31\ud8f3\ude61\ufdae\udbce\udea7\u6b16"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\udb44\udd5d\udb47\udc31\ud85a\udfc1\ufdae\udbce\udea7\u6b16\ud873\udfda"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\uda75\udf70"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\udbcd\ude37\ud9f7\udfbc\udb42\uded3\ud984\udc59\ud84d\udf29\ud9f0\udfdf\uda7c\udd67\udaa0\udd90\uda73\udfdf\u4b16\udab2\udd6c\ud81e\ude92\udb1f\udf7c"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\u00b9\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\udbfb\udd7d\ud8af\udfa8"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\u6ef0\uda75\udc3c\ud9cf\udf92\ud9be\udf34\udbe1\udf9f\uc341\ud81c\udef3\udbbf\udc5a\ud8f7\udd3b\udbf2\udc2e\ud93d\udd7b\ud857\ude8c\ud9ca\udd6f\uda67\udef3\udbfe\ude87\ud9e4\uddef\ud84c\udc44\udab0\udeb2\udbd0\udc70\u9808\uda52\ude6f\uda6c\ude93\ud890\udf57\uda10\ude22\udad9\ude81\udb95\udffa\ud899\udeb0\ud9d1\udf07\ud93a\ude9f\ud861\ude2f\ud8f5\ude74\ud9d5\ude13\ud805\ude8e\ud9b1\udcc5\ud8a0\udde0\uda76\udfa0\ud807\udf25\udab2\ude9f\ud8b0\uddfa\ud9a9\udeba"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\000\000\000\ufd81\udb03\udca5\u6b16"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\ud9d1\ude1d\udb94\udfc9\ud8c6\ude79\uea21\udbce\udea7\ud97a\ude24\ud990\udfa0\ud8e6\udd7e\ud814\udee4\ud96f\udf8b\uda4b\udf72\udb40\udebc\udb73\uddcb\udb9f\udeb4\ud82b\udcd7\udb44\udee0\ud9b4\udfb2"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\u4d97\ud9af\udf2a\ud9b2\ude84"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\ud972\udc3c\udbc2\udcc8\uda4f\udc61\ud9c1\udd91\ud967\udf98\udbc1\udd7d\ud8a4\udc02\udbd1\udc90\ud8c0\udd9f\udbdf\udd98\udb0b\udfdb\ud950\udd0a\ud908\ude61\ud923\udc80\udb1c\udf68\ud8d5\udee3\udb75\udca2\udb01\udc4b\udba0\ude1d\udb65\udede\ud9b7\udc32\ud863\udd00\udab8\udcf4\uda10\udfb3\uda1e\udf1c\udab9\udf7d\udbc4\udc8c\ud98c\udc26\udbb3\ude12\udaee\udcc4\uda99\udf08\ud849\ude5b\ud9ff\udfde\udbe6\uddde\udbcf\udf2c\udbf6\udf4b\udb34\udda0\udadd\udd21\udbdb\udca9\udaec\udda3\ud9d8\udc10\uda90\ude61\ud83d\udec6\ud9d3\udfbb\uda33\udee8\ud87e\udf59\u9e37\uda6a\udc7f\ud937\uddb4\uda05\udf80\ud847\udf77\ud927\udfe8\ud926\uddfa\udb23\udc6a\ud89f\udd53\ud975\udc0d\uda0c\ude26\ud9b3\udf8e\ud842\udf1e\ud900\ude0c\ud842\udf4a\udaee\udcd4\udb0f\udfc7\ud872\udfa2"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\udb71\udf8d\ud89b\udee8\uda7e\udd61\ud8ec\udc0d\ud989\udece\u36aa\udab3\udc70\ud93d\udc85\u58d8\ud819\udf2b\uda4a\udf6d\ud8eb\udd2b\uda7a\udf60\ud8af\uded3\ud865\udeb4\uc3c3\uae7a\ud836\udd22\uda75\udf68\udb6e\udf4b\udb3f\udfda\ud965\udd64\ud89b\udce6\ud5c7\ud845\udfd5\uda43\udccb\ud866\ude12\udbde\ude7b\ud8eb\udd06\ud968\udf18\ud861\udc2f\udb5d\udcf0\ud9f8\udd29\ud808\udf86\ud831\udd0d\udb4d\udd84\udad9\udd87\ud98e\udcc3\udbf7\udeb1\ud940\ude63\udaa9\udf07\uda1d\uddd5\ud978\uddf3\ud925\udcc8\ud83c\udfb7\ud94d\udd32\udbd0\udffa\ud90f\uddc2\ud9f6\uddd1\ud953\udcb2\ud8d3\udfdc\udaa7\udf94\uda60\udee4\uda44\udc4a\ud8dc\ude47\ud8d2\udf5f\ud8f4\udee5\udb7d\udd80\uda4a\udfb7\udbd7\ude7a\u862c\ud8e9\ude5f\udb26\udd64\uda66\ude82\ud87b\uddc3\uda3c\udcaa\uda4d\ude73\ud98b\udf8a\ud93c\uddaa\udb24\udfc2\ud8f4\udf6e\udaf2\ude36\udb60\udd73\udb1f\udd2a\ud937\udffd\udb3d\ude0a\ud980\udf40\ud908\udcea\ud858\udd92"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("s\000\000\ufdcf\udb03\udca5\ud863\udfc0"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("s\ud8f3\udc77\000\u8c39\ud9af\udd95\ud946\ude99\udb55\uddbf\ud982\udec7\ud8ce\udee1"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("sn\uda9e\udd4b\udbbd\udcd3\ud8aa\udda6\ud863\udfc0"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.LocaleUtils.toLocale("sn");
    assertNotNull(r);
    assertEquals("java.util.Locale", r.getClass().getName());
    assertEquals("sn", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang.LocaleUtils.toLocale("\uda6c\udf6b\udb75\udd13"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
}
