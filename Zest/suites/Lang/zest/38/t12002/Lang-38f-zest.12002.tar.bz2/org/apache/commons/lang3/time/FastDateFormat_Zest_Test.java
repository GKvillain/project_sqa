package org.apache.commons.lang3.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastDateFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb77\udd6f\ud891\udffe");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb77\udd6f\ud891\udffe]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda18\udea8\udafc\udc3d\ud870\udf33\uda2b\udeb4\ud905\uddfe\udb92\udd03\udbf0\udec7");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda18\udea8\udafc\udc3d\ud870\udf33\uda2b\udeb4\ud905\uddfe\udb92\udd03\udbf0\udec7]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb77\udd6f\ud87a\udf0a\ud89e\udc09\udbe9\ude93\ub03f\ud929\udc64\udbe0\udf34\ud130\ud8fc\udef5\ud876\udfb7\ud821\udf40\ud8f2\ude03\udb12\udf5c\ud88f\udee4\udba9\udc23\uda62\udf03\ud936\udc68\udbc1\udd5a\udabf\udfa8\ud9fd\udd99\ud8f9\udeec\ud9a7\udd8f\uda93\udea4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb77\udd6f\ud87a\udf0a\ud89e\udc09\udbe9\ude93\ub03f\ud929\udc64\udbe0\udf34\ud130\ud8fc\udef5\ud876\udfb7\ud821\udf40\ud8f2\ude03\udb12\udf5c\ud88f\udee4\udba9\udc23\uda62\udf03\ud936\udc68\udbc1\udd5a\udabf\udfa8\ud9fd\udd99\ud8f9\udeec\ud9a7\udd8f\uda93\udea4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb77\udd6f\u6864");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb77\udd6f\u6864]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb77\udd6f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb77\udd6f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud862\udf89\ufa63\uda3a\udca5\udb1a\ude85\ud8ac\udfae\ud8fa\udd10\ud823\udcad\uda35\udd8e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud862\udf89\ufa63\uda3a\udca5\udb1a\ude85\ud8ac\udfae\ud8fa\udd10\ud823\udcad\uda35\udd8e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb9f\udef4\uda18\udd42\udad2\udc55\udb50\udeb1\udb50\udc16\ud970\udd63\ud989\udd67\uda1c\udc08\udbc6\udf15\udbb2\udf71\udb52\udde7\udadf\udf8e\ud95d\udf1f\ud940\ude17\ud9bd\udc89\ud9cb\udc95\ud84d\udd8b\ud83c\udc95\udbdd\ude0c\udbc6\udfa5\ud86d\udcf9\uda21\udd8b\uda81\udd08\udb07\udcbe\ud8cb\udeac\ud8e6\udce6\ud9cc\udc68\udb6d\udd8e\udb2c\udd58\udb46\uddad\udbdd\udd38\ud976\udd4d\ud85c\udeb5\u8f31\ud852\udc12\uda88\udc15\udab9\udcd2\ud9c5\uddbe\ud836\udee4\ud9af\udd78\udb3c\udf85");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb9f\udef4\uda18\udd42\udad2\udc55\udb50\udeb1\udb50\udc16\ud970\udd63\ud989\udd67\uda1c\udc08\udbc6\udf15\udbb2\udf71\udb52\udde7\udadf\udf8e\ud95d\udf1f\ud940\ude17\ud9bd\udc89\ud9cb\udc95\ud84d\udd8b\ud83c\udc95\udbdd\ude0c\udbc6\udfa5\ud86d\udcf9\uda21\udd8b\uda81\udd08\udb07\udcbe\ud8cb\udeac\ud8e6\udce6\ud9cc\udc68\udb6d\udd8e\udb2c\udd58\udb46\uddad\udbdd\udd38\ud976\udd4d\ud85c\udeb5\u8f31\ud852\udc12\uda88\udc15\udab9\udcd2\ud9c5\uddbe\ud836\udee4\ud9af\udd78\udb3c\udf85]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb83\udd4b\ud8d7\udd45\ud997\udfad\ud9f2\udfc9\ud81e\uddde\ud89a\udcc6\udbec\ude96\ud856\ude9b\udb80\udec7\udb18\udd57");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb83\udd4b\ud8d7\udd45\ud997\udfad\ud9f2\udfc9\ud81e\uddde\ud89a\udcc6\udbec\ude96\ud856\ude9b\udb80\udec7\udb18\udd57]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ub085");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ub085]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9b4\udd6e\ud80a\udc7c\udaf4\udd31\ud964\ude84\uda7b\udf2c\ud8c9\udc7e\uda45\udfb9\uda9c\udd8d\udb9b\udc33\udae2\udda4\ud95e\ude99\ud894\uded7\uda66\udf2c\udaf6\udfd1\ud86a\udeac\uda57\ude78\udb58\udda4\udbb4\udfaa\udb5e\udcdd\ud91d\ude5e\ud8cf\udf04\udabc\udf77\udb9c\udea5\ud8e2\udf09\uda0e\udf76\ud87a\udc7b\udbe3\udd92\uda33\udefe\udb7a\udfde\ud950\uddbf\ud8ee\udd80\ud857\ude1a\ud9d3\ude20\uda50\udc1a\ud8b3\udc93\uda3b\uddfb\ud9cd\udf1d\ud906\udc67\udbf8\udcb4\uda56\udc65\u73e9\ud9b2\udf1b\ud9bc\ude7e\ud9a5\udf6a\uda57\udf63\ud9ad\ude33\udb5d\udf17\u8a86\ud996\udfb4\udb38\udf82\uda84\udda2\uda75\ude50\ue4cd\ud9cf\udc90\udb2e\udddc\ud861\ude22\uda51\udc5b\ua13e\ud8b7\udd40\uca79\uda27\udf70\ud8e6\udd2d\ud893\udcaa\ud9d4\ude01\udb64\ude50\ud8a2\udf54\udb62\udd7b\u02f1\udb43\udd3a\uda5e\uddf5\udb22\udf20\ud855\udfaa\udb9a\ude2c\u14b0\udb0d\udcbb\uda3f\udf59\udb65\udd98\ud94a\udc0f\udb60\udd89\udaa5\udfe8\ud81b\udf78\udbe6\udcd4\ud83f\udee8\ud810\uddec\udad2\udf90\udb54\udc4c\uda96\udd17\udac4\udef9\udafc\udd52\udb70\udd4a\udb88\udf52");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9b4\udd6e\ud80a\udc7c\udaf4\udd31\ud964\ude84\uda7b\udf2c\ud8c9\udc7e\uda45\udfb9\uda9c\udd8d\udb9b\udc33\udae2\udda4\ud95e\ude99\ud894\uded7\uda66\udf2c\udaf6\udfd1\ud86a\udeac\uda57\ude78\udb58\udda4\udbb4\udfaa\udb5e\udcdd\ud91d\ude5e\ud8cf\udf04\udabc\udf77\udb9c\udea5\ud8e2\udf09\uda0e\udf76\ud87a\udc7b\udbe3\udd92\uda33\udefe\udb7a\udfde\ud950\uddbf\ud8ee\udd80\ud857\ude1a\ud9d3\ude20\uda50\udc1a\ud8b3\udc93\uda3b\uddfb\ud9cd\udf1d\ud906\udc67\udbf8\udcb4\uda56\udc65\u73e9\ud9b2\udf1b\ud9bc\ude7e\ud9a5\udf6a\uda57\udf63\ud9ad\ude33\udb5d\udf17\u8a86\ud996\udfb4\udb38\udf82\uda84\udda2\uda75\ude50\ue4cd\ud9cf\udc90\udb2e\udddc\ud861\ude22\uda51\udc5b\ua13e\ud8b7\udd40\uca79\uda27\udf70\ud8e6\udd2d\ud893\udcaa\ud9d4\ude01\udb64\ude50\ud8a2\udf54\udb62\udd7b\u02f1\udb43\udd3a\uda5e\uddf5\udb22\udf20\ud855\udfaa\udb9a\ude2c\u14b0\udb0d\udcbb\uda3f\udf59\udb65\udd98\ud94a\udc0f\udb60\udd89\udaa5\udfe8\ud81b\udf78\udbe6\udcd4\ud83f\udee8\ud810\uddec\udad2\udf90\udb54\udc4c\uda96\udd17\udac4\udef9\udafc\udd52\udb70\udd4a\udb88\udf52]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("u"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda18\udea8\ud9ab\udd95\ud870\udf33\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda18\udea8\ud9ab\udd95\ud870\udf33\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("u\ud865\udd71"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udbdf\uddef\000\udad2\udc55\023\000\ud970\udd63\ud989\udd67\uda1c\udc08\udbc6\ude5c\000\udb13\udde7\udadf\udf8e\ud95d\udf1f\ud940\ude17\ud9bd\udc89\ud9cb\udc95\ud84d\udd8b\ud81e\uddae\udbb3\udc0c\udbc6\udfa5\ud86d\udcf9\uda21\udd8b\uda81\udd08\udb07\udcbe\u68b5\ud8b3\udf795\udb6d\udd8e\udb2c\udd58\udbaa\ude40\000\ud976\udd4d\ud85c\udeb5\u8f31\000\ud92c\udf76\udab9\udcd2\u9caf\000\ud9af\udd78\udb3c\udf85");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbdf\uddef\000\udad2\udc55\023\000\ud970\udd63\ud989\udd67\uda1c\udc08\udbc6\ude5c\000\udb13\udde7\udadf\udf8e\ud95d\udf1f\ud940\ude17\ud9bd\udc89\ud9cb\udc95\ud84d\udd8b\ud81e\uddae\udbb3\udc0c\udbc6\udfa5\ud86d\udcf9\uda21\udd8b\uda81\udd08\udb07\udcbe\u68b5\ud8b3\udf795\udb6d\udd8e\udb2c\udd58\udbaa\ude40\000\ud976\udd4d\ud85c\udeb5\u8f31\000\ud92c\udf76\udab9\udcd2\u9caf\000\ud9af\udd78\udb3c\udf85]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("W\ud858\ude50\ud960\ude77\udae3\udfce\uda5f\udc7f\udb67\udf69\uda3a\uded6\udb53\udebf\udaba\udfb4\udb6b\ude38\ud982\ude6c\uda7f\ude88\udb24\ude30\ud944\udc11\uda41\uddaa\ud9a9\udc04\ud999\uddda");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[W\ud858\ude50\ud960\ude77\udae3\udfce\uda5f\udc7f\udb67\udf69\uda3a\uded6\udb53\udebf\udaba\udfb4\udb6b\ude38\ud982\ude6c\uda7f\ude88\udb24\ude30\ud944\udc11\uda41\uddaa\ud9a9\udc04\ud999\uddda]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("B\udbb3\udfaa\uda6e\udc3f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb71\udeb7x"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("D\udb1e\udeaf\u58e9\udac7\udc69\ud964\ude60\udb8f\udeaf\udbfb\uddee\uda0e\uddd8\udae8\uddbf\udad5\ude2d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[D\udb1e\udeaf\u58e9\udac7\udc69\ud964\ude60\udb8f\udeaf\udbfb\uddee\uda0e\uddd8\udae8\uddbf\udad5\ude2d]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("L\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("h\ud950\ude57\udb12\ude8d\uda79\udeee\uda85\udd85\ud9c9\ude46\u606c\udb98\udeaa\udb51\uddfd\uda08\udea1\udbb5\ude70\ud8bc\udc01\udb28\ude01\ud9aa\ude8a\ud989\udffb\ud90f\udfe1\udafe\uddbf");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[h\ud950\ude57\udb12\ude8d\uda79\udeee\uda85\udd85\ud9c9\ude46\u606c\udb98\udeaa\udb51\uddfd\uda08\udea1\udbb5\ude70\ud8bc\udc01\udb28\ude01\ud9aa\ude8a\ud989\udffb\ud90f\udfe1\udafe\uddbf]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda18\udea8\ud9ab\udd95\ud87d\udff9\udb29\udf63\ud82b\ude5a\ud9ac\uddafK");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda18\udea8\ud9ab\udd95\ud87d\udff9\udb29\udf63\ud82b\ude5a\ud9ac\uddafK]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda18\udea8\uda48\udc29\ud8bb\udcad\ud9c8\uddd8y\uf45e\025");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda18\udea8\uda48\udc29\ud8bb\udcad\ud9c8\uddd8y\uf45e\025]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("W\ud858\ude50\ud960\ude77\udaab\uddce\uda5f\udc7f\udb67\udf69\uda3a\uded6\udb53\udebf\udaba\udfb4\udb6b\ude38\ud982\ude6c\uda7f\ude88d\000\uda1f\udd0e\ud9a9\udc04\ud999\uddda");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[W\ud858\ude50\ud960\ude77\udaab\uddce\uda5f\udc7f\udb67\udf69\uda3a\uded6\udb53\udebf\udaba\udfb4\udb6b\ude38\ud982\ude6c\uda7f\ude88d\000\uda1f\udd0e\ud9a9\udc04\ud999\uddda]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("N\ud826\uddb8"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("'\ud97c\udd22\ud957\uddf8\udae3\udfce\uda5f\udc7f\udb67\udf69\ud8e5\udf0d\udb3c\udf1e\udaba\udfb5\udb61\udc52\ud982\ude6c\uda7f\ude88\udaec\udfca\ud944\udc81\ud9be\udd32\ud9a9\udc04\uda84\udedf\ud9da\ude5f\u0e01\ud970\udd36\uda34\udf5f\ud829\ude7e\ud906\ude1b\udaab\udea7\udbd5\udf69\ud8fb\udcb5\udbb2\uddfc\udb39\udf4e\udb6e\uddbd\ud8e1\udc80\ud9fd\udc34\uda0b\udec9");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat['\ud97c\udd22\ud957\uddf8\udae3\udfce\uda5f\udc7f\udb67\udf69\ud8e5\udf0d\udb3c\udf1e\udaba\udfb5\udb61\udc52\ud982\ude6c\uda7f\ude88\udaec\udfca\ud944\udc81\ud9be\udd32\ud9a9\udc04\uda84\udedf\ud9da\ude5f\u0e01\ud970\udd36\uda34\udf5f\ud829\ude7e\ud906\ude1b\udaab\udea7\udbd5\udf69\ud8fb\udcb5\udbb2\uddfc\udb39\udf4e\udb6e\uddbd\ud8e1\udc80\ud9fd\udc34\uda0b\udec9]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("Z\udbd0\udf99\uda96\uded5\udbb2\ude01\uda76\udf5e\ud890\udd89\udafc\uddef\udbef\udd96\udbfe\udfd9\ud923\ude7d\udb5a\udd28\ud95c\udc24\uda96\ude96\udb8e\uddc7");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[Z\udbd0\udf99\uda96\uded5\udbb2\ude01\uda76\udf5e\ud890\udd89\udafc\uddef\udbef\udd96\udbfe\udfd9\ud923\ude7d\udb5a\udd28\ud95c\udc24\uda96\ude96\udb8e\uddc7]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("R\udbb3\udfaa\uda6e\udc3f\ud940\uddf8"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda6c\udd07M");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda6c\udd07M]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda4a\udca5k");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda4a\udca5k]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("D\udb1e\udeaf\u0ee1s\ud964\ude60\udb24\uddda\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[D\udb1e\udeaf\u0ee1s\ud964\ude60\udb24\uddda\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("O\udb1e\udeaf\u58e9\udac7\udc69\ud964\ude60\udb8f\udeaf\udbfb\uddee\uda0e\uddd8\udae8\uddbf\udad5\ude2d"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("Q\udb1e\udeaf\u58e9\udac7\udc69\ud964\ude60\udb8f\udeaf\udbfb\uddee\ud822\udec1\udb72\ude98\uda01\ude30\uda1e\udde4\udb74\ude32\udb43\ude91\udaf8\udd65\udba8\udd67\uda8e\udeef\uda5f\udf54\uda67\udfb0"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u4b66C"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("h\ud950\ude57\udb4a\udc08\u5900\uda85\udc8c\ud9c9\ude46\u606c\udb98\udeaa\udb51\uddfd\uda08\udea1w\ud84d\udee5\udb28\ude01\ud9aa\ude8a\ud989\udffb\ud90f\udfe1\udafe\uddbf");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[h\ud950\ude57\udb4a\udc08\u5900\uda85\udc8c\ud9c9\ude46\u606c\udb98\udeaa\udb51\uddfd\uda08\udea1w\ud84d\udee5\udb28\ude01\ud9aa\ude8a\ud989\udffb\ud90f\udfe1\udafe\uddbf]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("A\udb30\udd47\udb12\uddca\uda79\udeee\ud863\udf60\ud9c9\udee7\ud92b\udc36\udb9c\udfe3\udb51\uddfd\uda08\udea1\udbb5\ude70\ud8bc\udc01\udb28\ude01\ud9aa\ude8a\ud989\udffb\udab5\udea5\ud954\ude38"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("h\000\000\u6101\u00f9\ud9c9\ude23\u606c\udb98\udeaa\ud8b2\udcce\uda08\udea1w\000\000\ud9aa\udda6\u009a\udba5\ude0c\ubbb8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[h\000\000\u6101\u00f9\ud9c9\ude23\u606c\udb98\udeaa\ud8b2\udcce\uda08\udea1w\000\000\ud9aa\udda6\u009a\udba5\ude0c\ubbb8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda18\udea8\udb6a\ude04\udb11\uddb4\udb5a\udf65\udb93\ude29\u7fe2E");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda18\udea8\udb6a\ude04\udb11\uddb4\udb5a\udf65\udb93\ude29\u7fe2E]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda18\udea8\udb23\udcaf\ud855\udceb\uda8f\udc8a\udb9d\udda3\ud9ac\uddafG");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda18\udea8\udb23\udcaf\ud855\udceb\uda8f\udc8a\udb9d\udda3\ud9ac\uddafG]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda18\udf7d\uda48\udc29\ud8bb\udcad\ud9c8\uddd8y\uf45eF");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda18\udf7d\uda48\udc29\ud8bb\udcad\ud9c8\uddd8y\uf45eF]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("W\ud858\ude50\ud960\ude77\000\000\000\000\udb45\uddc1\udaba\udfb4\udb6b\ude38\ud982\ude6c\ud800\udfe9d\000\uda1f\udd0eE\ud999\uddda");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[W\ud858\ude50\ud960\ude77\000\000\000\000\udb45\uddc1\udaba\udfb4\udb6b\ude38\ud982\ude6c\ud800\udfe9d\000\uda1f\udd0eE\ud999\uddda]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda1d\uddd1\ud86c\udfba\ud960\ude77\udaab\uddce\uda5f\udc7f\udb67\udf69\uda3a\uded6\udb7c\udfd4\udaba\udfb4\udb6b\ude38\ud982\ude6c\udb72\ude91\udb61\udce3z\uda1f\udd0e\ud9a9\udc04\ud999\uddda");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda1d\uddd1\ud86c\udfba\ud960\ude77\udaab\uddce\uda5f\udc7f\udb67\udf69\uda3a\uded6\udb7c\udfd4\udaba\udfb4\udb6b\ude38\ud982\ude6c\udb72\ude91\udb61\udce3z\uda1f\udd0e\ud9a9\udc04\ud999\uddda]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("H\ud858\ude50\ud960\ude77\udaab\uddce\udb90\udeb7\ud9bf\udcac\uda3a\udf0f\uda80\udf36\udaba\udee1\udb6b\ude38\ud982\ude6c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[H\ud858\ude50\ud960\ude77\udaab\uddce\udb90\udeb7\ud9bf\udcac\uda3a\udf0f\uda80\udf36\udaba\udee1\udb6b\ude38\ud982\ude6c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("W\ud858\ude50\ud960\ude77\udaab\uddce\uda5f\udc7f\udb67\udf69\uda3a\uded6\udb53\udebf\u5802\000\ud97c\udedd\uda7f\ude88d\000\uda1f\udd0e\ud9a9\udc04u"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\udaab\udd55\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\udaab\udd55\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("W\ud821\udd50\ud960\ude77y\uda5f\udc7fy\000\udb53\uddc1\u0ff9\000\ud982\udddd\uda40\udf88d\000\uda1f\udd0e\ud9a9\udc04\uda5b\ude7c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[W\ud821\udd50\ud960\ude77y\uda5f\udc7fy\000\udb53\uddc1\u0ff9\000\ud982\udddd\uda40\udf88d\000\uda1f\udd0e\ud9a9\udc04\uda5b\ude7c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("W\udbc7\ude88\ud960\ude77\ud94f\udec9\uda55\ude20\ud911\udf84\udbb5\udd72\ud8ed\udf86\udaba\udfb4\ud875\udd3c\ud97d\udcd0\ud9e4\udf18J\udb26\udff2\uda2f\udcbc\ud9a9\udc04\ud999\uddda\udbac\udc59\ud9bf\udfcc\ud8f1\udd89\ud81a\udeae\uda40\udf9b"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("'\ud97c\udd22\ud957\uddf8\udae3\udfce\uda5f\udc7f\udb67\udf69\ud8e5\udf0d\udb3c\udf1e\udaba\udfb5\udb61\udc52\ud982\ude6c\uda7f\ude88\udaec\udfca\ud944\udc81\ud9be\udd32");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat['\ud97c\udd22\ud957\uddf8\udae3\udfce\uda5f\udc7f\udb67\udf69\ud8e5\udf0d\udb3c\udf1e\udaba\udfb5\udb61\udc52\ud982\ude6c\uda7f\ude88\udaec\udfca\ud944\udc81\ud9be\udd32]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("'\ud97c\udd22\ud957\uddf8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat['\ud97c\udd22\ud957\uddf8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("'\ud97c\udd22\ud957\uddf8\udae3\udfce\uda34\udd07\udb63\ude69\ud8e5\udf5e\udb3c\udf1e\udaba\udfb5\udb61\udc52\u126e\uda7f\ude88\udaec\udfca\ud944\udcbb\ud9be\udd32\ud9a9\udc04\uda84\udedf\udab3\uddcc\u0e01\ud81a\udc41\uda34\udf5f\ud829\ude7e\ud906\ude1b\udae0\udea7\udbd5\udf69\ud957\udda4\udb4e\udeb6\udb39\udf4e\udb6e\uddbd\ud8e1\udc80\ud9fd\udc34\uda0b\udec9\udbeb\udf8f\ud979\udf55\ud9b3\udc80\udb7e\udc33\ud956\udf65\ud913\udd73\udb72\udec8\uda13\udef5\ud820\udeb4\udac0\udf12\udb6c\uddfa\ud9ea\udefe\u3a73\ud8fd\ude60\ud99c\udde3\ud840\udf96\u6cc6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat['\ud97c\udd22\ud957\uddf8\udae3\udfce\uda34\udd07\udb63\ude69\ud8e5\udf5e\udb3c\udf1e\udaba\udfb5\udb61\udc52\u126e\uda7f\ude88\udaec\udfca\ud944\udcbb\ud9be\udd32\ud9a9\udc04\uda84\udedf\udab3\uddcc\u0e01\ud81a\udc41\uda34\udf5f\ud829\ude7e\ud906\ude1b\udae0\udea7\udbd5\udf69\ud957\udda4\udb4e\udeb6\udb39\udf4e\udb6e\uddbd\ud8e1\udc80\ud9fd\udc34\uda0b\udec9\udbeb\udf8f\ud979\udf55\ud9b3\udc80\udb7e\udc33\ud956\udf65\ud913\udd73\udb72\udec8\uda13\udef5\ud820\udeb4\udac0\udf12\udb6c\uddfa\ud9ea\udefe\u3a73\ud8fd\ude60\ud99c\udde3\ud840\udf96\u6cc6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("'");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[']", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("'\ud97c\udd22");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat['\ud97c\udd22]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("'\ud97c\udd22\ud957\uddf8\udae3\udfce\uda5f\udc7f\udb67\udf69");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat['\ud97c\udd22\ud957\uddf8\udae3\udfce\uda5f\udc7f\udb67\udf69]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("m\ud92b\udd3c\udbc4\ude0c\udbb2\ude01\uda76\udf5e\ud970\uddd8\udb53\udf0f\udb16\udd9d\udbe8\udd79\ud983\udf0e\udb52\ude19\ud980\udf1b\ud878\ude98\uda09\udcc5");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[m\ud92b\udd3c\udbc4\ude0c\udbb2\ude01\uda76\udf5e\ud970\uddd8\udb53\udf0f\udb16\udd9d\udbe8\udd79\ud983\udf0e\udb52\ude19\ud980\udf1b\ud878\ude98\uda09\udcc5]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb38\udc28S\ud88e\udc91\udb2e\udfea\ud8c4\udd5d\ud914\uddf8\ud9ee\ude29\ud810\ude8a\ud95b\udf0d\ud9c8\udc9c\ud9d8\udf5d\ud923\ude0a\ud922\udd17\udba1\udede\udbf2\ude93\ud89e\uddfa\ud93a\udf38\ud9e4\ude68\ud834\udc1c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb38\udc28S\ud88e\udc91\udb2e\udfea\ud8c4\udd5d\ud914\uddf8\ud9ee\ude29\ud810\ude8a\ud95b\udf0d\ud9c8\udc9c\ud9d8\udf5d\ud923\ude0a\ud922\udd17\udba1\udede\udbf2\ude93\ud89e\uddfa\ud93a\udf38\ud9e4\ude68\ud834\udc1c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("D\udb1e\udeaf\u0ee1I\ud964\ude60\udb24\uddda\000\000\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("D\udbd6\ude4b\udabf\udea4\u0a3d\ud964\ude60\udb24\uddda\ud9f9\udefba\000\uda09\udda4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[D\udbd6\ude4b\udabf\udea4\u0a3d\ud964\ude60\udb24\uddda\ud9f9\udefba\000\uda09\udda4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("'\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat['\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb38\udc28S\ud88e\udc91\udb2e\udfea\ud8c4\udd5d\ud914\uddf8\ud9ee\ude29\ud810\ude8a\ud95b\udf0d\ud9c8\udc9c\ud9d8\udf5d\ud923\ude0a\ud922\udd17\udba1\udede\udbf2\ude93\ud89e\uddfa\ud93a\udf38W\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb38\udc28S\ud88e\udc91\udb2e\udfea\ud8c4\udd5d\ud914\uddf8\ud9ee\ude29\ud810\ude8a\ud95b\udf0d\ud9c8\udc9c\ud9d8\udf5d\ud923\ude0a\ud922\udd17\udba1\udede\udbf2\ude93\ud89e\uddfa\ud93a\udf38W\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\udabf\udea4\u0a3d\ud964\ude60\udb24\udd03\ud8ab\udef4a\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\udabf\udea4\u0a3d\ud964\ude60\udb24\udd03\ud8ab\udef4a\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb9d\ude68\ud891\udffe\ud8e7\udf6c\ud824\udf3e\ud978\udd8d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb9d\ude68\ud891\udffe\ud8e7\udf6c\ud824\udf3e\ud978\udd8d]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("P\ud844\udcbf\udb3d\udc73\ud820\ude82\ud985\udeb1\ud8d8\udf04\ud9d7\udcb8\ud935\udef8"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("LL"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udab0\udcff\uda48\udc29\ud8bb\udcad\ud9c8\uddd8y\uf45eF\ue7c7");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udab0\udcff\uda48\udc29\ud8bb\udcad\ud9c8\uddd8y\uf45eF\ue7c7]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("G\uda3a\udde2\udabf\udef1\u0a3d\ud964\ude60\udb24\uddda\ud9f9\udefba\000\uda09\udda4\uda14\udc2f\ud86d\udf49\uda5f\udc6e\udb4b\uded8\uda30\ude78\uda9c\ude30");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[G\uda3a\udde2\udabf\udef1\u0a3d\ud964\ude60\udb24\uddda\ud9f9\udefba\000\uda09\udda4\uda14\udc2f\ud86d\udf49\uda5f\udc6e\udb4b\uded8\uda30\ude78\uda9c\ude30]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("W\ud821\udd50\ud80a\udefay\uda5f\udc7fy\uda96\udf96\udb53\uddc7\ud922\ude67\000\udaf1\udc14\uda25\udd97d\ud994\udfc7\uda22\uddff\udb84\ude38\ud94b\udcd1");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[W\ud821\udd50\ud80a\udefay\uda5f\udc7fy\uda96\udf96\udb53\uddc7\ud922\ude67\000\udaf1\udc14\uda25\udd97d\ud994\udfc7\uda22\uddff\udb84\ude38\ud94b\udcd1]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("D\udb1e\udeaf\ud989\udcef\ud92c\ude4e\ud960\udf7c\udb37\udc8a\000D\000\ud9ff\udcde");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[D\udb1e\udeaf\ud989\udcef\ud92c\ude4e\ud960\udf7c\udb37\udc8a\000D\000\ud9ff\udcde]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("h\000w\u6101\u00f9\ud9c9\udef2\udb82\udee1\udb9f\udeec\ud8b2\udce9\uda08\udea1w\000\000\ud9aa\udda6\u009a\ud899\ude42\uda28\ude4b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[h\000w\u6101\u00f9\ud9c9\udef2\udb82\udee1\udb9f\udeec\ud8b2\udce9\uda08\udea1w\000\000\ud9aa\udda6\u009a\ud899\ude42\uda28\ude4b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u428a\uda4e\ude4b\ud960\ude77\ud8c9\ude41\uda5f\udc7f\udb67\udf69\udad1\udf0a\udbde\udecc\udaba\udf33\udb6b\ude38\ud982\ude6c\uda7f\ude88dd\uda1f\udd0e\udbf0\uddcb\uda61\udc69");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u428a\uda4e\ude4b\ud960\ude77\ud8c9\ude41\uda5f\udc7f\udb67\udf69\udad1\udf0a\udbde\udecc\udaba\udf33\udb6b\ude38\ud982\ude6c\uda7f\ude88dd\uda1f\udd0e\udbf0\uddcb\uda61\udc69]", String.valueOf(r));
  }
}
