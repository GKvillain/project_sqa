package org.apache.commons.lang3.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastDateFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud826\udda8\ud9a0\ude34\ud9db\udd5a\udad4\uddb9\udaee\udff1\uda0e\ude4a\udbe2\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud826\udda8\ud9a0\ude34\ud9db\udd5a\udad4\uddb9\udaee\udff1\uda0e\ude4a\udbe2\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud826\udda8\ud860\uded0\udacb\udc51\udad4\ude03\udaee\udff1\ud90d\udc24\udbe2\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud826\udda8\ud860\uded0\udacb\udc51\udad4\ude03\udaee\udff1\ud90d\udc24\udbe2\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud826\udda8\ud9a0\ude34\ud8bb\udca9\uda47\udc1a\udaee\udff1\uda0e\ude4a\udbe2\udd8a\ud878\udf06\ud80d\udd60\udb9d\udfc5\u7527\ud890\udfda\ud93a\ude89\ud94a\ude2a\udacb\ude5e\ud9a5\udc49\uda10\udc23\udab0\udf13\ud9bc\udf32");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud826\udda8\ud9a0\ude34\ud8bb\udca9\uda47\udc1a\udaee\udff1\uda0e\ude4a\udbe2\udd8a\ud878\udf06\ud80d\udd60\udb9d\udfc5\u7527\ud890\udfda\ud93a\ude89\ud94a\ude2a\udacb\ude5e\ud9a5\udc49\uda10\udc23\udab0\udf13\ud9bc\udf32]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb20\udf5d\ud9da\udd76\ud9d7\udc38");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb20\udf5d\ud9da\udd76\ud9d7\udc38]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\udb49\udfad\ud900\ude8e\ud8ca\udecd\ud92b\udfca\u185f\ud8a9\udc97");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\udb49\udfad\ud900\ude8e\ud8ca\udecd\ud92b\udfca\u185f\ud8a9\udc97]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\000\000\000\000\000\000\000\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\000\000\000\000\000\000\000\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\000\ud972\udd58\ud9db\udd5a\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\000\ud972\udd58\ud9db\udd5a\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udbe0\udeb8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbe0\udeb8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\ud9ce\udd50\000\000\uda02\ude06\000\ud9db\udd5a\udad4\uddb9\udaee\udff1\uda0e\ude4a\udbe2\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\ud9ce\udd50\000\000\uda02\ude06\000\ud9db\udd5a\udad4\uddb9\udaee\udff1\uda0e\ude4a\udbe2\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\000\000\000q\ud972\udd58\ud9db\udd5a"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud8d4\uded6\ud927\udf3d\ud8f1\udc07\ud94d\udf74\ud9c4\udeff\udbd7\ude57\ud962\ude2b\ud96e\udd1d\udba6\ude6b\udac0\udcf3\udbe2\udd9d\ud83c\uddd4\udbb2\udda6\uda7d\udc33\ud8ba\udd55\udbe7\udf22\uda8e\ude5d\udbcc\ude25\ud968\udea0\udb22\udff3\ud8c0\udc5b\udaa3\uddfd\ud8cb\udc0c\udb7c\ude5f\u56d2\ud829\udd53\ud823\udc97\ud881\udea2\udb2c\udc9c\ud9f6\udef5\ud8e1\udd8c\ud87f\udfe7\udba7\udc7b\ud991\udd6b\ud83f\udd52\ud8b8\udffa\ud8d1\udd70\ud855\udeab");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8d4\uded6\ud927\udf3d\ud8f1\udc07\ud94d\udf74\ud9c4\udeff\udbd7\ude57\ud962\ude2b\ud96e\udd1d\udba6\ude6b\udac0\udcf3\udbe2\udd9d\ud83c\uddd4\udbb2\udda6\uda7d\udc33\ud8ba\udd55\udbe7\udf22\uda8e\ude5d\udbcc\ude25\ud968\udea0\udb22\udff3\ud8c0\udc5b\udaa3\uddfd\ud8cb\udc0c\udb7c\ude5f\u56d2\ud829\udd53\ud823\udc97\ud881\udea2\udb2c\udc9c\ud9f6\udef5\ud8e1\udd8c\ud87f\udfe7\udba7\udc7b\ud991\udd6b\ud83f\udd52\ud8b8\udffa\ud8d1\udd70\ud855\udeab]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6B\ud900\ude7d\ud8a9\udc3d\ud9ce\udc06\000\000\udbfb\udeac\ub991\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud826\udda8\ud9a0\ude34\ud9db\udd5a\udad4\uddb9\udaee\udff1\uda0e\ude4a\udbe2\udd8a\ud835\udd51\udbb3\udeb4\uda9c\ude25\uda21\ude58\uda37\udc93\ud932\udc32\ud9ab\udfe0\ud843\udf46\ud8c3\ude04\ud84f\udf4d\udb3e\udf67\ud880\ude21\ud806\udc8b\ud863\ude13\ud9bb\udf30\u3b7b\udbe6\ude36\ud876\ude98\uda71\udccf\udb67\udd13\ud99a\udf55\uda26\udc05\u5c0b\ud953\udcac\uda44\udfef\ud8ab\udd1f\ud85c\udd81\udb2b\udc26\ud9cd\udd8d\udbe7\udc45\ud83d\udecb\udb43\udf33\udb67\udc42\ud88a\udc0d\udb77\udc36\ud806\udd20\ud90c\uddf8\ud959\udea5\uda52\udd1c\udb1b\udc0b\ud980\udef1\ud976\udc64\ud98f\udd8e\ud84d\udd0e\ud96b\udd0a\udb37\uded3\ud9fb\ude02\udb62\udf89\udab1\udf69\u9cc6\ud89b\udeb0\ud8b2\ude81\ud81e\ude20\u5b5b\udaf8\uddd6\ud957\ude8f\uda92\udd9a\udb51\udff0\u3929\ud881\udc58\udad7\udefc\ud82f\udf64\u18bd\ud957\udc5e\uda2d\ude11\udb0b\udc4b\ud8a7\udffb\udacb\udfb3\ud94c\udd0a\uda9f\udd2c\ud8f9\udf50\ud9dc\udef7\ud8e7\udc08\udbe7\udd11\uda80\udf52\uda60\udd3b\ud99b\udc3b\uda17\udf8d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud826\udda8\ud9a0\ude34\ud9db\udd5a\udad4\uddb9\udaee\udff1\uda0e\ude4a\udbe2\udd8a\ud835\udd51\udbb3\udeb4\uda9c\ude25\uda21\ude58\uda37\udc93\ud932\udc32\ud9ab\udfe0\ud843\udf46\ud8c3\ude04\ud84f\udf4d\udb3e\udf67\ud880\ude21\ud806\udc8b\ud863\ude13\ud9bb\udf30\u3b7b\udbe6\ude36\ud876\ude98\uda71\udccf\udb67\udd13\ud99a\udf55\uda26\udc05\u5c0b\ud953\udcac\uda44\udfef\ud8ab\udd1f\ud85c\udd81\udb2b\udc26\ud9cd\udd8d\udbe7\udc45\ud83d\udecb\udb43\udf33\udb67\udc42\ud88a\udc0d\udb77\udc36\ud806\udd20\ud90c\uddf8\ud959\udea5\uda52\udd1c\udb1b\udc0b\ud980\udef1\ud976\udc64\ud98f\udd8e\ud84d\udd0e\ud96b\udd0a\udb37\uded3\ud9fb\ude02\udb62\udf89\udab1\udf69\u9cc6\ud89b\udeb0\ud8b2\ude81\ud81e\ude20\u5b5b\udaf8\uddd6\ud957\ude8f\uda92\udd9a\udb51\udff0\u3929\ud881\udc58\udad7\udefc\ud82f\udf64\u18bd\ud957\udc5e\uda2d\ude11\udb0b\udc4b\ud8a7\udffb\udacb\udfb3\ud94c\udd0a\uda9f\udd2c\ud8f9\udf50\ud9dc\udef7\ud8e7\udc08\udbe7\udd11\uda80\udf52\uda60\udd3b\ud99b\udc3b\uda17\udf8d]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u4942\000\ud97b\udc5cA\000\000\000\000\000\udbd9\udd6b\udb5e\ude7e"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49eb\000\uda16\ude6aw\000\ud9a5\udd11\ufe28\u5365\000\ud85d\ude0e\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49eb\000\uda16\ude6aw\000\ud9a5\udd11\ufe28\u5365\000\ud85d\ude0e\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\000\000\000S\000\000\000\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\000\000\000S\000\000\000\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000L\udbb5\udfcb\udae1\udf1d\uda83\ude35\udb12\udcd1\u00d8\000\udbd9\udd6b\udbc4\udd8a"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9d4\udcba\000\udaa4\udfb2\ud9b5\udcad\uda31\udf29\u1fb8\ud8bd\udf63a\000\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9d4\udcba\000\udaa4\udfb2\ud9b5\udcad\uda31\udf29\u1fb8\ud8bd\udf63a\000\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud859\udd71\ud909\ude9f\000\000K\ud810\udc07\000\000\000\ud8c8\udee3\udb0b\ude7d\ud8fa\udf0d\ud958\udef2\udb7f\udd72");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud859\udd71\ud909\ude9f\000\000K\ud810\udc07\000\000\000\ud8c8\udee3\udb0b\ude7d\ud8fa\udf0d\ud958\udef2\udb7f\udd72]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\000\000\000\ud93d\ude5dF\uda7f\ude1a/\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\000\000\000\ud93d\ude5dF\uda7f\ude1a/\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\ud898\udcd1y\000\000\000\000\udb02\udfc1\ud97d\uddc0\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\ud898\udcd1y\000\000\000\000\udb02\udfc1\ud97d\uddc0\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u9152\ud804\uddac\u00ebd\uf916\u3005\000N\ud9c2\udd00\u4c9f\uda6c\udf6f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\000\uda0c\udf71s\000\000\000\udafc\ude95\udbd9\udde7\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\000\uda0c\udf71s\000\000\000\udafc\ude95\udbd9\udde7\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\u7d00\000\000\000\ud8e7\udef3\u00fd\udb5a\ude0ch\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\u7d00\000\000\000\ud8e7\udef3\u00fd\udb5a\ude0ch\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\ud9d8\udd0c\ud8b5\udc97\ud8ee\uddd8'\000\000\000\udbd9\udd6b\ud838\udda4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\ud9d8\udd0c\ud8b5\udc97\ud8ee\uddd8'\000\000\000\udbd9\udd6b\ud838\udda4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\udbbe\udfdfJ\000\000\000\000\000\000\udbd9\udd6b\udbc4\udd8a"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\000\000\udac4\udc01\000\000Z\000\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\000\000\udac4\udc01\000\000Z\000\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud838\udc13\uda6e\udd63m\udb7d\udc9e\uda02\ude06\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud838\udc13\uda6e\udd63m\udb7d\udc9e\uda02\ude06\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\000\000\ud8e8\udefez\ud972\udd58\ud9db\udd5a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\000\000\ud8e8\udefez\ud972\udd58\ud9db\udd5a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u9a91\000\000\000q"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udad7\udf91k\000\ud9f0\udedf\uda03\udddf\udb63\udf51\ud973\udf5c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udad7\udf91k\000\ud9f0\udedf\uda03\udddf\udb63\udf51\ud973\udf5c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud80a\udc51\ud8ca\udd6f\ud942\udd86Qq\ud972\udd58\udb21\udddd"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("M\ud96e\udeb2\uda96\udfd7\uda1d\udd57\ud8a8\udee5\udadb\udeca\ud838\udc95\uda7b\udfa1\uda3a\udebe\ud9a7\udf90\ud9be\udeb2\udbc0\ude90");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[M\ud96e\udeb2\uda96\udfd7\uda1d\udd57\ud8a8\udee5\udadb\udeca\ud838\udc95\uda7b\udfa1\uda3a\udebe\ud9a7\udf90\ud9be\udeb2\udbc0\ude90]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9b9\udcc5W\uda30\udfb5\ud8cb\ude79\ud9a5\ude83\ud83c\udfce\000\udac8\udc92\uda06\uddd3\udbf6\udd39\udba4\udc43");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9b9\udcc5W\uda30\udfb5\ud8cb\ude79\ud9a5\ude83\ud83c\udfce\000\udac8\udc92\uda06\uddd3\udbf6\udd39\udba4\udc43]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda7b\udeaaS");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda7b\udeaaS]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda94\udc87\uda97\udc24\udabc\udeed\uaba2\ud9f9\udec4\000\ud811\ude27\uda2c\udd6b\ub991\ud856\udf0dG\udaea\uddfc\udb3f\udc86\udaaa\udc85\udb11\udf7a\ud88c\ude88\ube33\u5e15\ud94e\udd76\ud87c\ude0b\ud978\udf3e\ud848\ude4b\ud97b\udc98\ud9d0\udfaf\ud9e0\udfbb\ud9ba\udfb4\uda36\udd49\ud96b\udf9c\udbaf\udd73\udb74\ude86\ud9a7\udd55\ud95b\ude6e\ud9b9\uddcf\ud8f2\udd8b\udbb2\udec6\udb97\udef0\udabb\udd32\ud800\udcac\ud8a0\udef2\ud8f8\udfdb\udbba\ude17\ud8ad\udfc8\udbac\udcf3\u4683\ud852\ude1d\ud80e\udfb4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda94\udc87\uda97\udc24\udabc\udeed\uaba2\ud9f9\udec4\000\ud811\ude27\uda2c\udd6b\ub991\ud856\udf0dG\udaea\uddfc\udb3f\udc86\udaaa\udc85\udb11\udf7a\ud88c\ude88\ube33\u5e15\ud94e\udd76\ud87c\ude0b\ud978\udf3e\ud848\ude4b\ud97b\udc98\ud9d0\udfaf\ud9e0\udfbb\ud9ba\udfb4\uda36\udd49\ud96b\udf9c\udbaf\udd73\udb74\ude86\ud9a7\udd55\ud95b\ude6e\ud9b9\uddcf\ud8f2\udd8b\udbb2\udec6\udb97\udef0\udabb\udd32\ud800\udcac\ud8a0\udef2\ud8f8\udfdb\udbba\ude17\ud8ad\udfc8\udbac\udcf3\u4683\ud852\ude1d\ud80e\udfb4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\ud89e\udc46\ud9d9\udef5\u32bc\ud945\udef3\udb3a\udd79\ud8f2\udd01\uda8b\udc7d\ud8af\udcd1\uda87\udd82'");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\ud89e\udc46\ud9d9\udef5\u32bc\ud945\udef3\udb3a\udd79\ud8f2\udd01\uda8b\udc7d\ud8af\udcd1\uda87\udd82']", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud8fb\udf50\ud9b6\udf8a\ud900\ude7d\udb78\udea5\ud920\ude3b\ud850\udea4C\uda41\ude4f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u25e2\uda61\udfb2\udade\ude62\uda54\udc4b\ud810\udcf2'\000\udbfb\udeac\ub991\udbaf\udcb6\ud833\udf10");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u25e2\uda61\udfb2\udade\ude62\uda54\udc4b\ud810\udcf2'\000\udbfb\udeac\ub991\udbaf\udcb6\ud833\udf10]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb3d\udf9e\000I"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda71\ude7bP"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u4942\uf99d\ud9ac\uddd9\uda62\udd2aR"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49eb\000\ud96a\udd75\uda27\ude3eO\ud9a5\udd11\ufe28\u5365\000\ud85d\ude0e\uda6f\udc5c"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49eb\000\uda16\ude6aw\000\ud9a5\udd11\ufe28e\000\ud85d\ude0e\udbc4\udd8a"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ucef6\000\udb87\udcf6\000\udbc1\udf63\ud84d\ude41\u33d3\udb95\udc29H\udbd9\udd6b\ud9be\udce5");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ucef6\000\udb87\udcf6\000\udbc1\udf63\ud84d\ude41\u33d3\udb95\udc29H\udbd9\udd6b\ud9be\udce5]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud954\udea1\000\000\000\000\udb80\udff3\000\u0a28E\udaef\ude77\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud954\udea1\000\000\000\000\udb80\udff3\000\u0a28E\udaef\ude77\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\000\000\000S\ud826\udc93\udbae\udd65h\udbd9\udd6b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\000\000\000S\ud826\udc93\udbae\udd65h\udbd9\udd6b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\u1f44W\000S\000\udb40\uddc0=\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\u1f44W\000S\000\udb40\uddc0=\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\ud92c\udf76\uda3d\ude65\udb59\udd03\uda22\udd1d\ud9c7\udc7d\uda55\udeaad\ud81c\uddee\udaac\ude3e\udbc4\udda6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\ud92c\udf76\uda3d\ude65\udb59\udd03\uda22\udd1d\ud9c7\udc7d\uda55\udeaad\ud81c\uddee\udaac\ude3e\udbc4\udda6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda67\udd0b\udafe\ude7b\udb8a\udfcd\ud8dc\uddb9\udae9\udd93\ud969\udd77D\000\udabb\udf1d\udbee\udf9a\udbc4\uddba");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda67\udd0b\udafe\ude7b\udb8a\udfcd\ud8dc\uddb9\udae9\udd93\ud969\udd77D\000\udabb\udf1d\udbee\udf9a\udbc4\uddba]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\udaa4\udfb2\udb10\udc87\uda31\udf29\ud917\udf3f\uda71\udc58a\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\udaa4\udfb2\udb10\udc87\uda31\udf29\ud917\udf3f\uda71\udc58a\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u8aa8'\udaa4\udfb2\ud9b5\udcad\uda3a\udc7b\u2020\ud8c1\udf63\udb40\ude21\udbc6\ude66\ud87f\udf11\udb6d\udd84");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u8aa8'\udaa4\udfb2\ud9b5\udcad\uda3a\udc7b\u2020\ud8c1\udf63\udb40\ude21\udbc6\ude66\ud87f\udf11\udb6d\udd84]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\udaaf\udd88h\udabc\udfdd\000\ud8e7\udef3\u00fd\udb5a\ude0ch\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\udaaf\udd88h\udabc\udfdd\000\ud8e7\udef3\u00fd\udb5a\ude0ch\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud96f\udfe8\ud99a\udc15\udbe2\ude97\ud964\udebb\ud8ee\uddd8'\udb50\udd3f\ud9a1\udf5f\udbf8\udd84\udbd9\udd6b\udbfe\udca7\ud880\udd13\uda0d\udeec\udbad\uddba\u1016\ud9ec\uded4\ud851\uded1\ud9cf\uddfa\udb26\ude47\udbc0\udfc2\ud981\udf3d\ud88a\udeed\ud968\ude3b\ud862\udc27\ud944\uddab\ud97e\udcc4\ud99f\udc02\ud88c\udd72\udb09\udfba\udb92\udebd\ud90b\udd48\ud8ac\uddd1");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud96f\udfe8\ud99a\udc15\udbe2\ude97\ud964\udebb\ud8ee\uddd8'\udb50\udd3f\ud9a1\udf5f\udbf8\udd84\udbd9\udd6b\udbfe\udca7\ud880\udd13\uda0d\udeec\udbad\uddba\u1016\ud9ec\uded4\ud851\uded1\ud9cf\uddfa\udb26\ude47\udbc0\udfc2\ud981\udf3d\ud88a\udeed\ud968\ude3b\ud862\udc27\ud944\uddab\ud97e\udcc4\ud99f\udc02\ud88c\udd72\udb09\udfba\udb92\udebd\ud90b\udd48\ud8ac\uddd1]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\udbea\udd67\ud82c\udc3d\udbb1\udf75\ud8e9\udc56'\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\udbea\udd67\ud82c\udc3d\udbb1\udf75\ud8e9\udc56'\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud8ff\uddb4\000\uda63\udcae\ud836\udc16\ud8ee\udd42'\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8ff\uddb4\000\uda63\udcae\ud836\udc16\ud8ee\udd42'\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\ud9d8\udd0c\ud8b5\udc97\ud8ee\uddd8'\000\000\000\udbd9\udd6b\ud838\udda4\udbe4\udc7d\ub75e\udae3\udc64\udbe2\udd31\udb69\udc8b\ud80b\udf6d\udbed\udff9\ud930\udd44\ubbca\ud9a9\udfb9\ud869\ude9a\ud84b\udd5b\uda29\udccc\udb63\udd64\udb02\udc0d\ud91b\udd85\uda11\udd22\udb1e\udebb\udba9\udca4\udb05\uddac\ud82f\udf84\ud871\uddbf\ud9d3\uded1\ud976\udda9\udb03\udf3d\ud890\udd9e\udb15\uddd4\uda2c\ude17\u526f\udba8\ude23\ud91e\udf7e\uda12\udde3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\ud9d8\udd0c\ud8b5\udc97\ud8ee\uddd8'\000\000\000\udbd9\udd6b\ud838\udda4\udbe4\udc7d\ub75e\udae3\udc64\udbe2\udd31\udb69\udc8b\ud80b\udf6d\udbed\udff9\ud930\udd44\ubbca\ud9a9\udfb9\ud869\ude9a\ud84b\udd5b\uda29\udccc\udb63\udd64\udb02\udc0d\ud91b\udd85\uda11\udd22\udb1e\udebb\udba9\udca4\udb05\uddac\ud82f\udf84\ud871\uddbf\ud9d3\uded1\ud976\udda9\udb03\udf3d\ud890\udd9e\udb15\uddd4\uda2c\ude17\u526f\udba8\ude23\ud91e\udf7e\uda12\udde3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb11\udc72\udae3\udc63\uda09\udd55qq"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9b9\udcc5W\udba0\udc4c\udb4a\ude25\udb41\udec8\ud825\udcc0W\ud84c\udf94\uda06\udd8c\ud950\ude86\ud972\udd5b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9b9\udcc5W\udba0\udc4c\udb4a\ude25\udb41\udec8\ud825\udcc0W\ud84c\udf94\uda06\udd8c\ud950\ude86\ud972\udd5b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud994\udf02\udba3\udd6b\ud9db\udd86\udad4\uddb9\udaee\udff1\uda0e\ude4a\udbe2\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u42d6\udb49\udfad\ud900\ude8e\ud89b\udf77\ud994\udf02\udba3\udd6b\ud9db\udd86\udad4\uddb9\udaee\udff1\uda0e\ude4a\udbe2\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\ud9cb\udfa5F\000\u00c3\ud93d\ude5dF\uda7f\ude79\ud816\udc79\udbcb\udfa6\ud961\uddf8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\ud9cb\udfa5F\000\u00c3\ud93d\ude5dF\uda7f\ude79\ud816\udc79\udbcb\udfa6\ud961\uddf8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud954\udea1\000\000G\000\udb80\udff3\000\uda1a\udf1dE\udaef\ude77\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud954\udea1\000\000G\000\udb80\udff3\000\uda1a\udf1dE\udaef\ude77\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\udb7c\udff3W\000S\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\udb7c\udff3W\000S\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\000\ud937\udf45SS\000\000\000\udbd9\udd6b\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\000\ud937\udf45SS\000\000\000\udbd9\udd6b\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u00b2\000\000\000\000\000\000\uda2c\udc9b\ub991\u00c3\000\000\000\000\udba0\udcc2\ud88c\udd8e\ube33\000\000\ud83f\udc9f\ud89c\udd10\ud848\ude0a\udb10\udcc3\000\ud9e0\udf25\ud9ba\udfb4\uda36\udd49\u00b9\000\ud971\uddb7\ud9a7\udd55\000\ud9b9\uddcf\ud8c8\udcd6\uda44\udd0a\udb97\udef0\udabb\udd32\ud95c\udd09\ud8a0\ude1a\ud8f1\udeb7\ua12f\000\ud9ab\udf01\000\ud852\ude1d\ud80e\udfb4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u00b2\000\000\000\000\000\000\uda2c\udc9b\ub991\u00c3\000\000\000\000\udba0\udcc2\ud88c\udd8e\ube33\000\000\ud83f\udc9f\ud89c\udd10\ud848\ude0a\udb10\udcc3\000\ud9e0\udf25\ud9ba\udfb4\uda36\udd49\u00b9\000\ud971\uddb7\ud9a7\udd55\000\ud9b9\uddcf\ud8c8\udcd6\uda44\udd0a\udb97\udef0\udabb\udd32\ud95c\udd09\ud8a0\ude1a\ud8f1\udeb7\ua12f\000\ud9ab\udf01\000\ud852\ude1d\ud80e\udfb4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u49f6\000\000\ud937\udf45SS\000\ud840\ude1fS\udbd9\udd6b\ud873\udea0");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u49f6\000\000\ud937\udf45SS\000\ud840\ude1fS\udbd9\udd6b\ud873\udea0]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9e1\udfbcy\ud895\ude21y\000\000\000\000\udb02\udfc1\ud97d\uddc0\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9e1\udfbcy\ud895\ude21y\000\000\000\000\udb02\udfc1\ud97d\uddc0\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda94\udc87\uda97\udc24\udabc\udeed\uaba2\ud951\uddbfa\ud811\ude27\uda2c\udd6b\ub991\ud856\udf0dG\udaea\uddfc\udb3f\udc86\udaaa\udc85\udb11\udf7a\ud88c\ude88\ube33\ud90d\udfce\ud89f\uddd9\ud87c\ude0b\ud978\udf3e\ud848\ude4b\ud97b\udc98\ud9d0\udfaf\ud9e0\udfbb\ud9ba\udfb4\uda36\udd49\ud96b\udf9c\udbaf\udd73\udb74\ude86\ud9a7\udd55\ud95b\ude6e\ud9b9\uddcf\ud8f2\udd8b\udbb2\udec6\udb97\udef0\udabb\udd32\ud800\udcac\ud8a0\udef2\ud8f8\udfdb\udbba\ude17\ud8ad\udfc8\udbac\udcf3\u4683\ud852\ude1d\ud80e\udfb4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda94\udc87\uda97\udc24\udabc\udeed\uaba2\ud951\uddbfa\ud811\ude27\uda2c\udd6b\ub991\ud856\udf0dG\udaea\uddfc\udb3f\udc86\udaaa\udc85\udb11\udf7a\ud88c\ude88\ube33\ud90d\udfce\ud89f\uddd9\ud87c\ude0b\ud978\udf3e\ud848\ude4b\ud97b\udc98\ud9d0\udfaf\ud9e0\udfbb\ud9ba\udfb4\uda36\udd49\ud96b\udf9c\udbaf\udd73\udb74\ude86\ud9a7\udd55\ud95b\ude6e\ud9b9\uddcf\ud8f2\udd8b\udbb2\udec6\udb97\udef0\udabb\udd32\ud800\udcac\ud8a0\udef2\ud8f8\udfdb\udbba\ude17\ud8ad\udfc8\udbac\udcf3\u4683\ud852\ude1d\ud80e\udfb4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud859\udd71\ud820\udf15\000\000K\uda1f\udcaeK\000\000\ud8c8\udee3\udb0b\ude7d\ud8fa\udf0d\ud958\udef2\ud9af\uddab");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud859\udd71\ud820\udf15\000\000K\uda1f\udcaeK\000\000\ud8c8\udee3\udb0b\ude7d\ud8fa\udf0d\ud958\udef2\ud9af\uddab]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud8e4\udf7es\000\uda0c\udf71s\ud816\udd6a\udb60\udd42\u8b1c\udafc\ude95\udad0\udf41\udbc4\udd8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8e4\udf7es\000\uda0c\udf71s\ud816\udd6a\udb60\udd42\u8b1c\udafc\ude95\udad0\udf41\udbc4\udd8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud89c\udda8\000\u0200\000\ud928\udf53\udba2\ude37E\u0a28E\udaef\ude77\u8b84");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud89c\udda8\000\u0200\000\ud928\udf53\udba2\ude37E\u0a28E\udaef\ude77\u8b84]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb74\udfe7Z\000\000\000S\ud826\udc93\udbae\udd65h\udbd9\udd6b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb74\udfe7Z\000\000\000S\ud826\udc93\udbae\udd65h\udbd9\udd6b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9ae\udc62y\ud895\ude21y\udb72\udfa7\ud9af\udfc2W\udb8e\udea6\ud8ad\ude5b\ud98e\uddfd\udbdd\udf8a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9ae\udc62y\ud895\ude21y\udb72\udfa7\ud9af\udfc2W\udb8e\udea6\ud8ad\ude5b\ud98e\uddfd\udbdd\udf8a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud856\udc84\ud960\udc7eZ\000\udac4\udc01\000\000Z\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud856\udc84\ud960\udc7eZ\000\udac4\udc01\000\000Z\000]", String.valueOf(r));
  }
}
