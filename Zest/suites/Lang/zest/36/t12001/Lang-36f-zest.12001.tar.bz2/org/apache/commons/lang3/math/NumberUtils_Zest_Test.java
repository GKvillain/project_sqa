package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u7e02\uda5c\udddf\ud920\udd10\udad2\ude21\ud9d4\ude42\ud9fc\udd7b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u7e02\uda5c\udddf\udbcf\udd68\ud9a8\udc86\uda61\uddf6\ud9fc\udd7b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000\000\ud920\udcb3\udad2\ude21\000\ud9eb\udd74"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud84c\uded7\uda5c\udddf\u33e9\udad2\ude21\udaba\ude35\ud9fc\udd7b\u3e08\udaf7\udf91\udaa6\udfa7\udb46\udc1f\uda26\udd2d\udb33\uddd4\uc763\udb72\udd04\ud994\udec8"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda16\udf94"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud81f\udf04\ud94a\ude56\ud9ec\udc70\uda32\udf82\ud9d5\udc51\ud972\uded7\ud9e4\udc19\udb7f\udc7b\ud9e9\ude30\ud893\udec5\uda59\udf34\uda1a\udfb7\ud9ff\ude2a\ud8b9\udc95\udae5\udf0f\udbd5\udd02\ud8d3\udd83\ufa96\udb11\udfed\ud9ed\ude54\ud911\ude74\uda75\udc30\udbfa\udd44\udb43\udff9"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9ad\udf04\udab6\udc41\ud95b\udc24"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\035\uda5c\udd98\ud920\udd10\000\000\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9e8\udd3e\udafa\udd3d\ud9f0\uddb3\udb97\udee0\ud807\ude8a\ud9fc\ude42\ud99d\udef4\ud8f8\ude3f\ud9d9\udf2c\uda0e\udc4f\ud9a7\udf0b\ud93e\ude8e\udb6a\udd50\udb43\udcb8\udab8\udca1\udbce\ude92\ud814\ude0a\ud813\udc9e\udbae\udd4b\udb7f\udc65\udbaf\ude14\ud847\uddde\ud9d8\udf10\uda28\ude19\ud815\udfaa\udaa6\udefb\uc835\uda70\udf34\uda12\udde5\ud849\udca7\udbf3\udccf\ud837\ude66\ud9af\udc88\ud91d\ude9e\udb74\udc6f\ud8a4\ude5c\ud9fb\ude64\uda3c\udd86"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\035"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udafe\udfaa\uda5c\udddf\udbc3\udcb4\udbd6\udcc8\ud8a8\udc84\udb1e\udc53\uda97\udca0\ud832\uddab\ud96f\udfab\uda1f\udd1a\ud882\udf57\ud86c\udf01\ud8e1\udf86\udb6d\udf94\uda90\udf1a\udb8d\udc6c\udafa\ude36\udb1f\udda6\ud97a\udce8\ud8a3\udfe9\udbe5\ude4e\uab75\udb3f\udda1\ud962\udfd5\ua6b1\udb64\udc92\udb09\udf20\udb7b\udcfa\udaba\udebc\ud819\udc6b\ud932\udd7f\uc382\udbba\uddf6\ud8e2\udfc0\ud92b\udc4c\ud89f\udcf1\udbff\udd0c\ud85f\ude56\udad5\udd74\udbb3\udc3f\ud825\uddfb\udabe\udcb3\ud8c7\udd85\uda11\udc1b\ud8bb\udd0b\udaac\ude18\ud848\udf66\udbb7\udda2\udba4\ude94\udbec\ude36\udaa7\udd69\uda4f\udda0\ud967\udc07\udb17\udf5b\ud9d6\udd4b\ud9fc\uddcf\uda4c\ude61\udba9\udfe3\ud837\udd06\ud836\udd82\uda5d\udf9b\ud8f7\udc6a\udb04\udcec\uda18\udc86"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\035\udbaa\udd1f\ud920\udda4\000\ud876\udddf4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\035\ud8da\udf26\uda80\udc1c\000\000\000\ud91d\udcfd\udb04\udefc\ud9d4\udeb0\udbe4\udf0e\udad2\udce9\ud8a5\udcb6\uda58\udcdd\udbdb\udc04\ud834\ude81\ud9f3\udd3e\ud824\udd3f\uda1c\udf05\uda54\udf72\u6b0b\udbab\udd0e\uda5b\uddcc\ud935\uddc0\ud8cc\ude31\ud879\udcc8\udbfe\udfb4\udafe\ude93\udabe\udc98\ud9c4\udc2b\udbb2\udf1c\uda28\udc31\udb27\udee4\ud99b\udc2f\ud95e\udcbb\ud805\udd12\ud965\udc74\ud80a\udc90\uda4c\ude61\uda2a\udfb9\ud921\udf1c\udab0\udf98\ud986\udd84\ud951\udd93\ud881\udca8\ud831\udfa0\uda60\udf6f\u4808\uda75\udc27\ud9f6\ude81\uda5e\udc81\ud93a\udf92\ud8e0\udd0e\udb19\udd8b\uda1d\udfbf\ud9fc\ude0f\ud974\uddcb\ud93b\udccf\udae8\udec3\ud861\udfda\ub2b2\udbb6\udfa4\uda19\udf16\ud89d\udc45\udafe\udd3c\udb2d\udfe5\ud9fc\udc57\uda8f\udf01\ud96e\udefc\uda65\ude52"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E\uda5c\udd98\ud920\udd10\000\000\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\035\ud8da\udf26\uda80\udc1c\uda53\udd06\uda3b\udf1e\ud861\ude06\udbc9\udfd6\udb04\udefc\ud9d4\udeb0\uda42\ude0c\ud8fd\uddb6\udb42\uddff\uda58\udcf8\udbdb\udc04\udb56\udf32\uda92\udc51\udbb1\udc19\ud95d\udcf9\uda54\udf72\u6b0b\udad7\udc24\ud94d\udec5\ud935\uddc0\uda16\udf32\ud879\udcc8\udbfe\udfb4\udafe\ude93\udabe\udc98\ud9c4\udc2b\udbb2\udf1c\uda28\udc31\udb27\udee4\ud985\udf44\ud921\udf67\ud805\udd12\ud965\udc74\ud80a\udc90\udab3\udf15\uda2a\udfea\ud921\udf1c\udab0\udf98\ud9ad\udfcb\ud951\udd93\ud881\udc35\ud831\udfa0\uda60\udf6f\ud865\udd2c\uda75\udc27\ud9f6\ude81\uda5e\udc81\ud80b\udc9a\ud88d\udff4\udbb3\udc99\uda1d\udfbf\ud9fc\ude0f\ud974\uddcb\ud93b\udccf\udae8\udec3\ud861\udfda\ub2b2\udbb6\udfa4\uda19\udf16\ud89d\udc45\udafe\udd3c\udb2d\udfe5\ud9fc\udc57\ud921\udd6a\ud96e\ude79\uda65\udc71"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E\uda5c\udd98\udbae\udf1b\ud83a\udd99\udaa2\udff10"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u7e02\uda5c\udddf\ud920\udd10\udad2\ude21\udafd\ude7b\ud8cd\udf7f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("\u0a6d");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E\uda5c\udd98\ud992\udc19\udbfa\udd58\ud892\udf1ef"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E\ud871\ude83\ud8f1\ude9a\ud894\udd98\udb51\ude89F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\013\uda5c\udd98\ud992\udc19\udbed\ude1e\ud892\udf1ef"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E\uda5c\udd98\udba8\udc5f\udbfa\ude1a\u5a62d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(".\ud871\ude83\ud8f1\udf38\uda50\udc09\udbdd\udc0f\ud98b\udee2\udb35\udf5b\udaab\uddc1\uda58\udd5d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E\ud871\ude83\ud8f1\ude9a\ud894\udd98\udb51\ude89l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud996\udc7f\ud96f\udf9e\udb00\udc72\ud894\udd98\udb51\ude89l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(".\ud871\ude83\ud8af\uddf5\ud894\udd98\udb51\ude89l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud89e\ude73\ud871\ude83\ud8f1\ude9a\uda95\udf59\ud8b2\ude20L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("7\ud871\ude83\ud8af\uddf5\ud894\udd98\udb51\ude3dl"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u7e02\uda5c\udddf\ud920\udd10\udabe\udcf8\ud9d4\ude42\ud9fc\udd7b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E\ud86b\udc8b\ud8f1\ude9a\ud984\udd10\uda55\udf94."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud935\udd4c\udb64\udd7a\ud91f\udcb6\udbb8\ude44\udaa7\udc71D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("l"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9bd\udc49\ud9cd\udd0b\ud920\udd10\udad2\ude10\ud9d4\ude51\udb5f\uded4\ud9c1\udee7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
