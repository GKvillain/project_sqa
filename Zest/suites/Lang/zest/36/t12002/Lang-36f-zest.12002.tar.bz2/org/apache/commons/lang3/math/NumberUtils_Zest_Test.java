package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud936\ude52\uda47\udfe2\ud90f\udea4\udb0c\udd2c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb98\udeab\udb62\udddb\uda3b\ude4d\udb10\udc01\uda2a\udf56\ud83b\udf40\udb12\ude18\u0593\udb9a\udd61\ud82c\udc11\uda2a\udfb4\ud9b3\udc68\uda1d\udcbc\ud8d5\udff3\udb8a\udef1\ud82f\udd6f\ud913\udd5d\u429a\ud9ea\uddca\ud9be\udf49\ud948\udd49\udb11\udd37\ud8de\udc4c\udbe2\udd83\ud833\udf99\uda0e\udfa1\uda76\udf8f\udbb9\udfd7\ud9eb\udfe3\udacf\uddfc\uda65\udc01\uda4a\udf47\udaec\udf3d\udbc5\udfbb\ud8a2\udd0f\udb1a\udd68\udaac\udfc1\udaba\udc9a\ud9cb\udd96\ud854\udebc\udb26\udc56\uda79\udc37\uda82\ude9f\udbc5\ude19\ud9f1\udfc1\ud831\udf41\ud997\udca6\u4fcd\ud9a7\udc72\ud837\uddfc\udb3a\udd4c\ud925\ude2f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud825\udeb7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9ee\ude4eS\000\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u97a9\udb79\udcf1"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud904\udc00\uda22\udf32\ud90f\udea4\uda89\udd0d\udabb\udec9\ud95e\udcfc\uda2a\udd91\ud99b\udc51"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud946\ude84\u22d3\udacd\udfbf\ubfa6\udbf2\ude46"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud920\uddb2\udbf9\udffc\uda1b\udc30\ud911\udd9a\udab1\udd0f\udaac\udcf9\u4396\uda2a\udc35\uda66\udd26\uda7f\udd6c\ud9d8\udcf9\ud98c\ude9b\udb9e\udd35\024\ud802\udfcf\ud9b7\udd35\udb76\ude55\ud9fb\udce3\udbeb\udfa7\udbb2\uddbe\udbac\udf84\udb7d\udf7a\udbee\ude5d\ud811\udef8\ud9c8\udcd0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udbed\udd03\uda55\udc9f\ud805\udda0\uda67\udf5a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb50\udcf5\udb50\ude72\ud89f\ude86\udb8f\udd5c\udb25\udfa3\ud857\uddd7\ud80f\udf2e\udb3a\udc01\u8185\ud935\ude95\ud9c1\udffc\uda44\udfe1\ud93c\udfa1\ud963\udd76\udaab\udfe4\udb6b\udc74\ud9d8\ude9e\u0a16\ud8ab\udfd0\ud8d7\udcc6\uda89\udca0\udaa7\udc7c\uda67\udc60\ud85c\udde1\udbab\ude36\udbd9\udfe5\ud9e1\udc1e\ud99f\udc72\ud992\udef4\ud9df\udd27\uda3b\udfaa\ud8f2\udf22\ud805\uddc2\udbbf\uddf7\ud916\udfd0\ud819\ude72\uda37\udc61\ud877\udd53\ud838\udd96\ud8da\udd7f\ud96d\uddb9\uda05\udd45\udb45\udeab\ud9ae\udc21\udbd6\uddaf\ud879\udf63\ud93d\udf3b\udb67\udfa9\u83a6\ud9de\uddc1\ud97e\uded7\ud862\uddc0\udbd9\udeb0\udac1\udddd\ud99c\uddc2\ud906\udc0f\ud925\udde4\uda5f\udf2e\udba1\udd8d\ud9b6\udfa6\uda16\udc04\udb83\udcd9\ud909\ude92\udb06\udfe0\udb7c\udd81\udae4\udff9\udafb\ude7a\ud931\ude44\ud822\udcee\ud94d\udf1b\ud835\udf00\ud97a\udf46"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud80b\udcbd\uda6b\ude6a\ud8d2\udf1c\udb0c\udd2c\ud891\uddd6\u750c\ud80e\udcf2\ud88c\ude15\udb7e\udd96\ue1d0\udb0b\udd92\udbee\udf0e\ud8dd\uddd2\udbee\udeca\udacb\ude7e\ud83b\udf7a\ud84a\udc04\uda77\udc65\ud9b9\ude67\uda06\ude4c\udb91\uddba\udba1\uddfe\ud8ef\udca4\u9312\ud815\udde5\udadc\udd2c\ud9d7\udc66\ud97f\udcf6\uabf3"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud946\ude84e\udacd\udfbf\000\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud946\ude84e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud936\ude52\uda47\udfe2\ud90f\udea4F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("\ua8d6");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("6", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb19\udf87e\udbb8\udeb4\udb8e\udea63"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud933\udf10\uda47\udfe2\ud90f\udea4\udb0c\udd2c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud826\uddd3D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb19\udf87e\udbb8\udeb4\ud807\ude48.\udaa2\udca7\ud8a1\udee4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udbcc\udd6c.\ud8a9\udd0e\ud83b\udd8e\u3358\udab1\uddfc\ud861\ude83\u67ea\ud882\ude15\udba8\udef2\uda5f\udd33\ud857\udc06\udb36\ude45\ud8d9\ude95\udaff\udd80\udb3a\udfbe\ud8e0\udffd\udab6\udcd6\udae0\ude27"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud98a\uddad\udbc7\udc02\ud97b\udd08\udad0\udfc4L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud97b\udf48\u0dc6\udbb8\udeb4\ud807\ude48."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb19\udf21f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud936\ude52\uda47\udfe2\udab3\ude17\udb85\udee0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb05\ude1b\u00b5\ud85e\udc6b\ud8e4\udce9\ud90a\udd67\ud82d\udf72\ud80d\udc7a\ud959\udc8c\ud97f\ude27\ud81f\ude6d\ud8c9\udc81\ud950\udeb3\ud815\udca6\ud93f\udc90\uda10\udff2\udab3\udf6d\ud9e2\udcc4\udbe6\uddfc\ud8c5\udf8b\uda91\udcb3\ud9a7\udec2\u6c60d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb19\udf87e\udbb8\udeb4\ud8e9\udd37L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb19\udef0l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb19\udf87.\udbb8\udeb4\ud8e9\udd37L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\035"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb01\ude87.\ud9dc\ude47\ud919\ude67E"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud946\ude84e\ud9be\ude4eE\000"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ua8d6\ud8b3\udfc3L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
