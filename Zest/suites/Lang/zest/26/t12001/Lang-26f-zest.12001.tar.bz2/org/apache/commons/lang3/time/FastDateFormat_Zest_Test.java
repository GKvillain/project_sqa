package org.apache.commons.lang3.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastDateFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9a4\ude4c\uda47\udc4d\udac4\udd5d\ud85c\udcaa\ue410\uda66\udc95\u9c0a\ud8c9\ude83\ud99d\udd22");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a4\ude4c\uda47\udc4d\udac4\udd5d\ud85c\udcaa\ue410\uda66\udc95\u9c0a\ud8c9\ude83\ud99d\udd22]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud864\udd53");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud864\udd53]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udbe1\udff8\uda59\ude79\ud9c7\udcc4\ud956\udff1\u8c89\udb39\udc1e\uda56\udfdb\uda90\ude61\udb52\udd42\ud811\udf8b\ud8bd\udea4\uda80\uddb1\udaca\udf5c\uda03\ude8e\udb09\ude26\ud90d\udf49\u0db4\ud812\udc8c\udbe4\ude1c\u2204\udb1b\ude25\ud96e\udd01\ud859\udf92\ud90c\ude62\udbe8\udf56\udb87\udca8\uda06\ude00\ud88c\udd47\ud943\udd12\udacf\udc5b\ud8f3\udda1");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbe1\udff8\uda59\ude79\ud9c7\udcc4\ud956\udff1\u8c89\udb39\udc1e\uda56\udfdb\uda90\ude61\udb52\udd42\ud811\udf8b\ud8bd\udea4\uda80\uddb1\udaca\udf5c\uda03\ude8e\udb09\ude26\ud90d\udf49\u0db4\ud812\udc8c\udbe4\ude1c\u2204\udb1b\ude25\ud96e\udd01\ud859\udf92\ud90c\ude62\udbe8\udf56\udb87\udca8\uda06\ude00\ud88c\udd47\ud943\udd12\udacf\udc5b\ud8f3\udda1]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda68\udd3a\uda56\udf0a\ud8db\udf5c\uda4d\udc4d\udab9\udc14\udbb5\udc28\u9c0a\ud8c9\ude68");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda68\udd3a\uda56\udf0a\ud8db\udf5c\uda4d\udc4d\udab9\udc14\udbb5\udc28\u9c0a\ud8c9\ude68]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9a4\ude0e\uda47\udc4d\udac4\udd5d\ud9a0\udd8c\ud801\udc75");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a4\ude0e\uda47\udc4d\udac4\udd5d\ud9a0\udd8c\ud801\udc75]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda53\udcb4\uda46\udff3\ufb1c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda53\udcb4\uda46\udff3\ufb1c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\uda46\udfdf\ub8d2\ud85c\udcaa\000\000\000\ud8c4\ude21\ud9c3\udfb6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\uda46\udfdf\ub8d2\ud85c\udcaa\000\000\000\ud8c4\ude21\ud9c3\udfb6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30\u06fd\uda66\udccb\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39\ud963\udd71\udba0\udea8\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud938\udce4\ud844\udfad\ud8bd\udd37\uda28\udfe1\ud931\udcd0\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud95c\udfed\ud910\ude13\uda7f\udcf1\uda12\udf05\u3aa4\u4bcd\ud837\ude76\ub513\udb5c\udc4d\uda66\udf2b\ud99c\udd74\ua2ff\ud95a\udc95\ud800\udd93");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30\u06fd\uda66\udccb\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39\ud963\udd71\udba0\udea8\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud938\udce4\ud844\udfad\ud8bd\udd37\uda28\udfe1\ud931\udcd0\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud95c\udfed\ud910\ude13\uda7f\udcf1\uda12\udf05\u3aa4\u4bcd\ud837\ude76\ub513\udb5c\udc4d\uda66\udf2b\ud99c\udd74\ua2ff\ud95a\udc95\ud800\udd93]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\000\000h\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\000\000h\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u5745\000\udac4\udc8b\000\000\uda66\udc95\u9c0a\ud84b\udc64\ud967\udd72");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u5745\000\udac4\udc8b\000\000\uda66\udc95\u9c0a\ud84b\udc64\ud967\udd72]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9a4\ude4cn\u1884\ud85c\udcaa\ue410\uda66\udc95\u9c0a\ud8c9\ude83\ud99d\udd22"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("E\uda47\udc4d\000\ud85c\udc28\ue410\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[E\uda47\udc4d\000\ud85c\udc28\ue410\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u0bc3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u0bc3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\u1400\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\u1400\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9a4\ude4c\uda47\udc4d\000\ud853\udd28h\ud836\udf7a\u9c0a\ud8c9\ude21\ud99d\udd22");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a4\ude4c\uda47\udc4d\000\ud853\udd28h\ud836\udf7a\u9c0a\ud8c9\ude21\ud99d\udd22]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\uda46\udfdf\ud921\udd4b\ud94b\udd8fP\udb5e\uddfe\udaa4\udfbe\ud8b4\udc56\ud968\udfb2\udb55\udf73\ud98c\udd12\ud91f\ude12\udb7a\udf57\udb7e\udc9c\ud971\udea2\ud966\udd8f\udaec\udc10"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30=\uda66\udccb\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39\ud963\udd71d\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud938\udce4\ud844\udfad\ud8bd\udd37\uda28\udfe1\ud931\udcd0\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\u1f40\000\000\ud837\ude4f\ub513\udb5c\udc4d\udb53\udc82\ud87a\uddfd\ua2ff\ud95a\udc95\ud800\udd93");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30=\uda66\udccb\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39\ud963\udd71d\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud938\udce4\ud844\udfad\ud8bd\udd37\uda28\udfe1\ud931\udcd0\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\u1f40\000\000\ud837\ude4f\ub513\udb5c\udc4d\udb53\udc82\ud87a\uddfd\ua2ff\ud95a\udc95\ud800\udd93]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\000\000h\ud80c\udec5A\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udad2\udce0\ud8e8\udf88s\ud9ee\ude0c\035\000\000\ue200\udb9b\ude06\udbdf\udce7\uda33\udcba\udae6\udd1e\ud858\udf3a\uda9d\udcd7\udbff\udd7b\ud905\udd3e\udb85\udeaf\u6123");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udad2\udce0\ud8e8\udf88s\ud9ee\ude0c\035\000\000\ue200\udb9b\ude06\udbdf\udce7\uda33\udcba\udae6\udd1e\ud858\udf3a\uda9d\udcd7\udbff\udd7b\ud905\udd3e\udb85\udeaf\u6123]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\ud98e\udca6\u1e7fh\udbfa\udd3b\udb3e\udc57\udbb5\ude36'");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\ud98e\udca6\u1e7fh\udbfa\udd3b\udb3e\udc57\udbb5\ude36']", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\000\000h\000\uda85\udfbdT\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udb9c\udc03\ud845\udf7b\u2bfb\udb07\udf14H\udb7c\ude1e\udabd\uddee\uda57\ude7b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb9c\udc03\ud845\udf7b\u2bfb\udb07\udf14H\udb7c\ude1e\udabd\uddee\uda57\ude7b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\000\000h");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\000\000h]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda1c\udc0d\u1900\000\000\ud9d0\udffc\uda8b\ude59z\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda1c\udc0d\u1900\000\000\ud9d0\udffc\uda8b\ude59z\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("h\u1900\udb45\udef1\udb89\udcf5h\ud93e\udd8c\ud81c\udc2c\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[h\u1900\udb45\udef1\udb89\udcf5h\ud93e\udd8c\ud81c\udc2c\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\ud887\udf15\u00e1\ud9ab\ude93\ud91c\udd63\ud815\udff3L\ud97c\udc07\udb92\udd7d"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\000\000h\ud80c\udec5o\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\u5141\ud923\udc8cJ\000\000\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\000\000h\udb19\udf2c'\000\000\udb97\ude68\ud9d8\udd50\udb2f\udf24");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\000\000h\udb19\udf2c'\000\000\udb97\ude68\ud9d8\udd50\udb2f\udf24]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\000\ud930\udd97\ud9b2\uddca\uadcf\000\udbc8\ude84B"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\ud8c0\udc24\u0085\000\ud904\udee3C\000\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud975\udcfc\udb13\udd73M\uda25\ude87\udaa8\udf2d\ud86a\udc51");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud975\udcfc\udb13\udd73M\uda25\ude87\udaa8\udf2d\ud86a\udc51]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9ec\udd36\ud8f4\ude18\u1b00\udb59\udeb6\ud993\uddac\000Q\000\ud9ac\udd55"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\udb1b\udd8d\udb27\udeb1'\000\ud876\udd6d\uf2a5\u0ed3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\udb1b\udd8d\udb27\udeb1'\000\ud876\udd6d\uf2a5\u0ed3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("Z\u1900\udaca\ude2d\ud85b\udcbd\udb2c\udf8c\u397d\uda02\udd2b\udace\udd5e\uda3c\udc2b\uda45\udcb5\ucd8d\ud83d\udf00\ud8ee\udc3b\udb77\udc85\ud825\udccd\ud807\udc3d\udb0b\udfe4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[Z\u1900\udaca\ude2d\ud85b\udcbd\udb2c\udf8c\u397d\uda02\udd2b\udace\udd5e\uda3c\udc2b\uda45\udcb5\ucd8d\ud83d\udf00\ud8ee\udc3b\udb77\udc85\ud825\udccd\ud807\udc3d\udb0b\udfe4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud945\udc1ba\u1884\ud9ad\udd23\ud99d\udddd\udb48\udd84\u1c6a\udb22\udd8e\ud951\udf0e\u45fb\ud8b7\udc48\udac3\ude9e\ud837\udd8c\ud8c5\ude75\uda77\udd55\ud953\udc25\ud96a\udd19\udbb3\udf09\udabe\ude47\uda67\ude38\uda45\ude8e\udb32\udf49\uda19\udd14\udb18\udcd3\ud909\udf4f\ud8af\udf8b\ud62b\ud90e\uddb0\ud950\udf38\uda7d\udd5f\udae2\udf76\ud8f1\udd70");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud945\udc1ba\u1884\ud9ad\udd23\ud99d\udddd\udb48\udd84\u1c6a\udb22\udd8e\ud951\udf0e\u45fb\ud8b7\udc48\udac3\ude9e\ud837\udd8c\ud8c5\ude75\uda77\udd55\ud953\udc25\ud96a\udd19\udbb3\udf09\udabe\ude47\uda67\ude38\uda45\ude8e\udb32\udf49\uda19\udd14\udb18\udcd3\ud909\udf4f\ud8af\udf8b\ud62b\ud90e\uddb0\ud950\udf38\uda7d\udd5f\udae2\udf76\ud8f1\udd70]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("E\uda47\udc4d\000\uda87\udf9e\udae3\udd6f\uda9d\udc04R\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("E\uda47\udc4d\ud970\udef7\ud953\udd57\u9d93G");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[E\uda47\udc4d\ud970\udef7\ud953\udd57\u9d93G]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("E\uda6d\uddbdw\ud85c\udc28");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[E\uda6d\uddbdw\ud85c\udc28]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9f1\udf2b\ud916\udce3\ud89b\udce8\ud85c\udc28\udace\udf9aW\000\ud93d\uddbe\ud82d\ude48");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9f1\udf2b\ud916\udce3\ud89b\udce8\ud85c\udc28\udace\udf9aW\000\ud93d\uddbe\ud82d\ude48]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("E\uda47\udc4d\000\ud80e\udc21\ue410\ud8aa\udf75E\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[E\uda47\udc4d\000\ud80e\udc21\ue410\ud8aa\udf75E\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("K\udb4d\udec2\udac6\udfda\ud9f9\udc98\uda5d\udde3\ud9e6\udfad\udaa4\udfbe\ud8b4\udc56\ud968\udfb2\ud8eb\udf7e\ud98c\udd12\ud91f\ude12\udb7a\udf57\udb7e\udc9c\ud971\udea2\ud936\udc3b\uda36\udf3d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[K\udb4d\udec2\udac6\udfda\ud9f9\udc98\uda5d\udde3\ud9e6\udfad\udaa4\udfbe\ud8b4\udc56\ud968\udfb2\ud8eb\udf7e\ud98c\udd12\ud91f\ude12\udb7a\udf57\udb7e\udc9c\ud971\udea2\ud936\udc3b\uda36\udf3d]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud906\udcc8\udbfa\udc29=\uda4e\udf86\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39F\000\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud938\udce4\ud844\udfad\ud8bd\udd37\uda28\udfe1\udbb8\udf5b\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\u1f40\000\000\ud837\ude4f\ub513\000\000\ud87a\uddfd\ua2ff\uda70\udea1\ud800\udd93");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\udabd\udd86\ud906\udcc8\udbfa\udc29=\uda4e\udf86\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39F\000\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud938\udce4\ud844\udfad\ud8bd\udd37\uda28\udfe1\udbb8\udf5b\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\u1f40\000\000\ud837\ude4f\ub513\000\000\ud87a\uddfd\ua2ff\uda70\udea1\ud800\udd93]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud91f\ude25\uda77\udd1d\ud887\udf6c\udbf8\udee8\u5589\uda01\udced\ud9a1\udddd\udb5f\udf39\ud963\udd71d\ud87a\uddc6\udbbd\udf7e\ud83b\ude40\ud832\uddb0\udafb\udcab\uda1a\udfa3\udb7e\udcd4\udb0b\udd92\ud939\udf77\ud94c\udf62\udb8d\udd26\ud817\ude5b\ud931\udca8\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud9db\udc04\ud8e9\uddf2\uda7f\udcf1\u1f40\ud81e\udf2fy\ud837\ude4f\ub513\udb5c\udc4d\udb53\udc82\ud899\udcfd\ua2ff\ud95a\udc95\ud8e0\udc82");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\udabd\udd86\ud91f\ude25\uda77\udd1d\ud887\udf6c\udbf8\udee8\u5589\uda01\udced\ud9a1\udddd\udb5f\udf39\ud963\udd71d\ud87a\uddc6\udbbd\udf7e\ud83b\ude40\ud832\uddb0\udafb\udcab\uda1a\udfa3\udb7e\udcd4\udb0b\udd92\ud939\udf77\ud94c\udf62\udb8d\udd26\ud817\ude5b\ud931\udca8\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud9db\udc04\ud8e9\uddf2\uda7f\udcf1\u1f40\ud81e\udf2fy\ud837\ude4f\ub513\udb5c\udc4d\udb53\udc82\ud899\udcfd\ua2ff\ud95a\udc95\ud8e0\udc82]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30=\uda66\udccb\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39\ud963\udd71d\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\uda89\udf52\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud862\udee1\ud844\udfad\ud8bd\udd37\ud96a\udde2\ud837\udde7\ud95a\udf16\udafe\udd82\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\ud92c\ude32d\000\ud837\ude4f\ub513\uda42\udc20\ud923\udf5c\ud87a\uddfd\ua2ff\ud95a\udc95\ud800\udd93");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30=\uda66\udccb\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39\ud963\udd71d\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\uda89\udf52\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud862\udee1\ud844\udfad\ud8bd\udd37\ud96a\udde2\ud837\udde7\ud95a\udf16\udafe\udd82\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\ud92c\ude32d\000\ud837\ude4f\ub513\uda42\udc20\ud923\udf5c\ud87a\uddfd\ua2ff\ud95a\udc95\ud800\udd93]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30=\uda66\udccb\udae4\uddf0\udaac\udf56\uda6c\ude8a\udb5f\udf39\ud963\udd71d\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\uda1c\udddb\u626c\udbfe\udcd3\udb34\udcaa\ud938\udce4\udaa7\udc25\ud90c\udf4b\udbea\udc57\ud919\uddca\ud90b\udf0a\udade\ude0a\ud8b5\udcf5\ud938\udf7e\ud910\ude13\uda7f\udcf1\u1f40\ud92c\udfd7N\ud837\ude4f\ub513\udb5c\udc4d\udb49\udddd\ud95f\udf9a\ud9e2\udd1f\ud82c\udd41\ud800\udd93"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30=\uda66\udccb\u5589\uda01\udced\uda6c\ude8a\udbd9\udef6\ud9a7\udeafk\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb69\udc9c\uf074\udadf\udd21\ud8e1\ude93\ud96d\ude46\udb65\udd93\udbba\udf7f\ud9b0\udf4c\ud953\udc96\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\u1f40\000\ud816\udc0a\ud837\ude4f\ub513\udb5c\udc4d\udb53\udc82\ud87a\uddfd\ua2ff\ud95a\udc95\ud800\udd93");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\udabd\udd86\ud906\udcc8\ud9d1\udd30=\uda66\udccb\u5589\uda01\udced\uda6c\ude8a\udbd9\udef6\ud9a7\udeafk\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb69\udc9c\uf074\udadf\udd21\ud8e1\ude93\ud96d\ude46\udb65\udd93\udbba\udf7f\ud9b0\udf4c\ud953\udc96\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\u1f40\000\ud816\udc0a\ud837\ude4f\ub513\udb5c\udc4d\udb53\udc82\ud87a\uddfd\ua2ff\ud95a\udc95\ud800\udd93]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\ubc35\udbba\udc9dDh\ud80c\udec5A\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\udbf7\ude1d\udb50\udcc4\udbbf\ude6d\000h\ud80c\udec5A\000\000\udbf7\ude04\uda68\udde2\udbf4\udc2a\u7664\ud82a\udd83\ud8fb\ude75\ud8d4\udf84\ud9be\udd01\udae7\udec7\ud932\udf49\udaa8\udc63\ud9ad\udffb\ud9be\udf51\ud995\udf6a\uda5b\udfe8\ud973\udee7\uda98\udc6d\udaf6\udd20\ua4fc\udb24\ude13\ud810\udc28\udaf0\udd12\udb65\udd82\udb19\udc1c\ud9e3\udf33\udac1\udf52\ud84c\udc83\uda59\udfff\udb85\udeb5\uda3e\uddb9\udb79\ude62\udb7d\uded4\udb7d\udd74\ud9c1\udcda\uda2b\udeda\ud867\udc70\uda38\udc96\ud964\udfa0\uda65\udefa\ud903\udc2a\ud812\udf07\udaab\udd5e\ud8f7\udde8\uda6f\udd5c\ud8b7\udc47\ud848\udd14\ud809\ude2c\ud979\ude73\ud82d\udd74\ud868\uddd6\ud924\ude30\udab7\udc03\ud82e\udc3b\ud8b1\udd7a\ud979\udcfd\udbe5\ude34\uda63\uddfe\ud97a\udd9b\udb9c\ude1d\ud8d8\udcc4\ud9b3\udd65\udad6\udc59\ud897\udcb7\ud9b0\udd99"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udbea\ude30\uda1d\udfcf\ud9c7\udc59S\uda9e\udd6a\ud86e\udc4a\ua9c8\ud846\udd0d\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbea\ude30\uda1d\udfcf\ud9c7\udc59S\uda9e\udd6a\ud86e\udc4a\ua9c8\ud846\udd0d\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udad2\udce0\ud8e8\udf88s\ud9ee\ude0c\uaa9d\ud84c\udeddD\u9a06\udb9b\ude06\udbdf\udce7\uda33\udcba\udb5e\udeba\u89c1\uda9d\udd17\udbff\udd7b\ud905\udd3e\udb85\udeaf\udbea\ude4c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udad2\udce0\ud8e8\udf88s\ud9ee\ude0c\uaa9d\ud84c\udeddD\u9a06\udb9b\ude06\udbdf\udce7\uda33\udcba\udb5e\udeba\u89c1\uda9d\udd17\udbff\udd7b\ud905\udd3e\udb85\udeaf\udbea\ude4c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\ud98e\udca6\u1e7fh\udbfa\udd3b\udb3e\udc57\udbb5\ude36'\ud9c8\udd9e\udbe2\uddb5\udadd\udc8c\ud8c7\udfd8\ud922\udc41\udb28\udfc0\ud88e\udc3f\ud848\udf7d\udadb\udc0b\ud836\udeda\uda48\udddc");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\ud98e\udca6\u1e7fh\udbfa\udd3b\udb3e\udc57\udbb5\ude36'\ud9c8\udd9e\udbe2\uddb5\udadd\udc8c\ud8c7\udfd8\ud922\udc41\udb28\udfc0\ud88e\udc3f\ud848\udf7d\udadb\udc0b\ud836\udeda\uda48\udddc]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("I\u486b\udb8a\udf73\ud74fh\udbfa\udd3b\udb3e\udc57\udbb5\ude36\u45c6"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\udab4\udf57\ud8fe\udf3f\udad3\uded1\ud8c1\udec0\uda4a\udfc7\ud942\udc95\ud8a4\ude25'\udb80\udf1e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\udab4\udf57\ud8fe\udf3f\udad3\uded1\ud8c1\udec0\uda4a\udfc7\ud942\udc95\ud8a4\ude25'\udb80\udf1e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u00b3\u1900\ud98e\udca6\uf5d9\ud8cf\udf90\u29cb\udb3e\udc57\udbb5\ude36'\ud9ce\udd1a\uda7f\udd00\ud994\udd82\ud83d\udea4\uda24\udc48\ud975\ude76\udbbc\udcbd\ud840\udcc4\ud861\udf75\udb25\udc64\ud80c\ude10\u4b48\udbe6\udf3e\ud8e7\udf73\udb52\udd17\udb22\udf08\uda8a\udcb1\uda90\ude5b\ud93e\udeea\ud838\udc59\udad8\ude1f\ud985\udf23\udb63\ude15\uda0e\udf91\udb8e\udfbb\ud933\uddff\udb7c\ude95\udbd5\ude4e\uda79\uded6\udae4\udc71\u822f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u00b3\u1900\ud98e\udca6\uf5d9\ud8cf\udf90\u29cb\udb3e\udc57\udbb5\ude36'\ud9ce\udd1a\uda7f\udd00\ud994\udd82\ud83d\udea4\uda24\udc48\ud975\ude76\udbbc\udcbd\ud840\udcc4\ud861\udf75\udb25\udc64\ud80c\ude10\u4b48\udbe6\udf3e\ud8e7\udf73\udb52\udd17\udb22\udf08\uda8a\udcb1\uda90\ude5b\ud93e\udeea\ud838\udc59\udad8\ude1f\ud985\udf23\udb63\ude15\uda0e\udf91\udb8e\udfbb\ud933\uddff\udb7c\ude95\udbd5\ude4e\uda79\uded6\udae4\udc71\u822f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\ud98e\udca6\u4503\u0084\udbfa\udd3b\udb3e\udc57\udbb5\ude36'\udaa9\udcf3\uda80\udcb2\ud96e\udca8\ud8e5\ude5d\uda8d\ude63\ud8df\udeac\uda67\udf05\ud801\udee6\ud82a\udcca\ud86e\udf85\ud998\udd51\ud9a5\udccb\udb26\udcdd\udb74\ude61\uda9f\udc2a\udbdb\udce2\udb7a\ude14\ud95d\udddc\ud9b6\udf8e\udb00\udf50\ud844\udd09\udb32\udfc4\uda11\udd93\uda7f\udfb6\udb9f\ude02\udad0\ude37\udb75\udc05\udb4d\udd30\udaa5\udd14\udb06\udc8b\udaed\ude5f\uda38\udc79\ud81b\udc9b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\ud98e\udca6\u4503\u0084\udbfa\udd3b\udb3e\udc57\udbb5\ude36'\udaa9\udcf3\uda80\udcb2\ud96e\udca8\ud8e5\ude5d\uda8d\ude63\ud8df\udeac\uda67\udf05\ud801\udee6\ud82a\udcca\ud86e\udf85\ud998\udd51\ud9a5\udccb\udb26\udcdd\udb74\ude61\uda9f\udc2a\udbdb\udce2\udb7a\ude14\ud95d\udddc\ud9b6\udf8e\udb00\udf50\ud844\udd09\udb32\udfc4\uda11\udd93\uda7f\udfb6\udb9f\ude02\udad0\ude37\udb75\udc05\udb4d\udd30\udaa5\udd14\udb06\udc8b\udaed\ude5f\uda38\udc79\ud81b\udc9b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda9f\udec4\ud850\udc8b\u2bfb\ud90e\ude39\ud8b5\udcc7\udbda\udc39\uda0e\uddd7\ud96e\udd05\udbf1\udde4\uda02\udcfb\ud840\udef9\udb77\udc1a\udaa4\udf3c\udad1\uded3\uda8f\ude80\ud869\ude9f\udac2\udcae\udb41\udcf4\ud82e\udd9d\udb8f\udce5\ud8b5\uddf7\uda82\uddf9\ud96e\uded7\uda6b\ude57\ud9ee\udc51\uda1b\udeb5\ud945\udd6a\udb8f\uddba\ud9f6\uddda\ud888\udcfc\ud994\udd97\u2e7e\udb81\ude23\ud804\udcd7\ud825\udd19\udaa0\udf5b\udacd\udd6d\ud853\ude8e\uda57\ude22\ud9c3\udeae\ud8bf\udc52\ud8e8\udd32\ud8d8\udf2d\udb32\ude6b\udafc\udfd4\udb03\ude3f\udb55\udd2e\udb0b\udd97\ud9c5\udc66\udb0f\ude57\udbe9\udd00\ud971\udc83\ud886\udcac\uda68\udf33\u03ca\u6ac9\ud8f7\udeac\ud8ab\udeb0\ud8ee\udf55\udb31\udfd5\udb65\udc75\ud8e0\udc31\ud82f\uddfb\uda9f\udedd\ud96b\udd7e\ud8e1\udc12\ud966\ude0a\udb75\udeb0\ud9da\udc4a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda9f\udec4\ud850\udc8b\u2bfb\ud90e\ude39\ud8b5\udcc7\udbda\udc39\uda0e\uddd7\ud96e\udd05\udbf1\udde4\uda02\udcfb\ud840\udef9\udb77\udc1a\udaa4\udf3c\udad1\uded3\uda8f\ude80\ud869\ude9f\udac2\udcae\udb41\udcf4\ud82e\udd9d\udb8f\udce5\ud8b5\uddf7\uda82\uddf9\ud96e\uded7\uda6b\ude57\ud9ee\udc51\uda1b\udeb5\ud945\udd6a\udb8f\uddba\ud9f6\uddda\ud888\udcfc\ud994\udd97\u2e7e\udb81\ude23\ud804\udcd7\ud825\udd19\udaa0\udf5b\udacd\udd6d\ud853\ude8e\uda57\ude22\ud9c3\udeae\ud8bf\udc52\ud8e8\udd32\ud8d8\udf2d\udb32\ude6b\udafc\udfd4\udb03\ude3f\udb55\udd2e\udb0b\udd97\ud9c5\udc66\udb0f\ude57\udbe9\udd00\ud971\udc83\ud886\udcac\uda68\udf33\u03ca\u6ac9\ud8f7\udeac\ud8ab\udeb0\ud8ee\udf55\udb31\udfd5\udb65\udc75\ud8e0\udc31\ud82f\uddfb\uda9f\udedd\ud96b\udd7e\ud8e1\udc12\ud966\ude0a\udb75\udeb0\ud9da\udc4a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud918\udf4b\udba5\udd99\ud9b5\udffa\u5d41\ud9d0\udffc\uda8b\ude59z\000O\udb70\udd2e\ud8dc\uddc5\ud9ce\ude6b\ud8be\udc77\ud9bf\udedf\u7a6e"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda1c\udc0d\ud980\udfb6\u244d\000\ud9d0\udffc\uda8b\ude59zz\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda1c\udc0d\ud980\udfb6\u244d\000\ud9d0\udffc\uda8b\ude59zz\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda1c\udc0d\udbf5\ude57\034\ud898\udd2c\ud9d0\udffc\ud9c5\udfa8m\000\u7700\ud891\udfe6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda1c\udc0d\udbf5\ude57\034\ud898\udd2c\ud9d0\udffc\ud9c5\udfa8m\000\u7700\ud891\udfe6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\000\ud8b1\udf78\udbd8\udf5f\uda1f\uddc8'\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\000\ud8b1\udf78\udbd8\udf5f\uda1f\uddc8'\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\uda49\udfe6'h\udb19\udf6a'\ud8e1\udd0b\000\udb97\ude68\udb42\udd45\ud3e0");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\uda49\udfe6'h\udb19\udf6a'\ud8e1\udd0b\000\udb97\ude68\udb42\udd45\ud3e0]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\u1900\u15b4\000h\udb19\udf2c\udb94\udcd1G\000\udb97\ude68\ud9d8\udd50\udb2f\udf24");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\u1900\u15b4\000h\udb19\udf2c\udb94\udcd1G\000\udb97\ude68\ud9d8\udd50\udb2f\udf24]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\u88b9\000\000\u00a9\udb83\udf6e\000\000\000\000\000\000\000\000\000\000\000\000\udb7e\udcd4\ud909\udf03\ucbf4\000\ud8fc\ude3d\ud809\ude54\udbb8\udfa3\ud8d6\udf3d\ud953\udd0f\000\000\000\uda55\udc3c\000\ud81e\udf2fy\000\000\000\000\ud899\udcfd\ud85a\udef7\udae9\ude8b\ud8e0\udc82");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\u88b9\000\000\u00a9\udb83\udf6e\000\000\000\000\000\000\000\000\000\000\000\000\udb7e\udcd4\ud909\udf03\ucbf4\000\ud8fc\ude3d\ud809\ude54\udbb8\udfa3\ud8d6\udf3d\ud953\udd0f\000\000\000\uda55\udc3c\000\ud81e\udf2fy\000\000\000\000\ud899\udcfd\ud85a\udef7\udae9\ude8b\ud8e0\udc82]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud91f\ude25\uda77\udd1d\u00a9\000\u5523\uda01\udced\ud9a1\udddd\udb5f\udf39\ud922\udd51d\ud87a\uddc6\udbbd\udf7e\ud83b\ude40\ud832\uddb0\udafb\udcab\udae4\udc87\000\udb0b\udd10\ud92d\udc6a\ud94c\udf62\udb8d\udd26\ud817\ude5bH\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud9db\udc04\ud8e9\uddf2\uda7f\udcf1\u1f40\ud81e\udf2fy\ud837\ude4f\ub513\ud99e\udccf\udb53\udc82\ud899\udcfd\ua2ff\uda70\udea1\ud8d2\udc88");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\udabd\udd86\ud91f\ude25\uda77\udd1d\u00a9\000\u5523\uda01\udced\ud9a1\udddd\udb5f\udf39\ud922\udd51d\ud87a\uddc6\udbbd\udf7e\ud83b\ude40\ud832\uddb0\udafb\udcab\udae4\udc87\000\udb0b\udd10\ud92d\udc6a\ud94c\udf62\udb8d\udd26\ud817\ude5bH\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud9db\udc04\ud8e9\uddf2\uda7f\udcf1\u1f40\ud81e\udf2fy\ud837\ude4f\ub513\ud99e\udccf\udb53\udc82\ud899\udcfd\ua2ff\uda70\udea1\ud8d2\udc88]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\uda1c\udc0d\ud980\udfb6\u244d\000\ud9d0\udffcK\000z\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda1c\udc0d\ud980\udfb6\u244d\000\ud9d0\udffcK\000z\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud9a4\ude4c\uda47\udc4d\udac4\udd5d\uda47\udf72\ud9d5\udcb5\udb4c\udd68\uda8a\udf1f\ud855\ude8d\ud99d\udd22");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a4\ude4c\uda47\udc4d\udac4\udd5d\uda47\udf72\ud9d5\udcb5\udb4c\udd68\uda8a\udf1f\ud855\ude8d\ud99d\udd22]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\ud945\udc1ba\u1884\ud9ad\udd23\ud99d\udddd\udb48\udd84G\udb1a\ude2c\ud951\udf0e\u45fb\ud8b7\udc48\udac3\ude9e\ud837\udd8c\udab2\ude2b\uda77\udcc8\ud953\udc25\ud96a\udd19\udbb3\udf09\udabe\ude47\uda67\ude38\uda45\ude8e\udb32\udf49\uda13\udc90\udb18\udcd3\ud909\udf4f\ud8df\udf83\ud62b\ud9f2\udea6\ud9be\udedf\uda7d\udd5f\udae1\udd90\ud8f1\udd70");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud945\udc1ba\u1884\ud9ad\udd23\ud99d\udddd\udb48\udd84G\udb1a\ude2c\ud951\udf0e\u45fb\ud8b7\udc48\udac3\ude9e\ud837\udd8c\udab2\ude2b\uda77\udcc8\ud953\udc25\ud96a\udd19\udbb3\udf09\udabe\ude47\uda67\ude38\uda45\ude8e\udb32\udf49\uda13\udc90\udb18\udcd3\ud909\udf4f\ud8df\udf83\ud62b\ud9f2\udea6\ud9be\udedf\uda7d\udd5f\udae1\udd90\ud8f1\udd70]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\u3de3\udabd\udd86\ud906\udcc8\udbfa\udc29F\uda4e\udf86\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39F\000\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud938\udce4\ud844\udfad\ud8bd\udd37\uda28\udfe1\ud82d\ude6a\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\u1f40\000\000\ud837\ude4f\ub513\000\000\ud87a\uddfd\ua2ff\uda70\udea1\ud800\udd93");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u3de3\udabd\udd86\ud906\udcc8\udbfa\udc29F\uda4e\udf86\u5589\uda01\udced\uda6c\ude8a\udb5f\udf39F\000\uda20\udcd8\udb93\uddd0\ud83b\ude40\ud832\uddb0\udafb\udcab\udbcd\udf7b\udb87\udc0b\ud97c\uddeb\ud938\udce4\ud844\udfad\ud8bd\udd37\uda28\udfe1\ud82d\ude6a\ud90b\udf3d\ud953\udd0f\ud8b5\udcf5\ud938\udedc\ud910\ude13\uda7f\udcf1\u1f40\000\000\ud837\ude4f\ub513\000\000\ud87a\uddfd\ua2ff\uda70\udea1\ud800\udd93]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    try { org.apache.commons.lang3.time.FastDateFormat.getInstance("M\ubc35\udbba\udc9dDh\ud80c\udec5A\000\000"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udac1\udcc0\ud980\udf03\u244dz\ud9ba\udff1\ud951\udd65zz\udb6a\ude75");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udac1\udcc0\ud980\udf03\u244dz\ud9ba\udff1\ud951\udd65zz\udb6a\ude75]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\ud858\udf92\udb70\udd7dhh\ud861\udc2f\udbaa\udd13\u00ee\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud858\udf92\udb70\udd7dhh\ud861\udc2f\udbaa\udd13\u00ee\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\ubc35\udbba\udc9dD\ud853\udfd1\ud974\ude72\ud821\ude3bD\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ubc35\udbba\udc9dD\ud853\udfd1\ud974\ude72\ud821\ude3bD\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\udbf7\ude1d\udb50\udcc4\udbbf\ude6d\000\udb40\ude28\ud853\udf31'\000\000\udbf7\ude04\uda68\udde2\udbf4\udc2a\u7664\ud82a\udd83\ud8fb\ude75\ud8d4\udfa8\ud9be\udd01\udae7\udec7\ud932\udf49\udaa8\udc63\ud9ad\udffb\uda05\udc93\ud995\udfa6\uda5b\udfe8\ud973\udee7\uda98\udc6d\udaf6\udd20\ua4fc\udb24\ude13\ud810\udc28\udaf0\udd12\udb65\udd82\udb19\udc1c\ud9e3\udf33\udac1\udf52\ud84c\udc83\uda59\udfff\ud9cd\udf79\uda3e\ude11\udb79\ude62\udb7d\uded4\udb7d\udd74\ud9c1\udcda\uda2b\udeda\ud867\udc70\ud856\udd72\ud964\udf89\uda65\udefa\ud903\udc2a\ud812\udf07\udaab\udd5e\ud8f7\udde8\uda6f\udd5c\ud8b7\udc47\ud848\udd14\ud809\ude2c\ud979\ude73\ud82d\udd74\ud868\uddd6\ud924\ude30\udab7\udc03\ud83c\udd40\ud8b1\udd7a\ud979\udcfd\udbe5\ude34\uda63\uddfe\ud97a\udd9b\udb9c\ude1d\ud8d8\udcc4\ud9b3\udd65\udad6\udc59\ud897\udcb7\ud9b0\udd99");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbf7\ude1d\udb50\udcc4\udbbf\ude6d\000\udb40\ude28\ud853\udf31'\000\000\udbf7\ude04\uda68\udde2\udbf4\udc2a\u7664\ud82a\udd83\ud8fb\ude75\ud8d4\udfa8\ud9be\udd01\udae7\udec7\ud932\udf49\udaa8\udc63\ud9ad\udffb\uda05\udc93\ud995\udfa6\uda5b\udfe8\ud973\udee7\uda98\udc6d\udaf6\udd20\ua4fc\udb24\ude13\ud810\udc28\udaf0\udd12\udb65\udd82\udb19\udc1c\ud9e3\udf33\udac1\udf52\ud84c\udc83\uda59\udfff\ud9cd\udf79\uda3e\ude11\udb79\ude62\udb7d\uded4\udb7d\udd74\ud9c1\udcda\uda2b\udeda\ud867\udc70\ud856\udd72\ud964\udf89\uda65\udefa\ud903\udc2a\ud812\udf07\udaab\udd5e\ud8f7\udde8\uda6f\udd5c\ud8b7\udc47\ud848\udd14\ud809\ude2c\ud979\ude73\ud82d\udd74\ud868\uddd6\ud924\ude30\udab7\udc03\ud83c\udd40\ud8b1\udd7a\ud979\udcfd\udbe5\ude34\uda63\uddfe\ud97a\udd9b\udb9c\ude1d\ud8d8\udcc4\ud9b3\udd65\udad6\udc59\ud897\udcb7\ud9b0\udd99]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("K\uda47\udc4d\000\uda87\udf9e\udae3\udd6f\uda9d\udc04K\udbc8\udf04\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[K\uda47\udc4d\000\uda87\udf9e\udae3\udd6f\uda9d\udc04K\udbc8\udf04\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    Object r = org.apache.commons.lang3.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
}
