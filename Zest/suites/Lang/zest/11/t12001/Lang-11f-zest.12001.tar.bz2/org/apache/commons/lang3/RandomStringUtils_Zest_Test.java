package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class RandomStringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 9, 2, 16, "\ud8d6\udc46\ud96c\udd28\ud813\uddfb\ud8b2\uddb9\uda0e\udc5a\ud9e6\udc43\ud9ed\udcee\udb41\udd87\udaf4\udf4c\uda1e\udc25\udbe1\ude7b\udae7\udd4e\udbe2\udfe6", "\u0191\u1fbd\ua0dd\ua3ba\u64ca\ub26f\ub014\u7bd7\u631f\u5f3f\u128c\ubbda\u01e1\u594d\u25cb\u1aec\u7d83\ua8aa", "\ud901\udf0f\u5258\udbc2\udccd",
        0, 44230, -526672994, 277239732075680631L, 64422L, false, true, (char) 41474, (char) 26917,
        Double.longBitsToDouble(0x3fe486f0fc487575L), Double.longBitsToDouble(0x3febf4684147cb5dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 14, 0, "", "\u6ba0", "\ud9e6\udc43\ud812\ude34\ud800\udc6e\000\uda1d\udf32\udad1\udc93\ud9e2\udc1d\udbbc\udefb\u5366\udad3\udeb8\ud8ce\udc7c\ud8aa\udcb0\udad7\udc32\ud93c\ude3e\udb8f\udddf\uda87\udc90\000\000",
        -5, 3008, 478490891, -5444433877358877153L, 63580L, true, false, (char) 37864, (char) 0,
        Double.longBitsToDouble(0x3e47140000000000L), Double.longBitsToDouble(0x3fdb5c5de000cee2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 6, 15, "\ud8d6\udc46\ud96c\udd28\ud813\uddfb\ud8cb\udea5\uda06\udfdc\ud9e6\udc43\uda3d\udc2e\ud800\udc6e", "\u286e\u5018\u90d8\u6f16\ud6fe\u0191\u4008", "\udb8f\udddf\uda87\udc90\ud84d\udf9f\ud873\udc14\uda7a\udf51\ud880\udc2e",
        16, 18956, -739514849, 3945760647091526476L, 63580L, true, true, (char) 37987, (char) 46758,
        Double.longBitsToDouble(0x3feda0bad5c538f5L), Double.longBitsToDouble(0x3fdb5c5de53acee2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 7, 14, "\ud8bf\uddfb\udb99\udfcb\uda8e\udc11\ud840\udfb2\ud9dc\udec2\uda58\udf33\ud9e3\ude4c\ueec7\ud8e8\udd91\udb34\udc9d\udb8f\ude16\ud9e2\udc1d", "\uab7a\u371e\u18ec\ud55c\u9a2a\u64ca\u1070\ud02a\u114c\uc4f3\ud133\u5ad8\ud3de\u77b6\u4d5b\u2b06\u4374\u1c3a\ua82d\u8acf\u3d79\u8f35\u1214\u8c19\u2afb\u45da\u4447", "\udaaa\udfad\ud8b6\uddfc\ud87d\udd36\ud8b2\udeb4\ud9bb\udcd5\ud948\udef7",
        9, 99092, 545064148, -7172984312440708503L, -51305L, true, true, (char) 9945, (char) 49346,
        Double.longBitsToDouble(0x3fede524ec2c7171L), Double.longBitsToDouble(0x3fed4bd1ff281b36L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 2, 12, "\ud8d6\udc46\ud96c\udd28\ud813\uddfb\ud8cb\udea5\uda06\udfdc\ud9e6\udc43\ud812\ude34\ud800\udc6e", "\u286e", "\ud85b\ude69\udad3\udf6d\ud900\udf7c\u00b9\u00ae\ud93e\udd3e\udb8f\udddf\000",
        -5, -1000, 0, 7313311432677077259L, -93375L, true, false, (char) 21006, (char) 58564,
        Double.longBitsToDouble(0x3fe7e1b4e3f3ea4eL), Double.longBitsToDouble(0x3f4b6f6400000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 2, 12, "\ud8d6\udc46\ud96c\udd28\ud813\uddfb\ud8cb\udea5\ud814\udce3\ud92e\udde8\ud812\ude34\ud800\udc6e", "\u286e\u16fa\u914c\u8825\u7c44\u0194\u2b4a", "\udb0d\udeae\uda80\udd4c\ud84d\udf9f\ud873\udc14\uda7a\udf51\ud87f\udfff",
        -2, 1253, -751092386, 3945760647091526476L, 63580L, true, true, (char) 37987, (char) 46758,
        Double.longBitsToDouble(0x3feda0bad5c538f5L), Double.longBitsToDouble(0x3fe1bec8129dd0d0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 2, 12, "\udbe4\udeee\ud96c\udd28\ud813\uddfb\ud8cb\udea5\uda06\udfdc\ud9e6\udc43\ud812\ude34\ud800\udc6e", "\u286e\u5018\u90d8\u6f16\ud6fe\u0747\u4ec6", "\udb8f\udddf",
        14, 2217, 59120607, 7425394820308146739L, -2660L, true, false, (char) 64594, (char) 21006,
        Double.longBitsToDouble(0x3fe15154defc369cL), Double.longBitsToDouble(0x3fef9f5271e8db7bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 2, 12, "\ud9bb\udc93", "\u2415\u121e\u435a\ud7d4\u3e73\u882c", "\ud9e2\udc1d\udbbc\udefb",
        -2, 27725, -28587114, -41965364807716178L, 68025L, false, false, (char) 52230, (char) 41416,
        Double.longBitsToDouble(0x3fd3f0386466ce18L), Double.longBitsToDouble(0x3fd0b657e1e6b50aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.RandomStringUtils:@?\012",
        Z.run(T, 1, 11, 2, 12, "\ud8d6\udc46\ud96c\udd28\ud813\uddfb\ud8cb\udea5\ud9fe\udc01\ud9e6\udc43\ud812\ude34\ud800\udc6e", "\u286e\u5018\u90d8\uaf81\ud68e\u0191\u4008", "\udb8f\udddf\uda87\udc90\ud84d\udf9f\ud873\udc14\ud93d\udd73\udac8\ude4d",
        30, 18956, -739514849, 3945760647091526476L, 63580L, false, true, (char) 19281, (char) 41993,
        Double.longBitsToDouble(0x3fe381c14daa929cL), Double.longBitsToDouble(0x3fdb5c5de53acee2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.RandomStringUtils|random|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,boolean,boolean|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,[C|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean,[C|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean,[C,java.util.Random|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,java.lang.String|static",
    "M|org.apache.commons.lang3.RandomStringUtils|randomAlphabetic|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|randomAlphanumeric|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|randomAscii|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|randomNumeric|int|static",
    "C|org.apache.commons.lang3.RandomStringUtils|<init>|",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,boolean,boolean|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,[C|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean,[C|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean,[C,java.util.Random|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
