package org.apache.commons.lang.text;
import org.junit.Test;
import static org.junit.Assert.*;
public class ExtendedMessageFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1743\u4e4b\u2d56\u1e9b\u8559\u018e", "\ud8cf\udf22\udb71\udf97\uda98\udfb8\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34",
        40, 26864, -428875490, -828997797378511883L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b881466L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1708\u4e4b\u2d56\u1e9b\u8559\u018e", "\ud8cf\udf22\udb71\udf97\uda98\udfb8\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34",
        40, 26864, -428875490, -828997797378511883L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b881466L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 3, 12, 9, "\udb1a\udf97\ud898\udd5e\udb63\udc01\ud9b0\udc23\udbcb\udf9c\ud8c6\udc70\uda4c\ude3c\ud97f\uddb1\ud80c\ude97\ud8b6\ude86\udadf\udfce\udaed\uddc1", "\ub012", "\uda7e\ude68\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\ud911\udd6a\ud922\udc31\ud8ce\udd8b\ud8fd\udcfc\ud95b\udf34\u21e6\ud945\udd81\ud928\ude7a\ud999\ude37\uda4d\udfb5\udab5\udcf7\u7e09\ud8c2\udddb\udb04\ude68\ud8f8\udf9d\udb8e\ude55\ud805\udd83\ud9c4\udc5b\ud9c1\udc70\udb65\udca8\udbff\udd0a\ud8ee\udecc\udafb\ude3f\udba1\udd75\ud82d\uddc4\uda66\udf45\ud917\ude2b\ud8a3\udf50\ud81d\ude63\udb20\udd11\uda53\udd5d\ud8e2\ude4f\ud900\ude95\ud989\udfc2\udbba\uddf7\ud9d3\udf4c\udb6d\udfd9\u673b\udaa0\udc21\ud947\ude33\udbb8\udda9\udaaa\udf5d\uda23\udcec\ud953\ude47\udaaf\udce2\udbb2\udde8\udaca\uded4\ud862\udef6\ud81d\ude12\ud957\udd7e\ud97a\udc52\ud868\udcc6\ud8ff\ude46\ud8d0\udd88\ub7a6\uda47\udd4b",
        38, 12260, -1808697129, -1738612048963214537L, -8356L, false, true, (char) 3507, (char) 35568,
        Double.longBitsToDouble(0x3f833345c4ea2780L), Double.longBitsToDouble(0x3fc1a79483136610L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 15, 10, 9, "\ud9c9\udd97\uda3a\ude35\udb54\udee0", "\u6c3f\u32cb\u3101\u7eb1\u6174\u1e9b\u5c21\uc591", "\ud8cf\udf22\udaab\udd2a\uda98\udee9\ud91c\ude68",
        13, 37737, -1669090932, 1470651403512850982L, -99923L, false, false, (char) 1526, (char) 17175,
        Double.longBitsToDouble(0x3fd1e78bbdcbccdeL), Double.longBitsToDouble(0x3fd56912d9d04768L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1743\u5ef0\u2de0\u1e9b\u8559\u018e\u0abb\ub012", "\uda98\udfb8\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\udab5\udcfb\ud874\ude6c\ud8f6\udde7\ud95b\udf34\uda1a\ude4d\ud9ba\udc2d\ud935\udf9c\udb5b\ude38\uda4f\uddb2\u806e\udb75\uddd7\ud88f\ude6b\ud8f5\udc10\ud8f8\udf9d\udb8e\ude55\ud805\udd83\ud9c4\udc5b\udbce\uddfa\udb2d\udc3b\ud995\udcbb\udb09\udf20\ud8a9\udc2d\udbe5\udca8\ud9f7\udcac\ud90e\udec9\udb63\ude17\ud9fc\udc9c\udad6\udc4b\udaa7\udcce\ud8ab\udc79\u24eb\u9de3\udbf7\udffb\uc01d\ud917\udfc7\uda10\udcd7\ud888\udc24\udb89\udf6e\udb5c\udfad\ud942\uddc2\uda0c\udf78\ud803\udc62\ud9c6\udfee\ud987\udfe9\ud85a\udeb0\uda35\ude48\ud8c8\udce3\ud876\ude4c\ud939\udea2\ud9e3\udefc\u3073\udb05\udf68\uda91\udd10\ud961\udddd\udb75\udcdd",
        56, 88573, -55881592, -3679390849297936657L, 78591L, true, false, (char) 39919, (char) 58710,
        Double.longBitsToDouble(0x3fe352254bf53879L), Double.longBitsToDouble(0x3fb978a76c36d4c8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01", "\uc027\u0e6d\u1743\u4e4b\u2d56\u1e9b\u8559\u018e\u60db\ub012\u93a1\ucd54\u0091\u88e7\u245d\u46bd\u0ea2\ucf28\u92d0\u791b\uaf03\uc1dc\ud6b0\u4028\ubad1\u4942\u0f6c", "\ud887\ude28",
        51, 53680, 171141564, 8956557688788182913L, 13114L, true, true, (char) 37371, (char) 49863,
        Double.longBitsToDouble(0x3fe32537bf248017L), Double.longBitsToDouble(0x3fe1969e066a1260L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 3, "\udb1a\udf97", "\u2d06\uc08f\u79eb", "\ud887\udce4\ud8b6\ude86\ud81e\udfad",
        42, 66669, 1959196036, -6859712179290089754L, -60753L, true, true, (char) 46068, (char) 27180,
        Double.longBitsToDouble(0x3fe13169189bded0L), Double.longBitsToDouble(0x3fae8341a4033890L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 8, 9, "\ud9c1\udd24\udb34\udeef\udaff\udc08\udacc\uddbe\udb29\udef8\ud8c6\udc38\uda21\udc86\udb79\ude2d\ud80d\udce7\ud8b6\ude86\ud81e\udfad\udaed\uddc1\ud934\udf85\udb11\udfc4", "\ucd54\u0091\u88e7", "\ud9be\udf94\ud893\udf99\ud944\ude3f\u63f2\ud8f6\ude0d\ud95b\udf34\uda1a\ude4d\ud98e\udf46",
        30, 4718, 1068248053, 1155829608389489507L, -84199L, true, false, (char) 47228, (char) 8311,
        Double.longBitsToDouble(0x3fee57dd94daf184L), Double.longBitsToDouble(0x3fa5e12881761690L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 1, 8, 9, "\ud9d8\udd7e\uda20\ude3f\udb63\udc77", "\u79eb\u4a92\u1573\u4e4b\u2d56\u2191\u3726\u629f", "\udaa5\udd34\uda99\udc94\u8c3f\ud9d1\udef0\uda46\ude22\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34",
        40, 26864, 1550835998, -828998149565830155L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b67b666L), Double.longBitsToDouble(0x3fee54d8b993fe84L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1743\u4e4b\u2d56\u1e9b\u8559\u018e", "\ud8cf\udf22\udb71\udf97\ud8ee\udca8\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34",
        54, 26864, -428875490, -828997797378511883L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0f881466L), Double.longBitsToDouble(0x3fee57df1fc84d84L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01\ud9b0\udc2e\udbd4\udc9c\ud8c6\udc70\u1159\ud943\udd7d\ud80d\udce7\ud8b6\ude86\udb27\udf6d\uec51\ud934\udf85\u45e4\udab7\udfcf\ud857\ude8d\udb72\udc01\uda98\udfb8\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\udb5d\udd7d\ud922\udc31", "\uc1dc\ud6b0\u4028\ubad1\u7f41\u0f6c\ubae0\u3be6\ub8d6\ub777\ua44c\u0dd3", "\udaee\udfc9\ud895\udd8b\uda37\udcb8\uda07\ude52\ud990\uddd2\ud8de\udcb6\ud94b\ude9f\ud97b\udcea\uda0c\udff5\ud948\uddf8\ud9cc\udf29\uda8c\udd44\ud89a\udf35\ud9bb\udd34\ud8d0\udd9a\ud937\udd68\u5359\uda2c\udd79\ud9de\udda5\udbe5\udc6d\udac1\ude88\ud9a2\ude46\udbc9\udc59\ud9a6\udcda\udaba\udf0d",
        26, 40181, 966240195, 8541984177707810638L, -8561L, false, false, (char) 10612, (char) 60920,
        Double.longBitsToDouble(0x3fc347f2992b1c00L), Double.longBitsToDouble(0x3febbb1ee1c21555L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.String:\u79eb\u0e6d\u74c9\u9c68\uc436\u0439\u0771\u018e |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 5, 8, 9, "\uda90\udcbc\ud8af\udca5\udb63\udc01", "\u79eb\u0e6d\u74c9\u9c68\uc436\u0439\u0771\u018e", "\ud8c2\udd22\uda16\udd69\uda98\udef7\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34",
        40, 26864, -428875490, -828997799130132531L, -47637L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b881466L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 13, 8, 9, "\udb2d\udd97\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1743\u4e4b\u2d56\u1e9b\u8559\u018e", "\ud8cf\udf22\udb71\udf97\uda98\udfb8\ud91c\ude68\ud899\ude22\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\udb4c\udc74",
        -1, 62945, -428875490, -828997797378511883L, -47619L, false, false, (char) 31372, (char) 22782,
        Double.longBitsToDouble(0x3fd6909fcb881466L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udb1a\udf97", "\uaf89\uc08f\u79eb", "\ud80d\udce7\ud8b6\ude86\ud81e\udfad",
        42, 21598, -2100930778, -6859711316051994906L, 3820L, true, true, (char) 46068, (char) 0,
        Double.longBitsToDouble(0x3fe13168069bded0L), Double.longBitsToDouble(0x3fed9e96e27627ebL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1743\u4e4b\u2d56\u1e9b\u8559\u018e", "\ud8cf\udf22\udb71\udf97\uda98\udfb8\ud91c\ude68\ud89e\ude27\ud94c\udff5",
        58, 22129, -556783066, -3252532849455398989L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b881466L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 1, 9, "\ud86f\udf01", "\u30b9\ub195\u6cb5\u0e6d\u1743\u4e4b\u2d56\u1e9b", "\udb11\udfc4",
        4, 36038, -635936938, 5328994168349386424L, -31439L, true, false, (char) 27180, (char) 22345,
        Double.longBitsToDouble(0x3fec9b2e842dd7e7L), Double.longBitsToDouble(0x3fe76bee8dc6507eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 8, 9, "\udb1a\udfb8\ud943\udd5b\udb63\udc01", "\u79eb\u0e6d\u1743\u4e4b\u4220\u1e9b\u8559\u018e", "\ud8cf\udf22\ud868\udc1f\ud94f\udfc1\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34",
        40, 26864, -432116706, -828997797378511883L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b881466L), Double.longBitsToDouble(0x3feca7dd97375e09L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 0, 10, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u39e3\u0de8\u1743\u4e4b\u2d56\u1e9b\ub243\u8742\u0b3f\u1d69\u9341\ucd54\u7790\u2b3f\u912e\u46cc", "\ud922\udc31\u63f2",
        28, 93118, 1380743544, -6778579275307733804L, -25635L, false, false, (char) 59245, (char) 45591,
        Double.longBitsToDouble(0x3fc72cba6c77d344L), Double.longBitsToDouble(0x3fdbcf4f4b881466L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 9, "\udb1a\udf97", "\u353d\000\000", "\ud80d\udce7\ud8b6\ude86\ud81e\udfad",
        42, 21598, -2100930778, 115341346734080L, 3820L, true, true, (char) 46068, (char) 27180,
        Double.longBitsToDouble(0x3fe131691e9bded0L), Double.longBitsToDouble(0x3fed9e96e27627ebL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 10, 8, 9, "\udb1a\udf97", "\u5197\uc08f\u79eb", "\ud80d\udce7\ud88e\udd92\ud81e\udfad",
        -2, 21598, -2100930778, -6859711316001663258L, -82708L, true, true, (char) 46068, (char) 5479,
        Double.longBitsToDouble(0x3fe13115569bded0L), Double.longBitsToDouble(0x3fed9e96e27627ebL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\000", "\uaf89\u4760\000", "\ud80d\udce7\ud8b6\ude86\ud81e\udfad",
        37, 43166, 12998438, 0L, -99860L, false, false, (char) 0, (char) 27049,
        Double.longBitsToDouble(0x3fe13168069bded0L), Double.longBitsToDouble(0x3fed9e96e00027ebL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udbd6\udf5c\ud83f\ude96\udaba\ude07\udaca\udc5b\udbd4\udc9f\ud8c6\udc70\ufd28\ud955\udcf3\ud80d\udce7\ud8b6\ude86\ud81e\udfad\udaed\uddc1\ud934\udf85\udb11\udfc4\udb20\udf4a\ud8cf\udf22\udbe6\uddd1\udb7d\udfd6\udbc9\udd27\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34\uda1a\ude4d\ud9ba\udc2d\ud935\udf9c\ud999\ude37\uda75\udc50\ud97b\udcf1\udb86\uddc7\ud887\ude28\ud8f5\udc10\ud8f8\udf9d\udb8e\ude55\ud805\udd83\ud9c4\udc5b\ud88b\udf37\udb25\udd24\ud88e\udc5c\udb69\udcaa", "\u7a62", "\u4412\ud80a\udf4a\ud9f4\ude7f\udaca\udc13\udaeb\udfd3\udabd\udd1f\ud96c\udfbb\ub062\udba2\udd2b\udad0\udecd\ud810\udee2\ud9f6\uddd6\ud9d8\udefc\ud98b\udd69\ud1c5\ud96a\udf55\ud9d4\ude56\udbae\udedc\ud8c5\udd1b\ud960\udcb5",
        37, 50472, -1478310627, -3104725090301132135L, -99860L, false, false, (char) 40542, (char) 655,
        Double.longBitsToDouble(0x3fe1939229eb4325L), Double.longBitsToDouble(0x3fa6b1b9ac0c0e10L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 2, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1743\u4e4b\u2d56\u1e9b\u8559\u018e", "\ud8cf\udf22\udb71\udf97\uda98\udfb8\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\uece9\uda84\udf94\u63f2\ud8f6\ude0d\udb94\ude9b",
        40, 15816, -1532068884, -799627200395727883L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b881466L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 2, 11, 9, "\uda6d\udea0\u8e3a\udb63\udc01", "\ua192\u0e6d\u1743\u4e4b\u2d56\u1e51\ucf59\u018e", "\udbbf\udeb6\udb71\udf97\uda98\udfb8\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34\uda1a\ude4d\ud9ba\udc2d\ud935\udf9c\uda0e\udfb1\uda4f\udc45\u806e\udb75\uddd7",
        6, 83384, -2134842595, 735047420294075844L, 2375L, false, true, (char) 20242, (char) 7630,
        Double.longBitsToDouble(0x3fd75c247350dd68L), Double.longBitsToDouble(0x3fef8036a34f427aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\000\000\000", "\u79eb", "\udb5e\udf8f",
        36, 21865, -601907233, -1149450941204375770L, 8826L, true, true, (char) 33781, (char) 14631,
        Double.longBitsToDouble(0x3ec2ef4400000000L), Double.longBitsToDouble(0x3eba400000000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 0, "\ud854\udfd4", "", "\ud8c6\udc70",
        8, 44696, -1885981817, -4426530300494900239L, 69753L, false, false, (char) 25417, (char) 32477,
        Double.longBitsToDouble(0x3e4630fa5c000000L), Double.longBitsToDouble(0x3fee8a71498c0269L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 8, 11, "\udaf4\ude25\ud8d2\uddc8\udb57\ude1f", "\u60eb\ud037\u33d2\u9b7f\u2d56\u830c\u2fef\u5079", "\ud904\udfc8\uda2f\udec9\uda98\udfb8\udb94\ude64\ud89e\udddc\ud94c\udff5\udb7d\udc7a\udb8f\udc85\ud955\udfc5\u63f2",
        28, 93118, -1811434120, 8699812155789114330L, 73426L, false, false, (char) 19173, (char) 44324,
        Double.longBitsToDouble(0x3fdbc80c0b881466L), Double.longBitsToDouble(0x3fee57dd92c84d84L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\udb1a\udf97", "\000\ubf9e\u79eb", "\000",
        -2, 77945, -601907233, -1149450941204375770L, 8826L, true, true, (char) 33781, (char) 14631,
        Double.longBitsToDouble(0x3fd8c3e977a29c52L), Double.longBitsToDouble(0x3fd8c0269b533906L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 13, 15, 9, "\udb1a\udf97\ud898\udd44\uda25\udc02", "\ua60b\u0e6d\u1027\u4eb9\u2dda\u1e9b\u8559\u018e", "\ud912\ude13\ud9b2\udeb7\udad6\udce3\ud90e\udd0c\uda90\udfea\ud94c\udff5\ud832\udfaf\uda64\udcd1\ud826\udffd\udad7\udd6f",
        5, 76635, -711373433, 6323642186275798019L, -64311L, false, false, (char) 55868, (char) 38749,
        Double.longBitsToDouble(0x3fd0b87cc234cc26L), Double.longBitsToDouble(0x3fef3e3d9f10a089L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 12, "\udbff\uddb8\ud884\udfef\ud8e5\udc02\ud9b0\udc2e\udbd4\udc9c\ud8c6\udc70\uda4c\ude3c", "\u2d56\u1e9b\u8559\uc89c", "\ud8f9\udc22\udb71\udf97\udac9\udcf1\ud91c\ude9f\ud98a\udf7e\ud94c\udff5\ud843\udcaf\u1852\uda7a\udcdd\udb40\udfe5",
        28, 93118, 1385936248, 8699812155789140254L, -47619L, false, false, (char) 40372, (char) 4136,
        Double.longBitsToDouble(0x3fdbc80c06e3cd88L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 3, 12, 9, "\uda8d\udce8\ud898\uddbb\udb63\udc01\ud9b0\udc23\udbcb\udf9c\u33f3\uda4c\ude3c\ud938\ude8e\ub512\ud8b6\ude86\ud897\ude89\udaab\uddbe", "\ub012", "\uda7e\ude68\ud91c\ude68\ud88d\udf40\ud94c\udff5\ud832\udfaf\ud88e\udd09\ud922\ude99\ud8ce\udd8b\ud8fd\udcfc\ud95b\udf34\ud993\ude11\ud900\udd9b\ud9f2\udd04\ud999\ude41\uda4d\udfb5\ud89d\udd49\u7e09\ud8c2\udddb\udb04\ude68\ud8f8\udf9d\udb8e\ude55\ud805\udd83\ud9c4\udc5b\ud900\udce2\udb65\udca8\udbff\udd0a\ud8ee\udf39\udafb\ude3f\udba1\udd75\ud82d\uddc4\uda66\udf45\ud917\ude2b\ud8a3\udf50\ud81d\ude63\udb20\udd11\uda53\udd5d\ud8e2\ude4f\ud8fa\ude11\ud978\udd8b\udbdc\udceb\ud9d3\udf4c\udbb4\udf45\ud8f0\udeea\udaa0\udc21\ud947\ude33\udbb8\udda9\ud990\udf30\udbe1\udd70\ud9f8\udea6\ud972\udf78\udbb2\udde8\udaca\uded4\ud862\udef6\ud81d\ude12\ud957\udd7e\ud97a\udc52\ud904\udd6b\ud8dc\udd46\ud8d0\udd88\ub7a6\uda47\udd4b",
        38, 83412, -1808697129, -1738612048963214537L, -8356L, false, true, (char) 3507, (char) 35568,
        Double.longBitsToDouble(0x3f833344c4ea2780L), Double.longBitsToDouble(0x3fc1a79488ddbb34L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:org.apache.commons.lang.text.ExtendedMessageFormat@0\012",
        Z.run(T, 1, 3, 12, 9, "", "\u51cd\uaf7e", "\uda4c\ude3c",
        50, 90591, -1030631899, -5054564969075466273L, 8762L, true, false, (char) 63411, (char) 53320,
        Double.longBitsToDouble(0x3fd8d6844d70a4deL), Double.longBitsToDouble(0x3fd8c3e977a29c52L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\ub568 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 5, 12, 9, "\udb1a\udf97\ud898\udd5e\udb63\udc01\ud9b0\udc23\udbcb\udf9c\ud8c6\udc70\uda4c\ude3c\ud97f\uddb1\ud80c\ude97\ud8b6\ude86\udadf\udfce\udaed\udd8e", "\ub568", "\uda7e\ude68\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\ud911\udd6a\ud922\udc31\ud8ce\udd8b\ud8fd\udcfc\ud95b\udf34\u21e6\ud945\udd81\ud928\ude7a\ud999\ude37\uda4d\udfb5\udab5\udcf7\u7e09\ud8c2\udddb\udb04\ude68",
        45, 46564, -72215100, 5585725543839089096L, -21783L, true, false, (char) 53233, (char) 28381,
        Double.longBitsToDouble(0x3fb8cf171f1b10f8L), Double.longBitsToDouble(0x3fe601d12e643db7L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\u22f3\u93a1\u67df\u6f40\u88e7\u6a2f\u46ac\uaba2\u3106\uafbf\ua9b3\u7d20\uc1dc\u3daa\ud63a\u85af\u4942\u0f6c\u8e23\u7e09\ucc8a\u9e7b\ua44c\u0dd3\u00aa\u5023\u265a\u2442\u206d\u09f3\u9856\u134f\u0ee9\ucf40\u3cae\uc8cc\u63e5\u0b60\u2c5b\u3397\u259c\u8f44\u8ad7\u8150 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 5, 12, 9, "\udb1a\udf97\ud898\udd5e\udb63\udc01\ud9b0\udc23\udbcb\udf9c\ud8c6\udc70\uda4c\ude3c\ud97f\uddb1\ud80c\ude97\ud8b6\ude86\udac2\udcc5\udaed\uddc1", "\u22f3\u93a1\u67df\u6f40\u88e7\u6a2f\u46ac\uaba2\u3106\uafbf\ua9b3\u7d20\uc1dc\u3daa\ud63a\u85af\u4942\u0f6c\u8e23\u7e09\ucc8a\u9e7b\ua44c\u0dd3\u00aa\u5023\u265a\u2442\u206d\u09f3\u9856\u134f\u0ee9\ucf40\u3cae\uc8cc\u63e5\u0b60\u2c5b\u3397\u259c\u8f44\u8ad7\u8150", "\udaa0\udc21\ud947\ude33\udbb8\udda9\udaaa\udf5d\uda23\udcec\ud953\ude47\udaaf\udce2\udbb2\udde8\udaca\uded4\ud862\udf03\ud81d\ude12\ud957\udd7e\ud97a\udc52\ud868\udcc6\ud8ff\ude46",
        55, 90405, -414138688, 2642233249627930188L, 41170L, true, true, (char) 21552, (char) 48014,
        Double.longBitsToDouble(0x3feb108a69ba7bf9L), Double.longBitsToDouble(0x3fade55ac0999a20L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 3, 12, 9, "\udb1a\udf97\ud898\udd5e\udb63\udc01\udb74\udec4\udbcb\udf9c\ud8c6\udc70\uda4c\ude3c\ud97f\uddb1\ud80c\ude97\ud8b6\ude86\udadf\udfce\udaed\uddc1", "\ub012\u93a1", "\ud91c\ude68",
        13, 37737, -1669090932, 3301880383121926694L, -67735L, true, true, (char) 33309, (char) 49975,
        Double.longBitsToDouble(0x3fdbc8055b881466L), Double.longBitsToDouble(0x3fee57dd91c84d84L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 15, 10, 9, "\ud9c9\udd97\uda3a\ude35\udb54\udee0", "\u2b85\u3840\u4911\u7eb1\u6174\u43ef\uad17\u078f", "\ud8dc\udcc8\uc52e\uda98\udee9\udb3b\udd38",
        7, 71155, -1669090932, -8473296573721204186L, -99923L, false, false, (char) 44451, (char) 4535,
        Double.longBitsToDouble(0x3fd1e78bbdcbccdeL), Double.longBitsToDouble(0x3fd56912d9032168L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\u7eb1\u6174\u1b30\ud5ab\uc591\ucc51 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 5, 3, 9, "\ud9c9\udd97\uda3a\ude35\udb54\udee0\ud9b0\udc2e\udbd4\udc9c\ud88c\ude36", "\u7eb1\u6174\u1b30\ud5ab\uc591\ucc51", "\udaab\udd2a\uda98\udee9\ud91c\ude68",
        13, 37737, -1669090932, 7780757432207119870L, 1350L, false, false, (char) 1526, (char) 17175,
        Double.longBitsToDouble(0x3fc26f177b9799bcL), Double.longBitsToDouble(0x3fd56912d9d04768L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\ud9c9\udd97\uda3a\ude35\udb54\udee0 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 14, 13, 9, "\ud9c9\udd97\uda3a\ude35\udb54\udee0", "\u6c3f\u32cb\u3101\u7eb1\u6174\u1e9b\u5c21\uc591", "\ud8cf\udf22\udaab\udd2a\uda98\udee9\ud91c\ude68",
        13, 37737, -1669090932, 1470651403512850982L, -99923L, false, false, (char) 1526, (char) 17175,
        Double.longBitsToDouble(0x3fd1e78bbdcbccdeL), Double.longBitsToDouble(0x3fd56912d9d04768L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\u7810\u3325\u922f\u7f6b\u6174\u1e9b\u5c21\u0cb7\ucdfb\ub012\u93a1\u9bcf\ud7c1\u88e7\u75f4\u18d4\uc845\u9950\ua32f\u791b\uaf03 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 1, 9, "\ud9c9\udd97\ud83e\ude78\ud876\udc64", "\u7810\u3325\u922f\u7f6b\u6174\u1e9b\u5c21\u0cb7\ucdfb\ub012\u93a1\u9bcf\ud7c1\u88e7\u75f4\u18d4\uc845\u9950\ua32f\u791b\uaf03", "\uda42\ude8e\udb65\udd1f\ud913\ude69\ud910\ude89\ud8ad\udd93\uda2f\uddd9\u47a7\ud9e0\ude30\ud81f\udd72\ud9fd\udc3c\ud92c\udc8f\udad4\udcc1\udacb\udfab\udb80\udcb1\uda3c\udeba\uda74\udf10\uda91\udfe7\udaad\ude9f\ud8be\udcaf\ud8c6\udce5",
        53, 91601, 1435111018, 8441063340325778810L, 64089L, true, false, (char) 41729, (char) 13609,
        Double.longBitsToDouble(0x3fe95a55ab8027b9L), Double.longBitsToDouble(0x3fddf839ed89b816L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 3, 9, "\ud9ca\ude8e\uda72\udf1c\ud989\udfe8", "\u3684\u6190\u8677\uaa42\ua2a4\u1e9b\u5c21\uc591\u25c5\ub130\u39ba\u6b5c\uaf75\u84e3\u77aa", "\udb9b\udedc\ud922\udc31",
        51, 42270, -934792322, -4520209977511579316L, 18524L, false, true, (char) 30876, (char) 30519,
        Double.longBitsToDouble(0x3fe7a3ec53aef8ecL), Double.longBitsToDouble(0x3fdce74250de49ecL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:\uc1dc\ud6b0\u1876 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 5, 8, 9, "\udb7f\udf51\ud898\udd61\uda88\udc40\uda4e\udeef\udb62\uddaa\udbdf\ude59\ud84c\udd9d\ud9b5\udd66\ud80d\udce6\uda7c\udfa8\ud94c\udef6\udaed\uddc1\ud935\udccf\udb2d\udd08\udb20\udf4a\ud8cf\udf22\udb71\udf97\uda9b\udc2d\ud91c\ude68\ud97e\udc4e\uda24\ude32\udbc9\ude64\u0c52\ud922\udc31", "\uc1dc\ud6b0\u1876", "\ud966\udfb7\uda0b\ude02",
        39, 9839, 1976637093, -8512491251839299567L, 88559L, false, true, (char) 16133, (char) 28291,
        Double.longBitsToDouble(0x3fbae3eec0c58008L), Double.longBitsToDouble(0x3fc477571547e0c0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 8, 9, "\u0bcc", "", "",
        21, 1171, 6083020, -8100230805716873691L, -13286L, true, false, (char) 0, (char) 24320,
        Double.longBitsToDouble(0x3fe6e828c600526fL), Double.longBitsToDouble(0x3f2f4bbe24e00000L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\u79eb\u4a92\u6372\u4e4b\u2d56\u2191\u3726\u629f |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 2, 9, "\ud9d8\udd7e\uda20\ude3f\udb63\udc77", "\u79eb\u4a92\u6372\u4e4b\u2d56\u2191\u3726\u629f", "\udaa5\udd34\uda99\udc94\u8c3f\ud9d1\udef0\uda51\udf22\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34",
        40, 26864, 1550835998, -828998149565830155L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b67b666L), Double.longBitsToDouble(0x3fee54d8b993fe84L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:\u74c9\u9c68\uc436\u0439\u0771\u018e\u0abb\ub012\u5da1 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 9, "\uda86\udff8\ud8af\udca5\udb63\udc01\ud9b0\udc2e\ud8e9\udfa0", "\u74c9\u9c68\uc436\u0439\u0771\u018e\u0abb\ub012\u5da1", "\ub192\ud9db\udded\ud9e6\udd88\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\udb4b\udca9\uda1a\ude39\ud9ba\udc2d\udaf9\udd89\ud985\udf62\ud9d7\udd66\uda68\udef9\udb75\udde9\ud887\ude28\ud8f5\udc10\ud8f8\udf9d\udb8e\ude55\ud805\udd83\ud9c4\udc5b\u1215\ud815\udcce\ud8e9\ude7d\udbe7\udcfb\udba8\udc9a\udb7b\ude3b\udb8c\udee1\udbd7\udcab\ud860\udfc8\ud80b\udd9e\ud933\udd05\ud9ec\udf79\ud8b8\udcc0\udb38\udee0\udae7\udfff\udb11\udde2\ud8c1\udd97\ud97a\udf96\ud93f\udce0\ud937\udcc9\uda8e\udcbb\uda43\udd62\udb24\udddb",
        39, 79098, -111036315, -204404657734223669L, 86401L, true, false, (char) 11334, (char) 55221,
        Double.longBitsToDouble(0x3fed13f58da4090dL), Double.longBitsToDouble(0x3fc88bf8f438ec34L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String: |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 5, 8, 9, "\u73ef\ud8d6\udc0a\000", "", "\udb19\udf2c\ud842\udf9e\udb53\udfba\ud8f9\udd09\000\000\udaad\udf0b\000\ud8c2\udc3c",
        21, 44492, 1050142392, 5632197237571914705L, -87113L, false, false, (char) 36203, (char) 54159,
        Double.longBitsToDouble(0x3fe3b1380578507eL), Double.longBitsToDouble(0x3fd10520723cf176L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\u8f66\u1888\u897f\u4e96\u2d56\u1e9b\u9a1c\uc3ec\u0aa7\u1d69\u9341\uccf8\u7790\u3287\ud4e1\u46cc |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 10, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u8f66\u1888\u897f\u4e96\u2d56\u1e9b\u9a1c\uc3ec\u0aa7\u1d69\u9341\uccf8\u7790\u3287\ud4e1\u46cc", "\uda97\udf7c\udad0\udd3c",
        49, 93118, 1380743544, -6778579275307733804L, -25635L, false, false, (char) 59245, (char) 45591,
        Double.longBitsToDouble(0x3fbbb3f4d8efa688L), Double.longBitsToDouble(0x3fdbcf4f45881466L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 12, "\udbff\uddb8\ud884\udfef\ud8e5\udc02\ud9b0\udc2e\ud9c0\ude52\udb4c\udf2c\udaa2\udde1", "\u2d56\u1e9b\u165f\uc374", "\ud8f9\udc22\udb71\udf62\udac9\udcf1\ud84d\udd37",
        22, 72041, -1667042676, 3252669481259641382L, -99923L, false, true, (char) 47495, (char) 32848,
        Double.longBitsToDouble(0x3fe478ee46aaa3feL), Double.longBitsToDouble(0x3fe0bde760c4573eL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 2, 12, "\udbff\uddb8\ud884\udfef\ud8e5\udc02\ud9b0\udc2e\udbd4\udc9c\uda9d\udfab\uda49\udc1b", "\u2d56\u1e9b\u8559\uc89c", "\ud8f9\udc22\udb71\udf97\udac9\udcf1\ud91c\ude9f\ud98a\udf7e\ud94c\udff5\ud843\udcaf\u1852\uda7a\udcdd\udb40\udfe5",
        28, 93118, 1385936248, 8699812155789140254L, 83453L, false, false, (char) 40372, (char) 4136,
        Double.longBitsToDouble(0x3fdbc80c06e3cd88L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 12, "\udbff\uddb8\ud884\udfef\ud8e5\udc02\ud9b0\udc2e\udbd4\udc9c\ud8c6\udc70\uda4c\ude3c", "\u2d56\u1e9b\u8559\uc89c", "\ud8f9\udc22\udb71\udf97\udac9\udcf1\ud91c\ude9f\ud98a\udf7e\ud94c\udff5\udabb\udcab\u1852\uda7a\udcdd\udb40\udfe5",
        18, 26584, 1385895261, 8699812155789140254L, -47619L, false, false, (char) 40372, (char) 4136,
        Double.longBitsToDouble(0x3fdbc80c06e3cd88L), Double.longBitsToDouble(0x3fee57dd97c84d84L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udbff\uddb8\ud884\udfef\ud8e5\udc02\ud9b0\udc2e\udbd4\udc9c\ud8c6\udc70\uda4c\ude3c\ud9cd\ude5c\ud985\ude5c\ud8b6\ude86\ud829\udead\udaed\uddc1\uda03\ude4d\ud80d\udf73\udb20\uded7\ud8f9\udc22\udb71\udf97\udac9\udcf1\ud91c\ude9f\ud98a\udf7e\ud94c\udff5\ud843\udcaf\u1852\uda7a\udcdd\udb40\udfe5\ud8f6\ude0d\ud95b\udf34\ud8ec\ude56\ud9ba\udc2d\ud811\udc69\ud9c9\ude71\uda4d\udfb5\u806e\udb75\uddd7\ud887\ude28\uda1e\ude88\ud8f8\udf9d |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 5, 7, "\udbff\uddb8\ud884\udfef\ud8e5\udc02\ud9b0\udc2e\udbd4\udc9c\ud8c6\udc70\uda4c\ude3c\ud9cd\ude5c\ud985\ude5c\ud8b6\ude86\ud829\udead\udaed\uddc1\uda03\ude4d\ud80d\udf73\udb20\uded7\ud8f9\udc22\udb71\udf97\udac9\udcf1\ud91c\ude9f\ud98a\udf7e\ud94c\udff5\ud843\udcaf\u1852\uda7a\udcdd\udb40\udfe5\ud8f6\ude0d\ud95b\udf34\ud8ec\ude56\ud9ba\udc2d\ud811\udc69\ud9c9\ude71\uda4d\udfb5\u806e\udb75\uddd7\ud887\ude28\uda1e\ude88\ud8f8\udf9d", "\ubc66\u555c\u5dab\u523c\u6e71\u15ac\u3d7a\ud648\u1e47\u0c42\u7ed7\u0e19", "\ud826\udc4f\udb68\uddd3\ud820\udd02\ud97c\udd8e\ud846\ude20\uda25\udc1e\ud817\udea1",
        15, 8074, -401794032, -2369252916795744700L, -25685L, false, true, (char) 46315, (char) 63725,
        Double.longBitsToDouble(0x3fc3ecfef99ec898L), Double.longBitsToDouble(0x3fd3ab96aa654c8eL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 12, "\udbff\uddb8\udbaf\udc45\ud8e5\udc57\ud9b0\udc2e\udbd4\udc9c\ud8c6\udc70\uda4c\ude3c", "\u2d56\u1e9b\u8559\uc89c", "\ud8f9\udc22\udb71\udf97\udac9\udcf1\ud91c\ude9f\ud98a\udf7e\ud94c\udff5\ud843\udcaf\u1852\uda7a\udcdd\udb40\udfe5",
        28, 93118, 1385936248, 8699812155789140254L, -8105L, true, true, (char) 14195, (char) 53300,
        Double.longBitsToDouble(0x3fe6f2a8fd0a4d59L), Double.longBitsToDouble(0x3fecaf3cf0285fe3L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 15, 10, 9, "\udb05\udf15\udb37\ude35\udb54\udf22\ud9b0\udc2e\udbd4\udc9c\ud87c\udd5f\uda9a\udd03\ud9f1\udf4d\ud9aa\udda3\udad9\ude87\udac1\udc95\ud985\udee4\ud902\udd06\udaab\udd0f\udb20\udf4a\ud8dc\udcc8\uc52e\uda98\udee9\udb3b\udd38\ud9ca\udff8\u929e\udb32\udfff\uda08\udd9d\udbe9\ude7a\u63f2\ud8f6\ude0d\udbe4\udcf8\udb9c\udd0a\ud940\udca2\ud935\udf9c\ud824\udc5d\ud8ce\udc35\udb49\udf15\udb24\udcb1\ud94e\udd2c\udb56\uddfe\uda87\uddd0\ud972\udd23\ud850\udf57\uda30\udf4c\ud8d1\udc0f\uda39\udfe5\uda1c\udcc5\udb9e\udde7", "\u0e35\u7cba\ucc12\u321b\ua07b\u4a5c\u65bd\ua3c1\ub598\u2812\u78ff\u5dfe\u2c05\ud406\u6160\u6c25\ubdf4\u72a0\uca4f\u5eb3\u76c0\u4693\u38ef\u6d94\u1738", "\udb94\uddd8\uda42\udf57\udaf3\uddcc",
        21, 61728, 719157784, 7290573023972242572L, -68388L, true, false, (char) 49163, (char) 3207,
        Double.longBitsToDouble(0x3fdecdc22ae0d9f2L), Double.longBitsToDouble(0x3fd84201db3faebaL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 15, 15, 10, "\ud9c9\udd97\uda3a\ude35\udb54\udee0", "\u2b85\u3840\u4911\u7eb1\u212a\uad51\uad17\u078f", "\ud88b\udf19\uc52e\uda98\udee9\uda17\ude66\udaec\ude1e\uda88\udfe9\ud832\udfaf\udbd5\udeba\ud922\udc31\ud95e\udf73\ud9a6\udf7d\udbb7\ude22\udb9c\udd0a\udad6\udf2f\ud9a5\udcad\ud9af\udf10\udbae\udec9\udb8f\udc7d\ud83c\udd12\udaa6\udc45\uda3b\ude22\udb25\udf1b\ud9f1\udcb6\uda8a\ude37\ud812\uddc4\ud8cb\ude87\ud8e3\ude3b\udb70\ude06\udb2f\udda5\ud874\udc4b\uda07\udf2f\udbb5\ude87\ud8f2\ude86\ud9db\udd23\uda0e\udf02\u3efb",
        -2, 88044, -1639696096, -5180756410999716782L, 9706L, true, true, (char) 19303, (char) 28933,
        Double.longBitsToDouble(0x3fae8d74f03c6360L), Double.longBitsToDouble(0x3fe790cf3781c6dfL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.String:\ud9c9\udd97\uda3a\ude35\udb54\udee0\ud831\ude2e |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\ud9c9\udd97\uda3a\ude35\udb54\udee0\ud831\ude2e |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 14, 14, 9, "\ud9c9\udd97\uda3a\ude35\udb54\udee0\ud831\ude2e", "\u32cb", "\udad9\ude87\ud81e\udfad\udaa6\udfcb\ud8ce\udcbe\udb84\udc15\uda81\udddd\ud971\udfd3\udaab\udd2a\uda98\udee9\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\udb9b\udedc\ud922\udc31\u63f2\ud8f6\ude0d\ud965\ude34\uda1a\ude4d\ud9ba\udc2d\ud935\udf9c\ud824\udc5d\uda84\udf70\ud98a\udc02\udaea\udd2f\udb39\udfbc\ud849\udf88\udb71\udd3f\udb59\ude95\udb48\udc41\uda59\udf8c",
        35, 21676, 1836043833, -8055165732994047197L, 21011L, false, false, (char) 7363, (char) 54347,
        Double.longBitsToDouble(0x3fbee22145781630L), Double.longBitsToDouble(0x3fc8840566aea534L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.String:\u79eb\u4a92\u6372\u4e4b\u2d56\u2191\u3726\u629f |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\ud9d7\udc7e\uda20\ude3f\udb63\udc77 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 5, 9, "\ud9d7\udc7e\uda20\ude3f\udb63\udc77", "\u79eb\u4a92\u6372\u4e4b\u2d56\u2191\u3726\u629f", "\udaa5\udd34\uda99\udc94\u8c3f\ud9d1\udef0\uda51\udf22\ud94c\udff5\ud832\udfaf\u1852\ud922\udc31\u63f2\ud8f6\ude0d\ud95b\udf34",
        40, 26864, 1550835998, -828998149565830155L, -47619L, false, false, (char) 31372, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b67b666L), Double.longBitsToDouble(0x3fee54d8b993fe84L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 10, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u8f66\u1888\u897f\u4e96\u2d56\u1e9b\u9a1c\uc3ec\u0aa7\u1d69\u9341\uccf8\u7790\u3287{\u3adb", "\uda97\udf7c\u3b7c",
        24, 93118, 1380743544, -6778579275307733804L, -25635L, false, false, (char) 59245, (char) 45591,
        Double.longBitsToDouble(0x3fbbb3f4d8efa688L), Double.longBitsToDouble(0x3fdbcf4f45881466L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 10, "\ud834\udebb\ud980\udfac\ud998\ude71\udb5f\udde5\ud81e\ude61\ud989\ude5a\ud8a5\udd92\uda46\udc35\ud80d\udd32\ud8b6\ude86\ud81e\udfad\ud99a\udf97\u15cd\udb11\udfb0\ud8df\udf60\ud8cf\udec2\ud8f7\udc59\uda80\udeb8\udb35\udead{\ud94a\udc24", "\u6ad8", "\ud95b\udeff",
        19, 65024, 1165307092, 6677661166829036717L, -47619L, false, false, (char) 52801, (char) 55443,
        Double.longBitsToDouble(0x3fd1c40f45881466L), Double.longBitsToDouble(0x3fe96a8ce7193680L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 10, "\ud834\udebb\ud980\udfac\ud998\ude71\udb5f\udde5\ud81e\ude61\udab2\udc75\udb73\udfcd\uda46\udc0d\ud80d\udd32\ud8b6\ude86\ud81e\udfad\ud99a\udf97\u15cd\udb11\udfb0\ud95b\udde6\uda0a\udcff\udba2\ude90\ud9ff\udfc4\udb46\udfd7{\ud94a\udc24\ud832\udfaf\u1852\udafe\udf77\u3b7c\ud8b6\ude5a\ud95b\udf34\uda53\ude51\udb12\udc84\udb7c\udceb\ud0f4\uda07\udfea\u806e\udad7\udef3\ud8cf\udeb0\udb5f\udf48\ud96c\ude76\ud985\ude5f\ud988\udf60\udb3c\udebf\ud999\udf2c\ud82e\udf2f\udba9\ude74\udbd7\ude56", "\ua483\u1a01", "\ud818\udef4",
        54, 73505, 236599670, -6476611417981842331L, 24210L, false, true, (char) 4341, (char) 48815,
        Double.longBitsToDouble(0x3fed090f326b9ae2L), Double.longBitsToDouble(0x3fef1568d17653d2L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 12, 7, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u8f66\u1888\u897f\u4e96\u2d56\u1e9b\u9a1c\uc3ec\u0aa7\u1d69\u9341\uccf8\u7790\u3287{\u3adb", "\uda97\udf7c\u3b7c",
        24, 93118, 1380743544, -6778579275307733804L, -25635L, false, false, (char) 59245, (char) 45591,
        Double.longBitsToDouble(0x3fbbb3f4d8efa688L), Double.longBitsToDouble(0x3fdbcf4f45881466L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 11, 10, "\u0819\ud980\udef5\udbcc\udecb\ud838\udf3e\ud96b\udd0b\ud861\udc2c\ud9ff\udd2e\uda46\udc0d\ud80d\udd32\ud8b6\ude86\ud81e\udfad\ud99a\udf97\u15cd\ud88a\udf94\ud95b\udde6\ud8cf\udec2\ud8f7\udc59\ud983\ude7a\udb52\udd89{\ud94a\udc24\ud82f\uddaf\udac0\ude92\ud9af\udd1e\udbe7\udf05\ud8b6\ude63\ud95b\udf34\uda53\ude51\udb12\udc84", "\u02e1\ubae0\u31dd\u8708\u75df", "\udb88\ude09\ud8b0\udca0\ud90d\udd2c",
        6, 67031, -1585428358, 6265125049976525177L, 50462L, false, true, (char) 48247, (char) 7605,
        Double.longBitsToDouble(0x3fdb563519821042L), Double.longBitsToDouble(0x3fe83243d17f8b35L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 10, "\ud917\udd6d\ud8a8\udcb1\ud998\udeca\udb5f\udde5\ud81e\uddc5\udab2\udc75\udb73\udfcd\uda46\udc0d\ud80d\udd32\ud8b6\ude86\ud8f1\udf36\ud96f\udf4c\u15cd\udb11\udfb0\ud95b\udde6\ud8cf\udec2\ud8f7\udc59\uda80\udeb8\udb35\udead{\u6d4b\ud832\udfaf\u1852\uda97\udf7c", "\uc1dc\u70a3\ua150\u4019\ub9a7\ubc98\u04f1", "\ud881\udcf3\ud8e7\ude72\udb53\udf8d\udb7b\udf5b\udbf5\udfa3\udb69\ude46\ud8a0\udc4a",
        5, 31131, 302057125, -2147205943695945753L, 98141L, true, false, (char) 47448, (char) 8352,
        Double.longBitsToDouble(0x3fd26847e93d8e88L), Double.longBitsToDouble(0x3fe70582ef801bfdL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 0, 10, "\ud834\udebb\ud980\udfac\ud998\ude71\udb5f\udde5\ud81e\ude61\ud989\ude5a\ud8a5\udd92\uda46\udc35\ud80d\udd32\udbc7\udd0e\ud816\udd6b\ud99a\udf97\u15cd\udb11\udfb0\ud8df\udf60\ud8cf\udec2\ud8f7\udc59\uda80\udeb8\udb35\ude79{\ud94a\udc24\udaf2\udca9\udbda\udc5b\uda97\udf7c\u3b7c\ud8b6\ude5a", "\u5e91\uaaf5", "\u7f99\udb75\uddd7",
        35, 46998, 1089790914, 735046734540757700L, 86137L, false, false, (char) 58189, (char) 38522,
        Double.longBitsToDouble(0x3fd2ef56afd022eeL), Double.longBitsToDouble(0x3fa7676c624a0960L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\uda8a\udf8f\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1743\u1b4b\u3755\u1e9b\u8559\u018e", "\ud8cf\udf22\udb71\udf97\u7edd\ud91c\ude68\ud89e\ude27\ud890\udfd7\ud832\udf23\u1852\ud922\udc31\u009b\000\ud93f\udcbe",
        40, -984, 0, -864691127386887179L, -94695L, true, true, (char) 60028, (char) 8183,
        Double.longBitsToDouble(0x3fee57dd97c84d84L), Double.longBitsToDouble(0x3fce98d4d6084968L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 10, 8, 9, "\udb1a\udf97\ud898\udd44\u2ed6\ud97a\udddd\udbd4\udc9c\ud8c6\udc70\uda4c\ude3c\ud932\udc89\uda16\udc02\udae2\udd1c\ud81e\udfa9\udaed\udd54\ud934\udf85\udb11\udfc4\udb20\udf4a\ud8cf\udf22\udb71\udf97\ud8a2\udd5d\ud91c\ude68\udb1c\udc30\ud94c\udff5\ud954\udc1e\udbff\udfee\ud922\udc31\u63f2\ud8f6\ude0d\ud816\ude3b\udacc\udca8\ud97d\ude75\ud845\udfd8\ud8a4\udc6a\udbc7\udcad\udabe\ude06\udaa2\udf15\ud83f\udc75\uda34\udfa4\ud820\udc21\ud8bc\ude52\udabf\udce9\ud966\udc11\ud96d\udf3f\ud9d3\ude26\udb9c\udf8f\ud8b5\uded9\ud910\udc59\ud9b1\udd0c", "\u3f2d\u1d73\uc077\ub853\u51d6\u0e5d\ub524\u2904\ub46c\u34a9\ua171\u7d32\u8fbd\uc13c\u969e\u415b\u027e\ubb82\ua491\u3cca\u965e\u390c\ud239\u7748\u87d3\u0cf3\u6de4\u51fe\u70ac\u7ca4\u1dd1\u46ef\u7163\u139b\u0384\u45a5\uc542\uaa55\u5866\u64e2\uc6b5\u019a\u5331\ud268\u25cc\u9750\ud382\u439b\u854b\ua789\u8e0f\ud721\u7d65\u5e2d\u13de\u0e94\u6654\u09d5\u240f\u66db\u7997\u3797\uc116\u1ce9\ub2d6", "\uda3b\udd67\udac9\uddf2\udb7f\udd50\udb80\udf1c\udba3\uded6\ud95c\udfe4\ud9db\udd8d\ud9f4\udc7b\udabf\udef9\udb93\udcd5\udb10\udd79\ud9ec\udc91\udbe0\udeeb\udaa2\ude2b\ud853\udce4\udb5e\udeb4\udb55\udf95\ud904\udef5\udb72\udc6a\ud91e\ude6e\ud94b\udfb9\udaec\udefd\uda74\uddc4\ud9c4\udd20\ud800\udc62\ud85d\udf48\ud906\uddce\ud857\udc4a",
        25, 48009, -291746681, 3370857343640147613L, 55785L, false, false, (char) 36399, (char) 14593,
        Double.longBitsToDouble(0x3fa148037f9d3b70L), Double.longBitsToDouble(0x3fe985f5303518ecL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 1, 9, "\ud9c9\udd97\uda3a\ude35\udb54\udee0", "\u2b85", "\ud9aa\udda3\uda43\udf5b\u6b2e\ud912\udc81\ud902\udd06\udaab\udd0f\udbfc\udf71\uda83\udcf5\ud91d\udd23\uda98\udee9\udb3b\udd38\udaec\ude1e\ud8e2\udf76\ud943\udff7\udbd5\udeba\ud922\udc31",
        3, 46147, -1910189238, 2320830613151281538L, 43643L, false, true, (char) 58677, (char) 50957,
        Double.longBitsToDouble(0x3fe02e85e942f068L), Double.longBitsToDouble(0x3fdd25bb60aec730L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:org.apache.commons.lang.text.ExtendedMessageFormat@0\0121=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:org.apache.commons.lang.text.ExtendedMessageFormat@0\012",
        Z.run(T, 2, 2, 2, 12, "", "\000\000\000\000\u525e\u616e", "\u00f1\udaed\udce2\uda03\ude4d\ud80d\udf73\udb20\uded7\ud8f9\udc22\ud99b\udf4c\udac9\udc14\ud91c\ude9f",
        30, 37737, -1669074292, 3252669481259641382L, -99923L, false, false, (char) 1526, (char) 17323,
        Double.longBitsToDouble(0x3fd1e78bbdcbccdeL), Double.longBitsToDouble(0x3fefafa3f4e83facL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 10, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u8f66\u1888\u897f\u4e96\u2d56\u1e9b\u9a1c\uc3ec\u1f16\u1ec2\uc594\uccf8\u7790\u3287{\ua9d2", "\uda97\udf7c\u3b7c",
        24, 93118, 1380743544, -6778579275307733804L, -25635L, false, false, (char) 59245, (char) 45591,
        Double.longBitsToDouble(0x3fbbb3f4d8efa688L), Double.longBitsToDouble(0x3fdbcf4f45881466L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 10, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u8f66\u1888\u897f\u4e96\u2d56\u1e9b\u9a1c\uc3ec\u1f16\u1ec2\uc594\uccf8\u7790\u3287{\ua9d2\u3817\u0329\u6ad8\u3b7c\u874f\u3bdd", "\udb7c\udceb\udba2\udcaa\uda08\udc4b\u806e\udb75\uddd7\ud897\udd51\udbb0\udfbc\ud96c\ude76\uda2f\udc67",
        46, 699, 516513609, 6182249937125004811L, 43067L, false, false, (char) 48878, (char) 60907,
        Double.longBitsToDouble(0x3fdf022f5db9beb0L), Double.longBitsToDouble(0x3fecad1868696e41L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.String:\u8f66\u1888\u897f\u4e96\u2d56\u1e9b\u0d3e\uc3ec\u60e5\u1ec2\uc594\uccf8}\u3490\u9a08\ua9d2 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 2, 10, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u8f66\u1888\u897f\u4e96\u2d56\u1e9b\u0d3e\uc3ec\u60e5\u1ec2\uc594\uccf8}\u3490\u9a08\ua9d2", "\uda97\udf7c\u3b7c",
        24, 25710, -1041376151, -6778579275307733804L, -25635L, false, false, (char) 59245, (char) 45591,
        Double.longBitsToDouble(0x3fbbb3f4d8efa688L), Double.longBitsToDouble(0x3fdbcf4f45881466L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 9, "\udb1a\udf97\ud898\udd44\udb63\udc01", "\u79eb\u0e6d\u1743\u4e4b\u2d56\u1e9b\u8559\u018e", "\ud8cf\udf22\udb71\udf97\uda98\udfb8\ud91c\ude68\ud89e\ude27\ud94c\udff5\ud832\udfaf\u1852\uda8c\udc85\u636c\ud8f6\ude0d\ud95b\udf34",
        40, 26864, 1986648347, -834501020579255307L, -47619L, false, false, (char) 57996, (char) 55278,
        Double.longBitsToDouble(0x3fdbc80c0b881466L), Double.longBitsToDouble(0x3fee57dd93824d84L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 10, "\udb15\udd94\udb9e\udde2\ud998\ude71\udb5f\udde5\uda33\udd01\uda9d\ude72\udb73\udfcd\uda46\udc0d\ud80d\udd32\ud8b6\ude86\ud81e\udfad\ud99a\udf97\u15cd\ud932\udd31\ud948\udc8a\ud8dc\udd15\ud8f7\udc59\uda80\udeb8\udb35\udead{\udab7\ude0e\ud816\udc24\u1852\uda97\udf7c\u3b7c\ud8b6\ude5a\ud95b\udf34\uda53\ude51\udb12\udc84\udb7c\udceb\udba2\udcaa\uda08\udc4b\u806e\udb75\uddd7\ud897\udd51\ud902\udfc5\ud96c\ude76\udb8e\ude55\ud988\udd6b\uda58\udf75\uda1d\udff8\udbe2\udf7e\ud819\udd3b\uda11\ude54\udadf\udd94\udb4e\udde4\ud9f7\udf90\uda2d\udce2\ud8c6\udcba\ud9b6\ude61\ud9ab\udfbd\ud839\udfcd\udaf4\udd8b\udb22\udeae\u78c3\ud84c\udc05\uda6f\ude17\ud95f\udec6", "\u2300\ua6b4", "\ud818\udefe\ud942\udf3f",
        39, 28431, -818253540, -9021247109915679231L, -50796L, true, true, (char) 51945, (char) 26780,
        Double.longBitsToDouble(0x3febded8b11e82ffL), Double.longBitsToDouble(0x3fe9c4f44d49c660L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.String:\u8f66\u1888\u1080\u4e96\u2d56\uadb7\u4dfc\u6eed\u1f16\u1ec2\u2d95\u8a4d\u76c0\u00bf'\ua9d2\u3817\u0329\u6ad8\u3b7c\u5ab2\u0e8e\u6b02\u5e91\u4f26\u62fc\ub1f3\u6ca8\u3bbf\uc70e\u7ec5\uafe3\ub5a3\uc025 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 10, "\ud834\udebb\ud980\udfac\uda5e\udd34", "\u8f66\u1888\u1080\u4e96\u2d56\uadb7\u4dfc\u6eed\u1f16\u1ec2\u2d95\u8a4d\u76c0\u00bf'\ua9d2\u3817\u0329\u6ad8\u3b7c\u5ab2\u0e8e\u6b02\u5e91\u4f26\u62fc\ub1f3\u6ca8\u3bbf\uc70e\u7ec5\uafe3\ub5a3\uc025", "\udae3\udee2\udb20\udd9d",
        -4, 56059, 667721560, -6925311869333522371L, 72165L, false, true, (char) 13485, (char) 55458,
        Double.longBitsToDouble(0x3fe071072b6b8623L), Double.longBitsToDouble(0x3feec23c50d15950L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 1, 10, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u6bf5\uade1\u897f\u4e96\u2d56\u1e9b\u9a1c\uc3ec\u1f16\u75f5\u0696\u31f1\u2368\u3291{\ua9d2", "\uda97\udf7c\u3b7c",
        24, 93118, 1379236216, -6778579275307733804L, 87867L, false, true, (char) 59245, (char) 45591,
        Double.longBitsToDouble(0x3fbbb3f4c0efa688L), Double.longBitsToDouble(0x3fcfc5920c6428ccL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 10, "\ud834\udebb\ud980\udfac\uda5e\udd34", "\u8f66\u1888\u1080\u4e96\u2d56\uadb7\u4dfc\u6eed\u1f16\u1ec2\u2d95\u8a4d\u76c0\u00bf'\ua9d2\u3817\u0329\u6ad8\u3b7c\u5ab2\u0e8e\u6b02\u5e91\u4f26\u62fc\ub1f3\u5ca8\u3bbf\uc70e\u7f2b\uafe3\ub5a3\uc025", "\udae3\udee2\udb20\udd9d",
        -4, 56059, 667721560, -6925311869333522371L, 72165L, false, true, (char) 13485, (char) 55458,
        Double.longBitsToDouble(0x3fe071072b6b8623L), Double.longBitsToDouble(0x3feec23c50d15950L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 10, "\ud8ac\udce0\ud87e\ude73\ud998\ude71\udb5f\udde5\ub188\uda81\ude1f\ud844\udc70\uda46\udc0d\ud80d\udd32\ud8f8\ude87", "\uc3ec\u6f78\u75f5\u0696\u31f1\u2368\u3291{\ua9d2\u3817\u0329\u6ad8\u3b7c\u874f\uc1dc\u94ad\u451d\u4f26\u1035\u79af", "\ud897\udd51",
        13, 68581, 171164926, -5373133995227643094L, 81191L, true, true, (char) 57227, (char) 47877,
        Double.longBitsToDouble(0x3fb3fa73403b7fa8L), Double.longBitsToDouble(0x3fa829de56768e70L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 3, "\ud834\udebb\ud980\udfac\ud998\ude71", "\u6bf5\uade1\u897f\u4e96\u784d\ucea2\u9a45\uc3ec\u1f16\u75f5\u0696\u31f1\u2368\u3291{\ua9d2", "\uda97\udf7c\u3b7c",
        24, 93118, 1379236216, -6778579275307733804L, 87867L, false, true, (char) 50728, (char) 11151,
        Double.longBitsToDouble(0x3fd2170f303be9a2L), Double.longBitsToDouble(0x3fcfc5920c6428ccL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 10, "\ud834\udebb\ud980\udfac\uda5e\udd34", "\u8f66\u1888\u1080\u4e96\u2d56\uadb7\u4dfc\u6eed\u1f16\u1ec2\u2d95\u8a4d\u76c0\u00bf'", "\u1852\uda97\udf7c\u3b7c\udbdf\uddc4\udaa7\uddb8\uda53\ude51\udb12\udc84\udb7c\udceb\udae2\udcbf\ud972\ude02\ud92f\ude16\udb75\uddb0",
        48, 95220, 99354847, 762068325697772228L, 61549L, true, false, (char) 47378, (char) 32043,
        Double.longBitsToDouble(0x3fd139409eb127eeL), Double.longBitsToDouble(0x3fd8c27cc07b3fc8L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 10, "\udb99\udc83\ud8da\udf89\ud998\ude0f\udb5f\udde5\ub188\uda81\ude1f\ud844\udc70\uda46\udc0d\ud80d\udd32\ud8f8\ude87", "\uc3ec\u6f78\u75f5\u0696\u31f1\u2368\u3291{\ua9d2\u1817\uc9a6\ubf53\u3b7c\u874f\uc1dc\ub087\u451d\u4f26\u1035\u79af", "\ud897\udd51",
        36, 68581, 171136254, -5373133995227643094L, 81191L, true, true, (char) 57227, (char) 47877,
        Double.longBitsToDouble(0x3fb3fa73403b7fa8L), Double.longBitsToDouble(0x3fa829de56768e70L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 11, 10, "\ud928\udf0b\ud8bc\udd52\udbf1\udde0\ud838\udf3e\ud96b\udd0b\ud861\udc2c\ud9a1\udd1f\ud8a5\ude7d\ud80d\udd32\ud9d6\udfe0\udac3\udf5b\ud822\udfa4\udb57\udee8\ud88b\udc27\ud95b\udde6\udad4\udde5\udace\udeb9\ud983\ude7a\ud95d\ude01{ \ud8c9\uddfb\udac0\ude7d\ud8fc\udfa5\udbe7\udf05\ud8b6\ude63\ud95b\udf34\uda53\ude51\udb12\udc84", "\u02e1\ubae0\u3a0a\u8708\u75df", "\udb88\ude09\ud8b0\udca0\ud90d\udd2c",
        6, 38791, -1585382145, 6265117353395130745L, 50462L, false, true, (char) 48247, (char) 42174,
        Double.longBitsToDouble(0x3fdfb4b7a9821042L), Double.longBitsToDouble(0x3fe83243d17f8b35L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 15, 6, "\ud834\udebb\ud980\udfac\uda5e\udd34\u8428\ud81e\ude61\udab2\udc75\udb73\udfcd\uda5d\udf0d\ud80d\udd32\ud8b6\ude86\udbc3\udd9e\uda2f\udedb\u98cd\ud932\udd31\ud948\udc8a\uda0c\udd42\ud86b\udd74\uda80\udde8\ud868\udea8'\udbee\udc1b\uda32\udf04\u1852\uda97\udf7c\u3b7c\udbdf\uddc4\ud9dc\udd73\ud817\udcd8\ud90b\udef1\udba3\uddb8\udae2\udcbf\ud972\ude02\ud92f\ude16", "\u4730\uafe3\ub5a3\ub006\ub527\u03d8\u5be0\u20f6\u1107\u90d7\uba04\u7461\u3252\u7ef6\u2d98\u5ba0\u27ad\u6aac\ua0eb\u124e\u0ec2\ua1eb\u5e53\u46f1\ucc78", "\ud8ff\ude80\ud923\udd4a\ud9cc\ude2b\udb25\udeab\udb93\uddec\uda7e\ude9c\ud959\udd90\ud955\udc3b\ud98b\udef5\u151b\u342b\udb67\udedb\ud9fa\udc92\udb48\ude89\ucfc7\ud891\udcac\ud838\udffc\ud855\udd70\ud89b\udc80\ud974\udf20",
        28, 18678, 268779214, 5393538066853312637L, -61065L, true, false, (char) 46480, (char) 51947,
        Double.longBitsToDouble(0x3fec9e42412cc0c9L), Double.longBitsToDouble(0x3fdc03427906b9feL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.String:\u8f66\u1888\u1080\u4e96\u2d56\uadb7\u4dfc\u6eed\u1f16\u1ec2\u2d95\u8a4d\ud7bd''\ua9d2\u3817\u0329\u4ad2\u3b7c\u5ab2\u0e8e\u6b02\u5e91\u4f26\ud35e\u380c\u6ca8\u3bbf\uc70e\u37a9\u9515\ub5a3\uc025 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 0, 10, "\uda0a\udc3c\ud91a\udfb9\udbd6\udfae", "\u8f66\u1888\u1080\u4e96\u2d56\uadb7\u4dfc\u6eed\u1f16\u1ec2\u2d95\u8a4d\ud7bd''\ua9d2\u3817\u0329\u4ad2\u3b7c\u5ab2\u0e8e\u6b02\u5e91\u4f26\ud35e\u380c\u6ca8\u3bbf\uc70e\u37a9\u9515\ub5a3\uc025", "\ud89d\udd9f",
        -5, 28967, 315059147, 2867842428925401484L, 68420L, true, true, (char) 40384, (char) 13485,
        Double.longBitsToDouble(0x3fe2dcf23b1120e5L), Double.longBitsToDouble(0x3feb5844f3d8478aL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 10, "\ud8ac\udce0\ud87e\ude73\ud998\ude71\udb5f\udde5\ub188\udb5c\udc88\ud844\udc9d\uda46\udc0d\ud80d\udd32\ud8f8\ude87\ud81e\udfad\ud99a\udf97\u15cd\ud8bc\udd36", "\u31f1\u2368\u3291{\ua9d2\034\u0329\u6ad8\u3b7c", "\uda84\udc9d\udacf\udefe\udb7c\udceb\uda78\ude95\ud8cb\udc03\u6b5c\udb75\uddd7\ud897\udd51\ud902\udfc5\ud926\udebd\udba5\udd97\u9eb4\ud8cc\uddfe\ud852\udf57\udac1\ude89\udb1c\udf6e\uda55\udfce\ud839\uddc8\ueee8\ud911\udcf6\uda73\ude5e\ud938\udd54\ud972\udc1f\uda02\udc01\udbd9\udee0\udaee\uddcb\udb06\udf6a\ud82b\udd5d\udb01\uddfd\uda3c\udd19\ud8f8\uddfc\udb49\uddc0\udb19\udef1\ud8c0\ude8c\u876f\ue05c\udbc5\udce1",
        53, 14981, 1639505256, -8913108383934019317L, -85581L, true, true, (char) 52383, (char) 47529,
        Double.longBitsToDouble(0x3fc2dbf6988f96f8L), Double.longBitsToDouble(0x3fd08672ef3aa41aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|appendQuotedString|java.lang.String,java.text.ParsePosition,java.lang.StringBuffer,boolean|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|applyPattern|java.lang.String|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|containsElements|java.util.Collection|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|getFormat|java.lang.String|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|getQuotedString|java.lang.String,java.text.ParsePosition,boolean|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|insertFormats|java.lang.String,java.util.ArrayList|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|next|java.text.ParsePosition|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|parseFormatDescription|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|readArgumentIndex|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|seekNonWs|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|setFormat|int,java.text.Format|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|setFormatByArgumentIndex|int,java.text.Format|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|setFormats|[Ljava.text.Format;|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|setFormatsByArgumentIndex|[Ljava.text.Format;|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|toPattern||new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "C|org.apache.commons.lang.text.ExtendedMessageFormat|<init>|java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|appendQuotedString|java.lang.String,java.text.ParsePosition,java.lang.StringBuffer,boolean|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
