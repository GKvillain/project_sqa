package org.apache.commons.lang.text;
import org.junit.Test;
import static org.junit.Assert.*;
public class ExtendedMessageFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, 11026, 344955578, -7323935472436783533L, -12233L, true, false, (char) 9517, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 1, "\ud85b\udfc2", "\uc533\u574a\u222c\u6986\u86e6\u7aa5\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud837\udf15\uda56\udcc0\udb2b\udc92\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, -718, 344955495, -7323935472436783533L, -77769L, true, false, (char) 9517, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u2c3c\000\000\000", "",
        5, 34128, -74178767, 27079768801280L, -100000L, false, true, (char) 35688, (char) 162,
        Double.longBitsToDouble(0x3e154571a0000000L), Double.longBitsToDouble(0x3fe00000077e148fL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 1, "\ud85b\udfc2\ud879\udf5b\udb82\udd9b\udb24\udd05\ud93f\udc62\udbf0\udc3f\ud9ae\udf70", "\u4f40\u7fc3\u62d3\u5e72\ubdf9\u869a\u69f3\u8094\ub082\u045a\u6789\u1d71\u4864\u196b\u7316\u4ee7\ua820\u51e6\ud7d4", "\udba0\ude24\uda40\udf93\uda0f\udca1\ud9d9\udd9f\uda23\udcc9\ud9e7\udd3a\ud8a3\udd6c\udbf9\udd80\uda19\udf83",
        19, 93498, 193290490, -4301453387080122649L, 92026L, false, false, (char) 38375, (char) 50612,
        Double.longBitsToDouble(0x3fd325a1509d9d70L), Double.longBitsToDouble(0x3fc5f803b23f8cb8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\udad6\udebb\uda62\udc26\udb65\ude66\udb57\udd4a\ud8df\udd13\udbf0\udc3f\ud9ae\udf70\udbb0\udd12\uda08\udc68\ud853\ude74\ud950\ude07\uda66\udf76\udbe1\udd9e\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\udb49\ude71\ud9b0\udff5\u9b7d", "\u124f\u50d0\u216f\u6318\u1707\ud7d4\u47b4\u56e4\u98d2\u117a\u7813\u2aea\u50c2\u5d5d\ub1b7\ub227\u82bf\u6d23\u22ce", "\udb19\udd63\udb2a\udc3d\uda22\udfcc",
        40, 76890, -553092506, 3312485069049724691L, -1948L, true, false, (char) 12388, (char) 17909,
        Double.longBitsToDouble(0x3fe05334b09f3e87L), Double.longBitsToDouble(0x3fb408d72ba83f90L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud85b\udfc2\ud879\udf5b\udb82\udd9b\udb24\udd05", "\u694a\u86e6\u7aa5\u4f40\u51d6\u62d3\u7200\uaa9b\u869a\u69f3\u8094\u8e26\u740d\u1efb\u902b\u8890\u196b\u085c\u11a4", "\u8469\udb8e\udd6b",
        29, 11647, -984633591, -4897866203554731735L, 15185L, false, false, (char) 28115, (char) 34072,
        Double.longBitsToDouble(0x3fda0b566685a0aeL), Double.longBitsToDouble(0x3fd326809dbffe02L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 10, 1, "\ud86e\udf1c", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, 11026, 344955578, -2063556959629093293L, -12233L, true, false, (char) 9517, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 15, 12, 12, "\ud85b\udfc2\ud879\udf5b\udb82\udd9b\ud842\udeb0", "\u546e\u5955\ua8f9\u4ee1\u51d6\u62d3\u7200\uaa9b\u869a\u69f3\u8094\u8e26\u740d\u1efb\u902b\u8890\u196b\u085c\u22d2\u6303\u1707\ud7d4\u47b4", "\uda40\udf93\ud9ff\udd78\ud9c3\udd2b\uda23\udcc9\ud9e7\udd3a\udab6\udfb6\uda58\udc0a\ud96d\udf9a\ud979\udcac\uda2a\udc28\udb7e\udcfd\uda0e\ude25\ud90a\udd9c",
        49, 74024, -1879204730, 339159272573352708L, 28710L, true, false, (char) 34780, (char) 57560,
        Double.longBitsToDouble(0x3fe542a61882570dL), Double.longBitsToDouble(0x3feb9370b6b6194cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud9af\udfcd\uda59\udf91\udb82\udd9b", "\u552e\u5dbf\u86e6\u7aa5\u4f40\u51d6\u62d3\u7200\uaa9b\u92bd\u9781\u8094\u4ee6\ud7f3\u1efb\u902b", "\ud823\udf4e\uc593\ud894\udff0\udada\udc65\udad9\ude22\udb8a\udf4a\udb9c\udd3c\udba0\ude24\uda40\udf93\uda0f\udca1\ud9d9\udd9f\ud8a5\udc09\ud9e7\udde1\ud81b\udca8\udb0a\ude07\uda19\udec4\udbec\uded0\udac4\udecd\udac1\udde4\udab1\udc8c\udb59\udc23\ud8e8\ude98\uda5f\udf17",
        6, 5306, -10390700, 3921317322936591571L, 99430L, true, false, (char) 49840, (char) 21536,
        Double.longBitsToDouble(0x3f787d6d4128d980L), Double.longBitsToDouble(0x3fde77016fb65bdaL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u91aa\u4f40\u51d6", "\uda87\udd43\udb6f\udf71",
        26, 64037, -817002498, -5939866324706837134L, -27285L, true, true, (char) 5152, (char) 41527,
        Double.longBitsToDouble(0x3fe5d3aa177e148fL), Double.longBitsToDouble(0x3fe29cd2e15edf85L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\uda15\udcf6\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\ud810\udf52\ud817\udc50\uc593\ud894\udff0\uda4e\udd80\u8469\udb8e\udd6b\udb9c\udc96\udba0\ude24\uda40\udf93\uda0f\udca1\ud9d9\udd9f\uda23\udcc9\ud9e7\udd3a\ud81b\udca8\udb0a\ude07\uda19\udec4\udbec\uded0\udbf3\udc25\uca8f\udbdd\udda6\ud8bd\ude06\ud90f\udddf\udb85\uddef\uda88\udd77",
        7, 24473, 1246550789, 1547456225095653930L, -26297L, false, true, (char) 62436, (char) 1060,
        Double.longBitsToDouble(0x3fdfb884841acb0eL), Double.longBitsToDouble(0x3fe30610933f4feeL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 1, "\000", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u4f40", "\udbe1\udd9e\uda55\udfb8\uda76\udd54",
        8, 41321, -817002530, -2553129718110274190L, -27285L, true, true, (char) 5152, (char) 41527,
        Double.longBitsToDouble(0x3fe5d3aa177e148fL), Double.longBitsToDouble(0x3fe29cd2e1fadf85L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u607f\u37b6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d",
        52, 79845, 392379827, 3138442405993412266L, -89890L, true, false, (char) 10100, (char) 15701,
        Double.longBitsToDouble(0x3fe038d73f0945dbL), Double.longBitsToDouble(0x3fc478a9e4a6f01cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud85b\udfc2", "\u455b\u97bb\u7b5b\u694a\u86e6\u7aa5\u4f40\u51d6", "\ud83b\udea1\uda76\uddac\ud903\udeee\udbb1\udc96\ud925\udcff\ud953\udc53\ud916\udf7d\udbb6\udc24\ud9c8\udd5b\udb51\udf13\ud823\udf4e\uc593\ud894\udff0\uda54\ude80\u8469\udb8e\udd6b\udb9c\udc96\udba0\ude24\uda40\udf93\u3f43\ud9d9\udd9f\uda23\udcc9\ud9e7\udd3a\udab4\udd53\ud8b3\udf3d\ud94f\udc8a\udbec\uded0\ud8c4\ude4d\uda26\udcc0\ud8ca\udf88\udb8e\udf15\udb88\udcf6\ud911\udf0f\udab0\udd8c\udbb6\ude60\uda1f\uddce\udb7a\udf28\udbc8\ude0d\uda03\udd83\udb0c\udd7a\udb26\udff5\ud969\ude1e\ud9a3\udeb7\udac8\ude30\uda87\udc8a\ud82b\udec9\ud9c4\udd72\udb51\udc1d\ud866\udd0e\uda53\udce6\ud949\ude70\udaaf\udf77\udbfd\udcfd\uda72\udd5b\ud938\udd2c\u5fba\udb99\udc40\udb2f\ude2f\udb94\udc37\uec12\ud965\udff0\ud9db\udf0f\ud803\udfad\ud91e\udcbb\ud844\udc4c\ud838\uddfb\ud877\udff6\ud960\udd7b\uda0a\ude04\udaf4\udcd7",
        11, 63970, -516947146, 6062160414199813730L, -98341L, true, false, (char) 47426, (char) 39696,
        Double.longBitsToDouble(0x3fc09228024f86a0L), Double.longBitsToDouble(0x3fd79f96c6aa1ac0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\ud85b\udfc2 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 14, 11, 1, "\ud85b\udfc2", "\uc533\u574a\u2a5d\u388f\uab6a\u7aa5\u4f40\u5ee4", "\udbe6\udfda\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13\ud823\udf4e\uc593",
        53, 46390, -544876973, 9103078842387906305L, -12233L, true, false, (char) 42511, (char) 23418,
        Double.longBitsToDouble(0x3fce17e72ca8e9b4L), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 12, "\ud968\udff6\ud872\ude5b\udb79\udf9b\udb24\udd05\ud8df\udd13\udbf0\udc3f\udae6\udf6c\udbb0\udd12\ud99a\udf71\udaef\udfe7\udb01\udf2f\ud98e\udc3d\ud85f\uddbd\ud9ab\ude5e\udbab\udeec\ud903\udeee\ua632\ud925\udcff\udaf8\udef8\ud953\udd14\ud816\udfe7\ud9c8\udd5b\udb51\udf13\ud823\udf4e\udaed\udd90\udb7c\udef0", "\u2e58\u56e4\u98d2\u117a\u7813\u0fea\u50c2\u5e01\u755d", "\uda17\udc30\uda61\ude2d\ud887\udf6d\uda26\udd88\uda5a\uded9\ud93e\ude90\ud949\udd03",
        28, 57989, -1115330105, -1385730107203474124L, -74409L, true, false, (char) 18257, (char) 26636,
        Double.longBitsToDouble(0x3fd9496e1894bd94L), Double.longBitsToDouble(0x3fa5c45880a42e60L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u0e10\u80a3", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\udac2\udf4c\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, 11026, 344955578, -7323935472436783533L, -12233L, true, false, (char) 9517, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 3, 10, 10, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u2f40\u51d6", "\uda55\udfb8\uda64\ude02\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud849\udf96\udb51\udf14",
        45, 11026, 344955578, -7323935473908753581L, 80481L, true, false, (char) 62691, (char) 3571,
        Double.longBitsToDouble(0x3fed2c503e4114deL), Double.longBitsToDouble(0x3fe07f38eae6f1eaL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\ud9a2\udd71\udbf0\udf33\uda0c\ude17\udb24\udd05\ud86d\udfba\uda60\udd37\ud99c\udc4a\udbb0\udd12\uda12\ude72\ud9f2\udf36\udb71\udf5c\ud8ac\udf4c\udb58\udd6c\ud7fc\uda54\udc98\udb4b\udc92\ud9b3\ude66\ud82c\udc65\udbf1\ude35\u9be7\ud816\udfe7\ud9af\uddf6\udb51\udf13\ud823\udf4e\uc593 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 14, 10, "\ud9a2\udd71\udbf0\udf33\uda0c\ude17\udb24\udd05\ud86d\udfba\uda60\udd37\ud99c\udc4a\udbb0\udd12\uda12\ude72\ud9f2\udf36\udb71\udf5c\ud8ac\udf4c\udb58\udd6c\ud7fc\uda54\udc98\udb4b\udc92\ud9b3\ude66\ud82c\udc65\udbf1\ude35\u9be7\ud816\udfe7\ud9af\uddf6\udb51\udf13\ud823\udf4e\uc593", "\ubf38\u2985\u5581\uce88\u11ec\u115d\u5f68\u50c2\u5d5d\ubfc8\u2d25\u0dda", "\udb28\udd92\uda83\udc9c\ud9b3\udd10\udb20\udf7f",
        29, 78549, -1762939621, -4062330286374703582L, 32044L, true, true, (char) 20852, (char) 19334,
        Double.longBitsToDouble(0x3f9d75d81806e160L), Double.longBitsToDouble(0x3fcfe329ae9bafb4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 3, "\udb77\udf30", "\uc533\u0a6d\u960e\u2407\u6d12\u1c70\u6d5e\u51d6\u6be1", "\ud979\udd16\ud91d\udd09",
        22, 86316, -594446836, 7389066824089052191L, 61450L, false, false, (char) 15373, (char) 28847,
        Double.longBitsToDouble(0x3fdfadf85fb90c4cL), Double.longBitsToDouble(0x3fe038d6cf0945dbL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, 11026, 344955578, -7323935472436783533L, -12233L, true, false, (char) 9517, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 12, 0, "\ud85b\udfc2\ud879\udf5b\udb82\udd9b\udab8\uddd0\ud8df\uddd2\udbf0\udc3f\ud9ae\udf70\udbb0\udd12", "\u51d6\u62d3\u7200\uaa9b\u869a\u69f3\u8094", "\u9b7d\ud816\udfe7\udbbb\udd95\u69fa\ud823\udf6e\uc593\ud894\udff0\uda4e\udd80\u8469\udb8e\udd6b\udb9c\udc96\udba0\ude24\uda40\udf93\uda0f\udca1\ud9d9\udd9f\uda23\udcc9\ud9e7\udd3a",
        30, 83972, -1251568854, -3434226024422329534L, -87083L, true, true, (char) 45930, (char) 64905,
        Double.longBitsToDouble(0x3f62076b13663700L), Double.longBitsToDouble(0x3fc1b9a84f24b49cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\ud85b\udfc2 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 5, 1, "\ud85b\udfc2", "\uc533\u96ff\uae30\u694a\u86e6\u7aa5\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, 11026, 344955578, -7323935472436783533L, -12233L, true, false, (char) 9517, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fee05ab3342a2eeL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud8d0\udc3f\ua632\udac1\udd6c\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, 11026, 344955578, -4988541988715774123L, -12233L, true, false, (char) 9517, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 11, 5, "\uda3e\udefe", "\uc533\u302e\u7acb\uae44\u3f77\u459c\u4f9a\uc4c2\ua55d", "\uda69\udea1\ud903\udeee\ud82b\ude32\ud925\udcff\udba2\udfee\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udefe\ud823\udf4e\u9c93\ud894\udff0",
        35, 17027, 1580507642, -4328622370796630521L, -16479L, false, false, (char) 31946, (char) 24719,
        Double.longBitsToDouble(0x3fe957885da0b566L), Double.longBitsToDouble(0x3fea1682bfdaf2a4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\u25af\u574a\u7b5b\u694a\u86e6\u629e\u4f40\u51d6 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 10, 1, "\ud85b\udfc2", "\u25af\u574a\u7b5b\u694a\u86e6\u629e\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\uda1d\udfa4\ud8af\udf17\udb51\udf2c",
        45, 11026, 344955578, -7323935472436783533L, -12233L, true, false, (char) 9517, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud85b\udfc2\ud879\udf5b\udb82\udd9b\udb24\udd05\ud8df\udd13\udbf0\udc3f\ud9ae\udf70\udbb0\udd12\uda08\udc68\ud853\ude74\ud950\ude07\uda66\udf76\udbe1\udd9e\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9d1\udc84\udb73\ude0a\u6d69\ud9c8\udd5b\udb51\udf13\ud823\udf4e\uc593\ud894\udff0\uda4e\udd80\udbf6\ude68\udb8e\udd6b\udb9c\udc96\ud845\udd53\ud836\udea2\uda0f\udc3d\ud9d9\udd9f", "\u755d\ub22f\u82bf\u6d23\u91c4\ua0f3\ua932\ubfa3\uc0c3\u4554\ua181\uc748\ub8d1\u02b6\u2f6d", "\udba0\udc1a\udaef\udd7d\ud876\uddf9\uda5b\udc8c",
        22, 41148, 1562327175, 4153411617362049325L, 4720L, true, true, (char) 55397, (char) 38896,
        Double.longBitsToDouble(0x3fee5db9024f9677L), Double.longBitsToDouble(0x3fa7409b8cd17580L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 12, 15, 1, "\ud9e1\udde5", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u4f40\u3059", "\ud83c\ude9f\uda76\udd54\ud9fd\udd0b\ud8b4\udf83\ud925\udcff\ud9b0\udff5\u9b7d\udbe4\udc4f\ud995\ude69\ud8c8\udeef",
        7, 55401, 624804771, -7323935470876502445L, -45719L, true, false, (char) 25936, (char) 37371,
        Double.longBitsToDouble(0x3fe07f38eae6f1eaL), Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 1, "\udbb8\udfbe", "\uc533", "\ud9ae\udf70\udbb0\udd12",
        47, 73533, 1427177472, 144122941145088L, 72302L, true, true, (char) 5174, (char) 58962,
        Double.longBitsToDouble(0x3fe060000572dc91L), Double.longBitsToDouble(0x3fd1f668b7eb4ee6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 1, 15, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u0fda\u694a\u4ee6\ua0f7\ub438\u8a15", "\uda55\udfb8\uda76\udd54\ud903\udeee\ud92a\udc85\ud925\udcff\ud831\ude15\udb88\uddd6\ud8ff\udc99\udb1d\ude25\udbe7\udfb6",
        0, 19715, 1622329423, -3208478403148529878L, -12233L, true, false, (char) 9610, (char) 19665,
        Double.longBitsToDouble(0x3fcb92c2acabc7b8L), Double.longBitsToDouble(0x3fe56a833342d057L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 1, "\ud85b\udfc2", "\000", "",
        -5, -1000, -1039182833, 4657507776100113668L, 88939L, false, false, (char) 63705, (char) 9183,
        Double.longBitsToDouble(0x3fc43f7285c979d4L), Double.longBitsToDouble(0x3fea3afd3e8dd527L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 1, "", "", "\ud8df\udd13",
        53, 27140, -747388160, -4463256281215219035L, -99980L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e14200000000000L), Double.longBitsToDouble(0x3e3a3afd38000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\uc533\uc8bb\u222c\u6986\u86e6 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 1, "\ud85b\udfc2", "\uc533\uc8bb\u222c\u6986\u86e6", "\ud8c6\udd02\ud906\udee5\ud82f\udf32",
        15, 75358, -74178767, 6806373493215181170L, 723L, true, true, (char) 35688, (char) 39253,
        Double.longBitsToDouble(0x3fc7a6ec62a8ae34L), Double.longBitsToDouble(0x3fe33ce2894b148fL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 1, "\u6c63", "\000", "",
        -5, -720, -1040187377, 4657507776100113668L, -42133L, false, false, (char) 63501, (char) 9183,
        Double.longBitsToDouble(0x3fc43f7281c979d4L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 1, "\ud85b\udfc2", "\uc533\u574a\u222c\u6986\u86e6\ub4e8\u4edb\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud837\udf15\uda56\udcc0\udb2b\udc92\ud84c\udf97\ud9c8\udd5b\udb51\udf13",
        45, -718, 344955495, -7323935472436783533L, -20860L, false, true, (char) 1490, (char) 16625,
        Double.longBitsToDouble(0x3fd5761981e566fcL), Double.longBitsToDouble(0x3fd311fd89fd08b2L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\u546e\ua2a3\ua945\u4ee1\u51d6\u62d3\u7200\uaa9b\u869a\u69f3\u2925\u8e26\u740d\u0cf3\u20d1\ud268\u196b\u1823\u22c5\u6303\u1707\ud7d4\u47b4 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 12, 12, "\ud9ca\udf2b\ud84f\udeb6\udba7\udc94\ud842\udeb0", "\u546e\ua2a3\ua945\u4ee1\u51d6\u62d3\u7200\uaa9b\u869a\u69f3\u2925\u8e26\u740d\u0cf3\u20d1\ud268\u196b\u1823\u22c5\u6303\u1707\ud7d4\u47b4", "\ud96b\udda7\u7ff3\ud9c3\udd2b\uda23\udcc9\ud9e7\udd3a\udab6\udfb6\uda58\udc0a\ud96d\udf9a\ud979\udcac\uda2a\udc28\udb7e\udcfd\uda0e\ude25\udb5a\udc8d",
        37, 84488, -1879204730, 339159272573352708L, 28710L, false, false, (char) 34780, (char) 57560,
        Double.longBitsToDouble(0x3fe542a61882570dL), Double.longBitsToDouble(0x3feb9370b6b6194cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 3, 12, "\ud90e\ude9b", "\uae90", "\ud8ad\udf7e\ub637\ud928\udf9f\ud853\ude15\ud950\ude07\uda66\udf76\udb35\ude34\uda47\udde4\uda76\udd54\ud8bc\ude4a\ud814\udd0a\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13\ud823\udf4e\ud8fa\udd2b\ud894\udfdb\uda4e\udd80\ud8bf\udf80\udb8e\udd6b",
        29, 11647, -984633591, 5910772903000136693L, 15185L, false, false, (char) 20589, (char) 7867,
        Double.longBitsToDouble(0x3fe0f4b7303f7e07L), Double.longBitsToDouble(0x3fba15d58c426e78L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 15, 15, 12, "\ud85b\udfc2\ud879\udf5b\udb82\udd9b\udb8d\udc01", "\u5d67\u5955\ua8f9\u4ee1\u51d6\u62d3\u7200\uaa9b\u869a\u69f3\u0e14\u8dc5\u740d\u1efb\u6f95\ub41d\u6e92\u085c\ubf42\ud5df\u1cb0\ud7d4\u47b4", "\uda40\udf93\ud9ff\udd78\ud9c3\udd2b\uda23\udcc9\ud9e7\udd3a\udb37\udeb7\uda58\udc0a\ud96d\udf9a\ud979\udcac\uda2a\udc28\udb7e\udcfd\uda0e\ude25\ud90a\udd9c",
        49, 74024, -231367546, 322770029559134980L, 28710L, true, false, (char) 16557, (char) 30914,
        Double.longBitsToDouble(0x3fc8aa8cc6095c34L), Double.longBitsToDouble(0x3fe6b2cc76b6190aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 1, 10, "\ud85b\udfc2", "\uc533\u574a\u00ee\u4003\u3216\u18f1\u607f\u37b6", "\uda73\uddd4\udae7\udead\ud903\udeee\ud8e1\ude2d\ud925\udcff\ud9b0\udff5\ud963\ude1c",
        17, 96398, 392379717, 3138442405993412266L, -89890L, true, false, (char) 10100, (char) 15701,
        Double.longBitsToDouble(0x3fe038d73f0945dbL), Double.longBitsToDouble(0x3fc478a9e4a6f01cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\u62b3 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 13, 10, "\ud9e3\udf27", "\u62b3", "\uda5f\udda1\ud915\udc9a\uda08\udc74\ud853\ude74\udbec\udcfe\ud931\udc95\udbe1\udd9e\udbe6\udfda\ud949\udc9c\ud921\udf31\udbf0\udd36\ud85c\udf50\ud9b0\udff5\ud808\udf0d\uda14\udf1d\ud9c8\udd5b\udb51\udf13\ud823\udf4e\uc593",
        53, 60558, -544876973, 9103078842387906305L, 74377L, true, false, (char) 48322, (char) 35525,
        Double.longBitsToDouble(0x3fe713a578ce65bbL), Double.longBitsToDouble(0x3fdc6ddc55d25d38L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:\ud290\u7b70\u69f5\u86e6\u7aa5\u0e10\u80a3\ud5ac\u7200\uaa9b\u869a\u14ea\uc4b4\ud32b\uc05e\u1e9e\u902b\u8890\u196b\u17c4\u11a4\u1a3a\u1735\ud7d4\u47b4\u56e4\u98d2\ud694\u9d15\u5f1a\u50c2 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 5, 10, 1, "\ud85b\udf97\ud879\udf5b", "\ud290\u7b70\u69f5\u86e6\u7aa5\u0e10\u80a3\ud5ac\u7200\uaa9b\u869a\u14ea\uc4b4\ud32b\uc05e\u1e9e\u902b\u8890\u196b\u17c4\u11a4\u1a3a\u1735\ud7d4\u47b4\u56e4\u98d2\ud694\u9d15\u5f1a\u50c2", "\udb0a\ude07\uda19\udec4\udbec\uded0\ud832\udd43\udb79\udf11\ud980\uddc5\ud81f\udf20",
        10, 87481, 1454806933, -405925188461034060L, -79964L, true, false, (char) 47500, (char) 49166,
        Double.longBitsToDouble(0x3feea0a785463d68L), Double.longBitsToDouble(0x3fe6c4827d9bd455L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 10, 14, "\udb80\udf1f\uda44\udcab\ud980\udcd1\udae3\udc78\uda30\udd54\udbf0\udc3f\udad2\ude42\udbb0\udd12\uda08\udc68\u64d9\ud8a7\udf9f\uda83\ude4f\udaac\udc63\uda53\ude10\uda76\udd54\ud903\udeee\ua632\ud982\udc84\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13\ud823\udf4e\ud93b\uddba\ud96d\udcbd\ud899\udeea\u8469\udb8e\udd6b\udb9c\udc96\udba0\ude24\uda40\udf93\ud97d\udcd4\ud929\udeef\ud8ab\udd4b\uda16\uddc5\ud81b\udca8\udb0a\ude07\uda19\udec4\udab1\uded5\ud8db\udf38\udbe7\udec2\ud88c\udcfe\udb2c\udf0b\udad3\udcea\udb79\udc8b\ud972\udd6e\u22f5\uda05\udd4c\udbc4\udd66\udab2\udfc4\udae4\udea0\udb7e\ude1d\ud8d9\udd63\udabc\udfc2\udb14\udc70\uda00\ude16\ud96c\udccc\u5f7f", "\u8023\u5294\u9cba\u7ba4\u3429\u31d0\uc0d6\u403a\u7cd7\u72ce\u4a28\u7963\uad50\uc354\u056c\ubfdb\ubbf2\u8431\u30f7\uc641\uc85c\u7044\uba3e\u95a3\u2846\uc08a\u1fa0\u32f7\u5373\u90fd\u9029\u4df6\ud7c8\ucb8d\u69f8\u2b52\ucd39\u4415\u51e9\u7e03\u6078\u5001\u3d21\u3021\u5208\u3f8b\u3f5a\u83eb\u312c\u82f6\u8572\u4ea4\u67cd\u1128\ua83c", "\ud9de\ude3b\uda3f\udfc7\uda8f\udf2b\ud9a9\udc5f\ud8c1\udd96\ud94b\udfc9\udb6e\udd87\u13f8\udb4e\udc21\udbca\udccd\ud93c\ude9d\uda65\udc86\udbcb\udd3a\udac1\uddad\uda05\udd0e\uda69\uddef\ud8bb\udd87\ua7f0\u5c2f\udb80\ude69\udba0\udec9\udaf7\udc07\ud97a\udec2\uda6f\udc3e\udb26\udf3a",
        23, 57813, 2091774946, -5706436880398198882L, -75779L, true, true, (char) 52948, (char) 45612,
        Double.longBitsToDouble(0x3fea6243b15bab7fL), Double.longBitsToDouble(0x3fe494e64c361594L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\uc280\u574a\u9066\u694a\u86e6\u7aa5\u2f40\u51d6 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\ud85b\udfc2 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 5, 5, 10, "\ud85b\udfc2", "\uc280\u574a\u9066\u694a\u86e6\u7aa5\u2f40\u51d6", "\uda55\udf38\uda64\ude02\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud849\udf96\udb51\udf14",
        45, 11026, 344955578, -7323935471994294424L, 80481L, true, false, (char) 60014, (char) 3568,
        Double.longBitsToDouble(0x3fed2c503e4114deL), Double.longBitsToDouble(0x3fca64bc50aa2334L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:\ud9a2\udd71\udbf0\udf33\ud941\udc51\ud919\ude35\ud86e\udc50\uda60\udd37\ud99c\udc4a\udbb0\udd12\udb34\udc69\ud9f2\udf36\udb71\udf5c\ud809\udf50\ud946\udd7a\ud87e\udf74\ud8f0\udfc5\udbe8\ude85\ud9b3\ude66\u0752\udbf5\udf50\u9be7\ud816\udfe7\ud9af\uddf6\udb51\udf13\ud96b\udf52\uc593 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\ud9a2\udd71\udbf0\udf33\ud941\udc51\ud919\ude35\ud86e\udc50\uda60\udd37\ud99c\udc4a\udbb0\udd12\udb34\udc69\ud9f2\udf36\udb71\udf5c\ud809\udf50\ud946\udd7a\ud87e\udf74\ud8f0\udfc5\udbe8\ude85\ud9b3\ude66\u0752\udbf5\udf50\u9be7\ud816\udfe7\ud9af\uddf6\udb51\udf13\ud96b\udf52\uc593 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 14, 14, 10, "\ud9a2\udd71\udbf0\udf33\ud941\udc51\ud919\ude35\ud86e\udc50\uda60\udd37\ud99c\udc4a\udbb0\udd12\udb34\udc69\ud9f2\udf36\udb71\udf5c\ud809\udf50\ud946\udd7a\ud87e\udf74\ud8f0\udfc5\udbe8\ude85\ud9b3\ude66\u0752\udbf5\udf50\u9be7\ud816\udfe7\ud9af\uddf6\udb51\udf13\ud96b\udf52\uc593", "\ubf38\u2985\u5581\uce88\u3277\u0178\u5f68\u50c2\u5d5d\ubfc8\u2d25\u40da", "\udb0e\udd85\uda42\udc7c\ud93b\udc16\udafe\udfb4",
        43, 78793, -1762939621, -3341191396042002910L, -93034L, true, true, (char) 20852, (char) 19334,
        Double.longBitsToDouble(0x3f9d75d81806e160L), Double.longBitsToDouble(0x3fcfe329ae9bafb4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\udb74\udd28\udbf0\udf33\uda0c\ude17\udb24\udd05\udb3a\udfe0\uda60\udcd7\ud99c\udc4a\udbb0\udd12\uda12\ude72\ud9f2\udf36\udb71\udf5c\ud8ac\udf4c\udb58\udd6c\ud7fc\uda54\udc98\udb4b\udc92\ud9b3\udd25\ud852\udd31\udbf1\udea0\u9be7\ud816\udfe7\ud9af\uddf6\ud8b6\udc18\ud823\udf4e\uc593 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 5, 10, "\udb74\udd28\udbf0\udf33\uda0c\ude17\udb24\udd05\udb3a\udfe0\uda60\udcd7\ud99c\udc4a\udbb0\udd12\uda12\ude72\ud9f2\udf36\udb71\udf5c\ud8ac\udf4c\udb58\udd6c\ud7fc\uda54\udc98\udb4b\udc92\ud9b3\udd25\ud852\udd31\udbf1\udea0\u9be7\ud816\udfe7\ud9af\uddf6\ud8b6\udc18\ud823\udf4e\uc593", "\ud53c\u2985\u5581\u4875\u229f\u90ca\u0881\u5d37\u5d5d\u1c87\uc9bb\ua4d9", "\udb28\udd92\uda83\udc9c\ud9b3\udd10\udb20\udf7f",
        6, 49712, -1762939621, -4062330286374703582L, 32044L, true, false, (char) 11441, (char) 19334,
        Double.longBitsToDouble(0x3f9d75d81806e160L), Double.longBitsToDouble(0x3fcfe329ac71fbb4L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:org.apache.commons.lang.text.ExtendedMessageFormat@0\0121=java.lang.String:\000 |this=org.apache.commons.lang.text.ExtendedMessageFormat:org.apache.commons.lang.text.ExtendedMessageFormat@0\012",
        Z.run(T, 2, 2, 5, 1, "\000", "", "\uda47\udc7e\ud9ae\udf70\udbb0\udd12\uda08\udc68\ud853\ude74\ud950\ude07\ud9f6\udc6e\udb0e\ude15\000\000\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7",
        0, 94827, 730725565, 8449446323761945274L, 96608L, true, false, (char) 62691, (char) 3571,
        Double.longBitsToDouble(0x3fd29bc07c829774L), Double.longBitsToDouble(0x3e37378800000000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:org.apache.commons.lang.text.ExtendedMessageFormat@0\0121=java.lang.String: |this=org.apache.commons.lang.text.ExtendedMessageFormat:org.apache.commons.lang.text.ExtendedMessageFormat@0\012",
        Z.run(T, 2, 2, 5, 0, "", "", "",
        20, 87742, 30760, 0L, -27036L, false, true, (char) 0, (char) 60043,
        Double.longBitsToDouble(0x3fd0e57cce62015cL), Double.longBitsToDouble(0x3fc43f729f7979d4L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\ud85b\udfc2\ud879\udf5b\udb82\udd9b\udb24\udd05\ud944\udd64\udac9\udcbe\ud841\udeec\ud8e1\ude1f\ud94d\udd30\ud8d8\ude4d\ud950\udeae\uda66\udf76\udbe1\udd9e\uda55\udfb8\udb32\udf52\ud879\udc7e\ua632\ud925\udcff\ud9b0\udff5\u9b7d\udb4b\udea0\ud865\uded2\udb51\udf05\ud823\udf4e\uc593\ud894\udff0\uda4e\udd80\u8469\uda9b\udf68\udb9c\udc96\udba0\ude24\ud87e\udc91\ud9f9\udd20\ud9b2\udd57\uda23\udcc9\ud9e7\udd3a\ud9b5\udd83 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 5, 1, "\ud85b\udfc2\ud879\udf5b\udb82\udd9b\udb24\udd05\ud944\udd64\udac9\udcbe\ud841\udeec\ud8e1\ude1f\ud94d\udd30\ud8d8\ude4d\ud950\udeae\uda66\udf76\udbe1\udd9e\uda55\udfb8\udb32\udf52\ud879\udc7e\ua632\ud925\udcff\ud9b0\udff5\u9b7d\udb4b\udea0\ud865\uded2\udb51\udf05\ud823\udf4e\uc593\ud894\udff0\uda4e\udd80\u8469\uda9b\udf68\udb9c\udc96\udba0\ude24\ud87e\udc91\ud9f9\udd20\ud9b2\udd57\uda23\udcc9\ud9e7\udd3a\ud9b5\udd83", "\u7d71\u6415\u2190\u1d63\uc1f6\u3068\ua17c", "\udbb1\udc51\ud8ea\udee4",
        17, 55934, 866951580, -1470827833876251169L, 56371L, true, false, (char) 59006, (char) 45154,
        Double.longBitsToDouble(0x3fe672834c7bccabL), Double.longBitsToDouble(0x3fdd87bbcf1128b6L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 1, 6, "\ud85b\udfc2\udb81\udd9b\u5689\udb24\udd05\ud8df\udd13\ud8b5\udd02\ud981\udcc7\udbb0\udd12\uda9d\udc27\ud853\ude6c\ud950\ude07\uda66\udf76\udbe1\udd9e\uda55\udfb8\udab1\udf32\udbaf\udeb8\ud996\udcae\ud925\udcab\udbcd\udf63\udb73\ude0a\uda9f\udda9\ud9c8\udd32\udb51\udf13\ud823\udf4e\uc593\ud95a\udff3\uda4e\udd80\udbf6\ude68\ud9b4\ude80\udacd\udc30\udaa5\udc65\ud836\udea2\uda0f\udc3d\ud9d9\udd9f", "\u755d\ub22f\u82bf\u6d23\u91c4\ua0f3\ua932\ubfa3\u5c8f\u3726\ua181\uc748\u116a\u02b6\u2f6d", "\udb9f\udfb5\udaef\udd7d\ud876\uddf9\uda5b\udc8c\udbb0\ude06\ud830\udfab\udbb9\udf3c\ud9b8\udef7\udb0f\udc87\udaf7\udeb2\udb93\udfc0\ud83a\udcfb\ud8a9\uddd9\uda86\ude40\ud979\udfd4",
        2, 2161, 1295331497, -5243250489042759141L, 48730L, true, false, (char) 61093, (char) 8001,
        Double.longBitsToDouble(0x3fb52f039936cad0L), Double.longBitsToDouble(0x3feaa4e3d7aafb18L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\udab1\udce7\ud9b9\udeae{\ud8dc\uddce\ud8a2\udefd\000", "\u1709\u4f40\u51d6", "\uda03\udd20\udad7\udd42",
        46, 17386, 1771547121, 48829608744386560L, -87162L, true, true, (char) 28264, (char) 43064,
        Double.longBitsToDouble(0x3fb810be812ee7e8L), Double.longBitsToDouble(0x3feaa6e00df0ff73L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\udab1\udce7\ud9b9\udeae{\ud8dc\uddce\ud8a2\udefd\000\uda91\udc87\uda8b\ude8e\ubc89\ud853\ude74\ud950\ude07", "\uc71c\ucc4e", "\u782a\ud8b4\ude4f\ud84c\udf85\udb25\udcd1\ud952\udca8\ud98d\udf46\udb3c\udffc\ub3d4\udb20\ude5d\ud928\udced\udad7\udf4b\u148e\ud8f7\udec8",
        55, 20060, -63407510, -8628586366650548367L, -25688L, false, false, (char) 55193, (char) 49443,
        Double.longBitsToDouble(0x3fead1e0eb96a683L), Double.longBitsToDouble(0x3fe610ea5220e39aL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\udab1\udce1\ud9b9\udeae{\ud8dc\uddce\ud8a2\udefd\000\uda91\udc87\uda8b\ude8e\ubc89\ud853\ude74\ud950\ude07\ud812\udcdb\uea0b\uda03\udd20\udad7\udd42\uf533\udb98\udd3b\u780a\ud8b4\ude4f\ud84c\udf85\udb25\udcd1\ud81b\udc8c\uda55\ude6b\ud9c8\udcf0\ud9c5\udc1f\udb39\ude4f\udbcd\ude05\udaba\udc3c\ud8a5\udfc3\ud874\udc78\udb6d\udf92\udb0c\udfa7\ud88e\ude66\ud92f\ude88\ud828\udf15\udaa8\ude93\uda94\udf77", "\u22b1\u7f29\u2f96\u837e\u9473\u74c1\u0abe\ud670\u12e3\ub36f\u7cb6\u6ee5\u0f80\u4a38", "\ud90c\udfba\ud87d\udfdb\udb6c\udc1b\ud881\udf3d\udaea\udc76\ud9f5\udef7\uda2c\uddca\uda61\ude60\udb56\udd8f\udb71\udecb\ud9bb\udd84\ud978\udc81\udb33\udd02\ud91a\udeea\ud9c5\ude16\u8415\udb21\udcf8",
        26, 20970, 1472878791, -6670683698276863168L, -29369L, false, false, (char) 8376, (char) 50769,
        Double.longBitsToDouble(0x3fe6b9649f19ba61L), Double.longBitsToDouble(0x3fe63644263f13cdL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\udab1\udce7\ud9b9\udeae{\ud8dc\uddce\ud8a2\udefd\000\uda91\udc87\uda2d\ude7f\ubd52\ud853\ude74\ud950\ude07\ud812\udc08\uea0b\uda03\udd20", "\u65c3\u1717", "\udaf8\udcaf\ud81b\udc8c",
        6, 84416, -772114387, -2522745455335362523L, 80780L, false, false, (char) 27254, (char) 3164,
        Double.longBitsToDouble(0x3fd11fd9d33ce4d2L), Double.longBitsToDouble(0x3fef453fadcf3585L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\udab1\udce7\ud9b9\udeae{\ud8dc\uddce", "\u6b1a\u8c54\u1744", "\ud812\udc08\uea0b\uda03\udd20\udad7\udd42\ud93d\udff4\udb98\udd3b\u782a\ud8b4\ude4f\ud84c\udf85\udb25\udcd1\ud81b\udc8c\ud929\udd12\udbc0\udee8\ud9c5\udc1f",
        28, 77085, -9199788, 6523496975995863279L, -76328L, true, true, (char) 7184, (char) 11210,
        Double.longBitsToDouble(0x3fe38cf422d4d5daL), Double.longBitsToDouble(0x3fe892a255048ab6L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\udab1\udc02\ud9b9\udeae{\ud8dc\uddce\ud8a2\udefd\000\uda91\udc87\uda8b\ude8e\ubc89\ud853\ude74\ud950\ude07\ud812\udc08\uea0b\uda03\udd20\udad7\udd42\ud93d\udff4\udb98\udd3b\u782a\ud8b4\ude4f\ud84c\udf85\udb25\udcd1\ud81b\udc8c\ud929\udd12\udb4f\udfdc\ud9c5\udc1f\udb39\ude4f\udbcd\ude05\udad7\udf4b\ud855\udc95\ud9c8\udcb4\uda13\udf70\u5d25\udbe3\ude50\udbe6\udca2\udb4c\udd44\udb9b\ude34\udbbd\udf3a\ud926\udcfc\ud8e1\udc9f\ud928\udd64\udb7c\uddc2\udbce\udc12\ud880\udf5d\udb1d\ude58\ud94a\udd42\ud8d8\udfdf\ud833\udf77\ud900\udd2d\ud816\udd61\ud97a\udc3c\ud9bc\udc37\ud954\udfcf\ud93b\udf53\udad0\udc25\ud999\udda8\udaf5\udc12", "\ubc0e\u32d9\ud3f7\u7bdf\u7390", "\u91a5\udb33\ude69\uda61\udd8f\ud9b8\uddcf\ud863\udcf2\ufcf8\uda18\udd0e\udba7\udeb8\uda35\udf07\udb31\uddb6\udbc3\udcd6\uda2a\uddb0\udaa8\ude3f\ud81f\udc51\ud815\udcdd\udb8c\udf34\ud84d\udf01\ud9bf\ude37\udaab\udefd\udb8d\ude20\ud92e\udca6",
        22, 71477, -819853200, -2202255874922460369L, -83713L, true, true, (char) 31460, (char) 26484,
        Double.longBitsToDouble(0x3fd41f98f792c21aL), Double.longBitsToDouble(0x3fed3cd59d8fd2ceL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\uda73\udd4a\ud9b9\udeae{\ud980\udf49\ud8a2\udef5\000 \udb6d\uddc6\u5652\u09e4\ud950\ude07\ud812\udc08\ud945\ude13\ud9e2\udf76\udad7\udd42\udb5f\udfe5\udb98\udd3b\udb76\udc34", "\uaf29\u1264\u9192\u75f9", "\udbcd\ude05\udad7\udf4b\ud90e\udef3\ud9b6\udc53\udb7d\udea9\udb47\udfa8\ud881\udf6b",
        54, 7369, -40031374, 8244179544122425758L, 69423L, true, true, (char) 18699, (char) 37267,
        Double.longBitsToDouble(0x3fe9084a6b986750L), Double.longBitsToDouble(0x3fe5651d8cdee5a3L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u7aa5\u4f40\004", "\uda55\udfb8\uda76\udd54\ud903\udeee\u18a1\ud903\udd21\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, 11026, 344955578, -7323935472436783533L, 96608L, true, false, (char) 62691, (char) 79,
        Double.longBitsToDouble(0x3fd29bc07c829774L), Double.longBitsToDouble(0x3fe07f38eae6f1eaL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\udab1\udce7\ud9b9\udeae{\000", "", "\ud90e\udc5a\udb4b\ude1c\ud966\udd44",
        -5, 56867, 1459617792, 1474563898605286828L, -100000L, false, false, (char) 0, (char) 3962,
        Double.longBitsToDouble(0x3fe1302e8f5928b4L), Double.longBitsToDouble(0x3f81b2c00b4c3600L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 12, "\uda73\udd4a\ud9b9\udeae{\ud980\udf49\uda55\udc2f} \udb6d\uddc6\u5652\u09e4\ud950\ude07\ud812\udc08\ud945\ude13\ud90c\uddcc\ud8f1\udc1f\udb5f\udfa6\udb98\udd3b\udb75\udc42", "\uaf29\u1264\u9192\u75f9\u61a1\u4145\u7629\u86ad\uc1dc\uad33\u526e\u4aa0\u4c5b\ubfa3", "\ud82c\udd5c\u2b98\ud9db\uddc4\uda2e\udd83\u48ed\udb03\udc9f\ud91f\uddba\uda9c\udd37\ud975\ude27",
        37, 29214, 429009487, 1047829997560819641L, -74337L, false, true, (char) 53559, (char) 39402,
        Double.longBitsToDouble(0x3fe4cc96daa8a422L), Double.longBitsToDouble(0x3fd37a5a8d736b68L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 15, 10, 10, "\uda0c\udd5e\udb37\ude0b\ud939\udda1\ud925\ude43\ud867\udda0\udbf0\udc3f\u5f05\ud9ca\udd22\uda08\udcbc\udb23\udcdc\ud950\ude07\uda66\udf76\udbe1\udd9e\uda55\udfb8\uda64\ude02\ud903\udeee\ua632\ud925\udcff\ud9f1\uddf5\uda4d\uddff\ud891\udf5d\ud928\udde5\udb0b\udf90\ud823\udf4e\uc593\uda20\udd76\uda7b\udcb1\ud96b\udc3d\udba3\ude21\udb88\udf8d\udaff\ude69\uda3c\udd0d\ud813\ude0d\uda90\udd56\udb7f\udcb6\ud9e7\ude0e\ud979\udef7\udbc3\udfa2\udaf6\udedf\ud941\ude72\uda08\udfa1\ud89c\udc2f\ud914\ude32\udb0d\udd63\udabb\udf0e\ud813\udcad\ud80b\udd77\udb10\udcb5\udb13\ude6a\uda71\udd48\udb2f\ude75\ud8d3\udcc9\ud9fa\udd05\udb49\ude1c\ud8db\udee1\uda86\ude11\udb7b\udf82\udb45\udf75\ud980\udcd7\uda55\uddf9\ud8be\udd63\ud939\uddae\udba6\udd5a\u4da2\uda25\udd8a\uda4a\ude5e\udbd8\udf49", "\u638c\u6524\uae11\u2837\u667c", "\ud9a4\udf48\ud905\udc9d\ud85e\udf5d\ud9e6\ude15\udbba\udf91\udbd0\udc43\u4bc5\udbf3\udffa\ud89e\ude0f\ud829\udcba\udb69\ude6d\ud993\uddf8\uda1f\ude31\udb2d\udd6e\ud870\ude32\udb98\udf9f\udbcd\udff4\ud8ee\udfc5\u7395\ud819\udd72",
        13, 42085, 1851297645, 2920431073629086725L, -54817L, true, true, (char) 54940, (char) 25574,
        Double.longBitsToDouble(0x3fdabcbf18b0c4f6L), Double.longBitsToDouble(0x3feaf6c672050d10L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 12, "\000\ud872\ude5b\udb79\udf9b\udb24\udd05\ud8df\udd13\udbf0\udc3f\udae6\udf6c\udbb0\udc5f\ud99a\udf71\udaef\udfe7\udb01\udf2f\ud98e\udc3d\ud85f\uddbd\ud9ab\ude5e'\000\000\ud925\udc21\udaf8\udef8\021\ud816\udfc8\ud9c8\udd5b\udb51\udf13\ud823\udf4e\udaed\udd90\udb7c\udef0", "\u2e58\u56e4\u98d2\u5f67\uc767\u0fea\u50c2\u5e01\u755d", "\uda17\udc30\uda61\ude2d\u00e8\000\uda5a\uded9\ud93e\ude90\ud949\udd03",
        28, 57989, -1115330105, -1385730107203474124L, 96608L, true, true, (char) 54389, (char) 43796,
        Double.longBitsToDouble(0x3f411620290b9800L), Double.longBitsToDouble(0x3fe1bea264b6f8a2L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 1, "\uda66\udcde\ud9b9\udeae{\ud980\udf49\ud8a2\udef5\ud92c\udf6b{\udb6d\uddc6\uea52\u09e4\ud950\ude07\ud812\udc08\ud945\ude13\ud84c\uddeb\ud99d\ude7c\udb63\udd26\udb98\udd3b\udb76\udc34", "\uaf29\u1264\u9192\u75f9", "\udbcd\ude05\ud82e\udf77\udb32\udf8f\ud80d\udede\udbbf\udee1\udb47\udfa5\ud881\udf6b",
        54, 7369, -1758129294, 8244179544122425758L, 69423L, true, true, (char) 18658, (char) 37267,
        Double.longBitsToDouble(0x3fe9084a6bcf6750L), Double.longBitsToDouble(0x3fe5651d8cdee5a3L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 1, "\uda73\udd4a\ud9b9\udeae{\ud952\udd12\ud8bc\udfdc  \udaf1\udfe1\udbfc\udcd8\ud9ab\uddde\udbbe\udfa2\ud81b\udd49\ufe10\ud9e2\udf76\udad7\udd42\udb41\udee5\udb98\udd3b\udb76\udc34", "\uaf87\u1264\u8118\u2607", "\uda16\ude41\udad7\udfd9\ud90e\udef3\ud9b6\udc53\uda89\udc4f\ud920\udc46\uda7a\udc47\ud8bd\ude2e\ud95d\udc88",
        41, 92630, 1907938925, 4001308032715363731L, 22870L, true, true, (char) 63804, (char) 20102,
        Double.longBitsToDouble(0x3fe5651d8cdee5a3L), Double.longBitsToDouble(0x3fe43c350f992543L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 12, "\000\ud818\udff1\ud96a\uddd0\udb24\udd05\ud8df\udd13\udbf0\udc3f\uda6f\udd8f\udbb4\udc4b\ud99a\udf71\udaef\udfe7\udafc\udf20\ud98e\udd20\ud85f\uddbd\ud9ab\ude5e'\uda93\udde8\000\ud925\udc21\udaf8\udef8\ud9bd\udfa8\ud83e\udc5d\ud9c8\udd5b\ud81a\uddf7\uda0b\udde1\udb66\udeb8\ud9b2\udc31", "\ua406\u5748\u98d2\u5f67\uc83f\u7751\u50c2\u5e01\u755d", "\ud9dd\udd9f\ud916\udce9\ud95a\udd38\000\uda5a\uded9\ud82a\udee7\ud949\udcbd",
        59, 57817, -1115330105, -1385730107203474124L, 92504L, false, true, (char) 29393, (char) 59484,
        Double.longBitsToDouble(0x3e9363b09de00000L), Double.longBitsToDouble(0x3fd9496e1894bd94L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 12, "\000\ud872\ude5b\udb79\udf9b\udb24\udd05\ud8df\udd13\udbf0\udc3f\udae6\udf6c\udbb0\udc5f\ud99a\udf71\udaef\udfe7\udb01\udf2f\ud98e\udc3d\ud85f\uddbd\ud9ab\ude5e'", "", "\021\ud816\udfc8\ud9c8\udd5b\ud9e6\udf9d\ud823\udf4e\udaed\udd90\udb7c\udef0\uda4e\udd80\udbfc\udc63\ubf74\udb9c\udc96\udba0\ude24\udab5\udf0d\ud83c\udffe\ud9d2\ude9f\uda23\udcc9\ud9e7\uddde",
        30, 27260, -240682966, 7883478296454112834L, -100000L, false, false, (char) 30272, (char) 58032,
        Double.longBitsToDouble(0x3fb49b5091ae0d28L), Double.longBitsToDouble(0x3fdc758ddb9f7b0aL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 5, 1, "\uda7a\udc75\ud9b9\udedc{\ud980\udf49\ud8a2\udef5\ud92c\udf6b{\udb6d\uddc6\ud8d9\ude93\uda88\udde6\ud950\ude07\ud812\udc08\ud945\ude13\ud856\udfeb\ud9ce\udc7c\udb63\udd26\ud839\udc2a\udb6e\uddd2", "\uaf29\u1264\u9192\u75f9", "\udbcd\ude05\ud82e\udf77\udb32\udf8f\ud80d\udede\udbbf\udee1\udb47\udfa5\ud89e\udcd2",
        5, 7369, -1758129294, 8244179544122425758L, 69423L, true, true, (char) 18658, (char) 44213,
        Double.longBitsToDouble(0x3fead7ecc3cf679cL), Double.longBitsToDouble(0x3fe5651d8cdee5a3L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud964\udcfe\ud9b9\udeae{\ud950\udcba\ud8a2\udef5\ud92c\udf6b{\udb6d\uddc6\uea52\ud9de\udfb1\ud96d\ude08\ud812\udc08\ud945\ude13\udbd9\ude0a\ud842\udeb8\udb63\udd26\udb98\udd3b\udb76\udc34\udb88\udf3e", "\u1264\u7372\u76ce\u61a1", "\ud837\udd93\udb32\udf8f\ud80d\udede",
        18, 25059, -1318710259, -362674342362474127L, 82882L, false, false, (char) 19662, (char) 32739,
        Double.longBitsToDouble(0x3fdfcb5040034078L), Double.longBitsToDouble(0x3fd62c376642449aL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 1, "\u60d6\udb3c\ude46'\ud954\udd49\ud9d4\udead\ud92c\udf6b{\udae2\udc87\ud9d0\udd77\ud9de\udc23\udaf6\udd1a\udb64\udc9e\uda9d\ude1a\udb97\udc51\ud813\ude77\udb63\udd26\ue56b\udb14\udf1d", "\u5b81\uaa6c\u9192\u75f9\u61a1\u66e1\u757b\u2ca4\ub25c\u9dc0\u7b7b\u137b\u6743\ubfa3\u6436\u67c4\u6ee2\u3145\u0d1d\uba12\u457f\u92c2\u0142\u2630\uae67\ub76d\uc494\u39c8\u77b5", "\ud89f\udfe9\ud970\udd30",
        32, 23281, 1362183055, 6216100952102659272L, 39967L, false, false, (char) 17330, (char) 40723,
        Double.longBitsToDouble(0x3fad52d7305c5020L), Double.longBitsToDouble(0x3fd0cd00b8095898L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 12, "\000\ud818\udff1\ud96a\uddd0\udb24\udd05\ud8df\udd13\udbf0\udc3f\uda6f\udd8f\udbb4\udc4b\ud99a\udf71\udaef\udfe7\udad2\ude6b\ud98e\udc2e\ud85f\uddbd\udaa3\ude42'", "\u8d50", "\ud83e\udc5d\ud9c8\udd5b\ud81a\uddf7\uda0b\udde1\udb66\udeb8\ud84c\udfcf\udab6\udf77\uda76\udf61\udb6c\ude37\udb9c\udcfa\udba0\ude24\udab5\udf0d\ud9ef\udf37\u145a\uda23\udca4\ud9e7\uddde\ud81b\udca8\udb0a\ude07\uda2d\udf51\ud9dd\udd9f\ud916\udce9\ud95a\udd38",
        -5, 26638, 983156464, 7873021026062264402L, -7385L, true, true, (char) 39416, (char) 50745,
        Double.longBitsToDouble(0x3fc6c2ffb81a8c6cL), Double.longBitsToDouble(0x3fefc05a7f24cd5eL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 5, 1, "\u60d6\udb3c\ude46'\ud954\udd49\ud9d4\udead\ud92c\udf6b{\udae2\udc87\ud9d0\udd77\ud9de\udc23\udaf6\udd1a\udb64\udc9e\uda9d\ude1a\udb97\udc51\ud813\ude77\udb63\udd26\ue56b\ufb7c", "\u2bb3\uaa6c\u9192\u75f9\u61a1\u66e1\u5b7c", "\ud80d\udede\udbbf\udee1\udbfe\uddba\udb82\udff2\ud84a\udd86\uda6c\udc78\uda97\udc85\ud961\uddb4\udaff\udc6d\ud961\udcce",
        54, 88851, -1944189925, -6118934046818913347L, -79180L, false, false, (char) 22564, (char) 48952,
        Double.longBitsToDouble(0x3fc044ae6e930444L), Double.longBitsToDouble(0x3fee4d61d670be42L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 3, "\u60d6\udb3c\ude46'\ud954\udd49\ud9d4\udead\ud92c\udf6b{\udae2\udc87\ud9d0\udd77\ud9de\udc23\udaf6\udd1a\udb64\udc9e\uda9d\ude1a\udb97\udc51\ud813\ude77\udb63\udd26\ue56b\udb14\udf1d", "\u5b81\uaa6c\u9192\u75f9\u61a1\u66e1\u757b\u2ca4\ub25c\u9dc0\u7b7b\u137b\u6743\ubfa3\u6436\u67c4\u6ee2\u3145\u0d1d\uba12\u457f\u92c2\u0142\u2630\uae67\ub76d\uc494\u39c8\u77b5", "\ud89f\udfe9\ud970\udd30",
        32, 23281, 1362183055, 6216100952102659272L, 39967L, false, false, (char) 17330, (char) 40723,
        Double.longBitsToDouble(0x3fad52d7305c5020L), Double.longBitsToDouble(0x3fd0cd00b8095898L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 1, "\u60d6\udb5a\udc46'\ud954\udd49\uda48\udffa\ud92c\udf6b{", "\u8851\u2458\u0899\uc71c\ud616\u83c0\u4e71\ua9e9\ua9f2\u17cd\uc984\u33a0", "\udb4f\udfdc\udab1\udd76",
        47, 32581, -1099694210, -1556347104131897713L, -74040L, true, false, (char) 14063, (char) 5225,
        Double.longBitsToDouble(0x3fefd165c3de3a76L), Double.longBitsToDouble(0x3fa599cc02d9cd90L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 7, "\u60d6\udb3c\ude46'\ud954\udd49\ud9d4\udead\ud92c\udf6b{", "\u8e27\u9e2c\u0899\uc71c\ud616\u83c0\u4ecd\ua9e9\u1c29\u399d\ucb7a\u2bb3", "\udb46\udd66\udab1\udd76",
        47, 24725, -1099695532, -3659528130106330994L, -49002L, true, true, (char) 39801, (char) 27032,
        Double.longBitsToDouble(0x3fe39372b6f2df5dL), Double.longBitsToDouble(0x3fd9e72b27d14feaL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\u8851\u2458\u0899\uc71c\ud616\u83c0 |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 15, 5, 1, "\u60d6\udb5a\udc46'\ud954\udd49\udb82\uddb7\ud87d\uddfb{", "\u8851\u2458\u0899\uc71c\ud616\u83c0", "\udbaa\udd8d\udb52\udf0f\udba4\udfee\ud84e\udfe3\ud98b\udcf4\ud929\udd12\udb4f\udfdc",
        3, 49728, -103351565, -4723150667912921410L, 7058L, false, true, (char) 13858, (char) 18415,
        Double.longBitsToDouble(0x3fd71faf77f45970L), Double.longBitsToDouble(0x3feef1d3b42b3398L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:org.apache.commons.lang.text.ExtendedMessageFormat@0\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\000", "\uc533=\u7b5b\u7828\u86e6\u7aa5\u4f40\u51d6", "\uda03\udd20",
        8, 55233, 1584732321, -3508999147693705716L, 61450L, false, false, (char) 15373, (char) 28847,
        Double.longBitsToDouble(0x3fdfadf85e02fca8L), Double.longBitsToDouble(0x3fe038d73f0945dbL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 5, 1, "\u60d6\udb3c\ude46'\ud910\udec6\udb0b\udc48\uda17\udfcc'\udae2\udc87\ud9d0\udd77\ud9de\udc23\udaf6\udd1a\udb64\udc9e\uda9d\ude1a\udb97\udc51\ud813\ude77\udb63\udd26\ue56b\udb14\udf1d", "\u5b81\uaa6c\u9192\u75f9\u6216\u66e1\u757b\u35a3\ub25c\u9dc0\u7b7b\u137b\u6743\ubfa3\u6436\u67c4\u6ee2\u3145\u0d1d\uba12\u457f\ub356\u0142\u2630\uae67\ua2af\uc471\u39c8\u77b5", "\ud89f\udfe9\ud970\udd30",
        32, 23281, 1362183055, 6216100952102659272L, 39967L, false, false, (char) 17330, (char) 40723,
        Double.longBitsToDouble(0x3fad52d7305c5020L), Double.longBitsToDouble(0x3fd0cd00b8095898L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 15, 1, "\u60d6\udb3c\ude46'\ud910\udec6\udb0b\udc48\uda17\udfcc'\udae2\udc87\ud9d0\udd77\ud9de\udc23\udaf6\udd1a\udb64\udc9e\uda9d\ude1a\udb97\udc51\ud813\ude77\udb63\udd26\ue56b\udb14\udf1d", "\u5b81\uaa6c\u9192\u75f9\u6216\u66e1\u757b\u35a3\ub25c\u9dc0\u7b7b\u137b\u6743\ubfa3\u6436\u67c4\u6ee2\u3145\u0d1d\uba12\u457f\ub356\u0142\u2630\uae67\ua2af\uc471\u39c8\u77b5", "\ud89f\udfe9\ud970\udd30",
        32, 23281, 1362183055, 6216100952102659272L, 39967L, false, false, (char) 17330, (char) 40723,
        Double.longBitsToDouble(0x3fad52d7305c5020L), Double.longBitsToDouble(0x3fd0cd00b8095898L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=java.lang.String:\u60d6\udb3c\ude46'\ud910\udec6\udb0b\udc48\ud9ef\udda4'\udae2\udc87\ud9d0\udd77\ud9de\udc23\udaf6\udd1a\ud817\udc1d\udb97\udc37\udb76\udeac\ud815\udd29\udb63\udd26\ue56b\udb14\udf1d |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 3, 5, 1, "\u60d6\udb3c\ude46'\ud910\udec6\udb0b\udc48\ud9ef\udda4'\udae2\udc87\ud9d0\udd77\ud9de\udc23\udaf6\udd1a\ud817\udc1d\udb97\udc37\udb76\udeac\ud815\udd29\udb63\udd26\ue56b\udb14\udf1d", "\u5b81\uaa6c\u9192\u75f9\u6216\u66e1\u757b\u35a3\ub25c\u9dc0\u7b7b\u137b\u3a5e\u7360\u6481\u67c4\u6ee2\u3145\u0d1d\uba12\u457f\ub356\u0142\u2630\uae67\ua2af\u45a1\u3a68\ua4ed", "\ud89f\udfe9\ud970\udd30\ud97c\ude87",
        56, 96055, 1447298786, -5617144562796455966L, 59539L, true, false, (char) 4523, (char) 17330,
        Double.longBitsToDouble(0x3fe19e47043aa5aeL), Double.longBitsToDouble(0x3fe82e28110cd00bL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 10, 1, "\ud85b\udfc2", "\uc533\u574a\u7b5b\u694a\u86e6\u9ba5\u4f40\u51d6", "\uda55\udfb8\uda76\udd54\ud903\udeee\ua632\ud925\udcff\ud9b0\udff5\u9b7d\ud816\udfe7\ud9c8\udd5b\udb51\udf13",
        45, 11026, 344955578, -7323935469814825133L, -12233L, true, false, (char) 47501, (char) 19665,
        Double.longBitsToDouble(0x3fe6e4b0ab2af1eeL), Double.longBitsToDouble(0x3fda0b566685a0aeL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=new org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 15, 15, 12, "\ud85b\udfc2\ud879\udf5b\udb5e\udd9b\ud83b\udf07\uda10\udc64\ud9d2\udf50\ud815\uded1", "\uadab\u51d6\u62d3\u7288\uaa6d\u869a", "\ud9b5\udc7d\ud9b0\udff5\u9b7d\ud92e\udf68\ud959\ude65",
        1, 90565, 1854986410, -3900066675703403225L, 56538L, false, true, (char) 49021, (char) 18311,
        Double.longBitsToDouble(0x3fd3a9fd6667c2bcL), Double.longBitsToDouble(0x3fe1d28ef89108eaL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 2, 1, 6, "\ud85b\udfc2\udb81\udd9b\u5689\udb24\udd05\ud8df\udd13\ud8b5\udd02\ud981\udcc7\udbb0\udd12\uda9d\udc27\ud853\ude6c\ud950\ude07\uda66\udf76\udbe1\udd9e\uda55\udfb8\udab1\udf32\udbaf\udeb8\ud996\udcae\ud925\udcab\udbcd\udf63\udb73\ude0a\uda9f\udda9\ud9c8\udd32\udb51\udf13\ud823\udf4e\uc593\ud95a\udff3\udb1d\ude7e\udbf6\ude68\ud9b4\ude80\uda1e\udcd8\udaa5\udc65\ud836\udea2\uda0f\udc3d\ud9d9\udd9f", "\u755d\ub22f\u82bf\u6d23\u19c1\ua0f3\ua932\u0db9\uc54f\u3726\ua181\uc748\u811d\u02b6\u2f6d", "\udb9f\udfb5\udaef\udd7d\ud876\uddf9\uda5b\udc8c\udbb0\ude06\ud830\udfab\udbb9\udf3c\uda2c\udef1\udb0f\udc87\udaf7\udeb2\udb93\udfc0\ud83a\udcfb\ud8a9\uddd9\uda86\ude40\ud979\udfd4\ud87a\udc61\ud9b5\udc4a\udb27\udd35\ud8bb\udf2c\udac9\udf0d\ud9bf\udcbe\ud949\udd55\udbf5\udd0d\uda88\ude21\udbe9\ude6f\udbce\ude0c\uda09\udd48\uab0a\udaec\udf24\ud99b\udc36\ud9f5\udd6a\udaef\ude6d\ud8ad\uddfe\ud9fb\udefe\udb51\udd02\ud939\udd5d\ud8da\udfc9\ud918\ude0c\udb97\udf11\ud8d3\ude39\udad7\udc45\ud98e\udf42\uda6b\udc94\ud81e\ude75\uda1a\udfef\ud804\udf21\udaed\udcc0\ud99c\udcde\ud9fc\udec0\ud85a\udc61\ud8c2\ude79\ud9a5\udf64\ud98a\udf03\udbfe\ude09\udb73\uddae\uda2d\udd9e\ud999\udf67\ud82e\udf17\udb4f\udfe6\udb3d\udfe7\uda5e\udd0c\ud9f6\udee4\ud89e\udd63\uda42\udc6a\uda2a\udf8a\ud836\udc72\ud99b\udeca\uda04\udda9\ud808\udd4e\ud8a3\udfed\ud9c2\udf1d\u13b8\ud807\uddbe\ud97a\udcde\ud8ac\udd2b\ud900\udcef\udbe0\udf85\u15e7\ud8ba\udd88\udafe\uddd3\uda1e\ude07\ud9a0\udc93\ud95c\udfd6\ud875\udfbc\udbc4\udee2\uda34\udfb0\ud821\udf7f\udb7c\udfe2\ud8d5\udcbb\ud9da\udd8a\ud818\udceb\ud962\udf80\ud85c\udd7e\ud969\ude05\ud9bb\udc44\udae9\udc69\ud959\udea7\uda01\udc3a\udb72\udcc8\udae1\ude47\udaef\udf0e\udb4b\udff1\udb78\udd3a",
        9, 68659, -1898502404, -8752890744443246570L, -84333L, false, true, (char) 40799, (char) 53997,
        Double.longBitsToDouble(0x3fec352f38643800L), Double.longBitsToDouble(0x3febdf4d6c8dee5eL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 15, 1, "\ud886\udc6a\udb04\uddf0{\ud910\udec6\udb0b\udc48\uda17\udfcc'\udae2\udc87\ud9d0\udd77\ud9fb\udcad\udaf6\udd1a\udb64\udc9e\uda9d\ude1a\u3153\ud978\ude0a\udb63\udd26\ue56b\udb14\udf1d", "\u5b81\ub0d7\u5275\u75f9\u6216\u66e1\u757b\u35a3\ub25c\u9dc0\u5fa1\u137b\u6743\ubfa3\u6436\u67c4\u6ee2\u3145\u0d1d\uba12\u457f\ua3be\u0142\u2630\uae67\ua2af\uc471\u39c8\u77b5", "\ud89f\udfe9\ud970\udd30",
        32, 23345, 1362183055, 6216100952102659272L, 39967L, false, false, (char) 17330, (char) 40723,
        Double.longBitsToDouble(0x3fad52d7305c5020L), Double.longBitsToDouble(0x3fd0cd00b8095898L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 4, 0, "\ud886\udc6a\udb04\uddf0{\ud910\udec6\udb0b\udc48\uda17\udfcc'\udae2\udc87\ud9d0\udd77\ud9fb\udcad\udaf6\udd1a\udb64\udc9e\uda9d\ude1a\u3153", "\ua9e9\u2ab2\u17cd", "\uda7e\udcd3\ud919\uddf5\udb4f\udfdc\udb59\udea7\udb39\ude4f\udbcd\ude05\ud811\udf77\udb32\udf8f",
        54, 13406, -1046452888, -5668777933637450341L, 14290L, false, false, (char) 29598, (char) 55793,
        Double.longBitsToDouble(0x3fc630f0afeedba8L), Double.longBitsToDouble(0x3fd1b44c7bcfb374L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 15, 1, "\ud886\udc6a\udb04\uddf0{\ud910\udec6\udb0b\udc48\uda17\udfcc'\udae2\udc87\ud9d0\udd77\ud9fb\udcad\udb14\ude25\ud89b\udfc1\uda9d\ude38\u3153\ud978\ude0a\udb63\udd26\ue56b\udb14\udf1d\udb52\udf0f\ud82e\udd93\ud981\udc93\uda7e\udcd3\ud919\uddf5\udb4f\udfdc\udb59\udea7", "\u35a3\ub25c\u2075", "\ud857\udfde\ud80b\udd4f\uda49\udff1\uda97\udc85\ud961\uddb4\udaff\udc6d\ud961\udcce\ud99d\udc62\uda72\udc08",
        3, 29647, 1733342141, -6651434231901475156L, -32573L, true, true, (char) 12640, (char) 15550,
        Double.longBitsToDouble(0x3fee4d637e70be42L), Double.longBitsToDouble(0x3fead5378049f20aL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\0121=void |this=org.apache.commons.lang.text.ExtendedMessageFormat:@?\012",
        Z.run(T, 2, 1, 1, 0, "\uda7a\udc75\ud9b9\udedc{\udbd6\udcff\ud8a2\udef5\ud92c\udf6b{\udbc5\udd51\ud8d9\ude93\udb3e\udd4b\ud9e5\udcb5\ud812\udc08\ud945\ude13\udba5\udc72\ud9ce\udcf4\udb63\udd26\ud839\udc2a\udb6e\uddd2\udb53\udda4\udbb1\udd50\uda36\udcae\ud81b\udc8c\ud929\udd12\udb6c\udcde\udab1\udd76\udb37\ude97\udbcd\ude05\ud82e\udf77\udb32\udf8f\ud80d\udede\udad5\udf6d\udbd0\uddb3\ud86b\udd38\ud88f\udc7a\uda49\udff1\ua545\ud80d\udc5c\udaff\udc6d", "\u457f\u28be\u4d48\ua3ea\u6795\uade7\u3ef1\u294e\u2921\u5a0a\u6858\u7db8\u7c13", "\udbf6\udc58\uda78\udf36\ud945\ude8f\uda40\udd02",
        -5, 59917, 1665974435, -4100933824642083955L, 90431L, true, false, (char) 2365, (char) 62834,
        Double.longBitsToDouble(0x3fe5e00344b3058aL), Double.longBitsToDouble(0x3fe881591470fca2L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 15, 1, "\udab4\udeb1\udbc6\udf0b{\ud910\udec6\udb0b\udc48\uda17\udfcc'\udae2\udc87\ud9d0\udd77", "\u0899\uc71c\u3b2d\ucac4", "\udb14\udf1d\udb52\udf0f\udba4\udfee\ud981\udc93\uda7e\udcd3\ud919\uddf5\udb4f\udfdc\udb59\udea7\udb39\ude4f\udbcd\ude05\ud811\udf77\udb3d\udd24\ud80d\udede\ud813\ude4b",
        46, 76708, -84459322, 7950570164743683698L, -1282L, false, true, (char) 28726, (char) 29820,
        Double.longBitsToDouble(0x3fd1b44c7bcfb374L), Double.longBitsToDouble(0x3feded58abcf6750L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 15, 6, "\udb8e\udc6e\udb04\uddf0{\ud910\udec6\udb0b\udc48\uda17\udfcc'\u46c6\ud9d0\ude05", "\u0899\uc71c\u3b2d\ucac4", "\ud83e\udc73\udb52\udf05\udba4\udfee\ud981\udc93\uda7e\udcd3\ud919\uddf5\ud9ee\udfcc",
        0, 32714, -603908134, 1518667261504469184L, 72594L, false, true, (char) 13858, (char) 14063,
        Double.longBitsToDouble(0x3fd71faf7ae4dcacL), Double.longBitsToDouble(0x3fe796fa899e72b2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|appendQuotedString|java.lang.String,java.text.ParsePosition,java.lang.StringBuffer,boolean|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|applyPattern|java.lang.String|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|containsElements|java.util.Collection|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|getFormat|java.lang.String|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|getQuotedString|java.lang.String,java.text.ParsePosition,boolean|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|insertFormats|java.lang.String,java.util.ArrayList|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|next|java.text.ParsePosition|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|parseFormatDescription|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|readArgumentIndex|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|seekNonWs|java.lang.String,java.text.ParsePosition|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|setFormat|int,java.text.Format|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|setFormatByArgumentIndex|int,java.text.Format|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|setFormats|[Ljava.text.Format;|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|setFormatsByArgumentIndex|[Ljava.text.Format;|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|toPattern||new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
    "C|org.apache.commons.lang.text.ExtendedMessageFormat|<init>|java.lang.String",
    "M|org.apache.commons.lang.text.ExtendedMessageFormat|appendQuotedString|java.lang.String,java.text.ParsePosition,java.lang.StringBuffer,boolean|new:org.apache.commons.lang.text.ExtendedMessageFormat:java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
