package org.apache.commons.lang3.reflect;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 22, 8, 2, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8b8\udcf5", "\u4d97", "\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        4, 32943, -1303045202, -2863393357225700289L, 59083L, false, true, (char) 27218, (char) 46084,
        Double.longBitsToDouble(0x3fe930cf07a1d2acL), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 22, 2, 21, "\udb67\udd01", "\u3e68\u802a\u4ee0\u4d97\u3fd3\ud03e", "\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10\ud8a9\ude6f\uda7e\uded7\ud8df\udf1a\ud9dd\udc92\uda5c\udfa2\ud908\udfc3\ud8bc\ude1e\uda97\udccd\ud8e3\udf72\ud978\udd00\ud874\udc7a",
        -5, 99883, -1903694397, 909130614131483584L, -44067L, true, false, (char) 57630, (char) 54693,
        Double.longBitsToDouble(0x3fef3521dcd970bcL), Double.longBitsToDouble(0x3fe1dfe6afae513eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 20, 7, 2, "\udb67\udd01\ud97e\udf34\ud884\udf3b\ud8b8\udcf5", "\u4d97", "\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        4, 32943, -1303045202, -3151623733740521903L, 58985L, false, true, (char) 27218, (char) 9477,
        Double.longBitsToDouble(0x3fe930cbe7a1d2acL), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 22, 8, 2, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8b8\udcf5", "\u4d97\u3fd3\ud03e\u6a7c\ub19b", "\ud85a\udcdd\ud8e6\ude2c",
        19, -492, 1355841964, -799332314607445074L, 75041L, false, true, (char) 31909, (char) 8654,
        Double.longBitsToDouble(0x3fe4ce21177a0c54L), Double.longBitsToDouble(0x3fe930cf07a1d2acL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 21, 15, 2, "\u6d12\ud935\udfd0\uda34\udcca\uef4b\udaf0\udd29\udae9\udf20\ud957\udf43\ud89f\udf6d\udaa5\uddd8", "\uccaa\uc56b\uc8ae\ub456\u70e5\u04a1\ua899\u5d8f\u8fa0\u9cf0\ua3c4\ube50\u3fba\u1a92\u7dcd\u5801\u3407\u48ed\u66fb\u3f5b\u1cce", "\udba0\udf5b\u524f\ud893\udcab\uda98\ude4f\ud8a5\udd64\ud8fc\udf68\ud831\udd2f",
        55, 60395, -1975221207, -6974975079240123545L, 80623L, true, false, (char) 36495, (char) 61320,
        Double.longBitsToDouble(0x3fea34f028798030L), Double.longBitsToDouble(0x3fd0a17e883b49e2L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 18, 13, 19, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43\u05d3", "\uc9fe\u492c\u3d6c\u4071\ub456\u48ed", "\uda7e\uded7",
        43, 14282, -1705421761, -6087192166570803847L, -75093L, false, true, (char) 35334, (char) 13246,
        Double.longBitsToDouble(0x3fd6f5ea31edc1b2L), Double.longBitsToDouble(0x3fa1083517fc2d60L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 8, 2, "\uda1d\udd5c\ud97e\udf34\uda42\udf90\ud8ee\uded0", "\u4d97\u3fd3", "\ud950\udcf1\ud9c7\udf68\ud8e6\udec8\ud9c3\udc05\ud835\udc4f\udb2d\udf1d",
        48, 16964, -186109057, -5596536528466399510L, -22170L, true, false, (char) 56366, (char) 46291,
        Double.longBitsToDouble(0x3febd0645c5519b4L), Double.longBitsToDouble(0x3fed0ef89b1b3362L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Number\012",
        Z.run(T, 1, 14, 8, 3, "\udb67\udd01\udaff\udc61\uda3b\udd4b\ud8b8\udcf5", "\u4d97", "\u12b2\ud950\udcf1\udbdb\uddf4\ud9e2\udc46",
        1, 42355, -1044032446, 7207017435429403564L, 75041L, false, false, (char) 31909, (char) 13086,
        Double.longBitsToDouble(0x3fedae5cf09b67e7L), Double.longBitsToDouble(0x3fe930cf07a1d2acL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 22, 5, 9, "\udb67\udcc9\ud97e\udf34\uda42\udf3a\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43\u05d3\udac5\udd4d\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c", "\u213c\u3659\u8fa0\u17d1\ua3c4\uc206", "\ud8e3\udf72\ud978\udd00\ud88a\udfe5\u0093\ud924\udfff\ud93f\udc83\ud8c7\udc5a\ud85d\udef7\uda01\udfea\udb26\udf45\ud86e\udfe5\udb3f\udc9e\ud943\udc44\udaa4\udfcd\uda1c\udff1\ud897\udc99\ud88f\udd99\ud821\udf41\ud9a6\udf3c\udbe6\uddb3\uda02\ude59\udb05\udd46\udb4d\udfd6\ud920\ude6e\udbb5\ude4a\ud815\udda2\ud8d4\udf30",
        41, 39805, 1678133502, -6432955975829671621L, 4384L, false, true, (char) 20380, (char) 7244,
        Double.longBitsToDouble(0x3fc62de200696054L), Double.longBitsToDouble(0x3fc3f443c7332d94L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 16, 8, 0, "", "", "\u03c5\ud883\uddad\ud957\udf43\u05d3\udaa5\udd4d\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10\udbcf\ude62",
        36, 55798, -666685718, 92629815132410L, -100000L, true, false, (char) 46084, (char) 17670,
        Double.longBitsToDouble(0x3fed0e95631b3362L), Double.longBitsToDouble(0x3fdc30f225329cfaL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 8, 5, 2, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8b8\udcf5", "\u4d82", "\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud88b\udc32\udb2d\udf1d\udae4\udfbd",
        23, 32943, -1303045202, -2863393356101626817L, 59083L, false, true, (char) 27218, (char) 46084,
        Double.longBitsToDouble(0x3fde919e0f43a5a8L), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 19, 2, "\udb67\udd01\ud97e\udf34\uc03e\ud8b8\udcf5\ud91e\udc12\ud883\udd88", "\u224d\u6a7c\ub19b\u4a06\ub4ef\u8156\u9028\u48ed\u7eb6\u259a\ucfd4", "\udbbe\udede\uda87\udd70\ud8b6\udf5c\ud8e3\udd2e\udb46\udc38\ud978\udd00\ud874\udc7a\ud89e\udea8\ud924\udfff\ud90d\udc6a\udada\udfb9\ud80a\udc57",
        35, 61073, -1570215758, 7046481849145398276L, -56492L, true, false, (char) 5179, (char) 55868,
        Double.longBitsToDouble(0x3fef136f0f46ef52L), Double.longBitsToDouble(0x3faff7d63d6aa6b0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 18, 0, "\udbb2\udf75\udadd\udd38\ue7c4\ud8b8\udcf5", "\u4d97", "\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        4, 32943, -1303045202, -2863393357225700289L, 59083L, false, true, (char) 27218, (char) 51460,
        Double.longBitsToDouble(0x3fe933520fa1d2acL), Double.longBitsToDouble(0x3fe8d99b14c30f22L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 22, 8, 2, "\udb67\udd01\ud97e\udf34\udacd\ude00\ud8b8\udd0d\u03c5\udbcb\udeb6\ud957\udf43", "\u6a7c\ub19b\u4a06\u3d6c\u4071\ub2a9\u48ed\u7eb6", "\ud8df\udf1a\ud9dd\udc92\ud999\ude41",
        35, 25427, -878899364, 903990650878338938L, 16831L, true, true, (char) 64740, (char) 31349,
        Double.longBitsToDouble(0x3fe7c3c3f6a00501L), Double.longBitsToDouble(0x3fe96ecf7c320582L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.util.HashMap:{T=class java.lang.Integer}\012",
        Z.run(T, 2, 8, 2, 26, "\ud8d9\udea8\ud97e\udf34\udb9d\udf90\ud925\udfdf\u0464\ud95e\uddb1\ud957\udf43\u05d3\ud8ec\ude5d\ud8fc\udd6c\uda13\udd5c\udb41\udddc", "\ub436\u48ed", "\ud9f3\ude9d",
        43, 52130, -1954906391, 6832079774962314552L, 58491L, true, true, (char) 40807, (char) 8319,
        Double.longBitsToDouble(0x3fef96b721915152L), Double.longBitsToDouble(0x3fd8f4354445dd0cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 25, 19, 18, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43\ud904\udd88\uda99\udd69\u1255\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\u1bde\udb2d\udf1d\udb07\udfb4\udb6a\udee2\uda7e\uded7\ud9fd\udd68\ud9f2\udfe3\ud999\ude41\udb00\udcdf\ud9ad\udcf2\uda32\udfb2\u1ea4\ud96d\udf92\uda67\udf74\u7bb3", "\u8cb0\uba59\u09a4\ub94c\uc843\ud6e1\u4d3e\u02be\ua89b\u6c7d\u8523\ud54d\u4c06\u6bf9\u2744", "\uda90\udf95\ud94b\udfd0\udbb9\udfa4\udb81\udfd6\udb1c\udecd\ud9de\ude24\udbf1\ude60\uda46\udd73\ud83e\ude2a\ud8b4\ude2e\udb99\udede\uda3e\ude76\udb4d\udc13\udabb\ude01",
        13, 6695, 1428353389, 3094315367742240846L, -16092L, true, false, (char) 51606, (char) 52077,
        Double.longBitsToDouble(0x3fc5ae2363c35d68L), Double.longBitsToDouble(0x3fe071c8b05a8766L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 10, 8, 2, "\udb67\udd01\ud97e\udf34\udade\udd48\ud8b8\udcf5", "\u4d97", "\uda3e\udeae\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        4, 32943, -1303045202, -2863393357225700289L, 59083L, false, true, (char) 27218, (char) 46084,
        Double.longBitsToDouble(0x3fe930cf07a1d2acL), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 7, 9, "\ud905\udfcf\ud816\udec0\uda07\udf9e\udaae\udda9", "\u12c0\u3f3c\u0b82\u6a7c\ubb9b\u9f0f\ud1e6\u8c1c\u42ab\u1fb3\u548f\ua05a\u3659\u8fa0\u17d1", "\ud9cd\udff9\udba8\uddd9\u5ff4\ud8a0\udf30\ud874\udc7a\ud89e\udea8\ud92f\udc5a\udbff\udee5\udaa8\udd2b\ud995\ude9f\udba9\ude94\ud9e5\uddd4\udb56\udf2b\udb33\udc7f\udaee\udcb7\ud80d\udc5c\ud9e2\udedc\ud885\udcdc\ud9fe\ude40\uda70\udcf3\ubb8f\ud9d4\udfa6\ud895\udf9c\ud89f\ude66\ud8bb\udc0e\uda53\uddb6\udb3b\udd6f\udbd6\udde3\udb3c\udfe0\uda0d\udfbf\uda90\udc3b\ud9f2\udd31\uda02\udfc7",
        22, 60390, -530096250, 3006964315476599041L, -96043L, false, false, (char) 17358, (char) 12586,
        Double.longBitsToDouble(0x3feec36335907376L), Double.longBitsToDouble(0x3fe3ebbea7689514L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 11, 2, "\ud8ef\ude24\uda5c\ude7e\uda83\udcad\ud8b8\udda6", "\u4d97", "\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        4, 32943, -1303045202, -2863393357225700289L, 59083L, false, true, (char) 27218, (char) 46084,
        Double.longBitsToDouble(0x3fe930cf07a1d2acL), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 23, 13, 19, "\uda37\udc70\udb78\ude88\udb3e\udeed\ud8b8\udcf5\u03c5\ud8cb\udd50\ud82d\udcfc\ud9bb\udf6a\ud8fd\udd7c\u83b2\ud950\udcf1\ud9c7\udf68", "\ub456\u48ed\u7eb6\u2174\u3659\u5dab\u8549\u6cf9\uc206\ubcd6", "\ud978\udd00\ud874\udc7a\ud89e\ude18\ud912\udd53\udb30\udf7c\ud92d\udcfa\ud9e4\udf26\ud89e\udc4e\ud955\udc67\ud82c\udc3a\uda2f\udf1d\ud9a7\udda6\uda7b\udd9f\uda73\udc54\ud810\udf94\ud822\udf1c\udb27\udd4d\ud9d8\udeee\uda32\udcf4\udba3\udeb3\ud820\udfd8\ud826\udc46\ud83d\ude51\uda6b\udd48\ud989\udf8f\ud903\udff5\uda0c\udedb",
        58, 41100, -560111547, 139723439479204827L, -65694L, false, true, (char) 48402, (char) 37713,
        Double.longBitsToDouble(0x3fd7b9973bc23670L), Double.longBitsToDouble(0x3f90e41c847b6900L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 9, 24, 2, "\ud874\ude26\ud966\udd34\uda42\udf3a\ud8b8\udcf5", "\ub3f5", "\u12b2\ud950\udcf1",
        45, 48664, -1466042556, 7304250064542505674L, -66804L, true, true, (char) 4247, (char) 57663,
        Double.longBitsToDouble(0x3fafec21afa9a590L), Double.longBitsToDouble(0x3fee187ff6e902e6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 21, 17, 16, "\udb67\udd01", "\u3e68\u802a\u4ee0\ub54c\u8710\u3eea", "\udadb\udde9\ud9ca\udc84\ud830\udd3d\udbe5\udfed\udb38\udfeb\uda55\udc1f\ud97a\udd55\uda8a\uddd1\ud8df\udf1a\ud9dd\udc92\ubccc\udaff\udd8d\ua5f2\udaa8\udc90\ud8e3\udf72\ud978\udd00\ud9ab\udcd6\ud89e\udea8\ud925\udc4a\ud8bd\udcfd\ud941\udf3f\ud865\udfff\ud920\ude39\ud821\udc56\udb53\udf50\uda81\udf67\udb8d\udcef\udae1\udffa\ud95f\udd36\u3b26\ud883\uddac\ud8c9\udd3d\udb99\udf65\udbe7\udc7b\ud91f\udcc3\ud8f3\udede\uda7e\udf82\ud88b\ude05\ud98b\udf7e\uda36\ude96\ud9de\udf5f\ud81c\udc59\uda22\uddbd\udbd3\udd26\ud8b3\udc99\ud925\udf6f\uda6f\udc7a\uda71\udc1b\udaee\udebb\udb84\udc8d\ud921\udc8e\udbfa\uddce\ud961\udf82\uda37\udf3a\ud98f\udd5a\ud823\uddcb\ud8b6\udef8\udb2a\udda3\udbe6\udfe4\udacc\ude6a\uda10\udc72\uda3b\udd29\ud94a\udf11\ud873\udd7f\ud800\udf13",
        -1, 4843, -940547617, -7992721678208800759L, -99718L, true, false, (char) 57212, (char) 45309,
        Double.longBitsToDouble(0x3fec8e460b74116cL), Double.longBitsToDouble(0x3fd6086ac2d2ffdcL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 13, 1, 2, "\ud896\udc9a\ud97e\udf34\uda42\udf3a\ud8b8\udcf5", "\u4d97", "\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udb11\udf24",
        50, 32943, -1303045202, -7341895532180555686L, 59152L, false, true, (char) 27218, (char) 46084,
        Double.longBitsToDouble(0x3fe930cf07a146acL), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 2, 26, 8, "\udb26\udc70\ud97e\udf34\uda42\udf3a\ud8b8\udcf5", "\u4d97", "\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        42, 37215, -1303045202, -2863393357225700289L, 59083L, false, true, (char) 27218, (char) 46084,
        Double.longBitsToDouble(0x3fe930cf07a1d2acL), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 22, 8, 18, "\udb67\udd01", "\000\u802a\u4ee0", "\000\u8210",
        22, 39440, 15272, 1700593664L, -86817L, false, true, (char) 57663, (char) 11395,
        Double.longBitsToDouble(0x3fefd4d2cd000000L), Double.longBitsToDouble(0x3feae3fe16b5cb9dL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 0, 0, "\000\ud94c\udf26\u3701\ud8b8\udcae", "\u4cd8", "\u009d\ud950\udccd\ud9c7\udf68\ud83c\udc7d\ud85a\udd32\ud8b5\ude2c\ud8dc\uded4\000",
        27, 32816, -1303045202, -2863393357225700289L, 59083L, false, true, (char) 52306, (char) 122,
        Double.longBitsToDouble(0x3e143a5580000000L), Double.longBitsToDouble(0x3e470c3c00000000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 22, 8, 2, "\udb27\ude86\ud97e\udf34\uda42\udf3a\ud8b8\udcf5", "\u4d97", "\u12b2\ud950\udcf1\ud9cf\udeeb\uda98\udc7f\udb17\udce3\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        4, 32943, -1303045240, -2863393357225700289L, 59083L, false, true, (char) 27218, (char) 46084,
        Double.longBitsToDouble(0x3fe930cf07a1d2acL), Double.longBitsToDouble(0x3fda43362a801ff6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 13, 1, 2, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43", "\u6a7c\ub19b\u4a06\u3d6c\u4071\ub74c\ubdbd\u7eb6", "\ud8df\udf1a\ud9dd\udc92\ud999\ude41",
        11, 25427, -878899364, -420349114545297588L, 16831L, true, true, (char) 64740, (char) 20362,
        Double.longBitsToDouble(0x3fe6cf89945188efL), Double.longBitsToDouble(0x3fb65041abdbe158L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 21, 8, 25, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43", "\u6a7c\ubc40\ubc44\ud50a\u3fa0\ub456\u48ed\u7eb6", "\ud8df\udf1a\ud9dd\udc92\ud999\ude41",
        35, 25427, -878899364, 903990650878338938L, 16960L, true, true, (char) 64740, (char) 2401,
        Double.longBitsToDouble(0x3fe908ab88d606c0L), Double.longBitsToDouble(0x3fe2ba82bb905842L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 0, 8, 2, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8cf\ude76\u03c5\ud883\ude7d\ud957\udf43\u05d3\udaa5\udd4d\u94c2\uda71\uded7\ud9c7\udf68\ud9df\udcf6\ud85a\udd32\ud8e6\ude2c\udba5\udf3c\udba9\ude10\ud8a9\ude6f\uda7e\uded7\ud8df\udf1a\ud9dd\udc92\ud999\ude41\uf31d", "\u4cfd", "\ud89e\ude68\ud924\udfff\ud9ec\udcfa\udbdc\udfda\udba3\udc19\ud8df\uddde\udb15\uddc3",
        49, 36413, 201971399, -1954220124757997079L, -88958L, true, true, (char) 9306, (char) 33177,
        Double.longBitsToDouble(0x3fe496370c92b8c7L), Double.longBitsToDouble(0x3fcf60dd1325f428L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=class java.lang.Thread$State, T=class java.lang.Thread$State}\012",
        Z.run(T, 1, 16, 8, 2, "\udb67\udcbf\ud97e\udf34\uda42\udf3a\udbd9\udf01", "\u9957\ucd9c\ud0f6\u8d2a\u7e81\u5144\u66a7", "\udb2d\udf1d\udba9\ude10\ud8d9\ude67\ud95e\udc36",
        39, 19594, -759823322, -7651688190265497760L, -75093L, false, true, (char) 17670, (char) 26146,
        Double.longBitsToDouble(0x3feca0102cd3cb84L), Double.longBitsToDouble(0x3fe9b87aec5a7b28L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 7, 24, 25, "\uda1c\udc69", "\u3e68\u802a\u4ee0\u4d97\u3fd3\ud03e", "\ud8cd\udf67",
        20, 47286, -279095490, -4490622321878075348L, -86817L, false, false, (char) 3153, (char) 11395,
        Double.longBitsToDouble(0x3fefd4d2cd6b0f3aL), Double.longBitsToDouble(0x3feae3fe16b5cb9dL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\012",
        Z.run(T, 1, 14, 14, 24, "\udb7c\udc4f\uda43\ude05\uda42\udf90\ud868\udde6", "\u6645\u3f68\ud03e\u8af5\u5e15\u3513\u7ba9\ube50\ub48a\u48ed", "\uda8e\udcd7",
        10, 70354, -1705405648, 1097418134010359147L, 64058L, false, true, (char) 17670, (char) 2638,
        Double.longBitsToDouble(0x3fe8d99b15c30f22L), Double.longBitsToDouble(0x3fd84cd96cdae59eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 22, 8, 2, "\ud9be\udf8c", "\u3e68", "\000",
        -5, 53216, 26781, 0L, 67383L, false, false, (char) 6656, (char) 14811,
        Double.longBitsToDouble(0x3fdac64046fea1a0L), Double.longBitsToDouble(0x3fed77a746eab255L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\012",
        Z.run(T, 1, 5, 25, 8, "\ud9e3\udee3\ud97e\udfe7\uda42\udf3a", "\u0bf2\u6885\u2041\u8845\u0fac\u9797\u4a06\u3d6c\ubadd\ub8a7\u483b", "\udb10\ude40",
        55, 14282, 475616319, -2364270907464978998L, -75093L, false, true, (char) 20192, (char) 34878,
        Double.longBitsToDouble(0x3feeaf71adc30ff1L), Double.longBitsToDouble(0x3fe7fcda24969dbbL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Class:int\012",
        Z.run(T, 1, 13, 2, 21, "\udb67\udd01\ud804\udf37\uda42\udf3a", "\uc834\u1f7a\u551e\ub93a\ubf3f\ucb25", "\ud922\uddb1\u3a26",
        19, -492, 852525484, 785934754227019469L, 74503L, true, true, (char) 470, (char) 65297,
        Double.longBitsToDouble(0x3fe64a54ef7a0c8bL), Double.longBitsToDouble(0x3fe130cf04c76de3L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 21, 8, "\udb67\udd01", "\u3ced\ua387\u1052\u4d77\u3fd3\ud03e", "\uda5d\udc08\ud9ca\udcb6\ud85a\udd32\ud8e6\ude2c\u851d\udba9\ude10\ud8a9\ude6f\uda7e\uded7\ud8df\udf1a\ud9dd\udc92\uda5c\udfa2\ud908\udfc3\ud98d\udfd7\uda97\udccd\ud8e3\udf72\uda05\udcc6\ud874\udc7a\ud975\udc75\uda7e\ude36\ud85b\udee6\ud936\ude38\ud8f9\udc8f\udae0\udd35\uda19\ude27\uda8b\udd64\u9657\uda70\udcb2\ud86c\udd58",
        2, 20860, -1474424655, 8667641180952157834L, -96808L, false, false, (char) 64378, (char) 26912,
        Double.longBitsToDouble(0x3fce5662de5904f4L), Double.longBitsToDouble(0x3fd9e30e69b67352L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 21, "\udb67\udd01", "\u3e68\u802a\u4ee0\u32bf\000\000", "",
        45, 35984, -1322086953, 7304209892941634250L, -66804L, false, true, (char) 4247, (char) 57663,
        Double.longBitsToDouble(0x3fafec2197bf5a20L), Double.longBitsToDouble(0x3f9c26ba00000000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 20, 26, 2, "\uda29\udcda\uda86\udf73\ud884\udf3b\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43\uda89\udd96\uda05\udc66\udb84\udff1\ud87e\ude80\ud9c7\udf55\ud9ca\udc84", "\u48ed\u7eb6\u2174\ub6a4", "\udba3\udf0c\uda58\udfca\ud9ad\udc90\uda97\udc45\ud8e3\udf72\ud9c8\uddfa\ud874\udc7a\ud89e\udea8\ud924\udfff",
        47, 90711, 799149506, -7927286966067299065L, -87664L, true, false, (char) 33599, (char) 16318,
        Double.longBitsToDouble(0x3fe89ceb2ca73795L), Double.longBitsToDouble(0x3fdd0b7829ae9b36L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 20, 7, 26, "\ud809\ude90\uda26\udf04\udb15\udcdc\ud8b8\udcf3\u03c5\ud883\uddad\ud957\udf43", "\u6a7c\ub19b\u4a06\u3d6c\u4071\ub456\u48ed\u7eb6", "\uda35\udc07\ud865\udc56\udba3\udf0c",
        36, 25329, -876205802, 903990650871748730L, 7012L, false, true, (char) 51886, (char) 59148,
        Double.longBitsToDouble(0x3fe51d54fcf1f781L), Double.longBitsToDouble(0x3fef5aa902169934L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=E}\012",
        Z.run(T, 1, 20, 7, 21, "\udb67\udd01\ud8b1\udd8d\ud937\udc15\ud89f\udfc0", "\u4d97\u3fd3\ud072\u6aa7", "\ud9ca\udc84\ud85a\udd32",
        23, 97514, 1678014508, -933139386782407178L, -46474L, true, false, (char) 25446, (char) 63846,
        Double.longBitsToDouble(0x3feae3fe16b5cb9dL), Double.longBitsToDouble(0x3fdb69ce964c33acL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.util.HashMap:{T=class java.lang.Character}\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 20, 7, 2, "\ud8e5\udd5e\ud97e\udf34\ud884\udf3b\udbe0\udff7", "\u4d97\u3fd3\ud03e\u6a7c\ub19b\u4a06\u3d6c\u0bdb\ub456\u48ed\u7eb6\u2174\u1975\u8fd8\u6313\ud3e4\u88c3\ubc74\u3945\u8b1e\u2812\u0deb\u6487\ud50a\u3ce9\u74bc\u592e", "\udadb\udfcd\uda63\udd70\udad6\udc33\ud8f0\udce7",
        13, 42918, -1426484593, -8923169163544075063L, 3025L, true, false, (char) 14312, (char) 22288,
        Double.longBitsToDouble(0x3fbc96e8c7390840L), Double.longBitsToDouble(0x3fe75b4916da612cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 20, 7, 2, "\udb67\udd01\ud97e\udf34\ud884\udf3b\ud8b8\udcf5", "\u4d97\u3fd3\ud03e\u6a7c\ub19b\u4a06", "\uda13\udf15\udb2d\udf1d\udba9\ude10\ud8a9\ude6f\uda7e\uded7\ud8df\udf1a\ud865\udc56\udba3\udf0c\uda58\udfca\ud9ad\udc90",
        16, 92725, 427563130, -3266188186679625823L, 91939L, true, true, (char) 64013, (char) 5640,
        Double.longBitsToDouble(0x3fd6b5357f202726L), Double.longBitsToDouble(0x3fde2accb8882b80L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 20, 7, 10, "\udb67\udd01\ud97e\udf34\ud884\udf3b\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43\u05d3\udaa5\udd4d\u12b2\ud950\udcf1\ud953\ude0d\ud9d0\udc57\ud829\udddf\ud8e6\ude2c\udb2d\udf1d\udba9\ude10\ud8a9\ude6f\uda7e\uded7\ud8df\udf1a\udaea\udc6c\udbb2\udc43\uda58\udfca\ud9ad\udc90\udb8d\udddf\udbcc\udf8d\ud9c8\uddfa\ud8fa\udc7d\uda3e\udcb9", "\uacb1", "\udbaf\udc37\udbc2\udfe5\uda83\ude61\udbef\udf93\uda39\udd8d\ud9bd\ude4b",
        -2, 31975, 1130552595, 5434549155468532323L, 5658L, true, true, (char) 19157, (char) 25422,
        Double.longBitsToDouble(0x3fe95b198d4ed6c2L), Double.longBitsToDouble(0x3fda6cb020a3ac04L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 7, 2, "\udb67\udd01\ud97e\udf34\ud884\udf3b\ud9be\udfd8", "\u4d97", "\u12b2\uda90\udfb2\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\ud831\udde2",
        42, 32943, 1352932270, -92750486545582489L, 58985L, false, true, (char) 27218, (char) 9477,
        Double.longBitsToDouble(0x3fa30cbe052951f0L), Double.longBitsToDouble(0x3fdea3b77b861e44L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 9, 20, "\ud9c3\udc3c\udb3e\udcd8\ud884\udf3b\ud8b5\udf5d\u89db\ud960\udee4\ud907\udffd\udad7\udeee\uda5b\udf8c\uda69\udd80\uda19\ude52\udb06\ude2e\udbb8\udd38\ud85a\udd32\ud9f4\udf53\udb27\ude25\ud998\ude29\ud87d\udfad\ud8bd\udd5d\uda69\udfc5\ud8c5\udd76\udba3\udf0c\uda58\udfca\ud9ad\udc90\uda97\udc45\ud8e3\udf72", "\u356a\u5caf\u9068\uac8b\u88d8", "\u2003\ud9fd\udc00\ud828\uddc0\ud8e7\udc99\ud8b7\uded7\uda0d\udcef\ud8e4\udc39\ud879\ude63\ud8ea\udc77\ud990\ude26\udac5\udcac\ud99b\udca2\udbe9\udff6\ud86f\udc26\ud91e\udc5f\udafd\udfb5",
        19, 74087, 1046463250, -7393235575091911661L, 87938L, false, false, (char) 40426, (char) 35853,
        Double.longBitsToDouble(0x3fe2df7c37b13f94L), Double.longBitsToDouble(0x3feb1e2afaf01bceL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=E, E=E}\012",
        Z.run(T, 1, 20, 7, 22, "\udb67\udd01\ud97e\udf34\ud884\udf3b\ud8b8\udcf5", "\u41e2", "\ud8c3\udef0\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        37, 74567, 1770584112, -3151624214776859055L, 58985L, false, true, (char) 27218, (char) 9477,
        Double.longBitsToDouble(0x3fe930cbe7a1d2acL), Double.longBitsToDouble(0x3fe8d99b12c30f22L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 8, 0, "\udb67\udd01\ud97e\udf34\uda42\udf3a\ud8b8\udcf5", "\ucb69\u9c6e\ud07b\u6a7c\u573c", "\ud85a\udcdd\uda68\ude2d\udb2d\udf1d",
        44, 59471, -186109057, -5596536528466399510L, -22170L, false, false, (char) 35382, (char) 10940,
        Double.longBitsToDouble(0x3febd062a32619e0L), Double.longBitsToDouble(0x3fefbe956163cfd9L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\012",
        Z.run(T, 1, 4, 18, 22, "\u6d12\udb25\ude29\uda29\udcdc\uef4b\udaf0\udd29\ud85a\udc39\ud957\udf43\ud89f\udf6d\udaa5\uddd8\udb8f\udeb6\ud896\udc40\ud886\udd79", "\ub456\u70e5\u04a1\ua899\u5d8f\u8fa0", "\udae2\udf9d\udac9\udeed\ud91f\udd5a\udb82\udf34\uda51\udcf2\udb40\udd65\ud852\uded1\ud91c\udf8b\udbaf\udd7e",
        -1, 77979, 147442403, -4346828054622539917L, 81885L, true, true, (char) 31009, (char) 1811,
        Double.longBitsToDouble(0x3fe101aea173a5eeL), Double.longBitsToDouble(0x3fa4fa9211f8a440L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.util.AbstractList<E>\012",
        Z.run(T, 1, 14, 15, 18, "\u6d12", "\u7751\u6c8c\u9126\u4d97\u3674\ud0c9\u0351\u739d\uccaa", "\ud8e6\ude2c\ud8c7\udc49\ud923\udc40\udaf5\udd4e\ud985\udd2f\ud8df\udf1a\uda1e\udc73\ud999\ude41\udae2\udf9d\u5d95",
        -5, -1000, 522228480, -7509145953983535322L, 99322L, false, false, (char) 0, (char) 51711,
        Double.longBitsToDouble(0x3fcd41193dcf0c00L), Double.longBitsToDouble(0x3fec69842e7d56d8L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 18, 13, 16, "\udb67\udd4a\uda1d\udc2e\uda42\udf3a\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43\u05d3", "\uc9fe\u492c\u956f\u844a\ub456\u48ed", "\udae1\udf88",
        17, 95533, 1158829198, -6087192166570803847L, -75093L, false, false, (char) 35334, (char) 13246,
        Double.longBitsToDouble(0x3fd6f5ea31edc1b2L), Double.longBitsToDouble(0x3fa1083517fc2d60L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 5, "\udb67\udd01\udaa9\ude48\uda45\udf58\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43\udbfa\udfd2", "\uc9fe\u492c\u3d6c\u4071\ub4e3\u047c", "\uda7e\uded7\ud8df\udf1a\ud8a6\udc8b\ud999\ude41\u067c\udbc6\udea6\ud960\udc4f\ud8eb\udec9\ud95b\udd11\ufd00\udb10\udda5\ud807\udf99\uda9c\udded\ud8ef\udc87\ud823\udc48\uda4a\udfbe\uda5b\udfb4\udb87\udc16\udbe2\udd75\ud851\udc55\udbdd\udf9a\udb1b\udf73\u165e\uda27\udf36\ud933\udcaa\ud869\udd55\udac3\udff8\udb5d\udeba\ud8f0\udfd0\ud97c\udd89\uf142\uda7c\udc14\uda18\ude69\ud890\ude13\ud848\udc63\ud87e\udd36\ud867\udf61\ud8fa\udc33\ud97f\udec7\ud92b\ude8d\ud827\udea1\ud8ef\udf41\udb08\udd33\ud974\udd90\ud8dc\ude4a\udb5f\ude95\udb5d\udf29\ud82d\udd5a\udbce\udcb6\udba0\udc7d\udbd9\udc0b\ud88d\udeb2\udb21\udcec\uda61\udf0f\udb95\udfad\uda60\udcc9\uda0e\udda1\ud9a1\udf18\ud986\udccc\ud8f1\udcf9\ud85d\udf1f\udbb7\uddfd\ud939\udf0c",
        54, 13887, 1246831845, 2498400368610876858L, 73827L, false, true, (char) 64986, (char) 54179,
        Double.longBitsToDouble(0x3fc6e82d7421bdfcL), Double.longBitsToDouble(0x3fe11f1f8e236b84L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 14, 0, 3, "", "\u2e0a\u3e68\u0517\uad65\000", "\u12b2",
        22, 98464, 1383963498, -5692549005578025933L, -100000L, false, false, (char) 120, (char) 11328,
        Double.longBitsToDouble(0x3fab4d2c80000000L), Double.longBitsToDouble(0x3e38000000000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 16, 18, 13, "\udb67\udd01\udaff\udc61\uda3b\udd4b\ud8b8\udcf5", "\u509d", "\u12b2\ud950\udcf1\ud928\udea6\ua7d5",
        1, 41792, -945017372, 6054095928952280457L, -42863L, false, false, (char) 36402, (char) 31497,
        Double.longBitsToDouble(0x3feaaca0bb9e7dfcL), Double.longBitsToDouble(0x3fc22368e3e985a0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 5, 16, 18, "", "", "\udb71\udeca",
        20, 27383, -566038576, 7020069773322110068L, 67383L, true, false, (char) 17385, (char) 45793,
        Double.longBitsToDouble(0x3feaee43537f84dbL), Double.longBitsToDouble(0x3fdae1a0048219feL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 16, 0, 6, "", "", "\u03c5\ud883\uddad\ud957\udf43\udbb0\ude89\uda65\udf24\ua0f8\ud950\udcf1\ud9c7\udf68\ud85d\ude86\ud85a\udd32\ud8be\udd05\udb2d\udf1d\udb27\ude4f\udbc9\udfe2",
        36, 55798, -666685718, 92629815132410L, 25952L, false, false, (char) 46084, (char) 17670,
        Double.longBitsToDouble(0x3fed0e95631b3362L), Double.longBitsToDouble(0x3fdc30f229329cfaL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 26, 2, "\uda19\udcb1\ud970\ude0e\uda42\udf3a\ud8b8\udcf5", "\u4d82", "\u12b2\ud84f\ude92\ud9c7\ude82\ud9ca\udc84\uda87\udfc8\ud8b3\udc5c\udbbc\udedc\udae4\udfbd",
        23, 32943, -1303045202, -2863393356101626817L, 59083L, false, true, (char) 32536, (char) 57068,
        Double.longBitsToDouble(0x3fde919e0f43a5a8L), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=null\012",
        Z.run(T, 2, 18, 4, 15, "\ud844\udd20\ud981\uddb8\ud938\udf30\ud8b8\udcf5\uda35\udffe\ud883\uddbd\ud8ec\ude6e\udb20\udc91\ud93a\udf4e\u12b2\ud950\udcf1\ud9c7\udf68\ud8fe\udc7e\udbba\udc2d", "\u7eb6\u8cb6\u444a\u2018\u1648\uca54", "\udbd4\udcd3\udb4c\udc8f\ud978\udd00\ud874\udc7a\ud89e\udea8\ud924\udfff\uda64\udfd7\udada\udfb9\ud80a\udc57\ud8ca\ude41\u3409\uc874\udaa9\udef3",
        58, 77073, -1400891002, -850149959716282079L, -56511L, true, false, (char) 5179, (char) 55868,
        Double.longBitsToDouble(0x3fb903015dd89960L), Double.longBitsToDouble(0x3fe7d6abd057c7bfL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 11, 18, 14, "\udab8\udf78\udadd\udd38\udba8\udebe\uda5a\ude9b\ud8d9\uddca\ud883\uddad\ud95e\udfa8\udb75\ude84\udb9c\uddb1", "\u4a06\u3d6c\u4071\ub456\u92b1\u6c2b\u2174\u3659\u1076\uab3f\ua400\uc206\ubcd6\u3945\u7bc4\uc82f\u481b", "\udaa6\udfe8\udb5f\udd7a",
        55, 1458, -113039362, 6462462999574498684L, 68819L, true, true, (char) 38172, (char) 18712,
        Double.longBitsToDouble(0x3fd11e89e7c68792L), Double.longBitsToDouble(0x3fea3840bdff6d7dL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 17, "\udbb2\udfb4\udadd\udd38\ue7c4\uda47\udddd\ud962\udfb8\u67dc\ud974\udeb6\ud8ec\ude9d", "\u29e0\u85e9\u1203\u4071\ub456", "\ud8a9\ude45\udaf9\uded5\ud8df\udea6\ud9dd\udc92",
        4, 24090, -1402688981, -3774689371462305823L, -53761L, true, false, (char) 54970, (char) 36556,
        Double.longBitsToDouble(0x3fe59078b355ceafL), Double.longBitsToDouble(0x3fefffb648186632L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 26, 6, 2, "\ud8d9\udea8\ud97e\udf34\udb9d\udf90\u0b0e\ud912\udd4a\ud962\ude36\ud957\udf43\u05d3", "\u9ad4\u0fbe\u41ae\u9f0e\u9b6d\u9261\u7eb6\u665f\u9052\ud7a5\u2deb", "\ud9ad\udcbf\udbde\udf48\udbbc\ude55\ud848\ude48\udaad\udcb4\udba5\udcf7\udad9\udcf9\udab5\udcbe\uda33\udc3d\uda65\udff4\udb7c\udc17\udbdf\ude29\ud94e\udd6e\uda80\udd9b\ud879\udc03\ud9c2\udc62\ud9c0\ude88\uda43\udcdc\ud983\udc2b\ud89d\udcff",
        19, 2397, 2118266234, 5610240665126206081L, -83239L, true, true, (char) 36929, (char) 19286,
        Double.longBitsToDouble(0x3fdf7612643c5562L), Double.longBitsToDouble(0x3fe1c8c88d0a46b5L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.util.HashMap:{T=class java.lang.Integer}\0121=java.util.HashMap:{T=class java.lang.Integer}\012",
        Z.run(T, 2, 18, 2, 26, "\ud8d9\udea8\ud97e\udf34\udb9d\udf90\ud925\udfdf\u0464\ud9a0\udeb4\ud957\udf43\u05d3\ud8ec\ude5d\ud8fc\udd6c\uda13\udd5c\udb22\udedc", "\uc4f0\u48ed", "\ud9f3\ude9d",
        43, 52130, -1804857589, 6832079774962314552L, 86293L, true, false, (char) 40582, (char) 64740,
        Double.longBitsToDouble(0x3fcd2ecfd6f1cb0cL), Double.longBitsToDouble(0x3fdf2d6e496f27e6L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=null\012",
        Z.run(T, 2, 8, 2, 26, "\ud926\udfd0\ud81a\udc26\udb9d\udf90\ud925\udfdf\u0464\ud95e\uddb1\ud957\udf43\u05d3\ud8ec\ude5d\ud8fc\udd6c\uda13\udd5c\udb41\udddc", "\u20a8\u8e8b", "\uda3e\udcc3",
        -2, 96266, -1954925301, 6832076476427431224L, 58491L, false, false, (char) 40782, (char) 8319,
        Double.longBitsToDouble(0x3fef96b721915152L), Double.longBitsToDouble(0x3fd8f4354445dd0cL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=null\012",
        Z.run(T, 2, 8, 2, 26, "\ud8d9\udea8\ud97e\udf34\udb9d\udf90\ud925\udfdf\u0464\ud95e\uddb1\ud957\udf43\u05d3\ud8ec\ude5d\ud8fc\udd6c\ud8e5\udfe5\udb1a\udf09", "\ub436\u48ed\u7eb6\u665f\u9052\u8fa0\u9335\ubcce\ub4ba\ubca3\ua94f\u6837\ua719\ua54d\ub2ed\ud50a", "\udb52\udf4f\udb81\udcbc\udafb\udd88\ud95a\udc87\ud989\uddf3\udbb2\udf6c\u26b8\udaf2\udfc6\ud8de\udd2a\ud957\udc99",
        57, 98951, -533128228, -2624171739904798835L, -19846L, true, true, (char) 62355, (char) 17462,
        Double.longBitsToDouble(0x3fd96c0a7f45ea66L), Double.longBitsToDouble(0x3fd2a0fecbb46e66L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.util.HashMap:{T=class java.lang.Integer}\0121=java.util.HashMap:{T=class java.lang.Integer}\012",
        Z.run(T, 2, 0, 0, 18, "\000\ud97e\udf34\udb9d\udf90\ud925\udfdf\u0464\ud958\udd2d\000\000\ud8ec\ude5d\ud8fc\udd6c\uda13\udd5c\udb41\udddc", "\ub436\u48ed", "\ud9f3\ude9d",
        43, -1000, 0, 0L, -100000L, true, true, (char) 39792, (char) 26593,
        Double.longBitsToDouble(0x3fe8d99e4dc30f22L), Double.longBitsToDouble(0x3fcd2ecfd6f1cb0cL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.util.HashMap:{T=class java.lang.String}\0121=java.util.HashMap:{T=class java.lang.String}\012",
        Z.run(T, 2, 2, 2, 26, "\ud8d9\udea8\ud97e\udf34\udb9d\udf90\ud925\udfdf\u0464\ud95e\uddb1\ud957\udf43\u05d3\ud8ec\ude5d\ud8fc\udd6c\uda13\udd5c\uba14", "\ub436\u48ed", "\u00da",
        42, 52130, -1954906391, 6832079774962314552L, 58491L, true, true, (char) 40807, (char) 8319,
        Double.longBitsToDouble(0x3fef96b721910052L), Double.longBitsToDouble(0x3fd8f4354445dd0cL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 22, 6, 17, "\ud8d9\udea8\ud97e\udf34\udb9d\udf90\ud925\udfdf\u0464\ud95e\uddb1\ud957\udf43\u05d3", "\u2458\u2500", "\udaa2\ude2a\ud803\ude26",
        2, 34607, 502115546, -5596536528977012397L, 91068L, true, false, (char) 34728, (char) 39792,
        Double.longBitsToDouble(0x3fda7fb536366792L), Double.longBitsToDouble(0x3fee187910e9762dL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Enum<java.lang.Thread$State>\0121=java.util.HashMap:{E=class java.lang.Thread$State, T=class java.lang.Thread$State}\012",
        Z.run(T, 2, 14, 4, 2, "\udb67\udcbf\ud97e\udf34\uda42\udf3a\udb68\uddbc", "\u9957\ucd9c\ud0f6\u8d2a\u5765\u5144\u66a7", "\udb2d\udf1d\udba9\ude10\u1ecd\ud961\ude01",
        53, 19594, -759823322, -7651688190265497760L, 6317L, false, false, (char) 934, (char) 26146,
        Double.longBitsToDouble(0x3feca0102cd3cb84L), Double.longBitsToDouble(0x3fe9b87aec5a7b28L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=E, E=E}\0121=java.util.HashMap:{E=E, E=E}\012",
        Z.run(T, 2, 2, 20, 18, "\ud80c\udd5c\ud97e\udf34", "\u82a4\u1c11", "\ud97a\ude04\udbd1\udcd9\ud954\ude2b\udaa0\udc72\ud9ad\udfa0\ud85a\udc7a\udb8f\udf5e",
        37, 42927, 1346994604, -1569581989098933641L, 21290L, false, false, (char) 64815, (char) 2549,
        Double.longBitsToDouble(0x3fd1834c52f74c26L), Double.longBitsToDouble(0x3fe930cf07a12e81L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=class java.lang.Thread$State, T=class java.lang.Thread$State}\0121=java.util.HashMap:{E=class java.lang.Thread$State, T=class java.lang.Thread$State}\012",
        Z.run(T, 2, 16, 16, 17, "\udb67\udcc2\ud97e\udf34\uda00\udf86\udbed\udd20", "\u9957\u899d\ud0f6\u8d2a\u7e81\u5144\u66a7", "\udb2d\udf1d\udba9\ude10\ud8d9\ude67\ud95e\udc36",
        39, 19594, -759823322, -7651688190265497760L, -75093L, false, true, (char) 17670, (char) 26146,
        Double.longBitsToDouble(0x3feca0102cd3cb84L), Double.longBitsToDouble(0x3fc041ebb169eca0L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 4, 4, 8, "\udb67\udd01", "\u8bed\ua387\u1052\u4d77\u3fd3\ud03e", "\uda5d\udc08\ud9ca\udcb6\ud85a\udd32\ud8e6\ude2c\u851d\udba9\ude10\ud8a9\ude6f\uda7e\uded7\ud89c\udc97\ud9dc\udfae\uda5c\udfa2\ud970\udebb\ud98d\udfd7\uda97\udccd\ud8e3\udf72\ud83d\udcc2\ud874\udc7a\ud975\udc75\uda7e\ude36\ud85b\udee6\ud936\ude38\ud8f9\udc8f\udbf4\udcde\uda19\ude27\uda8b\udd64\u9657\uda70\udcb2\ud86c\udd58",
        2, 20860, -1474424655, 8667641180952157834L, -96808L, false, false, (char) 6516, (char) 26912,
        Double.longBitsToDouble(0x3fce5662de5904f4L), Double.longBitsToDouble(0x3fd9e30e643a7352L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 8, 18, 17, "\udb91\udef3\uda26\udf04\udb15\udcdc\ud8b8\udcf3\u03c5\ud883\uddad\ud957\udf43", "\u837c\ub19b\u4a06\u672e\ua185\ub456\u48ed\u7eb6", "\ud834\udf07\ud849\udfd7\udba3\udf0c",
        36, 25329, -876205802, 903990650871748730L, 72548L, false, false, (char) 10902, (char) 59148,
        Double.longBitsToDouble(0x3fe51d54fcf1f781L), Double.longBitsToDouble(0x3fef5aa902169934L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.util.HashMap:{T=class java.lang.Character}\0121=java.util.HashMap:{T=class java.lang.Character}\012",
        Z.run(T, 2, 20, 2, 14, "\ud8e5\udd5e\ud97e\udf34\ud884\udf3b\udbe0\udff7", "\u4d97\u6dbc\u01f1\u6a7c\ub19b\u4a06\u3d6c\u0bdb\ub456\u48ed\u7eb6\u2174\u1975\u8fd8\u6313\ud3e4\u77f1\ubd04\u3945\u8b1e\u2812\u0deb\u6487\u6b18\u3ce9\u3e59\u1a26", "\udadb\udfcd\uda63\udd70\udad6\udc33\ud8f0\udce7",
        13, 42918, -1426484593, 4263370543223215317L, 3025L, true, false, (char) 14312, (char) 22095,
        Double.longBitsToDouble(0x3fbc96e8c7390840L), Double.longBitsToDouble(0x3fe75b4916da612cL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 7, 20, "\udb3c\udfb3\ud97e\udf34\udb2c\ude70\uda7b\udf53", "\u0d97\u50f5\u50ea\u8761\ube5d\u491d\u3b04\u88be\ub445\u48ed\u7eb6\u2174\u3fc0\ud2d1\u5bf7\ub0ee\u249c\ub166\u2afa\u821e\u2812\u502f\u6487\u13fe\u3ce9\u74bc\u592e", "\udadb\udfcd\udb97\udd15\ud8df\uddd8\ud9b7\udc7e\ud98c\udd0c\uda4a\udc41\ud95a\udc28",
        56, 80386, 266930548, -4901484781790199207L, -73687L, false, false, (char) 47598, (char) 39615,
        Double.longBitsToDouble(0x3fd8c8b4d7044960L), Double.longBitsToDouble(0x3fd3938bdaff1f0cL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 4, 18, 22, "\u6d12\udb25\ude29\uda29\udcdc\uef4b\udaf0\udd29\ud85a\udc39\ud957\udf43\ud89f\udf6d\udaa5\uddd8\ud885\udcb2\ud9e5\uded1\ud8a1\ude67", "\ub469\u708e\u04a1\ua899\u5d8f\u8fa0", "\ud836\ude4c\udbf9\udeaa\ud91f\udd5a\udb82\udf34\uda51\udcf2\udb40\udd65\ud852\uded1\ud91c\udf8b\udbaf\udd7e",
        -1, 77979, 147442403, -4346828054622539917L, 81885L, false, true, (char) 31009, (char) 1811,
        Double.longBitsToDouble(0x3fe101aea173a5eeL), Double.longBitsToDouble(0x3fa4fa9211f8a440L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 5, 11, 5, "\udb67\udd01\udaa9\ude48\uda45\udf58\ud8b8\udcf5\u03c5\ud883\uddad\ud957\udf43\udbfa\udfd2", "\u8511\u492c\u3d6c\u4071\ub4e3\u047c", "\uda7e\uded7\u8bdc\ud9f6\udd3a\ud8a7\udf96\udad7\udc07\udbc6\udea6\ud960\udc4f\ud8eb\udec9\ud95b\udd11\ufd00\udb10\udda5\ud807\udf99\uda9c\udded\ud8ef\udc87\ud823\udc48\uda4a\udfbe\uda5b\udfb4\udb87\udc16\udbe2\udd75\ud851\udc55\udbdd\udf9a\udb1b\udf73\u165e\ud921\udf52\ud933\udcaa\ud869\udd55\udac3\udff8\udb49\udd3d\ud8c0\udccc\ud97c\udd89\uf142\uda7c\udc14\uda18\ude69\ud890\ude13\ud848\udc63\ud9be\udce6\ud936\udee8\ud8fa\udc33\ud97f\udec7\ud92b\ude8d\ud827\udea1\ud8ef\udf41\udb08\udd33\ud974\udd90\ud8dc\ude4a\udb5f\ude95\udb5d\udf29\ud82d\udd5a\udbce\udcb6\udba0\udc7d\udbd9\udc0b\ud88d\udeb2\udb21\udcec\uda61\udf0f\udb95\udfad\uda60\udcc9\ud9fb\ude87\ud9a1\udf18\ud986\udccc\ud8f1\udcf9\ud85d\udf1f\udbb7\uddfd\ud939\udf0c",
        54, 13887, 1246831845, 2498400368610876858L, 73827L, false, true, (char) 64986, (char) 54179,
        Double.longBitsToDouble(0x3fc6e82d7421bdfcL), Double.longBitsToDouble(0x3fe11f1f8e236b84L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 18, 4, 15, "\ud844\udd20\ud981\uddb8\ud938\udf30\ud8b8\udcf5\uda35\udffe\ud883\uddbd\ud8ec\ude6e\udb20\udc91\udbe1\udc42\u5d22\ud950\udcf1\ud9c7\udf68\ud902\ude7e\udbba\udc2d", "\u7eb6\u8cb6\u444a\u2018\u1648\uca54", "\udbd4\udcd3\udb4c\udc8f\ud978\udd00\ud874\udc7a\ud89e\udea8\ud924\udfff\uda64\udfd7\udada\udfb9\ud80a\udc57\ud8ca\ude41\u3409\uc874\udaa9\udef3",
        58, 77073, -1748197238, -852948461622107871L, -56511L, true, false, (char) 5179, (char) 55868,
        Double.longBitsToDouble(0x3fb903015dd89960L), Double.longBitsToDouble(0x3fe7d6abd057c7bfL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 17, "\udbb2\udfb4\udad0\udefe\ue7c4\uda47\udddd\ud962\udfb8\u67dc\ud974\udeb6\ud8ec\ude9d", "\u29e0\u85e9\u1203\u4071\ub456", "\ud8a9\ude45\udaf9\uded5\udb4c\udf59\u5965",
        28, 14982, -2007455149, -3774852841558247455L, -53761L, true, false, (char) 54970, (char) 36556,
        Double.longBitsToDouble(0x3fe59078b355ceafL), Double.longBitsToDouble(0x3fefffb648186632L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 22, 8, 2, "\udb67\udd6c\ud97e\udf34\uda42\udf3a\ud8b8\udcf5", "\u4d97", "\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\udbd6\udd30\ud8e6\ude2c\udb2d\udf1d\udba9\ude10",
        4, 32943, -1303045202, -2863393357225700289L, 59083L, false, true, (char) 27218, (char) 60932,
        Double.longBitsToDouble(0x3fe930ca77a1d2acL), Double.longBitsToDouble(0x3fe8d99b15c30f22L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 25, 25, 24, "\uda1d\udd5c\ud959\udf34\uda42\udf90\ud8ee\uded0", "\u4d97\u3fd3", "\ud950\udcf1\ud9c7\udf68\ud90b\ude63\udac4\uded0\ud835\udc4f\udb2d\udf1d",
        48, 16964, -957860993, -5596536588595941654L, -22170L, true, false, (char) 56366, (char) 46291,
        Double.longBitsToDouble(0x3febd0645c5519b4L), Double.longBitsToDouble(0x3fed0ef89b1b3362L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 21, 3, "\uda37\udc70\udb78\ude88\udb3e\udeed\ud8b8\udcf5\u03c5\ud8cb\udd50\ud82d\udcfc\ud9bb\udf6a\ud8fd\udd7c\u83b2\ud950\udcf1\ud9c7\udf68", "\ub456\u48ed\u7eb6\u941d\u4f3a\u51ac\ub649\u6cf9\uc206\ubcd6", "\ud978\udd4e\ud868\udd72\ud89e\ude18\ud912\udd53\udb30\udf7c\ud92d\udcfa\ud9e4\udf26\ud89e\udc4e\ud955\udc67\ud82c\udc3a\uda2f\udf1d\ud9a7\udda6\uda7b\udda1\uda73\udc54\ud810\udf94\ud822\udf1c\udb27\udd4d\ud9d8\udeee\uda32\udcf4\udba3\udeb3\ud820\udfd8\ud826\udc46\ud83d\ude51\uda6b\udd48\ud989\udf8f\ud9b7\udfef\uda0c\udedb",
        58, 41100, -560111547, 139723439479204827L, 96352L, false, true, (char) 38503, (char) 12915,
        Double.longBitsToDouble(0x3fe5e4d7329e98fcL), Double.longBitsToDouble(0x3fcec640b4439440L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 14, 14, 24, "\udb6a\udc87\uda43\ude05\uda42\udf90\uda21\ude42", "\u6645\u3f68\ud03e\u8af5\u5e15\u3513\u9aa9\ua95f\ub48a\u48ed", "\ud940\udd50",
        10, 70354, 1773452727, 1108140146202647976L, 64058L, false, true, (char) 17670, (char) 2638,
        Double.longBitsToDouble(0x3fe7a6677dc30f22L), Double.longBitsToDouble(0x3fd84cd96cdae59eL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 13, 13, 1, "\uda19\udcb1\ud970\ude0e\uda42\udf3a", "\u498b\u36ce\u7ce7\ua7e3\u727c\u2103\uc4c8\u6258\ubaaa\u2ad9\u1ef3", "\uda7e\uded7",
        43, 14282, -581348289, 2244742292018368187L, -78647L, true, true, (char) 20100, (char) 52321,
        Double.longBitsToDouble(0x3fe8db4045c30f22L), Double.longBitsToDouble(0x3fd6343309b65bdeL)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=E}\0121=java.util.HashMap:{E=E}\012",
        Z.run(T, 2, 18, 4, 26, "\ud844\udd20\ud981\uddb8\udb46\udf37", "\u16e3\u6c67\u334d\u224d\u6a7c\u2ea5\u4a06\ub4ef\u8156\u9028\u48ed", "\u2bfd\ud8b3\udcf1\uda52\udd8d\udbbe\udede\ud9c3\udde9\ud96c\udf7f\udbd4\udcd3",
        51, 54338, -760468698, 3702583008535145243L, -11608L, false, true, (char) 37520, (char) 61520,
        Double.longBitsToDouble(0x3fae44ff6596e8c0L), Double.longBitsToDouble(0x3fd86d33023d5900L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 13, 13, 1, "\udb60\udfb4\ud975\udc1b\ud8cb\udf0d", "\u4d94\u36ce\u2503\u8624\u727c", "\ud9bb\udd49\u49fa",
        39, 70298, -1406557649, -7663638031061090250L, -46474L, true, false, (char) 51858, (char) 11745,
        Double.longBitsToDouble(0x3fd5cb00d6d2575eL), Double.longBitsToDouble(0x3fef69b804a41de0L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String\0121=java.lang.Class:java.lang.String\012",
        Z.run(T, 2, 13, 13, 1, "\uda19\udcb1\ud970\ude0e\uda42\udf3a\ud99e\ude4c\u03c5\uda6e\udd63", "\ua770\u8ad7", "\udaeb\udeca\u7a49\udbfc\udfdf\ud2ec\uda7f\ude10\u9293\ud9ca\udd9d\udbb0\udfcd\ud9dd\udc76\ud8c0\ude34\udbe7\udf0e\udb56\ude04\ud808\udfef\udb11\udea6\ud978\udd73\ud8bb\udf9a\ud9ec\udc41\ud924\udfff\udaa8\uddb8\udbf4\udc17\ud8c5\uddce\ud81d\udf73\udb1b\uddbf\u4cbc\uda60\udc88\ud9be\udf1d\uda1f\udd17\ud8f7\udeca\udb51\udd82\udb5f\udfef\ud9c0\udd76\ud808\udca1\uda45\udd96\udb77\udef3\udb14\udfea\udb19\udc80",
        20, 91858, -2091515358, -4691711363758574730L, -90802L, false, true, (char) 41742, (char) 31028,
        Double.longBitsToDouble(0x3fcb687397b164c8L), Double.longBitsToDouble(0x3fe5eae6c6544698L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 20, 7, 6, "\udb46\ude01\ud97e\udf34\ud884\udf3b\ud8b8\udcf5\udaaa\udc5f\ud883\udd9c\ud957\udf43\u05d3\udaa5\udd4d\u12b2\ud950\udcf1\ud953\ude0d\ud9d0\udc57\ud829\udddf\ud8e6\ude2c\udb2d\udf1d\udba9\ude10\ud8a9\ude6f\uda7e\uded7\ud8df\udf1a\udaea\udc6c\udbb2\udc43\uda58\udfca\ud9ad\udc90\udb8d\udddf\ud98c\udd61\ud817\udd02\ud8fa\udca6\uda3e\udcb9\ud83d\udc7b\uda2d\udf9a\udb5b\udc65\uda15\udf3e\udaef\ude5d\udbaf\udc37\udbc2\udfe5", "\uc329\u1d8d\u5639\uca8f\ub4f0\u36e8\u40ba\u187b\u24c0\u167c\u6838\u8b67\u3f9f\u7b92\uc901\u399b\u964a\u5680\u57e1\u9895\uacce\ubb4a\u0152\u3d73\u05cb\ucd4c\u389f\u0984\ua4dd\uc6ae\u43f2\u6088\u0fbc\u828f\ub777\u30ab\ub95d\u1759\u10c9\u479e\u7d40\u37aa\ud0a3\u6997\u7835\u14ca\u642f\ubb21\u3fbf\u581e\u0ad2\ud636\u50cf\u2785\u22b8\u192c\ua81a\u2543\u505d\u240f\u9026\u57d0\u614c\uc012\u60b5\u2e8c\u012e\u31e5\u48b7\u476c\ub724\uc71a\ub450\u6ec2\u31d5\u98f4\ud6a9\uacc2\uc920\u6cbb\u71fd\u6d9a\u16a8\ub40b\u037c\u2e2c", "\udaf1\udc63\ud9da\ude21\u76c6\u9975\ud9af\udc03\ud8f6\udd06\ub395\udb3e\udd88\udbf6\udea4\udb17\udf89\ud919\udc5a\ud9b7\udec7\uda14\udf42\udb03\udc48\ud89d\ude12\ud94e\udcb2\ud834\udc79\udb39\udda2\udbc6\udf8e\udb98\udca9\ud80b\udc21\udb6b\ude8c\ucf06\ud8c3\ude6a\udbb8\udfef\udba3\udd50\ud87e\udd54\udbc0\udf45\udb74\udf40\udab5\uded4\uda12\udc6c\uda25\udd14\uda66\udd21\uda56\udec5\udafe\udc85\ud86b\udda3\ud961\udf17\udbbd\udd13",
        51, 59440, 1377870501, 5259261731818866382L, 48227L, true, true, (char) 47499, (char) 60622,
        Double.longBitsToDouble(0x3fb0e19ca4a11a78L), Double.longBitsToDouble(0x3fee4593edc41bd6L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 21, 10, 5, "\udb67\udd01\ud830\udf2d\uda42\udf3a\ud953\udf03\u03c5\udbd1\ude34\ud957\udf43\u05d3\ud839\udfb7\uda77\udfd5\u2d87\ud9ae\udda7\udaca\uddfa\ud85a\udc61\ue235\udb2d\udf1d\udba9\ude10\ud8a9\ude6f\ud90a\udd53\uda9b\udf86\uda60\udc7b\udae9\ude61\udbf4\udd3a\ud9c1\udd69\uda97\udc45\ud8ea\ude55\ud8c9\uddf5\ud9e1\ude3e\ud89e\ude27\udb09\udcb6\ud9ca\udfdc\ud992\udf2a\udb6c\udfc5\ud825\udd92\uda8b\ude1b\ud972\udcbb\ud96c\udefb\udb5a\udfee\ufc86\ud8eb\ude1d\ud9d2\udd1d\uda26\udc66\ud8e9\udc98\ud9dd\udd88\ud9af\udcc8\ud92b\ude12\ud9c1\udcca\ud90c\udc36\udb96\udd3f\ud878\udd8f\udb96\ude32\ud808\udfc8\ud8ca\ude5c\uda20\udc91\ud9a5\udc24\uda1b\ude7d\udab6\udef4\ua3bd\udaab\udc8c\ud8c6\udebd\udb0c\ude32\uda3e\udf43\ud8ae\udd45\uda42\ude9e\ud8d8\ude27\u20e9\ud83e\uded9\ud968\ude31\udb4b\ude9f\udbf8\udcfe\ud822\udff0\ud8a6\udc17\udbd5\udf66\ud982\udf80\udb76\udf46\ud8fc\udd37\ud80d\udee1\ud801\udfe1\ud882\udc42\udbfa\uddf2\udaf7\udfd8\ud85c\udf2c\uda76\udf33\udb0f\ude6e\udab4\udc6d\ud83d\udfd2\ud82f\udeaa\udb52\ude8a\uda21\udcba\ud88a\udff9\udaef\udf1b", "\u02dc", "\u74a2\udb8c\udc72\udaca\uddc5\udbe6\udc05\ud972\uded4\ud98d\udcaa\ud994\udfee\ud807\udcbe\uda32\udc56\ud80e\udde9\ud989\udc52\uda51\ude79\ud8c8\udcc1\uda98\uddd9\udbd0\udccc\udb69\udf0f\ud9a1\udd97\uda75\udebd\udb6e\uddcb\ud97c\ude49\ud8ca\ude71\ud87b\uddad\ud8ed\udf00\udae3\udc4f\udbf4\udef0\udaea\udec7\udaf1\uddb1\ud970\udfb3\ud906\udede\u8cad\uda26\ude65\uda95\udfbc\udab6\ude65\udade\udf45\ud97b\udc9d\ud8fb\ude8f\ud8f3\udd54\ud9cb\udd24\udabf\uddfc",
        38, 64822, 862049784, 8583372313890719282L, 7566L, false, true, (char) 27485, (char) 57767,
        Double.longBitsToDouble(0x3fda8db227811464L), Double.longBitsToDouble(0x3fd5faf80ba97db8L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 16, 8, 0, ",\000\udbf9\udc9c\udaa8\udf4d\u0471\uda95\udfae\ud957\udf43\u05d3\udaa5\udd4d\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32", "\u7eb6\u887d\u3d46\u8fa0", "\udb48\udfcd",
        56, 10552, 210476725, 1864674387398765350L, -79145L, true, true, (char) 55573, (char) 58321,
        Double.longBitsToDouble(0x3fdd1980c34a2304L), Double.longBitsToDouble(0x3fe422b940269bcfL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 11, 9, 20, "\ud827\udff2\udb3e\udcd8\ud884\udf3b\ud8b5\udf5d\u89db\ud960\udee4\ud907\udffd\udad7\udeee\uda5b\udf8c\uda69\udd80\uda19\ude52\udb19\udc2e\udbb8\udd38\ud85a\udd32\ud9f4\udf53\udb27\ude25\ud998\ude29\ud87d\udfad\udaec\udc73\ud807\udc70\ud8c5\udd76\udba3\udf0c\uda58\udfca\ud8ab\ude86\uda97\udc45\ud8ef\udd72", "\u356a\u0a30\u9068\uac8b\u5468", "\u97bf\ud9fd\udc00\ud828\uddc0\ud8e7\udc99\ud8b7\ude89\uda0d\udcef\ud8e4\udc39\ud879\ude63\ud8ea\udc77\ud990\ude26\udac5\udcac\ud923\udec5\udb16\udd5f\ud84c\uddf3\ud91e\udc5f\udafd\udfb5\udaf3\udfb4\u56ce\udae5\udf79\ud824\udd24\ud83c\udd9b\ud89f\udc65\uda34\udc9f\udb43\ude60\u552f\uda42\udc78\ud891\ude04\ud9f9\udc3c\ud9fa\udd06\udb36\udf92\udb0d\ude2d\ud8c3\udca7\ud862\udc29\ud8cd\udc33\ud820\uddab\ud852\ude6f\udb9f\ude30\ud95d\udd67\uda96\udfa4\udbd4\udf87\ud8f8\udf21\ud867\udcde\udb10\ude94\ud95d\udfaa\ud8b2\udebf\ud83b\udfa3\ud954\udd59\udb1c\udd76\udb3b\udd4c\ud8f1\udc53\uda16\udff8\ud90f\udee2\ud8c6\udf46\ud890\udcd3\uda42\udd24\uda5a\udf9d\udb45\udd10\uda84\udc00\ud84e\udda6\uda7f\ude00\ud95a\udc00\ud9b9\udc97\ud941\udcf7\udb1d\uddc9\ud9a8\udcdd\uda3c\udd18\ud9f2\udcf3\udb58\udf7d\uda73\udd83\udb6e\udd96\udac4\udf6b\ud95b\udcee\udb73\udc2a\ud801\udd89\udb56\udce3\udb13\ude18\uda96\ude4f\udad8\uddbf\ud983\udf67\ud8f7\udec1\ud948\udd57\ue442\ud83d\udf45\udacb\udca3\ud9c3\udfc3\ud827\udf53\udb25\uddbd\ud912\ude91\ud9e6\udc3c\uf61d\udba8\udc70\ud9b1\udc7f\udae6\uddcf\ud8c9\udd0c\ud939\udde8\udbdd\udd59\ud94e\udf66\uda98\udc81\uda1d\udfc1\ud888\udd7b\udb1f\udf66\udb6c\udfc5\ud9da\udf0b\udb61\udffc\ud8a1\udcad\udada\udca5",
        22, 24063, -2046858688, 8958252439038250327L, -68451L, true, true, (char) 4012, (char) 63648,
        Double.longBitsToDouble(0x3fecc8fdcf428e43L), Double.longBitsToDouble(0x3fdf7e64eeab4026L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 16, 8, 0, ",\000\udbf9\udc9c\udaa8\udf4d\u0471\uda95\udfae\ud957\udf43\u05d3\udaa5\udd4d\u12b2\ud950\udcf1\ud9c7\udf68\ud9ca\udc84\ud85a\udd32", "\u7eb6\u887d\u3d46\u8fa0", "\udb48\udfcd",
        56, 10552, 210476725, 1864674387398806960L, -79145L, true, true, (char) 55573, (char) 58321,
        Double.longBitsToDouble(0x3fdd1980c34a2304L), Double.longBitsToDouble(0x3fe422b940269bcfL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.Class,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.ParameterizedType,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.Type,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.ParameterizedType|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.Type,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.GenericArrayType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.ParameterizedType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.Type,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.TypeVariable,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.WildcardType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.Type|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|determineTypeArguments|java.lang.Class,java.lang.reflect.ParameterizedType|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getArrayComponentType|java.lang.reflect.Type|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getClosestParentType|java.lang.Class,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getImplicitBounds|java.lang.reflect.TypeVariable|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.Class,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.ParameterizedType,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.Type,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.ParameterizedType|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.Type,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.GenericArrayType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.ParameterizedType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.Type,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.TypeVariable,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.WildcardType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.Type|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
