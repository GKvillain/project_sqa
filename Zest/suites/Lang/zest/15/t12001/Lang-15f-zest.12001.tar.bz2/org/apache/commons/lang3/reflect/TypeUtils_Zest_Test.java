package org.apache.commons.lang3.reflect;
import org.junit.Test;
import static org.junit.Assert.*;
public class TypeUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        34, 57497, 1883814005, -3513205938651778315L, -14667L, true, true, (char) 64223, (char) 16594,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 8, 5, 9, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6", "\u0f5c\u26b8\u35fe\u7a81\u78b9\ub6ff\u8b57\u2979\u87ca\u2270\u8b81\ua921\u9f4b\uce93\ua0e4\u28a8\u4307\ud5cd\ua933\u6eb9\u2860\u2c1d\u2914", "\ud959\udff4",
        38, 16341, 181589259, 3254147287265884277L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551f42ec22f6cL), Double.longBitsToDouble(0x3fe012f8e5ef818fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 5, 20, "\udaf5\udd71\udb48\udeea\u3b8d\ud9ee\ude63\ud99c\ude99\ud81f\udda6\ud9ea\udec9\uda1f\udde5\ud8dd\udffe\ud891\ude48\uda70\udc15\udb93\uddcc\ud987\ude35\uda43\udd38\ud96d\udc4d\uda2b\ude16\ud936\udcd2\udaaf\udc22\ud85f\udf82\uc16d\udb35\udfae\udbf1\udc3c\udb2b\udf75\uda9d\udf69", "\u83ce\ub42e\u27ed\u2c1d\u7ea9\u424f\u33f2\uce47\u6e7e\u8eca\u1293\u2d3e\ub93c\ucb63\u7f8a\u0485\ud578\u7479", "\ud969\udc1f\udb3c\udfa0\udb6a\udf6f\ud8a0\ude3b\udb24\udf29\uda2b\udc0b\udbd2\udc03\ud9bd\udf34\ud904\udc65\udb21\ude9b\ud8a5\udfef\ud96d\uddca\udb0e\udf4e\ud9d6\udf9a\u203d",
        36, 90130, -2120423485, 3744047271576511025L, 16749L, true, true, (char) 6832, (char) 1748,
        Double.longBitsToDouble(0x3fd1dddcff209f34L), Double.longBitsToDouble(0x3fecae9d0907f9a7L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 11, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udafc\ude10\udbd5\udc6e\uda0c\udf2a\udb5f\udd2f\udaa0\udcf2", "\ua933\u3705", "\uda25\udd41",
        56, 64812, -1077171267, 1002054592466333340L, 26931L, false, true, (char) 1560, (char) 564,
        Double.longBitsToDouble(0x3fe3d81ef6308839L), Double.longBitsToDouble(0x3feb6e1485551f42L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Number\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 14, 2, 10, "\ud82c\udf08\udb4c\uddea\u3335", "\u8ea7\u2277\u1f11\u43c9\u2561\u35fb\u54cd", "\ud96d\udc4d",
        43, 13307, 1740374252, -2224011930980315737L, -20330L, true, true, (char) 59831, (char) 18442,
        Double.longBitsToDouble(0x3fe853058dacaf5bL), Double.longBitsToDouble(0x3fb034c7cde211b0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud82c\udf08\udb48\udeea\ud88d\udc3b\uda75\udc50\udabb\udcc5\ud81f\udda6\udbae\udc2b\udb20\udcc4\ud8dd\udfa0\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\u3dcf\u6eb9\u2860\u2c1d\u6756\u3779\u625b\u6ef5\u1f10\u3a8e\u6ce2\u2d3e\u5d89\ucc06\u6a78\u0485\ub92c\ucf8a\u7b6a\u42f7\u542f\ub2c9\u5ce7\u6633\u8a1e\u2e88\u0dcd\u1021\u9915\u4897\u1d3f\u7112", "\ud9c2\udd87\ud86a\udf6f\udaea\ude2d\udbed\uddab",
        10, 6223, -677005010, -5053628244141947564L, -57519L, false, true, (char) 54573, (char) 52924,
        Double.longBitsToDouble(0x3fe048a9a63dde1aL), Double.longBitsToDouble(0x3fec874047f8b77bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 22, 12, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\ud9ce\uded8\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\udb22\udda5\udaa9\udd19\ud822\udfc7\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\ud9d9\ude36\ud925\ude45\udb2b\udfdb\ud8c5\udce1\udb14\udf0d\udb5b\udef7\udaa0\udcf2", "\u66b6\u0934", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        34, 57497, 1883814005, -3513205938651778315L, -14667L, true, true, (char) 64223, (char) 15315,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9bf\udd64\udab0\udf38\ud81f\udda6\udbae\udc2b\ud806\udc18\ud9f4\udccd\udb0b\ude6c\ud98e\udefb\ud84d\udc11\uda4f\uddde\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udf45\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\ud99d\udc7d\ud815\udcf1\udb48\udc05\ud959\udff4\ud954\udd61\uda1f\udc77",
        5, 57497, 1883814005, -3513205938654084650L, -53464L, true, true, (char) 29024, (char) 8588,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 23, 10, "\ud824\udf08\udbf5\udc9a\ud931\udc22\ud8ff\udd36\udba0\udc34\ud928\udfec\uda02\uddff\uda1f\udea6\ud8dd\udffe\udb03\udca1\ud0af\uda4d\udd11\ud8f1\ude0a\ud87f\udc6a\ud874\udfef\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud8f2\udc0b\udb65\udea0\ud997\udc9e\uda74\udd82\uda41\ude52\ud931\udfbd", "\ua933\u6eb9", "\uda25\udd05\ud815\udcb9\udb48\udc05\u0fa8\ud8a6\udd0a\uda90\ude21",
        31, 1457, -532105099, -3513334525677653259L, -14667L, false, true, (char) 39947, (char) 16766,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\ud9fa\udf81\uda36\uddf0\udbce\udfe1\ud98e\udf48\ud84d\udc11\ud97f\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        34, 57497, -747612584, -4701069321493925337L, -50877L, false, false, (char) 48461, (char) 29913,
        Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL), Double.longBitsToDouble(0x3fd6a7fdbf8e238cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 15, "\ud82c\udf08\udb48\udeea\udb6a\ude12\ud9d2\ude9a\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65", "\u35c9\u7a81\u78b9\u60c6\uae0b\u1f34\u87ca\u67b9\u8c35\ua921\u9f4b\uce93\ua0e4\u28a8\u5940\ud5cd\ua933\u6eb9\u2860\u2c1d\u2914\u3779\ua3d6\u77a4\u502f\u2cca\u6ce2\u2d3e\u5d89\ucc06\u7f8a\u0485\u656b\u7441\u7bb5\ucbd4\u542f\ub2c9\uae25\u43ca\uc12a\u1bab\u307e\ucbb4\u8ae8\u2a4e\u470d\u6921\u2f6d\u7722\u0cd8\u6eca\u7818\u9dea\u9f54\u9cb4\u8f2a\u036d\u50cb\u673a\u7070\ub8b9\u09f8", "\ud815\uddd4\ud81e\udcd9",
        43, 68850, 67061884, -6765115038321698432L, 80199L, true, false, (char) 31716, (char) 8632,
        Double.longBitsToDouble(0x3fd11893dadd40dcL), Double.longBitsToDouble(0x3fe10068d9920bf5L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=null\012",
        Z.run(T, 2, 8, 14, 10, "\ud82c\udf08\udb48\udeea", "\u423a\u8ea7\ucdb9\u6b92\u0f5c\u26b8\u35fe\u7a81", "\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45",
        32, 16664, -1040930787, -8497698028522307004L, 45472L, false, true, (char) 55790, (char) 1796,
        Double.longBitsToDouble(0x3fd2fe6fb659689eL), Double.longBitsToDouble(0x3fedee548358bfcbL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud8e9\udd67\ud842\udcd0\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf26\udaaf\udc22\ud925\ude45\udb45\udf81\ud9b0\ude26\udbde\udfeb\udb5f\uddb6\udaa0\udcf2\udb1d\udc58\udb2c\ude6b\ud95f\udce1\udb93\udc73\udac0\udfe4\uda73\udee8\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a", "\u2d3e\u5d89\ucc06\u37c9\u042a\ud55f\u7479\u0bdf\uc89b\u0b1c\ub29e\uae25\u43ca\uc12a\u17bb\u120d\u77eb\ua98a\u691d\u378f\uad5e\u64ad\u59ff\u45d7\u57d5\u9880", "\ud960\udc6c\ud8af\udfde",
        24, 52303, 2022224330, -3605600760990719465L, 77276L, true, false, (char) 27023, (char) 22022,
        Double.longBitsToDouble(0x3fecb6ce52466cf8L), Double.longBitsToDouble(0x3fdd6fdcca1ef720L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\uda04\udf3d\uda30\udfbe\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd",
        44, 62005, -814694133, 278716252782396027L, 2547L, true, true, (char) 17676, (char) 64223,
        Double.longBitsToDouble(0x3fc658041c42a810L), Double.longBitsToDouble(0x3fd50c27a14e1f2eL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 10, "\ud829\udf04\uda47\udf2b\u7d8d\ud9ee\ude63\ud904\udd49\uda11\udc12\udbae\udc7e\uda1f\ude65\ud8dd\udffe\udb03\udca1\udbc4\ude37\udbac\udff2\udbfe\udfa6\uda43\udd38\udae0\ude5f\uda99\udd8e\ud9d4\udea6\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\ud912\ude54\udaad\udd4c", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud97a\ude04\u5ef8\udbc1\uddb9",
        34, 57497, 1883814005, -3513205938651778315L, -14667L, true, true, (char) 64223, (char) 39138,
        Double.longBitsToDouble(0x3fd5ffd567269b16L), Double.longBitsToDouble(0x3feeb1605a429bdcL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud82c\udf08", "\u3701\u423a\u8ea7\ucdb9\u6b92\u0f5c\u26b8\u35fe\u7a81\u78b9\ub6ff\u8b57", "\udbd2\udd29\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2\udb1d\udc58",
        13, 88680, 1110849600, -5919161768033637356L, -34767L, false, false, (char) 43964, (char) 49955,
        Double.longBitsToDouble(0x3feceec745cf67bbL), Double.longBitsToDouble(0x3f99ae380ead32c0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=null\012",
        Z.run(T, 2, 21, 16, 10, "\ud82c\udf08\ud841\udf07", "\ud7a2\uab63\ucdb9\u6b92", "\ud987\udc88\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udd09\udaf5\udc93\udaa8\udfcb\udb1d\udc58\udade\ude94\ud84b\uddaf\ud9d6\udd2d\udacb\udc77\uda73\udee8\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud82d\udcc3\uda04\udc5d\udba0\udcfe\udbed\udecb\ud98d\udfc4\ud9a5\udef0\ud942\udf2f\udb3c\udfeb\ud8ff\udd32\uda31\udf68\udaed\udde0\udacc\udcbe\udbba\udf54\udb4e\udd93\uda2d\udde5\ud9ed\udcac\uda25\ude4a\udb8c\udc7f\uda3a\ude34\ud980\udd71\udbc0\udf85\ud829\ude4b\ud845\ude58\ud837\udc70\uda3c\udc2e\udb7f\udd06\udb71\uddef\ud83f\uddd8\uda1d\ude2c\ud816\udc6a\ud8a6\udda6\udb64\udf43\ud91f\udc0d\udafc\udca6\ud931\udca4\ud9ab\udfaa\ud8f6\uddd6\udb31\udc1f\ud9dc\udfdd",
        44, 44707, 870437125, -2472581804802145864L, -55297L, true, false, (char) 61736, (char) 44082,
        Double.longBitsToDouble(0x3fd7ea5c82e92e20L), Double.longBitsToDouble(0x3fe9c2ec58dd135dL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 8, 5, 10, "\ud9b5\udd33\ud859\udd38", "\u423a\u8ea7\ucdb9\u6b92\u0f5c\u26b8\u35fe\ud52b", "\ud96d\udc4d",
        43, 13307, -1931998484, -2224179980683375193L, 45472L, false, true, (char) 21104, (char) 1796,
        Double.longBitsToDouble(0x3fd2fe6fb659689eL), Double.longBitsToDouble(0x3fedee548044bfcbL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 10, "\u9165\000\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\u2abb\ud8dd\udf1b\ud89e\ude9c\ud975\udd99\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud905\udf7e\udaaf\udc22\u3019\udb2b\udf34\ud997\udc9e\udbd9\udc74\udb16\uddb5\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        7, 99080, 47221, -3513205938651778315L, -14667L, true, true, (char) 64223, (char) 16594,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3e4d4b5fbc000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 18, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\ud80a\udea5\ud98e\udeeb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbe4\uded1\udb7c\udc6b\udaa0\udcf2", "\ub59a\u8dc0\u6a35\u2c1d\u2914\u3779", "\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd\udbed\ude51\udbeb\udf12\ud9a6\udef0\ud942\udf2f\udbe0\udf6b\ud874\ude91\uda4c\udd44",
        14, 46539, -1071595549, -6195685686394573040L, 15749L, false, false, (char) 15186, (char) 53266,
        Double.longBitsToDouble(0x3fe89eae1d7dad66L), Double.longBitsToDouble(0x3fd15637e3c3d760L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 8, 5, 10, "\ud82c\udf08\ud9c0\udf77\udb15\uddc3\uda42\udee9\ud8c7\udfc0\ud81f\udda6\udbae\udcc9\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud8c1\udff6\ud84d\udc0a\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6d\udc23\uda90\udcfd\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\ud9f9\udd84\udb37\ude96\ud8af\udde3", "\ua933", "\ue017\uda25\udd41\ud815\udcb9\udb2e\ude37\uab2a\udb2a\udc31\ud830\udc54\ud8d2\udcfd\udbed\ude51\udbeb\udf12\ud8f4\udcf7\udb0e\udd56\udb53\udfe5\ud874\ude91\uda4c\udd44\ud931\udfa3\udbbc\udd64\ud969\udc1f\udb3c\udfa0\udb6a\udf6f\ud8a0\ude3b\uda25\ude4a\udb77\ude55\ud93a\udca3",
        1, 77925, 553656527, -7607545013444087615L, -4157L, true, true, (char) 52710, (char) 3252,
        Double.longBitsToDouble(0x3fe54c873bc28947L), Double.longBitsToDouble(0x3fd9ea372fccf7d6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 7, 19, "\ua6e8\udbfe\ude84\ud803\uddab\ud9ee\ude63\udab0\udf9f\udb72\uddfb\udbb9\udd7e\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84c\udf89\ud987\ude2c\udaad\uddf0\ud96d\udc85\uda1d\ude2f\ud961\udf8c\udaaf\udc22\ud848\udc45\udb2b\udf78\ud980\udd33\ud8d2\ude60\ud97f\udf71\udaa0\udd01", "\ua933\ua6f4", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud882\udf36",
        13, 53577, -2099087320, 7608523818287899541L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551f42bd64e42L), Double.longBitsToDouble(0x3fef1d27ea7f7a20L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 23, 3, 10, "\ud82c\udf08\udb48\udeea\u7de8\uda40\udf4a\uda5e\udf96\uda59\udc07\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\udb3f\udf54\ud811\udeb6\ud987\ude35\uda43\udd38\ud96d\udc4d\uda5e\udff1\udaf6\udd7f\ud84a\ude0c\ud939\udece\ud828\udda5\ud868\udf7d\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\ud915\udeca\ud80c\uddc0\udb48\udc05\ud880\udf47\ud8a6\udd23\udbc1\uddb9",
        34, 57497, 1883814005, 8821804895530005237L, -40589L, true, true, (char) 27799, (char) 17676,
        Double.longBitsToDouble(0x3fef19d7edb2c020L), Double.longBitsToDouble(0x3fec4a8cd150c27aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 5, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\udbbb\udea8\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\ud89f\udff2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a",
        35, 77039, 1771497497, 8090919544611739344L, 82831L, false, false, (char) 12798, (char) 27799,
        Double.longBitsToDouble(0x3fdeb2721fc675faL), Double.longBitsToDouble(0x3fc658041c42a810L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 26, 5, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda46\udd65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933", "\udafd\udd81\udbdf\uddba\ud81a\udca8\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd",
        32, 62005, -817982000, 278716252782396027L, 2547L, true, true, (char) 17676, (char) 64223,
        Double.longBitsToDouble(0x3fc658041c42a810L), Double.longBitsToDouble(0x3fd50c27a0d41f2eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 11, 1, "\ud82c\udf08\udb48\udeea\udb5f\ude92\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud9cf\udd27\udade\udced\ud94f\udc71\udb2b\udfdb\udb60\udc23\ud8fc\udd46\udb5f\udd66\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\udbff\udf0e\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        19, 57537, 1883814005, -3513205938651778315L, -14667L, true, true, (char) 64223, (char) 16594,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fe5387cbf52d7efL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 8, 14, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\ud8f0\udde0\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\ud896\udd9a\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        34, 57497, 1883814005, -3513205938651778315L, -14667L, true, true, (char) 64223, (char) 16594,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 20, 14, 0, "\ud82c\udf08\udb48\udeea\u7d8d\ud822\udcbd\ud8b5\uddf5\ud80e\udc17\udbae\udc2b\uda1f\ude65\udb87\udc8d\udb03\udd32\ud98e\udefb\ud84d\udc11\udb16\ude3c\udb67\udc0a\udb82\uddf8\uda7b\udd10\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\udb05\udfa7\udbd9\udc74\udb5f\uddb6\uda7a\udf9c", "\ua933\u6eb9", "\ud9d4\udec2\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd\uc990\udbf9\uddb9\ud9a6\udef0\ud9db\udffd\udbf7\udcfd\ud874\ude91\uda4c\udd44\ud931\udfa3\ud8d3\udf51\udaa5\udfe9\ud872\udeac\uda60\ude74\udbfd\udf31\ud86e\udf6c\ud825\udde1\udbe6\udde7\udb26\udf43\ud98e\udf53\udaff\udf62\ud8be\ude9e\ud956\udc58\uda0d\udd0b\udb6a\udedb\uda6d\udf53\udad8\ude21",
        36, 99136, 461479235, 1919097012678421718L, 78180L, false, true, (char) 25403, (char) 43926,
        Double.longBitsToDouble(0x3fe08230dde00acbL), Double.longBitsToDouble(0x3fc23dde3237af14L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 10, 0, "\ud82c\udf08\udab6\udf81\ud803\udc20\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud975\uddfb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\000\ud996\udfd6\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\000\000\000",
        -5, 99080, 1883814005, -3513205938651778315L, -14667L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe885500150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 16, 17, 10, "\ud82c\udf5c\udb02\udf59\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22", "\u7b25\u08bc\ua0e4\u28a8", "\ud84b\uddaf\udb9d\udc26\udacb\udce4\ud8a6\udc41\uda25\udc8a\ud815\udcb9\ud8d2\udd88\udb09\udf2d",
        38, 83525, -1372006961, 7608523816444672117L, 32085L, false, false, (char) 62923, (char) 9116,
        Double.longBitsToDouble(0x3fe002dbfdeb2721L), Double.longBitsToDouble(0x3fef19d7e8015a20L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Class:java.lang.String\012",
        Z.run(T, 2, 8, 13, 8, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda3a\udd9d\ud98f\udecf\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\u7720\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        34, 43385, 1883814005, -666295456432729387L, -14667L, true, true, (char) 64223, (char) 16594,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd487d84L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 9, 5, 10, "\ud808\udda3", "\u00fc", "",
        25, 45203, -1677812253, 2692706649487140194L, -100000L, false, false, (char) 20406, (char) 25441,
        Double.longBitsToDouble(0x3fc361c52bb0c7bcL), Double.longBitsToDouble(0x3f419b1400000000L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\ud9b1\udcfe\ud81f\uddcc\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\uda37\udc0d\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9\u2860\u2c1d\u2914\u3779\ua3d6\u77a4\u6502", "\udbed\ude51\udbeb\udf12\ud9a6\udef0\ud942\udf2f\udbe0\udf6b\ud874\ude91",
        54, 95045, 989666795, -4602467838935924558L, -42992L, true, false, (char) 38721, (char) 14481,
        Double.longBitsToDouble(0x3fd71f01e4bc822cL), Double.longBitsToDouble(0x3fe707aabf10bd4fL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 4, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\uddbb\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud9fb\ude33\udb07\udf62\ud8f5\udecc\uda43\udd38\uda69\udd50\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\udbf1\udd35\ud815\udcb9\udb5b\ude4f\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        34, 55969, 1883821969, -3513205938651778315L, -14667L, true, true, (char) 26048, (char) 32577,
        Double.longBitsToDouble(0x3fc56d82f1887394L), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 5, 10, "\ud82c\udf08\ud986\udfd7\udad0\udc10\uda63\udf97\udab0\udf05\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb5e\udedb\ud997\udc9e\udbd9\udc74\udad4\ude8f\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\uda51\udc4f\ud8a6\udd70\udbc1\uddb9",
        34, 57497, 1884568693, -3513205938651778315L, -14667L, true, true, (char) 64223, (char) 5842,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 9, 20, "\ud82c\udf08\udb48\udeea\u7d8d\udb16\uddb6\ud957\udef6\udbd9\udc90\udbc9\udd95\ue6f4\ud8dd\udffe\udb03\udca1\ud98e\udefb\udbc8\udf6e\udbd6\udc06\uda43\udd38\uda49\udd5c\ud836\udfa2\uda66\udd03\uda7c\udc15\ud843\udc68\udb2c\udc14\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9\u2860\u2c1d\u2914\u3779\ua3d6\u77a4\u6502\u3a8e\u6ce2", "\ud9b4\udfa4\ud942\udf2f\ud85e\udf8a\ud874\udf53\uda4c\udd44\ud931\udfa3\udbbc\udd64\ud969\udc1f\udb3c\udfa0\udb6a\udf6f\ud81b\udfb9\uda25\ude2c",
        12, 5028, 363253926, -6628678775991682026L, -15601L, false, true, (char) 44445, (char) 59056,
        Double.longBitsToDouble(0x3fd3d776089b6fd4L), Double.longBitsToDouble(0x3fe11486174e05fbL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 12, 23, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udfec\udb03\udca1", "\u78b9\ub6ff\u8b57\u5229\u87ca\u2270\u8b81\ua921\u9f4b\uce93\ua0e4\u28a8\u5940\ud5cd", "\udacb\udce4\uda73\udee8\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd\udbed\ude51\udbeb\udf12\ud9a6\udef0\ud942\udf2f\udbe0\udf6b\ud874\ude91",
        32, 93909, 989666795, -4602467838936710990L, -42992L, true, false, (char) 38721, (char) 46273,
        Double.longBitsToDouble(0x3fea526dcb5b4d0fL), Double.longBitsToDouble(0x3fe2c7a20d15ab2dL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 25, 25, 14, "\u8f3a\ud9c8\udc15\u7d2b\ud9ee\ude63", "\u9427\uce65\u3be6\u26f6\u35fe\u7a81", "\ud96d\udcb2\ud82e\udf37\udb3e\udd79\udaaf\udc22\ud925\ude53",
        32, 16664, -1040930787, -8497698032352419200L, 45472L, false, true, (char) 55790, (char) 1796,
        Double.longBitsToDouble(0x3fd2fe6fb659689eL), Double.longBitsToDouble(0x3fc7b95219615744L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 1, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\ud802\ude90\uda1f\ude46\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        16, 57497, 1883816789, -3513205938651778315L, -14667L, true, true, (char) 22395, (char) 16594,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fde70f97ea5af24L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 5, 10, "\ud8ff\udfc4\udbba\ude9e\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb09\udea1\uda54\udd7f\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\ud993\ude29\udb8d\udd56\ud9fb\udcdb\ud96a\udcf7\udb2b\udfab\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud941\udcfd\udafe\udcda\ud959\udff4\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd\udbed\ude51\udbeb\udf12\ud9a6\udef0\uda02\udd6e\ud800\udf93\ud8a3\udd56\ud943\ude07\udb86\udfd4\udb99\udea7\ud8cb\udcc8\udbdf\udf71\udb55\udc8c",
        13, 57902, -66207876, 288983516459426245L, -37347L, false, true, (char) 58713, (char) 50725,
        Double.longBitsToDouble(0x3fd2976db762dbc6L), Double.longBitsToDouble(0x3fc26940f8c04688L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 16, 0, 19, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b", "\u36fc\uaf78\u7a95\u150b\u0d17\u8319\u5229\u87ca\u2270\u8b81\ua921", "\uda69\uddba",
        22, 4558, -1024506322, 273784443645343831L, -88716L, true, false, (char) 10026, (char) 28739,
        Double.longBitsToDouble(0x3fedee548358bfcbL), Double.longBitsToDouble(0x3fea5a1745cf67bbL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=E, E=E}\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 16, 5, 6, "\ud82c\udf08\udb48\udeea\uda91\udca5\udaae\uddee\udab0\udf9f", "\u6b92\u0f5c\u26b8\u35fe\u6ab7\u78b9\u52d9\u8b12\u5229\u0ba5\ud06b\u4e0b\ua921\u35cf\uce93\ub8a8\u28a8\u5940\u5a38\u743f\u12d7\u2860\u2c1d\u4c0a\ua8cc\u4df8\u7dba\u6502\u3a8e\u6ce2\u17f1\u44bf\ucc06\u1578\uc5fb\ud5a0\u7479\u7bb5", "\udb3c\udfa0\udb4a\ude6f\ud8e8\ude91\uda32\ude94\uda80\udea9\ud8b4\udca1\ud8d8\udd9a\ud84b\udc81\udbc2\udf70\ud873\udd97\ud90c\udc78\udabd\udfd4\ud942\udd97\udb5a\udda3",
        -5, 26519, -1332344010, 157818840507524961L, 92066L, true, false, (char) 4593, (char) 38488,
        Double.longBitsToDouble(0x3fe11669501d6d57L), Double.longBitsToDouble(0x3fdfdadc3f10bd26L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 8, 4, 13, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6", "\u0f5c\u26b8\u35fe\u7a81\u78b9\ub6ff\u8b57\u2979\u87ca\u2270\u8b81\ua921\u9f4b\uce93\uca0f\u28a8\u4307\ud5cd\ua8b3\u6eb9\u2860\u2c1d\u2914", "\ud959\udff4",
        38, 16341, 181589259, 3254147287265884277L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551f42ec22f6cL), Double.longBitsToDouble(0x3fe014cc75ef818fL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 4, 5, 9, "\ud82c\udf08\u390d\uee41\ud9ee\ude63\ud2f0\ud9f2\udc2b", "\u0f5c\u26b8\u6c00\u7a81\u78b9\ub6ff\u8b57\u2979\u87ca\u2270\u8b81\ua921\u8c8d\uce93\ua0e4\u28a8\u4307\u5ff6\ua933\u5c65\ubfeb\ub4a6\u2914", "\ud9dc\udc34",
        4, 16341, 181589259, -7179004199491310981L, 74145L, true, true, (char) 22814, (char) 28542,
        Double.longBitsToDouble(0x3fdd16e4c7b9fb68L), Double.longBitsToDouble(0x3fcddfd8c3cd96a0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 13, 0, 9, "\uda0a\udfb8\udb48\ude94\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6", "\u0f5c\u26b8\u35fe\u7a81\u78b9\u9a6a\u8adc\u2979\u87ca\ua4e2\u8bf6\ua921\u9f4b\uce93\ua0e4\u28a8\u4307\ud5cd\ua933\u6eb9\u2860\u2c1d\u2914", "\ud959\udff4",
        38, 16341, 181589259, 3254147287265884277L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551f42ec22f6cL), Double.longBitsToDouble(0x3fe012f8e5ef818fL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 5, 9, "\ud82c\udf08\udb48\udeea\u696b\ucf5a\u00e2\000", "", "",
        27, 41521, -915875475, 5743902095595470974L, -100000L, false, false, (char) 44248, (char) 61095,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc5400009122800L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.util.HashMap:{T=class java.util.Date}\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 5, 9, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6", "\u0f5c\u26b8\u35fe\u7a81\u78b9\ub6ff\u8b57\u6af4\u87ca\u2270\u8b81\ua921\u9f4b\uce93\ua0e4\u28a8\u4307\ud5cd\ua933\u6eb9\u2860\u2c1d\u2914", "\ud959\udff4",
        38, 74670, 181589259, -7305386464034375628L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551f42ec22f6cL), Double.longBitsToDouble(0x3fe012f8e6d96f7dL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.HashMap:{T=class java.lang.Character}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 3, 9, "\udb26\ude31\uda1c\udc42\u7e11\udb22\udf83\ud852\udf27\ud866\udd0d", "\ua79f\u025d\u35fe\u7a81", "\ud96d\udc4d\uda24\udcff\ud8be\udc3a\uda4a\udec7\ud846\udc5c",
        41, 6672, -1055749599, -8497698028522307004L, 49038L, true, true, (char) 40436, (char) 63863,
        Double.longBitsToDouble(0x3f946296b2f50900L), Double.longBitsToDouble(0x3fd849955659689eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=E}\0121=java.util.HashMap:{E=E}\012",
        Z.run(T, 2, 0, 16, 21, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6", "\u0f5c\u26b8", "\ud987\ude35\uda43\udd38\ud96d\udc4d\ud9c6\udcf0\ud961\udf8c\udaaf\udc22\ud96b\ude48\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2\ud984\ude0c\udade\ude94",
        -5, 50600, 1574627772, -6320752861403980101L, 85611L, true, true, (char) 58781, (char) 1560,
        Double.longBitsToDouble(0x3fe7ae79f27b03deL), Double.longBitsToDouble(0x3fe18441cf6dc290L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=null\012",
        Z.run(T, 2, 8, 13, 0, "\ud82c\udf08\udb48\udeea\u7d8d", "\u8ea7\ud1df\u6b92\u0f5cn\ua89b\u7a81", "\ud96d\udc4d\ud9c6\udcf0\ud961\udf8c\udaaf\udc22\ud925\ude45",
        1, -1000, 0, -8502796096475495868L, -100000L, false, true, (char) 15199, (char) 11250,
        Double.longBitsToDouble(0x3f94adda00000000L), Double.longBitsToDouble(0x3fd2fe600659689eL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 26, 5, 9, "\000", "\u3701\u423a\u8ea7\ucdb9\u6b92\u0f5c\uc2dd", "",
        21, 14422, 1654075006, 1057827025370218651L, -9320L, false, false, (char) 56746, (char) 35926,
        Double.longBitsToDouble(0x3fe5338b262e39b1L), Double.longBitsToDouble(0x3fd80c2ef080063eL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 20, 4, 9, "\udbab\udcc8\ud8dc\udf45\uda99\uded1\ud9ee\udd8d\udab0\udf9f\ud81f\udda6", "\u0f5c\u26b8\u35fe\u7a81\u78b9\ub6ff\u8b57\u508b\u8819\u9152\u6c47\ucbf1\ub48a\u6bdc\ua0af\u28a8\u5206\u52b1\ua933\u36de\u3822\u0bd7\ua53f", "\ud959\udff4",
        37, 67018, 181589259, 3254147287265884277L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551fcfec22f6cL), Double.longBitsToDouble(0x3fe012f8e5ef818fL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 9, "\ud82c\udf08\udb48\udeea\uda02\udc9d\ud9e9\ude57\udab0\udf9f\ud81f\uddb4", "\u0f5c\u26b8\u35fe\u6dbf\u16aa\ub6ff\u8b57\u2979\u87ca\u2270\u8b81\ua921\u9f4b\u85e1\ucadc\u28a8\u4307\ud5cd\ua933\u6eb9\u2860\u2c1d\u991f", "\uda98\udc52",
        38, 16341, -640494325, 3254324905638410357L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551f42ec22f6cL), Double.longBitsToDouble(0x3fe012f8e5ef818fL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 20, 16, 9, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6", "\u38c4\u9ead\u35cf\u7a81\u78b9\ub6ff\u8b57\uca06\u8759\u2270\u8b81\ua921\u9f4b\uce93\u28ce\u28a8\u4307\ud5cd\ua933\u6eb9\u2860\u2c1d\u59ac", "\ud959\udff4",
        38, 16341, 181589259, 3254147287265884277L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551f42ec22f6cL), Double.longBitsToDouble(0x3fe012f8e2f9818fL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 0, 2, 9, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6", "\u0f5c\u26b8\u35fe\u7a81\u78b9\ub6ff\u8b57\u2979\u55b7\000\000\ua921\u024b\uce93\u1caa\u8ded\u4307\ud5cd\ua933\u6eb9\u2860\u2c1d\u2914", "\ud959\udff4",
        38, 16341, 181589259, 3254147287265884277L, 18027L, true, false, (char) 20073, (char) 12798,
        Double.longBitsToDouble(0x3fd551f42ec22f6cL), Double.longBitsToDouble(0x3fe012f8e5ef818fL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 5, 20, "\udaf5\udd71\udb48\udeea\u3b8d\uda04\udf63\ud99c\ude99\ud81f\udda6\ud9ea\udec9\uda1f\udde5\ud8dd\udffe\ud891\ude48\uda70\udc15\udb93\uddcc\ud987\ude35\uda43\udd38\ud96d\udc4d\uda2b\ude16\ud936\udcd2\udaaf\udc22\ud85f\udf82\uc16d\udb35\udfae\udbf1\udc3c\udb2b\udf75\uda9d\udf69", "\u83ce\ub42e\u27ed\u2c1d\u7ea9\u424f\u33f2\uce47\u6e7e\u8eca\u1293\u2d3e\ub93c\ucb63\u7f8a\u0485\ud578\u7479", "\ud969\udc1f\udb3c\udfa0\udb6a\udf6f\ud8a0\ude3b\udb24\udf29\uf214\udba7\udfeb\ud9bd\udf34\ud904\udc65\udb21\ude9b\ud8a5\udfef\ud96d\uddca\udb0e\udf4e\ud9d6\udf9a\u203d",
        57, 6064, -2120423673, 3744047271576511025L, 16749L, true, true, (char) 6832, (char) 1748,
        Double.longBitsToDouble(0x3fd1dddcff209f34L), Double.longBitsToDouble(0x3fecae9d0907f9a7L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 7, 9, "\udbd4\ude02\udb48\udf3b\u3b8d\ud9ee\ude63\ud8b5\udc18\ud81f\udda6\udba1\ude81", "\u9fe7\u7468\u13a0\u78b9\ub6ff\ub957\u555c\uc95e\u2270\u4465", "\udbf1\udc3c\udb2b\udf75\uda9d\udfe9\udb82\udfad\u603d",
        44, 14841, -1378162359, -6320753613765293892L, -76120L, true, true, (char) 22360, (char) 14647,
        Double.longBitsToDouble(0x3fec04275019ae38L), Double.longBitsToDouble(0x3fd75699645bc9a0L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=E}\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 11, 10, "\000\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38~\uda6c\udcd5\ud961\udf8c\udaaf\udc22\ud925\ude45\udafc\ude10\udbd5\udc6e\uda0c\udf2a\udb5f\udd2f\udaa0\udcf2", "\ua933\u3705", "\000",
        -5, 64768, -1077171267, 1002054592466333340L, 26931L, false, true, (char) 1560, (char) 564,
        Double.longBitsToDouble(0x3fe3d81ef6308839L), Double.longBitsToDouble(0x3feb6e1485551f42L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 11, 10, "\ud82c\udf08\udb48\udeea\uda94\udf68\udbbb\ude1a\ud926\udd54\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36", "\u8b81\u97b4\u55b6\u82a3\u4a6e\ua1b3\u645a", "\ud882\udef9\ud93f\uddf5\uda74\uddcf\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\udb25\udc29\udb34\udeb0\ud861\udffb\uda38\udda4\udaf2\ude50\ud9a6\udf0e",
        9, 53633, -1030707608, 2252485276398472533L, -39574L, true, false, (char) 21816, (char) 56777,
        Double.longBitsToDouble(0x3febc2891c1cd33cL), Double.longBitsToDouble(0x3fd5f52f5e6177d6L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 6, 8, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\udbc1\udfab\ud8b1\udda6\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\ud8ab\udc27\ud8b8\udc95\uda0c\udf2a\udb5f\udd2f\udaa0\udcf2", "\ua933\u3705", "\uda25\udd41",
        56, 64812, -1077171267, 1002054592466333340L, 26826L, false, true, (char) 1560, (char) 564,
        Double.longBitsToDouble(0x3fe3d81ef6308839L), Double.longBitsToDouble(0x3feb6e1485551f42L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 22, 24, "\ud82c\udf08", "\u3701\u3043\u8ea7\u2277\u1f11\u13fb\u9f75\u3420\u0539\ucf0b\ub6ed\u8b57", "\udbfb\udf08\ud94b\udf1d\udb2b\udfdb\udb80\ude33\uda58\udf7b\udbad\udfb8\udaa0\udd53\udb1d\udc58",
        0, 55356, 1110849600, -596751429976667945L, -53788L, false, true, (char) 21753, (char) 15761,
        Double.longBitsToDouble(0x3fda56d3d2eb0cecL), Double.longBitsToDouble(0x3fe43ef6f48c114dL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=null\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 14, 2, 10, "\ud1a3\udbcf\udef9\udb3d\uddb9", "\u8ea7\u2277\u1f11\u43c9\u2561\u35fb\u54cd", "\ud96d\udc4d\ud8b8\udebf\ud961\udfe1\udbfb\udf08\ud94b\udf1d\udb2b\udfdb\udb80\ude33\uda58\udf7b\udbad\udfb8\udaa0\udd53\udb1d\udc58\ud974\ude49\udbe0\udf06\udb9d\udc26\ud895\udce8\ud864\udca5\udb74\ude0a",
        55, 69890, -1594436334, 2011772233188702985L, 21126L, true, true, (char) 14126, (char) 16588,
        Double.longBitsToDouble(0x3fd205d1d9ac2662L), Double.longBitsToDouble(0x3fc587bb1d2766bcL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 5, 0, 26, "\udae9\udc67\udab9\uddae\ud8f2\udfa9", "\u8ea7\u0dfb\u020c\u43c9\u8329\u28fd\uc2b3", "\ud811\udc68\udb7f\udeb9\ud996\udd4b",
        22, 7871, -1657618911, 5441375782415309164L, 16672L, false, true, (char) 43155, (char) 31825,
        Double.longBitsToDouble(0x3fcd255124853104L), Double.longBitsToDouble(0x3fe901a23a77e5f1L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.util.AbstractList<E>\0121=java.util.HashMap:{E=E, E=E}\012",
        Z.run(T, 2, 14, 2, 10, "\ud82c\udf08\ud870\uddfc\u178e", "\u44bc\u99fd\ubbc1\u43c9\u2561\u35fb\u54cd", "\ud96d\udc4d",
        9, 13205, 1740374252, -2224011930980315737L, -20330L, true, true, (char) 59831, (char) 18442,
        Double.longBitsToDouble(0x3fe955c58dacad5cL), Double.longBitsToDouble(0x3fb034c7cde211b0L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.Object\0121=java.lang.Class:java.lang.Object\012",
        Z.run(T, 2, 14, 14, 10, "\ud82c\udf08\udb4c\uddea\u3335", "\u8ea7\u2277\u1f11\u43c9\u2561\u35fb\u54cd", "\ud96d\udc4d",
        47, 56032, 1740374252, -2224012704084958557L, -20330L, true, true, (char) 33400, (char) 18442,
        Double.longBitsToDouble(0x3fe853058dacaf5bL), Double.longBitsToDouble(0x3fb034c7cde21160L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 20, 2, 10, "\udbe6\udd0d\ud91b\ude04\ud807\ude32", "\u8ea7\u2277\u61c1\u7a0a\ub8ed\u35fb\u54cd\u1461", "\uda44\ude42\ud83a\ude99\ud8b6\udf88\ud938\udfb8\udb2b\udfdb\udb80\ude33\uda58\udf7b\ud897\udcac\ub843\udb56\udc23\ud8b4\udeb1\udbe0\udf06\udb9d\udc26\ud8e1\udf3c\ud94f\udcb8\udaaf\udd32\ud805\ude5b\udbad\udc11\ud872\uddd3\udb17\udda5\ud987\udca8\udbf9\udf90\ud907\uddef\udb40\udcb1\uda84\udf0c",
        21, 53945, 479451904, 4857282331729218579L, -21294L, false, true, (char) 56188, (char) 41458,
        Double.longBitsToDouble(0x3fec75c14d624ed9L), Double.longBitsToDouble(0x3fe8b6c575bdb039L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 13, 22, 12, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63", "\ucdb9\u6b92\u0f5c\u26b8\u8327\u1911\u37bd\u06d8\uc93c\u5229\u87ca\ua51b\u8b81\ua921\ua9e0\u584c\u9225\u28a8\u5940\ud5cd\u66b6\u0934\u2860\u2c1d\u2914\u3779\ua3d6\u77a4\u6502\u3a8e\u6ce2\u2d3e", "\ud9e5\udca7",
        57, 4528, 524447597, 2819619870167866859L, -42992L, true, false, (char) 38721, (char) 48449,
        Double.longBitsToDouble(0x3fcc46478fb80440L), Double.longBitsToDouble(0x3fdb8519af63a21aL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 23, 10, "\ud96e\udc82\udbf5\udc9a\ud923\udd22\ud8ff\udd36\uda8f\udeac\ud972\uddc4\uda02\udda9\udaa3\udf5d\ud8dd\udfb4\ud986\udf40\ud0af\uda4d\udd11\ud8f1\ude0a\ud87f\udc6a\udb10\udefd\ud949\udcaa\u8426\udaaf\udc22\ud8f2\udc0b\udb65\udea0\ud997\udc9e\uda74\udd82\uda41\ude52\ud931\udfbd", "\ua47d\u6eb9", "\uda25\udd05\ud815\udcb9\udad6\udeac\u0fa5\ud8a6\udd0a\uda90\ude21",
        1, 85289, 847672773, -3513334525677653259L, -79873L, true, true, (char) 27715, (char) 16063,
        Double.longBitsToDouble(0x3fd3386d81658198L), Double.longBitsToDouble(0x3fe885502150c27aL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 11, 4, "\ud82c\udf08\udb48\udeea\udb6a\ude12\ud9d2\ude9a\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb10\udd42\ud98e\udefa", "\u60c6\uae0b\u1f34\u87ca\u67b9\u2e95\ua921\u9f4b\uce93\ua0e4\u28a8\u5940\ud5cd\ua933\u6eb9\u2860\u2c1d\u2914\u3779\ua3d6\u77a4\u502f\u2cca\u6ce2\u2d3e\u5d89\ucc06\u7f8a\u0485\u656b\u7441\u7bb5\ucbd4\u542f\ub2c9\uae25\u43ca\uc12a\u1bab\u307e\ucbb4\u8ae8\u2a4e\u470d\u6921\u2f6d\u7722\u0cd8\u6eca\u7818\u9dea\u9f54\u9cb4\u8f2a\u036d\u50cb\u673a\u7070\ub8b9\u09f8\ubf42\ubd06\u89c3\ub76b\u38fc\u5f4b", "\udbbf\udd0b\udbbd\ude80\ud9d2\udcf9\ud959\udde0\u7009\ud91c\udc77\ud898\udf6f\udaf3\ude33\ud9a6\uded4\ud86f\udf33\udb84\udfcf\ud93f\ude2e\uda9b\udf90\uab7f\uda32\udcc2\uda8c\uddd7\ud8df\udf30\uda6e\udf70\udadc\udc66\ud97e\udc4b\uda43\ude40\ud9d8\udec8\udbc3\ude69\u0214\uda7d\udc07\ud8af\udc58\udaaf\udf2c\u2dc4\uda82\udfa5\ud946\ude17\ud967\udde7\udae9\udf68\udbfd\udfd2\ud8e5\udd28\ud9cd\udd63\udb93\uddf1\uda46\udd7d\uda02\udc0f\ud87c\ude12\ud95b\uddc4\udabb\udfe3\u7a82\uda7b\udc7a\ud8b2\udf54\udbaf\udccd\uda0d\udcdd\ud9ab\udce7\udb48\udc7d\udb76\udd72\u4979\udb76\uddcf\ud8e0\udfc6\udb29\udcd9\ud865\udcd4\ubebc\ud8a9\udc76\ud920\uddfc\ud896\udd81\udb50\udc4b\udbae\uddce\uda31\udc39\ud824\ude40\ud9d8\udf0a\ud88f\ude82\uda80\uddfb\ud8c7\udf7b\uda2d\udc02\ud892\udf4f\ud9e7\ude27",
        10, 19739, 658977652, 8907960041914970924L, 17024L, true, true, (char) 42122, (char) 60770,
        Double.longBitsToDouble(0x3fe309f510f10d99L), Double.longBitsToDouble(0x3fdfeb4ed9a06500L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=class java.lang.Thread$State}\0121=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.lang.Enum<java.lang.Thread$State>\012",
        Z.run(T, 2, 2, 14, 10, "\ud82c\udea3u", "\u60bf\000\ucdb9\u6b92\ua710\000\u359c", "\uda43\udd38\u2e7e\000\ud961\udef1\u0aec\ud91d\ude2e\udb28\udedb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2\udb1d\udc58\ud82f\ude3c\000\udb9c\udfe6\udacb\udce4\uda73\udee8\u5ebb\ud815\udcb9\udb48\udc05\ud959\udff4\ud880\udc17\udad3\udebc\ud8f7\udf91\udb39\ude66\ud8b6\udc2f\uda47\udfab\ud99f\udf4a\uda2a\udd8e\ub27c\ud964\uddc8\u502e\ud869\ude17\udbb7\udc72\ud983\udf60\udb13\udcc7\udbc1\udc32\ud90f\udd8c\ud929\udc62\uda48\udc14\ud9a7\ude9f\udaa9\udc18\udae2\udc60\ud862\udf92\ud903\ude94\udb55\udc58\udb6a\udd28\ud8f3\udcb2\uda0f\ude7f\ud9ca\udda7\ud93d\udf97\ud937\udfe8\ud96e\udcc1\ud903\udfb0\ud840\ude92\uda58\uded0\ud9e7\ude13\ud876\udd53\udb59\udc99\ud9ce\udec9\ud82d\ude7c\udaa4\uddb1\ud88c\uded3\ud9a9\udce8\ud8ce\udc6c\ud849\udfc0",
        53, 40939, 291856786, 3242326784309979268L, 61559L, true, true, (char) 27339, (char) 21007,
        Double.longBitsToDouble(0x3fe65f335cd4293dL), Double.longBitsToDouble(0x3fe68c001cccdbebL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=class java.lang.Thread$State, T=class java.lang.Thread$State}\0121=java.util.HashMap:{E=class java.lang.Thread$State, T=class java.lang.Thread$State}\012",
        Z.run(T, 2, 0, 0, 0, "\000", "", "\ud883\udd98",
        25, -1000, -1677812253, 0L, -100000L, false, false, (char) 0, (char) 256,
        Double.longBitsToDouble(0x3fc361c523b00000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.util.AbstractList<E>\0121=sun.reflect.generics.reflectiveObjects.ParameterizedTypeImpl:java.util.AbstractList<E>\012",
        Z.run(T, 2, 14, 14, 10, "\ud82c\udf08\u665d", "\u27e4\uadd4\u4075\ud743\u600f\u7da9\u3674\u7a81", "\ud982\udf4d\uda6c\ude36\udb98\udfce\ud866\udf24\udaf5\udea7\udbdc\udc39\ud997\udc39\udbd9\udc74\ud9a7\udfda",
        -5, 24704, 1013754158, -5062874438210299064L, -88336L, false, false, (char) 14418, (char) 58226,
        Double.longBitsToDouble(0x3fc8a5415767949cL), Double.longBitsToDouble(0x3fe6d7b6bb7b509fL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 13, 13, 15, "\ud8e9\udd67\ud842\udcd0\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf26\udaaf\udc22\ud925\ude45\udb45\udf81\ud9b0\ude26\udbde\udfeb\udb5f\uddb6\udaa0\udcf2\udb1d\udc58\udb2c\ude6b\ud95f\udce1\udb93\udc73\udac0\udfe4\uda73\udee8\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a", "\u2d3e\u5d89\ucc06\u37c9\u042a\ud55f\u7479\u0bdf\uc89b\u0b1c\ub29e\uae25\u43ca\uc12a\u17bb\u120d\u77eb\ua98a\u691d\u378f\uad5e\u64ad\u59ff\u45d7\u57d5\u9880", "\ud960\udc6c\ud8af\udfde",
        24, 97391, 2022224330, -3605600760990719465L, 77276L, true, false, (char) 27023, (char) 22022,
        Double.longBitsToDouble(0x3fecb6ce52466cf8L), Double.longBitsToDouble(0x3fdd6fdcca1ef720L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 8, 5, 10, "\udab7\udd58\ud934\udcc9\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude7d\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud88e\udc18\uda43\udd38\ud96d\udc4d\udbf2\udd07\ud95f\udee4\udaaf\udc22\ud925\ude45\udb45\udf81\ud98c\udf34\uda7b\uded5\udb5f\uddb6\udaa0\udcf2\udb1d\udc58\udb2c\ude6b\ud95f\udce1\udb72\udcbc\udac0\udfe4\uda73\udee8\uda25\udd41\ud815\udcb9\udb48\udc05\ud859\udff4\ud8a6\udd0a", "\u2d3e\u5d89\ucbe4\ub83a\u553f\u519a\u7479\u0bdf\u828d\u0b5d\ub29e\u4507\ud3a2\uc12a\u17bb\u120d\uc564\ua6c5\ud302\u378f\uad5e\u64ad\u59ff\u45d7\u768a\u6cf3", "\ud960\udc6c\ud8af\udfde\uda26\udf5b\ud859\ude5f\udaeb\udeb7\udaea\ude4d\ud956\udefd\ud8b4\uddcf\udb91\udfce\ud872\udebc\udbd2\udc55\uda1f\udfa8\u4a02\udb3a\ude24\ud872\udd1e\ud999\udfdd\ud86b\udef8\uda35\udd0d\u4830\ud98a\udc0c\udbb4\udf81\ud92a\uddb5\ud914\udc3d\uda0d\udd87\udb41\udf5c\udbb0\udc78\udb80\udde9\ud9ab\uddc8\ud955\uddcb\ud93e\udfc0\udacb\ude78\u8434\ud99a\uddc0\uda2d\udfda\ud995\ude3e\udb15\ude70\udb5d\udd97\udbb4\udd94\udaaf\udf9f\udaea\uded9\uda7e\udd40\udbd1\udeb1\ud8e2\udc24\udba3\udf37",
        -1, 31040, -917777851, -5074450038175896067L, -86257L, false, true, (char) 13958, (char) 46553,
        Double.longBitsToDouble(0x3feca85ae44ee34dL), Double.longBitsToDouble(0x3fe39fdc46f5a92aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.util.HashMap:{T=class java.lang.Integer}\0121=java.util.HashMap:{T=class java.lang.Integer}\012",
        Z.run(T, 2, 4, 2, 3, "\ud8e9\udd67\ud842\udcd0\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\udab1\udc27\udb03\udc36\ud966\udd4d\ud84d\udc06\ud9a4\ude24\ud99e\udf54\ud96d\udc4d\uda6c\ude36\ud961\udf26\ud9a0\udf46\ud925\ude45\udaec\udc90\ud9b0\uddc7\udbde\udfeb\udb5f\uddb6\udaa0\udcf2\udb1d\udc58\udb2c\ude6b\ud80b\uddbd\udb93\udc35\udac0\udfe4\uda73\udee8\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a", "\u7815\uaf6b\ucc06\u37c9\u042a\u6bbc\u7479\u0bdf\uc89b\u0b1c\ub2f8\uae25\u4687\u0536\u1816\u120d\u77eb\ua98a\u83c7\u378f\u8788\u061d\ub334\ud48c\u57d5\u32e2", "\ud960\udc6c\ud8af\udfde\uda26\udf5b\ud98b\udefe",
        30, 16654, 1373814927, 4963614988790314108L, 29772L, true, true, (char) 24372, (char) 24382,
        Double.longBitsToDouble(0x3fdd6fdcca1ef720L), Double.longBitsToDouble(0x3f9f478cd659b720L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 13, 13, 10, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\uda04\udf3d\uda30\udfbe\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\u4b98\u6ec6", "\uda25\udd41\ud815\udcb9\uef10\ud939\uddc5\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd",
        44, 75317, -814694133, 278716252782396027L, 2547L, true, true, (char) 17676, (char) 64223,
        Double.longBitsToDouble(0x3fc658041c42a810L), Double.longBitsToDouble(0x3fd50c27a14e1f2eL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 11, 10, "\ud82c\udf08", "\u3701\u423a\u8ea7\ucdb9\u6b92\u0f5c\u26b8\ud694\u0235\u78b9\ub6ff\u8b57", "\udbd2\udd29\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2\udb1d\udc58",
        13, 88680, 1110849600, -5919161768033637356L, -34767L, false, false, (char) 63184, (char) 49955,
        Double.longBitsToDouble(0x3fe94121f5413de4L), Double.longBitsToDouble(0x3fa4571c41412f30L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 8, 5, 0, "", "", "\udab0\udf9f",
        19, 45187, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 0, 0, 25, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\ud80a\udea5\ud98e\udeeb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbe4\uded1\udb7c\udc6b\udaa0\udcf2", "\ub59a\u8dc0\u6a35\u2c1d\u2914\u467b", "\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd\udbed\ude51\udbeb\udf12\ud9a6\udef0\ud942\udf2f\udbe0\udf6b\ud874\ude91\uda4c\udd44\ud931\udfa3\ud916\uddc0\ud969\udc1f\udb3c\udfa0\udb6a\udf6f\ud8a0\ude3b\uda25\ude4a",
        13, 57763, -415253496, 5065797591439215046L, 91869L, true, true, (char) 3474, (char) 62633,
        Double.longBitsToDouble(0x3fe7d3b65c981a12L), Double.longBitsToDouble(0x3fed229eafbcfc4cL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Class:java.lang.String\0121=java.lang.Class:java.lang.String\012",
        Z.run(T, 2, 13, 13, 15, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\ud8de\udde3\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda3a\udd9d\ud98f\udecf\uda6c\ude36\ud925\udc71\udaaf\udc22\udbb4\ude10\udb54\ude1d\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\u7720\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        34, 43385, 1883814005, -666295456432729387L, -14667L, true, true, (char) 55323, (char) 5882,
        Double.longBitsToDouble(0x3fe884c7f150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd487d84L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.util.HashMap:{}\0121=java.util.HashMap:{}\012",
        Z.run(T, 2, 16, 0, 19, "\ud8ee\udfaa", "\uc9ed\u566a\u34b2\uade9\u1a06\u9592\u36fc\uaf78\u7a95\u150b\u0d17\u8319", "\udb19\ude2f\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\uda6e\uddba\udbaf\ude2b\udb1d\udc58",
        29, 70115, 1015167049, 2672579669463149588L, 96911L, true, false, (char) 30354, (char) 49955,
        Double.longBitsToDouble(0x3fea5a1745cf67bbL), Double.longBitsToDouble(0x3fdb9fdab1f44bb6L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.util.HashMap:{E=E, E=E}\0121=java.util.HashMap:{E=E, E=E}\012",
        Z.run(T, 2, 16, 0, 19, "\ud82c\udf08\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\udb4b\udd7a\ud8f4\ude16\ud84f\udd05", "\u150b", "\udab1\udd3b\ud961\udf72\udaaf\udc22\ud925\ude45\uda11\udfae\ud996\udff9\udbd9\udc74\ud813\udd0e\udbaf\ude2b\udb1d\udc58\udade\ude94\ud91f\uddb9\udb70\udfe7\uda1a\udf3c\uda73\udee8\udbba\udd6c\ud908\udc3c\udb3d\udccd\ud959\udff4\ud965\udf49",
        23, 45895, 1736519155, 351063921518617206L, -4655L, false, false, (char) 33286, (char) 59912,
        Double.longBitsToDouble(0x3fd6846452eeaa20L), Double.longBitsToDouble(0x3fbea847fb05bea8L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 16, 2, 22, "\udb74\udd3d\udb56\uddea", "\u423a\u8d77\ucdb9", "\ud9dd\udfe2\ud98e\udefb\ud8f1\udd03\ud987\ude35\ud835\udf72\ud96d\udc08\uda6c\ude36\udbac\udf51\ud85b\udd51\ud94c\udcce\udb2b\udfdb\uaf6b\udbd9\udc74\udbe0\ude35\ud979\udecb\ud8d4\udc52\u037f",
        57, 27862, -1378162244, -6320753614113775941L, -87211L, true, true, (char) 35345, (char) 61573,
        Double.longBitsToDouble(0x3fdcf67bb0335c70L), Double.longBitsToDouble(0x3fed5c32f5d07048L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 24, 7, "\ud82c\udf58\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud85d\udc9e\udbab\udc2b\ud814\udc43\uda01\udda3\udaef\ude7d\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\udbd9\udda8\uda6c\ude36\ud961\udf8c\udaaf\udc22\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2", "\ua933\u6eb9", "\uda25\udd41\ud815\udcb9\udb48\udc05\ud959\udff4\ud8a6\udd0a\udbc1\uddb9",
        34, 57497, 1883814005, -3513205938651778315L, -14667L, true, true, (char) 64223, (char) 16594,
        Double.longBitsToDouble(0x3fe885502150c27aL), Double.longBitsToDouble(0x3fc4e1f2fd4b5fbcL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 19, 6, "\ud9a4\udf23\udb48\udeea\u7d8d\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca1\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ufc9b\udbd2\udd29\ud925\ude45\udb2b\udfdb\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2\udb1d\udc58\udade\ude94\ud84b\uddaf\udb9d\udc26\udacb\udce4\uda73\udee8\uda25\udd41\ud815\udcb9,\ud959\udff4\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd\udbed\ude51\udbac\udd33\ud882\udd0c\uda84\udefa\uda46\udcfb\uda3e\udfc4\ueda0\u9858\ud846\udcd7", "\u1ae6\u2de1\u6996\u9a15\u61bf\ua2e3\ucaae", "\ud803\udc33\udaa3\udd3d\ud85a\udcc4\uaffb",
        3, 16259, 287075367, 8708842167255760508L, 6489L, true, true, (char) 61606, (char) 19554,
        Double.longBitsToDouble(0x3fc4a332f2ae4804L), Double.longBitsToDouble(0x3fc93375be7312f8L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 6, 19, "\ud8a2\udc23\udb48\udeea\u7e06\ud9ee\ude63\udab0\udf9f\ud81f\udda6\udbae\udc2b\uda1f\ude65\ud8dd\udffe\udb03\udca7\ud98e\udefb\ud84d\udc11\ud987\ude35\uda43\udd38\ud96d\udc4d\uda6c\ude36\ufc9b\udbd2\udd29\ud925\ude45\udb6a\uddda\ud997\udc9e\udbd9\udc74\udb5f\uddb6\udaa0\udcf2\udb1d\udc58\udade\ude94\ud84b\uddaf\udb9d\udc26\udacb\udce4\uda73\udee8\uda25\udd41\ud815\udcb9,\ud959\udff4\ud8a6\udd0a\udbc1\uddb9\ud8d2\udcfd\udbed\ude51\udbac\udd33\ud882\udd0c\uda84\udefa\uda46\udcfb\uda3e\udfc4\ud822\udc34\u9858\ud846\udcd7", "\u1ae6\u2de1\u6996\u9a15\u61bf\u0b48\ucadf", "\ud803\udc33\udaa3\udd3d\ud85a\udcc4\uaffb",
        3, 16259, 287075367, 8708842167255760508L, 6489L, true, true, (char) 47782, (char) 19732,
        Double.longBitsToDouble(0x3fc4a33dd2ae4804L), Double.longBitsToDouble(0x3fc93375be7312f8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.Class,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.ParameterizedType,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.Type,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.ParameterizedType|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.Type,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.GenericArrayType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.ParameterizedType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.Type,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.TypeVariable,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.WildcardType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.Type|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|determineTypeArguments|java.lang.Class,java.lang.reflect.ParameterizedType|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getArrayComponentType|java.lang.reflect.Type|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getClosestParentType|java.lang.Class,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getImplicitBounds|java.lang.reflect.TypeVariable|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.Class,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.ParameterizedType,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.Type,java.lang.Class,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.ParameterizedType|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|getTypeArguments|java.lang.reflect.Type,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.Class|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.GenericArrayType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.ParameterizedType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.Type,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.TypeVariable,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.WildcardType,java.util.Map|static",
    "M|org.apache.commons.lang3.reflect.TypeUtils|isAssignable|java.lang.reflect.Type,java.lang.reflect.Type|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
