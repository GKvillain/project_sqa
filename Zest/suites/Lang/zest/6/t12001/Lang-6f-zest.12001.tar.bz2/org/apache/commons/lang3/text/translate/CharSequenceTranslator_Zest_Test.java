package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class CharSequenceTranslator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:28\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\udbd9\ude81\udbca\udf3b", "\u3b9c\u764c\ud058\u6570\u06c7\u648c\u60a0", "\udb6c\ude7e\ud95a\udfb9\uda74\udd80",
        40, 64899, -27545931, 1670992676991464361L, 58802L, true, false, (char) 16433, (char) 20249,
        Double.longBitsToDouble(0x3fd111478030f872L), Double.longBitsToDouble(0x3fdc371b9ab3fa26L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:28\0121=java.lang.String:28\012",
        Z.run(T, 2, 3, 3, 2, "\udbd9\ude81\udbca\udf3b", "\u3b9c\u764c\ud058\u6570\u2aed\u9167\u096c", "\udb6c\ude7e\ud95a\udfb9\uda74\udd80",
        40, 64899, -27545931, 1670992680455238569L, -34952L, false, false, (char) 50224, (char) 20252,
        Double.longBitsToDouble(0x3fe088a3c0cabc2cL), Double.longBitsToDouble(0x3fdc3e816ab3fa26L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:39\0121=void |a1=java.io.StringWriter:\udbd9\ude81\ud82c\ude8d |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 2, "\udbd9\ude81\ud82c\ude8d", "\u3b9c\uaf74\u3612\u652b\u06c7\u648c\u60a0", "\udae6\ude7b\ud9cc\udc98\ud996\udecf\uda78\udecf\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\udb5c\uddf8\ud833\udd20\udb7f\udefe\u4c1b\ud856\udd18\udb40\udc60\ud859\udc63\udabd\udecb\udb6f\udedc\uda78\ude37\uda93\udd31\ud80d\udc9e\ud847\udfb7\uda96\udf71\uda17\udee7\ud8b6\udc14\udaf6\udfc1\ud84b\udf74\ud994\udfe0\ud887\udd01\uda55\ude13\udb69\udc4c\ud9b2\udf8d\uda74\udefb\ud975\udd40",
        57, 84726, 1530543078, 3829668904439201868L, 9872L, true, true, (char) 3510, (char) 64714,
        Double.longBitsToDouble(0x3fd6d10d79eeef98L), Double.longBitsToDouble(0x3feeb39f72aed3ecL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.String:28\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 2, "\udbd9\ude81\udbca\udf3b", "\u3b9c\u764c\ud058\u6570\u06c7\u648c\u60a0", "\udb6c\ude7e\ud95a\udfb9\uda74\udd80",
        40, 64899, -27545931, 1670992676991464361L, 58802L, true, false, (char) 16433, (char) 20249,
        Double.longBitsToDouble(0x3fd111478030f872L), Double.longBitsToDouble(0x3fdc371b9ab3fa26L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.String:2A\0121=java.lang.String:\udbd9\ude81\udbbe\udca1\u3d4b\udbdb\udded\udbd0\ude78 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 6, 5, "\udbd9\ude81\udbbe\udca1\u3d4b\udbdb\udded\udbd0\ude78", "\u6570\u06c7\u648c\u63bb\u056e\ubeb6\u90d1\u22a0\u23f5", "\ud994\udea9\udb5f\udff2\udb25\udc7d\udb7a\uddb4\udba7\udd96\udb97\ude7f\uda59\udf7a\udb40\udc60\ud859\udc63",
        42, 39947, 357440857, 8766058775314334840L, 41127L, false, false, (char) 15712, (char) 38483,
        Double.longBitsToDouble(0x3fef314746ef6b4fL), Double.longBitsToDouble(0x3fe772a2b6a9a6bcL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:2A\012",
        Z.run(T, 1, 3, 5, 1, "\udbef\udfa7", "\uaa79\u3b9c\u764c", "\udb61\ude25\u8666\ud888\ude00\udb53\udfb0\udb00\ude0f\udb6c\uddc4\uda42\udc4d\udbe2\uded7\ud960\udd68\uda2c\ude2f\ud8bb\ude9c\ud969\uddff\ud9fa\udfba\ud8be\udfd9\udb65\udcf7\u4c1b\udbfe\udc3e\uda14\ude03\uda79\udd36",
        42, 39947, 1512185177, -1896188707828472352L, -61733L, false, true, (char) 56896, (char) 35380,
        Double.longBitsToDouble(0x3feb029e15b84732L), Double.longBitsToDouble(0x3fd82b790c94dae6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 4, 2, "\udbe9\udf09\udbca\udf3b", "\u3b9c\u764c\ud058\u6570\u46dd\u8ced\u60e3", "\udb6c\ude7e\ud971\udef7\uda74\udd80",
        40, 64899, -27545931, 2823914181598289384L, -11551L, false, false, (char) 40795, (char) 20249,
        Double.longBitsToDouble(0x3fcbfb4f0691fec4L), Double.longBitsToDouble(0x3fdc371b9ab3fa26L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:28\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 5, 3, "\udaf5\udca3\udbca\ude41", "\u3b9c\u764c\ud058\u6570\u06c7\u648c\u60a0", "\udb6c\ude7e\ud95a\udfb9\uda74\udd80",
        40, 64899, -27545931, -2071014029373279300L, 58802L, true, false, (char) 16433, (char) 20249,
        Double.longBitsToDouble(0x3fd111478030f872L), Double.longBitsToDouble(0x3fdc371b9ab3fa26L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.String:23\0121=void |a1=java.io.StringWriter:\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\ud800\udf2b\ud8e1\udf05\ud888\ude00\uda6d\udedd\udb0d\udf14\ud913\udf4e\ud95a\udfb9\uda74\udd80\uda78\udecf\uda2c\ude2f |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 2, "\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\ud800\udf2b\ud8e1\udf05\ud888\ude00\uda6d\udedd\udb0d\udf14\ud913\udf4e\ud95a\udfb9\uda74\udd80\uda78\udecf\uda2c\ude2f", "\u5b7c\u1c1a\u5075\ub698\u1fff\ubf6e\u904c\u3ee1\u064c", "\ud8fc\ude27\ud82c\udcca\ud86a\ude81\ud8ef\udf5e\ud90c\udc91\ud825\ude63\ud975\ude15\uda3c\ude21",
        35, 55014, -1591459953, -1781380767543404956L, -41359L, true, false, (char) 63126, (char) 21783,
        Double.longBitsToDouble(0x3fe0322f86e30848L), Double.longBitsToDouble(0x3fe68011052969a2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\udba1\ude85\udbca\udf3b |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 2, 2, "\udba1\ude85\udbca\udf3b", "\u3b9c\u4eba\ub718\u5a22\u06c7\u648c\ub18e", "\ud9d5\ude30\u7b75\uda74\udd80\udabd\udd10\uda2c\uddc1",
        17, 5206, -2040859724, 6191163355517316178L, -91354L, false, true, (char) 55688, (char) 30634,
        Double.longBitsToDouble(0x3fbdfd311b2a1ec0L), Double.longBitsToDouble(0x3feda6306b441559L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:2A\0121=void |a1=java.io.StringWriter:\udbd9\ude81 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 0, "\udbd9\ude81", "\000\u3b9c\u7593", "\ud884\ude82\ud8e1\udf16\ud888\ude00\udbe9\udd3a\uda88\udf56\000\000\ud9f2\ude39\000\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\000E\u6c00\000\ud856\udc86\udb40\udc60\ud827\udf63",
        42, 99536, 606739801, 6374633643287964106L, -85254L, true, false, (char) 9531, (char) 23020,
        Double.longBitsToDouble(0x3fc028fde6ddd154L), Double.longBitsToDouble(0x3fe666fcb427da43L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 5, "\udbbb\udc81\udbca\udf3b\udb33\ude7c\ud849\udffb\ud924\udff9\udaef\udf8b\udb45\udf32\ud9bb\udcd9\ud990\udc02\ud924\udd64\ud8fd\udd86", "\u791d\u914d", "\ud879\udf55\uda73\udcb5\udb06\udfe9\udaf2\udf24\ud8be\udf55\udb65\udcf7\u4c1b\ud856\udd18\ud936\udcbb\ud9df\udd0f\ud8ae\udf06",
        42, 64545, -2019386964, -1158731188283346795L, 13422L, false, false, (char) 55085, (char) 54337,
        Double.longBitsToDouble(0x3feeea52d88660bcL), Double.longBitsToDouble(0x3fd3703deddef8f6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:\udbed\udf6c\ud919\udecf |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 1, 0, 3, "\udbed\udf6c\ud919\udecf", "\u949c", "\ud8e7\udea1\ud8b6\udeb9\ud877\udeae",
        17, 518, -165485137, 916396231782256215L, 66048L, false, true, (char) 13581, (char) 38947,
        Double.longBitsToDouble(0x3feaf8b9852e6fb5L), Double.longBitsToDouble(0x3fb4957ad26c19f0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 2, "\udbd9\ude81\udbca\udf3b", "\u3b9c\u764c\u6ed4\u5640\u538e", "\ud955\uded1\uda88\udf6a\ud9f2\udf22",
        43, 54460, -1906476670, -7085102317797921099L, 93449L, true, false, (char) 49725, (char) 23947,
        Double.longBitsToDouble(0x3fd921e9fe59efd8L), Double.longBitsToDouble(0x3fd111478030f872L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:2A\0121=void |a1=java.io.StringWriter:\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\ud8c1\udfb9\ud8e1\udf16\ud888\ude00 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 2, "\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\ud8c1\udfb9\ud8e1\udf16\ud888\ude00", "\u90d1\u22a0\u23f5", "\ud8bb\ude9c\udb60\udc5a\udb25\udc7d\ud8be\udf55\udb65\udcf7\u4c1b\ud856\udd18\udb40\udc60\ud859\udc63",
        42, 39947, -1895948967, -3435660875586994409L, -2303L, true, false, (char) 36807, (char) 33274,
        Double.longBitsToDouble(0x3fef9c551aa54b5aL), Double.longBitsToDouble(0x3fb3158b97436308L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.String:\udbd9\ude81\udbca\udf3b |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 6, 4, "\udbd9\ude81\udbca\udf3b", "\u5e79\u764c\ud058\uc81b\ua522\u0518\u49fc", "\udb6c\ude7e\ud95a\udfb9\uda74\udd80\udae3\udfa4\ud84d\udf40\udb89\uddc4\ud9c5\udfd0",
        27, 19549, -2093061038, -8385743957028757152L, 15985L, false, false, (char) 4988, (char) 6765,
        Double.longBitsToDouble(0x3fc0a13eed6d3610L), Double.longBitsToDouble(0x3fc49ef21934d7b4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:D\0121=void |a1=java.io.StringWriter:\udbd9\ude81\u181a |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 2, "\udbd9\ude81\u181a", "\u7e47\u764c\ud058\u6570\u06c7\uce8b", "\udbca\udf6b",
        13, 64559, 1193567328, -5810354343432810572L, -62693L, true, true, (char) 34522, (char) 22833,
        Double.longBitsToDouble(0x3feec2b5f6d5b2a3L), Double.longBitsToDouble(0x3fc04f9f47ba57e8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:13 |a2=java.io.StringWriter:\ud9ab\udf2b\udbca\udf3b\u3d4b\ud996\ude13\udbe2\udf42\uda88\udefd\ud8c6\ude31 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 0, 4, 4, "\ud9ab\udf2b\udbca\udf3b\u3d4b\ud996\ude13\udbe2\udf42\uda88\udefd\ud8c6\ude31", "\u9968\u9c39\ub7cc\u6f55\u90d1\u22a0\u23f5\u5763\ud4f0\ub4c2\u0a79\u5b7c\u6b82", "\udb9e\udc0f\udb40\udc60",
        0, 13469, 823632323, 6137812455384024884L, -56534L, true, false, (char) 40983, (char) 32539,
        Double.longBitsToDouble(0x3fd18ad17edab84cL), Double.longBitsToDouble(0x3fe4e4c089b13b59L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:\udbd9\ude81\udbca\udf3b |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\udbd9\ude81\udbca\udf3b |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 6, 2, 2, "\udbd9\ude81\udbca\udf3b", "\u3b9c\uc463\u9fdf\ucd19\ud68c\u0b67\u60a0", "\udb6c\ude7e\uda53\udcf6\ud902\udeae",
        40, 36387, -901851247, 4343832806377071376L, -29449L, true, false, (char) 16433, (char) 20249,
        Double.longBitsToDouble(0x3fd111478030f872L), Double.longBitsToDouble(0x3fdc371b9ab3fa26L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:28\0121=void |a1=java.io.StringWriter:\udb38\udee8 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 5, "\udb38\udee8", "\ub871\u3b9c", "\u4139\u7052",
        40, 89826, -1797505746, 5304790746899395007L, -55140L, false, true, (char) 40536, (char) 19553,
        Double.longBitsToDouble(0x3fe7eff2dba91730L), Double.longBitsToDouble(0x3fe22c32d61e3732L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 6, 1, 2, "\udbd9\ude81\udbba\udf73", "\u79e7\u25b7\u15a5\u33b4\u06c7\u648c\u60a0", "\udb6c\ude7e\ud95a\udfb9\uda74\udd80",
        40, 64899, -27545931, 1670992677679330217L, 58802L, true, false, (char) 16433, (char) 38510,
        Double.longBitsToDouble(0x3fdb9b131030f872L), Double.longBitsToDouble(0x3fdc371b9ab3fa26L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 4, 5, 4, "\udbd9\ude81", "\uaa79", "\ud8c4\udda9",
        -5, -1000, -2063694250, -7765348864930071250L, -54497L, false, false, (char) 0, (char) 31106,
        Double.longBitsToDouble(0x3fefdc72eeb59dacL), Double.longBitsToDouble(0x3fe7eff2d8a91730L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:39\0121=void |a1=java.io.StringWriter:\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 2, "\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded", "\uaab9\u6570", "\udba2\udf2d\uda6d\udf7c\uda88\udf6a\udb78\udfe4\uda06\udcf0\uda74\udd80\uf5d1\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\udb25\udc7d\ud8be\udf55",
        57, 4589, -135519854, 1475024726537837073L, 11204L, true, true, (char) 47293, (char) 37581,
        Double.longBitsToDouble(0x3fe4d95745dd8db2L), Double.longBitsToDouble(0x3fe31994e29ba31eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.String:\udbd9\ude81\udbca\udf3b\u3d4b |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.String:\udbd9\ude81\udbca\udf3b\u3d4b |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 6, 1, 4, "\udbd9\ude81\udbca\udf3b\u3d4b", "\u764c\ud058\u6570\u06c7\u648c\u60a0\u5e32\ube54\u90d1\u22a0\u23f5\u9ad3", "\udb44\ude77\udb25\udc7d\ud8be\udf55\udb65\udcf7\u4c1b\ud856\udd18",
        6, 24785, 1907970072, -210646897773240999L, -73022L, false, false, (char) 33653, (char) 52004,
        Double.longBitsToDouble(0x3fcff8995305aaecL), Double.longBitsToDouble(0x3fd1e22c0c34fb06L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:38\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 2, "\000\000", "", "",
        56, 21972, 0, 0L, 4684L, true, true, (char) 23310, (char) 93,
        Double.longBitsToDouble(0x3fc053d79fee3974L), Double.longBitsToDouble(0x3fe5aced66fdfe5bL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 2, "\udbd9\udf5e\udbca\udf3b", "\u3b9c\uc1d9\ua48c", "\ud9fa\udcce\udb9c\udfce\uda6d\udedd\uda88\udf6a\udb6c\ude7e\ud95a\udfb9\ud892\uded9\uda67\udc23\ud874\ude33\ud8bb\ude9c\udb60\udc5a\udb25\udc7d\ud8be\udf55\ud807\udd47\u4c1b",
        -1, 29956, 2084160785, 1933853039203412900L, -40377L, true, false, (char) 44267, (char) 34557,
        Double.longBitsToDouble(0x3fe3b4652f8f4a00L), Double.longBitsToDouble(0x3fc7009a5cb41720L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |a1=java.io.StringWriter:\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\ud9c8\ude9c\ud8ea\udf93\ud888\ude00\uda5d\uded5\uda88\udf6a\udb40\udd14\ud95a\udfb9\uda74\udd80\ud868\udea6\uda4e\uded9 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\ud9c8\ude9c\ud8ea\udf93\ud888\ude00\uda5d\uded5\uda88\udf6a\udb40\udd14\ud95a\udfb9\uda74\udd80\ud868\udea6\uda4e\uded9 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 2, 2, 5, "\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\ud9c8\ude9c\ud8ea\udf93\ud888\ude00\uda5d\uded5\uda88\udf6a\udb40\udd14\ud95a\udfb9\uda74\udd80\ud868\udea6\uda4e\uded9", "\u5b7c\u1c1a\u5075\ub698\u1fff\ubf6e\u904c\u3ee1\u064c", "\udb02\udf31\udb8f\udf89\udbbb\uddd6\ud8fd\udeb7",
        54, 58888, 1649776579, -2377965231806980235L, 792L, false, true, (char) 13867, (char) 16971,
        Double.longBitsToDouble(0x3fd205ab888154e2L), Double.longBitsToDouble(0x3fef32985cbc5a33L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.String:18\0121=void |a1=java.io.StringWriter:\ua329 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 2, "\ua329", "\uaa6b\u3b9c\u764c\ud058", "\ud8e1\udf16\ud888\ude00\uda6d\udedd\udbd3\udcd0\udaf7\udf27\ud95a\udfb9\ud82a\udd7b\uda78\udecf\ud852\ude16\ueaa8\udaaa\udc4a\uda38\udeae\ud80b\udfda",
        24, 54434, -135467187, 6040803932644741578L, 97251L, true, true, (char) 24693, (char) 56828,
        Double.longBitsToDouble(0x3fe152974a84025aL), Double.longBitsToDouble(0x3fd7a727db6e7848L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:32\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 4, "\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbe5\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\ud8c1\udfb9\ud8e1\udf16\ud888\ude00\uda6d\udedd\ud8a5\ude59\ud8a0\udd78\uda1c\udfdb\uda74\uddb3\uda78\udecf\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\udb25\udc7d", "\ub698\u20b6\u6fbd\u904c\u3ee1\u7e4b\ud257", "\uda57\udc7d\udb25\udc8c\ud859\udc14\ud806\udf92\udacf\udf68\ud99a\udf82\uda28\uddec\udbfb\uddf6\udaff\udd91\udabe\udd3e\uda47\udd1e\ud523\u07fe\uda71\udd85\ud986\udf34\ud8cc\ude12\ud8c4\udf9a\uda85\udfcc\ud981\udef1\u2d1c\udab1\udf7b\ud887\ude68\ud963\udcf9\ud8c4\udf80\uda36\udebd\ud95d\ude33\uda9f\udc1f\uda0e\udfce\ud8e1\uddb3\ud932\udc04\udb81\udf0a\ud833\udd0a\uda07\udcc9\udaf1\udd51\ud909\ude24\udbb7\udd6f\ud904\udffc\ud993\ude13\ud83b\udfab",
        50, 44729, 269046302, 4321212273372144549L, -92832L, false, false, (char) 16360, (char) 30035,
        Double.longBitsToDouble(0x3fede4e04eb51032L), Double.longBitsToDouble(0x3fd69594e1e816ceL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:1C\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 3, 0, 0, "", "\000", "\u00b9",
        28, 56960, 62775, 61440L, -100000L, false, false, (char) 0, (char) 2620,
        Double.longBitsToDouble(0x3fd009ebcff71cbaL), Double.longBitsToDouble(0x3fe5aced66fdfe5bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:A\0121=null |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 6, 0, "\udbd9\ude81\udbca\udf3b\u3d4b\ud8d1\udfa7", "\u5525\u6570\u06c7", "\uda6d\udf54\uda88\udf6a\udb6c\ude7e\ud95a\udfb9\uda74\udd80\uda78\udecf\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\udb25\udc7d\ud8be\udf55\udb65\udcf7\u4c1b\ud856\udd18\udae2\udc51\ud859\udc63\udabd\udecb\udb90\udd96\ud97e\udc73\ud884\udc44\uda32\ude04\ud9dc\ude57\udb34\udf3a\udbac\udde0\ud9a3\udfe2\udaa4\udd9d\uda12\udcca\udbca\udd41\ud981\udc8c\udaad\ude25\uda5a\udd5d\udb73\udfe1\ud909\udc00\ud96b\udedd\udb3a\udd3d\ud85b\udff5\ud919\udcca\ud82f\udf6d\ud96a\udcb7\udb33\ude70\ud8aa\uded4\ud857\udee5\ud87e\udf73\udbc1\udd54\ud913\ude26\udac5\udfdf\ud9bd\udd63\ud875\udebc\udb3b\udca3\uda09\udd36\ud9c5\udd94\ud9b7\udd32\udbc6\udf57\ud9f2\udff0\uda08\ude9a\udb32\udcb3\ud9fc\ude34\udaa3\udd35\udabe\ude64\ud9ab\udc72\ud849\udea7\ud9ea\udf8f\udbae\udfaa",
        10, 47030, 719274192, -9020980014061050113L, -9794L, false, false, (char) 7932, (char) 21930,
        Double.longBitsToDouble(0x3fd9ff7ee5c66e7cL), Double.longBitsToDouble(0x3fd933b59da53f58L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |a1=java.io.StringWriter:\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\uc251\ud981\udd82\u06f4\uda6d\udece\uda88\udf6a\udb6c\ude7e\ud95a\udfb9\uda74\udd80\ud965\udee4\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\ud9fe\udca8\ud8c2\udfd5\ud817\udea4\u4c8c\ud937\udd18\udb40\udc60\udad3\ude11\ud8e3\udf61\udb90\udd96\udb5b\udf82\uda3a\udf8c\uda21\udd2c\ud85a\uddd6\udb04\udd08 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.String:\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\uc251\ud981\udd82\u06f4\uda6d\udece\uda88\udf6a\udb6c\ude7e\ud95a\udfb9\uda74\udd80\ud965\udee4\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\ud9fe\udca8\ud8c2\udfd5\ud817\udea4\u4c8c\ud937\udd18\udb40\udc60\udad3\ude11\ud8e3\udf61\udb90\udd96\udb5b\udf82\uda3a\udf8c\uda21\udd2c\ud85a\uddd6\udb04\udd08 |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 2, 6, 2, "\udbd9\ude81\udbca\udf3b\u3d4b\udbdb\udded\udbd0\ude78\udafb\udd76\ud8e1\udd98\uda92\udcb9\uc251\ud981\udd82\u06f4\uda6d\udece\uda88\udf6a\udb6c\ude7e\ud95a\udfb9\uda74\udd80\ud965\udee4\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\ud9fe\udca8\ud8c2\udfd5\ud817\udea4\u4c8c\ud937\udd18\udb40\udc60\udad3\ude11\ud8e3\udf61\udb90\udd96\udb5b\udf82\uda3a\udf8c\uda21\udd2c\ud85a\uddd6\udb04\udd08", "\u4e7d\ua811\u3137\ubb2d\ua359\u8a74", "\udbd7\uddfc\uda2a\udef3\udb39\ude19\ud957\udf4c\ud91b\ude7e\uda6b\ude6f\ud8c4\uddb1\udb2a\udfd6\ud83f\udf4b\ud9ba\udf5c\ud923\udd41\ud92d\udeb3\ud9ed\ude19\ud819\udd1e\ud871\udd8f\ud83d\udf92\udbdc\udca0\ud811\udcef",
        33, 15763, -1198292759, -3336393610809882824L, -38856L, false, true, (char) 34462, (char) 14234,
        Double.longBitsToDouble(0x3fe3fccc45467c6cL), Double.longBitsToDouble(0x3fe8376c71c056e4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud997\udd04\udb92\udcaa\uda55\udd9d\ud9c1\udc1f\ud85a\udd8e\udb48\ude84\udaf8\ude5c\ud829\uddda\ud898\udf95\ud84d\udea8\uda07\ude4c\ud9aa\ude82", "\u22a0\u4ef4", "\ud852\udfae\ud8fa\udff6\ud922\udc29\ud885\udcb1\ud833\ude8c\udb75\udf78\uda3d\udedf\ud8ca\udfe6\udbb6\udd61",
        2, 96692, 1350156357, 6045780635641818627L, -28916L, false, true, (char) 45488, (char) 15755,
        Double.longBitsToDouble(0x3fc9059a1d43a228L), Double.longBitsToDouble(0x3fdd33666d4f314eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[null, null, null]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udbcc\udda2", "\ub7f0\u3b9c\u764c", "\udb3d\udd8e\ud95f\udf15\ud888\ude00\uda6d\udedd\uda50\udd2e\udb6c\ude39\ud95a\udfb9\uda74\udd80\uda78\udecf\uda2c\ude2f\ud8bb\ude9c\udb60\udc5a\ud827\udc7e\ud8be\udf55\udb65\udcf7\u4c1b\ud856\udd18\ud99b\udfef\ud832\udd50",
        43, 39864, 182590809, -1727496302638217471L, -79015L, false, true, (char) 63804, (char) 53384,
        Double.longBitsToDouble(0x3f959216890a6d60L), Double.longBitsToDouble(0x3fd1ccaf99fefa80L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:4 |a2=java.io.StringWriter:\udbbe\udd87\ud8c8\udc5f |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=java.lang.Integer:4 |a2=java.io.StringWriter:\udbbe\udd87\ud8c8\udc5f |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 0, 5, 3, "\udbbe\udd87\ud8c8\udc5f", "\u3b9c\u764c\ud058\u6570\u06c7\u648c\uad12", "\ud86a\ude82\ud95a\udfb9\uda74\udd80",
        0, 64899, 73117365, -2070817414360403012L, 58802L, true, false, (char) 16433, (char) 20249,
        Double.longBitsToDouble(0x3fed0f83c6187c39L), Double.longBitsToDouble(0x3fdc3eeadab3fa26L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 0, 2, 2, "", "", "\udbd0\ude78",
        -1, 34822, -872415078, 59097886704533504L, -34464L, false, false, (char) 28482, (char) 20620,
        Double.longBitsToDouble(0x3fe9e2dc51829ebcL), Double.longBitsToDouble(0x3eb775aced600000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\"\015\uda61\udd2f\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\"\015\uda61\udd2f\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 1, 2, 2, "\015\uda61\udd2f", "\u3b9c\u764c\u00b4\000\u2c72", "\ud946\udda3",
        58, 86583, 1532841488, -7008534249768912510L, -100000L, false, false, (char) 2900, (char) 62623,
        Double.longBitsToDouble(0x3fb4957ac26c1800L), Double.longBitsToDouble(0x3fd921e9fe59efd8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:3A\0121=void |a1=java.io.StringWriter:\"\015\uda61\udd2f\" |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 3, 2, 2, "\015\uda61\udd2f", "\ud5bd\u764c\u00b4\000\u2c72", "\ud946\udda3",
        58, 86583, 1532841488, -7008534249768912510L, -100000L, false, false, (char) 2900, (char) 62623,
        Double.longBitsToDouble(0x3fb4957ac26c1800L), Double.longBitsToDouble(0x3fd921e9fe59efd8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\ud874\udf18\ud8b4\udc07\ud880\udcbb\ud8ad\udca8\uda8f\udc23\udafb\udd76\ud8e1\udd98\uda92\udcb9\uda27\udc6f\ud97c\ude77\ud888\ude43\uda6d\udedd\ud884\ude1a\ud891\udcb0\ud97d\udd71\udaa7\udc79\uda78\udecf\uda2c\udda0\ud8bb\ude9c\ud8c4\udd4c\udb0f\udec8\ud8ca\uded5\udb89\udcaa\udad1\uddb7\udb36\ude65\ud9ac\udc61\ud999\udc65\udad6\udc57\ud95c\udd9c\ud81b\udd95\ud991\udf8e\udb62\udf9a\ud991\udcb5\ud9bf\udc6d\ud8e5\uddc6\uda4e\udd66\udbb8\udd3f\uf520\ud9d8\udebb\ud846\uded8\udb63\uddcb\udaa8\udfff\uda32\udf5e\ud89a\udec6\ud875\udc00\u3c22\uda31\udca6\u8792\udabd\udcad\udb0e\udf38\ud872\udd84\ud88a\udc71\ud956\udf37\uda30\ude6d\udbfc\udd95\ud991\uded6\ud816\udc8a\udacd\udcc8\ub0f9\uda13\ude21\ud8b8\udd11\ud869\udc36\udb04\udf74\ud900\udfba\ud9ed\udc4f\udaf3\udf96\ud938\udfba\udb98\udf5c\ud8a3\udc76\ud812\udc06\ud8ec\udf79\ud87f\udccc\ubd03\ud945\ude84\uda10\udf61\ud97a\udfef\udab6\udf7d |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\ud874\udf18\ud8b4\udc07\ud880\udcbb\ud8ad\udca8\uda8f\udc23\udafb\udd76\ud8e1\udd98\uda92\udcb9\uda27\udc6f\ud97c\ude77\ud888\ude43\uda6d\udedd\ud884\ude1a\ud891\udcb0\ud97d\udd71\udaa7\udc79\uda78\udecf\uda2c\udda0\ud8bb\ude9c\ud8c4\udd4c\udb0f\udec8\ud8ca\uded5\udb89\udcaa\udad1\uddb7\udb36\ude65\ud9ac\udc61\ud999\udc65\udad6\udc57\ud95c\udd9c\ud81b\udd95\ud991\udf8e\udb62\udf9a\ud991\udcb5\ud9bf\udc6d\ud8e5\uddc6\uda4e\udd66\udbb8\udd3f\uf520\ud9d8\udebb\ud846\uded8\udb63\uddcb\udaa8\udfff\uda32\udf5e\ud89a\udec6\ud875\udc00\u3c22\uda31\udca6\u8792\udabd\udcad\udb0e\udf38\ud872\udd84\ud88a\udc71\ud956\udf37\uda30\ude6d\udbfc\udd95\ud991\uded6\ud816\udc8a\udacd\udcc8\ub0f9\uda13\ude21\ud8b8\udd11\ud869\udc36\udb04\udf74\ud900\udfba\ud9ed\udc4f\udaf3\udf96\ud938\udfba\udb98\udf5c\ud8a3\udc76\ud812\udc06\ud8ec\udf79\ud87f\udccc\ubd03\ud945\ude84\uda10\udf61\ud97a\udfef\udab6\udf7d |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 1, 2, 0, "\ud874\udf18\ud8b4\udc07\ud880\udcbb\ud8ad\udca8\uda8f\udc23\udafb\udd76\ud8e1\udd98\uda92\udcb9\uda27\udc6f\ud97c\ude77\ud888\ude43\uda6d\udedd\ud884\ude1a\ud891\udcb0\ud97d\udd71\udaa7\udc79\uda78\udecf\uda2c\udda0\ud8bb\ude9c\ud8c4\udd4c\udb0f\udec8\ud8ca\uded5\udb89\udcaa\udad1\uddb7\udb36\ude65\ud9ac\udc61\ud999\udc65\udad6\udc57\ud95c\udd9c\ud81b\udd95\ud991\udf8e\udb62\udf9a\ud991\udcb5\ud9bf\udc6d\ud8e5\uddc6\uda4e\udd66\udbb8\udd3f\uf520\ud9d8\udebb\ud846\uded8\udb63\uddcb\udaa8\udfff\uda32\udf5e\ud89a\udec6\ud875\udc00\u3c22\uda31\udca6\u8792\udabd\udcad\udb0e\udf38\ud872\udd84\ud88a\udc71\ud956\udf37\uda30\ude6d\udbfc\udd95\ud991\uded6\ud816\udc8a\udacd\udcc8\ub0f9\uda13\ude21\ud8b8\udd11\ud869\udc36\udb04\udf74\ud900\udfba\ud9ed\udc4f\udaf3\udf96\ud938\udfba\udb98\udf5c\ud8a3\udc76\ud812\udc06\ud8ec\udf79\ud87f\udccc\ubd03\ud945\ude84\uda10\udf61\ud97a\udfef\udab6\udf7d", "\u9797\u7ddd", "\ud85e\udd99\udbab\udf36\uda30\udc88\ud9b7\ude68\ud941\udc0f\ud958\udffc\ud8a1\udc52\ud9be\ude84\udb70\udc44\ud832\ude25\udb2c\udd08\udb5b\ude76\uda9c\ude70",
        28, 35215, 1863473922, 916071832618378452L, 42391L, true, true, (char) 54929, (char) 38991,
        Double.longBitsToDouble(0x3fefb9174139798aL), Double.longBitsToDouble(0x3fd06e09e8fd5780L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.lang3.text.translate.AggregateTranslator:@? |a0=[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;:[[]] |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\0121=void |a1=java.io.StringWriter:\ud959\udc86\uda41\udc70\uda76\udd4a\udbb8\udf76\udbd0\ude78\udabd\udebe\uda4a\ude6f\uda39\udc8b\ud8c1\udfb9\ud8e1\udf16\uda1a\udcc9\ud96b\udea5\uda26\udf32\udaab\udc3b\u7c13\udb77\udd0e\ud92f\udcf0\uda30\udde6\udb38\udd0f |this=org.apache.commons.lang3.StringEscapeUtils$CsvEscaper:@?\012",
        Z.run(T, 2, 4, 2, 3, "\ud959\udc86\uda41\udc70\uda76\udd4a\udbb8\udf76\udbd0\ude78\udabd\udebe\uda4a\ude6f\uda39\udc8b\ud8c1\udfb9\ud8e1\udf16\uda1a\udcc9\ud96b\udea5\uda26\udf32\udaab\udc3b\u7c13\udb77\udd0e\ud92f\udcf0\uda30\udde6\udb38\udd0f", "\u1cae\uc5d4\u519a\u2033\ubf6e\u8c26\u5720\u51fb\u16cd\u8501\ub264\u1d2c\u4713\u4f48\u4ba1\uc0e0\u1c2f\u0e21\u82fd\u3b6e\u3824\u130f\u119c\u73e0\u55ef\uc0b2\u7437\u2bf2\ucc00\u77c9\u9876\ubcac\u2901\u478e\u74a2\u6899\u7921\u5ffd\u7006\u921a\u8f0e\u554f\u1b9c\u4519\u6e00\u1fd1\u90c8\u1a28\u7fb8\u2c71\u4f32\uc9ef\u6358\uacd3\u429c\u4bdb\u16d1\u90ed\u5308\uace4\ub3c8\u35fb\u3320\u6693\uc2c0\u8562\ub266\ubb6c\ua51d\u78d2\u209c\uae31\u56dc\ua491\uab90\u61d7\u7035\u6cb1\uc03c\u3e5f\u2b05\uc2d0\u5881\u318a\u7c34\u03b7\ud502\ud3eb\u8bb7\ud450\ucdcd\u7653", "\udae0\udfd7\udb4e\ude59\ud904\udf51\ud8b2\udfd0\udbcd\udffd\uda16\udcfc\ud942\udd0c\ud917\ude0b\udb97\udfd6\ubd78\uda15\ude9e\ud8fe\udf14\udb33\udc0b\ud9c2\ude88\ud9ec\udcff\udbdd\udf86\ud8aa\udcb8\uda40\ude66\udbab\udf09\udbb1\udfbb\ud894\udceb\udaf3\udc7d",
        36, 11324, -1517234756, -3711218648395820853L, -29586L, true, true, (char) 20346, (char) 34085,
        Double.longBitsToDouble(0x3fd6bdf621a0e704L), Double.longBitsToDouble(0x3fae3856cda78420L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,int,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|hex|int|static",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|with|[Lorg.apache.commons.lang3.text.translate.CharSequenceTranslator;|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,int,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
    "M|org.apache.commons.lang3.text.translate.CharSequenceTranslator|translate|java.lang.CharSequence,java.io.Writer|fld:org.apache.commons.lang3.StringEscapeUtils:ESCAPE_CSV",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
