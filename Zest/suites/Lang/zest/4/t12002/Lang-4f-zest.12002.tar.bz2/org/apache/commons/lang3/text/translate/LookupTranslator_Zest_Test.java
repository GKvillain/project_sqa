package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class LookupTranslator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9f3\ude14\ud81f\udf41\udbd2\udc76\ud84c\uded8\uda34\uddd9\ud9c6\udec3\ud891\udcb5", "\u8c89\u75c7", "\ud82d\udde9\uda71\uddba\ud89f\udcdd\ud9b6\udcbc\ud831\udcf6\udaf7\udecc",
        4, 67033, 1338644539, 3551674647856191913L, 62279L, true, true, (char) 18548, (char) 30095,
        Double.longBitsToDouble(0x3fae1fc518ed7c50L), Double.longBitsToDouble(0x3fead0c5aff911c8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\ud911\udcae\ud81f\udf19\udbd2\udc76\ud84c\uded8\uda34\uddd9\ud9c6\udec3\ud891\udd06", "\u8c89\u75c7", "\ud82d\udde9\uda71\uddba\ud89f\udcdd\ud9b6\udcbc\ud831\udcf6\udaf7\udecc",
        4, 67033, 1338644539, 3955309764459272629L, 62279L, true, true, (char) 43106, (char) 32670,
        Double.longBitsToDouble(0x3fae1fa418ed7c50L), Double.longBitsToDouble(0x3fead0c5aff911c8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 2, 2, "\ue8ff\ud81d\udc25\uca1d\ud998\ude0b\udb20\udc00\ud9b5\ude2d\ud997\uddc3\uda57\ude32\udbaa\udd40\ud931\udd74\udbad\udd48\ud86c\udcaf\udac7\udd35\ud9e5\udf9e\udafd\udc36\ud8c2\udfd8\ud9b6\udcbc\ud831\udcf6\udaf7\udecc\ud832\udd7f\ud8ee\udf5d\ud949\udce8\uda5d\udef4\ud997\udfa0\udbbd\udc13\udbf3\udcca\ud84b\udd7b\udbf0\udfe0\uda51\udf32\ud83a\udcdd", "\ucfe6\u7eb7\ucfea\u3fe6\u5e5b\u881a\uab17\u2da7\uc783\u4375\u1443", "\ud846\udd55\uda10\udf67",
        29, 96468, 1515141787, -3677322941984157861L, -36533L, true, true, (char) 11079, (char) 13680,
        Double.longBitsToDouble(0x3fe3fb841f97d2d3L), Double.longBitsToDouble(0x3fb8ab01faa9eff8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9f3\ude14\ud81f\udf41\udbd2\udc76\ud8d4\udf9c\uda4f\udc67\uf23c\udb48\ude90", "\u7f4b\u75c7\ua237\u5244\u5478", "\ud9b6\udc62\uda43\udd01\udaf7\udeac\ud93c\udfe7\ud90f\udeaf\udaef\udcee\ud8cf\udc36\ud989\udc9a\udb78\udc32\udbf3\udc60\ud914\ude5f",
        40, 72892, -674911172, 1780603616273910618L, 8902L, false, false, (char) 47976, (char) 45838,
        Double.longBitsToDouble(0x3fefe5084c4e6035L), Double.longBitsToDouble(0x3fe338dc026b65d1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud9f3\ude14\udb7a\udc0b", "\u6221\u9ccb", "\uda5a\udf09\udacb\udccc\udadf\udc41\ud960\ude5f\udae5\udf0e\ud82d\udde9\udb87\udfc6\uda1f\udf8e\ud9e2\udef8\uda57\udd51\ud9af\udf34\udb1c\udd56\ud947\udee0\ud8e5\udd49\ud8b9\ude27",
        1, 79715, 503801655, -6941493114282473717L, 9628L, false, true, (char) 25615, (char) 14785,
        Double.longBitsToDouble(0x3fd36321e1ee56e0L), Double.longBitsToDouble(0x3fdb88cddc270cbeL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9f3\ude14\ud81f\udf41\udbd2\udc76\ud84c\uded8\uda34\uddd9\ud9c6\udec3\ud891\udcb5", "\u8c89\u75c7", "\udbe8\udece\uda71\uddba\ud89f\udcdd\ud9b6\udcbc\ud831\udcf6\udaf7\udecc",
        4, 67033, 1338644539, 3551674647856191913L, -80710L, true, true, (char) 22071, (char) 64870,
        Double.longBitsToDouble(0x3fd9721752e3852cL), Double.longBitsToDouble(0x3fd1efa510f59a46L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9f3\ude14\ud81f\udf41\udbd2\udc76\ud84c\uded8\uda34\uddd9\ud9c6\udec3\ud891\udcb5\udbd4\udd56\udadc\udc6e\udb16\uddf1", "\u5244\uc395", "\ud9b6\udcae\ud831\udcf6\ud801\udc9b\udaa0\udc46\ud8ee\udeef\udaef\udcee\uda56\udc2d\ud825\udf73\ud8bc\ude37\ud9b2\udf44\udbe3\udf39",
        52, 56874, -674911172, 1780603617943923587L, 2954L, false, false, (char) 55375, (char) 54411,
        Double.longBitsToDouble(0x3fc00c68138d9e60L), Double.longBitsToDouble(0x3fee13aa7979b349L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 2, "\u6729\ud81f\udfea\udbd2\udc76\ud84c\uded8\uda62\udc4b\ud9c6\udec3\ud891\udcb5", "\u8733\u7120\ua9bc\u5244\ud719\u9b9c\u0268\u855d\u602b\u2fb1\u400f", "\uda56\udc2d\ud8ff\ude54\udb78\udcf5",
        52, 11765, 1086600693, -51930123833332575L, -8798L, false, false, (char) 52756, (char) 10882,
        Double.longBitsToDouble(0x3fe23d72b7f2f1b5L), Double.longBitsToDouble(0x3fed499d21de9fe0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 0, 2, 2, "\udba6\udf6e\ud81f\udf41\u2177\ud9d6\udd79\ud923\ude6c\udba2\udc92\ud881\ude16\uda70\udf09\udb27\udece\ud95c\udc13\udb7e\udcfb\ud960\udebc\uda27\udf0f\ud97b\udd59\uda71\uddba\ud916\udeba", "\u24a4\u400f\u1f39\u5420\ubb74\u7fd7", "\ud8b1\udeae\ud8c5\uddba\uda51\udf32\ud82e\udddd\udb28\udf02\ud8ed\udc66",
        54, 8924, 1260536382, -6666591926823752743L, -82401L, false, false, (char) 60897, (char) 23199,
        Double.longBitsToDouble(0x3fd15f667f702386L), Double.longBitsToDouble(0x3fdff5d9b0c12b18L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 0, 2, 0, "\ud9f3\ude14\ud81f\udf41\udbbb\udd0b\ud84c\uded8\ud95b\uddd5\ud9c6\udec3\ud891\udcb5", "\u8c89\u75c7", "\udaf3\ude7b\uda71\uddba\ud89f\udcdd\ud9b6\udcbc\uf5d6\udaf7\udecc",
        4, 67033, 1328639291, 3551674647856191913L, -134L, true, true, (char) 18548, (char) 30095,
        Double.longBitsToDouble(0x3fae1fc518ed7c50L), Double.longBitsToDouble(0x3fead0c5aff911c8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 1, "\ud9f3\ude14\ud81f\udf41\udbd1\udff2\udb23\udd82\ud856\udc3b\ud9cb\udc6e\udbaa\udd15\ud8a9\udd01\uda5a\udf09\ud88a\udc31\ud8bd\ude9c\ud960\ude96\udae5\udf0e", "\u0268\u855d\u602b\u285b\u782a\u2a30\ua3af\u07b1\u0f90\u3e10\ud46b", "\ud81d\uded8\ud82e\udddf\udb28\udf02\ud8ed\udc66\udad0\uddbb\udb48\udea1\ud8a4\ude64\ud83f\udf5e\ud8d7\udccd\ud8d9\udfac\ud986\udfa2\ud92f\udee0\ud835\udc33\uc86f\ud881\uddac\u365f\ud91d\udcf6\ud885\udd1d\udaea\ude30\ud873\udd09\uda81\udf91\ud94e\ude91\udbf3\udc87\uda90\udce8\ud959\uddb8",
        49, 86363, -550373580, -4499605953150238684L, 19413L, true, false, (char) 21260, (char) 27949,
        Double.longBitsToDouble(0x3fc90abd027fac40L), Double.longBitsToDouble(0x3fd99f2e3ea9f326L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud9f3\ude14", "\u25a2\u4cb3\u549f\ucac9\ud1c7", "\udb7e\udcfb\ud960\udebc\udae5\udf0e\udb69\udcc6\ud841\udd56",
        28, 86826, 127332829, -2439256204116288287L, 24869L, false, true, (char) 51954, (char) 38274,
        Double.longBitsToDouble(0x3fe0cf7d8b156a95L), Double.longBitsToDouble(0x3f947bb46e854360L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 1, 0, 0, 2, "\ud9f3\ude14\ud81f\udf41\udbdc\udedc\uda9d\udd55\ud969\udc75\uda4b\ude74\udbdf\udd81", "\u80d8\u7696\u6ea9\u7c30\u5478", "\ub9f9\udaf8\ude90\udaf7\udecc\ud82a\ude3d\ud8ee\udf5d\udaef\udcee\uda56\udc2d\ud8ff\ude54\udb53\udd24\udbf3\udc60\ud914\ude5f",
        38, -692, -1109873604, 1784868694892497754L, 43683L, true, true, (char) 16113, (char) 65393,
        Double.longBitsToDouble(0x3fbe98b03b566950L), Double.longBitsToDouble(0x3fe5eaf51447ed74L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 1, 2, 0, "\udbb6\udcd8\uda3b\ude15\udbea\ude3e\udbb1\ude0e\udb6a\udc18\udbaf\udd48\ud9b0\udd58", "\u13b7\u75c7\ua237", "\uda61\udd4f\ud835\udf4c\ud8eb\udc59",
        10, 88022, -1120896539, -7430559312612091845L, 70409L, true, true, (char) 3322, (char) 23978,
        Double.longBitsToDouble(0x3fdaf7bb46e85436L), Double.longBitsToDouble(0x3fe9e1fc55d96a1fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 1, 1, "\ud9f3\ude14", "\ud6aa\u4cb3\u549f\uc8ff\u8118", "\ud999\udff8",
        21, 24232, -1213150676, 7396695696147614224L, 27442L, false, true, (char) 21878, (char) 21082,
        Double.longBitsToDouble(0x3fe44f79c1156a95L), Double.longBitsToDouble(0x3fe83bada54d71ceL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\udb85\ude52\ud81f\udf41\udbd2\udc76\ud84c\uded8\uda34\uddd9\ud9c6\udec3\ud891\udcb5\uda79\udd09\uda5a\udf09\ud95c\udc13\ud87f\udc70\ud98a\udfea\udae5\udf0e\ufb85\uda71\uddba\ud89f\udcdd\ud9b6\udcbc\ud831\udc5b\udaf7\udecc\ud93c\udfe7\ud8ee\udf5d\udaef\udcee\ud8dd\udff1\ud8ff\ude54\udb78\udcf5\udbf3\udc60\ud914\ude5f\ud8eb\udf3b\uda51\udf32\ud82e\udddd\udb28\udf02\ud8ed\udc66\ud933\udc0c\uda01\udee8\ud806\udeb2\ud857\udfa2\udb74\udda4", "\u0e99", "\ud9c0\ude62\udb02\udfa4\udbd8\udcc4\ud8f6\udfa1\ud8d6\udf07\uda31\udfd3\ud93d\udcf2\ud83f\udd4f\udac8\ude19\udb4d\uddd5\u916e\ud829\udeaf\ud8f9\udd54\ud923\udfdd\ud921\udfe9\ud80a\udfa9\uda3d\udfdb\uda5f\udcb8\uda1e\ude1f\u0b00\ud84b\udc15\ud992\udc04\udb23\udea4\udb64\ude66\udbb0\udc83\ud819\udcae\ud67e\uc666\ud87c\udd12",
        29, 39831, 1436448098, -817835782440425625L, -10796L, true, true, (char) 57333, (char) 34647,
        Double.longBitsToDouble(0x3fe7c10683d3a43dL), Double.longBitsToDouble(0x3fa101480237d980L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud9f3\ude14\u7761\udba2\udd73\ud84c\udfb7\uda34\uddd9\ud9c6\udec3\ud891\udcb5\uda79\udd09", "\u75c7\ua237\u5244\u5478\u3248", "\ud8d1\udef0\uda11\uded9\ud93c\udfe7\ud8ee\udf5d\udaef\udcee\uda56\udc2d\ud8ff\ude54\udb78\udcf5\udbf3\udc60\ud914\ude5f\ud8eb\udf3b\ud9b1\udc2e\ud82e\udddd\udb28\udf02\ud8ed\udc66\ud93d\ude92\ufc8f\ud9d0\udefb\ud8c3\ude63\ud8d6\udff7\ud81a\udfa5\uda81\ude67\ud80c\udc85\ud9dd\ude95\ud9ec\udf66\ud825\ude3e\uda0f\udcdb\udb5e\udf31\udb75\udd65\udaf0\ude3c\ud9c2\ude1d\udaab\udc79\udbe9\udde8\udbec\udf47\udb99\uddcd\uda15\udc69\udaa5\ude2d\u76b1\ud941\udcd7\udb49\udfcf\ud91f\udc0b\ud8f7\udd7a",
        28, 88288, -545561541, 4823690224609905436L, -13074L, true, true, (char) 2196, (char) 26840,
        Double.longBitsToDouble(0x3fd500cd8728af54L), Double.longBitsToDouble(0x3fed6ce90e7d5f85L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 2, 1, "\000", "", "",
        41, 11968, 78556355, -9114983837187830872L, -100000L, false, false, (char) 27028, (char) 3935,
        Double.longBitsToDouble(0x3f9066a600000000L), Double.longBitsToDouble(0x3fddd00000000122L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9f3\ude14\ud81f\udf41\udbd2\udc76\ud84c\uded8\uda4e\udce6\ud9d5\ude74\ud891\udcb5", "\u2a25\u75c7", "\udb56\udeaa\ud9a7\udd27\ud8d0\udc89\ud9b6\udc6b\ud831\udcf6\udaf7\udecc\ud93c\udfe7\ud8ee\udf5d\udaef\udcee\uda56\udc2d\ud8ff\ude54\udb78\udcf5\udbf3\udc60\ud914\ude5f\ud8ee\udd3b\uda51\udf32\ud82e\udddd\udb28\udf02\ud8ed\udc66\uda50\udcfc\ud98a\udf66\udb87\ude65\ud884\udc6b\ud833\ude0e\uda0a\uddd0\uda61\udd21\ud905\udf32\udbdb\ude0c\udab6\ude0d\ud82e\udd9c\udba3\uddc5\udbc0\udce1\udbb7\udf94\udb48\udf58\udab6\ude00\ud818\ude08\udaca\udf1f\ud9e6\udc45\ud9ed\udce4\ud9d5\udeb3\ud83f\udee8\uda06\uded8\uda4e\udea7\ud91d\udc36\ud9e1\ude9d\udbd3\udeca\uda09\udea7\uda59\udfa7\udb99\udf1b\ud87c\udfcf\udb7d\udcbf\ud8d2\ude15\udb55\udeab\udb31\udc9d\ud976\udf91\udb84\udc15\udb3c\udf19\ud8e0\udfbe\udbbb\udfde\ud8b6\udd76\uda64\udcbe",
        33, 64633, -1876222954, 7288803512776328284L, 8345L, true, false, (char) 12053, (char) 25566,
        Double.longBitsToDouble(0x3fe1ccb15acf6c1dL), Double.longBitsToDouble(0x3fc7f6763c61ae84L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 1, 1, 2, "\ud9f3\ude14\ud81f\udf41\udbd2\udc76\ud9cb\udf56\udb04\udfe9\udaa7\ude54\ud891\udcb5", "\u8c89\u75c7\ua237\u5244\u5478\u5531\ub6fe\u855d\u602b\u285b\u400f\u08e0\u3c02\ub12e\u9eb3\u7a8e\ud4cf\u35b3\u3ea8\uc6c2\u4c8e\u7ed7\u48ba\u9c53\uc267\u6b9e\u4a50", "\ud899\udc0c\udb2f\uddcb\ud811\udc3f\ud8fe\udc24",
        48, 97443, -76879621, -6725079403040215023L, 20298L, true, true, (char) 18388, (char) 59828,
        Double.longBitsToDouble(0x3fdec71a8b169b6aL), Double.longBitsToDouble(0x3fe238ef281c108aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 2, "\000", "\ud6aa\u4cb3\u549f\ucac9\u924f", "\ud839\udf19\000\000\000\000",
        -5, 86826, 9564637, 0L, -100000L, false, true, (char) 51954, (char) 6445,
        Double.longBitsToDouble(0x3fe0cf79c3156a95L), Double.longBitsToDouble(0x3fc80f768dd0a86cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\000", "", "\ud9c6\udec3",
        0, -1000, -2122247554, 12816182411264L, -100000L, false, false, (char) 3935, (char) 26278,
        Double.longBitsToDouble(0x3fc7400000011024L), Double.longBitsToDouble(0x3e421a9400000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 1, 1, 0, 0, "\ud9f3\ude14\ud81f\udf41\udbd2\udc76\ud84c\uded8\uda34\uddd9\uda4e\udec7\ud891\udcb5", "\u8c89\u75c7", "\ud82d\udde9\uda71\uddba\ud89f\udcdd\ud9b6\udcbc\ud831\udcf6\ud867\udd0f",
        37, 91714, -1774080770, 3551674648282503593L, 17684L, false, true, (char) 1856, (char) 30305,
        Double.longBitsToDouble(0x3fae1fc518ed7c50L), Double.longBitsToDouble(0x3f9918b5fe28ebe0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 2, 0, "\ud9f3\ude14", "\u9035\u6221\uadf9\u75c1\u1dbd\u81c9\u91c2", "\udae5\udf0e\ud82d\udde9\ud970\udffb\udb91\udd24\udb33\udc1e\ud85d\udde2\ud980\udcc4\udb5a\udea2\u6d21\ud8e5\udd1f\ud8b9\ude27\udbc9\udd91\ud9d2\ude14\u90fc\uda9b\udf1c\udb6a\udf4e\uda51\udf32\ud82e\udddd\ud828\udce8\ud8ed\udc66\udb18\udd23\ud943\udfc5\ud8c2\uddd7\udbf1\udc12\ud949\udeaa\ud86c\udd3f\ud820\uddfa\udaee\udd31\uda62\udd74\udaea\udc59\udb2e\udf1e\ud98e\udc47\ub91f\ud9ef\udcfa\ud97e\udf75\ud9dd\uddda\ud8e1\udcf1\uda62\udf90\udb19\ude9e\ud8d9\udc1b\ud85a\udf0b\udaf4\ude88\ud9c0\ude3b\ud919\udfa1\uda82\udf6c\ud8a7\udebf\ud9b5\udc3b\udac4\udeed\ud9fe\udc3e\udaba\uddfc\ud980\udf8b\uda2a\udefd\ud986\udc2b\ud854\udfe9\udb28\udc84\ud929\udf3c\ud84c\udd76",
        40, 98567, -96893233, -6768690491602332326L, 45146L, false, false, (char) 24482, (char) 62752,
        Double.longBitsToDouble(0x3feb37d4da6db8dfL), Double.longBitsToDouble(0x3fe112e2a299e392L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9f3\ude14\ud81f\udf41\udbd2\udc76\ud84c\uded8\ud9a2\udcb4\udad9\udd0d\ud891\udd37", "\u8c89\u2369", "\ud9f8\uddfe\uda71\udd2e\ud9a2\udd9f",
        18, 44805, -1526021059, -757760850140331407L, 36518L, true, true, (char) 6445, (char) 25750,
        Double.longBitsToDouble(0x3fe0ab56cc697b73L), Double.longBitsToDouble(0x3fe209534c3c8612L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 2, 0, "\ud9f3\ude14\ud996\udefa\udbfc\udd62\udb1d\udd1b\ud8f7\udc01\ud9a2\udef0\ud851\udcdd\uda27\udd72\uda5a\udf09\udacb\udccc\ud9c4\ude17\ud96d\udd52\ud987\udff3\ud936\udf25\udb96\udc74\uda1f\udf8e\ud9e2\udef8\uda57\udd51\ud9af\udf34\udb1c\udd56\ud947\udee0\ud8e5\udd49\ud8b9\ude27\udbc9\udd91\ud9d2\ude14\u90fc\uda9b\udf1c\udb6a\udf4e\uda51\udf32\ud82e\udddd\udb28\udf02\ud8ed\udc66\ud834\udeed\ud943\udfc5\udbec\ude2d\ud816\ude8d\ud85e\udc34\uda04\udc65\ud8b5\udd54\ud883\udeef\uda10\udd93\ud96c\udf00\udbcc\udcd1\ud81a\udfa1\ud87d\ude62\ud807\udc33\u82e5\udb46\uddcc\u034e\ud8a1\uded0\ud8fc\udc19\uda24\udfac\uda11\udc76\ud9b3\ude77\uda72\udf4b\ud9d0\udf9e\udb54\udc54\uda95\udf00\uda02\udffd\uda13\udfa2\ud94b\udc31\ud983\udeef\ud918\udd5b\ud910\udfab\ud95c\udd67\udab9\ude54\ud9ce\uddc3\uda62\uddfd\udb8c\udcc1\ud9a7\udd18\udab5\udec7\udbfa\udc21\ud979\udc80\udb68\udfa9", "\uc124\u7ff5\ua58d", "\udbbc\udfd1\ud81e\udf78\ud93b\udc94\ud8fa\uddbd\ud9ea\udf83\udb15\udc7a\udb6a\udf4c\udaa5\udff1\uda60\udd09\udb92\udd71\ud84d\udc40\ud843\udc66\ud83f\ude0b\ud923\uddfc\ud918\udec3\ud84a\udd0d\ud8fc\ude66\ud8c2\uddd4\ud84c\ude81\uda19\udfed\uda2a\udeec\udbda\udc4f\ud893\uddfc\udb26\udd11\ud96f\ude95\ud8ed\udd05\ud84a\uded8\u7790\ud893\udd15\udad9\ude1b\ud88f\udeb2\ud9ec\udc8f\uda3c\ude5f\ud9ed\udcb1\udaa5\udeb9\ud8be\uddb4\ud9ff\udffa\udaee\ude4b\udb20\udf2c\ud90d\udf9f\ud86d\udeeb\ud83c\udc4b\udb36\ude70\ud9e5\ude78\ud829\udffe\ud803\udfc9\uda02\ude89\ud899\udcfa\udbfb\uddb4\ud9f4\udd0e\ud839\ude4a\ud899\udd85\udb94\udf42",
        54, 69628, -912554877, 4150102313834377181L, -9409L, false, true, (char) 21548, (char) 16721,
        Double.longBitsToDouble(0x3fec8d6295d2e8cfL), Double.longBitsToDouble(0x3fc72508f88820acL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 2, 0, "\ud9f3\ude14\ud996\udefa\ud8ce\udeeb\udb1d\udd1b\ud8f7\udc01\ud9a2\udef0\ud851\udcdd\uda27\udd72\uda5a\udf09\udacb\udccc\ud9c4\ude17\ud96d\udd52\ud987\udff3\ud936\udf25\udb96\udc74\udae2\udc30\ud9e2\udef8\uda57\udd51\ud9af\udf34\udb1c\udd56\ud947\udee0\ud8e5\udd49\ud8b9\ude27\udbc9\udd91\ud9d2\ude14\u90fc\uda9b\udf1c\udb6a\udf4e\uda51\udf32\ud82e\udddd\udb28\udf02\ud8ed\udc66\ud834\udeed\ud943\udfc5\udbec\ude2d\ud816\ude8d\ud85e\udc34\uda04\udc65\udbcf\ude81\ud883\ude44\uda10\udd93\ud96c\udf00\udbcc\udcd1\ud81a\udfa1\ud87d\ude62\ud807\udc33\u82e5\udb46\uddcc\u034e\ud8a1\uded0\ud8fc\udc19\uda24\udfac\uda11\udc76\ud9b3\ude77\uda72\udf4b\ud867\ude17\udb54\udc54\uda95\udf00\uda02\udffd\uda13\udfa2\ud94b\udc31\ud983\udeef\ud918\udd5b\ud910\udfab\ud95c\udd67\udab9\ude54\ud9ce\uddc3\uda62\uddfd\udb8c\udcc1\ud9a7\udd18\udab5\udec7\udbfa\udc21\ud979\udc80\udb68\udfa9", "\uc124\u7ff5\u1038", "\udbbc\udfd1\ud81e\udf78\ud93b\udc94\ud8fa\uddbd\ud9ea\udf83\udb15\udc7a\udb6a\udf4c\udaa5\udff1\uda60\udd09\udb92\udd71\ud84d\udc40\ud843\udc66\ud83f\ude0b\ud923\uddfc\ud918\ude0a\ud84a\udd0d\ud8fc\ude66\ud8c2\uddd4\ud84c\ude81\ud882\udddd\uda55\ude48\udbda\udc4f\udb6c\udc88\udb0a\udf86\ud96f\udef4\ud8ed\udd05\ud84a\uded8\u7790\ud893\udd15\udad9\ude1b\ud88f\udeb2\ud9ec\udc8f\uda3c\ude5f\ud9ed\udcb1\udaa5\udeb9\ud8be\uddb4\ud9ff\udffa\udaee\ude4b\udb20\udf2c\ud90d\udf9f\ud86d\udeeb\ud83c\udc4b\udb36\ude70\ud9e5\ude78\ud829\udffe\ud803\udfc9\uda02\ude89\ud899\udcfa\udbfb\uddb4\ud9f4\udd0e\ud87c\udd56\ud899\udd85\udb94\udf42\ue37f\udaba\ude68\ud978\udd4e\udb92\udf75\ud9c3\udf40\udab5\udc4d\udb62\ude9d\ud85a\udf96\udaaf\udf58\uda4c\udd06\ud883\ude33\udaa8\udc31\ud8d2\udd34\ud89a\udf04\ud953\udfa8\ud999\udc7f\uda8c\udf5d\ud9c6\udc38\uda90\udc3b\ud944\udc1a\ud8da\udd4f\udaa8\udc81\uda83\udf4b",
        2, 36196, 834273310, 6053939542221424924L, 33641L, false, false, (char) 45267, (char) 24322,
        Double.longBitsToDouble(0x3fea5b5bc3564debL), Double.longBitsToDouble(0x3fa454001a775950L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.LookupTranslator|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.LookupTranslator:[[Ljava.lang.CharSequence;",
    "C|org.apache.commons.lang3.text.translate.LookupTranslator|<init>|[[Ljava.lang.CharSequence;",
    "M|org.apache.commons.lang3.text.translate.LookupTranslator|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.LookupTranslator:[[Ljava.lang.CharSequence;",
    "C|org.apache.commons.lang3.text.translate.LookupTranslator|<init>|[[Ljava.lang.CharSequence;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
