package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class LookupTranslator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd76\ud935\udce9", "\u39d7\uc278\u2678\u6637\ud4a5\u54f5\ub020\u9d23\ua38d\u4af1\ua615\u7ec9\u8001\uce00\ua349\u0484\ube30\u96d2\u210e\u5b41\u79c4\u0774\u6a8e\u6b5f\u637a\ua0b3\u2ba7\ua337\ucd27", "\ud1a3\ud8cb\udfd2\u315f\ud9d4\ude96\ud81a\udea4\ud867\udff0\ud99f\udc7d\ud9a4\udfc2\ud85f\udf67",
        59, 55270, 1283015536, 1422777165187687398L, -25525L, false, false, (char) 17174, (char) 47143,
        Double.longBitsToDouble(0x3fd4417666d88dbeL), Double.longBitsToDouble(0x3fd1502f25f0257cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 1, "\ud83d\udd76\ud935\udce9", "\u39d7\uc278\u2678\u6637", "\ud865\udfb5\ufa03\ud824\udc8a\uda83\ude6c\udb14\ude38\uda28\udc64\ud855\ude3b\udad7\udff7\udb92\udfc6\udb04\udf2f\ud8f3\udce5\ud9fd\udff0\ud909\udc51\udac3\udfec\ud8d6\udcc9\uda48\ude89\ud8a9\udd88\ud93a\udf7d\uda9b\udd47\ufde4\udab2\udea3\udbfc\udff7\udb3b\udcf3\u1ddd\udaae\udf80\ud1a3",
        23, 59384, 1836521251, 8588130972537595426L, 7237L, true, true, (char) 22954, (char) 46415,
        Double.longBitsToDouble(0x3feb8143684b4c79L), Double.longBitsToDouble(0x3fda4344a099c0eaL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd76\ud935\udce9", "\u39d7\uc278\u2678\u2090\ud4f4\u54f5\ub020\u9d23\ua38d\u4af1\ua615\u7ec9\u8001\uce00\ua349\u6f08\ube30\u96d2\u210e\u5b41\u66fb\u9d2e\u9102\u6a71\u637a\ua0b3\u2ba7\ua337\u166b", "\ud1a3\ud8cb\udfd2",
        14, 75395, 1999580062, 2207368696757841341L, -15135L, true, true, (char) 46415, (char) 27613,
        Double.longBitsToDouble(0x3fb2d31e5f309df0L), Double.longBitsToDouble(0x3fef392c62eb546bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd76\ud935\udce9", "\u39d7\uc278\u2678\u6637\ud4a5\u54f5\ub020\u9d23\u0a6e\u4af1\ua615\u7ec9\uca0b\uc42d\ua349\u98df", "\ud909\udc51\udafb\uddec\ud8d6\udcc9\uda48\ude89\ud8a9\udd88\ud93a\udf7d\uda9b\udd47\udb7b\udd41\udb80\udfd8",
        28, 69464, 174601536, 6288870453462624421L, -6371L, true, true, (char) 50402, (char) 22954,
        Double.longBitsToDouble(0x3fd261c2a6e050daL), Double.longBitsToDouble(0x3fb2e95e5f309df0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 2, "\u30f9\ud948\ude09\ud8a9\udf09", "\ucd85", "\udb33\uddaa\uda11\udcdf\ud8c7\udfcc\ud9a5\udf1b\ud881\udc4f",
        39, 57626, -1453949568, -1933742092997932395L, -73221L, false, true, (char) 46369, (char) 37070,
        Double.longBitsToDouble(0x3fe27fe8d0b2174cL), Double.longBitsToDouble(0x3fa20eafab6a0eb0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd76\ud935\udce9\ud899\udfe0\ud9ca\udc89\uda6a\udcae\udad9\udd75\ud852\udfbe\udb0c\udfd5\ud8cb\uddf6\udb41\ude36\ud865\udfb5\ufa03\ud824\udc8a\uda83\ude6c\udb14\ude38\ufc3e\udbc7\udea4\udad7\udff7\udb92\udfc6\udb04\udf2f\ud8f3\udce5\ud9fd\udff0\ud909\udc51\udac3\udfec\ud8d6\udcc9\uda48\ude89\ud8a9\udd88\uda8c\udd25\udbd0\udc30\ud995\udef6\udb80\udfd8\udbe6\udfbd\udb3b\udcf3\u1ddd\udaae\udf80\ud1a3\ud8cb\udfd2\u315f\ud9d4\ude96\ud81a\udea4\ud867\udff0\ud99f\udc7d\ud9a4\udfc2\ud85f\udf67\udbba\udce9\udbaa\udf87\udad5\udff1", "\u73f5\u0617\u57b4\u5677\u32eb\u9543\u56ea\u334c\u4984\u6cc7\u5dea\u082d\u810e\u2c46\u473a\u4fb2\ud195\ua0ca\u8ff1\u0452\u4d9d\ucbd3\u1238\ubdc2\u3779\u5a57\u5d3a", "\ud9b3\udc4c",
        35, 21061, 70746942, 1175344955936727297L, -93301L, true, false, (char) 52357, (char) 37552,
        Double.longBitsToDouble(0x3fe927af51a4cd4fL), Double.longBitsToDouble(0x3fdbec7c7150f17eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd76\ud92d\udde9", "\u39d7\uc278\u2678\u9836\ud4a5\u249b\000\u53b5\ua38d\u4af1\ua615\u7ec9\u8001\uce00\ua349\u0484\ube30\u96d2\u549c\000\000\u0750\u6a8e\u6b5f\u637a\u85f6\u2b0d\ud3c5\000", "",
        15, -1000, 683931384, 7887962540686125982L, -34464L, true, false, (char) 23086, (char) 22954,
        Double.longBitsToDouble(0x3fd261c2a6e050daL), Double.longBitsToDouble(0x3fb2d31e5f309df0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd76\ud935\udce9", "\u76fa\ucb8a\uaaf5\u6637\ud4a5\u54f5\ub020\u9d23\ua38d\u4af1\ua615\u7ec9\u8001\uce00\ua349\u4d1b\u6ec9\u342f\u210e\u5085\u79c4\u0774\u6a8e\u6b5f\u637a\ud607\u2cf6\ua337\ucd27", "\ud1a3\ud8cb\udfd2\u315f\ud9d4\ude96\ud81a\udea4\ud867\udff0\ud8e3\udda0\ud9a4\udfc2\ud85f\udf67",
        59, 55270, 1283015536, 1422777165187687398L, -72168L, false, true, (char) 33487, (char) 59978,
        Double.longBitsToDouble(0x3fd1502f25f0257cL), Double.longBitsToDouble(0x3fb28d58e327ce38L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ub52f\ud934\udff6", "\u39d7\uc278\u2678\u6637\ud4a5\u54f5\ub020\u9d23\ua38d\u4af1\ua615\u7ec9\u8001\uce00\ua349\u0484\ube30\u96d2\u210e\u5b41\u79c4\u0774\u6a8e\u80f0\u637a\uceeb\u210d\ua337\ud01d", "\ud1a3",
        23, 59384, 1836559395, 8588130972537595426L, 7237L, true, true, (char) 22889, (char) 46415,
        Double.longBitsToDouble(0x3feb8143684b0079L), Double.longBitsToDouble(0x3fef309df7e7258cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 1, 1, 1, 1, "\uda1c\udea1\udaaa\udc36\ud8ac\ude02\ud8ea\udce5\uda6a\udcae", "\u6637\ud4a5\u54f5", "\ud824\udc8a\ud883\udd6c\udb05\udc7b\udb08\udcb3\ud855\ude00\udad7\udff7\udb92\udfc6\udb04\udf2f\ud8f3\udce5\ud9fd\udff0\ud909\udc51\udac3\udfec\ud8d6\udcc9\uda48\ude89",
        58, 13032, 569011016, 8921496678807308954L, 67516L, true, false, (char) 31170, (char) 28744,
        Double.longBitsToDouble(0x3fa19461b9e6d770L), Double.longBitsToDouble(0x3fe113b97dbd1ea2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 1, 1, 1, 1, "\ucba5\ud965\uddc5\ud922\ude77", "\uc2ce\u2678", "\udb41\ude36",
        23, 17342, -908454981, 3871885399898924680L, -72391L, true, true, (char) 4537, (char) 43033,
        Double.longBitsToDouble(0x3fee773e66be5663L), Double.longBitsToDouble(0x3fbf4514527fe8d0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 1, 0, 1, 2, "\ud83d\udd76\ud935\udce9", "\u39d7\uc278\u2678\u3f1b\uc632\u54f5\ub020\u9d23\ua38d\u4af1\ua615\u7ec9\u8001\uce00\ua349\u0484\ube30\u96d2\u7d0d\u5b41\u79c4\u6e5d\u6a8e\u6b5f\u637a\ua0b3\u2ba7\ua337\ucd27", "\ud1a3\ud8cb\udfd2\u315f\ud9d4\ude96\ud81a\udea4\ud867\udff0\ud99f\udc7d\ud9a4\udfc2\u4b81",
        9, -1000, 0, 620756992L, -25525L, false, false, (char) 0, (char) 47143,
        Double.longBitsToDouble(0x3fd4417666d88dbeL), Double.longBitsToDouble(0x3f9502f25f024000L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud95a\udea8\uda65\ude70", "\ua23d\uaea7\uad25", "\udb41\ude36",
        23, 62022, -908454981, 3871885400046816392L, 28976L, true, false, (char) 11181, (char) 43033,
        Double.longBitsToDouble(0x3fee715fe6be5663L), Double.longBitsToDouble(0x3fbf4514527fe8d0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 2, "", "\000\u380b", "\ud944\udfb7",
        21, 36872, 457974939, -1508581694764922514L, -80354L, false, false, (char) 22096, (char) 41254,
        Double.longBitsToDouble(0x3fe4af294809d3a3L), Double.longBitsToDouble(0x3fc367efdf38af30L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud83d\udd76\ud935\udce9", "\u39d7\u6bf4\u8a54\uaea1", "\ud9fc\ude15\ufa03\ud824\udc8a\uda83\ude6c\udb14\ude38\ud8ca\uddb4\ud855\uddd7\udad7\udff7\ud9c5\udd96\udb03\udf2f\ud8f3\udce5\ud9fd\udff0\ud909\udc51\udac3\udfec\udb41\udded\uda48\ude89\udb76\udd8d\ud921\uddd8\uda9b\udd47\ufde4\uc364\udab7\udce2\ud86e\udcee\udb90\udd4e\ud99e\udf6b\udb81\udfe9",
        48, 85398, 157441403, 4109340204721882924L, 7237L, true, true, (char) 22954, (char) 46415,
        Double.longBitsToDouble(0x3feb8143684b4c79L), Double.longBitsToDouble(0x3fda4344a099c0eaL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 0, 1, 1, "\udbef\ude90\ud935\udce9", "\u7694\u2a77\u4d94\u4b1f\ud4a5\u54f5\ub020\u9d23\ua38d\u4af1", "\ud855\ude3b",
        6, 97689, 734816411, -3214717127326867942L, -97988L, true, false, (char) 10511, (char) 3799,
        Double.longBitsToDouble(0x3fdf621ea399fd9eL), Double.longBitsToDouble(0x3fefe8726780ffabL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 1, "\ud83d\udd58\ud858\ude8d\ud8cb\udebc\uda90\udfe2\uda8a\uddd5\ud94f\uddc2\ud853\udc29\udb0c\udfd5\ud9a5\udf31\udb72\udecc\ud865\udfb5\ufa03\ud824\udc8a\uda83\ude6c\udb14\ude38\uda28\udc64\ud855\ude3b\udad7\udff7\udb92\udfc6\udb04\udf2f\ud8f3\udce5\ud9fd\udff0\ud909\udc51\udac3\udfec\ud8d6\udcc9\uda48\ude89\ud8a9\udd88\ud93a\udf7d\ud8aa\udd2f\udbfe\udf58\udbb9\udfd6\ud9a3\udfdb\udb3b\udc82\u1ddd\udaae\udf80\ud8b9\udc4d\ud8cb\udfd2\u315f\ud8f5\udfdb\ud818\uddbb\ud867\udff0\ud99f\udc7d\ud9a4\udfc2\u5f1b\udbba\udce9\udbaa\udf87\udad5\udff1\udb72\udf5f\ud84b\udfc8\ud805\udeac\udaec\udec1\ud8a1\udd23\uda15\udee5", "\u218c", "\uee64\udb92\udf05\uda96\udeb3\uda65\udc9d\udbe0\udd85\uda8e\udd5d\udab6\udcde\udb2b\ude9f\ud804\udf90\ud8a2\udd93\udbd5\udc70\ud896\udffb\ud86d\udd1e\udb29\ude1f\udae9\udd5c",
        59, 36769, 995977056, -2644824969621695401L, -72680L, false, false, (char) 16285, (char) 12663,
        Double.longBitsToDouble(0x3fe6ee14706361e5L), Double.longBitsToDouble(0x3fc18b9cb881f400L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 2, "", "\u0f5d", "z",
        37, 97892, 115, 0L, 36123L, false, true, (char) 579, (char) 22096,
        Double.longBitsToDouble(0x3fee854ab295e529L), Double.longBitsToDouble(0x3f83a74626cfdf80L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd76\ud935\udce9", "\u39d7\uc278\u2678\u6637\ud4a5\u54f5\ub020\u681a\u807f\u0a95\ua596\u7ec9\uca0b\uc42d\ua349\u98df", "\ud9b4\ude24\udab1\udc8c\udb08\ude3f\udb32\uddfa\ud8a9\udd79\ud93a\udf7d\uda9b\udd47\udb7b\udd41\udb80\udfd8",
        28, 69464, 174601536, 6288870453462594994L, 4742L, false, true, (char) 24004, (char) 47011,
        Double.longBitsToDouble(0x3fed18f09aa819eaL), Double.longBitsToDouble(0x3fbab4081ba0e648L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd47", "", "",
        -5, -1000, 6596096, 457974784L, -100000L, false, false, (char) 0, (char) 52359,
        Double.longBitsToDouble(0x3fd80d8cfd6d52acL), Double.longBitsToDouble(0x3fc8d48a00000000L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=new org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud83d\udd76\ud935\udce9\ud899\udfe0\ud9ca\udc89\uda6a\udcae\udad9\udd75\ud852\udfbe\udb0c\udfd5\ud8cb\uddf6\udb41\ude36\ud865\udfb5\ufa03\ud824\udc8a\uda83\ude6c\udb14\ude38\ufc3e\udbc7\udea4\udad7\udff7\udb92\udfc6\udb04\udf2f\ud8f3\udce5\ud9fd\udff0\ud909\udc51\udac3\udfec\ud8d6\udcc9\uda48\ude89\ud8a9\udd88\uda8c\udd25\udbd0\udc30\ud995\udef6\udb80\udfd8\udbe6\udfbd\udb3b\udcf3\u1ddd\udaae\udf80\ud1a3\ud8cb\udfd2\u315f\ud9d4\ude96\ud81a\udea4\ud867\udff0\ud99f\udc7d\ud9a4\udfc2\ud85f\udf67\udbba\udce9\udbaa\udf87\udad5\udff1", "\u73f5\u0617\u57b4\u5677\u32eb\u9543\u56ea\u334c\u4984\u6cc7\u5dea\u082d\u810e\u2c46\u473a\u4fb2\ud195\ua0ca\u8ff1\u0452\u4d9d\ucbd3\u1238\ubdc2\u3779\u5a57\u5d3a", "\ud9b3\udc4c",
        35, 21061, 70746942, 1175344955936727297L, -93301L, true, false, (char) 52357, (char) 37552,
        Double.longBitsToDouble(0x3fe927af51a4cd4fL), Double.longBitsToDouble(0x3fdbec7c7150f17eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.LookupTranslator:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud83d\udd76\ud935\udce9\ud9e5\udcfd\ud8ea\udce5\uda6a\udcae\ud82a\udd1d\ud88b\udf7a\udaa1\udf9e\ud8cb\uddf6\ud8d4\uddff\udab1\udf8f\udabd\ude95\uda52\udca4\udb06\udd92\ud9e1\udf5f\ud8ca\uddb4\ud855\uddd7\udad7\udff7\udaef\ude0a\udb1a\udeda\ud8f3\udc69\udbc5\udcf3\ud866\udf45\udac3\udfec\udb41\udded\uda48\ude89\udb76\udd8d", "\u1c8d\u18f6\ua7f8\u9b5f\u14ec\ud3bb\u5eca\ucd26\u37a8\u409a\u2abc\u941f\u5d86\u7c4a\u5026\u7995\u58f3\u8a17\u4f04\u3e84\u9a2a", "\udb59\udcd5\udaa4\udd24\udbea\udeda\ud922\udc30\udad6\ude4a\uda78\uddb3\udae9\ude30\uda80\udfb8\ud8a8\ude02",
        -3, 48450, 492856175, -3028062694330504073L, 42221L, false, false, (char) 43774, (char) 9787,
        Double.longBitsToDouble(0x3fb8ab569af6c2b0L), Double.longBitsToDouble(0x3fcbc1df7a350a4cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 0, "\ud824\ude84\udbbc\udfaa\uda1f\udeb2", "\u33bd\u42eb", "\udb67\udeff\u26db\ud9da\udc3c\ud910\uddb1\udb7d\udf5b\udaad\udd02\uda28\udce1\ud855\ude3b\udbc2\udd44\ud9fb\udf1d\ud9d5\udf96",
        2, 46535, -1399557543, 3798880679314421145L, 26282L, false, false, (char) 9715, (char) 18682,
        Double.longBitsToDouble(0x3febd2a67bc5ebefL), Double.longBitsToDouble(0x3fc01fec13117214L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 1, 1, "\ud83d\udd76\ud935\udce9\udb29\udc8b\ud9a1\udc71\uda6a\udcae\udad9\udd75\ud852\udfbe\udb0c\udfd5\ud8cb\uddf6\udb41\ude36\ud963\udd1e\ufa03\ud824\udc8a\uda83\ude6c\udb14\ude38\ufc3e\udbc7\udea4\udad7\udff7\udb92\udfc6\udb04\udf2f\ud8f3\udce5\ud9fd\udff0\ud9e3\udd4d\udb4c\udcb0\udb47\ude5e\udbac\ude2d\ud8a9\udd88\uda8c\udd25\udbd0\udc30\ud995\udef6\udb80\udfd8\udbe6\udfbd\ud932\ude1d\u1ddd\udaae\udf80\ud1a3\ud8cb\udfd2\u315f\ud9d4\ude96\ud81a\udea4\ud867\udff0\ud99f\udc7d\udbb8\ude0c\ud85f\udf67\udbba\udce9\udbaa\udf87\udad5\udff1", "\u73f5\u0617\u57b4\u5677\u32eb\u57ee\u56ea\u334c\u4984\u6cc7\u5dea\u082d\u810e\u2c46\u473a\u4fb2\ud195\ua0ca\u8764\u0452\u4d9d\ucbd3\u1238\ubdc2\u3779\u9910\u39a9", "\ud9b3\udc4c\ud84f\udf48\ud818\udd65\uda60\udf7d\ud944\udef9\udae6\udeed\udb48\uddba\udab7\udf61\udb48\udf1b\ud919\udeb7\udb75\uddf0\ud8f9\udc27\ud83a\udfcb\ud958\udc3d\ud894\uddda\uda50\ude3b\ud9a7\udc3e\ud897\udec0\udb8a\uddc9\uda89\udcf4\udaff\udf7e\udb65\udc3e\u8b1c\uda8d\udefb\uda04\udc88\ud941\uddf1\ud01b\ud8d3\udcbc\udba9\udfdc\ud9de\ude7f\u71ac\udb54\udfed\udb5d\udc59\udbd4\ude6b\ud885\udf05\uda6a\ude1f\ud8ac\udf13\uafa1\udbea\udf65\uda38\uddf6\ud878\ude78\udafe\uddca\u6a22\ud901\uddc8\ud93a\udce1\udaf2\udd06\uda2c\udcf9\ud95d\udc2a\uda3c\udd97\uda6e\udd84\ud812\udfdf\ud842\udecb\uda11\udfe4\udb77\udc1f\udbba\udf3e",
        32, 20983, 1547602545, -2382602889398070749L, 44036L, false, true, (char) 43311, (char) 31285,
        Double.longBitsToDouble(0x3fe98e49dd628571L), Double.longBitsToDouble(0x3f82c29dcca65400L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.LookupTranslator|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.LookupTranslator:[[Ljava.lang.CharSequence;",
    "C|org.apache.commons.lang3.text.translate.LookupTranslator|<init>|[[Ljava.lang.CharSequence;",
    "M|org.apache.commons.lang3.text.translate.LookupTranslator|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.LookupTranslator:[[Ljava.lang.CharSequence;",
    "C|org.apache.commons.lang3.text.translate.LookupTranslator|<init>|[[Ljava.lang.CharSequence;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
