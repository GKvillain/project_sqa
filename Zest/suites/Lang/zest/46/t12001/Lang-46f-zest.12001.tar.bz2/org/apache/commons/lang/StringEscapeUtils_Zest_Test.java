package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringEscapeUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud981\udfc4\ud906\udc7e\udba4\udf24\ud8f1\udccd\udbe3\udca8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD981\\uDFC4\\uD906\\uDC7E\\uDBA4\\uDF24\\uD8F1\\uDCCD\\uDBE3\\uDCA8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8ee\udc58\uda6e\udd43\udba4\ude62\ud8f1\udccd\udbe3\udca8\uda48\udd92\udaa5\ude77\ud83b\udd58\ud936\uded9\ud91d\udf41\udb69\udfb6\uda2c\udd82\udac8\udeda\udb27\ude5a\uda44\udce0\uf8f5\ud83a\udc77");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8EE\\uDC58\\uDA6E\\uDD43\\uDBA4\\uDE62\\uD8F1\\uDCCD\\uDBE3\\uDCA8\\uDA48\\uDD92\\uDAA5\\uDE77\\uD83B\\uDD58\\uD936\\uDED9\\uD91D\\uDF41\\uDB69\\uDFB6\\uDA2C\\uDD82\\uDAC8\\uDEDA\\uDB27\\uDE5A\\uDA44\\uDCE0\\uF8F5\\uD83A\\uDC77", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ub9b6\udb69\udfae\ud8ec\uddde\udaa9\uded8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uB9B6\\uDB69\\uDFAE\\uD8EC\\uDDDE\\uDAA9\\uDED8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud981\udfc4\ud906\udc7e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD981\\uDFC4\\uD906\\uDC7E", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud94e\udf3e\ud89c\udfad\uda75\udf0a\ud8c5\ude17\ud84d\uddeb\uda0d\ude55\ud8e2\udc57\ud8e9\uded1\ud93b\uded1\ud949\udc5f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD94E\\uDF3E\\uD89C\\uDFAD\\uDA75\\uDF0A\\uD8C5\\uDE17\\uD84D\\uDDEB\\uDA0D\\uDE55\\uD8E2\\uDC57\\uD8E9\\uDED1\\uD93B\\uDED1\\uD949\\uDC5F", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9d9\udcb8\ud906\udc7e\u00d8\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9D9\\uDCB8\\uD906\\uDC7E\\u00D8\\u0000\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udae1\udceb\ud8a5\uddaa\udac1\udde9\u07bd\uda0f\ude62");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDAE1\\uDCEB\\uD8A5\\uDDAA\\uDAC1\\uDDE9\\u07BD\\uDA0F\\uDE62", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\u6a5c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u6A5C", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\uda20\ude0b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA20\\uDE0B", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud971\udc77\ud906\udc7e\u28d8\000\udbbf\udf3e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD971\\uDC77\\uD906\\uDC7E\\u28D8\\u0000\\uDBBF\\uDF3E", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\udae2\uddb1\u00d8\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\uDAE2\\uDDB1\\u00D8\\u0000\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb3c\udf31\udb02\uddb8\udba9\udcfd\udbcb\udfbe\udae3\udccc\udac2\udf78\ud9a0\uddee\udb88\udefb\ud9f9\udc05\ud89f\udd43\udb98\udfe4\udb79\udefa\udae4\udf27\ud988\udf35\udb3e\ude40\udb1d\udd91\ud8ff\udee8\ud9ca\udfb9\ud957\udfaf\udacd\udf1c\ud895\ude93\udb06\udfa7\ud988\udf69\u9729\udb09\uddfe\udb4a\udc8b\ud83c\udda0\udbca\udce6\udafa\udece\udbb2\ude7a\udaaf\uddf0\udb96\udce0\ud822\ude89\ud8a6\udc6e\udbe8\uddd2\uda7f\udc92\ud8bc\udf0f\ud93f\udcb3\ud83b\uddc9\ud870\udd90\udb1d\udd7d\ud811\udef6\ud80c\udf59\udb9a\udc55\ud873\udc4d\uda83\udf6d\ud8cd\udd3a\udb50\udfc6\ud8be\udd06\ud923\udd6e\ud852\udded\udaa8\udfff\ud8f4\udefb\ud946\udd08\ud857\ude2d\ud8b0\udcc1\ud94f\udeb0\ud85e\udf05\uda64\ude07\ue74f\uda4a\ude5d\udbe7\uddb4\ud8ed\ude73\udb26\udf00\udb3e\ude26\ud8cb\udf63\ud958\udf60\ud987\udc95");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB3C\\uDF31\\uDB02\\uDDB8\\uDBA9\\uDCFD\\uDBCB\\uDFBE\\uDAE3\\uDCCC\\uDAC2\\uDF78\\uD9A0\\uDDEE\\uDB88\\uDEFB\\uD9F9\\uDC05\\uD89F\\uDD43\\uDB98\\uDFE4\\uDB79\\uDEFA\\uDAE4\\uDF27\\uD988\\uDF35\\uDB3E\\uDE40\\uDB1D\\uDD91\\uD8FF\\uDEE8\\uD9CA\\uDFB9\\uD957\\uDFAF\\uDACD\\uDF1C\\uD895\\uDE93\\uDB06\\uDFA7\\uD988\\uDF69\\u9729\\uDB09\\uDDFE\\uDB4A\\uDC8B\\uD83C\\uDDA0\\uDBCA\\uDCE6\\uDAFA\\uDECE\\uDBB2\\uDE7A\\uDAAF\\uDDF0\\uDB96\\uDCE0\\uD822\\uDE89\\uD8A6\\uDC6E\\uDBE8\\uDDD2\\uDA7F\\uDC92\\uD8BC\\uDF0F\\uD93F\\uDCB3\\uD83B\\uDDC9\\uD870\\uDD90\\uDB1D\\uDD7D\\uD811\\uDEF6\\uD80C\\uDF59\\uDB9A\\uDC55\\uD873\\uDC4D\\uDA83\\uDF6D\\uD8CD\\uDD3A\\uDB50\\uDFC6\\uD8BE\\uDD06\\uD923\\uDD6E\\uD852\\uDDED\\uDAA8\\uDFFF\\uD8F4\\uDEFB\\uD946\\uDD08\\uD857\\uDE2D\\uD8B0\\uDCC1\\uD94F\\uDEB0\\uD85E\\uDF05\\uDA64\\uDE07\\uE74F\\uDA4A\\uDE5D\\uDBE7\\uDDB4\\uD8ED\\uDE73\\uDB26\\uDF00\\uDB3E\\uDE26\\uD8CB\\uDF63\\uD958\\uDF60\\uD987\\uDC95", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9c3\udfae\udb91\udf87\u084f\ud912\udc16\udbe3\udca8\udba7\udf6a\ud8c1\udf63\uda80\udd85\uda3d\udf4e\ud86c\udd2b\ud9a5\udf9e\ud907\udc57\udba8\udc79\ud949\udfa4\ud9a8\udd62\udbb1\udf5c\udaf0\udf3f\ud972\udc2d\ud9a0\udce5\uda7b\udd73\uda09\udcc6\udbca\udc47\udb9d\ude97\ud807\udee5\ud970\udd0c\udab0\udf30\uda9b\ude8d\udaba\udf95\uda3a\udf8a\udbb5\udefc\uda9d\uded9\ud929\ude23\udab4\udd4e");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9C3\\uDFAE\\uDB91\\uDF87\\u084F\\uD912\\uDC16\\uDBE3\\uDCA8\\uDBA7\\uDF6A\\uD8C1\\uDF63\\uDA80\\uDD85\\uDA3D\\uDF4E\\uD86C\\uDD2B\\uD9A5\\uDF9E\\uD907\\uDC57\\uDBA8\\uDC79\\uD949\\uDFA4\\uD9A8\\uDD62\\uDBB1\\uDF5C\\uDAF0\\uDF3F\\uD972\\uDC2D\\uD9A0\\uDCE5\\uDA7B\\uDD73\\uDA09\\uDCC6\\uDBCA\\uDC47\\uDB9D\\uDE97\\uD807\\uDEE5\\uD970\\uDD0C\\uDAB0\\uDF30\\uDA9B\\uDE8D\\uDABA\\uDF95\\uDA3A\\uDF8A\\uDBB5\\uDEFC\\uDA9D\\uDED9\\uD929\\uDE23\\uDAB4\\uDD4E", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("M\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("M\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud978\udcc0\udb6e\udc32\uda02\ude33\ud90a\udcb4\ud9fe\uddf6\ud9fe\ude4b\ud85f\udecd\uda22\udc04\ud9fb\udd7b\ud844\udf1d\udb2d\uddd9\u2e56\ud89b\udf36\ud8da\udf7d\udbf6\udf50\u01af\udbc1\udc3c\udbd2\udf11\uda71\udf5a\u0bc4\uda9e\udce3\ud899\udfa4\udb1f\ude87\udb2a\ude6e\ud86c\ude56\uda5c\udc85\ud87d\udd6c\udba1\ude7e\udbf4\udd96\udafa\udf27\ud8e0\udc20\uda0e\uddde");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD978\\uDCC0\\uDB6E\\uDC32\\uDA02\\uDE33\\uD90A\\uDCB4\\uD9FE\\uDDF6\\uD9FE\\uDE4B\\uD85F\\uDECD\\uDA22\\uDC04\\uD9FB\\uDD7B\\uD844\\uDF1D\\uDB2D\\uDDD9\\u2E56\\uD89B\\uDF36\\uD8DA\\uDF7D\\uDBF6\\uDF50\\u01AF\\uDBC1\\uDC3C\\uDBD2\\uDF11\\uDA71\\uDF5A\\u0BC4\\uDA9E\\uDCE3\\uD899\\uDFA4\\uDB1F\\uDE87\\uDB2A\\uDE6E\\uD86C\\uDE56\\uDA5C\\uDC85\\uD87D\\uDD6C\\uDBA1\\uDE7E\\uDBF4\\uDD96\\uDAFA\\uDF27\\uD8E0\\uDC20\\uDA0E\\uDDDE", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\u0000\\u0000\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb6a\udd4e\ud906\udc7e\u00d8\udb30\udfa9\016");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB6A\\uDD4E\\uD906\\uDC7E\\u00D8\\uDB30\\uDFA9\\u000E", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9d9\udcb8\uda13\udf6a\025\ud96d\udf65\udb27\udff8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9D9\\uDCB8\\uDA13\\uDF6A\\u0015\\uD96D\\uDF65\\uDB27\\uDFF8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9d9\udc76\ud906\udc7e\u00d8\udb6a\udc7b\u0080");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9D9\\uDC76\\uD906\\uDC7E\\u00D8\\uDB6A\\uDC7B\\u0080", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9ce\udec6\ud858\udf18\udb9d\udf2c\002\ud967\udf12");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9CE\\uDEC6\\uD858\\uDF18\\uDB9D\\uDF2C\\u0002\\uD967\\uDF12", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8e6\uddd0\ud906\udc2e\uf2d6/\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8E6\\uDDD0\\uD906\\uDC2E\\uF2D6/\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9d9\udcb8\ud898\udd47Y\0005");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9D9\\uDCB8\\uD898\\uDD47Y\\u00005", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\uda77\udcce\udaae\ude41\005\udaf9\udcdc\ud8b2\uddc5");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA77\\uDCCE\\uDAAE\\uDE41\\u0005\\uDAF9\\uDCDC\\uD8B2\\uDDC5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\001\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0001\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud978\udcc0\udb6e\udc32\uda02\ude33\034\ud9fe\udd8c\ud9fe\ude4b\ud90b\udec3\000\000\000\000\000\ud89b\udeca\ud8da\udf7d\ud9c6\udc02\000\000\000\000\ud8fc\ude3d\uda95\udee3\ud899\udfa4\udb1f\ude87\000\000\000\udb58\udc0b\udba1\ude7e\udb45\ude3e\uda76\udc05\ud8a4\uddf1\uda0e\uddde");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD978\\uDCC0\\uDB6E\\uDC32\\uDA02\\uDE33\\u001C\\uD9FE\\uDD8C\\uD9FE\\uDE4B\\uD90B\\uDEC3\\u0000\\u0000\\u0000\\u0000\\u0000\\uD89B\\uDECA\\uD8DA\\uDF7D\\uD9C6\\uDC02\\u0000\\u0000\\u0000\\u0000\\uD8FC\\uDE3D\\uDA95\\uDEE3\\uD899\\uDFA4\\uDB1F\\uDE87\\u0000\\u0000\\u0000\\uDB58\\uDC0B\\uDBA1\\uDE7E\\uDB45\\uDE3E\\uDA76\\uDC05\\uD8A4\\uDDF1\\uDA0E\\uDDDE", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud999\udf66\udb93\ude1d\034\u3cab\016\ud94e\udc8a\ud91a\udca4\uda48\uddb3\ud97f\udfed\udb15\uddc0\udb41\udcf4\udb74\udcef\ud962\udf60\ud837\udfa7\udb2b\udcb7\udb04\udec3\ud9c5\ude05\ud903\uddcf\uda15\udf90\uda65\udcd9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD999\\uDF66\\uDB93\\uDE1D\\u001C\\u3CAB\\u000E\\uD94E\\uDC8A\\uD91A\\uDCA4\\uDA48\\uDDB3\\uD97F\\uDFED\\uDB15\\uDDC0\\uDB41\\uDCF4\\uDB74\\uDCEF\\uD962\\uDF60\\uD837\\uDFA7\\uDB2B\\uDCB7\\uDB04\\uDEC3\\uD9C5\\uDE05\\uD903\\uDDCF\\uDA15\\uDF90\\uDA65\\uDCD9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9d9\udcb8\uda3d\udc5e\\\ud96d\udf65\udb27\udff8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9D9\\uDCB8\\uDA3D\\uDC5E\\\\\\uD96D\\uDF65\\uDB27\\uDFF8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("'@");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("'@", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9d9\udcb4\udb6e\udc32\uda02\ude33\034\ud9fe\udd8c\ud9fe\udd6d\ud90b\udec3\000\000\000\000\000\ud89b\udeca\ud8da\udf7d\000\000\000\000\000\ud8fc\ude3dz\ud88f\udfc7\udb1f\ude87\000\000\000\udb58\udc0b\udba1\ude7e5\uda76\udc05\udb06\udde2\uda0e\uddde");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9D9\\uDCB4\\uDB6E\\uDC32\\uDA02\\uDE33\\u001C\\uD9FE\\uDD8C\\uD9FE\\uDD6D\\uD90B\\uDEC3\\u0000\\u0000\\u0000\\u0000\\u0000\\uD89B\\uDECA\\uD8DA\\uDF7D\\u0000\\u0000\\u0000\\u0000\\u0000\\uD8FC\\uDE3Dz\\uD88F\\uDFC7\\uDB1F\\uDE87\\u0000\\u0000\\u0000\\uDB58\\uDC0B\\uDBA1\\uDE7E5\\uDA76\\uDC05\\uDB06\\uDDE2\\uDA0E\\uDDDE", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("I\000\uda02\ude33\034\ud9fe\udd8c\ud9fe\udd6d\ud90b\udec3\000\000\000\000\000\000\udba8\udc74\000\000\000\000\000\ud8fc\ude3dz\ud88f\udfc7\udb1f\ude87\000\000\000\udb58\udc0b\udba1\ude7e5\uda76\udc05\udb06\udde2\uda0e\uddde");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("I\\u0000\\uDA02\\uDE33\\u001C\\uD9FE\\uDD8C\\uD9FE\\uDD6D\\uD90B\\uDEC3\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uDBA8\\uDC74\\u0000\\u0000\\u0000\\u0000\\u0000\\uD8FC\\uDE3Dz\\uD88F\\uDFC7\\uDB1F\\uDE87\\u0000\\u0000\\u0000\\uDB58\\uDC0B\\uDBA1\\uDE7E5\\uDA76\\uDC05\\uDB06\\uDDE2\\uDA0E\\uDDDE", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("I\000\000\000\000\000\000\000\000\000\000\000\000\ud8da\udf7d\000\000\000\000\000\ud8fc\ude3dz\ud88f\udfc7\udb1f\ude87\000\000\000\000\udb99\ude4b5\uda76\udc05\udb06\udde2\ud98e\uddd7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("I\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uD8DA\\uDF7D\\u0000\\u0000\\u0000\\u0000\\u0000\\uD8FC\\uDE3Dz\\uD88F\\uDFC7\\uDB1F\\uDE87\\u0000\\u0000\\u0000\\u0000\\uDB99\\uDE4B5\\uDA76\\uDC05\\uDB06\\uDDE2\\uD98E\\uDDD7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb12\udc75\udb57\udc48\uda02\ude33\034\ud9fe\udd8c\ud9fe\udd6d\ud90b\udec3\000\000\udbce\udcd3\uda6e\uddab\021\ud89b\udeca\ud8da\udf7d\000\000\udb85\udc01\ud989\udf8c\u0092\ud8fc\ude3dz\ud88f\udfc7\udb1f\ude87\000\000\udb44\udc6f\ud903\udeb3\udba1\udef15\uda76\udc05\udb06\udde2\ud96e\udde0");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB12\\uDC75\\uDB57\\uDC48\\uDA02\\uDE33\\u001C\\uD9FE\\uDD8C\\uD9FE\\uDD6D\\uD90B\\uDEC3\\u0000\\u0000\\uDBCE\\uDCD3\\uDA6E\\uDDAB\\u0011\\uD89B\\uDECA\\uD8DA\\uDF7D\\u0000\\u0000\\uDB85\\uDC01\\uD989\\uDF8C\\u0092\\uD8FC\\uDE3Dz\\uD88F\\uDFC7\\uDB1F\\uDE87\\u0000\\u0000\\uDB44\\uDC6F\\uD903\\uDEB3\\uDBA1\\uDEF15\\uDA76\\uDC05\\uDB06\\uDDE2\\uD96E\\uDDE0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("I\000\uda02\ude33C\ud9fe\udd8c\ud9fe\udd6d\ud90b\udec3\000\000\000\udb85\udc01\uda87\udcad\udb88\udcec\udb06\udfdc\u00fc\000\000\000\000\ud8fc\ude3dz\ud894\ude8b\udb1f\ude87\uda23\ude42\u00a0\000\udb6a\udd0b\udba1\ude7e5\uda76\udc05\udbf8\udd9e\ud9f3\udc3f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("I\\u0000\\uDA02\\uDE33C\\uD9FE\\uDD8C\\uD9FE\\uDD6D\\uD90B\\uDEC3\\u0000\\u0000\\u0000\\uDB85\\uDC01\\uDA87\\uDCAD\\uDB88\\uDCEC\\uDB06\\uDFDC\\u00FC\\u0000\\u0000\\u0000\\u0000\\uD8FC\\uDE3Dz\\uD894\\uDE8B\\uDB1F\\uDE87\\uDA23\\uDE42\\u00A0\\u0000\\uDB6A\\uDD0B\\uDBA1\\uDE7E5\\uDA76\\uDC05\\uDBF8\\uDD9E\\uD9F3\\uDC3F", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud981\udf79\ud906\udc7e\udba4\udf24\ud8f1\udccd\udbe3\udca8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD981\\uDF79\\uD906\\uDC7E\\uDBA4\\uDF24\\uD8F1\\uDCCD\\uDBE3\\uDCA8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9d9\udcb8\ud906\udc7e\004\uda1b\udfed\ud95d\udc31");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9D9\\uDCB8\\uD906\\uDC7E\\u0004\\uDA1B\\uDFED\\uD95D\\uDC31", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud819\udcd2\uda8d\udff4\"\uda20\udd0f\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD819\\uDCD2\\uDA8D\\uDFF4\\\"\\uDA20\\uDD0F\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud86e\uddf3\003");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD86E\\uDDF3\\u0003", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud86e\udc93\u00b1\uda02\ude33\ud98a\udccb\udae8\udc31\ud9cf\udd39\udb71\udd93\ud982\udda2\000\000\udae4\ude20\ud9d4\udfd8\ud988\ude2a\ud89e\ude56\u00fc\uda3d\udc9d9\ud400\uda46\uddb0\udbcb\uddb0\ud9dc\uddfe\ud894\ude53\udb1f\ude87\uda23\ude42\u00a0\u00e6\ud908\udddb\udba1\ude7e\udb56\udc3f\udbea\udeb1\udbca\udc11\ud95b\ude0d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD86E\\uDC93\\u00B1\\uDA02\\uDE33\\uD98A\\uDCCB\\uDAE8\\uDC31\\uD9CF\\uDD39\\uDB71\\uDD93\\uD982\\uDDA2\\u0000\\u0000\\uDAE4\\uDE20\\uD9D4\\uDFD8\\uD988\\uDE2A\\uD89E\\uDE56\\u00FC\\uDA3D\\uDC9D9\\uD400\\uDA46\\uDDB0\\uDBCB\\uDDB0\\uD9DC\\uDDFE\\uD894\\uDE53\\uDB1F\\uDE87\\uDA23\\uDE42\\u00A0\\u00E6\\uD908\\uDDDB\\uDBA1\\uDE7E\\uDB56\\uDC3F\\uDBEA\\uDEB1\\uDBCA\\uDC11\\uD95B\\uDE0D", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud819\udcf7\uda8d\udff4\"\udbf8\udc1b\"");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD819\\uDCF7\\uDA8D\\uDFF4\\\"\\uDBF8\\uDC1B\\\"", String.valueOf(r));
  }
}
