package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringEscapeUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udabd\udf03\ud9b4\udd8f\uda41\udfbe\ud8c4\udc85\udaf3\ude0e\uda01\ude11\udaa4\ude3e\ud998\ude16\ud86b\udfe2\ud881\udca1\uda34\udca7\uda7d\udc4b\udae5\udd83\udaa2\udf40\ud9ad\udfd3\ud9e6\udd9d\ud810\udf7a\udad4\uddb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDABD\\uDF03\\uD9B4\\uDD8F\\uDA41\\uDFBE\\uD8C4\\uDC85\\uDAF3\\uDE0E\\uDA01\\uDE11\\uDAA4\\uDE3E\\uD998\\uDE16\\uD86B\\uDFE2\\uD881\\uDCA1\\uDA34\\uDCA7\\uDA7D\\uDC4B\\uDAE5\\uDD83\\uDAA2\\uDF40\\uD9AD\\uDFD3\\uD9E6\\uDD9D\\uD810\\uDF7A\\uDAD4\\uDDB4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udabd\udf03\uda7f\uddd1\uda41\udfbe\udb13\udf54\udb04\udfe6\uda01\ude11\udaa4\ude3e\ud998\ude16\ud86b\udfe2\ud8a6\ude5c\uda34\udca7\uda7d\udc4b\udae5\udd83\udaa2\udf40\ud9ad\udfd3\ud9e6\udd9d\ud82d\ude7a\udad4\uddb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDABD\\uDF03\\uDA7F\\uDDD1\\uDA41\\uDFBE\\uDB13\\uDF54\\uDB04\\uDFE6\\uDA01\\uDE11\\uDAA4\\uDE3E\\uD998\\uDE16\\uD86B\\uDFE2\\uD8A6\\uDE5C\\uDA34\\uDCA7\\uDA7D\\uDC4B\\uDAE5\\uDD83\\uDAA2\\uDF40\\uD9AD\\uDFD3\\uD9E6\\uDD9D\\uD82D\\uDE7A\\uDAD4\\uDDB4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udabd\udf03\u23fa\000\000\000\ud932\udc08\000\ud998\ude16\ud86b\udfe2\000\uda33\udfbe\uda15\udd97\000\000\000\000\u2100\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDABD\\uDF03\\u23FA\\u0000\\u0000\\u0000\\uD932\\uDC08\\u0000\\uD998\\uDE16\\uD86B\\uDFE2\\u0000\\uDA33\\uDFBE\\uDA15\\uDD97\\u0000\\u0000\\u0000\\u0000\\u2100\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\ud9fb\udfd8\ud96c\udd5b\ud8c5\ude73");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uD9FB\\uDFD8\\uD96C\\uDD5B\\uD8C5\\uDE73", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\ud91a\udd87\udbca\udff2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uD91A\\uDD87\\uDBCA\\uDFF2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud189\uda0b\udf9f\ud831\udefd\ud9b4\udd8f9\ud8c4\udc85\udaf3\ude0e\uda01\ude11\udaa4\ude3e\ud826\udd12\udbe7\udf3f\ud881\udc5d\uda34\udca7\uda7d\udc4b\udae5\udd83\udaa2\udf40\ud9ad\udfd3\ud9e6\udd9d\ud810\udf7a\udad4\uddb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD189\\uDA0B\\uDF9F\\uD831\\uDEFD\\uD9B4\\uDD8F9\\uD8C4\\uDC85\\uDAF3\\uDE0E\\uDA01\\uDE11\\uDAA4\\uDE3E\\uD826\\uDD12\\uDBE7\\uDF3F\\uD881\\uDC5D\\uDA34\\uDCA7\\uDA7D\\uDC4B\\uDAE5\\uDD83\\uDAA2\\uDF40\\uD9AD\\uDFD3\\uD9E6\\uDD9D\\uD810\\uDF7A\\uDAD4\\uDDB4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud9b3\udcfc\ud841\udd5c\udabe\uddee\ud9b4\udd8f\udbc7\udf3c\ud905\udca5\udaf3\ude1e\uda44\ude93\udb41\ude8e\ud98e\udea9\ud95c\udc11\ud888\uddca\uda34\udca7\ud816\udcf7\udae5\udd83\uda68\udd23\ud9c7\udf17\ud9e6\udd9d\ud810\udf91\udad4\uddb4\udbaf\udd8a\ud94b\ude72\uda85\udd53\udb0d\udf9a\ud9ca\udd62\uda1f\ude75\udb42\udf7e\ud803\ude77\uda2c\udfdb\ud908\uddac\ud9fe\udfda\udba8\udd71\udbe8\udecd");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD9B3\\uDCFC\\uD841\\uDD5C\\uDABE\\uDDEE\\uD9B4\\uDD8F\\uDBC7\\uDF3C\\uD905\\uDCA5\\uDAF3\\uDE1E\\uDA44\\uDE93\\uDB41\\uDE8E\\uD98E\\uDEA9\\uD95C\\uDC11\\uD888\\uDDCA\\uDA34\\uDCA7\\uD816\\uDCF7\\uDAE5\\uDD83\\uDA68\\uDD23\\uD9C7\\uDF17\\uD9E6\\uDD9D\\uD810\\uDF91\\uDAD4\\uDDB4\\uDBAF\\uDD8A\\uD94B\\uDE72\\uDA85\\uDD53\\uDB0D\\uDF9A\\uD9CA\\uDD62\\uDA1F\\uDE75\\uDB42\\uDF7E\\uD803\\uDE77\\uDA2C\\uDFDB\\uD908\\uDDAC\\uD9FE\\uDFDA\\uDBA8\\uDD71\\uDBE8\\uDECD", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\uda5f\udea7\uda0b\udfe0\udabd\udf03\ud8fb\udf92\ud9d8\udcf6\ud900\udf23\udaf3\ude0e\uda01\ude11\udaa4\ude3e\ud998\ude16\ud86b\udfe2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA5F\\uDEA7\\uDA0B\\uDFE0\\uDABD\\uDF03\\uD8FB\\uDF92\\uD9D8\\uDCF6\\uD900\\uDF23\\uDAF3\\uDE0E\\uDA01\\uDE11\\uDAA4\\uDE3E\\uD998\\uDE16\\uD86B\\uDFE2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udabd\udf03\ud9b4\udd8f\uda41\udfbe\000\ud9ff\udeff\uda01\ude11\udaa4\ude3e\ud998\ude16\ud86b\udfe2\ud881\udca1\uda34\udca7\uda7d\udc4b\udae5\udd83\udaa2\udf40\ud9ad\udfd3\ud9e6\udd9d\ud810\udf7a\udad4\uddb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDABD\\uDF03\\uD9B4\\uDD8F\\uDA41\\uDFBE\\u0000\\uD9FF\\uDEFF\\uDA01\\uDE11\\uDAA4\\uDE3E\\uD998\\uDE16\\uD86B\\uDFE2\\uD881\\uDCA1\\uDA34\\uDCA7\\uDA7D\\uDC4B\\uDAE5\\uDD83\\uDAA2\\uDF40\\uD9AD\\uDFD3\\uD9E6\\uDD9D\\uD810\\uDF7A\\uDAD4\\uDDB4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\uda65\udff2\uda0b\udfe0\uda82\udf6a\ud949\udef1\uda7f\ude36\ud8e2\udfc0\udaf3\ude0e\ud962\udc19\u17a5\ud99e\udfb3\ud869\ude37\ud881\udca1\uda2a\udd94\ud9db\uded8\udbd1\udc08\u0a96\ubca6\uda62\udf92\ud810\udf7a\ud8bf\udcea");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA65\\uDFF2\\uDA0B\\uDFE0\\uDA82\\uDF6A\\uD949\\uDEF1\\uDA7F\\uDE36\\uD8E2\\uDFC0\\uDAF3\\uDE0E\\uD962\\uDC19\\u17A5\\uD99E\\uDFB3\\uD869\\uDE37\\uD881\\uDCA1\\uDA2A\\uDD94\\uD9DB\\uDED8\\uDBD1\\uDC08\\u0A96\\uBCA6\\uDA62\\uDF92\\uD810\\uDF7A\\uD8BF\\uDCEA", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udabd\udf03\ud9b4\udd8f9\ud8c3\udfa0\udaf3\ude0e\u00a1\000\ud998\ude16\ud86b\udfe2\ud881\udca1\uda34\udca7\uda7d\udc4b\udae5\udd83\udaa2\udf40\ud9ad\udfd3\ud9e6\udd9d\ud810\udf7a\udad4\uddb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDABD\\uDF03\\uD9B4\\uDD8F9\\uD8C3\\uDFA0\\uDAF3\\uDE0E\\u00A1\\u0000\\uD998\\uDE16\\uD86B\\uDFE2\\uD881\\uDCA1\\uDA34\\uDCA7\\uDA7D\\uDC4B\\uDAE5\\uDD83\\uDAA2\\uDF40\\uD9AD\\uDFD3\\uD9E6\\uDD9D\\uD810\\uDF7A\\uDAD4\\uDDB4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5cA\udabd\udf03\ud9b4\udd8f\000\ud992\udc08\udaf3\ude0c\uda01\ude11\udaa4\ude3e\ud998\ude16\ud86b\udfe2\u1144\000\000\000\ud951\udd0d\ud9ad\udf64\ud9e6\udd9d\ud810\udf7a\udad4\uddb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5CA\\uDABD\\uDF03\\uD9B4\\uDD8F\\u0000\\uD992\\uDC08\\uDAF3\\uDE0C\\uDA01\\uDE11\\uDAA4\\uDE3E\\uD998\\uDE16\\uD86B\\uDFE2\\u1144\\u0000\\u0000\\u0000\\uD951\\uDD0D\\uD9AD\\uDF64\\uD9E6\\uDD9D\\uD810\\uDF7A\\uDAD4\\uDDB4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udabd\udf03\ud9b4\udd8f\uda41\udfbe\ud8c4\udc85\ud8b5\udf0f\000\uda6c\udeb6\ud998\ude16\udbe7\udf3f\ud881\udca1\uda34\udca7\u0094\000\uda6d\uddb5\ud9ad\udfd3\ud9e6\udd9d\u2136\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDABD\\uDF03\\uD9B4\\uDD8F\\uDA41\\uDFBE\\uD8C4\\uDC85\\uD8B5\\uDF0F\\u0000\\uDA6C\\uDEB6\\uD998\\uDE16\\uDBE7\\uDF3F\\uD881\\uDCA1\\uDA34\\uDCA7\\u0094\\u0000\\uDA6D\\uDDB5\\uD9AD\\uDFD3\\uD9E6\\uDD9D\\u2136\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1b\udfd3\uda9d\udf49\udaac\udc15\000\ud9c8\udd84\ud8c4\udc85\udaf3\ude0e\u00a1\udaa4\ude3e\ud998\ude16\ud884\udca2\ud881\udca1\uda34\udca7\u0094");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1B\\uDFD3\\uDA9D\\uDF49\\uDAAC\\uDC15\\u0000\\uD9C8\\uDD84\\uD8C4\\uDC85\\uDAF3\\uDE0E\\u00A1\\uDAA4\\uDE3E\\uD998\\uDE16\\uD884\\uDCA2\\uD881\\uDCA1\\uDA34\\uDCA7\\u0094", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5cA\000\ud9b4\udd8f\uda41\udfbe\ud8c4\udc85\u6702\uda01\udd70\udaa4\ude3e\ud998\ude16\ud86b\udfe2D\ud9ae\udfb6\u0094\udae5\udd83\udaa2\udf40\udb7a\udd79\000\ud810\udf7a\ud9b6\udf66");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5CA\\u0000\\uD9B4\\uDD8F\\uDA41\\uDFBE\\uD8C4\\uDC85\\u6702\\uDA01\\uDD70\\uDAA4\\uDE3E\\uD998\\uDE16\\uD86B\\uDFE2D\\uD9AE\\uDFB6\\u0094\\uDAE5\\uDD83\\uDAA2\\uDF40\\uDB7A\\uDD79\\u0000\\uD810\\uDF7A\\uD9B6\\uDF66", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\uda2c\uded9\ud9b4\udd06\uda41\udfbe\ud8c4\udc85\udafe\udf0e\uda01\ude11\udaa4\ude3e\ud998\ude16\ud86b\udfe2\ud881\udca1\uda34\udca7\uda7d\udc4b\udae5\udd83\udaa2\udf40\ud9a2\ude8e\ud85c\ude0a\uda3c\udeb3\udaaa\udcec\ud99e\ude2a\uda94\udff6\ud877\udc68\uda84\udf9b\ud93a\udc03\ud902\udf7d\udb70\ude57\ud88e\udf8a\uda86\udc16\ud9dc\udfdd\uda05\udcb3\uda93\udc68\ud818\udc0c\ud927\udd80\uda2e\ude77\udb07\udc64\udb8a\udf78\udba6\udf87\ud8ef\udd1d\ud8e3\ude56\udae5\udc05\ud904\udefd\udb89\udc43\udb10\udf45\uda83\udd08\ud95f\udc60\uda72\udec6\ud88b\udeae\uda8d\udd70\udbdc\udc09\ud983\udce6\uda7e\udefc\udb95\udf56\ud9c4\ude6e\uda7d\ude26\ud93b\udfce\udb39\udeff\ud831\udd94\ud875\udc6e\u775d\ud852\ude75\ud8d6\udf9a\ud9e2\udcfe\udb5f\udf27\udaf0\udf89\ud943\uddcf\uda8a\udf5b\udbc6\udde4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDA2C\\uDED9\\uD9B4\\uDD06\\uDA41\\uDFBE\\uD8C4\\uDC85\\uDAFE\\uDF0E\\uDA01\\uDE11\\uDAA4\\uDE3E\\uD998\\uDE16\\uD86B\\uDFE2\\uD881\\uDCA1\\uDA34\\uDCA7\\uDA7D\\uDC4B\\uDAE5\\uDD83\\uDAA2\\uDF40\\uD9A2\\uDE8E\\uD85C\\uDE0A\\uDA3C\\uDEB3\\uDAAA\\uDCEC\\uD99E\\uDE2A\\uDA94\\uDFF6\\uD877\\uDC68\\uDA84\\uDF9B\\uD93A\\uDC03\\uD902\\uDF7D\\uDB70\\uDE57\\uD88E\\uDF8A\\uDA86\\uDC16\\uD9DC\\uDFDD\\uDA05\\uDCB3\\uDA93\\uDC68\\uD818\\uDC0C\\uD927\\uDD80\\uDA2E\\uDE77\\uDB07\\uDC64\\uDB8A\\uDF78\\uDBA6\\uDF87\\uD8EF\\uDD1D\\uD8E3\\uDE56\\uDAE5\\uDC05\\uD904\\uDEFD\\uDB89\\uDC43\\uDB10\\uDF45\\uDA83\\uDD08\\uD95F\\uDC60\\uDA72\\uDEC6\\uD88B\\uDEAE\\uDA8D\\uDD70\\uDBDC\\uDC09\\uD983\\uDCE6\\uDA7E\\uDEFC\\uDB95\\uDF56\\uD9C4\\uDE6E\\uDA7D\\uDE26\\uD93B\\uDFCE\\uDB39\\uDEFF\\uD831\\uDD94\\uD875\\uDC6E\\u775D\\uD852\\uDE75\\uD8D6\\uDF9A\\uD9E2\\uDCFE\\uDB5F\\uDF27\\uDAF0\\uDF89\\uD943\\uDDCF\\uDA8A\\uDF5B\\uDBC6\\uDDE4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb24\udc5c\uda14\udee5\udabd\udf03\u23fa\000\000\ud9e8\udf94\ud877\uddbdt\ud998\ude16\ud86b\udfe2\000\uda33\udfbe\uda15\udd97\000\024\000\000\u2100\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB24\\uDC5C\\uDA14\\uDEE5\\uDABD\\uDF03\\u23FA\\u0000\\u0000\\uD9E8\\uDF94\\uD877\\uDDBDt\\uD998\\uDE16\\uD86B\\uDFE2\\u0000\\uDA33\\uDFBE\\uDA15\\uDD97\\u0000\\u0014\\u0000\\u0000\\u2100\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\ud872\udf3e\ud82d\ude87\002\ud84e\udfbc\u6f7a\ud932\udcd6\000\ud998\ude16\ud86b\udfe2\000\uda33\udfbe\uda15\udd97\ud80e\udf07\u5663\000\u3500\u21ff\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uD872\\uDF3E\\uD82D\\uDE87\\u0002\\uD84E\\uDFBC\\u6F7A\\uD932\\uDCD6\\u0000\\uD998\\uDE16\\uD86B\\uDFE2\\u0000\\uDA33\\uDFBE\\uDA15\\uDD97\\uD80E\\uDF07\\u5663\\u0000\\u3500\\u21FF\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\ud917\udff1\u23fa\000\000\000\ud932\udc08\000\ud998\ude16\ud86b\udfe2\000\uda33\udfbe\udb3c\ude8a\000\udb5d\udd1e\"\000\udbf4\ude51\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uD917\\uDFF1\\u23FA\\u0000\\u0000\\u0000\\uD932\\uDC08\\u0000\\uD998\\uDE16\\uD86B\\uDFE2\\u0000\\uDA33\\uDFBE\\uDB3C\\uDE8A\\u0000\\uDB5D\\uDD1E\\\"\\u0000\\uDBF4\\uDE51\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda51\udd23\udbcf\ude6a\ud81e\udc0d\ud98e\ude69\udb39\udc5a\uda11\ude3e\ud9c7\udd79\032\ud842\udc12\ud86b\udfe2\000\uda33\udfbe\uda15\udd97\ud8d4\udec3\ud9a1\udff2\\\000\ud84e\udeea");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA51\\uDD23\\uDBCF\\uDE6A\\uD81E\\uDC0D\\uD98E\\uDE69\\uDB39\\uDC5A\\uDA11\\uDE3E\\uD9C7\\uDD79\\u001A\\uD842\\uDC12\\uD86B\\uDFE2\\u0000\\uDA33\\uDFBE\\uDA15\\uDD97\\uD8D4\\uDEC3\\uD9A1\\uDFF2\\\\\\u0000\\uD84E\\uDEEA", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udac0\ude97\u23fa\ud913\ude85\004\000\u70fa\000\ud998\ude16\ud86b\udfe2\ud8d6\udf2a\ud9dc\udce4\ud94b\udfe7\000\000\udbe2\udf90\ud864\udce4\ud9c5\udd13\ud83e\udf34");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDAC0\\uDE97\\u23FA\\uD913\\uDE85\\u0004\\u0000\\u70FA\\u0000\\uD998\\uDE16\\uD86B\\uDFE2\\uD8D6\\uDF2A\\uD9DC\\uDCE4\\uD94B\\uDFE7\\u0000\\u0000\\uDBE2\\uDF90\\uD864\\uDCE4\\uD9C5\\uDD13\\uD83E\\uDF34", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud8f7\udeb0\uda0b\udfe0\udaaa\udc97\udba2\udeaa\ud9ca\uddcd\u7d96\u080f\ud932\udcf2\000\ud998\uddb0\ud826\udd9e\ud90f\udefa\u40b9\ud810\ude10\uda54\ude84\u5774\000\ud886\udf58\u0200\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD8F7\\uDEB0\\uDA0B\\uDFE0\\uDAAA\\uDC97\\uDBA2\\uDEAA\\uD9CA\\uDDCD\\u7D96\\u080F\\uD932\\uDCF2\\u0000\\uD998\\uDDB0\\uD826\\uDD9E\\uD90F\\uDEFA\\u40B9\\uD810\\uDE10\\uDA54\\uDE84\\u5774\\u0000\\uD886\\uDF58\\u0200\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ue7a0");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uE7A0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfb5\udabd\udf03\u23fa\udbca\udf25/\ud958\udf08\ud830\udd80\udad0\udcf3\ud84b\udf6e\ud8ac\udd6b\ud9af\udded\ud78e\ud8d5\udd97\ud86c\udf3a\000\000\000\u2100\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFB5\\uDABD\\uDF03\\u23FA\\uDBCA\\uDF25/\\uD958\\uDF08\\uD830\\uDD80\\uDAD0\\uDCF3\\uD84B\\uDF6E\\uD8AC\\uDD6B\\uD9AF\\uDDED\\uD78E\\uD8D5\\uDD97\\uD86C\\uDF3A\\u0000\\u0000\\u0000\\u2100\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\uda9c\udeb4\ud939\udc57\udaae\udc32\u23fa\ud90d\udca5\udb4e\udfe7\u694e\ud932\udc08\000\u29af\ud8d0\ude5f'\uda33\udfbe\uda15\udd97\000\000\000\000\u2100\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDA9C\\uDEB4\\uD939\\uDC57\\uDAAE\\uDC32\\u23FA\\uD90D\\uDCA5\\uDB4E\\uDFE7\\u694E\\uD932\\uDC08\\u0000\\u29AF\\uD8D0\\uDE5F'\\uDA33\\uDFBE\\uDA15\\uDD97\\u0000\\u0000\\u0000\\u0000\\u2100\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\000\ud820\udc0f\ud9b4\udd8f9\ud903\udec0\udaf3\ude1e\uda44\ude93\udb41\ude8e\u00c1\000\000\000\udbec\ude09\000\000\000\000\000\000\000\000\000\udb0d\udf9a\ud9ca\udd62\uda1f\ude75\u5408\udb9e\uddcf=\000\uda87\udfc3\u0090\udad8\udf0c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\uD820\\uDC0F\\uD9B4\\uDD8F9\\uD903\\uDEC0\\uDAF3\\uDE1E\\uDA44\\uDE93\\uDB41\\uDE8E\\u00C1\\u0000\\u0000\\u0000\\uDBEC\\uDE09\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\uDB0D\\uDF9A\\uD9CA\\uDD62\\uDA1F\\uDE75\\u5408\\uDB9E\\uDDCF=\\u0000\\uDA87\\uDFC3\\u0090\\uDAD8\\uDF0C", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udb4a\udea6\udb34\udefd\005\ud8c3\udfa0\udaf3\ude0e\u00a1\000\ud998\ude16\ud86b\udfe2\ud881\udca1\ud83a\udef9\ud84e\udf68\udaed\uddf5\uda72\ude9b\ud9ad\udfd3\ud9e6\udd9d\ud810\udf7a\udad4\uddb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDB4A\\uDEA6\\uDB34\\uDEFD\\u0005\\uD8C3\\uDFA0\\uDAF3\\uDE0E\\u00A1\\u0000\\uD998\\uDE16\\uD86B\\uDFE2\\uD881\\uDCA1\\uD83A\\uDEF9\\uD84E\\uDF68\\uDAED\\uDDF5\\uDA72\\uDE9B\\uD9AD\\uDFD3\\uD9E6\\uDD9D\\uD810\\uDF7A\\uDAD4\\uDDB4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb24\udc5c\udb90\udd42\udabd\udeaa\u23fa\ud8f8\udca3\ud954\udd4c\ud9e8\udfbf\ud9aa\udfb8Q\udbed\udc80\ud9b4\udfd5\023\uda33\udfbe\uda15\udd97\000\024\000\000\u2100\ucb65\uda34\udd11\ud985\ude69\ud989\ude7e\uda7b\udf6b\ud9db\udeac\uda8b\udeed\udbb8\udd2a\ufafe\u60c0\ud947\udc7e\udb60\udf00\uda72\ude18");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB24\\uDC5C\\uDB90\\uDD42\\uDABD\\uDEAA\\u23FA\\uD8F8\\uDCA3\\uD954\\uDD4C\\uD9E8\\uDFBF\\uD9AA\\uDFB8Q\\uDBED\\uDC80\\uD9B4\\uDFD5\\u0013\\uDA33\\uDFBE\\uDA15\\uDD97\\u0000\\u0014\\u0000\\u0000\\u2100\\uCB65\\uDA34\\uDD11\\uD985\\uDE69\\uD989\\uDE7E\\uDA7B\\uDF6B\\uD9DB\\uDEAC\\uDA8B\\uDEED\\uDBB8\\uDD2A\\uFAFE\\u60C0\\uD947\\uDC7E\\uDB60\\uDF00\\uDA72\\uDE18", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb24\udc5c\uda14\udee5\udabd\udf03\u23fa\000\000\ud84b\udf17\ud9ae\udebc\001\ud998\ude16\ud86b\udfe2\000\ud8d8\uddf1\udb49\udc9b\ud802\udda1\u1a13\000\000\udbc7\ude6b\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB24\\uDC5C\\uDA14\\uDEE5\\uDABD\\uDF03\\u23FA\\u0000\\u0000\\uD84B\\uDF17\\uD9AE\\uDEBC\\u0001\\uD998\\uDE16\\uD86B\\uDFE2\\u0000\\uD8D8\\uDDF1\\uDB49\\uDC9B\\uD802\\uDDA1\\u1A13\\u0000\\u0000\\uDBC7\\uDE6B\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\000\000\000\000\000\000\u9f77\000\000\ud884\udca2\000\000\uda15\udd03\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000\\u9F77\\u0000\\u0000\\uD884\\uDCA2\\u0000\\u0000\\uDA15\\uDD03\\u0000\\u0000\\u0000\\u0000\\u0000\\u0000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb53\udff3\ud928\udeba\ud8b1\udc1b\ud91d\uddd2\uda65\udf65\uda79\ude14\ud9ab\uddc8\udbf9\udd8d\uda0f\udece\udb26\ude61\ud86b\udfe2\000\ud8d4\udd04\ud89f\udeb0\ud9a5\udf66\003\000\000\u2100\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB53\\uDFF3\\uD928\\uDEBA\\uD8B1\\uDC1B\\uD91D\\uDDD2\\uDA65\\uDF65\\uDA79\\uDE14\\uD9AB\\uDDC8\\uDBF9\\uDD8D\\uDA0F\\uDECE\\uDB26\\uDE61\\uD86B\\uDFE2\\u0000\\uD8D4\\uDD04\\uD89F\\uDEB0\\uD9A5\\uDF66\\u0003\\u0000\\u0000\\u2100\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud859\udd18\ud9d8\udc86\udb13\ude12\ud82d\ude87\002\ud84e\udfce\u6f7a\ud932\udcd6\000\ud998\ude16\udbe1\udebb\002\ud917\ude4f\ud962\udc8b\ud80e\udf07\u5663\000\u3500\u21ff\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD859\\uDD18\\uD9D8\\uDC86\\uDB13\\uDE12\\uD82D\\uDE87\\u0002\\uD84E\\uDFCE\\u6F7A\\uD932\\uDCD6\\u0000\\uD998\\uDE16\\uDBE1\\uDEBB\\u0002\\uD917\\uDE4F\\uD962\\uDC8B\\uD80E\\uDF07\\u5663\\u0000\\u3500\\u21FF\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb03\ude5c\uda0b\udfe0\uda2d\udd9a\udac1\udce4\"\000\000\ud932\udc08\ud95a\udc93\udb83\ude16\ud86b\udfe2\000\uda33\udfbe\udb3c\ude8a\000\udb5d\udd1e\"\000\udbf4\ude51\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB03\\uDE5C\\uDA0B\\uDFE0\\uDA2D\\uDD9A\\uDAC1\\uDCE4\\\"\\u0000\\u0000\\uD932\\uDC08\\uD95A\\uDC93\\uDB83\\uDE16\\uD86B\\uDFE2\\u0000\\uDA33\\uDFBE\\uDB3C\\uDE8A\\u0000\\uDB5D\\uDD1E\\\"\\u0000\\uDBF4\\uDE51\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb40\uddc0\u00ac\ud820\udc0f\ud9b4\udd8f9\ud903\udec0\uda2e\ude01\uda44\ude93\udb41\ude8e\u00c1\000\000\000\udbec\ude09\000\000\000\u40b5\000\udb7f\udd3e\udaec\udf3d\000\u00c8\udb0d\udf9a\uda12\udc05\ud84f\udedc\uc408\udb9e\uddcf=\000\uda87\udfc3\u0090\udae9\ude0c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB40\\uDDC0\\u00AC\\uD820\\uDC0F\\uD9B4\\uDD8F9\\uD903\\uDEC0\\uDA2E\\uDE01\\uDA44\\uDE93\\uDB41\\uDE8E\\u00C1\\u0000\\u0000\\u0000\\uDBEC\\uDE09\\u0000\\u0000\\u0000\\u40B5\\u0000\\uDB7F\\uDD3E\\uDAEC\\uDF3D\\u0000\\u00C8\\uDB0D\\uDF9A\\uDA12\\uDC05\\uD84F\\uDEDC\\uC408\\uDB9E\\uDDCF=\\u0000\\uDA87\\uDFC3\\u0090\\uDAE9\\uDE0C", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc6a");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC6A", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\uda89\udd76\u58df\ud913\ude85\004\000\u70fa\000\ud998\ude16\ud86b\udfe2\ud8d6\udf2a\ud9dc\udce4\ud94b\udfe7\004\000\udbe2\udf90\ud864\udce4\ud9c5\udd13\ud83e\udf34");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDA89\\uDD76\\u58DF\\uD913\\uDE85\\u0004\\u0000\\u70FA\\u0000\\uD998\\uDE16\\uD86B\\uDFE2\\uD8D6\\uDF2A\\uD9DC\\uDCE4\\uD94B\\uDFE7\\u0004\\u0000\\uDBE2\\uDF90\\uD864\\uDCE4\\uD9C5\\uDD13\\uD83E\\uDF34", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\000\000\ud820\udc0f\ud9b4\udd8f9\ud933\udff9\udaf3\ude1e\uda44\ude93\udb41\ude8e\u00c1\000\000\000\udbec\ude09X\000\000\000\000\ud853\udf69E\000\000\udb0d\udf9a\ud9ca\udd62\uda1f\ude75\ud8d1\ude05\ud903\ude55=\000\uda87\udfc3\u0090\udad8\udf0c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\u0000\\u0000\\uD820\\uDC0F\\uD9B4\\uDD8F9\\uD933\\uDFF9\\uDAF3\\uDE1E\\uDA44\\uDE93\\uDB41\\uDE8E\\u00C1\\u0000\\u0000\\u0000\\uDBEC\\uDE09X\\u0000\\u0000\\u0000\\u0000\\uD853\\uDF69E\\u0000\\u0000\\uDB0D\\uDF9A\\uD9CA\\uDD62\\uDA1F\\uDE75\\uD8D1\\uDE05\\uD903\\uDE55=\\u0000\\uDA87\\uDFC3\\u0090\\uDAD8\\uDF0C", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb24\udc5c\uda14\udee5\udabd\udf03\ud9e3\udd45\001\ud936\ude1b\ud84b\udf17\ud9e3\uddc6\001\ud998\ude16\ud86b\udfe2\ud895\udc8a\ud9cf\uddb8\udb49\udc9b\ud802\udda1\u1a13\000\000\udbc7\ude6b\udbe1\udfa9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB24\\uDC5C\\uDA14\\uDEE5\\uDABD\\uDF03\\uD9E3\\uDD45\\u0001\\uD936\\uDE1B\\uD84B\\uDF17\\uD9E3\\uDDC6\\u0001\\uD998\\uDE16\\uD86B\\uDFE2\\uD895\\uDC8A\\uD9CF\\uDDB8\\uDB49\\uDC9B\\uD802\\uDDA1\\u1A13\\u0000\\u0000\\uDBC7\\uDE6B\\uDBE1\\uDFA9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda51\udd23\udbcf\ude6a\ud81e\udc0d\ud98e\ude69\ud84d\udce3\uda11\ude3d\ud9c7\udd79\032\ud842\udc4f\ud90e\ude32\\\uda33\udfbe\uda15\udd97\ud8d4\udec3\ud9a1\udff2\\\000\udbe8\ude9f");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA51\\uDD23\\uDBCF\\uDE6A\\uD81E\\uDC0D\\uD98E\\uDE69\\uD84D\\uDCE3\\uDA11\\uDE3D\\uD9C7\\uDD79\\u001A\\uD842\\uDC4F\\uD90E\\uDE32\\\\\\uDA33\\uDFBE\\uDA15\\uDD97\\uD8D4\\uDEC3\\uD9A1\\uDFF2\\\\\\u0000\\uDBE8\\uDE9F", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb1c\udc5c\uda0b\udfe0\udb4a\udea6\udb34\udefd\005\ud8c3\udfa0\udaf3\ude0e\005\ud92c\udd0a\ud998\ude16\ud86b\udfe2\ud881\udca1\ud83a\udef9\ud84e\udf68\udaed\uddf5\uda72\ude9b\ud9ad\udfd3\ud9e6\udd9d\ud810\udf7a\udad4\uddb4");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB1C\\uDC5C\\uDA0B\\uDFE0\\uDB4A\\uDEA6\\uDB34\\uDEFD\\u0005\\uD8C3\\uDFA0\\uDAF3\\uDE0E\\u0005\\uD92C\\uDD0A\\uD998\\uDE16\\uD86B\\uDFE2\\uD881\\uDCA1\\uD83A\\uDEF9\\uD84E\\uDF68\\uDAED\\uDDF5\\uDA72\\uDE9B\\uD9AD\\uDFD3\\uD9E6\\uDD9D\\uD810\\uDF7A\\uDAD4\\uDDB4", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\udb53\udff3\ud928\udeba\ud8b1\udc1b\ud91d\uddd2\uda65\udf65\uda79\ude14\ud9ab\uddc8\udbf7\udd8d\uda0f\udece\udb26\ude61\ud86b\udfe2\000\ud8d4\udd04\ud8ef\udcb0\ud9a5\udf66\003\003\000\u2100\ucb65");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uDB53\\uDFF3\\uD928\\uDEBA\\uD8B1\\uDC1B\\uD91D\\uDDD2\\uDA65\\uDF65\\uDA79\\uDE14\\uD9AB\\uDDC8\\uDBF7\\uDD8D\\uDA0F\\uDECE\\uDB26\\uDE61\\uD86B\\uDFE2\\u0000\\uD8D4\\uDD04\\uD8EF\\uDCB0\\uD9A5\\uDF66\\u0003\\u0003\\u0000\\u2100\\uCB65", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang.StringEscapeUtils.escapeJava("\ud967\udeda\ud939\udcb6\udaae\udc32\u23fa\ud90d\udca5\udb4e\udfe7\u694e\ud932\udc08\ud8f9\uddca\u29c1\ud8d0\ude5f'\uda33\udfbe\udbf8\udea8'\000\u4cb6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\\uD967\\uDEDA\\uD939\\uDCB6\\uDAAE\\uDC32\\u23FA\\uD90D\\uDCA5\\uDB4E\\uDFE7\\u694E\\uD932\\uDC08\\uD8F9\\uDDCA\\u29C1\\uD8D0\\uDE5F'\\uDA33\\uDFBE\\uDBF8\\uDEA8'\\u0000\\u4CB6", String.valueOf(r));
  }
}
