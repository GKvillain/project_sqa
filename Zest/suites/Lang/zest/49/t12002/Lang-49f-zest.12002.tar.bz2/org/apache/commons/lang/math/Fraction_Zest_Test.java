package org.apache.commons.lang.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class Fraction_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\ud9ff\uddf9\udad1\udcc9\uda8e\ude56\ud9c5\ude32\ud8e9\udf98\udb13\udd2e\udbb9\udf92\ud9df\udcc0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\ud96c\udf99\uda04\udc45\ud887\udcb2\ud9cb\udeca\ud8e9\udf98\udb54\udd4e\ud828\ude6d\udbe7\udef6\ud916\udf51\uda83\udd31\udba9\ude44"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\ud9ff\uddf9\udad1\udcc9\udb26\ude43\ud9c5\uddc8\ud80b\udfa8\uda6e\udc7b\udbe9\uddd9\udb82\ude80\ud9e2\udc11\uda1e\udd9a\ud989\ude24\udb6c\udcb9\ud932\udd3c\udb1e\udc9e\udaf9\udcd6\ud9e3\udc9e\ud88c\uddbb\u8206\udb44\udf2b\ud960\udebb\ud8f4\udc8d\udb54\udf0d\ud80b\uddcb\ud801\udd86\udab2\udea0\u21ab\udab9\udda5\udb2e\udcd0\ud8cd\udd62\ud9a5\udf1c\ud85f\udfed\udaf8\udfaf\uda86\udcd3\ud98f\udfb9\udaf9\udf34\ud829\udde8\ud894\udc5e\ud82b\ude41\ud9e1\udf02\ud903\udd10\ud948\udcc2\udb47\udfb1\ud97c\udd55\ud902\udf8e\uda5d\udcb2\uda55\udc62\uda3b\udee0\udb0e\ude8c\ud907\ude12\ud894\uddd0\u180c\udae5\ude0a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\ud9ff\uddf9\udad1\udcc9\uda8e\ude56\ud9c5\ude32"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\udb2f\uddaa\udad1\udcc9\uda8e\ude56\u2d25\ud8e9\udfb5\udac6\udf27\udbb9\udf92\uda0d\udc08\uea12\u0deb\ud907\udf7f\udace\udc10\uda8b\udfe5\ud9fa\udfd4\udbeb\udfd5\uda74\ude69\ud8d3\udc0a\udb8e\udd27"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\ud9d1\udca9\udad1\udcc9"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\udbad\udd65"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\ubd31"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.math.Fraction.getFraction("1");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.math.Fraction", r.getClass().getName());
    assertEquals("1/1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\uda51\udfea\udaec\udf49\ud874\udea6\udb6a\udcb2\uda94\udce0\udb13\udd2e\ud91f\udd24\ud97d\udc7b\udab5\udf8e\ud942\udf4c\ud92a\ude2b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\ud96c\udf99\uda8f\udf2a\uda08\udf75\udba4\ude5e\udaa2\udff4\ud929\udc59\udab1\udd47\udbfa\udd4d\ud916\udf51\uda83\udd31\udbbd\udeee\udbaa\udfc4\udb33\udc34\udad3\udc1a\uda36\udefb\ud85a\udd18\ub22a\uda77\udfe3\ud83e\ude6d\udbdb\udc8d\uda8d\udf76\uda6e\udc5f\ud87b\udc3c\ud82e\udcd2\ud87f\udf9b\ud94c\udd86\udbea\udeff\ud877\udf87\udaa3\ude8b\ud8b5\udfb9\udb5b\udc82\udabb\ude31\ud9ed\ude43\ubf67\udabc\ude68\ud9a4\udf40\udb61\udd77\udbe7\udf2f\ud906\udf38\ud80b\uddd0\ud9d5\udc34\ud113\uda43\udcf5\udb45\ude66\udb28\udc1c\ud8d9\udea3\ue57e\udbb9\udd0e\udb37\udcce\udb1c\udcda\udbb2\ude64\udb66\udc5d\udb57\ude4d\udafd\udce6\udb87\uddd8\ud8eb\udd02\udad8\udf99\ud93a\udf23\ud807\udfde\ud85b\uddef\udb74\udd6b\ud86e\udcab\udb68\udc74\udb41\ude1e\uda75\udcf6\udac7\udfe1\ud8b0\ude9f\uadf1\udbd5\udee2\udab2\udd55\u6412\ud834\udfb6\ud97c\udfc0\ud94a\udf9a\ud982\udecc\udaa4\udf9c\ud193\ud899\udf47\uda39\ude82\udad8\udcbb\ud87b\ude8b\ud9b1\udd5a\ud9d5\udfc9\udab8\udc8f\ud96b\udfef\udb1b\uddd8\ub70c\ub71b\ud8a0\udd94\ud82e\udca3\ud8a1\udeec\ud889\udec9\ud885\ude8d\udb72\udc97\udba4\ude88\udade\udd32\uda59\udf59\ud9ba\udf95"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("/\ud842\udca2\udb5f\uded8\udac5\udda5\udb06\udf05\ud9e3\udc34\ud9a9\udff6\ud8af\udcbb\u1cfb\uda6e\udcb2\udad5\udf5f\ud81a\udf92\uda36\udf68\ud9ec\udebf\uda3b\udf73"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction(".\ud935\udc6a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang.math.Fraction.getFraction("\u1505\uda10\udd05\000\udb64\udc51\000\000\000\ud99b\ude6c\udab5\udf8e \ud92a\udd6f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
