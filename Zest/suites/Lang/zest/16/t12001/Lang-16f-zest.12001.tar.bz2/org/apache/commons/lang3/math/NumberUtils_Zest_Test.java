package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud80c\udc36\ud90f\udfb7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud8ed\udd42\udbf8\udcae\ud95c\udda8\udb11\udf79\udafa\udf8d\ud9b4\udf23\udab8\ude7f\ud8aa\udfff\uda14\udfe3\u4e61\ud93f\udd0f\ud923\udff0\ud9c7\udf2e\udaeb\udd1b\udba7\udcac\ud8ce\udd6e\uda57\udf64\ud874\udf81\udafd\udd0c\uda79\udc30\udae4\uddb7\ud9e3\udee0\udba7\udce5\uda30\udf46\ud754\udb14\udcaf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udad9\udde4\ud897\udc2f\ud9c9\udcba\udb53\udf0f\ud895\udd9f\udb36\udfbe\ud9e6\ude1f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb37\udc6f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud8ec\udfc8\udbcd\udf74\ud9f7\udcc0\ud8d7\udd44\udafc\udfd0\udbe9\udd2d\ud854\udd4a\uda71\udc1a\ud981\ude98\udb60\udf5d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud847\udd05\udb6e\udcc6\ud80f\udc12\udb87\udeef\ud8f9\ude4a\udaa2\udc5d\ud894\udd45\ud86a\udc8f\ud833\udc2d\ud990\udd62\udb8b\udeed\uda3a\udd42\ud852\udc20\ud9e8\udc2d\udbdc\udddc\udb3b\udef0\udbe5\udea0\udb08\udc15\ud875\uddb5\ua512\ud840\ude55\ud8e9\udf57\udb15\udfbd\ud91e\udcd5\udbab\udcf7\uda82\udf0d\uf82f\uee45\uda30\udc2a\ud8e4\udffd\ud9e6\ude93\ud811\udf59\ud9f1\udf92"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud8ee\uddc7\ud945\ude6d\udb5f\udde7\ud812\udeb1\uda04\udd35\uda2b\udee0\udbd0\udcd1\udbec\udd65\udbfd\uded0\udaca\udeb6\udb0d\udf34\ud99a\udff5\uda7c\uddfd\udb50\udfab\udad7\udef1\ud915\udf9f\udab5\ude01\ud96b\udc85\udb24\udda3\udae6\udda9\ud812\udd62\uda73\udfba\uda1c\udcaf\ud801\ude3a\uda8a\udfb7\uda99\udd2c\ueecf\ud979\udd64\ud920\udc2c\u7582\udb40\udfff\udb75\udc55\ud94d\udc07\ud8ec\udfab\udb9d\udef3\uda1b\udf3a\ud829\ude33\ud8c7\udcad\ud9fa\udf02\ud8af\ude06\udb10\udd73\ud97b\udd51\udb68\udf6c\udb4f\udd2f\udb4e\ude34\ud850\udcba\udaf4\udf10\udbfd\udc61\udbb1\ude68\udad2\udd77\ud8ce\udf77\ud820\uddeb\udaa9\udcdd\udbff\udd4b\ud940\ude2c\uda44\udc29\ud898\udfee\ud97e\udd8b\uda5e\udebf\ud886\udcf9\uda3a\udf65\udada\udced\ud8b9\udf19\uda01\udc93\udad3\ude8e\udbc5\udedb\ud958\ude3e\ud908\udca1\udbc8\udc14\uda8b\udf25\udb3b\ude51\uda93\udfdf\ud96d\ude6e\udbda\udc3c\ud848\udee2\u3de2\uda31\udc4c\ud845\udea3\ud9e2\udde4\ud85e\udc72"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud82c\udee6\udb4c\udc34"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\037"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\037\ub276\ud8e5\udccb\udb66\ude14"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udbe4\udea6\ub1b1\ud8db\udc6e\udb66\ude14\uda67\udf56\ud887\udf66\udb42\udcff\u0ed1"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("\u1095");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(".\ud94a\ude36\ud9d1\udf11\ud809\uddbf\udb7a\ude99\ud958\udc50\uda4a\udcb2\uda09\udd0f\ud991\udf47\ud8f8\ude43\udb66\ude53\ud910\ude60\udbff\udd84\ud8af\udce4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e\udb67\udc56\ud824\uddb8\ud84e\udd4b\ud888\udcb0\ud8d9\udcc2\udb7d\udfa4\ud904\udd62\udb2a\udc4c\udaae\ude5f\udbd7\uddaf\udaac\udd9f\uda3d\udcf4\ud910\udc5a\udb16\udf5e\ud977\udd3e\uda7f\udef9\ud843\udfd4\udaaa\uddb8\udbb0\udcbb\udaf3\uddc1\uda03\udfcd\ud94f\ude50\ud94d\ude99\uda41\udc94"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud80c\udc36\ud99b\udc5d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("l"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("F"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("e\udb67\udc56\ud824\uddb8\ud84e\udd4b\ud888\udcb0\ud8d9\udcc2\udb7d\udfa4\ud904\udd62\udb2a\udc4c\udaae\ude5f\udbd7\uddaf\udaac\udd9f\uda3d\udcf4\ud910\udc5a\udb16\udf5e\ud977\udd3e\udb48\udfdd\ud83b\udd5f\udaaa\uddb8\udbb0\udcbb\udaf3\uddc1\uda03\udfcd\udaf3\udf47\udb7c\ude2f\ua9f7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda9c\uded0\uda39\udef9\ud972\udfc4\udb5e\udc8a\udb79\udff3\uda1e\udd4e\u759b\udba7\udd33\ud969\ude42\u425c\ud93f\udde4\ubcde\udadc\udfbf\udb8a\udd01\ud9de\uded7\ud9d1\udeea\uda4b\udf53\udbdd\ude59\udb7b\udeb1\ud8aa\udf59\udac5\udcbc\ud89a\udf20\ud92d\udcc3\ud9a0\udf92\ud9db\udd41\ud912\udf53\udbb8\ude77\ud92d\udf61\uda51\udff7\ud915\udc2b\ud3c2\uda5e\udda1\udba8\udf7d\udb7e\uddf5\ud984\udce5\ud975\udca8\ud953\udce1\ud80e\ude7e\udbd8\udda7\udb18\udfeb\udbdc\udd59\ud9bb\udd49\uda75\udc5d\ud9d4\udfb8\uda6c\udee8\udab2\udc01\ud901\ude8b\udb1b\udee5\uda45\udc1b\ud8f1\udf04\udafc\ude80\ud975\udf1c\ud8b4\ude39\udbb5\udec3\uda04\ude43\ud950\udd33\uda73\uddb2\uda6f\udfa1\udb63\udc00\udb4f\udc29\ud809\udc24\ud992\udc0f\ud8e8\uddb3\ud8b9\udc69\uda6f\udc39\udbc9\udd4e\udbc8\udee1\uda09\udf5a\udad2\udffa\udb0b\ude95\ud8a3\ude21\ud98e\udeed\uda6a\udf5c\udb0b\ude68\udb93\udf50\udbfa\udcd2\udb93\uddd3\udba4\udc54\uda04\udd95\u06d1\ud934\udfe4\ud85f\uddda\uda56\udccc\udb94\ude24\ud874\udddf\ud86c\udd0e\ud9fc\udef5\uda23\udde1\ud85e\udf62\ud804\udf89\ud902\udd93\uda77\udcc1\udaca\udcb2\udb29\udeef\ud831\udd19\ud995\udde9\ud8c9\udcb8\uda83\udd10\uda3f\udd92\udb04\udd86\udaca\uded8\udbba\udc4a\udb58\udc5c\udb07\ude79\ud847\udfde\ud944\udd74\udae8\ude91\udb71\udf52\udadb\udd66\ud9c1\udd1d\ud9ab\ude9c\ub535\ud94f\udd5b\ud9c6\udea8\ud9c6\udf9e\ud815\udf71\udbb3\ude37\udae4\udf2e\udb02\udce7\udbd1\udd25\udbd1\uddfd\uda9c\udee4\udbca\udcb5\ud8eb\udfc1\ud95e\udc83\ud817\udcd6\ud8a8\udf24\udb44\udf60"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
