package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udad1\udc86\udb1d\udfda\ud8c4\ude3e\ud975\udd5f\udbef\udd09\ud950\udce1\ud9ae\udc24\u21bb\udb6a\udd80\ud952\udecf\udaf8\ude30\ud96e\udc2a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udad1\udc86\udb1d\udfda\ud96f\ude93\ud964\udc89\ud932\udfeb\ud91d\udca9\uda96\udd03\u21ec\ud924\udea3\ud9ca\ude78\udb1b\udf80\ud999\udcb6"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda21\udfd7\uda23\uddbd\ud8c4\ude3e\ud975\udcf6\udae2\udda2\ud8a1\udfb3\udb94\udf06\uda97\uddc0\udb50\uded9\uda20\uded6\udaf8\ude21\ud96e\udc2a\ud92b\udf37\ud8c1\udff1\udacf\uddbd\ud85f\udf1e\uf406\ud800\uddef\udbe8\ude39\ud967\ude1a\ud82e\udfd9\ud9fc\udc3d\ud958\udfe8\ud84b\ude2c\udabb\udde8\ud951\ude05\udba8\udfdf\ud909\udecf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud905\uddb8\ud8ed\udda1\ud8d0\udd70\ud816\udf6f\udbef\udd09\ud803\udea9\ud9ae\udc1c\udbda\udee2\udb6a\uddd4\ud952\udecf\ud897\udebe\uda03\udebb\ud85a\udfbf\udb65\uddf5\ud92b\udcb3\uda81\ude6c\ud843\ude6e\u8262\ud9bb\uddd7\ud871\ude09\uda7e\udfb5\ud81f\udd55\ud8b7\ude3b\udada\udd6e\ud977\udfe9\udb01\udc53\udad3\udf61\ufe00\ud9e9\udd76\udbca\udc13\ud86f\udd5a\ud8d8\udc05"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud951\udf89\udb1d\udfda\ud8c4\ude3e\ud975\udd5f\udbef\udd09\ud950\udce1\ud9b2\udc26\u21bb"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda05\udc87\ud8c0\udc86\ud9a2\udc14\uac68\u1db0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udad1\udc86"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udad1\udc86\udb1d\udfda\ud8c4\ude3e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udacd\udfbc\ud943\udc49\ud8c4\ude3e\ud9d5\udc65\udbef\udd09\ud950\udce1\ud9ae\udc24\u21bb\udb6a\udd80\ud842\uddc8\uda41\udf0e\ud96e\udc2a\udbc4\udcee\ud851\udff0\ud9af\udfc8\udb02\udc92\udbfc\uddc7\udb5a\uddfd\ud9d8\uddc0\ud86b\udfd4\uda41\udd86\udb18\udf4e\uda68\udc11\uda7e\udd8f\uda51\ude02\ud870\udd68\udb56\ude24\ud8c4\udfc3\ud844\uddae\ud8e2\udcad\udaad\udea5\ud90a\uddcc\uc556\ud8fa\udc63\udb52\udc7a\ud9f5\udcbe\udb12\udcaa\u8806\ud928\udd49\ud9f2\ude86\udaf7\udcbd\ud99a\udfe3\udb21\uddee\udb66\udf04\ud8a0\udc3f\ud878\udf42\ud93b\udf6a\uda3c\udff5\ud84a\udde0\udb73\ude1f\udb34\ude92\ub454\ud913\udd47\ud830\ude0f\udbab\udef6\uda71\udd6c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda21\udfd7\uda23\uddbd\ud8c4\ude3e\ud975\udcf6\udae2\udda2\ud8a1\udfb3\udb94\udf06\uda97\uddc0\udb50\uded9\uda20\uded6\udaf8\ude21\ud96e\udc2a\ud92b\udf37\u00de\udacf\udd55\ud85f\udf1e\012\uafc5\udbe8\ude39e\u0ca5\ud9e5\udd11\ud958\udfe8\ud84b\ude2c\udabb\udde8\ud951\ude05\udba8\udfdf\ud909\udecf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb27\udfa7\ud961\uddf4\udae3\udfda\udaa6\udf52\udbdd\udcec\udaef\uddc7\ud89b\udc94\udbd7\udd8a\udbaa\uded0\udb14\uddac\ud894\udf37\ud842\udfed\ud9c9\udd4b\ud8fb\udc79\udb79\uddfa\ud86d\udcfe\ud9c3\ude27\udb13\udc15\udbae\udc6b\uf46b\ud83b\uddc2\ud99d\udc2e\ud9e5\udf47\ud977\udd6a\ud962\udd93\uda4d\ude08\ud975\ude19\ud876\udfd4\udb19\udc8a\udb85\udd39\ud9d5\udceb\ud9b5\udd6b\udb8f\ude7e\ud94f\ude87\uda3b\uddef\udbe9\udcdc\udae9\udcf6\ub564\ud83f\udcee\ud920\udc9e\ud929\udc66\ud878\udf00\ud8fe\udd64\uda3c\udfd7\udae1\udfd0\uda71\udf92\ud891\udc7b\ud86d\udc71\udad8\uddbc\udbc0\udfc8\udbb6\udd27\udb48\udf98\ud9f9\udd66\ud997\uddbc\ud9e5\udf01\udbe0\udf4e\uda4d\ude3d\ud83b\udf27\ud9fd\udc6d\udbe3\udd6d\ud94b\udcac\udab2\ude08\udb1d\udf6b\ud9ec\udf2b\udb26\udc03\udb16\udc3b\ud97d\udcb0\ud80f\udf42\udbd9\udf97\udac0\udcff\udba0\udcda\ud95a\udce6\ud96f\udfb2\ud98d\udeae\ud97c\udf17\udaca\udf8a\udaac\ude50"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda21\udfd7\uda23\uddbd\ud8c4\ude3e\ud975\udcf6\udae2\udda2\ud8a1\udfb3\udb94\udf06\uda97\uddc0\udb50\uded9\uda20\uded6\udaf8\ude21\ud96e\udc2a\ud92b\udf37\u00de\udacf\udd55\ud85f\udf1e\012\uafc5\udbe8\ude39e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud934\udc34\udbbc\udf2a\udb27\ude22\ud953\ude0f\udae2\udda2\ud8a1\udfb3\uda46\udc40\udafd\udd0c\ud95b\udc28\uda20\uded6\udaf8\ude21\ud96e\udc2a\ud92b\udf37\u00de\udacf\udd55\ud9b2\ude48\ud9e3\udea0\ud9c4\udc10\udbe8\ude39.\u00a5\ud87a\udddc\uda69\ude83\ud8bf\ude66\udbbc\uddd0\ud985\udc5e\udba8\udfd6\ud909\udecf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda21\udfd7\uda23\uddbd\ud8c4\ude3e\ud975\udcf6\udae2\udda2\ud8a1\udfb3\udb94\udf06\uda97\uddc0\uda74\udef9\udaf0\ude34\udaf8\ude21\ud96e\udc2a\ud92b\udf37\u00de\udacf\udd55\ud85f\udf1e\012\uafc5\ub27cd"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u00e4\uda23\udd09M\000\udae2\udda2E\udb94\udefa\u008f\ud95a\ude4c\000\000\uda5d\udfa2\ud92b\udecb\u00de\udacf\udd55\ud851\udf17\012\uaf00\udbe8\ude39e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud934\udc34\udbbc\udf2a\udb27\ude22\ud953\ude0f\udae2\udda2\udbd2\udf2c\uda46\udc40\udafd\udd0c\ud95b\udc28\uda20\uded6\udaf8\ude21\udb0c\udefa\ud92b\udf37\u00de\udacf\udd55\ud9b2\ude48\ud9e3\udea0\ud9c4\udc10\udbe8\ude39."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud933\udf83\udbbc\udf2an\uda46\udfa3\udae2\udda2E\uda46\udc34\udafd\udd0c\ud95b\udc28\uda20\uded6\udaf8\ude21\ud96e\udc2a\uda66\udd74\u00de\000\000\000\000\udbe8\ude39.\u00a5\ud87a\udddc\uda69\ude83\ud8bf\ude66\udbbc\uddd0\u4304\000\ud816\udd6a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda21\udfd7\uda20\udfbd\ud8c4\ude3e\ud975\udcf6\udae2\udda2\ud8a1\udfb3\udb94\udf06\uda97\uddc0\uda74\udef9\ud898\udd64\udaeb\udeee\ud96e\udc2a\ud92b\udf37\u0660\udacf\uddc9\uda9f\udc91\uda24\udf5b\uafc5\ub27c2"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u00e4\uda1a\uddc6M\ud9e0\udd10\udae2\udda2E\udb94\udefa\u008f\ud983\udc4c\udb5a\udf4cl\uda5d\udfa2\ud92b\udecb\uda22\udc4e\ud898\udcc9\ud826\ude7a\012\ud925\udcd1\udaf8\udec17"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u00e4\uda23\udd09\ud847\ude50.\udae2\udda2\ud855\udefe\udb94\udfc2\u008f\udace\udce6\ud9be\udefc\uf6d5\udbfd\udccf\ud84a\uddc9\u00de\udacf\udd55\ud851\udf17\012\uaf00\udbe8\ude39e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u00e4\uda1a\uddc6M\ud8e4\udd12\udae2\udda2E\ud9c8\udd54\u2e0e\ud983\udc4c\udb5a\udf4cl"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("E\uda1a\uddc6M\ud9e0\udd10\udae2\udda2E\udb94\udefa\u008f\uda79\udc48\udb35\udef9\udbc8\udedd\uda5d\udfa2\ud92b\udecb\udb22\udd7f\ud898\udd45\ud833\udcca\012\ud925\udcd1\udaf8\udec17"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u00e4\uda23\udd09\ud8d3\udfeb\udb52\uddd8\ud87b\udd98\ud855\uded3\udb94\udfc2\u008f\udace\udce6\ud9be\udefc\uf6d5\udbfd\udccf\ud84a\uddc9\udbf3\udd97\ud8ed\udfb6\ud804\udddeL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\034\udbed\udf07\uda2d\udde2\ud860\udd05\ud98c\uddc2\ud946\udf73\udb25\udcb3\ud8bc\udf6e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb47\udee6\udb3a\udd84.\ud8e4\udd12\udae2\udda2E\ud903\udfb4\udb87\uded7\ud983\udc4c\ud9df\uddafl"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\034"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("5");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9b7\udc59\uda48\ude6f\udb5e\ude0f\ud975\udd37\u37f2\ud950\udce1\ud946\udd70\ud8d4\udc91\udb6a\udd1a\ud952\udecf\udb1d\udf9f\ud96e\udc2a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u00e4\uda23\udd09M\000\udae2\udda2E\udb94\udefa\u008f\ud95a\ude4c\000\000\uda5d\udfa2\ud92b\udecb\u00de\udacf\udd55\ud851\udf17.\uaf00\udbe8\ude39e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud996\udccc\uda20\udfbd\ud8c4\ude3e\uda7f\udcfb\udab8\udced\ud9af\udfba\udb94\udf06\uda97\uddc0\u0080\ud9f7\udf15\udaeb\ude2b\ud96e\udc2a\udafe\udc20\ud8a7\udeb0\udacf\ude2f\ud90c\udec9\udba8\udf75\ud8bb\udcd8\ud990\udd6cf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\034\uda1a\uddc6M\ud9e0\udd10\udae2\udda2E\udb94\udefa\u008f\uda79\udc48\udb35\udef9\udbc8\udedd\uda5d\udfa2\ud92b\udecb\u09cf\ud898\udd45\ud833\udcca\012\ud925\udcd1\udaf8\udec17"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud946\udea7\uda7e\uddb2\ud904\udd53\ud93f\ude39\udae2\udda2E\ud903\udfb4\udb87\uded7\ud983\udc4c\udac2\udeaeD"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("l"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda86\uddc1\000\000\000\000\ud917\udfcb\ud9ae\udc24\u21bb\udb6a\udd80\ud952\udecf\udaf8\ude30\ud96e\udc2a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda21\udfd7\udb46\ude90\ud9b6\uddeb\ud975\udd2c\ud966\udf45\uda50\udcb0\ud90d\udd3b\uda97\uddd6\uda74\udef9\udbba\udc74\ud893\udca7\ud96e\udc2a\ud92b\udf37\u0660\udacf\uddc9\uf141\ud8a3\udc7a\uafc5\udbf2\udc8cF"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("9\ud83d\udd95\ud9ee\udd34\uefbf\ud889\udd8f\ud855\uded3\udb94\udfc2\u008f\udace\udce6\ud9be\udefc\uf6d5\udbfd\udccf\ud84a\uddc9\udbf3\udd97\ud8ed\udfb6\ud804\udddeL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("-\ud83d\udd95\ud9ee\udd34\uefbf\ud889\udd8f\ud855\uded3\udb94\udfc2\udb8b\udd14\ud85c\udc15\ud8e9\udd10\uf6c5\udbfd\udccf\ud84a\uddc9\udbf3\udd97\ud8ed\udfb6\ud804\udddeL"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
