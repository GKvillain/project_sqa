package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda32\udc9c\ud917\ude56\u9101\udb55\udcd4\udb1b\udd35\ud84c\udf23\udaa9\ude3f\ud8ba\udf2e\u487f\ud959\udd1a\udbfa\udc74\ud9f2\udcbf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda32\udc71\ud917\ude56\u90f0\udb44\udfcb\udb1b\udd35\udac5\udfde\udaa9\udde8\ud8ba\udf2e\ud953\udd3f\u0bde\udbc4\uddf3\udb2a\udcfb"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb59\udd6d\ud917\ude56\udbb4\udee7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda85\ude3e\ud943\udcb3\ud968\uddcf\ud962\udfac\ud9ae\udc7f\ud84c\udf23"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda32\udc0c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda32\udc37\ud917\ude56\u9101\udb55\udcd4\udb1b\udd35\ud84c\udf23\udaa9\ude3f\ud8ba\udf2e\udbb7\udefe\ud959\udd1a\udbfa\udc74\uda22\uddf8\ud871\ude67\ud95c\udec0\udabd\udf2c\udbad\udf95\ud82c\udcb9\udba2\uddce\udbe9\udf3f\u67af\ud806\udef3\ud9be\udf4a\ud930\udc85\ud8bc\uddd9\ud8ad\udead\uda4d\udfa0\ud99b\udeb5\ud958\ude0d\u737e\uda9f\ude00\udbd8\udc4d\udacd\udc60\ud906\udc31\ud820\udf9c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb8c\ude0d\udbfa\ude6b\uda4c\udfab\udb36\udd50\udb1b\udd35\ud928\udeaf\udaba\udc0e\ud852\udf59\uda09\ude09\udbf0\udfb5\ud983\udcd8\ud9f2\udc81\udad1\ude75\ud880\udf8e\udb47\uddc7\udb7e\ude1d\ud8ac\udde4\udbaa\udeef\ud8ca\ude52"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud992\udffb\ud8de\uddae\ud884\udc0b\uda48\udf16\udb56\udf51\udb3a\udd30\udbb5\udf84\udb8a\udd15\ud843\udf03\uda6d\udcb1\udb18\udc89\uda90\udc57\ud800\udec1\udb79\ude75\ud957\udc40\ud8e9\udd08\ud8be\udcaf\udbb7\udec7\ud8da\udd1b\uda17\udd9b\ud93b\udc0e\udb41\udef3\ud9ed\uddf6\ud8ea\uddc3\uda64\ude63\ud8c0\udf70\ud8ef\ude7e\u602f\ud9b0\uded6\udbce\udec3\ud8f4\udc4e\ud9f3\ude55\udb58\ude02\udbc0\udffc\ud9f6\udf6e\ud95c\udecb\ud912\udff9\ud8d7\udc2e\ud8ce\udc1c\udade\udc1a\ud84c\udf86\udaba\udc29\ud9db\udcd8\uda0e\udfe6\ud9aa\udd99\ud888\udc5a\udb2a\udd9e\ud943\udf98\ud827\udc30\udbc9\udf63\udb2b\ude2d\ud9ed\ude1e\ud973\udf89"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u00f2"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda32\udc9c\ub2aa\u909f\udb55\udcd4\ud889\udccc\ud84d\udf73\udae5\udc3a\ud8a6\ude64\udb00\ude45\ud931\udebd\udba5\udf0a\u00a3\ud991\udffa\udbf2\udc05\ud823\ude0f\udb89\udd1d\ud8cd\ude49\uda6b\udf74\ud8ba\udf76\udbc6\udc6d\ud8ae\udf0f\udb81\ude02\uda3a\udf1c\udb15\udd7f\ud920\uddbf\uda35\udf9b\u2c48\ud9b5\udcbe\ud969\udc1c\udaad\udf0d\udae6\udc3c\ud8b0\uddd8\u775d\udb2b\udef6\ud843\udde4\ud99b\udda9\udbb4\udf15\ud91b\udc05\uda04\ude9e\uda59\udc93\udafb\ude05\udafc\udf0f\ud985\udf07\udbce\udc70\ud91d\udd08\ud83c\uddf9\ud938\udc70\ud8f2\ude37\ud9c1\udecb\ud9a8\udc58\ud874\udf3b\udb7b\udfa3\uda24\udefe\uda2a\udc95\uda79\udf0c\udadf\udfac\ud92f\udcfd\uda17\udda7\udbe4\ude73\ud934\udc31\u8eed\udbd6\udf44\udb52\udcdb\uda5e\udcca"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u2000\ud984\udcd3\ud968\uddcf\ud962\udfac\ud9ae\udc7f\ud84c\udf23"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u2000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda14\udc8e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9eb\udd78\udb13\udfd6\ud968\ude6b\ud962\udfac\ud9a9\udd3d\ud84c\udf23\ud837\udce6\udbc8\ude48\uda9e\udc27\uda55\udd8c\udbcb\ude57\udb73\udd7a\udb97\udd01\ud9b3\udd4f\ud964\udd53\uda2a\udd44\udbfb\udf54\udbde\udd62\ud88b\udc04\ud9e3\udd3d\udaaa\ude9b\ud9e1\udcc7\udab6\udf4e\ud9bb\ude99\ud973\udfa8\udae1\udd03\udba9\udc15\uda38\uded8\ud998\uddff\udae9\ude7b\ud982\udf86\uda9e\udeaa\udb96\udeb6\uda47\udf46\udb86\uddf8\udbdd\udf28\ud9f7\udf6f\udbfb\udd79\ud9d4\udcd9\udaaa\uddeb\ud959\uded7\ud90f\udc80\udbe0\udc2e\ud963\udccf\uda83\udf5b\udaf2\udc01\ud816\ude69\udb72\uddac\ud88b\udd52\udbed\udf06\ud9ce\uddd9\udbeb\ude36\ud965\udf86\udb60\udc17\u39d8\ud850\ude4c\ud94b\udd22\ud8d1\udcb7\udb32\ude32\ud8c2\udf1d\ud84d\udd48\udbaa\uddf8\ud9ce\udfb7\udbb2\udd85\udbe7\udc4a\udbe9\udddf\ud8e5\uddb8\ud95f\udc71\udac6\ude58\ud90a\udf69\udab0\udd5f\ud96f\udccb\ud999\udda7\ud807\udd2d\ud954\udf59\uda3c\udd09\udbc3\udcbe\udaee\ude59\ud8da\udc0a\ud85f\ude91\ud959\udf36\udafc\udd92\ud8c2\udeaf\u6b03\ud985\ude00\ud9f7\udd96\udab9\udfa3\udabb\udd88\ud8b9\udd14\udb7c\udd0c\udae0\udce5\ud90c\ude8f\ud8c1\udcd9\udbf0\udfff"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb8c\ude0d\udbfa\ude6b\uda4c\udfab\udb36\udd50\udb1b\udd35\ue918\udaa6\udc72\ud852\udf59\u009a\udbf0\udf21\ud8c3\ude99\000\000\000\000\udb4e\udec6\ud8ac\udde4\udbaa\udeef2"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb9a\udf0d\udbfa\ude6b\uda4c\udfab\udb36\udd50\udb1b\udd35\ue918\udaa6\udc72\ud852\udf59\u009a\udbf0\udf21\ud8c3\ude99\000\000\000\000\udb4e\udec6\ud8ac\udde4\ud9b0\udce7l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda0a\udc73\ud8d3\uded8\uda50\udda3\udb36\udd50\udb1b\udf9a\ue918\udaa6\udc72\ud96d\udde7\u009a\udbf0\udf21\ud8c3\ude99\000\000\ud9fd\udecf\u00e0\udb4e\udec6\ud8ac\udde4\udbaa\udeef."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb9a\udf0d\udbfa\ude6b\uda4c\udfab\udb36\udd50\ud9d3\ude37\ue918\ud83f\udd74\ud8dc\udf02E\udbf0\udf21\ud97f\udf18\ud8b5\udcbd\u1ad1\000\000\udb4e\udec6\ud8ac\udde4\ud9b0\udce7l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb9a\udf0d\udbfa\ude6b\uda4c\udfab\udb36\udd50\ud9d3\ude37\ue918\ud83f\udd74\ud8dc\udf02E\udbf0\udf21\ud97f\udf18\ud8b5\udcbd\u1ad1\000\000\udb4e\udec6\ud9f8\udd1a\udb91\udc704"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb9a\udef2\udbfa\ude6b\uda4c\udfab\udb36\udd50\ud872\udd66\ue918\ud83f\udd74\ud8dc\udf02E"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb2d\udd8e\udbc8\udebd\udb01\udf02\ud8cb\udd2c\ud9e7\uddd8\uda9b\udc48\ud876\udead\ud900\udc5b\udaf8\udc00\uda1b\ude73\udb9c\udc7a\ud98e\udc93\ud959\udf91\000\uda1f\uded5\uda9d\udc5f\udaf3\udee7\ud945\udcfdF"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb9a\udef2\udbfa\udeae\uda4c\udfab\udb36\udd50\ud872\udd66\ue918\udb88\ude59\ud8dc\udf43L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb51\udca7\ud917\ude56\uf100\udb55\udcd4\udb1b\udcd4\ud84c\udf23\u00cd\ud8ba\udf2e\u487f\ud959\udd1a\udbfa\udc74\ud9f2\udcbf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb9a\udf0d\udbfa\ude6b\uda4c\udfab\udb36\udd50\ud9d3\ude37\ue918\ud83f\udd74\ud8dc\udf02E\udbf0\udf21\ud97f\udf18\ud8b5\udcbd\uda68\ude75D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb2d\udd8e\udbc8\udebd\ud9e4\udcb4\uda38\udf96\ud8e6\udd17\uda9b\udc48\ud876\udead\ud900\udc5b\uda7d\udc02\ud806\udf1d\udb92\ude49\ud9a3\udd5d\ud959\udff0\ud8a5\udd47\uda25\ude1c\ud9d3\ude7c\ud8e8\udecc\udb08\ude3fd"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud88d\udeb9\udbf3\udeb1\uda4c\udfab\udb36\udd50\ud9b1\udc37\ue918\ud83f\udd74\ud8dc\udf02E\ud923\udc3b\ud9e8\udc35\ud90e\udc8e\ud99b\ude4e\ud85e\udf1ce"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud83d\ude1e\ud86f\udc27\uda4c\udfab\udb36\udd50\ud9d3\ude37\ud880\udd1b\ud83f\udd74\ud8dc\udf02E\udbf0\udf21\ud97f\udf18\ud833\udc5c\u3757\udb1b\uddad.\ud9cf\uddc6\ud938\udf9a\udb8f\udccf4"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud83d\ude1e\ud86f\udc27\uda4c\udfab\udb36\udd50\ud9d3\ude37\ud880\udd1b\ud83f\udd74\ud8dc\udf02\udaf5\ude7f\udbf1\udc14\ud97f\udf18\ud833\udc5c\u3757\udb1b\uddad.\ud9cf\uddc6\ud886\ude21\uda2f\udfa8l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud83d\uddfd\ud86f\udc27\uda4c\udfab\udb36\udd50\ud9d3\ude37\ud880\udd1b\ud83f\udd74\ud8dc\udf02\udaf5\ude7f\udbf1\udc14\ud97f\udf18\ud8b7\udf7b\u3757\udb1b\uddad.\ud9cf\uddc6\ud872\udca9\uda2f\udfa8E\udb13\udf49\ud98d\udf27\ud808\udddb\udaf2\udd32\ud9c3\ude4e\ud9bc\udcf8\udb45\udd2a\ud9e2\udcba\ud842\udf48\ud88a\udf26"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud86c\uddde\udbfa\ude92\uda4c\udfab\udb36\udd50\ud9d3\ude37\ud948\uddc0\udac7\udff6\ud914\ude35f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("\ua908");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u17e3\udbfa\ude6b\uda4c\udfab\udb36\udd50\ud9d3\ude37\ue918\udbee\uddcb\ud9ce\udd1a\udbc0\udc1e\udbf0\udf43\ud97f\udf18\ud9b6\udee8\udb18\udd8f\udb19\udc11\u4978\uda5f\udd6f\ud9dc\udc35\ud9b0\udce7l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("l"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda32\udc9c\ud917\ude56\u9101\udb55\udcd4\udb1b\udd35\ud318\udaa9\udd72\ud8ba\udf2e\u487f\ud959\udd1a\udbfa\udc74\ud9f2\udcbf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u17e3\u096c\uda4c\udfab\udb36\udd50\ud9d3\ude37\ue918\udbee\udd79\ud9ce\udd1a\udbb6\udc19\udbf0\udf43\ud97f\udf18\ud9b6\udee8\udb18\udd8f\udb19\udc11\u4978\uda5f\udd6f\ud9dc\udc35\ud9b0\udce7l"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
