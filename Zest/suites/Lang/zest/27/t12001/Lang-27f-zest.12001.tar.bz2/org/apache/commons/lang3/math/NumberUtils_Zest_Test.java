package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumberUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda46\udf5d\ud93e\udcca\ud95c\udd1c\ud9c6\udf66\uda07\uddf5\ud9cc\uddbe\ud930\udca1\ud842\ude66\u6156\ud9b9\udf19\udb35\udc7e\udba7\udce9\ud9d7\udf07\uda83\udf5a\ud988\ude22\ud965\udfe8"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda46\udf5d\ud93e\udcca\ud95c\udd1c\ud9c6\udf66\uda07\uddf5\ud9cc\uddbe\ud953\udda1\ud842\ude66\u6156\ud9b9\udf19\udb35\udc7e\udba7\udce9\ud9d7\udf07\uda83\udf5a\ud988\ude22\ud965\udfe8"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda46\udf5d\ud871\udd17\ud83a\udf79\uda8f\udfdb\ud9e6\udf90\ud9cc\udddf\uda75\ude25\uda2e\udd9c\uda94\uddc9\ud9b9\udf19\ud979\udc7e\uda36\udeb6\ud9d9\ude94\uda83\udf5a\udbea\udd52\ud965\udfe8"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udaf1\udce8\uda30\udca7\uda74\udf04\ua93c\uda07\uddf5"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud8ce\uded2\ud93e\udcca\udb3e\udf8d\udb37\udf60\ud81b\udec4\uda34\udefc\ud9fa\udddf\ud8f5\ude83\udb52\udc28\uda82\udc73"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud848\udc6c\ud90b\udfca\ud95c\udd1c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda46\udf5d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(""); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda46\udf60\udbe9\ude7f\ud9d7\udff0\uda9c\udf51\uda07\uddf5\ud9cc\uddbe\ud8db\udea3\udabf\udcfd\udb3a\uddc0\udb44\udca0\ud80f\udd70\uc158\ud9d7\ude81\udadb\udf66\ud988\ude22\ud965\udfe8\ud860\udfbd\udb17\ude8f\ud9fa\uddf6\uda9a\ude6f\uf914\ud96d\udd33\uda33\udee8\ud80a\udd18\ud850\udedb\udadc\ude9d\udbe2\udc8e\ud9e8\udeb9\ud849\udf6d\ud9f6\udfcb\ud898\udfba\udb61\udfe3\ud8e2\udf40\ud948\uddb8"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ua954"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda46\udf5d\ud9bc\udee9\ud981\udce0\ud9c6\udf66\uda07\uddf5\ud9cc\uddbe.\ud842\ude40\ud8ef\ude4f\ud9b9\udf19\ubcfd\udba7\udce9\ud9d7\udf07\uda83\udf5a\ud988\ude22\ud965\udfe8"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb6d\udc9b\udb12\udced\udb8e\udcdf\ud9ed\ude5b\ud9fb\udf79\ud8f0\udd13\uf851\ud9d1\uddc5\ud9d6\udf26\udada\udf15\udbf0\udc5a\udbdc\udd54\ud8f8\udc9d\ud999\udf79\ud93f\udf1c\ud8bd\udebe\udb0b\ude7a\udb31\ude16\ud893\udd33\ud8c5\ude4b\udadb\ude90\udba2\ude6d\udb0c\uddd2\uda8d\uded8\udac6\udea5\ud899\udd97\ud9a2\udda9\udbe7\udd44\ud881\udef8\udbf6\ude24\ud94b\udff2\udb0c\udc56\ud9a8\uddef\uda01\udce0\udb7c\udfcb\udb67\udf9d\udbcf\udfa0\uda9f\udeb9\ud8ac\udf36\udaa0\udd9c\ud80e\udff5\ud9fd\udc0f\uda7a\udda3\uda7c\udd3c\u6c05\ud940\ude53\udb85\udef3\ud99d\ude3f\udbad\udd9b\uda0b\udf05\ud899\ude75\ud892\udc7f\ud9b1\udfbc\ud90b\udc01\ud95b\udf4c\ud858\ude75\ud818\uded5\ud8a4\udc56\udb17\udc1e\udb20\uddda\ud847\udc47\uda20\udef2\ud95b\ude2f\ud93f\ude30\udbac\udd42\ud9ff\udcd8\ud873\udf9f\ud961\udf01\udab8\udd31\ud9be\udc88\u7d9d\udb26\udf5c\udae0\udd14\ud882\udc8a\ud99e\udd79\uda4b\udff5\ud9b5\udf0f\ud919\udd1e"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda55\udffc\ud9bc\udee9\ud974\ude08\udbd0\udd1f\ud951\udd43\udae2\udd8a."); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udbc8\ude3e\udbda\ude40\ud981\udce0\udb50\udeab\uda07\ude45\uda12\uddc1.\ud842\ude40\udb49\ude5c\ud9b9\udf19\ubcfd\udba7\udce9\ud9d7\udf07\ud9c7\udf3c\ud98e\ude61\u06f7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda55\udffc\ud9bc\udee9\ud974\ude08\udbd0\udd1f\ud951\udd43\udae2\udd8af"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9e7\udc6f\udb03\udd27\u84a4\ue4b2\ud826\udc3f\uda11\udc12E\uda53\udf56\ud84c\udd2e\uc2c3\ud8b4\udea6\uda5d\udf68"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udbc8\ude3e\udbda\ude40\ud989\udef4\udb40\udf82\ud8e1\uddeb\udbc7\udc75G\uda12\udca8\ud9bb\udc79\udb4b\udfc6\u0942\udba7\udce9\ud9d7\udf07\udb5f\udcf5\ud98e\ude61\u06f7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9e7\udc6f\udb04\udf62\uda1e\ude63\udad3\udcd6\ud826\udc70\uda11\udc12E"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9e7\udd11\udb04\udf62\uda1e\ude63\udad3\udcd6\udbef\udd35\udabb\ude1al"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udb53\udec4\ud832\uddbc\ud902\ude3a\ud9c7\udc40\udad0\udfab\ud8b3\udf0c\ud9c1\ude6e\ud994\udd9f\udbcf\udda5\udb62\udc54\ud9a5\udff1\u2164\ud86a\ude06\uda83\udf5a\ud988\ude22\ud965\udfe8"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9e7\udc6f\udb04\udf62\uda1e\ude63\udad3\udcd6\ud826\udc70\ud945\udccbd"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud9e7\udc6f\udb04\udf62\uda1e\ude63\udad3\udcd6\ud826\udc70\udaa6\udf5dF"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang3.math.NumberUtils.createNumber("\ua9f5");
    assertNotNull(r);
    assertEquals("java.lang.Integer", r.getClass().getName());
    assertEquals("5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\ud910\uddfc\udb04\udf20\uda1e\ude63\udad3\udcd6\ud826\udc70\uda11\udc12D"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\uda55\udffc\ud9bc\udee9\ud974\ude08\udbd0\udd1f\ud951\udd43\udb51\udc80L"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("f"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\014\udb0e\udcea"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\014"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber(".\udb0e\udcea\uda36\udf44\ud8d0\ude3e\ud9af\udd86\ud8c6\udeab\udbc7\udc2a\ud9c3\ude70\ud8ea\uddaf\udadc\ude6b\ud846\udf0d\ud948\udc47\udaa3\udc1e\ud934\uddef\udb76\udc1a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\udbc8\ude3e\udbda\ude40\ud981\udce0\udb50\udeab\ud958\udfae\udb30\udf2dE\ud842\ude40\udb49\ude5c\ud9b9\udf19\ubcfd\udba7\udce9\udbc7\udf4f\ud9c7\udf3c\ud98e\ude61\u06f7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\011\uda90\udea7\ud988\udc17\udb50\udeab\uda07\ude45\uda12\uddc1.\ud842\ude40\uda8d\ude3e\udb3a\udffe\ubcfd\ud8f8\udc91\ud9d7\udecb\ud9c7\udf3c\ud98e\ude61\u06f7"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("L"); fail("expected StringIndexOutOfBoundsException"); }
    catch (java.lang.StringIndexOutOfBoundsException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang3.math.NumberUtils.createNumber("\u09e7\ud98a\ude53\ud9f7\udfd5\udac3\udeef\udbef\udd35\udabb\ude1al"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
