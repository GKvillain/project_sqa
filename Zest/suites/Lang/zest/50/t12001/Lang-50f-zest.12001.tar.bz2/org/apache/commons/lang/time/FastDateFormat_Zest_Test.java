package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastDateFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud893\udf7d\uda5c\udde9\ud974\ude62\ud861\udc5b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud893\udf7d\uda5c\udde9\ud974\ude62\ud861\udc5b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud893\udfac\uda5c\udde9\ud977\udcc5\ud9d6\udfd2");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud893\udfac\uda5c\udde9\ud977\udcc5\ud9d6\udfd2]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\uda5c\udd75\ud974\ude62\ud861\udc5b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\uda5c\udd75\ud974\ude62\ud861\udc5b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud893\udf7d\uda5c\udde9\ud974\ude62");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud893\udf7d\uda5c\udde9\ud974\ude62]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb46\udd7a\udb5d\udf69\uda43\udde8\uda89\udc47\u814f\udb48\uddf2\udbc2\udcd8\u48d8\ud9ae\uddd9\ud946\ude0e\uda17\udea6\ud959\ude9e\uda27\udf86\ud966\udc23\ud85e\udea7\uda24\udea7\ud9cd\udc60");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb46\udd7a\udb5d\udf69\uda43\udde8\uda89\udc47\u814f\udb48\uddf2\udbc2\udcd8\u48d8\ud9ae\uddd9\ud946\ude0e\uda17\udea6\ud959\ude9e\uda27\udf86\ud966\udc23\ud85e\udea7\uda24\udea7\ud9cd\udc60]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8ca\ude52");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8ca\ude52]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda48\ude81\udafe\uded0\ud807\ude65\ud886\udf79\ud95c\uddb5\udbfa\udc2b\uda66\udc29\ud94f\udedf\ud81e\udfd2\ud8b9\udd19\ud84b\ude11\ud811\udea9\ud912\udeca\ud8b1\udc50\uaec0\udb7c\udeda\ud9df\udf06");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda48\ude81\udafe\uded0\ud807\ude65\ud886\udf79\ud95c\uddb5\udbfa\udc2b\uda66\udc29\ud94f\udedf\ud81e\udfd2\ud8b9\udd19\ud84b\ude11\ud811\udea9\ud912\udeca\ud8b1\udc50\uaec0\udb7c\udeda\ud9df\udf06]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda43\udfc0\ud8b1\udcbb\udbc2\uded4\ud97c\ude3e\udb11\udd3f\ud989\udf3b\udbcb\udc1e\udaa8\udcd1");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda43\udfc0\ud8b1\udcbb\udbc2\uded4\ud97c\ude3e\udb11\udd3f\ud989\udf3b\udbcb\udc1e\udaa8\udcd1]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udebb\ud924\uddfb\ud91f\udd16\ud8c8\ude94\udb68\udd23\ud8b9\udd6e\udb36\ude02\ud9d1\udff7\udb5f\udfa9\ud995\udc23\ud98c\ude2e\udb5a\ude33\uda8b\udc77\udb07\udcfb\udb1a\uddfc\uda19\udd9c\uda51\udd22\uda96\ude13\ub0c3\ud99a\uddcc\ud939\udf73\udb49\udc10\ud82b\udd3c\uda93\udc49\udac3\udd8d\ud89a\udcfa\udbbe\udd30\u634b\udb16\udda4\ud817\ude07\ua5df\ud8fb\udca4\uda24\ude12\ud8c5\udd5b\uda37\udcc2\ud94e\udd40\u6096\uda42\udfb1\ud8f7\udcb5\udb53\ude54\uda6b\udd15\uda63\udc44");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udebb\ud924\uddfb\ud91f\udd16\ud8c8\ude94\udb68\udd23\ud8b9\udd6e\udb36\ude02\ud9d1\udff7\udb5f\udfa9\ud995\udc23\ud98c\ude2e\udb5a\ude33\uda8b\udc77\udb07\udcfb\udb1a\uddfc\uda19\udd9c\uda51\udd22\uda96\ude13\ub0c3\ud99a\uddcc\ud939\udf73\udb49\udc10\ud82b\udd3c\uda93\udc49\udac3\udd8d\ud89a\udcfa\udbbe\udd30\u634b\udb16\udda4\ud817\ude07\ua5df\ud8fb\udca4\uda24\ude12\ud8c5\udd5b\uda37\udcc2\ud94e\udd40\u6096\uda42\udfb1\ud8f7\udcb5\udb53\ude54\uda6b\udd15\uda63\udc44]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uad6e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uad6e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud893\udf7d\uda5c\udde9\ud974\ude62\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\ud941\udc3c\ud9f2\ude3eu\ud9ff\uddd4\ud906\udefb\ud9c8\udc9b\udb6b\ude66"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud85b\udf6d\uda5c\udde9M");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud85b\udf6d\uda5c\udde9M]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud900\udd67M\ud9d6\udf94");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud900\udd67M\ud9d6\udf94]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud893\udfac\uda5c\udde9M\ud8d2\udd88");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud893\udfac\uda5c\udde9M\ud8d2\udd88]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("I\uda5c\udd75\ud909\udf41\ud841\udf33\ud84b\udcc8\udb0a\udc53\ud833\udd94\uda2c\udce2\udb83\udf07"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("Q\uda5c\udd75\udabd\udca0\ud861\udc5b\uda52\udd94\ud9c9\udc39\ud975\udc59\ud9a5\uddbe\ud98f\uded5\udb87\udf90\ud871\udd3b\ud9db\ude34\ud96f\ude17\ud8dd\udf9e\ud9f7\udfb2\uda3a\udfa7\uda26\udc18"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\ud913\udef3\uda75\udd64\ud8e3\udd46\u6d13\udae0\udc1a\ud974\udebc\ud92e\udfe9\ud87a\ude3b\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udad3\udfbc\ud92d\udd64\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\udbb3\ude16\ud813\udfc2\ud820\uddcd\udbc8\udefb\ud81e\udeac\ud8af\udc81\ud8b8\udc19\ud8d1\udcbb\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda4e\ude9b\ud823\udd92\uda79\ude84\ud877\udde6\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\ud81e\udfec\ud934\udfee\uda10\uded5\udb8a\udc1c\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\ud997\udd84\uda89\uded2\ud831\udffd\ud819\ude3e\uda13\ude0d\uda33\udc7f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\ud913\udef3\uda75\udd64\ud8e3\udd46\u6d13\udae0\udc1a\ud974\udebc\ud92e\udfe9\ud87a\ude3b\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udad3\udfbc\ud92d\udd64\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\udbb3\ude16\ud813\udfc2\ud820\uddcd\udbc8\udefb\ud81e\udeac\ud8af\udc81\ud8b8\udc19\ud8d1\udcbb\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda4e\ude9b\ud823\udd92\uda79\ude84\ud877\udde6\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\ud81e\udfec\ud934\udfee\uda10\uded5\udb8a\udc1c\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\ud997\udd84\uda89\uded2\ud831\udffd\ud819\ude3e\uda13\ude0d\uda33\udc7f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("R"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("s\ud828\udde2\udbb8\ude95\ud93c\ude11\udb9c\udde9\udb8c\ude1c");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[s\ud828\udde2\udbb8\ude95\ud93c\ude11\udb9c\udde9\udb8c\ude1c]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("N\ud9f2\udc9b\udb06\udfc2\udb4c\udfba\ud870\udd2b\udb33\udeb6\ud9dc\udc90\ud8e4\udf53\uda41\uded2\ud9bb\udde7"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("J"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda82\udebb\ud924\uddfb\ud91f\udd16\ud8c8\ude94\udb68\udd23\u1896\000\000\000\ud975\udd79\020\udb5a\uddc4\uda8b\udc77\udb07\udcfb\udb1a\uddfc\uda19\udd9c\uda51\udd22\uda96\ude13\ub0c3\ud99a\uddcc\u00cd\000\000\000\uda97\ude4a\ud89a\udcfa\udbbe\udd30\u634b\udb16\udda4\ud817\ude07\ua5df\ud8fb\udca4\uda24\ude12\ud8c5\udd5b\uda37\udcc2\ud94e\udd40\u6096\uda42\udfb1\ud8f7\udcb5\udb53\ude54\000\uda63\udc44");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda82\udebb\ud924\uddfb\ud91f\udd16\ud8c8\ude94\udb68\udd23\u1896\000\000\000\ud975\udd79\020\udb5a\uddc4\uda8b\udc77\udb07\udcfb\udb1a\uddfc\uda19\udd9c\uda51\udd22\uda96\ude13\ub0c3\ud99a\uddcc\u00cd\000\000\000\uda97\ude4a\ud89a\udcfa\udbbe\udd30\u634b\udb16\udda4\ud817\ude07\ua5df\ud8fb\udca4\uda24\ude12\ud8c5\udd5b\uda37\udcc2\ud94e\udd40\u6096\uda42\udfb1\ud8f7\udcb5\udb53\ude54\000\uda63\udc44]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\ud967\udf12\ud861\udc5b\ud9c7\udcd9H\000\udbda\udc0c\u009a\000\ud8fc\udcde\ud9c5\udf61\udb6b\ude66");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\ud967\udf12\ud861\udc5b\ud9c7\udcd9H\000\udbda\udc0c\u009a\000\ud8fc\udcde\ud9c5\udf61\udb6b\ude66]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud922\udfb6\ud9aa\udc58\ud8aa\udcc2\ud860\udfd7\ud9c7\udcd9\ud967\udfd0\ud940\udfbb\ud840\ude24z\ud9ff\uddd4\ue97f\ud865\ude56\udafd\ude6f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud922\udfb6\ud9aa\udc58\ud8aa\udcc2\ud860\udfd7\ud9c7\udcd9\ud967\udfd0\ud940\udfbb\ud840\ude24z\ud9ff\uddd4\ue97f\ud865\ude56\udafd\ude6f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud893\udf7d\uda5c\udde9\ud974\ude62\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\ud941\udc3c\ud9f2\ude3ey\ud9ff\uddd4\ud906\udefb\ud9c8\udc9b\udb6b\ude66");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud893\udf7d\uda5c\udde9\ud974\ude62\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\ud941\udc3c\ud9f2\ude3ey\ud9ff\uddd4\ud906\udefb\ud9c8\udc9b\udb6b\ude66]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8de\ude42\uda40\udf2f\ud974\ude62\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\ud941\udc3c\ud9f2\ude3eW\uda1b\udfd4\ud906\udefb\uda28\udf0d\ud9ff\ude42");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8de\ude42\uda40\udf2f\ud974\ude62\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\ud941\udc3c\ud9f2\ude3eW\uda1b\udfd4\ud906\udefb\uda28\udf0d\ud9ff\ude42]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud902\ude8c\udb5c\udf63\ud973\udddc\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\uda13\uddaf\ud9df\udd11S\udb19\ude01\ud8b4\udf95\ud9fa\udd9b\udbcc\udd50\udafd\udffa\ud887\udf93\udade\udd25\ud808\ude50");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud902\ude8c\udb5c\udf63\ud973\udddc\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\uda13\uddaf\ud9df\udd11S\udb19\ude01\ud8b4\udf95\ud9fa\udd9b\udbcc\udd50\udafd\udffa\ud887\udf93\udade\udd25\ud808\ude50]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\020\000\ud967\udf5f\ud861\udc5b\ud9c7\udcd9H\000\ud9f2\ude0cu\ud9ff\uddd4\ud906\udefb\ud9c8\udc61\udb6b\ude66"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8e5\udd82\uda00\udd23\ud974\ude62\ud9cf\udff4\udaa6\ude11\udb1e\udd12\ud94e\udce6\ud9f2\ude3ea\udacd\udddb\ud846\ude10\ud923\udc3c\ud81d\udddf\ud867\udc4b\ud9a8\udd47\udaa6\udf7b\udbc7\udc36\udae9\udc37\udb27\udc4f\ud86e\uddd4\udb4f\udea0\ud90c\udd02\ud895\udc1a\ud992\ude7b\ud85e\udc41\ud8d0\udcb3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8e5\udd82\uda00\udd23\ud974\ude62\ud9cf\udff4\udaa6\ude11\udb1e\udd12\ud94e\udce6\ud9f2\ude3ea\udacd\udddb\ud846\ude10\ud923\udc3c\ud81d\udddf\ud867\udc4b\ud9a8\udd47\udaa6\udf7b\udbc7\udc36\udae9\udc37\udb27\udc4f\ud86e\uddd4\udb4f\udea0\ud90c\udd02\ud895\udc1a\ud992\ude7b\ud85e\udc41\ud8d0\udcb3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud893\udf7d\uda5c\udde9\ud974\ude62\ud861\udc5b\udaff\udcd5\udaa0\udd0d\ud93a\udfb8\u1f0ed\ud9ff\uddd4\ud906\udefb\ud9c8\udc9b\udba3\ude63");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud893\udf7d\uda5c\udde9\ud974\ude62\ud861\udc5b\udaff\udcd5\udaa0\udd0d\ud93a\udfb8\u1f0ed\ud9ff\uddd4\ud906\udefb\ud9c8\udc9b\udba3\ude63]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud85b\udf6d\uda5c\udde9L"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud9f9\udd42A\ud93d\udf3b\uda28\ude32\udbdd\ude87\udac3\udc91\ud917\udea3\udbcc\udc28\udad2\udc75"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbf2\udf47\ud8ee\udf0bG\uda18\udf95\udb40\udd87\uda07\udd84\ud8d7\udf5f\ud88c\ude8b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbf2\udf47\ud8ee\udf0bG\uda18\udf95\udb40\udd87\uda07\udd84\ud8d7\udf5f\ud88c\ude8b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\000\udb2b\udf77P\udb68\udcb6\uda0b\udd48\udad0\uddfa\u74b5\ud925\ude10\uda09\udffa\uda22\uded7\ud9cd\udc0e\udb60\udcf8\ud9a0\udd96\u5289\udb35\udedf\udb74\uddb9\udb9b\udfb9"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\ud913\udef3\uda75\udd64\ud9d9\udf9a\u6c87\udae0\udc1a\ud974\udebc\ud92e\udfe9\ud87a\ude3b\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udbfd\ude0f\ud92d\udd7b\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\ud8b5\ude17\ud813\udfc2\ud820\uddcd\udbc8\udefb\ud81e\udeac\ud995\udd54\ud8ad\udfba\ud8d1\udcbb\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda4e\ude9b\ud823\udd92\uda79\ude84\ud877\udde6\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\uda37\udfd4K\ud832\udc16\ud819\ude3e\uda13\ude0d\uda33\udc7f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\ud913\udef3\uda75\udd64\ud9d9\udf9a\u6c87\udae0\udc1a\ud974\udebc\ud92e\udfe9\ud87a\ude3b\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udbfd\ude0f\ud92d\udd7b\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\ud8b5\ude17\ud813\udfc2\ud820\uddcd\udbc8\udefb\ud81e\udeac\ud995\udd54\ud8ad\udfba\ud8d1\udcbb\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda4e\ude9b\ud823\udd92\uda79\ude84\ud877\udde6\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\uda37\udfd4K\ud832\udc16\ud819\ude3e\uda13\ude0d\uda33\udc7f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("D\udb46\uddda\udbb8\ude95");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[D\udb46\uddda\udbb8\ude95]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("O\ud9f2\udc9b\udb06\udfc2\udb4c\udfba\ud870\udd2b\udb33\udeb6\ud9dc\udc90\ud8e4\udf53\uda41\uded2\ud9bb\udde7"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("m\udbba\udf69\ud9f5\udcaa\udb4c\udfba\ud870\udd2b\ud9b5\udda8\ud9db\udfe0\ud8e4\udf53\uda41\uded2\ud9bb\udde7");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[m\udbba\udf69\ud9f5\udcaa\udb4c\udfba\ud870\udd2b\ud9b5\udda8\ud9db\udfe0\ud8e4\udf53\uda41\uded2\ud9bb\udde7]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9db\udeff\ud9b4\udfa4\ud967\udff0\uda98\udd5d\ud85e\udea2\ud88a\udd77W\ud951\udd6f\ud9b8\udcddm\udbf3\udedb\udaf3\ude8e\ud895\udc7c\udab3\udc48\udbb7\udc14");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9db\udeff\ud9b4\udfa4\ud967\udff0\uda98\udd5d\ud85e\udea2\ud88a\udd77W\ud951\udd6f\ud9b8\udcddm\udbf3\udedb\udaf3\ude8e\ud895\udc7c\udab3\udc48\udbb7\udc14]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\u00b5\uda90\udc05\ud849\ude29\ud861\udc5b\ud9c7\udcd9H\ud8a4\udff2\udbf6\udd0cB\000\ud8fc\uddaf\ud9c5\udf61\udb6b\ude66"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude26h\ud967\udf12\ud861\udc5b\ud9c7\udcd9H\000\udbda\udc0c\u009a\000\ud8fc\udcde\ud9c5\udf61\udb6b\ude66");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude26h\ud967\udf12\ud861\udc5b\ud9c7\udcd9H\000\udbda\udc0c\u009a\000\ud8fc\udcde\ud9c5\udf61\udb6b\ude66]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("k\ua200\ud967\udf12\ud861\udc5b\ud9c7\udcd9H\000\ud861\udf21\u00f9\000\ud8fc\udcde\ud9c5\udf61\udb6b\ude66");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[k\ua200\ud967\udf12\ud861\udc5b\ud9c7\udcd9H\000\ud861\udf21\u00f9\000\ud8fc\udcde\ud9c5\udf61\udb6b\ude66]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud891\udcab\ud892\udd89\udba1\ude92\ud861\udc26\udb18\ude81E\000\ud858\udde7\ud815\ude76\uffb6\uda28\udc0e\ud9e2\udf42\udba8\udef4\udb28\ude9f\udab8\udfd0\ud814\udcea\ud832\udd9e\ud948\udcf9\udaa2\udee2\ud962\udfd2\ud946\uddd5\ud815\udc6e\udaa8\udfd6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud891\udcab\ud892\udd89\udba1\ude92\ud861\udc26\udb18\ude81E\000\ud858\udde7\ud815\ude76\uffb6\uda28\udc0e\ud9e2\udf42\udba8\udef4\udb28\ude9f\udab8\udfd0\ud814\udcea\ud832\udd9e\ud948\udcf9\udaa2\udee2\ud962\udfd2\ud946\uddd5\ud815\udc6e\udaa8\udfd6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud9a9\udfce\ud8aa\udcc2\udb8e\ude4e\ud9c7\udcd9\ud967\udfd0'\ud84d\udee5z\ud9ff\uddd4\035\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud9a9\udfce\ud8aa\udcc2\udb8e\ude4e\ud9c7\udcd9\ud967\udfd0'\ud84d\udee5z\ud9ff\uddd4\035\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud922\udfb6\ud8e4\udd0b\000\000\000\uda37\udc7a'");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud922\udfb6\ud8e4\udd0b\000\000\000\uda37\udc7a']", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud922\udfb6\ud9aa\udc58\ubf85\000\000\uda37\udc7a\ud940\udfbb\ud840\ude24z\ud8d2\udc5d\u1362\ud865\udd66e"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud922\udfb6\ud9aa\udc58\ud8aa\udcc2\uda1e\udcd1\ud8bf\udc2c\ud967\udfd0\ud989\udf9b\ud98e\udc0bw\u8724\ue97f\ud865\ude56\uda83\udc26\udb1e\udec7\ud834\ude73\ud8b9\ude5a\uda30\udfd5\ud947\udf54\ud83b\ude77\udb1e\udce5\uda9d\udd47\uda94\ude62\ud9fd\ude79\udaed\udd8a\udaef\udfd1\udae3\udc75\udbc5\ude9d\ud8f3\udf38\udb94\udc71\uda57\udff6\ud9eb\udf36\udbf5\udf18\udba4\udf66\ud944\ude0b\uda65\udc70\udaf0\udd10\ud90d\udc2b\udae9\udce0\uda6e\udd3b\udb35\uddcb\udbf4\udf15\ud926\udce4\ud82d\ude7c\udba8\uddf6\ud9c2\udfcc\udaa2\ude9e\uda09\uddbe\udb4e\udf2c\ud9c0\udf0b\udbf5\udc30\ud9e8\ude9c\ud938\uddaa\uda3d\udd1f\udb9d\udfb5\udba6\udfc5\ud8ea\udc21");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud922\udfb6\ud9aa\udc58\ud8aa\udcc2\uda1e\udcd1\ud8bf\udc2c\ud967\udfd0\ud989\udf9b\ud98e\udc0bw\u8724\ue97f\ud865\ude56\uda83\udc26\udb1e\udec7\ud834\ude73\ud8b9\ude5a\uda30\udfd5\ud947\udf54\ud83b\ude77\udb1e\udce5\uda9d\udd47\uda94\ude62\ud9fd\ude79\udaed\udd8a\udaef\udfd1\udae3\udc75\udbc5\ude9d\ud8f3\udf38\udb94\udc71\uda57\udff6\ud9eb\udf36\udbf5\udf18\udba4\udf66\ud944\ude0b\uda65\udc70\udaf0\udd10\ud90d\udc2b\udae9\udce0\uda6e\udd3b\udb35\uddcb\udbf4\udf15\ud926\udce4\ud82d\ude7c\udba8\uddf6\ud9c2\udfcc\udaa2\ude9e\uda09\uddbe\udb4e\udf2c\ud9c0\udf0b\udbf5\udc30\ud9e8\ude9c\ud938\uddaa\uda3d\udd1f\udb9d\udfb5\udba6\udfc5\ud8ea\udc21]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud88d\udf8f\ud926\udf85\ud87d\uddaa\ud965\ude14\udb34\udf9b\ud8d2\ude00\ud941\udc0b\ud840\ude24C\ud9ff\uddd4\ue97f\udbfa\udf81\udafd\udedd"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbde\udde3\udabf\udfda\ud8fa\udfa8\uda4f\udf6a\ud9c7\udd8a\u8f9b\udbb9\ude8f\udbf3\udf0bZ\uda1b\udfd4\ud908\udf03\uda28\udf93\ud9ff\ude42");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbde\udde3\udabf\udfda\ud8fa\udfa8\uda4f\udf6a\ud9c7\udd8a\u8f9b\udbb9\ude8f\udbf3\udf0bZ\uda1b\udfd4\ud908\udf03\uda28\udf93\ud9ff\ude42]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud902\ude8c\udb5c\udf63\ud973\udddc\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\uda13\uddaf\ud9df\udd11S\udb19\ude01\ud8b4\udf95\ud9fa\udd9bF\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud902\ude8c\udb5c\udf63\ud973\udddc\ud861\udc5b\ud9c7\udcd9\udaa0\udd0d\uda13\uddaf\ud9df\udd11S\udb19\ude01\ud8b4\udf95\ud9fa\udd9bF\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbc6\ude26h\ud967\udf12\ud861\udc5b\ud9c7\udcd9H\ua8b5\ud9fe\udf6b\ud862\udcb0a\ud8fc\udcde\ud9c5\udf61\ud950\udfda");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbc6\ude26h\ud967\udf12\ud861\udc5b\ud9c7\udcd9H\ua8b5\ud9fe\udf6b\ud862\udcb0a\ud8fc\udcde\ud9c5\udf61\ud950\udfda]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud9a9\udfce\ud8aa\udcc2\udb8e\ude4e\ud9c7\udcd9\ud967\udfd0'\ud84d\udee5z\u1858\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud9a9\udfce\ud8aa\udcc2\udb8e\ude4e\ud9c7\udcd9\ud967\udfd0'\ud84d\udee5z\u1858\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb37\ude7e\ud944\udcaf\ud8aa\udcc2\udb8e\ude4e\ud9d4\udce4\ud967\udfd0'\ud957\udc2b\u3a3f\ud91c\udfc8\ud96f\uddd0\ud8af\udd55\ud9a1\udef0\ud9d0\ude74\uda6e\udfdd\ud87f\udd29\uda8a\udeba\udab7\udc13\ud891\udf3b\udb3c\udf59\ud9bf\udc58\udbfa\udc72\uda7a\udc83\ud901\ude27\udb79\udc61\ud9c3\udc51\udaa3\udf28\udb2e\udf1b\udb64\udc2a\u4f2e\udbbc\udcdd\ud874\udccb\ud9cc\ude8b\udab1\udeae\ud8ba\udcd5\ud977\udd50\ud93e\udf16\udbf1\ude03\u662d\udade\udc42\uda85\udeee");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb37\ude7e\ud944\udcaf\ud8aa\udcc2\udb8e\ude4e\ud9d4\udce4\ud967\udfd0'\ud957\udc2b\u3a3f\ud91c\udfc8\ud96f\uddd0\ud8af\udd55\ud9a1\udef0\ud9d0\ude74\uda6e\udfdd\ud87f\udd29\uda8a\udeba\udab7\udc13\ud891\udf3b\udb3c\udf59\ud9bf\udc58\udbfa\udc72\uda7a\udc83\ud901\ude27\udb79\udc61\ud9c3\udc51\udaa3\udf28\udb2e\udf1b\udb64\udc2a\u4f2e\udbbc\udcdd\ud874\udccb\ud9cc\ude8b\udab1\udeae\ud8ba\udcd5\ud977\udd50\ud93e\udf16\udbf1\ude03\u662d\udade\udc42\uda85\udeee]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud9a9\udfce\udae4\udf5e\udb72\ude8f\ud9c7\udcd9\ud967\udfd0'\ud84d\udee5");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud9a9\udfce\udae4\udf5e\udb72\ude8f\ud9c7\udcd9\ud967\udfd0'\ud84d\udee5]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud9a9\udfce\ud8aa\udcc2\udb8e\ude4e\udac0\udc95\ud967\udfd0'\ud84d\udee5z\ud9ff\uddd4\uda8d\udfe3'\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud9a9\udfce\ud8aa\udcc2\udb8e\ude4e\udac0\udc95\ud967\udfd0'\ud84d\udee5z\ud9ff\uddd4\uda8d\udfe3'\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud9a9\udfce\uda6c\udd03\udb75\udd9d\ud9c7\udcd9\ud967\udfd0'\ud84d\udee5z\ud8d7\ude27\u4eff\uda43\ude20\uda44\udd26\ud97a\ude8d\ud872\udc80\udb54\udd39\udb60\udded\uda08\udde1\ud942\ude42\ud809\uddec\uda04\uddd1\udb8f\udfd6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud9a9\udfce\uda6c\udd03\udb75\udd9d\ud9c7\udcd9\ud967\udfd0'\ud84d\udee5z\ud8d7\ude27\u4eff\uda43\ude20\uda44\udd26\ud97a\ude8d\ud872\udc80\udb54\udd39\udb60\udded\uda08\udde1\ud942\ude42\ud809\uddec\uda04\uddd1\udb8f\udfd6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud94c\udf78\u4543\ud8dd\udc23\ud8e4\udde9\uda55\udf41\uda5b\udc8b'\ud84d\udee5\u4524\ud834\udf62\uda11\udf19\udaf7\udf38\ud89e\udf8b\ud939\udd8f\ud97a\udd10\ud854\udd84\ud854\udf9d\ud85f\udc02\ud84c\udfe9\ud8a8\udc6e\ud8ae\udfa8\ud8f7\udcd5\udb60\uded6\ud8e3\uddac\ud893\uddf8\uda62\ude5d\ud80b\ude83\ud86e\udd91\ud848\udff4\ud893\ude37\ud8d6\udfe7\ud882\udf63\ud870\udc9e\ud822\udea4\uda40\udeac\udbf8\udc12");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud94c\udf78\u4543\ud8dd\udc23\ud8e4\udde9\uda55\udf41\uda5b\udc8b'\ud84d\udee5\u4524\ud834\udf62\uda11\udf19\udaf7\udf38\ud89e\udf8b\ud939\udd8f\ud97a\udd10\ud854\udd84\ud854\udf9d\ud85f\udc02\ud84c\udfe9\ud8a8\udc6e\ud8ae\udfa8\ud8f7\udcd5\udb60\uded6\ud8e3\uddac\ud893\uddf8\uda62\ude5d\ud80b\ude83\ud86e\udd91\ud848\udff4\ud893\ude37\ud8d6\udfe7\ud882\udf63\ud870\udc9e\ud822\udea4\uda40\udeac\udbf8\udc12]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud9a9\udfce\uda92\udecf\uda00\ude68\udac0\udc95\ud9fd\udefe\ud942\udcb6\ud863\uddb8z\ud9ff\uddd4\uda8e\udcb2'\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud9a9\udfce\uda92\udecf\uda00\ude68\udac0\udc95\ud9fd\udefe\ud942\udcb6\ud863\uddb8z\ud9ff\uddd4\uda8e\udcb2'\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud925\udd3f\udab8\ude12\ud974\ude62\udbfc\udf31");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud925\udd3f\udab8\ude12\ud974\ude62\udbfc\udf31]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u2ce0\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\u00fa\udb0c\ude66\ud917\udef8\ubb00\000\ud95b\udc8d\ud92e\udfe9\ud87a\ude3b\uda9a\ude83K\000\000\ud8f3\udf79\udbfd\ude0f\ud92d\udd7b\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\ud8b5\ude17\ud813\udfc2\ud820\udd0f\udbc8\udefb\ud81e\udeac\uf2c7\000\000\000\000\udb14\udffb\udb4c\ude6a\uda08\udf3a\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda16\udd2a\ud823\udd92\uda79\ude84\ud877\udde6\udba9\udd19\\\udacb\udc65\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\ub7ab\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\uda37\udfd4K\ud832\udc16S\ud87a\uddfd\uda33\udc7f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u2ce0\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\u00fa\udb0c\ude66\ud917\udef8\ubb00\000\ud95b\udc8d\ud92e\udfe9\ud87a\ude3b\uda9a\ude83K\000\000\ud8f3\udf79\udbfd\ude0f\ud92d\udd7b\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\ud8b5\ude17\ud813\udfc2\ud820\udd0f\udbc8\udefb\ud81e\udeac\uf2c7\000\000\000\000\udb14\udffb\udb4c\ude6a\uda08\udf3a\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda16\udd2a\ud823\udd92\uda79\ude84\ud877\udde6\udba9\udd19\\\udacb\udc65\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\ub7ab\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\uda37\udfd4K\ud832\udc16S\ud87a\uddfd\uda33\udc7f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000h\ud967\udf12\000\udae2\uddb1H\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000h\ud967\udf12\000\udae2\uddb1H\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud922\udf12\ud9aa\udc58\ubf85\000\ud8bf\udc12\ud967\udfd0\ud87d\udc34\ud98e\udc0b\u009c\u8724\ue97f\ud865\ude56\uda83\udc26\udb1e\udde3\ud834\ude73\ud8b9\ude5a\000\000\ud81f\udcaf\udac2\udcd7\udbca\udebe\uda94\ude62\ud9fd\ude1f\udaed\udd8a\000\udab8\udd3b\000\000\000\000\ud9f5\udddb\udbf5\ude7d\udba4\udf66\ud944\ude0b\000\udbd2\udd29\ud90d\udc2b\udae9\udc05\000\000\000\000\ud82d\ude7c\udba8\uddf6\ud9c2\udf14\udaa2\ude9e\uda09\uddbe/\ud9c0\ude67\udbf5\udc30\ud80c\udd02\ud906\udcc2\uda3d\udd1f\u5cd3\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud922\udf12\ud9aa\udc58\ubf85\000\ud8bf\udc12\ud967\udfd0\ud87d\udc34\ud98e\udc0b\u009c\u8724\ue97f\ud865\ude56\uda83\udc26\udb1e\udde3\ud834\ude73\ud8b9\ude5a\000\000\ud81f\udcaf\udac2\udcd7\udbca\udebe\uda94\ude62\ud9fd\ude1f\udaed\udd8a\000\udab8\udd3b\000\000\000\000\ud9f5\udddb\udbf5\ude7d\udba4\udf66\ud944\ude0b\000\udbd2\udd29\ud90d\udc2b\udae9\udc05\000\000\000\000\ud82d\ude7c\udba8\uddf6\ud9c2\udf14\udaa2\ude9e\uda09\uddbe/\ud9c0\ude67\udbf5\udc30\ud80c\udd02\ud906\udcc2\uda3d\udd1f\u5cd3\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud800\ude00\000\000\000\000\000\000\ud98d\udfd9\u009c\u8724\ue97f\ud865\ude56\000\000\000\000\000\000\000\000\000\uda94\udde1\ud9fd\ude1f\ud8db\udd81\000\000\000\000\000\000\ud9f5\udddb\udbf5\ude7d\udba4\udf66\ud944\ude0b\000\udbd2\udd29\ud90d\udc2b\udae9\udc05\000\000\000\000\ud82d\ude7c\udba8\uddf6\ud9c2\udf14\udaa2\ude9e\uda09\uddbe/\000\000\000\ud906\udcc2\udb60\udff1\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud800\ude00\000\000\000\000\000\000\ud98d\udfd9\u009c\u8724\ue97f\ud865\ude56\000\000\000\000\000\000\000\000\000\uda94\udde1\ud9fd\ude1f\ud8db\udd81\000\000\000\000\000\000\ud9f5\udddb\udbf5\ude7d\udba4\udf66\ud944\ude0b\000\udbd2\udd29\ud90d\udc2b\udae9\udc05\000\000\000\000\ud82d\ude7c\udba8\uddf6\ud9c2\udf14\udaa2\ude9e\uda09\uddbe/\000\000\000\ud906\udcc2\udb60\udff1\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud894\udf0cH\ud967\udf12\udb06\udc5a\ud9c7\udcd9H\000\udbda\udc0c\u009a\031\uda85\udce5\ud8bc\udff8\udb43\uddb6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud894\udf0cH\ud967\udf12\udb06\udc5a\ud9c7\udcd9H\000\udbda\udc0c\u009a\031\uda85\udce5\ud8bc\udff8\udb43\uddb6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda67\udcf6\uda23\udf72\udac9\udf71\ud8f6\udc77\ud9b5\udf8bEE\uef79\ud912\udc7f\ud89c\udcdf\ud9f7\udc82\udb7e\udc2e\ud9c1\udd26\ud98c\uddbd\uda46\ude02\ud814\udcea\uda25\uddd8\uda39\udeea\ud9cd\udd98\ud871\udced\ud8b9\udffe\u5911\udb5b\udff2");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda67\udcf6\uda23\udf72\udac9\udf71\ud8f6\udc77\ud9b5\udf8bEE\uef79\ud912\udc7f\ud89c\udcdf\ud9f7\udc82\udb7e\udc2e\ud9c1\udd26\ud98c\uddbd\uda46\ude02\ud814\udcea\uda25\uddd8\uda39\udeea\ud9cd\udd98\ud871\udced\ud8b9\udffe\u5911\udb5b\udff2]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud860\ude95\ud864\udd96\ud93b\udee6\ud838\udf89\uda92\udd1a\uda7e\udf99\uda1c\udf29\ud852\udd6az\uda99\uddb2\ud96e\uddec\ud9f5\udd50z\ud814\udf8e\ud9cf\udf35\uda9e\udeda\uda1c\udfb2\ud88a\ude24\ud9d1\ude56\uee61\udb17\ude3f\uda3a\udd24\ud946\uddcd\udbad\udfe3\ud8f6\udc0e\udb29\udf96\udb61\udec3\ud8d2\udc99\udb42\udc3a\udbcb\ude94\udb0b\udcc9\ud8de\udc43\ud8cd\udc50\ud9a1\udc14\ud892\udf6f\ud8ad\udde0\ud8ed\udc9d\udbde\udea8\udb47\udca3\ud87a\udfbb\udbed\udce6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud860\ude95\ud864\udd96\ud93b\udee6\ud838\udf89\uda92\udd1a\uda7e\udf99\uda1c\udf29\ud852\udd6az\uda99\uddb2\ud96e\uddec\ud9f5\udd50z\ud814\udf8e\ud9cf\udf35\uda9e\udeda\uda1c\udfb2\ud88a\ude24\ud9d1\ude56\uee61\udb17\ude3f\uda3a\udd24\ud946\uddcd\udbad\udfe3\ud8f6\udc0e\udb29\udf96\udb61\udec3\ud8d2\udc99\udb42\udc3a\udbcb\ude94\udb0b\udcc9\ud8de\udc43\ud8cd\udc50\ud9a1\udc14\ud892\udf6f\ud8ad\udde0\ud8ed\udc9d\udbde\udea8\udb47\udca3\ud87a\udfbb\udbed\udce6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud902\ude57\udb5c\udf63\ud99c\udf11\ud861\udc5b\udbe1\uddda\udaa0\udcd3\uda13\uddaf\ud9df\udd11S\udb19\ude01\udb23\udf8b\ud82a\udcf3F\000F\uda0c\udfc5\udad7\udc7c\ud9b2\udda8\udb02\udd0a\ud817\udd9a\ud9de\udcc5\udbba\udf02\ud973\udd1e\ud9ea\udea6\udb15\ude23\ud832\udf8d\ud878\udcff\uda38\udf45\uda57\udf70\udada\udcb2\ud817\udf96\ud94b\udc7e\u8465\uda0f\ude4f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud902\ude57\udb5c\udf63\ud99c\udf11\ud861\udc5b\udbe1\uddda\udaa0\udcd3\uda13\uddaf\ud9df\udd11S\udb19\ude01\udb23\udf8b\ud82a\udcf3F\000F\uda0c\udfc5\udad7\udc7c\ud9b2\udda8\udb02\udd0a\ud817\udd9a\ud9de\udcc5\udbba\udf02\ud973\udd1e\ud9ea\udea6\udb15\ude23\ud832\udf8d\ud878\udcff\uda38\udf45\uda57\udf70\udada\udcb2\ud817\udf96\ud94b\udc7e\u8465\uda0f\ude4f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud902\ude8c\udb5c\udf63\ud973\udddc\ud861\udc62\udb8d\uddfb\uda88\ude37\udb30\udfff\ud9df\udc53S\ud8d8\udce1\uda85\udf96\ud9fa\udda9F\uda34\udc35\ud92b\udd5dS\udbbe\udfdf\udacc\udeda\udb8b\udea3");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud902\ude8c\udb5c\udf63\ud973\udddc\ud861\udc62\udb8d\uddfb\uda88\ude37\udb30\udfff\ud9df\udc53S\ud8d8\udce1\uda85\udf96\ud9fa\udda9F\uda34\udc35\ud92b\udd5dS\udbbe\udfdf\udacc\udeda\udb8b\udea3]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud902\ude8c\udb5c\udf63\ud973\udddc\000\000\udbfd\udc52\udb1c\udfae\ud9df\udc53S\u1858\000\ud9fa\udda9F\uda34\udc35\ud92b\udd5dS\udbbe\udfdfK\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud902\ude8c\udb5c\udf63\ud973\udddc\000\000\udbfd\udc52\udb1c\udfae\ud9df\udc53S\u1858\000\ud9fa\udda9F\uda34\udc35\ud92b\udd5dS\udbbe\udfdfK\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\ud913\udef3\uda75\udd64\ud9d9\udf9a\u6c87\udae0\udc1a\ud974\udebck\ud878\udf7c\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udbfd\ude0f\ud92d\udd7b\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\ud8b5\ude17\ud813\udfc2\ud820\uddcdk\ud81e\ude7d\ud995\udd54\ud8ad\udfba\ud8d1\udcbb\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda4e\ude9b\ud823\udd92\uda79\ude84\ud877\udde6\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0O\uda37\udfd4K\ud832\udc16\ud819\ude3e\uda13\ude0d\uda33\udc7f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\udbea\ude30\ud9f3\udc16\ud93e\udca6\ud9d9\udf9a\u6c87\udae0\udc1a\ud974\udebc\ud92e\udfe9\ud87a\ude3b\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udbfd\ude0f\udb03\uddc6\uda50\udd60\uda4a\ude43\ud8d1\uddc9\ud8b5\ude17\ud813\udfc2\ud820\uddcd\udbc8\udefb\ud81e\udeac\u9dbe\ud9de\udcc8\ud8d1\udc6a\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda4e\ude9b\ud823\udd92\udbf7\uddce\ud843\udd72\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\uda37\udfd4K\ud832\udc16\ud8db\udee0\ud9fa\udd9c\udaf1\uddde\udaf1\uddbf\ud923\uddf8\uda0e\uded0\uda0d\udfa4\ud8be\udd10\ud834\udfbe\udabc\uddfe\ud984\udc5d\ud844\udddf\ud8ef\udd9b\udba0\udf09\uda11\ude1d\ud8ca\udda2\udb72\udd04\udbe3\udd28\udb87\uddc8\udb46\udc9f\ud95b\udd25\ud95e\udc08\udbae\ude96\udbd0\udef3\ud8c8\udf5c\u9ca7\ud807\udeb9\uda01\ude28\ud8bc\udce6\udb59\ude8d\ud920\udf73\uda85\ude56\udbb6\ude70\ud8da\ude0b\uda37\udcce\udac4\udd7c\ud879\udeac\ud9a0\udef5\ud90f\udd91\ud8a2\udfac\ud849\udd77\u4499\udbad\udd7d\uda6f\udd50\ud83c\udce0\ud8ef\udf55\ud8fc\udd37\ud848\udc69\udba1\udf48\udbf8\udeea\udb7b\uddc7\udb04\udcc3\udb26\udef7\udac4\udd00\u4d82\ud976\udcdc\ud8c1\udf50\ud9df\udce4\uda79\udc1d\uf9c9\ud9e2\ude39\ud94a\udc24\uda42\udc76\udb64\udce5");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\udbea\ude30\ud9f3\udc16\ud93e\udca6\ud9d9\udf9a\u6c87\udae0\udc1a\ud974\udebc\ud92e\udfe9\ud87a\ude3b\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udbfd\ude0f\udb03\uddc6\uda50\udd60\uda4a\ude43\ud8d1\uddc9\ud8b5\ude17\ud813\udfc2\ud820\uddcd\udbc8\udefb\ud81e\udeac\u9dbe\ud9de\udcc8\ud8d1\udc6a\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda4e\ude9b\ud823\udd92\udbf7\uddce\ud843\udd72\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\uda37\udfd4K\ud832\udc16\ud8db\udee0\ud9fa\udd9c\udaf1\uddde\udaf1\uddbf\ud923\uddf8\uda0e\uded0\uda0d\udfa4\ud8be\udd10\ud834\udfbe\udabc\uddfe\ud984\udc5d\ud844\udddf\ud8ef\udd9b\udba0\udf09\uda11\ude1d\ud8ca\udda2\udb72\udd04\udbe3\udd28\udb87\uddc8\udb46\udc9f\ud95b\udd25\ud95e\udc08\udbae\ude96\udbd0\udef3\ud8c8\udf5c\u9ca7\ud807\udeb9\uda01\ude28\ud8bc\udce6\udb59\ude8d\ud920\udf73\uda85\ude56\udbb6\ude70\ud8da\ude0b\uda37\udcce\udac4\udd7c\ud879\udeac\ud9a0\udef5\ud90f\udd91\ud8a2\udfac\ud849\udd77\u4499\udbad\udd7d\uda6f\udd50\ud83c\udce0\ud8ef\udf55\ud8fc\udd37\ud848\udc69\udba1\udf48\udbf8\udeea\udb7b\uddc7\udb04\udcc3\udb26\udef7\udac4\udd00\u4d82\ud976\udcdc\ud8c1\udf50\ud9df\udce4\uda79\udc1d\uf9c9\ud9e2\ude39\ud94a\udc24\uda42\udc76\udb64\udce5]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\ud913\udef3\uda75\udd64\ud9d9\udf9a\u6c87\udbdf\udf8d\ud974\udebck\ud878\udf7c\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\u01b3\ud92d\udd7b\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\ud8d5\udc47\udbf3\ude68\ud831\ude47k\ud81e\ude7d\ud995\udd54\ud8ad\udfba\ud8d1\udcbb\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda8c\udc9a\udac7\udd12\uda79\ude84\ud877\udde6\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\u86c1\ud9ba\udcd8\udaec\ude20\u008a\ud832\udc16\ud819\ude3e\uda13\ude0d\uda33\udc7f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8c1\udd7a\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\ud9d6\udfe6\ud913\udef3\uda75\udd64\ud9d9\udf9a\u6c87\udbdf\udf8d\ud974\udebck\ud878\udf7c\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\u01b3\ud92d\udd7b\uda5f\udf4b\udbbf\udc5e\ud8aa\udf8c\ud8d5\udc47\udbf3\ude68\ud831\ude47k\ud81e\ude7d\ud995\udd54\ud8ad\udfba\ud8d1\udcbb\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\udbb4\uded0\uda15\udd39\uda50\udca9\udbd8\udc99\udb0b\uddb1\uda8c\udc9a\udac7\udd12\uda79\ude84\ud877\udde6\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\u86c1\ud9ba\udcd8\udaec\ude20\u008a\ud832\udc16\ud819\ude3e\uda13\ude0d\uda33\udc7f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud91e\udd7f\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\udbea\ude30\ud9f3\udc16\ud93e\udca6\ud9ed\udce5\u6c87\uda4e\udc11\ud974\udebc\ud92d\udde9\ud87a\ude3b\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udb35\udd2a\udb03\uddc6\uda50\udd60\uda4a\ude43\ud8d1\uddc9\ud8b5\ude17\ud813\udfc2\ud820\uddcd\udbc8\udefb\ud81e\udeac\u9dbe\ud9de\udcc8\ud8d1\udc6a\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\uda61\udfa6\ud92b\udd2d\udbfd\udfc9\ud827\udc91\udb0b\uddb1\uda03\udfd6\ud823\udd92\ud876\ude28\ud843\udd72\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\uda37\udfd4K\ud832\udc16\udadf\udce1\ud9fa\ude04\udaf1\uddde\udafd\udf9a\ud923\uddf8\udae5\udc7a\ud94a\ude29\ud8be\udd61\ud834\udfbe\udabc\uddfe\udbc6\uddb8\ud844\ude99\ud8ef\udd9b\udba0\udf09\uda11\ude1d\udbde\ude4b\udbff\uded9\udbe3\udd28\udb87\uddc8\udb45\udfb8\ud95b\udd25\ud95e\udc08\udbae\ude96\udbd0\udef3\ud8c8\udf5c\u9ca7\ud807\udeb9\uda01\ude28\ud8bc\udce6\udb59\ude8d\ud920\udf73\uda85\ude56\udbb6\ude70\ud8da\ude0b\uda37\udcce\udac4\udd7c\ud879\udeac\ud9a0\udef5\ud90f\udd91\ud8a2\udfac\ud849\udd77\u4499\ud9f9\udf1c\uda4f\udf71\ud81a\udfa6\ud8ef\udf55\udbc1\ude9a\ud993\udc42\udba1\ude57\udbf8\udeea\udb7b\uddc7\udb04\udcc3\uda45\udec7\udac4\udd00\udba0\udd6a\ud976\udcdc\ud8c1\udf50\ud9df\udce4\uda79\udc1d\uf9c9\ud9e2\ude39\ud94a\udc24\uda42\udc76\udb64\udce5\ud9f1\uded4\ud9ef\udf18\ud885\udf92\ud8c8\udf54\ud906\udebe\ud857\udf48\uda5b\uddd9\uda44\udee6\udb21\udff4\uda67\udd52\uda22\udde5\ud98c\ude7b");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud91e\udd7f\udbb2\udcbb\ud866\udf6c\ud997\udf06\udaf8\udf41\udbea\ude30\ud9f3\udc16\ud93e\udca6\ud9ed\udce5\u6c87\uda4e\udc11\ud974\udebc\ud92d\udde9\ud87a\ude3b\uda9a\ude83\ud8af\udc85\udb82\udc10\udafb\ude7b\ud8fe\ude56\udb35\udd2a\udb03\uddc6\uda50\udd60\uda4a\ude43\ud8d1\uddc9\ud8b5\ude17\ud813\udfc2\ud820\uddcd\udbc8\udefb\ud81e\udeac\u9dbe\ud9de\udcc8\ud8d1\udc6a\ud9f1\udd0a\ud937\udfa6\udb15\udccb\udb4c\ude6a\uda61\udfa6\ud92b\udd2d\udbfd\udfc9\ud827\udc91\udb0b\uddb1\uda03\udfd6\ud823\udd92\ud876\ude28\ud843\udd72\udba9\udd19\ud9e9\udd8a\udacc\udcb1\udacb\udc42\uda8c\udecd\ud866\udd3a\uda3d\udf54\uda94\udc66\ud934\udfee\ud80c\udfbf\uda03\uddf5\u84df\uda2e\udd9b\ud9db\udc81\udbe0\udea0\udad1\udca2\uda37\udfd4K\ud832\udc16\udadf\udce1\ud9fa\ude04\udaf1\uddde\udafd\udf9a\ud923\uddf8\udae5\udc7a\ud94a\ude29\ud8be\udd61\ud834\udfbe\udabc\uddfe\udbc6\uddb8\ud844\ude99\ud8ef\udd9b\udba0\udf09\uda11\ude1d\udbde\ude4b\udbff\uded9\udbe3\udd28\udb87\uddc8\udb45\udfb8\ud95b\udd25\ud95e\udc08\udbae\ude96\udbd0\udef3\ud8c8\udf5c\u9ca7\ud807\udeb9\uda01\ude28\ud8bc\udce6\udb59\ude8d\ud920\udf73\uda85\ude56\udbb6\ude70\ud8da\ude0b\uda37\udcce\udac4\udd7c\ud879\udeac\ud9a0\udef5\ud90f\udd91\ud8a2\udfac\ud849\udd77\u4499\ud9f9\udf1c\uda4f\udf71\ud81a\udfa6\ud8ef\udf55\udbc1\ude9a\ud993\udc42\udba1\ude57\udbf8\udeea\udb7b\uddc7\udb04\udcc3\uda45\udec7\udac4\udd00\udba0\udd6a\ud976\udcdc\ud8c1\udf50\ud9df\udce4\uda79\udc1d\uf9c9\ud9e2\ude39\ud94a\udc24\uda42\udc76\udb64\udce5\ud9f1\uded4\ud9ef\udf18\ud885\udf92\ud8c8\udf54\ud906\udebe\ud857\udf48\uda5b\uddd9\uda44\udee6\udb21\udff4\uda67\udd52\uda22\udde5\ud98c\ude7b]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udbf1\udcf1\ua200\ud967\udf12\udadf\udf7a\ud9c7\udd81HH\ue84d\u00f9\000\ud8fc\udcde\ud9c5\udf61\udb6b\ude66");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udbf1\udcf1\ua200\ud967\udf12\udadf\udf7a\ud9c7\udd81HH\ue84d\u00f9\000\ud8fc\udcde\ud9c5\udf61\udb6b\ude66]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("'\udba3\udfcb\ud8aa\udcc2\ud94f\udf6e\ud95d\udf21\udbfe\udd71'\ud84d\udee5\ud8cc\ude89\udabe\ude37\uda78\udd6a'\ud85c\udc2d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat['\udba3\udfcb\ud8aa\udcc2\ud94f\udf6e\ud95d\udf21\udbfe\udd71'\ud84d\udee5\ud8cc\ude89\udabe\ude37\uda78\udd6a'\ud85c\udc2d]", String.valueOf(r));
  }
}
