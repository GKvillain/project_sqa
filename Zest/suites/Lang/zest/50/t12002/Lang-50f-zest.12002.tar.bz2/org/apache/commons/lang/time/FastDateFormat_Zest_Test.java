package org.apache.commons.lang.time;
import org.junit.Test;
import static org.junit.Assert.*;
public class FastDateFormat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud855\ude29\ubc63\udb55\ude7a\ud8d0\udccb\udac5\udf4a\u2b30");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud855\ude29\ubc63\udb55\ude7a\ud8d0\udccb\udac5\udf4a\u2b30]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud98d\udf8d\ud8f0\ude26");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud98d\udf8d\ud8f0\ude26]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud84b\uddbb\uda4e\udc60\ud82e\udf82\ud89b\udebf\uda10\udeac\udb01\udd7e\ud80e\ude4e\ud8b2\uddc0\udaf2\uddc8\ud9b8\udf77\udb2e\udc1d\ud9a6\udc99\udb48\udcc3\ud802\udf83\ud891\udda4\ud816\udc52\udadc\udcf6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud84b\uddbb\uda4e\udc60\ud82e\udf82\ud89b\udebf\uda10\udeac\udb01\udd7e\ud80e\ude4e\ud8b2\uddc0\udaf2\uddc8\ud9b8\udf77\udb2e\udc1d\ud9a6\udc99\udb48\udcc3\ud802\udf83\ud891\udda4\ud816\udc52\udadc\udcf6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000R\ud853\udf69"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ubc63\udb55\ude7a\ud8d0\udccb\udac5\udf4a\u2b30");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ubc63\udb55\ude7a\ud8d0\udccb\udac5\udf4a\u2b30]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\u25a4");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\u25a4]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udab4\udd0e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udab4\udd0e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9a3\uddb0\000\000\ud898\ude4c\ud99e\ude57\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a3\uddb0\000\000\ud898\ude4c\ud99e\ude57\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud855\ude29\ud9e7\udebe\ud9bd\uddd6\ud8d0\udc76\udac5\udf4a\udbe4\udc9b\udb65\udc33\uda91\ude87\ud84a\udf82\uda05\udf6c\udbca\udfa2\ud9e8\udf00\ud91c\udd77\ud93b\ude44\u142b\ud8bd\udff7");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud855\ude29\ud9e7\udebe\ud9bd\uddd6\ud8d0\udc76\udac5\udf4a\udbe4\udc9b\udb65\udc33\uda91\ude87\ud84a\udf82\uda05\udf6c\udbca\udfa2\ud9e8\udf00\ud91c\udd77\ud93b\ude44\u142b\ud8bd\udff7]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uf722\uda34\udddc\ud850\udd82\ud87f\udcd4\ud8af\uddca\udb24\uddbc\ud91c\udc6e\udb69\udfeb\ud8d8\udcdc\ud83e\udd0e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uf722\uda34\udddc\ud850\udd82\ud87f\udcd4\ud8af\uddca\udb24\uddbc\ud91c\udc6e\udb69\udfeb\ud8d8\udcdc\ud83e\udd0e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud855\ude29\ud998\ude77\udb9f\udded\udb36\udc20\udac5\udfaf\u2b30\u8f3c\uda10\ude7e\udb32\udd60\ud97b\udf97\uda62\udc3b\ud913\udc86\udbc1\udf5a\uda01\udd02\udbb5\udcfa\ud8e1\udfda\ud981\udf56\uda02\udeee\udb8a\uded4\u765b\ud861\udd74\udb73\udf16\uda15\udd41\uda83\udf05\udb92\udcc7\uda17\udd1a\udb1f\udfd8\udb7c\udcb9\uda77\udeac\ud97a\udf37\ud8df\uddcf\u24ca\udaf1\udee5\udb70\udc33\udba7\udc40\uda1a\udcde\udac3\uddfb\ud901\udd78\udbc3\udec5\ud833\udfb6\ud902\udc0b\ud9b5\udd7e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud855\ude29\ud998\ude77\udb9f\udded\udb36\udc20\udac5\udfaf\u2b30\u8f3c\uda10\ude7e\udb32\udd60\ud97b\udf97\uda62\udc3b\ud913\udc86\udbc1\udf5a\uda01\udd02\udbb5\udcfa\ud8e1\udfda\ud981\udf56\uda02\udeee\udb8a\uded4\u765b\ud861\udd74\udb73\udf16\uda15\udd41\uda83\udf05\udb92\udcc7\uda17\udd1a\udb1f\udfd8\udb7c\udcb9\uda77\udeac\ud97a\udf37\ud8df\uddcf\u24ca\udaf1\udee5\udb70\udc33\udba7\udc40\uda1a\udcde\udac3\uddfb\ud901\udd78\udbc3\udec5\ud833\udfb6\ud902\udc0b\ud9b5\udd7e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud855\ude29\ubc63\udb55\ude7a\udad8\udc19\ud827\udcc9\ud92c\uddef\ud828\ude0e\uda93\ude7c\ud8f0\ude36\udba5\udd0b\ud85e\ude2f\ud9a1\udf0e\uda16\udf69\ud850\udeaf\ud960\ude5e\udb51\uddff\uda9d\udc19\ud857\uded2\ud99b\udf7e\ud83d\udf6c\uda35\udea0\ud8dd\ude70\ud992\udd5f\udbec\udc48\ud906\udc9f\udb55\ude3c\udb9f\udff7\ud948\udd2f\ud82e\ude3b\ud82a\udedc\ud7dd\ud849\udca0\udb28\ude1c\udac0\udeff\ud956\ude2f\uda7b\uddd9\ud80c\udf8a\ud9b4\udceb\udad2\uddef\ud9ba\udff0\uda39\udf77\uda8d\udd05\udb52\udd6f\ud878\udded\ud8f8\udd17\uda64\udc99\ud803\udd5a\udaf2\ude02\udb3b\ude60\udb68\udc8d\udab8\ude0d\udb57\ude2f\ud946\udd74\ud990\udc66\ud8ad\udd55\uda10\uddec\ud823\udde7\ud863\udd0a\udbf0\udde2\ud950\udc6b\ud836\udce2\udbcc\udc2f\ud8b6\udec0\uda80\udeee\ud8f6\udd9a\udb3b\ude5f\ud825\udcde\ud846\ude83\ud9e1\udfc6\ud8cc\ude7f\udb26\ude71\ua86f\ud954\udf23\ud835\udfef");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud855\ude29\ubc63\udb55\ude7a\udad8\udc19\ud827\udcc9\ud92c\uddef\ud828\ude0e\uda93\ude7c\ud8f0\ude36\udba5\udd0b\ud85e\ude2f\ud9a1\udf0e\uda16\udf69\ud850\udeaf\ud960\ude5e\udb51\uddff\uda9d\udc19\ud857\uded2\ud99b\udf7e\ud83d\udf6c\uda35\udea0\ud8dd\ude70\ud992\udd5f\udbec\udc48\ud906\udc9f\udb55\ude3c\udb9f\udff7\ud948\udd2f\ud82e\ude3b\ud82a\udedc\ud7dd\ud849\udca0\udb28\ude1c\udac0\udeff\ud956\ude2f\uda7b\uddd9\ud80c\udf8a\ud9b4\udceb\udad2\uddef\ud9ba\udff0\uda39\udf77\uda8d\udd05\udb52\udd6f\ud878\udded\ud8f8\udd17\uda64\udc99\ud803\udd5a\udaf2\ude02\udb3b\ude60\udb68\udc8d\udab8\ude0d\udb57\ude2f\ud946\udd74\ud990\udc66\ud8ad\udd55\uda10\uddec\ud823\udde7\ud863\udd0a\udbf0\udde2\ud950\udc6b\ud836\udce2\udbcc\udc2f\ud8b6\udec0\uda80\udeee\ud8f6\udd9a\udb3b\ude5f\ud825\udcde\ud846\ude83\ud9e1\udfc6\ud8cc\ude7f\udb26\ude71\ua86f\ud954\udf23\ud835\udfef]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda6b\udd30\udbf7\udc50\ud817\udcbf\udb1f\udf95\ud8d1\udf64\udb16\udde2\ud951\udd72\ud855\udc3e\udbb4\udcce\ud980\udcea\uac65\uda09\udc63\udbb8\uddd5y\ud889\udfa6\udb73\udc72\udb43\udf85");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda6b\udd30\udbf7\udc50\ud817\udcbf\udb1f\udf95\ud8d1\udf64\udb16\udde2\ud951\udd72\ud855\udc3e\udbb4\udcce\ud980\udcea\uac65\uda09\udc63\udbb8\uddd5y\ud889\udfa6\udb73\udc72\udb43\udf85]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8b5\udf81m");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8b5\udf81m]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud820\udc0fA\000R"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\u7bec\uda13\udfeaP\000\u6e52\ud853\udf69"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("I\000\000\000R\ud853\udf69"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\uda7e\udd1e\udb7d\udd32\udbb7\uddd7SR\uda27\ude5f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\uda68\ude50\ud921\ude7a\u6be1O\uda2a\uddbc\ud904\udda5\ud91c\udf57\uda1a\udf21\ud9d6\ude91\uda7c\udc11\udb9d\udc90\udbd5\udf80\ud85d\udced\udb0c\udf06"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8ff\udda9\ud9b3\ude80E");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8ff\udda9\ud9b3\ude80E]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud97d\udd32B\uda3c\uddde\ud8fb\udd3d\udbb1\udd39\ud817\udeea\ud8ee\udc92\ud9dd\udfa0\ud87b\udcc1\uda3b\udff5\ud889\udc73\udb8a\uddd1\ud9fa\udd66\udb9e\udc44\udb5d\udee0\udb3a\ude69\ud85c\udcf8\udb57\uddf6\udb64\uddf6"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ub408G\000\000R\ud853\udf69"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaad\udcf9\ud97a\udfc0\000\000k\ud9eb\udf75\ud882\ude93\ud866\udd10\ub4c1\udae4\udc95\udb97\udc53\ud928\udc2b\udbc2\udcdb\ud974\ude06\uda02\udde0");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaad\udcf9\ud97a\udfc0\000\000k\ud9eb\udf75\ud882\ude93\ud866\udd10\ub4c1\udae4\udc95\udb97\udc53\ud928\udc2b\udbc2\udcdb\ud974\ude06\uda02\udde0]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("Q\ubc63"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("N\ubc63\udb55\ude7a\ud8d0\udccb\udac5\udf4a\u2b30\udbec\udfdb\ud8f0\udfc9\udb87\udfae\udb37\udd7e\ud937\udc07\udb2f\ude37"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud93b\udd44d\udb55\ude7a\ud8d0\udccb\udac5\udf4a\udab9\udd87");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud93b\udd44d\udb55\ude7a\ud8d0\udccb\udac5\udf4a\udab9\udd87]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9a3\uddb0\000\000\ud980\udc1e\u03f5z\udb2c\ude4f\ud926\udc89\ud8c8\udfe9\udafa\uddc8\ud9f5\ude52\ud84b\udcad\udb6e\udfd6\uda52\uded1\udb7c\ude60");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a3\uddb0\000\000\ud980\udc1e\u03f5z\udb2c\ude4f\ud926\udc89\ud8c8\udfe9\udafa\uddc8\ud9f5\ude52\ud84b\udcad\udb6e\udfd6\uda52\uded1\udb7c\ude60]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9a3\uddb0\000\000\000\000\udbc1\udcdf\udb65\udc33\uda91\ude870\000\udbca\udeee\000\000\000\000\u6800");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a3\uddb0\000\000\000\000\udbc1\udcdf\udb65\udc33\uda91\ude870\000\udbca\udeee\000\000\000\000\u6800]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("L"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud84e\udd41\udbf7\udc50\ud9ba\udf7e\udb19\udf51\ud8d1\udf64\u77a8\ud951\uddbc\ud827\udefb\udba1\ude87\ud958\udf98\ud8d6\ude2f\ud80a\udfeb\ud90e\udfa1G\ud83a\udf87\udb73\udca0\udb43\udf85");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud84e\udd41\udbf7\udc50\ud9ba\udf7e\udb19\udf51\ud8d1\udf64\u77a8\ud951\uddbc\ud827\udefb\udba1\ude87\ud958\udf98\ud8d6\ude2f\ud80a\udfeb\ud90e\udfa1G\ud83a\udf87\udb73\udca0\udb43\udf85]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud89d\udf7ds\u94d3\uda7f\udffb\udb65\udd8c\udab5\udc38\udae1\udcc6\ud90e\udc21\ud818\uddce");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud89d\udf7ds\u94d3\uda7f\udffb\udb65\udd8c\udab5\udc38\udae1\udcc6\ud90e\udc21\ud818\uddce]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("Z\ud886\ude70\uda02\udd03\udafd\udc98\udbb4\udf2f\ud9c6\udf17\udbd8\udc0c\uda74\udc32\uda8f\ude51");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[Z\ud886\ude70\uda02\udd03\udafd\udc98\udbb4\udf2f\ud9c6\udf17\udbd8\udc0c\uda74\udc32\uda8f\ude51]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud835\udca5\udafe\udec9K\000R\ud99b\udc3e"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("h\ud8bc\ude0e");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[h\ud8bc\ude0e]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\udbbb\ude1cF\uda6e\udf17");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\udbbb\ude1cF\uda6e\udf17]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud820\udf5f\ub339H\ud95a\udfca\u6e52\ud853\udf69");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud820\udf5f\ub339H\ud95a\udfca\u6e52\ud853\udf69]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udb79\udc91\ud9a0\udf86W\000\ud880\udf35\ud853\udfb9\udbe9\udcc1\udb84\udd2b\ud82c\udcd4\ud8ec\ude1a\ud9eb\udd5a\ud954\udca1\ud93a\ude98");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udb79\udc91\ud9a0\udf86W\000\ud880\udf35\ud853\udfb9\udbe9\udcc1\udb84\udd2b\ud82c\udcd4\ud8ec\ude1a\ud9eb\udd5a\ud954\udca1\ud93a\ude98]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda28\udd41\uda1d\udff3\u630fD\udb03\udfff\udb0c\udca8\ud847\ude33");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda28\udd41\uda1d\udff3\u630fD\udb03\udfff\udb0c\udca8\ud847\ude33]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("J\ud893\ude6b\ubf25\000R\ud853\udf69\ud92e\ude56\udb4a\uddee\ud86d\ude33\udbd8\udc06\ud9b1\udd76\udaa6\udc14"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9ee\udf11\udb55\udc92\ud865\udea4\uda05\udcdf\ud829\udc45\ud88b\udd4da\ud89d\udd07\udbc0\ude7a\ud8a7\ude3b\ud89a\udfdd");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9ee\udf11\udb55\udc92\ud865\udea4\uda05\udcdf\ud829\udc45\ud88b\udd4da\ud89d\udd07\udbc0\ude7a\ud8a7\ude3b\ud89a\udfdd]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("w\000\000\000R\ud853\udf69\udb73\udeb1\udafc\ude73\udbb9\udc80\udbc1\udd72\ud8a9\udcbb\ud9ee\udfe1\ud88a\udef3\udb67\udda5\ud8b7\uddcc\udb99\udf09"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud904\udf6e\u4dad\uda17\ude8e\ud962\udd9cK\ud9bf\udc11");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud904\udf6e\u4dad\uda17\ude8e\ud962\udd9cK\ud9bf\udc11]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud917\ude25\ud8f3\udd59\udbb7\uddd7S\uda18\udd2c\udb89\udfa9\udb55\udfda\udaf7\udd78\ud987\udc5d\ud8d9\ude4d\udbd7\udcb6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud917\ude25\ud8f3\udd59\udbb7\uddd7S\uda18\udd2c\udb89\udfa9\udb55\udfda\udaf7\udd78\ud987\udc5d\ud8d9\ude4d\udbd7\udcb6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda7e\udd1e\udb7d\udd32\udbb7\uddd7SD\ud83b\ude69");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda7e\udd1e\udb7d\udd32\udbb7\uddd7SD\ud83b\ude69]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\udbb7\uddd7S\000\uda27\ude5f");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\udbb7\uddd7S\000\uda27\ude5f]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\uda7e\udd1e\udb7d\udd32\udbb7\uddd7\ud8ef\uddb0C\uda27\ude5f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8e2\udeab\udb34\uddad'");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8e2\udeab\udb34\uddad']", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8ff\udda9\ud83e\ude98w");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8ff\udda9\ud83e\ude98w]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8d3\uded0M\uda3c\uddde\ud8fb\udd3d\udbb1\udd39\ud907\ude62\uda43\udebf\ud9dd\udfa0\ud87b\udcc1\uda3b\udff5\udba1\udd8b\udb8a\uddd1\ud9fa\udd66\udb9e\udc44\udb5d\udee0\udb3a\ude69\ud85c\udcf8\udb57\uddf6\udb64\uddf6");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8d3\uded0M\uda3c\uddde\ud8fb\udd3d\udbb1\udd39\ud907\ude62\uda43\udebf\ud9dd\udfa0\ud87b\udcc1\uda3b\udff5\udba1\udd8b\udb8a\uddd1\ud9fa\udd66\udb9e\udc44\udb5d\udee0\udb3a\ude69\ud85c\udcf8\udb57\uddf6\udb64\uddf6]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ub408G\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ub408G\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9a3\uddb0\000\000\udb36\udf1b\u03f5z\udb2c\ude4f\ud9ab\udd95\ud8c8\udfe9\udafa\uddc8\ud9f5\ude52\ud84b\udcadd\uda90\udcd0\udb7c\ude60");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a3\uddb0\000\000\udb36\udf1b\u03f5z\udb2c\ude4f\ud9ab\udd95\ud8c8\udfe9\udafa\uddc8\ud9f5\ude52\ud84b\udcadd\uda90\udcd0\udb7c\ude60]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8e2\udeab\udb34\uddad'\ud9c5\udf7d\uda13\udea3\uda47\ude7e\ud8f5\uddf8\u4d1b\ud8f6\udead\udb2d\ude00\ud973\udf48\udbc4\udc46\uda44\udfef\uda76\udcd0\ud9ba\ude21\udb04\ude82\ud8dd\udde5\ud937\udc68\ud93d\udf34\udbb9\udcc0\ud9ef\uddd6\ud946\udc6a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8e2\udeab\udb34\uddad'\ud9c5\udf7d\uda13\udea3\uda47\ude7e\ud8f5\uddf8\u4d1b\ud8f6\udead\udb2d\ude00\ud973\udf48\udbc4\udc46\uda44\udfef\uda76\udcd0\ud9ba\ude21\udb04\ude82\ud8dd\udde5\ud937\udc68\ud93d\udf34\udbb9\udcc0\ud9ef\uddd6\ud946\udc6a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8e2\udeab\ud932\uddac'\ud8f1\udc4e\udbda\udf08\ud844\udeb2\uda09\udcba\udb1b\udf08\ud90f\udced\ud8a6\udf5e\udb8e\ude12\ud9da\ude3d");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8e2\udeab\ud932\uddac'\ud8f1\udc4e\udbda\udf08\ud844\udeb2\uda09\udcba\udb1b\udf08\ud90f\udced\ud8a6\udf5e\udb8e\ude12\ud9da\ude3d]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda4a\udcd6\udb34\uddad'\udb70\ude6a\ud9e1\udce2\ud958\udcf3\udb06\udc98\ud807\udf2f\ud92c\udf52\udbad\udd3b\uda96\udf89\udae0\udf0d\ud97f\udeb6\ud94a\ude02\ud848\ude7a\udb08\udf66\uda2d\udd03\uda64\udfee\ud98d\udd97\ud8be\udf62\ud860\ude49\ud921\udec0\ud872\udca9\udb10\uddec\ud987\udf28\udbc3\uddf4\ud8f1\uddc2\ud822\uddbd\udbfd\udd2c\udb4d\uddbb\udbc9\udfb0\udb11\udcb1\ud809\udda0\ud898\udeb2\uda8e\udfec");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda4a\udcd6\udb34\uddad'\udb70\ude6a\ud9e1\udce2\ud958\udcf3\udb06\udc98\ud807\udf2f\ud92c\udf52\udbad\udd3b\uda96\udf89\udae0\udf0d\ud97f\udeb6\ud94a\ude02\ud848\ude7a\udb08\udf66\uda2d\udd03\uda64\udfee\ud98d\udd97\ud8be\udf62\ud860\ude49\ud921\udec0\ud872\udca9\udb10\uddec\ud987\udf28\udbc3\uddf4\ud8f1\uddc2\ud822\uddbd\udbfd\udd2c\udb4d\uddbb\udbc9\udfb0\udb11\udcb1\ud809\udda0\ud898\udeb2\uda8e\udfec]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud831\udcd4\udb34\uddbc'\ud908\udcb0");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud831\udcd4\udb34\uddbc'\ud908\udcb0]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udae0\udc8a\udb7e\udd14'\ud8e9\udf33\udb04\udc71");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udae0\udc8a\udb7e\udd14'\ud8e9\udf33\udb04\udc71]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud8e2\udeca\udb34\uddad'\udbe6\udf20\udb15\udedb\ud801\ude53\ud852\ude83\ud9e3\ude15\uda52\udd9a");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud8e2\udeca\udb34\uddad'\udbe6\udf20\udb15\udedb\ud801\ude53\ud852\ude83\ud9e3\ude15\uda52\udd9a]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\uda13\ude20\000\000\000\000\udb91\ude05\000\000\000\000\ud9ba\udd71\000\ud8d2\udc68\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\uda13\ude20\000\000\000\000\udb91\ude05\000\000\000\000\ud9ba\udd71\000\ud8d2\udc68\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\ud7c1\000\000\uda13\ude20\ud81b\udc92\u7391\000\udb41\ude7e\udb25\udfef\ud89a\ude99\udb38\udcec\udab3\uddea\uda81\udff2\udb82\udce1\udbfc\udc11\ud8d2\udc68\000\000\udb80\udec6'\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\ud7c1\000\000\uda13\ude20\ud81b\udc92\u7391\000\udb41\ude7e\udb25\udfef\ud89a\ude99\udb38\udcec\udab3\uddea\uda81\udff2\udb82\udce1\udbfc\udc11\ud8d2\udc68\000\000\udb80\udec6'\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud855\ude29\ubc63\udb55\ude7a\ud8d0\udccb\udac5\udf4a\ud8fd\udee8");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud855\ude29\ubc63\udb55\ude7a\ud8d0\udccb\udac5\udf4a\ud8fd\udee8]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\udaad\udcf9\ud8ab\udf57k\000k\ud9eb\udf75\ud882\ude93\ud866\udd10\ub4c1\u8547\udac0\udc08\ud8f1\udd48\udaaa\udf83\ud89a\udffe\uda02\udde0");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\udaad\udcf9\ud8ab\udf57k\000k\ud9eb\udf75\ud882\ude93\ud866\udd10\ub4c1\u8547\udac0\udc08\ud8f1\udd48\udaaa\udf83\ud89a\udffe\uda02\udde0]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\ud9a3\uddb0\000z\ud980\udc1e\u03f5z\udb2c\ude4f\ud926\udc89\ud8c8\udfe9\udafa\uddc8\ud81f\udc4b\ud84b\udcad\udb6e\udfd6\uda52\uded1\udb7c\ude60");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\ud9a3\uddb0\000z\ud980\udc1e\u03f5z\udb2c\ude4f\ud926\udc89\ud8c8\udfe9\udafa\uddc8\ud81f\udc4b\ud84b\udcad\udb6e\udfd6\uda52\uded1\udb7c\ude60]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("w\000w\ud944\ude5f\udbb4\udf46\udacc\udc05\udb73\udeb1\udafc\ude73\udbb9\udc80\udbc1\udd72\ud82b\udcbc\udab2\udc41\ud88a\udec7\ud987\udeb5\ud8b7\uddcc\udb19\udcaa");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[w\000w\ud944\ude5f\udbb4\udf46\udacc\udc05\udb73\udeb1\udafc\ude73\udbb9\udc80\udbc1\udd72\ud82b\udcbc\udab2\udc41\ud88a\udec7\ud987\udeb5\ud8b7\uddcc\udb19\udcaa]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    try { org.apache.commons.lang.time.FastDateFormat.getInstance("\ud83a\udf1c\udbaf\udd54\uda33\ude7bRR\uda27\ude5f"); fail("expected IllegalArgumentException"); }
    catch (java.lang.IllegalArgumentException e) { }
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\000\000\000\000\000\000\000\000\000\000\000\000\000\000");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\000\000\000\000\000\000\000\000\000\000\000\000\000\000]", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    Object r = org.apache.commons.lang.time.FastDateFormat.getInstance("\uda7e\udd1e\uda25\udf06\ud999\udce7DD\ud83b\ude69");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang.time.FastDateFormat", r.getClass().getName());
    assertEquals("FastDateFormat[\uda7e\udd1e\uda25\udf06\ud999\udce7DD\ud83b\ude69]", String.valueOf(r));
  }
}
