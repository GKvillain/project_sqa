package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\udb09\udd63\u6f9b\ud957\udd70\udaf7\udca6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb09\udd63\u6f9b\ud957\udd70\udaf7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\udb09\udd63\u6f9b\ud8bb\udf62");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb09\udd63\u6f9b\ud8bb", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.defaultString("\uda70\udc3c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda70\udc3c", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\udbd6\udd7e\ud9d2\udd97\ud957\udd70\udaf7\udca6");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udbd6\udd7e\ud9d2\udd97\ud957\udd70\udaf7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\ud806\udc06\u52e1\uda65\udd4b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\udb09\udd63\u6f9b\ud814\udd43\udb34\udc50\ud835\udf9e\uda26\udc96\uda2e\udd98\udb34\udff3\ud9f9\udf9d\ud9c2\ude68\udb54\udcc6\udb9a\udd72\ud8b1\ude21\udafc\udc9d\ud89d\udc06\udb73\udf7b\ud8ac\udfd3\ud86f\udef2\ud848\udc2d\ud981\udc8a\udaa3\udfd2\ud81e\udc44\ud9b6\udfda\uda7d\udfd2\ud8eb\udc78\ud98b\udf01\ue7c6\udbfb\udd78\ud921\udd6f\ud889\udd1d\ud8ee\udf77\uda81\udeaf\ud856\udca5\uda52\udf16\ud93b\ude3d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb09\udd63\u6f9b\ud814\udd43\udb34\udc50\ud835\udf9e\uda26\udc96\uda2e\udd98\udb34\udff3\ud9f9\udf9d\ud9c2\ude68\udb54\udcc6\udb9a\udd72\ud8b1\ude21\udafc\udc9d\ud89d\udc06\udb73\udf7b\ud8ac\udfd3\ud86f\udef2\ud848\udc2d\ud981\udc8a\udaa3\udfd2\ud81e\udc44\ud9b6\udfda\uda7d\udfd2\ud8eb\udc78\ud98b\udf01\ue7c6\udbfb\udd78\ud921\udd6f\ud889\udd1d\ud8ee\udf77\uda81\udeaf\ud856\udca5\uda52\udf16\ud93b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\udb1b\udfe3\u0278\ud957\udd70\ud94f\udc32\u3073\ud9b4\udd0c\uda92\udda8\udadf\udf50\uda8a\ude35\udb23\uddc5\udb50\udda7\ud8df\udc38\udbfa\ude81\uda0c\udec4\ud910\ude3f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\udb0e\udfe0\u738d\ud96c\udeca\udaf7\udca6\ud9c0\udead\ud912\uddc4\ud95e\udf6c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\ud855\ude80\ud98d\ude8d\uda8a\udee7\ud87b\udc0c\ud84c\udcf6\udb77\udf75\ud91b\udef2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chomp("\udb09\udd63\u895a\ud938\udc70\udb7a\udfea\udbcd\udf46\udadc\uddfd\ud885\udd78");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb09\udd63\u895a\ud938\udc70\udb7a\udfea\udbcd\udf46\udadc\uddfd\ud885\udd78", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.capitalize("\udb09\uddf0\u2b9b\uda90\udd59\ud904\udcdb");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb09\uddf0\u2b9b\uda90\udd59\ud904\udcdb", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("\udaf5\udd5a\udbff\udc5e\ud957\udd70\udaf7\udca6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\ud876\udd6f\ud8cb\udcfe\udb60\udd6c\ud980\ude81\udbe6\ude1f\uda78\udc83\udbea\udf4e");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\ud8ca\udc63\udb74\udf63\ud957\udd70\udb00\udf6e\u51ff\udaa0\udfc6\udac7\udc1f\ud836\udc44\udbd1\udce2\ud8c1\udc45\ud8be\udfd7\udb4a\udd67\ud95e\udef7\ud8da\ude9c\ud80e\ude67\udb25\ude0c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8ca\udc63\udb74\udf63\ud957\udd70\udb00\udf6e\u51ff\udaa0\udfc6\udac7\udc1f\ud836\udc44\udbd1\udce2\ud8c1\udc45\ud8be\udfd7\udb4a\udd67\ud95e\udef7\ud8da\ude9c\ud80e\ude67\udb25", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\udb09\udd63\u6f9b\udb2e\udf33\udb19\uded8\udbcd\udcfb\udb91\udedb\ud807\udf4f\ud882\udfc1\udbde\udc46\ud850\udcd6\udb93\udd71\ud918\udebe\udbd0\ude41\uda68\ude42\udb59\udf10\ud9f6\uddd0\udad2\udcbc\udab0\udd26\ud8b5\udcb3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud9b6\udce3\udaba\udf6c\uda01\udfbb\ud8ca\udc02\uda09\udef1\udb76\ude7c\udbcc\udd95\ud967\udf27\udbfd\udc18\uda69\udd7e\udb50\udf95\ud990\udf31\udbe5\udda4\ud87f\uddb1\udbaa\udfb7");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud9b6\udce3\udaba\udf6c\uda01\udfbb\ud8ca\udc02\uda09\udef1\udb76\ude7c\udbcc\udd95\ud967\udf27\udbfd\udc18\uda69\udd7e\udb50\udf95\ud990\udf31\udbe5\udda4\ud87f\uddb1\udbaa\udfb7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\u5009");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\u5009", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud8b6\udd1b\udb5e\udea1\ud957\udd70\ud904\udd53\ud89d\udfdf\ud803\udc75\udb85\udfed\ud86c\udf19\udb13\udeb3\uda72\udc3c\uda32\ude51\ud972\udf93\udb32\udd03\ud896\udd8e\ud989\ude8b\ud9ee\ude5f\ud971\udcbd\ud84c\uddc0\ud9dc\udd8f\udb51\udf74\uda98\udc98\ud969\udcea\ud96b\udde4\udb7a\udf3a\udb31\udc3c\ud9f0\uddb9\uda41\udece\uda8f\udfa6\ud800\udd5a\ud915\udf34\ud902\udde6\ud9f7\ude01\uda21\uded8\udadb\udcad\udbf9\udf98");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8b6\udd1b\udb5e\udea1\ud957\udd70\ud904\udd53\ud89d\udfdf\ud803\udc75\udb85\udfed\ud86c\udf19\udb13\udeb3\uda72\udc3c\uda32\ude51\ud972\udf93\udb32\udd03\ud896\udd8e\ud989\ude8b\ud9ee\ude5f\ud971\udcbd\ud84c\uddc0\ud9dc\udd8f\udb51\udf74\uda98\udc98\ud969\udcea\ud96b\udde4\udb7a\udf3a\udb31\udc3c\ud9f0\uddb9\uda41\udece\uda8f\udfa6\ud800\udd5a\ud915\udf34\ud902\udde6\ud9f7\ude01\uda21\uded8\udadb\udcad\udbf9\udf98", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud8c8\udd5e\ud978\udcc5\ud85b\udc9c\udb0c\udf6e\ud820\udcfe\ud9e2\udeb8\udab2\udfc0\udbe9\udd4e\ud9a5\udf70\ud9ff\udf4f\ub0db\ud90f\udf36\ud965\udd9d\udbb6\udcd0\uda20\udf90\uacd8\udb3b\udc1b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8c8\udd5e\ud978\udcc5\ud85b\udc9c\udb0c\udf6e\ud820\udcfe\ud9e2\udeb8\udab2\udfc0\udbe9\udd4e\ud9a5\udf70\ud9ff\udf4f\ub0db\ud90f\udf36\ud965\udd9d\udbb6\udcd0\uda20\udf90\uacd8\udb3b\udc1b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\udb09\udd63\ub99b\ub4a4\ud86c\ude74\udac0\udc01\ud937\udd23\ud8cc\udc25\u5025");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb09\udd63\ub99b\ub4a4\ud86c\ude74\udac0\udc01\ud937\udd23\ud8cc\udc25\u5025", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\u01c0\ud90b\udf95\ud8c2\udd49\udb1f\udd1e\ud801\udedf\ud858\ude65\ud8e1\udd77\ud9b1\udcc8\ud9cb\ude99\u5d2f\ud85b\ude31\ud979\udce8\ud8ea\udcc8\udaa3\udf89\udaee\udc3c\ud80a\udffa");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud859\uded8\ud8b9\udc87");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud859\uded8\ud8b9\udc87", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chomp("\ud4e8");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud4e8", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\udb09\udd63");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb09\udd63", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\u01d1\ud846\udd8e\uda4d\uddfb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\u9009\u52e1\ud9a7\udfd7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\u60b1\udbf1\udf36\uda65\udd4b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\ua290");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\u6361\uc727\ud998\ude33\ud951\udf81\udb37\ude08\uda3d\udddf\ud89d\udeb3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\u0edf\udaa6\ude7a\udacf\uddd1\ud980\ude81\udad2\udf46\uda7f\ude9f\udac6\ude55");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("\ud872\udeca\udb70\udde6\udac7\udee0\ud805\udc52\ud847\udfb8\udbc5\ude4c\uf88d\uda6f\uded5\ud833\udce4\uda2c\udc8d\ud887\udd45\ud82c\udcb9\udb56\ude1c\ud972\ude2f\u4fa0\udb27\udc25\uda23\udc79\ud8b1\udf52\udb0f\udd71\udb80\ude00\udb93\udc35\ud901\ude60\udb00\udcc6\ud8cc\udf89\uda4b\udf43\udb5c\ude0c\u602e\ud9bf\udfe3\ud9ce\ude8e\ud97d\udcf3\uda63\udcd0\udb0d\udd1d\ud958\udeed\ud9a3\udd8d\udba5\udf17\ud998\udde1\ud868\udfb1\ud8c6\udc43\ud9d0\udd7c\ud960\ude35\udb97\udc9d\udaeb\udd6c\ud9aa\udc28\uda0c\udc48\uda8f\udd45\udafc\udd21\udb69\udccc\ud8c8\udf8b\udb2d\uddc7\ud80e\ude6c\udb2e\ude41\udb2d\ude28\udaeb\udef9\ud882\udcd1\udb7d\udd87\udbbc\udd5a\udbba\udc95\ud803\udf2e\ud910\udcbe\ud8a0\udc37\ud91a\udc1b\ud88e\ude88\udb05\udf1b\udb75\udd6a\udb46\udd15\ud890\udc44\udb8c\udf4c\uda8a\ude37\ud86f\udec2\ud914\udf18\ud8e2\udf98\udb36\udfe1\ud849\udf57\udb9c\udc37\udb1b\udd13\ud891\ude13\ud842\udd64\ud8da\udf27\udb15\udf92\ud80f\udfbd\ud9b6\udc84\ud8b2\udf8c\ud959\ude7a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\u01c0\u5bed\ud8a2\udf5b\udb1f\udd1e\ud801\udedf\ud858\ude65\ud8e1\udd77\ud9b1\udcc8\ud9cb\ude99\u5d2f\ud85b\ude31\ud979\udce8\ud8ea\udcc8\udaa3\udf89\udaee\udc3c\ud80a\udffa");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\u01d1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\u9009\u52e1\ud9a7\udfd7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\u01b7\u3aed\u00cb\000\ud801\udedf\ud858\ude65\uef64\ud9b1\udc53\ud9cb\ude99\u5d2f\ud85b\ude31\ud9a3\udd9d\000\000\000\ua0b4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\u01b7\u3aed\u00cb\ud9d8\udc0b\ud9c5\udc82\ud858\udef5\uef64\udb7d\uddf9\ud943\ude50\udbf2\udea3\udb23\udf44\uda63\udef4\u00bc\udbd8\ude8d\u00a8\ua0b4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\udb28\udd19\u6f9b\ud8d2\udf0e\udaf7\udc86");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb28\udd19\u6f9b\ud8d2\udf0e\udaf7", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("\u00ba\uec3d\udab8\udeb8\uda5f\udcf1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\u5cf0\u862d\uc19c\ud872\udf4d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud872\udeca\udb70\udde6\udac7\udee0\ud805\udc52\ud847\udfb8\udbc5\ude4c\uf88d\uda6f\uded5\ud833\udce4\uda2c\udc8d\ud887\udd45\ud82c\udcb9\ud841\udd68\udb6d\udd35\udbe7\udd9f\udbe9\udcc7\ud81f\udd00\ud8b1\udf52\udb0f\udd71\udb80\ude00\udb93\udc35\ud901\ude60\udb00\udcc6\ud8cc\udf89\uda4b\udf43\udb5c\ude0c\ud9b3\udcfc\ud9bf\udfe3\ud9ce\ude8e\ud97d\udcf3\uda63\udcd0\udb0d\udd1d\ud958\udeed\ud9a3\udd8d\udba5\udf17\ud998\udde1\ud868\udfb1\udb4a\udd46\ud9d0\udd7c\ud960\ude35\udb97\udc9d\udaeb\udd6c\ud9aa\udc28\uda0c\udc48\uda8f\udd45\udafc\udd21\uda94\udd1e\ud8c8\udf8b\udb2d\uddc7\udb19\udc70\udb01\udeba\udb2d\ude28\udaeb\udef9\ud882\udcd1\udb7d\udd87\udbbc\udd5a\udbba\udc95\ud803\udf2e\ud910\udcbe\ud8a0\udc37\ud91a\udc1b\ud88e\ude88\udb05\udf1b\udb75\udd6a\udb46\udd15\ud890\udc44\udb8c\udf4c\uda8a\ude37\ud86f\udec2\ud914\udf18\ud8e2\udf98\udb36\udfe1\ud849\udf57\udb9c\udc37\udb1b\udd13\ud8c6\udd2e\udb83\udced\u152d\ud983\udfd1\ud80f\udfbd\uda3e\udd48\ud8b2\udf8c\uda5a\udcd9");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud872\udeca\udb70\udde6\udac7\udee0\ud805\udc52\ud847\udfb8\udbc5\ude4c\uf88d\uda6f\uded5\ud833\udce4\uda2c\udc8d\ud887\udd45\ud82c\udcb9\ud841\udd68\udb6d\udd35\udbe7\udd9f\udbe9\udcc7\ud81f\udd00\ud8b1\udf52\udb0f\udd71\udb80\ude00\udb93\udc35\ud901\ude60\udb00\udcc6\ud8cc\udf89\uda4b\udf43\udb5c\ude0c\ud9b3\udcfc\ud9bf\udfe3\ud9ce\ude8e\ud97d\udcf3\uda63\udcd0\udb0d\udd1d\ud958\udeed\ud9a3\udd8d\udba5\udf17\ud998\udde1\ud868\udfb1\udb4a\udd46\ud9d0\udd7c\ud960\ude35\udb97\udc9d\udaeb\udd6c\ud9aa\udc28\uda0c\udc48\uda8f\udd45\udafc\udd21\uda94\udd1e\ud8c8\udf8b\udb2d\uddc7\udb19\udc70\udb01\udeba\udb2d\ude28\udaeb\udef9\ud882\udcd1\udb7d\udd87\udbbc\udd5a\udbba\udc95\ud803\udf2e\ud910\udcbe\ud8a0\udc37\ud91a\udc1b\ud88e\ude88\udb05\udf1b\udb75\udd6a\udb46\udd15\ud890\udc44\udb8c\udf4c\uda8a\ude37\ud86f\udec2\ud914\udf18\ud8e2\udf98\udb36\udfe1\ud849\udf57\udb9c\udc37\udb1b\udd13\ud8c6\udd2e\udb83\udced\u152d\ud983\udfd1\ud80f\udfbd\uda3e\udd48\ud8b2\udf8c\uda5a\udcd9", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\u5cf0\u862d\uc19c\ud872\udf4d\ub06f\ud978\udc04\ueb95");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud8b6\udd1b\udb5e\udea1\ud957\udd70\ud904\udd53\ud89d\udfdf\ud803\udc75\udb85\udfed\ud820\udf13\udb13\udeb3\uda72\udc3c\uda32\ude51\ud972\udf93\udb32\udd03\ud896\udd8e\ud989\ude8b\ud9ee\ude5f\ud971\udcbd\ud84c\uddc0\ud9dc\udd8f\udb51\udf74\uda98\udc98\ud969\udcea\ud96b\udde4\u0081\udb30\udfc1\ud9f0\uddb9\uda41\udece\uda8f\udfa6\ud800\udd5a\ud915\udf34\ud902\udde6\036\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8b6\udd1b\udb5e\udea1\ud957\udd70\ud904\udd53\ud89d\udfdf\ud803\udc75\udb85\udfed\ud820\udf13\udb13\udeb3\uda72\udc3c\uda32\ude51\ud972\udf93\udb32\udd03\ud896\udd8e\ud989\ude8b\ud9ee\ude5f\ud971\udcbd\ud84c\uddc0\ud9dc\udd8f\udb51\udf74\uda98\udc98\ud969\udcea\ud96b\udde4\u0081\udb30\udfc1\ud9f0\uddb9\uda41\udece\uda8f\udfa6\ud800\udd5a\ud915\udf34\ud902\udde6\000\000\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud8a7\udc1b\udb5e\udea1\ua31a\ud904\udd53(\000\000\u8210P\000\000\000\udb12\udcc8\ud896\udd8e\037\ud9af\ude96\ud971\udcbd\ud84c\udd4b\000\000\u3d15\udbab\ude95\ud96b\udde4\u0081\000\000\000\000\uda9e\udf2e\ud915\udf34\ud902\udde6\036\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud8a7\udc1b\udb5e\udea1\ua31a\ud904\udd53(\000\000\u8210P\000\000\000\udb12\udcc8\ud896\udd8e\ud9af\ude96\ud971\udcbd\ud84c\udd4b\000\000\u3d15\udbab\ude95\ud96b\udde4\u0081\000\000\000\000\uda9e\udf2e\ud915\udf34\ud902\udde6\000\000\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("\u016dv\ud86a\udcea");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\u01b7\u3aed\u00cb\u6e3d\ud801\udedf\ud858\ude65\uef64\ud9b1\udc53\uda67\udca7\udb82\udf1c\ud9d4\udec4\ud9a3\udd9d\000\000\000\ua0b4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\u01b7\u3aed\u00cb\u6e3d\ud801\udedf\ud858\ude65\uef64\ud9b1\udc53\uda67\udca7\udb82\udf1c\ud9d4\udec4\ud9a3\udd9d\000\000\000\ua0b4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\u5cf0\u862d\uc19c\ubb0d\uda82\udc29\ud978\udc79\ud985\udffb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\u5cf0\u862d\uc19c\ubb0d\uda82\udc29\ud978\udc79\ud985\udffb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
