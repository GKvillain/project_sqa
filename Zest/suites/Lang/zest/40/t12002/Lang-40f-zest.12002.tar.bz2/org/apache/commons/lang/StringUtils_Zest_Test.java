package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class StringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\ud862\udeef\ud9bc\udf37\udbf9\ude99\ud934\udfe9\udb9c\udffb\ud9c5\ude5d\ud883\udddf\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\ua035\udb11\udc24\ud9ab\udd16");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud862\udeef\ud9bc\udf37\udbf9\ude99\ud934\udfe9\udb9c\udffb\ud9c5\ude5d\ud883\udddf\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\ua035\udb11\udc24\ud9ab", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\udb39\uded0\ud946\udc63\uda34\ude55\ud946\ude51\ud877\udda8\ud9ce\udf01\ud85b\udc27\uda92\ude35\uda45\uddaa\ud968\udf39\ud861\udc17\udb7c\udd1f\uda74\udcf4\udbea\ude35\udba7\udcfa\ud9ab\udd16");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb39\uded0\ud946\udc63\uda34\ude55\ud946\ude51\ud877\udda8\ud9ce\udf01\ud85b\udc27\uda92\ude35\uda45\uddaa\ud968\udf39\ud861\udc17\udb7c\udd1f\uda74\udcf4\udbea\ude35\udba7\udcfa\ud9ab\udd16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud862\udeef\uda0c\udc39\u0f24\ud95a\udebd\udba9\udc05\ud8c6\udc0f\ud883\udddf\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\ua035");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud862\udeef\uda0c\udc39\u0f24\ud95a\udebd\udba9\udc05\ud8c6\udc0f\ud883\udddf\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\ua035", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("\ud862\udeef");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\ud862\udeef\u4fa9\udbe6\udcec\ud87c\udcf8\ud96a\udd98\udbe5\udc70\ud89a\udc81\udb11\udcdb\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\ud9ee\udcf1\ua035");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\udb57\udee7\udab0\uddf2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\ud862\udeef\ud97e\udf05\udbf9\ude99\ud9bb\udc0c");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud862\udeef\ud97e\udf05\udbf9\ude99\ud9bb", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\udb26\udef1\ud9bc\udf37\udbf9\ude99\ud934\udfe9\udb9c\udffb\ud9c5\ude5d\ud883\udddf\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\ua035\udb11\udc24\ud9ab\udd16");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chomp("\ud862\udeef");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud862\udeef", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud862\udeef\ud9bc\udf37\udbf9\ude99\ud934\udfe9\udb9c\udffb\uda1c\udf89\ud802\udd77\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udceb\ua035\udb11\udc24\ud9ab\udd16\uda26\udddd\ud9aa\udfd9\uda1b\udf3b\ud80f\udcd7\udb00\ude11\ud9a6\udf31\udb83\udfb1\ud959\udf1a\udae3\ude77\udbe7\udccd\udb1f\udcdf\udab4\udd87\ud8c3\udd22\ud88f\ude58\ud9f6\udc6c\ud85b\udf31\ud8d5\udf17\ud9b5\uddb2\udb4b\udec2\ud81b\udc69\ud8a4\udf68\ud8c5\udefe\udba9\uddf1\udb20\udff2");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud862\udeef\ud9bc\udf37\udbf9\ude99\ud934\udfe9\udb9c\udffb\uda1c\udf89\ud802\udd77\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udceb\ua035\udb11\udc24\ud9ab\udd16\uda26\udddd\ud9aa\udfd9\uda1b\udf3b\ud80f\udcd7\udb00\ude11\ud9a6\udf31\udb83\udfb1\ud959\udf1a\udae3\ude77\udbe7\udccd\udb1f\udcdf\udab4\udd87\ud8c3\udd22\ud88f\ude58\ud9f6\udc6c\ud85b\udf31\ud8d5\udf17\ud9b5\uddb2\udb4b\udec2\ud81b\udc69\ud8a4\udf68\ud8c5\udefe\udba9\uddf1\udb20\udff2", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.capitalize("\ud862\udeef\ud9bc\udf37\udbf9\ude99\ud8a9\udd04\000\ud99c\udfce\ud883\udddf\udab3\udccc\udafc\udf3d\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\ua035\udb11\udc24\ud9ab\udd16");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud862\udeef\ud9bc\udf37\udbf9\ude99\ud8a9\udd04\000\ud99c\udfce\ud883\udddf\udab3\udccc\udafc\udf3d\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\ua035\udb11\udc24\ud9ab\udd16", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\ud92f\udeec\uda55\uddee\udb10\udd78\uda62\udea9\udb9c\udffb\ud845\ude2a\uda93\udf59\uad23\ud889\udf9b\ud9f4\udf8d\udb4c\udfc4\udb7c\udd1f\uda74\udcf4\ua035\udb75\udcb7\ud9ab\udcd9\ud957\udf0a");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.capitalize("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.defaultString("\ud851\uddef\ud9bc\udf37\udbf9\ude99\ud9f9\udead\udb9c\udffb");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud851\uddef\ud9bc\udf37\udbf9\ude99\ud9f9\udead\udb9c\udffb", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\u5e0a\ud9bc\udf37\udbf9\ude99\ud934\udfe9\udb9c\udffb\ud9c5\ude5d\ud883\udddf\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\ua035\udb11\udc24\ud9ab\udd16");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\ud862\udeef\udbed\udd70\udb15\ude08\udba6\ude42\ud925\ude7b\ud9d0\udece\ud883\udddf\uad09\uda45\ude18\uda3b\ude41\udac0\udff4\ud861\udf70\ud9f7\udcf6\ud873\udff8\udb44\udfde\ud9ab\udd16");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\udb29\udf84\ud862\udd46\udbe4\ude68\ud892\udd99\udb9c\udffb\uda36\udd79");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb29\udf84\ud862\udd46\udbe4\ude68\ud892\udd99\udb9c\udffb\uda36\udd79", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\udb39\udf3c\ud946\udc85");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb39\udf3c\ud946\udc85", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\udb39\uded0");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb39\uded0", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.defaultString("\udb78\udec8\ud925\udf6d\uda34\ude55\ud946\ude51\u4f16\ud9c4\udd3e\ud8fc\ude76\udbda\udcac\uda5f\udc2b\udb57\udf9c\ud861\udc27\udb7c\udd1f\ud997\udf0f\udbea\udd8b\udba7\udcfa\ud9f4\udc21\udbb6\udecc\udb88\udcd9\ud981\udcae\udaf5\udfd2\ud897\udea3\ud9bd\udf52\ud863\udc20\udbed\udc82\ud9cd\ude28\ud81e\ude0b\udbbd\udc7f\udab9\udc4f\ud9c4\udf9e\udb07\udee8\uda54\udc3b\ud857\udea0\ud983\udd7b\ud9b8\uddf8\ud928\uddcf\udb99\ude08\udb56\uddef\ud86a\ude87\udb18\udfe0\ud810\ude38\ud9ac\udcad\ud822\uddc7\ud82c\udc2e\ud81d\udd2f\udb6e\udf0a\udb09\udeeb\ud944\udd03\udac6\udd6d\ud8f2\udf1c\ud9e2\udc11\udb3f\udc10\ue685\ud82b\udd4d\u36de\ud8ed\udcc8\u5d85\ud8f8\udf48\ud89c\udc07\ub253\uda8d\udc5b\ud966\udcb4\uda27\ude5a\ud8fe\udc52\udafa\udeb0\ud87e\ude4b");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\udb78\udec8\ud925\udf6d\uda34\ude55\ud946\ude51\u4f16\ud9c4\udd3e\ud8fc\ude76\udbda\udcac\uda5f\udc2b\udb57\udf9c\ud861\udc27\udb7c\udd1f\ud997\udf0f\udbea\udd8b\udba7\udcfa\ud9f4\udc21\udbb6\udecc\udb88\udcd9\ud981\udcae\udaf5\udfd2\ud897\udea3\ud9bd\udf52\ud863\udc20\udbed\udc82\ud9cd\ude28\ud81e\ude0b\udbbd\udc7f\udab9\udc4f\ud9c4\udf9e\udb07\udee8\uda54\udc3b\ud857\udea0\ud983\udd7b\ud9b8\uddf8\ud928\uddcf\udb99\ude08\udb56\uddef\ud86a\ude87\udb18\udfe0\ud810\ude38\ud9ac\udcad\ud822\uddc7\ud82c\udc2e\ud81d\udd2f\udb6e\udf0a\udb09\udeeb\ud944\udd03\udac6\udd6d\ud8f2\udf1c\ud9e2\udc11\udb3f\udc10\ue685\ud82b\udd4d\u36de\ud8ed\udcc8\u5d85\ud8f8\udf48\ud89c\udc07\ub253\uda8d\udc5b\ud966\udcb4\uda27\ude5a\ud8fe\udc52\udafa\udeb0\ud87e\ude4b", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\ub60e\udbe3\udf9f\ud9e1\udd8a\udb0f\udd0e\u6ca8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\ud898\udcb2\ud8fe\udd21\udaec\ude38\udbe9\udf76\ud807\uddc0\ud85b\udd47\udb98\udc41\udbd3\udd2c\uda99\ude6c\udb09\udcd3\udb0d\udf5c\udbc3\udc7c\ud96e\uddfa\uda66\udc2f\ud9b6\udfe0\ud8ea\udf15\ud9f8\udcc3\udaf0\udf9d\udb2e\uddf3\ud8d7\udf8e\ud969\ude0c\uda35\ude7a\udb8f\udfa1\ud8b6\ude91\u6639\ue94e\ud8c6\udc95\uda30\udde7\udb2b\udfb5\ud841\udecf\ud967\udf29\ud8b9\udecb\ud919\udf63\ud9a6\udc83\udbd7\uddbd\ud816\ude37\ud8ef\udd68\udb5e\udf31\ud9ed\udfd8\ud907\udc7f\ud9c8\udffa\udb5e\udd26\ud9c5\udfbc\ud81a\udeb7\ud875\udee8\udbc3\udc98\ud909\udf42\uda43\udf4b\udadc\udf80\udb16\udd7b\ud981\udc04\ud83a\udda2\udbbf\udd90\ud9fb\udc79\udba2\udd7a\udbbf\udf6a\ud8fc\udfbc\uda4c\udf02\u80bc\ud9f1\udee9\ud9e2\ude47\udbd9\udd21\ud811\ude69\ud849\uddc5\udbcb\udd0d\udb06\ude22\udb85\ude6e\ud952\udd53\ud9e6\ude4d\ud8a9\udc78\ud8b6\udeef\uda6c\ude0b\udaa8\udfc1\ud811\udf19");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\u82ef\ud9c3\udf40\ud831\udce2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\ub590");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\u04a4\udba2\ude18\u28c3\ud87c\udcf8\ud96a\udd98\udbdb\udd6b\ud89a\udc81\udb11\udcdb\uda45\ude18\uda3b\ude41\ud9e8\udf95\udb7c\udd1f\uda23\udfe2\udbd6\udfeb");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\u88ae\u8800");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\u13e9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chomp("\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chomp("");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\u5756\u9152\ud9d8\udcd6\udb2f\udfa6\ud961\udff6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\u5e0a\u6f88\udbf9\uddaa\ud934\udfe9\ud942\udd0d\ud9c5\ude5d\ud883\udddf\uad09\uda45\ude18\uda3b\ude41\ud861\udc30\udb7c\udd1f\uda74\udcf4\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\u3892\u0e42\udb38\udc9b\udacb\udde1\ud898\ude9b\uda5b\udf95\udbfb\udca4\u77fa\udbdc\udd89\udaa9\udc31");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\u04a4\udba2\ude18\u28c3\ud87c\udcf8\ud96a\udd98\udbdb\udd6b\ud89a\udc81\udb11\udcdb\uda45\ude18\uda3b\ude41\ud9e8\udf95\udb7c\udd1f\ud95c\udf0f\udbb8\udfc0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("\u04ab\ud800\udc22\u59d7\udb95\udc35\ud840\ude7d\udbdb\udd3b\ud89a\udc81\udb11\udc67\uda45\uddbb\udaf4\udc3e\uda57\udeee\u1454\uda24\udc9d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\u04a4");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("true", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.chop("\uda31\udc91\udbfc\ude8a\udbf9\ude99\udb1f\udde2\udb9c\udffb\ud9c5\ude5d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\uda31\udc91\udbfc\ude8a\udbf9\ude99\udb1f\udde2\udb9c\udffb\ud9c5", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\u82ef\u9fb3\uabe2\ud9b8\udc76\uda62\udf88\ud818\udfc7");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllLowerCase("\u04ab\uff56\u59d7\udb95\udc35\ud840\ude7d\udbdb\udd3b\udb49\udcd9\udb11\udc80\uda45\uddbb\udaf4\udc3e\uda57\udeee\u1454\uda24\udc9d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\u04ab\uff56\u59d7\uda77\udde7\ud970\udf6a\ud8ae\udc05\udb49\udcd9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\u6b80\uffcf\u59d7\udb95\udc35\ud840\ude7d\udbdb\udd53\ud89a\udc81\udbd1\udec7\uda6f\ude2d\udaf4\udc3e\uda57\udeee\ud96c\udf66\uda00\udda6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\ud898\udcb2\ud8fe\udd21\udaec\ude38\ud829\udd83\udbca\udc7e\ud85b\uddda\udb98\udc41\udbd3\udd2c\uda99\ude6c\udb09\udcd3\udb0d\udf5c\udbc3\udc7c\uda17\udcce\udbfc\ude54\ud81e\udcc5\ud8ea\udf13\ud9f8\udcc3\udaf0\udf9d\udb2e\uddf3\ud8d7\udf8e\ud969\ude0c\uda35\ude7a\udb8f\udfa1\ud8d2\ude91\u6639\ue94e\ud8c6\udc95\uda30\udde7\udb2b\udfb5\udbac\udf45\ud957\udeea\ud8b9\udecb\ud919\udf63\ud9a6\udc83\udbd7\uddbd\ud816\ude37\ud8ef\udd68\udb5e\udf31\ud9ed\udfd8\ud907\udc7f\ud9c8\udffa\udb5e\udd26\ud9c5\udfbc\ud81a\udeb7\ud875\udee8\udbc3\udc98\ud909\udf42\uda43\udf4b\udadc\udf80\udb16\udd7b\ud981\udc04\ud80a\udeee\udbbf\udd90\ud9fb\udc79\ud8b0\udc7d\udbbf\udf6a\ud8fc\udfbc\uda4c\udf02\ud827\udf1f\udbb6\udea5\ud9e2\ude91\udbd9\udd21\ud808\udf69\ud849\uddc5\udbcb\udd0d\udb06\ude22\udb85\ude6e\ud952\udd53\ud9e6\ude4d\ud8a9\udc78\uda3c\udca3\udbc5\udfd2\udaa8\udfc1\ud811\udf19");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\ud898\udcb2\ud8fe\udd21\udaec\ude38\ud829\udd83\udbca\udc7e\ud85b\uddda\udb98\udc41\udbd3\udd2c\uda99\ude6c\udb09\udcd3\udb0d\udf5c\udbc3\udc7c\uda17\udcce\udbfc\ude54\ud81e\udcc5\ud8ea\udf13\ud9f8\udcc3\udaf0\udf9d\udb2e\uddf3\ud8d7\udf8e\ud969\ude0c\uda35\ude7a\udb8f\udfa1\ud8d2\ude91\u6639\ue94e\ud8c6\udc95\uda30\udde7\udb2b\udfb5\udbac\udf45\ud957\udeea\ud8b9\udecb\ud919\udf63\ud9a6\udc83\udbd7\uddbd\ud816\ude37\ud8ef\udd68\udb5e\udf31\ud9ed\udfd8\ud907\udc7f\ud9c8\udffa\udb5e\udd26\ud9c5\udfbc\ud81a\udeb7\ud875\udee8\udbc3\udc98\ud909\udf42\uda43\udf4b\udadc\udf80\udb16\udd7b\ud981\udc04\ud80a\udeee\udbbf\udd90\ud9fb\udc79\ud8b0\udc7d\udbbf\udf6a\ud8fc\udfbc\uda4c\udf02\ud827\udf1f\udbb6\udea5\ud9e2\ude91\udbd9\udd21\ud808\udf69\ud849\uddc5\udbcb\udd0d\udb06\ude22\udb85\ude6e\ud952\udd53\ud9e6\ude4d\ud8a9\udc78\uda3c\udca3\udbc5\udfd2\udaa8\udfc1\ud811\udf19", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\034\000\000\000\ud867\udcb3\udbdb\udd3b\ud89a\udc81\udb11\udc67\uda45\uddbb\udaf4\udc3e\uda07\udee6\u1454\uda24\udc9d");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000\000\000\ud867\udcb3\udbdb\udd3b\ud89a\udc81\udb11\udc67\uda45\uddbb\udaf4\udc3e\uda07\udee6\u1454\uda24\udc9d", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumeric("\u04ab\uff56\u59d7\uc904\ud94e\udd73\ud8ae\udc05\udb49\udcd9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.deleteWhitespace("\034\000\000\000\ud867\udcb3\udbd6\udf3b\ud89a\udc81K\000\u3000\000\000\000");
    assertNotNull(r);
    assertEquals("java.lang.String", r.getClass().getName());
    assertEquals("\000\000\000\ud867\udcb3\udbd6\udf3b\ud89a\udc81K\000\000\000\000", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphaSpace("\u04ab\uff56\u59d7\uc904\ud94e\udd73\ud905\udcc9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\u04ab\uff56\u59d7\udb95\udc35\ud840\ude7d\udbdb\udd3b");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\u04a4\u0228\ud832\udcc9\ud87c\udcf8\ud96a\ude57\udbdb\udd6b\u3b9d\ud920\udc82\udb3c\udcd6\uda3b\ude83\ud9e8\udf95\udb7c\udd1f\ud95c\udf0f\udbb8\udfc0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAllUpperCase("\udb30\udd1e\uda67\udc89\ud97c\udc1d\u42ee\uda9b\udcca\ud87f\udf08\udac2\udf56\ud9c9\ude4a\udae6\udc69\ud965\udcd4\uda33\udd3c\uda75\udce6\uda92\uddf5\udb79\udf55\ud9c1\udf50\uda75\udf3e\ud9c5\udfbe\uda64\uddd9\ud80a\udcd6\udaeb\udfa8\udbcf\udc42\ud8a0\udc92\ud92c\udf11\uda65\udc09\uda7c\udc17\ud446\ud809\udd97\udac5\ude1d\udb85\udeed\ud943\udf42\udb84\uddb1\u26f2\ud90e\udd29\udb7b\udff1\udb47\udf4f\uda02\udec8\uda4f\ude14\ud9af\uddc2\ub26c\udb7b\udf17\udb33\udedd\ud85a\udd04\ud9bb\udeab\ud99f\udf64\ud97e\udfc5\ud8af\udea8\udbca\udd49\ud854\udfe3\udadf\udf9c\uda5b\udd93\udae4\udf6d\uda60\ude59\ud900\udd6e\udb34\udf58\udb8c\udeaf\uda92\udd5c\ud90c\uddb9\udaea\ude3b\ud8dc\udf7e\ud924\uddab\udb57\udfd8\ud83f\ude50\ud93a\udd27\udad0\udfdc\udbf6\uddc7\ud8a8\udcb4\ud834\udf4f\ud858\udf13\ud85d\udde4\ud871\udcd3\ud986\uddc5\ud85c\udda3\udb21\ude81\u8cbf\ud9f1\udfd3\ud961\udee3\ud925\udfbe\ud825\udf6b\ud98b\udcdb\uda50\udeb3\ud831\udec6\udb5f\udf3c\ud8d8\udc5e\ud974\udf62\uda14\udde5\udbaf\udd54\ud871\udc41\udb83\udf77\udabc\udd1f\ud927\uddef\udb10\udf38\ub355\ud8b6\udf72\udac9\udf9a\udbe6\udde7\uac1d\udb31\ude3d\udabe\udf34\udbfa\udee5\ud85b\udc3e\ud870\udd0c\udb76\ude7d\uda0c\udd65\uda60\udc3a\ud8bb\udeaa\uda10\udcc5\uda7d\ude80\ud9a0\udfde\uda27\udc20\ud98a\udf65\uda4f\ude5e\udb9b\udf85\u3923\udb0a\udf06\udb77\udd8b\ud885\ude85\uda9c\uddba\ud83e\udffd\ud9de\ude18\uda78\udc0e\udbcd\udd4b\udb51\uddd2\ud8f9\udd47\udb75\udf46\udab6\udcf4\udb4d\udff4\ud98c\udfc2\uda3c\udecd\udb7b\ude86\udac7\udca2\ud92e\udcf8\ud99a\udc80\ud86a\udd06\udb8d\udc0e\ud9b6\uddad\ud8b1\udc72\udade\udf7c\ud979\udcaa\ud81c\udc6f\ud93d\uddba\udb5c\udd7b\udbf3\udcd6\ud951\udde1\udbb3\udcde\ud913\udffa\ud948\udf3c\ud948\udca0\udb1b\ude2b\uda75\udc72\ud93a\udf9b\u7560\udb72\udc53\ud90f\udee1\ud992\ude9e\ud897\udf4c\ud94f\udca5\udaa7\ude6c\uda75\udf2f\ud947\udc29\ud9e7\udd41\ud97a\udd93\ud9b4\udcd9\udbba\udf2c");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlpha("\u04ab\uff56\ua9e1\uc904\ud94e\udd73\ud905\udcc9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    Object r = org.apache.commons.lang.StringUtils.isAlphanumericSpace("\u04ab\uff56\ua9e1\uc904\ud94e\udd73\ud905\udcc9");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
