package org.apache.commons.lang3.math;
import org.junit.Test;
import static org.junit.Assert.*;
public class Fraction_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud879\udcfa\ud899\uddfb\u468b\ud8d0\udd12\ud8ec\udc1e\ud8d7\uddf0\ub79a\udb6b\ude37\ud97f\ude3a\uda05\udff9\ud922\udf0b\ud8ce\udca4\uda2d\udd91\udaf1\ude33\ud9cd\ude14\ud8df\ude48\ud979\ude3b\ud9cb\udc3b\udb2b\udf74\ud8d2\ude82\udaf1\ude6e\ud937\udf1a\u836e\ud949\ude9c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\udae4\ude0f\udb43\udeee\u468b\ud8d0\udd12\ud8ec\udc1e\ud8d7\uddf0\ub79a\udb6b\ude37\ud97f\ude3a\uda05\udff9\ud922\udf0b\ud8ce\udca4\uda2d\udd91\udaf1\ude33\ud9cd\ude14\ud8df\ude48\ud979\ude3b\ud9cb\udc3b\udb64\udfab\ud8d2\ude82\udaf1\ude6e\ud937\udf1a\u836e\ud949\ude9c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud879\udcfa"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud879\udcfa\ud899\uddfb\u468b"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud876\udd81\ud899\uddfb\u468b\ud8d0\udd12\ud8ec\udc1e\ud8d7\uddf0"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud977\udc4d\ud91b\ude3b\u46a9\ud8d0\udd12\uda40\ude08\uda4e\ude01\ub79a\udb80\udebd\ud97f\ude3a\uda85\udc13\uda18\udf8f\uda10\ude1e\udb9e\udfaa\udaf1\ude33\ud9cd\ude14\ud88f\udee0\ud83a\udf90\ud9ca\udfc4\ud957\udc97\ud8d2\udef0\ud93f\udcb5\ud840\ude2d\udb88\udebf\udac4\ude4e\ud932\udebc\ud9da\udfe7\ud85b\ude99\udaaf\udfc3\udabd\udfac\udbee\udd3f\uda18\udcc5\ud9c2\udde2\udaa1\udf07\ud943\udd3a"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud879\udcfa\ud899\uddfb\u468b\ud8c4\udd4c\ub8d9\ud8d7\udd4b\ub79a\udb6b\ude37\ud97f\ude3a\uda05\udff9\ud98a\udf20\ud8ce\udce5\uda2d\udd91\udaf1\ude33\ud865\udc00\ud432"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud8d4\udc93\ud8cd\ude71\udad0\udffc\ud8d0\udd12\ud8ec\udc1e\ud98d\ude2a\ub79a\udb6b\ude37\ud97f\ude3a\udb7a\ude62\ud919\udf57\ud8ce\udca4\ud9ef\udebf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\000"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud879\udcfa\ud899\uddfb\u468b\000\ud8eb\udfa2\ud8d7\uddf0\u60b0\udb6b\uddb1\ud97f\ude3a\uda05\udff9/\ud894\udde9\uda2d\udd91\udaf1\ude33\udb81\ude0e\ud8df\ude48\ud979\ude3b\udb26\udc88\000\ud8b3\udf79\udaf1\ude6e\ud937\udf1a\u836e\ud949\ude9c"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang3.math.Fraction.getFraction("9");
    assertNotNull(r);
    assertEquals("org.apache.commons.lang3.math.Fraction", r.getClass().getName());
    assertEquals("9/1", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud879\udd10\ud899\uddfb"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ub4f5\ud899\uddfb\u468b\uda03\udf0d\ud8ec\udc6b\ud8d7\uddf0\ub79a\udb6b\ude37\ud97f\ude3a\uda05\udff9\ud922\udf0b\ud8ce\udca4\udb22\udd10\uda19\udf2a\ud91d\ude64\uda01\udf55\ud979\ude3b\ud925\ude40\udb2b\udf74\udaf9\ude16\udbcf\udf53\ud937\udeed\u836e\ud949\ude9c\uda2e\udf64\udb09\udebe\ud896\udd3e\ud9e4\udc29\ud9c8\udf37\udac1\udca9\ud9b3\udd80\uda58\udd19\udb48\udf5e\udb40\udd2c\ud9b5\udf1b\ud939\uddbe\ud9c3\uded2\ud87d\udf7c\ubd4c\udb89\uddc3\ud834\udd77\ud963\udce6\udb4f\ude09\ud988\uddeb\udad7\ude89\udaf0\udc84\ud91a\udeea\uda97\udd3b\uda3f\ude1a\ud863\ude12\ud8bd\udc24\uda34\udd03\ud923\uddfa\uda44\udf3d\ud80e\udf0c\u5111\ud91a\ude58\ud98c\udf3d\udabc\udc2d\ud9da\udc7e\ud949\udd7f\uda74\udf3a\udaec\udc1d\ue061"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud879\udcfa\ud8a3\ude40\u46c9\000\ud8eb\udfa2\ud869\udeb8\u6003\udb31\uddb4\ud895\udcb6\uda04\ude76 \ud894\udde9\udbba\udc93\ud954\udf1d\udaba\udd2a\udb5a\udf46\ud9e1\udcdf\ud913\udf45\u9300\ud864\udc71\ud891\udf1f\udbba\udffe\ud9db\udf4b\ud943\udc9d"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud9e4\udcf9\ud843\udd83\ud9e6\udc2a.\ud8eb\udfa2\ud8d7\uddf0\u60b0\udb6b\uddb1\ud97f\ude3a\uda05\udff9\ud8c0\udede\ud9e5\udc60\uda2d\udd91\udaf1\ude33\udb81\ude0e\ud8df\ude48\ud979\ude3b\udb26\udc88\000\ud8b3\udf79\udade\udfae\ud826\uded1\ud829\udc85\u6491\uda27\udf65\udb16\uddcf"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud9bf\udff0\ud853\udd78\uda43\udf64\uda54\udd71\ud8a8\udefb\ud92b\udff7\udafb\udc8d\ud85a\udec6\uda0d\ude55\ud851\uddfc\u54a4\ud969\udc0e\ud98c\udfe7\uda54\udeec\uda44\udcd0\uae18\udb06\ude13\udbb0\udf8a\ud9a9\udd30\udb15\udc8c\udb2a\ude4c\udb22\udf63\ud947\udc04\ud9c6\udf78\ud92b\udc64\uda11\udf8c\ud995\udfcf\ud88e\ude03\ud964\udf84\ud976\udf7b\ud917\udd40\ud8bf\udf53\ud984\udfc2\udb0a\udd25\ud987\udc3a\ud8c7\udc74\uda4f\ude1c\udb32\ude5c\ud976\ude5b\udb36\udfd1\ud9e5\udf58\uda83\udc80\ud8de\udc77\ud9e0\udc39\ubbd4\udada\uddf9\ud8c1\udf40\udb51\udd0c\udb95\udef8\ud94d\udf9e\ud811\udc17\udb3e\udfbb\udb92\ude30\uac30\udabb\udc8a\udab6\udc77\u00c6\udba1\ude0c\ud8d7\udf0b\ud9e5\udd16\ud9bc\ude12\ud895\ude18\udb48\uddb4\ud864\udf0d\udab8\udf2f\ud96b\udcce\udac2\udc00\ud9da\udeef\udacd\udcc2\ud9ba\udd08\ud837\udd27\udb9b\ude84\u94fb\ud977\udd59\ud9de\udce4\ud8f9\udd2c\uda7b\udcb4\ud82d\udcdb\udb3f\udd1c\udaa5\udc1d\ud9c6\udd2b\uda7c\udce7\ud807\udddb\uda63\uddb8\ud859\udef5\udb3e\udd2e\ud9c5\udc2b\ud98a\udfc2\ud880\udeb5\udb4e\udfd8\ufddd\uda76\udebe\udbfe\udeeb\udb60\ude67\ud876\udc1e\ud8a3\udcec\udb16\udd5d\ud9f4\udd2e\u3544\ud8db\udd94\udb06\udd62\ud915\udc3c\ud810\udfa5\udb72\ude20\uda85\udc8d\ud8e4\udd18\ud914\udda1\ud9e0\udf72\ud958\udd8b\udb81\udfcd\ud9ae\udd4f\uda93\ude68\uda04\udf9a\ud80b\udd49\ud996\udc27\ud915\ude52\udb57\ude22\udbae\udc5c\ud931\udedf\udb5f\udc6e\uda63\udfa9\ud85c\uddcf\ud948\udf4b\ud82a\udca2\u1b5a\udbde\udf92\ud82f\udd3a\udb4a\ude4b\uda24\udf73"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    try { org.apache.commons.lang3.math.Fraction.getFraction("\ud9bf\udff0\ud853\udd78\uda43\udf64\uda54\udd71\ud8a8\udefb\ud92b\udff7\udafb\udc8d\ud85a\udec6\uda0d\ude55\ud851\uddfc\u54a4\ud969\udc0e\ud98c\udfe7\uda54\udeec\uda44\udcd0\uae18\udb06\ude13\udbb0\udf8a\ud9a9\udd30\udb15\udc8c\udb2a\ude4c\udb22\udf63\ud947\udc04\ud9c6\udf78\ud92b\udc64\uda11\udf8c\ud995\udfcf\ud88e\ude03\uda00\udf52\ud976\udecf\ud917\udd40\ud8bf\udf53\ud984\udfc2\udb0a\udd25\ud987\udc3a\ud8c7\udc74\uda4f\ude1c\udb32\ude5c\ud976\ude5b\udb36\udfd1\ud9e5\udf58\uda83\udc80\ud8de\udc77\ud9e0\udc39\ubbd4\udada\uddf9\ud8c1\udf40\udb51\udd0c\udb95\udef8\ud94d\udf9e\ud811\udc17\udb3e\udfbb\udb92\ude30\uac30\udabb\udc8a\udab6\udc77\u00c6\udba1\ude0c\ud8d7\udf0b\ud9e5\udd16\ud9bc\ude12\ud895\ude18\udb48\uddb4\ud864\udf0d\udab8\udf2f\ud96b\udcce\udac2\udc00\ud9da\udeef\udacd\udcc2\ud9ba\udd08\ud837\udd27\udb9b\ude84\u94fb\ud977\udd59\ud9de\udce4\ud8f9\udd2c\uda7b\udcb4\ud82d\udcdb\udb3f\udd1c\udaa5\udc1d\ud9c6\udd2b\uda7c\udce7\ud807\udddb\uda63\uddb8\ud859\udef5\udb3e\udd2e\ud9c5\udc2b\ud98a\udfc2\ud880\udeb5\udb4e\udfd8\ufddd\uda76\udebe\udbfe\udeeb\udb60\ude67\ud876\udc1e\ud8a3\udcec\udb16\udd5d\ud9f4\udd2e\u3544\ud8db\udd94\udb06\udd62\ud915\udc3c\ud810\udfa5\udb72\ude20\uda85\udc8d\ud8e4\udd18\ud914\udda1\ud9e0\udf72\ud958\udd8b\udb81\udfcd\ud9ae\udd4f\uda93\ude68\uda04\udf9a\ud80b\udd49\ud996\udc27\ud915\ude52\udb57\ude22\udbae\udc5c\ud931\udedf\udb5f\udc6e\uda63\udfa9\ud85c\uddcf\ud948\udf4b\ud82a\udca2\u1b5a\udbde\udf92\ud82f\udd3a\udb4a\ude4b\uda24\udf73\ud877\udd25\ud96d\udefe\ud8ba\uded6\ud941\udf29\ud9b3\udca5\ud82f\udcfb\ud8ac\udc05"); fail("expected NumberFormatException"); }
    catch (java.lang.NumberFormatException e) { }
  }
}
