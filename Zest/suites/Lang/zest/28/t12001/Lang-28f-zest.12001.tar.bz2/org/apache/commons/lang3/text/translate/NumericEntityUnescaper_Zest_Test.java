package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumericEntityUnescaper_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda38\uddf6", "\u4493\u9251\u095f\u8ee7\u9ba2\u2d5f\u6811\ube14\ub5e9\u81d8\u3a7f\ua36b", "\udb66\udf89\ud8b0\udc13\udae8\udc9f",
        37, 20994, -287020820, 132603349680341136L, 64559L, false, false, (char) 19024, (char) 23523,
        Double.longBitsToDouble(0x3fdebd7b5a7894a8L), Double.longBitsToDouble(0x3fbfe54783fc3248L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 0, "\ud818\udd4d\uda38\uddf6", "\u4493\u9251\u095f\u8ee7\u9ba2\u2d5f\u6811\ube14\ub5e9\u81d8\u3a7f\u9f01", "\ud866\ude0a\ud8b0\udc13\udafd\udd9f",
        37, 20994, -287020820, 132603349680341183L, 64559L, false, false, (char) 19024, (char) 23523,
        Double.longBitsToDouble(0x3fdebd7b5a7894a8L), Double.longBitsToDouble(0x3fbfe54783fc3248L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda38\uddf6", "\u44a8", "\udbbc\udf30\udbff\udd68\udb93\udfb2\ud997\udf68\ud889\udc4e\ud802\ude9c\ud87c\udf0a\ud8f1\udcd2\ud877\udcdb\ud94d\ude36\ud8a2\udc8c\udb66\udf89\ud8b0\udc13\udae8\udc9f\ud9d2\udf5e\ud88e\uddd7",
        0, 68123, 193282192, -293318074467004155L, 38352L, true, true, (char) 19873, (char) 30608,
        Double.longBitsToDouble(0x3fbfe54783fc3248L), Double.longBitsToDouble(0x3feb8af1b535c0cdL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 0, 0, "\ud818\udd4d\uda38\uddf6", "\u5a72\u1869\u787a\u18ad\u9ba2\u2d5f\u6811\ube14\ub5e9\u81d8\u3a7f\ua36b", "\udb66\udf89\udb5a\udf17\udab3\udcbf",
        37, 20994, -287020820, 132603349680341136L, 64559L, false, true, (char) 18865, (char) 32052,
        Double.longBitsToDouble(0x3fdebd7bea7894a8L), Double.longBitsToDouble(0x3fbfe54783fc3248L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda34\udcf7", "\u4493\ua1cb\u09a0\uc1f9\u9ba2\ua8ad", "\u2cf4\ud8af\udd15\uda23\ude0c\ud847\udcca\udb8b\ude28\ud9a5\udef6\udb9f\udc5e",
        35, 96303, -1308035084, 2809475933527142000L, -17936L, false, true, (char) 19659, (char) 46319,
        Double.longBitsToDouble(0x3fbc0b596fc37770L), Double.longBitsToDouble(0x3fdebd7b575694a8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 1, "\ud818\udd4d\uda38\uddf6", "\u4493\u9251\u095f\u8ee7\u1b57\u2cd8\u6811\ube14\ub5e9\u81d8\u96b2\uc311", "\udb66\udf89",
        10, 96303, -1305020428, 7781449920296895288L, -17936L, true, true, (char) 19458, (char) 10428,
        Double.longBitsToDouble(0x3fbc0b782dab7170L), Double.longBitsToDouble(0x3fdebd78fe7894a8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda38\uddf6", "\u7fdf\u927f\u095f\u8ee7\u9ba2\u2d5f\u6811\u11bc\ud6df\u2be2\u2e1f\u2d79", "\udb66\udf29\ud8b0\udc13",
        23, -511, -1023589510, 5412662499344831634L, 43428L, true, true, (char) 4834, (char) 61871,
        Double.longBitsToDouble(0x3fd3c4a541912a3cL), Double.longBitsToDouble(0x3fbfe1af546bcd00L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda38\uddf6", "\u4493\u9251\u095f\u8ee7\u9ba2\u179a\u6811\ube14\ub5e9\u81d8\u3a7f\ua36b", "\udb66\udf89\ud8b0\udc13\udae8\udc9f\ud9d2\udf5e\ud88e\uddd7\udb95\udfe9\udafe\ude26\uda11\udc6f\udbdc\ude34\ud8e9\udc15\ud83f\udd72\ud8c6\udeee\ud87c\udf55\ud962\ude4c\ud9f1\udeef\udb10\udd52\ud951\uddbe\udb24\udd52\ud8bc\ude7a\udba6\udf4f\udbd2\udff2\udaee\udf2d\udbfd\udd91\udaac\udc69\udba5\udf0c\uecb6\ud837\udfb8\udac9\udff2\uda94\udcea\udba6\udd84\ud8b5\udd64\ud82c\udd7a\udac3\ude76",
        13, 44141, -231552782, -2364299706658237264L, -38913L, false, true, (char) 16698, (char) 8864,
        Double.longBitsToDouble(0x3fbcd8797d4c5ea8L), Double.longBitsToDouble(0x3feb20f89efbdf23L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 1, "\uda77\udcbc\udbcd\udd9f\ud8fe\udc7f\uda9d\ude43\ud852\udf78\uda54\uddcf\ud916\ude1d", "\u2d5f\u2abc\u157f\u3005\u81d8\u3a7f\ua36b", "\uda8a\udd5b\ud8a9\udf76\udb13\udc9f",
        37, 20994, -299242230, 3887076563693944976L, 59299L, false, false, (char) 19024, (char) 23523,
        Double.longBitsToDouble(0x3fd5ad7b5e29e440L), Double.longBitsToDouble(0x3fc3796401fe1924L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud840\ude85\uda38\ude0f\ud87b\udfc5\ud8e6\udfdc\ud852\udfd7\ud8ec\udef2\uda08\ude59\udbbc\udf65\uda5e\udf24\ub685\u143b\ud889\udcca\ud802\ude9c\ud87c\udf0a\ud8f1\udcd2\ud877\udcdb\ud94d\ude36\ud8a2\udc8c\udbb5\udc83\ud8f8\uddac\udae8\udc9f\ud9d2\udf5e\uda70\uddc8\udab1\udd72\udb29\udf26\uda11\udc6f\udbdc\ude34\ud8e9\udc15\ud83f\udd72", "\u8e03\u7e8e\uc83d\u60b7\ua80c\u629e\u9760\u5988", "\ud813\udc86\udbe7\ude74\ud99b\udff1\uda85\udecb",
        38, 88573, 952155415, 145574734838788409L, 67223L, true, false, (char) 7878, (char) 63544,
        Double.longBitsToDouble(0x3fd692b5f6c53b00L), Double.longBitsToDouble(0x3fe9991834425575L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda38\uddf6\ud84e\udcef\ud8bc\udf1d\ud852\udfd7\ud8ec\udef2\uda08\ude59\udbbc\udf65\udbff\udd68\udb93\udfb2\ud997\udf68\ud98f\udf31\ud823\udc48\ud912\ude72\ud933\udc9b\ud877\udcdb\ud94d\ude36\ud8a2\udc8c\udb66\udf89\ud8b0\udc13\udae8\udc9f\ud9d2\udf5e\ud88e\uddd7\udb95\udfe9\udafe\ude26\uda11\udc6f\udbdc\ude34\ud8e9\udc15\ud83f\udd72\ud8c6\udeee\ud87c\udf55\ud962\ude4c\ud9f1\udeef\udb10\udd52\ud844\udd98", "\u72e8", "\udbec\udf35\uda4e\udffc\udbcb\uddd0\u87ec\ud846\udc83\ud90a\udefb\ud862\ude8c\ud9fb\udf37\udbff\udff3\ud8e4\udc96\udb97\udd64\udac3\uddc0",
        7, 25128, 1702982993, -222457271938919301L, -60451L, true, true, (char) 39265, (char) 431,
        Double.longBitsToDouble(0x3fd4192cf2b71354L), Double.longBitsToDouble(0x3fde60112d2c0e2cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda38\uddf6", "\u7cf8\uccb0\u733a\u3498\ud31b\uca35\ua9d2\ube14\u83d6\u81d8\u2d3c\ua36b", "\udb66\udf13\udb0a\udcc0\uda82\uddeb",
        37, 66530, 77319901, -263492533580604296L, 53473L, true, false, (char) 9741, (char) 43257,
        Double.longBitsToDouble(0x3fe919442c847a7aL), Double.longBitsToDouble(0x3fe2ff7a05354aa6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 0, 0, "\ud9d9\udfda\uda38\uddf6", "\u447e", "\udbbc\udf65\udbff\udd68\udb93\udfb2\ud997\udf68\ud889\udc4e\ud802\ude9c\ud87c\udf0a\ud8f1\udcd2\ud877\udcdb\uec82\ud8f7\ude52\ud958\uddaa\uda29\ude37\udbf4\udfa5\ud9d2\udf5e\ud88e\uddd7",
        0, 83941, 1102696308, -3544151371673404111L, 38352L, true, true, (char) 19873, (char) 30608,
        Double.longBitsToDouble(0x3fc74743d1fe1924L), Double.longBitsToDouble(0x3fa112413a67e040L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\ud907\ude5e\ud86f\ude02\ud8bc\udf1d\ud852\udfd7\ud8ec\udef2\uda08\ude59", "\u2d5f\u6811\ube14\ub5e9\u81d8\u3a7f", "\ud8a2\udc8c\udb66\udf89\ud8b0\udc13\udae8\udc9f\ud9d2\udf5e\uda02\udff2\udb6f\uddc3\ud891\udc86\udaa7\udeb4\udbdc\ude34\ud8e9\udc15\udadb\udc80\ud8c6\udead\ud87c\udf55\ud962\ude4c\ud9f1\udeef\udb10\udd52\udac6\ude59\uda7b\udef9\ud85b\udf60\uda04\udd65\ud998\udea3\ud8bd\udc22\ud8be\udd09\ud89c\udf05",
        3, 60035, 1227272627, -2377059427776233002L, -70242L, false, true, (char) 39636, (char) 24182,
        Double.longBitsToDouble(0x3fd5da4d60f4744eL), Double.longBitsToDouble(0x3fe6d03e4f487562L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udcc8", "\u6932", "\ud892\udc08\udba4\udeb1",
        30, 72400, -1777707609, 438086664192L, -43213L, false, true, (char) 51723, (char) 0,
        Double.longBitsToDouble(0x3febd59000ec6bfdL), Double.longBitsToDouble(0x3f4ddc8240000000L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 0, "\ud969\udffa\udba4\udc5f\udb66\udc49", "\u4556\u6931\u8ee7\u9ba2\u2d77", "\ud802\ude9c\ud87c\udf0a\ud8f1\udcd2\udb4d\udf85\ud97f\ude8f\ud8a2\udc8c\udb66\udf89",
        10, 96303, -1305020428, 7712013563826825452L, -17936L, true, true, (char) 23297, (char) 44447,
        Double.longBitsToDouble(0x3fbc2869adab7170L), Double.longBitsToDouble(0x3fdebd7b5a7894a8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udcc8\000", "\u4493\u9251\u095f\u8ee7\u9ba2\u2d5f\u00a7", "\u00af\u84cb",
        0, 82212, 1122301083, 6987015769311429444L, -32404L, false, true, (char) 54505, (char) 2288,
        Double.longBitsToDouble(0x3fc2003af46d06e4L), Double.longBitsToDouble(0x3fd31ced057dda62L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udcc8", "\000\000\000\u2000\u8ee7", "",
        6, 98830, 645062744, 435462333552883370L, 87859L, false, true, (char) 58379, (char) 56701,
        Double.longBitsToDouble(0x3febd591b0ec6bfdL), Double.longBitsToDouble(0x3fe05f77209001d7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud818\udd4d\uda38\uddf6\ud84e\udcef", "\ucfb8\u632b\u35d2\u796b\u8d02\ub1d5\u0bf4", "\udb14\ude45\ud9a4\ude52\uda2f\udeed\ud8d1\udc72\ud829\udf16\ud8f6\ude96\udb46\udf2d\uda8b\uddde",
        39, 20180, 30874123, 4699352897183327515L, 26389L, true, false, (char) 30764, (char) 47966,
        Double.longBitsToDouble(0x3fe4f9f9cdf45af6L), Double.longBitsToDouble(0x3fe742b92c9918d1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\ud8f6\ude57", "\u44dc\u9251\u095f\u8ee7\u9ba2\u6d87\u6811\ube14\ub5e9\u874b\u3a7f\ua36b\u770d\u83e3\u30bf\u4b19\u4ad1\ucbc2", "\ud9f0\udfa8\ud996\ude60\udb1a\udd52\ud8e9\udc4f\ud83f\udd72\ud9e2\ude1b\udad8\ude1b\ud804\udddd\ud9f1\udeef\udb1e\udf44\udbd3\uddff\u64d0\udac7\ude7b\ud94a\udd09\u5696\ud870\udf84\udb35\udf32\uda8f\udcab\udac4\udd9f\ud946\ude2f\udbec\ude09\uda51\udeeb\udb1f\udfad\uda96\ude52\ud886\udc7a\ud8b9\udfb8\ud89d\udfbd\ud889\udf04\uda1e\uddda\udb93\udcd4\udb4f\udf0b\ud849\udd1d\udb44\udf37\udbc9\udc96\uda44\ude42\ud888\udfe8\ud89c\udebb\ud882\udf3a\ud84e\udeab\ud995\udf75\uda47\udf7a\ud890\udf58\udac9\udf85\ud8db\udfcd\uda91\udfc2\udbf6\udfd8\ud8d9\udde5\udbd9\uddd9\ud94c\udebc\udb0e\udd12\udb73\udcb8\ud8d4\udc83\u553f\ud983\udc2b\u8d0c\ud9b5\uddd8\ud969\udc08",
        51, 96676, 1752716849, 3962353804968942798L, 14499L, true, false, (char) 59073, (char) 54141,
        Double.longBitsToDouble(0x3fd050327c590dbeL), Double.longBitsToDouble(0x3fe3c1f8e66c1d95L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 1, 0, "\ud818\udd4d\uda38\uddf6", "\u4493\u9251\u095f\u8ee7\u9ba2", "\uda20\udcc5\ud844\udc00\ud87c\udf0a\ud8f1\udcd2\ud846\udfa2\ud94d\ude36\ud8a2\udc8c\udb66\udf89\ud8b0\udc13\udae8\udc9f\ud9d2\ude76\udae9\udcc5\ud853\udfeb\ud9e0\udc75\ud90f\udf88\udbdc\ude34\uda19\ude61\ud943\udf13\ud8c6\udeee\ud87c\udf55\ud962\ude4c\ud9f1\udeef\udb10\udd52\udae8\ude2b\udb10\udcb8\ud8c1\udefb\udbc0\udeb1\udb31\udc7a\udbe2\ude6c\ud9d2\udc70\udbde\udc4e\udb72\udfec\ud9e8\udcb1\udbd1\udeaa\ud96c\udd15\uda58\ude66\udbff\udda1\uda5e\ude94\ud917\udd9d\udb6e\ude0b\udb8a\ude8b\ud864\udd69\u2d3c\uda05\ude89\uc078\udb17\udf46\udbb2\udda9\ud9c0\udcab\uda93\udcd5\ud8f2\udd3b\ud926\udebb\ud860\udf35\udbf3\udd6b\udbed\ude5c\udb62\ude57\udbde\udd71\udb2c\udc3d\udb21\udca2\udaf9\udf42\ud9e0\udde9\udac3\udcc2\udaf3\udc89\udafe\udd68\ud8e4\udf73\ud85d\udfc4\ud879\ude84\ud8dd\udfc2\udb1b\udec8\ud8ea\udf9c\uda41\ude1e\ud82b\udd2c\ud879\udce1\udae2\ude2d",
        35, 57913, -612946215, 5547787563276016173L, -88418L, false, false, (char) 49032, (char) 39539,
        Double.longBitsToDouble(0x3fe89785e4db5fa0L), Double.longBitsToDouble(0x3fe0af6ac81bbd60L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\000\000", "", "\uda00\udd9f",
        33, 14102, -1464697640, -7635196043670593434L, -99825L, false, false, (char) 61695, (char) 0,
        Double.longBitsToDouble(0x3fc3701c974d0b90L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "", "\ua54b\u1af9\u0089\u471c\u20ba\u7d55\u9ba2\u75ab\u676a\000\ub591\u1abc\000\000\000\u6747\u30bf\u4b19\u30a2", "\u00ec",
        21, -1000, -68293436, -1355212930175446338L, 26208L, true, false, (char) 0, (char) 43007,
        Double.longBitsToDouble(0x3fbfe1927b8af000L), Double.longBitsToDouble(0x3fd35c0cd71ee2c2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\ud9c8\udffa\udbdf\udd22\udad6\udd60\ud852\udfec\udaf6\ude97\uda08\ude59\udbbc\udf30\udbff\udd68\udb93\udfb2\ud997\udf68\ud889\udc4e\ud802\ude9c\ud87c\udf0a\ud8f1\udcd2\ud877\udcdb\ud94d\ude36\ud8a2\udc8c\udb66\udf89\uda14\udd13\udae8\udc9f", "\u3ca5\u4c39\u4e44\uc7b9\u82ba\u611d\u0f06\u95f4", "\udb10\udd52\ud92d\ude0c\uda32\udfb7\udb7d\udf49\udaa1\udf8c\ud9e8\udcf1\uda5c\ude46\ud88f\uddd4\u0984",
        -4, 68430, 374577531, 4396366807689606460L, 95388L, true, true, (char) 2024, (char) 49260,
        Double.longBitsToDouble(0x3fdda6eccfee5582L), Double.longBitsToDouble(0x3fefe5e8e4ab48e0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 1, "\ud818\udd4d\uda38\uddf6\udb33\udf96\udad6\udc99\udb55\udd60\ud811\udf77\ud9e9\uddb9\uda33\udc20\uda13\udc17", "\u5b5c\ub5e9", "\ud877\udcdb\ud94d\ude36\ud8a2\udc8c\udb66\udf89\ud8b0\udc13\udae8\udc9f\ud87e\udf53\ud88e\ude33",
        0, 24203, -1391941943, -352214510025487355L, 56641L, true, true, (char) 19873, (char) 30608,
        Double.longBitsToDouble(0x3fbfe547b86558a0L), Double.longBitsToDouble(0x3fc1feb414d70334L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d", "", "",
        45, -1000, 0, 0L, -91910L, false, false, (char) 4783, (char) 170,
        Double.longBitsToDouble(0x3d96f62000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda38\uddf6", "\u4493\u9251\u095f\u8ee7\u9ba2\u2d5f\u6811\ube14\ub5e9\u81d8\u3a7f\ua36b", "\udb66\udf89\ud8b0\udc13\udae8\udc9f",
        37, 20994, -287020820, 132603349680341136L, 64559L, false, false, (char) 19024, (char) 23523,
        Double.longBitsToDouble(0x3fdebd7b564e94a8L), Double.longBitsToDouble(0x3fbfe54783fc3248L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 0, 0, 0, "\ud818\udd4d\uda38\uddf6\ud84e\udcef\ud91c\udf62\ud850\udf40\ud8ec\udef2\uda10\udc59\udb7d\ude25\ud9dc\udcdc\udae7\udf91\ud997\udf68\ud932\udfe3\ud8f7\ude32\ud9fa\udc08\uda70\udeff\udbb7\udd63\udb83\udcad\uf034\uda26\uddd9\ud8b0\udc13\udae8\udc9f\u70ba\ud88e\uddd7\udb95\udfe9\udafe\ude26\uda11\udc6f\udbdc\ude34\ud8e9\udc15\ud83f\udd72\ud8c6\udeee\ud87c\udf55\ud962\ude4c\ud9f1\udeef\udb9f\udcb7\udb37\uddea\ud9a0\uded8\udb03\udf8e", "\u6561\uc2cb\u6e8e\ubb25\u9b09\uc29a\u7f45\u5a30\u0747\uc3e5\ub8b8\u4222\ua29d\u84d0\ub32f\u1848\u660e\u05ab\u73e7\u22f1\ubfff\u0a15\u9eda\ud41b\u892e\u7db8\u3509\u631e\u3756\ubc6c\u8ff2\u650d\u5fb7\u54ea\u9753\u3c82\u9409\u00ab\u02d4\u98bd\u8f15\ube04", "\udaba\udfad\uda67\ude97\ud9f7\uddcc\ud903\udfac\uda2c\udd57\udaab\ude99\udb3f\udf54\ud9ad\udf28\uda63\udda7\ud993\udca3\ud913\ude71\ud981\udecf\ud836\udd40\uda55\udf61\ud955\udca7\udbd1\ude0a\ud957\uded2\ud945\udefe\udb4a\udf67\u2f08\udb9c\uded5\udb04\udc4f\udaf3\udff4\ud8df\udc6d\ud9be\udec6\ud972\uddcb\ud94d\ude61\udb7c\udd03\udb10\uddb8\udb4e\udc48\udae9\uddb2\ud886\ude5b\ue32b\ud9e4\ude9b\ud87e\udd01\udac4\udf8a\udb3e\udc37\udaea\udc25\uda47\udeb8\uda41\ude54\ud895\udcbd\uda9e\udeae\ud9c7\udee1\ud907\uddb5\udba7\udfc4\udbb1\uddc9\uda26\udf3a\uda50\udfbd\ud812\uded9\ud803\udc6c\uda24\udf65\u9edf\ud9c8\ude82",
        44, 81215, 1403195337, 4623607878835649737L, -97251L, true, true, (char) 37528, (char) 9325,
        Double.longBitsToDouble(0x3fdb1fb235889cbeL), Double.longBitsToDouble(0x3fb3a3cfe5cab578L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud840\ude85\udabf\udd16\ud87b\udfc5\ud8e6\udfdc\ud852\udfd7\ud9c3\udcde\uda08\ude59\udbbc\udf65\udb71\ude9b\ud91f\udd77\u143b\ud889\udcca\ud802\ude9c\ud87c\udf0a\ud8d7\udccd\ud877\udcdb\ud94d\ude36\ud8a2\udc8c\udbb5\udc83\ud8f8\uddac\udae8\udc9f\ud9d2\udf5e\uda70\uddc8\udab1\udd72\udafc\udc50\uda11\udc3e\udbdc\ude34\ud8e9\udc15\ud83f\udd72", "\u8e03\u7e8e\ucc63\u60b7\ua80c\u629e\u9760\u5988", "\ud813\udc86\udbe7\ude74\ud99b\udff1\uda85\udecb\udb8c\ude88\ud8c1\ude0c\ud8a2\udc6f\ud9c9\udf91\ud96c\udcf6\ud833\udf96\udb22\udea5\udaa5\udf9f\udb58\ude5a\ud939\udf72\u639b\ud989\udd72\ud8f4\udc3c\ud9d4\udf56\uda7b\udf36\u9cdc\ud991\udf2c\ud868\udc92\udb2a\udeee\uda1c\udf59\ud943\udf9c\ue51f\udbf1\udde2\udb79\udcd4\udaa7\udde0\ud8dc\udc3e\ud9b8\udf28\udae0\udd22\ud87b\udc08\udb70\udff2\udaf5\udc86\udb42\udd74\ud805\udc37\udada\udd9b\ud977\udf3d\u8308\ud95b\udf2f\udad6\udc92\udac5\udc07\ud926\udd4f\udbf5\udc34\udba2\udd99\udbf1\udee2\udbaf\udda2\ud85f\ude51\ud8fb\udc9d\ud91e\udf71\ud972\udd3b\uda3b\udfe0\u08b1\udba3\udf39\udac1\udf8e\ud820\udf63\ud91c\udfcc\ud8db\ude94\ud80f\ude5b\ud9eb\ude48\udbdb\udf33\udbde\udf94\udb14\udce1\ud87b\udf41\uda1b\udd3c\udab9\udd7e\u208a\udbf4\udf45\ud80f\udcfd\ud8bf\udcf6\ud878\ude99\udabe\ude7e\ud95f\udcc9\ud9f2\udf96\ud89b\ude16\ud8f1\udeb7\ud8c0\udd0f\ud9d3\udfe5\udb86\udda8\udb04\udd6b\ud9e4\ude30\udb14\uddaf\udb7c\udf07\ud85b\ude80\ud881\udfe2\ud892\udcf3\uda18\uddc1\u0893\ud938\udcc2\ud8a0\uded0\uda97\udcdf\ud94b\udef7\uda90\udcbe\ud8fa\udf40\ud973\uddbe\udaff\udf8a\udb2f\udc58\udba1\ude98\uda1e\udcf7\ud943\udfc8\udbc7\ude01",
        55, 91015, -1874762474, -3964393724225221070L, 15205L, false, true, (char) 4773, (char) 36659,
        Double.longBitsToDouble(0x3fee359cbee2366dL), Double.longBitsToDouble(0x3fd46c6f08a4e5e6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb1b\udeb9\udabf\udd16\ud87b\udfc5\ud8e6\udfdc\ud852\udfd7\ud9c3\udcde\uda08\ude59\udbbc\udf65\udb71\ude9b\ud91f\udd77\u143b\ud889\udcca\ud802\ude9c\ud87c\udf0a\ud8d7\udccd\ud877\udcdb\ud94d\ude36\ud8a2\udc8c\udbb5\udc83\ud8f8\uddac\udae8\udc9f\ud9d2\udf5e\uda70\uddc8\udab1\udd72\udafc\udc50\uda11\udc3e\udbdc\ude34\ud8e9\udc15\ud83f\udd72", "\u8e03\u7e8e\ucc63\u60b7\ua80c\u629e\u9760\u5988", "\ud813\udc86\udbe7\ude74\ud99b\udff1\uda85\udecb\udb8c\ude88\ud8c1\ude0c\ud8a2\udc6f\ud9c9\udf91\ud96c\udcf6\ud833\udf96\udb22\udea5\udaa5\udf9f\udb58\ude5a\ud939\udf72\u639b\ud989\udd72\ud8f4\udc3c\ud9d4\udf56\uda7b\udf36\u9cdc\ud991\udf2c\ud868\udc92\udb2a\udeee\uda1c\udf59\ud943\udf9c\ue51f\udbf1\udde2\udb79\udcd4\udaa7\udde0\ud8dc\udc3e\ud9b8\udf28\udae0\udd22\ud87b\udc08\udb70\udff2\udaf5\udc86\udb42\udd74\ud805\udc37\udada\udd9b\ud977\udf3d\u8308\ud95b\udf2f\udad6\udc92\udac5\udc07\ud926\udd4f\udbf5\udc34\udba2\udd99\udbf1\udee2\udbaf\udda2\ud85f\ude51\ud8fb\udc9d\ud91e\udf71\ud972\udd3b\ud97f\udfc2\ud88e\udefa\udba3\udf39\udac1\udf8e\ud820\udf63\ud91c\udfcc\ud8db\ude94\ud80f\ude5b\ud9eb\ude48\udbdb\udf33\udbde\udf94\udb14\udce1\ud87b\udf41\uda1b\udd3c\udab9\udd7e\u208a\udbf4\udf45\ud80f\udcfd\ud8bf\udcf6\ud878\ude99\udabe\ude7e\ud95f\udcc9\ud9f2\udf96\ud89b\ude16\ud8f1\udeb7\ud8c0\udd0f\ud9d3\udfe5\udb86\udda8\udb04\udd6b\ud9e4\ude30\udb14\uddaf\udb7c\udf07\ud85b\ude80\ud881\udfe2\ud892\udcf3\uda18\uddc1\u0893\ud938\udcc2\ud8a0\uded0\uda97\udcdf\ud94b\udef7\uda90\udcbe\ud8fa\udf40\ud973\uddbe\udaff\udf8a\udb2f\udc58\udba1\ude98\uda1e\udcf7\ud943\udfc8\udbc7\ude01",
        55, 91015, -1874762474, -3964393724225221070L, 15205L, false, true, (char) 4773, (char) 36659,
        Double.longBitsToDouble(0x3fee359cbee2366dL), Double.longBitsToDouble(0x3fd46c6f08a4e5e6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud840\ude85\udabf\udd16\ud87b\udfc5\ud8e6\udfdc\ud875\udf6e\ud9c3\udcde\ud8e4\udf87\ud9b9\ude07\udaaf\udcd7\uda0b\udf06\udbfb\ude48\ud889\udcca\ud802\ude9c\ud87c\udf0a\ud8d7\udccd\ud877\udcdb\ud94d\ude36\ud8a2\udc8c\udbb5\udc83\ud8f8\uddac\ud808\udf61\ud9b3\udef0\ud84e\udcf6\udab1\udd72\udafc\udc50\uda11\udc3e\udbdc\ude34\ud8e9\udc15\ud9de\udc42", "\u8e03\u7e8e\ucc63\u05f9\u8b8e\u9b9d\u9760\u5988", "\ud813\udc86\udbe7\ude74\ud99b\udff1\ud97b\udfa7\udb8c\uddd0\uda1c\udc05\ud8a2\udc6f\ud9c9\udf91\ud96c\udcf6\ud833\udf96\udb22\udea5\udaa5\udf9f\udb58\ude5a\ud939\udf72\u639b\ud989\udd72\ud8f4\udc3c\ud9d4\udf8e\ud945\udd23\udad2\udf34\uda8d\udda4\ud985\udcfd\udb15\udcee\uda1c\udf59\ud943\udf9c\ue51f\uda83\udc4b\udb79\udd13\udaa7\udde0\ud8dc\udc3e\ud9b8\udf28\udae0\udd22\ud87b\udc08\udb70\udff2\udaf5\udc86\udb42\udd74\ud805\udc37\ud8a4\udda0\ud977\udf3d\ud919\udd66\udbd9\udd56\ud894\udff6\uda3b\ude9a\ud926\udd4f\udbf5\udc34\ud816\udf13\udaab\udf70\ud91a\ude5a\ud8d9\udc4d\ud8fb\udc77\ud91e\udf71\ud972\udd3b\uda3b\udfe0\u08b1\udba3\udf39\udac1\udf8e\udb31\udc0a\uda0f\udcd6\ud8db\ude94\ud80f\ude5b\ud9eb\ude48\udbdb\udf33\udbde\udf94\udb14\udce1\ud87b\udf41\uda1b\udd3c\ud98f\ude28\ud9a5\udfb9\udbd4\udfd2\ud80f\udcfd\ud8bf\udcf6\uda60\udf8d\ud90c\udea4\ud806\ude7f\ud9f2\udf96\ud89b\ude16\ud8f1\udeb7\ud8c0\udd0f\ud9d3\udfe5\uda45\udca8\udaf5\udc9c\ud9e4\ude30\udb14\uddaf\udb7c\udf07\ud85b\ude80\ud881\udfe2\ud892\udcf3\uda18\uddc1\u0893\ud938\udcc2\ud8a0\uded0\uda97\udcdf\ud94b\udef7\uda99\uddbe\ud8fa\udf40\ud973\uddbe\ud843\ude6c\ud9ea\udd19\udba1\ude98\uda1e\udcf7\ud943\udf2d\udbc7\ude01",
        55, 91015, -1874762474, -3964393724225221070L, 15205L, false, true, (char) 49061, (char) 24961,
        Double.longBitsToDouble(0x3fe3f59cbee23621L), Double.longBitsToDouble(0x3fbcf1bc22939768L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.NumericEntityUnescaper:",
    "C|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|<init>|",
    "M|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.NumericEntityUnescaper:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
