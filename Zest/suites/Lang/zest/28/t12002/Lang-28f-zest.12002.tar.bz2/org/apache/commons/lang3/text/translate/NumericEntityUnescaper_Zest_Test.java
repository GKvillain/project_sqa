package org.apache.commons.lang3.text.translate;
import org.junit.Test;
import static org.junit.Assert.*;
public class NumericEntityUnescaper_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\udac3\udd5a\udad2\udea3\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u98b4\u1046\ua4f7\u79bc\u4a97\ucf34\u84b0\u7cd5\uaca8\ub97f\ua640\u31ae\ub5db\u6b27\u7ac8\u9e48\u5929", "\ud909\udf69\udb3c\udd65\u853a\ud851\ude8b\ud958\udec3\ud836\udfbb\ud9ec\udce7\udbe4\ude23\u536b\udb76\ude31\ud948\udd89\uda9b\udcfe\ud887\udc24\ud960\udd5c\ud871\udc7b\ud9d7\udde8\udb15\udd5b\uda4f\udd76\uda07\udfb9",
        44, 81100, 344312287, 1256378785877250729L, 38515L, true, false, (char) 28446, (char) 61328,
        Double.longBitsToDouble(0x3fd95b9ac7af6106L), Double.longBitsToDouble(0x3fe018aae4bfa43dL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\ud928\ude16\udabd\udf8b\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\udb63\uddaa\udb62\udf20\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u98b4\u1046\ua4f7\u3c1c\uab3e\ucf34\u84b0\ub13f\u76ee\u8518\ua640\u31ae\ub666\u6b27\u7ac8\u9e48\u5929", "\ud909\udf69\udb3c\udd65\u853a\ud851\ude8b\ud958\udec3\ud836\udfbb\ud9ec\udce7\udbe4\ude23\u536b\udb76\ude31\ud948\udd89\uda9b\udcfe\ud86e\udce2\ud960\udd5c\ud871\udc7b\ud9d7\udde8",
        5, 83606, 2002309145, -6009538732679782116L, 53072L, true, false, (char) 32142, (char) 41539,
        Double.longBitsToDouble(0x3fe326a96195b9acL), Double.longBitsToDouble(0x3feebd841e03155cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\udbb5\udd07\ub27e\uda76\udd78\udb66\uddef\uda90\udf2f\ud8e8\udcbe", "\u776e\u8c3c", "\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda0a\udd35\ud948\udea7\udb55\udf60\ud853\udda3\ud9ea\ude90\uda33\ude31\udab5\ude6f\udb65\uddd8\ud995\udf19\udb9a\udf31\udaa5\udd94\ud8fe\udc34\ud868\udf1e\ud920\ude61\ud86c\udf98\udbd4\udce7\uda8e\udfb7\udb5a\udc54\u325a\udbb1\udee8\uda73\uddfb\ud99d\udfcc\udb5c\udfe8\ud810\uddfd\ud891\udf33\ud9fe\udde7\ud974\uddb0",
        22, 98615, -1688311980, 8387284006722027947L, -44305L, false, true, (char) 52094, (char) 45738,
        Double.longBitsToDouble(0x3fd2ea8b4a2ce358L), Double.longBitsToDouble(0x3fee5f03cabc5825L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\udac3\udd5a\udae6\udda3\ud89b\udf87\udb1f\udc1e\uda3c\udd60\udabc\udd3e\ud8bb\udc9c\ud9fe\ude1f\uda17\udc24\uda49\udf96\uda43\udc38\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u76a6\u1067\u59a0\u7609\u4a97\ucf34\u84b0\u1999\u8d00\u3b62\ua640\u31ae\ub5db\u6b27\u7ac8\u9e48\u5929", "\ud8e8\ude98\udb3c\udd65\u853a\ud878\udfe0\uda26\ude1b\udbc6\udebb\ud9ec\udce7",
        24, 51376, 991769981, 1525348183432284107L, -91337L, false, false, (char) 61310, (char) 63781,
        Double.longBitsToDouble(0x3fd6ed57f16266ecL), Double.longBitsToDouble(0x3fb75dd608e564c8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udb6a\ude5b", "\u329e\u826d", "\udb2f\udc73\udab0\udc5d\ucf5d",
        21, 99918, 60664274, -2852862980782084627L, 18955L, false, true, (char) 31516, (char) 47537,
        Double.longBitsToDouble(0x3fe9c5f9219d7828L), Double.longBitsToDouble(0x3fdc516a2145e6beL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 1, "\udbb5\udd07\ua57e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\ud8e3\ude6a\udad2\uddb5\ud89b\udf87\uda70\udcc6\000\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\u00fb", "\u227a\u98b4\u1046\ua4f7\u79bc\u4a97\ucf34\u84b0\u7cd5\uaca8\ub97f\ua640\u31ae\ub5db\u6b27\u7ac8\u9e48\u5929", "\ud909\udf69\udb3c\udd65\u853a\ud851\ude8b\ud958\udec3\ud836\udfbb\ud9ec\udce7\udbe4\ude23\000\udb69\udcb4\ud948\udd89\uda9b\udcfe\ud887\udc24\ud960\udd5c\ud871\udc7b\ud9d7\udde8\udb15\udd5b\uda4f\udd76\uda07\udfb9",
        44, 81100, 344312287, 1256378785877250729L, -85598L, false, false, (char) 31553, (char) 29786,
        Double.longBitsToDouble(0x3f155c8000000000L), Double.longBitsToDouble(0x3fade5a6890e0de0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\uda86\uddaa\ub27e", "\uaa77\u8ec0\u7279\u9834\u18e8\ud153\u32d3\u5de9\u1ba3\ud562", "\uda43\udc38\ud948\udea7\udb55\udf60\ud964\ude29\ud973\udfcf",
        7, 50285, 1674002594, -776618328719514312L, 37549L, true, false, (char) 37323, (char) 21940,
        Double.longBitsToDouble(0x3feb22953c2db378L), Double.longBitsToDouble(0x3fe84a2068dcd31fL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 1, 1, "\udb86\udd50\ub24f\udb76\ude53\udad4\udc01\ud980\udf40\udb24\udd00\ud8b7\udd17\udad2\udea3\u0ddd\udb1f\udc1e", "\uc389\ua19a\ubb24\uc324\u650a\u8f34\uae4e\u0557\u0972\u35cb\uaa8c\ub09f\u54cb\u2800\u0ffb\u5144\u42b2\u4a97\ucf34\u80af\u7cd5\ubebb\u5169\u41cf\u31ae\u57c5\u4290\u7ac8\u9e48\u5929\u78f6", "\udb7b\udff5",
        19, 2591, -2102494682, 4585737523921191682L, -67088L, true, true, (char) 59495, (char) 56565,
        Double.longBitsToDouble(0x3fdd2f845c4cd7baL), Double.longBitsToDouble(0x3fe2a383f65f6868L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\udac3\udd5a\udad2\uddb5\ud89b\udf87\uda70\udcc6\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\u38ed\000\uda42\udf3a\ud948\udea7\udb55\udf60\ud853\udda3\ud96a\udfd3\ud9d8\udf50", "\u227a", "\ud8fe\udc34\ud88d\ude11\ud827\udc03\u253f\ud9ba\ude7d\udac2\udc2f\udb5a\udc54\u325a\uda50\udf79\000\ud98f\udde2",
        41, 93322, -1467101715, 6989197616750584461L, 50863L, false, true, (char) 14780, (char) 46608,
        Double.longBitsToDouble(0x3fe13657dffb82aeL), Double.longBitsToDouble(0x3fe811fd1f30dc4eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 0, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\udac3\udd5a\udad2\udea3\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\ud8ff\udf43", "\u227a\u98b4\u1046\ua4f7\u79bc\u4a97\ucf34\u84b0\u7cd5\uaca8\ub97f\ua640\u31ae\ub5db\u6b27\u7ac8\u1f2d\u9927\u8adc\ua350\u0799\u280f\u4852\u6ad4\ua59e\u2368\u28b4\ua293\u8119\u6b40\ua960\ub868\ua2fd\uce87\u64bc\u8305\u2d7d", "\udb1f\udf72\udb17\ude33",
        7, 26467, 1670173353, -4591888280718023955L, -85598L, false, false, (char) 31553, (char) 29786,
        Double.longBitsToDouble(0x3fe018aae4bf8897L), Double.longBitsToDouble(0x3fe14ecaab82ebc0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\udac3\udd5a\udad2\udea3\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\ud8b1\ude5d", "\ucfef\u98b4\u1046\ua4f7\u79bc", "\ud9ba\udee1\udac2\udc2f",
        20, 96152, -1150314620, -232210807161855672L, 53454L, true, true, (char) 18113, (char) 17291,
        Double.longBitsToDouble(0x3fdd2bb6ca9ee804L), Double.longBitsToDouble(0x3feaa11d765e9b5eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 1, 1, 1, 1, "\u71c8\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud9bc\udf85\udad4\udccc\ud882\udf7b\ud89f\uddee\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud9f8\udf9d\uda64\udfb1\udadb\uddd7\uda3e\udc58\uda43\udc38\ud948\udea7\udb55\udf60\ud9ee\ude70\u4d3b\ud92a\udf6a", "\u6e71\ucc02\u1046\ua4f7\u79bc\u4a97\ucf34\uac6b\u2090\uaca8\ub97f\u5983\ub64d\ud7d3\u3ff3\u3949\ub6c8\u9073\ud3d5\ua350\u0799\u280f\u4852\u6ad4\ua59e\u5ba3\u28b4\ua293\u8119\u6b40\ua960", "\ud960\udd5c",
        43, 14783, -713072675, 4931988522305900721L, -75708L, true, true, (char) 41565, (char) 58391,
        Double.longBitsToDouble(0x3fdf0638c5db808cL), Double.longBitsToDouble(0x3fba40e14211b6e0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\udb22\udcb6\ud978\ude9b\udad2\udea3\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u98b4\u1046\ua4f7\u79bc\u4a97\ucf34\u84b0\u7cd5\uaca8\ub97f\ua640\u31ae\ub5db\u6b27\u7ac8\u9e48\u3974", "\ud97c\ude78\ud8d8\udfa0\u853a\ud851\ude8b\ud958\udec3\ud836\udfbb\ud9ec\udce7\udbe4\ude23\u536b\udb76\ude31\ud948\udd89\uda9b\udcfe\ud887\udc24\ud960\udd5c\ud871\udc7b\ud9d7\udde8\udb15\udd5b\uda4f\udd76\uda07\udfb9\udb1f\udfdb\udb17\ude33\uda5e\udf14\uc6e0\udb72\udc86\uda52\ude2e\ud864\udf22\uda90\udfa4\udb81\uddbb\udbfb\ude3e\udb51\udce5",
        13, 61939, -891206465, 6526090555136489736L, -8902L, true, false, (char) 4007, (char) 60212,
        Double.longBitsToDouble(0x3fdfc9a5156bab46L), Double.longBitsToDouble(0x3fc9c4699a1c30c4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbb5\udd07\uda98\ude73\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\udac3\udd5a\udad2\udea3\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u98b4\u1046\ua4f7\u79bc\u4a97\ucf34\u84b0\u7cd5\uaca8\ub97f\ua640\u31ae\ub5db\u6b27\u41cc\ub741\u0849", "\ud909\udf69\udb3c\udd65\u853a\ud851\ude8b\ud958\udec3\ud836\udfbb\ud9ec\udce7\udbe4\ude23\u536b\udb76\ude31\ud948\udd89\uda9b\udcfe\ud887\udc24\ud960\udd5c\ud871\udc7b\ud9d7\udde8\udb15\udd5b\uda4f\udd76\uda07\udfb9\udb1f\udf72\udb17\ude33\uda5e\udf14\uc6e0\udb72\udc86\uda52\ude2e\ud864\udf22",
        -2, 91698, -1179903388, -5751215973560695849L, -86724L, true, false, (char) 34963, (char) 23950,
        Double.longBitsToDouble(0x3fcf08018a702850L), Double.longBitsToDouble(0x3fa6b3a74a07b4d0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4", "\u6979\u81c7", "\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38",
        43, 87288, 509473753, -5247236595401969157L, -51010L, true, false, (char) 33691, (char) 6681,
        Double.longBitsToDouble(0x3fe59f4858631989L), Double.longBitsToDouble(0x3fd28d8a3aba60eaL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 0, "\uda98\udf7b\ub265\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\udac3\udd5a\udad2\udea3", "\u73f9\uc42c\u3339\ua19a\ubb24\uc324\u650a", "\ud853\udda3\ud96f\uddd3\ud9d8\udf50\ud9e2\udd06\ud915\ude83\uae72\ud9e1\udd60\udaa8\ude20\ud8fe\udc34\ud88d\ude11\ud827\udc03\udbc8\ude1d\ud9ba\udee1\udac2\udc2f",
        20, 96152, -1150314620, -232210807161855672L, 53454L, true, true, (char) 18113, (char) 17291,
        Double.longBitsToDouble(0x3fdd2bb6ca9ee804L), Double.longBitsToDouble(0x3feaa11d765e9b5eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\ud928\ude16\udabd\udf8b\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\udb63\uddaa\udb62\udf20\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u98b4\u1046\ua4f7\u3c1c\000\ub92f\u84b0\ub13f\u76ee\u8518\ua640\u31ae\ub666\u6b27\u7ac8\u9e48\u5929", "\ud909\udf69\udb3c\udd65\u853a\ud851\ude8b\ud958\udec3\ud836\udfbb\ud9ec\udce7\udbe4\ude23\u536b\udb76\ude31\ud948\udd89\uda9b\udcfe\ud86e\udce2\ud960\udd5c\ud871\udc7b\ud9d7\udde8",
        5, 83606, 2002309145, 233495069434140L, 53072L, true, false, (char) 32142, (char) 41539,
        Double.longBitsToDouble(0x3fe326a96195b9acL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 1, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\ud928\ude16\udabd\udf8b\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\uda3e\udc58\uda43\udc38\udb63\uddaa\udb62\udf20\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u98b4\u1046\ua4f7\u3c1c\uab3e\ucf34\u84b0\ub13f\u76ee\u8518\ua640\u31ae\ub666\u6b27\u7ac8\u9e48\u5929", "\ud909\udf69\udb3c\udd65\u853a\ud851\ude8b\ud958\udec3\ud836\udfbb\ud9ec\udce7\udbe4\ude23\u536b\udb76\ude31\ud948\udd89\uda9b\udcfe\ud86e\udce2\ud960\udd5c\ud871\udc7b\ud9d7\udde8",
        5, 83606, 0, 0L, 53072L, true, false, (char) 32142, (char) 41539,
        Double.longBitsToDouble(0x3fe326a96195b9acL), Double.longBitsToDouble(0x3feebd841e03155cL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udbb5\udd07\ud8cf\udedb\ud83b\ude5d\u65ce\udb2c\udd3d\udbed\udf8e\udb8f\udf9e\udb1d\udfea\uda25\udccb\ud87a\udf8b\ud9ea\udcc5\udb88\udd36\udabe\udfbe\uda64\udf62\udae3\udfd7\uda3e\udc58\uda43\udc38\udb63\uddaa\udb62\udf20\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u98b4\u1046\ua4f7\u3c1c\uab3e\ucf34\u84b0\ub13f\u76ee\u8518\ua640\u31ae\ub666\u6b27\u7ac8\u9e48\uafae", "\ud909\udf69\udb3c\udd65\u853a\udbc0\udd22\ud958\udec3\ud836\udfbb\ud9ec\udd12\udbe4\ude23\udb6f\udfd7\udb76\ude44\ud948\udd89\uda9b\udcfe\ud86e\udce2\ud960\udd5c\uda27\udef8\uda8c\udf3e\udb15\udd5b\ud907\udf32\uda07\udf21\udb1f\udf72\udb17\ude33\uda5e\udf14\uc6e0\udb72\udc86\uda52\ude2e\u599c\udba8\ude06\udba3\udf6d\udbfb\ude3e\udb51\udce5\ud8f7\udd19\uda9f\ude65\ud98b\udcfb\ud989\udcef\ud8e9\uddb7\udbce\uddff\ud931\udf64\uda22\udef0\ud91d\udecf\uda62\udd2b\uda58\udfdc\u7006\udb00\ude03\ud860\udeac\ud958\udcf8\uda70\udd3b\ud816\udc8d\ud9e8\udeab\udb96\udf78\udac8\udc50\ud9aa\udccf\ud810\udea1\uda47\udc2b",
        40, 49049, -1201055312, 3504913761703887481L, -47986L, true, true, (char) 6401, (char) 30096,
        Double.longBitsToDouble(0x3fee4eaa9d713696L), Double.longBitsToDouble(0x3fd736260bdd316cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 1, "\udb6a\udd73", "\ubd55\u826d", "\udb2f\udc73",
        48, -989, 0, 0L, -46221L, false, true, (char) 6575, (char) 194,
        Double.longBitsToDouble(0x3e25f00000000000L), Double.longBitsToDouble(0x3fe9c5f9219d0028L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 0, 0, 1, "\udbb5\udc94\udbc7\udf4d\udb76\ude93\udbb0\ude2f\ud908\udf52\ud929\uddae\ud8d3\uddae\udb33\udd57\ud872\uddd7\uda70\udcc6\udb2a\udec7\udabc\udf78\ud8bb\udc9c\uda64\udfb1\udb52\udcd7\uda3e\udc58\udbbe\udd76\ud94b\udd5f\udb55\udf60\ud853\udda3\ud96f\uddd3\u00fb", "\u227a\u98b4\u1046\ua4f7\u79bc\u4a97\ucf34\u84b0\u7cd5\uaca8\ub97f\ua640\u31ae\ub667\u6b27\u2bab\u1bea\ub0fc\ua723\u9222\u53b6\u6614\u6b04\u411b\ua59e\u2368\u28b4\ua293\000\u35c3\ua960\ub868\ua2fd\uce87\uaa12\u850f\u2d7d\u1a8d\ua123\u8984\ua6a4\ub231\u3283\ua8a5\uca68\u0aee\u696e\u2ade\u8f09\u7e56\u8514\000\u958a\u9cc8\ub54a\u5b08\u06a1", "\udb86\udf35\ud877\udff4\ud932\udcc3\ud8d1\udd85\udbb6\udf44\udbb5\ude0a\ud8db\udcf6\udb1b\ude78\uda60\udeea\ud852\ude83\ud963\ude3a\ud8ca\uddef\ud892\udd0c\udbe2\udf33\udaab\udd3c\udb93\udeea\udb8e\udc2f\ud891\uddcb\udaac\udc02\uda20\udc61\ud9f0\udec5\ud9be\udc0b\ud96d\udccb",
        20, 40172, -1120118671, -6523520918599427713L, -40572L, false, true, (char) 5854, (char) 11105,
        Double.longBitsToDouble(0x3fd6d08dd8630f88L), Double.longBitsToDouble(0x3fe4ad136314f1bfL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 1, "\udbb5\udd07\u00aa", "", "",
        -5, 85656, 57431, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc51d600f67a940L), Double.longBitsToDouble(0x3f1e5d1f76e00000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 1, "", "\uaecc\u8b55\u826d\u91ab\u6979", "\000",
        -5, -1000, 575191703, 4984622349476182253L, 43104L, false, true, (char) 31659, (char) 56873,
        Double.longBitsToDouble(0x3f9e1e5d1f76e5c0L), Double.longBitsToDouble(0x3fdc516a200000beL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=java.lang.Integer:0 |a2=java.io.StringWriter: |this=org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\012",
        Z.run(T, 2, 1, 0, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\ud8a2\udfb0\udad2\udea3\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\u8e30\uda3d\udfc7\ud904\udfda\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\ud8ff\udf43", "\u6a4f\u98b4\u1046\ua4f7\u79bc\u4a97\ucf34\u84b0\u7cd5\uaca8\ub97f\ua640\u31ae\ub5db\u3af0\u9cf3\u1f2d\u9927\u8adc\ua350\u0799\u280f\u378d\u6ad4\ua59e\u2368\u28b4\u3c3b\u80cb\u6b40\ua960\u011d\ua2fd\uce87\u64bc\u8305\u2d7d", "\udbe2\udfd2\udb17\udedd",
        7, 26467, 1670173353, -4591888280718023955L, -96897L, false, true, (char) 62754, (char) 42274,
        Double.longBitsToDouble(0x3fe1a4316f58d423L), Double.longBitsToDouble(0x3fb65b1598c80378L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 1, "\udb57\udcf8", "", "",
        -5, -1000, 202086656, 373662154752L, -100000L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e151d6000000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 1, 1, "\udbb5\udd07\ub27e\udb76\ude53\u60e4\udb2c\udd3d\ud872\udc31\udab6\udc43\udad2\udea3\ud89b\udf87\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\uda64\udfb1\udae3\udfd7\udbda\udcc5\udb61\udec1\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\ud9d8\udf50", "\u227a\u98b4\u1046\ua4f7\u79bc\u4a97\ucf34\u84b0\u7cd5\uaca8\ub97f\ua640\u31ae\u1fa2\u6b27\u7ac8\u9e48\u5929", "\ud909\udf69\udb3c\udd65\uda3e\udc28\udbb0\udc2a\ud958\udec3\ud836\udfbb\ud9ec\udce7\udbe4\ude23\u536b\udb76\ude31\ud964\udfc5\uda9b\udcfe\ud887\udc24\ud960\udd5c\ud871\udc7b\ud9d7\udde8\udb15\udd5b\uda4f\udd76\uda07\udfb9",
        44, 81100, 344312287, 1256378785877250729L, 38515L, true, false, (char) 28446, (char) 61328,
        Double.longBitsToDouble(0x3fd95d0ac7af6106L), Double.longBitsToDouble(0x3fe018aae4bfa43dL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.text.translate.NumericEntityUnescaper:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 0, "\udbb5\udd07\ub27e\udb76\ude53\ud8ad\udc6d\udbcf\uddf8\udbac\udf6e\ud86f\udf6b\ua17f\ud894\udf6a\udb1f\udc1e\ud83b\udeb8\udabc\udc94\ud8bb\udc9c\udb90\udd64\uda3e\ude8d\uda45\ude6f\uda43\udc38\ud948\udea7\udb55\udf60\ud853\udda3\ud96f\uddd3\udbbc\udebd", "\ucfef\u98b4\u1046\u3292\u79bc\u4a97\u0cdc\u3642\u13d5\u8917\uc053\u140c\ua8ee\ub5db\u6b27\u7ac8\u9e48\u2d29\u7946\u313d\u0799\u280f\u1e10\u771f\u177d\ube6c\ua2c5\u1517\u194f\u7443\ubff2\u20af\u41f5\u4e76\u3f03\u9ed8\ua92c\u03b0\u00cd\ub386\u6487\u0aed\u4a03\u29f1\ua90e\u5e9b\u310f\u6e07\u458f\u1253\ua5c7\u120b\u1180\u5912\ua89b\uc1ea\u2c42\u4f3d\uc39d\uabd2\u8dee\uc249\u1000\uab19\uac01\ua59b\ua4e9\ub481\u854a\u39ca\u67c4\u0c39\u7b4f\u16ee\ua24d\ub459", "\udb80\udff9\udb6e\udddc\ud887\udcfe\ud8d8\ude36\ud87f\udd0c\ud822\udcb2\uda11\ude33\udbb4\udff3\ud81a\udf24\udbb2\udcb1\uda99\ude1d\ud983\udf23\u4e72\ud90a\udd87\u41a3\udbc7\udce4\uda29\udeee\udb12\udef3\udbd9\uddd9\ud997\udd40\ud84c\udcad\udb1a\udc81\ud9ea\udeb2\ud9d1\udee6\ud97d\udf67\udbfa\udcf8\uda9a\uded6\uda29\uddcc\uda86\udc90\uda8c\udcb7\uda96\udc9f\uda70\udfa6\ud830\udf20\udbf3\ude80\udad1\udf84\udaf0\udd9d\ud873\udec3\udb30\udd1f\udab3\udeca\udb45\udf06\ud860\udff2\ud84a\udc07\ud9d6\udcce\ud83b\udf50\uda2a\ude9c\uda7f\udf45\udbb7\udfbe\uda5b\udd2a\uda6f\udf99\ud861\ude06\ud851\udfc4\ud951\udc1a\u50a3\udb29\udd85\ud865\udf70\udb9b\udca4\ud925\udc03\udbd5\udcf9\ud8c7\ude31",
        -4, 12243, 461687545, 2172741514123496033L, -43062L, true, false, (char) 3897, (char) 63464,
        Double.longBitsToDouble(0x3fcce57e5f2cfc88L), Double.longBitsToDouble(0x3fe2e43e43bb1467L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.NumericEntityUnescaper:",
    "C|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|<init>|",
    "M|org.apache.commons.lang3.text.translate.NumericEntityUnescaper|translate|java.lang.CharSequence,int,java.io.Writer|new:org.apache.commons.lang3.text.translate.NumericEntityUnescaper:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
