package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class RandomStringUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 13, 12, "\ud98e\udc95\udb4d\udc87\ud919\udffc\ud95c\udcf3", "\u663c\uc977\u4694\u815b\u3ef9\u5afa\ua0e0\ud524\u7205\u9ec6\u3c57\u19d2\u1e9e\u6c8e\u4fe8\u91d4\u203f\u3655\u2b9f\u23fd\u042e\ua3b9\u90f4\u18f8\u5cb1\ubf68\ucdd0\uc765\uaadc\u47fc\u9c66", "\udaf4\udf71\ud9b4\udc9a\ud867\udcba\udbc0\udd93\udadd\udfe8\ud830\udfed\ud919\ude4a\ud909\udf1e\udb2b\udd0a\ud986\udfc5\udbbd\udefc\uda8a\udc48\ud86b\ude6e\ud945\udf04\udbab\uddcd",
        25, 68434, 1012974582, -8968547746264721914L, -46788L, true, false, (char) 64192, (char) 23681,
        Double.longBitsToDouble(0x3fd6d8253c4c42d0L), Double.longBitsToDouble(0x3fc2684517b00ba8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 4, 13, 12, "\ud9a2\udedc\udb4d\udc5e\ud919\udffc\ud95c\udcf3\ud9f0\ude84\ud8cb\udf8e\ud9dd\udc61\ud89e\udc3f\ud8c3\ude87\ud94f\ude9b\ud97f\udc36\ud870\udf8d\uda69\udd8d\ud916\udd52\ud8da\udce2\ud8f1\udeca", "\u1e9e\u6c8e\u4fe8\u91d4", "\ud9c8\udf0b\udaab\udd00\ud93b\udda7\ud8a6\udc99\ud9ae\ude56\ud86c\udeb4\u6283\udbcb\ude89\ud8f2\udc59\ud8f2\udc74\udbda\udd0d\ud80e\udc55\ud832\ude8f",
        20, 23689, 983902205, -9024967378303137951L, -47840L, false, true, (char) 19144, (char) 62156,
        Double.longBitsToDouble(0x3fc1bd6466c530d8L), Double.longBitsToDouble(0x3fe6391a56fa4773L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 13, 2, "\ud98e\udd3a\udb4d\udc87\ud919\udffc\ud95c\udcf3\udba3\udc1e\udb3e\udc29\udb2e\udc40\udb04\udc5f\ud8c3\ude87\udb73\udfb1\uda11\udfc4\ud99d\udf24", "\u1a51\ua737\u8372", "\udb0a\udef9\ud9d5\udcdd\ud9b8\udd00\ud9a4\udd86",
        14, 54152, -727206612, 6559484533903429529L, 31693L, true, false, (char) 2230, (char) 51203,
        Double.longBitsToDouble(0x3fe2c30c1ed26902L), Double.longBitsToDouble(0x3fed9cf14929c6feL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 13, 12, "\ud98e\udc95\udb4d\udc87\ud919\udffc\ud95c\udcf3", "\u663c\uc977\u4694\u815b\u3ef9\u5afa\ua0e0\ud524\u7205\u00de\u3c57\u19d2\u1e9e\ub0b4\u4fe8\u91d4\u203f\u3655\u2b9f\u23fd\u042e\u20c3\000\u18f8\u5cb1\ubf68\ucdd0\uc765\uaadc\u47fc\u9c66", "\udaf4\udf71\ud9b4\udc9a\ud867\udcba\udbc0\udd93\udadd\udfe8\ud830\udfed\ud919\ude4a\ud909\udf1e\udb2b\udd0a\ud986\udfc5\udbbd\udefc\uda8a\udc48\ud86b\ude6e\000",
        9, 86220, -1678550566, 4350692699281117528L, -10418L, false, true, (char) 16645, (char) 64192,
        Double.longBitsToDouble(0x3fc518fb25b6094cL), Double.longBitsToDouble(0x3fe1310b40934228L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 13, 12, "\ud98e\udc95\udb4d\udc87\ud919\udffc\ud818\udc11", "\u663c\uc977\u4694\u815b\u3ef9\u5afa\ua0e0\ud524\u7205\u9ec6\u3c57\u19d2\u1f01\u6c8e\u4fe8\u91d4\u203f\u3655\u2b9f\u23fd\u042e", "\ud86c\udeb4\u6283\udbcb\ude89",
        13, 88485, -1641443630, -4116813758603683543L, 60799L, true, true, (char) 6817, (char) 18977,
        Double.longBitsToDouble(0x3fe15ad60440b21cL), Double.longBitsToDouble(0x3fedfdb2be9e4c2aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.lang3.RandomStringUtils:@?\012",
        Z.run(T, 1, 11, 13, 12, "\ud98e\udc95\udb4d\udc87\ud919\udffc\ud95c\udcf3", "\u663c\uc977\uc644\u7bef\u3ef9\u5afa\ua0e0\u2f38\u7205\u9ec6\u3c57\u19d2\u1e9e\u6c8e\u4fe8\u91d4\u203f\u8452\u7922\u23fd\u042e\ua3b9\uc38a\u18f8\u5cb1\ubf68\ucdd0\uc765\uaadc\u47fc\u9c66", "\udaf4\udf71\ud9b4\udc9a\ud867\udcba\udbc0\udd93\udadd\udfe8\ud830\udfed\ud919\ude4a\ud909\udf1e\udb2b\udd0a\ud986\udfc5\udbbd\udefc\uda8a\udc48\ud86b\ude6e\ud945\udf04\udbab\uddcd",
        25, 68434, 1012974411, -8968547746264721914L, -46788L, true, false, (char) 64192, (char) 23681,
        Double.longBitsToDouble(0x3fd6d8253c4c42d0L), Double.longBitsToDouble(0x3fc2684517b00ba8L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 13, 0, "\ud98e\udc95\udb4d\udc87\ud919\udffc\ud95c\udcf3", "\u663c\uc977\u4694\u815b\u3ef9\u5afa\ua0e0\ud524\u7205\u9ec6\u3c57\u62a1\u1e9e\u6c8e\u4fe8\u91d4\u0e2c\u7d2f\u59f1\u24a9\u040f\ua3b9\u90f4\u18f8\u5cb1\ubf68\u9bc8\u5923\u402b\u4779\u9ccf", "\udaf4\udf71\ud9b4\udc9a\ud867\udcba\udbc0\udd93\udadd\udfe8\ud830\udfed",
        -4, -199, 1278654605, -555506597804948793L, -13640L, false, false, (char) 15060, (char) 998,
        Double.longBitsToDouble(0x3fc5248b8130c9d4L), Double.longBitsToDouble(0x3fc518fb25b6094cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 13, 12, "\ud98e\udc95\udb4d\udc87\ud919\udffc\ud96f\ude3d", "\u6621\uc977\u4694", "\ud870\udf8d\uda69\udd8d\ud916\udd52\udb23\ude03",
        46, 8692, 1826179280, 7388591792416276558L, 17279L, false, true, (char) 39827, (char) 25877,
        Double.longBitsToDouble(0x3fa64e8884a86590L), Double.longBitsToDouble(0x3feccad83fe610fbL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.RandomStringUtils|random|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,boolean,boolean|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,[C|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean,[C|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean,[C,java.util.Random|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,java.lang.String|static",
    "M|org.apache.commons.lang3.RandomStringUtils|randomAlphabetic|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|randomAlphanumeric|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|randomAscii|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|randomNumeric|int|static",
    "C|org.apache.commons.lang3.RandomStringUtils|<init>|",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,boolean,boolean|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,[C|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean,[C|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,int,int,boolean,boolean,[C,java.util.Random|static",
    "M|org.apache.commons.lang3.RandomStringUtils|random|int,java.lang.String|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
