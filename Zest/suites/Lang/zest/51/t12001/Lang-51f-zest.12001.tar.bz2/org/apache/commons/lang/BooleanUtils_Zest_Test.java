package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class BooleanUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\udae8\udd3b\udab6\ude7b\ud873\udc14\udaa0\udce8\ud924\udfa4\uf6a6\u25a2\ud9ce\udc7b\ud808\udd75\uda0a\udca9\ue5a0\ud83a\udcfe");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\udae8\udd3b\ud968\udef4\udb38\ude89\uda52\udf31\ud87f\udfed\udb4b\udff5\ud811\udd05\ud9ec\udfb8\ud808\udd75\uda0a\udca9\ue5a0\ud83a\udcfe");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\udaa4\udc56\ud8f6\ude57\uda2e\udf6e\ud889\udfaa\uda54\udcc6\udba2\udd67\ud975\udeb7\ud891\udd41\ud988\udfab\ud9fc\udcbc\udade\udcd9\ud83a\udd0d\ud88e\udcea\udb18\udcae\ud933\udc24\ud948\udea9\ud984\udc09\ud800\udc9f\ud9b3\udfa8\ud90c\udc0e\ud9de\udee2\ud9a6\udd92\udae3\uddba\ud9e5\udc95\ud833\uddc9\udb36\uddcd\ud9be\udf3e\udb8c\udf45\udb9d\udc0c\udaa7\udef2\udbac\udddf\ud8ba\udda5");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\udae8\udd3b\udab6\ude7b\ud873\udc14\udaa0\udce8\ud924\udfa4\uf6a6\u25a2\ud9ce\udc7b\ud805\udf75\uda0a\udca9\ue5a0\uda7b\ude1e\uda6d\ude25\udab5\udcd8\uda4c\ude2e\udb22\udf10\udab7\udf60");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\uda5a\udced\udb7f\udf5f\udab4\udd34");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\000\udab6\ude7b)\uda33\ude59\ud924\udfa4\uf6a6\u25a2\ud9ce\udc7bQ\000\udb6d\udd9a\ud83a\udcfe");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\udbfb\udd38\ub2b1\u336a\uda29\udfd4\uda35\udf6e\udbac\udf02");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("G");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud8ac\udfee");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\udba4\ude66\ud9c4\udfe0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\u9f80\udbe5\udee8");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\uc71f\udbe0\ude03\udbb3\udd02\ud98b\udd8a\uda9b\ude04\ud80c\udf13\udbfa\udc18\ud9ef\uded9\u689d\uda4d\uddd6\ud837\udd52\udbc4\udcee\u3887\udb5c\udfec\ud838\udee6\u93eb\udb9a\ude10\udb3f\ude98\ud96d\udde6\uda05\uddc3\udb39\udd86\ud9f1\udc5a\udadc\udf2e\uda5c\udf83\u697e\udae7\udcd7\udaa1\udc34\ud80e\udf1a\ud9ee\udc8f\udb33\udd5d\ud98c\udd67\ud91f\udef5\ud838\udc0c\u3298\uda81\uddb0\uda2c\udff7\udadb\udeb3\ud9c1\uddca\ud913\udf0d\uc299\uda8e\udcff\udaa3\udd0d\udaac\ude93\ud809\udfe4\ud902\udd54\udac0\udf30\ud832\uddd3\udb04\udd44\uda21\udd34\ud92d\udd80\ud8a0\ude7e\ud9af\udd15\ud86a\udcf9\udb9a\udf27\ud98b\udc17\udbfc\udd83\ud8cc\udfac\udba0\udd09\ud90d\ude73\ud808\udcd5\udb1b\uddd7\ud987\udf8e\ud9bc\ude73\uda2b\udd29\ud945\uddd0\udafa\uded0\udb5b\udd06\ud881\udc89\ud8b7\udd84\udb3a\ude66\udbe1\udcd2\ud893\udcc2");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\udae8\udd3b\udab6\ude7b\ud873\udc14\udaa0\udce8\uda63\udc02\u03f9\u25a2\ud9ce\udc7b\ud808\udd75\uda0a\udca9\ue5a0\ud83a\udcfe");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
