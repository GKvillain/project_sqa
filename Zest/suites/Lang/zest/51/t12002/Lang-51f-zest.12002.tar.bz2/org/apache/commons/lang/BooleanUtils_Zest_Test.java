package org.apache.commons.lang;
import org.junit.Test;
import static org.junit.Assert.*;
public class BooleanUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud9af\udce3\ud89c\udf70");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\uda44\udecc\ud89c\udf70\ud91c\udf80\ud81a\udf80\ud9e4\udc30\ud950\udf1e\udac4\udcf0\ud907\udc74\udb0e\udcab\uda77\udfc8\udb6a\udd17\udae8\udc71\ud873\udf4c\uda5e\udd9d");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud9af\udcf7\ud89c\udf70\ud96f\udf04\ud9f2\udfbe\ud804\ude9f");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud9af\udce3\ud89c\udf70\uda27\udf43\ud8a4\udfc7\udb6c\udc9a\ud90d\udfbc\ud976\udf68\ud80b\uddac\uda79\udd84\udafa\udc8b\udaf1\udd2a\ud95d\udc07\uda34\udf39\ud951\ude8a\ud968\udd63\ud9cd\udd43\ud9fb\udd63\ud8da\udfdc\udafd\udf16\ud90a\udc56\u62cb\udab5\udd7e\udb6b\udff5\ud815\udd35\ud94d\udd98\udb6c\udd7b\udbfa\udea6\udbe4\udc06");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud826\uddc0");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud8da\ude00\u15df");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("?");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud9af\udce3\ud89c\udf70\udade\udc0a\ud857\udf08\ud9aa\udf32\udb33\ude69\ud80c\udc45\uda9c\udd6b\ud86a\ude26\ud934\udfb4\ud99f\udead\ud8ba\udd2d\udb99\udfaf\u2627\udb09\udc52\udba8\udf63\udb81\ude1e\udabb\udd4f\ud856\udfeb\u399e\udb1f\udc68\ud9b3\udd54\ud8eb\udde3\udb78\udddf\udb9e\udf08\ud968\udf98\ud889\ude50\ud876\ude1e\ud94e\uddcc\ud8d7\uddc1\udb55\udf5b\ud8c3\uddb0\udbb5\udfa2\udbee\uddf7\uda08\udfbe\ud965\ude06");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud9c3\ude53\ud9b6\udc0b\ud9eb\udff4\ud983\udf33\ud937\udf9d\ud87f\udc68\ud9dd\udce2\ud906\udc37\ud858\udfca\uda24\udf35\udbc7\udcc4\udbf9\udd12\udb1e\udf5c\ud93d\udfec\uda7b\udd97\uda34\udd24\udbcf\udd61\udb62\udfae\ud9fd\uddf5\ud861\udead\ud8f1\udf73\ud888\udfaa\ud98a\udeb6\uda39\udf90\udb01\udc4f\uda27\udcec\udbf0\udf46\ud5e6\udae4\udf77\udb52\ude17\ud817\udde5\ud9a3\udde8\ud824\udf90\ud8fb\ude22\ud8fd\udccd\uda41\udf46\udb9f\udd65\udb02\ude30\ud9e5\udcd7\ud913\udd2c\ubb6a\ud850\udfb9\udbcb\udffe\ud94f\udca3\u50cd\udbad\udf99\ud94b\uddb7\ud89b\udd85\u994e\ud802\udddc\ud8c2\udd63\ud90e\udfbf\uda2b\udec2\ud81a\udc78\ud98c\ude8b\ud82a\udd4e\ud8e4\udd4d\ud83a\udc9d\udaca\udf9a\ud9aa\udd70\uda3f\udd91\udb79\uddbc\ud866\uddda\udbd2\udfdd\udbf9\udf0a\udacc\udd26\ud87a\ude82\u5ae3\udb5a\udd87\uda7e\udf73\ud993\udf23\ud8a4\udc2d\uda76\udf6c\uda3b\uddba\udb14\udeb9\ud853\udc16\uda2f\uddc5\ud811\udf5b\uc345\udba2\udeb3\udb17\ude20\udb3b\udcaa\ud81f\ude9e\ud92e\udd3e\ud8e0\udfbc\udaaf\udd88\uda90\ude6a\udb91\udc69\u2efb\ud9a5\udf32\ud86a\uddf1");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("y\uda72\udcc3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("Y\uda72\udcc3");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("t\u5efa\udad3\udc91");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud9f9\udd8c\ua7eb\ud95e\udf3e\ud8ee\udf91\ud8f9\ude24\ud93e\uded4\ud916\uddac\ud935\uddd7\ud802\udc71\ud936\udfd1\ua15e\ud819\uddd4\udac7\udfec\ud857\udc84\ud9d1\udfb0\uead7\ud99b\uddce\ud8a4\udc0d\ud8c9\udcef\uda50\udf24\udbd0\udcc7\udba6\udc26\udb2c\ude30\ud9e4\udf1a\udb23\udd72\udacf\udc74\ud901\udd3a\uda5c\udd1a\ud961\ude14\udaef\udfe6");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("T\u5efa\udad3\udc91");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("O\u5efa");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    Object r = org.apache.commons.lang.BooleanUtils.toBoolean("\ud9af\udcb4\ud89c\udf70");
    assertNotNull(r);
    assertEquals("java.lang.Boolean", r.getClass().getName());
    assertEquals("false", String.valueOf(r));
  }
}
