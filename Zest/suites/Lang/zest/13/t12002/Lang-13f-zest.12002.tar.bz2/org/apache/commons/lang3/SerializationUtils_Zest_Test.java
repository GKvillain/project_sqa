package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class SerializationUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 60, -19, -84, -110, -19, -72, -111, -19, -92, -81, -19, -80, -70, -19, -84, -85, -19, -69, -100, -19, -84, -71, -19, -73, -108, -19, -94, -109, -19, -74, -112, -19, -84, -65, -19, -65, -96, -19, -87, -128, -19, -78, -123, -19, -82, -104, -19, -71, -76, -19, -87, -68, -19, -...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 0, "\udb12\ude11\ud92f\udc3a\udb2b\udedc\udb39\uddd4\ud893\udd90\udb3f\udfe0\uda40\udc85\udb98\ude74\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u5aa5", "\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udae2\udc1b\ud8ae\udd1c",
        41, 21100, 168381404, 8306153328672249062L, 34008L, true, true, (char) 16245, (char) 18992,
        Double.longBitsToDouble(0x3feee698e4bc01e8L), Double.longBitsToDouble(0x3fb9d95d9416afe0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 60, -19, -84, -110, -19, -72, -111, -19, -92, -81, -19, -80, -70, -19, -84, -85, -19, -69, -100, -19, -84, -71, -19, -73, -108, -19, -94, -109, -19, -74, -112, -19, -84, -65, -19, -65, -96, -19, -87, -128, -19, -78, -123, -19, -82, -104, -19, -71, -76, -19, -87, -68, -19, -...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 0, "\udb12\ude11\ud92f\udc3a\udb2b\udedc\udb39\uddd4\ud893\udd90\udb3f\udfe0\uda40\udc85\udb98\ude74\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u5aa5", "\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udae2\udc1b\ud8ae\udd1c",
        41, 21100, 168381404, 5207676785827623267L, 33493L, false, false, (char) 6905, (char) 40611,
        Double.longBitsToDouble(0x3fb9d95d9416afe0L), Double.longBitsToDouble(0x3fd5b9045e95bd0cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 2, "\uda60\udc98\uda83\udec8\ud8d3\udffe\udb39\udd9c\ud893\udd90\udb3f\udfe0\uda40\udc85\udb98\ude74", "\u58fb\u9bee\u983e\u7d1d\u5aa5\u9908\u72bc\u61ef\u4eb6\u2c76\u3890\uc469\u394e\u6967\u10ca\ud362\ubdac\u16a6\u89c8\u6954", "\udb59\udfcf\udbce\udc6c\udb8f\udd3d\udaa7\udea1\udad1\udc7b\ud909\udc01\udba0\ude98",
        53, 90271, -837858686, 3084991639344008479L, 5950L, true, true, (char) 22749, (char) 32910,
        Double.longBitsToDouble(0x3fc7a14984b46080L), Double.longBitsToDouble(0x3fee3ffb0d359714L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 0, "\udb12\ude11\ud92f\udc3a\ud9f5\uddab\udb39\uddd4\ud9c5\udd89\udb3f\udfe0\uda40\udc85\udb98\ude74\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u5aa5", "\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udae2\udc1b",
        -2, 62971, -644155900, 723192625368490610L, -17872L, false, true, (char) 16777, (char) 50395,
        Double.longBitsToDouble(0x3fb3a901cd169118L), Double.longBitsToDouble(0x3f9db1990cecaec0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 60, -19, -84, -112, -19, -69, -106, -19, -92, -82, -19, -65, -80, -19, -96, -79, -19, -66, -65, -19, -84, -72, -19, -78, -75, -19, -94, -109, -19, -74, -112, -19, -84, -65, -19, -65, -96, -19, -81, -102, -19, -67, -114, -19, -86, -123, -19, -79, -114, -19, -87, -68, -19, -6...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 3, "\udb10\uded6\ud92e\udff0\ud831\udfbf\udb38\udcb5\ud893\udd90\udb3f\udfe0\udbda\udf4e\uda85\udc4e\uda7c\udf15\udbe4\udf37", "\ua29b", "\ud9a3\udd19\ud8df\udcf9\udae7\udcf5",
        58, 1644, -1920598304, -5052702616762598153L, 66290L, true, true, (char) 23352, (char) 46727,
        Double.longBitsToDouble(0x3fb13c14e2ebcd20L), Double.longBitsToDouble(0x3feee6cf3a720a09L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 0, "\udb12\ude11\ud92f\udc3a\udb2b\udedc\udbe9\udeab\ud893\udd75\ud804\udf71\uda95\udf3f\ud85b\udd02\udaa6\udfae\udbc0\udea5", "\u983e\u7d1d\u5aa5", "\ud8d3\udfbc\udac9\uddfc",
        37, 83251, -1504313118, -8798963727723729779L, 64173L, false, false, (char) 46727, (char) 63648,
        Double.longBitsToDouble(0x3fe02200f79e429aL), Double.longBitsToDouble(0x3feecf6f28ad80d7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 6, -19, -84, -110, -19, -72, -111]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 0, "\udb12\ude11", "\u78a5\ud6a9\ua1ed\000\000]\000\000\u4085\u973f\u7d1d\u5aa5\u55ce\u72bc\u61ef\u4eb6\u2c76\u3890\uc469\u2c62\ud3ee", "\udae2\udc1b",
        -4, 62971, -644155900, 946826706944L, -17872L, false, true, (char) 16777, (char) 16245,
        Double.longBitsToDouble(0x3fe000077000d31cL), Double.longBitsToDouble(0x3d0d800000000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 1, 1, 0, "\udb12\ude11\ud8ad\udf4a\udb2b\udedc\ud802\udd51\ud829\udcc2\udb27\udefa\uda40\udc85\ud814\udc13\uda83\udef2\udbc0\udf06", "\u983e\u1036\u5aa5", "\ud846\udff1\udb94\uddc9\ud919\udc6a\udb17\ude3e\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udae2\udc1b\ud8ae\udd1c",
        3, 15829, 168381404, 8306153328672249062L, 34008L, true, true, (char) 16245, (char) 18992,
        Double.longBitsToDouble(0x3fd5dfe563e4b05cL), Double.longBitsToDouble(0x3fb03c35d416afe0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 117, -19, -86, -84, -19, -68, -76, -19, -91, -115, -19, -71, -97, -19, -84, -85, -19, -69, -100, -19, -84, -71, -19, -73, -108, -19, -94, -109, -19, -74, -112, -19, -84, -65, -19, -65, -96, -19, -87, -128, -19, -78, -123, -27, -78, -108, -19, -87, -68, -19, -68, -107, -19, ...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 0, "\udaac\udf34\ud94d\ude5f\udb2b\udedc\udb39\uddd4\ud893\udd90\udb3f\udfe0\uda40\udc85\u5c94\uda7c\udf15\udbd1\udded\uda68\udcdc\udadd\ude1e\ud8ce\udda1\uda49\udd14\uda9d\udf44\uda42\udd88\ud9c1\udef9\ud8f0\ude87\uda60\udc4d\ud975\udc32", "\u2c62\ud3ee", "\udbe8\udc61\udbb7\udfa9\ud916\udf7a\udaf6\udfc0\ud983\udc73\ud847\udc88\ud836\ude1f\ud956\udf47\udb8f\udd3d\udaa7\udecb\u44bd\udb1b\udf9c\udb0b\udf61\udade\udeb6",
        41, 81802, -608798480, -8886890814963746925L, -11619L, true, true, (char) 46593, (char) 45081,
        Double.longBitsToDouble(0x3fd981709d8c8208L), Double.longBitsToDouble(0x3fefc040d79a10f1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 4, "\udb0f\udca9\udb22\udf83\uda3b\udc7d\udb39\uddd4\ud9a3\udf18\uda64\udfa7\uda40\udc85\udb98\ude74", "\u846b\u051f\u6667\ua120\uc55b\u5dbf\u903f\u45a0\u4df1\u2b96\u2543\uc469\u2c62\ub808\ub326\u1de2\u9f42", "\udaf6\udfc0\ud983\udc73\ud870\udfdd",
        56, 65696, 504761208, 3891149053532965237L, -81614L, false, false, (char) 42461, (char) 8319,
        Double.longBitsToDouble(0x3fe1f33db6f905bfL), Double.longBitsToDouble(0x3fea7c45e45a9d51L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 0, "\udaf4\ude90", "\ub481\u2220\ua1ed\uba89\u121e\u9d55\u6b76\u58c5\u9bee\u983e\u7d1d\u5aa5\u55ce\u72bc\u61ef\u4eb6\u2c76\u3890\uc469\u31ee\ud3ee", "\udae9\udd89\ud8ae\udd1c\ud916\udf7a\udaf6\udfc0",
        4, 79026, -848292634, 1971098000324697909L, -18103L, true, true, (char) 10252, (char) 40494,
        Double.longBitsToDouble(0x3fb9d95d974d17e0L), Double.longBitsToDouble(0x3fe5df94089664aaL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 60, -19, -84, -82, -19, -80, -80, -19, -92, -81, -19, -80, -70, -19, -84, -85, -19, -69, -100, -19, -84, -71, -19, -73, -108, -19, -94, -109, -19, -74, -112, -19, -84, -65, -19, -65, -96, -19, -87, -128, -19, -78, -123, -19, -82, -104, -19, -71, -76, -19, -87, -68, -19, -69...\0121=java.lang.String:\udb2e\udc30\ud92f\udc3a\udb2b\udedc\udb39\uddd4\ud893\udd90\udb3f\udfe0\uda40\udc85\udb98\ude74\uda7c\udef9\udbc0\udf06\012",
        Z.run(T, 2, 3, 0, 0, "\udb2e\udc30\ud92f\udc3a\udb2b\udedc\udb39\uddd4\ud893\udd90\udb3f\udfe0\uda40\udc85\udb98\ude74\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u5aa5", "\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udae2\udc1b\ud8ae\udd1c",
        41, 21100, 168381404, 8306153328672249062L, 34008L, true, true, (char) 16245, (char) 18992,
        Double.longBitsToDouble(0x3feee698e4bc01e8L), Double.longBitsToDouble(0x3fb9d95d9416afe0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 60, -19, -85, -73, -19, -73, -118, -19, -92, -81, -19, -80, -70, -19, -84, -85, -19, -69, -100, -19, -93, -93, -19, -71, -94, -19, -87, -70, -19, -73, -102, -19, -84, -85, -19, -77, -85, -19, -87, -128, -19, -78, -123, -19, -82, -104, -19, -71, -76, -19, -87, -68, -19, -69,...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 0, "\udaf7\uddca\ud92f\udc3a\udb2b\udedc\ud8e3\ude62\uda7a\uddda\udb2b\udceb\uda40\udc85\udb98\ude74\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u5aa5", "\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udae2\udc1b\ud8c5\udd1c\ud85a\udf5c\udaf6\udfc0\ud983\udc73\uc13d\ud890\uddeb\udbcd\udf9e\udb8f\udd3d\udaa7\udea1\u44bd\udb1b\udf9c\udb0b\udff8\uda2f\udc0d\ud847\ude8d\ud8c9\udf9d\udab0\udd33",
        3, 46463, 1163833725, 2708464061368176008L, 8932L, false, false, (char) 41398, (char) 9602,
        Double.longBitsToDouble(0x3fe98981806f6518L), Double.longBitsToDouble(0x3fea2cc08f558d9dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 2, "\ud87a\udd24\ud946\udda7\udb60\udd68\udb97\udca8\udbb8\udf7c\udb3f\udfed\uda40\udc85\udb98\ude74\uda7c\udef9\udb2d\udc72", "\u983e\u7d1d\u5aa5", "\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\ud956\udf83\udb0d\ude71\uda43\ude91\udad5\ude21\uda8a\ude11\udae2\udc1b\ud8ae\udd1c",
        2, 96702, 168368459, 8306153328890374118L, 34008L, true, true, (char) 55168, (char) 18992,
        Double.longBitsToDouble(0x3feee698e1a501e8L), Double.longBitsToDouble(0x3fb9d957693eafe0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 108, -19, -84, -110, -19, -72, -111, -19, -92, -81, -19, -80, -70, -19, -84, -85, -19, -69, -100, -19, -84, -71, -19, -73, -108, -19, -83, -94, -19, -65, -72, -19, -85, -128, -19, -73, -123, -19, -87, -114, -19, -67, -109, -19, -82, -104, -19, -71, -76, -19, -87, -68, -19, ...\0121=[B:[[-84, -19, 0, 5, 116, 0, 108, -19, -84, -110, -19, -72, -111, -19, -92, -81, -19, -80, -70, -19, -84, -85, -19, -69, -100, -19, -84, -71, -19, -73, -108, -19, -83, -94, -19, -65, -72, -19, -85, -128, -19, -73, -123, -19, -87, -114, -19, -67, -109, -19, -82, -104, -19, -71, -76, -19, -87, -68, -19, ...\012",
        Z.run(T, 2, 3, 3, 1, "\udb12\ude11\ud92f\udc3a\udb2b\udedc\udb39\uddd4\udb62\udff8\udac0\uddc5\uda4e\udf53\udb98\ude74\uda7c\udef9\udbc0\udf06\uda2e\ude80\uda76\udeb3\udaca\udf4f\ud8ae\udc5a\ud9a9\udcd0\ud8d5\udefa\udbc3\udcea\ud810\ude15", "\u3890\u297b", "\udab9\ude1d\ud964\udd6d\ud85e\udc16\ud9ac\udc12\ud916\udf7a\uda98\udfb1\udacf\udee7\ud84c\udd1c\ud992\ude64\ud8b4\ude9a\ud87b\udd7c\ud951\udd54\ud98c\udd19\ud992\udf33\udb03\udccd\udae3\udeb6\ud85d\udded\ud97c\udcd6",
        40, 58951, -535137088, 8744293289366620516L, -47793L, true, true, (char) 7348, (char) 32927,
        Double.longBitsToDouble(0x3fda3a9ad956ffd2L), Double.longBitsToDouble(0x3fe114cf37df0e4cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 60, -19, -95, -116, -19, -71, -114, -19, -92, -81, -19, -79, -77, -19, -84, -85, -19, -69, -100, -19, -83, -119, -19, -70, -108, -19, -86, -114, -19, -68, -93, -19, -93, -88, -19, -79, -101, -19, -90, -107, -19, -68, -96, -19, -82, -104, -19, -71, -76, -19, -87, -68, -19, -...\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 0, "\ud84c\ude4e\ud92f\udc73\udb2b\udedc\udb49\ude94\uda8e\udf23\ud8e8\udc5b\ud995\udf20\udb98\ude74\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u5aa5\u7d2f\u72bc\u1ada\u4eb6\u2c76\u3890\uc469\u2c62\ud3ee\u7c70\ud362", "\ud916\udf7a\udaf6\udfc0\ud983\udc73\uc13d\ud890\uddeb\udbcd\udf9e\udb8f\udd3d\ud937\udea9\ud9ca\udc30\udb1b\udfe7\udb0b\udff8\udade\udeb6\ud85d\udded\uda80\udff8\udbba\udf40\udbf8\udffd\uda48\udf0a\ud837\udec6\ud928\udf11\uda1d\udce0\udb43\udf1a\udb50\udd61",
        22, 32055, -1992651604, 7541313408096727139L, 85231L, true, false, (char) 52129, (char) 14739,
        Double.longBitsToDouble(0x3fb40310bfca8dc0L), Double.longBitsToDouble(0x3fe99339eed7e008L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 4, "", "\ud1e7", "\udb1d\ude6e",
        43, 4613, -679867043, 37975980310528L, 86113L, false, false, (char) 54985, (char) 29697,
        Double.longBitsToDouble(0x3e48b14800000000L), Double.longBitsToDouble(0x3fdf3032c2b20148L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 6, -19, -84, -110, -19, -72, -111]]\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 3, "\udb12\ude11", "\u78a5\u98b9\u6335\ub7ef\u11c8\u660c\uadbb\u58c5\u9bee\u74bb\u7d1d\ucfb4\u55ce\u72bc\u61ef\u36ef\u2c76\ud0b7\u954c\u37b2\uaf3b", "\udb08\udcbb\ud92c\udf3b",
        41, 36444, 168381404, 2685660995656599761L, -39976L, true, true, (char) 16245, (char) 18992,
        Double.longBitsToDouble(0x3fd22d31c97803d0L), Double.longBitsToDouble(0x3fb9d95d9c16afe0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 1, 4, 0, "\udb12\ude11\ud92f\udc3a\udb2b\udedc\udb39\uddd4\ud893\udd90\ud8b7\udfdc\uda58\udef2\ud926\udea6\udabe\uddaa\udbc0\udf06\uda68\udcdc\udadd\ude1e\ud8d8\udc84\uda49\udd14\uda9d\udf44\ud9a2\udcfc\ud9e3\uddfa\udb99\ude5b\udb2f\udecf\ud844\udc6e\ud9e9\udf20\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udae2\udc1b\ud8ae\udd1c\ud916\udf7a\udaf6\udfc0\ud983\udc43\uc13d\ud80c\udf97\udbcd\udfbe", "\u928e\u3074\u048b\u8d4b\u2ea2\u0993\ud48a", "\ud91e\udcde\uda3d\udd8f\uda74\udda0\ud9ef\udc1e\udb07\udff6\ud80a\udf1b\ud9b3\uddac\udb80\ude86\ud89e\udd3f\udaea\udded\udab8\udf92\ud8a2\udfe7\udb27\udea5\udae4\udc03\udb3a\uddbe\uda26\udeb1\ud82d\udce2\ud936\udd19\udb4b\ude6a\uda75\udc8f\udb1e\ude96\udb23\udd93\ud9e4\udfd6\ud9d3\ude3b\udbaf\udd71\ud805\udd72\ud9bd\udf68\u115e\ud8fb\uddb2\udbd8\udf8d\uda04\ude6f\udb68\udca7\udbe7\ude2a\udbb0\udc3b\udba5\ude5a\udbff\udfb2\ud8f8\udfe4\ud919\ude81\udb77\udc35\ud8f7\udec1\ud9c3\uddf5\udb9c\ude62\uda26\udc65",
        44, 19578, -1602994776, -3372099460547893510L, 80875L, true, false, (char) 739, (char) 18662,
        Double.longBitsToDouble(0x3fed95d50ee9ed3fL), Double.longBitsToDouble(0x3fc06aba60aa6c90L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:\udb12\ude11\ud92f\udc3a\udb4c\udcec\udb39\udda5\ud87b\udc03\ud90c\udd24\ud807\udda7\ud85d\ude91\uda7c\udef9\udbc0\udf06\0121=java.lang.String:\udb12\ude11\ud92f\udc3a\udb4c\udcec\udb39\udda5\ud87b\udc03\ud90c\udd24\ud807\udda7\ud85d\ude91\uda7c\udef9\udbc0\udf06\012",
        Z.run(T, 2, 0, 0, 0, "\udb12\ude11\ud92f\udc3a\udb4c\udcec\udb39\udda5\ud87b\udc03\ud90c\udd24\ud807\udda7\ud85d\ude91\uda7c\udef9\udbc0\udf06", "\u2fa7\u7d1d\u86cc", "\uda55\udc6f\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\ud937\udddf\ud8cc\udd17\udbfc\udfb8\udb6c\udd54\ud962\uddcd\udae2\udc1b\ud8ae\udd1c",
        2, 21317, 168381404, -1036694938316477853L, 22741L, false, false, (char) 6905, (char) 40611,
        Double.longBitsToDouble(0x3fb9d95d9416afe0L), Double.longBitsToDouble(0x3fe70f5bbebbb9e7L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 1, 4, 4, "\ud988\udd57\uda41\udc3f", "\u308d\u5cc9\uba73\u121e\u9d55\u6b76\u58c5\u6d74\u189f\u7d1d\u5aa5\u55ce\u72bc\u61ef\uc35e\u8b46\uaaab\ucf27\ua34f\u1e9b\u69dc\u7dce", "\ud9a9\udfea\udaf2\udfc0\ud983\udc73",
        26, 5366, 123387696, 2167932878685545331L, -9052L, true, false, (char) 8319, (char) 30735,
        Double.longBitsToDouble(0x3fdf5429680319f0L), Double.longBitsToDouble(0x3fe07c415bcf8579L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=null\012",
        Z.run(T, 2, 3, 0, 0, "\udb12\ude11\ua358\udb2b\udea5\udb39\uddd4\ua9bd\ud84e\udc06\udbcf\udec6\udb98\ude74\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u5aa5", "\000\uda94\udc09Y\ud9e9\udf20\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udb66\udebe\ud8ae\udd1c",
        41, 21100, 590044, 8306152839045977318L, 34008L, true, true, (char) 16245, (char) 18992,
        Double.longBitsToDouble(0x3feee698e4bc01e8L), Double.longBitsToDouble(0x3fb9d95d9416afe0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 1, "\udb12\udd4e", "\u78a5\ud6a9\ua1ed\uba89\u121e\u9d55\u6b76\u58c5\u9bee\u983e\u7d1d\u5aa5\u5581\u72bc\ubd7e\uaf47\u2c76\u3890\uc469\u2c62\ud3ee", "\udae2\udc1b\ud8ae\udd1c\ud916\udf7a\udaf6\udfc0",
        4, 79026, -848292634, 529946119553551224L, 33493L, false, false, (char) 6905, (char) 40611,
        Double.longBitsToDouble(0x3fb9d95d9416afe0L), Double.longBitsToDouble(0x3fb2cc176250b8e8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 12, -19, -84, -110, -19, -72, -111, -19, -92, -81, -19, -80, -70]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 0, "\udb12\ude11\ud92f\udc3a", "\ud6a9", "\udb98\ude74\uda7c\udef9",
        30, 72625, -747603777, -6841533253775116641L, -41076L, true, true, (char) 2273, (char) 47069,
        Double.longBitsToDouble(0x3fc371139471ca58L), Double.longBitsToDouble(0x3fc1b0bc79bb25e8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 57, -20, -127, -96, -19, -94, -70, -19, -78, -68, -19, -89, -79, -19, -75, -118, -19, -84, -113, -19, -73, -116, -19, -95, -67, -19, -75, -104, -19, -84, -65, -19, -65, -96, -19, -87, -128, -19, -78, -123, -19, -82, -104, -19, -71, -76, -19, -87, -68, -19, -69, -71, -19, -8...\0121=java.lang.String:\uc060\ud8ba\udcbc\ud9f1\udd4a\udb0f\uddcc\ud87d\udd58\udb3f\udfe0\uda40\udc85\udb98\ude74\uda7c\udef9\udbc0\udf06\012",
        Z.run(T, 2, 3, 0, 1, "\uc060\ud8ba\udcbc\ud9f1\udd4a\udb0f\uddcc\ud87d\udd58\udb3f\udfe0\uda40\udc85\udb98\ude74\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u5aa5", "\ubca3\udbbf\uddf4\ud9de\udcbb\ud987\udccf\udac6\udf5b\udb0d\udde9\udbee\udcff\udb6c\udd54\ud962\uddcd\ud99e\udc98\udaf2\udeea",
        12, 47012, 168381404, 5207676784593225217L, -6139L, false, true, (char) 13388, (char) 38396,
        Double.longBitsToDouble(0x3fe544a802028a59L), Double.longBitsToDouble(0x3fe9491932a18e48L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 0, "", "\u4e5e\000", "\u00b8",
        -5, -1000, 0, -517631382659268417L, -100000L, false, false, (char) 0, (char) 1056,
        Double.longBitsToDouble(0x3fe162903000032cL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 1, 1, "", "", "\ud893\udd75",
        -5, 54688, 70, 14291512590336L, -99962L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3d79000000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 1, 1, 0, "\uef05", "\ub6bd\u4351\u4107\uba89\u3951\ub94e\u6b76", "\ud8d8\udc84\udb36\udc15\uda9d\udf44",
        21, 59832, -350163668, 295655979471771377L, 34299L, false, true, (char) 0, (char) 30318,
        Double.longBitsToDouble(0x3fd4d313d16c1104L), Double.longBitsToDouble(0x3fe7880007b3e0edL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 0, "\udb12\ude11\ud92f\udc3a\udb2a\udfdc\udb39\uddd4\ud8d0\udf8f\ud839\udc5d\uda3f\udff9\udb98\ude74\ud8f4\udf94\udb9f\uddb4", "\u983e\u7d1d\u5aa5", "\udb91\udf5b\udac9\uddfc\udb43\udde0\udb0e\udf67\udac6\udf5b\udb0d\udde9\ud9ce\udd56\udb6c\udd54\ud962\uddcd\ud9dd\udff0\ud8ab\udc34",
        41, 64852, 1315814428, 174335942921215695L, 34056L, true, true, (char) 16245, (char) 18992,
        Double.longBitsToDouble(0x3feee698e7c201e8L), Double.longBitsToDouble(0x3fc80caeca0b55acL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.String:\uda5f\udfe9\uda65\ude5d\udab4\udc0f\udbcd\udff8\ud893\udd90\udb3f\udfe0\ud831\udc21\udb98\ude6e\uda7c\udf1b\uda15\uded3\uda68\udd12\udadd\ude1e\uda92\udc81\ud918\udebd\uda19\ude75\u75e9\ud9e3\ude16\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\udac6\udf5b\udbf2\udc6c\udb96\ude85\ud930\udfb0\udb6d\udc0e\ud9ac\udf54\ud8c6\uddb3\udbe1\udfef\uda33\udc36\ud983\udc73\uc13d\udb77\udf58\udbd6\ude65\udb8f\udd3d\udaa7\udea1\udb01\udd7b\udb5d\udfaa\ud87b\udfd1\udb90\udc35\ud87e\udcdd\ud82f\udc82\udbc0\ude2f\ud9bf\uddf4\u3538\udb1e\udd3e\ud86d\udebc\ud997\uddb0\ud967\udc42\udbff\ude28\uda96\udd23\udb95\udd06\udad4\udcbf\ud823\udde4\ud907\udc30\u5f0d\u2062\uda08\udf1f\udad7\udde0\udb83\udf61\ud992\udc54\ud824\udfdd\ud860\udfa4\udb35\uddfa\ud921\udfe0\udac8\udfd1\udaa6\udc72\u918c\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 2, 2, "\uda5f\udfe9\uda65\ude5d\udab4\udc0f\udbcd\udff8\ud893\udd90\udb3f\udfe0\ud831\udc21\udb98\ude6e\uda7c\udf1b\uda15\uded3\uda68\udd12\udadd\ude1e\uda92\udc81\ud918\udebd\uda19\ude75\u75e9\ud9e3\ude16\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\udac6\udf5b\udbf2\udc6c\udb96\ude85\ud930\udfb0\udb6d\udc0e\ud9ac\udf54\ud8c6\uddb3\udbe1\udfef\uda33\udc36\ud983\udc73\uc13d\udb77\udf58\udbd6\ude65\udb8f\udd3d\udaa7\udea1\udb01\udd7b\udb5d\udfaa\ud87b\udfd1\udb90\udc35\ud87e\udcdd\ud82f\udc82\udbc0\ude2f\ud9bf\uddf4\u3538\udb1e\udd3e\ud86d\udebc\ud997\uddb0\ud967\udc42\udbff\ude28\uda96\udd23\udb95\udd06\udad4\udcbf\ud823\udde4\ud907\udc30\u5f0d\u2062\uda08\udf1f\udad7\udde0\udb83\udf61\ud992\udc54\ud824\udfdd\ud860\udfa4\udb35\uddfa\ud921\udfe0\udac8\udfd1\udaa6\udc72\u918c", "\ubafd\u31bd\u15c9\ub0a8\u0a65\u8014\u5042\u2beb\u7437\u10ab\ua255\u9551\ub3f7\u071c\ub51c\u3f77\ub24e\u60ca\u2bcd\u4a03\u0576\uabdd\u6165\u6ed0\ud458\u1431\u4cfb\ud249\u7087\ub2ff\u5e84\ub450\u9188\u4eb6\u01d1\ub866\u38a4\u7290\u01ec\u207b\uad92\u62b0", "\ud941\udcc4\ud8da\udeb1\udba3\udcb5\udb24\udd0a\udb91\udca9\ud8d9\uddd5\ud8c9\udffd\ud9b0\udfb3\ud8ef\ude92\ud91a\udd09\udbea\uddd9\udbeb\ude94\udb80\uddd3\ud99f\udc24\udb6f\udd3d\udbd8\udcaa\ud9ee\udd1e\ud84b\udf22\udbd3\udf77",
        35, 7817, 1522898327, -3196816007952599672L, -78890L, false, true, (char) 13834, (char) 53921,
        Double.longBitsToDouble(0x3fe124d48680fa2dL), Double.longBitsToDouble(0x3fe486e534f920c6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 60, -19, -84, -110, -19, -72, -111, -19, -92, -81, -19, -80, -70, -19, -84, -85, -19, -69, -100, -19, -84, -71, -19, -73, -108, -19, -94, -109, -19, -74, -112, -19, -84, -65, -19, -65, -96, -19, -84, -87, -19, -76, -119, -19, -82, -104, -19, -73, -119, -19, -87, -68, -19, -...\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 2, "\udb12\ude11\ud92f\udc3a\udb2b\udedc\udb39\uddd4\ud893\udd90\udb3f\udfe0\udb29\udd09\udb98\uddc9\uda7c\udef9\udbc0\udf06", "\u983e\u7d1d\u0c2f", "\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\ud90f\udd39\udaf6\udce4\ud9ce\udd56\udb6c\udd54\ud962\uddcd\udae2\udc1b\ud8ae\udd1c\udb54\ude79\udaf7\udc16\ud983\udc73\uc13d\ud890\uddeb\udbcd\udf9e\udb8f\udd3d\udaa7\udea1\u44bd\ud805\udc90\udafc\udc93\udade\udeb6\ud85d\udded",
        56, 60196, -1532560217, 1935690565568582523L, 39821L, false, false, (char) 8477, (char) 41774,
        Double.longBitsToDouble(0x3fd8116c7589819aL), Double.longBitsToDouble(0x3fe2d20a5986f5dfL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 2, 111, -19, -94, -73, -19, -70, -89, -19, -93, -88, -19, -70, -117, -19, -93, -81, -19, -75, -81, -19, -89, -112, -19, -68, -106, -19, -94, -109, -19, -74, -112, -19, -84, -65, -19, -65, -96, -19, -87, -128, -19, -78, -123, -19, -92, -99, -19, -75, -74, -19, -95, -127, -19, -...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 4, "\ud8b7\udea7\ud8e8\ude8b\ud8ef\udd6f\ud9d0\udf16\ud893\udd90\udb3f\udfe0\uda40\udc85\ud91d\udd76\ud841\udf98\uda49\udd08\uda68\udd12\udadd\ude1e\ud9e2\udc89\uda49\udd14\udaa6\udc21\ud81e\udc41\ud9e3\uddfa\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\ud9dc\udf5b\ud9b0\ude74\udbe1\ude52\uda42\udc61\ud962\udd98\ud8d5\ude9d\ud91b\udfda\ud993\uddf2\uda33\udc36\ud983\udc73\udb1d\udcfa\ud8ce\udecd\uda83\udd41\ud83a\udf84\ud8d1\ude49\udad1\udc7b\u9e0e\ud972\udce5\udb6f\ude17\ud842\udd11\uda2f\udf47\u014b\uda45\udd59\udbcd\ude85\udb78\udf63\ud9b1\uddc0\ud997\ude1d\ud9d3\ude78\udbff\udd78\uda96\udd23\ud802\ude3e\ud8dc\ude30\udb9b\udfa2\udaf8\udf7e\udbd6\ude85\udb21\udcd9\ud9d0\udff2\udbb5\ude97\ud9ba\udebd\udb6a\udd36\ud961\udc5b\ud829\udc9c\u6be8\u748b\udab3\udd28\udaa3\udf43\uda72\udd97\ud820\uddea\ud9cf\udd52\uda27\udca2\ud9ec\udf9d\udb4b\udd1b\uda4e\udd84\udacd\udcba\udad0\udcba\ud914\udcd6\udb44\udd58\ud8e4\ude8b\ud9da\ude5e\ud984\udc76\ud901\udf1a\ud806\udf8b\uda9e\ude1d\uda18\udecc\udad3\ude83\ud8b9\udfb1\ud91b\udca1\u43c8\uda97\udd3e\ud9b8\ude59\uda1e\uddb7\udbad\udf6a\ud8c6\udd50\udbb0\udf23\ud85b\udfd7\ud99e\udd55\ud9f6\udf44\udb2c\udf56\udb5c\udd50\udb2a\ude21\ud89f\udd91\ud80c\udd46\ud860\udfcc\udb33\ude09\ud850\uddfc\u227f", "\u9636\ub17b\u4f55\ua67f\u3825", "\ud9ef\udda8\udb9a\udf4b\uda90\udf8a\ud932\udcf5\ud947\ude47\ud996\udf9e\ud8c6\udfb1\uda4d\uddc2\ud9a6\uddea\ud972\udf90\udb22\ude3c\ud8c1\ude20\u90fa\ud93e\udf57\ud9ee\udd89\udafc\udce4\ud92a\udd7e\ud8f5\ude86\udb95\udf64\udb4b\udfbe\uda31\udd65\uda7e\ude1d\udb01\udf51",
        20, 18486, -741902891, 8524315567193833414L, -76248L, true, false, (char) 2448, (char) 62405,
        Double.longBitsToDouble(0x3fd59cf64fc2341eL), Double.longBitsToDouble(0x3fd40ee7fd32ccecL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 1, -99, -19, -94, -73, -19, -70, -89, -19, -93, -88, -19, -70, -117, -19, -93, -81, -19, -75, -81, -19, -89, -112, -19, -68, -106, -19, -94, -109, -19, -74, -112, -19, -84, -65, -19, -65, -96, -19, -87, -128, -19, -78, -123, -19, -92, -99, -19, -75, -74, -19, -95, -127, -19, -...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 1, "\ud8b7\udea7\ud8e8\ude8b\ud8ef\udd6f\ud9d0\udf16\ud893\udd90\udb3f\udfe0\uda40\udc85\ud91d\udd76\ud841\udf98\uda49\udd08\uda68\udd12\udadd\ude1e\ud9e2\udc89\uda49\udd14\udaa6\udc21\ud81e\udc41\ud9e3\uddfa\udb99\ude5b\udac9\uddfc\ud9c7\udf83\ud9e9\udf20\ud9dc\udf5b\ud9b0\ude74\udbe1\ude52\uda42\udc61\ud962\udd98\ud8d5\ude9d\ud91b\udfda\ud993\uddf2\uda33\udc36\ud983\udc73\udb1d\udcfa\ud8ce\udecd\uda83\udd41\ud83a\udf84\ud8d1\ude49\udad1\udc7b\u9e0e\ud972\udce5\udb6f\ude17\ud842\udd11\uda2f\udf47\u014b\uda45\udd59\udbcd\ude85\udb78\udf63\ud9b1\uddc0\ud997\ude1d\ud9d3\ude78\udbff\udd78\uda96\udd23\ud802\ude3e\ud8dc\ude30\udb9b\udfa2\udaf8\udf7e\udbd6\ude85\udb21\udcd9\ud9d0\udff2\udbb5\ude97\ud9ba\udebd\udb6a\udd36\ud961\udc5b\ud829\udc9c\u6be8\u748b\udab3\udd28\udaa3\udf43\uda72\udd97\ud820\uddea\ud9cf\udd52\uda27\udca2", "\ud613\u5461\u3344\u4db0\ua2f0\u302f\u206d\u8fd1\ud26e\ua21c\ua812\u2081\u55a5\ua38b\u1ee9\u8785", "\uda1e\uddb7\udbad\udf6a\ud8c6\udd50\udbb0\udf23\ud85b\udfd7\ud99e\udd55\ud9f6\udf44\udb2c\udf56\udb5c\udd50\udb2a\ude21\ud89f\udd91\ud80c\udd46\ud860\udfcc\udb33\ude09\ud850\uddfc\u227f\udb73\ude54\udb82\ude44\ua803\uda08\udc60\ud9dc\udffb\udbe0\udc3a\udbd9\udc82\ud9c1\udd2c\u7d53\ud9ef\udda8\udb9a\udf4b\uda90\udf8a\ud932\udcf5\ud947\ude47\ud996\udf9e\ud8c6\udfb1\uda4d\uddc2\ud9a6\uddea\ud972\udf90\udb22\ude3c\ud8c1\ude20\u90fa\ud93e\udf57\ud9ee\udd89\udafc\udce4\ud92a\udd7e\ud8f5\ude86\udb95\udf64\udb4b\udfbe\uda31\udd65\uda7e\ude1d\udb01\udf51\uda83\ude17\udbed\udfaf\udb66\udf39\udad0\uded0\uda88\udf11\ud889\udcc7\udaf7\udf1e\uda04\udc90\udad8\udefd\udac0\uddc4\ud86f\udee2\udbc5\uded8\udb26\udf49\ud88b\udd6e\ud950\udf05\uca32\ud98d\uddaa\ud9f7\ude7b",
        32, 78083, -880493903, -7709620829061198471L, 92554L, true, false, (char) 23474, (char) 37288,
        Double.longBitsToDouble(0x3fd35f60ade80714L), Double.longBitsToDouble(0x3feec0592ed69f0dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.SerializationUtils|clone|java.io.Serializable|static",
    "M|org.apache.commons.lang3.SerializationUtils|deserialize|[B|static",
    "M|org.apache.commons.lang3.SerializationUtils|deserialize|java.io.InputStream|static",
    "M|org.apache.commons.lang3.SerializationUtils|serialize|java.io.Serializable|static",
    "M|org.apache.commons.lang3.SerializationUtils|serialize|java.io.Serializable,java.io.OutputStream|static",
    "C|org.apache.commons.lang3.SerializationUtils|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
