package org.apache.commons.lang3;
import org.junit.Test;
import static org.junit.Assert.*;
public class SerializationUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 111, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -106, -19, -82, -118, -19, -69, -113, -1...\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\ud94f\udf9a\ud988\udc86\udafa\ude73", "\ud018\u4499", "\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\uda1c\ude0c\udba1\udf7c\uda64\ude42\ud912\udc8e\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb\udb2a\udd0f\ud94f\udfb7\ud907\udea5\uda2f\udd04\uda07\udfe8\udaec\ude9d\uda57\udda5\udb92\udfe5\ud924\udee2\uda3c\ude24\ud8a9\udf0c\ud867\udde6\ue281\udbe7\udcf9",
        -3, 39989, 1875731036, -1157075455366651000L, -41352L, false, true, (char) 39296, (char) 10792,
        Double.longBitsToDouble(0x3fe4e7b1f451ee9eL), Double.longBitsToDouble(0x3fc142e9f56767c4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 111, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -106, -19, -82, -118, -19, -69, -113, -1...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 0, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\ud94f\udf9a\ud988\udc86\udafa\ude73", "\ud018\u4499", "\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\uda1c\ude0c\u3e0b\udbe9\udc98\ud912\udc8e\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb\udb2a\udd0f\ud94f\udfb7\ud907\udea5\uda2f\udd04\uda07\udfe8\udaec\ude9d\uda57\udda5\udb92\udfe5\ud924\udee2\uda3c\ude24\ud8a9\udf0c\ud867\udde6\ue281\udbe7\udcf9",
        -3, 35637, 1875731036, -1157075455366651000L, -41352L, false, true, (char) 39296, (char) 10792,
        Double.longBitsToDouble(0x3fe4e7b1f451ee9eL), Double.longBitsToDouble(0x3fc142e9f56767c4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 108, -19, -93, -77, -19, -74, -107, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -106, -19, -82, -118, -19, -72, -111, -1...\0121=java.lang.String:\ud8f3\udd95\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\ude11\ud8d9\udc44\ud84e\udc3a\ud991\udce2\ud99f\udc76\u1414\ud8af\ude00\ud887\ude45\ud94f\udf9a\udaf6\udf1d\ud92a\udc37\012",
        Z.run(T, 2, 3, 0, 4, "\ud8f3\udd95\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\ude11\ud8d9\udc44\ud84e\udc3a\ud991\udce2\ud99f\udc76\u1414\ud8af\ude00\ud887\ude45\ud94f\udf9a\udaf6\udf1d\ud92a\udc37", "\ua879\u4499", "\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\uda1c\ude0c\udba1\udf7c\uda64\ude42\ud898\uddd1\ud8c9\udd70\udbf5\udca5\ud987\udfbd\ud918\ude6e\udb67\udcbe\ud94f\udfb7\ud907\udea5\uda2f\udd04\uda07\udfe8\ud918\ude3e\ud990\uded1\udaf6\ude38\ud924\udee2\uda3c\ude24\uda6c\ude0d\ud84b\udcb2\ue281\udbe7\udcf9",
        -3, 39989, 1676901939, -1157075257798155384L, 84007L, true, false, (char) 55135, (char) 10792,
        Double.longBitsToDouble(0x3fe4e7b1f451ee9eL), Double.longBitsToDouble(0x3fe73244f959d9f1L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 30, -19, -94, -98, -19, -69, -120, -17, -113, -109, -19, -93, -83, -19, -67, -69, -22, -125, -115, -19, -92, -128, -19, -75, -120, -19, -91, -65, -19, -65, -109]]\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 4, "\ud89e\udec8\uf3d3\ud8ed\udf7b\ua0cd\ud900\udd48\ud97f\udfd3", "\u3dc7\u02f9\u34a0\u2094\u858f\u385b\u039a\u5738", "\udafa\ude73\udb34\udc29\ud9b2\udf07\ud813\udc8a\udade\udd7b\ud9f1\udf4d\uda03\ude2b\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\ud9fe\udf1d\udb4c\udf6f",
        0, 43787, -1547778247, -4224737154907710806L, -40638L, true, false, (char) 44864, (char) 41942,
        Double.longBitsToDouble(0x3fd6799f509bcd4cL), Double.longBitsToDouble(0x3fd3a26a0eec0f72L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 15, -19, -94, -82, -19, -76, -121, -17, -113, -109, -19, -87, -110, -19, -71, -83]]\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 2, "\ud8ae\udd07\uf3d3\uda52\ude6d", "\u75be\u3a08\u1ed3\u56e4\u9af7\u6236\u2e9d\u09e2\ubbfc\u03bb\uae70\u9aa2\ub729\u7aab\u72c7\u3c03\ud018\u4499\u87e2\u038e\u804b\ua58d\u0e20\uac0b\u3a9d", "\ud8c9\udd70\udbf5\udca5\udae3\udde8",
        -3, 37382, -1923461511, -3977204150907315448L, 82134L, false, true, (char) 24635, (char) 26870,
        Double.longBitsToDouble(0x3fe1bf2e240eb6c4L), Double.longBitsToDouble(0x3fdb76d709815f30L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 2, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\uda84\udcd5\ud988\udc86\udafa\ude73", "\ud018\u4499", "\udb4c\udf2b\ud875\udda2\ud8ff\udde1\uda1c\ude0c\udba1\udf7c\uda64\ude42\ud912\udc8e\ud9c7\udc11\udbf5\udca5\udae3\udde8\ud882\udfbb\udb2a\udd0f\ud94f\udfb7\ud907\udea5\uda2f\udd04\uda07\udfe8\udaec\ude9d\uda57\udda5\udb92\udfe5\ud924\udee2\uda3c\ude24\ud8a9\udf0c\ud867\udde6\ue281\udbe7\udcf9",
        -3, 92421, 1875731036, -1157075455366651000L, -41352L, false, true, (char) 39296, (char) 10792,
        Double.longBitsToDouble(0x3fe4e7b1f451ee9eL), Double.longBitsToDouble(0x3fc142e9f56767c4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 1, 1, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb69\udd04\ud893\udd47\ud972\uddc9\ud858\ude9e\udbd5\udfe5\ud813\uddf3\udb4c\udfa1\ud8a1\udc34\ud835\ude9f\ud8c7\udfb3\ud889\udd17\ud917\ude9f\ud988\udcb3\uda8d\ude64", "\ud018\u4499", "\ud806\ude92\ud98b\ude54\ud8cf\udc72\ud960\udf8f\ud8af\uddd6\uda64\uddd6\ud912\udc8e\ud8c9\udd70\udaf4\uddaf\udae3\udde8\ud882\udfbb\udb59\udf77\ud94f\udfb7\ud907\udea5\uda2f\udd04\ud8a6\udfed\udaec\ude6c\uda57\udda5\udb92\udfe5\ud924\udee2\uda3c\ude24\ud8a9\udf0c\ud885\udf81\udb91\udfd6\udbe7\udcf9",
        -3, 39846, 1875731036, -1156862755701251192L, -41352L, false, true, (char) 30848, (char) 58900,
        Double.longBitsToDouble(0x3f95e85b8a3dcea0L), Double.longBitsToDouble(0x3fc142e9f56767c4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 9, -19, -95, -107, -19, -77, -98, -17, -113, -109]]\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 1, "\ud855\udcde\uf3d3", "\u739d\u75be\u1cb1\u1f69", "\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\udb49\udc58\ud988\udcf5\udafa\ude73\udb34\udc29\ud9b2\udf07\ud813\udc8a\udade\udd7b\ud9f1\udf4d\uda03\ude59\uda23\udfd8\ud875\udfb9\ud977\udca1\uda1c\udda1\udba1\udf7c\uda64\ude42\ud912\udc8e\ud8c9\udd70\udbf5\udca5\udae3\udde8\udb22\udcea\ud975\udc2e\ud97b\udfb7\ud907\udea5\uda2f\udd04",
        -5, 33775, 119668026, 5425368009335967698L, -99848L, true, false, (char) 62162, (char) 63270,
        Double.longBitsToDouble(0x3fe798d4c1972385L), Double.longBitsToDouble(0x3fe2e08346016fcdL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 111, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -91, -19, -82, -118, -19, -69, -113, -19...\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\udea5\udb8a\udecf\ud8b2\udc13\ud813\udd58\ud94a\udc3e\udb02\udf64\udb95\udd23\udac0\udf4a\udb1f\ude28\ud94f\udf9a\ud988\udc86\udafa\ude73", "\ud018\u4499", "\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\uda1c\ude0c\udba1\udf7c\uda64\ude42\ud912\udc8e\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb\uf298\ud86b\udf93\ud933\udff6\uda2f\udd04\udb7d\udefb\udaec\ude9d\uda57\udda5\udb92\udfe5\ud924\udee2\uda3c\ude24\ud8a9\udf0c\udae9\udde7\ue281\udbf2\udedd",
        -3, 39989, 1875731036, -1157075455366651000L, 48699L, false, true, (char) 8411, (char) 6896,
        Double.longBitsToDouble(0x3fc75a947565af40L), Double.longBitsToDouble(0x3fd3c009b3280ac4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, -121, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -106, -19, -82, -118, -19, -69, -113, -...\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\ud94f\udf9a\ud988\udc86\udafa\ude73\udb34\udc29\ud9b2\udf07\ud813\udc8a\udade\udd7b", "\u8469\ua58d\u0e20\uac0b\u3a9d\u0838\u259c\u80a5\ubb6d\u2142\ub10a\u031d\u7697\u287b\uba17\u135b\ube1e\u25ae\u80b2\u948b\u27b1\u2180\uc36a\u05c3\u4a6b", "\udac8\udcf2\udaeb\udd0e\uda28\udf17\ud89c\udfb1\ud9f3\uddef\ud8e7\udff5\udb8c\udee0\udbfe\udc1c\udbae\udf28\udb49\ude9a\udafe\udd95\uda8b\uddb0\udb56\ude4b\ud96c\udcb6\udaa8\udd5f\ud9ed\udcaa\uda8a\udfa5\udb4f\udc50\udb97\udf8c\udb3a\udf30\u9979",
        2, 65087, 633302861, -1434732969384486367L, 84004L, false, false, (char) 39890, (char) 5226,
        Double.longBitsToDouble(0x3fe70c0335f51d07L), Double.longBitsToDouble(0x3fd7c7d7738854b8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 111, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -106, -19, -82, -118, -19, -69, -113, -1...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\ud8b8\udc4b\ud988\udc86\udafa\ude73", "\ud018", "\uda03\ude59\ud824\udd8e\ud8e7\udc16\uda9f\udeb9\uda1c\ude0c\udba1\udf7c\uda64\ude42\ud912\udc8e\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb",
        57, 82489, -926015002, -7352729989631569561L, 30362L, false, true, (char) 23324, (char) 24635,
        Double.longBitsToDouble(0x3fc30d0bc8df9710L), Double.longBitsToDouble(0x3f8d6d886ddb5c00L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 51, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -108, -19, -75, -127, -19, -85, -119, -19, -70, -106, -19, -92, -113, -19, -72, -104]]\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 2, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud894\udd41\udac9\ude96\ud90f\ude18", "\u7855\u6ffa\u918c\u05f5\u6ac7\ua262\u4db7\u7aab\u72c7\u3ba4\ud018\u4499\u87e2\u04a2\u841d\ua58d\u0e20\uac0b\u3a9d\u0838\u259c\uc0a5\u55fe\u6f2f\ub10a\u031d\u7665", "\uda07\udfe8\uda6a\ude5d\uda57\udda5",
        56, 28602, 1751036926, -1890385291982396873L, -85211L, false, false, (char) 17129, (char) 4986,
        Double.longBitsToDouble(0x3fd6bf88c258d4eeL), Double.longBitsToDouble(0x3fb6f3be5a204b68L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\ud94f\udf9a\ud988\udc86\udafa\ude73", "\ud018\u4499", "\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\uda1c\ude0c\udba1\udf7c\uda64\ude42\ud912\udc8e\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb\udb2a\udd0f\ud94f\udfb7\ud907\udea5\uda2f\udd04\uda07\udfe8\udaec\ude9d",
        31, 84926, -1405284398, 7520646330818232472L, 83104L, true, true, (char) 29380, (char) 44494,
        Double.longBitsToDouble(0x3fec477f8d6bf88cL), Double.longBitsToDouble(0x3fd2c6a777e7b156L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\ud9d3\udd4b\ud3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb82\udf19\ud893\udd47\udac9\ude96\ud8c7\udd6f\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udacf\udf81\0121=java.lang.String:\ud9d3\udd4b\ud3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb82\udf19\ud893\udd47\udac9\ude96\ud8c7\udd6f\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udacf\udf81\012",
        Z.run(T, 2, 0, 0, 3, "\ud9d3\udd4b\ud3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb82\udf19\ud893\udd47\udac9\ude96\ud8c7\udd6f\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udacf\udf81", "\ua262\u578b", "\ud9b2\udf07\ud813\udc8a\udb75\udd88\ud9f1\udf88",
        0, 53907, 1363119426, -4133026708824926246L, 58599L, true, false, (char) 46945, (char) 554,
        Double.longBitsToDouble(0x3fcbc4ddf7df4500L), Double.longBitsToDouble(0x3fc78d0319e77c1cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 36, -19, -93, -77, -19, -71, -101, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -28, -105, -105, -19, -88, -85, -19, -69, -94]]\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 1, "\ud8f3\ude5b\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\u45d7\uda2b\udee2", "\uc8be", "\udbe1\udff5\udbd6\udece\uda8f\ude09\udbea\uddda\ud94f\udf9a",
        16, 60210, 728357740, 3355546143616698109L, -13313L, false, false, (char) 25003, (char) 19016,
        Double.longBitsToDouble(0x3fe0da89ffdac6a4L), Double.longBitsToDouble(0x3fdd62549e43b050L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 111, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -106, -19, -82, -118, -19, -69, -113, -1...\0121=[B:[[-84, -19, 0, 5, 116, 0, 111, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -106, -19, -82, -118, -19, -69, -113, -1...\012",
        Z.run(T, 2, 3, 3, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\ud80e\ude08\ud988\udc6a\udafa\ude73", "\ud018\u4499", "\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\uda1c\ude0c\udba1\udf7c\uda64\ude42\ud912\udc8e\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb\udb2a\udd0f\ud94f\udfb7\ud907\udea5\uda2f\udd04\uda07\udfe8\udaec\ude9d\uda57\udda5\udb92\udfe5\ud924\udee2\uda3c\ude24\ud8a9\udf0c\ud867\udde6\ue281\udbe7\udcf9",
        -3, 39989, 1875731036, -1157075455366651000L, -41352L, false, true, (char) 39296, (char) 10792,
        Double.longBitsToDouble(0x3fe4e7b1f451ee9eL), Double.longBitsToDouble(0x3fc142e9f56767c4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 1, 1, "\ud9d3\udd9e", "\u4ba8\u739d\u75be", "\udb84\udffa\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08",
        25, 30416, -115922212, 5797499875803700515L, -70626L, true, false, (char) 40574, (char) 30495,
        Double.longBitsToDouble(0x3feedec1449584ceL), Double.longBitsToDouble(0x3fb8d2e11f0450c0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 1, 2, 4, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\u0d6d\ud8f3\udc97\ud865\udf67\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33", "\u578b\u3d6b\u72a9", "\udade\udd7b\ud9f1\udf4d\uda03\ude59\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\ud837\ude59\udba1\udf70\ud8be\udf24\ud8ff\udccd\ud8c9\udd70\udbda\uded6\ud9ab\uddec\ud854\udf98\udb2a\udd0f\ud9ba\udeb8\ud907\udea5\uda2f\udd04\uda07\udfe8\udb67\ude9b\uda57\udda5\udb92\udfe5\ud924\udee2\uda3c\ude24\ud8a9\udf0c\ud867\udde6\ue281\udbe7\udcf9\udb7d\uded7\ud9fe\udebc\udac8\udcf2\ud8a3\udf6a\ud832\udccf\ud91e\udf4e\uda86\udf64\ud8e8\udcde\udb8c\udee0\udbfe\udc1c\udbba\udf7b\ud805\udcb8\uda7f\uddcc\udb05\udef1\udb51\ude6c\ud9fa\udd3d\udba6\udf93\ud8e8\udc90\ud84a\udedd\u92e2\udb7a\udfb8\ud977\udc2d\udbe6\udc86\ud966\udf9f\uda4c\udf18\ud8cf\udeb1",
        39, 3537, -357043404, -4575213216191998857L, -75155L, true, true, (char) 30493, (char) 53863,
        Double.longBitsToDouble(0x3fe11c5deee4eebfL), Double.longBitsToDouble(0x3fb89ede2acabdb0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 1, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udae3\ude7d\ud873\udee0\udaf6\udeb4\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\ud950\udc6f\ud988\udc86\udb14\ude80", "\uc284\u4499", "\ud6f9\udaf8\ude0b\uda9f\udeb9\udac4\udc7a\ud8ed\udc1a\ud9df\udf56\ud858\udf54\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb\udb2a\udd0f\ud94f\udfb7\ud907\udea5\uda2f\udd04\uda07\udfe8\udaec\ude9d\uda57\udda5\udb92\udfe5\ud924\udee2\uda3c\ude24\ud8a9\udf0c\ud867\udde6\ue281\udbe7\udcf9",
        -3, 39989, -419952036, -1157075455375296632L, -41352L, false, true, (char) 39296, (char) 27631,
        Double.longBitsToDouble(0x3fe4e7b1f451ee9eL), Double.longBitsToDouble(0x3fc142e9f56767c4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 0]]\0121=java.lang.String:\012",
        Z.run(T, 2, 3, 0, 4, "", "", "\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96",
        21, 97195, 1501368493, 7414501885952732202L, -67748L, false, false, (char) 59919, (char) 54403,
        Double.longBitsToDouble(0x3fd235074c26c7f8L), Double.longBitsToDouble(0x3fd526db453e0588L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 51, -19, -85, -88, -19, -79, -74, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -83, -76, -19, -72, -103, -19, -94, -109, -19, -75, -121, -19, -91, -81, -19, -73, -123, -19, -82, -118, -19, -69, -113]]\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 1, "\udae8\udc76\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\ud96f\uddc5\udb8a\udecf", "\u3492\u858f\u395d\u05f5\u6ac7\ua262\u082e\u237f\u72c7\u3ba4\u3f43\u4499\u87e2\u940a\u8469\ua58d\u0e20\uac0b\u3a9d\u0838\u259c\u80a5\u944c\u2142\ub10a\u031d\u7697\ub6b0", "\udaec\ude9d\uda57\udda5\udb93\udc65\ud955\udfe2\uda3c\ude24\ud8a9\udf0c\ud867\udde6",
        27, 31595, 595928677, 1182258422331826780L, 67562L, true, true, (char) 49743, (char) 40778,
        Double.longBitsToDouble(0x3fa04750e9dcb2f0L), Double.longBitsToDouble(0x3f51cd06a57d6000L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=null\012",
        Z.run(T, 2, 3, 0, 4, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\udd2a\ud893\udd47\udac9\ude96\udb8a\udecf\u7bab\000\ud923\ude10*\000\000\udae2\uddb1\ud92f\udd9a\ud988\udc2e\ud94e\udedd", "", "\ud9f1\udf4d\uda03\ude59\uda23\udfd8\udaeb\udd45\000\uda1c\udd32",
        30, 30499, 1266983963, -8495833563426479136L, 51040L, false, false, (char) 41942, (char) 43868,
        Double.longBitsToDouble(0x3fb5f9a980000000L), Double.longBitsToDouble(0x3e4c000000000000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 9, -30, -71, -94, -19, -96, -96, -19, -73, -81]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 0, "\u2e62\ud820\uddef", "\ub047\u75be\u5509\u525f\u933b\uc8be\u7437\uc751\u85ff\u918c\u05f5\u6ac7\ua262\u578b\u7aab\u72c7\u3ba4\ud018\u4499\u87e2\u940a\u8469\ua58d\u0e20\u2f0a\uab4c\ud25d\u9b62\u80dd\ubb6d\u2142\ub10a", "\ud907\udea5",
        19, 86815, 648050775, 513970259310069622L, -64745L, false, false, (char) 19530, (char) 29380,
        Double.longBitsToDouble(0x3fe00b7e6b88eff1L), Double.longBitsToDouble(0x3fd6bf88c258d4eeL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 1, 0, 0, "\000\000", "\u739d\u75be\u5509\000", "",
        5, 98214, 2046820352, -288230376676736244L, -67748L, false, false, (char) 59919, (char) 56086,
        Double.longBitsToDouble(0x3fd235074c26c7f8L), Double.longBitsToDouble(0x3fb49b6d14f81620L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 2, -64, -128]]\0121=!org.apache.commons.lang3.SerializationException\012",
        Z.run(T, 2, 3, 1, 4, "\000", "\u974a", "\000\000\000\udb7b\uddf6\ud9fb\ude6c\000\000\000\000\ud897\udf79\ud94f\udf9a\ud988\udc86\udafa\ude73l\ud9b2\udee4\ud813\udc8aR\ud9dd\udcae\uda03\ude2b",
        3, -1000, -962295296, -7591756897892433920L, -100000L, false, true, (char) 23471, (char) 40968,
        Double.longBitsToDouble(0x3fe80002a000da18L), Double.longBitsToDouble(0x3fe3c88039e68d5aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 2, "\ud8f0\udeec\000", "\u739d", "\u3258",
        -5, 97195, 173, 7414332363593559082L, 63324L, false, false, (char) 48947, (char) 54380,
        Double.longBitsToDouble(0x3fd235074c26c7f8L), Double.longBitsToDouble(0x3fd5200b413e0588L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 1, "\udb60\udccf", "\u4ba8\u739d\u75be\u5509", "\udbd5\udfe5",
        48, 30246, 2058169386, -229730499743661300L, -45436L, false, true, (char) 43525, (char) 32190,
        Double.longBitsToDouble(0x3fd526d6953e0588L), Double.longBitsToDouble(0x3fe5a3561dcb3de0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 0, 0, 4, "\000", "\000\000\u312e", "",
        43, -829, 0, 0L, -100000L, false, false, (char) 0, (char) 65112,
        Double.longBitsToDouble(0x3fe6e000036cf917L), Double.longBitsToDouble(0x3fe0600006136331L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 0, "", "", "\ud8a3\ude5f",
        -5, 2856, -1073728936, 7192553092335303595L, 5006L, false, false, (char) 54611, (char) 49115,
        Double.longBitsToDouble(0x3fd53e0b40c72a74L), Double.longBitsToDouble(0x3fb63f9b16e5f998L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=null\012",
        Z.run(T, 2, 3, 0, 0, "", "", "\udbfd\ude6c\udb74\ude19\u00fd",
        -4, 66382, 0, 1711276032L, -45388L, false, true, (char) 51635, (char) 33341,
        Double.longBitsToDouble(0x3fb617b3d6e5f998L), Double.longBitsToDouble(0x3f4f20000001d000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\udb32\udc23\udb10\udeb5\udb95\udd23\udb80\udd33\ud89c\udf08\ud94f\udf9a\ud988\udc86\udafa\ude73", "\ud018\u4499", "\uda23\udfde\udaf8\ude0b\uda9f\udeb9\uda1c\ude0c\udba1\udf7c\uda64\ude42\ud912\udc8e\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb\udb2a\udd0f\ud94f\udfb7\ud907\udea5\uda2f\udd04\uda07\udfe8\udaec\ude9d\uda57\udda5\udb92\udfe5\udaad\udf25\uda26\ude96\ud8a9\udf0c\ud867\udde6\ue281\udbe7\udcf9",
        -3, 39989, 1875731036, -1157075455366651000L, -41352L, false, true, (char) 39296, (char) 10792,
        Double.longBitsToDouble(0x3fe4e7b1f451ee9eL), Double.longBitsToDouble(0x3fc142e9f56767c4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 116, 0, 108, -19, -89, -109, -19, -74, -98, -17, -113, -109, -19, -87, -110, -19, -71, -83, -19, -83, -78, -19, -76, -118, -19, -81, -67, -19, -71, -84, -19, -93, -100, -19, -72, -115, -19, -94, -109, -19, -75, -121, -19, -85, -119, -19, -70, -106, -19, -82, -118, -19, -69, -113, -...\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 0, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\ud8dc\ude0d\ud893\udd47\udac9\ude96\udb8a\udecf\udbd5\udfe5\ud813\uddf3\ud94a\udc3e\udb02\udf64\udb95\udd23\udb80\udd33\ud89c\udf08\ud94f\udf9a\u2c40\udafa\ude73", "\ub07b\u3eda\u34fa\uc4ee\u066a\ua58d\u0e20\uac0b\uab55\u1358\u259c\u80a5\ubb6d\u2142\ub10a\u031d\u7697\u287b\uba17\u135b\ube1e\u25ae\u80b2\u948b\u27b1\u2180\uc36a\u05c3\u4a6b\u46d9\u0c37\u36de\uc2f8\uaab2\u0b9a\u3a8e\ua6e0\uca1a\u3f72\u53a5\u339e\u0602\u1bb0\ubf85\u5093\u5471\u6b87\ub883\u497b", "\udb7e\udd33\udbbf\udf41\ud972\uded0\ud91f\udf5a\ud979\udfc7\uf842\ud954\ude65\udbb7\udebc\uda21\udc90\ud902\udf82\udb17\udc55\uda76\udc6b\ud99f\udd72\udb82\udc7a\udaa2\udeee\ud95d\udd95\ud875\uddce\ud8c0\udda5\udabb\udf9d\uda78\udfe8\ud98c\uddd4\u008f\uda8a\udd75\ud9c4\udcbb\ud8e1\udd4f\udabd\udc9a\udb96\ude54\ud81c\ude55\uda0f\udd12\uda19\udece\udb56\udca5\ud942\uddf9\ud828\udeb6\ud92f\udeaa\ud882\udefc\ud90b\udd69\udbaf\udeee\uda2d\udfe6\ud9e3\udea8\ud894\udecd\ud99a\udcf6\ud9a0\udf7b\udb49\udcd4\ud9a2\ude8f\udac2\udf6b\uc928\uda8d\udc5a\ud894\udf81\ud9a1\udfe0\uda0b\ude74\ud823\udf79\udbb6\ude39\udb1f\udde4\ud846\udc24\ud9c1\udd19\ufc94\udb37\udff5\udaa9\udd09\udb64\udef8\ud828\ude34\uda0f\udc6f\udaf7\udf78\udb1a\ude8d\ud8d1\udcda\ud918\udc86\ud847\udfd1\ud890\udc99\ud9a2\udd7b\udabe\udf68\ud9e3\udd94",
        45, 58320, -896438105, -6441912412562008198L, 61598L, true, false, (char) 47277, (char) 44689,
        Double.longBitsToDouble(0x3fbcfc5a4169fa30L), Double.longBitsToDouble(0x3fe0a16ea7e5c071L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[-84, -19, 0, 5, 112]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 1, "\ud9d3\udd9e\uf3d3\uda52\ude6d\udb72\udd0a\udbfd\ude6c\udb74\ude19\ud893\udd47\udac9\ude96\udb8a\udecf\ud955\ude66\udb57\udea2\ud94a\udc3e\udb1c\udd32\udb82\udcd7\udb80\udd33\ud85e\udf09\ud96e\udd0e\ud988\udc86\udafa\ude73", "\u5d18\u4499", "\uda23\udfd8\udaf8\ude0b\uda9f\udeb9\u29e5\ud927\ude51\udbf4\udfd3\ud912\udd41\ud8c9\udd70\udbf5\udca5\udae3\udde8\ud882\udfbb\udb50\udf0f\ud94f\udfb7\ud907\udea5\uda0c\udd24\uda07\udfe8\udaec\ude9d",
        23, 84926, -1405284398, 1900153995852316841L, -55620L, true, false, (char) 28916, (char) 4358,
        Double.longBitsToDouble(0x3fe43a0859e49e4fL), Double.longBitsToDouble(0x3fef1251d6d72fd8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.lang3.SerializationUtils|clone|java.io.Serializable|static",
    "M|org.apache.commons.lang3.SerializationUtils|deserialize|[B|static",
    "M|org.apache.commons.lang3.SerializationUtils|deserialize|java.io.InputStream|static",
    "M|org.apache.commons.lang3.SerializationUtils|serialize|java.io.Serializable|static",
    "M|org.apache.commons.lang3.SerializationUtils|serialize|java.io.Serializable,java.io.OutputStream|static",
    "C|org.apache.commons.lang3.SerializationUtils|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
