package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipFile_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 12, 7, "\uda79\ude75\ud998\uddab\uda02\udfb1\udabb\ude1c\ud8e2\udc88\ud8a9\udf33\udbcc\udc53\udbd8\uddc3\ud8ee\udd06\ud97a\udc1d\ud9fd\udd55\uda0e\udc8d\u1c0a\ud9ac\uddfa", "\u015a\ub500\u9fc3\uad9a\ucf9e", "\udaa4\udccd\udae7\udd3b\u1ea4\uda86\udfcb\ud8ad\ude36\ud92c\udd41\ud9a0\udc03",
        31, 14176, -1801950890, 4787519288754597821L, -35128L, true, true, (char) 10193, (char) 55784,
        Double.longBitsToDouble(0x3fc10ebb01cacee4L), Double.longBitsToDouble(0x3fe02cfb519ed456L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 3, 3, "\uda79\ude75\ud998\uddab\uda02\udfb1\udabb\ude1c\ud8e2\udc88\ud8a9\udf33\udbcc\udc53\udbd8\uddc3\ud8ee\udd06\ud97a\udc1d\ud9fd\udd55\uda0e\udc8d\u1c0a\ud9ac\uddfa", "\u015a\ub500\u9fc3\uad9a\ucf9e", "\udaa4\udccd\udae7\udd3b\u1ea4\uda86\udfcb\ud8ad\ude36\ud92c\udd41\ud9a0\udc03",
        31, 14176, -1801950890, 4787519288754597821L, -35128L, true, true, (char) 10193, (char) 55784,
        Double.longBitsToDouble(0x3fc10ebb01cacee4L), Double.longBitsToDouble(0x3fe02cfb519ed456L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 12, 7, "\uda9b\udf61\uda65\ude92\uda02\udfb1\udabb\ude1c\ud8e2\udc88\ud8a9\udf33\udbcc\udc53\udbd8\uddc3\ud8ee\udd06\ud97a\udc1d\ud9fd\udd55\ud844\uddcb\udaac\udf44\ud9ac\uddfa\ud833\uddde\ud9a8\udef7\ud837\udd66\udb1c\udf62\ud921\ude07\ud975\udc1c\ud85f\udcc1\uda9a\ude21", "\u4ff1\u0792\u413e\u1f34\u8a0d\uc92c", "\uda70\udf01\ud942\udf58\ud8f4\udc49\udb99\udc8b\u5654\ud816\udfbc\ud8b0\udc9d",
        -3, 82456, -1620406158, -3146144751073107554L, 44592L, true, true, (char) 53001, (char) 34914,
        Double.longBitsToDouble(0x3fd79b95dffba634L), Double.longBitsToDouble(0x3fb71d7bf13e63c0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 6, 13, "\uda79\ude75\ud9c7\udc03\uda02\udfb1\udabb\ude1c\ud8e2\udc88\ud8a9\udf33\udbcc\udc53\udbd8\uddc3\ud8ee\udd06\ud97a\udc1d\ud9fd\udd55\uda0e\udc8d\ud96b\udcfb\uda69\udd11", "\u23af\u3825\u9fc3\uad9a\ucf9e\u4252\ucce3\u9edb\u4ff1\u0792\u413e\u1f34\uba8d\u8f7c\ud4ee\u2810\u0a0a\uae2c\u01de\u50ad\u5f0e\u0884\u3f4f", "\udb80\udec0",
        18, 79606, 1340576074, -6218723208795757302L, 21073L, true, false, (char) 16581, (char) 51534,
        Double.longBitsToDouble(0x3fb5b479eb46e5a8L), Double.longBitsToDouble(0x3feeacfb5202095eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 3, 12, 7, "\uda79\ude75\ud998\uddab\uda02\udfb1\udabb\ude1c\ud8e2\udc88\ud8a9\udf33\udbcc\udc53\udbd8\uddc3\ud8ee\udd06\ud97a\udc1d\ud9fd\udd55\uda0e\udc8d\u1c0a\ud94e\uddeb", "\u015a\ub500\u9fc3\uad9a\ucf9e", "\udaa4\udccd\udae7\udd3b\u1ea4\uda86\udfcb\ud8ad\ude36\ud92e\udf41\ud9a0\udc03",
        31, 14176, -1801950890, 4787519288754597821L, -35128L, true, true, (char) 21058, (char) 39753,
        Double.longBitsToDouble(0x3fd64bd41613f58aL), Double.longBitsToDouble(0x3fe02cf9419ed456L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 10, 5, "\ud913\udcd2\ud940\udcb2\uda02\udfb1\udabb\ude1c\ud8e2\udc88\ud8a9\udf33\udbcc\udc53", "\ua736\u0793\u2e78\u9265\u60c3\u088b\u7067\u015a\ub500\u9fc3\uad9a\ucf9e", "\udaa4\udccd\ud9dd\udc37\udbfb\udcd7\uda7e\udece\ud8ad\ude36\ud92c\udd77\ud9a0\udc03",
        31, 14176, -1801950890, 4787519288754597821L, -35128L, true, true, (char) 10193, (char) 55784,
        Double.longBitsToDouble(0x3fc10ebb01cacee4L), Double.longBitsToDouble(0x3fe02cfb519ed456L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 15, "\ud8a1\uded5\ud998\uddab\uda02\udfb1\udabb\ude1c\udbaf\udc8d\ud8a9\udf33\udbcc\udc53\ud8e0\uddc7\ud8ee\udd06\ud97a\udc1d\ud8aa\udc32\uda0e\udc50\udafa\udca2\ud96c\udff8\ucee1\ud9a8\udef7\ud837\udd66\udb1c\udf62\ud921\ude07\ud810\udde7\ud85f\udd27\uda9a\ude21\ud880\udc6b\udb27\ude72\udb03\udf24\ud9ae\udf6f\udb2f\ude93\ud8fb\udfb8\ud9f1\udf54\ud9a0\udc03", "\u29de\uae2c\u01de\u03c8\u7683\u0fe2\u86fd", "\udb80\udec0\ud904\udf72\ud818\udc4c\ud849\uddd4\udab7\udf48\udbb3\ude20",
        51, 4989, 350250119, -3122703879440599158L, 88785L, true, false, (char) 10768, (char) 32094,
        Double.longBitsToDouble(0x3fd28e61f50b528aL), Double.longBitsToDouble(0x3fb7f906138913b8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 3, 12, 7, "\uda79\ude75", "\u8b65\ud3ba\u3052\ud238\uaaa3\u6452\u117a\u0793\u1974\ub43b\u00c3\u088b\u7067\u015a\ub500\u9fc3\uad9a\ucf9e\u4252\ucce3\u9edb\u424f\u1d95\u41af\u1f34\u8a0d", "\udad7\ude65\uda70\udf01\ud942\udf58\ud8f3\udfaf\udb99\udc8b\u5654\ud82e\udd0a\ud8b0\udc9d\udb91\udfad\ud8e4\udc09\ud8c2\udfc6\ud904\udf72\uda69\udc95\ud967\ude58\udbd9\udd23\ud86c\udc2b\ud853\udd1f",
        13, 2648, -452527964, -4812806365943275119L, 65307L, true, false, (char) 11336, (char) 33692,
        Double.longBitsToDouble(0x3fb5b196f9de7418L), Double.longBitsToDouble(0x3fe5e97a70f0e7deL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 15, "\ud822\udc7f\ud999\udd55\ud9c0\udddc\udabb\ude1c\udbaf\udc8d", "\u22e6\u6452\u117a\u8d21\u2e3b", "\ucee1\ud9a8\udef7",
        31, 82031, -1404175626, 8172550321384073949L, 37167L, false, true, (char) 13338, (char) 1062,
        Double.longBitsToDouble(0x3fbbc6de36134200L), Double.longBitsToDouble(0x3fc3420a6b8a9a30L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 3, 3, 9, "\udb61\uddd9\ud850\udea8\ud91d\udd6c\ud909\ude02", "\ud238\u22e6\u6452\u117a\ua720\u2e3b\ubed7\u57d5\u7097\u7067\u015a\ub500\u9fc3\u21a4\ud004\u4252", "\ud968\udd04\ud9ec\udd8a\udb2f\ude93\ud8fb\udfb8\ud9f1\udf54\ud9a0\udc03\uda35\uddaf\ud8dd\udde9\udb5a\udfdf",
        46, 1167, 1965461743, 3958379744976833940L, -54756L, false, false, (char) 17451, (char) 17775,
        Double.longBitsToDouble(0x3fdfc3b83ac5ba2cL), Double.longBitsToDouble(0x3fea2f10d3d3441eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 15, "\ud8a1\uded5\ud998\uddab\uda02\udfb1\ud9e5\ude03\udb9b\udfcb\udadd\udc2c\uda96\udca4\ud934\udf31\ud879\udcba\udb1f\udd81\ud8aa\udc32\uda0e\udc50\udafa\udca2\ud966\udff8\ucee1\udb50\udcf8\ud837\udd66\udb1c\udf62\ud921\ude07\ud810\udde7\ud85f\udd27\uda9a\ude21\uda75\udd6b\udb27\ude72\udb03\udf24\ud9ae\udf6f\udb2f\ude93\ud8fb\udfb8\ud9f1\udf54\ud9a0\udc03", "\uc101\u1eea\u01de\u1422\u7683\u0fe2\u86fd", "\udb80\udec0\ud904\udf72\ud818\udc4c\uda87\udff3\udab7\udf05\udbb3\ude20\ud883\ude31\ud9c7\udcd4\uf297\ud86a\uded0\udb9d\udca9\udbc8\udffb\uda57\uddc0\ud9bd\udfd1\udb0c\udeb5\ub249",
        50, 81629, -524051421, -2515128332698017765L, -87005L, true, true, (char) 3697, (char) 53474,
        Double.longBitsToDouble(0x3fe599ecd0ac32d6L), Double.longBitsToDouble(0x3fee595f443da55aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 12, 7, "\uda79\ude75\ud9a3\udf60\ud8c8\udd74\udae9\udd45\ud8e2\udc88\ud8a9\udf33\udbcc\udc53\udbd8\uddc3\ud8ee\udd06\ud97a\udc1d\ud9fd\udd55\uda0e\udc8d\udae2\udc76\ud8bd\udfde", "\u015a\ub500\u9fc3\uad9a\ucf9e", "\udaa4\udc3a\udae7\udd3b\uc759\uda86\udfcb",
        8, 71074, -1223508795, 1001107623825008648L, 93118L, false, true, (char) 62947, (char) 10193,
        Double.longBitsToDouble(0x3fc78525b221d760L), Double.longBitsToDouble(0x3fbcacee7164fb50L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipFile|resolveLocalFileHeaderData|java.util.Map|new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|canReadEntryData|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|close||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|closeQuietly|org.apache.commons.compress.archivers.zip.ZipFile|static",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|finalize||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|getEncoding||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|getEntries||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|getEntriesInPhysicalOrder||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|getEntry|java.lang.String|new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|getInputStream|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|populateFromCentralDirectory||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|positionAtCentralDirectory||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|positionAtCentralDirectory32||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|positionAtCentralDirectory64||new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|readCentralDirectoryEntry|java.util.Map|new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|setSizesAndOffsetFromZip64Extra|org.apache.commons.compress.archivers.zip.ZipArchiveEntry,org.apache.commons.compress.archivers.zip.ZipFile$OffsetEntry,int|new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
    "M|org.apache.commons.compress.archivers.zip.ZipFile|resolveLocalFileHeaderData|java.util.Map|new:org.apache.commons.compress.archivers.zip.ZipFile:java.io.File",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
