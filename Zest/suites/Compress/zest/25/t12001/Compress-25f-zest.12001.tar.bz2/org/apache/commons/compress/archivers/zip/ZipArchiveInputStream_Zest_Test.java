package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 4, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 4, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc17\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3969ded4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 17, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\udb9f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 6, 18, "\udada\udcae\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\ud911\udd0a\ud8f6\udeab\ud9b2\udfaf\udba9\udf6b\uda1a\udf05\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud8cd\udcea\udb39\uddc0\uda3a\udfb4\uda47\udc30\ud8a3\udf6f\ud9d7\uddd7\udb47\udfbe\ud980\udea2\ud94f\udcf9", "\u5ff5\u59a5", "\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud8ed\udd71",
        56, 9960, -717162250, 7088418470270004017L, 38017L, true, true, (char) 30716, (char) 8000,
        Double.longBitsToDouble(0x3f8dcfa8a0c3c540L), Double.longBitsToDouble(0x3fe0da42e84b0ec8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 6, 16, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3fc52a461b4df350L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 4, 2, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\uda9c\udca9\udb2c\ude7c\ud921\udd02\uda83\udc98\uda46\udebd\ua77b\udab0\ude15\udbc5\udfbe\ud90a\udca9\uda8f\udeee\uda31\udc67\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud88a\uddc3\uda9a\udf1c\uda85\ude68\udab7\udc33\ud815\ude25\uda53\udc05\uda21\ude74\ud824\udcce\ud82f\ude6e\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1",
        -4, 65420, 1292203339, -6611752132716928231L, 25793L, false, true, (char) 14639, (char) 61677,
        Double.longBitsToDouble(0x3fd4142ab52fe3d6L), Double.longBitsToDouble(0x3fe8298c4efcc878L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 4, 11, "\udb07\udc38\ud8a3\udd2c\udbdf\ude1d\ud8cf\udda6\ud9d4\udf7f\ud8b4\udf43\ud9c6\ude35\ud921\udc50\udb81\udee6\udba8\ude56\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\udaf1\ude07\ud96e\uddf1\udbe2\udf0c\udbed\ude1f\ud835\udf78\ud8a6\ude35\udbd6\udd36", "\uc32f\u3dc2\u7f02\u606a\u59a5\u1b18\u71a5\u1385\u5f14\u3e93\uc7a4\u0719\u2148\u4b0b\u926b\u059c\u2ba2\u4b34\u7584\u6de5\u2f33", "\u8e21\udace\udc97\udbd0\udf84\udaee\udfa2\udadc\udd9a\udb5a\udc9e\udb8a\uddcb\ud805\udc66",
        45, -738, 1930481655, 6663016310257568407L, -34623L, true, false, (char) 2129, (char) 23199,
        Double.longBitsToDouble(0x3fede315b4a631f6L), Double.longBitsToDouble(0x3fc7ae0291bb11f4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 2, 10, 11, "\ud84a\udfec\udaad\udd9e\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8f\uda5f\udc91\ud8a6\udc52\ud8e2\udcbf\udb22\udcd1\u1508\ud9f1\ude65\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\udbd0\udea2\uda0a\udcc0\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud874\udc4c\udbdd\udf12\uda02\udd88", "\u98d9", "\udbfa\udc96\ud9b4\uddb8\ud8c8\udcf2\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\uddd0\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udad4\udd27\udb10\udcb4\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe\ud88a\udc70\udb87\udedc\udb8a\uddcb\ud805\udc66\udbaa\udebd",
        18, 26646, -236242642, 3569466191136688901L, -89311L, false, false, (char) 1764, (char) 41478,
        Double.longBitsToDouble(0x3fe81d6fb6f9e6c6L), Double.longBitsToDouble(0x3fcb07ce6cebd65cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 6, 15, 2, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udf42\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud9a5\ude2a\ud93f\uddd7\ud8a6\ude82\udbd6\udd36\ud88b\udc77\udadf\udfd9\ud927\udf83", "\u5ff5", "\udb25\udf6a\uda02\ude80\udab8\udd87\ud900\udc3b\uda84\udf29\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\uda7d\udc15\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\ud9dd\ude1e\udbd6\ude5f\udb61\ude57\udb57\udc4e\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914887801994L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3fda363470a7213eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 6, 2, 0, "\udae5\udc86\ud950\udfc6\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud957\udfaf\000\udbd6\udd36\ud88b\udc77\ud980\ude6a\udad7\udd33", "\u4874", "\udbfa\udc96",
        12, 94742, -627989904, 36778994661588992L, -36266L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3fed7c42690cfe33L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 9, 14, 12, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud9dd\udf99\uda5f\udc91\ud921\udc50\ud97a\udfe4\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud839\udf25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\ud94d\udf00\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c7\udda1",
        29, 32882, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7f8d3c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 4, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 8, 12, 14, "\udad7\udc6a\udaad\udcd1\udbc1\udc29\ud90c\udf6f\ud9d4\udf3f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\uda8e\udd4d\udba9\udfa0\udb13\ude41\ud9b6\udd8a\ud950\udd1c\uda83\udc98", "\u875c\u7e5a\ud393\u6b6b\u116c\u696c\u3d69\ua222", "\ud9a8\udecb\ud98d\ude70\ud852\udd9f\ud902\uded4\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud9c8\udfd1\udaa9\udd0e\udb4f\ude28\uda98\ude73\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe\ud88a\udc70\udb87\udedc\udb8a\uddcb\ud805\udc66\udbaa\udebd\uf468",
        1, 76854, 831081111, -4001436152702130436L, -34623L, true, false, (char) 40915, (char) 43177,
        Double.longBitsToDouble(0x3fd10853b78cfe3aL), Double.longBitsToDouble(0x3fe28af219423aa8L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 17, 4, 1, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb68\udfde\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\ud8bb\ude37\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\udafc\ude14\ud817\udde7\ud823\udcd7\uda98\uddff\ud917\udfb9\udbe1\udd41\ud84e\udeff\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udaee\uddf1\ud8c1\udf9b",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 11, "\udae5\udd11\udaad\udcd1\udbc1\udc29\ud8cf\udda6\udb2c\uddab\ud8e5\udc51\udb3c\uddca\ud921\udd7a\udbdf\udef5\udbd2\udc44\udb13\ude41\ub6c5\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud8c6\udf58\ud8b2\udd6a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud965\udc34\ud927\udfb6", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud821\udded\ud823\udcd7\ue4d0\udbe2\udf40\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udb17\ude30\ud8c1\udf7e",
        55, 11202, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c77706c8L), Double.longBitsToDouble(0x3feb0b0a76d37cd4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:32875 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 5, 11, "\udae5\udc86\udaad\udcd1\udae4\uddfb\ud8c9\ude5f\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud97f\udc0f\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud97c\udc14\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud803\ude6f\ud93f\udcef\ud9fe\udea6\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        -3, 32878, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 12, 1, 5, "\udae5\udc86\ud88b\uded5\udbd6\udf09\ud8cf\udd02\ud9d4\udf7f\u3c3d\uda61\udc18\ud921\udc50\udb81\udee6\udba9\udf6b\udafc\ude2e\udaaa\uddf7\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\ud30f\u2695", "\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c",
        56, 9960, -717162250, -6523148453075006365L, 38017L, true, true, (char) 30716, (char) 8000,
        Double.longBitsToDouble(0x3f8dcfa8a0c3c540L), Double.longBitsToDouble(0x3fc6890bac8c3874L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 11, "\udae5\udc86\uda6f\udef0\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\ud924\udf20\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ud90b\udeee\ud936\udc78\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u86c7", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\ud9f4\udd88\ud815\ude25\ud9a3\udd6c\udb46\ude0e\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud99f\udc7f",
        52, 9997, 1356596605, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fd3dc87860506f2L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\uda66\udc5d\udb08\udeb0\ud921\udc50\udb81\udee6\ud9c1\uddb7\udb13\udeb0\ud9a4\ude41\ud921\uded5\uda83\udcf1\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udb1a\udd18\udb84\udd6d\ud9cc\uddf5\ud8b6\udc5b", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9f8\udef7\uda29\udfb6\ud957\uddfb\udb7c\udf55\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\ud851\udd63\udbc6\udd6b\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3fe30b0a3ed37c37L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 4, 14, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\udb7b\udede\udb86\udec8\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud86e\udcd2\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\ud9f4\udf66\ud840\udd1c\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1224050709, -8534975088895958154L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c51b54c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 1, 16, "\udae5\udc86\udaad\udcd1\ud966\udd12\ud965\udd05\udb0a\udede\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\udafc\udc8d\uda53\uddc6\uda46\udebd\ud99e\udf53\uda0e\udeac\uda64\udfcf\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\udb99\uddd5", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c",
        27, 71272, -717162250, -7232746869791510361L, 38017L, true, true, (char) 1704, (char) 8000,
        Double.longBitsToDouble(0x3fc73b7a8a0c3c54L), Double.longBitsToDouble(0x3fc6890ba12c3874L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-75, 86, 125, -95, -111, -7, 113, 118]] |a1=[B:[[-59, 117]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 4, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8a1\udda6\ud9d4\udf7f\ud8ef\udd40\uda75\udc17\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud934\udd89\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda17\udd40\udb79\udebb\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5\u59a5", "\ud9b4\uddb8\ud8c6\udc13\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c",
        56, 9960, -1153369866, 7088418470270004017L, 38017L, true, true, (char) 30716, (char) 8000,
        Double.longBitsToDouble(0x3f8dcfa8a0c3c540L), Double.longBitsToDouble(0x3fc6890ba12c3874L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-75, 86, 125, -95, -111, -7, -97, 118]] |a1=[B:[[-59]]\012",
        Z.run(T, 2, 6, 7, 5, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udac0\udf51\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\udb02\udd83\ud928\udc4e", "\u5ff5", "\udbfa\udc43\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\udb08\uddf7\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe\ud88a\udc70\udb87\udedc\udb8a\uddcb\ud805\udc66",
        0, 73547, -2028004338, -1014654420479554921L, -34623L, true, false, (char) 6706, (char) 4452,
        Double.longBitsToDouble(0x3fd8af0783248710L), Double.longBitsToDouble(0x3fd756f0bf39e668L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-75, 86, 125, -95, -97, -34, 117, 71]] |a1=[B:[[-59, 13, 73, 117, 85, 26, -30, 116]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 4, 15, "\udae5\udc86\udaad\udcd1\udbcf\udc0e\ud8a5\ude77\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc7a\udb81\udee6\udba9\udf6b\ud995\udce9\ud909\udfc6\udad6\ude33\uda83\udcf9\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\uda2a\udc3f\ud915\ude5a\ud9d9\udca8\udaed\udcc9\udbb6\udca4", "\u5ff5\u4a3d\u1779\u71a5\u1385\u174a\uc612\uc7a4\u18e1", "\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\uda1e\udde1\ud996\udfcb\u307a\udb85\udf93",
        57, 43870, 1214087811, 5268491059397222475L, 46702L, false, true, (char) 15421, (char) 8707,
        Double.longBitsToDouble(0x3fda37b8ca1d8dbeL), Double.longBitsToDouble(0x3fd2e871f52fe3d6L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 8, 11, 11, "\udb4f\udc5b\udaad\udd77\udbc1\udc29\ud8bc\udf9c\udbe4\udfa8\udb4c\udd12\uda5f\udc8d\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uf2e7\ud930\ude7d\ud810\udcac\ud8a6\ude35\udbd6\udd36\u40c9\ud926\udd94\ud927\udf7c", "\u5ff5", "\udbfa\udc96\udb3f\udf3e\udab7\udd37\ud900\udc68\udab7\udc61\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\ud905\udea2\ud84e\udf2c\udbcd\udf44\ud87f\ude03\udb85\udf93\ud930\udc26\uda17\udcf1\udae9\udec6\udbc6\udd88\udbf5\udc8a\ud978\udf86\ud850\udf51\udbde\udf45\udbf3\ude70\ud985\udf11\ud9fe\ude70\ud947\udcee\udbfe\ude3f\ud905\uded6\ud8b7\udfbf\ud937\udf62\uda50\udcbd\ud8f9\udebc\ud8ee\udffb\uda24\udce8\ud9f5\udc25\udbc7\udc22\u18e5\udba6\udc9f\udbd1\uded0\udb2c\udc99",
        2, 36582, -847763405, -7042580113077566060L, 49508L, true, true, (char) 43713, (char) 22197,
        Double.longBitsToDouble(0x3fc3c21d8f5b5510L), Double.longBitsToDouble(0x3fb98b1bf729e0c0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 4, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\ud80c\udf83\ud97e\udef8\uda87\udeef\ud8c1\udefe",
        55, 434, 1356596713, -8534906916631150474L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:33077 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 4, 11, "\udbb8\udc0f\udaad\udcf4\udbc1\udc29\ud8cf\uddca\uda64\udc1e\uda77\udd64\uda5f\udc91\ud921\udc50\udb81\udee6\ud851\udf85\udb13\ude8e\udb27\udf63\ud950\udd57\uda83\udc98\uda75\udde6\ua77b\uda3d\udf04\ud994\ude8a\udbec\udcba\uda78\udf1e\ud8a6\ude5e\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u8c33", "\ud9eb\udeef\udbf5\udeec\udaa5\ude3f\ud900\udc3b\udab7\udc33\ud815\ude25\ud9f3\udfc1\udb3f\udd43\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbd4\udded\ud87f\ude03\udb85\udf93\ud9c2\udd88\ud8ef\udd60\udb08\uddc8\udbc6\udd88\ud8c1\udefe",
        59, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 59624, (char) 8279,
        Double.longBitsToDouble(0x3fe9fe53c61dd1eaL), Double.longBitsToDouble(0x3fda597d8da6f8a2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 17, 18, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\udb9f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud8c1\udefb\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud996\udccf\ud900\udd36", "\u5ff5\u59a5\u173d\u71a5", "\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c",
        56, 9960, -717162250, 7088418470270004017L, 38017L, true, true, (char) 30716, (char) 8000,
        Double.longBitsToDouble(0x3f8dcfa8a0c3c540L), Double.longBitsToDouble(0x3fc6890ba12c3874L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 8, 9, 11, "\udae5\udc74\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\udb9f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 18, "\udada\udcae\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\ud911\udd0a\ud8f6\udeab\ud9b2\udfaf\udba9\udf6b\uda1a\udf05\ud9b6\udd8a\ud950\udcf7\u1474\uda46\udebd\udbf5\udf7e\ud8cd\udcea\uda81\udd9d\u4612\uda47\udc30\uda64\udd5d\ud9d7\uddd7\udb47\udfbe\ud980\udea2\ud94f\udcf9", "\u5ff5\u59a5", "\uda59\ude6b\udbff\udf0d\uaac2\udac6\ude21\ud815\ude25\ud8ed\udd71",
        56, 9960, -717162250, 7088418470270004017L, 38017L, true, true, (char) 30716, (char) 8000,
        Double.longBitsToDouble(0x3f8dcfa8a0c3c540L), Double.longBitsToDouble(0x3fe0da42e84b0ec8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 8, 14, 10, "\udada\udcae\udaad\udcd1\udbc1\udc29\ud8c0\udda6\ud9d4\udf7f", "\u2279\u8662\ub641\uc4eb\u045b\ub48d\u2d1f\u32b8\ud330\u2299\u6f24\u20be\u0ce3\u320a\u6463\uc033\ua222\u7038\u9d23\u2e5a\u5ff5\u0996\u7afc\u7b6c\ub4be\u81ba\uc612", "\ud93e\udeda",
        58, 42914, -708344953, 7088418471016590129L, 28611L, false, false, (char) 48294, (char) 8000,
        Double.longBitsToDouble(0x3fc4b8a2ca0c3c54L), Double.longBitsToDouble(0x3fe0da42e84b0ec8L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 4, 18, "\udad2\ude29\udaad\udcd1", "\ua1d8\u2fc2\u61c6\u23a9\u8718", "\ud995\udc49\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud8cd\udcea",
        -4, 62831, 0, 255480995774464L, -100000L, false, false, (char) 1909, (char) 21,
        Double.longBitsToDouble(0x3fe9a00000f4b5c8L), Double.longBitsToDouble(0x3fea6fceae3ee52fL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 6, "\udada\udcae\ud841\udefc\udbc1\udc90\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\ud911\udd0a\udb27\udce4\ud9c0\udcfa\udba9\udf6b\uda1a\udf05\uc448\ud864\udf6b\ud840\udef8\uda46\udebd", "\u8bf2\u20ea\u73ff\u47a5\ub596\u4f40\ua23a\u678a\u5680\ud5fd\u5ff5\u59a5\u3e6a\u71a5\u1385\u174a\uc612", "\uda94\udc9d\udb48\udda0\ufc70\ud819\udf30\ud85a\uded7",
        17, 93278, -1098769631, 5157158208635400159L, 81234L, false, true, (char) 11757, (char) 4179,
        Double.longBitsToDouble(0x3febbb3e76ad2e1bL), Double.longBitsToDouble(0x3fe3e10eb3703800L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 9, "\ud989\udcfb\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda93\udcff\ud8f6\udeab\ud9b2\udfaf\ud907\udfd9\uda1a\udf05\ud9b6\udd8a\ud90f\udcd7\uda89\udfb2\uda46\udebd\uda3d\udf84\ud8cd\udcea\udb39\uddc0\uda3a\udfb4\u792f\ud9dd\udf9b\udb8b\uddd8\udb47\udfbe\uda27\udc64\ud9ba\uddee", "\u4041\u59a5", "\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud81d\udd24\ud8ed\udd71",
        56, 9960, -717162250, 7088418469911969073L, 38017L, true, true, (char) 30716, (char) 8000,
        Double.longBitsToDouble(0x3f8dcfa8a0c3c540L), Double.longBitsToDouble(0x3fe0da42e84b0ec8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 9, 9, 6, "\udae5\udc86\udaad\udcd1\u3c57\ud93a\ude41\ud9d4\udf7f\ud8c7\udd8d\ucf6e\udaae\uddf1\udb81\udee6\udb79\udcc5\ud927\ude38\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8c9\udea8\udbc8\udfb1\ud88b\udc77\udace\ude29\ud9e6\udc9e", "\u5ff5", "\udbfa\udc3b\ud9b4\uddb8\uda9a\udf1c\ud9f2\udddb\udbc3\udc79\udb40\udf55\udaf0\ude81\uda74\ude3a\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\ud801\udc7e\ud92f\udf9f\ud9e4\udff0\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 37878, (char) 30564,
        Double.longBitsToDouble(0x3fe7e644b30206c8L), Double.longBitsToDouble(0x3fc12a461b4ed4f4L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udae5\udc86", "\u7981\ua1d8\u0647\u3972I\u412e\u30bd\000\000\u0a94\u2d1f\u32b8", "\000",
        19, 34160, 0, 0L, 73945L, false, true, (char) 200, (char) 29440,
        Double.longBitsToDouble(0x3fe1f72f2970cae2L), Double.longBitsToDouble(0x3f35000000000000L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:14314 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:14314 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 5, 14, "\ud860\udce3\udab1\udc79\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud9dd\udf99\uda5f\udc91\ud921\udc50\ud97a\udfe4\udba9\udf6b\u64b7\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud839\udf25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\ud94d\udf00\ud84e\uded5\uda70\udc94\ud87f\udef0\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\ud941\udde5\ud8c7\udd5f",
        37, 14277, 1351265963, -8534906917645254538L, 77513L, true, true, (char) 49526, (char) 25034,
        Double.longBitsToDouble(0x3feb0b0a3ed37cd4L), Double.longBitsToDouble(0x3fcab69c2ebaaec4L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-89, 58, -38, -80, -111, -43, -36, 63]] |a1=[B:[[-52, 72, 126, -17, -120, 104, 44, 42]]\0121=java.lang.Boolean:false |a0=[B:[[-89, 58, -38, -80, -111, -43, -36, 63]] |a1=[B:[[-52, 72, 126, -17, -120, 104, 44, 42]]\012",
        Z.run(T, 2, 7, 7, 12, "\udad7\udc6a\uda0a\udfe0\udbc1\udc05\ud90c\udf6f\ud9d4\udf3f\ud8c7\udd8d\uda5f\udc91\ud921\udc50", "\uadfc\u7378\ub4ae\u2d1f\u32b8\u8b98\u875c\u7e5a\ud393\u6b6b\u116c", "\ud980\udea2\ud927\udf7c\uda4b\udd47\ud9a8\udecb\ud98d\ude70\ud852\udd9f\ud902\uded4\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud9c8\udfd1\udbe0\udd2a\ud832\udd98\ud9bc\udc65\ud84e\udf37\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88",
        31, 45720, 1115276018, 5826537547841268577L, -97179L, false, false, (char) 25034, (char) 24744,
        Double.longBitsToDouble(0x3fe69be6a24e5d85L), Double.longBitsToDouble(0x3fef0c464110853bL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 8, 8, 14, "\udad7\udc6a\udaad\udcd1\udbc1\udc29\ud90c\udf6f\ud9d4\udf3f\ud8a9\ude8d\uda5f\udc91\udb06\udfc4\uda8e\udd77\udba9\udfa0\udb13\ude41\ud9b6\udd8a\ud950\udd1c\ud878\uded3", "\u4e81\u866b\ud393\u6b09\u116c\u696c\u3d69\ua222", "\ud9a8\udecb\ud98d\ude70\ud852\udd9f\ud902\uded4\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udaa0\udf4c\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud9c8\udfd1\udaa9\udd0e\udb4f\ude28\uda98\ude73\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe\ud88a\udc70\udb87\udedc\udb8a\uddcb\ud805\udc66\udbaa\udebd\uf468",
        1, 76854, 831081111, -3969532723310582020L, -34623L, true, false, (char) 40915, (char) 43177,
        Double.longBitsToDouble(0x3fd10853b78cfe3aL), Double.longBitsToDouble(0x3fe28af219423aa8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 6, 1, "", "\u1ca7", "\ud8c7\udd8d\uda5f\udc91\ud921\udc50",
        46, -1000, 0, 5241773251048032777L, 67340L, true, false, (char) 63423, (char) 2199,
        Double.longBitsToDouble(0x3fb5ff877d2c7800L), Double.longBitsToDouble(0x3fe9100000c9780dL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-75, 86, 91, -91, -90, -39, -97, -46]] |a1=[B:[[-75, -99, 96, -38, 84, -78]]\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 7, 18, 16, "\udae5\udc86\ud88b\uded5\udbd6\udf09\ud8cf\udd02\ud9d4\udf7f\u3c3d\uda9f\udc17\ud93f\udef7\udb81\udee6\udba9\udf6b\udafc\ude2e\udaaa\uddf7\ud854\udcd6\udac6\udcce\u70a8\ud931\udd12\ud940\udec4\udac2\ude77\ud918\udecf\udbf6\udca1\ud8a6\ude35\ue388\uda92\udf97\ud980\udea2\uf4ef", "\u5be5\u74cd\u1790\uae0a\u9d84\u17e2", "\udb78\udee4\ud99a\udef2\udb3a\udf78\ud9f6\udea7\udadf\udc76\ud8dc\uddb5\ud935\udcb3\ud850\udddd\udbcd\udf44\ud9f4\udfdc\udaaa\uddbe\ud92f\udf9f\uda17\udcec\udacc\udf43\udbc6\udd88\ud974\udff8\udacc\udde6\udbb4\udf70\udbaa\udfc1\ud983\udfa2\uda27\ude94\udbc9\udf60",
        58, 70716, -414503612, 2479933434548779461L, 54545L, true, false, (char) 4081, (char) 6318,
        Double.longBitsToDouble(0x3fe5fb3fb9ff5c4eL), Double.longBitsToDouble(0x3fd739372c701b1eL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:true |a0=[B:[[-75, 86, 63, -64, -111, -7, -118, -48]] |a1=[B:[[]]\012",
        Z.run(T, 2, 6, 7, 11, "\udae5\udc86\uda6f\udef0\udbc1\udc29\ue3ba\000\000\uda5f\udc91\ud921\udc50\udb63\udee6\u5762\uda21\udf5e\ud995\udc49\011\uda83\udc98\uda46\udebd\ud890\udef0\ud95a\ude4c\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\u0db4\000\000", "", "\ud902\udea0",
        13, -923, -891128320, -2697196099547303859L, 96695L, true, true, (char) 23654, (char) 63715,
        Double.longBitsToDouble(0x3fe85eaa0331625fL), Double.longBitsToDouble(0x3fe230000321097cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-75, 86]] |a1=[B:[[81, -88]]\012",
        Z.run(T, 2, 6, 7, 0, "\udae5\udc86", "\u7981\ua1d8", "\ud921\udc50\udb81\udee6\udba9\udf6b\ud924\udf20\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ud90b\udeee\ud936\udc78\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c\uda4b\udd47\ud9a8\udecb\ud892\udff3\ud848\udf94\ud902\uded4\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b",
        0, 4348, 1447231488, -4528723728566805696L, -100000L, false, false, (char) 47685, (char) 9373,
        Double.longBitsToDouble(0x3fd11be820000000L), Double.longBitsToDouble(0x3e403b9f50000000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[64, 59]] |a1=[B:[[]]\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 7, 2, 6, "\ud970\ude6b", "", "\ud8ef\udd40\uda75\udc17-",
        48, -1000, -1195769856, 5236425505663404553L, -100000L, true, false, (char) 20560, (char) 10136,
        Double.longBitsToDouble(0x3d91e00000000000L), Double.longBitsToDouble(0x3fe9144d80c9780dL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 4, 4, 0, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8a1\udda6\ud9d4\udf7f\ud8ef\udd40\uda75\udc17\ud921\udc50\ud9e9\udc9a\ud9d7\udd46\udb0b\ude07\ud934\udd89\ud8d0\udef8\uda83\udc98\uce74\ua780\ud940\udec4\uda17\udd40\udb79\udebb\udbd8\udfc4", "\uaf7c", "\ud956\udf9b\ud9a8\udecb\ub7a2\ud852\udd9f\udaa4\udfc5\udbfa\udc96\ud9b4\uddb8\ud8c6\udc13\ud900\udc3b\udab7\udc33\ud815\ude25\udb55\udd86\udb8a\udc88\udbd5\udf70\uda6b\ude35\ud823\udcd7\udae3\udda4\ud85f\udc70\udbcd\udf44\ud86e\udd03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udbd4\udcd1\ud80a\udf94\ud962\ude50\ud98b\udd69\ud8fb\udea1\ud939\udfc3\udad6\udd43\ud8cf\udc2d\ud99a\udf44\ud879\udfda\uda57\udee1\ud866\udd85",
        48, -588, 967232004, -5922963107859495403L, 26773L, false, false, (char) 41891, (char) 16686,
        Double.longBitsToDouble(0x3fe099baac9d3560L), Double.longBitsToDouble(0x3fefe9135835ad0aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-75, 86, 125, -95, -70, 113, 118, -92]] |a1=[B:[[-59, 117]]\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 7, 4, 11, "\udae5\udc86\udaad\udcd1\ua8ea\ud8a1\udda6\ud9d4\udf7f\ud8ef\udd40\uda75\udc17\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud934\udd89\ud94d\udef7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda17\udd40\uda1a\uddd7\ud88e\udd94\udb3c\udf20\u71ac\ud88b\udc3c\ud980\udea2\ud927\udf7c", "\u5ff5\u59a5", "\ud9b4\uddb8\ud8c6\udc13\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud9ed\udc02\udb63\udce8\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\udb39\udd9b\ud89b\udfe3\udaec\uddcb\ud977\udd61\u32ac\uda74\uddba\udb76\udf1d\udb9f\udd67\ud85d\udedd",
        8, 119, 1583419295, 8829657816370494020L, -73152L, true, true, (char) 44721, (char) 60910,
        Double.longBitsToDouble(0x3fd3aef7ff9e84d4L), Double.longBitsToDouble(0x3fcf4ed9f462f48cL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-75, 86, 91, -91, -90, -39, -97, -46]] |a1=[B:[[-75, -99, 96, -46, -48, -78]]\0121=java.lang.Boolean:false |a0=[B:[[-75, 86, 91, -91, -90, -39, -97, -46]] |a1=[B:[[-75, -99, 96, -46, -48, -78]]\012",
        Z.run(T, 2, 7, 7, 16, "\udae5\udc86\ud88b\uded5\udbd6\udf09\ud8cf\udd02\ud9d4\udf7f\u3c3d\uda9f\udc17\ud93f\udef7\udb81\udee6\udba9\udf6b\udafc\ude2e\udaaa\uddf7\ud854\udcd6\udac6\udcce\u70a8\ud931\udd12\ud940\udec4\udac2\ude77\ud918\udecf\udbf6\udca1\ud8a6\ude35\ud8de\udf7b\uda92\udf97\ud980\udea2\uf4ef", "\u5be5\u74cd\u1790\u0102\000\u17e2", "\u00fb\ud99a\udedc,\ud9f6\ude67\udadf\udc76\ud8dc\uddb5\ud935\udcb3\ud850\udddd\udbcd\udf44\ud9f4\udfdc\uf747\000\000\udac9\udc43\udbc6\udd88\ud974\udff8\udacc\udde6\udbb4\udf70\udbaa\udfc1\ud983\udfa2\uda00\ude94\udbc9\udf60",
        -5, 33264, -414503612, 2479933434548779461L, 54545L, true, false, (char) 4081, (char) 6318,
        Double.longBitsToDouble(0x3fe5fb3fb800004eL), Double.longBitsToDouble(0x3fd739372c701b1eL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-75, 86, -62, -56, -125, 62, 28, 110]] |a1=[B:[[]]\0121=java.lang.Boolean:true |a0=[B:[[-75, 86, -62, -56, -125, 62, 28, 110]] |a1=[B:[[]]\012",
        Z.run(T, 2, 7, 7, 11, "\udae5\udc86\uc9f2\ud8f8\uddb3\ud96e\udc4c\uda9e\udf2e\ud85b\uddf0\uda66\udcd3\ud940\udd50\udb9f\udc61\u5762\uda21\udf5e\ud995\udc49\011\uda83\udc98\uda46\udebd\ud890\udef0\ud95a\ude4c\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\u0db4\000\000", "", "\ud902\udea0",
        13, -923, -891128320, -2697196099547303859L, 96695L, true, true, (char) 23654, (char) 63715,
        Double.longBitsToDouble(0x3fe85eaa0331625fL), Double.longBitsToDouble(0x3fe230000321097cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 4, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\udb00\ude79\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25\ud9a3\udd6c\udb48\ude0f\ud824\udc7d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 4, 11, "\udae5\udc86\ud8df\udf4a\udbdb\udff1\ud8fd\udc7c\ud9d4\udf2c\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udba9\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\ua77b\ud940\udec4\uda0a\udc7a\uda08\udebc\ud810\udcac\ud8a6\ude42\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u9b44", "\udbfa\udc96\ud9b4\uddb8\uda9a\udf1c\ud900\udc3b\udb0b\ude38\ud815\ude25\ud9a3\udd6c\ud912\ude39\udbfe\udf4e\udaf5\uddf3\udaaa\ude1f\ud9f6\udc13\ud821\udeaf\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 42, 1343945464, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3feeb423c3020622L), Double.longBitsToDouble(0x3feb0b0a3b1a7cd4L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 4, 2, "\ud828\udf68\udaad\udcd1\udbc1\udc29\u3ba7\ud9d4\udf7f\ud8c7\udd8d\uda75\udffc\ud91c\udd81\udb81\udee6\udba9\udf6b\uda9c\udca9\udb2c\ude7c\ud921\udd02\uda83\udc98\uda46\udebd\ua77b\udab0\ude15\udbc5\udfbe\ud90a\udca9\uda8f\udeee\uda31\udc67\udbd6\udd36\ud88b\udc77\uda2a\udf05\udb8a\udc5c", "\u4736\u814b\u173d", "\uda9a\udf1c\uda85\ude68\udab7\udc33\ud815\ude25\uda53\udc05\uda21\ude74",
        6, 198, 1555168101, -1458571464793081274L, 68687L, true, true, (char) 8000, (char) 9187,
        Double.longBitsToDouble(0x3fe41878a8b4485dL), Double.longBitsToDouble(0x3fe6cf18ee7755ccL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 4, 6, "\ud8ca\udcb9\udaad\udda8\udb5c\udd29\uda8f\ude84\udb90\udef3\udb4a\udc3c\udbbe\udcd7\ud9e6\udf33\ud9be\udf71\ud944\uddf4\uda9c\udca9\ud890\udd81\uda85\udefb\ud924\udfb2\uda34\udd45\ud804\udf60\ud816\ude07\ud9d5\udfae\ud901\udcc4\uda8f\udeee\uda31\udc67\udbd6\udd36\udb98\udc15\ud90e\udd8b\udbeb\udea0", "\u05ed", "\udbfa\udc96\ud88a\uddc3\uda98\udf1c\ud843\ude67\udab1\uded9\ud815\ude25\uda53\udc05\udba6\udf76\udbe9\udd31\ud82f\ude6e\ud823\udcd7\uda98\uddff\ud84e\uded5\udb8b\udfe0",
        0, 32, -405528308, 1086840917121139331L, -4437L, true, false, (char) 34647, (char) 18305,
        Double.longBitsToDouble(0x3fda450dc950e1bcL), Double.longBitsToDouble(0x3fda37b8c41cbdbeL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 0, 17, "A", "", "\udb77\udf81",
        18, 93, -2036565899, 47340572645523456L, -100000L, false, false, (char) 0, (char) 19126,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4c000000000000L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 7, 17, "A", "", "\udb77\udf81",
        3, 205, -2036565899, 47340572645523456L, -100000L, false, false, (char) 0, (char) 19126,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4c000000000000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 4, 11, "\udae5\udc86\udaad\udcd1\udbc1\udc29\ud8cf\udda6\ud9d4\udf7f\ud8c7\udd8d\uda5f\udc91\ud921\udc50\udb81\udee6\udb9d\udf6b\udb13\ude41\ud9b6\udd8a\ud950\udcf7\uda83\udc98\uda46\udebd\u2b7b\ud940\udec4\uda0a\udc7a\ud930\udeb0\ud810\udcac\ud8a6\ude35\udbd6\udd36\ud88b\udc77\ud980\udea2\ud927\udf7c", "\u5ff5", "\000\ud997\ude6b\uda9a\udf1c\ud900\udc3b\udab7\udc33\ud815\ude25W\000\uf53d\ud835\ude71\ud823\udcd7\uda98\uddff\ud84e\uded5\udbcd\udf44\ud87f\ude03\udb85\udf93\ud92f\udf9f\uda17\udcf1\udae9\udec6\udbc6\udd88\ud8c1\udefe",
        55, 33018, 1356596488, -8534906914880068746L, -41646L, false, true, (char) 15491, (char) 15502,
        Double.longBitsToDouble(0x3fe7e643c30206c8L), Double.longBitsToDouble(0x3feb0b0a3ed37cd4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String,boolean,boolean",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String,boolean",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|bufferContainsSignature|java.io.ByteArrayOutputStream,int,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|cacheBytesRead|java.io.ByteArrayOutputStream,int,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|canReadEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|checksig|[B,[B|static",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|close||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|closeEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|drainCurrentEntryData||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|fill||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|findEocdRecord||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getBytesInflated||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextZipEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String,boolean,boolean",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String,boolean",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
