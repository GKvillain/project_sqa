package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 4, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        29, 5383, -857414228, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1d525bb3006L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 4, 14, "\udbcb\udee8\ud915\udec1\udacc\ude9d\ud894\udcb8\uda09\udf3d\udb66\udcd5\ud871\uddfd\uda9e\udf9b\uda05\udc5d\ud81f\ude3b\ud884\udf26\ud977\udd54\ud86e\udf58\ud958\udc98\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud79b\u118c\u4214", "\udb4b\uddb0\ud9f4\udf81\ud9c2\ude35\ud8b6\ude79\uda8f\udd92\ud8a4\udd79",
        31, 65803, 553117100, -6918799075858900364L, 54408L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d9c2c78eL), Double.longBitsToDouble(0x3fd1a9af263d2806L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 1, 14, "\udbcb\udee8\uda93\ude56\uda2d\udfde\ud88f\udd76\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud81f\udda2\ud857\udcae\ud9b9\udcd0\udaed\udced\uda8d\udd99\ud958\udcb1\ud8e6\udf2b\udb8a\udd9d", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u2d07\ua905", "\uda58\udc17\uda6b\udf5c\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        25, 62616, -871083624, 265364910257040702L, 3208L, false, false, (char) 503, (char) 44839,
        Double.longBitsToDouble(0x3fd2902ea046d99cL), Double.longBitsToDouble(0x3fa8aa56cdd15800L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 4, 14, "\udbcb\udee8\ud83e\udc4e\uda47\udda3\ud88f\udce8\ud8e6\udc6b\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda81\ude63\000\000\ud86e\udec5\ud93a\udc3c\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\000", "",
        -5, -1000, 0, 0L, 73348L, true, false, (char) 58623, (char) 50170,
        Double.longBitsToDouble(0x3faf01d7239db4e0L), Double.longBitsToDouble(0x3fe940effa160095L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 4, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\udb02\udde4\uda60\udfb4\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\udba6\udeda",
        1, 5383, -857414228, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1ad75bb3006L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 4, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud845\udfec\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\u34eb\ub82b\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        29, 5383, -857414228, -4835243142723790786L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1d525bb3006L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 4, 1, "\udbcb\udee8\ud9d3\udc5a\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        29, 5383, -857414228, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1d525bb3006L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 4, 14, "\udbcb\udee8\ud87b\ude4d\uda7e\udebe\ud92e\udd17\ud8b9\udef5", "s\ua174\u2424", "\ud86e\udf58\udbb7\udca1\ud916\udc03\udb01\udd52\udbdf\udd9d\udac6\uddac",
        59, 51686, -2059307342, -2130722081858991930L, -33984L, true, false, (char) 4105, (char) 45815,
        Double.longBitsToDouble(0x3fe261a773111442L), Double.longBitsToDouble(0x3fd80793253d118aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\u564e", "", "",
        38, 22281, 0, 0L, -100000L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3f39803511e80000L), Double.longBitsToDouble(0x3fd5ffdeb0000000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Long:896 |a0=[B:[[-101, -72, 98, 41, -21, 34, 72, 77]]\012",
        Z.run(T, 1, 1, 4, 11, "\udbcb\udee8\udb92\udd59\udb1b\ude52\ud878\udd7d\uda09\udf3d\udb60\udfd5\ud871\uddfd\ud9c4\ude70\udafa\udd27\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86e\udee9\udb17\udd91\uda94\udc25\ud8ab\udc1e\uda77\ude82\udac6\uddac\ua5a6\ud823\udd43\ud8a5\udf31\ud945\udd6b\udb7d\udc4a\ud906\ude39\ud9cb\udec4\udb56\udd6e\uda05\udccb", "\u32b6", "\ud956\uded8\udbe6\udc23\ud86e\ude8a\udbf2\udea8\ud9b5\udea3\ud973\ude14\uda1a\udff4\uda49\udff7\uda79\ude09\udb3c\udfb0\uda80\udf24\ud83d\udf00\ud94e\udf07\udbcb\ude11\udbe0\udf71\ud812\uddac\uda78\udd24\udadc\udfa8\udb23\udfa6\udb27\udeca\ud94a\udcb0\uda4c\udd43",
        34, 4141, 752384572, -380221872786309947L, 82505L, true, true, (char) 56660, (char) 46166,
        Double.longBitsToDouble(0x3fe18336806f58f2L), Double.longBitsToDouble(0x3fe6baacc7915d37L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 4, 15, 7, "\udb57\udd0e\ud9cf\udc42\uda7e\udef4\ud89b\udee8\uda21\udd4d\udb8c\udfb0\ud871\uddfd\udaf3\ude9a\ud810\udea2", "\u272c\u4cbb\u756c\ub4c1\uaef2\ud775\u1d84\uc242\u9842\ub9f8\u3489\ud78b\u6921\ud5fb\u8822", "\uda6b\udf7d",
        57, 54152, 253201054, -1010967055222088996L, -41204L, true, true, (char) 7148, (char) 7560,
        Double.longBitsToDouble(0x3feab8effac54b06L), Double.longBitsToDouble(0x3fa45da75c73bf90L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 4, 14, "\udbcb\udebd\ud9d3\udc79\uda7e\udef4\ud88f\udce8\ud833\udef2\ud977\udd5d\udae9\udde9\ud858\uddaf\ud972\udc61\ud9e3\uddb3\ud9f0\udf50\ud969\udded\ud89c\udf30\ud963\udcd5\ud8e6\udf2b\udb8a\udd64", "\u03f2\uac29\u9c4d\u0650\u92cc\u0cce\u4283\u887c\u4326\ud0a6\u866c\u32b6\u0430", "\udbe6\udc23\ud86e\ude8a\udbf2\udea8\uda21\udc32\ud973\ude14\udabb\udced\ud996\udd3f\ud895\ude94\udb25\ude4e\uda80\udf24\ud83d\udf00\ud94e\udf07\ud89b\udf3a\ud91a\udd0b\udbf4\udc08",
        54, 95737, -671963016, -748906330639008351L, -26218L, true, true, (char) 11979, (char) 7695,
        Double.longBitsToDouble(0x3fe0bb93875556ceL), Double.longBitsToDouble(0x3fd578b005406240L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 6, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda24\udec9\udb60\udfd5\ud871\uddfd\ud9fb\udfe8\ud936\uded8\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\uc6fb\ud6e8\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\ud81e\udde6\ud9f1\ude49",
        7, 44679, -857414341, 265364910250006609L, 3208L, false, false, (char) 36943, (char) 35183,
        Double.longBitsToDouble(0x3fd9f206529a3726L), Double.longBitsToDouble(0x3fd5b1d521b65006L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 4, 13, "\udbcb\udee8\uda15\udedd", "\u20bc\u06a4\u27f7", "\ud989\udea9\ud942\udc55\ud965\udfea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64\udb14\udcad\udb9a\udd43",
        59, 42598, -2059307419, -2610918392127371066L, -7657L, true, false, (char) 4105, (char) 60107,
        Double.longBitsToDouble(0x3fe261a2d7ea7142L), Double.longBitsToDouble(0x3fd80793253d118aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 4, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud98d\udd9c\ud958\udc7d\udae2\ude69\uaaf5", "\u70a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u5a7d\u887c\u4326\u6ee0\u86ff", "\udaaa\udf81\ud9ee\udd9d\udbe5\udff5\ud951\udd3c\ud8f3\uddd7\uda21\udc32\ud973\ude66\uda1a\udffd\ud90f\udf9c\uda79\ude09\udb3c\udfb0\uda80\udf24\udae2\udd72\ud849\udd9f\ud863\ude01\ud87e\udd61\udba3\udd80\udadc\udd04\ud993\udd62\ud8f9\udfe8\udb06\ude6d\udbe0\ude7c\ud8bc\ude78\udb8a\udef5\uda33\udf26\ud991\udf27\uda81\udea8\udb50\udc69\ud89d\udf42\ud845\udf40\ud973\udcf0\udaa2\ude55\ud976\udd8f",
        33, 73130, 719031459, 7241823197448330010L, 72028L, false, true, (char) 34437, (char) 35353,
        Double.longBitsToDouble(0x3fdc7b373585f8faL), Double.longBitsToDouble(0x3fa2b0a0aefdd170L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 4, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\ud9bb\udcc3\ud910\udfb0\uda1a\udd45\ud89d\udcd7\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\ud918\udf0b", "\uc2a5\u18ae\uace5\u124e\u2791\u61c0\u2c45\u887c", "\uda6b\udf7d",
        57, 54152, 253173662, -1010967055222088996L, -41204L, false, false, (char) 21377, (char) 28174,
        Double.longBitsToDouble(0x3fe940effa164b95L), Double.longBitsToDouble(0x3fa45da75c73bf90L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 4, 14, "\udac5\uddba", "\u2d60\u20bc\ua99a\u283b\u76ab\ua174\u2424\u6a96\u267f\u4cbb\u4a2a\u1828\uaf09\u3c2b\ua307\uc2a5\u18ae", "\udb7d\udc4a\ud906\ude39\ud9cb\udec4\udb56\udd6e",
        55, 47859, 339877452, 8733283491485389150L, -78798L, false, false, (char) 9533, (char) 24400,
        Double.longBitsToDouble(0x3fefde67203e03aeL), Double.longBitsToDouble(0x3fe1ceda73281dffL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 5, 14, "\udbcb\udee8\udbf2\udcab\uda4e\udfac\ud88f\udce8\ud8ba\udd10\udb60\udfd5\uda6b\uddfa\ud834\udc9f\ud810\udea2\ud857\udcae\udb96\ude3f\ud883\udd7a\ud97b\udfcf\udafb\ude0b\ud8e6\udf2b\udb8a\udd64", "\u8949\u0447\u1a5d\u2c9c\ucc94\u40a1\u9623", "\udb3b\udeb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        29, 31735, -859533921, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 15808,
        Double.longBitsToDouble(0x3fe1bc0ba94d1b95L), Double.longBitsToDouble(0x3fd5b1d525bb3006L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 8, 14, "\uda0b\ude24\u01c6\ud936\udf34\udb3e\udfec\uda14\ude4a\udb60\udfd5\ud871\uddfd\udaed\udd9a\uda1c\udf07\udbc2\udfc0\ud9b9\udcaf\udb45\udeda\ud895\udc32\ud9fb\udc76\ud984\udd7d\u7566", "\uc7df\ua3d9\uc15f", "\udada\ude3d\ud9cb\ude9b\ud847\uded2\uda05\udcad\udb4b\uddb0",
        -5, 60964, 573795456, -3820227251849886660L, -18941L, false, false, (char) 37316, (char) 57741,
        Double.longBitsToDouble(0x3feda70ddbe3a4b0L), Double.longBitsToDouble(0x3fc5ae20d4eb8198L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 4, 14, "\udbcb\udee8\ud9d3\udc79", "\u22ac\ua99a\u283b\u76ab\ua174\u2424\u6a96\u7ece\u4cbb\u756c\u684c\uaf09\u3c2b\ua307\ubbec\ua138\u74bc\u2c9c\u798b\u3ae9\u2c45\u5493\u26a5\u7b82\u71af\ub248\u8185\u1481\u1a31\u2d5d\uc13b\u39aa\ucd5a\u3cc0\u9ec6\u64bc\u416b\u373d\ua8cc\ud649\u840d", "\ud882\udd6e",
        43, 98363, 821479778, 9154134603095289901L, -65688L, false, true, (char) 48403, (char) 39788,
        Double.longBitsToDouble(0x3fe8f5b6b11a39b6L), Double.longBitsToDouble(0x3fee0547358e10dbL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 2, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\udba5\udd48\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        29, 5383, -857414228, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1d525bb3006L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 1, 14, "\udbcb\udef1\uda93\ude56\uda2d\udfde\ud88f\udd76\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud81f\udda2\ud857\udcae\ud9b9\udcd0\udbaf\udf1b\uda90\udd17\ud958\udcb1\ud8f8\udc28\udb8a\udd9d", "\uc2a5\ua43b\uacea\u2c9c\ud78b\u2d07\ua905", "\uda58\udc17\uda6b\udf5c\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        25, 62616, 839694744, 265364910257040702L, 3208L, false, false, (char) 503, (char) 48167,
        Double.longBitsToDouble(0x3fd2902eafa0d99cL), Double.longBitsToDouble(0x3fa8ea51cdd15800L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 1, 9, "\udbcb\udee8\udbd7\udc9b\uda2d\udfde\ud96f\uddc5\ud936\udeda\udb60\udfd5\ud871\uddfd\udaf3\ude9a\uda66\udf46\ud9fb\ude6f\ud8dd\udf3f\udaed\udced\uda8d\udd99\ud958\udcb1\udbc0\udd7c\udb8a\udd9d", "\ua793\ub5ca\u3a46\u2c9c\ud78b\u2d07\ua905", "\uda58\udc17\uda6b\udf5c\ud9c2\ude35\uda56\udf0a\udb51\udcc3\ud92e\uddfe",
        13, 62427, -122333288, 265363900939726142L, 3208L, false, false, (char) 503, (char) 44839,
        Double.longBitsToDouble(0x3fe1481750236cceL), Double.longBitsToDouble(0x3fa8aa56a7b45800L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 14, "\udbcb\udee8\ud83e\udc4e\uda47\udda3\ud88f\udce8\ud8dc\udc6b\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\udb91\udfeb\000\000\ud95c\udd5d\ud9b7\ude89\ud90f\udcb7\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\000", "",
        -5, -1000, 0, 1202430090056883741L, -78972L, true, false, (char) 58623, (char) 50170,
        Double.longBitsToDouble(0x3faf01d7239db4e0L), Double.longBitsToDouble(0x3fd971dff42ca422L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 4, 14, "\udbcb\udee8\ud83e\udc4e\uda47\udda3\ud88f\udce8\ud8e6\udc6b\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda81\ude63\000\000\ud86e\udec5\ud93a\udc3c\ud8e6\udf2b\udb8a\udd64", "\u8239\u18ae\u1bfe\u1464\ud78b\u3ae9\000", "\udb9e\udec9\000\000\000\000\ud919\udf2c\udbe6\udc23_\ued00\udbc9\udda7\udbf0\udd06\ud91e\udec3\udb36\udf30",
        49, 97390, -1227394686, -2748748049644849387L, 58605L, true, true, (char) 25319, (char) 1691,
        Double.longBitsToDouble(0x3fb9ab26993c9598L), Double.longBitsToDouble(0x3fe751660efd1e5fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 13, 11, 14, "\udbcb\udee8\ud83e\udc4e\uda47\udda3\ud88f\udce8\ud8e6\udc6b\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda81\ude63\000\000\ud86e\udec5\ud93a\udc3c\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u397f\uacea\u2c9c\ud78b\u3ae9\000", "",
        -5, -1000, 0, 1418L, 73348L, true, false, (char) 58623, (char) 50170,
        Double.longBitsToDouble(0x3faf01d7239db4e0L), Double.longBitsToDouble(0x3fe940effa160095L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 14, 14, "\ud9ce\udc32\udb20\udc11\uda20\udd81\udb00\uddda\ud8af\udf8e\ud9a9\udcbf\uda07\udef2\uda14\udecc\ud80d\udefd\uda81\ude63\ud952\udd3c\udba3\udc49\uda3f\ude28\ud81a\ude05\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uad5d\u6121\u5bc2\u3b03", "",
        -5, -1000, -1795162112, 3602880766745790178L, 97169L, false, false, (char) 53820, (char) 58623,
        Double.longBitsToDouble(0x3fefd800003e40aeL), Double.longBitsToDouble(0x3fe1ceda73281dffL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 11, 8, 1, "\udb3d\udda0\ud83d\udca3\ud9b9\udddc\uda76\udfce\ud85d\udd3c\ud875\udf0d\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud862\ude06\ud8e1\udc6d\u00c4\ud86e\udec5\ud93a\udc3c\ud8e6\udf2b\ud95d\ude5c", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\000", "",
        -5, -1000, 1392522240, 0L, -45255L, true, false, (char) 37065, (char) 50015,
        Double.longBitsToDouble(0x3faf01d7239db4e0L), Double.longBitsToDouble(0x3fe940effa160095L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 4, 1, "\udbcb\udee8\ud83e\udc4e\uda47\udda3\ud88f\udce8\ud8e6\udc6b\udb9b\udcf3\ud831\udfcc\udadd\ude61\udb60\ude85\uda81\ude63\000\000\udb14\udc78\ud93a\udc3c\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\u368b\u3ae9\000", "",
        -5, -1000, 0, 2414336L, 73348L, true, false, (char) 58623, (char) 50170,
        Double.longBitsToDouble(0x3faf01d7239db4e0L), Double.longBitsToDouble(0x3fe940effa160095L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 5, 4, 14, "\udbcb\udee8\ud83e\udc4e\uda6a\udf24\ud88f\udce8\ud8e6\udc6b\udb60\udfd5\udad5\ude58\uda71\ude09\udbf2\udf98\ud99f\udd0a\ud95b\udecd\000\udb73\udec6\ud93a\udc3c\udb87\udcfc\udb87\udc68\uda77\ude82\udbbc\udfd4\ud91a\ude03", "\uc2d5\u248c", "\000\000\000",
        -5, -1000, 0, -942530560L, 31093L, true, true, (char) 50170, (char) 37746,
        Double.longBitsToDouble(0x3fde30ed4ec052c6L), Double.longBitsToDouble(0x3fe0b6074c42397dL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 15, 4, 14, "\udb5a\udd8f\ud820\udc98\uda47\udda3\ud88f\udce8\uda6f\udf70\udb80\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda81\ude63\000\000\ud86e\udec5\ud93a\udc3c\ud8e6\udf2b\udb8a\udd64", "\uc2a5\ub875\uacea\u2c9c\ud78b\u3ae9\000", "",
        -5, -1000, 0, 0L, 73348L, true, false, (char) 58623, (char) 50170,
        Double.longBitsToDouble(0x3faf01d7170dc4e0L), Double.longBitsToDouble(0x3feaf4279cddb6d1L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-101, -72, -93, 73, 78, -60, 95, -72]]\012",
        Z.run(T, 1, 14, 4, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\udb02\udde4\uda7f\uddb4\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\uda21\uddd8",
        1, 5383, -857414228, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1ad75bb3006L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Long:339 |a0=[B:[[-101, -72]]\012",
        Z.run(T, 1, 1, 4, 5, "\udbcb\udee8", "\u3384\u95e1\uc21f\u2e0e\ud025\u9c04\ubaf8\u6a96\u4f11\u28c4\u9146\u6f20\u43c7\ua9f8\u44b5\u1a6a\u4be5", "\ud841\udcf4\ud906\ude39\ud9cb\udec4\u3109",
        12, 28659, -280022452, -7376779819494338176L, -19099L, false, false, (char) 31290, (char) 45306,
        Double.longBitsToDouble(0x3fe0b25caf2fbb4eL), Double.longBitsToDouble(0x3fdc73bf9abba69aL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 4, 14, "\udbcb\udee8", "\u2d60\u20bc\ua99a\u283b\u76ab\ua174\u2424\u6a96\u0ea2\u4cbb\u756c\u6f20\uaf09\u3c2b\ua307\uc2a5\u18ae", "\ud869\udc40\ud906\ude39\ud9cb\udec4\udb56\udd6e\uda05\udccb\u7a9b\uda6b\udf31\ud9c2\ude35",
        22, -1000, -235384110, -3324401046949440673L, 46437L, false, false, (char) 7560, (char) 45350,
        Double.longBitsToDouble(0x3fe0b25ca828bb4eL), Double.longBitsToDouble(0x3fd000000abba69aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:478 |a0=[B:[[-101, -72, 98, 41]]\012",
        Z.run(T, 1, 1, 4, 11, "\udbcb\udee8\udb92\udd59", "\u20bc", "\ud9c4\ude70\udafa\udd27\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86d\ude3e\ud975\udc8d\udac3\udc53\ud8ab\udc1e\uda77\ude82\udac6\uddac\ua5a6",
        55, 81589, -607901810, 4302847248287612095L, 17437L, true, false, (char) 60197, (char) 21158,
        Double.longBitsToDouble(0x3feaf0a21180cc7aL), Double.longBitsToDouble(0x3fe4f61ccbaccd95L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Long:1090 |a0=[B:[[-11, -95, -113, 125, 64, 90, -79, 85]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 4, 11, "\udb25\udfd1\udabf\uddad\ud870\udc8a\udae1\udc85\uda1c\udfd1\udb60\udfd5\ud871\udd35\ud9c4\ude70\uda51\ude53\ud860\udc92\udb5c\ude80\udb9d\udfee\udb3e\udd75\ud83d\ude49\uda94\udc25\udaa3\ude1e\udba6\udeca\ud9dd\uddca\ua5a6\ud823\udd43\udb4a\udf22\ud94a\udc8a\udb7d\udc4a\ud906\ude39\ud94c\ude5d\udb56\udd89\uda05\udccb", "\u2b9f", "\ud956\uded8\udbe6\udc23",
        2, 31068, 1107014336, -2644149276149595600L, -53430L, false, false, (char) 20928, (char) 43100,
        Double.longBitsToDouble(0x3fd4d1bc7ab63aa4L), Double.longBitsToDouble(0x3fe408610024cc18L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 4, 14, "\ud812\udd61\ud9d3\udd06\uda7e\udef4\ud88f\udce8\ud833\udef2\ud977\udd5d\udae9\udde9\ud858\uddaf\uda5f\ude18\ud998\udd3e\uda06\udc5c\ud969\udded\ud89c\udf30\ud963\udc58\ud8e6\udf2b\udb8a\udd64\uda60\udd70\ud893\uddef\udbef\udf6b\ud9f1\udc7f\uda66\udd98\ud933\udfc5\ud999\udda1", "\u887c\u6d29\uae16\u866c\u480a\ucb6d\u1481\u1a31\ucc2d\u9b8a\ub119\u8046\u3cc0\u30a4\u1acf\u2c2e\u5727\u8dbf\ud68b\u840d\u221c\uc32a\u450e\ua6d2\u905c\u1f70\u7d1a\ucde3\u3422\ub416\u260e\u7384", "\udbaa\udc6f\ud854\udc3c\ud80a\udd8b\ud984\ude8a\ud1b8\uda9c\udf75\ud973\udf66\uda5d\udd9c\ud87a\ude19",
        15, 5648, 1877975549, 12641566150999169L, -95865L, true, false, (char) 22053, (char) 42133,
        Double.longBitsToDouble(0x3fbb472f9ba25a20L), Double.longBitsToDouble(0x3fe7ad40ba7bf6b3L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Long:277 |a0=[B:[[107, -86]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 14, "\ud89b\udeda", "\u2d60\u8c48\ua99a\u61a0\u9b79\ua0b7\u2424\u6a96\u267f\u4cbb\u6a5c\u3900\uaf09\u3c2b\ub44b\uad5e\ub967\uacea\uc6fb\ud6e8\u3ae9\u2c45\u887c\u4326\u98be\u864e\u32b6\u0430\uc9f2\u5002\u5557\u6c38\ub0a8", "\udbb3\ude49\udb0f\udfaf\uda79\ude5a\uda84\ude85\udadd\udfbe\u5b3f\udb94\udf0a\uda95\udfb6\ud844\udd6f\ud90e\udd55\udaca\udcc1\uda6b\udc43\ud92c\udc09\ud899\udcbf\ud8df\udc31\uda4e\uddbd\uda1d\udf38\ud83c\ude40\uda52\udec8\udb94\udead\ud87e\udd41\ud8aa\udf54\ud8bb\udd5e\udbd6\udffa\udbec\udd64",
        48, 54240, -1982314709, 3060726941591182852L, 78830L, false, false, (char) 22961, (char) 12406,
        Double.longBitsToDouble(0x3fed9b774098ea26L), Double.longBitsToDouble(0x3fec29b9d8cbdbf1L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 13, 0, 14, "\udbcb\udee8", "\u2d60\u20bc\ua99a\u6763\u76ab\u131d\000\000\000\ud057\u7538\u3fec\u8759\u0bad\u760a\u70a5\u18ae", "\udb7d\udc4a\ud906\ude39\udb49\udf84\udb56\udd6e",
        42, -1000, 0, 8925852984471261568L, -78798L, false, false, (char) 21343, (char) 49013,
        Double.longBitsToDouble(0x3fefdef3489003aeL), Double.longBitsToDouble(0x3fe1ceda73281dffL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:984 |a0=[B:[[126, -55, 115, 58, 78, -60, 113, 97]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 14, "\udbae\udef9\udaa3\udd6a\uda7e\udef4\ud9a1\ude91\uda87\udfb9\ud9bb\udc77\ud910\udfb0\uda1a\udd45\ud89d\udcd7\ud857\udd3d\ud861\udec5\udb49\udd4c\udb3c\udd61", "\u5039", "\ud935\ude5f\uf18b\udbcd\udf7f\udbf8\udea9\ud9ac\udfff\ud910\udd10\ud9cb\udec4\udb5e\ude6e",
        55, 47859, 339877452, 8733283491485389184L, -78798L, false, false, (char) 9533, (char) 24400,
        Double.longBitsToDouble(0x3fb2061c5eb3fd58L), Double.longBitsToDouble(0x3fc447528ca077fcL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 2, 14, "\000", "\u735f", "\ud871\uddfd\udaf3\ude9a\ud810\udea2",
        31, -595, -1212874752, 8278043357049217138L, 30496L, false, false, (char) 43850, (char) 33711,
        Double.longBitsToDouble(0x3fa35799e6500000L), Double.longBitsToDouble(0x3fec742a08c6dbc4L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 2, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\udba5\udd48\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\u36ea\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        29, -1000, -857473024, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1d525bb3006L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:-360 |a1=[B:[[117, 126, -70, -20, 91, -71, 21]]\012",
        Z.run(T, 1, 8, 2, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\udba5\udd48\udb60\udfd5\udb06\udce8\ud893\udd52\ud934\udcdb\ud898\udf47\ud925\udc71\ud96f\udcea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u441c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        5, -365, -387652180, 6560216958070822974L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1d525bb3006L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 2, 0, "", "\u75d6", "",
        -5, -1000, 0, -587135910697500672L, -100000L, false, false, (char) 0, (char) 2330,
        Double.longBitsToDouble(0x3fdc066f5d447baaL), Double.longBitsToDouble(0x3fd5ffdeb401828cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 1, 7, "\udbcb\udee8\ud83e\udc4e\uda47\udda3", "\ua99a", "\ud810\udea2\udb91\udfeb\ud8c6\udd7e\000\ud95c\udd5d\ud9b7\ude89\ud90f\udcb7\udb8a\udd64\uda77\ude82\udac6\uddac\ua5a6\uf10f\ud8a5\udf29\ud945\udd6b\udb7d\udc4a\ud906\ude39\000\000\000\000\000\000\udaf1\udcc7\ud870\udf59\ud919\udfeb",
        10, -841, 58624, 265364910250006590L, -29961L, false, false, (char) 30027, (char) 52732,
        Double.longBitsToDouble(0x3fd05f6c1f26bb48L), Double.longBitsToDouble(0x3fe9d4e0d43910c1L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 8, "\uda03\ude1f\u77f2\ud987\udfd5\ud88f\udce8\ud8dc\udc6b", "\u76ab\u733c\ub06b\ua859\u61ac\u42dc\uc40e\u933b\ua302\u3c2b\ua307\uc2a5", "\ud945\udd6b\udb7d\udc4a\ud906\ude39\uda26\udd93\ud9d7\udc16",
        30, -1000, 0, 279962572L, 81245L, false, true, (char) 59067, (char) 12182,
        Double.longBitsToDouble(0x3fe0b2908837f195L), Double.longBitsToDouble(0x3fbc33196ab68a68L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 11, 0, "\udbcb\udeee\ud83e\udc4e\uda47\udda3\ud88f\udce8\ud8e6\udc6b\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda81\ude63\u8100\000\ud86e\udec5\ud93a\udc3c\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u397f\uacea\u2c9c\ud78b\u5fe9\000", "",
        -5, -1000, 0, 35747322042254730L, 73348L, true, false, (char) 8391, (char) 3545,
        Double.longBitsToDouble(0x3fe01762e239e8e3L), Double.longBitsToDouble(0x3f70bfff57042080L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-101, -72, 14, 30, 23, 115, 95, -72]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 5, 1, "\udbcb\udee8\ud83e\udc4e\uda47\udda3\ud88f\udce8\u5bab\udb60\udf1c\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda81\ude63\ud8fa\udde4\000\ud86e\udec5\ud93a\udc3c\ud8e6\udf2b\udb8a\udd64\uda77\ude82\ud901\udc48\udb90\uddcb\ud8ad\udd42\ud896\udcb2\ud945\udd6b\udb80\udfed\udbf1\udeda\ud17c\000\000\000", "", "\ud919\udf2c",
        29, -905, 58624, -232007970315115844L, 58732L, false, false, (char) 9843, (char) 19081,
        Double.longBitsToDouble(0x3fcb0bd1ab1a2734L), Double.longBitsToDouble(0x3fc40d9ab55f1c80L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 11, 14, "\udbcb\udee8\ud83e\udc4e\uda47\udda3\ud88f\udce8\ud8e6\udc6b\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda81\ude63\000\000\ud83e\ude6e\ud93a\udc53\ud8e6\udf2b\udb8a\udd64", "\u2199\u397f\uacea\u2c9c\ud78b\u3ae9\000", "",
        -5, -1000, 1824835840, 34359739786L, -41376L, true, true, (char) 7148, (char) 7560,
        Double.longBitsToDouble(0x3fe940effa160095L), Double.longBitsToDouble(0x3fddd7723fc84c5cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 5, 4, 14, "\udbcb\udee8\ud83e\udc4e\uda6a\udf24\ud88f\udce8\ud8e6\udc6b\ud94d\udf4d\ud97c\ude8e\udbb5\udf45\udbf2\udf98\ud99f\udd0a\ud95b\udecd\000\udb73\udec6\ud93a\udc3c\udb87\udcfc\udb87\udc68\uda77\ude82\udbbc\udfd4\ud91a\ude03", "\uc2d5\u248c", "\000\000\000",
        -5, -1000, 0, -942530560L, -53131L, false, true, (char) 9859, (char) 37746,
        Double.longBitsToDouble(0x3fde30ed4ec052c6L), Double.longBitsToDouble(0x3fe0b6074c42397dL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 14, "\udbcb\udee8\ud83e\udc4e\udad2\uddd8\ud942\udd16\ud9d3\udeb9\udbbf\ude92\udae4\udcbd\uda71\ude09\ud8f1\ude37\ud9ac\udff5\ud95b\udecd\000\udb73\udec6\ud95d\ude2d\udb87\udd1f\udb87\udc68\uda77\ude82\udbbc\udfd4\ud944\uddf8", "\uc2d5\u248c", "\000\000\ud9d5\ude4a",
        57, -970, 0, -942530560L, 33407L, true, true, (char) 50170, (char) 59060,
        Double.longBitsToDouble(0x3fde30ed42c052c6L), Double.longBitsToDouble(0x3fe2778ca442397dL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\012",
        Z.run(T, 2, 15, 15, 0, "\udb5a\udd8f\ud820\udc98\uda47\udda3\udbe5\udf33\udad1\udf9d\udaf0\udc61\ud88e\udd0b\udaf3\ude9a\ud810\udea2\uda7b\udd63\000\000\ud86e\udec5\ud93a\udc3c\ud8e6\udf2b\ud98a\udd5d", "\u7383\u081a\ub0b6\u33b5\ud78b\u9463\u8d22", "",
        -5, -1000, 0, 0L, 73348L, true, false, (char) 4531, (char) 42023,
        Double.longBitsToDouble(0x3faf01d7170dc4e0L), Double.longBitsToDouble(0x3feaf4279cddb6d1L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[55, 1, -83, -108, 78, -60, 95, -72]]\012",
        Z.run(T, 1, 14, 4, 14, "\uda67\udd31\ud9dd\udfc4\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud9f1\udd3e\uda64\udf59\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u2c45", "\uda31\udd83\udb11\uddf1\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\uda21\udd18",
        1, 5383, -857414228, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1ad75bb3006L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-101, -72, -93, 73, 78, -60, 95, -72]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 4, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda2d\udcf9\u80da\ud963\udfd6\udb02\udde4\uda7f\uddb4\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\uda21\uddd8",
        1, 5383, -857414228, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1ad75bb3006L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 4, 11, "\ud8ea\udf19", "\ud1dc\u20bc\ua99a\u283b\u76ab\ua174\u2424\u6a96\u0ea2\u4cbb\u756c\u661e\uaf09\u3c2b\ua307\uc2a5\u18ae", "\ud869\udc40\ud906\ude39\ud9d7\udc1a\udb56\udd6e\uda05\udccb\u7a9b\uda6b\udf31\ud9c2\ude35",
        22, -1000, -235384110, -3324401046949440673L, 46437L, false, true, (char) 35123, (char) 28666,
        Double.longBitsToDouble(0x3fe7e58c6028bb4eL), Double.longBitsToDouble(0x3fd000000bf1ce9aL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Long:1090 |a0=[B:[[-11, -95, -113, 125, 64, 90, -79, 85]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 13, 11, "\udb25\udfd1\udabf\uddad\ud870\udc8a\udae1\udc85\uda1c\udfd1\udb60\udfd5\ud871\udd35\ud959\udd9b\ud896\udf89\ud82c\ude92\udb5c\ude80\udb9d\udfee\udb3e\udd75\ud83d\ude49\uda94\udc25\udaa3\ude1e\udba6\udeca\ud9dd\uddca\ua5a6\ud823\udd43\udb4a\udf22\ud94a\udc8a\udb7d\udc4a\ud906\ude39\ud94c\ude5d\udb56\udd89\uda05\udccb", "\u2b9f\u5a7a\u2709\ubb0b\ucc2d\u8b76\u0661\u20f4\u389a", "\ud935\ude07\udb3c\udfb0\uda80\udf24\ud83d\udeb2\ud94e\udf07\udbcb\ude11\udbdb\ude71",
        31, 79680, 197230414, 110445138057109906L, -2278L, true, false, (char) 38577, (char) 63875,
        Double.longBitsToDouble(0x3fed8f442503695eL), Double.longBitsToDouble(0x3fe9fa6112f25bc2L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Long:974 |a0=[B:[[-10, 44, -113, 125, 64, 90, -79, 85]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 11, "\udb26\udc5c\udabf\uddad\ud870\udc8a\udae1\udc85\uda1c\udfd1\udb60\udfd5\ud871\udd35\ud9c4\udc70\uda51\ude53\ud860\udc92\udb5c\ude80\udb9d\udfee\udb3e\udd75\ud958\udcec\udb30\udfa8\udaa3\ude1e\udb4c\udddd\ud9d8\ude25\ud8e2\udf4e\ud8d2\udeb0\udb4a\udf22\udbcc\uddca\udae6\ude4f\ud906\ude16\ud94c\ude5d\udb56\udd89\uda05\udccb", "\u2b9f", "\udba1\ude9d\udbe5\udf65",
        2, 31068, -419712320, -2644149276149595600L, -53430L, false, false, (char) 20928, (char) 43100,
        Double.longBitsToDouble(0x3fd4d1bc7ab63aa4L), Double.longBitsToDouble(0x3fe408610024cc18L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:1012 |a0=[B:[[-69, -92, -113, 125, 39, 92, -79, 85]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 8, 11, "\udaeb\udfd4\udabf\uddad\udb57\ude8c\udae1\udc85\uda7a\udfe0\udba5\udfe9\uda37\ude49\udbce\udc11\uda51\ude53\udb66\ude89\udb65\udd20\udb9d\udfee\udb3e\udd75\ud83d\ude49\uda94\udc25\udaa3\ude1e\ud84e\udf9e\ud9cc\udce8\ua586\ud823\udd43\udb4a\udf22\ud94a\udc8a\uda59\udd78\ud906\udd8f\ud94c\ude5d\udb56\udd89\uda2d\udfcb", "\u2b9f\u517a\u3acb\ub81b\ua2d0\u8b76\u0661\u20f4\u3cc0", "\udb93\uddbe\udb28\udd19\udb43\udf99\ud83d\udeb2\ud94e\udf07\udbcb\ude11\udbe0\udf71",
        40, 47900, 770322614, 2601934375397667842L, 50869L, true, true, (char) 15369, (char) 34534,
        Double.longBitsToDouble(0x3fedcf89364bc94fL), Double.longBitsToDouble(0x3fcb348314c28ae4L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Long:1090 |a0=[B:[[-11, -95, -113, 125, 64, 90, -79, 85]]\0121=java.lang.Boolean:false |a0=[B:[[-11, -95, -113, 125, 64, 90, -79, 85]]\012",
        Z.run(T, 2, 1, 14, 11, "\udb25\udfd1\udabf\uddad\ud870\udc8a\udae1\udc85\uda1c\udfd1\udb60\udfd5\ud871\udd35\ud9c4\ude70\uda51\ude53\ud860\udc92\udb5c\ude80\udb9d\udfee\udb3e\udd75\udacb\udd0f\uda55\udde4\udaa3\ude1e\udba6\udeca\ud9dd\uddca\ua5a6\ud823\udd43\udb4a\udf22\ud94a\udc8a\udb7d\udc4a\ud906\ude39\ud9be\ude56\udb56\udd89\uda05\udccb", "\u2b9f", "\ud956\uded8\udbe6\udc23",
        2, 31068, 1107014336, -8393222641208573310L, -53430L, false, false, (char) 20928, (char) 43100,
        Double.longBitsToDouble(0x3fd4d1bc7ab63aa4L), Double.longBitsToDouble(0x3fe408610124cc18L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:704 |a0=[B:[[-11, -65, -113, 125]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 10, 11, "\udb25\udfef\udabf\uddad", "\u6ca8\ua99a\u2773", "\ud860\udc92\udb5c\ude80\ud84e\udcc7\udb3e\udd49\ud83d\ude49\udb69\udea4\ud8a6\udd42\udba6\udeca\ud9dd\uddca\ua5a6\udb18\udf94\udacf\udc0c\ud8aa\udf27\udb7d\udc4a\udb7d\uded6\udb6a\uddaf\u30f6\uda05\udccb\udb5d\ude17",
        56, 44427, 1497269672, -3632844924451753044L, -50175L, false, false, (char) 32661, (char) 60244,
        Double.longBitsToDouble(0x3fe186da75285756L), Double.longBitsToDouble(0x3fd16a7f2051764eL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Long:1251 |a0=[B:[[-11, -95, -113, 125, 64, -5, -79, 85]]\0121=java.lang.Long:1251 |a0=[B:[[-11, -95, -113, 125, 64, -5, -79, 85]]\012",
        Z.run(T, 2, 1, 1, 11, "\udb25\udfd1\udabf\uddad\udb70\udc2b\udae1\udc85\uda1c\udfd1\udb60\udfd5\ud871\udd35\ud9c4\ude70\uda51\ude53\ud860\udc92\udb5c\ude80\udb9d\udfee\udb3e\udd75\ud83d\ude49\uda27\udd48\uda4f\udea2\ud9db\udcbb\ud9dd\uddca\ua5a6\ud80e\ude1e\ud8ef\udc00\ud94a\udc8a\ud8bd\udd0b\ud916\udd51\ud94c\ude5d\udb56\udd89\uda05\udccb", "\u2b9f", "\ud956\uded8\udbe6\udc23",
        2, 31068, -164121920, 3212741855530980590L, -53430L, false, false, (char) 20928, (char) 43100,
        Double.longBitsToDouble(0x3fd4d1bc7ab63aa4L), Double.longBitsToDouble(0x3fe4086100ca3818L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Long:1090 |a0=[B:[[-11, -95, -113, 125, 64, 90, -79, 85]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 15, 11, "\udb25\udfd1\udabf\uddad\ud870\udc8a\udae1\udc85\uda1c\udfd1\udb60\udfd5\ud871\udd35\ud9c4\ude70\uda51\ude53\ud860\udc92\udb5c\ude80\udb9d\udfee\udb3e\udd75\ud83d\ude49\uda94\udc25\udaa3\ude1e\udba6\udeca\ud9dd\uddca\ua5a6\ud823\udd43\udb4a\udf22\ud94a\udc8a\udb7d\udc4a\ud906\ude39\ud94c\ude5d\udb56\udd89\uda05\udccb", "\u2b9f", "\ud956\uded8\udbe6\udc23",
        2, 31068, 1107014336, -2644149276149595600L, -53430L, false, false, (char) 20928, (char) 43321,
        Double.longBitsToDouble(0x3fd5d7b3aab63b5cL), Double.longBitsToDouble(0x3fe408610024cc18L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Long:1090 |a0=[B:[[-11, -95, -113, 125, 64, 90, -79, 85]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 2, 14, "\udb25\udfd1\udabf\uddad\ud870\udc8a\udae1\udc85\uda1c\udfd1\udb60\udfd5\ud871\udd35\ud9b0\ude89\uda51\ude53\ud860\udc92\udb5c\ude80\ud82f\ude61\udb65\udfc8\ud83d\ude49\uda94\udc25\udaa3\ude1e\udba6\udeca\ud9dd\uddca\ua5a6\ud823\udd43\udb4a\udf22\ud94a\udc8a\udb7d\udc4a\ud906\ude39\ud9cb\udc7c\udb56\udd0c\uda59\udebc", "\u2b9f", "\ud956\uded8",
        29, 57007, -869231116, 4754590369018091582L, 75400L, false, false, (char) 25423, (char) 15225,
        Double.longBitsToDouble(0x3fb11865745ad4b0L), Double.longBitsToDouble(0x3fc32c8ff9a2618cL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Long:406 |a0=[B:[[-11, -95]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 4, 11, "\udb25\udfd1", "\u367c", "",
        33, 65576, 2822573, 0L, -34464L, false, true, (char) 45224, (char) 48211,
        Double.longBitsToDouble(0x3ecee00000000000L), Double.longBitsToDouble(0x3fba707281300000L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Long:208 |a0=[B:[[-48]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 14, "\000", "\u2d60\u8c48\ua99a\u61a0\u9b79\ua0b7\u2424\u6a96\u267f\u4cbb\u6a5c\u3900\uaf09\u3c2b\ub44b\uad5e\ub967\uacea\uc6fb\ud6e8\u3ae9\u2c45\u887c\u4326\u98be\u864e\u32b6\u0430\uc9f2\u5002\uad0b\u6bd9\ub0a8", "\udbb3\ude49\udb0f\udfaf\uda79\ude5a\uda84\ude85\udadd\udfbe\u5b3f\udb94\udf0a\uda95\udfb6\ud844\udd6f\ud90e\udd55\udaca\udcc1\uda6b\udc43\ud92c\udc09\ud899\udcbf\ud8df\udc31\uda4e\uddbd\uda1d\udf38\ud83c\ude40\uda52\udec8\udb94\udead\ud87e\udd41\ud8aa\udf54\ud8bb\udd5e\udbd6\udffa\udbec\udd64",
        48, 54240, -1982314709, 3060726941591182852L, 78830L, false, false, (char) 22961, (char) 12406,
        Double.longBitsToDouble(0x3fed9b774098ea26L), Double.longBitsToDouble(0x3fec29b9d8cbdbf1L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Long:277 |a0=[B:[[107, -86]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 9, "\ud89b\udeda", "\u2d60\u8c48\u1198\u2292\u9b79\ua0b7\u2424\u6a96\u267f\u4cbb\u6a5c\u0f5c\u9ea7\u3c2b\ub44b\uad5e\u72ae\ub4bc\uc6fb\ud6e8\u3ae9\u2c45\u887c\u430d\u98be\u864e\u32b6\u0430\uc9f2\u5002\u5557\u6c38\ub0a8", "\udbb3\ude49\udb0f\udfaf\uda79\ude5a\uda84\ude85\uda01\udd90\ub8f3\udb45\udc83\uda97\ude12\ud9f3\udf26\ud995\udf43\udbf2\udfa8\ud805\udd70\ud92a\udc47\udb15\udfc7\udb18\udf29\u6bf7\uda1d\udf38\ud83c\ude40\uda52\udec8\udb94\udead\ud87e\udd41\ud8aa\udf54\ud8bb\udd5e\ud92a\uddb4\udbec\udddb",
        48, 54240, -1982314709, 3060726941591182852L, 78830L, false, false, (char) 22961, (char) 12406,
        Double.longBitsToDouble(0x3fc66ddd0f5ddfd0L), Double.longBitsToDouble(0x3fec29b9d8cbdbf1L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-101, -72]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 0, 14, "\udbcb\udee8", "\u2d60\u20bc\ua99a\u6763\u76ab\u131d\000\000\000\ud057\u7538\u3fec\u8759\u0bad\u760a\u70a5\u18ae", "\udb7d\udc4a\ud906\ude39\udb49\udf84\udb56\udd6e",
        42, -1000, 10496, 8925852984471261568L, -78798L, false, false, (char) 21343, (char) 49013,
        Double.longBitsToDouble(0x3fefdef3489003aeL), Double.longBitsToDouble(0x3fe1ceda73281dffL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Long:627 |a0=[B:[[-128, 91, 115, 58, 70, 118, 45, 2]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 7, 14, "\udbb0\udf8b\udaa3\udd6a\udb76\udda6\ud85d\udc32\uda87\udf1c\ud9bb\udc77\ud910\udfb0", "\u24b3\u9907\u2fe3", "\ud84e\udf0d\ud918\udf0b\udb9a\udf24\ud8aa\udd3e\ud95d\ude19\u468f\udbc7\udd7f\udbf8\udea9\uda5f\udd78\ud928\ude58\ud9cb\udec4\ud86e\uddf6\ud9b8\udcb9\ud989\udf1c\uda6b\udf7d\ud80f\ude5d\uda61\udc34",
        14, -859, -774022453, 440881480642817884L, -45974L, false, false, (char) 45350, (char) 46220,
        Double.longBitsToDouble(0x3fc9a4a5d95f7c30L), Double.longBitsToDouble(0x3fe34a37fd0de266L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 0, "\udbcb\udeee\ud83e\udc4e\uda47\udda3\ud88f\udce8\ud8e6\udc6b\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda81\ude63\u8100\000\ud86e\udec5\ud93a\udc3c\uda88\udedc\udb4e\udf88", "\u5047\u389a\uacea\u1b14\ubc93\u5f3d\000", "",
        -5, -1000, 0, 35747322042254730L, 73348L, true, false, (char) 8391, (char) 3545,
        Double.longBitsToDouble(0x3fe01762e239e8e3L), Double.longBitsToDouble(0x3f70bfff57042080L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 7, 0, "\udb7a\udf46\udb72\udeba\udb70\udeea\ud877\udf4c\ud8a2\udd71\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\u80df\ud966\udec7\000\ud8da\udc0c\ud86f\udeae\uda3c\udfd8\udb1c\udf6d", "\ud3a6\u397f\uacea\u2c9c\ud78b\u5fe9", "",
        -5, -1000, 0, 8323072L, 26125L, false, false, (char) 50405, (char) 48911,
        Double.longBitsToDouble(0x3fe1cf4581b25cffL), Double.longBitsToDouble(0x3fe57662d9888be9L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=void\012",
        Z.run(T, 2, 13, 5, 1, "\ud9f3\udceb\ud83e\udc6d\ud811\udc8b\ud88f\udce8\ud889\udcf9\udb60\udf1c\ud85c\uddfd", "\u1d51\u1cb6\000\u4c28\u8cbd\u770d\uaf09\u3c2b\u105e", "\ud896\udcb2\ud945\udd6b\udb80\udfed\udbf1\udeda\ud17c\000\000\000",
        -5, -1000, 0, 6091839425024L, -28299L, false, true, (char) 19131, (char) 9843,
        Double.longBitsToDouble(0x3fe6c73d80815e8dL), Double.longBitsToDouble(0x3fe6344a10a06cd5L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-101, -72, 14, 30, 23, 115, 95, -72]]\0121=void |a1=[B:[[-101, -72, 14, 30, 23, 115, 95, -72]]\012",
        Z.run(T, 2, 13, 5, 1, "\udbcb\udee8\ud83e\udc4e\uda47\udda3\ud88f\udce8\u5bab\udb60\udf1c\u5af1\udae5\udd12\ud810\udea2\uda81\ude63\ud8fa\udde4\000\ud84d\udec5\000", "\u3c2b\u105e\u2bcc\u69b8\u6e73\u2c9c\u5f59\ub7b6\ud17c\000\000\000\000", "",
        3, -1000, -774022436, 408021951744L, -26972L, true, true, (char) 26906, (char) 19131,
        Double.longBitsToDouble(0x3fbac00016c73d80L), Double.longBitsToDouble(0x3fcb0bd1a31a2734L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-35, 58, -54, 56, -1, -56, -66, -73]]\0121=java.lang.Boolean:false |a0=[B:[[-35, 58, -54, 56, -1, -56, -66, -73]]\012",
        Z.run(T, 2, 14, 14, 4, "\ud90d\udc6a\udafa\udf68\udb2f\uddf8\udbee\udee7\ud924\udc12\u0da1\udb00\udfe8\udaf3\ude9a\udac1\uddd9\uda2d\udcf9\u80da\ud963\udfd6\udb02\udde4\uda7f\uddb4\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u4e06\u4f34\u78b6\ud698\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b4\udd79\udaaa\udf81\uda21\uddd8",
        1, 9855, 777938092, -5820899499629971492L, -92280L, false, false, (char) 25524, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fd5b1ad75bb3006L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-39, 0, -93, 73, 78, -60, 95, -72]]\0121=java.lang.Long:0 |a0=[B:[[-39, 0, -93, 73, 78, -60, 95, -72]]\012",
        Z.run(T, 2, 14, 0, 4, "\uda09\udd30\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda2d\udcf9\u80da\ud963\udfd6\udb02\udde4\uda7f\uddb4\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u90ad\u3f59\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\uda21\uddd8",
        1, 5383, -857414228, 265364910250006590L, -14200L, false, false, (char) 25462, (char) 21280,
        Double.longBitsToDouble(0x3fe59e9b014d3573L), Double.longBitsToDouble(0x3fd5b1ad75bb3006L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Long:234 |a0=[B:[[97, -119]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 5, 11, "\uda91\udcb9", "\030", "\ud85a\udf0c",
        31, 94573, 38441, 0L, -81858L, true, false, (char) 48211, (char) 247,
        Double.longBitsToDouble(0x3fec7c2bd869b2feL), Double.longBitsToDouble(0x3fa3614fd0382290L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 12, 5, "\ud89b\udeda", "\u2d60\u8c48\u1198\u2292\u9b79\ua0b7\u2424\u6a96\u267f\u4cbb\u6a5c\u0f5c\u9ea7\u3c2b\u29af\u7b75\u72b3\ub4bc\uc6fb\ud6e8\u3ae9\u2c45\u887c\u430d\u98be\u864e\u32b6\u0430\uc9f2\u5002\u5557\u6c38\ub0a8", "\udbb3\ude49\udb0f\udfaf\uda79\ude5a\uda84\ude85\uda01\udd90\ub8f3",
        3, 57328, -485396392, -3011771556961557028L, 60240L, false, true, (char) 57193, (char) 34899,
        Double.longBitsToDouble(0x3fb3faa6649730f8L), Double.longBitsToDouble(0x3fd5267a909f7604L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[49, -35]]\0121=java.lang.Long:0 |a0=[B:[[49, -35]]\012",
        Z.run(T, 2, 13, 13, 7, "\ud961\ude0d", "\u2d60\ua5bb\ua99a\u6763\u76ab\u131d\000\000\u2517\uc253\ubce6\u3fec\u8759\u0bad\u760a\u70a5\u18ae", "\udb7d\udc4a\ud906\ude39\udb49\udf84\ue71f",
        32, -1000, 10496, 8925852984471261568L, -78798L, false, false, (char) 33798, (char) 48994,
        Double.longBitsToDouble(0x3fefdef3489003aeL), Double.longBitsToDouble(0x3fe1ceda73281dffL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-39, 0, -93, 73, 78, -60, 95, -72]]\0121=java.lang.Long:0 |a0=[B:[[-39, 0, -93, 73, 78, -60, 95, -72]]\012",
        Z.run(T, 2, 0, 0, 4, "\uda09\udd30\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda2d\udcf9\u80da\ud963\udfd6\udb02\udde4j\000\ud8f2\udf98", "\000\u9087\u3f59\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\uda21\uddd8",
        1, 5383, -857414228, 265364910250006590L, -14200L, false, false, (char) 25462, (char) 21280,
        Double.longBitsToDouble(0x3fe59e9b014d3573L), Double.longBitsToDouble(0x3fd5b1ad75bb3006L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[26, 32, 113, 104, 78, -60, 95, -72]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 4, "\ud84a\udc50\udaa1\udf98\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\uda2d\udcf9\u80da\ud963\udfd6\udb02\udde4\uda7f\uddb4\ud88a\udf1d\uda7b\udfc1", "\uc2a5\u90ad\u3f59\u2c9c\ud78b\u3ae9\u2cd9", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\uda21\uddd8",
        1, 39255, -85726576, 234663723808987198L, -14200L, false, false, (char) 25462, (char) 21280,
        Double.longBitsToDouble(0x3fe59e9b014d3573L), Double.longBitsToDouble(0x3fd5b1ad75bb3006L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 14, 5, "\ud89b\udeda", "\u2d60\u8c48\u1198\u2292\u9b79\u2a33\u5f7a\u6a96\u267f\u4cbb\u7491\u0f5c\u53c0\u3c2b\u29af\u7b75\ubcab\ub4bc\uc6fb\ud6e8\u3ae9\u2c45\u887c\u430d\u98be\u864e\u32f4\u00a5\u7981\u5002\u5557\u6c38\ub0a8", "\udba3\udd49\ud82d\udfbe\ud801\udf7d\udb29\udd40\ud87c\udfcd\ub8f3",
        0, 54142, -485396392, -3011771556961557028L, 60240L, false, true, (char) 57193, (char) 34899,
        Double.longBitsToDouble(0x3fb3faa6679d9d20L), Double.longBitsToDouble(0x3fd5267a909f8c04L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Long:277 |a0=[B:[[107, -86]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 8, 5, "\ud89b\udeda", "\u2d60\uce19\u50af\u2292\u3d1b\u9cb1\u24aa\u8601\u267f\u4cbb\u6a5c\u0f5c\u9ea7\u3c2b\u29af\u7b75\u72b3\ub4bc\uc6fb\ud6e8\u3ae9\u2c45\u887c\u430d\u98be\u864e\u32b6\u0430\uc9f2\u5002\u5557\u6c38\ub0a8", "\udbb3\ude49\udb0f\udfaf\uda79\ude5a\uda84\ude85\uda01\udd90\ub8f3",
        3, 57328, -485396392, -3011771556961557028L, 60123L, false, true, (char) 57193, (char) 34899,
        Double.longBitsToDouble(0x3fb3c0d3e49730f8L), Double.longBitsToDouble(0x3fd5267a909f7604L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[111, -36]]\0121=java.lang.Long:0 |a0=[B:[[111, -36]]\012",
        Z.run(T, 2, 13, 13, 7, "\uda9f\ude0c", "\u2d60\ua5bb\ua99a\u6763\u76ab\u13d8\000\000\u2517\uc253\ubce6\u3fec\u8759\u0bad\u760a\u70a5\u18ae", "\udb7d\udc4a\ud906\ude39\udb49\udf84\ue71f",
        32, -1000, -1885853440, 8925852984471261568L, -16042L, true, true, (char) 41572, (char) 49981,
        Double.longBitsToDouble(0x3fe1ceddf3281dffL), Double.longBitsToDouble(0x3fdea2bf29de971eL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Long:277 |a0=[B:[[107, -86]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 8, 5, "\ud89b\udeda", "\u2d94\uce19\u50af\u2292\u3b5d\u2726\u24aa\u029b\u267f\u4cbb\u6a5c\u0f5c\u9ea7\u3c2b\u29af\u7b75\u72b3\ub4bc\uc6fb\ud6e8\u3ae9\ua484\u887c\u430d\u98be\u322f\u467f\u0430\uc9f2\u5002\u5557\u6c38\ub0a8", "\udbb3\ude49\udb0f\udfaf\ud803\ude14\uda4d\udd85\uda01\udd90\ud9fe\udda2",
        4, 35871, -670683206, 7839424949439587835L, 62956L, false, true, (char) 57193, (char) 34899,
        Double.longBitsToDouble(0x3fb3c0d3e49730f8L), Double.longBitsToDouble(0x3fd9567a909f7604L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 2, 14, "\udbcb\udee8\ud9d3\udc79\uda7e\udef4\ud88f\udce8\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\ud857\udcae\ud9b9\udcd0\ud965\udfea\ud86e\udf58\ud958\udcb1\ud8e6\udf2b\udb8a\udd64", "\uc2a5\u18ae\uacea\u2c9c\ud78b\u3ae9\u2c45", "\udb4b\uddb0\uda6b\udf7d\ud9c2\ude35\ud8b6\ude79\udaaa\udf81\ud92e\uddfe",
        29, 83063, -857414280, 265364910250006590L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fa600292dd98030L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Integer:-360 |a1=[B:[[117, 126, -107, -99, 91, -71, 21]]\0121=java.lang.Integer:-360 |a1=[B:[[117, 126, -107, -99, 91, -71, 21]]\012",
        Z.run(T, 2, 8, 8, 8, "\udbcb\udee8\ud9a9\udf1c\ud91c\ude48\ud88f\udce8\udba5\udd48\udb60\udfd5\udb06\udce8\ud893\udd52\ud934\udcdb\ud898\udf47\ud925\udc71\ud96f\udcea\ud86e\udf58\ud958\udcb1\ud96b\udf86\udb8a\udd64", "\uc2a5\u18ae\u30c5\ub2cd\ud78b\u3ae9\u2c45", "\uda78\ude27\udbfa\udf4a\udb03\udd2a\ud8b6\ude26\udaaa\udf81\ud92e\uddfe",
        5, -365, -387652180, 6560216958070822974L, -89139L, true, true, (char) 37464, (char) 27360,
        Double.longBitsToDouble(0x3fde3cd8a9ef96d2L), Double.longBitsToDouble(0x3fd55b7d53442df8L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 3, 0, "\udb7a\udf46\ud8c7\udc84\udb70\udeea\ud877\udf4c\uda66\udd73\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ud810\udea2\u1cdf\ud966\udec7\udb96\udd8b\ud96a\udf7f\ud86f\udeae\uda3c\udfd8\udb1c\udf6d", "\ud3a6\u397f\uacea\u2c9c\ub002\u4d22", "\000",
        -5, -1000, 0, 35747321967694730L, 12890L, false, true, (char) 29701, (char) 10986,
        Double.longBitsToDouble(0x3fdb25cffd5d02b6L), Double.longBitsToDouble(0x3fd888be966f7026L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=void |a1=[B:[[86, 108, -9, 94, -78, 117, 116, -104]]\0121=void |a1=[B:[[86, 108, -9, 94, -78, 117, 116, -104]]\012",
        Z.run(T, 2, 5, 5, 1, "\uda86\udf9c\udb27\udd8e\udbe2\udca5\ud8a4\uddc8\u5bab\udb60\udf1c\ud8ed\udd2b\udaed\udc7d\ud810\udea2\uda81\ude63", "\u6402\u4728\uac0e\uc856", "\udb90\uddcb\ud8ad\udd42\ud896\udcb2\ud945\udd6b\udb80\udfed\udbf1\udeda\ud17c",
        -5, -1000, 40448, -1577058304L, 73348L, true, true, (char) 14080, (char) 11916,
        Double.longBitsToDouble(0x3fe5e7e46a51294eL), Double.longBitsToDouble(0x3fe12b07e295aad8L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[55, 1, -83, -108, 61, -101, 95, -15]]\0121=java.lang.Boolean:true |a0=[B:[[55, 1, -83, -108, 61, -101, 95, -15]]\012",
        Z.run(T, 2, 14, 14, 14, "\uda67\udd31\ud9dd\udfc4\uda6d\udccb\ud88f\udd21\uda09\udf3d\udb60\udfd5\ud871\uddfd\udaf3\ude9a\ue737\ud855\uddaf\ud995\udc9f\ud962\udd15\ud9f1\udd3e\uda64\udcda\ud8e7\udc2c\udb8a\udd64", "\u7383\u18ae\uacea\u1455\ud78b\u3ae9\u2c45", "\uda31\udd83\udb11\uddf1\ud9c2\ude5a\udb6c\udf6f\udaaa\udf81\uda21\udd18",
        1, 5383, -1763383892, 265383790926239806L, 3208L, false, false, (char) 25462, (char) 20928,
        Double.longBitsToDouble(0x3fd5dd34d29a378eL), Double.longBitsToDouble(0x3fddf3f095bb3006L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 7, 0, "\udb7a\udf46\udb72\udf63\udb70\udeea\ud877\udf4c\ud8a2\udd71\udb09\udfb7\uda28\ude27\udaf1\ude99\ud810\udf1d\u80df\ud966\udec7\ud8c1\udd86\ud81a\udcfa\ud848\udf05\uda3c\udfd8\udb1c\udf6d", "\ud3a6\u2e8b\ud219\u2c9c\ud78b\u5fe9", "\022",
        -5, -1000, 0, 35747321967694730L, 12844L, false, true, (char) 48911, (char) 33169,
        Double.longBitsToDouble(0x3fdb25cffbd6112cL), Double.longBitsToDouble(0x3fd92e6cc663adb2L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|computeCheckSum|[B|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|exceptionMessage|[B,int,int,int,byte|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatBigIntegerBinary|long,[B,int,int,boolean|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatCheckSumOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongBinary|long,[B,int,int,boolean|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongOctalOrBinaryBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatNameBytes|java.lang.String,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatNameBytes|java.lang.String,[B,int,int,org.apache.commons.compress.archivers.zip.ZipEncoding|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatUnsignedOctalString|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseBinaryBigInteger|[B,int,int,boolean|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseBinaryLong|[B,int,int,boolean|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseBoolean|[B,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseName|[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
