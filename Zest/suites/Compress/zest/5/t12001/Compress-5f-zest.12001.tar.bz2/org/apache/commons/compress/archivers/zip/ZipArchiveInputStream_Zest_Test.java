package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 5, 10, 11, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud97f\udf36\ud862\udf2d", "\u71c6\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u72c6\u7294\u860f\u9783", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 78797, 800719449, -3934216517876067412L, 81865L, false, false, (char) 30897, (char) 2625,
        Double.longBitsToDouble(0x3fe4cfc5888e9bddL), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 5, 10, 11, "\ud98d\udd8c\ud935\udf99\udac3\udf2d\ud9f8\udebe\uda9c\udeaf\ud9da\udd91\ud919\udff0\ud97f\udf9a\ud862\udf2d", "\u71c6\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u72c6\u7294\u2794\u1414", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 78797, 800719449, -3934216517876067412L, 81865L, false, false, (char) 30897, (char) 2625,
        Double.longBitsToDouble(0x3fe4cfc5888e9bddL), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[104, -68, 57, -61, -45, -46, -96, -32]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 10, 11, "\ud998\udfec\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud97f\udf36\ud862\udf2d", "\u71c6\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u79c6\u7294\u860f\u9783", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\udbf9\udf33",
        55, 78797, 800719449, -3934216517876067412L, 81865L, false, false, (char) 30897, (char) 2625,
        Double.longBitsToDouble(0x3fba7e2c4474deb0L), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 5, 10, 3, "\udb83\udfe7\ud94e\udd02\uda93\udd30\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud97f\udf36\ud862\udf2d", "\u71c6\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u72c6\u7294\u860f\u9783", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 78797, -1194340217, -3934216517876067412L, 81865L, false, false, (char) 64696, (char) 2625,
        Double.longBitsToDouble(0x3fe4cfc5888e9bddL), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[93, 92, 57, -61, -45, -46, -96, -32]] |a1=[B:[[-106, 91, 21, -55, -22, 105, 0, -106]]\012",
        Z.run(T, 1, 1, 10, 11, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\uddf9\udb84\ude07\ud97f\udf36\ud862\udf2d", "\u71c6\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u72c6\u7294\u860f\u9783", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 78797, 800719449, -3934216517876067412L, 81865L, false, false, (char) 30897, (char) 2625,
        Double.longBitsToDouble(0x3fe4cfc5888e9bddL), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 9, 4, 0, "\ud98d\udd8c\udac1\udd1f\ud803\udd02\ud93e\udddb\uda42\udc13\u917d\udb56\udf65\ud97f\udf4c\ud862\udf2d\ud986\udd32\udbe4\udc85\udad2\udcd5\udbb3\udf08\ud872\udf61", "\u1399", "\udbe1\ude34\ud840\udf0c\ud902\udc33\ud93f\udeb6\udabf\ude51\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32\ud8c4\udebe\udb55\udca3\ud8fc\udd94\ud907\udfb4\udbc2\uddb2\u34b8\uda2f\uddbc\uf858\udbcb\udc8d\u15cf\uda76\udf37\uda9c\udd6b\ud9f2\udf15\ud960\udd82\udba1\udd03\udaea\udf3c\udbb0\udda6\ud9a1\udf75\udbb2\udf3f\udaa6\udeda\ud8d8\udfd5\ud861\ude75\ud986\uddc4\udad2\udd58\u2dcf\udbcc\udf44",
        -3, 87944, 1352402232, 3189428908069488662L, 29332L, false, false, (char) 47126, (char) 38072,
        Double.longBitsToDouble(0x3fb1e593d1c0a288L), Double.longBitsToDouble(0x3fc6bb66aabb3f20L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 2, 10, 11, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud80a\ude24\ud862\udf2d", "\u71c6\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u30e3\u0adb\ua5f2\u28b7", "\ud8c8\ude4c",
        25, 96761, 477157509, 2623312378717728757L, 87116L, false, true, (char) 46705, (char) 29075,
        Double.longBitsToDouble(0x3fe3aac9847084aaL), Double.longBitsToDouble(0x3fe5e00fe669780aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 1, 11, 10, 0, "\ud98d\udd8c\ud969\udef3\udbd2\udc60\udafc\udec0\uda9c\udeaf\uda64\udcc0\udb84\ude07\ud97f\udf36\uda31\udf36\ud91b\udc84\udbe4\udcf1\udae4\uded5", "\ucbf9\uc01a\u1399\ud6e5\u02d6\ud1b5\u85b0\u9783\u0f9f\u58a1\u16e2\u6dff\u57fe\u423a", "\uda95\ude8e\udb65\udf58\udbaa\ude93\uda76\uddac\uda0b\ude21\ud92a\udf30\udbcb\udc8d\u15cf\uda76\udeab\udb29\udd75\ud983\ude93",
        44, 22386, -862136178, 6681222817508237830L, 48263L, true, true, (char) 65300, (char) 13905,
        Double.longBitsToDouble(0x3fe6e59437fe0d72L), Double.longBitsToDouble(0x3fdf28230ef4b9b4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 8, 11, "\ud98d\udd8c\ud969\udef3", "\ub273\uae80\u749d", "\ud986\udd32\udbe4\udc85\udae4\uded5\udbb3\udf08\ud872\udf61\udbb8\udffc\ud9af\ude7e",
        32, 6818, 2055276121, -4838503427636223808L, 9531L, true, false, (char) 32914, (char) 39662,
        Double.longBitsToDouble(0x3fc1268d621426acL), Double.longBitsToDouble(0x3fc6c38e1fd4919cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 10, 10, 11, "\uaf7b\uda4e\uddb7\ud803\udd02\ud9d0\udcf5\uda9c\udeaf\ud9da\udd91\udb84\ude07\uda2e\ude8e\ud81e\ude78", "\u71c6\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u72c6\u7294\u860f\u5918", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 78797, 800719449, -4893483238505815757L, 81865L, false, false, (char) 38065, (char) 32190,
        Double.longBitsToDouble(0x3fe72f20108e50f4L), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 4, 10, 11, "\000\000\uf53d\ud9d0\udd10\ud814\udeab\ud9da\udd91\udb84\ude07\ud97f\udf36\u00ab", "", "\ud872\udf61",
        5, -568, -2138418518, -936748722659195261L, -75616L, true, false, (char) 49293, (char) 24924,
        Double.longBitsToDouble(0x3fe318017f0e6be0L), Double.longBitsToDouble(0x3fc1268d62142400L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 10, 11, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud875\ude9f\udb63\udf7e\ud97f\udf36\ud862\udf2d", "\u71c6\uc18b\u3345\ub86b\uc02d\ud719\u02f6\u1f13\u7294\u860f\u9783", "\udac1\udd04\udb3a\udf08\udb65\udd1a\ud812\ude32",
        55, 51997, 895649076, -3934219343964548180L, -39383L, true, false, (char) 49434, (char) 30904,
        Double.longBitsToDouble(0x3fe34bc0568ac08aL), Double.longBitsToDouble(0x3fc55300e24f66b4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[93, 92, 57, -61, -45, -46, -96, -32]]\012",
        Z.run(T, 1, 7, 10, 11, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud97f\udf36\ud862\udf2d", "\u71c6\uc18b\u5745\uace9\ub433\u4194\ubcd0\u72c6\u7294\u860f\u9783", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 78797, 800719449, -3934216517876067412L, 81865L, false, false, (char) 63872, (char) 2625,
        Double.longBitsToDouble(0x3fe4cfc5888e9bddL), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 10, 2, 8, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9c0\uddc4\ud9ee\udcf3\u040f", "\u8f3b\u17ac\u98ff\u07e5", "\udbb8\udffc\ud9b7\udfb7\ud80e\udf27\ud937\uddd3\uda57\udded\udbe1\ude7d\ud840\udf0c\ud99a\udc20\udab1\udec6\udb2f\ude79\ud9f8\udcbe",
        25, 68609, 477157466, 2623312378998664946L, 11795L, false, true, (char) 37857, (char) 51284,
        Double.longBitsToDouble(0x3febaac9847003fcL), Double.longBitsToDouble(0x3fecac8fe36f67bcL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[112, 121, 17, -118, 28, 124, 108, 103]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 0, 4, 1, "\ud9a0\udda9\ud141\ud8ba\udc4c\u47ac\uda9c\ude97\ud9da\udd91\udb84\ude07\uda6c\udc8d\ud862\udf50", "\u71c6\uc18b\u5745\ucbf9\uc01a\ubd60\uc42a\u72c6\u7294\u860f\u9783", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 78797, 800719449, -3934216517876067412L, 44269L, true, false, (char) 37553, (char) 63252,
        Double.longBitsToDouble(0x3fc55300e24f66b4L), Double.longBitsToDouble(0x3fe4cfc5888e9bddL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 9, 10, 3, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud88d\udc3a\udb84\ude71\ud8a4\udf09", "\u47b8\u71c6\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u72c6", "\ud902\udc33\ud8ee\udcdc\ud8c9\udd01",
        55, 31630, 162202761, 2049375896806613174L, 30471L, false, false, (char) 40210, (char) 46705,
        Double.longBitsToDouble(0x3fe3dff5aa755930L), Double.longBitsToDouble(0x3fbc212ab5e00fe0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 10, 11, "\ud998\udfec\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud97f\udf36\ud862\udf2d", "\u714b\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u79c6\u7294\u860f\u9783\u0f9f\u03cf\ub23e\u6d2e\u57fe", "\ud978\udd33\u8529",
        26, 2060, -2137243962, 6426822011207209589L, 61468L, true, false, (char) 63252, (char) 30897,
        Double.longBitsToDouble(0x3fc27b35a1a7e2c4L), Double.longBitsToDouble(0x3fc1d37ac3073270L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[104, -68, 57, -61]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 2, 7, "\ud998\udfec\ud969\udef3", "\ub273\uae80\u749d", "\ud971\udd7b\udbe4\udc85\udae4\uded5\udbb3\udf08\ud872\udf61\uda85\udc02\ud96e\udd3d\ud80e\udf24\ud8e6\ude8a\ud89c\udc2c\udbe1\ude34\ud840\udf0c\ud902\udc33\ud8ee\udcdc\ud8c9\udd01\ud82d\ude53\udacd\udc4b\udb65\udd1a\uc4a2\ud8b9\uddb7",
        32, 91584, -916006164, -2412289290620315668L, -22805L, false, false, (char) 30904, (char) 15987,
        Double.longBitsToDouble(0x3fe4560450aa9807L), Double.longBitsToDouble(0x3fc27b35a1a7e2c4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 10, 11, "\ud998\udfec", "\u18b7\ub273\uae80\u749d\ud594\u8f8f\u28cf\u47b8\u71c6\uc18b\u5745\ucbf9", "\ud937\uddd3\uda59\udced\udbe1\ude34\ud840\udf0c\ud902\udc33\ud8ee\udcdc\ud8c9\udd01\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\udbf9\udf33\ud8c4\udedb\ud96e\ude8e\u8529\ud907\udfb4\udbc2\uddb2\udabd\udcaf\uda2f\uddbc\ud813\udd03\ud92a\ude0b\udbf5\udf0d\uda76\udeab\ud98c\udc69\udb73\ude67\udaa4\udfd0",
        23, 99822, -1363642175, -2782273919673473191L, -46359L, true, true, (char) 11559, (char) 50448,
        Double.longBitsToDouble(0x3fe2c39987e565b9L), Double.longBitsToDouble(0x3fdf96154cb89812L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[58, 53, -8, -82]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 2, 11, "\uda6a\udf65\ud928\udede", "\ub273\uae80\u99a7\u49b5\u442b\u441d\u5a36\u3f90\ub431\u5745\u4461\u316b", "\ud9aa\uddfa",
        1, 53712, 347291387, -7240771194855214009L, -57162L, false, false, (char) 40447, (char) 16478,
        Double.longBitsToDouble(0x3fdbe10406360538L), Double.longBitsToDouble(0x3fe7648729d6b066L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[104, -68, -43, -126, -45, -46, 45, -53]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 10, 11, "\ud998\udfec\uda05\udeb2\ud803\udd02\udb5d\uddfb\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud97f\udf36\ud862\udf2d", "\u82a9\uc1cd\u5745\ucbf9\uc01a\u1399\u7030\u79c6\u7294\u860f\u9783", "\ud9f8\udcbe\ud9d5\udfb5\udad4\ude69\udbf9\udf33",
        55, 78797, 800719449, -3934216517876067412L, 81865L, false, false, (char) 30897, (char) 2625,
        Double.longBitsToDouble(0x3fba7e2c4474deb0L), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 3, 10, 11, "\ud998\udfec\ud838\udf5b\ud8da\udd2e\ud9d0\udd10\udb18\udead\ud9da\udd91\udb84\ude07\ud97f\udf36\ud862\udf2d", "\ucf9a\uc4f4\u55a9\uc4f4\uc01a\u7e90\uae75\u79c6\u7294\u7572\ub608", "\ud9c6\udf5d\udb3a\ude24\udb65\udd1a",
        25, 39510, -1537544203, 3439063845810133740L, 64039L, true, false, (char) 21706, (char) 30058,
        Double.longBitsToDouble(0x3fe4560450aa9807L), Double.longBitsToDouble(0x3fc27b35a1a7e2c4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 3, 4, 11, "\ud998\udfec\ud969\udef3\ud803\udd02\ud9d0\udd10\udb9f\uddab\ud9da\udd91\udb84\ude07\ud97f\udf36\ud862\udf2d", "\ua6e3\uacfd\u571a", "\u596a",
        22, 59783, 249840392, 4412297005479706132L, 68620L, false, false, (char) 5212, (char) 42675,
        Double.longBitsToDouble(0x3fb695ae9d664b30L), Double.longBitsToDouble(0x3fc5ba58adef27b0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 10, 11, "\ud998\udfec\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud97f\udf36\udbc0\ude3c", "\u71c6\uc18b\u5745\u6903\u46a5\u1399\u7030\u79c6", "\ud902\udc33\ud8ee\udcdc\ud8c9\udd01",
        55, 31630, 162202761, 2058546923293892790L, 30471L, false, false, (char) 40210, (char) 46705,
        Double.longBitsToDouble(0x3fbef24613aac980L), Double.longBitsToDouble(0x3fbc212a89de5800L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[83, -73, 30, -46, 99, 0, -96, -32]] |a1=[B:[[83, 110, 21, 8, -100, 105, 0, -106]]\012",
        Z.run(T, 1, 1, 10, 3, "\udb83\udfe7\ud94e\udd02\uda93\udd30\ud9d0\udd10\uda9c\udeaf\ud8ac\udf75\ud839\udd13\ud97f\udf36\udafe\udf65", "\u3b83\ubd9e\u5745\ua038\ubfcc\u1399\u7030\u72c6\u01b1\u6a30\u8354", "\uda09\udcba\udb3a\ude24\udb65\udd1a\ud812\ude32\ud8c4\udedb",
        47, 84783, -916006164, -2412289290620315668L, 84949L, false, true, (char) 41871, (char) 15987,
        Double.longBitsToDouble(0x3fe4560450b21c07L), Double.longBitsToDouble(0x3fc27b35aa67e2c4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[83, -73, 30, -46, 99, 0, -96, -32]] |a1=[B:[[91]]\0121=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 9, 7, "\udb83\udfe7\ud94e\udd02\uda93\udd30\ud9d0\udd10\udb99\udded\uda73\uddc2\udb84\ude07\ud97f\udf36\uda48\udea1\ube66", "\uc18b", "\ud9af\ude7e\ud80e\udf27\ud937\uddd3",
        37, 2002, 1966842048, 1159380442220841562L, -83138L, false, true, (char) 25999, (char) 64385,
        Double.longBitsToDouble(0x3fc0ef99abb2e33cL), Double.longBitsToDouble(0x3fed65d577ecde85L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[81, 28, 96, -9, -119, -96, -32, 118]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[81, 28, 96, -9, -119, -96, -32, 118]]\012",
        Z.run(T, 2, 0, 7, 5, "\ud981\ude4c\ud890\ude27\u81b9\ud9d0\udd10\ud8a6\udc54\u60f9\udb61\udf3b\ud97f\udf36\ud802\udcfd", "\uc964\uc18b", "\ud8b4\udeab\uda7d\udf1d\udaa0\udc37\uda57\udded\ud86d\udd2a\ud840\udee6\ud902\udc33\ud8ee\udcdc\ud9f4\udf35\udb2a\ude70\udb3a\ude24\udb65\udd1a",
        44, 45630, 1966628876, -83769990995824598L, 84949L, true, true, (char) 64794, (char) 46033,
        Double.longBitsToDouble(0x3fe45600c0aa9807L), Double.longBitsToDouble(0x3fc27b35aa67e2c4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 10, 10, 2, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\udad6\ude8d\ud9da\uddf9\udb84\ude07\ud97f\udf36\ud952\udd33", "\u02a9\ua31e\u5745\ucbf9\uc01a\u1399\u7030\u1b97\u7294\u27d4\u3a75", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud9a9\udc5d",
        38, 78797, 800719449, -3934216515746999380L, 74322L, true, false, (char) 49434, (char) 30904,
        Double.longBitsToDouble(0x3fe34bc0568ac08aL), Double.longBitsToDouble(0x3fc55300fbc44ca4L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 10, 0, "", "\u911f", "\u00e7\000\ud97f\udec6\ud862\udf2d\ud986\udd32\udbe4\udc85\udae4\uded5\udbb3\udf08\ud872\udf61\u008c\ud9af\ude7e\u00aa",
        55, 11907, -1126550998, -6972802851223371776L, -44571L, false, false, (char) 5212, (char) 42675,
        Double.longBitsToDouble(0x3fe7617dd3acc966L), Double.longBitsToDouble(0x3fef66f4287bc918L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 9, 4, 0, "\ud98d\udd8c\udac1\udd1f\ud803\udd02\ud93e\udddb\uda42\udc13\u917d\udb56\udf65\ud97f\udf4c\ud862\udf2d\ud986\udd32\udbe4\udc85\udad2\udcd5\udbb3\udf08\ud872\udf61", "\u1399", "\udbe1\ude34\ud840\udf0c\ud902\udc33\ud93f\udeb6\uda00\udc12\000\udb3a\ude24\udb65\udd1a\ud812\ude32\ud8c4\udebe\udb55\udca3\ud8fc\udd94\ud907\udfb4\udbc2\uddb2\u34b8\uda2f\uddbc\uf858\udbcb\udc8d\u15cf\uda76\udf37\uda9c\udd6b\ud9f2\udf15\ud960\udd82\udba1\udd03\udaea\udf3c\udbb0\udda6\ud9a1\udf75\udbb2\udf3f\uda07\udeab\ud8d8\udfd5\udb14\udcee\000\udad2\udd58\u2dcf\udbcc\udf44",
        -3, 87944, 56, 0L, 29332L, false, false, (char) 47126, (char) 38072,
        Double.longBitsToDouble(0x3fb1e593d1c0a288L), Double.longBitsToDouble(0x3fc6bb66aabb3f20L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 2, 11, "\ud98d\udd8c\ud8c7\udc56\ud83c\uddcb\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\ud9d0\ude0d\ud80a\ude24\ud862\udf2d\ud986\udd32\udbe4\udc85\u1387", "\ucbf9\uc01a\u13b9\u7030\u30e3\ua36f\u588b\u5ba0\u7c31\u166a\u303d\u744a\u57fe\u423a\ud3db\uab56\u4868\u1e8c\ua19f\uae53", "\udbf0\udda4\u15cf\ud8c0\uddcf\ud904\uddcd",
        47, 72943, 835394173, -4390746668409180630L, -9432L, true, false, (char) 52604, (char) 54567,
        Double.longBitsToDouble(0x3fe12aae4e934b61L), Double.longBitsToDouble(0x3fe308c4826a45ccL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[93, 92, 57, -61, -45, -46, -96, -32]]\012",
        Z.run(T, 1, 7, 10, 11, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud80a\ude24\ud862\udf2d", "\u71c6\uc18b\ub445\ub60b\u797c\u823c\u706d\u30e3\u0adb\ua5f2\u28b7", "\ud8c8\udd82\udb3a\ude24\udb65\udd1a\ud812\ude32\ud8c4\udedb\ud96e\ude8e",
        2, 62836, -561654868, -3956174862536365957L, 81865L, true, true, (char) 5598, (char) 5010,
        Double.longBitsToDouble(0x3feb2f1f82a7c0f0L), Double.longBitsToDouble(0x3fdede06602db900L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 11, 7, 3, "\ud8fc\udea3\udb67\uddac\ud966\udec0\uda13\udf05\udb81\uddd0\ud88d\udd50\udb84\ude07\udb10\ude67\udac2\udcf5", "\u1f7d\ucc40\u8bad\u51cc\ua5f3\u1399", "\uda7c\udd9f\u0ed8\udbbc\ude15\uda83\udcd7\udbdc\ude6a\udb13\udc24\udb3a\ude33\udb65\udd1a\ud812\ude32\ud8c4\udedb\ud96e\ude8e\ud826\udfac\udb64\ude78\udbc2\uddb2\udabd\udcaf\uda2f\uddbc\uda2e\udf2f\udbcb\udc8d\u15c9\ud8ea\udda5\ud939\ude1e\ud97c\udca7\udb69\ude11\uda52\udd0e\ud991\udf52\ubab3\ud9f4\ude59\ud890\udfaf\ud96c\udce6\ud82e\udeb2\u930f\ud9e7\udccf\udb3f\udc27\udb40\udffc\uda5d\udc7c",
        57, 50490, -2065831173, -2906649251598256295L, -83777L, false, false, (char) 38599, (char) 24045,
        Double.longBitsToDouble(0x3fe626bab8f79eabL), Double.longBitsToDouble(0x3fae16054c759f20L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 5, 7, "\ud98d\udd8c\uda47\udf22\udb91\uddfd\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\ude07\ud80a\ude24\ud862\udf2d", "\u14c6\uc18b\u5745\ua7f9\uc01a\u1399\u7030\u30e3\u0adb\ua5f2\u28b7", "\ud8c8\ude4c",
        25, 96761, 477157509, 2623312378717728757L, 87116L, true, true, (char) 46705, (char) 29075,
        Double.longBitsToDouble(0x3fe23ee5d47084aaL), Double.longBitsToDouble(0x3fe5e00fe669780aL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 2, 4, 0, "\udb0d\udd8f\ud969\udef3\udbd2\udc60\udafc\udec0\uda9c\udeaf\uda64\udcc0\udb84\ude07\ud93f\ude57\uda31\udf36\ud91b\udc84\udb5a\udc2c\ud9f4\udf59", "\ucbf9\u62c5\u4db1\ud6e5\u02d6\ud1b5\u85b0\u9783\u0f9f\u58a1\u16e2\u6dff\u57fe\u1da4\u7193\u0258\ub95d\u0421\u1cdf\u6a46\ua294\u3848\u4eca\ucd01\u0b33\u4710\u3302\u97e9", "\udb4d\ude37\ud833\udeba\udbd9\udd85\uda5d\udfe8\ud963\udd81\ud96a\udcd1\udbd5\udd09\ud816\udd8b\ud889\ude3c\ud9ad\ude42\ud898\ude83\udb8c\udfa6\udbe6\udc93\udb40\udf6a\ud94b\udeaf\ud862\udc81\uda69\uddce\ud8e3\udf1a\ud8f1\udf22\udb5a\udec4\udbb1\ude70\udae3\udfa4\uda44\ude6e\uda3d\udcc2\ud957\ude86\udb17\udfd3\ud9a4\udc6b\uda79\udcdc\udac1\udca5\udb1b\uddb1\udbf1\uddf0\ud878\udf53\ud994\udc2d",
        55, 31886, -1797656973, 3483846668908320661L, 38003L, true, false, (char) 38687, (char) 36689,
        Double.longBitsToDouble(0x3fcd65c105d22424L), Double.longBitsToDouble(0x3fe3b09278ad768fL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 9, 0, 9, "\ud98d\udde0\ud8d7\udf8a", "\ub273\uae80\u749d", "\u1452\ub9ab\u5cea\udbb3\udf08\ud872\udf61\udbb8\udffc\ud90c\udefd",
        32, 6818, -437565863, 4098423073594133329L, 9531L, true, false, (char) 58429, (char) 57840,
        Double.longBitsToDouble(0x3fea710bb0799540L), Double.longBitsToDouble(0x3fc6c38e1e66599cL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 10, 11, 11, "\uaf7b\uda4e\uddb7\ud803\udd02\ud9d0\udcf5\ud93e\udda0\ud9da\udd91\udb84\ude07\uda2e\ude8e\ud81e\ude78", "\u71c6\uc18b\u5745\ucbf9\uc01a\ucb24\u7030\u72c6\u7294\u860f\u5918", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 78797, 800719449, -4893483238505815757L, 81865L, false, false, (char) 38065, (char) 62141,
        Double.longBitsToDouble(0x3fe72f20108e50f4L), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[21, 50, -102, 13, -57, 116, -45, -12]] |a1=[B:[[]]\012",
        Z.run(T, 1, 1, 10, 11, "\ud945\udf62\u00ca\uf53d\udbf7\udca4\ud803\udf24\ud9da\udd91\udb84\ude07\ud97f\udf36\u00ab", "", "\udafa\udf04",
        5, -568, -2138418518, -936748722659195261L, -75616L, true, false, (char) 49293, (char) 24924,
        Double.longBitsToDouble(0x3fe31801070e6be0L), Double.longBitsToDouble(0x3fc1268d62142400L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[-120, 44, 17, -118, 28, 124, 72, 112]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:-1 |a0=[B:[[-120, 44, 17, -118, 28, 124, 72, 112]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 0, 1, "\udbb8\ude5c\ud141\ud8ba\udc4c\u47ac\uda78\udea0\ud8f4\udd5e\udb45\udc6c\ud904\udf75\ud9be\udcf3", "\u71c6\uc18b\u5745\ucbf9\uc01a\ubd60\uc42a\u72c6\u7294\u1f7e\u28bf", "\udaf0\udec1\ud8ca\udd05\udb65\udd1a\udb32\udd22\udb97\udd39\ud955\uddd2\udae2\udcc3\ud907\udfb4",
        11, 247, -2077710213, -3804004397193229291L, -19721L, true, false, (char) 9818, (char) 44636,
        Double.longBitsToDouble(0x3fe7baf048c3a11fL), Double.longBitsToDouble(0x3feb40e26bb7cbf5L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[112, 84, 17, 11, -3, -20, 108, 103]] |a1=[B:[[-106, 91]]\0121=!java.io.IOException\012",
        Z.run(T, 2, 1, 8, 1, "\ud9a0\ude84\ud141\ud83b\ude2d\u471c\uda9c\ude97\uda3c\udf6d\ud8ec\udc11\ud95f\uded1\ud862\udf72", "\u71c6\uc18b", "\ud9af\ude7e\udace\ude66\uda45\ude43",
        50, 2069, -1623482176, 5520075015177756874L, 98045L, false, true, (char) 14580, (char) 57903,
        Double.longBitsToDouble(0x3fc6c38e1fd4919cL), Double.longBitsToDouble(0x3fe2cd22d2ec2fbaL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 3, 7, "\ud9a0\udda9\ud141\ud8ba\udc4c\u47ac\uda9c\ude97\ud9da\udd91\udb84\ude07\uda6c\udc8d\ud91f\udf70", "\u71c6\uc18b\u4a4b\ucbf9\uc01a\ubd60\uc42a\u72c6\u96ba\ucf04\u942e", "\ud9f8\udcbe\udb3a\ude24\udadf\udd17\ud812\ude32",
        55, 78797, 12190297, -3914458268155128916L, 82166L, true, false, (char) 33368, (char) 9383,
        Double.longBitsToDouble(0x3fdbae0836083cc0L), Double.longBitsToDouble(0x3fe4ccaff08e9bddL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[28, 15, -29, -118, 28, 124, 108, 103]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 9, 1, "\udb4c\udd3f\ud213\ud8ba\udc4c\u47ac\uda9c\ude97\ud9da\udd91\ud95f\udd7b\ud873\ude5c\ud9c0\ude13", "\u71c6\u5f67\u81ae\ucb98\uc01a\ubd60\ua134\u39c6\u7294\uca5b\u08af", "\ud9f8\udcbe\udba7\udf87\uabae\ud812\ude32",
        55, 78797, 800719449, -3921157617467665492L, -44950L, true, false, (char) 37553, (char) 63252,
        Double.longBitsToDouble(0x3fc55300fe4f66b4L), Double.longBitsToDouble(0x3feb331e9d42cbf8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[-79, 65, 44, -118, 28, 124, 108, 103]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 0, 11, 1, "\ud8e1\udd71\ud15c\ud8ba\udc4c\u47ac\uda9c\ude97\ud9da\udd91\udb84\ude07\uda6c\udc8d\ud862\udf50", "\u07f7\u37af\u5745\ucbf9\uc01a\ubd60\uc42a\u72c6\u7294\u860f\u9783", "\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32",
        55, 13701, 800719449, -3934216517876067412L, 44130L, true, false, (char) 37553, (char) 63252,
        Double.longBitsToDouble(0x3fc55300e24f66b4L), Double.longBitsToDouble(0x3fe4cfc5888e9bddL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 2, 3, 6, "\ud9a0\udda9\uda8b\ude2e\ud890\ude70\udad1\uddac\ud8ae\uddac\ud9da\udd9e\udb84\ude07\uda6c\udc8d\udbea\udfb5\ud986\ude23\ud804\udd39\ud9ca\ude85", "\ucbf9\uc01a\ubd60\u2ee7\u7317\u7294\u860f\u9783\u3f23\u1ab0\u7243\u6d5b\u57fe\u423a", "\u8529\ud907\udfb4",
        20, 260, -2077710213, -2218737326239529408L, 81830L, true, false, (char) 18891, (char) 2625,
        Double.longBitsToDouble(0x3fe4cfc5888e9bddL), Double.longBitsToDouble(0x3fdc3a34f04f883eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |a0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 8, 1, "", "\u03eb\u26df\ub25b\uae80\u5b9c\uca9d\u5a5f\u29c0", "\udbb3\udf08",
        -4, 94052, -810188457, -462422016L, 18230L, false, false, (char) 16123, (char) 49293,
        Double.longBitsToDouble(0x3fa7e680263862f0L), Double.longBitsToDouble(0x3fe8735f0489346bL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 9, 9, 7, "\uda6d\udddb\ud81b\udf80\udb86\ude1e\ud8f0\udec0\ue674\udbff\udf53\uda15\udcc5\ud97f\udf36\uda48\udea1\ube66", "\u385f", "\uda11\udcae\ud817\udfaf\ud926\udc41\uda5c\udced\udbe1\ude34\udbe3\udef4\udaab\udd9d",
        26, 41617, 1121088596, 3662053272554290722L, 42420L, true, false, (char) 16384, (char) 7451,
        Double.longBitsToDouble(0x3fd992c49d211288L), Double.longBitsToDouble(0x3fe6546d34503788L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 2, 9, 7, "\udb83\udfe7\ud94e\udd02\uda93\udd30\ud9d0\udd10\udb99\udded\uda73\uddc2\udb84\ude07\ud97f\udf36\uda48\udea1\ube66", "\uc18b", "\ud9af\ude7e\ud80e\udf27\ud937\uddd3",
        37, 2002, 1966842048, 1159380442220841562L, -83138L, false, true, (char) 25999, (char) 64385,
        Double.longBitsToDouble(0x3fc0ef99bad8cdecL), Double.longBitsToDouble(0x3fed61296a4805adL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[120, -98, 30, -46, 99, 0, -96, -32]] |a1=[B:[[91]]\0121=java.lang.Boolean:false |a0=[B:[[120, -98, 30, -46, 99, 0, -96, -32]] |a1=[B:[[91]]\012",
        Z.run(T, 2, 1, 1, 7, "\udaa8\udfce\ud94e\udd02\uda93\udd30\ud9d0\udd10\udb99\udded\uda4b\uddb5\udb84\ude07\ud97f\udf36\uda48\udea1\ube66", "\uc18b", "\ud9af\ude7e\ud80e\udf27\ud937\uddd3",
        37, 2002, 1966842048, 1159380442220841562L, -83138L, false, true, (char) 25999, (char) 47489,
        Double.longBitsToDouble(0x3fc0ec908bb2e33cL), Double.longBitsToDouble(0x3fed65d577ecde85L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-117, 49, 96, -9, -119, 42, 44, 90]]\0121=java.lang.Boolean:false |a0=[B:[[-117, 49, 96, -9, -119, 42, 44, 90]]\012",
        Z.run(T, 2, 7, 7, 5, "\udabb\udd61\ud890\ude27\u81b9\ud95a\udf5c\udb8a\udd56\uda27\udc7c\uda80\udf29\uda78\udccf\ud802\udcfd\udb64\udc39\udbaa\ude2e\udb9d\udccb\udbb3\udf08\udaaa\udddc\u4f09\ued19\uda49\udfab\udaba\udf67\uda68\udcc4", "\ua1ab", "\ud816\udef1\udb3a\ude24\udb27\udf1b\ud812\ude32\u4df3\uda3b\udce9\ud9cd\udf38\ud8b6\udf1d\udaf0\udfb5\udaa3\udf18\uda2f\uddbc\ud92e\udd51\ud9ae\ude06\ud915\udfec\ud8b1\udcda",
        45, 48818, -661507437, 5881861476167625732L, -51199L, true, true, (char) 41487, (char) 40107,
        Double.longBitsToDouble(0x3fe306aee1b7b491L), Double.longBitsToDouble(0x3fceb7283839c430L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 9, 4, 0, "\ud98d\uddb9\udac1\udd1f\ud803\udd02\ud93e\udddb\uda42\udc13\u917d\ud8cc\udc00\ud951\udcae\ud862\udf2d\ud986\udd32\ud8b2\udfed\udad2\udc10\udbb3\udf08\ud872\udf61", "\u1399", "\udbe1\ude34\ud840\udf0c\ud902\udc33\ud93f\udeb6\uda00\udc12\000\udb3a\ude24\udb65\udd1a\ud812\ude32\ud8c4\udebe\udb55\udca3\ud8fc\udd94\ud907\udfb4\udbc2\uddb2\u34b8\uda2f\uddbc\uf858\udbcb\udc8d\u15cf\uda76\udf37\uda9c\udd6b\ud9f2\udf15\ud960\udd82\udba1\udd03\udaea\udf3c\udbb0\udda6\ud9a1\udf75\udbb2\udf3f\uda07\udeab\udb7c\ude20\uda1d\udd8e\u00e8\udad2\udd58\u2dcf\udbcc\udf44",
        -3, 87944, 56, 26L, 29332L, false, false, (char) 47126, (char) 38072,
        Double.longBitsToDouble(0x3fb1e593d1c0a288L), Double.longBitsToDouble(0x3fc6bb66aabb3f20L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[93, 92, 23, -14, -9, -105, 46, 111]] |a1=[B:[[-7, -115, 21, -55, 125, 105, 0, -77]]\0121=java.lang.Boolean:false |a0=[B:[[93, 92, 23, -14, -9, -105, 46, 111]] |a1=[B:[[-7, -115, 21, -55, 125, 105, 0, -77]]\012",
        Z.run(T, 2, 1, 1, 3, "\ud98d\udd8c\uda47\udf22\u9227\ud9c7\udf5e\uda9f\udd2c\u0eac\ud817\udd79\ud80a\ude24\ud862\udf2d", "\uce29\u17bd\u5745\ua7f9\u1fad\u1399\u7030\u30e3\u0adb\ua5f2\u28b7", "\ud8c8\ude4c",
        25, 96761, 477157509, 2623312378717728757L, 49417L, true, true, (char) 46705, (char) 29075,
        Double.longBitsToDouble(0x3fe23ee5d07084aaL), Double.longBitsToDouble(0x3fe059c55e69786eL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 0, 0, "", "", "",
        -5, -1000, -1996488704, -432345562374706005L, -99885L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe5567da800808aL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |a0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |a0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 8, 8, 6, "", "\u6044\u2657\ub25b\uae80\u5b9c\uca9d\u5a5f\u29c0", "\udbb3\udf08",
        -4, 67284, -815381533, -462422016L, 18230L, false, false, (char) 16123, (char) 49293,
        Double.longBitsToDouble(0x3fa7e680263862f0L), Double.longBitsToDouble(0x3fe8735f0489346bL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-117, 49, 96, -9, 120, -19, 42, 44]]\0121=java.lang.Boolean:false |a0=[B:[[-117, 49, 96, -9, 120, -19, 42, 44]]\012",
        Z.run(T, 2, 7, 7, 5, "\udabb\udd61\ud890\ude27\udba8\udc1d\ud95a\udf5c\udb8a\udd56\uda27\udc7c\uda80\udf29\uda78\udccf\ud802\udcfd\udb64\udc39\udbaa\ude2e\udb9d\udccb\udbb3\udf08\udaaa\udddc\u4f09\ued19\uda49\udfab\udaba\udf67\uda68\udcc4", "\ua1ab", "\ud816\udef1\udb3a\ude24\udb27\udf1b\ud812\ude32\u4df3\uda3b\udce9\ud9cd\udf38\ud864\uded3\udac5\udeb6\uda96\udf75\uda2f\uddbc\ud975\uddf5\ud9ae\ude06\ud915\udfec\ud8b1\udcda",
        1, 48818, -661507437, 8089576448446606580L, -51199L, true, true, (char) 41487, (char) 40107,
        Double.longBitsToDouble(0x3fe306aee1b7b491L), Double.longBitsToDouble(0x3fceb7283839c430L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[93, 92, 57, -61, -45, -46, -96, -32]] |a1=[B:[[68, 91, 21, -55, -22, 105, 0, -106]]\012",
        Z.run(T, 1, 1, 10, 11, "\ud98d\udd8c\ud969\udef3\ud803\udd02\ud9d0\udd10\uda9c\udeaf\ud9da\udd91\udb84\udee3\ud97f\udf36\ud862\udf2d", "\u6374\uc18b\u5745\ucbf9\uc01a\u1399\u7030\u72c6\u7294\u860f\u8b16", "\ud9a1\uddf9\udb3a\udeea\ud8b2\udea1\ud812\ude32",
        55, 78797, 800719449, -3934216517876067412L, 81865L, false, false, (char) 30897, (char) 2625,
        Double.longBitsToDouble(0x3fe4cfc5888e9bddL), Double.longBitsToDouble(0x3fc83993881972e0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[80, 101, 6, 95, -45, -46]]\012",
        Z.run(T, 1, 7, 6, 2, "\ud880\udf95\uda36\ude8f\ud803\udd02", "\uae80\u749d\ud594\u8f8f\u28cf\u47b8\u71c6\uc18b\u5745\uace9\ua626\u4255", "\udbe1\ude34\ud840\udf0c\udb72\udfec\ua78f\ud8d8\uded6\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32\ud8c4\udedb\ud96e\ude8e\udbdb\udd05\udaca\ude5b\udbc2\udd96\ud9e0\ude81\uda2f\uddf8\ud92a\udf30\udbcb\udc8d\u15cf\uda4c\udd76\u8c9a\udb44\udc85\udaf0\udc24\ud8f7\udcb2\udae7\udd86\udb4d\ude37\uda80\udd80\udbb2\udc96\ud995\udc7b\ubed2\udb70\udf61\ud9a8\udc7e\udb6f\udc80\ud9d3\uddd3\udacd\udf1c",
        39, 46379, -1868605869, 1784930712308968261L, 91663L, true, false, (char) 1743, (char) 48602,
        Double.longBitsToDouble(0x3fddf17b9b6be9d2L), Double.longBitsToDouble(0x3fd57d0f8312d51eL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-48, -48, -48, -48, -48, -48, 84, -44]] |a1=[B:[[-48, -48, -48, -48, -48, 75, -48]]\012",
        Z.run(T, 1, 1, 10, 0, "\000\000\000\u0800\000\000\udb84\ude04", "\000\000\000\000\000\ua27b\000", "\u0083\000",
        -5, 52387, -852644901, 9170130649021027L, -99863L, true, false, (char) 11880, (char) 14769,
        Double.longBitsToDouble(0x3fa0aebbe95761f0L), Double.longBitsToDouble(0x3fd07642b06dd970L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 11, 11, 11, "\uaf7b\uda4e\uddb7\ud803\udd02", "\uae80\u749d\u0570\u65d1\u2210\u47b8\u71c6\uc18b\u5581\u3f2a\uc01a\ucb24", "\udbe1\ude34\ud840\udf0c\udbd9\ude8d\ud8ee\udca0\ud8c9\udd01\ud9f8\udcbe\udb3a\ude24\udb65\udd1a\ud812\ude32\ud8c4\udedb\ud96e\ude8e\u8529\ud9b5\udeeb\ud827\udf3a\udabd\udcaf\uda2f\uddbc\udb37\udd73\udbcb\udc8d\u15cf\uda76\udeab\ud98c\udc69\ud800\udf29\udad4\udedc\ud919\udfaa\udae7\udd86\udb4d\ude37\ud991\udde9\ud84f\udee1\udbf1\udc59\uda1c\udf28\uda1b\uddb4\ud93f\uded1\ud87e\udd63\udbb1\uded9\u40ac",
        36, 57908, 473903927, 8882348104876679602L, 12351L, false, true, (char) 16811, (char) 29798,
        Double.longBitsToDouble(0x3fe790e65377e084L), Double.longBitsToDouble(0x3fe4714042ab18c8L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[91, 30, 54, 86, 116, -128, -5, 105]] |a1=[B:[[91]]\0121=java.lang.Boolean:true |a0=[B:[[91, 30, 54, 86, 116, -128, -5, 105]] |a1=[B:[[91]]\012",
        Z.run(T, 2, 1, 1, 7, "\u098b\ud94e\udd66\ud886\udfa4\udbb0\udc2b\udb99\udd68\uda41\udf10\udb84\ude07\ud97f\udf36\uda48\udea1\ube66", "\uc18b", "\ud9bb\ude78\ud80e\udf27\ud937\uddd3",
        4, 2002, 1966842048, 1159380442220841562L, -83138L, false, true, (char) 25999, (char) 47489,
        Double.longBitsToDouble(0x3fc0ec9087b2e33cL), Double.longBitsToDouble(0x3fe6ea937fecde64L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 9, 9, 0, "\ud80b\udeab\ud95a\udfb4\ud803\udd02\ud93e\udddb\udbad\udefe\u917d\udb56\udf65\ud97f\udf4c\ud862\udf2d\ud986\udd32\udbe4\udc85\udad2\udcd5\udbb3\udf08\ud872\udf61", "\u1399", "\udbe1\ude34\ud840\udf0c\uda61\udfa3\uda2b\uddaf\ud938\ude92\ud9ff\udeff\udb3a\ude24\udb65\udd1a\ud812\ude32\ud8c4\udebe\udb55\udca3\ud8fc\udd94\ud907\udfb4\udbc2\uddb2\u34b8\uda2f\uddbc\uf858\udbcb\udc8d\u15cf\uda76\udf37\uda9c\udd6b\ud9f2\udf15\ud960\udd82\udba1\udd03\udaeb\udc13\ud822\udf91\u174e\uda29\uddfb\ud929\udcab\ud8d8\udfd5\udb14\udcee\000\udad2\udd58\u2dcf\udbcc\udf44",
        1, 79304, 56, 0L, 29332L, false, false, (char) 41238, (char) 51729,
        Double.longBitsToDouble(0x3fb1e593d9c0a288L), Double.longBitsToDouble(0x3fec5f172aaecfc8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|checksig|[B,[B|static",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|close||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|closeEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|fill||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextZipEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|matches|[B,int|static",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|readFully|[B|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|skip|long|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String,boolean",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
