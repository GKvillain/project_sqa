package org.apache.commons.compress.archivers.sevenz;
import org.junit.Test;
import static org.junit.Assert.*;
public class Coders_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 1, "\udb05\udcee\ud972\udfd1\ue181\udb25\udc53", "\ud6c8\u4444\u2baf\ub0b4\u143a\u7272\u0fbf\ua959", "\udb7e\udc0f\ud897\udc3f\ud9ac\uddb5\ud965\udc32\u2b78\udaae\udc36\ud9a2\udf0d\uda7d\udd93\udaa9\uddc7\ud913\udde7\uda86\udcb7\uda18\uddbb\udaa0\udc5d\udba7\udc86\uec6e\uda9d\udd13\udbf4\udc44\uda96\udc3f\ud90d\ude6c\ud8ab\udcdc\ud912\ude27\ud835\udd70\ud94c\udd4b",
        22, 67110, -1496778373, -6207042882646603146L, 55776L, true, false, (char) 42854, (char) 9514,
        Double.longBitsToDouble(0x3fe8ad04d0599eb5L), Double.longBitsToDouble(0x3fe18d055236606aL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9ac\udc14\ud99d\uddc8\ud876\udfa0\ud8fd\udffb\ud827\udddc\udac1\udc3e\uda8d\udff5\udad3\udf61", "\u143a\u9c39\u0fbf\ua959\ua8f1\u2d27", "\ud9ac\uddb5\ud965\udc32\u2b78\udaae\udc36",
        12, 85613, 192036123, -6375772210988415867L, -43524L, true, true, (char) 32315, (char) 47774,
        Double.longBitsToDouble(0x3fe0708df4f5e1b5L), Double.longBitsToDouble(0x3fef6580dfa42a71L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 1, "\udb05\udcee\ud972\udfd1\ue181\udb25\udc53", "\ud6c8\u4444\u2baf\ub0b4\u143a\u7272\u0fbf\ua959", "\udb7e\udc0f\ud897\udc3f\ud9ac\uddb5\ud965\udc32\u2b78\udaae\udc36\ud9a2\udf0d\uda7d\udd93\udaa9\uddc7\ud913\udde7\uda86\udcb7\uda18\uddbb\udaa0\udc5d\udba7\udc86\ud92e\udca6\uda9d\udd13\udbf4\udc44\uda96\udc3f\ud90d\ude6c\ud8ab\udcdc\ud912\ude27\ud835\udd70\ud94c\udd4b",
        15, 87102, -1496802640, 4230330725508579939L, -23361L, true, true, (char) 42826, (char) 9514,
        Double.longBitsToDouble(0x3fe8ad04d0599eb5L), Double.longBitsToDouble(0x3fe18d055236606aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udb05\udc25", "\u6a86\u19a8\u9c27", "\uda6c\udff0\uda54\udd78\ud92c\uddcb\uda00\udceb\ud898\uddcf\ud9dc\uddf5\ud993\udea8\ud804\udc2d\ud93e\udc23\ud8a0\udd2a\ud9ac\uddb5\ud965\udc32\u2b78\ud883\ude81\ud9a2\udf0d\uda7d\udd93\udaa9\uddc7\ud913\udde7\uda86\udcb7\uda18\uddbb\udaa0\udc5d\udba7\udc86\uec6e\ud96b\udc16\udbf4\udc44\uda96\udc3f\ud90d\ude6c\ud8ab\udcdc\ud9b1\ude56\ud835\uddef\udb09\udff6\udabb\udfcb\uda30\udcf7\uec39\ud9a2\ude4e\ud95c\udd31\udad5\ude35\ud9cd\udc59",
        54, 80702, -1600503891, -7010465159383975847L, -95338L, false, false, (char) 1668, (char) 10407,
        Double.longBitsToDouble(0x3fd4cf6e97452e6aL), Double.longBitsToDouble(0x3fd34de4b0582892L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 1, 1, "\udb39\uddc0\ud972\udfd1\uda34\udcdf\uda83\uddd7", "\ud6c8\u4444\u2baf\ub0b4\u143a\u4cc3\u0fbf\ua959", "\udbc6\ude61\udb29\udca8\ud955\udc7c\ud992\udf9a\udae7\udca5\uda89\udcf2\ud9a2\udf0d\uda7d\udd93\udaa9\uddc7\ud913\udde7\udb0f\udf58\udb7a\udccb\udb55\udf64\udba7\udc86\uec6e",
        55, 5990, -1340406539, 3058273916059508644L, -31760L, false, false, (char) 43681, (char) 52725,
        Double.longBitsToDouble(0x3fe3b54ee2f3723bL), Double.longBitsToDouble(0x3fb4cdd536efea28L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 0, "\udb05\udcee", "\u5887\u19a8\u9c27", "\uda2f\udd25\uda96\ude6d\ud92c\uddcb\uda00\udceb\ud854\uddce\ud9cf\udf57\ud993\udedf\ud804\udc2d\uda25\udf4c\udb0b\udecd\ud94e\udfee\ud977\ude93\u2b78\udaae\udc36\ud9a2\udf0d\uda7d\udd93\udaa9\uddc7\ud913\udde7\uda86\udcb7\uda18\uddbb\udaa0\udc5d\udba7\udc86\ud8f2\udc28\ud952\uddfe\uda9c\udd72\udb8f\udc5e\ud917\udc47\ud8ab\udcdc\ud912\ude27\ud835\udd70\ud94c\udd4b\udabb\udfcb\uda30\udcf7\uec39\ud9a2\ude4e\ud95c\udd31\udad5\ude35\ud9cd\udc59",
        54, 80702, -1600503891, -7010465159383975847L, -95338L, false, false, (char) 45036, (char) 34701,
        Double.longBitsToDouble(0x3fe09fda0d2e1422L), Double.longBitsToDouble(0x3fc6bf07880693c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |a2=[B:[[97, 120, -13, -71, 81, -11, 35]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 1, "\ud991\udfa8\ud823\udee9\ue181\udb25\udc53", "\u4954\u4444\u2baf\ub0b4\u143a\u3fa3\u0f6c\u232f", "\udb7e\udc0f\ud897\udc3f\udab3\udd67\ud965\udc68\uda40\udeca\udaae\udc36\udbd6\udd08\udbb7\ude15\udaa9\uddc7\ud913\udde7\ud9bc\udf32\uda18\uddbb\ud9b9\udf8a\udba7\udc6c\uda8e\udcde\uda9d\udd13\udbf4\udc44\ud9f6\udf9f",
        24, 41980, -493411357, 7514931177697454483L, -14081L, true, true, (char) 52778, (char) 13394,
        Double.longBitsToDouble(0x3fe79b91d8803754L), Double.longBitsToDouble(0x3fe6ea0a93a51e69L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |a2=[B:[[-43, -66, 66, -95, 81, -11, 35]]\0121=null |a2=[B:[[-43, -66, 66, -95, 81, -11, 35]]\012",
        Z.run(T, 2, 1, 1, 1, "\udb05\udcee\ud972\udfd1\ue181\udb25\udc53", "\ud6c8\u9aa0\u028f\ub0b4\ucf39\u7272\u0fbf\u5d59\u110a\u2dce\u5f06\u93b5", "\u2b78\udaae\udc36",
        12, 85613, 192036123, -8619690726911998843L, -44083L, true, false, (char) 32392, (char) 47774,
        Double.longBitsToDouble(0x3fe0708df4f5e1b5L), Double.longBitsToDouble(0x3fef6580dfa42a71L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 1, 1, 1, "\udb05\udcee\ud972\udfd1\ue181\ud9f7\udedc", "\u20c3\u43c8\u2baf\ub0b4\u143a\u7272\u0fbf\ua959\ua8f1\u2d27\u5f06\u93b5\u0305\uab55\u5ba7", "\uda7b\udfc4\udaa9\uddc7",
        25, 5709, -1977747282, 3413488357686461981L, 25944L, false, false, (char) 59050, (char) 56327,
        Double.longBitsToDouble(0x3fed21538be35891L), Double.longBitsToDouble(0x3fcbbc52f3071780L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.tukaani.xz.LZMA2OutputStream:@? |a2=[B:[[-43, -66, -77, -90, 81, -11, 35]]\0121=org.tukaani.xz.LZMA2OutputStream:@? |a2=[B:[[-43, -66, -77, -90, 81, -11, 35]]\012",
        Z.run(T, 2, 1, 1, 1, "\udb05\udcee\udbe3\uded6\ue181\udb25\udc53", "\ud6c8\u4444\u2baf\ub0b4\u143a\u7272\u0fbf\ua959", "\udb7e\udc0f\ud897\udc3f\ud9ac\uddb5\ud965\udc32\u2b78\udaae\udc36\ud9a2\udf0d\uda7d\udd93\udaa9\uddc7\ud913\udde7\uda86\udcb7\uda18\uddbb\udaa0\udc5d\udba7\udc86\uec6e\uda9d\udd13\udbf4\udc44\uda96\udc3f\ud90d\ude6c\ud8ab\udcdc\ud912\ude27\udb49\ude19\udbf0\udf4e",
        32, 67110, -1496778373, -6207042883921671562L, 55776L, true, false, (char) 42854, (char) 9514,
        Double.longBitsToDouble(0x3fe8ad04d0599eb5L), Double.longBitsToDouble(0x3fe61d055236a8e3L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |a2=[B:[[-43, -66, 108, -62, -10, 14, 18, 40]]\0121=null |a2=[B:[[-43, -66, 108, -62, -10, 14, 18, 40]]\012",
        Z.run(T, 2, 1, 1, 1, "\udb05\udcee\ud99c\uddf2\udb26\udf3e\ud842\udc58", "\ud6c8\u4444\u2baf\ua857\u143a\ua11a\u0fbf\ua959\ua8f1\u2d27", "\ud9ac\uddb5\ud8d5\udeea\udbe5\udf96\udaae\udc36",
        12, 85613, 192036123, -8619690727804533627L, -44083L, true, false, (char) 32392, (char) 47774,
        Double.longBitsToDouble(0x3fe0708df4f5e1b5L), Double.longBitsToDouble(0x3fef6580dfa42a71L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.tukaani.xz.LZMA2OutputStream:@? |a2=[B:[[-43, -66, 66, -95, 81, -11, 35]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\udb05\udcee\ud972\udfd1\ue181\udb25\udc53", "\u6624\u4444\u2baf\ub0b4\u143a\u7272\u0fbf\ua959", "\udb7e\udc0f\ud897\udc3f\ud9ac\uddb5\ud965\udc32\u2b78\udaae\udc36\ud9a2\udf0d\uda7d\udd93\udaa9\uddc7\udbab\udc79\uda86\udcb7\uda18\uddbb\udaa0\udc5d\udba7\udc86\uec6e\ud91e\udd38\udbf4\udc44\uda96\udc3f\ud90d\ude6c\ud8ab\udcdc\ud989\udea3\ud840\udc0c\ud94c\udd4b",
        20, 76899, -1496778373, -6207042882646603146L, 84704L, true, false, (char) 42854, (char) 9514,
        Double.longBitsToDouble(0x3fe8ad04d0599eb5L), Double.longBitsToDouble(0x3fe18d055236606aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 1, "\000", "\u5887", "\uda8d\udff5\udad3\ude9a\uda2f\udd25\uda96\ude6d\ud92c\uddcb\udb27\uddde\ud854\udd8b\ud9cf\udf57",
        4, 79592, 1295420291, -5152662825870273046L, -100000L, false, false, (char) 3301, (char) 47145,
        Double.longBitsToDouble(0x3fd938a1dc3a5ebeL), Double.longBitsToDouble(0x3fdb36cd58114d2cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 0, "\ud9ac\udc14", "\uaf9b", "\uda8d\udff5\udad3\udf61\uda2f\udd25\uda96\ude6d\ud92c\uddcb\udb44\uddcd\ud854\uddce\ud9cf\udf57\ud993\udedf\ud804\udc2d\udb7e\udc0f\ud897\udc3f\ud9ac\uddb5",
        14, 45312, 1771170302, -5027302331605714635L, -53676L, true, false, (char) 52380, (char) 59332,
        Double.longBitsToDouble(0x3fd2d74c3366d910L), Double.longBitsToDouble(0x3f814d2c83846f80L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 1, 1, 1, "\udb05\udcee", "\u5887\u19a8\u9c27", "\uda2f\udd25\uda96\ude6d\ud92c\uddcb\uda00\udceb\ud854\uddce\ud9cf\udf57\ud993\udedf\ud804\udc2d\udb7e\udc0f\ud897\udc3f\ud9ac\uddb5\ud965\udc32\u2b78\udaae\udc36\ud9a2\udf0d\uda7d\udd93\udaa9\uddc7\ud913\udde7\uda86\udcb7\uda18\uddbb\udaa0\udc5d\udba7\udc86\uec6e\uda9d\udd13\udbf4\udc44\uda96\udc3f\ud90d\ude6c\ud8ab\udcdc\ud912\ude27\ud835\udd70\ud94c\udd4b\udabb\udfcb\uda30\udcf7\uec39\ud9a2\ude4e\ud95c\udd31\udba1\udd7c\uda9e\udce7",
        54, 80702, -1600503891, -7010465159383975847L, -95338L, false, false, (char) 9581, (char) 31481,
        Double.longBitsToDouble(0x3f82122497db6f80L), Double.longBitsToDouble(0x3fdc69d3d548da86L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.sevenz.Coders|addDecoder|java.io.InputStream,org.apache.commons.compress.archivers.sevenz.Coder,[B|static",
    "M|org.apache.commons.compress.archivers.sevenz.Coders|addEncoder|java.io.OutputStream,org.apache.commons.compress.archivers.sevenz.SevenZMethod,[B|static",
    "C|org.apache.commons.compress.archivers.sevenz.Coders|<init>|",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
