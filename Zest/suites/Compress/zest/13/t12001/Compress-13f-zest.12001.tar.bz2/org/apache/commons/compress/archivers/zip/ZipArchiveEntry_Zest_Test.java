package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipArchiveEntry_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63\012",
        Z.run(T, 2, 16, 5, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u30c1\u2fec\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63\012",
        Z.run(T, 2, 16, 5, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u30c1\ua54a\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\ud977\udfe6\udb14\udcba\udab8\udce3\ud986\udc38\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\ud954\udfe9\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554552424438469L, -40655L, true, false, (char) 53692, (char) 138,
        Double.longBitsToDouble(0x3fe71f2d64463a72L), Double.longBitsToDouble(0x3fcf3d0f9ea6109cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 5, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u30c1\u2fec\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f99766864L), Double.longBitsToDouble(0x3fe74f1db44e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 5, 14, "\u8b7f\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\ud8cb\udcce\000\000", "\u0a81\ub4b6\uadf0\u432a\ub4e7\u2fec\u6b4f\u57b8", "\uda3f\ude0c",
        28, 28880, -413197092, 6326126266213731788L, 37552L, true, true, (char) 12275, (char) 46104,
        Double.longBitsToDouble(0x3fb441bd977ce4d8L), Double.longBitsToDouble(0x3fe8d7d382d0852dL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 15, 5, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\uc717\uaddb\u432a\u30c1\u0b7b\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e6335236cdbL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 3, 0, "\uda15\uddea\u50e9\ud8dc\udfba\uda57\udd7a\udb58\udcd5\udaba\udd56\ud829\udef8\uda2c\udcce\uda1d\udc8c\udaec\ude49\ud82b\udc47\ud936\udf5e\udbf5\udf8c\ud889\udedc\ud9d0\ude13\uc8eb\ud99e\udc72\udbec\udf7c\udaa8\udc37\ud8f5\udd78\ud9fa\udfb0\uda4a\ude40\udb02\udf56\ud82e\udd36\ud9ba\udcc9\uda6d\udfe7\ud85b\udcd5\ud90b\udfc0", "\u0e78\u47a3\ua9a6\u0458\u3c74\u474d\ua09c\u3c9f\u8b06\u0b0a\u44e9\u123b\ubcf5\u5709\u9d69\u4f76\u69b1\ub2c7\u1829\u5978\u8bd5\u5281\u6c60\u98d5\u93f2\u0474\u2d77\u40ee\ub58d\uade5\u7979\u2c36\ucd31\u86d2\u83a6\ub70b\uc83d", "\udbe9\udfc9\uda01\ude53\uda17\udfcb\ufae6\uda4f\udcf4\ud9ab\udc1e\udb12\ude0b\udbd4\udd1d\ud8dc\ude0d\ud80d\udf8e\ud93b\udf5d\uda43\udc09\udb9f\udf1a\ud9a2\udefe\u3a23",
        59, 92531, 324466350, -7787307004867763942L, 46037L, true, true, (char) 16244, (char) 45354,
        Double.longBitsToDouble(0x3fea60f4a078af6aL), Double.longBitsToDouble(0x3fefa769081d219eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63\012",
        Z.run(T, 2, 0, 0, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u30c1\uad36\u6c12\uc1ca", "\u9e81\ud9e0\udeb0\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e6330000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 4, 11, 11, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude30\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u30c1\u2fec\u6c12\uc1ca", "\uda3f\ude0c\udac2\udf16\ud9c3\udc36\ud9a1\uddc3\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\ud83a\udfc4\ud986\udcbe\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufab7",
        5, 67299, 1675179666, -1545554551883766469L, -40655L, false, true, (char) 48701, (char) 22122,
        Double.longBitsToDouble(0x3fe71f2a94463a72L), Double.longBitsToDouble(0x3fcf3d0f9ea6109cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 16, 5, 14, "\ud87d\udd9e\ud880\udc4a\udb33\udd46\udac0\udcb6\udb57\udff5\ud90a\udf9f\udb50\udfa9\ud97f\udea3\ud960\udd70", "\u2a1e\ub4b6\uadf0\u432a\ua29d\u83a3\ua220\uc1ca\ud6c6\u08cd\ua55b\ud6d5\u79e1\u57ab\u5a5f\u2e9d\u94a0\uaef6\uce39\ubfab\u9fd9\u5f16\u0458\u7988\u3124\u0551\u5439\u4eca\u98f2\u44e9\u1ce7", "\uda5e\udfd2\uda8f\udfda\udb9b\uddd8\udb4f\uddbe\udb1d\ude54\ud8e2\udee3",
        47, 93601, 1826294505, -7390525398691247335L, 79584L, false, false, (char) 24508, (char) 56768,
        Double.longBitsToDouble(0x3fd01c4289eb0ec0L), Double.longBitsToDouble(0x3fe0f13da21172ddL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 10, 5, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u22c0\u2fec\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud947\udf0c\udb5d\uded0\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63\012",
        Z.run(T, 1, 16, 5, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud947\udf0c\udb5d\uded0\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u994e\u9f96\u2fec\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\uda52\udeb5\udb56\udedf\udaaf\ude04\ud986\udc38\ud880\udc33\u7f24\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udb51\udebf\ud970\udf6c",
        18, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 8, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\uda08\udd4f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a", "\ud9f6\ude22\ud99c\ude23\ud8f5\udd78\ud858\udc3f\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44",
        57, 1881, -93281553, -8850176786322515248L, -84929L, false, true, (char) 20160, (char) 3197,
        Double.longBitsToDouble(0x3fe29b1ecd3bea8dL), Double.longBitsToDouble(0x3fedefc607d1ab08L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 10, 9, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud910\ude51\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u30c1\uc8d0\u4b81\u2514", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9ba\udf8a\ud8d4\ude27\udb88\udfad\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |a1=[B:[[81, 75, 117, -6, -111, -68, 64, 108]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\uda88\udf34\ud902\udf92\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\ud8ce\udeef\ud9c4\udf8a\uda87\ude63\012",
        Z.run(T, 1, 1, 5, 4, "\uda88\udf34\ud902\udf92\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\ud8ce\udeef\ud9c4\udf8a\uda87\ude63", "\u0a81\u607b\ucda5\u432a\u30c1\u2fec\u9e70\u219c", "\uda3f\ude0c\ud860\udee5\udbe0\udc98\ud9a0\udf68",
        55, 97988, 55158598, -4027879084536924827L, 77177L, true, false, (char) 44170, (char) 14713,
        Double.longBitsToDouble(0x3fc950a5a3e67ad4L), Double.longBitsToDouble(0x3fc4bbbe012b6a30L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u30c1\u2fec\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udf13\uda7c\udf6b\udbe8\udd76\ud9da\udebc\ud99d\uddeb\ud801\udd0d\ud9ff\ude75\u1fde\ud9d9\udca5\udb08\udfad\udaad\uddd8\ufb56",
        36, 30825, -617897297, -1545554551501691589L, -11547L, true, true, (char) 47082, (char) 54970,
        Double.longBitsToDouble(0x3fcf3d0f9f87c09cL), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 16, 6, 7, "\u8c06\uda0d\ude25\ud8fd\udd4b\ud8c9\ude5b\udb62\udf7f\ud90a\udf9f\udb33\udc82\uda88\udcaa\udb84\udf29", "\u0a75\ub4b6\uadf0\u24ec\ucdbf\u24f2\u8eee\u9fda", "\uda5d\udde8\udaeb\ude89\ud884\udeb0\ud97b\ude4b\ud9c2\udde7\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44\ud801\udc82\udaf5\ude70\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56\udb87\udf40\ud848\udc58",
        51, 9539, -121576133, -231381514704696471L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 5, 5, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u057a\ub4b6\uadf0\u432a\u30c1\u2fec\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\ud9eb\udf09\ud986\udc38\ud863\udd44\ud801\udc82\udbce\udd9c\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\0121=void |a1=[B:[[-78, 26, 81, -122, -64, -6]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\012",
        Z.run(T, 2, 16, 1, 15, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82", "\ud1e2\u674a\u0a81\ub4b6\uadf0\u432a", "\udb40\udd00\ud9a5\udd7f\ud85f\udf3b\ud94e\udcd3\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\u5b9d\ud8e5\ude65\ud98e\udc22\ud863\udd44",
        57, 1881, -93281553, -8850176786322515248L, -84929L, false, true, (char) 20160, (char) 43132,
        Double.longBitsToDouble(0x3fe4e8edb7a5ea4bL), Double.longBitsToDouble(0x3fede96b1fd1ab08L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=void |a1=[B:[[-81]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\udb84\udf9c\udb33\udc82\uda88\udcaa\uda87\ude63\012",
        Z.run(T, 2, 15, 1, 5, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\udb84\udf9c\udb33\udc82\uda88\udcaa\uda87\ude63", "\u09df", "\ud93f\ude64\ud9bf\udd84\u122e",
        -5, -1000, 1330342092, -4059173106118295552L, -41133L, false, false, (char) 53681, (char) 26006,
        Double.longBitsToDouble(0x3fea332f81500349L), Double.longBitsToDouble(0x3dee2ff300000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.util.Date:Wed Dec 31 15:59:59 PST 1969 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 10, 13, 8, "\uc38f", "\uac67\u0cd0\u85be\ucef8\u064b\ud6c0", "\uda80\udf82\u56e8\udaa0\udcc2\ud917\udf64\ud9bf\udd84\ud8f8\udee8\ud975\udd11\ud99c\udee2",
        22, 57113, -129450111, -6048772304367318420L, -21578L, false, false, (char) 3279, (char) 7321,
        Double.longBitsToDouble(0x3fd65c81a03ca95cL), Double.longBitsToDouble(0x3f99575f8a20dec0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 6, 7, "\ud988\udf89\udb4a\udc18\ud8f1\udc9e\ud84f\udd45\ud8f8\udd85\udadb\udce6\uda93\udd73\000\000\uda69\udc6b\ud9ee\uded1\uda87\udceb\ud8c7\ude2c\udaa0\udcc2\ud93f\ude64\ud8fd\udce2\ud9ab\udc61\udae0\udce4\uda74\uddfcl\ud91a\udd2c\ud92a\udd85\u4182\udbe0\udc32\ud9a0\udf68\ud9d5\udf7e\ud952\udfc1\udb6c\udc2e\udaaf\ude04", "\u2b42\u960a\ubf2b\u4aca\u150b\u10f7\u5f33\uada7\ud24e\u6e43\u8182\u94c3\u88c8\uaf86\u0ae3\u296d\u5ffd\u7140\u428c\u220f\uaa68\u456e\ud3b0\u4d9e\ua204\ua2d8\uc0c7\u434a\u3ade\u4305\u2e8f\u1556\u364b\uba31\u3df0\u09cc\u178f\u6efb\u907d\u2b48\u01fa\u5265", "\ud8ab\uddcf\ud973\udeec\uda64\udc1a",
        54, 7972, 608242297, -4856902443366591066L, -16481L, true, true, (char) 15645, (char) 17211,
        Double.longBitsToDouble(0x3fa6b7ac4cb6f820L), Double.longBitsToDouble(0x3fe8e6d2d1cfd32dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\udac5\udfb5\ud9ad\udfc3\ud94b\udd4e\ud89b\udd76\ud923\udf5c\udb74\udecb\udafc\uded7\udb9c\udc6f\ud8ba\udcad\0121=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\udac5\udfb5\ud9ad\udfc3\ud94b\udd4e\ud89b\udd76\ud923\udf5c\udb74\udecb\udafc\uded7\udb9c\udc6f\ud8ba\udcad |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\udac5\udfb5\ud9ad\udfc3\ud94b\udd4e\ud89b\udd76\ud923\udf5c\udb74\udecb\udafc\uded7\udb9c\udc6f\ud8ba\udcad\012",
        Z.run(T, 2, 1, 4, 7, "\udac5\udfb5\ud9ad\udfc3\ud94b\udd4e\ud89b\udd76\ud923\udf5c\udb74\udecb\udafc\uded7\udb9c\udc6f\ud8ba\udcad", "\u0a88\ud231\u0cb7", "\ud8f8\udee8\uda30\udf1a\udb7f\udf34\u00bc\udb6c\udc1a\ud95b\udd68\ud89e\uddd2\udbcc\udd61\ud9a0\udf68\udb6e\uddca\udb88\udfcd\ud866\uddc2",
        0, 87114, 1145566464, 8646341256296417723L, 40353L, false, false, (char) 50215, (char) 22949,
        Double.longBitsToDouble(0x3fec85e5b2ae3705L), Double.longBitsToDouble(0x3fd6a375f07ec33eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 4, 4, 12, "\ud996\udc87\udae3\udfe9\ud88c\udceb\ud8c9\ude5b\u7a76\uda84\udc65\ud859\udf91\ud82d\udcd5", "\ua4ad\uc97f\ub4b6\u9a6c\u94af", "\uda30\udf1a",
        -4, -1000, -956301312, -3715858365646094741L, -84164L, false, true, (char) 36738, (char) 5158,
        Double.longBitsToDouble(0x3fdc94f7daca2728L), Double.longBitsToDouble(0x3fd342ff38a1a1f2L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 11, 11, 14, "\u8b7f\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\ud8cb\udcce\uda98\udc0b\ud90c\udd66", "\u0a32\uc070\u70bb\u432a\ub4e7\u2fec\u8691\u578c\u40c8\u648f", "\ud852\udfc7\udac8\ude9b\uda44\udc73\u9841\udbed\udfe7\udb7a\uddef\ud99c\udfef\uda39\ude00\ud801\udc9d\ud9ff\ude75\ud842\ude9b\uf3dd\ud914\udd4c\ud9fd\udded\uda0d\udf76\ud911\udf8c\udaa3\udd74\ud9b8\udd09\udb79\ude3c\ud8a5\udffc\u0bef\ud9a9\udca7\ud915\udef0\uda21\udcd4\u47de\uda68\uddde\ud92c\udf60\ud914\ude73\ud8ea\udfdd",
        31, 36402, -566637165, 2150263753244011561L, -61934L, true, true, (char) 57688, (char) 6562,
        Double.longBitsToDouble(0x3fe0638d8eef6c95L), Double.longBitsToDouble(0x3fe2c828682e0c05L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 10, 10, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude63", "\u0a81\ub4b6\uadf0\u432a\u22c0\u2fec\u6c12\uc1ca", "\uda3f\ude0c\ud9fd\udc53\udbe0\udd25\ud9a0\udf68\ud9d5\udf7e\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38\ud863\udd44\ud801\udc82\ud9ff\ude75\ud842\ude9b\uf3dd\ud8ae\udcb2\udaad\uddcd\ufb56",
        5, 67299, 1675179666, -1545554551501691589L, -11547L, true, true, (char) 51343, (char) 54967,
        Double.longBitsToDouble(0x3fcf3d0f9ea6109cL), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 8, 8, 14, "\u8c06\uda22\udd25\udbbd\udc8a\ud8c9\ude5b\udb57\udff5\uda08\udd4f\udb33\udc82\ub25d\ud89c\ude80", "\u0e66\ubad5\u25b3\u432a\u30c1\u1a2d\u2821", "\ud858\udc3f\uda3f\ude0c\u377c\uda24\udc6e\ud9a0\udf1b\ud9d5\udf7e\udbb8\uddcd\uda4d\udf77\udaaf\ude04\ud986\udc38",
        12, 74257, -1667507119, 1665103634851420954L, -90542L, true, true, (char) 51641, (char) 32679,
        Double.longBitsToDouble(0x3fe496af565363d9L), Double.longBitsToDouble(0x3fd3bea8d77bf180L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |a1=[B:[[7, -100, -29]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8ba6\uda0d\ude25\uda77\udd48\ud871\udecf\ud89d\udcc4\ud810\udff6\udb32\udfdb\uda88\udcaa\udbfd\udf87\0121=void |a1=[B:[[7, -100, -29]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8ba6\uda0d\ude25\uda77\udd48\ud871\udecf\ud89d\udcc4\ud810\udff6\udb32\udfdb\uda88\udcaa\udbfd\udf87\012",
        Z.run(T, 2, 1, 1, 7, "\u8ba6\uda0d\ude25\uda77\udd48\ud871\udecf\ud89d\udcc4\ud810\udff6\udb32\udfdb\uda88\udcaa\udbfd\udf87", "\u5e37\u05cc\u5b13", "\udb3b\uded5\uda3b\udc81\ud854\uddac\udbdd\udfee\ud9e9\udeee\udb3d\udd55",
        26, 73592, 1621272057, 811638565721168499L, 87473L, true, false, (char) 54666, (char) 8189,
        Double.longBitsToDouble(0x3fce8c6b4b7c39b4L), Double.longBitsToDouble(0x3fdd607e45a6b7daL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\uda0d\udde3\uda0d\ude25\ud8fd\udd4b\udb03\ude18\udb62\udf7f\ud90a\udf9f\udb33\udc82\ud940\udcef\udb9e\udf2c\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\uda0d\udde3\uda0d\ude25\ud8fd\udd4b\udb03\ude18\udb62\udf7f\ud90a\udf9f\udb33\udc82\ud940\udcef\udb9e\udf2c\012",
        Z.run(T, 2, 1, 1, 7, "\uda0d\udde3\uda0d\ude25\ud8fd\udd4b\udb03\ude18\udb62\udf7f\ud90a\udf9f\udb33\udc82\ud940\udcef\udb9e\udf2c", "\u0a75\ub4b6\uadf0\u24ec\ucdbf\u24f2\u8eee\u9fda", "\uda5d\udde8\udaeb\ude89\uda78\udfcb\udb72\ude35\ud9c2\udde7\udbbc\udd1c\uda4d\udf77\u8022\u6eb8\ud863\udd7c\ud801\udc82\udaf5\ude70\ud842\ude9b\uf3dd\ud8ae\udcb2\ud9ef\uddb1\ufac9\udbbc\udcda\ud978\udf04",
        0, 9539, -121576133, -231381514704696471L, 99557L, true, false, (char) 30839, (char) 20113,
        Double.longBitsToDouble(0x3fad28fd7a984270L), Double.longBitsToDouble(0x3fe74e63344e6cdbL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 10, 10, 16, "\uc38f", "\uac67\u0cd0\u85be\ucef8\u064b\ud6c0", "\uda80\udf82\u56e8\udaa0\udcc2\ud917\udf64\ud9bf\udd84\ud8f8\udee8\ud975\udd11\ud99c\udee2",
        22, 57113, -129450111, -6048772304367318420L, -21578L, false, false, (char) 3279, (char) 7321,
        Double.longBitsToDouble(0x3fd65c81a03ca95cL), Double.longBitsToDouble(0x3f99575f8a20dec0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude2f\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude2f\012",
        Z.run(T, 2, 16, 5, 14, "\u8c06\uda22\udd25\ud8fd\udd4b\ud8c9\ude5b\udb57\udff5\ud90a\udf9f\udb33\udc82\uda88\udcaa\uda87\ude2f", "\u0a81\ub4b6\uadf0\u432a\u30c1\u2fec\u6c12\uc1ca", "\ud8fa\udcb1\ud9fd\udc53\udbe0\udd25\udaba\udf95\udb15\uddc3\udb88\udfcd\uda4d\udf77\udaaf\ude04\ud986\udc38",
        12, 74257, -1667507119, -400641221515683046L, 24148L, true, false, (char) 51641, (char) 20160,
        Double.longBitsToDouble(0x3fe496af565363d9L), Double.longBitsToDouble(0x3fe377546f7ec3a8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|setName|java.lang.String|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|setName|java.lang.String,[B|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|addAsFirstExtraField|org.apache.commons.compress.archivers.zip.ZipExtraField|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|addExtraField|org.apache.commons.compress.archivers.zip.ZipExtraField|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|clone||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|equals|java.lang.Object|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getCentralDirectoryExtra||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExternalAttributes||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraField|org.apache.commons.compress.archivers.zip.ZipShort|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraFields||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraFields|boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getGeneralPurposeBit||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getInternalAttributes||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getLastModifiedDate||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getLocalFileDataExtra||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getMethod||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|setName|java.lang.String|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|setName|java.lang.String,[B|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
