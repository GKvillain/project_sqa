package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipArchiveOutputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 4, 3, "\ud9de\udef4\udb8a\udc0e\udb78\udc2d\ud882\uded2\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\ud91f\udc30", "\u4d4e", "\udbf7\udd63\udb89\udd49\ud81c\ude9a\uda2b\udc38\ud9df\udca3",
        22, 8130, -407597454, -6786241505905067578L, 36686L, false, false, (char) 29959, (char) 48287,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 4, 3, "\ud9af\udd97\udb8a\udc0e", "\uca1e", "\ud938\udd14",
        24, 64817, 0, 8863084068592297258L, 69936L, true, true, (char) 53326, (char) 61161,
        Double.longBitsToDouble(0x3fe39382dd4ee7b4L), Double.longBitsToDouble(0x3fdc6a1d23686108L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 1, 1, 0, 3, "\ud9de\udef4\udb8a\udc0e\ud934\uddfd\udb36\uddb1\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\ud91f\udc30", "\u4d4e", "\udbf7\udd63\udb89\udd49\ud81c\ude9a\uda2b\udc38\ud9df\udca3",
        22, 8130, -407597454, -6786241505905067578L, 36686L, false, false, (char) 29959, (char) 48287,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 4, 3, "\ud9de\udef4\udb8a\udc0e\000\000\ud866\udd2c\ud900\udc75\udafa\uddec\u0095\udafd\udded\ud91f\udc30", "\u4d4e", "\udbf7\udd63\udb89\udd49\ud81c\ude9a\uda2b\udc38\ud9df\udca3",
        22, 8130, -407597454, -6786241505905067578L, 36686L, false, false, (char) 29959, (char) 4250,
        Double.longBitsToDouble(0x3fef50000683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 4, "\ud9de\udef4\udb8a\udc0e\udb78\udc2d\ud882\uded2\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\ud91f\udc30", "\u4d4e", "\udbf7\udd63\udb89\udd49\ud81c\ude9a\uda2b\udc38\ud9df\udca3",
        22, 8130, -407597454, -6786241505905067578L, 36686L, false, false, (char) 29959, (char) 48287,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 1, 17, 14, 11, "\ud9de\udef4\udb8a\udc0e\udb78\udc2d\udb57\udfa6\udba4\udc0c\udbfb\ude7e\udbb3\udc69\udb95\uddef\ud997\udcb9\uda03\uddef\uda07\udf8f\ud813\uddc2\udbd4\udfee\udbdd\udf96\ud853\ude88\ud851\uddb9\ud9d6\udd71\ud91a\udf6b\ud8c6\udc4a", "\u3c02\u1ef5\ud526\ua618\u35e0\ub813\uc924\u4334\u13d8\ua475\u355c\ubd11\ubc9e\u8c61\u46ae\u8b31\u13dd", "\ud952\udc1e\ud868\ude9d\uda9a\uddd4\ud81b\udd74\ud98f\udfdc\udbfd\udcff\udb9e\udf63\udb52\uddcd\udb53\udd58\ud97b\udd18\ud950\udfbe\ud867\udf64\uda1c\udf43\ud903\udcd4\ud91f\udd7c\ud810\udd23\ud908\ude2f\ud8e9\udc74\ud1e0\udb7d\udec4\udb90\udf46\ud9fa\udf8d\udafd\udc61\udbbb\uded7\ud90f\udc95\ud8f4\udc73\ud832\udd74\ud828\udd15\udb38\udfcb",
        9, 66917, 664509785, 4484784835453053384L, -88681L, true, true, (char) 54840, (char) 1134,
        Double.longBitsToDouble(0x3fe74d30addab379L), Double.longBitsToDouble(0x3fe84165ce472a6eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 3, 9, "\uda6d\udea8\udb8a\udc42\ud83c\udd3d\ud8fb\udc58\ud806\udfaf\ud900\udc75\u8241\ud938\udca9\udb8e\ude76\ud8fc\uddbe\ud9b6\ude8c\ud8f2\udc33\ub8ec\ud93f\udfd3", "\ua662\ua9c8\u286a\ua6ec\u5b65\u03eb\u919e\u25af\ucad4\u6f29", "\ud9d3\udee9",
        1, 58228, 1851033219, -5341742260995230746L, 48599L, true, true, (char) 26392, (char) 47810,
        Double.longBitsToDouble(0x3fdad302e38817e2L), Double.longBitsToDouble(0x3fc734ad65d02cb0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 14, 3, "\ud9de\udef4\udae5\udc3d\udb78\udc2d\ud882\uded2\ud979\udc41\ud9e4\udc07\ud978\udc29\ud938\udd25\udafd\udded\ud91f\udc30", "\u4d4e", "\udbf7\udd63\ud929\udeb5\ud81c\ude9a\uda2b\udc38\udb2d\udc2a",
        43, 8130, -407597454, -6786241505913390650L, 36686L, false, false, (char) 47110, (char) 48287,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 1, 12, 1, 3, "\ud9de\udef4\udb8a\udc0e\udb78\udc2d\ud882\uded2\ud8e4\udf4b\uda20\udf42\ud854\ude9c", "\u62e0\u9622\u2739\u8ca2\u7869\u9ccd\u6315\ua300\ua9c8\u4459", "\udb1c\udede\ud9b9\udcf2\ud881\udfc1\udbc7\udca1\ud929\uddfb\ud923\ude08\ud987\udc14\ud9d3\udee9\ud9a7\ude83",
        48, 96179, 920507100, 1247672738851897807L, 41905L, true, true, (char) 64856, (char) 63343,
        Double.longBitsToDouble(0x3fdcc333cf9de016L), Double.longBitsToDouble(0x3fa857f195f97550L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 2, "\ud9ae\udc51\udb8a\udc0e\udb73\udd0a\u56af\ud84e\udf22\ud827\udefe\udafa\uddec\ud938\udd14", "\u9622\u56a7\u4d4e\u78a9\u9ccd\ucbac", "\uda76\udd55\ud9df\udce7\udaf9\ude97\ud83d\udcf6\ud8ca\udcc5",
        27, 90534, 1218077058, -6498107199840551234L, -55962L, false, false, (char) 25038, (char) 33584,
        Double.longBitsToDouble(0x3fedf9b6e8b8b734L), Double.longBitsToDouble(0x3fa85b37d13483f0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 1, 7, 4, 3, "\ud9de\udef4\ud83e\udc7e\udb77\udd17\ud882\uded2\ud866\udd2c\ud844\udc37\uda0c\udde7\ud91b\udc14\udafd\udded\udaff\udc01", "\u4d4e", "\udbf7\udd63\udb89\udd49\ud81c\ude9a\uda2b\udc38\uda6e\udd41",
        32, 8130, -407597454, -6786241505905067578L, 36686L, false, false, (char) 20008, (char) 48287,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 10, 19, 16, "\ud9de\udef4\udb8a\udc0e\udb78\udc2d\ud882\uded2\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\uda66\ude7f", "\u3f75", "\ud872\udf0e\udb1b\uddb3\ud849\udd30\udb7a\ude6c\udba0\uddcb\uda62\udf25\ud83d\udd89\ud9dd\udddb\udbc4\ude13\uda3f\ude72\udbd4\ude8a",
        13, 81582, -604816417, 1891517147164380138L, 42628L, true, true, (char) 17538, (char) 60164,
        Double.longBitsToDouble(0x3fd3b40833c2456cL), Double.longBitsToDouble(0x3fea8f4455f255c6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalStateException\012",
        Z.run(T, 1, 13, 4, 3, "\ud9de\udef4\udb8a\udc0e\udad5\ude36\ud882\uded2\ud866\udd2c\ud88b\udf1a\udb14\uddaa\ud938\udd14\udafd\udded\ud91f\udc30", "\u1605", "\udbf7\udd63\ud816\uddd1\ud81c\ude9a\uda2b\udc38\ud967\udde1\ud930\udcb0\ud820\udc89\ud863\ude8c\udab2\udef0\ud8bf\udffc\ud952\udcc1\ud9e4\udcaa\ud905\udeb0\ud9d3\udee9\ud805\udd92\ud8b0\uddc0\uf9d1\udaed\ude17\udb7e\udf29\ud9c6\udc71\uda65\udce8",
        10, 60412, -843437882, 5216960601554205982L, 62738L, false, true, (char) 5935, (char) 44201,
        Double.longBitsToDouble(0x3fe4b83d950ef781L), Double.longBitsToDouble(0x3fc6ca0719978c04L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 1, 17, 18, 5, "\ud9d1\udcdd\ud9c5\udd32\udb76\udd54\ud882\uded2\ud8ba\ude6b\ud8de\udda9\udafa\uddec\ud938\udd14\udafd\udded\ud91f\udc30\ud93d\ude17\uda53\udd24\uda85\udee4\uda89\udf8c\ud971\udcfa", "\u30a9\ua456\ua6cf\u6b0a", "\ud881\udfc1",
        45, 16108, -1512958482, -65444314786138641L, 99658L, true, false, (char) 33584, (char) 54939,
        Double.longBitsToDouble(0x3fec603b4ce82640L), Double.longBitsToDouble(0x3fe4caf2795797d2L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 3, "\ud9de\udef4\udb8a\udc0e\udb91\udea6\ud9ad\udf56\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\ud91f\udc30", "\u4d4e", "\udbf7\udd63\udb89\udd49\ud81c\ude9a\uda2b\udc38\ud9df\udca3",
        22, 8130, 934579826, -6786241776488007226L, 36686L, true, false, (char) 29959, (char) 48287,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 4, 19, "\ud9de\udef4\udbbe\udcfa\udaec\udd48\udbc6\uded9\udb8c\udf62\uda62\ude88\udafa\uddec\ud938\udd14\ud9e5\udd72\ud9b7\udc2d", "\ud487\u7871\u9ccd\u5aac\ua318", "\ud9df\udca3\ud9f0\udfd8",
        19, 37683, -1580044978, 3495982734530752692L, -55962L, false, true, (char) 12495, (char) 33751,
        Double.longBitsToDouble(0x3fee7e6ba744bd54L), Double.longBitsToDouble(0x3fe7dc52390530fbL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 4, 3, "\ud9f1\udcbb\udb8a\udc0e\udb78\udc2d\ud882\uded2\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\ud915\udd5e", "\u4ddb", "\udbf7\udd63\udb89\udd49",
        24, 11560, -800131130, -1503569491829985644L, 3090L, false, true, (char) 37432, (char) 15184,
        Double.longBitsToDouble(0x3fe5f76c6defff17L), Double.longBitsToDouble(0x3f784269f50d2000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 4, 3, "\ud9de\udef4\udb7c\udf48\uda0f\udfb4\udb88\udc68\ud866\udd2c\ud983\udcc9\udafa\ude7e\ud938\udd14\udafd\udded\ud91f\udc30", "\u4d4e", "\udbf7\udd63\uda4b\udceb\ud816\ude8e\uda2b\udc38\ud9df\udca3",
        35, 13394, -407597454, -6786241505905067578L, 36686L, false, false, (char) 29959, (char) 48361,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 3, "\ud9de\udef4\udb8a\udc0e\udb78\udc2d\udb1e\udde0\ud8a1\udeff\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\udade\udefe", "\u44e0\u09de\u6dcf\ud0dd\ua371\ua9c8\ud6a2", "\ud83d\udd89",
        56, 99022, 814016966, 5231601344443782638L, 881L, false, false, (char) 35114, (char) 41452,
        Double.longBitsToDouble(0x3fe6e582a7bf36ddL), Double.longBitsToDouble(0x3fd685592db94756L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 11, 4, 3, "\ud9de\udef4\udb0b\udf4d\ud8a7\udf1a\udb9c\udf7d\ud866\udd2c\ud986\udc78\udafa\uddec\ud938\udd14\ud913\udde5\ud83b\udf3f", "\u91bf\u6460\u9ccd\ucbac\u6076\u30f3\ub391\ua67f\u6b0a\u2c15\ucd80\u137a\u1ceb\uc5dc\u2b47\u5daa\u919c\uc950\u9068\u856c\u962b\u68bb\u4f62\uc3ec\u00cf\u00bc\ua74d\u745d\u10ae\u9dcf\uaa0a\uad18\uaaa8\ud5b8\u7c1d\u6d61\u9fab\uac01\u4123\uc177\u3e47\u0256\u32d5\u6dc8\u56be\u2f5c\u4eb6\u2e5b\ud214\u4017\u80b3\u429d\u6899\u939a\u497c\u372a\u5992\u79a0\u872e\u5fd4\u9ec6\u70a8\ubf57\u420d", "\ud9e1\udf7a\ud82f\udf07",
        31, 90202, -1523531241, 161511823839783132L, 60325L, true, false, (char) 40542, (char) 2207,
        Double.longBitsToDouble(0x3fb37fafbe9b1300L), Double.longBitsToDouble(0x3f997e1c282ad280L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 4, 3, "\ud9af\udd97\udb8a\udc0e", "\u85ee", "\ud938\udd14",
        2, 43525, 44472, 8863084068592297258L, 69936L, true, false, (char) 54696, (char) 61161,
        Double.longBitsToDouble(0x3fe3a8badd4ee7b4L), Double.longBitsToDouble(0x3fee862559b43084L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 15, "\udbad\udf36\ud8d2\udfa8", "\uca1e", "\uda7e\udc2c",
        50, 64817, 0, 8884877486000317738L, -88191L, true, true, (char) 21527, (char) 27385,
        Double.longBitsToDouble(0x3fe52e741f55cfb1L), Double.longBitsToDouble(0x3f4a09c532180000L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 2, 17, 1, 13, "\ud9af\udd97\udb8a\udc0e", "\ud2ee", "\udad8\udfa1",
        44, 64817, 0, 8863084068592297258L, 69936L, true, false, (char) 7393, (char) 61161,
        Double.longBitsToDouble(0x3fe39382dd4ee7b4L), Double.longBitsToDouble(0x3fdc6a1e53686108L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 1, 1, 0, 3, "\ud9de\udef4\udb8a\udc0e\ud934\uddfd\udb36\uddb1\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\ud91f\udc30", "\u46c8", "\udbf7\udd63\udb89\udd49\ud81c\ude9a\uda2b\udc38\ud9ec\udd69",
        8, 8130, -407597454, -6786241505905067578L, 36686L, false, false, (char) 29959, (char) 48287,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 19, "\ud9de\udef4\ud982\udc6b\udad0\ude95\uda8c\udfa7\udb91\udf69\ud9ba\udc46\uda87\udc0c\ud938\udc9c\ud99c\udd1c\ud91f\udc30", "\u4deb\u78a9\u9ccd\uad27\u80e9\u00d8\u97d2\u3de5", "\ud9c7\udd03\ud881\udfc1\ud86f\ude1e\udbe9\udc4b\ud9e4\udc9d\ud905\udeb0\udbc4\uddf0\udb7e\udd0e\ud9a2\udc26\ufa3f\udaed\ude17\ud999\uddf6",
        38, 21651, 1003662068, 7674835449346871995L, -84856L, true, true, (char) 59133, (char) 63207,
        Double.longBitsToDouble(0x3fdec399a2da56b8L), Double.longBitsToDouble(0x3fddb404b6126bd6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 3, "\ud9de\udef4\udb8a\udc0e\ud9e8\udc22\udac1\ude37\ud866\udd2c\ue0f1\udafa\uddec\ud9af\udc12\udb92\udf4e\ud91f\udc1d", "\u05cf", "\ud90e\udee7\uda4e\ude0c\ud81c\udefa\udae3\udd73\ud9df\udcf5\ud96e\udd24\ud986\ude06\ud9c7\udd37",
        3, 11910, -1773989964, 1576091880508587710L, 63453L, true, false, (char) 7330, (char) 46511,
        Double.longBitsToDouble(0x3fe425a6fde6112bL), Double.longBitsToDouble(0x3fe73ae81b51094bL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 14, 11, "\ud9de\udef4\udb8a\udc0e\udb78\udc2d\udb57\udfa6\udba4\udc0c\udbfb\ude7e\udbb3\udc69\udb95\uddef\ud997\udcb9\uda03\uddef\uda07\udf8f\ud813\uddc2\udbd4\udfee\udbdd\udf96\ud853\ude88\ud851\uddb9\ud9d6\udd71\ud91a\udf6b\ud8c6\udc4a", "\u3c02\u1ef5\ud526\ua618\u35e0\ub813\uc924\u4334\u13d8\ua475\u355c\ubd11\ubc9e\u8c61\u46ae\u8b31\u13dd", "\ud952\udc1e\ud868\ude9d\uda9a\uddd4\ud81b\udd74\ud98f\udfdc\udbfd\udcff\udb9e\udf63\udb52\uddcd\udb53\udd58\ud97b\udd18\ud950\udfbe\ud867\udf64\uda1c\udf43\ud903\udcd4\udbdf\udcbb\udb7f\udf14\ud908\ude2f\ud8e9\udc74\ud1e0\udb7d\udec4\udb90\udf46\ud9fa\udf8d\udafd\udc61\udbbb\uded7\ud90f\udc95\ud8f4\udc73\ud832\udd74\ud828\udd15\udb38\udfcb",
        9, 66917, 664509785, 4484784835453053384L, -88681L, true, true, (char) 54840, (char) 1134,
        Double.longBitsToDouble(0x3fe74d30addab379L), Double.longBitsToDouble(0x3fe84165ce472a6eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 2, 17, 1, 7, "\ud8c7\udd08\ud8a4\ude01\ud959\uddd3\ud882\udd65", "\ua6b6", "\ud975\udc0f\udb6f\udccc\ud8a9\udd92\ud83c\udcc3\uda89\udf4c\udaa1\uddb0\udae6\udcf7\udaaf\udf21\udb54\udc40\ud8c4\udcbc",
        9, 94846, 404558195, -7949321319702242553L, 22548L, false, false, (char) 20381, (char) 57962,
        Double.longBitsToDouble(0x3fd50b6b26ec0a1eL), Double.longBitsToDouble(0x3fdbb8db755160a8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 16, 2, "\ud9e6\udd5c\udaaf\ude07", "\u232d\u539e\u3124\u045d\u6602\u62e0", "\udbd4\udfee",
        56, 51191, 1262451448, 7025345401966812456L, 94487L, true, true, (char) 57023, (char) 65228,
        Double.longBitsToDouble(0x3fdc19fb438d43a4L), Double.longBitsToDouble(0x3fd822584bdc9134L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 3, "\ud9de\udef4\udb8a\udc0e\udb91\udea6\ud9ad\udf56\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\ud91f\udc30", "\u4d4e", "\ud9be\udfce\udb89\udd78\ud81f\udf9a\uda2b\udc38\ud9df\udca3",
        22, 8130, 934579826, -6786241776488007226L, 36686L, true, false, (char) 30215, (char) 28267,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 18, "\ud9da\udc0d\ud85e\udf52", "\u84ca\u3995\u45c8\u519b\u6602\u9d8a\u1d27\u2739\u4d4e\u78a9\u5d41\ucb1a\u5fc9\ub2ec\u5f03\u2470\u6b0a\u2c15\uca4a", "\ud9bb\udf33\ud9e4\udc9d\ud905\ude81\ud8bd\uddfe",
        -5, 4217, 1440909003, -6399566761414905881L, -22883L, true, false, (char) 13286, (char) 49111,
        Double.longBitsToDouble(0x3fe9b01b0683026eL), Double.longBitsToDouble(0x3fd20909d294a618L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 9, 2, "\ud9de\udef4\udb8a\udc0e\udb91\udea6\udaa7\udf53\udb00\udc39\ud900\udc75\ud8a8\udf98\ud938\udd14\udafd\udded\udb73\udf01", "\u7d01\u6398\u9ccd\ucb97\ua318\ua9c8\u286a\ua6ec\u6b0a", "\ud881\udf82\uda4f\udda5\ud94a\udddf\ud9e4\udc9d\ud905\ude81\ud8ab\udd95\ud805\uddc1\ud8b0\uddc0\ud8b7\udc87\udb23\udd38\u783b",
        45, 33111, -1894382, -100136265426899982L, -3464L, true, false, (char) 8675, (char) 36257,
        Double.longBitsToDouble(0x3fd19758f65ca8d4L), Double.longBitsToDouble(0x3fe8963ed03d0cf3L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 0, 7, "\ud9af\udd97\udb8a\udc0e", "\u85ee", "\ud938\udd14",
        2, 43525, -1308578376, 4480888967517884884L, 69936L, true, false, (char) 54696, (char) 61161,
        Double.longBitsToDouble(0x3fe3a8badd4ee7b4L), Double.longBitsToDouble(0x3fee862559b43084L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 2, 12, 12, 3, "\ud9af\ude91\udb8a\udc76", "\ud7bb", "\u66c1\uda2c\udfdd",
        41, 29088, -294312478, 6832619974973691230L, 73153L, false, true, (char) 3743, (char) 17344,
        Double.longBitsToDouble(0x3fead19f5639a416L), Double.longBitsToDouble(0x3fcca2d139d45d6cL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 2, 7, 7, 3, "\ud9a5\udf90\ud876\ude66", "\u8d63", "\ud938\udd14",
        2, 43525, -1845449288, 8863084407894713642L, -45995L, true, true, (char) 18432, (char) 31950,
        Double.longBitsToDouble(0x3f4ab15ba8000000L), Double.longBitsToDouble(0x3fe3a8badd4ee7b4L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.IllegalStateException\012",
        Z.run(T, 2, 17, 13, 13, "\udac9\uddc4\ud969\udf79\ud8df\udd73\u6048\ud90e\udcdb\uda71\udd40\udad0\udd94\udad8\udfa1\udb24\ude4d\ud848\udc3e\000", "\u2904\u9ccd\ucbac\ua318\ua9c8\u286a\uc63e\u72dd\u2c15\u91a6\u8dc5\u7346\u6080\u6319", "\ud88e\udd73\ud9d6\udcce\ud8ad\uddf5",
        -1, 29318, -229842394, -6024063515435219297L, -77230L, true, true, (char) 58027, (char) 3734,
        Double.longBitsToDouble(0x3fdae24a33c8e11eL), Double.longBitsToDouble(0x3fe229dee886c860L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 6, 19, "\ud9de\udef4\ud982\udc6b\udad0\ude95\uda8c\udfa7\udb91\udf69\ud9ba\udc46\ud8b3\udce2\ud909\udc2d\ud976\uddcb\ud91f\udc30", "\u8fb1\u6fc3\u9ccd\uad27\u80e9\u00d8\u97d2\u3de5", "\udb74\udf52\ud881\udfa9\ud86f\ude1e\udbe9\udc4b\ud9e4\udc9d\ud905\udeb0\udbc4\uddf0\udb7e\udd0e\ud9a2\udc26\ufa3f\udaed\ude17\ud999\uddf6",
        38, 21651, 1003662068, 7674835449346871995L, -84856L, true, true, (char) 59133, (char) 63207,
        Double.longBitsToDouble(0x3fdec399a2da56b8L), Double.longBitsToDouble(0x3fddb404b6126bd6L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 6, 10, "\ud9de\udef4\udb8a\udc0e\udb78\udc2d\udb57\udfa6\udba4\udc0c\udbfb\ude7e\udbb3\udc69\udb95\uddef\ud997\udcb9\uda03\uddef\uda07\udf8f\ud813\uddc2\udbd4\udfee\udbdd\udf96\ud853\ude88\ud851\uddb9\ud9d6\udd71\ud91a\udf6b\ud8c6\udc4a", "\u3c02\u1ef5\ud526\ua618\u35e0\ub813\ua123\u4334\u13d8\ua475\u355c\ubd11\ubc9e\u8c61\u3ae1\u6388\u9b2a", "\ud952\udc5d",
        -4, 31637, -612655205, 6301937433531655750L, 62942L, false, true, (char) 40411, (char) 12878,
        Double.longBitsToDouble(0x3fe4135f46684d9cL), Double.longBitsToDouble(0x3fe385c2e92c9a78L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 4, 3, "\ud9de\udeee\udb8a\udc0e\udb78\udc2d\ud882\uded2\ud866\udd2c\ud900\udc75\udafa\uddec\ud938\udd14\udafd\udded\ud91f\udc30", "\u4d4e", "\udbf7\udd63\udb89\udd49\ud81c\ude9a\uda2b\udc38\ud9df\udca3",
        22, 8130, -407597454, -6786241505905067578L, 36686L, false, false, (char) 29959, (char) 48287,
        Double.longBitsToDouble(0x3fef50d20683db4bL), Double.longBitsToDouble(0x3fe6e582a7bf36ddL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 2, 17, 1, 7, "\ud8c7\udd08\ud8a4\ude01\ud959\uddd3\ud882\udd65", "\ua6b6", "\ud975\udc0f\udb6f\udccc\ud8a9\udd92\u5a71\uda89\udf4c\udaa1\uddb0\udae6\udcf7\udaaf\udf21\udb54\udc40\ud8c4\udcbc",
        8, 94846, 404558195, -7949321319702242553L, 22548L, false, false, (char) 20381, (char) 57962,
        Double.longBitsToDouble(0x3fd50b6b26ec0a1eL), Double.longBitsToDouble(0x3fdbb8db755160a8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|createLocalFileHeader|org.apache.commons.compress.archivers.zip.ZipArchiveEntry,java.nio.ByteBuffer,boolean,boolean,long|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|usesDataDescriptor|int,boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|writeDataDescriptor|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|writeLocalFileHeader|org.apache.commons.compress.archivers.zip.ZipArchiveEntry,boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|writeLocalFileHeader|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|addRawArchiveEntry|org.apache.commons.compress.archivers.zip.ZipArchiveEntry,java.io.InputStream|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|addUnicodeExtraFields|org.apache.commons.compress.archivers.zip.ZipArchiveEntry,boolean,java.nio.ByteBuffer|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|canWriteEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|checkIfNeedsZip64|org.apache.commons.compress.archivers.zip.Zip64Mode|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|close||new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|closeArchiveEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|closeCopiedEntry|boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|closeEntry|boolean,boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|copyFromZipInputStream|java.io.InputStream|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|createArchiveEntry|java.io.File,java.lang.String|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|createCentralFileHeader|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|createLocalFileHeader|org.apache.commons.compress.archivers.zip.ZipArchiveEntry,java.nio.ByteBuffer,boolean,boolean,long|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|usesDataDescriptor|int,boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|writeDataDescriptor|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|writeLocalFileHeader|org.apache.commons.compress.archivers.zip.ZipArchiveEntry,boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|writeLocalFileHeader|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
