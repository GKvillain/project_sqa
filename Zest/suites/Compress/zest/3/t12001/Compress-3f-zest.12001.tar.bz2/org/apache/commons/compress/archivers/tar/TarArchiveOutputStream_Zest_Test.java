package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarArchiveOutputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 6, 9, "\uda36\ude81\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u348c", "\ud82f\udd10\ud9fa\udca8",
        8, 65201, 1554082389, -6859047895260918896L, 18697L, true, false, (char) 5340, (char) 21478,
        Double.longBitsToDouble(0x3fe02b6629bdfb72L), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 6, 9, "\uda36\ude81\udb28\udf6d\uda5f\udea1\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\udb10\udec7\udb38\udf54\uda11\udfcb\uda8e\ude4a\uda31\udf0d\ud8f9\udd0a\ud8a9\ude70\uda98\udf9b\ud833\udecc\udaff\udcaf\ud9d8\udfbb\ud9db\udf8a\ue581\ud913\udc37\ud89e\udef9\udb80\ude43\ud8fd\udfe5\ud982\udf5c", "\ud684", "\ud82f\udd75\ud9fa\udca8\ud928\udcb1\ud929\udea6\ud9db\udede\ud82b\udea5\udae1\udd9b",
        48, 18796, 970734671, 6881741025258632294L, -25684L, true, false, (char) 24501, (char) 25199,
        Double.longBitsToDouble(0x3fc3f406de6b289cL), Double.longBitsToDouble(0x3fab51fbb5fa6d20L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 1, 6, 9, "\uda36\ude81\udb28\udf6d\uda8d\udd14\ud8e1\ude58\ud9f7\udd23\ud80b\udd38\uf63e\ud8c3\udda3\udaec\udcab\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\udb3c\udced\ud979\ude9c\ud805\ude25\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd37\udba4\ude19", "\u348c", "\ud82f\udd10\ud9fa\udca8",
        8, 65201, 1554082389, -6859047895260918896L, 18697L, true, false, (char) 5340, (char) 21478,
        Double.longBitsToDouble(0x3fea6bcc771701f7L), Double.longBitsToDouble(0x3fe441bfd3a2349aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 12, 6, 9, "\uda36\ude81\udb28\udf6d\uda7e\ude14\udb3c\udfc5\ud917\udeae\ud806\udfdb\uf63e\ud990\udc9a\udaca\udf9e\ud956\udd89\ud913\udf72\ud8d3\udf4a\ud9fd\udd2d\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda40\udeca\udacd\udd44\ud819\udf31\udba4\ude19", "\u348c", "\udba5\uddcb\ud9d1\uddd3\u8d99\uda3e\udc6b\ud9c7\udfca\udbb7\udeab\udbb3\udfc7\ud908\udd92\udbd6\udf5c\udac4\udd9d\udbd1\udd46\udb3e\udca0\ud91b\uddb0\uda86\udd76\udb88\udda0\udb7f\udffb\uda8e\udc0e\udbef\udea7\ud8c6\ude12\ud8ec\udc85\ud996\udc80",
        10, 62952, 701630270, 161790661525078783L, 52259L, true, false, (char) 26436, (char) 63525,
        Double.longBitsToDouble(0x3fb6d61d8c7362d8L), Double.longBitsToDouble(0x3fd606b7dc398f52L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 11, 8, 1, "\uda87\uddca\udb28\udfbe\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\udaca\udf9e\ud932\udd1c\uda41\udcfc\ud8f9\udd0a\uda09\udd33\ud890\udd4c\ud83e\udf42\ud979\ude4a\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\ud8b0\uddc1\uda75\ude79\ud96f\uddf4\udba4\udee4", "\u348c\uab8a", "\ud9fa\udca8\u8d99",
        56, 95389, -1596996536, -5650597446434662360L, 15633L, false, true, (char) 21478, (char) 53962,
        Double.longBitsToDouble(0x3fdbdfb72d8030f8L), Double.longBitsToDouble(0x3fed11a44b6384f3L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 2, "\ud9fc\udee3\uda26\ude1f\udba3\udee3\ud932\ude1b\udbe3\udcbe\ud82a\udd99\udb33\udefa\udac2\udd27\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\ud933\udc14\uf78b\udad8\udced\ud979\ude9c\udb88\udc21\ud962\udf53\uda3b\udd22\ud912\udf49\uda98\ude55\ud9b5\udf11\udbf1\udda2\ud9f4\udfbf", "\u0437\uab8a\u374b", "\u8d99\uda03\udf9d",
        39, 69200, -1818948720, 8393471100901535949L, -43936L, false, true, (char) 39057, (char) 13447,
        Double.longBitsToDouble(0x3fe1e8c3e3a234c1L), Double.longBitsToDouble(0x3fe31b43daca6545L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 0, 9, 9, "\uda36\ude81\uca33", "\uccd6", "\ud990\udc9a\udaca\udf9e",
        54, -1000, 888857067, -1463750804327840455L, -100000L, false, false, (char) 28434, (char) 53688,
        Double.longBitsToDouble(0x3fb31e959e68b930L), Double.longBitsToDouble(0x3fd04938ad8024d6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 3, 6, 9, "\uda36\udf0b\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\uda0a\udfa1\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u348c", "\ud82f\udd10\ud9fa\udca8",
        8, 77361, 1554082389, -6859047895260918896L, 18697L, true, false, (char) 5340, (char) 21478,
        Double.longBitsToDouble(0x3fe1236629bdfb72L), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 7, 14, "\uda3b\udfc9\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\ud83f\uddd7\ud8f8\udd1f\uda41\udcfc\u00ee\ud9f3\udf05\udbd7\ude6b\uda65\udf2c\ub01f\ud992\uded0\uda3a\ude51\udb99\udc57\udb73\udcc4\uda04\udc85\ud9cd\uddf4\udac5\udd68\udba4\ude19", "\u30e2", "\ud84b\udc10\ud9fa\udca8",
        13, 70058, 1503586101, -6906425211351659632L, 18697L, true, false, (char) 5340, (char) 21478,
        Double.longBitsToDouble(0x3fe02b6629bdfb72L), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 12, 9, "\uda36\ude91\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\udbd6\udc9d\udaca\udf9e\ud875\udf20\ud884\ude7f\ud8f9\udd0a\udb9b\udd76\uda83\udcf4\ud985\udc39\ud984\udea3\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u348c", "\uda0a\udfa4\uda07\ude9d",
        4, 62112, 9279227, -8884475941383779455L, 18636L, true, false, (char) 5340, (char) 21478,
        Double.longBitsToDouble(0x3fdba94f537bf76eL), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 11, 8, 1, "\uda36\ude81\udbfe\udfb9\ud93f\udf68\uda16\udc82\udbd9\udfa1\uf4a5\ud88d\udc2d\ud964\udfe8\uda07\udfc0\ud813\udf22\uda41\udcfc\udb91\udc04\udb51\udcbc\udbd7\ude5c\ud8cf\ude98\ud924\udca6\udaf4\udd0e\ud8fc\ude14\udb9f\udd31\ud913\udc37\ud83f\udfee\ud8e5\udf9b\udb29\udcda\udb72\ude67", "\ub4d0", "\uda60\udd28\udaa7\udeff\ud871\ude3f\ud96f\udf4b\ud9cd\udece\ud8ee\udc65\udbc3\udf09\ud908\udce1\ud853\udd1c\ub364\udb2f\udca0\u42cf\udab5\uddb2\udab4\udecb\ud827\udd74\ud915\uddf8\udbc6\udf19\uda09\uddfb",
        14, 49913, -481441968, 4353009714662849018L, -20313L, false, false, (char) 15393, (char) 10756,
        Double.longBitsToDouble(0x3fead99629618cc3L), Double.longBitsToDouble(0x3fe6e99e36b719c4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 4, 7, "\u8017\udb96\uddf8\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\ud928\udd2a\uda72\udd56\ud8dd\udf60\ud958\udfa7\udaa4\udf77\ud8e6\udda9\uda47\udfe9\ud94b\uddbc", "\u348c", "\ud82f\udd10\ud9fa\udca8",
        8, 65201, 1554082389, -6859047895260918896L, 18697L, true, false, (char) 5340, (char) 21478,
        Double.longBitsToDouble(0x3fe02b6629bdfb72L), Double.longBitsToDouble(0x3fe1e8c3e0a234c1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 7, 6, 9, "\u270c\udadc\udd2d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u348c", "\ud82f\udd10\ud9fa\udca8",
        8, 65201, 1554082389, -6859047895260918896L, 18697L, true, false, (char) 5340, (char) 21478,
        Double.longBitsToDouble(0x3fe02b6629bdfb72L), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 6, 9, "\uda36\ude81\udb28\udf6d\u8808\udb3d\udc19\udaac\udcb9\ud80b\udd38\uf63e\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8d0\ude0a\uda09\udd33\udbd7\ude6b\udad0\udc5e\u48df\udb9a\udcf8\ud9db\udf45\ue633\ud84c\udc31\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u3f83\u7bd7", "\ud9fa\udca8\u8d99",
        52, 65717, -731316824, -5650597446434662360L, 34133L, true, false, (char) 13616, (char) 22201,
        Double.longBitsToDouble(0x3fed11a60a32b9f5L), Double.longBitsToDouble(0x3f80c8d4e4b65b00L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 11, 6, 9, "\uda36\ude81\udb28\udf6d\u00cb\udb3c\udf7d\ud8a9\udd56\u483d\uf63e\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud970\ude70\ue57d\ud913\udc37\uda98\ude55\ud8f0\udc4e\000\000", "", "\udb55\udc99",
        -1, -1000, 0, 5836665118626245205L, 93648L, false, false, (char) 46303, (char) 9742,
        Double.longBitsToDouble(0x3fe801cee4665f80L), Double.longBitsToDouble(0x3f75b314defdb900L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 6, 12, 13, "\uda4d\udd71\udb08\udd6d\uda2b\udee4\ud80f\uddb0", "\u57e8\u43c8?\u0f03\u699c\ubaac\u7e52\u6556\ubca5\u53f0\u4b4a\u0bce\u8717\u17b0", "\udae4\udd9e\udba4\ude19\uda8c\udec3\udb66\ude4c\ud887\udf25\ud8ed\uddd4\udb55\udc99\ud82f\udd10\ud9ee\udea8\u8d99\ud9f9\udd63\ud9e8\udce1\ud832\udd84\ud927\udd48\u1daf\uda79\uddf7\udba2\udc03\udb3a\udca0\u42cf\ud911\uddc0\ud972\udf2e\u441d",
        4, 22275, -77174062, 1695199980065468207L, 5474L, false, true, (char) 6494, (char) 47620,
        Double.longBitsToDouble(0x3fec2b8eb8449ce9L), Double.longBitsToDouble(0x3fdc6eefde41157eL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 11, 6, 9, "\uda36\ude81\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u348c", "\ud82f\udd10\ud9cf\udfa8",
        8, -847, 1554082304, -6859047895260918896L, 18697L, true, false, (char) 5340, (char) 21478,
        Double.longBitsToDouble(0x3fe02b6629bdfb72L), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 7, 7, 9, "\uda36\ude81\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u348c", "\ud82f\udd10\ud9fa\udca8",
        8, 65201, 1554082389, -6917313215440024688L, 18697L, true, false, (char) 5340, (char) 128,
        Double.longBitsToDouble(0x3fe02b6001bdfb72L), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 11, 9, "\uda36\ude81\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\u40e6\ud8a0\udc35\uda55\udc66\ud916\ude41\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u348c", "\ud82f\udd10\ud9fa\udca8\u8d99",
        4, 95389, -1596996536, -5650597446434663640L, 77734L, false, true, (char) 58597, (char) 29203,
        Double.longBitsToDouble(0x3fdbdfb72c7a30f8L), Double.longBitsToDouble(0x3fed11a608b745dfL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 10, 6, 14, "\ud9f8\ude25\udb28\udf6d\udb34\udde9\udad6\udf28\ud8a9\udd56\ud80b\udd38", "?\u0f03\u3bee\u0908\u7e52\ua71c", "\udb88\udc21\ud9db\udf45\ue633",
        13, 29936, 388409420, -7815368451384680188L, -91063L, false, false, (char) 19073, (char) 11392,
        Double.longBitsToDouble(0x3fb7542191982568L), Double.longBitsToDouble(0x3fd8edb3e132c9e6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 0, 0, 12, "\uda36\ude81\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\uf63e\uda29\udfb4\udaca\udf9e\ud8f8\udd1f\udb03\udd9e\ud8f9\udc1f\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb84\ude21\ud9db\udf45\udbfb\udd7c\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u8fb3", "\ud82f\udd10",
        -5, 38198, 1363970201, 6674733034447553608L, 28102L, true, false, (char) 13616, (char) 22201,
        Double.longBitsToDouble(0x3fed11a60e5dcb3bL), Double.longBitsToDouble(0x3fbbfb9a552fb800L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 6, 6, 9, "\uda36\ude81\udb28\udf6d\uda8d\udd14\udb3c\udfc5\udb5f\ude13\ud996\udc37\uda1b\udf87\ud990\udc9a\udaca\udf9e\ud8f8\udd1f\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\u348c", "\ud82f\udd10\ud9fa\udca8",
        8, 65201, 1554082389, -6859047895333818448L, 43447L, true, false, (char) 40759, (char) 21390,
        Double.longBitsToDouble(0x3fe02b6629bdfb72L), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 12, 12, 3, "\uda36\ude81\udb28\udf6d\ud817\udc3a\udb93\udf93\ud9f7\udd23\ud80b\udd38\udac5\uddc2\ud8c3\udda3\udaec\udcab\ud8f8\udd1f\uda41\udcfc\ud8eb\udf0a\uda09\udd33\udbd7\ude6b\udb3c\udced\ud979\udddc\ud9a7\udefe\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\ud887\udd38\udbef\udcde", "\u348c\u996c\u955d", "\ud9f8\udfe3\ud9f9\udd63",
        15, 14631, -1315632240, -8896764135421890473L, -80032L, false, false, (char) 32784, (char) 42608,
        Double.longBitsToDouble(0x3fe41570c0a2349aL), Double.longBitsToDouble(0x3fc8aeca9575cf24L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 11, 8, 1, "\000\udb28\udfbe", "\000\000", "\udaca\udf9e",
        53, 46225, 888799232, 200549202919424L, -29871L, false, false, (char) 46151, (char) 23769,
        Double.longBitsToDouble(0x3fdcfebf1d8024d6L), Double.longBitsToDouble(0x3fc6088f000385fcL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 11, 8, 1, "\uda87\uddca\udb28\udfbe", "\uace2", "\ud990\udc9a\udaca\udf9e",
        53, 46225, 888857067, -1463750804932550087L, -29871L, false, true, (char) 46151, (char) 0,
        Double.longBitsToDouble(0x3ece3b0049ac0000L), Double.longBitsToDouble(0x3fc6088f10ab85fcL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=void |a0=[B:[[87, -102, 41, 38, 93, -28, -10, -119]] |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 6, 8, 1, "\uda87\uddca\ud859\udd56\uda8d\udd14\ud826\udcb9\ud8a9\udd56\uda06\uddd6\uf63e\ud990\udc9a\udb3d\udf53\ud83a\udd5d\uda41\udd0f\ud90e\udc79\ud9e6\uddbb\ud8a7\udc26\uda7f\ude27\ud98e\ude4b\udb97\udda8\ud967\ude2b\ue93a\ud913\udc37\ud8b0\uddc1\uda75\ude79\ud962\udd2e\udba4\udee4", "\u348c\uab8a\u374b\u9717\u67ae\ubc41\u20f4\u401e\u8376\uab3a\u55d2", "\udb3a\udca0\u42cf\ud911\uddc0\ud91c\udd23\ud8c0\udd2f\u883f",
        53, -762, -1839614958, -4899705103901841891L, -80084L, true, true, (char) 9259, (char) 28609,
        Double.longBitsToDouble(0x3fbdc96e446738e8L), Double.longBitsToDouble(0x3fe890e24cf9efcaL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 11, 8, 11, "\000", "\u4ef1\uab93\u4792", "\udaca\udf9e",
        53, 46225, 888799232, 200549202919424L, -29871L, false, false, (char) 46151, (char) 23769,
        Double.longBitsToDouble(0x3fdcfebf1d8024d6L), Double.longBitsToDouble(0x3fd924478001c2feL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 6, 0, "\uda36\ude81\udb28\udf6d\uda8d\udd14\udb3c\udfc5\ud8a9\udd56\ud80b\udd38\ud835\udfc3\ud8a5\udf65\udaf3\udf66\ud8ef\udfda\uda41\udcfc\ud8f9\udd0a\uda09\udd33\udbd7\ude6b\ud957\udf5c\ud979\ude9c\udb88\udc21\ud9db\udf45\ue633\ud913\udc37\uda98\ude55\ud8e6\udda9\udac5\udd68\udba4\ude19", "\ud192", "\ud82f\udd10\ud9fa\udca8",
        8, 65201, 1554082389, -2035922492277276431L, 18697L, true, false, (char) 10522, (char) 21402,
        Double.longBitsToDouble(0x3fe02b6629bdeec7L), Double.longBitsToDouble(0x3fe1e8c3e3a234c1L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |a0=[B:[[87, -102, 41, 38, 93, -28, -10, -119]] |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=void |a0=[B:[[87, -102, 41, 38, 93, -28, -10, -119]] |this=org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 8, 8, 1, "\uda87\uddca\ud859\udd56\uda8d\udd14\ud826\udcb9\udadd\uddb0\uda06\udddb\uf63e\ud990\udc9a\udb3d\udf53\ud83a\udd5d\uda41\udd0f\ud90e\udc79\ud9e6\uddbb\ud8a7\udc26\uda7f\ude27\ud98e\ude4b\udb97\udda8\ud967\ude2b\uda96\ude04\ud90f\udfce\ud8b0\uddc1\uda75\ude79\ud962\udd2e\udba4\udee4", "\u348c\uab8a\u5a13\u671a\u91fb\u3319\u211f\u401e\u8376\uab3a\u55d2", "\udb3a\udca0\u42cf\ud911\uddc0\ud91c\udd23\ud8c0\udd2f\u883f",
        53, -762, -1839614958, -4899705103426247139L, -80084L, true, true, (char) 41387, (char) 39407,
        Double.longBitsToDouble(0x3fbdf6f3c46738e8L), Double.longBitsToDouble(0x3fe890e24cf9efcaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|closeArchiveEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|finish||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|putArchiveEntry|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|close||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|createArchiveEntry|java.io.File,java.lang.String|new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|flush||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|getRecordSize||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|setLongFileMode|int|new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|write|[B,int,int|new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|writeEOFRecord||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream,int,int",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream,int",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|closeArchiveEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|finish||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|putArchiveEntry|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
