package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarArchiveEntry_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 6, 13, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91\uda49\udc06\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d\ud8af\ude8d\udb0c\udef3\ud808\udfd6\ud984\udea1\ud8a6\uddc8\udaeb\uddd6\ud814\udc6b\udbfd\uddaa\ud955\udcf5\udaa0\ude1f\ud889\udcac\udb8a\uddc7",
        33, 30461, 1325747216, 7499045965869731624L, 44901L, false, true, (char) 10671, (char) 35436,
        Double.longBitsToDouble(0x3fd2e265ea00a0c2L), Double.longBitsToDouble(0x3fead12c7db5d496L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 6, 13, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udbef\ude83\ubd26\ud96b\udc91\uda49\udc06\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d\ud8af\ude8d\udb0c\udef3\ud808\udfd6\ud984\udea1\ud8a6\uddc8\udaeb\uddd6\ud814\udc6b\udbfd\uddaa\ud955\udcf5\udaa0\ude1f\ud889\udcac\udb8a\uddc7",
        33, 30461, 1325747216, 7499045965869731624L, 44901L, false, true, (char) 10671, (char) 35436,
        Double.longBitsToDouble(0x3fd2e265ea00a0c2L), Double.longBitsToDouble(0x3fead12c7db5d496L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 8, "\uda52\udc2b\udbbe\udfc6\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91\ud894\udff0\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\uda90\udc92\u72a3\ud9a4\udf3e\ud815\udf29\ud9b1\uddc8\uda5a\udccf\ud928\ude27\ud8cb\udf8e\udba0\udc4a\ud9e8\udd47", "\ua90e", "\ud948\udc55\udaf1\udc56\udba6\udcf9",
        21, 92516, -1623105148, 632906347118636056L, 89949L, false, true, (char) 18014, (char) 54986,
        Double.longBitsToDouble(0x3f838b921ed01fc0L), Double.longBitsToDouble(0x3fefece5dab8da90L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 1, 13, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\udaa2\udcad\ud950\uddb7\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\uc835\ua0c8\u9ac9\u7a1e\u9a99\u7860\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d\ud8af\ude8d\udb0c\udef3\ud808\udfd6\uda8b\udecc\ud8b8\udcbc\udaeb\udd98\uda8a\udc46\ud802\ude5f\ud86b\udcc4\udac8\udfe4\ud889\udcac\udb32\ude3c",
        33, 30432, 1325747216, 7499045965869731624L, 44901L, false, true, (char) 10671, (char) 35436,
        Double.longBitsToDouble(0x3fd2e265ea00a0c2L), Double.longBitsToDouble(0x3fead12c7d5cd496L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 6, 13, 8, "\udba0\udf7b\udbd7\udc7c\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\udb46\udc90\ud96b\udc91\uda49\udc06", "\u4a24\u3859\ua4dc\u2aae\u0531\u4305\u675b\u06dc\u0912\u9889\u2a61\u5413\ucd1d\ud7c6\u03d0\u49fc\u10e5\u0195\u57ca\ua741\u78bc\u2381", "\ud8df\udf00",
        16, 63883, -51302597, 3917589999717557858L, -91931L, true, true, (char) 36168, (char) 59947,
        Double.longBitsToDouble(0x3fd0d07a1318be3aL), Double.longBitsToDouble(0x3fca673c835748b4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 1, 6, 13, 8, "\udae7\uddb5\ud873\udfd0\uda47\udd39\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91", "\u1aea\u3fcf\u3859", "\udade\udd5e\uda75\udc9a\ud987\udf0a\uda38\udc51\udaa9\udde7\ud8cb\udf8e\ud958\udea6",
        3, 7277, 1870519148, -6743767999051302644L, -86151L, false, true, (char) 49757, (char) 48406,
        Double.longBitsToDouble(0x3fef7591d98475c3L), Double.longBitsToDouble(0x3fcf13e830602320L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 10, 13, 3, "\udae7\uddb5\udbf1\udde1\udb47\udcd1\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91\uda49\udc06\ud900\udf17\ud84c\ude32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud9b6\udf6f\udbb1\ude29\ud83b\udc58\uda27\udebe", "\u9dd1\u500a\u1f12\ud30f\uc488\u9a99\u936e\u4387", "\ud8df\udeb1\ud9b0\udf32",
        39, 33788, 912135001, -4194638636999790583L, -19330L, true, true, (char) 21863, (char) 5237,
        Double.longBitsToDouble(0x3fd8c5fc79a673c8L), Double.longBitsToDouble(0x3fc0da45b1740160L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 15, 5, 14, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\ud896\udf1c\ud801\udf73\ud96b\udc91\uda49\udc06\ud900\udf17\ud833\udc32\udab0\udc16\ud8b0\uddf6\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\uda8e\udf6c\ud9d5\udcce\udbfb\udd63\ud808\udfd6\ud984\udea1\ud8a6\uddc8\udaeb\uddd6\ud814\udc6b\udbfd\uddaa\ud955\udcf5\udaa0\ude1f\ud889\udcac\udb8a\uddc7",
        33, 30461, -222633968, 7551211710934011688L, 44901L, false, true, (char) 1711, (char) 35399,
        Double.longBitsToDouble(0x3fd2e265ea00a0c2L), Double.longBitsToDouble(0x3fead12c7db5d496L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:[[]] |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 6, 9, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91\uda49\udc06\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udac9\udf10\udad3\udd67\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud9bb\udf86\ud83b\udc58\uda27\udebe", "\u03d0\u500a\u1f69\ud30f\uc488\u1c14\ud367\u2325", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d\ud8af\ude8d\udb0c\udef3\ud808\udfd6\ud984\udea1\ud8a6\uddc8\udaeb\uddd6\ud814\udc6b\udbfd\uddaa\ud955\udcf5\udaa0\ude1f\ud889\udcac\udb8a\uddc7",
        5, 62018, 1325752307, 7499045965869731624L, 16157L, false, true, (char) 10671, (char) 35436,
        Double.longBitsToDouble(0x3fd2e265ea00a0c2L), Double.longBitsToDouble(0x3fead12c7db5d496L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 0, 13, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91\uda49\udc06\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\u8584\u52fe\u0bbe\uc488\u9a99\u7860\u2381", "\ud998\udcae\ud9df\udf47\ud9f3\udd39\udb6f\udf9d\ud8af\ude8d\udb0c\udef3\ud808\udfd6\ud984\udea1\ud8a6\uddc8\udaeb\uddd6\ud814\udc6b\udbfd\uddaa\ud955\udcf5\udaa0\ude1f\ud889\udcac\udb8a\uddc7",
        33, 30461, 1325747216, 7499045965869731624L, 44901L, false, true, (char) 10671, (char) 35436,
        Double.longBitsToDouble(0x3fd2e265ea00a0c2L), Double.longBitsToDouble(0x3fead12c7db5d496L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 6, 1, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\udb6f\udc6f\ud960\udf2b\udaf6\udc66\ud8ab\ude7a\ud8c2\udd27\uda49\udc06\ud900\udf17\uda1f\udcbf\udb75\udc58\ud87c\udd5f\ud9f4\ude84\u5fa8\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\ud66e\uc172\u5fae\uc488\u9a99\u7860\u2381", "\ud8df\udeb1\ud8a3\udfcb\udac2\udca5\udb6f\udf9d\ud8af\ude8d\udb0c\udef3\ud808\udfd6\ud984\udea1\ud9da\udf02\udaeb\uddab\ud814\udc6b\udbfd\uddaa\ud955\udcf5\udaa0\ude1f",
        57, 40005, -799787327, 9021962218092415087L, 18568L, false, false, (char) 36038, (char) 2907,
        Double.longBitsToDouble(0x3fdfb42712019552L), Double.longBitsToDouble(0x3fe7d7796946c926L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 0, 0, 0, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubcf0\ud967\udf89\uda49\udc06\ud900\udede\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud89b\udd32\uda38\udc51\ud928\ude27\ud8cb\udf8e\udbbd\udc39\uda27\udebe", "\u03d0\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381", "\ud8df\ude99",
        16, 78539, -51302452, 3917589997855286882L, -99877L, false, false, (char) 36168, (char) 300,
        Double.longBitsToDouble(0x3f780000c6000000L), Double.longBitsToDouble(0x3fca673c835748b4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 4, 15, "\ud80a\udeaf\udbf1\udde1\udbd1\udcf7\u8307\ud97c\ude1d\udaf6\udc66\ubd26\ud98a\ude96\uda49\udc06\ud900\udf17\ud833\udc32\uda83\udfbf\ud962\udfc3\udaa3\udddc\ud8f0\udddf\ud9ac\udd82\udba0\udc32\u7514\uda3c\ude2c\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u3cb4\u9e98\u917f\ud313\u0f7f\u0814\uc0b5\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d\udb7c\udd33\ud959\udc17\udbbc\udf27\ud88b\uddd3\ud924\udfe7\udb9d\udfcc\ud8ac\ude04\ud8a8\uddb5\ud97b\uddf5\udaa0\ude1f\ud889\udcac\udb8a\uddc7",
        33, 30461, 1325747216, 7499045965869731624L, 44901L, false, true, (char) 10671, (char) 54482,
        Double.longBitsToDouble(0x3fd2e26fba00a0c2L), Double.longBitsToDouble(0x3fe8192c7d805546L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 3, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\uda0e\udf1b\uda49\udc06\ud900\udf17\ud833\udc32\ud8d3\udf47\ud895\udf34\udaa3\uddb5\u5f6b\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d",
        6, 28586, 1082109961, -7152876764890383363L, -99604L, true, false, (char) 13059, (char) 3464,
        Double.longBitsToDouble(0x3fe60adf6855d054L), Double.longBitsToDouble(0x3fbbcf9d785e8040L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 6, 6, 4, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\udaf1\udcc7\ud939\udf14\uda49\udc06\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\uda6f\udecb\ud9e9\ude6c\udb03\udfa4\ud9ed\udff7", "\u03d0\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d\ud8af\ude8d\ud9d9\udcf8\udbb5\udd82\ud984\udea1\ud8a6\uddc8\udaeb\uddd6\ud814\udc6b\ud8cc\udd12\ud955\udcfd\udb1b\ude1d\udaab\ude89\udb8a\uddc7",
        33, 30461, 1325747216, 7499045965869731624L, 44901L, false, true, (char) 10671, (char) 21828,
        Double.longBitsToDouble(0x3fcb0bb4f4013594L), Double.longBitsToDouble(0x3fee06747ea4551cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 1, 0, 13, 8, "\udae7\uddb5\udbf1\udde1\udbc4\udef7\u8307\ud960\udf2b\u5677\000\000\uda49\udc00\ud900\udf17\ud833\udc32\udab0\udc16\udae4\udd78\000\uda17\ude6a\000\udaf3\udf19\ud987\ude89\uda38\udc51\ud928\ude27\ufa08\ud80c\udc25\uda27\udebe", "\u03d0", "\ud948\udc55\udaf1\udc56\udba6\udcf9",
        21, 92734, -1623105148, 576461817455312920L, 89949L, false, true, (char) 3930, (char) 56511,
        Double.longBitsToDouble(0x3f838b921ed01fc0L), Double.longBitsToDouble(0x3fefece5dab8da90L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 2, 13, "\ud85d\ude10\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\udb45\udc31\ud96b\udd00\uda49\udc06\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\u3ebd\ud996\udfbe\ud8b0\uddf7\ud911\udec1\ud83b\udc58\uda27\udebe", "\u03d0\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d\ud8af\ude8d\udb0c\udef3\ud808\udfd6\ud984\udea1\ud8a6\udd2b\udaeb\uddd6\ud814\udc6b\udbfd\uddaa\ud921\udd9b\udbef\udfdd\ud889\udcac\udb8a\uddc7",
        33, 12749, -819482566, -5041878120311959699L, -76951L, false, true, (char) 10671, (char) 51564,
        Double.longBitsToDouble(0x3fdff629bcd016ccL), Double.longBitsToDouble(0x3febfdfa6824d496L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 13, 13, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91\uda93\udecb\ud900\udf3b\ud831\uddd8\udbcd\udfb6\u6efd\udaa3\udddc\ud85e\udd2e\ud9b2\ude41\udb25\udcfa\ud8c1\udfc6\ud99f\udcb4\uda82\udd37\uda46\uddb2\ud9fa\udf31\uda54\udd01", "\u7133\u48ee\u1f7d\ud30f", "\u2339\uda8b\udede\udb7d\udd76\ud931\udd91\ud8df\udeb1\udb8b\udd3c",
        58, 71097, 1409310598, 858343829870598123L, 77795L, false, false, (char) 13059, (char) 3464,
        Double.longBitsToDouble(0x3fe60adf6855d054L), Double.longBitsToDouble(0x3fe21f93ae934ff1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 13, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\ud881\udf36\udaed\udcff\udb62\udeac\ud860\ude07\ud96b\udc91\ud8e7\udeb6\ud91b\udf74\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\udb6d\ude43\udb25\udc34\ud987\ude89", "\u7122\u4f1d", "\u7235\ud80d\udd38\ud940\udfe9\uda1c\udcb0",
        41, 17022, 143364217, -5603686795968274450L, 84372L, true, true, (char) 56511, (char) 30162,
        Double.longBitsToDouble(0x3fbed01fdfece5d8L), Double.longBitsToDouble(0x3fe5c6d4843b34f1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 3, 8, "\udb7e\udc62\udbf1\ude72\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91\uda49\udc06\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udaa3\udddc\u5f6b\ud9a4\udea7\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381", "\ud8df\udeb1\ud9b0\udf32\ud9f3\udd39\udb6f\udf9d\ud8af\ude8d\udb0c\udef3\ud808\udfd6\ud984\udea1\ud8a6\uddc8\udaeb\uddd6\ud814\udc6b\udbfd\uddaa\ud955\udcf5\udaa0\ude1f\uda81\udfe0\udba7\udc58",
        33, 30461, 1325747216, 7499045965869731624L, 44901L, false, true, (char) 10671, (char) 35436,
        Double.longBitsToDouble(0x3fd2e265e9baa78aL), Double.longBitsToDouble(0x3fa1cf4c7a7424a0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 1, 13, 8, "\uda52\udc2b\udbbe\udfc6\u5739\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud96b\udc91\ud894\udff0\ud900\udf17\ud833\udc32\udab0\udc16\ud87c\uddc4\udbb6\udc85\u72a3\ud9a4\udf3e\ud815\udf29\ud9b1\uddc8\uda5a\udccf\ud928\ude27\ud8cb\udf8e\udba0\udc4a\ud9e8\udd47", "\ua90e", "\ud948\udcc3\udaf1\udc56\udba6\udcf9",
        21, 92516, -1623105148, 632906347118636056L, 89949L, false, true, (char) 18014, (char) 54986,
        Double.longBitsToDouble(0x3f838b921ed01fc0L), Double.longBitsToDouble(0x3fefece5dab8da90L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 4, 10, "\ud9f0\udf7c\ud8f2\uddb2\ud96f\ude78\ubb1e\ud8ac\udeb2\udaa5\udc5a\udb11\udd40\uefd9\ud8b0\udf92\uda82\udf7f\uda0f\udcf9\uda81\udc8f\ud87c\udd8e\uda90\udc92\u72a3\ud9a4\udf3e\ud815\udf29\ud9b1\uddc8\uda5a\udccf\ud928\ude27\ud8cb\udf8e\ud9c9\udfff\ud9e8\udd01", "\u6b6e", "\ud948\udc55\ud97a\udd7b\udaf2\udf32\uda6f\udc3b\uda24\udd52\ud9e4\udf88\ud866\udeef\ud8df\udf88\ud9b0\udf32\ud948\udc02\udbb0\udfc2\ud8a5\uddc6\udb09\udc50\ud808\udfd6\ud984\udea1",
        3, 25008, 1138726072, 364405255734143112L, -38607L, true, true, (char) 1965, (char) 398,
        Double.longBitsToDouble(0x3fd3dd55b19a8856L), Double.longBitsToDouble(0x3fc7ff85cf0d9cfcL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 3, 3, "\uda99\udee9\udbd9\uddb0\udbd1\udcf7\u8307", "\u222e\u6c51\u518f\u433e", "\ud87c\uddc4\uda90\udc92\ud93d\udead",
        27, 53974, -227465579, 3489601367791619745L, -24243L, true, true, (char) 61727, (char) 64377,
        Double.longBitsToDouble(0x3fdfbf4e223c5474L), Double.longBitsToDouble(0x3fe85095ce19fdeaL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 1, 1, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud90b\udff5\ud91b\udce5\uda24\udd69\ud9a4\udf5c\udab0\udc16\udb5e\udd15\ud839\ude1b\ud8f0\udf87\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\uc835\ua0c8\u9ac9\u7a1e\u1628\u99b3\uaaaa", "\udb74\udcbe",
        28, 78539, -60701492, 3917589997855286882L, 5851L, true, false, (char) 36106, (char) 300,
        Double.longBitsToDouble(0x3fc6179cb1cb62c8L), Double.longBitsToDouble(0x3fe4c02b90d5d22dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\ud806\ude77", "\u222e\u3641", "\ud833\udc32\ud81c\ude4a\ud891\udc19\udaa3\udddc\u5f6b\ud9a4\udf3e\udb25\udc34\ud80d\udeec\ud891\udf34\ud910\udd67\ud8a2\udf8e\u4183",
        20, 57310, 1870519203, -6743767999384804495L, -69939L, false, false, (char) 49718, (char) 48406,
        Double.longBitsToDouble(0x3fef7591d98475c3L), Double.longBitsToDouble(0x3fcf13e827d46630L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:[[]] |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=[Lorg.apache.commons.compress.archivers.tar.TarArchiveEntry;:[[]] |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 9, 9, 15, "\udba0\udf7b\udbd7\udc7c\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\udb46\udc90\ud96b\udc91\uda49\udc06", "\u4a24\u3859\ua4dc\u2aae\u0531\u4305\u675b\u06dc\u0912\u9889\u2a61\u5413\ucd1d\ud7c6\u03d0\u49fc\u10e5\u0195\u57ca\ua741\u78bc\u2381", "\ud8df\udf00",
        16, 63883, -51302597, 3917589999717557858L, -91931L, true, true, (char) 36168, (char) 59947,
        Double.longBitsToDouble(0x3fd0d07a1318be3aL), Double.longBitsToDouble(0x3fca673c835748b4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 10, 10, 3, "\udae8\uddb5\udb75\udde5\udb47\udcd1\u8307\ud960\udf2b\udaf6\udc66\ubd26\uda20\udc6d\ud8e2\udd64\ud9e7\udeb1\udb70\uddf3\ud8e2\uddae\ud87c\uddc4\ud9ca\uddd6\udba2\uddf5\udade\ude9f\ud820\uddcd\udaab\uddf4\uda1b\udc07\ud9b6\udf6f\udbb1\ude29\uda9f\udeab\ud9f5\udfe9", "\u238c\u500a\u4208\u2e2f\u05c2\u2262\ua20f\u7597\u5443\ud360\u585b\u18ed\ua1bc\u9c02\ud227\u8963\ua47a\u2e46\u1b9b\u5df2\u101b\u0188\ua628\u533b\u9ddf\u51b5\u2676\u730b\u5671\u7ec8", "\udadd\udd04",
        10, 79686, -1192409418, -6650829064453869749L, 27683L, true, false, (char) 50731, (char) 57582,
        Double.longBitsToDouble(0x3fef66763b4238c1L), Double.longBitsToDouble(0x3fd78550b6512858L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 3, 3, "\udae7\uddb5", "\u8a69\u2e44\u4d69\u222e\ub6f2\u6f2e\u433e\u1aea\u9067\u9dc9", "\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58",
        24, 92314, 8248227, -6743858966458631924L, -86151L, false, true, (char) 49757, (char) 48406,
        Double.longBitsToDouble(0x3fef7591d98475c3L), Double.longBitsToDouble(0x3fe7c38a0c1808c8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 0, "\u17a6", "\uce8f\u1f99\ub136\u6dc3\u6c51\u5450\uaf9b\u1aea\u3fcf\u3859", "\udb6d\ude43\uda8f\udc29\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58",
        24, 92314, 1870519203, -6743767999051302407L, -86151L, false, true, (char) 49757, (char) 48406,
        Double.longBitsToDouble(0x3fef7591d98475c3L), Double.longBitsToDouble(0x3fcf13e830602320L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 1, 1, 8, "\udae7\uddb5\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\udaa2\udcbf\udb61\udd5c\uda24\udd6f\ud9a4\udf5c\udab0\udc16\udb5e\udd15\ud8c1\ude1f\ud8f0\udf87\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud928\ude27\ud8cb\udf8e\ud83b\udc58\uda27\udebe", "\u03d0\uc835\ua0c8\u9ac9\u7a1e\u1628\u99b3\uaaaa", "\udb74\udcbe",
        30, 78652, 1549911244, -2602660556285395363L, 5851L, true, false, (char) 36106, (char) 300,
        Double.longBitsToDouble(0x3fe13f235472d8b2L), Double.longBitsToDouble(0x3fe4c02b90d5d22dL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\0121=java.util.Date:Wed Dec 31 16:00:00 PST 1969 |this=org.apache.commons.compress.archivers.tar.TarArchiveEntry:org.apache.commons.compress.archivers.tar.TarArchiveEntry@0\012",
        Z.run(T, 2, 6, 13, 8, "\ud845\udf78\udbf1\udde1\udbd1\udcf7\u8307\ud960\udf2b\udaf6\udc66\ubd26\ud9e8\udcb1\uda49\udc30\ud90a\uddbc\ud833\udcab\uda97\udf16\ud87c\uddc4\ud9d4\udc74\u8436\ud9a4\udf3e\udb25\udc34\ud987\ude89\uda38\udc51\ud98a\udc57\ud4fd\udaac\uddc9\ud85b\ude81", "\u036d\u500a\u1f12\ud30f\uc488\u9a99\u7860\u2381\u5eda\ud360\u585b\u18ed\ua1bc\u171f", "\ud808\udfd6\udb16\udc70\ud8a6\uddae\udadc\udfd6\ud814\udc6b\ud875\udc9e\udbe2\udc7a\udaa0\ude1f",
        57, 99933, -799741759, 556318065689818787L, 18568L, false, true, (char) 35495, (char) 2938,
        Double.longBitsToDouble(0x3fdfbf0d42019552L), Double.longBitsToDouble(0x3fe40f796946c926L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|isDirectory||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|equals|java.lang.Object|new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|equals|org.apache.commons.compress.archivers.tar.TarArchiveEntry|new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|evaluateType|[B|new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|fillGNUSparse0xData|java.util.Map|new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|fillGNUSparse1xData|java.util.Map|new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|fillStarSparseData|java.util.Map|new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getDevMajor||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getDevMinor||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getDirectoryEntries||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getFile||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getGroupId||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getGroupName||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getLastModifiedDate||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getLinkName||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|getLongGroupId||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveEntry|isDirectory||new:org.apache.commons.compress.archivers.tar.TarArchiveEntry:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
