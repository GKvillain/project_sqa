package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f",
        3, 77076, -325196094, 24877495308445755L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe6c6442f372840L), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u1432\u8adb\u56b8\ubf93\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f",
        3, 77076, -325196094, 24877495862093883L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe6c6442f372840L), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 14, 2, "\ud832\uddd1\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud9d3\udc99\udafb\udd44\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\ud67a", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f\udb85\udf7e",
        21, 45058, 5829840, 4522432313872140687L, 69435L, false, false, (char) 57142, (char) 9730,
        Double.longBitsToDouble(0x3fe300355446d75cL), Double.longBitsToDouble(0x3fd643f2602b9b38L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 2, "\000", "\u529d", "\ud893\udf45\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f",
        36, -880, 0, 919909351L, -49040L, true, false, (char) 47333, (char) 42592,
        Double.longBitsToDouble(0x3fe3d41270a469daL), Double.longBitsToDouble(0x3fe100c78ddf3781L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[2, -77, 106, 95, 89, -118, -12, -115]]\012",
        Z.run(T, 2, 3, 14, 2, "\ud832\udde3\ud09a\ud98f\udd89\ud8ba\ude24\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub5ff\u43e9\u70e5\u8bf7\u9f68\u117a\ud61b\u5701\ubf93\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21",
        51, 49233, -1353119924, -1396706588511149581L, -48401L, false, true, (char) 4850, (char) 48450,
        Double.longBitsToDouble(0x3fcbda01fb63236cL), Double.longBitsToDouble(0x3fe9b94206ed07edL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 14, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbc\udfde\udbf5\udce1\ud902\udcd2\ud884\udf1b\udb40\udec2\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\ud80f\udd2f\u6d88\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u1528\uce12\u117a\ud61b\u5701\ubf93\u2f5a\u35b9", "\udada\udcc8\udb88\ude50\udbbd\udff2\udbdf\udf73\udb27\udcef\uda6b\udcde",
        3, 76124, 544020197, 3250629106924145085L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe1aba7ff37ee1aL), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 10, 8, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\u1cd7\ud8bb\udefb\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\ud925\udef6\udbe6\udf21\udb2b\ude9f",
        3, 77076, -325196094, 24877495308445755L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe6c6442f372840L), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 0, 14, 0, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f",
        3, 77076, -325196094, 24877495308445755L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe6c6442f372840L), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\ud875\udcd9\ud804\udc8a\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\udbaa\udc7f", "\u5fef\ud388\u9623\u04f2\u8bf7\u208c\u4672\u0572\u57c1\u0c21\u457e\u7c24", "\uda50\udeec\ud88f\ude86",
        39, 87274, 1900489845, 844466638878286913L, 84382L, true, true, (char) 49810, (char) 57615,
        Double.longBitsToDouble(0x3fe9c942bc0965cdL), Double.longBitsToDouble(0x3fd2e42b644ba01eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-12, 79, 54, -26, 47, 122, 33, 122]] |a1=[B:[[-65, 3, -71, -75, -57, 92, 74, 83]]\0121=java.lang.Boolean:false |a0=[B:[[-12, 79, 54, -26, 47, 122, 33, 122]]\012",
        Z.run(T, 2, 4, 14, 2, "\uda24\ude7f\ud966\udc16\ubf5f\udbaa\udf51\udbaa\udd48\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\ud8ec\udcb6\udad4\udc2e\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\u1583\u5701\ubf93\u7e77\u4697", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udb81\uded0\udb2b\ude9f\udb85\udf7e",
        21, 22906, 5792243, 4522432313872140687L, 95528L, false, true, (char) 52981, (char) 1034,
        Double.longBitsToDouble(0x3fb8019ba67f1ea0L), Double.longBitsToDouble(0x3fd372d96f418e54L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 13, 9, 6, "\ud83f\uded5\u1264\udb9c\udf4f\ud912\udd96\ud89b\udea0\udbf5\udcf2\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud967\udf55\uda5f\udfea\ub4d3\u6d30\ud9ad\udc2b\ud972\udf26\ud8a4\udd22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\ub6e8\u70e5\u8bf7\u208c\u117a\u8978\uad33\uc03d\u2f5a\u5801", "\uda50\udeec\udb32\udc85\ud821\ude14\ud9c5\udd20\ud89b\udfb5\udb2b\ude48",
        45, 77076, -1398937918, 24876773753940027L, 31560L, true, true, (char) 48450, (char) 28135,
        Double.longBitsToDouble(0x3fa9f7e147dc3400L), Double.longBitsToDouble(0x3fef6fa7686006dbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\ud831\udd3a\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\u9ffa\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f",
        3, 77076, -325196094, 24877495308445755L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe6c6442f372840L), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 12, 2, "\ud832\udde3\uda7f\udce3\ud9da\udd60\ud96f\udeb7\udbbc\udfc6\udbfe\udf86\ud89b\uddef\udaa3\udd93\udaa4\udf6c\ud974\uddf2\ud854\udfbc\ud8bb\ude7f\uf7e5\u6d30\ud9ad\udc2b\ud972\udf26\ud826\udf83\uda79\udc20\ud920\udc4b\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u72f5\uc880\u5701\ubf93\u2f5a\ub794", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73",
        15, 64567, 922887233, -5811605821472381246L, -71330L, true, true, (char) 13872, (char) 7037,
        Double.longBitsToDouble(0x3fdf3f330e4ba01eL), Double.longBitsToDouble(0x3fef4c4047372840L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfb0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\u6d30\udb8c\udf1b\ud6cd\udbaa\udfc3\ud811\uddfd\ud920\udc07\uda01\udfac", "\u5fef\u7a79\u4e25\u8544\u8bf7\uae8b\u117a\u39f6\u56c3\ubf93\u2f5a\u1f91", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f",
        3, 77076, -325196094, 24877495308445755L, -79800L, true, true, (char) 48450, (char) 6874,
        Double.longBitsToDouble(0x3fe6c6442f372840L), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 13, "\ud832\udde3\u1264\ud98f\uddcf\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud972\udf26", "\ua199\u8d25\u0879\u7aa3\u5fef\ub633\u441b\u70e5\u8bf7\u208c\u117a\ud61b", "\udbf4\udf4f",
        34, 32328, 2101049728, 953358103876273835L, 35422L, true, false, (char) 38710, (char) 12281,
        Double.longBitsToDouble(0x3fea61b816c2af59L), Double.longBitsToDouble(0x3fdf3ec9d07600b0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 2, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\uda2f\udc07\uda49\udceb\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\udaa7\udfdc\ubf8c\uefe5\uac59\ud9ad\udcb0\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud92b\udd7f", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u80c8\u32e1\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udfa6\udb2b\ude9f",
        3, 77076, -325196094, 24877495308445755L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe6c6442f372840L), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 15, 14, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0", "\ub45e\u1781\u2e47\u9f91\ud0b3\u00ab\u9309\u547c\u237a\ua199\u8d25\u74aa\u7aa3\u5fef\ub633\u43e9\u70e5\u8bf7\u208c", "\ud807\uddb6\udb08\ude40\udbf4\udf4f\uda78\ude45\udae4\udefe\udaed\ude1e\ud83c\udf3e\ud93f\udd93\uda21\udf7c",
        50, 4376, 185992688, 3963771092163168076L, -48401L, false, true, (char) 4850, (char) 48450,
        Double.longBitsToDouble(0x3fe12e807b45c885L), Double.longBitsToDouble(0x3fea7e7375a29149L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 14, 2, "\ud832\uddd1\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udf86\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud9d3\udc99\udafb\udd44\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\ud67a", "\uda50\udedd\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f\udb85\udf7e",
        21, 9106, 12793410, 4522432313872140687L, 69435L, false, false, (char) 57142, (char) 9730,
        Double.longBitsToDouble(0x3fe300355446d75cL), Double.longBitsToDouble(0x3fd643f2602b9b38L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[10, -95, 52, 11, -17, 90, 21, 35]] |a1=[B:[[20, -118, 99, 42, 84, -32, -67, -93]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 11, 13, "\ud83a\udcd1\u1264\udb3b\udd1f\ud88a\udc45\uda53\udc2d\udbc7\ude95\ud893\udfd0\udabb\udc3f\udaa4\udfa8\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\ue1ff\ud9ac\udfd7\ud972\udf26\udb29\udd29\udb72\udcd9\udba0\udfab\ud996\ude9c\udb97\udd51\udaeb\udfff\uda1a\ude72\ud9f3\udc94\ud973\uddb7\u119a\udbde\udcd9", "\u4f44\u2dba\ubf93\u2f5a\ud384\u4d10\u1eed\u41d3\u01f8\u42df\u17f6\u02b7\uabd2", "\ud8e3\ude16\udb97\udc56\udb60\udfed\udb34\ude50\ud854\udfa2\udadb\udfff\ud8dc\udc69\udbaf\udf51\ud958\udc88\udb86\udef9\udbbd\udf47\udb97\udffa\uda9f\udcab\uda40\ude30",
        29, 85020, 561632642, -8701580603857850869L, -44218L, true, false, (char) 52377, (char) 556,
        Double.longBitsToDouble(0x3fecf655379dec6dL), Double.longBitsToDouble(0x3fe38fab3c72fdd4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[100, -98, -98, 95, 89, -114, 86, -115]]\012",
        Z.run(T, 2, 13, 14, 2, "\udb94\udfce\u11ce\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud92f\uddde\uda9b\udd33\ud99d\udca3\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\ud803\udfc4\udb81\udc19\ud972\udf2e\ud9d3\udc99\udafb\udd44\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u4e84\u061d\ub3a1\ubf93\u2f5a\ud67a", "\uda24\udffe\ud93f\udd05\ud9fd\udd66\udbdf\udf73\udbe6\udf21\ud8be\uded3\udb85\udf7e",
        21, 78650, 196282753, -8705106882288388392L, 69435L, false, false, (char) 19767, (char) 15046,
        Double.longBitsToDouble(0x3fe305f55546d75cL), Double.longBitsToDouble(0x3fdf9c42102b9b38L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[2, -95, -67, -56, 95, 89, -114, 86]]\012",
        Z.run(T, 2, 1, 14, 2, "\ud832\uddd1\ud9ed\uddf8\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud9d3\udc99\udafb\udd44\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\ub522\u7b22\u1700\ubf93\u2f5a\ud67a\u9d88\u1eed\u41d3\u01f8\u42df", "\udb2b\ude9f\udb85\udf7e\ud8c0\ude8b\uda7c\udc62\ud8c9\udcd5\udb60\udfed\udb34\ude50\ud854\udfa2\uda33\udd2b\udb0b\udf1f\u3ee0\ud958\udc88\udb86\udef9\uda11\udf51\udb97\udffa\udae7\udffe\udb37\ude6b\ud9bd\udcfe\ud893\udfb1\ud9d3\udf3d\ud809\udf27",
        48, 156, -912325674, -3785670667007512989L, 80011L, false, false, (char) 21667, (char) 24563,
        Double.longBitsToDouble(0x3fe47ec71392f6fbL), Double.longBitsToDouble(0x3fe04a0a174bbacdL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 8, 2, "\ud84a\udc48\uc964\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\uda9d\udf75\udaa3\ude5d\udbbe\udf6a\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud9d3\udc99\udafb\udd44\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\ud67a", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f\udb85\udf7e",
        21, 17122, 7437913, 4522432313872140687L, 69435L, true, true, (char) 57221, (char) 9730,
        Double.longBitsToDouble(0x3fe300355446d75cL), Double.longBitsToDouble(0x3fd643f2602b9b38L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 1, 0, 2, "\ud832\uddd1\udbfb\udc63\ud985\udd89\ud8be\udc86\ud827\udc03\udbf5\udce1\ud893\udfd0\udaa3\udd93\uda5d\udf0e\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\uda2e\udd79\ud9ad\udc2b\ud972\udf26\ud9d3\udc99\udafb\udd44\ud920\udc07\ud83b\udd4f", "\u5fef", "\u00df\ud98a\udf85\ud94f\udd4f",
        14, -1000, 0, 4947131849758316040L, -100000L, false, false, (char) 32608, (char) 5094,
        Double.longBitsToDouble(0x3fdb8f549e056d72L), Double.longBitsToDouble(0x3fbd41e36f7b8a38L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:45079 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 1, 2, "\ud832\uddd1\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\uda15\udd53\uda09\udcd1\udbb8\udcb7\uda21\udd62\ud8a5\udf02\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud9d3\udc99\udaa3\udf86\ud920\udc07\udafd\udde9", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5732\ubf93\u2f5a\ud67a", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f\udb85\udf7e",
        21, 45058, 5829840, 4522432313872140687L, 69435L, false, false, (char) 57142, (char) 9730,
        Double.longBitsToDouble(0x3fe300355446d75cL), Double.longBitsToDouble(0x3fd643f2602b9b38L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 1, 9, 7, "\udb18\udfa4\udaab\udcf6\ud98f\udd6c\ud8be\udc86", "\u38a9\u5282\u5287\ub45e\u2721\ub7cf", "\ud9ad\udc2b\ud845\uddaf\udbc4\udcb9\udafb\udd44\ud920\udc07\udbb9\udfa8\ud9e2\udc80",
        -3, 39, 418463908, 3999647407373366751L, -91076L, false, false, (char) 49221, (char) 47213,
        Double.longBitsToDouble(0x3fe1aca22e0844a7L), Double.longBitsToDouble(0x3fe3268eea8236f3L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[2, -95, 52, 95, 89, -114, 86, -115]]\0121=java.lang.Boolean:false |a0=[B:[[2, -95, 52, 95, 89, -114, 86, -115]]\012",
        Z.run(T, 2, 14, 14, 2, "\ud832\uddd1\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\uda21\udd62\ud81a\udd7d\uda0a\udc9f\ua640\ud888\ude48\ud970\udccb\ud9d3\udc99\ud854\udc34\udb3d\udd30\ud83b\udde8", "\u5fef\u5c6f\ub7cc\u70e5\u8bf7\u208c\u117a\uce1a\u5701\ubf93\u7c17\ub0f6", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\ud8ef\udefb",
        15, 70711, 922887358, -5811605820682672446L, 90523L, false, true, (char) 53360, (char) 23225,
        Double.longBitsToDouble(0x3fdf3f34f44ba01eL), Double.longBitsToDouble(0x3fe6c6442a8f1ca8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[2, -95, 52]]\012",
        Z.run(T, 2, 13, 14, 2, "\ud832\uddd1\u1264", "\u65b0\u7cd8\u2650\u5282", "\udb7f\ude9a",
        19, 45354, 1058711928, 2070286360272418308L, -32316L, false, false, (char) 57470, (char) 55098,
        Double.longBitsToDouble(0x3fddf3781c967e9aL), Double.longBitsToDouble(0x3fe19db4d4065958L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[109, 23, 52, 95, 89, -114, 86, -115]]\012",
        Z.run(T, 2, 1, 14, 2, "\ud99d\udd47\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\u6d30\ud9ad\udc2b\ud83e\udcba\udbba\udd75\udafb\udcb0\ud952\udf00\udac0\udc0c", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\ud67a", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\ud92b\udc1a\udb85\udf7e",
        21, 362, 5829655, 4522432313872140687L, 69435L, false, false, (char) 57142, (char) 9730,
        Double.longBitsToDouble(0x3fe85cc55146d75cL), Double.longBitsToDouble(0x3fdbdb85b02b0938L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[2, -95, 52, 95, 89, -114, 86, -115]] |a1=[B:[[-65, 3, -71, -75, -57, 92, 74, -21]]\012",
        Z.run(T, 1, 4, 14, 2, "\ud832\uddd1\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\u6d30\ud9ad\udc2b\ud972\udf26\ud9d3\udc99\udafb\udd44\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\ud61b\u5701\ubf93\u2f5a\ud67a", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\ud8bf\udc17\udb77\udf36\udb2b\ude9f\udb85\udf7e",
        21, 45058, 5829840, 4522432313872109455L, 69435L, false, false, (char) 57142, (char) 9730,
        Double.longBitsToDouble(0x3fe300355446d75cL), Double.longBitsToDouble(0x3fd643f2602b9b38L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 14, 2, "\000", "\u529d", "\ud893\udf45\udaa4\udc93\udaa4\udf6c\udbb8\udcfd\uda4f\uddba\ud83b\ude03",
        49, -880, 0, 919909351L, -49040L, true, false, (char) 47333, (char) 42592,
        Double.longBitsToDouble(0x3fe3d41270a469daL), Double.longBitsToDouble(0x3fe100c78ddf3781L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 7, 2, "\000", "\u529d", "\ud8f7\udfd8\udacb\udd8c\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f",
        36, -880, 439296612, 228553176039L, -49040L, false, false, (char) 58308, (char) 42592,
        Double.longBitsToDouble(0x3fe3d41270a469daL), Double.longBitsToDouble(0x3fe100c78ddf3781L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 14, 2, "\ud9d5\ude4a\udb48\uddfa", "\u65f6\uc0f4\u25c5\u5282\u6f91\u369e\u13a3\u2d9b\uae06\u734b\u9146\u7169\uafba\u7eba\u635b\u4292\u7057\u2700\ub076", "\udbb7\udc99\ud832\udd25\ud808\udebd\ud998\udec4\udb93\udf12\udb12\udd91\ud852\udd45\ud838\udcca\udb1a\udd0a\ud9c1\ude33\ud9f8\ude49\031\udb25\ude10\ud81c\udc5a\u2c93\uda10\udd01\ud98f\udde2\ud881\udd32\uda3e\udfba\udbb6\udcb2\ud980\udf27\udbd1\udf46\udbb9\ude29\udaa3\udff9\udbda\uddb1\ud9f1\udeef\ud844\udf21\ud866\ude79\ud828\ude3a\ud9a5\udc2d\ud8ac\udd0a\ud85e\ude8a\ud950\ude68\ud8d5\uddf4\udb82\ude5b\udbb7\ude97\udbf4\udde1\udac6\udd26\u14b3\uda66\udc72\ud893\ude8d\ud8eb\udeff\ud855\ude88\uda11\udc2d\ud904\uddda\uda4c\ude46\ud9cc\udee5\ud978\udce7\ud802\udd06\udbd7\udca3",
        21, 16725, 804467153, 7794167945221370146L, 21237L, true, false, (char) 51233, (char) 9664,
        Double.longBitsToDouble(0x3fca4af7bca13540L), Double.longBitsToDouble(0x3fb4d1da8f3a8e28L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 1, 4, "\000", "\u529d", "\ud893\udf45\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f",
        36, -880, 0, 919909351L, -49040L, true, false, (char) 47333, (char) 42592,
        Double.longBitsToDouble(0x3fe3d41270a469daL), Double.longBitsToDouble(0x3fe100c78ddf3781L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[80, 89, 84, 68, 72, 59, -118, -12]]\012",
        Z.run(T, 2, 3, 14, 2, "\ud880\udc89\ud984\udc74\udb78\udd6b\ud8ba\ude24\udbbd\udc0e\uda8a\udd6b\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc", "\u8442\u4c87\u2c62\u54e3\u237a\u5814\u8d67\u0879\u7aa3\u5fef\ub5ff\u43e9\u70e5", "\udac2\uddc9\udb8a\udf4c\udad8\udc56\udb08\ude40\udbf4\udf4f\uda78\ude45\ud823\udd5c\ud99b\udc8d\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f\udb85\udf7e\ud8c0\ude8b\uda31\udd9d\ud815\udffe",
        17, 41895, 1292349720, -914294587029206541L, -26547L, false, true, (char) 5943, (char) 53097,
        Double.longBitsToDouble(0x3fc9bf0a2052cfa4L), Double.longBitsToDouble(0x3fddc0712be6c98eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 3, 8, "\udade\udd8b\u4a9d\ud98f\udd89\ud8b6\udc3b\udbbd\udc0e\ud800\udc03\udb9d\ude02\uda98\udf1c\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f", "\u4c87\u2c62\u3d7a\u2353\ua199\u2f1a\u07cf\u7aa3", "\ud973\udd65\u119a\udbde\udcd9",
        0, 84378, -1987015974, -3377085436662900109L, -46140L, false, true, (char) 65128, (char) 58531,
        Double.longBitsToDouble(0x3f9c0d3b37050ae0L), Double.longBitsToDouble(0x3fe815b5cc75d28dL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 15, 0, "\ud832\ude1a\ud09a\ud98f\udd89\ud8ba\ude24\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\uda71\udc07\udbb8\udca1\ud854\udfbc\ud8bb\ude7f\udbb3\udfe1\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83f\udee8", "\u5fef\ube96\ub89a\u70e5\u8bf7\u9f68\u117a\ud61b\u5701", "\uda78\ude45\ud9d5\udd6e\uf431\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f\udb85\udf7e\ud8e1\ude7b\uda31\udd9d\ud8a4\uddf8\udb60\udfed\udb34\ude50\udb67\udd78\uda0a\udf8f\uda83\udc1b\ud825\udd9e\ud8f6\udd37\ud870\udcbe\uc680\ud827\udd89\udbfb\ude01",
        33, 56764, -1299170241, -3188434186282979910L, 23324L, true, false, (char) 64411, (char) 13782,
        Double.longBitsToDouble(0x3fdfec0b3ad7a8dcL), Double.longBitsToDouble(0x3fbbc9a2fe42a580L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 2, "\ud832\udde3\ud886\udc9c\ud98f\udd89\ud8ba\ude24\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud958\udf26\ud8ed\udc2d\udbe6\udf4e\uda3c\udf4d\ud8b2\ude3d", "\u5fef\ub5ff\u43e9\u70e5\u8bf7\u9f68\u117a\ud61b\u5701\ubf93\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21",
        51, 49233, -1353119924, -1396706588511149581L, -71550L, false, true, (char) 11895, (char) 52301,
        Double.longBitsToDouble(0x3fea60ba371a1c67L), Double.longBitsToDouble(0x3fb1954eb8acad08L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 8, 2, "\ud832\udde3\ud09a\ud98f\udd89\ud8ba\ude24\udbbd\udc0e\udb1e\udcb6\uda59\ude72\ud88a\udd42\uda8d\udc9f\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\udab6\udd25\ud856\udf98\ud9d3\ude29\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud9e0\udf23\ud83b\udd80", "\u6cca\ub5ff\ub777\u2123\ub913\u9f68\u117a\u495e\ua908\u05b6\u2f5a\u5801", "\uda50\udeec\uda5a\udf57\ud81d\udd52\udba5\udc2f\udbe6\udf21",
        51, 49233, -1353119924, -6354325353315933930L, 29024L, false, false, (char) 52629, (char) 9946,
        Double.longBitsToDouble(0x3fd5d04954811ef2L), Double.longBitsToDouble(0x3fe190171e13a4deL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[93, -75]]\0121=java.lang.Boolean:false |a0=[B:[[93, -75]]\012",
        Z.run(T, 2, 14, 14, 11, "\ud88d\udce5", "\u0bae\ua707\u64d1\u2650\u5282\u6a66\u0129\u186e\u2e47\u9f91\u8442\u4c87\u2c62\ua432\u47f7\uc57f\u2a29\u7e5a\u7aa3", "\ud8c4\udd3b\uda0c\udd5a\uda09\udf08\ud939\udc2c\udaff\udfc8\ud818\udc9c\ud839\udefc\udaab\udf84\udbe9\udc24\ud8f2\ude69\ud956\udc4e\uf487\uda50\udeec\ud854\udef4\ud834\udd9b\ud8ca\udc92\ud9da\ude28\udba1\udfda\udb85\udf7e\ud8fa\udd8b\uda31\udd9d\ud8a4\uddf8\udb60\udfed\ud892\udf21\ud843\udda2\udbe4\udd23\udbb7\udd94\ud8d8\udef0\ud94c\udce2",
        0, 29381, 159813866, 2904179011349677218L, -52003L, false, false, (char) 51228, (char) 42277,
        Double.longBitsToDouble(0x3febef82ee46b46bL), Double.longBitsToDouble(0x3fedc88d2dc8dd5bL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 6, 1, "\u57dc\udb2b\udfbe\ud819\ude9c\ud893\uddff\udbbc\udfde\udbf5\udce1\ud902\udcd2\ud884\udf1b\udb40\udec2\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\ud80f\udd2f\u6d88\ud9ad\udc2b\ud972\udf26\ud969\udd83\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\u1528\uce12\u7aac\u79d9\u5701\u9bbc\u2f5a\u35b9", "\udada\udcc8\udb88\ude50\udbbd\udff2\u83d5\udb55\udee7\uda6b\udcde",
        3, 22892, -614636730, -5325069682208519747L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe1aba7ff37ee1aL), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 5, 6, 2, "\ud822\udf26\u1264\ud98f\udd89\ud8be\udc86\ud9cc\ude37\ud897\udfc3\ud8b7\udfd0\uda84\udf95\udaa4\udf6c\udbb8\udcfd\u1cd7\uda44\udc3f\ud832\udf5e\u6d5e\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\udaa0\udec8\udb7c\udee4\ud85d\uded4", "\u9d5a\u4ddd\u4416\u70e5\ud29e\u187e\u1106\u1455\u5701\u6693\u2f5a\u5801", "\u975c\ud89e\udd01\udb44\uded7\ud925\udef6",
        26, 775, 1720325953, 5515455348881614482L, 90523L, false, true, (char) 13872, (char) 4850,
        Double.longBitsToDouble(0x3fdf3f34f44ba01eL), Double.longBitsToDouble(0x3fe1faec2cffe338L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[14, -72, 7, 77, 95, 47, 114, 86]] |a1=[B:[[127, 88, 56, 53, -29, 32, 66, 0]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 15, 2, "\ud83e\udfe8\uda37\udc7d\ud98f\ude5f\ud8a2\udf86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udb9c\udf28\ud987\udc1d\uda9a\uddca\ud92f\udfcd\u7dc0\ud8ed\udd38\uda93\udcfe\ud975\ude00\ud884\ude10\ud811\uddfd\ud92d\udeb7\udbaa\udc7f", "\uc8af\ud388\ud568\ucd65\ucd13\ub750\u4672\u3a30\u7d3d\u0c21\u26f9\u1c31", "\uda50\udeec\ud88f\ude86",
        39, 59882, 1905821557, 844466638878286913L, 84382L, true, true, (char) 8563, (char) 57615,
        Double.longBitsToDouble(0x3fe9c942bc0965cdL), Double.longBitsToDouble(0x3fd2e42b664ba01eL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 13, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udbd8\udd4b\ud875\udcd9\ud804\udc8a\ud9f9\udd1e\uf01c\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\udbaa\udc7f", "\u5fef\ud388\u9623\u04f2\u8bf7\u208c\u4672\u0572\u57c1\u0c21\u457e\u8809", "\uda50\udfbe\ud88f\ude86\ud941\udd63\udbdf\udf73\udbe6\udf21",
        51, 49457, -1353119924, 1086036846495424777L, 77161L, false, true, (char) 14901, (char) 23502,
        Double.longBitsToDouble(0x3fbac3c250740368L), Double.longBitsToDouble(0x3fec68ae67f907ddL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-12, 79, 54, -26, -56, -77, 122, -123]] |a1=[B:[[-65, 3, -71, -75, -57, 92, 74, 83]]\0121=java.lang.Boolean:false |a0=[B:[[-12, 79, 54, -26, -56, -77, 122, -123]] |a1=[B:[[-65, 3, -71, -75, -57, 92, 74, 83]]\012",
        Z.run(T, 2, 4, 4, 2, "\uda24\ude7f\ud966\udc16\udbf8\udde3\udbaa\udfb5\udbaa\udd48\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\ud8ec\udcb6\udad4\udc2e\ud8bb\ude7f\uefe5\u6d30\ud9ad\udc2b\ud82e\ude44\udb2b\udc6f\ud8f3\ude9c\ud90a\uddcd\ud83b\udde8", "\u07ef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\u1583\u5701\ubf93\u7e77\u4697", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udb81\uded0\udb2b\ude9f\udb85\udf7e",
        21, 22906, 5792243, 4522432313872140687L, 95528L, false, true, (char) 52981, (char) 1034,
        Double.longBitsToDouble(0x3fb8019ba67f1ea0L), Double.longBitsToDouble(0x3fd372d96f418e54L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 5, 9, 6, "\ud83f\uded5\u1264\udb9c\udf4f\ud912\udd96\ud89b\udea0\udbf5\udcf2\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud967\udf55\uda5f\udfea\ub4d3\u6d30\ud9ad\udc2b\ud972\udf26\ud8a4\udd22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\ub6e8\u70e5\u8bf7\u208c\u117a\u8978\uad33\uc03d\u2f5a\u5801", "\uda50\udeec\udb32\udc85\ud821\ude14\ud9c5\udd20\ud89b\udfb5\udb2b\ude48",
        45, 77076, -1398937918, 24876773753940027L, 31560L, true, true, (char) 48450, (char) 28135,
        Double.longBitsToDouble(0x3fa9f7e147dc3400L), Double.longBitsToDouble(0x3fef6fa7686006dbL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 5, 2, "\ud80f\udfe3\udb85\udea6\ud9da\udd60\ud89f\udeaf\udbbc\udfc6\udbfe\udf86\ud89b\uddef\udaa3\udd93\udaa4\udf6c\ud974\uddf2\ud854\udfbc\ud8bb\ude7f\uf7e5\u6d30\uda95\udd33\ud972\udf26\ud826\udf83\ud872\ude9c\udb83\uddb5\ud83b\udde8", "\u5fef\ub633\u0c92\u4f3b\u8bf7\u208c\u72f5\uc880\u5701\ubf93\u2f5a\ub794", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73",
        15, 64567, 1006773313, -5811605821472381246L, -71330L, true, true, (char) 13872, (char) 7037,
        Double.longBitsToDouble(0x3fdf3f330e4ba01eL), Double.longBitsToDouble(0x3fef4c4047ecfe03L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-31, -81, -67, -56, 95, 89, -114, 86]]\012",
        Z.run(T, 2, 1, 14, 2, "\ud911\udddf\ud9ed\uddf8\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud88d\udc57\udaa3\ude2c\udaa4\udf6c\ud873\udf1b\ud86e\udc39\ud8a9\udc3a\udb22\uddf9\ud8e4\udc24\udb3d\udf42\udbcf\udfe7", "\ua199\u8d25\u6eb2\u4e8e\u5fef\ub633\u43e9\u70e5\ud0ec\u56b6\ub522\u7b22\u1700\ubf93\u2f5a\ua5fb\u9de5\u1eed\u41d3\u09f1\ua287\u18ac\u02b7\uabd2\u3573\u0fb5\u7a271\u829d\u7fe4\u9b2d", "\ud9e6\udf27\ud958\udc88\udb86\udef9\uda11\udf51\ud833\ude68\ua854\uda41\ude8b",
        24, 96, -1400656855, -5745542153946389250L, 97590L, false, true, (char) 59165, (char) 28957,
        Double.longBitsToDouble(0x3fe9593074ec1236L), Double.longBitsToDouble(0x3feb5669cdba9039L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[80, 89, 84, 68, 72, 59, -118, -12]]\0121=java.lang.Boolean:false |a0=[B:[[80, 89, 84, 68, 72, 59, -118, -12]]\012",
        Z.run(T, 2, 14, 14, 2, "\ud880\udc89\ud984\udc74\udb78\udd6b\ud8ba\ude24\udbbd\udc0e\uda8a\udd6b\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc", "\u8442\u4c87\u2c62\u54e3\u237a\u5814\u8d67\u0879\u7aa3\u5fef\ub5ff\u43e9\u70e5", "\udac2\uddc9\udb8a\udf4c\udad8\udc56\udb08\ude40\udbf4\udf4f\uda78\ude45\ud823\udd5c\uda19\udeac\ud934\udd64\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f\udb85\udf7e\ud8c0\ude8b\uda31\udd9d\uda7c\udfd1",
        11, 8891, 1292349720, -914294587029206541L, -26547L, false, true, (char) 5943, (char) 53097,
        Double.longBitsToDouble(0x3fc9bf0a2052cfa4L), Double.longBitsToDouble(0x3fddc0712be6c98eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Integer:49284 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:49284 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud832\udde3\ud886\udc9c\ud98f\udd89\ud8ba\ude24\ud8c3\udcf1\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud82c\udf58\u901d\u6d30\ud9ad\udc2b\ud958\udf26\ud8ed\udc2d\udbe6\udf4e\uda3c\udf4d\ud8b2\ude3d", "\u9f0a\uc977\u44ac\u70e5\u8bf7\u9f68\ucfe3\ud61b\u4d4f\u1555\u2f5a\u5801", "\ud9df\udc2f\ud93f\ude3f\ud9fd\udd66\udbdf\udf73\udbe6\udf21",
        51, 49233, 1784219468, -1369795650579308045L, -71550L, false, true, (char) 11895, (char) 52301,
        Double.longBitsToDouble(0x3fea60ba371a1c67L), Double.longBitsToDouble(0x3fb1954eb8acad08L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 2, "\ud832\udde3\u1264\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udbb8\udf9b\udaa4\udf6c\udbb8\udcfd\ud854\udfbc\ud8bb\ude7f\uefe5\u6d30\udaff\udf24\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u43e9\u70e5\ud6ca\u35cc\u115f\ud61b\u5701\ubf93\u2f5a\u5801", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udbe6\udf21\udb2b\ude9f",
        3, 77076, -325196094, 24877495308445755L, -79800L, true, true, (char) 48450, (char) 14901,
        Double.longBitsToDouble(0x3fe6c6442f372840L), Double.longBitsToDouble(0x3fe7683f686006aaL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-65, -125, 54, -26, 47, 122, 33, 122]] |a1=[B:[[-65, -89, 80, -75, -57, 92, 74, 69]]\0121=java.lang.Boolean:false |a0=[B:[[-65, -125, 54, -26, 47, 122, 33, 122]]\012",
        Z.run(T, 2, 4, 14, 13, "\ud9ef\uddb3\ud966\udc16\ubf5f\udbaa\udf51\udbaa\udd48\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\ud8ec\udcb6\udad4\udc2e\ud9c8\udd06\uef50\u6d30\ud9ad\udc2b\ud972\udf26\ud8a5\udf22\ud811\uddfd\ud920\udc07\ud83b\udde8", "\u5fef\u67d7\u4480\u70e5\u8bf7\u208c\u117a\uca75\uaf91\ubf93\u7e77\u4697", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udb81\uded0\udb35\udf9f\udb85\udf7e",
        21, 22906, 832708339, 4522343403754146191L, -12745L, false, true, (char) 16078, (char) 25810,
        Double.longBitsToDouble(0x3fd372d96f418e54L), Double.longBitsToDouble(0x3fe7792cac3bc1f8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[2, -95, -67, -56, 95, 89, -114, 86]]\012",
        Z.run(T, 2, 1, 14, 2, "\ud832\uddd1\ud9ed\uddf8\ud98f\udd89\ud8be\udc86\udbbd\udc0e\udbf5\udce1\ud893\udfd0\udaa3\udd93\udaa4\udf6c\udbb8\udcfd\uda21\udd62\ud8bb\udf0d\uefe5\u6d30\uda6d\udc2b\ud972\udf26\uda5b\udd5d\udb0f\udec6\ud920\udc07\ud83b\udde8", "\u5fef\ub633\u2aba\u703c\u8bf7\u208c\u8b9f\u7b22\u1700\ubf93\u2f5a\ud67a\u9d88\u1eed\u41d3\u01f8\ua3e9", "\ud80b\udcee\udbf4\udd5c\ud8c0\ude8b\uda7c\udc62\ud8c9\udcd5\udb60\udfed\ud8e1\udeea\udb3c\udd26\uda33\udd2b\udb0b\udf1f\u3ee0\ud8ba\udf7f\udb86\udee8\uda11\udf51\udb97\udffa\udae7\udffe\udb37\ude6b",
        49, 30, -1400656855, -5745542153946389250L, 97590L, false, false, (char) 31193, (char) 65053,
        Double.longBitsToDouble(0x3fe9593074ec1236L), Double.longBitsToDouble(0x3feb5669cda15c39L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:38 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 2, 7, "\udb18\udfa4\udaab\udcf6\ud98f\udd6c\ud8be\udc86", "\u38a9\u5282\u5287\u646e\ua5a1\ub829", "\ud9ad\udc2b\ub779\udbc4\udcb9\udafb\udd44\ud920\udc07\udbb9\udfa8\ud86f\udebe",
        21, 17, 418463908, 3999647407373366751L, -91076L, false, false, (char) 49221, (char) 47213,
        Double.longBitsToDouble(0x3fe1aca22e0844a7L), Double.longBitsToDouble(0x3fe3268eea8236f3L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-65, -108, -28, 119, -56, -77, 122, -123]] |a1=[B:[[-65, 3, -71, -75, -57, 92, 74, 83]]\0121=java.lang.Boolean:false |a0=[B:[[-65, -108, -28, 119, -56, -77, 122, -123]] |a1=[B:[[-65, 3, -71, -75, -57, 92, 74, 83]]\012",
        Z.run(T, 2, 4, 4, 2, "\udbef\uddc4\uda14\udfa7\udbf8\udde3\udbaa\udfb5\udbaa\udd48\udbf5\udce1\ud893\udfd0\uda97\udd93\udaa4\udf6c\ud8ec\udcb6\udad4\udc2e\ud8bb\ude7f\uefe5\ud90e\udcc8\ud8f7\udda9\ud808\udf8f\udb2b\udc6f\ud8f3\ude9c\udb35\udc33\ud83b\udde8", "\u07ef\ub633\u43e9\u70e5\u8bf7\u208c\u117a\u1583\u5701\ubf93\u7e77\u4697", "\uda50\udeec\ud93f\ude09\ud9fd\udd66\udbdf\udf73\udb81\uded0\udb2b\ude9f\udb85\udf7e",
        21, 22906, 5792243, 4522432313872140687L, 95528L, false, true, (char) 52981, (char) 1034,
        Double.longBitsToDouble(0x3fb8019ba67f1ea0L), Double.longBitsToDouble(0x3fd372d96f418e54L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-65, -108, -28, 119, -56, -77, 122, -123]] |a1=[B:[[]]\0121=java.lang.Boolean:true |a0=[B:[[-65, -108, -28, 119, -56, -77, 122, -123]] |a1=[B:[[]]\012",
        Z.run(T, 2, 4, 4, 2, "\udbef\uddc4\uda14\udfa7\udbf8\udde3\udbaa\udfb5\udbaa\udd48\udbf5\udce1\ud893\udfd0\uda97\udd93\udaa4\udf6c\ud8ec\udcb6\udad4\udc2e\ud8bb\ude7f\uefe5\000", "", "\udb35\udc33\ud83b\udde8\ud9cc\udff6\uda87\udfa0\ud823\ude30\ud902\ude1c\uda76\ude27\udbf6\udfba\udbde\udcd9\ud94f\udd4f\udac2\uddc9\ud8fc\udf45\udad8\udc56\udb08\ude40\uda05\udd36\uda5c\udde7\udb32\udc01\ud9bb\udeac\uda50\udeec\ud93f\ude09\ud9fd\udd66",
        4, 51701, 196617711, 3963770483630931968L, -48401L, false, true, (char) 5092, (char) 40258,
        Double.longBitsToDouble(0x3fac7bc780000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-65, -108, -28, 119, -56, -77, 32, -105]] |a1=[B:[[]]\012",
        Z.run(T, 1, 4, 4, 2, "\udbef\uddc4\uda14\udfa7\udbf8\udde3\ud950\udcc7\udb9c\udeee\ud908\udee1\ud9a3\udeb5\uda97\udde1\udaa4\udf6c\ud8ec\udcb6\udad4\udc2e\ud8bb\ude7f\uefe5\000", "", "\udb23\udf9a\ud83b\udde8\ud9cc\udff6\uda87\udfa0\ud823\ude30\ud902\ude1c\uda76\ude27\udbf6\udfba\udbde\udcd9\ud94e\ude4f\udbaa\udcc9\ud8fc\udf45\udad8\udc56\udb08\ude40\uda05\udd36\ud9ca\ude7e\udace\udcfb\udb9c\uddf9\ud8f1\uddff\ud93f\ude09\ud9fd\udd66",
        20, 93986, 1324591435, 3963770483630931968L, 82671L, false, false, (char) 9827, (char) 64322,
        Double.longBitsToDouble(0x3fe3841fbbfa9325L), Double.longBitsToDouble(0x3ec2a00000000000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextZipEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|bufferContainsSignature|java.io.ByteArrayOutputStream,int,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|cacheBytesRead|java.io.ByteArrayOutputStream,int,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|canReadEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|checksig|[B,[B|static",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|close||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|closeEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|currentEntryHasOutstandingBytes||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|drainCurrentEntryData||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|fill||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|findEocdRecord||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getBytesInflated||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|isFirstByteOfEocdSig|int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|matches|[B,int|static",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|processZip64Extra|org.apache.commons.compress.archivers.zip.ZipLong,org.apache.commons.compress.archivers.zip.ZipLong|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextZipEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
