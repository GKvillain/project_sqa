package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 11, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u9e88", "\ud832\ude6b\ud965\ude7e\udbef\ude68\ud8a3\udc2a\uda37\udf47\udbe5\udff3\ud8fa\udda2\udb0c\udff4\udb6c\uddd1",
        11, 43878, -1501477472, 5754276885467843935L, -35683L, false, false, (char) 64064, (char) 16117,
        Double.longBitsToDouble(0x3fc88c79077247c8L), Double.longBitsToDouble(0x3fe0bf9d31addbb5L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 11, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6", "\u375b\u2b03\u22c0\ud5e5\u9e88\u8b36\u7802\u8e60\u86d6\u5559\ub449\u8dfc", "\udb0c\udff4\udb6c\uddd1\ud8d5\udd73\uda7c\udfab\udb44\udc59\udafe\udd0b\u4d5f\000\udbf9\uddfb\ud9c1\udc1b\udb65\ude51\ud96e\ude43\udab6\ude47\udabc\udd21\ud9d2\udff3\ud97a\udfcf\uda20\udcec\ud9fd\udc9a\ud94f\udc7d\udb3e\ude08\ud8e8\udf2a\u8d9d\ub742\udb5a\udfad\uda56\udc4e\ud851\udc61\ud9dc\udf42\uda1b\udcde\udb8d\udc3a\ud836\udd5d\uda6c\udf77\udb3a\udf9f\ud9dc\ude51\u5dfe\ud93f\udd79\udbe6\udd67\ud9cf\udef8\ud9ce\udcea\ud809\ude6f\ud8a8\udf9d\uda0d\udfa1\udb2b\ude49\ud9df\udf1e\ud86e\udfff\ud955\udec8\ud93d\udc44\uda35\udc53\ud9ce\udde1\ud946\udfe1\ud818\udff8\udb50\udf80",
        47, 36072, -7876264, -6229277319786913987L, -79444L, false, true, (char) 44598, (char) 39981,
        Double.longBitsToDouble(0x3fe4c9d98431d236L), Double.longBitsToDouble(0x3fc808d9869c55fcL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 6, 14, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d\ud8aa\ude4e\udafb\udea8", "\u7a88", "\udae3\udec3\u49d7\udbec\udf2c\ud8b8\udc32\udba4\ude87\udb48\udde0\u2921\udb0d\udc60\udb0a\udfa1",
        11, 43878, -1501477472, 5754276885467843935L, -99740L, true, false, (char) 64064, (char) 16117,
        Double.longBitsToDouble(0x3fc88c790babbbc4L), Double.longBitsToDouble(0x3fe0bf9ad9addbb5L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 11, 6, 11, "\udbf6\udc00\uda02\udfaa\ud838\udfdd\uda2d\udce0\ud8cb\udc2d\uda28\ude4d\udafb\udea8\udad2\udc83\ud99b\ude29\ub33f\ud966\ude3b\ud881\udee5\ud832\ude6b\ud965\ude7e", "\u8dfc\u9e89\u5edb\u5c61\ud150\u7739\ud0fa\u2935\u888b\ubf35\u1055\uab98\u8ba9\u8416\u92a5\ube54\u3b39\u9b13\u1647\ub8ab\u2599", "\ud96d\udf67\uf0b0\udaff\udf5e\ud895\udc4d\udb4a\udd5a\ud94e\udf1e\ud9b2\udd1c\uda54\udd0c\ud90b\uddac\ud993\udf84\ud87d\udf0f\udbdb\udf64\ud800\udf9c\ud892\udf93\ud9f3\uddb3\udbf0\ude92\ud8ac\ude0c\ud815\udd94\udbe1\udc63\uda1f\udc50\ud938\udc37\ud8ca\uddfb\ud826\udf98\udbbc\udf23\ud8d8\udce1\udba0\udf60\udb56\ude91\ud8db\udd21\ub1bf\ud815\udc50\uda0c\udc0d\ud9bf\udd53\ud95f\ude2b\uda7b\udfde\ud9f2\udeec",
        25, 32019, 1771108016, 4622135841437994961L, -32622L, false, true, (char) 31187, (char) 56553,
        Double.longBitsToDouble(0x3fd647f61bf1061eL), Double.longBitsToDouble(0x3febbdc5b5cbbff5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 11, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d", "\u22c0\u00dc\uc44e\u6f72\u7895\u8e60\u6f6d\u6881\u8194\u572d\u9e89\u5edb", "\ud8d5\udd73\uda7c\udfab",
        33, 5991, 26037599, 1969286835277200189L, -62188L, false, false, (char) 9356, (char) 21454,
        Double.longBitsToDouble(0x3fe0bf9d31addbb5L), Double.longBitsToDouble(0x3fec8143e5fb4e73L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 11, "\ud80a\udc2e\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d\udade\ude48\ub6bb", "\uc516", "\ud832\ude6b\ud965\ude7e\udbef\ude68\ud8a3\udc2a",
        43, 6185, 316145798, 6680938856949573033L, -79535L, true, true, (char) 12375, (char) 64064,
        Double.longBitsToDouble(0x3fb8a6a4c4900918L), Double.longBitsToDouble(0x3f9bdf0ec2fe74c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 10, 6, "\udbf6\udc00\ud87e\udfe9\udb37\udcd4\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u3d20\u02f3\u4875\u1dd1\u86d6", "\uda37\udf47\udbe5\udff3\ud8fa\udda2\udb0c\udff4\udb6c\uddd1\ud8d5\udd73\uda7c\udfab\udb44\udc59\udafe\udd84\ud983\udd76\ud90e\udd8d\ue939\ud9c1\udc1b\udb65\ude51\ud96e\ude43\udab6\ude47\udabc\udd21\uda5c\udc2a\u56ff\udb9e\ude4d\udbd7\udfdb",
        50, 67599, -1392185601, 3982742132251924499L, 62095L, true, false, (char) 22552, (char) 39023,
        Double.longBitsToDouble(0x3fe95d57a543243aL), Double.longBitsToDouble(0x3fe74c474a355249L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 13, 0, "\udbf6\udc00\ud87e\udfe9\ud87c\udcd7\ue5c4\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u9e88", "\ud832\ude6b\ud965\ude7e\udbef\ude68\udbb3\udcaa\uda37\udf47\udbe5\udff3\ud8fa\udda2\udb0c\udff4\udb6c\uddd1",
        11, 43878, -1501477472, 5715151863705062751L, -35683L, false, false, (char) 40512, (char) 16099,
        Double.longBitsToDouble(0x3fc88c79077247c8L), Double.longBitsToDouble(0x3fd17f3a6381b6e8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 6, 11, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\u8403\ud8cb\udc5a\uda28\ude4d\udafb\udea8", "\u9e88\u23b8\u9e46\u9f10\u39c2\u7799\ub449\ua542\u7ff8\u45d7", "\ud9d3\udd72\uda76\udf27",
        33, 17263, 19581123, 1990115983553776957L, -99308L, true, true, (char) 21392, (char) 21454,
        Double.longBitsToDouble(0x3fe909cd3100c122L), Double.longBitsToDouble(0x3fe8a0a2860ad12bL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 6, 11, "\uda69\udef5\u02db\udae6\udf13\ufff2\udb5c\udf3f\ud8c4\ude8f", "\u1847\u9f5b\u6f5c\u67b2\u46a7\u86d6\u8d6b\ub449\u7b83\u867d\u144f\u9ac4\u5ed3\ud6aa\ud0fa\ud3f9\u9e75\u3dbe\u45fe\ubb83\u69be\ud088\u1215\u0bf6\u9b09\u9ba9\ua050\u117e", "\ud9de\udc62\ud83b\udef0\udae1\udf62\uda06\ude3d\ud828\ude56\uda94\ude8d\udac5\udda8\udab7\udd79\uda28\udf13\udbe5\udfd3\uda4c\ude22\ud97a\uddd7\udb3d\udff5\u503f\ud80e\udc7e\udb71\udecb\ud845\udc3f\udaa2\uddd6\uda3c\udc61\uda23\udd19\udb34\ude87\uda9d\ude2b\ud9bf\udd24\ud9ca\udd45\udbd3\udf2e\ud91b\udc73\ud89b\uddb6\ud912\udf64\u3de7\ud812\udfb8\ud9a5\udd10\udb98\udf0b",
        5, 54479, 724723463, -8621939645336861245L, -29100L, false, false, (char) 33050, (char) 56670,
        Double.longBitsToDouble(0x3fec41102444bea0L), Double.longBitsToDouble(0x3fa5aa38dae80e10L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 11, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u9e88", "\ud832\ude6b\ud965\ude7e\udbef\ude68\ud8a3\udc2a\uda37\udf47\udbe5\udff3\ud8fa\udda2\udb0c\udff4\udb6c\uddd1",
        11, 43878, -1501477472, 5754276885467843935L, 97692L, false, false, (char) 64064, (char) 16117,
        Double.longBitsToDouble(0x3fb533b20ee48cf0L), Double.longBitsToDouble(0x3fe0bf9d31addbb5L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-58, -48, 78, -71, 107, -106, -62, -101]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 13, 11, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d\udb72\ude92\ud87e\udd9d", "\u9e88\u6f5c\u7895\u8e60\u86d6\u5559", "\udbe5\udff3",
        49, 25294, 1184196009, 1649025660496626854L, -90660L, true, true, (char) 13694, (char) 5777,
        Double.longBitsToDouble(0x3fe6a32c604c8df4L), Double.longBitsToDouble(0x3fecc38040c463c8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 12, "\udbf6\udc00\udb7f\udf48\udb04\udc87\ud800\udc4f", "\ua306\u5400\ud5ae\u9e88\u6f5c\u7895\u14ac\u1205\u6d67\u54e6\u1149\ud50f", "\udb6c\uddd1\ud8d5\udd73\ud91b\udeda\udb44\udc59\udafe\udd0b\ud87e\udeb0\ud90e\udd8d\ue939\ud9c1\udc1b\udb65\ude51\ud96e\ude43\udab6\ude47",
        6, 59159, 1046640455, -6649661465154075694L, 5331L, false, false, (char) 52603, (char) 59747,
        Double.longBitsToDouble(0x3fe7d4fcc6f9afe0L), Double.longBitsToDouble(0x3fe8b0f0ed91a937L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 9, 11, "\ud9bf\udc44\uda65\udeb6\udb37\udcd4\udbfa\uddeb\ud9ec\udf2a\uda28\ude4d\udafb\udea8", "\u5320", "\ud838\udcee\ud950\ude8f\udbef\ude68\ud8a3\udc2a\uda37\udf47\udb18\udcaf",
        59, 78430, 658563241, -6040315168312044611L, 95043L, false, false, (char) 63186, (char) 50185,
        Double.longBitsToDouble(0x3fc893c47550c10cL), Double.longBitsToDouble(0x3fa291970c463c80L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 7, 12, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u9e88", "\ud832\ude6b\ud965\ude7e\udbef\ude68\ud8a3\udc2a\uda8e\udf14\ud851\udf0a\ud92c\ude06\ud92e\udc65\udad7\ude9b",
        -4, 1062, -1501477472, 5754276885467843935L, -35683L, false, false, (char) 64064, (char) 16117,
        Double.longBitsToDouble(0x3fc88c79077247c8L), Double.longBitsToDouble(0x3fe0bf9c81addbb5L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 6, 1, "\udbf6\udc00\ud87e\udfe9\udaf8\udd68\ud891\udead\ud8ca\udfaf\ud822\udcc9\uda22\udf29", "\u9e88", "\ud832\ude6b\ud965\ude7e\udbef\ude68\ud8a3\udc2a\uda37\udf47\udbe5\udff3\ud8fa\udda2\udb0c\udff4\udb6c\uddd1",
        11, 43878, -1501477472, 5754276885467843935L, -35683L, false, false, (char) 64064, (char) 16117,
        Double.longBitsToDouble(0x3fd0b33c83b923f2L), Double.longBitsToDouble(0x3fe0bf9d31addbb5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 9, 11, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u9e88\u6f5c\u7895", "\udbef\ude68\ud9fa\ude56\udba9\udf0e\udb14\udeec\ud8fa\udda2\udb0c\udff4\udb6c\uddd1\ud8d5\udd73\uda7c\udfab",
        33, 5991, 26037599, 1969286835277200189L, -62188L, false, false, (char) 9356, (char) 21454,
        Double.longBitsToDouble(0x3fe0bf9d31addbb5L), Double.longBitsToDouble(0x3f9a808285830ec0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-59, -94, -55, 59, 107, -21, -62, -115]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 1, 11, "\udbf5\udfd2\udbf9\udf6b\ud89b\udd1b\ufff2\udbbd\udc26\udb40\udf99\udacb\uddff", "\uc93e", "\ud832\ude6b\ud942\udc7e\udbef\ude68\ud8a3\udc2a\uda37\udf47\ud80c\udc87\ud8fa\udda2\udae7\udd29\ud921\udc58\udab1\udd21\ud947\udf35\udb44\udc59",
        46, 79599, 458510321, 7317499732605132244L, -18556L, false, false, (char) 46434, (char) 7754,
        Double.longBitsToDouble(0x3fe77258850bb3ceL), Double.longBitsToDouble(0x3fa339522993e280L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 7, 13, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2", "\u2b03\u22c0\ud5e5\u9e88\u6f5c\u19fd\u8e60\u86d6\u5559\ub449\u8dfc\u9e89", "\udb6c\uddd1\ud8d5\udd73\uda44\ude10\udbcf\udc9f\udafe\udd0b\ud983\udd76\ud90e\udd8d\ue939\ud9c1\udc1b\udb65\ude51\ud96e\ude43\udab6\ude47",
        6, 70431, -563226195, 6726267969957677928L, -17835L, true, true, (char) 12324, (char) 46257,
        Double.longBitsToDouble(0x3fddfd923ab09dceL), Double.longBitsToDouble(0x3fe08c8b91ad2da0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 1, 6, 14, "\udbf6\udc00\ud87e\udfe9\ud95a\udc47\ufff9\ud8cb\udc2d\ud8aa\ude4e\udafb\udea8", "\u7a88", "\udae3\udec3\u49d7\udbec\udf2c\ud8b8\udc32\udb67\udc88\ud99c\udfac\ud884\udd67\udb0c\udfff\udb0a\udfa1",
        11, 43878, 1367557536, 1752651689666366815L, -99740L, true, false, (char) 64064, (char) 16117,
        Double.longBitsToDouble(0x3fc88c790babbbc4L), Double.longBitsToDouble(0x3fe0bf9ad9addbb5L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 15, 5, 6, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ud9b1\ude8b\ud8ba\udd98\ud8aa\ude4e\udac4\udfed\udad2\udc83\uda95\udc46\uda02\udf05\udbf0\udd0e\ud801\ude96\uda78\ude19\udb14\udc51\ud8e5\ude38\ud8b7\udf90\udba4\ude87\udb48\udde0\u2921", "\u90af\ud0fa", "\ud983\udd76\uda73\udd3a\ud84f\udd19\ud9c1\udc2c\udb65\ude51\ud96e\ude43\uda8d\udfc2\ud892\ude08\ud908\udd78\udba0\udd86\ud874\udc6c\udbda\udcd5\udb34\ude07\udabb\udf1a\ud8ee\ude03\u29e5\ud972\udc76\uda6c\udcb0\ud967\ude4d\udbfa\udc46",
        24, 62130, 656378416, 1806331274127670360L, -87624L, true, false, (char) 11467, (char) 47655,
        Double.longBitsToDouble(0x3fe151a164c89fcbL), Double.longBitsToDouble(0x3fd2eec3b1c63e2eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 15, 1, 12, "\ud8e5\udd34\ud87e\udfe9\ud89b\uddc6\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8\udad2\udc83\ud9c2\udcbd\uda69\udeb8\ud966\ude51\ud881\udeb2\ud832\ude6b\uda31\uddc5\ud99e\udc3e", "\u9e89\u5edb\u5c61\ud150\u7739\ud0fa\u0b8e\u72fc\ubf35", "\ud9c1\udc1b\udb65\ude51\ud96e\ude43\udab6\ude47\udabc\udd21\ud9d2\udff3\udb3d\udc0f\uda31\udc2f\uda80\udeb0\ud886\udc19\ud943\ude81\uda20\udf86\udb22\udcfc\ud8ac\ude77\uda54\udd50\ud85b\udc63\udabe\udead",
        55, 7488, -1199845404, 3375681741313202409L, 8050L, true, true, (char) 38740, (char) 29305,
        Double.longBitsToDouble(0x3fd804da61e74dd2L), Double.longBitsToDouble(0x3fed59a96f454b3eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 3, 11, "\udbf6\udc00\uda94\uddb3\ud82d\udf18\ufff2\ud8cb\udc2d", "\u22c0\u00dc\ud3b6\u6e9f\u7895", "\ud85e\uddc9\udbc7\udf05\uda60\udc77\udbe5\udff3\ud8fa\udda2\ud8cb\uded4\udb6c\uddd1\udb3d\udd27\udb11\udeb1",
        33, 5991, 26037599, 1969286835277200189L, 14884L, false, true, (char) 23130, (char) 12643,
        Double.longBitsToDouble(0x3fe3a20935fb4e73L), Double.longBitsToDouble(0x3fc0d2e3a06c2540L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 5, 11, "\ud8ba\udd3b\ud87e\udfe9\ud89b\uddc6\ufff2\ud930\udca2", "\u700d\u122b\ub08e\ua319\ua489\u8e60\u9e30\u6938\u8194\u572d\u9072\u5313", "\ud8ea\udd81",
        33, 43952, 361356137, -6386995790399387621L, -48076L, false, false, (char) 42754, (char) 35401,
        Double.longBitsToDouble(0x3fd0fd08bc2fe74cL), Double.longBitsToDouble(0x3fdaddbb5f2050f8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 3, 11, "\ud80a\udc2e\ud885\udfd0\ud89b\uddc6\ufff2\ud8cb\udc2d\udade\ude48\ub6bb", "\uc516", "\udaf8\ude2e\uda27\udcd8\udacb\udde7\ud99c\udcfb",
        43, 6185, 316145798, 6680938856949573033L, -79535L, true, true, (char) 12375, (char) 64064,
        Double.longBitsToDouble(0x3fb8a6a4c4900918L), Double.longBitsToDouble(0x3f9bdf0ec2fe74c0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 15, 15, 6, "\udbf5\udfea\ud882\ude0a\ud99a\udfa7\ufff2\ud8cb\udc2d\uda28\ude4d\udaca\udfa8\ud839\udc0c\udae7\udedb\ud8fb\udc35\ud878\udeff\uda10\udf6d\ud84c\udddb\ud965\ude7e\udbc4\udf92\ud8a2\udf58\uda37\udf47\udbe5\udff3\ud9ea\udd1a\uda5a\udce4\udb6c\udd30\ud8d5\udd73\uda7c\udfab\udb44\udc59\udafe\udd84\ud983\udd76\ud90e\udd8d\ue939\ud9c1\udc1b\udb65\ude51\ud96e\ude43\ud8a0\ude3c\udabc\udd21\uda5c\udc2a\u56ff\udafb\ude9b\ud95c\udec1\ud8ff\udf80\ud83f\udf89\ud834\ude1b\udb67\ude1f\ud86e\udc25\ud9a6\udd7d\ua314\ud98d\udc97\ud9a4\ude9f\udbf2\udcae\uda42\udd4d\ud947\ude3e\ud998\udfc2\ud974\udc7f\ud9aa\udf18\ud825\uddf2\ud93e\udf1f\ud878\uddd5\ud89b\udd63\udb81\udd83\uda48\udd12\ud983\udf9c\ud81c\udc43\ud91f\udd7d\udb13\udfd1\ud963\udeb0\u4c09\udbe7\udc6f\uda5b\uddf1\ud85c\ude70\uda31\udcb2\ud875\udf3f\ud8b7\udce2\udb4f\udc9b\udadb\udc19\ud8db\udcb4", "\ucca6\u6bbb\ud6ee\u3833\ua8a2\u53d9\u3ee0\u9f3e\u0fc8\u1ff7\u8307", "\ud94f\udc33\ud91a\uddd4\ud8ad\ude3f\ud8db\ude2e\ud988\udff8\uda65\uddaa\ud8df\uddcc\udbf0\udf86\udb29\ude57\uda5b\udc53\udb3c\udd2d\ud855\udcb0\udb34\udda2\ud9ee\ude89\ud96c\ude67\ud9a5\udf2c",
        46, 67392, 1977371337, -3973528898181413160L, -29679L, true, true, (char) 26489, (char) 39225,
        Double.longBitsToDouble(0x3fe68690cca648e4L), Double.longBitsToDouble(0x3feab79c842c8eddL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[65, 78, -71, 68, 99, -108, -75, -119]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[65, 78, -71, 68, 99, -108, -75, -119]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 14, 0, "\u1b71\ud87e\udfe9\ud874\udf93\ue5c4\udae5\udeb9\udbaa\udced", "\u4ee6\uc6ae\uc44a", "\ud965\ude7e\udbf3\udd68\udbb3\udcaa\uda37\udf47\udbe5\udff3",
        28, 67814, 882358003, 1649078076277507238L, -79535L, true, true, (char) 26988, (char) 40512,
        Double.longBitsToDouble(0x3fd179a81108ba78L), Double.longBitsToDouble(0x3fddcaef2a2fe74cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 12, 2, "\udbf5\udf72", "\u7f19\u7de9\u375b\u2b03\u22c0\ud5e5\uae38\u8574\u7885", "\udbef\ude68\udbb3\udcaa\uda37\udf47\udbe5\udff3\uda24\udc11\udb46\udefd\udb6c\uddd1\ud8d5\udd73\uda7c\udfab",
        33, 87487, 26037599, 1969286832475405117L, 92436L, false, false, (char) 9356, (char) 21454,
        Double.longBitsToDouble(0x3fdf440a6381b6e8L), Double.longBitsToDouble(0x3feb57f69341e3b6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 2, 11, "\uda22\ude95\ud87f\udc58\ud89b\uddc6\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u9e88", "\ud832\ude6b\ud9b6\uddc7\udbef\udde6\ud8c4\udcc0\uda42\udddf\ud91c\udedb\ud8fa\udfc5\udb10\udef4\udb6c\uddd1",
        34, 2866, -1501477525, 5754276885467844085L, 97692L, false, true, (char) 24421, (char) 16117,
        Double.longBitsToDouble(0x3fb533b23aad0cf0L), Double.longBitsToDouble(0x3fb6e89c8d6ed8a0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-48]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 13, 11, "\000", "\u022b", "\000\udbd5\udf66\ud802\udfbf\u5313\000\000\udb94\udf2a\000\udbef\ude68\udaed\udfef\000\udbe5\udff2",
        -1, -1000, 169, 1649025660496626854L, -34596L, true, true, (char) 13694, (char) 0,
        Double.longBitsToDouble(0x3fe6a000000000f4L), Double.longBitsToDouble(0x3fecc38040c463c8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 1, 12, "\udbf6\udc00\ud93a\udd66\ud83f\udc93\ud91f\udf08", "\ua306\u5400\ud5ae\u6bd7\u6595\u6d75\u14ac\u1205", "\ufbab\ud8e4\ude36\ud91e\udfdc\udb0c\udff4\udb6c\uddd1\ud8d5\udd73\ud91b\udeda\udb44\udcb7\udafe\udd0b\ud87e\udeb0\ud90e\udd8d\ud89e\ude0c\ud9c1\udc08\udb65\ude51\ud958\udc3c\udab6\ude47\udabc\udc79\ud9d2\udff3\ud924\uddfb\udb08\udeb0\ucba3\udba7\udd25\uf69d\ud948\udcc6\ud830\udcfe\uda48\udef8\ud894\ude41\ud942\udcbf\udaf2\uddf8\ud98c\udd48\udb4a\udec5\uda4b\udec6\u6cde\ud90c\udf4d\uda27\udfc7\uee1c\uda1f\udf24\udbc1\ude50\udb7d\udd9d\udac8\udd81\ud85a\udd01\u59ae\ud965\udd19\ud833\uded6\ud8d9\udc74\udb9c\udf0f\udb2b\ude73\udb54\udea2\uda9f\udcc8\udac2\udef2\uf73f\udad1\udf6d\u7eb0\uda1e\udea0\ud92d\udfd4\udbb7\udf91\u153c\ud8f3\udcf3\ud9a7\udf32\udb31\udf53",
        2, 28111, 948350806, -7062620429732391424L, -68127L, true, false, (char) 42879, (char) 62149,
        Double.longBitsToDouble(0x3fd3730a9dbf52b4L), Double.longBitsToDouble(0x3fea635b4d68d290L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 15, 15, 10, "\udbf6\udc00\ud87e\udfe9\ud89b\udccd\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u9e88\u6f5c\u7895", "\udbef\ude68\udbe1\udd88\udbc0\udc69\udb14\udeec\ud8fa\udda2\udb0c\udff4\udb6c\uddd1\ud8d5\udd73\uda7c\udfab",
        33, 5991, 26037599, 1969286835277200189L, -62188L, false, false, (char) 9356, (char) 21454,
        Double.longBitsToDouble(0x3fe0bf9d31addbb5L), Double.longBitsToDouble(0x3f9a808285830ec0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, 92, -43, 69, 107, -21, -62, -115]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 1, 11, "\uda30\ude8c\ud905\udd75\ud89b\udd1b\ufff2\udbbd\udc26\udb13\udf99\udacb\uddff", "\uc93e", "\ud832\ude6b\ud942\udc7e\udbef\ude68\ud8a3\udc2a\uda37\udf47\ud80c\udc87\ud8fa\udda2\udae7\udd29\ud921\udc58\ua55e\ud95a\udc1c\udb44\udc59",
        -3, 3787, 458510321, -2266160273054404652L, -18556L, false, false, (char) 56836, (char) 7754,
        Double.longBitsToDouble(0x3fcdc009d7c03f44L), Double.longBitsToDouble(0x3fa339522993e280L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 14, 13, "\udbf6\udc00\ud87e\udfe9\ud89b\uddc6\ufff2", "\u2b03\u22c0\ud5e5\u9e88\u6f5c\u19fd\u8e60\u86d6\ubf7b\u32a1\u4c2d\u9e89", "\udb6c\uddd1\ud8d5\udd73\ud929\udcd1\udbcf\udc9f\udafe\udd0b\udaf5\udcc9\ud88e\udfd9\udbc7\uddea\udbfc\uddf8\udae5\udc20\ud96e\ude43\udab6\ude47",
        42, 49574, -563226195, 6726267969957677928L, -17835L, true, true, (char) 12324, (char) 46257,
        Double.longBitsToDouble(0x3fddfd923ab09dceL), Double.longBitsToDouble(0x3fe08c8b91ad2da0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 1, 12, "\udbf6\udc00\ud93a\udd66\ud83f\udc93\ud91f\udf08", "\ua306\u5400\ud5ae\u6bd7\u6595\u6d75\u14ac\u0864", "\ufbab\ud960\ude34",
        22, 25294, 1184196009, 1649025661402596518L, -54007L, false, false, (char) 20943, (char) 5777,
        Double.longBitsToDouble(0x3fe60f5e5c4c8df4L), Double.longBitsToDouble(0x3fe2dcd498c463c8L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, 92, -43, 69, 107, -21, -62, -115]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[0, 92, -43, 69, 107, -21, -62, -115]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 14, 11, "\uda30\ude8c\ud905\udd75\ud89b\udd1b\ufff2\udbbd\udc26\udb13\udf99\udacb\uddff", "\uc93e", "\ud832\ude6b\ud942\udc7e\udbef\ude68\ud8a3\udc2a\ud909\udcea\ud80c\udc87\ud8fa\udda2\udae7\udd29\ud921\udc58\ua55e\ud95a\udc1c\ud8ec\udf8c",
        55, 10189, 458510321, -2266160273054404652L, -18556L, false, false, (char) 56836, (char) 7754,
        Double.longBitsToDouble(0x3fcdc009d7c03f44L), Double.longBitsToDouble(0x3fa339522993e280L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 11, "\uda87\udc82\ud87e\udfe9\ud8a3\udfc7\ufff2\ud8cb\udc2d\uda28\ude4d\udafb\udea8", "\u9e88\u6f5c\u7895\u8e60", "\ud8a3\udc2a\uda37\udf47\udbe5\udff3\ud8fa\udda2\udb0c\udff4\udb6c\uddd1\ud8d5\udd73\uda7c\udfab\ud9f3\udc74",
        56, 79596, 458510321, 7317499732068453076L, -76546L, false, false, (char) 21454, (char) 22974,
        Double.longBitsToDouble(0x3fdaddbb5148d35aL), Double.longBitsToDouble(0x3fea1bc49f0806c4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|parsePaxHeaders|java.io.InputStream|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|applyPaxHeadersToCurrentEntry|java.util.Map|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|available||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|canReadEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|close||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|consumeRemainderOfLastBlock||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getCurrentEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getLongNameData||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextTarEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getRecord||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getRecordSize||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|isAtEOF||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|isDirectory||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|isEOFRecord|[B|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|mark|int|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|parsePaxHeaders|java.io.InputStream|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
