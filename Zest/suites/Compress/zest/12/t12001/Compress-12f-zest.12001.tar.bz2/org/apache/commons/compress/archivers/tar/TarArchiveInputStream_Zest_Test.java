package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 4, 4, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52", "\ud123\ub7c4", "\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9c6\uddf3\ud82f\udf4f",
        53, 88324, -1832974494, 1898181985229620971L, -55205L, false, false, (char) 7786, (char) 55208,
        Double.longBitsToDouble(0x3fe521fbb754d908L), Double.longBitsToDouble(0x3fc5cc33213a5790L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 4, 4, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52", "\ud123\ub7c4", "\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9c6\uddf3\ud82f\udf4f",
        53, 88324, -1832974494, 1898181985229620971L, -55205L, false, false, (char) 7786, (char) 55208,
        Double.longBitsToDouble(0x3fe521fbb454d908L), Double.longBitsToDouble(0x3fc5cc24013a5790L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 4, 4, 13, "\ud9e7\udf1f", "\u4402\uc2f0\ud4fa\u53de", "\ud978\udc1b\ud851\udef1\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34",
        43, 77297, 1373428868, 7462468411830765410L, -81845L, true, false, (char) 59878, (char) 32415,
        Double.longBitsToDouble(0x3fe7073c4e1e888aL), Double.longBitsToDouble(0x3fe521fbb7546b1dL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 1, "\udb09\ude32", "\ua564\u9abc\ud4fa", "\ud958\udc72\ud977\udf42\ud851\udef1\ud86c\udc11\ud893\ude17\ud80f\ude81\ud9f5\udcd0\udb40\udfb3\udb31\udd34",
        20, 77297, 1373428868, 7462468411830765410L, -81845L, true, false, (char) 4906, (char) 13905,
        Double.longBitsToDouble(0x3fe1d91e3e1eb18aL), Double.longBitsToDouble(0x3fe521fbb754d908L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 3, 1, 13, "\udba1\udc46\ud8c5\udd4c\ud887\udcbb\u0ec2\ud93d\udf96", "\ud123\ub7c4\u4dcb", "\ud88f\udf06\ud901\ude93\udb1d\udc73\ud835\ude08\udb31\udd8f\ud9c6\uddf3\ud82f\udf4f\ud89d\uddc1\ud978\udd96\ud9ab\ude13\udbe5\udce2\ud9d4\udc98\udb96\ude4c\ud980\udf84\udbd9\udcc6\ud90e\ude40",
        4, 7860, 1637469999, -7645822792009985970L, 88169L, true, true, (char) 32803, (char) 5572,
        Double.longBitsToDouble(0x3fda3a7834cc07e4L), Double.longBitsToDouble(0x3faf32f5194a8390L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[99, 42, -107, 28, 87, -117, 16, -9]]\012",
        Z.run(T, 1, 10, 6, 2, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\udb9a\udc40\udba5\udd1b\u0628", "\u7c03\u50b3\u0c5e\u9328\u2dc1\u734e\u3f41\ubeef", "\u7957\ud978\udd96\udae0\udcf1\ud8f1\udc0c\uda31\udcd9\ud8ec\udec7\ud96c\ude71\udb0c\udecc\ud90e\ude40\ud986\udddb\u3465\ud9b7\udd14\ud8a3\ude6d\ud82b\udc69",
        0, 15952, -1383831950, 7650555908296951791L, -51551L, true, false, (char) 16166, (char) 50061,
        Double.longBitsToDouble(0x3fd433e7a0e2b4aaL), Double.longBitsToDouble(0x3fcebf42eab8b470L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 2, 4, 13, "\ud903\udc45\ud8b8\udc4c\ud9cb\udc7e\ud967\udeb5\ud93d\udf52", "\u0367\u1e95", "\ud86c\udc11\ud88f\udc06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9d7\uddf3\ud82f\udf4f",
        53, 88324, -1832974494, -4003222379791108277L, -55205L, false, false, (char) 7786, (char) 17617,
        Double.longBitsToDouble(0x3fe521fad9bcd908L), Double.longBitsToDouble(0x3fd8f828a7a12bc8L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 0, 4, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud971\ude43\ud93d\udf52", "\ud123\ub7c4", "\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udbb0\udd0c\udbfe\udfbc\ud9c6\ude29",
        27, 29924, -1911437587, -1251809455939393328L, -14176L, false, false, (char) 29561, (char) 7786,
        Double.longBitsToDouble(0x3fe0f58c56a43f76L), Double.longBitsToDouble(0x3feaa6c844ae6199L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 4, 4, 4, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52", "\ud123\u4094", "\uda2b\ude93\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9c6\uddf3\ud82f\udf4f",
        31, 88324, 1962215266, -6776581715559692565L, -55205L, false, false, (char) 7786, (char) 55208,
        Double.longBitsToDouble(0x3fe521fbb754d908L), Double.longBitsToDouble(0x3fee4534c84e95e4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 5, 12, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\udb00\ude73", "\u232f\ub7e7", "\ud88e\udc5b\ud88c\udf9a\u15ee\udbcf\uddec\udac8\udc7f\ud972\ude98\uda21\udf55\ud82f\udf4f",
        53, 88324, 2009007970, 2356745958266793240L, -55579L, false, false, (char) 28186, (char) 43100,
        Double.longBitsToDouble(0x3fc5cc33213a5790L), Double.longBitsToDouble(0x3fed5f3bfd461c5dL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 8, 4, 13, "\udb93\udc5a\udaf6\udca6\ud894\udeb2\ud940\udd27\ud93d\udf52", "\ud123\ub7c4", "\uda57\udd0b\ud87b\udf65\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\udb00\udeee\uda4e\ude93\udb77\udca3\ud9a6\udfe4\udae0\udcf1\ud989\udc02\uda31\udcd9",
        -3, 58594, 542861310, -5653646045444954594L, 43532L, false, false, (char) 26162, (char) 25472,
        Double.longBitsToDouble(0x3fca31ca41769f28L), Double.longBitsToDouble(0x3febf1dfc40316beL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[107, 83, -107, 28, 87, -117, 16, -9]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 13, 4, 4, "\udb9b\udd83\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52\udbb4\udf41\u061f\ud8d9\ude95\uda51\uddde\ud978\udc1b\ud851\udef1\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9c6\uddf3\ud82f\udf4f\u7957\ud978\udd96\udae0\udcf1\ud989\udc02\uda31\udcd9\ud8ec\udec7\ud96c\ude71", "\ubd25\u17fa\u5c2f\u9eeb\u7751\u46dd\ub580\u70ff\u61a7\u18a4\u6323\u046e\uc0cc\u51b6\u42d3\u091a\uc328\u3f88\u83a2\uafef\u0ab1", "\ud88f\udf87\ud8f6\udd98",
        9, 87610, 1884768702, -5080185679602949405L, 62479L, false, true, (char) 42393, (char) 5002,
        Double.longBitsToDouble(0x3fcc46c36e167ca8L), Double.longBitsToDouble(0x3fcbeaf7ac939ff4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 6, 4, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52", "\ud123\ub7c4", "\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9c6\uddf3\ud82f\udf4f",
        53, 88324, -1832974494, 1898181985229620971L, -55205L, false, false, (char) 7786, (char) 55208,
        Double.longBitsToDouble(0x3fe521fbb754d908L), Double.longBitsToDouble(0x3fc5cc33213a5790L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 4, 4, 2, "\udb93\udc14\uda48\udc84\uda59\ude24\ud940\udd27", "\u53de\ud123\ub7c4\u7c03\u50b3\u0c5e", "\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9c6\uddf3\ud82f\udf4f\u7957\ud978\udd96\udae0\udcf1\ud989\udc02\uda31\udcd9\ud8ec\udec7\ud96c\ude71\udbd9\udcc6\ud90e\ude40\ud986\ude36\ud835\udc58",
        41, 43158, 218878030, -3977875073314906298L, -86482L, false, true, (char) 43909, (char) 28850,
        Double.longBitsToDouble(0x3fd547a468c7a01aL), Double.longBitsToDouble(0x3fc5c62ef7384b2cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[100, 119, -30, 56, 37, 28, 60, -20]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 4, 13, "\uda94\udca7\ud812\udc68\ud855\ude4c\ud96c\udc1c\ud997\udcad", "\u92a9\u2a68\u7c03\u50b3\u0c5e\u9328\ud1ef\u72e3", "\ud877\udf44\ud830\uddfe\udacd\udddf\ud978\udd96",
        16, 78933, 627066394, -7430569465795358459L, 13952L, false, false, (char) 28186, (char) 59740,
        Double.longBitsToDouble(0x3fc5cc30813a5790L), Double.longBitsToDouble(0x3fe66f1353958c34L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 1, 4, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52\udaee\udc1e", "\ub7c4\u7c03\u50b3\u0c5e\u5f9a\u2dc1\u734e\u7e11\uc73f", "\u7957\ud978\udd96\udae0\udcf1\ud989\udc02\uda31\udcd9\ud8ec\udec7\ud96c\ude71\udbd9\udcc6\ud90e\ude40\ud986\udddb\ud835\udc58\ud9b7\udd14\ud8a3\ude6d\udb01\uddf3",
        5, 76258, 32691422, 1258172873853361453L, -32393L, false, false, (char) 55434, (char) 42000,
        Double.longBitsToDouble(0x3feca974054b580dL), Double.longBitsToDouble(0x3feb0201e5b591f5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 9, 0, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52", "\ud123\ub7c4", "\ud86c\udc11\u6f0d\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9c6\uddf3\ud958\udf02",
        53, 88324, -1832974494, 1898181985229620971L, -55205L, false, false, (char) 7786, (char) 55208,
        Double.longBitsToDouble(0x3fe521fbb754d908L), Double.longBitsToDouble(0x3fc5cc33213a5790L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:-1 |a0=[B:[[99, 42, -107, 28, 87, -117, 16, -9]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 8, 13, 12, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52", "\ud123\ub7c4", "\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\uda13\udfee\ud82f\udf4f",
        53, 88324, -1832974494, 1898181985229620971L, -55205L, false, false, (char) 11051, (char) 55322,
        Double.longBitsToDouble(0x3fda23f764af2ac8L), Double.longBitsToDouble(0x3fc5c83c213a5790L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 12, 14, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27\ud93d\udf52\udaee\udc1e", "\u962e\u7c03", "\ud88f\udf06\udad3\udd5d\ud80d\uddf6\ud86b\udc90\udb31\udd34\ud9c6\uddf3\ud8ff\udcb7\udaeb\udcc1\ud978\udd96\udae0\udcf1\ud989\udc02\ud8df\udf84\ud827\udc56\udaaf\udf28\udbbc\udfca\ud90e\ude40",
        40, 97804, 1629531220, -5844382940039294898L, 79499L, false, false, (char) 21193, (char) 19030,
        Double.longBitsToDouble(0x3fd43153dca05ac8L), Double.longBitsToDouble(0x3f9d3021363a5580L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[61, -15, 85, 34]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 13, 4, 7, "\udb6d\udc21\udb85\ude52", "\u5a85\uc909\u6248\u10eb\u78a7\u6bcd\u50b3\u93d0\u3a76\ud264\u7330\u7e11\u80ae\uc0dd\u4bd9\u749f\u2e2a\ud5e4", "\ud8ec\udec7\uda75\udf04\udbd9\udcc6\udaf7\udfd5\ud986\udddb\udbf3\udcf3\udb5c\udd2c\uda68\udfbd\udbd1\udf4d",
        13, 40116, 387531743, 6781125645748275219L, 6727L, true, true, (char) 39586, (char) 9076,
        Double.longBitsToDouble(0x3fcbc7bfb7213b6cL), Double.longBitsToDouble(0x3fee487b7c1ae658L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[0, -16]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 13, 12, 13, "\udb30\udc20", "\u9df6\uc16b\ud4fa", "\udaf9\udd12\ud858\ude76\ud832\ude52\ud988\udf91\ud88e\udf01\ud901\ude93\udbcf\uddec\udaca\udff3\udb31\udd34\ud9c6\uddf3\ud82f\udf4f\u7957\ud978\udd96\ud999\udf29\ud8c3\udd08\ud881\udc5f\udbcc\udfe8\ud96c\ude71\udbe2\udf6b",
        50, 8134, 1805604628, -7078304753472804269L, 51580L, true, false, (char) 52320, (char) 65053,
        Double.longBitsToDouble(0x3fa5d0a5a2b41a40L), Double.longBitsToDouble(0x3fef1da3f9b8e9c6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 1, 15, 13, "\ud9d6\udd1f", "\u4662\u63ae\ud4fa\u53de", "\ud978\udc1b\ud851\udef1\ud86c\udc11\ud88f\udf06\ud815\udf2e\ud8d4\ude0f\uda0c\udc52\udb48\uddbd",
        43, 77297, -253961084, -6714641998545964431L, -81845L, true, false, (char) 59878, (char) 32415,
        Double.longBitsToDouble(0x3fe7073c4e1e888aL), Double.longBitsToDouble(0x3fe521fbb7546b1dL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 10, 0, 13, "\ud9e7\udf1f", "\u9c03\uc2f0\ud4fa\u53de", "\ud978\udc1b\udad9\udfe5\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34",
        48, 77297, 1373428868, 7462468411830765410L, -81845L, true, false, (char) 59878, (char) 32415,
        Double.longBitsToDouble(0x3fe7036c4e1e888aL), Double.longBitsToDouble(0x3fe520e3b7546b1dL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udb09\ude32", "\u2aba\u93d3\u7d19", "\ud825\udfdf\ud9ae\udca1\ud999\udf80\ud8a2\udf3c\ud893\ude42\ud80f\ude81\ud9f5\udcd0\udb40\udfb3\udb1d\ude34",
        20, 32937, -801992742, 7462468411830765410L, -81845L, true, false, (char) 4906, (char) 13840,
        Double.longBitsToDouble(0x3fd3b23c73db6048L), Double.longBitsToDouble(0x3fe521fbb754d908L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 1, 1, "\udb09\ude32", "\u79fa\u31da\ua334\u53de\ubb16\u22e7\u07ec\u4369\u1d88\u01e0\u93b2\u55ae\u35e5\u80ae\u3d3b\u4bd9\u2d8a\u2e3a\u3b1a\u3c0d\u6ff1\u9dd3", "\ud913\udc6c\ud930\udc7f\uda94\udc2a\udae6\udc9f\udbae\udc2e\uda32\udc45\uda43\udf20\ud8e3\udeb3\ud8e4\udfc7",
        57, 22892, 101704424, -3112052857413203538L, 29510L, false, true, (char) 43160, (char) 20119,
        Double.longBitsToDouble(0x3fd18e84bb1ed154L), Double.longBitsToDouble(0x3fe94b040b5c3f9bL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:-1 |a0=[B:[[113, 22, -107, 28, 87, -117, -110, 13]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 13, 13, "\udba1\udc46\ud8c5\udd4c\ud887\udcbb\u0ec2\ud93d\udf96", "\uc84d\ub7c4\u24ad\u2234\u9e1a\u92c5\u2dc1", "\udb31\udd8f\ud9c6\uddf3\ud82f\udf4f\ud89d\uddc1\ud978\udd96\udb90\ude53\udbe5\udce2",
        32, 30118, -1872256488, -1762615856169593888L, -61938L, false, true, (char) 56614, (char) 14924,
        Double.longBitsToDouble(0x3fe099e03c8c6963L), Double.longBitsToDouble(0x3feb669b7e620d5aL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-82]]\012",
        Z.run(T, 1, 10, 6, 2, "\u00de", "\u2b78", "\u009a\ud8d9\ude95\udab9\uddd2\ud978\udc1b\000",
        7, 29927, 941132613, -3238527306509641794L, 61278L, true, true, (char) 6495, (char) 21724,
        Double.longBitsToDouble(0x3ec209d64afc0000L), Double.longBitsToDouble(0x3f1aff1b6c800000L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[-73, 2, -107, -105, 127, 21, 65, -65]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:-1 |a0=[B:[[-73, 2, -107, -105, 127, 21, 65, -65]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 13, 6, "\ud8e7\udf32\ud8c5\uddc7\udaaf\ude45\ud971\uddef\ud93e\udc01", "\u37d4\ub7c4", "\ud91c\udca8\ud868\uddba\uda7f\udf53\udbcb\udf7c\udbb0\udd0c\udbfe\udfbc\uda1a\udf93",
        48, 75002, -1911437753, -1251809593368844080L, 97357L, false, true, (char) 29561, (char) 7828,
        Double.longBitsToDouble(0x3fe66d8c56a43f76L), Double.longBitsToDouble(0x3feaa6c844ae6199L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 13, 12, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud9d5\ude51\udb5f\udf75", "\ud123\ub7c4\u1bc7\u50b3\u0c5e\ub741\u639f\u875a", "\ud9ae\uddbc\ud82f\udf4f\u1dec",
        51, 55573, -2011740626, 6144661372923982016L, 35624L, false, false, (char) 5487, (char) 28186,
        Double.longBitsToDouble(0x3feaa6c842ae6120L), Double.longBitsToDouble(0x3fbebd310c7984e8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 8, 8, 4, "\ud951\ude21", "\u573e", "\udbff\uddc3\ud8d9\ude95\uda97\udf30\ud978\udc1b\udaf0\udd80\uda2b\ude93",
        22, 13613, 215157655, -8856584473756080342L, 97500L, false, true, (char) 13258, (char) 59615,
        Double.longBitsToDouble(0x3fcb6c9516fe6384L), Double.longBitsToDouble(0x3fddfaa9baa5001aL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 5, 4, "\udb9b\udd83\uda83\udd4b\ud887\udcbb\ud940\udd27\uda34\udf4c\udbb4\udf41\u061f\ud8d9\ude95\uda51\uddde\ud84d\udda6\u921c\ud986\udc39\udacb\udf84\ud904\udfb8\udbcf\uddec\udac8\udc7f\udab2\udf32\udbb5\udd98\ud82f\udf4f\u7957\ud978\udd96\udae0\udcf1\ud989\udc02\uda31\udcd9\ud8ec\udec7", "\u29e2\ubd25", "\ud8a3\ude6d\ud9a2\udea4\uda76\ude15\ud6f9\ud9ea\udff0\udb47\udcfe",
        58, 99724, 745211849, 1423253358751050474L, 80692L, false, false, (char) 45792, (char) 6807,
        Double.longBitsToDouble(0x3fe9eb6fb838331bL), Double.longBitsToDouble(0x3fe01154ac1ea0b6L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 13, 13, "\udba1\udc46\ud8c5\udd4c\ud887\udcbb\u0ec2\ud93d\udf96", "\uc84d\ub7c4\u24ad\u2234\u9e1a\u92c5\u419c", "\ud87f\ude76\u4444\ud83d\udc92\ud89d\uddc1\ud978\udd96\udb90\ude53\udbe5\udce2",
        32, 52238, -1872256337, -1762615856169593888L, -61938L, false, true, (char) 56614, (char) 14924,
        Double.longBitsToDouble(0x3fe099e03c8c6963L), Double.longBitsToDouble(0x3feb669b7e620d5aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 3, 13, "\udb7c\udda1\ud8c5\udd4c\ud887\udcbb\u0ec2\ud8bc\udf14", "\uc84d\u6baf\u4262\ub67a\u7be1\u1620\u567a\u6691\u271c\u8109", "\ud825\udc69\ud978\udd96\udb90\ude53\udbe5\udce2\udb38\udf8a\udb96\ude4c\ud980\udf84\udbbd\uddeb\ud915\udf40\ud986\udddb\udb48\udf21\ud9a4\udf2d\ud960\udcf6\uda4e\udc88",
        23, 76630, 1768133139, -3211202272227929236L, 82724L, true, false, (char) 31353, (char) 11281,
        Double.longBitsToDouble(0x3f9d1419b4b3b580L), Double.longBitsToDouble(0x3fe48d8d30792e7eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 13, 6, "\ud985\udd09\ud8c5\uddca\udaaf\ude45\ud971\uddef\ud93e\udc01", "\u37d4", "\ud851\udef1\ud91c\udca8\ud868\uddba",
        20, 32907, 34392302, 6505203831080061496L, 41154L, true, false, (char) 15328, (char) 55152,
        Double.longBitsToDouble(0x3fb5a934a89c7af8L), Double.longBitsToDouble(0x3fef064fe6388541L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 4, 4, 13, "\udb93\udc5a\ud8c5\udd4c\ud887\udcbb\ud940\udd27", "\u53de\ud123\ub7c4", "\ud86c\udc11\ud88f\udf06\ud901\ude93\udbcf\uddec\udac8\udc7f\udb31\udd34\ud9c6\uddf3\ud82f\udf4f",
        53, 88324, -1832974494, 1898181985229620971L, -55205L, false, false, (char) 7786, (char) 58843,
        Double.longBitsToDouble(0x3fe521fbb754d908L), Double.longBitsToDouble(0x3fc5cc33213a5790L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 2, "\uda9c\udd65\ud8c5\udd4c\ud887\udcbb\ud820\udc76\udb96\udc0a\ud97f\udff9\udbe4\udd0e\ud8d9\ude95\uda51\uddde\ud8b0\ude78\ud851\udf12", "\u2dc1\u734e\u3f41\ud6a3\u42a0\u4bb6", "\udac0\udc45\ud8f1\udc5f\udac6\udd27\udb86\udc89\udaf6\udced\udb14\udf79",
        52, 65614, -639422812, 7032918995919738030L, -80599L, false, false, (char) 393, (char) 59796,
        Double.longBitsToDouble(0x3fef7b51640e704eL), Double.longBitsToDouble(0x3fe5fc7dc677a76fL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udb83\udf2b\udb8c\udf92\uda95\udd89\ud89c\uddd7\udba2\udd00\udaa0\udfef", "\ub79e\u7c03\u81d9\u0c5e\u7131", "\ud961\udd6a\ud972\uddff\ud8fa\udd79\udad0\ude11\ud742\uda02\uddbc\udb3c\ude73",
        27, 34299, -1730061285, -8041369525892288968L, -13598L, true, true, (char) 15162, (char) 12487,
        Double.longBitsToDouble(0x3fd06426fafd655cL), Double.longBitsToDouble(0x3f9e327b4e83db60L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextTarEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|applyPaxHeadersToCurrentEntry|java.util.Map|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|available||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|canReadEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|close||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getCurrentEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getRecord||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getRecordSize||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|isAtEOF||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|matches|[B,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|parsePaxHeaders|java.io.Reader|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|paxHeaders||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|readGNUSparse||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|reset||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextTarEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
