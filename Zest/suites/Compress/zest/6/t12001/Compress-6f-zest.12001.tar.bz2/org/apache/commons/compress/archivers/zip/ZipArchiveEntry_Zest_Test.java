package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipArchiveEntry_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 18, 5, "\udb11\ude35\ud923\ude14", "\u63c3\u6ef5\u589a\u3390\ud1fa\u7a7d\u8b43", "\ud9b1\uddff\ud835\udc60\ud867\udfe1",
        22, 2430, 1732185009, 5034456987952074163L, -44000L, false, true, (char) 49964, (char) 200,
        Double.longBitsToDouble(0x3fdb6bfc66d17c02L), Double.longBitsToDouble(0x3fd6b46206642358L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 18, 5, "\udb11\ude35\ud89e\uddd1", "\u6c82\u6ef5\u589a\u3390\ud1fa\ub9cd\u4bc6", "\ud9b1\uddff\ud835\udc60\uda27\uddd0",
        22, 2430, 1732185009, 5034456988354727347L, -44000L, false, true, (char) 49964, (char) 200,
        Double.longBitsToDouble(0x3fdb6bfc66d17c02L), Double.longBitsToDouble(0x3fd6b46206642358L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 0, 0, 3, "\uda05\ude2f\ud923\ude14", "\u63c3\u10bc\u589a\u3390\ud1fa\ua213\u406f", "\ud9b1\uddff\ud835\udc60\ud867\udfe1",
        22, 2430, 1732185009, 5034456725959069107L, -71058L, false, false, (char) 12669, (char) 51561,
        Double.longBitsToDouble(0x3fd6b46206642358L), Double.longBitsToDouble(0x3fee39f29a3a7245L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 0, 12, 11, "\udb11\ude35\ud994\udf6d", "\u62e7\u6ef5\u589a\ub045\u7e0f\u90f2\u022a\u09cd\u5f53\u69c7", "\udae1\udc7f\ud9c9\udcb4\uda70\uddc6\uf813\udac4\udf77\ud80a\ude02\ud96a\uddfd\uda30\udc06\uda0a\udfe4\ud8e1\udcd6\udba7\udcdb\uda07\uddff\uda90\ude75\uda91\udf32",
        -2, 82943, -149775433, -4402633691853353251L, -11177L, true, true, (char) 41953, (char) 28284,
        Double.longBitsToDouble(0x3fe9a37eb40c0889L), Double.longBitsToDouble(0x3fbab338756a0528L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\udb11\ude35\ud923\ude14\012",
        Z.run(T, 2, 0, 1, 3, "\udb11\ude35\ud923\ude14", "\ubc12\u9741\u5fb6\ua198\ud1fa", "\uda17\ude45\udbea\udefe\ud89a\udd38\udb23\uddcc\ud825\udd87",
        22, 80438, 1040140183, -7405993845942530637L, -44112L, false, true, (char) 22409, (char) 27001,
        Double.longBitsToDouble(0x3fdb6d6e36d17c02L), Double.longBitsToDouble(0x3fd6b46206642358L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 0, 8, 5, "\uda3e\udeac\udaf1\udd5e", "\u63c3\u6ef5\ucad1\u3390\u1a46\ucb03\uc228\u9460\u0371\ua29f\u2b45\u9a1b", "\uda70\uddc6\uf813\udbc5\udcfb\uda4c\ude03\udbf5\ude7e\ud88c\udcec\ud873\udcba\udbef\udf7d\ud931\uddc3\udbba\udfaf\udb63\udee1\ud24e\udabb\udfcd\uf24e\ud93f\ude7a\uda11\ude7b\ud9b0\udd1f\udbc2\udc75\uda4f\udca7\ud849\udc69",
        16, 98168, 188466252, 7507270067281856373L, 11322L, false, false, (char) 50909, (char) 52765,
        Double.longBitsToDouble(0x3fdb6817512b1922L), Double.longBitsToDouble(0x3fa1ab5af4664ae0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 6, "\udb11\ude35\ud923\ude14", "\u63c3\u6ef5\u589a\u3390\ud1fa\u7a7d\u8b43", "\ud9b1\uddff\ud80c\udf60\ud867\udfe1",
        22, 2430, 1732185009, 5034456987952074163L, -44006L, false, true, (char) 49964, (char) 200,
        Double.longBitsToDouble(0x3fdb6bfc66d17c02L), Double.longBitsToDouble(0x3fd6b46206642358L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 18, 2, "\udb11\ude35\ud923\ude14", "\u3213\u6ef5\u589a\u3390\ua703\u1cb8\ud1e4", "\ud816\udd8d",
        20, 85052, -1619457374, -5547747278132933711L, 18195L, false, false, (char) 37121, (char) 37846,
        Double.longBitsToDouble(0x3fd0e521e1406050L), Double.longBitsToDouble(0x3fdb6bfc66d17c02L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 5, "\udb11\ude35\ud923\ude14", "\u63c3\u6ef5\u589a\u3390\ud1fa\u7a7d\u8b43", "\ud9b1\uddff\ud835\udc60\ud867\udfe1",
        22, 2430, 1728053425, 62482999335046400L, -100000L, false, true, (char) 49964, (char) 200,
        Double.longBitsToDouble(0x3fdb6bfc66d17c02L), Double.longBitsToDouble(0x3fd6b46206642358L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 5, 19, "\udb11\ude35\ud923\ude14", "\u43c3\u6ef5\u589a\u3390\ud1fa\u7a7d\u8b43", "\udbb1\ude85\udb38\udd5c\ud834\udfc5\ud907\udcc5\ud909\udc20\uda70\uddc6\uf813\udbc5\udcfb\ud80a\ude02\ud89d\udf52\udbae\udc10\uda0a\udfe4\ud823\udcd7",
        0, 56192, 296544619, -3291863932751256371L, 50765L, true, false, (char) 36998, (char) 28570,
        Double.longBitsToDouble(0x3fde87a2d4df3864L), Double.longBitsToDouble(0x3fd2e69330abbafcL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 11, 5, "\ud80a\ude52\udae7\ude80", "\u308b\u9704\u7e7c\u2017\ud1fa\u7a7d\u8b43\u5947\u5f53\u738e\u58e9\u55c2\u57c8\u15fe\u360f", "\ucc8c\ud873\udc81\udbae\udc10\uda0a\udfe4\ud9b2\udc7e\udbb4\udfb5\u81f5\udb52\uddb2\uda6b\udfcd\ud89a\udd79\ud8ba\udf3b\udba2\udea1\udb4e\udd64\uda03\udea8\uda99\uddd1\ud98e\udfe2",
        24, 43266, 233980106, 7802522622415883902L, -7567L, false, true, (char) 24885, (char) 37663,
        Double.longBitsToDouble(0x3fab96e2194aa0f0L), Double.longBitsToDouble(0x3fe02785f8f31b83L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 0, 12, 5, "\udb11\ude35\ud923\ude14", "\u6330\u6ef5", "\ud95b\udfc1\udad5\udc77\ud9f3\udccf\uda27\udc04\ud85d\udc7b\ud9b1\uddff\ud933\udecf\ud867\udfe2\udae1\udc7f\ud9c9\udcb4\uda70\uddc6\uf813\udb67\udcec",
        21, 53816, 1377762106, 3470147816754958496L, -90783L, true, true, (char) 61575, (char) 13429,
        Double.longBitsToDouble(0x3fe237c671cf84b3L), Double.longBitsToDouble(0x3fe315e498b8faefL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 18, 5, "\ud828\udfe7\ud923\ude50", "\u63c3\u6ef5\u589a\u3390\ud1fa\u7a7d\u8b43", "\ud9b1\uddff\ud835\udc60\ud867\udfe1\u6c3c\ud8e6\ude3e\ud826\udc54\ud968\udfcd\udb99\udf56\ud80a\ude02\ud89d\udf52\ud802\udd3a\ud9f7\ude87\ud823\udcd7\ud955\uddd2\udbc7\udf89\uda90\ude75\udaf6\udccd\ud910\udcaa",
        19, 79363, 713609316, -8348883712208989446L, 49031L, false, false, (char) 5418, (char) 63582,
        Double.longBitsToDouble(0x3fcb0080662dec00L), Double.longBitsToDouble(0x3fea89bf1cdde434L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 15, 15, 17, "\udbe4\uddbe\ud8e7\udccf", "\u3dc8\u8b44\u589a\u3399\ud1fa\u7a7d\u4606\u5947\u0c42\ub32c\u1ca5\u00e7\u583b\u15fe\u360f\u7ec3\u6f51\u3e25\u66ae\u4d40\ua221\uac81\u4b4e\u9305\u3bd3\u2bd0\u94c4\u6693\uc783\u1cbe\u8a70\ud062\u13c9\u9775", "\udb85\uddaa\udb0e\udc4f\udaa9\udd0a",
        22, 19620, 1165714963, 4234983034737827351L, 36551L, false, false, (char) 12189, (char) 62531,
        Double.longBitsToDouble(0x3fc0fb9f489fa874L), Double.longBitsToDouble(0x3fe2ec7a7c2dabf0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 0, 11, 5, "\udb11\ude35\ud923\ude14", "\u63c3\ub8e9\uaf24\u26c9\u0ffd\ud7fd\u0fad", "\ud9b1\uddff\ud835\udc60\ud867\udfe1\udae1\udc7f\udaff\udeef\uda70\uddc6\uf813\udbc5\udcfb\ud80a\ude02\udb6d\uddba",
        1, 56750, -1077489504, -4755394706924589720L, -4310L, true, true, (char) 19097, (char) 60141,
        Double.longBitsToDouble(0x3fe9883b4561014cL), Double.longBitsToDouble(0x3faf867d7bee79c0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 20, 20, 1, "\udb11\ude35\ud923\ude14", "\u63c3\u6ef5\ud24f\u3390\ud1fa\u7a7d\u8b43", "\ud9b1\uddff\uec82",
        44, 76512, -1444449986, 7439677965448641525L, 31042L, false, false, (char) 18634, (char) 49964,
        Double.longBitsToDouble(0x3fc4060506daff18L), Double.longBitsToDouble(0x3feb45f0096b4620L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\udb11\ude35\ud923\ude14\ud9f9\udc82\ud9bb\udc6b\udae1\ude83\udb4d\udc41\udaa9\udff0\udb47\udca7\ud95b\udfc1\udb97\udd19\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 5, 5, "\udb11\ude35\ud923\ude14\ud9f9\udc82\ud9bb\udc6b\udae1\ude83\udb4d\udc41\udaa9\udff0\udb47\udca7\ud95b\udfc1\udb97\udd19", "\u5f53\u69c7", "\udae1\udc7f\ud9c9\udcb4\udb2f\uddfc\udb2d\udf5a\udbc5\udcbf\ud80a\ude02",
        6, 20106, 807956750, -4627782182570462794L, -40245L, true, false, (char) 37803, (char) 20995,
        Double.longBitsToDouble(0x3fe1f8615786dc0fL), Double.longBitsToDouble(0x3faae5b2bf983c20L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 8, 9, 3, "\uda05\ude2f\ud923\ude14", "\u63c3\u10bc\u589a\ucf48\ud1fa\ua213\u406f", "\ud9b1\uddff\ud835\udc60\ud867\udfe1",
        22, 2430, 1732185009, 5034456725757742515L, 99724L, false, false, (char) 12669, (char) 51561,
        Double.longBitsToDouble(0x3fd6b46206642358L), Double.longBitsToDouble(0x3fee39f29a3a7245L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 11, 11, 16, "\ud858\udf38\ud86c\uddc9", "\u62e7\u6ef5\u589a\ub045\u7e0f\u90f2\u3687\u2e1f\u3067\u6301\u7523\u55c2\u57c8\ub3d7\u57c1\u7ec3\u1556\uc572\u03d1\u855a\ua221\u2c71", "\uda90\ude75\uda91\udf32",
        -2, 15223, -135502180, -3754115346392894657L, -11177L, true, true, (char) 41953, (char) 28284,
        Double.longBitsToDouble(0x3fe9a37eb40c0889L), Double.longBitsToDouble(0x3fbab338756a0528L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 8, 8, 11, "\udbea\udff0\ud994\udf6d", "\u62e7\u6ef5\u589a\ub045\u7e0f\u6a33\u01d0\u57c3\u5f40\u69c7", "\udae1\udc7f\ud9c9\udcb4\uda70\uddc6\uf813\udac4\udf77\uc00b\ud96a\uddfd\uda30\udc06\uda0a\udfe4\ud8e1\udcd6\udba7\udcdb\uda07\uddff\ud8b6\ude76\ud968\udc7f",
        -2, 26807, -146555925, -4402633691853353251L, -11177L, true, true, (char) 41953, (char) 28284,
        Double.longBitsToDouble(0x3fe9a37eb40c0889L), Double.longBitsToDouble(0x3fbab338756a0528L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 1, 4, 1, 3, "\udb11\uddc6\ud923\ude14", "\ubc12\u9741\u5fb6\ua198\ud1fa", "\uda34\ude34\udbea\udefe\ud89a\udd38\udb23\uddcc\ud825\udd87\udae1\udc7f\ud9a4\udcc2\ud922\udf3e\ud98a\uddc7\udbc5\udcfb\ud80a\ude02\ud89d\udee2",
        23, 44562, -689744747, -4755394703852041368L, -37742L, false, false, (char) 2411, (char) 10860,
        Double.longBitsToDouble(0x3fe3cb1261e8c994L), Double.longBitsToDouble(0x3feeb1aa3b3a6198L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 9, 2, "\udb11\ude35\ud923\ude14", "\u3213\u6ef5\u589a\u3390\ua703\u13de\ud1e4", "\ud816\udd8d",
        20, 85052, 263772578, -5547747432751756367L, 18195L, false, true, (char) 37200, (char) 37846,
        Double.longBitsToDouble(0x3fd0e521e1406050L), Double.longBitsToDouble(0x3fdb6bfc66d17c02L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 7, 5, "\ud9ba\udd12\ud934\udd8d\ud933\udc7f\ud9bb\udc6b\udae1\ude83\udb4d\udc41\ud958\ude48\uda10\udede\ud95b\udfc1\udbc4\udfef\udbf9\udc7a\uda27\udc8c\ud98e\udef1\uda1b\udf82\ud835\udc60\udb17\udc39\ud802\udcf1\ud9eb\udd5f\udbbf\udec0\ud97c\udc12", "\u3820\u1192\u3ca0\u1a0c", "\uda90\ude75\uda14\udcc6\ud99e\udd74\ud999\udf08\uda7c\udc0c\ud82e\udf28\ufc42",
        -3, 30933, -1992915936, -6916650150401653047L, 49645L, false, false, (char) 36359, (char) 30510,
        Double.longBitsToDouble(0x3fcaa951ff9e6464L), Double.longBitsToDouble(0x3fc3c3859be14490L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|equals|java.lang.Object|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|java.lang.String",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|java.util.zip.ZipEntry",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|org.apache.commons.compress.archivers.zip.ZipArchiveEntry",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|java.io.File,java.lang.String",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|addAsFirstExtraField|org.apache.commons.compress.archivers.zip.ZipExtraField|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|addExtraField|org.apache.commons.compress.archivers.zip.ZipExtraField|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|clone||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getCentralDirectoryExtra||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExternalAttributes||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraField|org.apache.commons.compress.archivers.zip.ZipShort|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraFields||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getInternalAttributes||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getLastModifiedDate||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getLocalFileDataExtra||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|equals|java.lang.Object|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|java.lang.String",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|java.util.zip.ZipEntry",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|org.apache.commons.compress.archivers.zip.ZipArchiveEntry",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|<init>|java.io.File,java.lang.String",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
