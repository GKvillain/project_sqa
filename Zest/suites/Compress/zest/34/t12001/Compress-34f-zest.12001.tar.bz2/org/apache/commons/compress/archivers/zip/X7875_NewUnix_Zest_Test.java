package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class X7875_NewUnix_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, 16, -126, 21, -22, 53, -84, 123]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=5840539158917869954 GID=1000\012",
        Z.run(T, 2, 10, 14, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\u93aa\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, -1684111425, 5840539158917869954L, -55746L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61f32915f4L), Double.longBitsToDouble(0x3fe8562039d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, 16, -126, 21, 8, 53, -84, 123]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=5840539158917869954 GID=1000\012",
        Z.run(T, 2, 10, 14, 12, "\ud92d\udc40\udab2\udc45\ud938\ude65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\u93aa\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udba2\udcba\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, -1684111425, 5840539158917869954L, -55746L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61f32915f4L), Double.longBitsToDouble(0x3fe8562039d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, 16, -126, 21, -22, 53, -84, 123]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\ud8ac\udd88\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\u93aa\u1d92\ua1f4\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\uc510\uad8f\ubf1f\u8e65\ubb41\u7945", "\ud8ba\udef9\ud983\udfe8\ud8f6\udde1\udaf1\udfb7",
        19, 2805, -568128646, -2743362585209443563L, -1631L, false, true, (char) 17039, (char) 3049,
        Double.longBitsToDouble(0x3fd9b534cb6a70deL), Double.longBitsToDouble(0x3fe91681975c1afbL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 12, "\u0684\udab2\udc45\ud91a\udf65\udbdc\udfab\udaa3\udf84\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\uda6b\udee2\ud984\ude93\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\ufb52\uda97\udd6e\u9d87\ud895\udc26", "\ucc8c\u2539\u44a1\u3a59\uc414\u93aa\uc4ba\ua6be\u1789\ub3f3\u1bb8\uc188\u2306\uc13b\u233b\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udba3\uddfd\ud984\udc02\udbbc\udd3a\udaee\ude75\ud832\udccd\uc16a",
        14, 17044, -150661301, -7283771337964733166L, 29342L, false, true, (char) 51921, (char) 34340,
        Double.longBitsToDouble(0x3fe91681928d1afbL), Double.longBitsToDouble(0x3fdc8c40327335c6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, 16, 11, 8, 63, -42, -115, 110]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=[B:[[1, 2, -24, 3, 2, -24, 3]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 10, 6, 6, "\ud92d\udc40\ud93b\udd38\udb6f\udd06\udabd\udd9e\uda54\udd16\udbeb\udc58\ud96a\udd82\ud935\udc24\uda15\udd9b\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\ud9f9\udcd6\ud8e8\udcf1\udb4e\udf71\ufbea\u719d\ud895\udc26", "\u8ff9\u531e\u44a1\u291d\uc414\u93aa\u684b\ud55e\u9153\u8913\u06b6\uabd9\u3284\u2c7d\u67e0\ub7bf\u457e\ua6ad\ubf1f\u76b5\u4d3f\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\ud8b1\udfa9\ud846\udd09\udb00\udc10",
        48, 77634, -1684111425, 5841460549661946242L, -73832L, false, true, (char) 54219, (char) 50318,
        Double.longBitsToDouble(0x3fe8562039d8d9baL), Double.longBitsToDouble(0x3fe28e41dad65108L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[B:[[1, 2, -24, 3, 2, -24, 3]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=5840539158917869954 GID=1000\012",
        Z.run(T, 2, 6, 14, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\udaec\udd85\udb9b\udef9\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\udadd\udf95\udbda\udd8b\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\ucfb2\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\ud90a\udd4e\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, -1684111425, 5840539158917869954L, -55746L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61f32915f4L), Double.longBitsToDouble(0x3fe8562039d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=[B:[[-6, -45]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 12, "\ud92a\udc03", "\u053c\u51fd\u1f88\uca0e\u2d7e\u63a8\ub63d\u160f\uc872\u061c\uadf0\u6ab3\u43a2\u7019\u9b06\ub15f\u3fb9", "\ud988\udd4f\ud9a9\udf48\uda7e\udc70\udb41\udf7f\uda15\udecd\ud8c2\udd4e",
        34, 119, 409298633, -2000508389637315216L, 24078L, false, false, (char) 47562, (char) 19438,
        Double.longBitsToDouble(0x3fb332f19c9c8160L), Double.longBitsToDouble(0x3fb8215a0e2d9dc0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 1, 12, 12, "\ud9f0\udfe3\ud957\ude55\ud9c0\udcbc\udba8\udcc2\udb5e\udefe\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\udde6\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26\u3608\ud939\udda1", "\u44a1\u291d\uc414\u93aa\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447\u0b8c", "\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd",
        15, 86938, -649948860, -9043673264187499398L, 46580L, false, true, (char) 31248, (char) 49852,
        Double.longBitsToDouble(0x3fdb5386fd3fa064L), Double.longBitsToDouble(0x3fe7398ef1c8c403L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 0, 0, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052", "\udb41\udf7f\uda15\udecd\ud8c2\udd4e\ud866\udc51\uda4f\udcb0\uda02\uddbd\ud846\udeb8\ud917\udd86",
        12, -1000, 1545489422, 59387559897653252L, -14275L, true, true, (char) 5479, (char) 20444,
        Double.longBitsToDouble(0x3fd0e8da54875154L), Double.longBitsToDouble(0x3fbc7e614209bcc0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |a0=[B:[[-12, -41]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=5269357795847203981\012",
        Z.run(T, 2, 10, 13, 12, "\ud924\udd07", "\u061e\u51fd\u1f88", "\ud9f3\udef5\ud9ed\udd43\ud9e6\udd8f\ud977\ude9f\ud97c\ude3d\ud823\udccf\udbff\udc7f\ud93a\udc7a\udb0c\udf70\ud9a4\udefc\u9d87\ud895\udc26\u3608\ud939\udda1\ud988\udd4f\ud9a9\udf48",
        24, 65930, -40536334, 5269357795847203981L, -7236L, true, false, (char) 21495, (char) 12892,
        Double.longBitsToDouble(0x3fbe80ece0738790L), Double.longBitsToDouble(0x3fc58b83c011bb48L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, -23, -126, 21]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 12, "\ud92d\udc19\udab2\udc45", "\u51fd\u1f88\u1d51\u2cf1\u63a8\u2e85\u541a", "\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26\u3608",
        21, 97376, -1372898277, -1267409828458063486L, 42095L, true, false, (char) 54976, (char) 35244,
        Double.longBitsToDouble(0x3fe0300bd0eae65aL), Double.longBitsToDouble(0x3f8ce1e42b170780L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, 16, -126, 21, -22, 53, -84, 123]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |a0=[B:[[-3, 16, -126, 21, -22, 53, -84, 123]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 10, 10, 2, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\ud8e6\udd0f\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\uda3a\udf67\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\u93aa\u684b\u7bdd\ua653\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, -1684111425, 5840539158917869954L, -55746L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61ff2915f4L), Double.longBitsToDouble(0x3fe8562039d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 2, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udb30\ude7c\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\udaca\uddc4\ud9b0\udece\udbc7\udd83\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud846\udf40", "\u9052\u7e15\u54d5\u291d\u7f14\u93aa\u684b\u7bdd\u9153\ua372\u1706\u969c\u066a\uc13b\u6805\u060e\uc0ab\u8d88\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udfbc\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\uc16a\udbdc\udd86\udbaf\udce7\uda0e\udfaf\udbe0\udf06\uda4a\uddd4\udb40\udc32\udba8\udf52\udaac\udcc2\ud1f0\udb30\udee3\ud805\udcb9\u6f04\uda3a\udfd2\udbf6\udef4\ud9f9\udee6\ud8bd\ude0b\uda61\udcc8",
        -3, 19, -1709633176, -4901934510956215964L, -85440L, false, false, (char) 13075, (char) 61691,
        Double.longBitsToDouble(0x3feca9499e17e46eL), Double.longBitsToDouble(0x3fe2da00e37326b0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Long:1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 8, 10, 12, "\ud915\udf40\udab2\udc45\udbbd\udfc3\udbdd\udc32\udb31\udc52\ud9ef\ude93\udbd9\udf1b\u55d3\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\uda4e\ude3e\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb07\udecd\ud9d1\udd57\u9d87\ud895\udc26", "\u9052\u531e\u87d9\u2b6c\uc414\u93aa\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\u4eb5\u9b9b\uc979\u6a2e\u1447", "\udb0b\udff7\ud983\udfe8\uda85\udd88\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, 1419673535, 5838978840248906114L, -91074L, true, true, (char) 9172, (char) 54663,
        Double.longBitsToDouble(0x3fdc8c40371535c6L), Double.longBitsToDouble(0x3fdacf61f32915f4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, 16, -126, 21, -22, 53, -84, 123]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 7 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 10, 7, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud975\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\u93aa\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\u9cfb\ub8d6\u8faa\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, -1684111425, 5840539158917869954L, -55746L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61f32915f4L), Double.longBitsToDouble(0x3fe8562039d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 1, 4, 14, 9, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u80a1\u291d\uc414\u93aa\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\u7bb8\u6784\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        14, 77634, -1684111425, 5840539158917869954L, -55746L, true, false, (char) 34251, (char) 57342,
        Double.longBitsToDouble(0x3fdaceb6d32915f4L), Double.longBitsToDouble(0x3fe2762039d8d7acL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, 16, -126, 21, -22, 53, -84, 123]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=3825205248 GID=1000\012",
        Z.run(T, 2, 10, 14, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud8f0\udf58\uad15\udbda\udd7f\ud93a\udc7a\udb48\udf64\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e", "\uda15\udecd\ud8c2\udd4e\ud866\udc51\uda4f\udcb0\uda02\uddbd\ud846\udeb8\ud917\udd86\ud807\udc83\u1792",
        55, 10832, 13033476, -469762048L, -14275L, true, true, (char) 5479, (char) 20444,
        Double.longBitsToDouble(0x3fd0e8da54875154L), Double.longBitsToDouble(0x3ec0a104de600000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=5840539158917869954 GID=1000\012",
        Z.run(T, 2, 2, 14, 11, "\ud92d\udc40\ud9d8\uded9\ud91b\udc26\ud847\udc40\udb31\udc52\uda67\udd34\ud8f0\udc5b\udb56\udd07\ud9f3\udef5\ud971\udd85\ud94d\ude30\udba4\ude81\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\u8268\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u53a4\u44a1\u291d\u2f1d\u4e0f\u684b\u242e\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udb38\udcf7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udcc8\udbff\udcd0\ud959\udcf2\ud9e0\udcb7",
        18, 61674, -1678336509, 5840539158917869954L, 2796L, true, true, (char) 9045, (char) 54663,
        Double.longBitsToDouble(0x3fdc8c40371535c6L), Double.longBitsToDouble(0x3fdacf61f32915f4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, 16, -126, 21, -22, 53, -111, 104]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 11, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\ud8c1\udf98\udbf2\udc20\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43", "\u06a3\uadf0\u6ab3\u43a2\u436a\u50f8\u4c1e\uab15\u9e62\u5123\u9052\u531e\u44a1\ucf19\uc414\uc6ae\u684a\u1d58\u3594\u46b5\ua730", "\udaf0\udd7b\udbd0\udf33\ud851\udcf0\udaf1\udd11\ud883\udd59\udb57\udf96\udb29\udd7b\ud917\udc8b\ud91f\ude1c",
        26, 85549, -1918558539, -6293150399066676669L, -7775L, true, true, (char) 2210, (char) 31847,
        Double.longBitsToDouble(0x3fe8aecf6c7a827eL), Double.longBitsToDouble(0x3fedff3b436c9b9eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=5840539158917869954 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=5840539158917869954 GID=1000\012",
        Z.run(T, 2, 14, 14, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\udae6\udf60\ud950\udd65\udaa8\uddf8\ud981\udcef\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\u93aa\u684b\u0311\u90d8\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\ua6ad\ubf1f\u7ebd\u1c59\ua111", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, -1684111425, 5840539158917869954L, -78388L, true, true, (char) 9045, (char) 54663,
        Double.longBitsToDouble(0x3fdc8c40371535c6L), Double.longBitsToDouble(0x3fdacf61f32915f4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Long:1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=java.lang.Long:1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 4, 8, 14, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\u93aa\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udff7\ud821\udd62\ud8f6\udde9\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, -1684111425, 5840539158917869954L, -55746L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61f32915f4L), Double.longBitsToDouble(0x3fe8562039d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=8751597501182782629 GID=1000\012",
        Z.run(T, 2, 2, 14, 12, "\ud92d\udc40\udab2\udc45\ud97f\udd18", "\u1f88\u1d51\u2cf1\u63a8\u2e85\u541a\uc872\u061c\uadf0\u9ccc\ud06d\u436a", "\ud895\udc26\u79ad\ud9a9\ude15\ud988\udceb\ud9a9\udf48\uda7e\udc70\uda60\udc75\ud8a7\udd36",
        47, 99477, -508679409, 8751597501182782629L, 42854L, false, false, (char) 48384, (char) 22730,
        Double.longBitsToDouble(0x3f71bb4a3de5e300L), Double.longBitsToDouble(0x3fe3bc39f4a3e4c4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 1, 10, 14, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\udb2d\udc9b\ud94f\udee6\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e\u44a1\u291d\uc414\000\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\ub21e\u7cc4\000\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\ua7d5\ud846\udd7b\uda6b\udc05",
        48, 28890, 0, 0L, -55746L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61f32915f4L), Double.longBitsToDouble(0x3fe8562039d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 14, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udaf7\udd52\ud9ef\ude93\udaa2\udce1\udb56\udd01\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a", "\uadf0\u5b59\u60ac\u436a\u1cf9\u4c1e\uab15\u9e62", "\ud9a9\udf48\uda7e\udc70\udb41\udf7f\uda15\udecd\ud8c2\udd4e\udb7d\ude92\udb21\udd27\uda02\uddbd\ud846\udeb8\udba9\uddef\ud834\udc07",
        1, 87422, 1859321004, -3763074129356516229L, 46396L, false, false, (char) 2899, (char) 64784,
        Double.longBitsToDouble(0x3fd65cca6877ca4eL), Double.longBitsToDouble(0x3fdb53127a1d1b7aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 13, 12, "\uda3f\udeff\ud984\udf47\udbd1\udf87\ud999\udf39\ud8ca\udede\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud90d\ude22\udb4f\udcd1", "\ua81b\uadf0\u035a", "\ud9a4\udefc\u9d87\ud895\udc26\ueb7d\ud939\udda1",
        56, 94723, -295091846, -2455841125704567054L, -72211L, true, false, (char) 58275, (char) 54976,
        Double.longBitsToDouble(0x3fd70e43cc0c02f4L), Double.longBitsToDouble(0x3fcd5ccb5039c3c8L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |a0=[B:[[-9]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 0, "\ue627", "", "\u21e0",
        -5, 43472, 1976711172, -943259991655227116L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fe859f11870a268L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 10, 2, 7, "\u0684\udab2\udc45\ud91a\udf65\udbdc\udfab\udaa3\udf84\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\uda6b\udee2\ud984\ude93\ud97c\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\ufb36\uda97\udd6e\u9d87\ud895\udc26", "\ucc8c\u2539\u44a1\u3a59\uc414\u93aa\uc4ba\ua6be\u1789\ub3f3\u1bb8\uc188\u2306\uc13b\u233b\ub21e\u776e\ua6ad\ubf1f\u7ebd\ub841\u1447", "\udba3\uddfd\ud984\udc02\udbbc\udd3a\udaee\ude75\ud88a\udc58\uda8a\udf0b",
        6, 78576, -150661301, -7283771337964733166L, 29342L, false, true, (char) 51921, (char) 34340,
        Double.longBitsToDouble(0x3fe91681928d1afbL), Double.longBitsToDouble(0x3fdc8c40327335c6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 11, 12, "\u0684\udab2\udc45\ud91a\udf65\udbdc\udfab\udaa3\udf84\ud9ef\ude93\udaa2\udce1\udbd4\udf26\udbfd\udc3a\ud9cd\udf55\uda6b\udee2\udb70\ude89\ud958\udec6\ud823\udccf\udbda\udd7f\ud933\udf4a\ufb52\uda97\udd6e\u9d87\ud895\udc26", "\ucc8c\u2539\u44a1\u3a59\uc414\u93aa\uc4ba\ua6be\u1789\u0fa3\u1b61\uc188\ub26e\u334a\u8ecd\ub2bb\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udba3\uddfd\uda36\udd7b\udbbc\udcb1\udaee\ude75\ud832\udccd\uc16a",
        14, 17044, -150661301, -7283771337964733166L, 29342L, false, true, (char) 51921, (char) 34340,
        Double.longBitsToDouble(0x3fe91681928d1afbL), Double.longBitsToDouble(0x3fdc8c40327335c6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Long:1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=java.lang.Long:1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 8, 8, 12, "\u0684\udab2\udc45\ud91a\udf65\udbdc\udfab\udaa3\udf84\udaa2\udc0c\udaa2\udce1\ud879\uddd9\uda03\udfe6\ud9ed\udd43\uda6b\udee2\ud814\ude80\udbd4\udd2a\udb46\ude3b\uda71\udd55\ud934\udf83\ufb52\uda97\udd6e\ud95a\udf1f\ud895\udc41", "\ucc8c\ucd39\uc1e6\ua71b\u1fac\u0883\u060b\ua6be\u1789\ub3f3\u1bb8\uc188\u2306\u63e6\u233b\ub21e\u776e\ua6ad\ubf1f\u7ebd\ubb41\u1447", "\udba5\udc58\ud9af\udfe4\ud8c8\udde2\udbc1\udda9\ud832\udccd\uc16a\ud846\udd7b\u4318\ud9f7\udec3\u2a9a\u5765\ud97b\udc36",
        41, 78338, 946833798, -3444605324747910366L, -73832L, true, true, (char) 42023, (char) 1970,
        Double.longBitsToDouble(0x3fe8bc1ae246a08bL), Double.longBitsToDouble(0x3fd37a4dcc232340L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 7 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=[B:[[1, 2, -24, 3, 2, -24, 3]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 7, 6, 6, "\ud92d\udc40\ud93b\udd38\udb6f\udd06\udabd\udd9e\uda54\udd16\udbeb\udc58\ud96a\udd82\ud935\udc24\uda15\udd9b\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\ud9f9\udcd6\ud8e8\udcf1\udb4e\udf71\ufbea\u719d\ud895\udc26", "\u8ff9\u1e15\u2792\u291d\uc414\u93aa\u684b\ud55e\u9153\u8913\u06b6\uabd9\u29b7\u2c7d\u67e0\ub7bf\u457e\ua6ad\ubf1f\u76b5\u4d3f\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\ud8b1\udfa9\ud846\udd09\udb00\udc10\uda0e\udfaf\udbe0\udf06",
        25, 4020, -1475415678, 6813211600182284692L, -73832L, false, true, (char) 54219, (char) 50318,
        Double.longBitsToDouble(0x3fe856203ad8d9baL), Double.longBitsToDouble(0x3fe28e442ad65108L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=5841460549661946242\0121=[B:[[1, 2, -24, 3, 8, -126, -15, 14, -88, 107, 9, 17, 81]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=5841460549661946242\012",
        Z.run(T, 2, 13, 6, 6, "\ud92d\udc40\ud93b\udd38\udb6f\udd06\udabd\udd9e\uda54\udd16\udbeb\udc58\ud96a\udd82\ud935\udc24\uda15\udd9b\udbec\ude23\ud9e6\udd3a\ud98f\udf7d\ud97c\ude3d\ud823\udccf\ud9f9\udcd6\ud8e8\udcf1\udb4e\udf71\ufbea\u719d\ud895\udc26", "\u3440\u6589\u55cb\uaf7b\uc414\u93aa\u684b\ud55e\u9153\u8913\u06b6\uabd9\u3284\u400b\u3345\u4287\u457e\ua6ad\ubf1f\u76b5\u4d3f\u1447", "\udb0b\udff7\ud983\udfe8\ud9cd\uddcd\udaf1\udfa9\ud832\udccd\ud8b1\udfa9\ud846\udd09\udb00\udc10",
        48, 77634, -1684111425, 5841460549661946242L, -73832L, false, true, (char) 54219, (char) 50318,
        Double.longBitsToDouble(0x3fe8562039d8d9baL), Double.longBitsToDouble(0x3fe28e41dad65108L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 9, 6, "\ud92d\udc40\udb81\ude7b\ud9fd\udc1e\udabd\udd9e\uda54\udd16\udbeb\udc58\ud952\ude82\ud82b\udc27\ud9f4\udfec\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\udb4a\udde8\ud8fb\udfb5\udbce\udec4\udb4e\udf71\ufbea\u719d\ud895\udc26", "\u8ff9\u531e\u44a1\u47c7\u848c\u102f\u684b\ud55e\u9153\u8913\u06b6\uabd9\u3284\u2c7d\u67e0\ub7bf\u1fb1\ua64f\uc2eb\u310d\u4d29\u1447", "\udb0b\udff7\ud983\udfe8\udbeb\udff6\udaf1\udfb7\ud832\udccd\ud8b1\udfa9\ud846\udd09\udb00\udc10",
        2, 70578, -1995212253, -1457650100313871152L, -73832L, false, true, (char) 54219, (char) 50318,
        Double.longBitsToDouble(0x3feaf6203e20372fL), Double.longBitsToDouble(0x3fe288b182d65108L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=[B:[[1, 2, -24, 3, 2, -24, 3]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=[B:[[1, 2, -24, 3, 2, -24, 3]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 6, 6, 6, "\ud92d\udc40\ud93b\udd38\udb6f\udd06\udabd\udd9e\uda54\udd16\udbeb\udc58\ud96a\udd82\ud935\udc24\uda15\udd9b\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud97c\ude3d\ud823\udccf\ud9f9\udcd6\ud8e8\udcf1\udb4e\udf71\ufbea\u719d\ud895\udc26", "\u8ff9\u531e\u44a1\u291d\uc414\u93aa\u684b\ud55e\u9153\u8913\u06b6\uabd9\u3284\u2c7d\u67e0\ub7bf\u50a2\uac91\ubea3\u76b5\u4d3f\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\ud8b1\udfa9\ud846\udd09\udb00\udc10",
        48, 77634, -1684111425, 5841460549661946242L, 11447L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61f32915f4L), Double.longBitsToDouble(0x3fe8562039d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 7 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 7 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 7, 7, 15, "\ud83a\ude72\ud9fe\udc09\udb6f\udd06\udabd\udd9e\udaa2\udca0\udb57\udc75\ud96a\udd82\ud935\udc24\ud899\udee2\ud9bf\ude25\ud9e6\udd3a\ud8e2\udcd6\ud821\uddf0\ud920\udcbd\ud9f9\udcd6\ud8e8\udcf1\udb4e\udf71\udb25\uddf4\u71c8\ud895\udc26", "\ua532", "\udbb0\udcfb\uda5d\udd16\ud8c2\udd4e\u1181\udb93\ude84\ud92c\udfd1\ud80f\udf29",
        2, 51813, 1890825457, -2954277732404245742L, 53284L, false, true, (char) 22693, (char) 54849,
        Double.longBitsToDouble(0x3fe74c1a3123d0dbL), Double.longBitsToDouble(0x3fb9d7ae19af5188L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1994579028279388764\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1994579028279388764\012",
        Z.run(T, 2, 13, 13, 12, "\ud924\udd07", "\u061e\u51fd\ub83d", "\ud9f3\udef5\ud9ed\udd43\ud9e6\udd8f\ud977\ude9f\ud97c\ude3d\ud902\udd60\udbff\udc59\ud93a\udc7a\udb0c\udf70\ud9a4\udefc\u9d87\ud895\udc26\u3608\ud939\udda1\ud988\udd4f\ud9a9\udf48\uda7e\udc70\udb41\udf7f",
        1, 19967, 1072196749, 1994579028279388764L, -41603L, true, false, (char) 54316, (char) 48384,
        Double.longBitsToDouble(0x3fc58b83c011bb48L), Double.longBitsToDouble(0x3fc18db4caa11a28L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |a0=[B:[[127, -110]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 11, 12, "\udbaf\udcc2", "\u45e6\ubd3f\u9854", "\u5363\ud982\udd8e\udae9\ude1f\ud977\ude9f\ud97c\ude3d\ud823\udccf",
        1, 69702, -1312483271, 4477492078681047819L, -98687L, true, true, (char) 1636, (char) 28589,
        Double.longBitsToDouble(0x3fd7aae2bce3578aL), Double.longBitsToDouble(0x3fe707907cfffd95L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 2, 2, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\uda8e\udfa4\udb31\udc52\ud9ef\ude93\udaa2\udce1\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ud9e6\udd3a\ud977\ude60\ud975\ude3d\ud823\udccf\udbda\udd7f\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26", "\u69f6\u685a\u44ed\u291d\uc414\u93aa\u684b\u7bdd\u9153\ua372\ua730\u1fa0\u06c8\uc13b\u6805\u9cfb\ub8d6\u8faa\ubf1f\u7ebd\ubb41\u1447", "\udb0b\udff7\ud983\udfe8\ud8f6\udde1\udaf1\udfb7\ud832\udccd\uc16a\ud846\udd7b\uda6b\udc05",
        48, 77634, -1690029377, 5840539158917869954L, -55746L, true, false, (char) 24011, (char) 7789,
        Double.longBitsToDouble(0x3fdacf61f1270bf4L), Double.longBitsToDouble(0x3fed1b9ac9d8d9baL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=3825205248 GID=1000\0121=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=3825205248 GID=1000\012",
        Z.run(T, 2, 14, 14, 12, "\ud92d\udc40\udab2\udc45\ud91a\udf65\udbdc\udfab\udb31\udc52\ud9ef\ude93\ucede\udb56\udd07\ud9f3\udef5\ud9ed\udd43\ub13e\ud977\ude60\ud8f0\udf58\uad15\udb57\udc93\ud928\udc4e\udb48\udf64\ud9a4\udefc\u9d87\ud895\udc26", "\u9052\u531e", "\uda15\udecd\ud8c2\udd4e\ud866\udc51\uda4f\udcb0\uda02\uddbd\uda86\udfbc\ud917\udd86\udad6\udeeb\udb80\udff6",
        55, 65864, 3772458, -469762048L, -14275L, true, false, (char) 7047, (char) 20444,
        Double.longBitsToDouble(0x3fd0e8da54875154L), Double.longBitsToDouble(0x3ec0a104de600000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |a0=[B:[[126, 15, 75, -114, 33, -53]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 11, 15, "\udbae\udd3f\uda7b\uddbe\ud951\udefb", "\u7608\uc682\u2cf1\u63a8\u2e85\u2382\u33f3\u3374\uadf0\u6ab3\u43a2\u436a\u50f8\u4c1e\u9d73\u312c\u448f\u9052\u531e\u44a1\ucf19\uc414\u1976\u686d\u1d58\u3594\u46b5\u1f05\u1aa1\u06c8\u0f3c\u9f75\ub21e\u51cd\u2578", "\ud917\udc45\ud91f\ude1c\udbf1\udc1b\ud93c\ude13",
        0, 68742, -108666301, 4011651120804489281L, -37402L, false, false, (char) 26649, (char) 27831,
        Double.longBitsToDouble(0x3fe6eb56c3791934L), Double.longBitsToDouble(0x3fdf29747787bdc8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |a0=[B:[[61, -45, -126, 109, -41, -116, 95, 57]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 11, 11, "\ud86d\udd03\udab2\udc9d\uda07\udcbc\uda8f\udc69\udbf2\udc20\ud9ef\ude93\udaa2\udce1\udb67\ude13\ud9f3\udef5", "\u3ee1\u06a3\uadf0", "\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26\u3608\ud939\udda1\ud988\udd4f\ud9a9\udf48\uda7e\udc70\ud949\udca9\uda15\udecd\uda3c\udf7b\ud866\udc50\uda55\udd34\ud8bd\uddb1\ud865\uddfa\ud917\udd86\ud807\udc83",
        1, 87422, -748463402, -3763074132946840453L, 58813L, false, false, (char) 13341, (char) 28857,
        Double.longBitsToDouble(0x3fd65cca666bd462L), Double.longBitsToDouble(0x3fe5a9893d6a4aecL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Long:1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=java.lang.Long:1000 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\012",
        Z.run(T, 2, 4, 4, 15, "\udbae\udd3f\uda7b\uddbe\ud951\udefb\ud8c1\udf98\uda48\uddd1\ud969\udfe8\ud9ad\udfc3\ud9a6\uddcd\ud982\udf2a\ud908\udf9e\ud8b7\udfd1\udbf2\udd75\uda33\uded1", "\u43a2\u436a\u50f8\u4c1e\u9d73\u312c\u4487\u9052", "\ud83b\ude8a\uda15\ude05\udb9c\udc86\ud866\udc73\uda55\udd34\udaf9\udfdb\ud865\uddfa\ud859\udfe7",
        37, 99386, 1545499150, 7967734601781534724L, -14533L, false, true, (char) 34795, (char) 771,
        Double.longBitsToDouble(0x3fe118aa0dfea6faL), Double.longBitsToDouble(0x3f9bea31083b7a80L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |a0=[B:[[-3, -119]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 14, 12, "\ud92d\udcb9", "\u053c\u51fd\u1f88\u1d51\u2cf1\u63a8\u2e85\u541a", "\udab6\ude81\udae4\udf5c\ud93a\udc7a\udb4e\udf71\ud9a4\udefc\u9d87\ud895\udc26\u83c6",
        21, 4391, -1372898277, -1267409828458063486L, 42095L, true, false, (char) 54976, (char) 35244,
        Double.longBitsToDouble(0x3fe0300bd0eae65aL), Double.longBitsToDouble(0x3f8ce1e52b170780L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |a0=[B:[[126, 4, 75, -114, 33, -53]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 11, 15, "\udbae\udd34\uda7b\uddbe\ud951\udefb", "\u7608\uc682\u2cf1\u63a8\u2e85\u2382\u33f3\u3374\uadf0\u6ab3\u43a2\u436a\u50f8\u4c1e\u9d73\u0958\u43f6\u9052\u531e\u44a1\ucf19\uc414\u1976\u686d\u1d58\u3594\u46b5\u1f05\u1aa1\u06c8\u0f3c\u9f75\ub21e\u51cd\u2578", "\ud917\udc45\ud91f\ude1c\udbf1\udc1b\ud93c\ude13",
        0, 68742, -108666301, 4011651120804489281L, -37402L, false, false, (char) 26649, (char) 17197,
        Double.longBitsToDouble(0x3fe6ecab5b791934L), Double.longBitsToDouble(0x3fdf29747787bdc8L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |a0=[B:[[36, 3, 28, 45, -49, -14]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 11, 15, "\uda54\udf33\ud94c\udd5d\udaff\ude22", "\u7608\uc682\u2cf1\u63a8\u2e85\ub4ef\u33f3\u3374\uadf0\u6ab3\u43a2\u436a\u50f8\u4c1e\u9d73\u312c\u1b6d\u9052\u531e\u44a1\ucf19\uc414\u1976\u686d\u1d58\u3594\u46b5\u1f05\u1aa1\u06c8\u0f3c\u9f75\ub21e\u51cd\u2578", "\ud917\udc45\ud91f\ude1c\udbf1\udc1b\ud93c\ude13",
        0, 68742, -108666301, 4011651120804489281L, -37402L, false, false, (char) 26649, (char) 27831,
        Double.longBitsToDouble(0x3fe6eb56c3791934L), Double.longBitsToDouble(0x3fdf29747787bdc8L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=37684950225947648\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 12 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=37684950225947648\012",
        Z.run(T, 2, 13, 7, 12, "\udbd2\uddf3\ud927\udecd\udb0c\udd6c\ud946\udf62\udb31\udc23\ud8b5\udd15\udad9\udc2a\udb62\udfed\uda1e\udfb3\ud9ed\uddd2\ud9e6\udd3a\ud977\ude60\ud9d3\udc6a\ud922\udff5\udbda\uddba", "\u50f8\u4c1e\uab15\u95cb\u5a22", "\uda7e\udc70\uda76\udc38\uda15\udd8f\ud91e\uddec\udb86\udf1f\uda4f\udcb0\uda02\uddbd\ud846\udeb8\ud917\udd86\ud807\udc83\u1792\u7dc7\ud844\udd8b\udad0\udc0f\000\uda33\ude59\udb57\udf96\udb29\udd7b\ud917\udc8b\ud91f\ude1c\udbf1\udc1b",
        29, 36461, -1465238258, 37684950225947648L, 24294L, true, true, (char) 43358, (char) 16221,
        Double.longBitsToDouble(0x3fe53a138522e064L), Double.longBitsToDouble(0x3fd6ac2419fea950L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=0\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 6 |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=0\012",
        Z.run(T, 2, 13, 7, 12, "\udbd2\uddf3", "\u793a\u51ce\u0264\u4d4c\u5fd7\000\000\ucb05", "\ud922\udff5\000\ud93a\udc24\000\000\uc300\ud895\udc26\ud9d3\udd29",
        4, 97376, 2833435, 0L, -100000L, false, false, (char) 41487, (char) 33225,
        Double.longBitsToDouble(0x3fb6ea99680001e0L), Double.longBitsToDouble(0x3fe0300bd0eae65aL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |a0=[B:[[36, 3, 28, 45, -49, 0]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=1000 GID=1000\0121=void |a0=[B:[[36, 3, 28, 45, -49, 0]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=13577500 GID=0\012",
        Z.run(T, 2, 10, 11, 15, "\uda54\udf33\ud94c\udd5d\udaff\ude30", "\u7608\uc682\u2cf1\u63a8\u2e85\ub4ef\u33f3\u3374\uadf0\u6ab3\u43a2\u436a\u50f8\u4c1e\u9d73\u312c\u1b6d\u9052\u531e\u44a1\ucf19\uc414\u1976\u686d\u1d58\u3594\u46b5\u1f05\u1aa1\u06c8\u0f3c\u9f75\ub21e\u51cd\u2578", "\ud917\udc45\ud91f\ude1c\udbf1\udc1b\ud93c\ude13",
        0, 68742, -108666301, 4011651120804489281L, -37402L, false, false, (char) 26649, (char) 27831,
        Double.longBitsToDouble(0x3fe6eb56c3791934L), Double.longBitsToDouble(0x3fdf29747787bdc8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |a0=[B:[[36, 3, 28, 45, -49, 0]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=13577500 GID=0\0121=void |a0=[B:[[36, 3, 28, 45, -49, 0]] |this=org.apache.commons.compress.archivers.zip.X7875_NewUnix:0x7875 Zip Extra Field: UID=13577500 GID=0\012",
        Z.run(T, 2, 11, 11, 15, "\uda54\udf33\ud94c\udd5d\udaff\ude30", "\u7608\uc682\u2cf1\u63a8\u2e85\ub4ef\u33f3\u3374\uadf0\u6ab3\u43a2\u436a\u50f8\u4c1e\u9d73\u312c\u1b6d\u9052\u531e\u44a1\ucf19\uc414\u1976\u686d\u1d58\u3594\u46b5\u1f05\u1aa1\u06c8\u0f3c\ua014\ub23d\u51cd\u2578", "\ud917\udc45\ud91f\ude1c\udbf1\udc1b\ud93c\ude13",
        0, 68742, -108666301, 4011651120804489281L, -37402L, false, false, (char) 26649, (char) 27831,
        Double.longBitsToDouble(0x3fe6ed9ec3791934L), Double.longBitsToDouble(0x3fdf29747787bdc8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|getCentralDirectoryLength||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|clone||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|equals|java.lang.Object|new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|getCentralDirectoryData||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|getGID||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|getHeaderId||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|getLocalFileDataData||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|getLocalFileDataLength||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|getUID||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|hashCode||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|parseFromCentralDirectoryData|[B,int,int|new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|parseFromLocalFileData|[B,int,int|new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|reset||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|setGID|long|new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|setUID|long|new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|toString||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
    "M|org.apache.commons.compress.archivers.zip.X7875_NewUnix|getCentralDirectoryLength||new:org.apache.commons.compress.archivers.zip.X7875_NewUnix:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
