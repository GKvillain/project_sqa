package org.apache.commons.compress.archivers.sevenz;
import org.junit.Test;
import static org.junit.Assert.*;
public class SevenZFile_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 2, "\ud828\udf9c\udb93\udde0\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\ud8ad\udf98\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud823\udd24\uda2c\udf60\ud8e2\ude61\udb05\udd03\udbe0\udec4\ud859\udefc\ud874\udc78\ud8d8\udd80\udbeb\ude7f\udbed\udf7f\ud940\udcb1\ud82a\udf29\udaaf\udd84", "\ub055\u33c2\u3326\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5",
        44, 56195, 1717953789, -8506253532653050375L, -91878L, false, true, (char) 5537, (char) 57241,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 2, "\ud828\udf9c\ud92e\udce2\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\ud8ad\udf98\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud823\udd24\uda2c\udf60\ud8e2\ude61\udb05\udd03\udbe0\udec4\ud859\udefc\ud874\udc78\ud8d8\udd80\udbeb\ude7f\udbed\udf7f\ud940\udcb1\ud8da\udf21\udaaf\udd84", "\ub055\u33c2\u9e26\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\uda08\udec0\ud933\udc28\ud855\udce1\uda74\ude30\ueec5",
        44, 83115, 1717953789, -5197482196500518710L, -92027L, false, true, (char) 5537, (char) 57241,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 13, 2, "\ud89d\udf16\udba3\udc28\ud8a8\udd9c\ud9ed\udd12", "\ud588\uc6c2", "\ud823\udd24",
        30, 40134, 767933145, 2302026221404485999L, -54806L, false, true, (char) 13329, (char) 20226,
        Double.longBitsToDouble(0x3fc860a1e32c5d68L), Double.longBitsToDouble(0x3f74a68b25409700L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 13, 2, "\ud828\udf7b\udb93\udde0\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\ud8ad\udf98\udb11\udd6f\ud9da\udf49\ud943\udeb8\ud823\udd24\uda2c\udf60\ud8e2\ude61\udb05\udd03\udbe0\udec4\ud859\udefc\ud874\udc78\ud8d8\udd80\udbeb\ude7f\udbed\udf7f\ud940\udcb1\ud9c6\uded7\ud875\ude08", "\ub055\u33c2\u3326\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5",
        25, 84571, 1717953637, -8506253532653050375L, -91878L, false, true, (char) 5537, (char) 57241,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 0, 2, "\ud8cb\udfa0\udb93\udde0\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\uda66\udd14\uda3d\udddd\udaa1\udfc7\udb6d\udd11\ud943\ude7b\ud823\udd24\uda2c\udf60\u8002\udb05\udd03\udbe0\udec4\ud859\udefc\ud874\udc78\uda2e\uddeb\ud85f\udf5f\udbe9\ude91\ud940\udcb1\ud82a\udf29\udaaf\udd84", "\ub055\u33c2\u3326\u4b1f\u4109\u025a\u22d4\ud1b6\u1125", "\ud855\udce1\uda74\ude30\ueec5\udb05\ude59\ud9fc\udfaf",
        51, 92515, -389175815, 6822748587530919866L, 95319L, false, false, (char) 13331, (char) 45447,
        Double.longBitsToDouble(0x3fe6fdf4da9fa555L), Double.longBitsToDouble(0x3fed6a92b948bbf1L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-8, 108, 99, -80, 100, -116, -67, -30]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 2, "\ud828\udf9c\udb93\udde0\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\ud8ad\udf98\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud83a\udd30\uda88\ude21\ud8e2\ude61\udb05\udd03\udbe0\udec4\ud859\udefc\ud874\udc78\ud8d8\udd80\udbeb\ude7f\ud851\ude12\ud921\udd52\ud82a\udf29\udaaf\udd84", "\ub055\u33c2\u3326\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5",
        39, 52143, 1717953789, -8968435444463019101L, -91878L, false, false, (char) 57803, (char) 57048,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 2, "\ud800\udc1f\udab6\udfb7\ud9c8\udd8d\udb81\udd49\udb9f\udccd\uda0c\uded0\u6e5a\udb11\udd6f\udb6d\udd11\uda87\udd5d\ud823\udd24\uda2c\udf60\ud9fb\udeee\udb05\udd03\udbe0\udec4\udbc3\udfd1\ud96b\udd0e\ud848\uddb3\udbeb\ude7f\udbed\udf7f\ud940\udcb1\ud82a\udf29\udaaf\udd84", "\ub055\u33c2\u3326\u6346", "\udb2e\udf5c\udb73\udff9\udb27\udc56\u54c7\ud965\udece\u5ec2\ud917\udda3\ueec5",
        44, 62747, -1487942491, -8506253963991800327L, 95319L, false, false, (char) 13331, (char) 4289,
        Double.longBitsToDouble(0x3fea81abca9fa555L), Double.longBitsToDouble(0x3fd80117486cc4aeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 13, 2, "\ud828\udf9c\ud8bc\udd35\ud889\udd8b\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\ud9be\ude31\ud9b8\udcaa\udb6d\udd11\ud943\ude7b\ud823\udd24\uda2c\udf60\udbc6\ude57\udbb8\udc60\udabf\udf75\ud859\udefc\ud8d8\udfd1\ud83c\ude65\udbeb\ude7f\udbed\udf7f\ud940\udcb1\ud82a\udf29\udaaf\udd84", "\ub055\u353d\u3326\u4b1f", "\udae5\udce2\udb74\udc35\udb27\udc56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5",
        38, 53893, -438043556, 1533249589507268793L, 42010L, false, true, (char) 42977, (char) 21588,
        Double.longBitsToDouble(0x3feb1c346e012910L), Double.longBitsToDouble(0x3fd6ded6662072eaL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-8, 108, 99, -80, 100, -116, -67, -30]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 2, "\ud828\udf9c\udb93\udde0\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\ud8ad\udf98\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud823\udd24\uda2c\udf60\ud8e2\ude61\udb05\udd03\udbe0\udec4\ud859\udefc\ud874\udc78\ud8d8\udd80\udbeb\ude7f\udbed\udf7f\ud940\udcb1\ud82a\udf29\udaaf\udd84", "\ub055\u6d9c\u1722\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5",
        -2, 56350, 1717953789, -8506253532653050375L, -91878L, false, true, (char) 5537, (char) 57241,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-8, 108]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 10, "\ud828\udf9c", "\u646b\u934c", "\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud823\udd24\uda2c\udf60\ud8e2\ude61\udb05\udd03\udbe0\udec4\ud859\udefc\ud874\udc78\ud8d8\udd80\udbeb\ude7f\udbed\udf7f",
        58, 82859, -1786317877, -9138220944197015990L, 53152L, true, true, (char) 42477, (char) 55667,
        Double.longBitsToDouble(0x3fbd732092ce00d0L), Double.longBitsToDouble(0x3fd3f4ba7170314eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[109, -26, 115, -8, 35, 88, -67, -30]]\012",
        Z.run(T, 1, 7, 4, 2, "\ud89d\udf16\udba3\udc28\uda53\udd88\ud9ed\udd12", "\ud588\u983b", "\ud909\uddce\udaec\udded\ud8e2\ude61\uda15\udd8b\uda6d\udd0f",
        47, 37399, 1007464586, -2330255355450534809L, -14179L, true, false, (char) 37582, (char) 12029,
        Double.longBitsToDouble(0x3fec191a9ef3f64eL), Double.longBitsToDouble(0x3fef424926345469L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[78, -51, -19, -96, 93, -108]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 14, 7, "\ud97e\udffd\ua71d\uced0\ud88d\uddc4", "\ud588\u8a4b", "\ud8df\udfb2\ud919\udf5b\ud8b1\udecc\udafe\udd1e\ud809\udc41\ud920\ude1d\u1b02\udb17\udeff\ud945\udfe8",
        57, 38904, 1013866911, -3806205874084697892L, 22833L, true, true, (char) 55654, (char) 54479,
        Double.longBitsToDouble(0x3feebdc661c08e42L), Double.longBitsToDouble(0x3feed9ee6efdc6c8L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-8, 108, 99, -80, 100, -116, -67, -30]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 2, "\ud828\udf9c\udb93\udde0\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\udba7\udc94\ud825\udd75\udb18\udfa7\udae5\udd0c\udb5b\udcbe\uda88\ude21\ud8cf\udf61\udb05\udd03\udbe0\udec4\udb9e\ude08\uda59\udc23\ud8ad\udd87\udbeb\ude7f\ud851\uddcd\udadb\udf44\ud839\udc69\udaaf\udcdc", "\ub055\u33c2\u3326\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5",
        39, 52143, 1717953789, -8968435444463019101L, -91878L, false, false, (char) 57803, (char) 57048,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 15, 2, "\ud828\udf9c\udb93\udde0\ud894\udcbc\ud9ed\udd12\ud969\udfc1\ud916\udf8d\ud8ad\udf98\udb11\udd6f\udb6d\udd11\ud943\ude7b\uda91\udf65\ud93b\udf74\ud88f\uded0\udb76\udd6d\udbe0\ude99\ud859\udefc\ud874\udc78\ud8d8\udd80\udac5\ude05\ud837\udda4\ud921\udd52\ud82a\udf29\udaaf\udd84", "\ub055\u33c2\u33ef\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\ud855\udce1\u8b3f\u759f\ud8ae\udfae",
        -2, 43789, -1999528069, 2833146395015140867L, -52746L, false, true, (char) 41952, (char) 14951,
        Double.longBitsToDouble(0x3fecd20f4adf509aL), Double.longBitsToDouble(0x3fe6ad2aaace71aaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-8, 108, 99, -80, 100, -116, -67, -30]]\0121=java.lang.Boolean:false |a0=[B:[[-8, 108, 99, -80, 100, -116, -67, -30]]\012",
        Z.run(T, 2, 7, 7, 2, "\ud828\udf9c\udb93\udde0\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\ud91a\ude18\udae9\udd92\udb6d\udd11\ud943\ude7b\ud83a\udd30\ud8b5\udff7\ud9d7\ude26\uda90\ude9e\udbe0\udec4\ud859\udefc\uda1d\ude45\ud86f\ude3f\ud904\udf8b\ud851\ude12\ud921\udd52\ud82a\udf29\udaaf\udd84", "\ub055\u33c2\u3326\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5",
        39, 52143, 1717953789, -8968435444463019101L, -91878L, false, false, (char) 57803, (char) 57048,
        Double.longBitsToDouble(0x3fed6bc3c89078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[55, 11, 103, 81, 100, -116, -67, -30]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 2, "\ud867\udc3b\udb97\udf81\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud916\udf8d\ud8ad\udf98\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud83a\udd30\uab13\ud8e2\ude3f\udb05\udd03\udbe0\udec4\ud859\udefc\ud874\udc78\ud8d8\udd80\udbeb\ude7f\ud851\ude12\ud921\udd52\ud82a\udf29\udaaf\udd84", "\ub055\u33c2\u3326\u4b1f", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5",
        39, 52143, 1717953789, -8968435444463019101L, -91878L, false, false, (char) 57803, (char) 57048,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[108]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 13, 0, "\ufa9c", "\000\000", "\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud83a\udd30\uda88\ude21\ud8e2\ude61\u00d9\udbe0\udec4\ud859\udefc\ud874\udc78\ud8ac\udd80\udbeb\ude7f\ud818\ude2c",
        20, 82859, -1786317877, -9138220944197015990L, 96981L, true, false, (char) 43741, (char) 50557,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd1c6e00e8d28d8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-33, 55, -118, 110, -104, 93, 81, 25]]\0121=java.lang.Boolean:false |a0=[B:[[-33, 55, -118, 110, -104, 93, 81, 25]]\012",
        Z.run(T, 2, 7, 7, 10, "\ud80f\udd67\udaba\udf9e\ud9c8\udd8d\udb81\udd49\udb9f\udccd\uda0c\uded0\u6e5a\udb11\udd6f\udb84\udc7c\uda87\udd5d\ud887\uddb7\uda29\ude53\ud9fb\udeee\udb05\udd03\udbe0\udec4\udbc3\udfd1\ud96b\udd0e\udaa6\udec2\udbeb\ude41\udbed\udf7f\ud940\udcb1\ud82a\udf29\udaaf\udd84", "\ub055\u33c2\u3326\u6346\u4109\uaecd\u4ad5\ud1cb\u1125\u5a7c\ucc03\ua7a5\u6255", "\ud9ab\udde6\udbfd\udf6a",
        -1, 37129, -1533670745, 2302949000567514470L, 73172L, true, true, (char) 943, (char) 9448,
        Double.longBitsToDouble(0x3fe4fd2aa9801174L), Double.longBitsToDouble(0x3fab312bf0c67a40L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 7, 2, "\ud830\udfa0\udb93\udde0\ud894\udcbc\ud9a8\uddd1\ud9bb\udf69\ud916\udf8d\ud8ad\udf98\udb11\udd6f\udb6d\udd11\udb3a\udcd6\ud9cf\udcbc\uda05\ude2a\ud82c\udf7a\ud83b\udfbe\ud80b\udf85\ud859\udefc\udb53\udc08\ud9f2\udf9d\ud85f\udd75\udb1f\udcd9\ud88a\ude2d\ud806\udf2e\udaaf\udd84", "\ub055\u52e6\u4227\u1af7", "\ud837\ude68\udb73\udfe4\udb4d\udd56\u54c7\ud965\udece\ud855\udce1\uda74\ude30\ueec5\ud9c4\uddb9\uda57\ude38",
        1, 92515, -389175815, 6839074133695536826L, -13993L, true, false, (char) 28377, (char) 45225,
        Double.longBitsToDouble(0x3fe6fdf4da9fa555L), Double.longBitsToDouble(0x3fe6a019bf76f9f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[55, 97, 103, 81, 100, -116, -67, -30]]\0121=java.lang.Boolean:false |a0=[B:[[55, 97, 103, 81, 100, -116, -67, -30]]\012",
        Z.run(T, 2, 7, 7, 2, "\ud867\udc91\udb97\udf81\ud894\udcbc\ud9ed\udd12\ud9bb\udf69\ud990\udf8a\ud8ad\udf98\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud83a\udd30\uab13\ud8e2\ude3f\udb05\udd03\udbe0\udec4\udaf5\udfc9\ud85a\udc42\uda03\udc94\u1def\ud816\ude5c\ud921\udd80\ud82a\udf29\udaaf\udd84", "\ub16a\u69a0\u4c84\u95d6", "\ud837\udea2\udb73\udfe4\udb27\udc56\u54c7\ud965\udece\udba3\udd68\uda74\ude30\ueec5",
        39, 52143, 1717953789, -8968435445808145501L, -59385L, false, true, (char) 10366, (char) 57048,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fe6fdf4da9fa555L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 13, 2, "\ud828\udf9c\udac9\udddb\ud894\udcbc\ud9ed\udd12\ud9c7\udf69\ud916\udf8d\ud8ad\udf98\udb11\udd6f\udb6d\udd11\ud943\ude7b\ud823\udd24\uda2c\udf60\ud8e2\ude61\udb05\udd03\udba9\udd49\ud859\udefc\ud874\udc78\ud9bb\udff0\u7fe6\ud9f3\ude84\ud940\udcb1\ud82a\udf29\udaaf\udd84", "\uafd3\u33c2\u5456\u4b70", "\udad6\udcee\udb37\udf30\udb85\udcb5\uda3d\udf1a\ud983\udc90\ud855\udce1\uda74\ude30\ueec5",
        44, 56195, 1717953789, -8506253532653050375L, -91878L, false, true, (char) 5537, (char) 57241,
        Double.longBitsToDouble(0x3fefaa00f09078f7L), Double.longBitsToDouble(0x3fc5f7f9ea7f8fecL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|getCurrentStream||new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|buildDecoderStack|org.apache.commons.compress.archivers.sevenz.Folder,long,int,org.apache.commons.compress.archivers.sevenz.SevenZArchiveEntry|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|buildDecodingStream||new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|calculateStreamMap|org.apache.commons.compress.archivers.sevenz.Archive|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|close||new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|getEntries||new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|getNextEntry||new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|matches|[B,int|static",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|read||new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|read|[B|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|read|[B,int,int|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|readAllOrBits|java.io.DataInput,int|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|readArchiveProperties|java.io.DataInput|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|readBits|java.io.DataInput,int|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|readEncodedHeader|java.io.DataInputStream,org.apache.commons.compress.archivers.sevenz.Archive,[B|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|readFilesInfo|java.io.DataInput,org.apache.commons.compress.archivers.sevenz.Archive|new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
    "M|org.apache.commons.compress.archivers.sevenz.SevenZFile|getCurrentStream||new:org.apache.commons.compress.archivers.sevenz.SevenZFile:java.io.File",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
