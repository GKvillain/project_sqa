package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 5, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824", "\ud8dd\udd23",
        12, 90950, 1361968870, -7458186948677527110L, 6476L, false, true, (char) 50162, (char) 54828,
        Double.longBitsToDouble(0x3fe5879e54db5f30L), Double.longBitsToDouble(0x3fbe672faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 5, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824", "\ud8dd\udd23\uda47\udd68\udb2d\udfbc",
        10, 98532, 1067391418, -1502249068168585196L, -94768L, true, false, (char) 33402, (char) 19467,
        Double.longBitsToDouble(0x3fbe672faf4bd5a8L), Double.longBitsToDouble(0x3fdf2938b5a4cb20L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 5, 5, "\uda13\ude3a\uda65\udfbc\ud9db\udeba\udb24\uded7\uda61\udf79\udbe2\udef5\udafd\uddcf", "\u5df9\u88ef\ua3d8\ubffc\u6c3e\u8182\uc64c", "\ud8dd\udd23",
        12, 90950, 1361968870, -7458186948677527110L, -59060L, true, false, (char) 50162, (char) 54828,
        Double.longBitsToDouble(0x3fe5879e54db5f30L), Double.longBitsToDouble(0x3fbe672faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 5, 1, "\ud977\udd4d", "\u872a\ub30b\ubbdf\u682c\u90d5\u37f1\u8f18\u06bb", "\ud849\uded5\udbca\udcbf\udb49\udd80\ud81a\udf15\udb19\udc52\ud8dd\udd12",
        -2, 28886, 1361968870, -7458186948677527110L, 6331L, false, true, (char) 50162, (char) 54828,
        Double.longBitsToDouble(0x3fe5879e56db3030L), Double.longBitsToDouble(0x3fe0019fade97ab5L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 7, 6, "\ud803\udd53\uda65\udf89\ud850\udd34\ud9b9\udd88\udb76\udf19\udac8\udff7\udafd\udd8e\uda5a\udcf2", "\u05f9", "\uda85\udd1f\udbd8\uded8\udb33\ude39\ud9e1\udf84\udaf8\udeab\ud8dd\udd23\uda47\udd68\udb2d\udfbc\ud916\udc50\ud9d9\udc62\ud9fd\udfc7\ud9e3\ude31\udadd\udefe\ud97d\udcb1\udbc2\udd62\ud916\udf08\ud837\udde6\ud8ef\udf77\ud8bc\udc3d\ud8db\udc8a\ud95c\udf8d\udbd8\udfdc\udb1b\udfd2\ud860\udef2\uf379",
        52, 80125, 1523395068, -1734762785358148543L, -45308L, true, true, (char) 55302, (char) 10015,
        Double.longBitsToDouble(0x3fe40e8cbdd87c3eL), Double.longBitsToDouble(0x3fe80cda40aead6bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba", "\ubbdf\u3cc4\u8a58\ucfd7\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824\u090e\ua363\u25b6\u016f\u2c38\ucf1c\uafcf\u7d21\u67b9\u3170\u4cc2\uab0a", "\uda47\udf01\ud8ea\udfb4\udaff\udf1e\udbb1\udf9f\ud9d0\udda4\udac6\udcbd\udbda\udc21\udbb5\udf14\udb86\udc3e\ud9c4\udfbb\uda9b\udc45\ud9e3\udd58\udb1c\udc6e\ud960\uddc9\udbe6\udc33\udb50\ude80\udb53\udf3e\ud824\uddaa\ud98b\udecc\u0357\uda1e\uddfb\ud9e3\udd02\uda33\udfb6\ud98f\ude51\ud825\udf20\ud99b\udfff\udb0f\udfe0\ud817\udcb5",
        33, 72530, 226951445, -4162924175828945453L, -70034L, true, false, (char) 11466, (char) 23555,
        Double.longBitsToDouble(0x3fec2d73430bd8b8L), Double.longBitsToDouble(0x3fa27e59c75ed7e0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 5, 8, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\ud9ec\udc9a\ud8a6\udfd6", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824\u090e\ua363\u2356\u1a10\u6d74\ucf1c\uafcf\u7d21\u67b9\u3170\u6192\u4dbd\u1dc4\u1b0f", "\ud896\udf68\ud970\udc11\udaa0\ude8a",
        1, 48757, 287773965, 4766956630617039161L, -56745L, false, true, (char) 31285, (char) 5605,
        Double.longBitsToDouble(0x3fbff3c6ee62e1b0L), Double.longBitsToDouble(0x3fba74d706cf85b0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 5, 6, "\ud893\udc5a\ud846\udc78\udad2\udeab\ud9d4\udc90\udb76\udf19\ud9db\udec9\udb65\udc04", "\u5df9\u05f9\ua3d8\u092d\u13d8\u12d3\u1824", "\udb3f\udfac",
        37, 40081, 1361968870, -7458186948677527110L, 6476L, false, true, (char) 50162, (char) 54828,
        Double.longBitsToDouble(0x3fe5879e54db5f30L), Double.longBitsToDouble(0x3fbe672faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 9, 6, "\ud916\udf15\ud981\udc54\ud9db\udeba", "\ubbdf\u3cc4\ub959\u89d1\u5ae7\u05f9\u76d8\u5e07\u00ec\u785d\u1824\u090e\ud54a\u6f3e\u016f\u58f5\u4550\uafcf\u7d21\u67b9\uc9dc\u4cc2\uba72", "\uda1f\udecc\ud8ea\udfb4\udafe\udffd\ud997\uddf7",
        4, 53897, -137175355, -3886194227579941311L, -47417L, false, false, (char) 47200, (char) 29989,
        Double.longBitsToDouble(0x3fe1b93d550fad1bL), Double.longBitsToDouble(0x3fe4c10d08ef64ddL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 9, 10, "\uda2a\uddd7", "\u872a\ub30b\ubbdf", "\ud918\uddbf\uda34\udfdb\ud9f8\udd2b\ud892\udfd4\uda5c\udde2\ud831\udd5a\udbd6\udd87\uda53\udc98\ud89d\ude8e\ud89c\udc36\ud8c3\uddb5\uda47\udd68\udb2d\udfbc\udad2\udfae\udb39\ude31\udbcb\udd02\u0fa5\u2276\udad7\udcea\u7b44\udb16\udd64\ud81f\udc4c\uda47\udf01\ud8ea\udfb4\ud9b1\udc15\ud92f\udf47\uda80\udcbf\udaf9\uddd0\udaff\udd52\ud87f\uddf6\udb9a\udd20\uda3a\udd8b\ud86e\ude97\udb8b\udf89",
        29, 53202, 482768306, -8916218863600020430L, 51857L, false, true, (char) 61978, (char) 47330,
        Double.longBitsToDouble(0x3fa226a22f68d910L), Double.longBitsToDouble(0x3fd8f1aab5786940L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 9, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824", "\ud8dd\udd23",
        12, 90950, 1361968870, -7458186948677527110L, 6476L, false, true, (char) 50162, (char) 54828,
        Double.longBitsToDouble(0x3fe5879e54db5f30L), Double.longBitsToDouble(0x3fbe672faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Long:590 |a0=[B:[[71, 29, 53, 89, 95, 6, -119, 110]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 3, 1, "\ud977\udd4d\uda65\udf89\ud98f\udf36\udbb9\udf9e\udb76\udf19\udbe2\udef5\udad5\uddde\uda5e\udc64\uda3e\udcb9\udb57\udd5a\ud977\udef8\uda8c\udf93\udacd\uddf5\ud83f\ude38\uda5a\udec7\uda80\udf5e\udbdb\udc42\ud9d5\udc3e\ud9d3\udfd1\udba7\ude56\udb2d\udfbc\udab2\udfdf\ud9d9\udc62\udad8\ude83\udb07\udcdd\ud938\udef9\ud93c\udd60\ue78f\udb16\udd94\ud81f\udc4c\uda47\udf01\ud8ea\udfb4\ud8bd\udebc\udaae\udc3f\uda61\udf35\ud9e8\udc6a\udb0b\udfe2\uda19\udfa1\u43ed\udbb7\udd2d\udab9\udfec\udb98\uddbb\ud9d6\udf1e", "\u6f18\u55fc\u2f52\u9a39\u1df2", "\ud91e\udc54\ud9fb\udf08\ud928\uddff\udaf1\udd62\ud882\udeb9\ud93c\udd85\uda0d\udca0\ud8ac\udc31\udbbd\udd8f\uda85\udcab\uda59\udca7\ud8ba\udf81\ud9c1\uddbd\udad2\udf23\udbbe\udd27\uda6a\uddcf\uda2d\ude6b\ud9b3\uddaa\ud997\udf48\ud87d\uddeb\ud86d\ude40\udbd5\udf98\ud8e9\ude06\udb8f\ude65\ud945\udcd2\udb5d\udfa5\udb1a\udfc7\u4f20\uda14\udcd0\udb1b\udf53\ud906\udc21\udbd8\udea4",
        6, 68973, -24190018, 5347754156021166659L, -91420L, true, false, (char) 50182, (char) 300,
        Double.longBitsToDouble(0x3fb76790e505cc88L), Double.longBitsToDouble(0x3fd1a66fd08d7770L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 5, 6, "\000", "\u872a\uc3e1\ubbdf", "\uda3e\udcb9\udb9c\udc39\ud9f1\udf63\ud89c\udfc4\ud809\ude9b\udba1\udd52\udbd8\udec6\uda80\udf5e\ud89d\udea2\udaf6\ude83\ud8dd\udd23\uda47\udd68\udaef\udcd6",
        10, 98532, 1056964794, -1502249068168585196L, -94768L, true, false, (char) 33402, (char) 19467,
        Double.longBitsToDouble(0x3fbe672faf4bd5a8L), Double.longBitsToDouble(0x3fe9d8e692110290L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 5, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9\u96d8\ubffc\u9bcc\u0aa0\u1824", "\ud8dd\udd23",
        12, 90950, 1361968870, -7458186948677527110L, 6476L, false, true, (char) 50162, (char) 63538,
        Double.longBitsToDouble(0x3fe8ca9134db5ffdL), Double.longBitsToDouble(0x3fbe672faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 1, 0, "\udaeb\udc95\uda25\udfde\ud9db\udf1f\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1f2a", "\ud8dd\udd23",
        12, 90950, 1361968870, -7458186948677527110L, 55829L, false, true, (char) 50162, (char) 54828,
        Double.longBitsToDouble(0x3fdb0f3ca9b6be60L), Double.longBitsToDouble(0x3fbe672faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 5, 6, "\ud977\udd4d\uda65\udf89\ud9fd\udecf\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\ub4db\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u665c", "\ud8cc\ude90\uda47\udd68\ud96b\udd68\udad2\udf5c\ud9d9\udc62\udb47\udd79\ud9c7\udf34\ud928\udcfc\udb11\udd56\ue78f\udb16\udd64\uda49\udc81\udb48\udefe\ud8ea\udfb4\uda40\udff8\udaff\udd23\ud80c\uddf2\ud8f9\udcb0\udaab\udf26",
        33, 36148, 521664393, 3554447002796641557L, -77871L, true, true, (char) 44402, (char) 27153,
        Double.longBitsToDouble(0x3fe8e5a6145ba7b2L), Double.longBitsToDouble(0x3f81e3b901836c00L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 5, 6, "\udba1\udf02\uda5d\udee1\ud9db\udeba\ud98a\udef9\ud8f5\udeea\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824", "\ud8dd\udd23\uda47\udd68",
        15, 83870, -1736494468, 4584411231991296111L, -7254L, true, false, (char) 30433, (char) 33402,
        Double.longBitsToDouble(0x3fcb6be611e672f8L), Double.longBitsToDouble(0x3fde97ab5e0caf26L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Long:952 |a0=[B:[[71, 29, 53, 89, -85, -118, -92, -19]]\0121=java.lang.Long:952 |a0=[B:[[71, 29, 53, 89, -85, -118, -92, -19]]\012",
        Z.run(T, 2, 1, 1, 8, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u0f7e\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824", "\ud8dd\udd23",
        12, 90950, 1361968870, -7458186948677527110L, 6476L, false, true, (char) 16115, (char) 26334,
        Double.longBitsToDouble(0x3febddb7ecdba45aL), Double.longBitsToDouble(0x3fbe672faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 4, "\ud997\udf5d\000\ud836\udf7a\ud9d4\udc1d\000\udbd5\udf29\udafd\udd8e", "\000", "\ud809\ude9b",
        -3, -1000, 0, 992137445376L, 38761L, false, false, (char) 21020, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e3db00000000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 5, 10, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udee0\ud830\udffc\udaf3\ude8e", "\u5df9\u05f9\ua3d8", "\udb80\udc45\ufe1a\ud9d5\udf8e\uda7b\ude44",
        5, 84697, -942882074, 5849611755499500156L, 92623L, false, false, (char) 9052, (char) 60648,
        Double.longBitsToDouble(0x3fe35269a6c7c006L), Double.longBitsToDouble(0x3fcb6be9b1e672f8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 6, 10, "\uda23\udc61\uda65\udf89\ud996\udd31", "\ubbdf\u3cc4\u8a58\ucfd7\ub608\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824\u090e\ua363\u1a9f\u61b1\u199b\u4cd3\uafcf\u4308\ud1a5\u3170\ub996\u07d1", "\uda47\udf01\ud8ea\udfb4\ud9df\udd6d\ud8c4\udfb6\ud8b2\udf16\udb73\udcc3\uda78\ude18\ud803\udea5\udac2\udf81\ud8d8\udf76\uda06\uded1\udb75\udcc0\ud8a9\udfa6\ud948\udc60\udac3\ude19\ud896\udd79\ud9f2\udce6\udbd9\udc52\ud8b8\ude54\ud86c\udd26\ud99b\udee1\udafb\udc2f\uda98\udd2e",
        44, 61846, -458508269, 2360581760191254333L, 40152L, false, false, (char) 56191, (char) 6100,
        Double.longBitsToDouble(0x3fd4b6e2ec5fe888L), Double.longBitsToDouble(0x3fc26fbc1015989cL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 5, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\ud8ba\udd22\uda99\udfe6", "\u5df9\u05f9\ua3d8\ubffc\u9bcc", "\ud89d\udea2\udba4\udcf9\uda13\udce5\udb31\udebe\udb73\udc02\udad7\udfb0\ud9d9\udc62\udb47\udd79\udaaa\ude69\ud94e\ude49\udaca\udfbb\u1922\udb16\udd64\ud81f\udc4c\uda47\udf01\ud8ea\udfb4\ud819\udfab\ud9f2\uddc3\uda1a\udd19\ud873\udd11\udab3\udde4\uda62\udd16\ud998\udf72\udabc\udf6b\uda35\udfc9\udb76\udce4\udb77\ude3f\ud91a\uddd4\u1e37\udb16\udcdc\ud8ee\udc88\udbad\udf8d\ud92b\uddb0",
        40, 67233, -1716460851, -8344281153079853560L, -27617L, true, true, (char) 50663, (char) 9789,
        Double.longBitsToDouble(0x3febc9a1e54e26e0L), Double.longBitsToDouble(0x3fd60400e814cad8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 5, 0, "\000\000\000\000\udb76\udf19\u00cc\000", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u72c9\000", "\ud8dd\udcba",
        12, -1000, 0, 1056964608L, -100000L, false, false, (char) 144, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fbe40002f4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 10, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9", "\ud831\udd5a\udbd8\udec6\uda80\udf5e\ud89d\udea2\ud9e9\udf1c\ud8d2\uddc6",
        12, 90950, 1361968870, -7458186948677527110L, 6476L, false, true, (char) 8435, (char) 54924,
        Double.longBitsToDouble(0x3fe5879e54db5f30L), Double.longBitsToDouble(0x3fbaa72faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:-745\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 0, "", "", "",
        51, -796, 0, 2089670225895085301L, -14443L, true, false, (char) 12746, (char) 55014,
        Double.longBitsToDouble(0x3fe64bf3d401ffddL), Double.longBitsToDouble(0x3fde77cfd9f6a090L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 5, 7, "\ud828\udfc3\ud8ef\udc2c\ud9db\udef2\uda8a\udd58\udbf2\udfbe\ud860\udf7e\u3896\udb4b\udc9d\ud883\ude20\ud870\udd48", "\u19e5\u3d6e\u2ae1", "\udacc\udf0e",
        4, 35046, 1377630912, -1456352742418171803L, 62443L, true, false, (char) 38619, (char) 59925,
        Double.longBitsToDouble(0x3fd9ae5a8f8f51c6L), Double.longBitsToDouble(0x3fc3b17e193a72f8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 1, 12, 5, 6, "\ud86f\uddcb\uda65\udf89\ud9d1\udcba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9\ua3d8\u6d07\u4178\u1cf3\uc6cc", "\ud87b\udf23\uda47\udd68",
        58, 29486, -1728484024, 4546723615523401839L, -8790L, false, false, (char) 14231, (char) 39082,
        Double.longBitsToDouble(0x3fb27e9523cce5f0L), Double.longBitsToDouble(0x3fde97ab52cd9cd2L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-73, -110, 73, 2, -106, -122, -92, -19]]\0121=java.lang.Long:1089 |a0=[B:[[-73, -110, 73, 2, -106, -122, -92, -19]]\012",
        Z.run(T, 2, 9, 1, 6, "\ud9e7\uddc2\ud979\ude32\ud8c6\uddb6\ud9d4\udc1d\udb4f\udda1\uda33\udd5d\ud8e8\ude9f", "\uc17f\u5360\u2105\ubffc\ua593\u54a9\ub4e9", "\udaa3\udf34\uda47\udd68\ud830\uddc3\udad2\udfae\ud9d9\udc62\udb47\udd79\ud9c7\udf34\udabb\udc65\uda31\ude2c",
        2, 62144, 1596986372, -7148580557971752712L, 83069L, false, false, (char) 22520, (char) 7027,
        Double.longBitsToDouble(0x3fe1d90abd6c6b11L), Double.longBitsToDouble(0x3fda5b251a623e98L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 2, 0, "\ud83d\udd50\ud96b\udd2a\ud9db\udeba\udb24\udf97\udb9c\udf58\ud8af\ude3b\ud92e\ude08", "\u477a\u05f9\u4676\u3e9c\ucbd2\u0aa0", "\udaf6\ude6c\ud8dd\udd23\uda20\uded4",
        7, 57448, -1736476850, 4584411231991296111L, -8790L, false, true, (char) 557, (char) 18069,
        Double.longBitsToDouble(0x3fd648f1c8f3397cL), Double.longBitsToDouble(0x3fde97ab59904120L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 5, 0, "\uda13\ude3a\uda65\udfbc\ud9db\udeba\udb24\uded7\uc6a2\000\000", "\u5df9\u88ef\ua3d8\ubfaf\u6c3e\u8182\uc64c", "\ud8dd\udd23",
        12, -1000, 0, -7493989778877113926L, -94768L, true, false, (char) 33402, (char) 19419,
        Double.longBitsToDouble(0x3fbe672faf4bd5a8L), Double.longBitsToDouble(0x3fddecd15ff64dbeL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 11, 5, "\uda13\ude3a\uda65\udfbc\udbac\udc63\ud997\udc73\udafa\ude86\udbe2\udef5\udafd\uddcf", "\u5df9\u88ef\ua3d8\ub765\u6c3e\u8182\uc64c", "\ud8dd\udd23\uda47\udd68",
        5, 83870, -1736494468, 4584411231991296111L, 28465L, true, true, (char) 50220, (char) 59190,
        Double.longBitsToDouble(0x3fcb6be6122672f8L), Double.longBitsToDouble(0x3fde97ab5ea98b14L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Long:1019 |a0=[B:[[-29, -82, 53, -116, -85, -118, 112, 4]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 5, "\uda13\uddde\uda65\udfbc\ud9db\udeba\udaa0\udc34\uda61\udf79\udbe2\udef5\udafd\uddcf", "\u4e2b", "\ud809\ude9b",
        34, 88059, 2096615984, 5785034141978891264L, 38761L, false, false, (char) 20738, (char) 33705,
        Double.longBitsToDouble(0x3fdba987f0de7f3eL), Double.longBitsToDouble(0x3f94eb00000007e0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 2, 12, 12, 5, "\uda13\ude3a\uda65\udfbc\ud9db\udeba\udb24\uded7\uda61\udf79\udbe2\udef5\udafd\uddcf", "\u5df9\u1edd\ua2d3\uc4f6\u6c3e\u8182\uc64c", "\ud8dd\udd23",
        12, 90950, 1361968870, -7458186948677527110L, -59060L, true, false, (char) 23794, (char) 55066,
        Double.longBitsToDouble(0x3fe5879e54db5f30L), Double.longBitsToDouble(0x3fe0a850f5e97a5fL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 5, 5, "\uda13\ude3a\uda65\udfbc\ud9db\udeba\udb24\uded7\u00a2\ud9c5\udf21\uaf87", "", "\ud89c\udfc4M\udafb\udd5f\udbf6\udda80\udbaf\udcb6\udaf6\ude83\ud8dd\udd23\uda47\udd68\udb2d\udfbc\udad2\udfae",
        -5, -1000, 0, -8701130316705560017L, 24416L, false, false, (char) 19467, (char) 40126,
        Double.longBitsToDouble(0x3fde97a008a1928eL), Double.longBitsToDouble(0x3fb6a44a3d2aadf0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 5, "\uda13\uddde", "\u0513\u5792\ubbdf", "\uda3e\udcb9\uda2b\udf44\udb94\udc54\udbd4\udce0\000\udb5f\udd0c\ud816\uddb8\000\000\udaf6\udd88\ud8dd\udd23\uda47\udd68\udb2d\udfbc",
        10, 98532, 0, 0L, -94768L, true, false, (char) 33402, (char) 19467,
        Double.longBitsToDouble(0x3e47a5ead4000000L), Double.longBitsToDouble(0x3fd5c6a1e719c2d2L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 5, 5, "\uda13\ude93\uda65\udfbc\ud9db\udeba\udb24\uded7\uda61\udf79\udbe2\udef5\udafd\uddcf", "\u5e0e\u88ef\uafd7\ubffc\u6c3e\u34c5\u0d0c", "\ud83d\udd78",
        7, 97691, 1361950950, -7458186948677527110L, -59060L, true, false, (char) 50162, (char) 54993,
        Double.longBitsToDouble(0x3fe5879e54db5f30L), Double.longBitsToDouble(0x3fe98ce5f5e97ab5L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 7, 6, "\ud803\udd53\uda65\udf89\ud850\udd34\ud9b9\udd88\udb76\udf19\ud850\udd2d\ud9dc\udcc1\udb1a\udff3", "\u05f9", "\uda85\udda1\udbd8\uded8\udb33\ude39\udb8c\udf9e\udaa0\udc5a\udbc0\udcd5\udaca\udf6a\udb95\udd10\ud916\udc94\ud9d9\udc62\udbfc\udd6d\uda65\udd6d\uda7a\udff8\ud97d\udd5b\udbc2\udd62\ud916\udf08",
        23, -504, 2058684674, 8106573790035494425L, -62098L, false, false, (char) 14437, (char) 15047,
        Double.longBitsToDouble(0x3fe382d66c41e7ecL), Double.longBitsToDouble(0x3fe0c8c94ae0ce28L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Long:551 |a0=[B:[[71, 29, 53, 89, -85, -118]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 3, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba", "\ua924\uc40b\u8a58\ucfd7\u5df9\u05f9\ua3d8\ua8b5\u13ba\u0aa0\u1824\u090e\ua363\u4731\u7d94\uc07b\ucf1c\uafcf\u7d21\ud472\ube0f\u97b9\u98f0", "\uda47\udf01\ud8ea\udfb4",
        4, 28901, 870159334, -5341254744262408058L, -80815L, false, true, (char) 46309, (char) 62081,
        Double.longBitsToDouble(0x3fedda5fe4a64be4L), Double.longBitsToDouble(0x3fb172a65a63b2f8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 7, 6, "\ud977\udd4d\ud9c0\udddc\uda65\udcc0", "\ubbdf\u6ed7\u21a2\ucf49\u5df9\ub99d\ud119\ubffc\ubdc3\u1205\u2b49\u59eb\u0a83\u17be\u0216\u2c38\ucf1c\uafcf\u7d21\u67b9\ub9f7\u25a6\u2b2d", "\uda1d\udd01\ud8ea\udfb4\udaff\udf1e\udbb1\udf9f\ud9d0\udda4\udac6\udcbd\udbda\udc21\udbb5\udf14\ud999\udc88\udab8\udd20\uda95\udcdd\u01af\udb4f\udcd2\ud853\udde5\ud905\udeec\udb59\udcf9\ud960\udc48\uda9b\udc09\ud98b\udecc\u0357\uda40\udffb\ud9e3\udd02\uda33\udfb6\ud98f\ude51\ud825\udf20\ud99b\udfff\udb0f\udfe0\ud817\udcb5",
        58, 39475, 218431765, -4162924175828945453L, -81838L, true, false, (char) 11466, (char) 22019,
        Double.longBitsToDouble(0x3fec2aaac30bd8b8L), Double.longBitsToDouble(0x3fa27e59c75ed7e0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 2, 12, 12, 6, "\ud977\udd4d\uda65\udf89\ud9db\udeba", "\ubbdf\u3cc4\u8a58\ucfd7\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824\u090e\ua363\u25b6\u016f\u2c38\ucf1c\uafcf\u7d21\u67b9\u3170\u4cc2\uab0a", "\uda47\udf01\ud8ea\udfb4\udaff\udf1e\udbb1\udf9f\ud9d0\udda4\udac6\udcbd\udbda\udc21\udbb5\udf14\udb86\udc3e\ud9c4\udfbb\uda9b\udc45\ud9e3\udd58\udb1c\udc6e\ud960\uddc9\udbe6\udc33\udb50\ude80\udb53\udf3e\ud824\uddaa\ud98b\udecc\u0357\uda1e\uddfb\ud9e3\udd02\uda33\udfb6\ud98f\ude51\ud825\udf20\ud99b\udfff\udb0f\udfe0\ud817\udcb5",
        33, 72530, 226951445, -4162924175828945453L, -70034L, true, false, (char) 11466, (char) 23555,
        Double.longBitsToDouble(0x3fec2d73430bd8b8L), Double.longBitsToDouble(0x3fa27e59c75ed7e0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 10, 8, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\ud885\udc2e\ud8f4\ude40", "\uc604\u05f9\ubc65\u546c\u29a3\u0aa0\ub8ba\u0846\u8baf\u07d9\u4785\u6df2\ucf1c\uafcf\u35c5\uaa02\u3170\u8cb5\u0089\ua563\u1b0f", "\ud896\udf68\ud970\udc11\udaa0\ude8a",
        1, 93397, 1094781153, 6964500420251798305L, -14111L, false, true, (char) 1990, (char) 31119,
        Double.longBitsToDouble(0x3fa2a445958fcd80L), Double.longBitsToDouble(0x3fc65108cf725600L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 5, 8, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\ud9ec\udc9a\ud8a6\udfd6", "\u3de3\u05f9\ua3d8\u212c\u9bcc\u0aa0\u1824\u090e\ua363\u2356\u1a10\u6d74\ucf1c\uafcf\u7d21\u84b8\u3170\u6192\u4dbd\u1dc4\u1b0f", "\ud896\udf68\ud970\udc11\udaa0\ude8a",
        1, 48757, 287773965, 4766956630617039161L, -56745L, false, true, (char) 31285, (char) 5605,
        Double.longBitsToDouble(0x3fbff3c6ee62e1b0L), Double.longBitsToDouble(0x3fba74d706cf85b0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 11, 4, "\uda44\udd57\udb67\udf70\udac6\udd30\udae3\udd6e\udb12\udd1a\uf351\ud8a6\udfd6", "\uc252\ua427\ud0fe\ubffc\u9bcc\u0aa0\u1824\u4a87\u7170\u79c8\u1a10\u6d74\ucf1c\uafcf\u7d21\u6006\u0ead\u6192\u4dbd\u1dc4\u3994", "\ud9e3\udc7b\ud970\udc11\ud9b5\udf37",
        1, 50078, 287779904, 7216870847441477945L, -6569L, false, true, (char) 13224, (char) 37679,
        Double.longBitsToDouble(0x3fdb1b050b98b86cL), Double.longBitsToDouble(0x3fe4d4a250d9f0b6L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 11, 8, "\ud977\udd4d\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\ud9ec\udc9a\ud8a6\udfd6", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824\u090e\ua363\u2356\u1a10\u6d74\ucf1c\uafcf\u7d21\u67b9\u3170\u6192\u4dbd\u1dc4\u1b0f", "\ud896\udf68\ud970\udc11\udaa0\ude8a",
        1, 48757, 287773965, 4766956630617039161L, -56745L, false, true, (char) 31285, (char) 5605,
        Double.longBitsToDouble(0x3fbff3c6ee62e1b0L), Double.longBitsToDouble(0x3fba74d706cf85b0L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Long:141 |a0=[B:[[99, 42]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 9, 8, "\ud893\udc5a", "\u879d\ub30b\u94d2\u2a73\u8a58\ucfd7\u5df9\u05f9\ua3d8\u092d\u13d8\u12d3", "\u4031\udb3f\udfac\u5be7",
        16, 83870, -1736494468, 4584411231991296111L, -8790L, false, true, (char) 34950, (char) 33402,
        Double.longBitsToDouble(0x3feedaf98479b082L), Double.longBitsToDouble(0x3fde97ab58b8d87eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 5, 6, "\ud916\udf15\ud981\udc54\ud9db\udeba", "\ubb43\u3cc4\ub959\u89d1\u5ae7\u05f9\u76d8\u5e07\u00ec\u785d\u1824\u090e\ud54a\u93af\u024f\u9662\u4550\uafcf\u7d21\u67b9\uc9dc\u4cc2\uba72", "\uda61\udd4d\ud8ea\udfb4\udafe\udffd\ud997\uddf7",
        4, 53897, -137175355, -3886194227579941311L, -47417L, false, false, (char) 47200, (char) 29989,
        Double.longBitsToDouble(0x3fe1b93d550fad1bL), Double.longBitsToDouble(0x3fe4c10d08ef64ddL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 8, 6, "\ud916\udf15\ud981\udc54\ud9db\udeba", "\ubbdf\u3cc4\ub959\u89d1\u5ae7\u05f9\u76d8\u5e07\u00ec\u785d\u1824\u090e\ud54a\u6f3e\u016f\u58f5\u4550\uafcf\u7d21\u67b9\uc9dc\u4cc2\uba72", "\uda1f\udecc\ud8ea\udfb4\udafe\udffd\ud997\uddf7",
        4, 53897, -137175355, -3886194227579941311L, -47417L, false, false, (char) 47200, (char) 29989,
        Double.longBitsToDouble(0x3fe1b93d550fad1bL), Double.longBitsToDouble(0x3fe4c10d08ef64ddL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 9, 8, "\ud916\udf15\ud981\udc54\ud9db\udeba", "\ubbdf\u3cc4\ub959\u89d1\u5ae7\u05f9\u5d70\u5e07\u00ec\u785d\u1824\u4d7f\u3d4e\u6f3e\u5b20\u58f5\u4550\uca89\u92ea\u68ff\uc9dc\u4cc2\uba72", "\uda1f\udecc\ud8ea\udfb4\udafe\udffd\ud997\uddf7",
        4, 53897, -137175355, -3886194227579941311L, 78054L, true, false, (char) 15725, (char) 16055,
        Double.longBitsToDouble(0x3fab61a95025b420L), Double.longBitsToDouble(0x3fe4c10d08ef64ddL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 9, 6, "\uda2a\udfa8\udaf4\udf77\ud8e2\ude6d", "\ubbdf\u40ea\ub959\u89d1\u5ae7\u05f9\u76d8\u5e07\u00ec\u785d\u1824\ub49b\u1514\u8a40\u2732\u683d\u4550\uafcf\u7d21\u67b9\uc9dc\u4cc2\uba72\u8fb3\u9d99\u3702", "\ud997\uddf7\ud8d7\ude63\ud948\udccc\uda81\ude49\ud942\udfc3\uda6e\udca6\ud86d\udd42\uda08\udf97\udb3d\udd01\udb5d\uddaa\ud999\udca7",
        2, 47531, 1692213912, 6285222906604117839L, -25253L, false, true, (char) 30143, (char) 20901,
        Double.longBitsToDouble(0x3fe66f7bae75f806L), Double.longBitsToDouble(0x3fb87eb44e0af700L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 6, "\ud916\udee6\ud981\udc54\ud9db\udeba\uda90\udc3b\udbc8\ude2a\udbe2\ude97\udafd\udd8e\udb10\udcfa\ud885\udef0\ud9fc\ude08\ud9f1\udf63\ud891\udec4\uda9d\udf80\ud921\udc9c\udbf4\udc83\uda80\udf5e\ud89d\udea2\ud9ca\udfcd\u7183\uda47\udd68\ud85a\udf33\ud93c\uddfc", "\u67b9\u41f5", "\udb86\uddbc",
        0, 36862, 2058732665, -2346280944569809234L, 16031L, true, false, (char) 28356, (char) 45639,
        Double.longBitsToDouble(0x3fcdf419aa9ac2acL), Double.longBitsToDouble(0x3fe1a44918cd2f94L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 0, "", "\u3948\u872a\ub30b\ubbdf\u9fba", "\uda34\udfdb\ud9f8\udd2b\ud892\udfd4\uda5c\udde2\ud831\udd5a\udbd6\udd87\uda53\udc98",
        13, -749, 1915224064, -766141861225235738L, -99876L, false, false, (char) 52364, (char) 38,
        Double.longBitsToDouble(0x3d1b000000000000L), Double.longBitsToDouble(0x3fe0ede006b0f3caL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Integer:-988 |a1=[B:[[-55, -55, -88, -52, -100, 112, -12]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 9, 6, "\udbdf\uddef\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\uaf46", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824", "\ud8dd\udd23",
        12, -1000, 1358954496, -7458186948677527110L, 6476L, false, true, (char) 50162, (char) 54828,
        Double.longBitsToDouble(0x3fe5879e54db5f30L), Double.longBitsToDouble(0x3fbe672faf4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:-970\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 0, "\ud977\udd4d", "\u872a\ub30b\ubbdf", "\udb3b\udcf7\000\ud9f1\udf63\udbd4\udce0\uda13\udc49\ud831\udd5a\udbd8\udec6\uda80\udf5e\ud89d\udea2\udafd\udd83\ud8dd\udd23\000\udaef\udcd6",
        30, -1000, 0, -1513209476815626220L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fbe40002f4bd5a8L), Double.longBitsToDouble(0x3fe4fbb543a1b720L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Integer:-990 |a1=[B:[[-6, -37, -81]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 5, 0, "\ud977\udd4d", "\u872a\ub30b\ubbdf", "\uda3e\udcb9\uda2b\udf44\ud9f1\udf63\ud89c\udfc4\ud809\ude9b\ud831\udd5a\udbd8\uddfd\uda80\udf5e\u91e7\udad1\udd88\ud8dd\udd23\uda47\udd68\udb2d\udfbc",
        10, -1000, 1067391418, -1502249068168585196L, -94768L, true, false, (char) 33402, (char) 60682,
        Double.longBitsToDouble(0x3fbe672f874bd5a8L), Double.longBitsToDouble(0x3feb67d01c5c1f9dL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 9, 10, "\udb9a\udefe\udafa\udf0e", "\ub30b\ubbdf\u3cc4\u8a58\ucfa9\u5df9\u05f9\u56dd\u5212\u9a09\u0acd\u1824\u090e\uae2e\uaf1e", "\uda3e\udca4\ud9dc\udf75\udb47\udd79\uda9f\udc75",
        0, 53750, -1139807344, 8987390739637789351L, -19225L, true, false, (char) 28643, (char) 19749,
        Double.longBitsToDouble(0x3fded2ea645c7d3aL), Double.longBitsToDouble(0x3fe859296a8455c2L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Long:590 |a0=[B:[[71, 29, 53, 89, 95, 6, -119, 110]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 10, 1, "\ud977\udd4d\uda65\udf89\ud98f\udf36\udbb9\udf9e\udb76\udf19\udbe2\udef5\udad5\uddde\ud904\udde7\uda3d\udfd2\udb57\udd5a\ud977\udef8\uda8c\udf93\udacd\uddf5\ud83f\ude38\uda5a\udec7\uda80\udf5e\udbdb\udc42\ud9d5\udc3e\ud9d3\udfd1\udba7\ude56\udb2d\udfbc\udab2\udfdf\ud9d9\udc62\udad8\ude83\udb07\udcdd\ud938\udef9\ud93c\udd60\ue78f\udb16\udd94\ud81f\udc4c\uda47\udf01\ud8ea\udfb4\ud8bd\udebc\udaae\udc3f\uda61\udf35\ud9e8\udc6a\udb0b\udfe2\uda19\udfa1\u43ed\udbb7\udd2d\udab9\udfec\udb98\udd7c\ud9d6\udf1e", "\u6f18\u55fc\u2f52\u9a39\u1df2", "\ud91e\udc54\udb02\uddeb\ud8f5\udcc2\udaf1\udcce\ud882\udeb9\ud93c\udd85\uda0d\udca0\ud8ac\udc31\udbbd\udd8f\uda85\udcab\uda59\udca7\ud8ba\udf81\ud9c1\uddbd\udad2\udf23\udbbe\udd27\uda6a\uddcf\uda2d\ude6b\ud9b3\uddaa\ud997\udf48\ud87d\uddeb\ud86d\ude40\udbd5\udf98\ud8e9\ude06\udb8f\ude65\ud945\udcd2\udb5d\udfa5\udb1a\udfc7\uda8d\ude3d\udadf\udf42\udb17\udfec\ud906\udc21\udbd8\udea4",
        6, 68973, -24190018, 5347754156021166659L, -91420L, true, false, (char) 50182, (char) 300,
        Double.longBitsToDouble(0x3fb76790e505cc88L), Double.longBitsToDouble(0x3fd1a66fd08d7770L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Long:100 |a0=[B:[[71, 29]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 3, 1, "\ud977\udd4d", "\ub6da\ub30b\ubbdf", "\uda3e\udcb9\udb57\udd5a\ud977\udef8\uda8c\udf93\udacd\uddf5\ud83f\ude38\uda5a\udec7\001\000\ud9d5\udc1f\ud9d3\udfd1\udba7\ude56\udb2d\udfbc",
        51, 98532, 10426810, 0L, -94768L, true, false, (char) 33402, (char) 19467,
        Double.longBitsToDouble(0x3fbe67002f4bd5a8L), Double.longBitsToDouble(0x3fe0000004fe696fL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:590 |a0=[B:[[71, 29, 53, 89, 95, 6, -119, 110]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 11, 1, "\ud977\udd4d\uda65\udf89\ud98f\udf36\udbb9\udf9e\udb76\udf19\udbe2\udef5\udad5\uddde\uda5e\udc64\uda3e\udcb9\udb57\udd5a\ud9ab\ude52\uda8c\udf93\udacd\uddf5\ud83f\ude38\uda5a\udec7\uda80\udf5e\udbdb\udc42\ud9d5\udc3e\ud9d3\udfd1\udba7\ude56\udb2d\udfbc\udab2\udfdf\ud9d9\udc62\udad8\ude83\udb07\udcdd\ud938\udef9\ud93c\udd60\ue78f\udb16\udd94\ud81f\udc4c\ud9b9\uddba\ud89c\ude4d\ud8bd\udebc\udaae\udc3f\uda61\udf35\ud9e8\udc6a\udb0b\udfe2\uda19\udfa1\u43ed\udbb7\udd2d\udab9\udfec\udb98\uddbb\ud9d6\udf1e", "\u6f18\u55fc\u2f52\u9a39\u1df2", "\ud91e\udc54\ud9fb\udf08\ud928\uddff\udaf1\udd62\ud882\udeb9\ud93c\udd85\uda0d\udca0\ud8ac\udc31\udbbd\udd8f\uda85\udcab\uda59\udca7\ud8ba\udf81\ud9c1\uddbd\udad2\udf23\udbbe\udd27\uda6a\uddcf\uda2d\ude6b\ud9b3\uddaa\ud997\udf48\ud87d\uddeb\ud86d\ude40\udbd5\udf98\ud8e9\ude06\udb8f\ude65\ud945\udcd2\udb5d\udfa5\udb1a\udfc7\u4f20\ud8a5\udfb9\udb1b\udf03\ud906\udc21\udbd8\udea4",
        6, 68973, -24190018, 5347754156021166659L, 41593L, true, false, (char) 50182, (char) 226,
        Double.longBitsToDouble(0x3fb76790e505cc88L), Double.longBitsToDouble(0x3fd1a66fd08d7770L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 5, 6, "\ud977\udd37\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb76\udf19\udbe2\udef5\udafd\udd8e", "\u5df9\u05f9\u96d8\ubd51\ub28a\u0aa0\u1824\u090e\ua363\u25b6\u016f\u2c38\ucf1c", "\ud9c7\udf34\ud928\udcfc",
        45, -912, 1378232099, 6916907909280361691L, 17818L, false, false, (char) 52009, (char) 42946,
        Double.longBitsToDouble(0x3fd8bf8ed98087f4L), Double.longBitsToDouble(0x3f950174cf05c220L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 1, 0, "\udaeb\udc95\uda25\udfde\ud9db\udf1f\ud9d4\udc1d\uda39\ude0f\u14f6\udafd\udd8e\udaaa\udd0d\ud9cf\udc68\ud816\udfc5\ud9fd\udf77\ud880\udec1\ud809\udedb\ud831\udd5a\udbd8\udec6\ud8ae\udf52\ud89d\udea2", "\u016f\u2c38\ucf1c\uafcf\u7d21\u37b0\u3211\u4cc2", "\ud830\udf4c",
        0, 48665, 262219689, -7281207912333666462L, 60989L, true, true, (char) 19427, (char) 22587,
        Double.longBitsToDouble(0x3fbb0d7e99c80f98L), Double.longBitsToDouble(0x3fd251b4aa50216aL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 5, 7, "\ue48d\ud86c\udf17\udb3a\udc72\ud9c6\udef3\udb76\udee0\ud830\udffc\udaf3\ude8e", "\u6dcd\u6090\ua3d8", "\uc9df\ud938\udc0c\udaaf\udcf1\udb0a\udd29",
        7, 84697, 1304675046, 5849610837097919100L, 13148L, false, false, (char) 34448, (char) 4530,
        Double.longBitsToDouble(0x3fe35269a6c7c006L), Double.longBitsToDouble(0x3fcb6be9b1e728d8L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.String:\u00ed\u0082 |a0=[B:[[44, -94, -7, 15, -92, -19, -126, 0]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 5, 10, "\u4f5c\udbd2\udd29?\ud9d4\udc1d\u00b2\ud830\udf30\udaf3\ude8e", "\u5df9\u05f9\ua3d8", "\udb80\udc45\ufe1a\ud9d5\udf8e\uda7b\ude44",
        5, 84697, -942882074, 280264467021824L, 92623L, false, false, (char) 39679, (char) 60648,
        Double.longBitsToDouble(0x3fe35269a6c7c006L), Double.longBitsToDouble(0x3fcb6be9b1e672f8L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 6, 10, "\uda23\udc61\uda65\udf89\ud996\udd31", "\ubbdf\u3cc4\u8a58\ucfd7\ub608\u05f9\ua3d8\ubffc\u9bcc\u0aa0\u1824\u090e\ua363\u1a9f\u61b1\u199b\u4cd3\uafcf\u4308\ud1a5\u3170\ubd1c\u07d1", "\ud9b5\udd22\uda25\udfda\ud9df\udd6d\ud8c4\udfb6\ud8b2\udf16\udb73\udcc3\uda78\ude18\ud803\udea5\udac2\udf81\ud8d8\udf76\uda06\uded1\udb75\udcc0\ud8a9\udfa6\ud948\udc60\udac3\ude19\ud896\udd79\ud9f2\udce6\udbd9\udc52\ud8b8\ude54\ud86c\udd26\ud99b\udee1\udafb\udc2f\uda98\udd2e\uda2d\udd0c\udb49\ude37\udab5\ude76\ud8bc\ude89\uda72\udd8c\ud839\udff0\uda67\udec6\ud9ba\udf7e",
        1, 42877, -196860597, 9070353207194494099L, -76499L, false, true, (char) 28473, (char) 27591,
        Double.longBitsToDouble(0x3fde6485fa51b31eL), Double.longBitsToDouble(0x3feb0b633370948bL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:-988\0121=java.lang.Integer:-988\012",
        Z.run(T, 2, 6, 6, 0, "\ue200\000\000\000\udb76\udf19\u00cc\000", "\u5df9\u05f9\ua3d8\ubffc\u9bcc\u0413\ua2d1", "\ud8dd\udcba",
        12, -1000, 0, 1056964608L, -100000L, false, false, (char) 144, (char) 43131,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fbe40002fa60d90L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Long:208 |a0=[B:[[-48]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 0, "\000", "\000\u5420\u00cc", "\uda48\udfb9",
        7, 85309, 1925902549, -4539627571864005146L, 93535L, true, true, (char) 58690, (char) 63641,
        Double.longBitsToDouble(0x3fc273db47923bc4L), Double.longBitsToDouble(0x3fcabe8c6e563a24L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Integer:-745\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 0, "", "", "",
        51, -796, 0, 2089670225895085301L, -14443L, true, false, (char) 12746, (char) 55014,
        Double.longBitsToDouble(0x3fe64bf3d7edffddL), Double.longBitsToDouble(0x3fde71a8f9f6a090L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 4, 8, "", "\ua1d3\ubf22\u57df\u00cc\u092d\u04f6\ucf38\u5df9\u05f9\u9ffd\u3325\u38fc\u87f3", "\ud907\ude0b\udafa\udfd8",
        1, 94141, -1885290690, 5478407646138819982L, -51464L, true, false, (char) 18542, (char) 44274,
        Double.longBitsToDouble(0x3fb1ffc70d20ce00L), Double.longBitsToDouble(0x3fedba445655b8cbL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-73, -110, 73, 2, -106, -122, -92, -19]]\0121=java.lang.Boolean:false |a0=[B:[[-73, -110, 73, 2, -106, -122, -92, -19]]\012",
        Z.run(T, 2, 9, 9, 6, "\ud9e7\uddc2\ud979\ude32\ud8c6\uddb6\ud9d4\udc1d\udb4f\udda1\uda33\udd5d\ud8e8\ude9f", "\uc17f\u5360\u2105\ubffc\ua593\u54a9\ub4e9", "\udaa3\udf34\uda47\udd68\ud830\uddc3\ud9c5\udc07\ud9da\udc40\udb47\uddaf\ud9c7\udf34\udabb\udc65\uda31\ude2c",
        2, 62144, 1596986372, -7148580559917909768L, 83069L, false, false, (char) 22520, (char) 7027,
        Double.longBitsToDouble(0x3fe1d90abd6c6b11L), Double.longBitsToDouble(0x3fda5b2512883e98L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 11, 8, "\ud83d\udd50\ud96b\udd2a\ud9db\udeba\udbed\ude26\udb9c\udf23\ud8af\ude3b\ud92e\ude08\uda91\udf09", "\u05f9\u4676\u3e9c\ucbd2\u0aa0\u1824\u4280\ua34c\u25b6\ud678\u74c5\u0800\u1ca2\u7d21\u67b9\u5c11\ucd30\ud131\u43c7\u5c41\u5832\u27d9\u3bef", "\udb40\udcc3\ud882\udf98\udb12\udf50\ud9b3\udf51\ud8cf\udca0\udb4e\udf61\uda51\udde4\udb03\udc7d\ud989\ude4e",
        3, 84999, 936853825, 632051806433987807L, 48006L, false, true, (char) 63330, (char) 17170,
        Double.longBitsToDouble(0x3feae33098a9b912L), Double.longBitsToDouble(0x3fd24157db1a6cbcL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[78, 0, 53, 89, -85, -118, -92, -19]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 5, 8, "\uda7e\udc30\uda65\udf89\ud9db\udeba\ud9d4\udc1d\udb92\udf19\ud9ec\udc9a\ud8a6\udfd6", "\ua7e4\u05f9\ua3d8\u212c\u4ed0\u74e1\u0f81\u08d7\ua363\u2356\u1a10\u601d\u7f53\uafcf\u7d21\u753e\u3170\u6192\u4dbd\u1dc4\u20ed", "\ud896\udf68\ud970\udc11\udaa0\ude8a",
        1, 48757, -1160202483, 6559734464131655238L, 8791L, true, true, (char) 50646, (char) 18012,
        Double.longBitsToDouble(0x3fbff3c6ee62e1b0L), Double.longBitsToDouble(0x3fba74d73ecf85b0L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:-880 |a1=[B:[[-37, -81, -108, 40, 121, -55, -55, -84]]\0121=java.lang.Integer:-880 |a1=[B:[[-37, -81, -108, 40, 121, -55, -55, -84]]\012",
        Z.run(T, 2, 6, 6, 4, "\udb9a\udefe\udafa\udf0e", "\ub30b\ubbdf\u3cc4\u8a58\ucfa9\u5df9\u05f9\u4bdc\u5212\u9a09\u0acd\u1824\u090e\uae2e\u91cc", "\udaa9\udd79\ud9dc\udfaf\udb47\udd79\uda54\uddb0\ud848\udec4\ud93c\udd60",
        21, -901, -1379999065, 3008102028153293538L, -57781L, true, false, (char) 62610, (char) 6347,
        Double.longBitsToDouble(0x3fe059296ed9c596L), Double.longBitsToDouble(0x3fede5ce8f73ae7eL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-75, -83, -109, 61, 93, 96, 1, 60]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 11, 1, "\ud9e5\udfdd\ud9c3\udf6d\ud88d\ude90\udb31\udc6c\udb76\udf02\udbe2\udef5\udad5\uddde\uda5e\udc64\uda3e\udcb9\ud92d\ude45\udbff\ude6c\ud828\udfe4\ud8a5\udf23\uda6c\udc85\uda41\udf10\uda80\udf5e\udbdb\udc42\ud9d5\udc3e\ud9d3\udfd1\udba7\ude56\udb2d\udfbc\udab2\udfdf\ud9cf\udc62\udad8\ude83\udb07\udcdd\u818e\ud822\udd33\ud98a\ude00\udb16\udd94\ud81f\udc4c\ud9b9\uddba\ud89c\ude4d\ud8bd\udebc\udaae\udc3f\uda61\udf35\ud864\udd29\udb0b\udfe2\ud9c9\udc58\u43f3\udbb7\udd2d\udab9\udfec\udb98\uddbb\udaa3\udc39", "\u025b\u4291\u2f52\u9a39\u1df2", "\ud91e\udc54\ud9fb\udf08\ud928\uddff\udaf1\udd62\ud882\udeb9\ud93c\udd85\uda0d\udca0\ud8ac\udc31\udbbd\udd8f\uda85\udcab\uda59\udca7\ud984\udf61\ud9c1\ude8b\uda02\udf1b\udbbe\udd27\uda6a\uddcf\uda2d\ude6b\ud9b3\uddaa\ud997\udf48\ud87d\uddeb\ud86d\ude40\udbd5\udf98\ud8e9\ude06\udb8f\ude65\ud945\udcd2\udb5d\udfa5\udb1a\udfc7\ud9c4\ude79\ud8af\udcef\udb1b\udf03\ud906\udc21\udbd8\udea4",
        6, 68973, -24190018, 3546314305072953778L, 41593L, true, false, (char) 50182, (char) 226,
        Double.longBitsToDouble(0x3fb76790e505cc88L), Double.longBitsToDouble(0x3fd1a66fda8d7770L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.String:\u00ed\u0082 |a0=[B:[[44, -94, -7, 15, -92, -19, -126, 0]]\0121=java.lang.String:\u00ed\u0082 |a0=[B:[[44, -94, -7, 15, -92, -19, -126, 0]]\012",
        Z.run(T, 2, 10, 10, 4, "\u4f5c\udbd2\udd29?\ud9d4\udc1d\u00b2\ud830\udf30\udaf3\ude8e", "\u5df9\u05f9\ua3d8", "\udb80\udc45\ufe1a\ud9d5\udf8e\uda7b\ude44",
        5, 84697, -942882074, 280264467021824L, 92623L, false, false, (char) 39679, (char) 60648,
        Double.longBitsToDouble(0x3fe35269a6c7c006L), Double.longBitsToDouble(0x3fcb6be9b1e672f8L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[78, 0, 53, 89, -85, -118, -92, -19]]\0121=java.lang.Long:0 |a0=[B:[[78, 0, 53, 89, -85, -118, -92, -19]]\012",
        Z.run(T, 2, 11, 11, 9, "\uda7e\udc30\uda65\udf89\ud9db\udeba\ud9d4\udc1d\uda25\ude02\ud9eb\udff2\ud8a6\udfd6", "\ua7e4\ua07a\ua3d8\u212c\u4ed0\u74e1\u8917\u08db\ua363\u2356\u1a10\u601d\u7f53\uafcf\u7d21\uab77\u319a\u6192\u4dbd\u1dc4\u20ed", "\ud896\udf68\ud970\udc11\udaa0\ude8a",
        1, 8542, -1160202283, 5606483742847952497L, 8791L, true, true, (char) 22324, (char) 15865,
        Double.longBitsToDouble(0x3fbff3c6ee62e1b0L), Double.longBitsToDouble(0x3feb4e9ae7b76698L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-75, -83, -109, 61, 93, 96, 1, 60]]\0121=java.lang.Boolean:true |a0=[B:[[-75, -83, -109, 61, 93, 96, 1, 60]]\012",
        Z.run(T, 2, 9, 9, 1, "\ud9e5\udfdd\ud9c3\udf6d\ud88d\ude90\udb31\udc6c\ud94b\ude2c\ud945\udccb\udad5\udd7a\ud816\udf89\ud92b\udff1\ud88c\udc9b\ud970\udc18\ud829\udc25\ud8a5\udf23\udae0\udfff\udb45\ude00\udaa2\udfab\udbdb\udc42\ud9d5\udc3e\ud9d3\udfd1\ud85e\udd9e\udb2d\udfbc\udab2\udfdf\ud9cf\udc62\udad8\ude83\udb07\udcdd\u818e\ud822\udd33\ud98a\ude00\udb16\udd94\ud81f\udc4c\ud9b9\uddba\udb8b\udfe3\ud8bd\udebc\udaae\udc3f\uda61\udf35\ud864\udd29\udb0b\udfe2\u33dc\ud8a9\udf29\udbd5\ude40\uda92\udd7a\udb98\uddbb\udaa3\udc39", "\u025b\u4291\u2f52\u9a39\u1df2", "\ud9ee\udfbc\uda5d\udf0c\uda73\ude42\udaf1\udd62\ud882\udeb9\ud93c\udd85\ud9c7\udf7d\udae2\udc60\udaee\udc27\uda85\udcab\uda59\udca7\ud984\udf61\ud9c1\ude8b\uda02\udf1b\udbbe\udd27\uda16\udc65\uda2d\ude6b\ud9b3\uddaa\ud997\udf48\ud87d\uddeb\ud8d2\udf26\udb68\ude0c\ud8e9\ude06\udb8f\ude65\uf6d1\udb5d\udfa5\udb26\udc4d\ua346\ud81a\ude09\udb27\udf74\ud906\udc21\udbd8\udea4",
        6, 68973, -24190018, 6508397529903897686L, 28025L, false, true, (char) 50182, (char) 226,
        Double.longBitsToDouble(0x3fb76790e505cc88L), Double.longBitsToDouble(0x3f9e37fda8d77700L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 9, 11, 5, "\ud848\ude7a\udb3b\udfd8\ud9db\udf71\udb44\udf6a\udb76\udf19\udbe2\udef5\udafd\udde4", "\u2a60\u05f9\u2ce3\ud0d6\u9c17", "\ud89d\udea2\udb08\uddc5\uda86\uddb8",
        50, 90825, -1284553498, 7684587241064131546L, 6476L, false, true, (char) 50162, (char) 54828,
        Double.longBitsToDouble(0x3fda8f3cac265328L), Double.longBitsToDouble(0x3fbe67372f4bd5a8L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Long:3 |a0=[B:[[-95, -63, -124, 121, 41, -116, -125, -86]]\0121=java.lang.Long:3 |a0=[B:[[-95, -63, -124, 121, 41, -116, -125, -86]]\012",
        Z.run(T, 2, 11, 11, 9, "\udad1\uddf1\ud9b4\udda9\u3059\udbbc\udeb3\ud9da\udc6f\ud8a4\udef3", "\ucfd7\u5e0e\u88ef\u9d36\ubffc\u6c3e\u34c5\u0d0c\ubc09\u1c7e\ub887\u26f4\u0bf5", "\udb47\udd79\ud9c7\udf34\ud8dc\udcf6\ud824\ude47\ud84b\udd17\ud935\udc56\udb6f\ude1d\uda30\udd54\ud8d1\udde5\uda62\udd4e",
        6, -182, 1649626610, 8575175028647933629L, 39075L, false, true, (char) 9211, (char) 41874,
        Double.longBitsToDouble(0x3fed01085c982e00L), Double.longBitsToDouble(0x3fa982fa647784f0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 5, 8, "\ud9b0\udc3b\ud870\uddb9\ud8b0\udff4\ud988\udf4c\ud8f4\udc89\ud92e\udf8b\udbfa\ude74", "\u3de3\u05f9\ua3d8\u212c\u9bcc\u0aa0", "\udaf6\ude83\ud968\udc4a\uda23\udf31",
        0, 83870, -1736494468, 4584411231991248239L, 10922L, true, true, (char) 16475, (char) 33402,
        Double.longBitsToDouble(0x3fda4c0308f339d0L), Double.longBitsToDouble(0x3fde97ab552aba8cL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Long:102 |a0=[B:[[-26, -74, 64, 36, -85, -118, 96, 11]]\0121=java.lang.Boolean:false |a0=[B:[[-26, -74, 64, 36, -85, -118, 96, 11]]\012",
        Z.run(T, 2, 11, 9, 6, "\ud916\udee6\ud970\udd54\ud9db\udeba\uda90\udc3b\udbc8\ude2a\u336e\uaf00\000\u1884\ud9fc\ude08\udadc\udd2d\ud891\udec4\uda9d\udf80\ud921\udc9c\udbf4\udc83\uda80\udf5e\ud89d\udea2\000\u7183\uda47\udd68\ud85a\udf33\ud93c\uddfc", "\u67b9\u41f5", "\udb86\uddbc",
        0, -834, 2058732544, -2346280944569809234L, 16031L, true, false, (char) 28356, (char) 45639,
        Double.longBitsToDouble(0x3fcdf419aa9ac2acL), Double.longBitsToDouble(0x3fe1a44918cd2f94L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 9, 6, "\uda50\udc97\udb1f\udc22\ud9db\udeba\uda90\udc3b\udbc8\ude2a\udbe2\ude97\udafd\udd8e\udb10\udcfa\ud885\udef0\ud9fc\ude08\ud9f1\udf63\ud891\udec4\uda9d\udf80\ud921\udc9c\udbf4\udc83\uda80\udf5e\ud89d\udea2\ud9ca\udfcd\u7183\uda47\udd68\ud85a\udf33\ud93c\uddfc", "\u67b9\u41f5", "\udb86\uddbc",
        0, 36862, 2058732665, -2346280944569809234L, 16031L, true, false, (char) 28356, (char) 45639,
        Double.longBitsToDouble(0x3fcdf419aa9ac2acL), Double.longBitsToDouble(0x3fe1a44918cd2f94L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-76, 115, 96, -102, -85, -118, 96, 11]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 11, 6, "\ud9e4\udfa3\ud990\uddca\ud9db\udeba\uda90\udc3b\udbc8\ude2a\udbe2\ude97\udafd\udd8e\ud8ce\udfda\ud836\udf26\ud9fc\ude08\ud9f1\udf63\udb36\udf57\uda9d\udf80\ud921\udc9c\ud855\udcb3\udab1\udfa9\ud89d\udea2\ud9ca\udfcd\u7183\uda47\udd68\ud85a\udf33\ud858\udf8a", "\u67b9\u0543", "\udb86\uddbc",
        0, 36862, 2058732665, 8174972209897751183L, 16031L, true, false, (char) 28356, (char) 22087,
        Double.longBitsToDouble(0x3fe6524deaa621bbL), Double.longBitsToDouble(0x3fe1a44918cd2f94L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[32, 95, 96, -74, -85, -118, 96, 11]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 11, 6, "\ud950\udd8f\ud990\udde6\ud9db\udeba\uda90\udc3b\udbc8\ude2a\udbd9\ude97\udafd\udd8e\ud8ce\udfda\ud836\udf26\ud9fc\ude08\ud9f1\udf63\udb36\udf57\uda9d\udf80\ud921\udc9c\ud855\udcb3\udab1\udfa9\ud89d\udea2\udb67\udd9b\u7183\uda47\udd68\ud85a\udf33\ud858\udf8a", "\u67b9\u0543", "\udb86\uddbc",
        0, 58662, 2058732665, 8174972209897751183L, -5571L, false, false, (char) 600, (char) 30205,
        Double.longBitsToDouble(0x3fe7d6410519278eL), Double.longBitsToDouble(0x3fdb39fe960bf524L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 2, 0, "\ud83d\udd50\ud96b\udd2a\ud9db\udeba\udb24\udf97\ud944\udecd\ud8b1\udd67\ud821\udea1", "\u477a\u05f9\u4676\u3e9c\ucbd2\u0aa0", "\udaf6\ude6c\ud8dd\udd23\uda3d\udf2c",
        1, 3, -1736459026, 4584411231907410031L, -8790L, true, true, (char) 47213, (char) 56665,
        Double.longBitsToDouble(0x3fd648f1c8f3397cL), Double.longBitsToDouble(0x3fde97ab59904120L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.String:\u00d0\u00e4\u00a1 |a0=[B:[[-84, -48, -28, -95, 50, -12, 103, 20]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 3, "\udadc\udc00\ub114\ud9d1\ude62\udb24\udf97\ud944\udecd\ud8b1\udd67\ud821\udea1", "\u477a\u1701\u3721\u3f41\ucbd2\u0aa0", "\udaf6\ude6c\ud8dd\udd23\uda3d\udf2c",
        1, 3, -1736459026, 7827002963614167151L, -8790L, true, false, (char) 40619, (char) 49753,
        Double.longBitsToDouble(0x3fd648f1c8f3397cL), Double.longBitsToDouble(0x3fde97ab59904120L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.String:\u00d0\u00e4\u00a1 |a0=[B:[[-84, -48, -28, -95, 50, -12, 103, 20]]\0121=java.lang.String:\u00d0\u00e4\u00a1 |a0=[B:[[-84, -48, -28, -95, 50, -12, 103, 20]]\012",
        Z.run(T, 2, 10, 10, 6, "\udadc\udc00\ub114\ud9d1\ude62\udb24\udf97\ud944\udecd\ud8b1\udd67\ud821\udea1", "\u477a\u1701\u3721\u3f41\ucbd2\u0aa0", "\udaf6\ude6c\ud8dd\udd23\uda3d\udf2c",
        1, 3, -1736459026, 7827002963614167151L, -8790L, true, false, (char) 40619, (char) 49753,
        Double.longBitsToDouble(0x3fd648f1ceaef57cL), Double.longBitsToDouble(0x3fd22b2ad9904128L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 0, 3, "\ud9b4\udf15\ud9bf\udd1d\ud9d1\ude62\udb24\udf97\ud944\udecd\ud8b1\udd67\ud821\udea1", "\u47e0\u1701\u3721\u3f41\ucbd2\u0aa0", "\udaf6\ude6c\ud8dd\udd23\uda3d\udf2c",
        1, 3, -1736459026, 7827002963614167151L, -8790L, true, false, (char) 40619, (char) 49753,
        Double.longBitsToDouble(0x3fd648f1c8f3397cL), Double.longBitsToDouble(0x3fe064f5a908f737L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=java.lang.String:Invalid byte 1 at offset -1736459184 in '\u042a&' len=3 |a0=[B:[[-84, -48, -86, 38, -95, 50, -12, 103]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 3, 3, "\udadc\udc00\ud9da\udc56\ud9d1\ude62\udb24\udf97\ud944\udecd\ud849\udef5\ud821\udea1", "\u477a\u1701\u3721\ub3c6\ucbd2\u0aa0", "\udaf6\ude6c\ud8dd\udd23\uda3d\udf2c",
        1, 3, -1736459183, 7827002963614167151L, -8790L, true, false, (char) 40619, (char) 49753,
        Double.longBitsToDouble(0x3fd648f1c8f3397cL), Double.longBitsToDouble(0x3fde97ab59904120L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.String:\031\u0081 |a0=[B:[[64, 25, -127, 0, -95, 50, -26, 23]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 3, "\ud870\udf49\udbb1\udc30\ud9d1\ude62\ud916\udc47\u6e61\ud8b1\udd67\ud821\udea1", "\u20a9\uc409\ua97a\u3f41\u49d3\ub29f", "\udaf6\ude6c\uda23\udd26\uda3d\udf2c",
        1, 3, -1741375971, 7827002963614167151L, -5462L, true, true, (char) 11228, (char) 39760,
        Double.longBitsToDouble(0x3fd648f8b8f3397cL), Double.longBitsToDouble(0x3fde97ab5c82ed20L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.String:b\u0081 |a0=[B:[[-35, 98, -127, 0, -95, 50, -26, 23]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 3, "\ud80d\udc92\udbb1\udc30\ud9d1\ude62\ud916\udc47\u6e61\ud8b1\udd67\ud821\udea1", "\u20a9\uc409\u11a5\u20d8\u3597\uc583", "\udaf6\ude6c\uda23\udd26\uda3d\udf2c",
        1, 3, 621039389, -749452070070136146L, 59281L, true, true, (char) 38469, (char) 24887,
        Double.longBitsToDouble(0x3fde97ab5e69a348L), Double.longBitsToDouble(0x3fdcc583ca554002L)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.String:Invalid byte 1 at offset 621039388 in 'b\ufffd{NUL}' len=3 |a0=[B:[[-35, 98, -127, 0, -95, 50, -26, 23]]\0121=java.lang.String:Invalid byte 1 at offset 621039388 in 'b\ufffd{NUL}' len=3 |a0=[B:[[-35, 98, -127, 0, -95, 50, -26, 23]]\012",
        Z.run(T, 2, 2, 2, 3, "\ud80d\udc92\udbb1\udc30\ud9d1\ude62\ud916\udc47\u6e61\ud8b1\udd67\ud821\udea1", "\u36b4\u592b\u11a5\u20d8\u3597\uc583", "\udaf6\ude6c\uda23\udd26\uda3d\udf2c",
        1, 3, 621039389, -749452070070136146L, 59281L, true, true, (char) 38469, (char) 24887,
        Double.longBitsToDouble(0x3fde97ab5e69a348L), Double.longBitsToDouble(0x3fdcc583cb374002L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|computeCheckSum|[B|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|exceptionMessage|[B,int,int,int,byte|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatCheckSumOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongOctalOrBinaryBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatNameBytes|java.lang.String,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatUnsignedOctalString|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseBoolean|[B,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseName|[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctalOrBinary|[B,int,int|static",
    "C|org.apache.commons.compress.archivers.tar.TarUtils|<init>|",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
