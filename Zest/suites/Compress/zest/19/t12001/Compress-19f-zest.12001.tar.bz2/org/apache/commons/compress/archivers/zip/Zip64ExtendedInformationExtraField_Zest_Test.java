package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class Zip64ExtendedInformationExtraField_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 1, 4, 0, 5, "\uda71\udf9e\udb5d\ude8e\udbdf\udcd3\ud90f\uddac", "\u072b\u1102\u72d3\u9af7\ub74f\u9ea1\ucbed\u1162\u3103", "\ud8e6\udc52\udb71\ude38\ud91d\udea7\uda90\ude33\udb45\udeb6\uda52\udfe9\uda1c\udc1a",
        52, 74839, 2097755331, 6721689780525197161L, -1155L, true, false, (char) 3445, (char) 58509,
        Double.longBitsToDouble(0x3fdb0f7ef5d0874eL), Double.longBitsToDouble(0x3fcc9dc166369398L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 1, 4, 0, 5, "\uda5e\ude54\udb5d\udde5\udbdf\udcd3\ud90f\uddac\u5e86\ud8ab\ude2c\uda9b\ude20\ud8b9\udd9c\udaee\udda1\udac5\udea5\udbb4\udd39\uda65\ude35\uda5e\udd99\ud808\uddfb\udb6f\udc27\ud837\udcc1\udba5\uddec\ud947\uddea", "\u3292\u49e7\u5943\u1be5\u7622\u45a5\u70f4\u03cd\u5bf2\u6270\u0232\u4f17\u03f9\u47d7\ub9de\u959f\u38eb\u49f5\ucd43\u321d\u17e1\uce7c\ua6b6\u8417\u7063\uc973\u1142\u0eab\u4172\u852e\u2e6f\u3eb1\u75e9\u105a\u5ca2\uad82\u2495", "\ud8cb\ude39\ud8f5\udfb3\u6c35\uda48\udfa2",
        52, 83555, -619960609, 430636466703833248L, 34250L, false, true, (char) 56258, (char) 65008,
        Double.longBitsToDouble(0x3fe152235e500603L), Double.longBitsToDouble(0x3fe9031a1dbb0dadL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 11, 1, 1, "\ud9b1\ude45", "\u7f43\u2ac3\u6ff5\ud408\u6c31\u7f30\u9af7\u8962\u9ea1\uc98d\u1183\u3103\u2f52\u9ff1\uc8c1", "\uda90\ude33",
        27, 94236, -139349939, 7903330151006830855L, -55351L, true, true, (char) 36730, (char) 28783,
        Double.longBitsToDouble(0x3fd663b28361efdeL), Double.longBitsToDouble(0x3fe6105d34e4ee0bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 1, 13, 0, 5, "\uda71\udf9e\udb5d\ude8e\ud9a1\uddb0", "\u6ff5\u3392\u696e\u72d3\u9af7\ub74f\u798b", "\ud8ac\udedb\ud836\udf14\udad2\udede\ud8db\udd5e\udb71\ude38\ud91d\udea7\uda90\ude33\u8725\ud838\udd77\uda1c\udc1a\udac0\ude9a\ud9ae\ude0d\ud94d\udc21",
        18, 7193, 578245015, 3409649453283942139L, -94253L, false, true, (char) 26641, (char) 61310,
        Double.longBitsToDouble(0x3f89fcaaa38f8340L), Double.longBitsToDouble(0x3fe5f15b3dbab428L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 4, 14, 3, "\uda97\udd99\udbc7\udc0a\udbdf\udcd3\ud90f\uddac\u5e86\ud8ab\ude2c\uda9b\ude20\ud8b9\udd9c\udaee\udda1\udac5\udea5\udbb4\udd39", "\u1fd7\u8780\ub2cb\u9f39\u5fc4\ud29f\uce35\u3292\uc521\uba3d\ube4b\u6c5b\u230c\u0403", "\udbe4\udf9e\ud989\ude51\u8494\ud9c8\udd58\ud938\udcec\uda89\uddac",
        53, 37476, -1492668754, 2145825128363805438L, -54404L, true, true, (char) 40089, (char) 8190,
        Double.longBitsToDouble(0x3fecd3e18faf49c5L), Double.longBitsToDouble(0x3fe685b55fe54d05L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 1, 0, 0, 5, "\uda71\udf9e", "\u7a94\000\000\000\000\u7265\u9af7\ub74f\u9ea1\ucbed\u1162\u3103\u00ea\u271c\uc8c1", "\uda90\ude33",
        -1, 94236, 1367341901, 7903329317783175431L, -84322L, true, true, (char) 23594, (char) 42131,
        Double.longBitsToDouble(0x3fe7d97a8ddcd798L), Double.longBitsToDouble(0x3fd663b28361efdeL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 0, 5, "\uda71\udf9e\udb5d\ude8e\udbdf\udcd3\ud90f\uddac", "\u072b\u1102\u72d3\u9af7\ub74f\u9ea1\ucbed\u1162\u3103", "\ud8e6\udc52\udb71\ude38\ud91d\udea7\uda90\ude33\udb45\udeb6\uda52\udfe9\uda1c\udc1a",
        52, 74839, 2097755331, 6721689780525197161L, -1155L, true, false, (char) 3445, (char) 65079,
        Double.longBitsToDouble(0x3fdb0f7a05d0874eL), Double.longBitsToDouble(0x3fcc9dc166369398L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 13, 8, 12, "\uda72\udc1e\udb5d\ude8e\udbdf\udcd3\ud920\udd43", "\u19fe\u3437\u2a72\u9af7\ub74f\u9ea1\u9bee\u1162\u3103", "\ud8e6\udc52\ud987\udd02\ud91d\udea7\uda90\ude33\udb45\udeb6\uda52\udfe9\uda1c\udc1a",
        52, 20599, 2097755331, 6721689780525197161L, 80903L, true, true, (char) 3363, (char) 59789,
        Double.longBitsToDouble(0x3fdb0f7ef5d0874eL), Double.longBitsToDouble(0x3fcce184e6369398L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 1 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 8, 6, 7, "\uda79\uded7\udb5d\ude8e\udbdf\udcd3\ud90f\uddac\u5e86\ud863\ude9d\ud8ee\uddee\udab8\udf23", "\ud723", "\ud808\uddfb\ud8bd\udecf\ud837\udd74\uda80\uddfa\ud8e6\udc3c\udb71\ude38\ud91d\udea7\uda90\ude33\udb45\udeb6\uda52\udfe9\uda1c\udc1a\udac0\ude9a\ud9ae\ude0d\uda25\udc2d",
        18, 76865, 161025474, 3732364680200986163L, 91091L, false, true, (char) 3340, (char) 30973,
        Double.longBitsToDouble(0x3febcdf817bfe90eL), Double.longBitsToDouble(0x3fe4a76aaa1e3394L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 10, 3, 5, "\uda71\udf9e\udb5d\ude8e\ud936\udcff\ud90f\udd9b\u5e86\ud8ab\ude2c\uda9b\ude20", "\u9af7\u8b28\u8998\ucbed\u1162\u3103\u2f52\u9ff1\uc8c1", "\uda90\ude33\udb45\udeb6\uda52\udfe9\uda1c\udc1a\udac0\ude9a\ud9ae\ude0d\ud94d\udc21\ud910\udebd\uda3a\udc08\udbe4\udf9e",
        2, 14547, -710567878, -581059570220713552L, 88661L, false, true, (char) 11001, (char) 35711,
        Double.longBitsToDouble(0x3fd5eb7fd17cbcd8L), Double.longBitsToDouble(0x3fea3fd5133b8b27L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 1, 0, 0, 5, "\uda71\udf9e\udb5d\ude8e\udbdf\udcd3\udb66\ude7e", "\u072b\u33b6\u29df\u9af7\ub74f\u0f99\u71ee\u1162\u3103", "\ud8e6\udc52\udb71\ude38\ud91d\udea7\uda90\ude33\udb45\udeb6\uda52\udfe9\uda1c\udc1a",
        52, 74839, 2097755331, 6721689780525197161L, -1155L, true, false, (char) 58677, (char) 58509,
        Double.longBitsToDouble(0x3fdb0f7ef5d0874eL), Double.longBitsToDouble(0x3fcc9dc166369398L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 1, 2, 0, 8, "\uda71\udf9e\udb5d\ude8e\udbdf\udcd3\ud90f\uddac", "\u072b\u194e\u72ff\u5262\ub74f\u9ea1\ucbed\u1162\u3103", "\ud8e6\udc3d\udb71\ude38\ud91d\udea7\uda90\ude33\udb45\udeb6\uda52\udfe9\ud852\udc15",
        52, 74839, 2097755331, 6721689780525197161L, -1155L, true, false, (char) 3445, (char) 58509,
        Double.longBitsToDouble(0x3fdb0f7ef5d0874eL), Double.longBitsToDouble(0x3fcc9dc17a369398L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[57, -54, -77, 76, -81, 9, -33, 124]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 1, 1, 0, 5, "\udb69\udefa\udbe3\ude7c\udbdf\udc39\ud90f\uddac", "\u072b\u1102\uc363\u9af7\ub74f\u9ea1\ub67d\u2cf1\u3103", "\ud8e6\udc52\udb71\ude38\ud91d\udea7\uda90\ude33",
        18, 31515, -494929075, 7923718575509307655L, -84322L, true, true, (char) 23515, (char) 42131,
        Double.longBitsToDouble(0x3fd3e9351d6435f6L), Double.longBitsToDouble(0x3fd663b36361efdeL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[46, 106, 45, -75, -81, -93, -33, 124]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 11, 8, "\uda5e\ude9a\udb5d\udde5\udbdf\udcd3\ud90f\uddac\ud878\udd2d\ud948\ude12\udaab\ude7b\ud8b9\udd9c\ud8ea\uddff\udac5\udea5\udbb4\udd39\ud9cd\ude29\uda5e\udd99\ud805\udffb\ud8a9\udc64\ud8b2\uddb2\udba5\udd73\ud947\uddea", "\u3292\u8791\u5943\ub255\u2cea\ua77a\u70f4\u03cd\u2c8a\uae97\u8269\u5fbf\u03f9\u47d7\ub9de\u959f\u5e9d\u7111\u0c76\u8ecb\u3999\uce7c\ua6b6\u8b58\u2ae9\u161b\u1142\u0d1b\u4172\u852e\u2e6f\u1a1b\u75e9\u1f4c\u5c87\uad82\u2495", "\ud8cb\ude39\uda92\udc20\ud94d\udd8a\uda48\udfb5",
        52, 49683, -619960595, 430636468191909024L, -75923L, false, true, (char) 27285, (char) 17491,
        Double.longBitsToDouble(0x3fe1031a1e57ac7cL), Double.longBitsToDouble(0x3fe360800eecb7efL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 15, 0, 2, "\uda5e\ude54\udb5d\udde5\udbdf\udcd3\ud90f\uddac\u5e86\ud8ab\ude2c\uda9b\ude20\ud8b9\udd9c\udaee\udda1\udac5\udea5\udbb4\udd39\uda65\ude35\uda5e\udd99\ud808\uddfb\udb6f\udc27\ud837\udcc1\u8dec\ud947\uddea", "\ub675\u49e7\u5943\u1be5\u7622", "\ud910\udebd\uda3a\udc08\udbe4\udf9e\udb75\udce6\ud985\udc99",
        52, 50526, 1135032752, -1293919681825567516L, -26134L, false, false, (char) 29888, (char) 48121,
        Double.longBitsToDouble(0x3fd8b535d5ef8b22L), Double.longBitsToDouble(0x3fdd7feb958b0c04L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 11, 1, 1, "\000", "", "\ud8ab\ude2c\udae2\udfd9",
        27, 92230, -54812969, -2750698124531053651L, -71114L, false, false, (char) 59679, (char) 36543,
        Double.longBitsToDouble(0x3fe7fe8091fb8ebcL), Double.longBitsToDouble(0x3fe5be01cd88630cL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 1, 1, "\ud9b1\ude45\udb69\udfc7", "\u2ac3\u6ff5\ud408\ud520\u35bd\u9af7\ubfe3\ua931\uc9a5\u1183\u3103", "\ud8c6\udf52\udb71\ude38\ud916\udc8d\uda90\ude33\udb45\udf54\ud8fe\udc20\ud923\udfce",
        51, 74839, -1124534845, 9099590381513067813L, 37948L, false, true, (char) 58805, (char) 52575,
        Double.longBitsToDouble(0x3fcc9dcb623cd0ccL), Double.longBitsToDouble(0x3fd9fb53e78d7df0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=java.lang.Integer:0 |a0=[B:[[-127, 21]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 13, 1, 13, "\ud9b1\ude45", "\u7f43\u03f2\uaa83\ud408\u6c31\u7f30\u9af7\u8962\u9ea1\uc98d\u1183\u3103\u2f52\u9ff1\uc8c1", "\ud8d3\ude3a",
        27, 94236, -139349939, 7903330151006830855L, -55351L, true, true, (char) 36730, (char) 28783,
        Double.longBitsToDouble(0x3fd663b28361efdeL), Double.longBitsToDouble(0x3fe6105d3707767dL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=java.lang.Integer:0 |a0=[B:[[-23, -99]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 7, 1, 1, "\udb19\udecd", "\u7f43\u2ac3\u6ff5\ud408\uc986\u7f30\u9af7\u8962\u9ea1\uad16\u1183\u3103\u2f52\u9ff1\uc8c1\u1e65\ud607\u81e1\u943d\u5943\ube74\u76e4\u45a5\ubd8b\ud2de\uc6f3\uba08\u16b4\u5d7f\ud60c\u575b\u4576\u4969\u9503\u4e94\u9152\u135d", "\ud863\ude1e\udb95\uddc6\ud861\udd15\ud946\ude22\udb0b\ude71",
        7, 84654, 282236580, 6199013088602524551L, 54065L, false, true, (char) 59099, (char) 7436,
        Double.longBitsToDouble(0x3fece49a8ef79c47L), Double.longBitsToDouble(0x3fec71446bde08d6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=null |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 10, 10, 5, "\uda71\udf9e\udb5d\ude8e\ud9a1\uddb0", "\uaa6a\u3392\u696e\u72d3\u9af7\u11df\u78f0", "\ud8ac\udedb\ud865\udeab\udad2\ude94\ud8db\udd5e\udb71\ude38\ud91d\udea7\uda90\ude33\u8725\ud838\udd77\uda1c\udc1a\udac0\ude9a\ud9ae\ude0d\ud94d\udc21",
        18, 7193, 578245015, 3409649453283942139L, -13176L, true, true, (char) 26641, (char) 61310,
        Double.longBitsToDouble(0x3f89fcaaa38f8340L), Double.longBitsToDouble(0x3fe57a833e9cc55fL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 12, 5, "\uda71\udf9e\udb5d\ude8e\ud9a1\uddb0", "\u6ff5\u3392\u696e\ud6f9\ud71c\ub6b7\u5435", "\ud80a\udc8b\ud836\udee0\uda18\udee1\ud8db\udd5e\udb71\ude38\ud91d\udea7\uda90\ude33\u8725\ud838\udd77\uda1c\udc1a\udac0\ude9a\ud9ae\ude0d\ud8d9\ude9f\ud910\udebd\uda3a\udc08\udbd3\udd74\udb75\udce6\ud985\udc99\ud9c8\udd58\ud938\udcec\uda89\uddac\ud828\uddd9\uda65\udf85",
        14, 30762, 1263159112, -120009266474171380L, -39906L, false, true, (char) 8915, (char) 32627,
        Double.longBitsToDouble(0x3fd1ff194b300622L), Double.longBitsToDouble(0x3fdbaa3fffb3b6beL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 15, 14, 3, "\uda97\udd99\udafc\ude84\udbe6\uddf3\ud90f\udde5\u5e86\ud8ab\ude2c\uda9b\ude20\uda16\udc99\udaee\udd35\udac5\udea5\udbb4\udd39", "\u1fd7\u8780\ub2cb\u9f39\u75dc\u90f4\u6bb1\u3292\ucfbd\uba3d\u8e48\u6c5b\u230c\u0403", "\ud958\udf86\ud989\ude51\u8494\ud9c8\udd58\ud938\udcec\uda89\uddac",
        53, 37476, -1492668754, -6005513176341591298L, 76668L, true, true, (char) 40089, (char) 8190,
        Double.longBitsToDouble(0x3fecd3e18faf49c5L), Double.longBitsToDouble(0x3fe685b55fe54d05L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 0, 0, 3, "\uda97\udd99\udbc7\udc0a\udbdf\udcd3\ud90f\uddac\udbf7\udd85\ud8ab\ude2c\uda9b\ude20\udb96\udcca\000\000\000", "\u1fd7", "\udba5\udd34\udbfa\udddc\udba4\uddd9\ud91d\udea7\uda90\ude33\ud86f\udc2a\ud8b3\udc39\uda32\uded6\udaea\udf4f",
        -3, 51427, -103809913, 762121911231009175L, -79008L, false, false, (char) 26821, (char) 62308,
        Double.longBitsToDouble(0x3fe0e03dc5f9fdb0L), Double.longBitsToDouble(0x3fe3479188bfdf3eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 12, 3, "\uda97\udd99\udbc7\udc0a\udbdf\udcd3\ud90f\uddac\ud86b\uddef\udbb8\ude35\uda9b\ude1a\udb45\udd81\uda8d\udf1d\ud90c\ude49\u2fcc", "\u9d77\u622b\ua1a6\ua017\u5fc4\ud29f\uce35\u3292\uc521\uba3d\ube4b\u6c5b\u230c\u0403", "\udbe4\udf9e\ud94c\udc52\u8494\ud9c8\udd58",
        51, 94752, -301264152, -6564404497458155858L, -54404L, true, true, (char) 55557, (char) 9714,
        Double.longBitsToDouble(0x3fecd3e18faf49c5L), Double.longBitsToDouble(0x3fef4971c8e1ea03L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[103, 105, -105, -38, -81, -93, -33, 124]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=java.lang.Integer:0 |a0=[B:[[103, 105, -105, -38, -81, -93, -33, 124]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 1, 1, 3, "\uda97\udd99\udbc7\udc0a\udbdf\udcd3\ud90f\uddac\u5e86\ud8ab\ude2c\uda9b\ude20\ud8b9\udd9c\udaee\udda1\udac5\udea5\udbb4\udd39", "\u1fd7\u8780\u3ab3\u8865\u5f1d\ud29f\uce35\u3292\uc521\uba3d\ube4b\u6c5b\ub620\u85bd", "\udbe4\udf9e\ud989\ude51\u8494\ud863\ude66\ud899\udcca\uda89\udd41\ud828\uddd9\uda65\udf85\udaee\udd6f\ud8e4\ude57\ud876\udc09\ud8fb\udcfa\ud85c\udfd5\udb69\udc0d\udb4e\udc79\uda76\udc10\udbb3\udff2\udace\udf5c",
        37, 80453, 2026236973, 7560392707569191475L, -98297L, false, false, (char) 36706, (char) 26211,
        Double.longBitsToDouble(0x3fe71a7089c9d31dL), Double.longBitsToDouble(0x3fdee1e5b480abf2L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.util.zip.ZipException\012",
        Z.run(T, 2, 12, 0, 5, "\uda71\udf9e", "\u6cab", "",
        -5, -1000, -140632320, -276144542461001055L, -19309L, true, true, (char) 29590, (char) 27167,
        Double.longBitsToDouble(0x3e4bff4000000000L), Double.longBitsToDouble(0x3fd258ebcda38072L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 12, 0, 5, "\uda71\udf9e\udb5d\ude8e\udbdf\udcd3\udbeb\udedc", "\u072b\u1102\u72d3\u9af7\ub74f\u9ea1\ucbed\u1162\u3103\u2f52\u9ff1", "\ud91d\udea7\uda90\ude33\udb3a\udc52\uda32\ude26\ud822\uddd0\udac0\ude9a\ud9ae\ude0d\ud94d\udc21\ud95a\ude8e\uda3a\udc7f\udb05\udd31",
        0, 14547, 992490972, -603267875445720656L, -4996L, true, true, (char) 55826, (char) 61027,
        Double.longBitsToDouble(0x3fbed98dba0d9208L), Double.longBitsToDouble(0x3fe9560e4bf28b88L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 12, 0, 3, "\u7924\uda7e\udd0b\udbdf\udcd3\ud8a7\udfd9\u0875\ud8ab\ude2c", "\u72d3\u9af7\ub74f\uc9e3\ucc35\u1162", "\udb0d\udf08\ud8e6\udc52\udb71\ude38\ud91d\udea7\uda90\ude33\udb45\udeb6\uda52\udfe9\udb66\udd80\udac0\ude9a\ud9ec\ude0c\ud94d\udc21",
        0, 3184, -378582531, -2584649695219933567L, -50064L, false, true, (char) 15759, (char) 58518,
        Double.longBitsToDouble(0x3fd8d1143035ae76L), Double.longBitsToDouble(0x3fcf0b77f0b11c2cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 8, 8, 12, "\uda72\udc1e\udb5d\ude8e\udbdf\udcd3\ud920\udd43", "\u19fe\u3437\u2a72\u9af7\ub74f\u9ea1\u9bee\u1162\u3103", "\ud96e\udc5d\ud987\udd02\ud91d\udea7\ud873\udf98\ud9df\udd7a\uda52\udfe9\uda1c\udc1a\udac0\ude9a",
        9, 85331, 1565015358, 762207198225322391L, 43867L, false, true, (char) 59789, (char) 12704,
        Double.longBitsToDouble(0x3fe7421d38e70c27L), Double.longBitsToDouble(0x3fd8da4e6c18f0b4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 0 |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 3, 3, 5, "\uda71\udf9e\udb5d\ude8e\ud936\udcff\ud90f\udd9b\u5e86\ud8ab\ude2c\uda9b\ude20", "\u9af7\u8b28\u8998\ucbed\u1162\u3103\u2f52\u9ff1\uc8c1", "\uda90\ude33\udb45\udeb6\uda52\udfe9\uda1c\udc1a\udac0\ude9a\ud9ae\ude0d\ud94d\udc21\ud910\udebd\uda3a\udc08\udbe4\udf9e",
        2, 14547, -710567878, -581059570220713552L, 88661L, false, true, (char) 11001, (char) 35711,
        Double.longBitsToDouble(0x3fd5eb7fd17cbcd8L), Double.longBitsToDouble(0x3fea3fd5133b8b27L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=void |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 0, 0, 5, "\uda71\udf9e\udb5d\ude8e\udbdf\udcd3\udb66\ude7e", "\u072b\u33b6\u29df\u9af7\ub74f\u3a90\u71ee\u1162\u3103", "\ud8e6\udc52\udb71\ude38\ud91d\udea7\uda90\ude33\udb45\udeb6\uda52\udfe9\uda1c\udc1a",
        52, 74839, 2097755331, 6721689780525197161L, -1155L, true, false, (char) 3637, (char) 58509,
        Double.longBitsToDouble(0x3fdb0f7ef5d0874eL), Double.longBitsToDouble(0x3fcc9dc166369398L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 7, 7, 8, "\uda5e\ude9a\udb32\ude4f\ud94b\uddc2\udb7e\udfa3\udbec\udc04\ud821\udd22\udaab\ude7b\ud8c6\udfb0\udb28\udcfe\udac5\udeab\udbb4\udd39\ud9cd\ude29\uda5e\udd99\ud805\udffb\ud8a9\udc64\uda03\udcdb\ud8ac\ude13\ud8fe\udcb7\u5dfd\ud927\ude90\uda90\ude33", "\u4b8f\u2cea\ua77a\u70f4\u3a7b\u8da0\uae97", "\ud9c8\udd58",
        -2, 5158, -301264152, -1180934819826081329L, 75330L, false, true, (char) 6947, (char) 36038,
        Double.longBitsToDouble(0x3fba69800ebc7570L), Double.longBitsToDouble(0x3fd0a860234b40faL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[103, 105, -105, -38, -81, -93, -33, 124]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 12, 3, "\uda97\udd99\udbc7\udc0a\udbdf\udcd3\ud90f\uddac\ud86b\uddef\udbb8\ude35", "\ucfc7\u2343\u1daa\u9ea1\ucbed\u9d77", "\udba5\ude12\udbfa\udddc\udba4\uddd9\uda7f\udc79\uda1f\ude29",
        0, 56417, 1725066444, 8768020446238301806L, 66777L, false, false, (char) 23550, (char) 42131,
        Double.longBitsToDouble(0x3fe7df0ccddcd73cL), Double.longBitsToDouble(0x3fd663b28361efdeL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a0=[B:[[103, 105, -105, -38, -81, -93, 125, -88]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 12, 3, "\uda97\udd99\udbc7\udc0a\udbdf\udcd3\ud8ad\udfd8\ud930\udd75\udb6a\udcb0", "\ucfc7\u2343\u1daa\u9ea1\ucbed\u9d77", "\udba5\ude12\udbfa\udddc\udba4\uddd9\uda7f\udc79\uda1f\ude29",
        0, 1513, 1032974758, 8768020446238301806L, 66777L, false, false, (char) 23550, (char) 42131,
        Double.longBitsToDouble(0x3fe7df0ccddcd73cL), Double.longBitsToDouble(0x3fd663b28361efdeL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 1, 4, 0, 5, "\uda28\udd5b\udabe\udf2f\udbdf\udcd3\ud90f\uddac\u5e86\ud8ab\ude2c\uda9b\ude20\ud8b9\udd9c\udaee\udda1\udac5\udea5\udbb4\udd39\uda65\ude35\uda5e\udd99\ud808\uddfb\ud8ac\ude85", "\uba55\u1e65\uce35\u3292\u42eb\u8523\ud45e", "\ud94d\udc21\ud834\udc8f\uda39\udffc\udbe4\udf9e\udb75\udce6\uda76\udc4f",
        13, 66369, 312949168, -1293919836444390172L, 43984L, false, false, (char) 15802, (char) 2754,
        Double.longBitsToDouble(0x3fd1183644b7a96eL), Double.longBitsToDouble(0x3febe99a8920b009L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:@?\012",
        Z.run(T, 2, 2, 2, 11, "\uda97\ude3a\udbc7\udc0a\udbdf\udcd3\ud8d8\udc87\ud93a\udcfe\uda35\udc8c\ud9d7\udcc7\udb3a\udd57\udb0a\udf5b\ud991\udf73\ud96e\udd68", "\u2975\u0acc\u2106\u6bd1\u3851\u7131\u6653\uae4c\u166c\u8a49\u7903\uad2d\u2335\u3ead\u1cb8\u57d7\u404b\u1e15\u138c\u3b4f\ubd26\ud452\u5117\u5171", "\ud9fd\ude70\udbeb\udfe4\ud890\udda2\ud912\ude0f\udb5f\udd82\udae8\udf88\udaf1\udc19\udb39\udc27\udb1b\ude8d\ud949\udc12\ud97c\udfc0\ud8c4\udef3\ud940\udf0b\ud809\udcfe",
        7, 32567, -1459395267, -7681574299217012183L, -8917L, true, true, (char) 47427, (char) 32407,
        Double.longBitsToDouble(0x3feba289ddf833abL), Double.longBitsToDouble(0x3fec3ce94daabcebL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|reparseCentralDirectoryData|boolean,boolean,boolean,boolean|new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|addSizes|[B|new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getCentralDirectoryData||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getCentralDirectoryLength||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getCompressedSize||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getDiskStartNumber||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getHeaderId||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getLocalFileDataData||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getLocalFileDataLength||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getRelativeHeaderOffset||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|getSize||new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|parseFromCentralDirectoryData|[B,int,int|new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|parseFromLocalFileData|[B,int,int|new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|setCompressedSize|org.apache.commons.compress.archivers.zip.ZipEightByteInteger|new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|setDiskStartNumber|org.apache.commons.compress.archivers.zip.ZipLong|new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|setRelativeHeaderOffset|org.apache.commons.compress.archivers.zip.ZipEightByteInteger|new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
    "M|org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField|reparseCentralDirectoryData|boolean,boolean,boolean,boolean|new:org.apache.commons.compress.archivers.zip.Zip64ExtendedInformationExtraField:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
