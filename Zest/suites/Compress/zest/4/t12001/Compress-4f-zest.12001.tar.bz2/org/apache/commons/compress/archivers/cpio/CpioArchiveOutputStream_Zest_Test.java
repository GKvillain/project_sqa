package org.apache.commons.compress.archivers.cpio;
import org.junit.Test;
import static org.junit.Assert.*;
public class CpioArchiveOutputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\ub9ba", "\uda04\udcbc",
        30, 84383, 2067581283, -5498506127951853359L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1", "\uc8f4\ud978\udfdc\ud884\udfbd\udacc\ude57\ud8dc\udf93\ud851\udc12\ud87f\udcef\udad5\udf9e\udad3\udfb1\uda87\udd4b",
        57, 17656, 1182839672, -8295925314605020368L, 92738L, false, true, (char) 20650, (char) 59096,
        Double.longBitsToDouble(0x3fe70094a6fd54a0L), Double.longBitsToDouble(0x3fe0abb59eec3da3L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 1, 6, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\udad3\udd58\ud9f0\uddf3\udbdb\udc91\uda6a\ude08\udae8\udebb\udb69\ude3a\ud8ae\udd82\udb08\ude8c\ud962\udd36", "\ubb0c\u38d0\u563d\uafda\ub819\u9d82\u176a\u2bc4\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\ua73c\u29a3\u0570\u5f07\u4b6d\uad05\u42ba\u849c\u49e8\u7266\ud562\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 27463, 2067581438, -5498334604641236783L, -26375L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 18, 7, "\ud9e5\udcb0", "\u6b85\u795e\u4ef2\u8c74", "\udae8\udebb\udb69\ude3a",
        -5, 22859, -1509219411, 2577793247405420109L, -100000L, true, true, (char) 40512, (char) 65012,
        Double.longBitsToDouble(0x3fc6f5184654102cL), Double.longBitsToDouble(0x3fc4e4d564cab280L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 1, 2, 18, 5, "\ud8df\udd4d\ud8d5\udcaf\udbbd\udd9c\uda86\udc81\ud981\udf1c\udba8\udcf5\ud9ab\ude44", "\u548b\u4d3b", "\udb6d\ude5f\udac2\udf68",
        10, 20099, -230620901, 7075437936014277647L, -91991L, true, true, (char) 8781, (char) 22367,
        Double.longBitsToDouble(0x3feb445dc74802deL), Double.longBitsToDouble(0x3fe03a8a2a2b7533L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 4, 7, "\ud9e5\udcb0\udb85\udd4a\ud85f\ude7c\uda86\udc81\ud981\udf1c\uda45\uddf1\ud9ea\udf45\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\udabb\ude16\ud849\udd1b\udb7e\udd46", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u78ef\u661c\u7859\uae20\u5cc3\u0579\u5f07\u4b6d\u2cba\u3481\uc78c\ua1a0\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 9, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\u1e9a\u38bd\u75b1\uafda\ub819\u9d82\u57fd\u4751\u7728\u0a21\u3f9b\ua02b\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\u2ea8\u6101\uc1eb\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, -402536093, -5434117468603873071L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c630130960L), Double.longBitsToDouble(0x3fdcc70deda0ee7eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 3, 15, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u0453\u39c8\u55d6\uaf60\u03be\u3f9b\u78ef\uaeec\uc80a\u32ba\u5da4\u0579\u09fe\u1201\u4226\u4c84\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u1082", "\uda04\udcbc",
        30, 3943, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 11, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u78ef\u23fc\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71", "\u2c78\ub679\u8817\ua936\u548b\u4d3b\u2206", "\udac2\udf68",
        10, 20016, -230620901, 7119781239962483727L, -91991L, true, true, (char) 50398, (char) 46546,
        Double.longBitsToDouble(0x3feb445dc74802deL), Double.longBitsToDouble(0x3fe03a8a2a7bb2fdL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 8, 12, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\uda20\udc08\ud98b\ude83\udb31\udd07", "\ubb0c\u38d0\u7642\uafda\ub859\u9d82\u176a\u758b\uafd4\u35dc\u3f9b\u980a\u8047\u86b1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c51eb00060L), Double.longBitsToDouble(0x3fe3d97986d03b97L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 18, 7, "\udaf6\udd14\ud88f\udc05\udbe8\udd5b\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud94e\udc9a\udb93\ude13", "\ubb0c\u38d0\u75b1\ua009\ucb7f\ub772\u176a\u55d6\u9f86\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\uab77\u7401\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fd820e301a0ef2eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 18, 13, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\uccac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 18, 3, "\ud9e5\udcb0\udbab\udfde\ud8ba\udd31\uda86\udd03\ud981\udf1c\ud942\udd10\ud9ab\ude55\ud92e\udcf7\uda29\udeec\udaeb\udce9\ud859\udfcb\ud9b2\udcd0\ud849\udcb7\uda43\udd2b\udac8\udca1\udb52\udd30\ud94b\ude2a\uda62\udc4b", "\u3118\u9d82\u9d0b\u6dd8\u9bcf\u072f\u19fa\u78f6", "\ud84b\ude4d\uda03\ude28\udb39\udcf9\ud8df\ude95\udbf2\udd1d\ud9f3\udfa7\ud89c\udd1f\ud929\udc4f",
        8, 5616, 305152239, 6098140941337706237L, 65353L, true, true, (char) 41227, (char) 48258,
        Double.longBitsToDouble(0x3fdf7181fd61649cL), Double.longBitsToDouble(0x3fe1b8dc9eed1478L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 7, "\ud95a\udcdd\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud950\ude4c\ud8e3\udece\uda6a\ude08\udae8\ude9b\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udab1\udda9", "\ubb0c\u38d0\u75b1\u0e73\u2f7b\u9d20\u6807\u5581\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u3eb3\u4b6d\uad05\u42ba\u0cd2\u052c\u09e8\uca57\u5f2d\u23ac\u5c51", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572099438049071L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c630b00060L), Double.longBitsToDouble(0x3fea39b24b102c90L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 14, 7, "\000", "\u6b85", "\ufa3f",
        -5, 98880, 98, -5693980516491699484L, -100000L, true, true, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd0000002a3e482L), Double.longBitsToDouble(0x3f8ec463e0319d00L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 18, 7, "\ud944\udc51\u5aee\udb24\udfee\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\ud871\udfcf\uda6a\ude08\udae8\udebb\udb69\ude3a\ud8cf\udfbf\udaf7\udf2d\udb6d\ude5f", "\ubb0c\u3a00\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u1b9e\u1fb3\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, -969, 2067581285, -5498572099590279471L, -80178L, true, false, (char) 35323, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbf1\udd5f\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u78ef\uaeec\u3130\u7434\u27b0\u0579\u5f07\u4b6d\u0939\u9e1b\ua78c\u65ac\ua1e5\u1ec2\u5f2d\u23ac\u0323", "\ud8b6\udd4c",
        54, 84383, 2067581283, -5498572098649519919L, 88592L, false, false, (char) 2917, (char) 50913,
        Double.longBitsToDouble(0x3fe102c02eb00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 16, 11, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71", "\u4ef2\u8c74\u529e\ua980\u548b\u4d3b\u21a6", "\udb82\udcb5",
        36, 20099, -230620901, 7075437936014277647L, -91991L, true, true, (char) 34642, (char) 46546,
        Double.longBitsToDouble(0x3feb445dc74802deL), Double.longBitsToDouble(0x3fd66514562f02e6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 1, 2, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud98f\udd1c\ud844\udda4\ud9ab\ude55\ud9ea\uded5\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud847\udfc0\udb6d\ude5f", "\uce36\u5cdd\u146e\u76d6\uc219\u0b1c\u996d\u8135\u14cb\u067a\u3f9b\u78ef", "\uda87\udd4b\ud8de\udf43\udb41\udc98",
        22, 70610, 1265519413, -2106702343635661026L, 39544L, true, true, (char) 602, (char) 33417,
        Double.longBitsToDouble(0x3fe0abb59eec3da3L), Double.longBitsToDouble(0x3fd6ed4078a31e34L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 2, 18, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u0385\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 11, 3, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\udae0\udd19\udae8\udebb\uda70\uddbf\ud9d7\uddbd\ud849\udcb7\udb8b\ude5f", "\uba3b\u18fc\u75b1\uafda\ub819\u9d82\u176a\u55d6\u4ef7\uc34b\u53e5\u78f5\uaeec\u7a1c\u80fa\u2207\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u1c15\u29be\uca36\u5f2d\u23ac\u7731", "\uda04\udcbc\ud8d7\udc72",
        23, 9283, -1280220721, 1738117673626031607L, -95772L, true, false, (char) 64481, (char) 20198,
        Double.longBitsToDouble(0x3fe58003067b2f30L), Double.longBitsToDouble(0x3fe683bcbb89702cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 1, 10, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71", "\u4ef2\u8c74\u529e\ua980\u548b\u4d3b\u2206", "\ud97e\ude86",
        19, 20099, -230620901, 7075437936014277647L, -91991L, true, true, (char) 34642, (char) 46546,
        Double.longBitsToDouble(0x3fee745dc74802deL), Double.longBitsToDouble(0x3fe03a8a2a2b7533L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ub56a\u1723\u75b1", "\uda54\udcff\ud979\udc0f\ud9e2\udd6c\ud9c0\ude51\ud8dc\udf93\ud851\udc12\ud87f\udcef\udaad\udf8f\udad3\udfb1\uda87\udd4b",
        58, 17611, 1182808411, 5531310814944782584L, 92738L, false, true, (char) 65232, (char) 59096,
        Double.longBitsToDouble(0x3fe70094a6fd54a0L), Double.longBitsToDouble(0x3fe0abb59eec3da3L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 8, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\ud8f8\udc88\udb2a\uddaa\udb0a\uddbe\udaf3\udf2b\udad8\udd97\uda6a\ude08\udabd\udf76\udb69\ude3a\ud9b2\udcd0\udb7d\udf71\udabf\udd4e", "\u9088\u38d0\u75b1\uafda", "\ud978\udf57\ud948\udc1d\udaac\udf33\ud8dc\udf93\ud851\udc12\ud87f\udcef\udad5\udf9e\udad3\udfb1\ud80e\udce1\ud8de\udf43\udb39\udcf9\uda7d\udf9f\ud82b\udd18\ud9f3\udfa7\udbac\udfa7\ud929\udc4f\udad4\udc17\udbd9\ude60\ud8f7\ude02\udaf7\udfdc\udb0f\uddfb",
        53, 35812, -1996489794, -4074868683713336460L, 24021L, false, true, (char) 53371, (char) 58666,
        Double.longBitsToDouble(0x3fafbeb1f17b1a20L), Double.longBitsToDouble(0x3fd70b38fa474b30L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 16, 12, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda69\udf81\udad7\udc61\ud8fe\udcce\uda25\udf93\udbd0\udec5\uda6c\ude4f\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb88\udeeb", "\ubb0c\u38d0\u75b1", "\uc8f4\ud978\udfdc\udba2\udfee\udacc\ude57\ud8dc\udf93\ud851\udc12\ud87f\udcef\udb2e\ude5a\udad3\udfb1\uda87\udd4b",
        57, 17656, 1182839672, -8295925314605020368L, 39544L, false, false, (char) 1396, (char) 37789,
        Double.longBitsToDouble(0x3fe0abb59eec3da3L), Double.longBitsToDouble(0x3fd7a354df3e88d0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 12, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\ude98\ud942\udd10\ud9ab\ude55\u171b\ud9e6\udcff\ud8ad\ude77\ud823\ude37\ud9b2\udcd0\ud87c\udc96\udb6d\ude5f\ud97e\ude86\ufe36\ud94b\ude2a\uda62\udc4b\ud955\udf1a\udb46\udcaa\udb44\ude5b\uc8f4\ud978\udfdc\ud884\udfbd\udacc\ude57", "\u78ef\uaecc\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\u332e\u65ac", "\udaf7\udfdc\ud8c3\uddf5\udbb7\udc9b\udb7b\ude86\udbba\udc0d\ud9f6\udff7\udb58\udc0f",
        0, 33800, 588679870, 6011116131904002111L, -85591L, true, true, (char) 15048, (char) 50195,
        Double.longBitsToDouble(0x3fd1f06ebee3212cL), Double.longBitsToDouble(0x3fea1aa447738c0bL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\udb37\ude54\ud849\udcb7\ud933\ude62", "\ubb0c\u1a00\u866c", "\ud8b2\udd24\ud978\udfdc\uda9c\udc28\udacc\ude57\ud8dc\udf93\ud851\udc12",
        44, 10675, 939385957, 7688144850443532996L, -10981L, true, true, (char) 38926, (char) 51501,
        Double.longBitsToDouble(0x3fe8f7161d4a581dL), Double.longBitsToDouble(0x3fd182f929d5a3dcL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 18, 12, 7, "\ud93a\udde7\ud9ef\udeac\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1", "\uc8f4\ud978\udfdc\ud884\udfbd\udacc\ude57\ud8dc\udf93\ud851\udc12\ud87f\udcef\udad5\udf9e\udad3\udfb1\uda87\udd4b",
        57, 17656, 1182839672, -8295925314605020368L, 92738L, false, true, (char) 20650, (char) 59096,
        Double.longBitsToDouble(0x3fe70094a6fd54a0L), Double.longBitsToDouble(0x3fe0abb59eec3da3L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\u0e9a\u48a3\u75b1", "\ud920\ude1d\ud828\udd7b\ud884\udfbd\udacc\ude57\ud8dc\udf93\ud851\udc12\ud87f\udcef\udad5\udf9e\udad3\udfb1\uda87\udd4b\ud8de\udf43\ud9ad\udf73\uda7d\udf9f\ud82b\udd18\ud9f3\udfa7\udbac\udfa7\ud929\udc4f\udad4\udc17\udbd9\ude60\ud8f7\ude02",
        10, 40557, 1034127893, -2268742274764960910L, 64007L, false, true, (char) 554, (char) 11643,
        Double.longBitsToDouble(0x3fbcfeea6fe4bf30L), Double.longBitsToDouble(0x3fdd9d6a3b005536L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 14, "\ud9e5\udcb0\ud8f9\udd65\udbd7\udfd7\uda86\udc81\ud981\udf1c\udad3\udd58\ud9f0\uddf3\udbdb\udc91\ud9ba\ude10\udae8\udebb\udb69\ude3a\ud8ae\udd82\udae8\udc7c\udbff\udead", "\ubb0c\u38d0\u563d\uafda\ub819\u9681\u176a\u2bc4\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\ua73c\u29a3\u8c5a\u5e91\uaca1\u8186\u42ba\u849c\u49e8\uad10\u7cb4\u2f4e\u23ac\u0323", "\uda04\udcbc\ud8d7\udc72\u6b35",
        4, 5829, -98607667, -4785997325402447769L, -36787L, true, true, (char) 20198, (char) 50959,
        Double.longBitsToDouble(0x3fe3d97986d07797L), Double.longBitsToDouble(0x3f8f9a2f4ae12540L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\012",
        Z.run(T, 2, 6, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\udad3\udd58\ud9f0\uddf3\udbdb\udc91\udbb8\uddf0\udaeb\udebe\udb69\ude3a\ud8ae\udd82\udb08\ude8c\ud962\udd36", "\ubb0c\u38d0\u563d\uafda\ub819\u9d82\u176a\u2bc4\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\ua73c\u29a3\u0570\u5f07\u4b6d\uad05\u42ba\u849c\u49e8\u7266\ud562\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 27463, 2067581438, -5498334604641236783L, -26375L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 1, 8, 5, 7, "\ud9e5\udcb0", "\u6b85\u795e\u4ef2\u8c74", "\udae8\udebb\udb69\ude3a",
        -5, 22859, -1509219411, 4739732173709723680L, -37551L, false, false, (char) 14255, (char) 2961,
        Double.longBitsToDouble(0x3fc6f5184654102cL), Double.longBitsToDouble(0x3fc4e4d564cab280L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 18, 7, "\ud9e5\udcb0", "\u6b85", "\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb",
        21, 98620, -1810300141, -6482048012133193395L, -100000L, false, false, (char) 62289, (char) 40512,
        Double.longBitsToDouble(0x3fd84c67416f5002L), Double.longBitsToDouble(0x3fd95040b14e4d56L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 1, 1, "\udb8f\udfd0\udb85\udcbb\ufd72\uda8f\ude81\ud981\udf1c\ud942\udd10\ud98d\udd55\udbc2\udc16", "\u9161", "\ud8cf\ude77\udac2\udfc8",
        18, 48098, -234881024, 7075437936014277755L, -75257L, false, false, (char) 1153, (char) 21670,
        Double.longBitsToDouble(0x3fd312b0fa02052eL), Double.longBitsToDouble(0x3fe50dbb4935ae92L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 6, 12, "\uda17\udee3\udb85\udd4a\udbbd\udd71\udb71\uddb8\ud981\udf1c\ud942\udd10\uda80\udf81", "\u548b\u4d3b\ua90b", "\udaf5\udc34\u2e4d\000\udb19\udf2c\ud955\udf1a\udb97\ude53\udaab\udc4f\ud9f9\ude3a",
        6, 60047, 2038106418, -8630790080843139437L, -3939L, false, false, (char) 46396, (char) 6519,
        Double.longBitsToDouble(0x3fab4208360f8370L), Double.longBitsToDouble(0x3fc0bc58178dc4dcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 18, 5, "\ud8df\udd4d\ud8d5\udcaf\udbbd\udd9c\ud89c\udeec\ud981\udf1c\udba8\udcf5\ud9ab\ude44", "\u548b\u4d3b", "\udb6d\ude5f\udac2\udf68",
        10, 20099, -230620901, 7075437936014277647L, -10517L, false, true, (char) 55326, (char) 42024,
        Double.longBitsToDouble(0x3fe481ba4f4802deL), Double.longBitsToDouble(0x3fe03a8a2a2b7533L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 18, 15, "\ud872\ude97\ud8d5\udcb2\udbbd\udd9c\uda86\udc81\ud9e9\uddd0\ud9db\ude81\udaa9\udcd2", "\u548b\uc7ae", "\udb6d\ude29\udac2\udff6\udb52\udd30\ud94b\ude2a\uda85\udc4b\ud9de\ude40\udada\udfc0\uda72\udf41\udad3\uddf4",
        25, 9593, -1950873259, 206623971670681416L, 37275L, false, false, (char) 37679, (char) 14731,
        Double.longBitsToDouble(0x3fd9a232749cedf6L), Double.longBitsToDouble(0x3fee4836435829a7L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 5, "\ud8df\udca2\ud8d5\udcaf\ud8c2\udffa\udb85\udc6e\ud983\udcfd\udba8\udcf5\ud9ab\ude44\udbc1\udfd7\uda6a\ude08", "\uc8be\u654c\u086c\u43b3\ud787\ubb0c\u38d0\u95a5\uafda\u47f9\u9dac\u5e2a\ud03c", "\ud851\udc12\ud87f\udcef\ud90f\udc5b\u1cc6\ud98d\uded5\udb9e\udc51\ud978\uddf3\uda09\udf40\ud819\udc6c\ud9d5\uddf5\ud882\uddd5\uda87\udd6e\ud846\udd1c\ud891\udc6d\uda2f\udd27\uda46\ude87\ud8c8\udd84\ud828\ude8d\ud837\ude6d\uda7a\udc7c\u5f43\udac8\udd34\ud95b\udf1b\uda6c\udd78\udac3\udd71\uda3b\ude56\uda32\uddd1\udaba\udf7c\ud8aa\udf14\udbc2\udfe0\uda45\uddab\udb5c\udc65\uda3f\ude4a\udb88\udd97\udace\udd58\ud8c9\uddf6\udadf\udde1\udac4\udd3e\ud95a\udc69\ud94d\ude49\ud864\udc32",
        44, 51613, 496483435, 7595814905400009992L, 96650L, true, true, (char) 3662, (char) 25277,
        Double.longBitsToDouble(0x3fe8e1220ccf62e5L), Double.longBitsToDouble(0x3fe6e72d7f462aa0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 11, "\ud9e5\udcb0", "\u6b85\u795e\u5116\u7a2d", "\udae8\udebb\udb69\ude3a\udabb\ude16\ud849\udd1b\udb7e\udd46\udac2\udf68\udb52\udd30\ud94b\ude2a\uda62\udc4b\ud955\udf1a",
        1, 25199, 77902984, 2786498454382207143L, 26104L, false, true, (char) 65355, (char) 12126,
        Double.longBitsToDouble(0x3fdfd0353fba6ffaL), Double.longBitsToDouble(0x3fe623544488086fL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 9, "\ud9e5\udcb0\ud86b\udc1d\ud8ba\udd56\uda10\ude27\ud977\ude53\ud942\udd10\ud9ab\ude55\ud92e\udcf7\uda29\udeec\udaeb\udce9\ud859\udfcb\uda1d\udd07\ud849\udd0f\uda7d\udc11\udac8\udca1\uda79\udd23\ud94b\ude2a\uda62\udc4b\ud955\udf1a\udb90\ude49\udbbe\udff0\uc8f4\ud8a6\udc53\ud862\udd34\ud8a9\udd2c\ud8dc\udff4\udb00\uddcb", "\u46d1\u627f\u9147\u0579\u489a", "\ud89c\udd1f",
        15, 51058, -843636456, 388846907278830038L, -10254L, true, true, (char) 33303, (char) 21435,
        Double.longBitsToDouble(0x3fd6390f5b9ef678L), Double.longBitsToDouble(0x3fe68d9d8c832a56L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 2, 7, "\ud95a\udcdd\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud950\ude4c\ud8e3\udece\uda6a\ude08\udae8\ude9b\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udab1\udda9", "\ubb0c\u38d0\u75b1\u0e73\u2f7b\u9d20\u6807\u5581\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u3eb3\u4b6d\uad05\u42ba\u0cd2\u7248\uc59c\ub03f\u5f2d\u23ac\u5c51", "\ud817\udd06",
        2, 84383, 2067581283, -5498572099438049071L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c630b00060L), Double.longBitsToDouble(0x3fea39b24b102c90L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 7, "\ud9e5\udcb0\udafd\udf28\uda84\ude1a\ud8bc\udd70\u5381\udabc\udd02\ud961\udf19\ue120\uda6a\ude08\udae8\udebb\uf549\ud8c8\udfc9\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u06ce\u3f9b\u34ef\u2159\u3117\u7434\u27b0\ub537\u5f07\u4b6d\u0939\u9e1b\ua78c\u65ac\ua1e5\u30d5\u15b1\u29a3\u0323", "\ud97c\udc0f",
        43, 84383, 2067581283, -5498572098649519919L, 88592L, false, false, (char) 2917, (char) 50913,
        Double.longBitsToDouble(0x3fe102c02eb00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 4, 7, "\ud9e5\udcb0\000\000\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\u5ae4\ud848\udda4\udb6d\ude5f", "\u1991\u38b5\u75b1\uafda\ub819\u9d82\u4dd4\u55d6\uaf60\u0385\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0088\u7398\u3408\000\u7d61\000\000\u2118\000\u5e4d\u00fd\u030e", "\uda04\udcbc",
        44, 84383, 2067581283, -5498572098649520128L, 30896L, false, false, (char) 0, (char) 1280,
        Double.longBitsToDouble(0x3fe102c630000000L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 8, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\ud9dc\ude56\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u0385\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97982553e97L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 18, 10, 7, "\ud9e5\udcb0\udae2\udefa\ud8eb\udfc4\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\uda37\udcaa\udb69\ude4c\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\ua144\u9039\ud449\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u948f\u03bc", "\uda04\udd11",
        30, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64594,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 12, 10, "\ud8b7\udd3c\ud822\ude1c\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udb8b\udd39\ud87c\udc00\ud8a5\udd34\ud84a\udd46\ud953\udc14", "\ubadd\ucd4c\u75b1\u0ec7\ub819\u68c4\u176a\u5881\u1222\u8255\u540f\u67b7\u5c49\u86c1\u6576\u5cc3\ud76b\ua17f\u7ebb\u73b0\u42a9\u8fd8\u4941\u61bd\uca5b\u5f2d\u227c\ud0a6", "\uda04\udcbc",
        34, 84383, 280152419, -5498572098649519919L, -36787L, true, true, (char) 20198, (char) 21977,
        Double.longBitsToDouble(0x3fe3d95396e636c3L), Double.longBitsToDouble(0x3fe0e61db16d09a8L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 11, 6, "\udbb4\udcb9\udb85\udcb6\udbbd\udd71\uda86\udc81\ud981\udf1c\udb0e\udc7a\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubaac\u38d0\u75b1\uafda\u82c5\u630c\u0204\u6643\uaf7d\u0385\u87c0\ubc1c\u9202\u869b\u6576\u5cc3\u0579\u5f07\u6f93\ubb23\u1392\u992d\u65ac\ub27d\ucaee\u5f2d\u9855\u035e", "\uda04\udcbc",
        30, 84383, 36424035, -3464634634197858239L, -26448L, false, false, (char) 6352, (char) 7821,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 7, 0, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud854\udc38\uda43\udf09", "\ubb0c\u38d0\u75b1\uafda\u9bfc\u9d82\u176a\u55d6\uaf60\u0385\u3f9b\u78ef\uaeec\u86c1\u6576\u5c52\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u688c\ub33d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 2067581283, -5498572099740038959L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 13, 7, "\udb72\ude2e\uda4d\ude92\udbd9\udcd2\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u6c23\ubca8\ua692\ub819\u9d82\u176a\u55d6\uaf60\u0385\u3f9b\u78ef\u1037\u86cb\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u6740", "\uda04\udcbc\ud8d7\udc72\udb06\udf8b",
        48, 38919, 404687057, -5598302029078667088L, -36787L, true, true, (char) 20198, (char) 50959,
        Double.longBitsToDouble(0x3fdc92f30c270cf4L), Double.longBitsToDouble(0x3fea270444a8e72fL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 12, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\udbef\udf54\ud91c\udcdb\ud9ab\ude87\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udae8\udfbc", "\ubb0c\u38d0\u75b1\uafda\ub819\u29a8\u81a1\u55d6\uaf60\u0385\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\u620e\u1929\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 106547555, 9201176469632387281L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b000f8L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 18, 10, 10, "\udbe1\udcae\udb85\udd4a\udbbd\udd71\uda86\udc81\ud910\udeef\ud972\udda4\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud8ee\udcca\ud8eb\udf07\udb0f\ude50", "\ubb0c\u38d0\u75b1\uafda\ub819\u9d82\u176a\u55d6\uaf60\u0385\u471e\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda38\udc16",
        -5, 84383, 2067581283, -5498572098649519919L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c6373b3c3dL), Double.longBitsToDouble(0x3fe5eb6486d07797L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 18, 12, 7, "\ud953\udd19\ud9ef\udeac\udac9\udfd8\udae3\udeda\udb45\ude00\uda7b\udc85\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1", "\uc8f4\ud978\udfdc\ud884\udfbd\udad8\udd57\ud8dc\udf93\ud828\udd12\ud87f\udcef\udad5\udf9e\udad3\udfb1\udaf8\udea4\udac7\udc40\uda27\udc1b\ud80e\udc59\ud800\udc44\ud95f\udf9d\udbac\udfa7\ud929\udc4f\udad4\udc17\udbd9\ude60",
        0, 76080, 1991458557, 4441545482399502060L, -96747L, true, true, (char) 65224, (char) 22262,
        Double.longBitsToDouble(0x3fe05683d6bd8082L), Double.longBitsToDouble(0x3fd4057509000150L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 1, 11, 18, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\ud942\udd10\ud9ab\ude55\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f\ud97e\ude86\udb52\udd39", "\u75b1\ubffbb\ucd93\u1d54\u55d6\uaf60\u06ce\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u4f40\u5f07\u4b6d\uad05\u42ba\ua78c\u65ac\ub27d", "\udb0f\uddfb\udba7\uddb6\udbfd\udd10\ud8b2\udda9\ud9a1\uddc7\ud978\udd05\udb38\udfc8\udbaa\udcdf\uda04\ude13\ud9ec\ude50",
        0, 55369, -724245120, 8110990317160021854L, -72307L, true, false, (char) 46079, (char) 28063,
        Double.longBitsToDouble(0x3fe12dfaca6c8b6bL), Double.longBitsToDouble(0x3fea322d0c156e10L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 4, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\ud981\udf1c\udad3\udd58\ud9f0\uddf3\udbdb\udc91\udb4b\udeb9\udbf4\udf9c\udb69\ude3a\ud8ae\udd82\udb08\ude8c\ud962\udd36", "\ubb0c\u39ef\u563d\uafda\ub819\u9d82\u176a\u2bc4\u2f15\u9039\u3f9b\u78ef\uaeec\u86c1\ua73c\u29a3\ua432\u5ec4\u4b02\uad05\u42ba\u849c\ua0e7\u7266\ud562\u5f2d\u05bd\u0323", "\udbd0\ude62",
        14, 27463, 2067581438, 1551627201246333014L, -26375L, false, false, (char) 17509, (char) 62928,
        Double.longBitsToDouble(0x3fe30746f6b00060L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 10, 9, "\ud9c6\udf1c\ud8d7\uddb4\ud8d8\udd67\uda10\ude27\ud977\ude53\ud942\udd10\ud9ab\ude55\ud92e\udcf7\uda29\udeec\udaeb\udce9\ud859\udfcb\uda1d\udd07\ud849\udd0f\uda7d\udc11\udac8\udca1\uda79\udd23\ud94b\ude2a\uda62\udc4b\ud955\udf1a\udb90\ude49\udbbe\udff0\uc8f4\ud8a6\udc53\ud862\udd34\ud8a9\udd2c\ud8dc\udff4\udaec\udd38", "\u46d8\u627f\u9147\uba2e\u608f", "\ud89c\udd1f",
        15, -136, -1194631271, 7961782120199920184L, -10254L, true, true, (char) 33303, (char) 21435,
        Double.longBitsToDouble(0x3fd6390f5b9ef678L), Double.longBitsToDouble(0x3fe68d9d8b832a01L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 8, 8, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udc81\uda71\ude94\ud942\udc8a\ud9c8\ude44\udbaf\udcb6\uda6a\ude08\udae8\udebb\ud9dc\ude56\000\000\000", "\ubb0c\u38d0\u0151\000\ub819\u9d82\u9509\u55d6\uaf60\u0385\u3f9b\u78ef\ub3d9\u86c1\u6576\ubac2\u0088x\000\uad05\u7d61\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\000",
        -5, 27552, 0, 0L, 88592L, false, false, (char) 62975, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b00060L), Double.longBitsToDouble(0x3fe0000182553e97L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 11, 12, 7, "\ud953\udd19\ud9ef\udeac\udac9\udfd8\udae3\udeda\udb45\ude00\uda7b\udc85\ud9ab\ude55\udb85\udcc8\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\ubb0c\u38d0\u75b1", "\uc8f4\ud978\udfdc\ud884\udfbd\udad8\udd57\ud8dc\udf93\ud828\udd12\ud87f\udcef\udad5\udf9e\udad3\udfb1\udaf8\udea4\ud93a\udf40\uda27\udc1b\ud80e\udc59\ud800\udc44\ud95f\udf9d\udbac\udfa7\ud929\udc4f\udad4\udc17\udbd9\ude60",
        0, 76080, 1991458557, 4441545482399502060L, -96747L, true, true, (char) 65224, (char) 22262,
        Double.longBitsToDouble(0x3fe05683d6bd8082L), Double.longBitsToDouble(0x3fd4057509000150L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 10, 9, "\ud9c6\udf1c\ud9c9\udeff\udaef\udcca\uda10\udd86\uda43\ude59\ud942\udd10\ud9ab\ude55\ud92e\udcf7", "\u3db2\ubaaf\ua68c\u6539\u5b2e\u8ef0\ubb0c\u673f\u338f\ua98d", "\ud88f\udce8",
        0, 29442, 48108489, -6707101513932254238L, -55989L, false, false, (char) 14072, (char) 3221,
        Double.longBitsToDouble(0x3fd509a09ac2a534L), Double.longBitsToDouble(0x3fe8f5be1cb87076L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 11, 12, 7, "\ud953\udd19\ud9ef\udeac\udac9\udfd8\udae3\udeda\udb45\ude00\ub7ff\udbe3\udc10\udb85\udcc8\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udb6d\ude5f", "\u10e4\u37b5\u75b1", "\000\000\ud884\udfbd\udaca\udd57\ud8dc\udf93\u4448\000\000\udad3\udfb1\002\ud927\udc32\uda27\udc1b\ud80e\udc59\ud800\udc44\udb86\udf31\udbac\udfa7\ud929\udc4f\udad4\udc17\udbd9\ude60",
        0, 76080, 0, 151824882061036L, -36098L, false, false, (char) 10933, (char) 31555,
        Double.longBitsToDouble(0x3fed70b8df810775L), Double.longBitsToDouble(0x3fe05683d6bd8082L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 5, 7, "\ud9e5\udcb0\udb85\udd4a\ue99c\udabd\udc49\uda67\udd75\ud821\udc1a\ud9b6\udcff\ud8fe\udd4d\uda95\ude7e\udae8\udf0f\udb69\ude3a\ud8da\udfe9\udad4\ude1e\udb6d\ude5f", "\ubb0c\u38d0\u75b1\ud155\u6fea\u9d82\ud387\u99ab\ua567\u8b63\u9cbd\uadab\uaeec\u236e\ucf82\u5cc3\u0579\u973e\u82e4\uad05\ub69c\u8306\u0481\u9942\u6c69\u07bc", "\ud816\udddc\ud827\ude7f\uda04\udcbc\ud8fc\udce4\udb06\udffa\ud8bc\udcd1\udb0a\udd4f\ud93e\udd9e\uda90\udc2f\udac8\udfb7\udb2e\uddb8\ud85b\ude5b\udb4b\ude32\udac9\udeca\uda50\udd7e\udad9\udccb\uda2a\udcf0\uda91\udc6e\udb43\udc46\ud9b8\udca7\ud8c2\udd48\ud8fd\udc9a\ud868\udcb7\uda8f\udce6\u183b",
        0, 45540, -1690116242, 2959225999249189112L, 25792L, true, true, (char) 63760, (char) 2983,
        Double.longBitsToDouble(0x3fcbdc90ed5ab5e4L), Double.longBitsToDouble(0x3fe324e08ad25b93L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 13, "\udadd\udd75", "\u6b85\u0a5e\u4ef2\u8c74", "\udac7\udebb\ud90b\udd2b",
        -1, 22859, 680862637, 4739501134533969952L, 79441L, true, false, (char) 14255, (char) 35411,
        Double.longBitsToDouble(0x3fd1be9bb32b79b2L), Double.longBitsToDouble(0x3fc4e4d564cab280L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 11, 4, "\ud355\ud9c9\udf10\udaef\udcca\uda10\udd86\uda43\ude59\ud942\udd10\ud9ab\ude55\ud92e\udcf7", "\u3db2\ubaaf\u2511\u6539\u5b2e\u8ef0\ubb0c\u673f\u338f\ua98d", "\ud9ce\ude2e",
        0, 29442, 1339954121, 5040220353041050812L, -80389L, true, true, (char) 62771, (char) 10369,
        Double.longBitsToDouble(0x3feda31a27fd5c98L), Double.longBitsToDouble(0x3faccd04d6152ef0L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 18, 12, 7, "\ud9e5\udcb0\udb85\udd4a\udbbd\udd71\uda86\udcc8\udbef\udf54\ud91c\udcdb\ud9ab\ude87\udbc1\udfd7\uda6a\ude08\udae8\udebb\udb69\ude3a\ud9b2\udcd0\ud849\udcb7\udae8\udfbc", "\ubb0c\u38d0\ucea0\uafda\ub819\u29a8\u81a1\u55d6\uaf60\u0385\u3f9b\u78ef\uaeec\u86c1\u6576\u5cc3\u0579\u5f07\u4b6d\u620e\u1929\ua78c\u65ac\ub27d\ucaee\u5f2d\u23ac\u0323", "\uda04\udcbc",
        30, 84383, 106547555, 9201176469632387281L, -26448L, false, false, (char) 2917, (char) 64481,
        Double.longBitsToDouble(0x3fe102c636b000f8L), Double.longBitsToDouble(0x3fe3d97986d07797L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|close||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|close||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|close||new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.changes.ChangeSetPerformer|perform|org.apache.commons.compress.archivers.ArchiveInputStream,org.apache.commons.compress.archivers.ArchiveOutputStream|new:org.apache.commons.compress.changes.ChangeSetPerformer:org.apache.commons.compress.changes.ChangeSet",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|closeArchiveEntry||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|createArchiveEntry|java.io.File,java.lang.String|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|ensureOpen||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|finish||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|pad|int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|putArchiveEntry|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|write|[B,int,int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeAsciiLong|long,int,int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeBinaryLong|long,int,boolean|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeCString|java.lang.String|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeHeader|org.apache.commons.compress.archivers.cpio.CpioArchiveEntry|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeNewEntry|org.apache.commons.compress.archivers.cpio.CpioArchiveEntry|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|close||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|close||new:org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream|close||new:org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.changes.ChangeSetPerformer|perform|org.apache.commons.compress.archivers.ArchiveInputStream,org.apache.commons.compress.archivers.ArchiveOutputStream|new:org.apache.commons.compress.changes.ChangeSetPerformer:org.apache.commons.compress.changes.ChangeSet",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
