package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 7, 6, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u1283", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 20710, -1341038501, -1787495971352134552L, -18509L, false, false, (char) 10131, (char) 27268,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 7, 6, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\uabc6", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 20710, -1341038501, -1787495971352134552L, -18509L, false, false, (char) 10131, (char) 39756,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 7, 10, "\udbf3\udd16\uda9c\udc62\udb6b\uddb5\udb6b\udc49\ud98b\udf8d\uda30\ude78\uda14\udca2\ud8c7\udc8c\u8fef\ud8fa\udd46\udbd4\udd64", "\u976f\u1283\u7074\ua4c3\u0d19\u6a56\u3f4a\u7fa5\u80a3\u9aa5\u2c15\ub2bb\u2336\u4549\u5065\ua89a\u39f2\u1476\ua697\uaa74\u1441\ua30a\u9388\u3bb6\ubc08\ua794", "\udb36\udcce\uf718\ud85d\ude34\udbd0\udda0\ud923\udee2\ud901\udd9e\udbd0\udda6\ud910\udff9\udbd4\udca5\uc349",
        13, 10442, -1108841968, 1157240529191911731L, 864L, true, true, (char) 35866, (char) 46695,
        Double.longBitsToDouble(0x3fd73d0be3e2b990L), Double.longBitsToDouble(0x3fe6717512c07d8bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[76, -121, 85, 28, 110, 62, 59, -23]] |a1=[B:[[83]]\012",
        Z.run(T, 1, 5, 6, 2, "\uda7c\udfb7\uda85\udd4c\uda9e\udc6e\udb6b\udc19\ud924\udcd9\ud972\udd45\uda22\udef7\ud8c7\udc8c\u8fef\udb0a\udd6f\udb07\udd97\udb6e\uded3", "\u1283", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 20710, -1341038501, -1787495971352134552L, -18509L, false, false, (char) 10131, (char) 61959,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f883d632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[28, 121, 112, -120, -56, -79, 59, -23]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 17, 6, 12, "\udb4c\udca9\ud8a0\udeb8\udaf8\udde1\udb6b\udc19\ud98b\udf8d\ud972\udcb8\ud874\udfe1\uda80\udce8\u859a\uda8f\udf50\u5a9a\ud8e8\udfa2", "\u1283", "\uffac\udb75\uddec",
        19, 56016, 1151071781, 4276601424290499177L, -9797L, false, true, (char) 56217, (char) 28609,
        Double.longBitsToDouble(0x3fdadf204c6dbb6cL), Double.longBitsToDouble(0x3fb1edd2c68acd98L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 10, 6, 7, "\ud939\udce8\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\udbbd\udd67\udb1d\uddbb\ud8ff\udcfa", "\u669d\u4958\ua550", "\udbfc\udf2a\u6982\ud9b2\ude11\udb29\udfed\uda60\udfff\ud94a\udc6c\ud82c\udfa5\udaf6\udc6b",
        51, 94932, -575225427, 4006093257642622689L, 72044L, true, false, (char) 19471, (char) 51680,
        Double.longBitsToDouble(0x3fcfb27cb0284bc8L), Double.longBitsToDouble(0x3fd8a037aa8bca70L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 11, 9, 11, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud881\udfab\ud9b0\udd79\ud828\uded8", "\u1283\u4958\ua550\u0d19\u6a56\uc796\u874c\u7bf5\u7049\u875c\u06d5\u799e", "\udb40\udc8b\udae5\udfa7\ud852\udded\ud8f1\udd90\udb46\ude11\udb29\udeeb\uda26\udd76\udab1\udc0f\ud8c0\ude81\udb42\udc3a\ud9f3\udc97\ud95d\udc54\udab8\ude80\udb65\udcd9\ud930\udd84\udb2d\udc5d",
        19, 13128, 1385560306, -932048053290569134L, 24865L, false, true, (char) 21352, (char) 43937,
        Double.longBitsToDouble(0x3fc2854e29d08d44L), Double.longBitsToDouble(0x3feb24c538af4983L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 16, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\000", "\udba3\udc20\ud907\udd23\udbfc\udf2a",
        -5, 18258, -255489450, 3929048492363278854L, 61310L, false, false, (char) 46961, (char) 62312,
        Double.longBitsToDouble(0x3e01edc000000000L), Double.longBitsToDouble(0x3fca2b3671945510L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 6, 7, "\udbf3\udc4e\uda9c\udc62\udbd8\udc5b\ud8b0\uddc1\ud9d0\udf71\ud97c\udc3a", "\u762d\u718d\ub0c8\u22d6", "\udb6a\udffe\ud958\udd84\udaff\uddaf\udba3\udc20\ud8a9\udef7\ud9ac\udf34\udb0a\ude33\ud8f2\udfd2\ud894\udcbc\uda17\udd0c",
        30, 965, -416183838, 8511025287951761748L, -70870L, true, false, (char) 27268, (char) 35241,
        Double.longBitsToDouble(0x3fe26d18f80c8ecbL), Double.longBitsToDouble(0x3fd0a441e207f5feL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 11, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u1283", "\udba3\udc20\udb58\udd04\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 20710, -1341038501, -1787495971352134552L, -18509L, false, false, (char) 10131, (char) 27268,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 15, 6, 7, "\uda13\udfa6\uda9c\udc62\uda73\udf61\ud8db\udd1b\ud919\udf7f\ud9da\udcc2\ud9a6\udef3\uda34\udc27\udb49\udff8\ud975\udfd5\udb1d\udd84\ud8ad\udc92", "\u5ab8\u4958", "\ud910\udd09",
        24, 22656, -1323071734, -1097318831308224311L, -942L, false, true, (char) 12941, (char) 46961,
        Double.longBitsToDouble(0x3fd74febbd28f284L), Double.longBitsToDouble(0x3fb1edd2c68acd98L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 0, 0, "\udbb2\udcf6\000\ud992\udc08\udb6a\udf64\udacc\ude4e\ud972\udcb8\uda22\udef7\udb92\udc08\000\000\000\ud8ff\udc40", "\u958d", "\000",
        41, -1000, 0, 0L, -40090L, true, false, (char) 45299, (char) 0,
        Double.longBitsToDouble(0x3fd000000001e576L), Double.longBitsToDouble(0x3fe1b6e80047b74bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-61, -26, 108, 50, -33, 59, -40, 91]] |a1=[B:[[83]]\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 15, 7, "\udbf3\udd16\uda9c\udc62\u710f\udb6b\udc08\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u1283", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud82a\ude0d\ud8d8\udd70",
        34, 20710, -1341038501, -1787495971352134552L, -18509L, false, false, (char) 10131, (char) 27268,
        Double.longBitsToDouble(0x3fd651544e9bf656L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 14, 9, "\udbf3\udd16\ud8ec\udc5b\udaf8\ude3c\udb6b\udc19", "\uc366\u20fa\u762d\u79e6", "\ud9d1\udea2",
        28, 44949, -240901539, 8677361809555517198L, -50421L, false, true, (char) 52250, (char) 48571,
        Double.longBitsToDouble(0x3fdc4acc530aaa4eL), Double.longBitsToDouble(0x3fb6db260f158088L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 1, 13, 4, 7, "\udbf3\udd16\udba6\udfe6\udac1\udc62\ud8dc\ude67\ud98b\udf8d\u149f\ud8a3\ude80\uec1e\u28e0\ud8b4\ude03\udb1d\udd84\ud8ff\udcfa", "\u1283\u3358\ua550\u4db8\ub6a6\u921e\u874c\u7bf5\u7049\u7e72", "\udaf6\udc6b\udbbc\udf5d\udb40\udc8b\udae5\udfa7",
        39, 30911, 356782289, -7812491475824851189L, -80373L, true, true, (char) 32164, (char) 58557,
        Double.longBitsToDouble(0x3feb3b892492df48L), Double.longBitsToDouble(0x3fd07316882c3f90L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:51761 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 4, 6, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8", "\u762d\u79e6\u0901\u831c", "\udb6a\udffe",
        26, 51735, 1444474638, -3499538913317405099L, 65642L, false, false, (char) 47502, (char) 8332,
        Double.longBitsToDouble(0x3fd5916bc3c56022L), Double.longBitsToDouble(0x3fe487398954761dL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u1283", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 20710, -1341038501, -1787495971352134552L, -18509L, false, false, (char) 10131, (char) 27268,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-61, -26, 108, 50, -4, 53, 59, -23]] |a1=[B:[[83]]\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 6, 7, "\udbf3\udd16\uda9c\udc62\udb2c\ude65\udb6b\udc19\ud9b6\udc42\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud9b5\udfea\udb1d\udd84\ud8ff\udcfa", "\u1283", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 10110, -1341038501, -1797095807374246808L, -18509L, false, false, (char) 10131, (char) 27268,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 1, 6, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u11b3\u4958\ua550\u0d19\u6a56\uc3e4\u874c\u7bf5\u7049\u0969\ucbea\uc838\u736e\u5065\u219a\u210a\u580a\ub0c6\u48ef", "\udab1\udc0f\uda95\udc0a\udb25\udc6b\udb57\udc7e\udb31\udce3\ud89c\udfb1\u354f\ud8f0\uddf8\ud840\udd18\ud806\ude4d\ud82f\udf85\ud874\ude9e\ud819\udc22\udaa7\ude8e\udb0d\udce7",
        5, 10699, -1610099162, 7023092128621351331L, -65947L, false, true, (char) 51159, (char) 54125,
        Double.longBitsToDouble(0x3fea491e0dfe520bL), Double.longBitsToDouble(0x3fd369faa0748eacL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 6, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\udbbd\udc88\ud85f\ude59\udb1f\udded", "\u1252\u4958\ua550", "\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70\uda60\udfff\ud94a\udc6c\ud82c\udfa5\udaf6\udc6b",
        51, 94932, -575235667, -5238937377431130041L, 72044L, false, false, (char) 53164, (char) 3681,
        Double.longBitsToDouble(0x3feed1a77207876eL), Double.longBitsToDouble(0x3fd887ca7fcb2962L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 3, 6, 7, "\ua001\uda9b\udf87\udaf8\ude3c\udb6b\udc19\uda51\udc8e\ud944\uded8\uda22\ude71\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u665c", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        15, -823, 162290348, -1787512038824788888L, -84045L, false, false, (char) 38191, (char) 33090,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 7, 16, 7, "\ud819\ude2d\udafc\udfe3\ud897\udef5\ud9d5\udf85\ud996\udc17\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud911\udd53\ud8ae\udfd3\udaca\udf05", "\u1283\u4958\ua550\u1776\uc633\ub796\ud55f\u6b5d\u5383\uab90\u630f", "\udbd4\ude66",
        45, 69573, -1219785162, 482853035660568995L, -40685L, false, true, (char) 37065, (char) 13099,
        Double.longBitsToDouble(0x3fb711dd07a1c8d8L), Double.longBitsToDouble(0x3fe807c740c58e60L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 7, 14, 9, "\u2a9d\ud831\ude03\udb29\udf55\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\udada\udc36\ud8c2\udef3\ud8ff\udcfa", "\u1283", "\ud969\udc23\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 90478, -1341038501, -1787495973981762968L, -18509L, false, false, (char) 10131, (char) 27268,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 7, 7, 1, "\udbf3\udc78\ud930\uddc3\udaf8\ude63\uda01\udf19\uda62\udda2\ud96d\udfee\ud94e\udc63\udba7\ude7f\ud91f\udffd\ud882\udfcf\udb45\udcf8\ud8ff\udcfa", "\ud47f", "\uda81\udfc5\udb3d\udf47\udbf3\udd61\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 78858, -1041080891, 1996032388564050084L, 27827L, false, false, (char) 10131, (char) 50508,
        Double.longBitsToDouble(0x3fe1274c074da30eL), Double.longBitsToDouble(0x3f884962fcb924c0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-61, -26, 108, 50, 59, -123, 59, 25]] |a1=[B:[[89, 88, 77, -72, -23, 38, 26, 117]]\012",
        Z.run(T, 1, 5, 7, 10, "\udbf3\udd16\uda9c\udc62\udb6b\uddb5\udb6b\udc49\ud98b\udf8d\uda30\ude78\uda14\udca2\ud8c7\udc8c\ud81d\udfeb\ud8fa\udd46\udbd4\udd64", "\u3389\u9388\u837d\u0de8\u0d19\u6a56\u3f4a\u7fa5\uc40d\u9aa5\u2c15\ub2bb\u2336\u4549\u5065\u46d4\u1fc9\u152a\ua697\uaa74\uba10\ub36f\u3c4e\u3bb6\ubc08\ua794", "\udb36\udcce\ud80b\udc86\ud85d\uddb4\udbd0\udda0\ud923\udee2\ud901\udd9e\udbd0\udda6\ud910\udff9\udbd4\udca5\ud81f\udfb3",
        13, 10442, -1108841968, 1157240529191911731L, 864L, true, true, (char) 35866, (char) 46695,
        Double.longBitsToDouble(0x3fd73d0be3e2b990L), Double.longBitsToDouble(0x3fe671a512c07d8bL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 6, 2, "\uda7c\udfb7\uda85\udd4c\uda9e\udc6e\udb6b\udc19\ud924\udcd9\ud972\udd45\uda22\udef7\ud8c7\udc8c\u8fef\udb0a\udd6f\udb07\udd97\udb6e\uded3", "\u1283", "\udb74\udec8\udb5e\udeef",
        52, 2463, 862357258, -1097318831308224311L, -9797L, false, true, (char) 9114, (char) 46961,
        Double.longBitsToDouble(0x3fdadf2bbc6dbb6cL), Double.longBitsToDouble(0x3fb1edd2c1d10e70L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[76, -121, 85, 28]] |a1=[B:[[-111]]\012",
        Z.run(T, 1, 5, 6, 0, "\uda7c\udfb7\uda85\udd4c", "\ub8c1", "\ud8c7\udc8c\u8fef\udb0a\udd0a\udb07\udd97\udb4b\ude60\udbfc\udc44\uda55\udc67\udb72\udf00\ud958\udd84\udaff\uddaf\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70\uda60\udfff\ud919\udfbe\ud82c\udf77",
        42, 6496, 816850516, -5760433267013873946L, -46694L, true, false, (char) 60012, (char) 48828,
        Double.longBitsToDouble(0x3fc56883d9d56c7cL), Double.longBitsToDouble(0x3fcb44a377635ff8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[76, -121]] |a1=[B:[[84, -12, 29, 54, -81, 0, -30, -84]]\012",
        Z.run(T, 2, 16, 5, 8, "\uda7c\udfb7", "\ud084\u7e24\u574d\uc366\ubadf\u7730\u4b12\ua3dc\u672b\u0f0d\u830a", "\udaff\udd60\udb79\udf20\ud9e7\udd1b\u929c\u6982\ud9b2\ude11\ud8d8\udd70\uda60\udfff\ud915\udf38\ud9a0\ude8e\udb49\udf52\ud88e\udd19\udb66\ude86\udae5\udfa7\ud852\udded\u6245\udb76\udd7a\udb29\udeeb\uc11c\uda0b\udf5c\ud863\udf0d\ud847\udc98",
        19, 16596, -137839796, -4800455929025291523L, -60009L, true, true, (char) 30948, (char) 12151,
        Double.longBitsToDouble(0x3fe960c8cd09a5a8L), Double.longBitsToDouble(0x3fc4a467b80a479cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 15, 4, 16, "\uda7c\udfb7\uda85\udd4c\uda97\udc07\udb6b\udc19\ud924\udcd9\ud972\udd45\ud992\udcb0\udb34\udcc6\u8fb9\udb0a\udd6f\uda04\udcd5\udb6e\udecd", "\ub9bb\u49d7\ua550\u0790\u46cd\u9549\u874c\u7bf5", "\ud94a\udc6c\ud82c\udfa5\udaf6\udc6b",
        23, 51724, -575225427, 5929989697518580584L, 68670L, true, true, (char) 48828, (char) 22232,
        Double.longBitsToDouble(0x3fca714249bddefcL), Double.longBitsToDouble(0x3fe0d3ef8d8e65d8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[]] |a1=[B:[[]]\012",
        Z.run(T, 1, 5, 6, 10, "", "", "\udacc\ude4e",
        44, 39452, 194, -646360139L, -99814L, false, false, (char) 42125, (char) 60676,
        Double.longBitsToDouble(0x3fe000000697f1a4L), Double.longBitsToDouble(0x3fe873c363e65618L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 7, 6, 2, "\uda7c\udfb7\ud978\udde5\uda9e\udc6e\udb6b\udc19\ud924\udcd9\ud972\udd45\uda22\udef7\ud8c7\udc8c\u8fef\udb0a\udd6f\udb07\udd97\ud955\udc05", "\u1283\u4958\ua550", "\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70\uda60\udfff\ud94a\udc6c\ud82c\udfa5\udaf6\udc6b",
        21, 94932, -575225427, -5238937378368884665L, -9275L, true, true, (char) 48828, (char) 37065,
        Double.longBitsToDouble(0x3feac77ccd80bd42L), Double.longBitsToDouble(0x3fb4228ac0ada928L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[76, -121]] |a1=[B:[[-48]]\012",
        Z.run(T, 1, 5, 6, 2, "\uda7c\udfb7", "\000", "\uda22\udef7\ud8c7\udc8c\u8fef\udb0a\udd6f\udb07\udd97\uf9ba\ud9d1\ude94\uda55\udc67\udb6a\udffe\ud958\udd84\udaff\uddaf\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11",
        0, 44889, 1821960710, -5759716504888047134L, 96692L, true, true, (char) 27628, (char) 10131,
        Double.longBitsToDouble(0x3fad10e746515440L), Double.longBitsToDouble(0x3fea6d18f80c1eb1L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[76, -121, 85, 28, 110, 62, 59, -23]] |a1=[B:[[76]]\012",
        Z.run(T, 1, 5, 6, 16, "\uda7c\udfb7\uda85\udd4c\uda9e\udc6e\udb6b\udc19\ud924\udcd9\ud972\udd45\uda22\udef7\ud994\udc92\u8fc9\udb0a\udd6f\udb07\udd97\udb6e\uded3", "\ubd7c", "\udb32\ude3b\ud9a4\ude20\udbd4\udcbe\ud95b\udfba\uda04\ude56\udbe7\udd28\uda60\udfff\ud94a\udc6c\ud82c\udfa5\udaf6\udc6b\udbbc\udf5d\udb40\udc8b\udae5\udfa7\ud852\udded",
        22, 14066, 1903483168, -6108662560106553329L, -88342L, true, false, (char) 48365, (char) 695,
        Double.longBitsToDouble(0x3fceac3b80b62f14L), Double.longBitsToDouble(0x3fea0d3313979fbeL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[28, 121, 112, -120, -56, -79, -84, 66]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 15, 12, "\udb4c\udca9\ud8a0\udeb8\udaf8\udde1\udbdc\udd72\udb0d\udd1f\ud8a6\udc5b\uda91\udeff\udb3f\udf28\ud9a9\ude68\ud912\udd15\ud89d\udf8b\ud8e8\udfa2", "\u1283", "\uda7b\ude3f\ud8e5\udea4\udb2f\udd4d\ud96b\ude70\ud816\ude30\udae7\udd32\ud98f\ude70\ud92a\udde7\ud82c\udfa5\udada\udf2c\ud91a\ude55\u725c\udae5\udfa7\ud852\uddb7\ud8f1\udd90\ud909\udd73\udb36\udea3\ud978\ude62\udb50\ude7b\uda72\udc52\udaa1\udeb6\ud880\udc61\uda88\udfbd",
        44, 40561, 107447196, -5804058899458401847L, 15959L, false, true, (char) 38869, (char) 47406,
        Double.longBitsToDouble(0x3fb92d8f744e2d60L), Double.longBitsToDouble(0x3fce5f4cb7026eb8L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-112, 22, 101, -56, 60, 59, -23, 91]] |a1=[B:[[-23]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 12, 12, "\u33c0\ud946\udc95\udaf8\ude6c\udb6b\udc19\ud98b\udf8d\udb20\ude89\ud892\ude8f\uda80\udce8\u859a\uda8f\udf50\ud9b1\udde1\ud9fd\udf89", "\u7319", "\ud89a\udc6c\udbb3\udce4\uda41\udcf6\ud96b\ude4d\ud9aa\udc42\ud963\uddd5\udbb2\udfe9\udbb9\udc4f\ud82c\udfa5\udaf6\udc6b\udaac\udf51",
        10, 69573, -1219785162, 3581329578937421899L, -84244L, false, false, (char) 21456, (char) 23050,
        Double.longBitsToDouble(0x3fef2f91d24bc1dbL), Double.longBitsToDouble(0x3fc30f80a3f7db68L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[112, 35, 37, -112, -75, -34, -54, -117]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:-1 |a0=[B:[[112, 35, 37, -112, -75, -34, -54, -117]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 17, 17, 1, "\ud9a0\udc53\ud855\udec0\udae5\ude0e\ud8fa\uddbb\ud89d\udc1b\udb5e\udd93\ud9a7\udf70\uda80\udcf9\ud852\udc90\ud839\uddd9\u5a3e\ud8e8\udfa2", "\u47d7", "\ud9b4\udc83\u63fa\uda13\udde2\ud9eb\udfc2\ud8e0\udfc0\ud9df\udd9b",
        17, 64289, -1834716585, -5095900185787160986L, 35203L, false, true, (char) 22942, (char) 5548,
        Double.longBitsToDouble(0x3feca52eaa4a1668L), Double.longBitsToDouble(0x3fe25e63a7650cc2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[-61, -26, 108, 50, 47, -127, 78, 93]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 9, "\udbf3\udd16\uda9c\udc62\uda5f\udcb1\uda7e\udf8d\uda9a\udece\udbd4\udc46\uda22\udef7\ud8c7\udc8c\u8fef\ud881\udfab\ud9b0\udd79\ud828\uded8", "\u1283\u4958\ua550\u0d19\u6a56\uc796", "\ud8d8\udd70\uf5ee\udad5\udc91",
        24, 19106, 1981627496, 5961430359355750318L, -63207L, true, false, (char) 35241, (char) 60012,
        Double.longBitsToDouble(0x3f88496315d10780L), Double.longBitsToDouble(0x3fd8cdb4632c3ad6L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 16, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\000", "\udba3\udc20\ud907\udd23\udb8a\udf6b",
        29, 41243, 2083945724, 3929048492363278854L, 61310L, false, false, (char) 46961, (char) 62312,
        Double.longBitsToDouble(0x3e01edc000000000L), Double.longBitsToDouble(0x3fca2b3671945510L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 8, "\ud862\udf30\ud831\ude15\u3b58", "\u56c0\uc366\u20fa\u762d\u79e6\u9a78", "\u4586\000\udabb\udf1d\udaff\uddaf\udba3\udc20\u4194\udbfc\udfd3\000\ud9b2\ude11\ud8d8\udd70\uda60\udfff\ud94a\udc6c\ud82c\udfa5\udaf6\udc6b\udbbc\udf5d",
        2, 4437, -1224736768, 6463633340808564945L, 71554L, true, false, (char) 37335, (char) 38751,
        Double.longBitsToDouble(0x3fe5d99306efbc88L), Double.longBitsToDouble(0x3fe42d9f460f5b66L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 8, 5, "\ud875\udfff\uda9c\udc62\u3dd7\uda50\udffc\ud829\udd5d\ud8b3\udfb7", "\u762d\u304e\u2771\u22d6", "\ud9b7\udc94\ud93b\udd95\udaff\udd41\ud8dd\udc9b\udb48\udf48\udad4\udf0b\udb0a\ude33\ud88f\ude80\ud894\udcbc\uda17\udd0c\ud9ea\udf9a\ud824\udcd9\uda1c\udf8b\udac7\udd2d\udb1a\udec7\ud9bb\udf33\u8b3e",
        45, 49289, -1558219675, -4349556732912159705L, 6755L, false, false, (char) 41176, (char) 60571,
        Double.longBitsToDouble(0x3fef3db8349d1272L), Double.longBitsToDouble(0x3fde1d16fa27eee2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 0, 10, "", "\ucdf1", "\ud9cf\udd66",
        39, -928, -1644167168, 7667660460196575614L, -100000L, false, false, (char) 0, (char) 39261,
        Double.longBitsToDouble(0x3fbdfc6928770000L), Double.longBitsToDouble(0x3fef3509c8000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-61, -26, 108, 50, -33, 59, -40, 91]] |a1=[B:[[-117, 64]]\0121=java.lang.Boolean:false |a0=[B:[[-61, -26, 108, 50, -33, 59, -40, 91]] |a1=[B:[[-117, 64]]\012",
        Z.run(T, 2, 5, 5, 3, "\udbf3\udd16\uda9c\udc62\u710f\udb6b\udc08\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8f8f\ud924\uddfb\ud9bd\udc15\ud8f2\udf86\ud9d1\udea2\uda55\udc67\uda52\ude32\ud958\udd7e\udaff\uddaf\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\udb49\udce2", "\ub2bb\u0870", "\ud994\udf46\udae5\udfa7\ud852\udded\ud8f1\udd90\udb46\ude11\ud841\udd1c\uda30\udc1b\uda95\uddc8\udad4\udd4b\ud870\ude97\uda73\ude85\ud933\udf20\udac3\udfc1\ud806\udf90\uda36\udc46\ud8b0\udf9f",
        42, 88918, -986186458, -1253890998399034583L, 27932L, true, true, (char) 2038, (char) 23309,
        Double.longBitsToDouble(0x3fc34bbebb015c90L), Double.longBitsToDouble(0x3fee0f69b5c579acL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 17, 7, "\udbf3\udd16\ud864\ude43\udac1\udc62\ud8dc\ude67\ud98b\udf8d\u149f\ud8a3\ude80\udbad\udf01\udae9\udc14\ud8c9\ude9f\udb1d\udd84\ud8ff\udcfa", "\u1283\u3358\ua550\u4db8\ub6a6\u921e\u874c\u7bf5\ucc62\u8c58", "\udaf6\udc6b",
        51, 94932, -575225427, -5239075499284402105L, -70262L, true, true, (char) 50364, (char) 37065,
        Double.longBitsToDouble(0x3fd8714180d7ea72L), Double.longBitsToDouble(0x3fe98f6c63677124L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 6, 7, 5, "\ud8c5\udc38\ud9a0\udec0\ud872\ude7a\udb5c\ude99\udb88\udf4c\uda13\udf4a\uda22\udef7\ud8c7\udc8c\u8fae\ud924\uddfb\udbe5\udda7\udb43\udc6c\ud97f\udd00\uda55\udc62\ud8e5\udf5c\ud908\udca3\udaff\uddaf\udb6d\udc25\ud910\udd09\ud960\ude2d\ud949\udff0\uba6f\ud868\udd85\ud827\udf68\ud94f\udf0b\ud82e\udca3\udaf6\udc6b", "\u1a7b\u9acb\u5703\u79e3\ub13d\u70d9\u571a\u0fd0", "\udbbd\udc3a\ud9c5\udf53\udb88\udd64\ud86b\udfdc\ud896\udc92\ud87d\uded1",
        25, 56767, -1270164907, 2325452359949371255L, -61977L, false, false, (char) 60817, (char) 44277,
        Double.longBitsToDouble(0x3fe617675b3bb7f9L), Double.longBitsToDouble(0x3fbb002d7d6a6028L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 6, 7, "\udbf3\udd16\uda9c\udc62\ud9b1\udc57\udb6a\udf71\ud98b\udf8d\ud972\udcb8", "\u41b3\u649e\ud073\ucc56", "\udb6a\udffe",
        6, 36935, 1451093774, -3499538913317405099L, 65642L, false, false, (char) 47502, (char) 8332,
        Double.longBitsToDouble(0x3fd5916bc3c56022L), Double.longBitsToDouble(0x3fe487398954761dL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[112, 108, 108, 50, -23, 12, 127, -21]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 3, 13, "\udba0\udd9c\uda9c\udc62\udb19\udc3c\udbaf\udc1b\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\ubd63", "\uda71\udc27\ud943\udc09\udbfc\udf2a\u6982",
        43, 39550, 2001794212, 7825261662789787739L, 9023L, false, true, (char) 46184, (char) 27814,
        Double.longBitsToDouble(0x3fb1edd2d672cd98L), Double.longBitsToDouble(0x3fe0934580af47e3L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:-1005 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 4, 7, "\udbf3\udd16\u00e3\udb2c\uddd9\udb6b\udc19\ud9b6\udc42\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud9b5\udfea\udb98\udd82\000", "\u1283", "\uf70e",
        -5, -1000, 1158742016, 3703647786252995158L, -40090L, true, false, (char) 7924, (char) 9080,
        Double.longBitsToDouble(0x3fb51d874d6f9000L), Double.longBitsToDouble(0x3fe006edb000004bL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 6, 1, 7, "\udbf3\udd16\uda9c\udc62\udb2c\ude65\udb6b\udc19\ud9b6\udc42\ud972\udcb8\uda22\udef7\ud908\udcac\u8fef\ud9b5\udfea\udb1d\udd84\ud8ff\udcfa", "\u1283", "\udba3\udc20\udbc8\udd05\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 46526, -1338029992, -1797095807374246808L, -18509L, false, false, (char) 10131, (char) 27268,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:88127 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 4, 7, "\udbbd\udfb9\uda9b\udff7\ud94a\udcaa\udb51\udeaf\ud9b6\udc42\ud972\udcb8\uda22\udef7\udb93\udfe5\u8fef\ud9e9\udf44\udb1d\udde8\ud8ff\udcfa", "\u1283", "\udba3\udc20\ud910\udd09\ud8fc\udccb\ud82f\udc48",
        45, 88082, 914802889, 619502258913108059L, 65781L, false, false, (char) 5083, (char) 27341,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 15, 15, 8, "\udbf3\udd16\uda9c\udc62\udb2c\ude65\udb6b\udc19\ud9b6\udc42\ud972\udcb8\uda22\udef7\ud8c7\udc8c\ud89d\uddab\ud9b5\udfea\ud83f\udddd\ud822\udd20\ud96a\udde3", "\uc5cf\ua56c\u0d19", "\ud991\udd57\ud9ae\ude33\ud8d8\udd70\udb1f\udd28\udaa1\uddd2\ud828\ude59\ud98b\udf00\udbb7\ude17\udb40\udc8b\udae5\udfa7\ud852\udded\udade\udc66\udae0\udc74\ud86f\udd02\ud8f1\udc1f\udb41\udf2a\udbc5\uddeb\ud922\udd17\uda8a\uddf6",
        -5, 98294, 477138168, 5952412425760049451L, -50786L, false, true, (char) 14469, (char) 64100,
        Double.longBitsToDouble(0x3fe4723884185342L), Double.longBitsToDouble(0x3fdc1962903bb7ecL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 3, 6, 1, "\u9f54\uda9b\udf87\uda52\udc16\udb6a\udfa6", "\uc2e0\u20fa\u762d\u79e6\u9a78\u831c", "\ud801\udfa1",
        14, 243, 1444474638, -3499538913317405099L, 65642L, false, false, (char) 17551, (char) 28064,
        Double.longBitsToDouble(0x3fe56604a34509acL), Double.longBitsToDouble(0x3fba39cc4aa3b0e8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 3, 12, 7, "\u9fe6\uda9b\udf87\udaf8\ude3c\udb6b\udc19", "\u3d4a\u9637\u762d\u79e6\u9a78\u831c", "\ub4a1",
        48, 311, 1444474638, -1337811092179567019L, -55913L, true, true, (char) 6977, (char) 13554,
        Double.longBitsToDouble(0x3fba39cc4aa3b0e8L), Double.longBitsToDouble(0x3fdadf2bb5506046L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-23, -3, -9, -58, 103, -59, -91, 85]] |a1=[B:[[83, 40, 32, 70, 3, 102, 47, 45]]\0121=java.lang.Boolean:false |a0=[B:[[-23, -3, -9, -58, 103, -59, -91, 85]] |a1=[B:[[83, 40, 32, 70, 3, 102, 47, 45]]\012",
        Z.run(T, 2, 5, 5, 7, "\ud819\ude2d\uda27\udef6\ud897\udef5\ud9d5\udf85\ud996\udc17\ud972\udcb8\uda22\udef7\udab7\udde3\ud80c\udec3\ud87e\uddff\ud8ae\udfd3\udaca\udf05", "\u1283\u4958\ua550\u1776\uc633\ub796\ud55f\u6b5d\u5383\uab90\u630f\uad85\ud5a7\uaf6e\u069a\u210a\u580a\u2038\ua2d7\ube50\u2bd0\u0a12\u2692", "\udbea\udc88\udb52\udc4d\ud810\ude33\ud843\udc30\uda68\udfdb\udbec\udf2e\ud881\udc27\udb19\udf6d\ud8a3\udf9a\ud8bd\udef2\u7036\udab9\udcb2\ud803\udf6d\udb48\ude1e\udb78\udc8b\ud8bc\ude7d\ud8c4\udede\uda58\udf82\uda60\ude85",
        36, 84145, 35411521, -8853001028783351037L, -25646L, true, true, (char) 51216, (char) 24732,
        Double.longBitsToDouble(0x3febcc11c66d063eL), Double.longBitsToDouble(0x3fb814471bdf6ea8L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 14, 9, "\u2a9d\ud831\ude03\udb29\udf55", "\u56c0\uc366\u20fa\u762d\u2658\u09e4", "\uda55\udc67\udb6a\udffe\ud958\udd84\udaff\uddaf\ud969\udc23\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70\uda60\udfff\ud92b\ude6c\ud82c\udfa5\udaf6\udc6b\ud906\udc21",
        44, 34917, -1219785162, 6463633340808564945L, 78355L, false, false, (char) 37065, (char) 45496,
        Double.longBitsToDouble(0x3fcdae2b0b9c2754L), Double.longBitsToDouble(0x3fef1288a6d01740L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:78682 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Integer:78682 |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 4, 4, 8, "\ud862\udf30\ud831\ude15\u3b58", "\u9741\uc366\u20fa\u762d\u3f4d\u9a78\u831c\u0f0d\u4586\000\uae38\ua550\u0d19\u46bc\u9ad7\000\u7bf5\u7049\u7d03\u8033\u9fed\u547b\ub22b\u627f\ua37c\u6afb\u4dca", "\ud90a\udeb6\ud9b8\ude38\ud94a\udd41\u7bed",
        43, 78639, 1533471424, 4530407983820518093L, 52916L, true, false, (char) 20098, (char) 35894,
        Double.longBitsToDouble(0x3fe49d1618b96877L), Double.longBitsToDouble(0x3feb1c864041e53bL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!java.io.IOException\012",
        Z.run(T, 2, 6, 10, 16, "\udbc2\udd88\uda9c\udc28\ud992\udf09\udb62\ude99\ud98b\udf8d\ud972\udcb8", "\u41b3\u649e\ud073\ucc56", "\udb6a\udffe",
        6, 36935, 1451093774, -3499538913317405099L, 65642L, false, false, (char) 47502, (char) 8332,
        Double.longBitsToDouble(0x3fd5916bc3c56022L), Double.longBitsToDouble(0x3fd8ae7313e916c2L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 7, 6, 7, "\udbf3\udd16\uda9c\udc62\udaf8\ude3c\udb6b\udc19\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u1283", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70",
        34, 20710, -1341038501, -1787495971352134552L, -18509L, false, false, (char) 10131, (char) 27268,
        Double.longBitsToDouble(0x3fb94551226d18f8L), Double.longBitsToDouble(0x3f8848db2ad10780L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 3, 6, 7, "\ua001\uda9b\udf87\udaf8\ude3c\udb6b\udc19\uda51\udc8e\ud944\uded8\uda22\ude71\ud8c2\ude8c\udacf\udfe3\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u665c", "\udba3\udc20\ud910\udd09\udbfc\udf2a\u6982\ud9b2\ude11\ud8d8\udd70\udaba\udc7a\ud88e\ude3c\udbba\udf3d\udaf2\uddce\udbbc\udf5d",
        2, 120, 497906344, 8142639526872092738L, 20336L, false, false, (char) 29663, (char) 40893,
        Double.longBitsToDouble(0x3fcb09a592f10828L), Double.longBitsToDouble(0x3fdbd595d04a9bc2L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[112, 108, 108, 50, -23, 12, 127, -21]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 3, 13, "\udba0\udd9c\uda9c\udc62\udb19\udc3c\udbaf\udc1b\ud98b\udf8d\ud972\udcb8\uda22\udef7\ud8c7\udc8c\u8fef\ud990\ude5f\udb35\udc81\ud8ff\udcfa", "\ubd63\u7e2b\ucf70\u25a0\u5d57\uc796\u874c\u7bf5\u7049\u120e\ub2bb\u878b\u1d5f\ubddc\u219a\u210a\u58c4", "\uda2a\ude4e\u9617\ud950\udf7a\ud85f\udf5c\uda75\udc01\ud9f8\uddff",
        39, 18, 1393043606, -476694995052450079L, -86851L, false, false, (char) 59207, (char) 25156,
        Double.longBitsToDouble(0x3fe4e1d092abdd4aL), Double.longBitsToDouble(0x3feeb02f35c21a25L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-48, -48, -48, 78, 93, 106, -98, -92]] |a1=[B:[[-48, -48, -119, -23, 38, 102]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 9, "\000\000\000\uda7e\udf8d\uda9a\udece\udbd4\udc46\uda22\udef7\ud8c7\udc8c\u8fef\ud881\udfab\ud9b0\udd79\ud828\uded8", "\000\000\u76b9\u0d19\u6a56\uc796", "\ud8d8\udd70\uf5ee\udad5\udc91",
        24, 19106, 1981627496, 5961430359355750318L, -63207L, true, false, (char) 35241, (char) 60012,
        Double.longBitsToDouble(0x3f88496315d10780L), Double.longBitsToDouble(0x3fd8cdb4632c3ad6L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-48, -48, -48, 78, 93, 106, -98, -92]] |a1=[B:[[-48, -48, -48, -23, 38, 102]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 9, "\000\000\000\uda7e\udf8d\uda9a\udece\udbd4\udc46\uda22\udef7\ud8c7\udc8c\u8fef\ud881\udfab\ud9b0\udd79\ud828\uded8", "\000\000\000\u0d19\u6a56\uc796", "\ud8d8\udd70\uf5ee\udad5\udc91",
        24, 19106, 1916008, 5908794538710857646L, -63207L, true, false, (char) 35241, (char) 60012,
        Double.longBitsToDouble(0x3f88496200110780L), Double.longBitsToDouble(0x3fd8cdb0032c3ad6L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-48, -48, -48, -48, 45, -2, -93, 81]] |a1=[B:[[-48, -48, -48, -48, 64, 102]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 9, 9, "\000\000\000\000\uda5d\udc2e\udbd3\udf81\uda22\udef7\ud8c7\udc8c\ud8f9\udce7\ud881\udfab\ud9b0\udd79\ud828\uded8", "\000\000\000\000\u6970\uc796", "\uda7a\ude61\uf525\udad5\udc91",
        24, 19106, 1981627496, 5908722709677799342L, -63207L, true, false, (char) 0, (char) 18253,
        Double.longBitsToDouble(0x3f88496315d10780L), Double.longBitsToDouble(0x3fd8cdb4632c3ad6L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-48, -48, -48, 78, 93, 106, -98, -92]] |a1=[B:[[-48, -48, -48, -23, 38, 102]]\0121=java.lang.Boolean:false |a0=[B:[[-48, -48, -48, 78, 93, 106, -98, -92]] |a1=[B:[[-48, -48, -48, -23, 38, 102]]\012",
        Z.run(T, 2, 5, 5, 9, "\000\000\000\uda7e\udf8d\uda9a\udece\udbd4\udc46\uda22\udef7\ud8c7\udc8c\u8fef\ud881\udfab\ud9b0\udd79\ud828\uded8", "\000\000\000\u0d19\u6a56\uc796", "\udaed\udea9\ud9e0\udcb3\udb01\ude63\ud82c\udfa5",
        16, 97008, 1375748436, -6151644766177907044L, -95695L, true, false, (char) 59989, (char) 50364,
        Double.longBitsToDouble(0x3f3107ac66d80000L), Double.longBitsToDouble(0x3fd961d6b681d0deL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-60]] |a1=[B:[[]]\0121=java.lang.Boolean:true |a0=[B:[[-60]] |a1=[B:[[]]\012",
        Z.run(T, 2, 5, 5, 2, "\ufdf4", "", "\udbd3\udf81",
        26, 45222, -1107296053, -4937672040561463593L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe800000655cf6fL), Double.longBitsToDouble(0x3fd70520f3793ee6L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 1, 3, 14, 7, "\ua001\uda9b\udf87\udaf8\ude3c\udb6b\udc19\uda51\udc8e\ud8d7\udc24\uda22\ude71\ud8c7\udc8c\u8fef\ud924\uddfb\udb1d\udd84\ud8ff\udcfa", "\u665c", "\udba3\udc20\ud910\udd09\udbfc\udf2a\ud9c2\udc03\udace\udc66\udaee\udc4e",
        47, 43, 162290348, -1787512038824788888L, -84045L, false, false, (char) 38191, (char) 33090,
        Double.longBitsToDouble(0x3fb945513a6d18f8L), Double.longBitsToDouble(0x3f8849632ad10780L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-48, -48, -48, -48, 39, -5, -48, -48]] |a1=[B:[[-48, -48, -48, -48, 64, -48]]\0121=java.lang.Boolean:false |a0=[B:[[-48, -48, -48, -48, 39, -5, -48, -48]] |a1=[B:[[-48, -48, -48, -48, 64, -48]]\012",
        Z.run(T, 2, 5, 5, 0, "\000\000\000\000\ud957\udc2b\u3b00\000\000\ud8f9\udc1c\ud881\udfab\u00d7\000", "\000\000\000\000\u4670\000", "\uda7a\ude61",
        -5, 20120, -1342152613, -1765012058075743128L, -36768L, false, false, (char) 65427, (char) 179,
        Double.longBitsToDouble(0x3e4d340000000000L), Double.longBitsToDouble(0x0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|canReadEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|supportsCompressedSizeFor|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|bufferContainsSignature|java.io.ByteArrayOutputStream,int,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|cacheBytesRead|java.io.ByteArrayOutputStream,int,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|checksig|[B,[B|static",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|close||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|closeEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|currentEntryHasOutstandingBytes||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|drainCurrentEntryData||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|fill||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|findEocdRecord||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getBytesInflated||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|getNextZipEntry||new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|isFirstByteOfEocdSig|int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|canReadEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|supportsCompressedSizeFor|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|new:org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
