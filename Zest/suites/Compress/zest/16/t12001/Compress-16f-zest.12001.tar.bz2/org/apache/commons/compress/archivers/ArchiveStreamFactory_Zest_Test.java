package org.apache.commons.compress.archivers;
import org.junit.Test;
import static org.junit.Assert.*;
public class ArchiveStreamFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 1, "\udb0c\udebf\ud8f6\udf78\uda2c\udf2f\u7d76", "\uc692\ua7a4\ud12a\ud230\u5e43\ud673\u1d84\u9489\uc975\u8190\u45cf\u160c\u4ee8", "\u5d16\ud891\udc78\ud801\udc13\udad6\udd81\ud80f\udc7f\ua007",
        50, 91161, 1828131513, 598884423520614730L, 94281L, true, true, (char) 9876, (char) 2790,
        Double.longBitsToDouble(0x3fed775a921dde77L), Double.longBitsToDouble(0x3fc7423e392b9448L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 1, "\udb4e\uddcc\ud921\uded1\uda2c\udf2f\u7d76", "\uc692\ua7a4\ud12a\ud230\u5e43\ud673\u2a0e\u9489\uc975\u8190\u45cf\u160c\u76e9", "\u5d16\ud891\udc78\ud801\udc13\udad6\udd81\uda8c\udd5e\ud942\uddd2",
        1, 91161, 1828131513, 598884423520614730L, 94281L, true, true, (char) 9876, (char) 2790,
        Double.longBitsToDouble(0x3fed775a92483377L), Double.longBitsToDouble(0x3fc7423e392b9448L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 1, "\udb0c\udebf\ud8f6\udf78\uda2c\udf2f\u7d76", "\uc692\ua7a4\ud12a\ud230\u5e43\ud673\u1d84\u9489\uc975\u8190", "\udb8d\uddc6\ud9d9\udf43\u5977\u5d16\ud891\udc78\ud801\udc13\udad6\udd81",
        15, 43979, -720651890, 7336497459434169L, 29354L, false, false, (char) 57651, (char) 28628,
        Double.longBitsToDouble(0x3fef3e2855ba4e4cL), Double.longBitsToDouble(0x3fe749ba75bb2faeL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 1, "\udb0c\udebf\ud8fe\udd78\udbb8\udcb5\u7d76", "\u0d18\u493a\ud158\ud230\u5e43\ud673\u1d84\u9489\uc975\u8190\u45cf\u160c\u4ee8", "\u5d16\ud891\udc78\ud801\udc13\udad6\udd81\ud80f\udc7f\ud94e\uddc0",
        50, 91161, 1828131513, 598884423520614730L, 94281L, true, true, (char) 693, (char) 36217,
        Double.longBitsToDouble(0x3fed77d9921dde77L), Double.longBitsToDouble(0x3fd77806c177ea96L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 1, 1, "\udb0c\udebf\ud8f9\udf78\uda2c\udf2f\u7d76", "\uc692\ua7a4\ud12a\ud230\u5e43\u2774\u1d84\u9489\uc975\u8190\u74c7\u160c\ud068\u5b0d\u1d92\ud4e4\ua6cf\u3940\u663b\u060e\u81cd\u1ea5\uc09f\u163d\u9cb0\ua563\u0cf2\u0514\ua7b0\u101c\ubf46\ua76c\ub3f2\ua991", "\udab8\udf2b\udaf1\udf23\uda92\udc12\ud9ca\ude2b\ud9b0\udc00\ud9c1\udfde\udb50\udc2b\ud919\ude17\ud8bc\udf6e\ud933\udd94\udb8e\udd8a\uda2a\ude73\uda1c\udd6b\uda89\udd7b\udb93\udd93\ud9e9\udf77\udbf8\udeec",
        43, 9293, -1781035065, 3493008928670625726L, 94112L, false, true, (char) 49541, (char) 40819,
        Double.longBitsToDouble(0x3fc69f13f9c43690L), Double.longBitsToDouble(0x3fdbfb7bf0690b64L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 1, "\udb0c\udebf\ud8f6\udf78\uda2c\udf2f\u7d76", "\u6d6d\u264d\ud12a\ud230\u5e43\u0ae6\u1d94\u9489\uc975\u8190\u45cf\ud1b9\u4e58", "\u5d16\ud9a6\udfa5\udb40\udc31\ud9fc\udfd4\ud80f\udc7f\ua007",
        50, 91161, 1828131513, 598884423520614730L, 94281L, true, true, (char) 9876, (char) 2790,
        Double.longBitsToDouble(0x3fed775a921dde77L), Double.longBitsToDouble(0x3fc7423e392b9448L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\012",
        Z.run(T, 2, 3, 3, 4, "\udb0c\udebf\ud8f6\udf78\uda2c\udf2f\ud873\udd8a", "\uc692\ua7a4\ud12a\ud230", "\ud90d\udc96\udad8\udff7\ud920\ude8c\uda5f\udff9\ud8cf\ude58\ud86b\udc78\udb8d\uddc6\ud9d9\udf43\ud95f\uddfa\ud845\udc4c\ud893\udc39",
        22, 45089, 1773688566, -3869972100120438544L, 281L, false, true, (char) 23083, (char) 27175,
        Double.longBitsToDouble(0x3fe3ec35b4847b50L), Double.longBitsToDouble(0x3fef3e2855ba4e4cL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 0, 1, "\udb0c\udebf\ud81e\udf6c\udbac\udd55\ud910\udc9a", "\u1436\ua7aa\u33bc\ud197\u5e43\ud673\u63be\u843d\u53ce\u9048\u9e7e\u160c\u75d7", "\uda5c\udff8\ud8bf\udf95\ud84c\udd16\udad6\udd81\uda92\uded2\ud8fa\udcdc",
        0, 19352, 1276372510, 598884591024339274L, 7907L, false, true, (char) 39191, (char) 3608,
        Double.longBitsToDouble(0x3fe749ba75bb2faeL), Double.longBitsToDouble(0x3fd390f5a786f8acL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\012",
        Z.run(T, 1, 3, 4, 1, "\udb4e\uddcc\ud921\uded1\uda2c\udf2f\u7d76", "\uc692\ua7a4\ud12a\ud230\u5e43\ud673\u2a0e\u9489\uc975\u8190\ua5cf\u160c\u76e9", "\u5d16\ud891\udc78\ud801\udc13\udad6\udd81\uda8c\udd5e\ud942\uddd2",
        1, 91161, 1828131513, 598884423520614730L, 94281L, true, true, (char) 9876, (char) 2790,
        Double.longBitsToDouble(0x3fed775a92483377L), Double.longBitsToDouble(0x3fc7423e392b9448L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\012",
        Z.run(T, 1, 3, 1, 1, "\udb4e\uddcc\ud921\uded1\uda2c\udf2f\u0098", "\uc692d\000\000\000\000\000\u940a\uc975\u8190\u45cf\u160c\uabe8", "u\ud891\udc78\ud801\udc13\udad6\udd81\ud960\uded0\ud942\uddd2",
        -2, 3225, 0, 598884423520614730L, 94281L, true, true, (char) 9876, (char) 2790,
        Double.longBitsToDouble(0x3fed775a92483377L), Double.longBitsToDouble(0x3fc7423e39280048L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 1, "\udb0c\udebf\ud8f6\udf78\uda2c\udf2f\u7d76\udae3\ude17\udad9\udf63", "\ud12a\ud230\u5e43\ud673\u1d84\u9489\uc975\u8190\u45cf\u160c\u4ee8", "\u5d16\ud891\udc78\ud801\udc13\udad6\udd81\ud80f\udc7f\ua007",
        50, 91161, 1828131513, 598884423520614730L, 94281L, true, true, (char) 9876, (char) 2790,
        Double.longBitsToDouble(0x3fed775a921dde77L), Double.longBitsToDouble(0x3fc7423e392b9448L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 1, "\udb0c\udebf\ud8fe\udd78\udbb8\udcb5\u7d76", "\u05b3\u01b2\ua3e7\ud1f7\u5e43\ud673\u1d84\u9489\uc975\u8190\u45cf\u160c\u4ee8", "\u5d16\ud891\udc78\ud801\udc13\udad6\udd81\ud80f\udc7f\ud94e\uddc0",
        50, 91161, 1828131513, 598884423520614730L, 94281L, true, true, (char) 693, (char) 36217,
        Double.longBitsToDouble(0x3fed77d9921dde77L), Double.longBitsToDouble(0x3fd77806c177ea96L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.lang.String,java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveOutputStream|java.lang.String,java.io.OutputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "C|org.apache.commons.compress.archivers.ArchiveStreamFactory|<init>|",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.lang.String,java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
