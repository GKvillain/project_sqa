package org.apache.commons.compress.utils;
import org.junit.Test;
import static org.junit.Assert.*;
public class IOUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 1, 4, 2, "\ud8c4\ude62", "\uafb9\u99f8\uab02\u0536\uaf4d\u4967\u633f\u244c\u9bdc", "\udb15\ude68\ud913\uddae\udac6\uddbe",
        33, 54148, 1345472599, -681274274071940655L, -52010L, false, false, (char) 46237, (char) 9957,
        Double.longBitsToDouble(0x3fc72257ed8ae684L), Double.longBitsToDouble(0x3fe6831bb25b6202L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 1, 4, 1, "\ud8c4\ude62", "\uafb9\u99f8\uab02\u0536\uaf4d\u4967\u633f\u244c\u9bdc", "\udb15\ude68\ud913\uddae\udac6\uddbe",
        33, 54148, 1345472599, -681274274071940655L, -52010L, false, false, (char) 46237, (char) 9957,
        Double.longBitsToDouble(0x3fc72257ed8ae684L), Double.longBitsToDouble(0x3fe6831bb25b6202L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 1, 4, 2, "\udae3\udc44", "\uafb9\u99f8\uab02\u0536\uaf4d\u4967\u9a27\u18dd\u87cd", "\udbb6\udd64\ud913\uddae\udac6\uddbe\udb89\udd14\ud867\udcb8\udb87\udd10\ud97c\uddf2\udb21\ude5d\ud86b\uddb3\uda5b\udf8f\uda21\udcdd\u0829\udb42\udf2b\ud950\udc93",
        29, 32536, 735562331, 8688956784510109657L, -18732L, true, false, (char) 61294, (char) 34122,
        Double.longBitsToDouble(0x3fe58d254edae7acL), Double.longBitsToDouble(0x3fcfd7bc3b46f530L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 3, 4, "\ud8c4\ude62", "\uafb9\u937d\u5783\u1a18\uafd0\u4967\u633f\u8d0a\u9632", "\uda05\udc3f\udaeb\udf36\ud95b\udc63",
        33, 54148, -2127411113, -681274274071940655L, 13526L, false, false, (char) 60611, (char) 51570,
        Double.longBitsToDouble(0x3fdb98fbf6c57342L), Double.longBitsToDouble(0x3fe6831bb25b6202L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 3, "\ud807\ude4e\ud91e\udf49\ud9a0\uddea", "\u1417\u5aab\u6f45\u25a5\u2675\u52ea\u42a6\u33b0\u193e\u113e\u5265\uaf91\u6de5\u13e4\u1fbd\u4d7e\u51ba", "\ud93e\udd2c\ud9d2\udf01\ud94a\udeb6\udb49\udd20",
        56, 93556, 967219469, 2414030779489519334L, -62283L, false, true, (char) 8238, (char) 45767,
        Double.longBitsToDouble(0x3fe715f63ee63747L), Double.longBitsToDouble(0x3fd4ec25f3f43034L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 0, 4, 2, "\ud8c4\ude62", "\u15f9\u99f8\uab02\u0536\u4d87\uc2f7\u0e64\u5c4c\u9bdc", "\udb15\ude68\ud913\uddae\udac6\uddbe",
        33, 54148, 1345472599, -681274274071940655L, -52010L, false, false, (char) 46237, (char) 9957,
        Double.longBitsToDouble(0x3fc72257ed8ae684L), Double.longBitsToDouble(0x3fcf6c6ec8096644L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 4, 2, "\ud9e0\udd92", "\u08ec\u5960\u61e5", "\uda5b\udd38\udabe\ude91\ud976\udce5\udbac\ude32\ud9de\udc54\ud827\udc87\udb15\ude68\ud913\uddae\udac6\uddbe\udb89\udd14\ud866\udffe\udb87\udd10\ud94c\udc19\udaca\ude7d\uda00\udc02\u6e13\ud81e\udcec\ud867\udd27\udb4c\udee0\ud950\udcd6\udae4\udc01\uda7e\udc96\uda66\udd74\udbbe\ude25\udb87\uddd7\udb85\udceb",
        -1, 515, -2017068, -782029718959270473L, 447L, true, true, (char) 18463, (char) 37450,
        Double.longBitsToDouble(0x3fc0f8156c0424d4L), Double.longBitsToDouble(0x3fe0ac7d6004f799L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.IOUtils:@?\012",
        Z.run(T, 1, 7, 4, 2, "\ud8c4\ude62", "\uafb9\u99f8\uab02\u0536\ub450\u4967\u633f\ud01d\u5af4", "\udb15\ude68\ud913\uddae\ud851\uddf9",
        25, 76972, -195052398, -681274673503899183L, -8167L, true, true, (char) 24102, (char) 11357,
        Double.longBitsToDouble(0x3fef2f9d01ce7100L), Double.longBitsToDouble(0x3fae577fb90ccda0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 3, 3, "\ud8b7\udd35", "\u6a18\u99f8\uab02\u0536\u5cbf\ubaa0\u9074\u30a8\u14dc", "\udbb6\udc58\ud913\udd46\udac6\uddbe\udb89\udd14\uda94\udfe6\ud869\udeb9\ud94c\udc19\ud8ad\udef9\ud951\udf03\uda5b\udf8f\uda21\udcdd\uda1a\udfaa\udafb\ude87",
        48, 91314, 1644346064, 2543755727739239702L, -16222L, false, true, (char) 28129, (char) 19496,
        Double.longBitsToDouble(0x3fc2b2d32dab1c54L), Double.longBitsToDouble(0x3fb912819e013358L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void\0121=new org.apache.commons.compress.utils.IOUtils:@?\012",
        Z.run(T, 2, 1, 7, 7, "\ud8c4\ude62\udb51\udc7e", "\ub07b\u49aa\u9498\u797b\u62da\u633f", "\ud80f\udd01\udad3\udee9\udad5\udcd8\ubea6\udb29\udfc9\ud83a\uddc5\uda54\ude2e\udb47\udd00\ud80b\udd10\ud939\udde0\udbe6\udf18\ud95a\udc96\uda83\udc16\ud87d\udec5\ud8b1\udcc7\udac4\udd02\ud87a\udffd\ud807\udd38\ud9ee\udf7b\ud84d\udd48\ud876\udf11",
        13, 58836, 1063766051, 285126102984200605L, 38783L, true, false, (char) 37125, (char) 43327,
        Double.longBitsToDouble(0x3fd8500019be9d8aL), Double.longBitsToDouble(0x3fe6c609ebd94453L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 1, "\ud859\udf5f", "\uafb9\u99f8\uab02\ud4e8\uaf4d\uaf08\ub3be\u5e8a\u70d1\u9b47", "\ud913\udd5d",
        41, 78523, 1677160148, 6458241403994167225L, -26247L, true, false, (char) 6788, (char) 46237,
        Double.longBitsToDouble(0x3fe08fa69cb912bfL), Double.longBitsToDouble(0x3feb15cd0fd06376L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 1, 1, 2, "\uda8f\udec9", "\u900b\u575a\uab02\u0536\uaf4d\u4967\u633f\u244c\u61e1\u3414\u5a3e\u0ab6\u0bd4\ub975\u2efc\u1d4f\u8763\u4d73\u96a6\ud017", "\ud984\udc29\udb42\udf2b\ud950\udc93\uda1e\udd3e\uda7e\udc96\udb4a\udc86\ud936\ude81\ud9e8\udd56\udaf5\udd8e\udba8\udf85\ud921\udca4\udb46\udd67",
        38, 68019, 1777902935, -1694139755817702091L, 21418L, true, false, (char) 45781, (char) 6022,
        Double.longBitsToDouble(0x3fe4daaebad2903fL), Double.longBitsToDouble(0x3fc4b5242117f424L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 2, "\ud8c4\ude62", "\uafb9\u99f8\uab02\u0536\uaf4d\u99ff\u6335\u244c\u9bdc", "\udb15\ude68\ud913\uddae\udac6\uddbe",
        33, 54148, 1345472599, -681274274071940655L, -52010L, false, false, (char) 46237, (char) 9957,
        Double.longBitsToDouble(0x3fd738abf70e92faL), Double.longBitsToDouble(0x3fe683199a5b6202L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 5, 3, 0, "\ud8c4\ude62", "\uafb9\u99f8\uab02\u428b\u8198\u4967\u9de9\ub709\u1e6d", "\uda86\udecb\uda50\udf4e\uda46\uddb9\udb89\udd11\ud867\udcd8\udb87\udd10\udada\ude78\udb0d\uddc8\udaab\udd52\udb20\uddd1\ud8dd\udfa8\udb8b\udca4\ud884\udd4b\ud950\udc93\uda1e\udd3e\uda7e\udc96",
        -2, 2889, 573252078, -8053811859870579023L, 68134L, false, false, (char) 48330, (char) 5759,
        Double.longBitsToDouble(0x3fd3e821778559acL), Double.longBitsToDouble(0x3fc955c8a6dab6b8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.IOUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 2, 2, "\ud8c4\ude62", "\uafb9\u99f8\uab02\u0536\uaf4d\u4967\u633f\u244c\u9bdc", "\udb15\ude68\ud86c\ude68\udaac\udf1b",
        33, 54148, 1345472599, -681274274071940655L, -52010L, false, false, (char) 46237, (char) 9957,
        Double.longBitsToDouble(0x3fc72257f65cdc40L), Double.longBitsToDouble(0x3fe6831bb25b6202L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 2, 2, "\ud9cb\udd9c\ud98f\uddcc\udba1\udf33\ud8f5\uddea\ud948\ude5b\uda1e\udc00\uda45\udf53\ud9bb\udcb1\uda21\ude31\udab2\ude8b\ud976\udce5", "\u1ca2\u0ab6\u0bd4\ub375\u2efc\u1d4f", "\udb0d\uddc8",
        27, 32546, 1963355900, -805211045181312495L, -4610L, false, false, (char) 11357, (char) 1974,
        Double.longBitsToDouble(0x3fe8934cafd0af4eL), Double.longBitsToDouble(0x3fe667fc42b897adL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 0, 4, 2, "\ud8c4\ude62", "\uafb9\u99f8\uab02\u0536\uaf4d\u4967\u2f28\u5d08\u9bdc", "\udb15\ude68\ud913\uddae\udac6\uddbe",
        33, 48157, 1345472576, -681274274071940655L, -52010L, false, false, (char) 46210, (char) 9957,
        Double.longBitsToDouble(0x3fc72257ed8ae684L), Double.longBitsToDouble(0x3fe6831bb25b6202L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 4, 2, "\ud9a5\udf53\ud997\udfa7", "\u9005\u2dbd\uadc3", "\ud82c\ude27\ud8b3\ude03\udbac\uddca\ud9de\udc54\ud827\udc87\udb15\ude68\ud913\uddae\udac6\uddbe\udb91\ude34\ud867\udcb8\udb87\udd10\ud94c\udc19\udb2d\udc98\udab0\uddbd\uda5b\udf8f\uda21\udcdd\ud984\udc29\udadb\udc77\ud875\uddd0\uda1e\udd3e\uda7e\udc96\ud93f\udda0\udbe2\udedc\uda4a\ude79",
        58, 71951, 2118729228, 6599400405081889905L, -68059L, true, false, (char) 45617, (char) 17205,
        Double.longBitsToDouble(0x3fe68140c658f9b3L), Double.longBitsToDouble(0x3fe4818e991597e4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 2, "\ud8c4\ude62\ud9da\udc0e\ud8ef\udd62\ud970\udced\udb76\udc97\udb44\udd1a\uda49\udd65\ud875\udef0\uda5b\udd38\u5d7e\udaf5\ude19\udb97\udc1f\udbeb\udfb9\ud827\udc7b\udb1e\udd68\ud913\uddae\udb8a\ude1f\uda72\udfec\ud867\udcb8\u5659\ud9e4\udf1f\udb15\udfbc\ud8dc\udf0c\ud840\udcaa\uda21\udcc1\ud99f\udc29\ud825\udf6e\ud96f\udc0b\uda1e\udd3e\u113a\udb1d\uddb0\ud863\udedf\udaca\ude40\ud974\ude29\ud848\udfd1\ud974\ude6f\udaab\udd1a\udb6d\udc23\ud890\udd3a\ud8d4\udd48\ud8a8\udcaf\ud9a9\udd14\ud81f\udd34\udb56\ude17\udb65\udd32\ud836\udd7d\udac9\udfe8\u22eb\ud8fd\ude47\uda26\udddd\udbb4\udfe3\ud90d\uddeb\u3d6e\ud8fc\udf11\ud95f\ude65\ud830\ude6e\udb02\udd03\uda65\udf4f\uda30\udfc7\ud9e6\ude27\ud854\udc95\udb7d\udcf3\ud92d\udd1e\ud880\uddc4\udbd9\udc67\ud8c8\udd3a\udbc7\udcbd\ud82c\udc15\uda34\udc62\ud957\udfa4\udb44\udf06\udbbc\udf84\ud93f\udd20\ud829\udff6", "\ua9f9\u2fae\u72c0\ud060", "\ud849\udf24",
        41, 64801, -570057413, -1340255698115199877L, 6161L, false, false, (char) 28031, (char) 10362,
        Double.longBitsToDouble(0x3fcbf179f7f78820L), Double.longBitsToDouble(0x3fd7ae3be66d70a4L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.IOUtils:@?\012",
        Z.run(T, 1, 7, 0, 2, "\udad2\udd43\udae1\udddb\udba1\udee4\ud98b\udee7\ud9e7\udd50\ud90f\udf48\uda21\udd93\ud881\udf58\udbab\udd40\udab2\ude8b\uade3\udbac\ude32\ud8c4\ude67\ud827\udcc3\udb15\ude68\udb46\udf1d\ud969\udc1c\uda4d\uded2", "\u4d73\u2e28\uc95b\u46c3\ud542\u6b93\u0849\u347c\u5144\uca66\uc2d6\ubaf6\u0395\u1c9a\u174f\u9e30\u3995\ub3a4\ub396\ua396\u57d1\u9d5b\u827b\u8693\u5175\ua8be\uc062\u207f\ucbe5\u6e3a\ube70\u08b7\u4531\ub247\u6931\ub05d\u3c1f\u3d57\u6c45\ua180\u0280\u8ce5\u32d8\u6e81\u146b\u929c", "\ud9e6\udd09\ud8ab\udd05",
        50, 99977, 1796109973, -5763564392921715825L, 12151L, true, true, (char) 28369, (char) 51468,
        Double.longBitsToDouble(0x3fadb98063f2e5f0L), Double.longBitsToDouble(0x3fe52a4429db2e9aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 4, "\ud825\ude33", "\uafb9\u937d\u0996\ud29c\u4ca3\u56eb\uc1a7\u5d7a\u95fc\u5172\ud355\u81c3\u3ce9\u5d94\u2efc\u1d4f\u220d\u4d73", "\ud97b\udea2\uda4a\ude26\uda41\udffc\ud922\udcfc\ud85e\udeb0\uda1e\udd3e\udb63\udfbd\ud9be\udc38\udaea\ude41\uda5b\udf3c\u154d\uda6e\udf17\ud906\ude16\ud91f\udc5f\udb87\udfa3",
        37, 86858, 1315123892, 7513188695827455114L, -19851L, true, true, (char) 5438, (char) 33324,
        Double.longBitsToDouble(0x3fe742e3c913387dL), Double.longBitsToDouble(0x3fe905f2369e6fa8L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 3, "\ud807\ude4e", "\uafb9\u0eaf\u1417", "\udba0\udefb\udb9b\ude2c\ud894\udefe\uda7a\uddce\ud9dd\udfb2\ud8ff\uddd1\udb1c\ude38\ud93a\udfee\ud847\ude38\ud94a\udde8\ud8ec\udf2a\udaaa\uddbf\ud94c\udc24\udad2\udf0c",
        2, -1000, -150851328, 3092574887193250242L, 43624L, false, true, (char) 64432, (char) 38362,
        Double.longBitsToDouble(0x3fccc4301484c154L), Double.longBitsToDouble(0x3fc5720edc1b450cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.IOUtils:@?\0121=new org.apache.commons.compress.utils.IOUtils:@?\012",
        Z.run(T, 2, 7, 7, 7, "\ud807\ude4e\ud91e\udf49\ud9a0\uddea", "\u1417\u5aab\u6f45\u25a5\u2675\u52ea\u42a6\u33b0\u193e\u113e\u5265\uaf91\u6de5\u13e4\u1fbd\u4d7e\u51ba", "\ud93e\udd2c\ud9d2\udf01\ud94a\udeb6\udb49\udd20",
        56, 93556, 967219469, 2414030777107154662L, 79070L, false, false, (char) 44320, (char) 45664,
        Double.longBitsToDouble(0x3fe715f63ee63747L), Double.longBitsToDouble(0x3fd4ec25f3f43034L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 0, 0, 6, "\ud807\ude4e\ud91e\udf49\ud9bc\udd16", "\uba85\u85e7\u6fdd\u25a5\u2675\u19bb\ucb5d\ub5af\u193e\u113e\u5265\uaf91\u6de5\u3691", "\udaf5\udc31\ud8cd\uddac\udb11\udea9\udb18\udd39\ud960\udf0e\udbe0\udeaf\udb49\uddbe\uda5a\udcca\ud8b4\udd6f\udb06\uddf4\udb32\ude40\udb15\uddba\ud8e9\ude8e\udb98\udde9\ud909\udf20\ud8ee\udd1f",
        11, 78090, -1033947418, -3739477194757327729L, 57877L, true, false, (char) 21900, (char) 24294,
        Double.longBitsToDouble(0x3fea656da90e92aeL), Double.longBitsToDouble(0x3fe9da87a959b131L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.IOUtils:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 5, 6, "\ud807\ude4e\uda12\udf64\ud871\udd3d", "\u1417\u5aab\u6f45\u25a5\u15dd\u52bc\u42a6\u33b0\u193e\u113e\u5265\uaf91\u6de5\u13e4\u1fbd\u4d7e\u51ba", "\ud93e\udd2c\ud9d2\udf01\ud94a\udeb6\udb49\udd20",
        56, 94956, 967238261, 2414030779489519334L, -62283L, false, true, (char) 8238, (char) 45767,
        Double.longBitsToDouble(0x3fe715f63ee63747L), Double.longBitsToDouble(0x3fd4ec25f3f43034L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 1, 3, "\uba40", "\uafb9\u0eaf\u1417\u51f2\u7aad\u2189\ubaa5", "\ud9dd\udfb2\ud8ff\uddd1\udb1c\ude38\ud93a\udfee\ud847\ude38\ud94a\udde8",
        24, 10699, -158621517, -8273831799066561208L, 43796L, false, false, (char) 46252, (char) 32934,
        Double.longBitsToDouble(0x3fe7c65508e41eedL), Double.longBitsToDouble(0x3fd0d629d868734cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a1=[B:[[]]\012",
        Z.run(T, 1, 4, 4, 0, "", "*\000\000", "\ud9fc\udcde",
        21, -1000, -68501213, 2153732652961424034L, -100000L, false, false, (char) 39581, (char) 21361,
        Double.longBitsToDouble(0x3fe0d5d5405763f7L), Double.longBitsToDouble(0x3fc50a0650dfda2cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 5, 0, "\ud91f\udf55\udae6\udd5c\ud99b\udfdb\ud9e4\ude6a\ud888\udf3f\udb63\uddb6", "\u010e\u66cc\u373b\u15fb\u2eff\u12a0", "\udafe\udf82\ud83a\uddc5\uda54\ude2e\ud971\udc33\ud92b\uddc1\ud90f\udcbc\ud986\udcc3\udaaa\ude4a\udb75\uddfb\uda61\udc80\udbc1\ude1b\ud8af\udd04\ud8f9\udc38\udac1\udff7\ud9ee\udf06",
        -5, 71157, 2080657233, -5755725031386134493L, -43779L, true, false, (char) 11097, (char) 52251,
        Double.longBitsToDouble(0x3fe0fee145bb843eL), Double.longBitsToDouble(0x3fcb0cab4deff39cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 5, 2, "\ud8e4\udc62", "\uafb9\u99f8\uab02\u2c52\u8dca\u878d\ud791\u5343\uca76", "\ud8b6\udc50\ud913\uddae\ucd97\udb89\udce9\ud867\udcb8\udb87\udd10",
        47, -79, 1506645434, -1966538126415110525L, 61802L, false, true, (char) 16416, (char) 32972,
        Double.longBitsToDouble(0x3fd4461029fd3aa2L), Double.longBitsToDouble(0x3fe3f3ce4aa77305L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.IOUtils:@?\0121=new org.apache.commons.compress.utils.IOUtils:@?\012",
        Z.run(T, 2, 7, 7, 5, "\ud8c4\ude62\ud99f\udded", "\u99f8\ua632\u8853", "\uda89\udda6\ud976\udce5\udbac\ude32\ud9de\udc54\ud827\udc87\udb15\ude68\ud86c\ude68\udaac\udf1b\udb89\udd14\udb26\udc39\ud9f0\udcb1\ud958\udf57\udb0d\uddc8\ud951\ude86\u478a\ud815\udf15\udb1a\udd30\udbd4\udc2b\udad9\udfe6\ud9fe\udf73\uda7e\udc96\u6def\ud8db\udce3\udb22\ude0c\ud89f\udc2f\udbf8\udcc5",
        23, 3961, -580658953, -7565617875295165326L, 92493L, true, true, (char) 33970, (char) 6642,
        Double.longBitsToDouble(0x3fed5b794df8e1d7L), Double.longBitsToDouble(0x3fe7ba7740d32ef8L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |a1=[B:[[]]\0121=java.lang.Integer:0 |a1=[B:[[]]\012",
        Z.run(T, 2, 4, 4, 0, "", "*\000\000", "\ud9fc\udcde",
        21, -1000, -68501213, 2153732652961424034L, -100000L, false, false, (char) 39581, (char) 21361,
        Double.longBitsToDouble(0x3fe0d5d5405763f7L), Double.longBitsToDouble(0x3fc50a0650dfda2cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void\012",
        Z.run(T, 1, 1, 4, 2, "\ud8c4\ude62", "\uafb9\u9a53\uab02\u0536\uaf4d\u4967\u633f\u244c\u9bdc", "\udb15\ude68\ud913\uddae\udac6\uddbe",
        33, 54148, 1345472599, -681274274071940655L, -52010L, false, false, (char) 46237, (char) 9957,
        Double.longBitsToDouble(0x3fc72257ebec5348L), Double.longBitsToDouble(0x3fe6831bb25b6202L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.utils.IOUtils|skip|java.io.InputStream,long|static",
    "M|org.apache.commons.compress.utils.IOUtils|closeQuietly|java.io.Closeable|static",
    "M|org.apache.commons.compress.utils.IOUtils|copy|java.io.InputStream,java.io.OutputStream|static",
    "M|org.apache.commons.compress.utils.IOUtils|copy|java.io.InputStream,java.io.OutputStream,int|static",
    "M|org.apache.commons.compress.utils.IOUtils|readFully|java.io.InputStream,[B|static",
    "M|org.apache.commons.compress.utils.IOUtils|readFully|java.io.InputStream,[B,int,int|static",
    "M|org.apache.commons.compress.utils.IOUtils|toByteArray|java.io.InputStream|static",
    "C|org.apache.commons.compress.utils.IOUtils|<init>|",
    "M|org.apache.commons.compress.utils.IOUtils|skip|java.io.InputStream,long|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
