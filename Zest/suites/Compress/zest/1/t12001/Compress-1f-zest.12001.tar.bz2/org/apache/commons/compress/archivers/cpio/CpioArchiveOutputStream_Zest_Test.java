package org.apache.commons.compress.archivers.cpio;
import org.junit.Test;
import static org.junit.Assert.*;
public class CpioArchiveOutputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 2, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u5850", "\u5cde\ud9d3\udc7b\ud869\udffb\udbda\udf52",
        55, 50423, -828293390, -516740634952093817L, -54678L, true, true, (char) 45708, (char) 19911,
        Double.longBitsToDouble(0x3fe1f221abf8a7d7L), Double.longBitsToDouble(0x3fc501ca0664350cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 2, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u5811", "\u5cde\ud9d3\udc7b\ud869\udffb\udbda\udf52",
        55, 50423, -828293390, -516740634952093817L, -54678L, true, true, (char) 45708, (char) 19911,
        Double.longBitsToDouble(0x3fe1f221abf8a7d7L), Double.longBitsToDouble(0x3fc501ca0664350cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 1, 2, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u5850", "\uda4e\udd21\udbd2\udfd3\ud85a\udd12\udbda\udf52",
        55, 51095, -828256831, -516740634952093817L, -54678L, true, true, (char) 397, (char) 37575,
        Double.longBitsToDouble(0x3fe1f50afbf8a7d7L), Double.longBitsToDouble(0x3fc5024e6664350cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 15, "\ud8f2\udf08\ud8af\ude78\ud9a2\udf02\ud968\udffd", "\u5850", "\u5cde\uda1a\udc00",
        4, 4547, -83561779, 115468060372790537L, -54573L, true, true, (char) 27916, (char) 3424,
        Double.longBitsToDouble(0x3fe1f282a80206b8L), Double.longBitsToDouble(0x3fe6035789ca0df9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 11, 10, "\udb14\udd1a\udb4a\udf59\ud979\udeea\udbe8\udc02", "\u44af\u6e8a\ud613\u755c\u902b\u0697\u8b5c\ucfe1", "\udb32\udeb4\udb38\udc29\ud82f\udd5d\ud9f2\uded7\ud941\udded",
        -5, 48342, -1479074242, 1031530988716644520L, 16743L, false, true, (char) 12060, (char) 48724,
        Double.longBitsToDouble(0x3fe74272107d1ba9L), Double.longBitsToDouble(0x3fd08324134a62a0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 3, 5, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u8083", "\u5cde\ud9d3\udc7b\ud869\udffb\udbda\udf52\udb38\udd58\udb89\udcb3\ud87e\udffa\udac1\udd5b",
        54, 54600, 243748598, -7639761211546329966L, -60624L, false, true, (char) 6189, (char) 22168,
        Double.longBitsToDouble(0x3fe57a2547da3c6dL), Double.longBitsToDouble(0x3fe97caae18471f5L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 5, 2, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u5850\u49e1\u78be\u5845\u9999\u2387\u93d3\ucbbb\ua1b6\u646e\u22a1\u655c\u2b70\u202e\u7eac\u1d64", "\udbdf\udccf",
        51, 97337, 756958258, 4879174606150474302L, -60531L, false, true, (char) 26119, (char) 62533,
        Double.longBitsToDouble(0x3fe422b50fd8b83eL), Double.longBitsToDouble(0x3fdb16053eaecd76L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 9, 11, "\udbd7\udfc5\ud8ae\ude1d\uda61\udc70\ud969\udc1e\ud92c\ude92", "\u49e1\u78be\u5845\u9798\u4964\ub785\u6e39\ua1b6\u646e\uc889\u31cb", "\u173e\ud82a\udcb1",
        37, 11935, 912440312, 971607262640152985L, 72593L, true, false, (char) 10010, (char) 23448,
        Double.longBitsToDouble(0x3fe783a28643bb0aL), Double.longBitsToDouble(0x3fc3570825202288L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\000", "\ua5d0\000", "\u00e6",
        -5, -1000, 1493172224, 2274245377198653440L, 16329L, false, false, (char) 0, (char) 63623,
        Double.longBitsToDouble(0x3fe8000006f6f2a1L), Double.longBitsToDouble(0x3fd530e879252bf4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 2, "\uda6d\udda7\ud8af\ude78\ud966\ude1b\ud968\udffd", "\u5850", "\u5cde\ud9d3\udc7b\ud869\udffb\udbda\udf52",
        55, 50423, -828293390, 5175809290632684929L, -64071L, true, true, (char) 45708, (char) 19911,
        Double.longBitsToDouble(0x3fe1f221ac2fa7d7L), Double.longBitsToDouble(0x3fe5671b64438405L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 11, 3, 12, "\uda6b\udd4d\udba3\ude72\udb0b\udc15\ud8c3\udefd", "\u5850\u49e1\u78be\u5845\u7f85\ua397\u88c9\ua0b6\ua1b6", "\ud811\udc31\ud92c\ude7e",
        23, 47107, -1057416046, 4914989383256841790L, -93273L, false, true, (char) 41215, (char) 48804,
        Double.longBitsToDouble(0x3fe961ac222a535cL), Double.longBitsToDouble(0x3fe8a2a025de490dL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 1, 2, 3, 1, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u5850", "\u5cde\ud9d3\udc7b\ud869\udffb\ud91d\udc53",
        55, 50423, -828293390, -516740634952093817L, -54678L, true, true, (char) 45708, (char) 10184,
        Double.longBitsToDouble(0x3fe1f221abf8a7d7L), Double.longBitsToDouble(0x3fc501ca0664350cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 12, 14, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u5850\u49e1\u78be\u5845", "\udaeb\uddea\udb5b\udcc4\uda26\udcc1\ud87f\udc09\udb32\udeb4\ud81b\udcfd\ud92c\ude7e\ud88b\udfd1\ud9c7\udf13\ud85a\udcdb\ub8d3\udbe2\udd0b\ud9c0\udda7\ud828\udd5d\udb64\udd57\ud8e5\udd73\ud969\udea7\ud946\udc4c\ud9bb\udcfb\udb56\uddeb\udb51\ude34\ud9bc\udfa8\udaf3\udcd5\udac3\udfae\udab4\udea7\ud876\udee6\ud8a5\udfb2\uda6d\udeab",
        44, 36677, -624615786, -921700448002868196L, 92346L, true, false, (char) 36494, (char) 62543,
        Double.longBitsToDouble(0x3f92869c90896880L), Double.longBitsToDouble(0x3fbf577ec6cd4438L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 3, 2, "\ud89e\udc9f\ud8af\ude64\udb0b\udc15\ud968\udffd", "\u5850", "\uda63\uddc2\u74c5\ud958\uddd0\udb12\udc0f",
        34, 50423, -828293390, -516740634952093817L, -54678L, true, true, (char) 45708, (char) 19911,
        Double.longBitsToDouble(0x3fe1f221abf8a7d7L), Double.longBitsToDouble(0x3fccd90a6664350cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 3, 2, "\uda6d\udda7\ud8af\ude78\udaee\udd08\ud968\udffd", "\u09bb", "\udba0\udd38\ub4a8\ud98a\udcac\ud930\udeb8",
        55, 50423, -828293390, -516740634415222905L, 76394L, true, true, (char) 54975, (char) 19776,
        Double.longBitsToDouble(0x3fe1f221abf8a7d7L), Double.longBitsToDouble(0x3fc501ca0f70350cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 3, 0, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u8249\u5b0e\u731d\uceb6", "\udbda\udf52\udb38\udd58\uda26\udcc1\ud87f\udc09\udb32\udeb4\ud81b\udcfd\ud92c\ude7e\ud88b\udfd1\ud9d4\udc13\ud85a\udcdb\ub8d3\udbf2\udff2\ud9a3\ude0d\uda36\udd8e\ud9f7\udd0f",
        -3, 82555, -312555076, 4356605491103490343L, -99375L, false, false, (char) 42283, (char) 54926,
        Double.longBitsToDouble(0x3fec3efb8194fc8cL), Double.longBitsToDouble(0x3fe901c4e37b4fe2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 10, 15, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd\udba0\udefb", "\u9013\u2a9d\u57fd\u9999\u2387\u8479\ucbbb\uc575\u646e\u22a1\u655c\u2b70\u202e\u37aa\ub1de\u75a5\u1da7\u9dee", "\udb9c\udd2b\udbbf\udd12\u32eb\uda18\udffc",
        32, 89599, 1101358171, -4073094001790242780L, 15372L, true, false, (char) 13472, (char) 51199,
        Double.longBitsToDouble(0x3fd403617a5d8540L), Double.longBitsToDouble(0x3fed4e179918cf88L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 4, 2, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u5850", "\ud81b\udfa0\ud9d3\udc5d\ud86a\udc15\udbda\udf52\udb38\udd58\uda26\udcc1\ud87f\udc09\udb32\udeb4\ud81b\udcfd\ud936\ude83\ud88b\udfd1\udaa3\udc05\ud85a\udcdb\ub8d3\udbe2\udd0b\udbdf\udc9a\ud95a\udc70\udba7\udc8f",
        16, 33951, -553759583, -7608917908483554280L, -857L, false, true, (char) 15705, (char) 42334,
        Double.longBitsToDouble(0x3fce90bda59ea3e8L), Double.longBitsToDouble(0x3fccce08ff6724d4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 3, 2, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd", "\u5850", "\u5cde\udade\udc11\udaab\uddbd\udbda\udf52",
        55, 50423, -828293390, -1813777328090257144L, -54678L, true, true, (char) 45708, (char) 19911,
        Double.longBitsToDouble(0x3fe1f221a8f8a7d7L), Double.longBitsToDouble(0x3fbd4818da726660L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 1, 4, 3, 2, "\ud90a\ude34\ud8af\uddb3\udab5\udec5\ud948\udffc", "\u181d", "\udb2a\udc05\ud9d3\udccd\ud869\udffb\udb76\udd00\udb44\ude85\uda26\udcc1\ud87f\udc09\udb32\udeb4\udb32\udc09",
        2, 38910, -871621293, -4541567317511402290L, -43573L, true, true, (char) 11940, (char) 23390,
        Double.longBitsToDouble(0x3fa91350cb6c8460L), Double.longBitsToDouble(0x3fe4a2262c22e445L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 1, 4, 10, 15, "\ud971\udc89\ud8c5\udd8b\ud908\udf12", "\u666b\u33f8\u8eac", "\ud9d3\udc7b\ud894\udf14\uda90\uddec\ud940\ude4e\uda26\udcc1\udae3\ude1b\ud933\udff2\udb8e\udd98\udafe\udf5c\uda24\ude1d\ud9fc\udf14\uda92\ude60\u1e24\udaa1\ude4a",
        1, 59249, -1871044126, -5743676848728191051L, -89521L, true, false, (char) 165, (char) 63778,
        Double.longBitsToDouble(0x3fd221f7247f0052L), Double.longBitsToDouble(0x3fe0d479d48c8d18L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 15, 2, "\ud909\ude35\ud83e\udf55\udb0b\udc72\ud968\udffd", "\u3ead\u3432\ua375\u5409\u9976\u23ba\u84d3\ucbbb\ua1b6\u646e\u0e70\ub05b", "\ud9c7\udf13\ud8e7\udc21\u8567\ud869\udcb0\ud98d\udf99\ud9eb\uded8\uda64\udcbd\udb2a\udeb3\udab6\udea0\ud91a\udd0c\uda93\ude0b",
        14, 11419, 121417714, 7721552303509925208L, -14340L, false, false, (char) 52572, (char) 31731,
        Double.longBitsToDouble(0x3fdd8ec4378d744eL), Double.longBitsToDouble(0x3fdc6f40383e746aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 8, 2, "\uda6d\uddf9\ud839\udffe\udacf\udcb3\ud968\udffd", "\u5850", "\u5cde\ud9d3\udc7b\ud869\udffb\udbda\udf52",
        55, 50423, 165467370, 1415212935392029757L, -54678L, true, true, (char) 45708, (char) 4049,
        Double.longBitsToDouble(0x3fce94c6afe203a0L), Double.longBitsToDouble(0x3fc501ca0664350cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 0, "\uda6d\udda7\u00e7\ud88b\udce4\u9200", "\u5850", "\u5cde\ud9d3\udc7b\ud869\udffb\udbda\udf52",
        55, 50423, 16114, -576460750748668025L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e38000000000000L), Double.longBitsToDouble(0x3fc501ca0664350cL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 2, "\udbd3\udc3c\udaa1\ude19\udb09\udf6c\ud969\udc47\udba0\udefb", "\u874e\u78be\u5845\u996c\uce02\u869f\uc74c\u6fc9\u646e\u22a1\u871c\u6a6a\u202e\u37aa\ub1de\u75a5\u2dc1\u64ef", "\ud8f1\udf87\ud837\udce3\udb6d\udc66\uda74\ude8c",
        56, 60103, -2103834165, 8652485013307089759L, 27752L, false, true, (char) 35076, (char) 55224,
        Double.longBitsToDouble(0x3fe5df36ad3e59dfL), Double.longBitsToDouble(0x3fe84a9607ca49feL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 3, 2, "\uda6d\udda7\ud8af\ude78\ud839\udced", "\u996e\u0ed4\ud37b\u78be\u5845", "\udbda\udf52\udb38\udd58\uda26\udcc1\uda4a\udd5b\udb32\udeb4\ud81b\udcfd",
        0, 53286, -1778770605, -4541567334683076402L, -1635L, false, false, (char) 12094, (char) 38338,
        Double.longBitsToDouble(0x3fe4fb4496686bccL), Double.longBitsToDouble(0x3fcb3ff6c73466b4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 2, 4, 3, "\uda61\udfa7\ud8af\ude78\udb0b\udc15\ua3fe", "\u501b", "\uda4e\udd21\udbd2\udfd3\ud860\uddb5\udbda\udf52",
        18, 51095, -828256831, -516740634952093817L, -54678L, true, true, (char) 397, (char) 24284,
        Double.longBitsToDouble(0x3fe1f4e2c3f8a7d7L), Double.longBitsToDouble(0x3fc5024e6664350cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\uda6d\udda7\ud8af\ude78\ud84b\udcd6\ud969\udcd5", "\u5850", "\uda4e\udd21\udbd2\udfd3\ud85a\udd12\udbda\udf52",
        55, 51095, -828256831, -516740634960930425L, -54678L, true, true, (char) 397, (char) 37575,
        Double.longBitsToDouble(0x3fe1f50afbf8a7d7L), Double.longBitsToDouble(0x3fc5024e6664350cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 8, 14, "\uda6d\udda7\ud89c\udd2e\ud8d2\udf10\udbb5\udc5a", "\u501f", "\uda4e\udd21\ud9cc\ude4f\udbbf\udd02\udbda\udf52\ud91d\udf5a\ud8aa\ude03\ud8a2\uded8\udb32\udeb4\ud81b\udcfd\ud92c\ude7e\uda0d\udeb2",
        20, 74554, -1588625507, -6352575497436546598L, 21985L, false, false, (char) 40297, (char) 38984,
        Double.longBitsToDouble(0x3febe8dbd7814c77L), Double.longBitsToDouble(0x3fee7c5845cd2332L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 8, 10, "\ud9e7\udd60\udb84\udce9\udb1e\udd34\udb44\udf45", "\u8c0c", "\uda59\udc87\ud9d5\ude7d\ud85a\udd12\ud88d\ude4b\ud806\udfd2\ud9fe\ude70\ud9d5\ude86\ub2ca\uda0d\ude6d\ud8c4\udfca\ud858\udf51\udbcc\udcb6\udacf\udf0b\ud84b\udceb\udbe2\udd0b\u9df0\ud8d0\udc78\ud8e2\udc4c",
        25, 29693, -139236633, -8737241260874106589L, -97794L, true, false, (char) 29710, (char) 15486,
        Double.longBitsToDouble(0x3fd8fdf8c8dfc0eaL), Double.longBitsToDouble(0x3fd78f9686122c34L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 9, "\uda5d\udce0\ud8af\ude78\udb0b\udc15\udb68\udc3e", "\u13aa\u49e1\u56b7\uaa21\u7f31\ubc9d\u93d3\ucc0f", "\udb46\uddb4\ud81b\udcfd\ud92c\ude7e\ud88b\udfd1\ud87a\udf6b",
        44, 15774, -1479074242, 1329612989053229224L, -2088L, true, false, (char) 5278, (char) 22415,
        Double.longBitsToDouble(0x3fe719ebde5c1127L), Double.longBitsToDouble(0x3fc4b866be4f7944L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 7, "\uda6d\udd28\ud8af\ude78\udb43\udd11\udb73\udf56", "\u142a", "\uda4e\udd21\udab7\uded5\ud978\udc01\udbda\udf52",
        55, 97783, -828256831, -516740634952093817L, -20118L, false, true, (char) 287, (char) 37575,
        Double.longBitsToDouble(0x3fe1f50afbf84e27L), Double.longBitsToDouble(0x3fc5024e7a64350cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 2, "\uda6d\udda7\uda6d\udc61\uda4d\ude20\ud97f\udefd\udba0\udefb\uda8c\uded6\uda75\udc2f\ud938\udd47\ud918\udfb7", "\u9e09\u28d6\ucbbb\u396a", "\ud81b\udcfd\ud92c\ude7e\ud9f6\udc86\ud9ec\udefa\ud836\udc59\ud901\udf95\udb97\udc27\uda3d\ude55\ud8b3\udd0a\ud81c\udde0\uda77\udeb2\udbc3\udfaa",
        4, 25145, 1192611642, -4666301331734884517L, -4294L, true, true, (char) 11317, (char) 61510,
        Double.longBitsToDouble(0x3fb3d07addc4e938L), Double.longBitsToDouble(0x3fe2629003815777L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 13, 2, "\udacf\udc20\udba6\ude5c\udb10\uddde\ud8a0\udfdf\uda29\udc43\udabb\udfdc\ud87f\ude94\ud9ae\udc24\ud918\udfff", "\uad8e\u936c\ucbbb\u21b6\u413d\u22a1\u655c\ud091\u202e\u37aa\u620e\ud4b7\ubfc2\u0638", "\udaed\udc64\udbc7\udd1e\udb59\udc3c\uda6c\uddef",
        44, 99397, -1205314418, 3561124014287696261L, 71610L, false, true, (char) 4659, (char) 39695,
        Double.longBitsToDouble(0x3fd3524e4bf7cfacL), Double.longBitsToDouble(0x3fd10a192de5a674L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 3, 5, "\uda72\udcd1\ud8af\ude78\ud9a2\udf02\ud968\udffd\udb85\uddea\ud9e4\udf60\udb10\uddb1\udb9b\udf51\udb41\udfa1\u9d9b\ud82e\udcc1\uda00\ude00\udb41\udcb2", "\u7c67\u46fe\uafd9\u6b1f\u4285\uc171", "\uda6a\udf0b\ud965\ude4f\udb4c\udf92\udb7b\udd63\ud971\uddea",
        23, 24966, 1996058680, -7489777042765405461L, 29307L, true, true, (char) 52005, (char) 27049,
        Double.longBitsToDouble(0x3fd804df7c9adeecL), Double.longBitsToDouble(0x3fee81f03541764eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 3, 15, "\ud971\ude2c\ud8af\ude78\ud9a2\udf02\ud968\udffd", "\u5850", "\u5ce2\uda1a\udc00",
        4, 4547, -83561779, 115539142081539337L, -54573L, true, true, (char) 27916, (char) 3424,
        Double.longBitsToDouble(0x3fe1f282a80206b8L), Double.longBitsToDouble(0x3fe6035789ca0df9L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 1, 10, 11, 10, "\ud894\udf27\uda66\udf3b\ud979\udeea\u5fa3", "\u7476", "\ud9b4\udee0\ud9c9\udc01\ud862\udf0b\udb0c\ude59",
        0, 50509, -828264974, 5307131664665330055L, -12058L, true, true, (char) 25203, (char) 25551,
        Double.longBitsToDouble(0x3fc5024a0664348cL), Double.longBitsToDouble(0x3fe56c5c7ee26e3cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 11, 10, "\udb14\udd1a\udb4a\udf59\ud979\udeea\udbe8\udc02\udb87\udd9d\ud948\udc4e\ud9d0\udf4c\uda27\ude24\udb87\udf12\ud888\udc5d", "\u8b5c\u507f\u6ad6\u2c61\u921eI\ub73b\uc9c8\u1a0c\u5e27\u7389", "\udbd1\udfd5\ud90e\udebc\ud830\udd2c\ud874\uddfb\u9345\udbb4\udd5f\uda04\ude68\udaa3\ude8a\ud934\udc89\uda1a\udeaf\ubc1e\ud90c\udfeb\udb80\ude7a\udba8\udf00\ubbcb\ud817\uddda\ud90e\uddb8\uda91\ude26\udb35\udc44\ud931\ude9c\uda85\ude61\ud923\udcb2\ud89a\ude40\udac4\udf83\udbff\udcf7",
        21, 3507, -1472716137, -8468196763562867803L, 60362L, false, true, (char) 22125, (char) 35459,
        Double.longBitsToDouble(0x3fcf9c11bfcb267cL), Double.longBitsToDouble(0x3feaffb9edc029fbL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 3, 10, "\udb14\udcd2\udb56\udd53\ud979\udeea\udbe8\udc02", "\u837f\u6e50\ud613\u755c\u902b\u8011\u82fb\u3cb3", "\ud875\ude92\ud8f8\udc2b",
        22, 99079, 1933158179, -4541520107230865458L, -18110L, true, true, (char) 64715, (char) 12060,
        Double.longBitsToDouble(0x3fdee1c67dd09c84L), Double.longBitsToDouble(0x3fbf46ea48419208L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 5, 2, "\uda6d\udd92\ud8af\ude78\udb0b\udc15", "\u65f2\u5850\u661f\u4906\ud620\u71be\u2387\u7ca6\u4d42\ua1b6\u646e\u22a1\u1cc7\u2b70\u202e\u7eac\u1d64\uad59\u3d9c\u64ef\u2860\u155b\u61ab\u9fb4\u0235\u8874\uba7f\u9794\ua7e7\u7372\u748c\ubf36\u3f73\u8532\u7d93\u0d03", "\uda54\uddbc\udb77\udec4\udae1\udc94\ud935\udc01\uda54\udf53\uda3c\udf75\uda44\udd15\ud9d9\udd06\ud936\udc9e\ud84e\udf7d\udbb8\udc0d\ud8c9\ude2b\udb56\udfb2\udb73\uddf4\ud983\udc46\u7245\udaf4\udf55\u4184",
        15, 56485, -1303310738, 6712210665954791592L, -24134L, false, false, (char) 24805, (char) 43392,
        Double.longBitsToDouble(0x3fa22a95e455f3e0L), Double.longBitsToDouble(0x3fdb6b401f5ae4acL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 9, 11, "\udbd7\udfc5", "\u7d25\u1960", "\ud938\udd47\udba4\udf50\u8f3d\uda30\ude32\uda4a\udc03\udb30\udf4e\ud959\uddc8\udbeb\ude02\uda91\udd0f\ud88f\udc24\udaef\udf73",
        56, 50462, 1400093267, 462886201640455374L, -81536L, false, true, (char) 12052, (char) 7355,
        Double.longBitsToDouble(0x3fee7e138781284fL), Double.longBitsToDouble(0x3fb065fe05d577b8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 4, "\ud8c4\udc61\ud900\udc07\ud983\udfd0", "\ub8be\u9770\ub8e5\u07ed\u6dfd\uc2ad\u837d\000\ucb17\ua1b6\ubc57\u9906\ubb2e\u90b0\u202e\u3833\u4c66\ud776", "\ud8d9\udd54\udbc2\udd42\ud9ff\udfc1\ud805\udd31\ud9e3\udcc8\ud867\udee1\u4a57\ud9e5\udd06\ud9fa\udd8a\ud870\udf66\ud85f\udfba\ud9da\ude83\udb06\udd07\udb4e\ude61\ud9d5\udeca\udab5\udc23\ud9bd\udffb\uda6e\udd73\u744c\uda74\uddc0",
        55, 61241, -1430854463, -2089040875249308326L, 26597L, true, true, (char) 237, (char) 45398,
        Double.longBitsToDouble(0x3fe85ecfd5e595e7L), Double.longBitsToDouble(0x3fdea39adae724a8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 4, 13, "\u00f1\ud8af\udd91\000\ud936\uddda\ue9a5\ud920\udd4e\ud803\udd50\ud93d\udd21\ud80f\udfb9\ud817\udd7b\udabe\udd9c\ud893\udc22\uda2e\udd80\ud88a\udd26\udb17\udfae\udb63\udec1\udb5e\udc2d\u00e1\udbe1\udf4a\udbb4\udc9b", "\u31da\u9ed5\ubef6\ucad0", "\udab5\udc7b\udb0d\udf7b\ud82c\ude71\ud9f3\udc89\udaa5\udd2d\ud90b\udcf0",
        6, 71396, 1655688407, -1986579871054830112L, 60100L, false, true, (char) 51397, (char) 17909,
        Double.longBitsToDouble(0x3feed7a72ac44bffL), Double.longBitsToDouble(0x3fc46cd531ce0b40L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 0, 0, "\000", "\ua5d0\000", "\uda04\ude8f",
        55, -1000, 1437520143, 8574389467093828499L, 16329L, false, false, (char) 0, (char) 2012,
        Double.longBitsToDouble(0x3fe8000006f6f2a1L), Double.longBitsToDouble(0x3fd530e879252bf4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 1, 11, 0, 0, "\u00f8", "\ua5d0\000\u9978\u54d7\u2d5b\u7b2f\u7212\ua17b\u2387\u9bc9\u3f1d\ua1b6\u00f2\u9684\u7ff0\u2a5c\u06ff\u83cd\ud18f\u62a8\ub817\u3e92\u090a\u09fe\u5400\u8510\u4872\uce63\u345f\u5b5f\u3c7b\uabfb\u7c46\u299c\ua363\u8fe7\u2997\u9485\u43e7\u0b7a\u85e5\uc178\u13a1\u7116\u74e4", "\uda2e\udd70\ud888\udc38\ud989\ude98\u646d\uda86\udd65\uda43\udc0d\ud91b\udfa5\uda3a\uddb9\uda9f\udd0a",
        0, 85608, 478646597, 5815051883768114454L, -57007L, false, true, (char) 18201, (char) 1842,
        Double.longBitsToDouble(0x3fd475d40633621cL), Double.longBitsToDouble(0x3fb2264606772228L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 4, "\000\ud8b7\udd91\udab3\udc77\ud944\udde1\000\000\uda5c\udf14\u00e6\000\000\udabf\udd3e\ud869\udffb\000", "\u00f2\u9684\u0087\u2b28\ub062\u3763\u9516\u142f", "\ud8b9\ude79\ud91c\ude91\udacd\udcb5\u52a5\ud805\uddf2",
        51, 44120, 1547819100, 5998837510059085543L, -52494L, true, false, (char) 25232, (char) 11353,
        Double.longBitsToDouble(0x3fe28a2a17a7c7b9L), Double.longBitsToDouble(0x3fedb8ab90dd9affL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 2, "\uda6d\udda7\uc65a\ud874\ude8f\uda95\udf7e", "\u5850\u34d8", "\ud9d3\udc7b\ud869\udffb\udbda\udf52\udb38\udd58\uda26\udcc1\ud87f\udc09",
        4, 43353, -1799995213, 1046932597704891731L, 60562L, false, false, (char) 10966, (char) 65073,
        Double.longBitsToDouble(0x3fb0e10151e17350L), Double.longBitsToDouble(0x3fe8b29edc70765aL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 2, "\uda40\uddf1\ud8af\ude78\ud966\ude1b\ud968\udffd\udba0\udefb\uda7f\udf31", "\u78be\u5845\u9999\u2387\u93d3\ucbbb\ua1b6\u646e\ua842\u8255\u31ed\u44df", "\ud802\udd86\udbe2\udd0b\udb78\ude7f\uda28\udf5d\ud86a\udd4b\udaf7\udc71\udbad\uddeb",
        58, 23453, 1426343429, -6114967870092823075L, 23612L, false, false, (char) 11515, (char) 30668,
        Double.longBitsToDouble(0x3fe529c1e7ddd231L), Double.longBitsToDouble(0x3fec687141213d39L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 8, 5, "\ud951\udd13\uda88\udc73\uda0d\udfb0\ud95d\udc8d\udae1\udebc\uda8c\udc6c\ud87f\ude94\ud938\udd47\ud8b4\uded8\u5cde\ud9d3\udc7b\ud869\udffb\ud808\udc49\ud81b\ude27\uda3d\udfb3\ud87f\udc09\udb73\udf54\ud840\udd65\uf1b3\ud9b0\ude24\ud9c7\udf13\ud85a\udcdb\u81de\ud9b9\udcf9\udbbb\udf08\u3e39", "\uc892", "\ud9a7\uded8\u7b71\uda8b\udd17\ud92f\udf04\u3c7d\uda1c\udc23\udb1d\udc84\uda77\udcdf\ud9df\udc23\ud9a6\udc87\ud890\udda8\udadf\udcd2\uda62\udfbb\uda02\ude6f\uda62\udef7\uda8d\udd96",
        6, 13639, -2124538021, -4953926122221157819L, -63998L, true, true, (char) 31392, (char) 12682,
        Double.longBitsToDouble(0x3fee845d6d06c6cfL), Double.longBitsToDouble(0x3fd6ea25be7a89c0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 0, "\uda6d\udda7\ud9a0\ude11\uda75\udf1c\ud968\udffd", "\u5850", "\u5cbe\ud9d3\udc7b\ud869\udffb\udbda\udf52",
        55, 50423, -828293390, 5175809292704998785L, -64071L, true, true, (char) 45708, (char) 19911,
        Double.longBitsToDouble(0x3fe1f221ac2fa7d7L), Double.longBitsToDouble(0x3fe5671b64438405L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 4, 4, 8, "\ud987\ude30\ud95c\udf2f\udb8e\udd06\ud995\udd10\udba0\udefb\uda7f\udf31\ud890\udf06\udaa4\udf78\udb84\udcde\udb13\udd28", "\u93e9\ua4fa\ua1b6\ua6a1\ub3b7\u824f\u3884\u447b", "\ub8d3\udbf7\udf0b\udb32\udc74\udb70\udd5f\ubccd",
        40, 59858, -631154249, -9087665294727456577L, 3838L, false, false, (char) 43494, (char) 52110,
        Double.longBitsToDouble(0x3fda86c34fb2e84cL), Double.longBitsToDouble(0x3fc15658e51da630L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 15, "\uda2e\udfc3\udaaf\udf8a\udbd3\udff9\ud93d\udcc7", "\u5850\u49e1\u78be\u5845\u9999\u0931\u697f\u3eba\ubdbb\u9795\ua842\u8255\u573f\u310d\ub23f", "\udb77\udda7",
        42, 69962, -1578376527, -8808323517921950492L, 72926L, false, true, (char) 50210, (char) 63023,
        Double.longBitsToDouble(0x3fde0e6c87ed6b1aL), Double.longBitsToDouble(0x3fee5652dda42186L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 3, 12, "\uda6b\udd4d\udba3\ude72\udb0b\udc15\u5eee\ud846\udfcc\udbc3\uded3\ud84f\udcc3\ud949\udc70\ud8b4\uded8\u5cde\ud8b2\udc0c\udb52\ude35\udb0f\udd6c\udbb1\udd45\uda26\udcc1\ud8b5\udd02\ud8ed\udfba\ud81d\udc0b\ud92c\udec9\ud88b\udfd1\udae5\udf72\udad2\udf76", "\ua753\u22b0\ub4fe\ub9b8", "\ud95a\udee2\uda68\udc15\uda1d\udf1d\ud825\udfcb",
        2, 22219, 1686889785, -2712644539108684390L, -39734L, false, true, (char) 459, (char) 28580,
        Double.longBitsToDouble(0x3fc4942fc5fd0608L), Double.longBitsToDouble(0x3fd0169f167a4caaL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 2, "\ud8d8\udc5a", "\u8839\uaf8a\u78d5\u09bb", "\udba0\udd38\ub4a8\ud98a\udcac\ud930\udeb8",
        8, 58826, 220366441, -516645369663279225L, 76394L, false, true, (char) 54975, (char) 19776,
        Double.longBitsToDouble(0x3fe1f221abf8a7d7L), Double.longBitsToDouble(0x3fc501ca0f70350cL)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 10, 15, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd\udba0\udefb", "\u9013\u2a9d\u57fd\u9999\u2387\u8479\ucbbb\uc575\u646e\u22a1\u655c\u2b70\u202e\u37aa\ub1de\u75a5\u1da7\u9dee", "\udb9c\udd2b\udbbf\udd12\u32eb\uda18\udffc",
        3, 89605, 1101358171, -4073094001790242780L, 15372L, true, false, (char) 13472, (char) 51199,
        Double.longBitsToDouble(0x3fd403617a5d8540L), Double.longBitsToDouble(0x3fed4e179918cf88L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 15, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd\udba0\udefb", "\u9013\u2a9d\u57fd\u9999\u2387\u8479\ucbbb\uc575\u646e\u5b20\u08d5\u2b70\u202e\u37aa\ub1de\u75a5\u8478\u0d52", "\udb9c\udc98\udbbf\udd12\u32eb\uda18\udffc",
        2, 89599, 1101358171, -4060727794512646108L, -63069L, true, false, (char) 13472, (char) 51199,
        Double.longBitsToDouble(0x3fd40361705d8540L), Double.longBitsToDouble(0x3fd19632123030baL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 15, "\uda6d\uddd1\ud8af\ude78\udb0b\udc15\ud968\udffd\ud825\udcfb\ud86c\udfdc\ud87f\ude94\uda97\udf35\uda90\udc34\ud9cb\udd51\ud9d3\udc7b", "\ucbbb\uc575\u646e\u22a1\u26e8\u2b70\u202e\u37aa\ub1de\u75a5\u1da7\u9dee\uc45f\u8e8c\u8cfd\u2ede\u47bd\u7a44\uaeb8\u9046\uba28", "\uda90\udd7e\ud8c1\udc83\ud842\udecc\ud86c\udc69\udab9\udd30\udaf3\udd75\ueddb\ud80e\udda2\udbf2\udd94\udb33\udccd\udace\udea9\ud855\udec1\ud964\udc06\uda2a\ude8c\uda92\udfa7\udbc7\udc32\ud9dd\ude7a\udb6d\udf22\udb68\udd8c\ud90c\udc99",
        4, 9746, 606230534, -7916660748547999422L, 95748L, true, false, (char) 6328, (char) 33397,
        Double.longBitsToDouble(0x3fdfdc4157add834L), Double.longBitsToDouble(0x3feb330c5cf7056bL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 10, 15, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd\ud81e\udf1a", "\u9013\u5450\u5863\u9999\uc9e2\u47c0\ucbbb\uc575\u646e\u22f1\u655c\u2b70\u202e\u37aa\ub1de\u75a5\u1da7\u9dee", "\udb9c\udd2b\udb40\udef3\u59cc\uda18\udffc",
        32, 89599, 1101358171, -4073094001790242780L, 15372L, true, false, (char) 13472, (char) 20520,
        Double.longBitsToDouble(0x3fd2347f2a5d8540L), Double.longBitsToDouble(0x3fed4e179918cf88L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 10, 15, "\uda6d\udda7\ud8af\ude78\ud9ed\uddc7\ud815\udf0c\udba0\udf38", "\u9013\u2a9d\u57fd\u9999\u2387\u8479\ucbbb\uc575\u646e\u1728\u655c\u2b70\ua02e\u37c8\ub1de\u75a5\u1da7\u9dee", "\ud97f\udc25\ud823\udfe1\udb81\uddc9\ud974\udfd6",
        1, 89599, 1101358171, -4073094001790242780L, 15372L, true, false, (char) 13472, (char) 51199,
        Double.longBitsToDouble(0x3fe201b0bd2e4182L), Double.longBitsToDouble(0x3fed4e179c2f931bL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 0, 15, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\034\000", "\u9013\u2a9d\u57fd\u9999\u2387\u8479\u01a9\u3e85\u646e\u22a1\u655c\000\000\ub12e", "\u1e3e\udbb7\udcd7\ud819\udd70",
        5, -1000, -1522480532, -7880796469773435551L, -40529L, true, false, (char) 47163, (char) 30621,
        Double.longBitsToDouble(0x3fe5bf342793a76cL), Double.longBitsToDouble(0x3f99cc0c1585b9e0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 7, 15, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd\udba0\udefb", "\u9013\u2a9d\u57fd\uc07d\u1451\u843a\ucbbb\uc575\u646e\u22a1\u655c\u2b70\u202e\u37aa\u87a6\u83e4\u1d8b\u9dee", "\udb9c\udd2b\udbbf\udd12\u32eb\uda18\udffc",
        7, 89675, 1101358171, -4073094001790242780L, 63949L, true, true, (char) 26741, (char) 43952,
        Double.longBitsToDouble(0x3febe9a91aab6554L), Double.longBitsToDouble(0x3fd403617a5d8540L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 5, "\udbd3\udc3c\udaa1\ude19\udb09\udf6c\ud969\udc47\udba0\udefb\uda7f\udf31\ud820\ude86", "\u5845\u996c\uce02\u869f\uc74c", "\udb32\udeb4\udab5\udeaa\ud911\udf0c\ud88b\udfd1\ud9c7\udf13\ud85a\udcdb\ub8d3\udbe2\udd0b\udbdf\udccf\ud828\udd70\udb51\udeb8\ud8f1\udf87\ud837\udce3\udb6d\udc66\ud92e\udd89\ud927\uddc4\uda64\udcee\ud942\udc5f\uda1d\udc5a\ud870\udd2a\udaaf\udf7b\ud8b1\udc02\ud878\udfe9\uda1f\udece\ud948\udc45\udb7b\udc06\ud990\ude1e\ud939\udf65\uda5c\udf0b\u970c\udae5\udc5e\udbf3\udcc2\udb2b\uddc6\uce26\udbd3\udc67\ud843\udec5\ud84c\uddb8\ud825\uddf6\uda29\ude1c\udb97\udfa2\ud8de\ude41",
        2, 71192, -1746425505, 8360402925513039673L, 89930L, false, true, (char) 42218, (char) 57122,
        Double.longBitsToDouble(0x3fe0bf59f9372917L), Double.longBitsToDouble(0x3fca52640a11354cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 2, "\udbd3\udc3c\udaa1\ude19\udb09\udf6c\ud895\udddd\udba0\udf1d", "\u874e\u78be\u5845\uc7ba\uce02\u869f\uc74c\u6fc9\u646e\u22a1\u871c\u6a6a\u202e\u37aa\ub1de\u75a5\u8d88\u3ab7", "\ud8f1\udf87\ud837\udce3\udb6d\udc66\uda74\ude8c",
        56, 60103, -2103834165, 8652485013307089759L, 27752L, false, true, (char) 35076, (char) 55224,
        Double.longBitsToDouble(0x3fe5df36ad3e59dfL), Double.longBitsToDouble(0x3fe84a9607ca49feL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 15, "\ud9b8\udc80\udbd3\udc4c\uda5f\ude42\ud9ae\uddcc\uda43\udf9f\uda7f\udefe\udb01\udc16\ud996\udc4e\udb24\ude95\u52e7\udb94\udda9\uda1c\udcdc", "\uca3f\u3ea7\u22a1\u8ebc\u850b\ub2fa\uc162\uc718\u6ca6\u3f22\u0202\u1b15\ua6e9\uc15b\ud1d6\u8c53\u6a16\u72a3\ucd1e\u66f4\u55da\u8f90", "\ud8aa\uddbb\ud8a5\udc44\ud95c\ude02\uda49\udcd6\udb72\udeb7\udbc9\udc00\uda26\ude9a\udb7d\udfce\udb44\udfcf\udbee\udf66",
        0, 73652, -690693463, 6903815351686568011L, 17410L, false, false, (char) 38996, (char) 35070,
        Double.longBitsToDouble(0x3fb038eaaf181dd0L), Double.longBitsToDouble(0x3fe83ab5ec17c302L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 11, 7, "\uda6d\uddf1\udb07\udd03\uda5c\udd9c\udac4\udd22\udb86\udd32", "\u8863\uc937\u93cd\u8f44\ub1ce\u9373\u182d\u658e\ua8a8\u232e\u8ebc\u2b3e\u8e19\u3790\uc764\u6c01\u2dc1\ub844\u2860\uab33", "\ud8d2\ude13\ud824\ude32\udba8\udf8f\ud860\udc8f\udbc0\ude4c\ud9d4\udfa2\ud8e8\udcda\ud8e9\udfab\uda45\udd1f\ud8b9\uddd2\ud822\udecd",
        53, 2199, -1558948000, -9021834375254232612L, 92511L, true, false, (char) 55997, (char) 36799,
        Double.longBitsToDouble(0x3fe713bb00d1b3a2L), Double.longBitsToDouble(0x3fc899bd8311f324L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 8, 14, "\uda6d\udda7\ud89c\udd2e\ud8d2\udf10\udbb5\udc5a", "\u458b\u7165\u3d53\u6c87\u0191\u7404\u93d3\u8ebd\u2155\u1b3e\u22a1\u655c\u2bfc\u41a9\u37aa\u11d9\ud762\u2dc1\u2fb6\u2860\u5cb4\u98b5\ua070", "\ud899\ude83\uda55\udc14\ud944\udc9c\u95e2\u2b53\ud94c\udc2e",
        -3, 55227, 1901054522, -5073621706767960333L, 17759L, true, false, (char) 29909, (char) 55012,
        Double.longBitsToDouble(0x3fe73e445b073c24L), Double.longBitsToDouble(0x3fb27d657d68c1f8L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 8, 14, "\000\000\000\udbb5\udc5a", "\u4f6a", "\uda4e\udd21\ud9cc\ude4f\udbbf\udd02\udbda\udf52\ud91d\udf5a\ud8aa\ude03\ud8a2\uded8\udb32\udeb4\ud81b\udcfd\ud92c\ude7e\uda3d\udeaa",
        20, -1000, -1588625664, -6352575497436546598L, -100000L, false, false, (char) 9087, (char) 7290,
        Double.longBitsToDouble(0x3f9d754c04d74440L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.UnsupportedOperationException\012",
        Z.run(T, 2, 2, 11, 9, "\uda5d\udc2f\ud8af\ude78\udb0b\udc15\udb68\udc3e", "\u13aa", "\uda4e\udd4c\udbd2\udfd3\ud9b4\udeb4\udbda\udf52\udb61\udfcd\ud8aa\ude64\udb44\uddbc\udb46\ude62\ud81b\udd03",
        0, 34598, 1735007571, 8500944044860316878L, -82584L, false, false, (char) 11996, (char) 2316,
        Double.longBitsToDouble(0x3fbd45e8a67f7e70L), Double.longBitsToDouble(0x3fde029afb212ef6L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 2, "\uda6d\udda8\uda6c\udffd\uda45\udd51\ud97f\udefd\uda55\uddd7\uda8c\udeb2\uda75\udc2f\ud938\udd47\ud918\udfb7", "\u9e09\u28d6\ucbbb\u8dd4", "\ud81b\udcfd\ud92c\ude7e\ud9f6\udc86\ud9ec\udefa\ud836\udc59\ud901\udf95\udb97\udc27\uda3d\ude55\udadd\udebf\uda1e\udc1c\uda77\udf1e\udbc3\udfaa",
        4, 7225, 1192611642, 5696558376658571099L, -4294L, true, true, (char) 11317, (char) 37363,
        Double.longBitsToDouble(0x3fb3d0543034e938L), Double.longBitsToDouble(0x3fda74c08703c7f6L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 2, "\uda6d\udda7\uda73\udeb3\uda4d\ude20\ud97f\udefd\udba0\udefb\uda8c\uded6\uda75\udc2f\ud938\udd47\ud918\udfb7", "\u9e09\u28d6\ucbbb\u396a", "\ud81b\udcfd\ud92c\ude7e\ud9f6\udc86\ud9ec\udefa\ud98b\udcbb\ud901\udf27\udb97\udc27\uda3d\ude55\ud8b3\udd0a\ud826\udce0\uda77\udeb2\udbc3\udfaa",
        4, 25145, 1192611642, -4666301331734884517L, -4294L, true, true, (char) 11317, (char) 61510,
        Double.longBitsToDouble(0x3fea8a0f5bb89d27L), Double.longBitsToDouble(0x3fe2629003815777L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 2, "\000\uda22\udc86\udb7c\udeba\ud8cf\udf46\ud89b\udd17\ue2d0\uda5c\udfd2\u00e6\udb7b\udd5c\ud988\udc32\udabf\ude30\ud869\udffb\000\ud8bc\udff6\uda26\udc76\u00f2\ud90f\udf87\ud9d3\udee1\udb0f\udedb\ud84c\udf8c\ud9c7\udf18\ud99a\ude9b\uda1f\udde6\ud841\udcb9\ud8c6\udcb7\ud96b\udf4f", "\u38c6\ud20b\u1c08\uabc2\u05b4", "\udb0c\udd16\ud8b1\udd66\ud82e\udf9e\ud8be\udfc6\udb5c\udf96\udbf3\udd81\ud82f\uddd1\ud816\ude12\uda44\udc4e\ud89d\udd27\udb0b\udce1\ud865\udd74\ud972\udf20\uda11\ude8a\ud8cb\udfe4\uda06\udf07",
        3, 15381, 416332764, 5288182751430689214L, -74298L, false, true, (char) 23104, (char) 18742,
        Double.longBitsToDouble(0x3fe8c32e0698e39eL), Double.longBitsToDouble(0x3fe786860436226aL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 0, "\uda86\udd51\ud97c\ude26\uda85\ude62\ud968\udffd\udba0\udefb\uda7f\udf31\ud87f\ude94\ud938\udd47\ud8b8\udf99\udb70\ude47\udaf3\udc26\ud869\udffb\udbda\udf52\udb38\udd58\ud8fd\udcf3\ud9ff\uddfb\uda83\udf5c\udb2c\udc42", "\u37aa", "\udbe2\udd0b\udb78\ude7f\uda28\udf5d",
        5, 62640, 2022838001, -235225368603655902L, 50200L, false, false, (char) 47136, (char) 194,
        Double.longBitsToDouble(0x3fa00d5437147590L), Double.longBitsToDouble(0x3fe06b7bbc33f6adL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 0, "\uda6d\udda7\ud940\udde4\uda75\udf1c\ud968\udffd", "\u5850", "\u5cbe\ud9d3\udd47\ud869\udffb\uda1b\ude72",
        6, 50423, -828293390, 5175809292704998785L, -64071L, true, true, (char) 45761, (char) 19911,
        Double.longBitsToDouble(0x3fe1f221ac2fa7d7L), Double.longBitsToDouble(0x3fe5671b64438405L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 7, 7, 8, "\udb43\uddc8", "\u8839\uaf4a\u78d5\u8ea4", "\udbf2\udfe0\ub52b\ud98a\udcac\ud930\udeb8",
        8, 81822, 222849300, -8981160869306134002L, 76394L, false, true, (char) 54975, (char) 17736,
        Double.longBitsToDouble(0x3fb447f35fc3c6b8L), Double.longBitsToDouble(0x3fc501ca0f70350cL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 3, 2, "\ud8d8\udc5a", "\u46cb\u1c7d\u78d5\u09bb\u3037\u04a7\u148b\u1da5\u478f\u3b53\u4838\u064b\ud729", "\ud926\udc16\ud8d6\ude77\uda45\udce1\ud898\udfe5\ub8d3\udbe2\udd0b\udbdf\udccf\ud828\udd70\udb47\udd61\ud815\udf83\udb4d\ude71\uda64\uded4",
        2, 23439, 1368606664, -8560701384837219542L, -85761L, true, false, (char) 14843, (char) 50371,
        Double.longBitsToDouble(0x3fda8968e108bb60L), Double.longBitsToDouble(0x3fe5ca64793e838cL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 7, 7, 0, "\udaff\uded4", "\u2381\u76de\u78d5\u09bb", "\ud9c9\udf15",
        2, 37515, -362553395, 3014305408510801442L, -70758L, true, true, (char) 39353, (char) 6424,
        Double.longBitsToDouble(0x3fd64b3b9f48fe36L), Double.longBitsToDouble(0x3fc9d80e54f910d4L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 7, 7, 2, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd\udba0\udefb", "\u9013\u2a9d\u57fd\u9999\u2387\u8479\ucbbb\uc575\u646e\u22a1\u655c\u8f96\u2006\u37aa\ub1b6\u75a5\u09ce\u619e", "\udb9c\udd2b\udbbf\udd12",
        4, 86905, -1912536137, 970781172569564251L, 15372L, true, false, (char) 42436, (char) 52193,
        Double.longBitsToDouble(0x3fe07c6ffceb7ca9L), Double.longBitsToDouble(0x3fed4e169918cf88L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 7, 15, "\uda6d\udda7\ud8af\ude78\udb0b\udc15\ud968\udffd\udba0\udefb", "\u01b1\u9f9f\u8e36\uc07d\u1451\u7961\u4363\u141f\u646e\u22a1\u6a26\u9b5c\u202e\u37aa\u87a6\u83e4\u1d8b\u9dee", "\udb9c\udd2b\udbbf\udd12\u32eb\uda18\udffc",
        7, 89675, 1101358171, -4073094001790242780L, 63949L, true, false, (char) 64985, (char) 30505,
        Double.longBitsToDouble(0x3febe9a91aab6554L), Double.longBitsToDouble(0x3fdac44174cc51aaL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 2, "\ud83c\udd7f\ud8cf\udfaf\udbaa\udf4d\udbff\ude1e", "\u5850\u49e1", "\ud9d3\udc7b\ud869\udffb\udbda\udf52\udb38\udd58\uda26\udcc1\ud87f\udc09",
        55, 61463, -224265400, -388538863785586700L, -87347L, false, true, (char) 25531, (char) 26360,
        Double.longBitsToDouble(0x3fd990d43cf32feaL), Double.longBitsToDouble(0x3fe76808aed77a41L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 10, 10, 2, "\uda6d\udda7\ud8af\ude78\uda0d\udcd5\ud94c\udc0e", "\u5850\u49e1\u78be\u5845\u9999", "\udb38\udd58\uda26\udcc1\ud87f\udc09\uda83\udf5c\uda1c\uddb2\ud877\udf53\ud8c8\udebb\uda76\uddfe\ud906\udf85\u0cba\udbe2\udd7e\udb78\ude7f\uda28\udf5d\uda2b\udf0c\udb08\udc4a\uda78\udcef\ud9f1\ude73\ud902\udcc5\udb5b\uddf7\udba8\udc8e\udbed\ude39",
        0, 16990, 1453930301, -6310371049475603924L, -97287L, false, true, (char) 52839, (char) 64482,
        Double.longBitsToDouble(0x3fe4da7d5e60fbd9L), Double.longBitsToDouble(0x3fdba6676258631cL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 15, "\uda2e\udfc3\udaaf\udf8a\udbd3\udff9\ud93d\udcc7", "\u5850\u49e1\u78be\u5845\u9999\u5b30\u697f\u3eba\ubdbb\u7357\u9c09\u8255\u573f\u310d\ub23f", "\udb77\udda7\udbcb\udcb8\ud9c1\ude90\udaa1\udd25\udb39\udd39\udbca\ude08\ud981\udca0\ud859\ude27\udb6c\udc1b\ud834\uded0\u3ed5\udafc\udcbe\uda33\udddc\udb3f\udd7c",
        20, 77911, -455209564, -847060624853141927L, -66729L, false, true, (char) 23284, (char) 37281,
        Double.longBitsToDouble(0x3fe5ab7ecf3a19c0L), Double.longBitsToDouble(0x3fe808737edf4a6bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|close||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|closeArchiveEntry||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|ensureOpen||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|finish||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|pad|long,int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|putArchiveEntry|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|putNextEntry|org.apache.commons.compress.archivers.cpio.CpioArchiveEntry|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|setFormat|short|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|write|[B,int,int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|write|int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeAsciiLong|long,int,int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeBinaryLong|long,int,boolean|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeCString|java.lang.String|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeHeader|org.apache.commons.compress.archivers.cpio.CpioArchiveEntry|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeNewEntry|org.apache.commons.compress.archivers.cpio.CpioArchiveEntry|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|writeOldAsciiEntry|org.apache.commons.compress.archivers.cpio.CpioArchiveEntry|new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|close||new:org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:java.io.OutputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
