package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 6, 6, 15, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0688\u5eec", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud88e\udf55\udad5\uddf5\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 6, 0, 15, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0688\u5eec", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud88e\udf55\udad5\uddf5\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 6, 6, 15, "\ud829\udce8\ud87c\udd1e\ud881\ude29\ud8e6\udcd9\ud8aa\udff6\udbe6\uddaf\udaee\ude52\ud83f\udc50", "\u693b\u4f79\uc4f1\uba5a\u7541\u19fd\u5147\u7369\u39ce\u8bca\u8785\uc930\u7649\u847e\u5007\u558d\u9821\u1e1c\u8e32\ucb95\uc66d\u94b1\ud1a2\u832f\u26bc\u0ea0\ud571\u18c1\u0cb0\u6dec\ub9e6\u544e\ucce4", "\u88df\udbf8\udc47\ud9a5\udcd4\ud938\udc5e\udb52\uddd6\udb58\ude53",
        23, 38854, 1703077565, 8520401037598837266L, 47907L, false, true, (char) 45990, (char) 51866,
        Double.longBitsToDouble(0x3fee3af7cdd033a6L), Double.longBitsToDouble(0x3fd105893cea1b26L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 6, 15, "\ud8f2\udc92\ud8b2\udd2e", "\u38c8\u0688\u5eec", "\uda9f\udcf1\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud88e\udf55\udad5\uddf5\udbfe\udf6f\udbc7\udc03\ud93d\udd9c\ud9ba\uddad\udafb\udd2a\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u4b67\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\uda22\udfb5\ud971\ude52\uda01\udf57\ud9c5\udf68\udb98\udf49",
        12, 4705, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04818eb9a4L), Double.longBitsToDouble(0x3fe74c5d1b1aca82L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 6, 15, "\ud85a\udee5", "\u1af1\u38c8\u0688\u5727\u3221\uc1a8\u157e\u693b\u4897\uc4f1\ua526\u7521\ub79d\u51e9\000\000\u5213\u8785", "\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\uda5a\udced",
        34, -1000, 0, 7001446267660394118L, -28023L, true, false, (char) 18449, (char) 20173,
        Double.longBitsToDouble(0x3fd8cf7052a13b88L), Double.longBitsToDouble(0x3fe7813cabf7b20fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 9, 9, "\ud90e\ude7a\ud89b\udc02", "\u38c8\ub388\u5eec", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud8c5\ude36\udb38\udeee\udad5\uddf5\udae1\udd21\uda92\ude19\ud93d\udd6c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\uda26\udc74\ud8d4\udc1a\udb7e\udc02\ud9e6\ude1c\ud8fb\udd53\ud9c5\udf68\udb98\udf49",
        40, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 46009,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fc90dd7ee68b17cL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[-7]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 6, 15, ")", "\u1af1\u38c8\u0688\u5727\u8323\uc1a8\u157e\u693b\u4f79\uc4f1\ua526\u7521\ub79d\u51e9\u7369\u39ce\u6178\000", "s\udafb\udd7d\ud8d1\ude97\ud9cf\uddc6\udb24\udd1b\ud8ea\ude74\ud9e6\uddea",
        -5, 58175, -2009808994, -4588641728959403321L, 22368L, false, false, (char) 37866, (char) 36388,
        Double.longBitsToDouble(0x3fe0df122bfe1413L), Double.longBitsToDouble(0x3fec4d7a258cf705L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[41, 52, 76, -91]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 0, 6, 15, "\ud859\udd64\ud87c\udcd5", "\u0a39\u0688\u5eec", "\udbbe\udd5f\ud9f9\udfed\ud96a\udea8\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\ud82b\udd7b\ud888\udd03\ud82e\udc6c\udbd3\udeed\ud9e9\udf5a\u6e2f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\udb19\udc66\ud9b8\udca3\udb24\udd1b\ud906\udf82\udba5\ude80\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\udaff\udfb8\ud8d6\udc11\ud8f9\ude40\udb70\udcee\ud9c5\udf68\ud90a\udd01",
        -2, 65304, -1648044660, -3934319443218607129L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fee8a75fe9a3513L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-127, -126, 85, 44]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 13, 3, 15, "\udab1\udfb2\uda85\udc5c", "\u38c8\u78a7\ud6b6", "\uda9f\udd78\udba8\ude68\udae2\udc4b\uda3b\udf7e\ud83e\udef9\ud923\udd36\uda26\uddcb\ud888\udd0c\ud836\udc70\udbcc\ude03\udaea\udc78\ud8e4\ude07\udac8\udcee\ud81d\uddb6\udbf5\udef6\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\uda15\udce1\ub4f2\uda6b\udc57\udad0\udc0c\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 8865, -1648044660, 2852460059720094448L, -44428L, false, false, (char) 18114, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04806a4ea4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 2, 15, "\ud85a\udf33\u7221", "\u38c8\u0688\u5eec", "\ud8ef\udc3b\u45d9\ud94f\udd9a\udb89\ude7d\udac3\uddc6\u2d74\ud885\udf09\ud888\udd0c\ud8c4\udf6b\udbd9\udd5b\udad5\uddf2\ud8d2\udf9a\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\u94d4\ud829\udddb\ud9d7\udff1\ud834\udca3\uda2a\uddb9",
        1, 29221, -1014182825, -8632063901505036631L, -32601L, true, false, (char) 20692, (char) 24568,
        Double.longBitsToDouble(0x3fd2974fb037c48aL), Double.longBitsToDouble(0x3feff0a0793caf44L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 6, 15, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0688\u5eec", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud88e\udf55\udad5\uddf5\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\ud852\udc8f\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udfc4\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 11, 6, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0c29\u9dce", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda66\udd7d\udb9c\uddab\ud91f\udc4d\ud8f0\uddb4\udaf0\udf15\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 1908305066949459899L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75ff9a6582L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[42, -75, 76, -18]]\012",
        Z.run(T, 1, 14, 5, 15, "\ud85a\udee5\ud87c\udd1e", "\u69c5\u0688\u5eec", "\uda9f\udd78\u45d9\udb2b\udc9b\uda66\ude54\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud9c4\udf3e\ud836\udc70\ud88e\udf55\udad5\uddf5\udbfe\udf6f\udb6d\udcc4\ud93d\udd6b\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 38704,
        Double.longBitsToDouble(0x3fe2ba15688eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 13, 4, 15, "\ud85a\udee5\ud87c\udd1e\ud880\udc4b\ud8e6\udcd9\ud8aa\udff6\udbe6\uddaf\udaee\ude52\ud83f\udc50\ud8ba\udd41\uda9f\udd78\u45d9", "\ua526\u7521\ub79d\u51e9\u7369\u39ce\u8bca", "\ud93d\udd9c\uda2a\udd39",
        32, 2951, 1660824270, 2879127002731487060L, -20116L, true, false, (char) 41851, (char) 26333,
        Double.longBitsToDouble(0x3fe63e0288b9bfd7L), Double.longBitsToDouble(0x3fe51a09be86612aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 6, 15, "\ud9f0\udee6\uda3b\udc8d", "\u38c8\u0688\u5eec", "\uda9f\udd78\ud801\uded5\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud88e\udf55\udad5\uddf5\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud83a\udeca\ud816\udd54\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 5, 6, 15, "\uda54\udfb6\ud8d0\udc28", "\u67d9\u82ae\u2c1c\u8323\uc1a8\u157e", "\uda3b\udf7e\udbfc\ude18\ud856\udeca\uda51\udf0f\uda19\udf16\uda3d\udd5b\ud85a\udd3a\udaf0\udff8\udbfe\udf6f\ud9cb\udc05\ud92f\udd9f\uda2a\udd39",
        32, 2951, 1660824270, 2879127001372532564L, -20116L, true, false, (char) 33578, (char) 26333,
        Double.longBitsToDouble(0x3fe63e0288b9bfd7L), Double.longBitsToDouble(0x3fe24ff1d686612aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[42, -75, 76, -18]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 6, 15, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0688\u7154", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud8c5\udf0b\udb86\udcae\ud88e\udf55\udad5\uddf5\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\ud949\ude3c\ud9d8\udcc5\udb98\udf49",
        37, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 1, 14, "\uda8e\udd60\ud996\udcb5", "\u8f4a\u73aa\u5eec", "\ud8d7\udcaa\u45d9\ud876\udda3\ud907\udd94\udbf7\udc19\ud8de\udf8e\udaac\udcfd\ud8a4\ude02\ud836\udc70\ud88e\udf55\ud896\udcd6\ud924\udc76\udaaf\uddf2\ud93d\udd9c\ud906\ude67\ud9e9\udf50\ud8c8\ude30\ud9b8\udc20\ud9b8\udcf5\ud8fb\udec7\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\udaa2\uddb8\ud9d8\udc3e\ud9c5\udf68\udb98\udf49",
        12, 21992, -1648044660, 2852460059694142192L, 87653L, true, false, (char) 21223, (char) 29993,
        Double.longBitsToDouble(0x3fd9e3835735ece0L), Double.longBitsToDouble(0x3fb5bbbaa4e11970L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[16, -120, 90, -8]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 15, "\ud940\udfb8\ud98a\ude28", "\u38c8\u0688\u5eec", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud88e\udf55\udad5\uddf5\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\u8637\ud8f6\ude78\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 15, "\ud807\udce8\uda89\udceb\ud880\udf24\ud8e6\udcd9\ud8aa\udff6\udbe6\uddaf\udaee\ude52\ud91f\udfa1", "\u693b\u4f79\uc4f1\u74b9\u7547\u19fd\u3247\u7369\u771a\u8bca\u8785\uc930", "\udafb\udd7d\ud8d1\udf26",
        35, 10993, 1208721236, -3787982604373407968L, -34102L, false, false, (char) 62144, (char) 47248,
        Double.longBitsToDouble(0x3fe24ff1d686612aL), Double.longBitsToDouble(0x3fe0500f09c60dfbL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 14, 6, 15, "\ud829\udce8\ud87c\udd1e\ud867\udc9d\ud8b1\udcb9\ud8aa\udff6\udbe6\uddaf\udaee\ude52\ud83f\udc50", "\u387c\u4f79\ud17c\uba5a\u6ee0\u19fd\u5147\u7369\u39ce\u8bca\u8785\uc930\u7649\u847e\u5007\u558d\u9821\u1e1c\uc438\ucb46\uc66d\u94b1\ud1a2\u832f\u26bc\u0ea0\ud571\u18c1\u0cb0\u6dec\ub9e6\u9476\ucce4", "\u88df\udbf8\udc47\udb26\udfb5\ud9ae\udce0\u1350\udb58\uddc7",
        23, 38854, 1703077565, 8520401037598837266L, 47907L, false, true, (char) 45990, (char) 51866,
        Double.longBitsToDouble(0x3fd4798f99d64476L), Double.longBitsToDouble(0x3fd105893cea1b26L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 6, 15, "\ud829\udce8\uda42\ude40\ud8ee\udf1a\ud8e6\udcd9\udb0f\udd89\udbe6\uddaf\udaee\ude52\ud83f\udc50", "\u610e\u4f79\uc4f1\uba5a\u7541\u222a\u086b\ub14f\u9deb\u01ee\u86a9\uc930\u7649\u847e\u72fc\ua78c\u2ce7\u1e1c\u8e32\ucb95\uc66d\u7c2a\ud1a2\ucf57\u2f33\u0e42\u508f\u18c1\u0cb0\u6dec\u13ae\u917c\u8d92", "\ud8f8\udc88\udbe5\ude5c\ud9a5\udcd4\ud938\udc5e\udb52\uddd6\udb58\ude53",
        23, 38854, 1703077565, 8520401037598837266L, 47907L, false, true, (char) 45990, (char) 51866,
        Double.longBitsToDouble(0x3fee3af7cdd033a6L), Double.longBitsToDouble(0x3fd105893cea1b26L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 14, 14, 15, "\ud829\udce8\ud966\udc12\ud881\ude29\ud8e6\udcd9\ud8aa\udff6\udbe6\uddaf\udaee\ude52\ud83f\udc50", "\u693b\u4f79\u67e7\ubd4f\u8bc1\u4b26\u5147\u7369\u39ce\u2d20\u048b\ubc15\u7649\u847e\u25f1\ub1b2\u9821\u9d37\u08bd\u4dbf\uca6c\u0242\ud1a2\u832f\u26bc\u0ea0\ud571\u18c1\u0cb0\u6dec\u9679\uc1bc\ua77f", "\ub469\udbf8\udc47\ud9a5\udcd4\ud938\udc5e\udb3d\udd8c\ud9f1\udf01",
        24, 38854, 1703077565, 8520401037598800914L, 14237L, false, true, (char) 45990, (char) 51866,
        Double.longBitsToDouble(0x3fee3af7cdd033a6L), Double.longBitsToDouble(0x3fd1058936ea1beeL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 1, 15, "\ud8f2\udc92", "\ua0d0\ua1ac\u0688\u5eec\u8323\u015d\u14f7\u693b\u4f79\uc4f1\ua526\u7521\ub79d\u51e9\u7369\u39ce\u8bca\u8785", "\ud9ba\uddad\udafb\udd2a\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u4b67",
        36, 593, -1076417849, -127516165568585143L, -94395L, false, true, (char) 37581, (char) 15833,
        Double.longBitsToDouble(0x3fe68db622f02795L), Double.longBitsToDouble(0x3fefbd907c6c6c40L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 12, 15, "\ud8f2\udc92\ud8b2\udd2e", "\u38c8\u0688\u5eec", "\uda9f\udcf1\u45d9\ud9a1\uddc6\ud83b\ude7e\udbfc\uddc0\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud88e\udf55\udad5\uddf5\udbfe\udf6f\udbc7\udc03\ud93d\udd9c\ud9ba\uddad\udafb\udd2a\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba3\udcb0\ud864\udc6c\ud884\udfc4\udad0\udc8e\ud8f6\udee8\ud80d\ude60\ud84e\udca0\uda22\udfb5\ud971\ude52\uda01\udf57\ud87b\ude02\ud97e\udef0",
        47, 4705, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04818eb9a4L), Double.longBitsToDouble(0x3fe74c5d1b1aca82L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 1, 15, "\ud8f2\udc92", "\u1af1\u38c8\u1b91\u1d70\u8323\ube8b\u152b\u693b\u4f79\u8589\ua526\u7521\ub79d\u33a3\u738e\u39ce\u8bca\u8785", "\ud9ba\uddad\udafb\udd2a\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udb7b\ude15\ud922\udfae\u4b67",
        36, 593, -1076417849, -127516165568585143L, -94395L, false, true, (char) 37581, (char) 25139,
        Double.longBitsToDouble(0x3fd509dc45e04f2aL), Double.longBitsToDouble(0x3fefbd907cc22190L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |a0=[B:[[-62, 98, -126, -2]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:-1 |a0=[B:[[-62, 98, -126, -2]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud8f2\udc92\ud8b2\udd2e", "\u38c8\u0688\u5727", "\000\u4557\uda69\udddd\000\000\000\uda54\udc69\ud888\udd0c\u8766\ud88e\udf55\udad5\uddf5\udbe1\udc6f\udbc7\udc03\ud93d\udd9c\ud9ba\uddad\000\000\000\udaf6\ude5a\ud8ea\ude74\udba5\udeca\ud830\udd12\ucef7\000\000\000\000\000\000\000\ud977\ude3b\udadc\udd48",
        12, 4705, 12899724, 2852459716096758512L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04818eb9a4L), Double.longBitsToDouble(0x3fe74c5d1b1aca82L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 2, 0, "\ud8f2\udc92\ud8b2\udd2e", "\u38c8\u0688\u5eec", "\uda9f\udcf1\u45d9\udb42\uddea\uda3b\udf7e\ud967\udd0e\ud8bb\udfc2\ud87c\udffb\ud9c8\udfcd\udab3\udc05\uda5b\udd10\udad5\uddf5\ud916\udc9c\ud92a\ude43\ud9b6\udf99\ud8e3\udc79\udafb\udd2a\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\udb5f\udf59\ud963\udf63\udb53\ude23\ud9d0\udf12\udad0\udc6e\ud9be\udeec\ueeff\ud90a\udc9e\uda22\udfb5\ud971\ude52\ud865\udeea\ud9c5\udfe1\udb98\udf49",
        12, 65093, -1648044660, 2852460059694142192L, 87653L, true, false, (char) 37965, (char) 31866,
        Double.longBitsToDouble(0x3fe74c5d1b1aca82L), Double.longBitsToDouble(0x3fd6cad8fbe0eeaeL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 13, 7, "\ud8f2\udc92\ud8b2\udd2e", "\u8320\u0620\u5eec", "\uda5b\udcef\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud88e\udf55\udad5\uddf5\u153e\udbc7\udc32\ud93d\udd9c\ud9ba\uddad\udafb\udd2a\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\ud8e4\udd89\ud948\udc45\u4b67\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\uda22\udfb5\ud971\ude52\uda01\udf57\ud9c5\udf68\udb98\udf49",
        12, 78529, 626687628, 2852460450536166128L, -18910L, false, true, (char) 10438, (char) 47701,
        Double.longBitsToDouble(0x3fc61e9fe183c488L), Double.longBitsToDouble(0x3fe74915531aca82L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 5, 15, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0688\u5eec", "\uda60\udf64\udbe2\udd92\ud85f\ude38\uda4f\udf97\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud888\udd0c\ud836\udc70\ud891\udc55\udb19\uddf7\ud8bf\udee2\ud9d1\udf64\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\ud852\udc8f\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udfc4\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 3, 15, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0688\u5eec\u8323\uc1a8\u157e\u46bc", "\udbfc\ude18\ud8de\udf8e\udba9\udc3e\ud881\udd63\ud836\udc70\ud88e\udf55\uda29\ude80",
        18, 92555, 963422793, 5839317634388263105L, 42030L, true, false, (char) 51015, (char) 38639,
        Double.longBitsToDouble(0x3fefa65b745712f6L), Double.longBitsToDouble(0x3fecf61c66a9883bL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[42, -75, 76, -18]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[42, -75, 76, -18]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 13, 15, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0688\u7154", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda51\udf0f\ud8c5\udf0b\udb86\udcae\ud88e\udf55\udad5\uddf5\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\ud949\ude3c\ud9d8\udcc5\udb98\udf49",
        37, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 1, 14, "\uda8e\udd60\ud996\udcb5", "\u8f4a\u73aa\u08c5", "\ud8d7\udcaa\u45d9\ud876\udda3\ud907\udd94\udbf7\udc19\ud8de\udf8e\udaac\udcfd\ud8a4\ude02\ud836\udc70\ud88e\udf55\udad3\udfd5\ud924\udc76\udaaf\uddf2\ud93d\udd9c\ud906\ude67\ud9e9\udf50\ud8c8\ude30\ud9b8\udc20\ud9b8\udcf5\ud8fb\udec7\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\udaa2\uddb8\ud9d8\udc3e\ud9c5\udf68\udb98\udf49",
        12, 21992, -1648044660, 2856682184344802032L, 87653L, true, false, (char) 21223, (char) 14889,
        Double.longBitsToDouble(0x3fd9e3835735ece0L), Double.longBitsToDouble(0x3fb5bbbaa4e11970L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:-1 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 0, 0, "\ud8f2\udc92", "X\u2ded\u54c0\u5700\u3d55\u1f25\000\000\000\000\000\000\000\000\000\u19ce\u393f\000", "\ud9ba\uddad",
        -5, -1000, 0, 2878926061796589568L, -20116L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 6, 6, 15, "\ud85a\udee5\ud87c\udd1e", "\u38c8\u0688\u5eec", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda58\udd0f\ud888\udd0c\ud836\udc70\ud888\udf71\udad5\uddf5\udbfe\udf6f\ud9cb\udc05\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\udad0\udc8e\ud8f6\udee8\ueeff\ud90a\udc9e\udb7e\udc02\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, -95, 94, 56, 80, 99]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 10, "\ud930\udcd1\ud98e\udc68\ud880\udc93", "\u0688\u5eec\u8323", "\u45d9\udab6\ude91\u0b56\udbfc\ude18\ud8ce\udc8e\ud823\udf39\uda05\udc55\ud836\udc70\udaf3\udce8\uef99\udbeb\ude88\ud9ca\udfd0\ud8fd\udd9c\uda2a\udd39\ud8bb\udd7d\ud8d1\udf26\ud994\ude51\ud9d5\udd1f\udae3\udc44\udb98\ude8d\ud830\udd12\u48c7\udb10\udd35\ud8f6\ude78\udbed\udd9e\ud94e\udcde\udb7e\udc02\ud991\ude00\udae5\udec9\u8fc0\ud8b9\udcd9\ud987\udd01\ud80b\udcad",
        49, 63688, -600155611, 2418634109524196546L, -32411L, true, false, (char) 53223, (char) 2162,
        Double.longBitsToDouble(0x3fe884c7039a6582L), Double.longBitsToDouble(0x3fc0958a40daabe8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, 0, 74, 97]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 15, "\uda30\udf30\ud97a\udd91", "\u38c8\u0688\u5eec", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda4b\udc0f\u775d\uda15\udd5f\ud921\udd7c\ud8ce\udc0d\udbc7\udd69\uda10\ude03\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\u8637\ud8f6\ude78\ueeff\ud90a\udc9e\udb77\udc7f\ud971\udea2\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 2852460059694142192L, -18910L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, -95, 94, 56, 80, 99]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[0, -95, 94, 56, 80, 99]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 13, 10, "\ud930\udcd1\ud98e\udc68\ud880\udc93", "\u0688\u5eec\u8323", "\u45d9\udab6\ude91\u0b56\udbfc\ude18\ud8ce\udcbb",
        7, 19832, -1981577370, -5904657005253650193L, -44666L, false, false, (char) 42462, (char) 20938,
        Double.longBitsToDouble(0x3fd8f505a37435fcL), Double.longBitsToDouble(0x3fd4d7f7e0757236L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, 0, 74, 97]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[0, 0, 74, 97]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 13, 15, "\uda30\udf30\ud97a\udd91", "\u38c8\u0688\u5eec", "\uda9f\udd78\u45d9\udb42\uddea\uda3b\udf7e\udbfc\ude18\ud8de\udf8e\uda4b\udc0f\u775d\uda15\udd5f\ud921\udd7c\ud8ce\udc0d\udbc7\udd69\uda10\ude03\ud93d\udd9c\uda2a\udd39\udafb\udd7d\ud8d1\udf26\ud9b8\udca3\udb24\udd1b\ud8ea\ude74\udba5\udeca\ud830\udd12\u48c7\u8637\ud8b2\udfd8\udbf9\udeac\ud837\udd39\udbda\udd17\ud96e\udf93\udb70\udcee\ud9c5\udf68\udb98\udf49",
        12, 64577, -1648044660, 2852460061075182320L, 83571L, false, true, (char) 60963, (char) 4144,
        Double.longBitsToDouble(0x3fe2bb04808eb9a4L), Double.longBitsToDouble(0x3fe5eb75fb9a6582L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|applyPaxHeadersToCurrentEntry|java.util.Map|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|available||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|canReadEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|close||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|consumeRemainderOfLastBlock||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getCurrentEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getLongNameData||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextTarEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getRecord||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getRecordSize||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|isAtEOF||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|isEOFRecord|[B|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|matches|[B,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|parsePaxHeaders|java.io.InputStream|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
