package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 4, 5, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5\ud879\udf57\uda3a\ude33\udad3\udddf\u38a5\ud96c\udd46", "\ua3ed\u8738\uce33\ub6de\u2a8b\uc7b2\u53bb\u0955\u01cb\ubcd6\ubc29\u7964", "\uda74\udd86",
        30, 978, 1927372920, 3889249693584632729L, 6886L, true, true, (char) 48020, (char) 57091,
        Double.longBitsToDouble(0x3fd585fe6951a16cL), Double.longBitsToDouble(0x3fdd1a39651d097cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 2, 9, 9, 5, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud9f1\udc9c\uda00\udfa9\ud9a4\udd55\ud804\udc59\udaa8\udfa5\udbc3\udd9b\ud9c5\udd1f\ud80a\udc52\ud96c\udd15\udaae\udf6d\ud93a\udd77\ubb1d\ub0a8\udbb4\udf68\udb03\udebb\udb7c\ude92\udab9\uddc4", "\u3191\u55af\uc936\u7964\u8799\u8519\u0b97", "\udad4\udc95\ud91c\ude75\uda1f\udd8d\ud90e\udde2\ud802\udccc\udabb\udc81\udb97\uddcf\udb10\udc95\uda36\ude8e\udb51\udf35\ud81a\ude84\udb20\ude92",
        40, 13732, -1521743708, 5621513737600118914L, 30063L, true, true, (char) 32578, (char) 20009,
        Double.longBitsToDouble(0x3fddd8b789c1a38cL), Double.longBitsToDouble(0x3fdb209804bd3880L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 0, 5, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5\udab9\udeee\uda3a\ude33\u5c22\ufa29\udac6\udfac\udb11\uddb3\ud93a\udd01\ud866\udcb8\ub0a8", "\uac9b\ud526\u53bb\u0955", "\uda7d\ude96\ud88c\udd6f\ud82a\udc3c\u03fd\uda18\udc82\udb1f\udf3e\ud9eb\udec7\ud865\udf3d\ud8f7\udf2b\ud9a6\udef5\ud87e\udf05\uda1c\udddc\udaa8\udc20",
        4, 95699, -351040872, -6659113217014446639L, 1698L, false, false, (char) 38655, (char) 49602,
        Double.longBitsToDouble(0x3fe9c5f4346e5b86L), Double.longBitsToDouble(0x3fe83004ec14b6aaL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 4, 4, "\000\000\ud866\udd67\ud870\udffc\uda00\udfa9\ud99d\ude70\ud92b\udee5\udace\uddc1\uda2e\ude76\udad3\udddf\000\000", "\"\000\000\000\uc32e\uc79c\u53bb\u4dc6\000\ubfcc\000\000", "",
        46, -1000, 0, 905510912L, -10798L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3fc51a16d7468e58L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 0, 4, "\ud942\udecd\ud8bd\udfb6\ud8d1\udf4b\uda3f\uded8\ud832\udc63\udb62\udc31\ud92b\udee5\ud879\udf57\ud9fd\uddd3\uda8c\udf0b\ud96e\udc6f\udba6\udd43", "\u97d2\023\ua261\ub688\u2a8b\uc7b2\u5110\u1851\ubc2d\uad0d\u39c0\u1eb2", "\udbb7\udfff\uda96\udee1\ud84b\udfcd\ud865\udf3d\udb6d\udc2e\ud84b\udeca\ud853\uddb2\ud9ed\udf04\udabe\udd65\uf632\udbc3\udc19\uda36\ude3b\udb51\udf35\ud800\udcf8\ud98d\uddda\ud99e\udc2c\u3dbf",
        3, 50655, 2003633413, -5689652495501177705L, 84652L, true, false, (char) 35856, (char) 16594,
        Double.longBitsToDouble(0x3fe30619d45ee597L), Double.longBitsToDouble(0x3fee36ddce35f583L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 8, 6, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5", "\ucc99\ua0c9\u2dd4\ud692\u5ef0\ua3ed\u8738\uce33\ub6de\u2a8b\u766f\u66b6\u0955\u01cb\ubcd6\ubc29\u7964\u8799\uc6fe\u9248\u89b2\u7637\u9e18", "\ud87e\udf05\ud9ed\udf04\udabe\udd65\ueb80\udb2f\udcae\uda36\ude8e\udb51\udf35",
        57, 63174, 346159624, 1995448866248865769L, 3844L, true, false, (char) 16307, (char) 28072,
        Double.longBitsToDouble(0x3fca2904718acac0L), Double.longBitsToDouble(0x3fd9019b5814e4a0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 2, 3, "\ud942\udea9\ud81c\udf0e\ud866\udd67\udb7a\udf00\uda8e\udc92\ud936\udd29\ud92b\udee5\ud879\udf57\uda40\udeb7\udad3\udddf\u38a5\ud96c\udd46\udaae\udf6d\udb42\udd7b\ud866\udcb8\ub0a8\udbb4\udf68\udb42\udef4\udb7c\uddf2\udaed\udd1e", "\u3799\ubcd6", "\ud831\udfef\u84bd\uda7f\udc85\udb3a\udc5e\uda85\udef0\ud865\udfbc\ud8f7\udf2b\ud9a6\udef5\ud87e\udf05\ud9ed\udf04\uda88\ude65\ueb80\udb2f\udcae\uda36\ude8e\udb51\udf35\ud9e9\ude8d\ud9f8\udf88\u4049\ud924\udfcd\udadc\udc85\udb1d\udd16\ud863\udd12",
        20, 51743, 306900213, -81088973536181975L, -42478L, false, true, (char) 13953, (char) 40793,
        Double.longBitsToDouble(0x3fc9e644ccc9a1bcL), Double.longBitsToDouble(0x3fe1d086756a06e5L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 1, 9, 4, 5, "\ud942\udecd\ud81c\udf0e\ud866\udd67\uda3d\udda2\ud86b\udcda\ud970\udfef\ud8b4\udcaa\ud879\udf57\uda3a\ude33\uda27\udcea\udbf5\uddef\ud96c\udd46", "\ua3ed\u8738\u9d6f\ub660\u2a8b\uc7b2\u53bb\u0955\u01cb\u5194\u556c\u3f68", "\uda74\udd86",
        30, 88650, -844279967, 3889248701447187353L, 6886L, true, true, (char) 48020, (char) 57091,
        Double.longBitsToDouble(0x3fd585fe6951a16cL), Double.longBitsToDouble(0x3fdd1a39643f097cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 4, 5, "\ud942\udecd\ud81c\udf0e\ud866\udd67\uda93\ude6b\uda01\udc2d\ud929\ude76\ud92b\udee5\ud879\udf57\ud86a\ude6c", "\u2dd4", "\ud866\udcb8\ub0a8\udbb4\udf68\udb33\udff4\udb7c\uddf2\udab9\uddc4\uda8b\udef2\udb96\ude3a\ud870\udf3f\udaa1\udc1f\uda7d\ude96\ud84e\udd70",
        3, 72337, 368799803, 4525289985375162258L, -8867L, true, true, (char) 55642, (char) 17996,
        Double.longBitsToDouble(0x3fed284975d899bdL), Double.longBitsToDouble(0x3fe842ffdd585fe6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 4, 5, "\ud942\udecd", "\u531f\u6481\u5427\u5dee\u71e3\u4a47\ucc99\u4374\u98d6", "\udb2d\udc3e\ub0a8\udbb4\udeeb\udb33\udff4",
        33, 83502, 427392977, -7750548442489824044L, -727L, true, false, (char) 11598, (char) 46793,
        Double.longBitsToDouble(0x3fdf7fb20e889cdcL), Double.longBitsToDouble(0x3fec91f6687803ebL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 8, "\ud942\udecd", "\u0b4a\u6481\u5427\u5dee\u71e3\uc946\ucc99\u53d4\u2dd4", "\ud866\udcb8\uda10\udcbd\uda77\udd30\udac0\ude89\udb7c\uddf2\ud91b\udc16\uda8b\udef2\ud949\udf45\ud93e\udfd7\udaa1\udc1f\uda7d\ude96\ud84e\udd70",
        3, 72337, -1098414604, 4525419852301291410L, 43151L, false, true, (char) 48523, (char) 9163,
        Double.longBitsToDouble(0x3fed296c3dd81dbdL), Double.longBitsToDouble(0x3fce4bff75617fe8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 4, 5, "\ud942\udecd\ud9d4\udfca\ud866\udd67", "\u5427\u5dee\u71e3\uc946\ucc99\ua0c9\u2dd4\ud692\u0f6d", "\udbb4\udf68\ud9e9\ude8e\udb7c\uddf2\ud902\udd41\udaa2\udcc5\udb96\udecd\ud93e\udfd6",
        -3, 63609, 2025210451, -5167400533897338495L, -96092L, false, true, (char) 25699, (char) 18903,
        Double.longBitsToDouble(0x3feccfdc9c727ce8L), Double.longBitsToDouble(0x3fccdcfa3a354f3cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 5, 8, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5\ud879\udf57\uda3a\ude33", "\u2dd4\ud692\u5ef0", "\udbb4\udf68\udb33\udff4\udb7c\uddf2\udab9\uddc4\uda8b\udef2\udb96\ude3a\ud93e\udfd6",
        -3, 63609, 2028552787, -5167400533897338495L, -30556L, false, true, (char) 25699, (char) 55006,
        Double.longBitsToDouble(0x3fecc9afcc727ce8L), Double.longBitsToDouble(0x3fe3d73e8fa5092eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 6, 2, "\ud8da\uddf9\ud81c\udf85\ud866\udd67\ud870\udffc\uda00\udfa9\udb81\udf47\ud92b\udee5\ud879\udf57\uda3a\ude33\udb98\udf9c\ud9cb\ude31", "\ubef5\ua3ed\u2ac8", "\udb81\udf0c\udbcf\udf9e\udaf5\udfe9\ud942\udddf",
        19, 65212, 2034905487, 3021260121436668508L, -63254L, false, true, (char) 36416, (char) 1956,
        Double.longBitsToDouble(0x3fe4e3970b9935f9L), Double.longBitsToDouble(0x3fbc9f3a33d4bdf0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Long:1010 |a0=[B:[[18, -99, -20, -34, 54, 55, 64, -52]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 3, 6, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5\ud879\udf57\uda2d\udd6d\udb33\ude96\u38a5\ud96c\udd46", "\u0a73\u8a53\uce33\ub6de\u2a8b\uc7b2\u8c4c\u4d3f\u8ec6\u8591\ubc29\u7964", "\uda74\udd86",
        30, 98416, 1927372920, 3889249693584632729L, 6886L, true, true, (char) 48020, (char) 57091,
        Double.longBitsToDouble(0x3fd585fe6951a16cL), Double.longBitsToDouble(0x3fd95411d51d097cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 0, 0, "", "\ud7fc\u0f62\u6448\u5427\u5dee\u71e3\uc946\ucc99\u05c9\uc0d3", "\udb10\udc87\u00d9\000\000\udb7c\uddf2\udab9\uddc4\uda8b\udef2\u8541\ud93e\udfd6\udaa1\udc1f\uda7d\ude96\ud84e\udd70",
        3, 72337, 368799803, 4525289985375162112L, -8867L, true, true, (char) 55642, (char) 17996,
        Double.longBitsToDouble(0x3fed2801700000bdL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 0, 4, "\000$\000\000\000\000\ud921\uddcf\ud879\udf57\uda16\ude6a\udad3\udddf\u38a59", "\000\000\000\000\000\000\000\u5c13\u01cb\ubcd6\ubc29\ub88c", "\000",
        30, -1000, 1927372920, 3889249693584632729L, 96608L, false, true, (char) 24638, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd3e84419524b38L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 8, 5, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5\ud82f\udd92\uda3a\ude33\udad3\udddf\ud81e\udf6d\ud83b\udfb5", "\u325d\u8738\uce33\ub6de\u2a8b", "\ud850\udf93\uda89\ude98",
        0, 63609, 2025210451, -5167400533897338495L, -30556L, false, true, (char) 25699, (char) 59870,
        Double.longBitsToDouble(0x3fed310a9c72fac0L), Double.longBitsToDouble(0x3fe7d8276be3092eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 7, 0, "\ud942\udf14\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\uda2d\udff3\ud907\uddda\ud854\udfd2\udbef\udd37\udad1\udef3\u38a5\ud882\udd51", "\u6724", "\udb33\udff4\udb7c\uddf2\udab9\uddc4\ud985\ude8e\udb96\ude3a\ud93e\udfd6\udaa1\udc1f",
        24, 58451, -1203129192, -5989046978657685445L, -8867L, true, true, (char) 20279, (char) 51275,
        Double.longBitsToDouble(0x3fed2849751d01bdL), Double.longBitsToDouble(0x3fe842ffdd585fe6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 7, 5, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5\ud879\udf57\uda3a\ude33\udad3\udddf\u38a5\ud96c\udd46", "\u404a\u99eb\ub8be\u881b\u9cce\u919e\u53bb\u0955\u01cb\u1a62\ub46e\ua84a", "\uda74\ude01\ud9b4\uddf7\ud84b\udfcd\uda9b\udff8\ud928\udcf5\ud9a6\udef5\ud87e\udf05\ud9ed\udf04\udabe\udd65\ueb80\udb2f\udcae\uda36\ude8e",
        30, 697, 1545996942, -5561960622069387561L, -78137L, true, false, (char) 35289, (char) 25632,
        Double.longBitsToDouble(0x3fe3c750f846e8deL), Double.longBitsToDouble(0x3fe38e03daff88eeL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 4, 0, "", "\u0396", "\ud929\ude76\ud9cf\udddc\ud9ab\ude4d\uda3a\ude33\udad3\udddf\u38a5\000\udaae\udf65\ud93a\udd77",
        4, 6241, 133, 0L, 59744L, true, true, (char) 21828, (char) 7572,
        Double.longBitsToDouble(0x3fc92b9f294c0000L), Double.longBitsToDouble(0x3fc30f16c402e124L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Long:175 |a0=[B:[[18, -99]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 4, 0, "\ud942\udecd", "\u531f\u6481\u5427\u5dee\u71e3\uc946\ucc99\ua0c9\u2dd4", "\ud866\udcb8\ub0a8\udbb4\udf68\udb33\udff4\udb7c\uddf2\udab9\uddc4\uda8b\udef2\udb96\ude3a\ud93e\udfd6\udaa1\udc1f\uda7d\ude96\ud84e\udd70",
        22, 72337, 368799803, 4525289985375162258L, -8867L, true, true, (char) 55642, (char) 45899,
        Double.longBitsToDouble(0x3fed284abdd81dbdL), Double.longBitsToDouble(0x3fe842ffdd585fe6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 4, 3, "\ud953\udccc\ud838\udc48\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud93a\udfe9\ud879\udf57\uda3a\ude33\udad3\udddf\ud817\udd49\ud96b\udea0\udaae\udf6d", "\u8738\uce33\ub6de\u2a8b\uc7b2\u1dcd\u09c1\u01cb", "\udaca\udc4e\udb25\udc8c\uda94\udf51",
        3, 94180, 65752978, 8278003659501560829L, -10798L, false, false, (char) 63698, (char) 48020,
        Double.longBitsToDouble(0x3fe842ffdd585fe6L), Double.longBitsToDouble(0x3fc51a16d7468e58L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Long:864 |a0=[B:[[-30, 126, 47, 88, 54, 55, 64, -52]]\0121=java.lang.Long:864 |a0=[B:[[-30, 126, 47, 88, 54, 55, 64, -52]]\012",
        Z.run(T, 2, 1, 1, 9, "\uda12\udfae\uda5f\udd88\ud866\udd67\ud870\udffc\uda00\udfa9\uda43\udea3\ud92b\udf5e\ud879\udf57\uda3a\ude33\ud85c\udca4\uda82\udce4\udb04\udd86\udb13\udf3a\ud9e0\udf08\ud866\udcb8\ub0a8\udbb4\udf68\udb33\udff4\udb7c\uddf2\udab9\uddc4\uda8b\udef2\ud906\udd95\uda95\ude68\udaa1\udc1f\uda7d\ude96\ud84e\udd70\ud826\udd5d\udbb5\udea7\uda56\ude11\ud9ac\udef7\ud84b\udfcd\udaa9\ude35", "\ub01a", "\ud9e6\udd8c\ud96c\ude11\ud898\uddcf\ud9f0\uddca\uda68\udcdd\udb75\udc50\ud85d\udfa3\ud8ae\udd1b\udad2\udd92\uda3e\udd8b",
        11, 46603, -1058729115, 8130614398077743050L, -65243L, false, true, (char) 44500, (char) 50517,
        Double.longBitsToDouble(0x3fe382a9953656caL), Double.longBitsToDouble(0x3fe5b2198fa6cc0fL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 2, 9, 9, 5, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud9f1\udc9c\uda00\udfa9\ud9a4\udd55\ud804\udc59\udaa8\udfa5\udbc3\udd9b\ud9c5\udd1f\ud80a\udc52\ud96c\udd15\udaae\udf6d\ud93a\udd77\ubb1d\ub0a8\udbb4\udf68\udb03\udebb\udb7c\ude92\udab9\uddc4", "\u3191\u55af\uc936\u7964\000\000\000", "\udad4\udc95",
        21, 65124, 1364841751, 1934673409166140097L, 30321L, false, true, (char) 44382, (char) 26983,
        Double.longBitsToDouble(0x3fe57a7df416ba41L), Double.longBitsToDouble(0x3fec631b18a4960cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 0, 5, "\ud942\udecd\ud94a\ude50\ud866\uddc9\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5\uda2b\udc09\udbd8\udf6f\u5c13\ufa29\ud900\udeb8\ud9c4\uddef\ud9ef\udc5b\ud866\udcb8\ub0a8", "\uac9b\ud526\u53bb\uac96", "\uda7d\ude96\ud88c\udd6f\ud82a\udc3c\u03fd\uda18\udc82\udb1f\udf3e\ud9eb\udec7\ud865\udf3d\ud90b\udc28\ud9a6\udef5\ud8bb\udee4\udbfb\udcf2\udaa8\udc20",
        4, 17859, -341404575, -6659113217014446639L, 1698L, false, false, (char) 38655, (char) 46668,
        Double.longBitsToDouble(0x3fe9c5f4346ee438L), Double.longBitsToDouble(0x3fe83004ec14b6aaL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 0, 5, "\ud942\udecd\uda3e\udf08\ud866\udd67\ud870\udffc\uda00\udfa9\ud94c\udea9\ud985\udf78\udab9\udeee\uda3a\ude33\uda88\udc7a\ud88e\ude00\udb38\udf4c\udaf0\ude1e\ud93a\udd01\ud866\udcb8\ud968\udca5", "\uac9b\ua316\u96bf\ubf2d", "\udb76\udd4a\ud860\udce2\uda1f\udc49\ud944\udf01\uda18\udc82\udb1f\udf3e\ud82e\udc69\ud9ea\udf66\ud8f7\udefc\ud9a6\udef5\ud87e\udf05\uda1c\udddc\udaa8\udc20",
        4, 95699, 1349683864, -966470426534177955L, 1698L, false, false, (char) 38655, (char) 49541,
        Double.longBitsToDouble(0x3fe9c5f4346e5b86L), Double.longBitsToDouble(0x3fe83004ec14b6aaL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 0, 0, "", "\000\u43bd\u6481\u4930\u5dd8\u4a56\uc946\ub1e1\u88ad\u3d3c", "\ud866\udcb8\ub0a8\udbb4\udf68\udb33\udff4\udb29\udec7",
        11, 94880, 1416660289, 8570068617469207205L, 47968L, true, true, (char) 53787, (char) 41512,
        Double.longBitsToDouble(0x3f919f5311c6be20L), Double.longBitsToDouble(0x3e3feb9708000000L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 0, 5, "\ud942\udecd\ud81c\udf0e\udb50\udc7d\ud871\udc54\uda00\udfa9\ud929\ude76\ud92b\udee5\udab9\udeee\uda3a\ude33\u5c22\ufa29\udac6\udfac\udb11\uddb3\ud93a\udd01\ud866\udcb8\ub0a8", "\uac9b\ud526\u53bb\u0955", "\uda7d\ude96\ud88c\udd6f\ud82a\udc3c\udbb2\udda1\uda18\udc82\udb1f\udf3e\ud9eb\udec7\ud865\udf3d\ud8f7\udf2b\ud9a6\udef5\ud87e\udf05\uda1c\udddc\udaa8\udc20",
        4, 95699, 1611893400, -6658919166097046063L, 1698L, false, false, (char) 38655, (char) 49602,
        Double.longBitsToDouble(0x3fe9c5f4346e5b86L), Double.longBitsToDouble(0x3fe83004ec14b6aaL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 7, 9, "\udaca\uded1\ud9f4\udf5a\ud866\udd67\udbb0\udffc\ud9fe\udddf\ud9dc\ude13\ud9bc\udef5\ud9dd\uded6\ud937\udeb8\ud8b0\udd47\uda69\ude22\udac6\udfac\udb11\uddb3\udb7c\ude31\ud859\udce1\ub0a8", "\uac9b\ud526\u53bb\u38a1", "\udb07\udd57\ud8fd\udf69\ud82a\udc2e\ud968\udcef\uda18\udc98\udb1f\udf3e\ud9eb\udec7\ud929\udca7\ud8f7\udf2b\ud9a6\udef5\ud87e\udf05",
        3, 66714, 1546755544, 3570134425797888664L, -16641L, true, false, (char) 47298, (char) 18217,
        Double.longBitsToDouble(0x3fdcaf1359ba59ccL), Double.longBitsToDouble(0x3fe9c5f4346e5b86L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Long:906 |a0=[B:[[18, -99, 54, -54, -49, 64, -52]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 5, "\ud942\udecd\ud966\udffa\u3cff\ud870\udffc", "\u423b\u4a56\uc946\u3196\u3138\u2b07\u5bed\u5e7a\ua3ed\u8738\uce33", "\udaa0\ude77\uda8b\udef2\udb96\ude3a\ud93e\udfd6\ud948\uddf3\uda5e\udcd9\ud88c\udd6f\uda48\udfeb\u033d\uda18\udc82\udb1f\udf3e",
        29, 89920, 905536509, 9000632528512572530L, 58112L, false, true, (char) 56212, (char) 48162,
        Double.longBitsToDouble(0x3fee87589dd1a396L), Double.longBitsToDouble(0x3fe0ac25f5112b81L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 0, 3, "\ud942\udecd\ud81c\udf0e\ud866\udd67", "\u7507\u7697\u4a56\uc946\u3196\u225b\u13e9\uac65\u9bcf", "\udbb4\udf68\ud960\ude2b\uda85\ude05\udaa0\ude79\uda8b\udef2\udb96\ude3a\ud820\udd87",
        0, 63609, 2024161875, 2966523941318011121L, 93519L, false, false, (char) 25671, (char) 55006,
        Double.longBitsToDouble(0x3fecc9afcc727ce8L), Double.longBitsToDouble(0x3fe3d73e8e60b1b0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:-980 |a1=[B:[[-14, -48, -126, -48]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 4, 4, "\000\000\ud866\udd67\ud870\udffc\uda00\udfa9\ud99d\ude70\ud92b\udee5\udace\uddc1\uda2e\ude76\udad3\udddf\000\000", "\"\000\ud0b2\000", "\uda8b\udef2",
        20, -1000, 16361125, 0L, -100000L, false, false, (char) 251, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fecc9afcc727ce8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:-1005\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 4, "\000\000\ud866\udd67\ud870\udffc\uda00\udfa9\ud99d\ude70\ud92b\udee5\udace\udd17\uda2e\ude76\udb0d\uddbd\ud917\udfa6\udb32\ude8a", "\"\000\000\000\uc32e\uc79c\u53bb\u4dc6\000\ubfcc\000\ucd33", "\udb1e\udc0e",
        -5, -1000, 0, 3889139755306757017L, -35121L, false, false, (char) 0, (char) 64861,
        Double.longBitsToDouble(0x3fd00000019ad36cL), Double.longBitsToDouble(0x3fdd199543de4050L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 0, 4, "\000\000\ud866\udd67\ud870\udffc\uda00\udfa9\ud99d\ude70\ud92b\udee5\udace\uddc1\uda2e\ude76\udad3\udddf\000\000", "\"\000\000\000\uc32e\uc79c\u53bb\u4dc6\000\ubfcc\000\000", "",
        46, -1000, 0, 905510912L, -10798L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3e44000000000000L), Double.longBitsToDouble(0x3fc51a16d7468e58L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 8, 6, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude9a\ud92b\udee5", "\ucc99\ua183\u2dd4\ud692\u5ef0\ua3ed\u8738\uce33\ub6de\u9227\u766f\u66b6\u0955\u01cb\ubcd6\ubc29\u7964\u8799\u73c8\u56f5\u89b2\u7637\u7dcd", "\ud904\uded6\ud960\udd28\ud96a\udcb6\ud9a3\udf73",
        7, 56932, -531809143, 3633283516115651142L, -17524L, true, true, (char) 55613, (char) 46338,
        Double.longBitsToDouble(0x3fb34e4c5a6e6328L), Double.longBitsToDouble(0x3fe35f39e8d14823L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 8, 6, "\ud942\udecd\ud81c\udf0e\ucb5a\ud9ff\udf88", "\u5dee\u697b\u663f\u9530\ua0c9\u2dd4\ud692\u2a22\ucbcc\u8742\uce33", "\udb13\udfb1\u400d\udb96\ude3a\ud93e\udfd6\uda10\udf61\ud894\udf8d\ud84e\udd70\ud83a\udc5e\ud81d\udc72\uda74\udd86\ud9ac\udef7\ud4f8\uda77\udf5c\ud8f7\udf2b\ud9fd\udec2",
        5, 7786, 498986917, 6916295205404966664L, -25416L, true, true, (char) 36684, (char) 40035,
        Double.longBitsToDouble(0x3fe160a50fe91bb1L), Double.longBitsToDouble(0x3fd05e838b4858beL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 3, 8, "\ud942\udecd\ud81c\udf0e\ud866\udd67\ud870\udffc\uda00\udfa9\ud929\ude76\ud92b\udee5\ud879\udf57\uda3a\ude33\udad3\udddf\u3972\ud96c\udd46\udaae\udf6d\udbc2\udf3b\ud99c\udeba\udb2a\ude7a\udbb4\udf68", "\u766f\u66b6\u0955\u01cb\ubcd6\ubc29\u7964\u8799\u19ed\u4ef9\ud201", "\ud8f7\udf2b\udb9c\uddf4\ud87e\udf05\ud9ed\udf04\udabe\udd65\ueba3\udb2f\udcae\uda36\ude8e\udb51\udf35\ud9ec\ude8d\ud8b9\udd09\ud8b3\udd3f\udb14\udfcd\ud8c1\ude82\ud9b8\udfa2\ud8f0\udd08\ud9c5\udd42\ud9b2\uddd7\ud924\udeab\uda67\udc42\udb53\udde5\uda3c\udc4c\udaee\udeb9\ud947\udc77\ud962\udff2\ud879\udd6a\ud912\uddb6\ud8a0\uddb5\ud867\udc8c\udac5\udf35\ud8ea\udd51\ud8fe\udcad",
        1, 80998, -1587977966, -5439415406837518284L, -36202L, true, true, (char) 50970, (char) 63978,
        Double.longBitsToDouble(0x3fb8c44ddf46b5d8L), Double.longBitsToDouble(0x3fd1c1276f4d82dcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 5, 8, "\ud942\udecd", "\u531f\u6481\u5427\u5dee\u71e3\uc946\ucc99\ua0c9\u2dd4", "\ud866\udcb8\ub0a8\udbb4\udf68\udb33\udff4\udb7c\uddf2\udab9\uddc4\uda8b\udef2\udb96\ude3a\ud93e\udfd6\udaa1\udc1f\uda7d\ude96\ud854\udd73",
        3, 72337, 368799803, 4525289985375162258L, -9120L, true, true, (char) 55642, (char) 17996,
        Double.longBitsToDouble(0x3fed284970c52242L), Double.longBitsToDouble(0x3fb61d4a85b605f0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 0, 0, "", "\ubdc5\u0f0f\u6448\u5427\u9db6\u71e3\uc946\ucc99\u05c9\u93e0\u1039\uba4c\u7e4a\u00d9\uca19\u0d0b\uaec8\u91de\u6864\u8541\u01cb", "\ud84e\udd70\ud83a\udc5e\uda88\uddb0",
        1, 94249, 65752832, 8278003659494089705L, -10786L, false, false, (char) 61394, (char) 189,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3f92ad6678c535a0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:-1005 |a1=[B:[[50, 24, -9, -66, -77]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 2, 4, "\uda45\udf14", "\u0f62\u6448\u5427\u5dee\u71e3", "\udbe5\udc18\ud95b\udc46\udaae\udf6d\ud93a\udd77\ud9e2\udf10\ud8ee\udff3",
        -5, -1000, -1540341924, -388314425114390528L, -727L, true, false, (char) 11598, (char) 22986,
        Double.longBitsToDouble(0x3fadd67174415fb0L), Double.longBitsToDouble(0x3fe801f66d7803ebL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Long:208 |a0=[B:[[-48]]\012",
        Z.run(T, 1, 1, 3, 4, "\000", "\000", "\uda2d\udfbc",
        21, 6262, 1291909462, 6662964812768608313L, 43003L, false, false, (char) 0, (char) 28082,
        Double.longBitsToDouble(0x3e1c5fe000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=java.lang.String:\u00fc7 |a0=[B:[[-4, 55, 0, 89, 54, 55, 64, -83]]\012",
        Z.run(T, 2, 9, 8, 5, "\udb2c\udd67\ud830\udc89\ud866\udd67\ud870\udfdd\uda00\udfa9\ud929\ude76\ud92b\udee5\ud82f\udd92\uda3a\ude33\udad3\udddf\udaf0\uded6\ud97e\ude44", "\u8e03\ub511\uce1d\ub6de\u2a8b", "\udaab\ude81\uda89\ude98",
        0, 63609, 2025210451, -5167400533897322701L, 41393L, false, true, (char) 25699, (char) 59870,
        Double.longBitsToDouble(0x3fed310a9c72fac0L), Double.longBitsToDouble(0x3fe7d8276be3092eL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 0, 5, "\ud942\udecd\ud94a\ude50\ud930\udddf\ud870\udffc\uda00\udfa9\ud929\ude76\uda5f\udfdf\udb3b\udc11\udbd8\udf6f\udbec\udca9\ufa33\ud900\udeb8\ud9c4\uddef\ud9ef\udc5b\ud866\udcb8\ub0a8", "\uac9b\ud526\u53bb\u29a0", "\uda7d\ude96\ud88c\udd6f\ud82a\udc3c\u03fd\udb9e\ude96\udb1f\udf3e\ud9eb\udec7\ud865\udef7\ud90b\udc28\ud824\ude38\ud8bb\udf4e\udbfb\udcf2\udaa8\udc20",
        4, 17859, -341404575, -6659113213423167535L, 1698L, false, false, (char) 38655, (char) 46668,
        Double.longBitsToDouble(0x3fe9c5f4346ee438L), Double.longBitsToDouble(0x3fe83004e940b6aaL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.Integer:-981\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 2, 6, "\uda53\udd08\udb8c\udf50\ud866\udd67\ud870\udffc\uda00\udfa9\ud8f2\udeb7\ud933\udd55\udbe4\udfcd\uda2e\udf1d\udad3\udddf\ufbfaA", "\u04a9\u0098\ud0b2\000", "\uda8b\udef2\uda6f\udd47\uc500",
        19, -1000, 0, 0L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fecc9afcc727ce8L), Double.longBitsToDouble(0x3fd74b3ec6af743aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:-1005\0121=java.lang.Integer:-1005\012",
        Z.run(T, 2, 5, 5, 2, "\000\000\ud866\udd67\ud870\udffc\uda00\udfa9\ud99d\ude70\ud92b\udee5\udace\uddc1\uda2e\ude76\udad3\udddf\000\uda36\udd5a", "\"\000\ud0b2\000\uc32e\uc79c\u53bb\u4dc6", "\000",
        -5, -1000, 0, 70650219150049280L, -100000L, false, false, (char) 57745, (char) 55642,
        Double.longBitsToDouble(0x3fc8aba553acadd4L), Double.longBitsToDouble(0x3fde24e20b739248L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:-980 |a1=[B:[[-14, -48, -99, 103]]\0121=java.lang.Integer:-980 |a1=[B:[[-14, -48, -99, 103]]\012",
        Z.run(T, 2, 5, 5, 0, "\000\000\ud866\udd67\ud870\udffc\uda00\udfa9\ud99d\ude70\ud92b\udee5\udace\uddc1\ud93b\udcdd\udad3\udddf\000\000", "\"\000\u96cd\u8997", "\uda8b\udef2",
        20, -1000, 16361125, 0L, -100000L, false, false, (char) 251, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fecc9afcc727ce8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Long:175 |a0=[B:[[18, -99]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 7, "\ud942\udecd", "\u537c\u6481\u5427\u5dee\u71e3\uc946\ucc99\ua0c9\u4517", "\ud866\udcb8\u87a8\udbb4\udf68",
        59, 8076, -90411498, 8495354603195368769L, 8197L, true, true, (char) 29156, (char) 49854,
        Double.longBitsToDouble(0x3fe7acf98809f9a1L), Double.longBitsToDouble(0x3fea20afdf923ecdL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.String:\u00fc7 |a0=[B:[[-4, 55, 0, 89, 54, 55, 64, -83]]\0121=java.lang.String:\u00fc7 |a0=[B:[[-4, 55, 0, 89, 54, 55, 64, -83]]\012",
        Z.run(T, 2, 8, 8, 5, "\udb2c\udd67\ud830\udc89\ud866\udd67\ud870\udfdd\uda00\udfa9\ud929\ude76\ud92b\udee5\ud82f\udd92\uda3a\ude33\udad3\udddf\udaf0\uded6\ud97e\ude44", "\u8e03\ub511\uce1d\ub6de\u2a8b", "\udaab\ude81\uda89\ude98",
        0, 63609, 2025210451, -5167400533897322701L, -64335L, true, false, (char) 37533, (char) 59870,
        Double.longBitsToDouble(0x3fed310a9c72fac0L), Double.longBitsToDouble(0x3fe7d8276be3092eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|computeCheckSum|[B|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|exceptionMessage|[B,int,int,int,byte|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatCheckSumOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatNameBytes|java.lang.String,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatUnsignedOctalString|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseName|[B,int,int|static",
    "C|org.apache.commons.compress.archivers.tar.TarUtils|<init>|",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
