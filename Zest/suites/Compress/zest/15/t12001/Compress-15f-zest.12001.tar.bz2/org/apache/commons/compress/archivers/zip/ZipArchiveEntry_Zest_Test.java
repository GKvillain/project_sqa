package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class ZipArchiveEntry_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 8, 12, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a", "\u05ab\u7afb\ua755", "\udbae\udeb3\udbb3\udc05\ud927\udd7f\ud9ad\ude71\udb4f\ude2b\uda9c\udd5d\ud940\udc49\udb18\udea2",
        30, 60265, 492073215, 8309628520782510989L, 82907L, false, true, (char) 18122, (char) 4623,
        Double.longBitsToDouble(0x3fe07b7043018925L), Double.longBitsToDouble(0x3fee69b0a7b3a692L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 7, 12, "\u0d2f\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a", "\u05ab\u7afb\ua755", "\udbae\udeb3\udbb3\udc05\ud927\udd7f\ud9ad\ude71\udb4f\ude2b\uda9c\udd5d\ud940\udc49\udb18\udea2",
        30, 60265, 492073215, 8309628520782510989L, -63781L, true, true, (char) 18122, (char) 4623,
        Double.longBitsToDouble(0x3fe07b7043018925L), Double.longBitsToDouble(0x3fec89b0a7b3a68fL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 1, 6, 8, 12, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud868\udf81", "\u05ab\u7afb\ua755", "\udb93\udc0c\udbb3\udc05\ud927\udd7f\ud9ad\ude71\udb5d\ude2b\uda9c\udd5d\ud940\udc49\udb18\udea2",
        30, 60265, 492073215, 8309628520782510989L, 82934L, false, true, (char) 18122, (char) 4623,
        Double.longBitsToDouble(0x3fe07b7043018925L), Double.longBitsToDouble(0x3fee69b0a7b3a692L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 12, "\u6c2a\ud858\udc5d\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a", "\u05a9\u7afb\ua755", "\ud957\udde6\udbb0\udee5\ud927\udd7f\ud9ad\ude71\udb4f\ude2b\ud9f0\udc68\ud94b\udde6\ud814\udf9f",
        7, 60265, 492073215, 8309628520782510989L, 82907L, false, true, (char) 18122, (char) 4623,
        Double.longBitsToDouble(0x3fe07b727b018925L), Double.longBitsToDouble(0x3fee69b0a7b3a692L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 3, 8, 12, "\u6c2a\uf04f\ud83d\udc93\ud815\ude6a\ud81f\udf58\udaea\udc27\u28d6\ud918\udeed\ud842\uddc4", "\u05ab\u7afb\u1b6f", "\udbae\udeb3\udbb3\udc05\ud927\udd7f\ud959\udf42\ud95f\ude73\uda9c\udd08\ud940\udc49\udb18\udea2\ud846\udf12\udb3b\udd28",
        5, 80157, 1720453517, -7643470933608286843L, -20599L, false, false, (char) 37399, (char) 52262,
        Double.longBitsToDouble(0x3fee69b0a7b3a692L), Double.longBitsToDouble(0x3fd686a445d45d88L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 3, 15, 14, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\ue7af\ud80f\udd6b\uda0b\uddf1\ud98b\udcba", "\u783e\u2679\ua755\u2e68\ua608\ubc24\ub41d\u4e52\ucf91\u84d0\u5267\ub709\ubd37\u87dc\u7fc1\u3403\u4bca", "\udb9c\ude2c\ud8f4\udd4a\ud9b1\ude63\ud988\udc90\udb8c\udfa2\uda0c\ude58\udb54\uddf2\udae0\udcb0\uda0a\udc61\ud89e\udcd2\udaf4\udd19",
        14, 70923, 1841302792, -5917129898123996158L, -84472L, true, true, (char) 4609, (char) 8196,
        Double.longBitsToDouble(0x3feea23cca5d5858L), Double.longBitsToDouble(0x3fd7064c50e5229eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 12, 8, 12, "\u6c2a\uf04f\ud80b\udfc4\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a", "\u05ab\u7afb\ua755", "\udbae\udeb3\udbb3\udc05\ud927\udd7f\ud9ad\ude71\udb4f\ude2b\uda9c\udd5d\ud940\udc49\udb18\udea2",
        30, 60265, 492073215, 8309628520782510989L, 82907L, false, true, (char) 18122, (char) 4623,
        Double.longBitsToDouble(0x3fe07b7043018925L), Double.longBitsToDouble(0x3fee69b0a7b3a692L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 4, 12, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a\uda21\udde3\uda44\uddd0\ud9c6\udcdb", "\u7e0b\ua611\u0acf\uc630\ucf2a\ucf91\u5101\u5267\ub709\ubd37", "\udb13\udd7a\ud9d2\udca7\udac0\ude34\uda99\udd89\udb9c\ude2c\ud8d7\udd5b\ud9b1\udeae\ua6a7",
        40, 28798, -1880574863, -4385060105425026370L, 12947L, false, true, (char) 984, (char) 5962,
        Double.longBitsToDouble(0x3fdb7ce2ff6c19f4L), Double.longBitsToDouble(0x3fe55a1e7c7e4717L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 8, 12, "\u6c2a", "\ub5cd", "\uda43\udd50\u4f63\ud837\ude8a\uda21\udde3\uda44\uddd0\ud9c6\udcdb\ud8df\udf0d\udaf5\udfd8\ud816\udcb3",
        59, -1000, 0, 0L, -100000L, false, false, (char) 46655, (char) 40266,
        Double.longBitsToDouble(0x3fec4f3118ffd7afL), Double.longBitsToDouble(0x3fe8e8eaa38d7351L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 9, 5, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb89\uddf9\ud837\udd9e", "\u05ab\u7afb\ua755", "\ud91c\ude4a\udbb2\udf78\ud927\udd7f\ud9ad\ude71\udb4f\ude2b\uda9c\udd5d\ud940\udc49\uda02\udef4",
        37, 5044, 492033191, -420880831851906163L, -91333L, true, false, (char) 45079, (char) 52262,
        Double.longBitsToDouble(0x3fee69b0a7b3a692L), Double.longBitsToDouble(0x3feaf18cec072a4bL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 8, 12, "\u6c2a\ud822\udee3\udb1f\udef8\ud815\ude6a\ud81f\udf58\udaea\udc27\ud93a\uddfa\udb68\ude6d\udb95\udeb9", "\u05ab\u7afb\u7770\u02b6\ua5d0\uc27a\u9b60\ubdaa\ucf91\u848f\u8cc6\ub6b5\ubd37\u87dc\u4dae\u0b21\u4bca\uc11d", "\ud8d7\udd5b\ud9b1\udeae\ua6a7\udb8c\udf0d\udae9\ude2b\udb35\ude87\uda45\udc64",
        9, 80286, -29215648, 6335801891535917996L, 91755L, false, true, (char) 30909, (char) 13470,
        Double.longBitsToDouble(0x3fe659df7de6f53cL), Double.longBitsToDouble(0x3fe62141a27bad53L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.util.Date:Wed Dec 31 15:59:59 PST 1969 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 12, "\u6c2a\uf04f\ud9d9\udfa2\uda5c\udfda\udbf2\udd1b\ud9be\uddcb\udb39\udc25\udb68\ude6d\ud837\ude8a\uda21\udde3\uda44\uddd0\udb85\uddbb\ud8df\udf0d\udbf1\ude45\uf5ee", "\u3024\uac03", "\ud84d\udfc4\uda8c\udcf8\udb18\udea2\udbc3\udd1a\uda1a\udf79\udab4\udc73\ud95f\udcb5\udb5c\udfd3\uda99\udd89\udb9c\ude2c\ud8d7\udd5b\udbef\uddad\uda06\ude36",
        24, 35044, -795583195, -659562148835843322L, -86313L, true, false, (char) 1065, (char) 3938,
        Double.longBitsToDouble(0x3fe2531122e35d75L), Double.longBitsToDouble(0x3fecf71ba03e98a1L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 12, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a", "\uc563\u7afb\ua755", "\udbae\udeb3\udbb3\udc05\ud927\udd7f\ud9ad\ude71\udb4f\ude2b\uda9c\udd5d\uda41\udf43\udb18\udea2",
        30, 617, 492073215, 8309628520782510989L, 82907L, false, true, (char) 18122, (char) 4623,
        Double.longBitsToDouble(0x3fe07b7043018925L), Double.longBitsToDouble(0x3fee69b0a7b3a692L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 0, 8, 12, "\u6c2a\uf04f\000\000\000\udaea\udc27\uda43\udd50\000\000", "\u05ab", "\ud816\udcb3\ud8a8\udd87\udbe6\udc2e\000\udbb8\udf5b\ud9ad\ude71\000\udb51\udca7\ud940\udc49\udb18\udea2",
        -4, -1000, 0, 78789517L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe07b7040018925L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 0, 0, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\000\000\000", "", "\000",
        5, 1124, -1552523224, -1017685030873435621L, -67476L, true, false, (char) 1134, (char) 46655,
        Double.longBitsToDouble(0x3fe41ef63f89e623L), Double.longBitsToDouble(0x3fcffaf5ec747550L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 0, 0, 12, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udad9\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a", "\036\000\000", "",
        41, 97739, 0, -791969792L, 46317L, false, true, (char) 52081, (char) 45679,
        Double.longBitsToDouble(0x3fddb24ef056a3c8L), Double.longBitsToDouble(0x3fe07b7043018925L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 0, 0, 12, "\000\000\ud80b\udf9e\ud815\ude6a\ud81f\udf58\000\u0800\udb68\ude6d\u2df4", "", "\u8bb0",
        24, 1124, 40, 0L, -100000L, false, false, (char) 1134, (char) 46655,
        Double.longBitsToDouble(0x3e4c000000000000L), Double.longBitsToDouble(0x3fcffaf5ec747550L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 8, 8, 12, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a", "\u05ab\u7afb\u3b29", "\udb0d\uded3\ud8a1\udf8d",
        -5, 98034, -791992346, 5696530937029309792L, -83235L, true, true, (char) 18607, (char) 55408,
        Double.longBitsToDouble(0x3fec6b9a8bca04b2L), Double.longBitsToDouble(0x3fd8595ec65d8e82L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 3, 3, 8, "\uda95\udd07\udb13\udd85\ud83d\udc93\ud815\ude6a\uda30\udf3f\ud829\udd6d\u28d6\ud918\udeed\ud842\uddc4\uda21\udde3\udbe6\udec1\ud8f2\udfc5\ud81c\udfa0\ud828\ude8f\ud8f0\ude68\uda7a\udcd1\udbae\udeb3\udb3e\udc8b\ud927\udd7f\ud959\udf42\ud95f\ude73\uda9c\udd08\ud8f8\udfb3\udb19\udeb9", "\uc348\u8c89\u12d0\u89f6", "\ud8a0\udef1\ua6f6\uda1a\udd97\ud85d\udd4e\ud859\udce0\u3958\ud9d5\udd5b\udb2f\udcc6\ud9fb\uddf2\udac5\udfb2\udac7\udf05\uda93\udff3\uda3f\udcce\ud870\udf57\ud89a\udd82\uda09\ude22",
        -2, 77854, 1068809953, 8039628047190437866L, -7975L, true, false, (char) 35500, (char) 3892,
        Double.longBitsToDouble(0x3fe3ede8893cf55aL), Double.longBitsToDouble(0x3fad9652dec17280L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 9, 14, "\u6c2a\ud9bf\ude11\ud80b\udf9e\ud883\udda2\uda19\udf78\ud98e\udd70\ud80f\udd6b\uda0b\uddf1\ud98b\udcba", "\u783e\u2679\ua755\ubcbd\ua608\ubc24\ub41d\u4e52\ucf91\u84d0\u5267\ub709\ubd37\u87dc\u7fc1\u3403\u9571", "\udb9c\ude2c\ud8f4\udd4a\ud9b1\ude63\ud988\udc90\udb8c\udfa2\uda0c\ude58\udb54\uddf2\udae0\udcb0\uda0a\udc61\ud89e\udcd2\udaf4\udd19",
        14, 70923, 1841302792, -5917129898123996158L, 80572L, false, true, (char) 3591, (char) 12981,
        Double.longBitsToDouble(0x3fd7064c51b5229eL), Double.longBitsToDouble(0x3fd966e87ca9f0aeL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 6, 12, "\u6c2a\uf04f\ud80b\udf9e\ud815\ude6a\ud81f\udf58\udaea\udc27\uda43\udd50\udb68\ude6d\ud837\ude8a\uda21\udde3\uda44\uddd0\ud9c6\udcdb", "\u7e0b\ua405", "\ud908\udd6d\ud9c2\udcbc\udb4f\ude2b\uda9c\udd5d\ud940\udc49\udb18\udea2\udb63\udcfc\ud991\ude90\udb13\udd83\ud9d2\udca7\udac0\ude34\uda99\udd89\udb9c\ude2c\ud8d7\udd5b\ud9b1\udeae\ua6a7\udb32\udf3b\uda80\udec6\udbb5\uddd5\udb9b\udf7a\ud935\udda7\uda1a\udcf5\udad0\udc62\ud8b1\udc69\udb29\ude09\ud9c0\udf37",
        45, 60622, 324637692, 6597372970094205114L, 33960L, false, false, (char) 1882, (char) 11222,
        Double.longBitsToDouble(0x3fdec6b081fa2086L), Double.longBitsToDouble(0x3fe5be8ad85436a0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 4, 4, 12, "\u6c89\uf04f\ud80b\udf9e\ud815\ude6a\uda9b\uddb6\udae9\udfc1", "\u88da\u4783\u8f79\u05ab\u7afb\u5dd9\u195d\u8024\u0b45\ucb15\u3784\ucd32\ub2f8", "\uda86\udd0d\ud8fa\udc53\ud8ea\udf68\udafa\ude5b\ud98e\uddaa\ud898\udf2c\uda5b\udf8a\ud85b\udd39\ud9cf\udf43\ud9b2\udd06\ua6a7\udade\uddd1\uda5f\udf64\udbb5\uddd5",
        33, 60262, -1742325712, -6965611553876459940L, -66759L, true, true, (char) 31920, (char) 7802,
        Double.longBitsToDouble(0x3fbf91c5e8261a48L), Double.longBitsToDouble(0x3fe9cc1a7c3b68b6L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 8, 8, 12, "\u6c2a", "\ub5cd", "\ud899\udc87\uda6b\udc8c\ud837\ude8a\uda21\udde3\uda44\uddd0\ud9c6\udcdb\ud8df\udf0d\udaf5\udfd8\ud816\udcb3",
        59, 91669, 0, 924057600L, -100000L, false, false, (char) 46655, (char) 40266,
        Double.longBitsToDouble(0x3fec4f3118ffd7afL), Double.longBitsToDouble(0x3fe8e8eaa38d7351L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 8, 12, "\u6c2a", "\u6c71", "\udb70\ude26\ud9e7\uddd4\ud837\ude12\uda21\udde3\uda44\uddd0\ud880\udcd8\ud8df\udf0d\udaf5\udfd8\ud816\udcb3\uda57\udd90\ud9c2\ude9c\udbc6\udcfd\ud927\udd7f\ud9ad\ude71\udb4f\ude2b\uda9c\udd5d\ud940\udc49\udb46\uded6\ud877\udd07\udb3b\udd28\ud9d2\udeb9\udaad\udc3c\ud923\udd3a\uda89\udf36\udbb5\udd6b\ud8d7\udd5b",
        32, 89391, -1994046961, -8044481164050997303L, -45864L, false, false, (char) 56700, (char) 28582,
        Double.longBitsToDouble(0x3fe2df98ea4055d3L), Double.longBitsToDouble(0x3feb6c0a4da91e41L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|equals|java.lang.Object|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|addAsFirstExtraField|org.apache.commons.compress.archivers.zip.ZipExtraField|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|addExtraField|org.apache.commons.compress.archivers.zip.ZipExtraField|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|clone||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getCentralDirectoryExtra||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExternalAttributes||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraField|org.apache.commons.compress.archivers.zip.ZipShort|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraFields||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraFields|boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getGeneralPurposeBit||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getInternalAttributes||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getLastModifiedDate||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getLocalFileDataExtra||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getMethod||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getName||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getPlatform||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|equals|java.lang.Object|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
