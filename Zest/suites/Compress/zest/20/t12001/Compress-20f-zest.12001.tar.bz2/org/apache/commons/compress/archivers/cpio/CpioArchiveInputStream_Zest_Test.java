package org.apache.commons.compress.archivers.cpio;
import org.junit.Test;
import static org.junit.Assert.*;
public class CpioArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 1, 6, 9, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, -61200L, true, false, (char) 41080, (char) 2447,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 1, 6, 9, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\uda61\udf5b\ud87a\udff3\ud922\udf28\udaac\udfa6\udbcc\ude44\uda23\udf0f\uda57\ude46\uda5f\udd58\udb33\udd6f\ud946\udd05\ud8c2\uddfc\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ue19c\ud90b\udcb2\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\ud92c\ude08\udb65\udff8\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\udb41\udc89\udb4e\udf1c\ud9d5\udcba\udbaf\ude33\udafc\udfb7\udb6f\udf65\uda86\udedf\uda82\udc9e\udbaa\udfba\u9d72\udac5\udc07\ud94f\udc51\ud841\udcf3\ud954\udfeb\ud991\udfe1\uda50\uddc8\udbc9\udeab\uda83\ude5a\ud829\udd1b\ud855\udfa7\u1996\udae1\udfff\uda87\udfe2\udbfe\udd04\udae4\ude97\udbb9\udd4d\ud95c\ude60\udb9f\uded0\u69ed\ud81a\ude98\udab6\udea3\ud985\udf04\udb94\udee7\ud831\ude27\udb1a\udc38\ud8fa\udc58\ud912\ude96\u4aa1",
        36, 73152, 1182429410, 8598710342045951138L, 55583L, false, false, (char) 22047, (char) 38552,
        Double.longBitsToDouble(0x3fe7671b44224515L), Double.longBitsToDouble(0x3fdd2e661e65d8d6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 6, 9, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud82d\udf5c\u6f6a\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u6fea\u9ec9", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, -61200L, true, false, (char) 41080, (char) 2263,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 9, 11, "\ud8c1\ude25\udaf4\udf38\ud9c0\ude38\uda44\udc40\ud83e\udd02\ud96e\udd0c\ud82f\udefe\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\ud91d\udc09\uda5f\udcc9\udb33\udd6f\ud9c2\udf82\uda08\uddb0\ud854\udf42\ud816\udf37\ud809\udf97\udaf9\udfd6\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud922\uddd1\ud892\udf36\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\udbdb\udfc0\udb49\ude4e", "\u6b3e\uaec9\u2d02\u1dda\u31e0\u31e9\u1611\u4fb6\u34f9\ud18a\u0fbc\u385f\ubbee\u5a7c\u35dd\u52ed\u5da2\u351c\u1a63\ub3b6", "\ud951\udc5c\udaa8\udcd1\ud943\udcda",
        22, 70668, -384969189, -9151943861865742004L, -78376L, false, true, (char) 46632, (char) 51349,
        Double.longBitsToDouble(0x3fd102400be28588L), Double.longBitsToDouble(0x3fe58037354b5709L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 5, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc68\udaf9\udfe5\udae0\udf24\udbf8\udd00\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\udee3\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, -61200L, true, false, (char) 41080, (char) 2447,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 0, 16, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, -61200L, true, false, (char) 41080, (char) 2447,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 3, 11, "\ud8c1\ude25\uda7f\udfbe\ud80b\udcd9\ud9f0\udc96\ud844\udc90\udb36\udd60\udaeb\udd77\udb60\udf48\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\u7b03\ud8f6\udc16\ud9d3\udc13\udb0a\udc24\u6f01\udb91\udc5d\ud8bd\udcf1\ud96d\udf89\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\uda03\ude91\udb6b\udc4f\uda52\ude7d\udbc4\ude07\udb76\udcd8", "\u6b3e\uaec9\u2d02\u1dda\u531a\u4eac\u1611\u4fb6", "\ud904\udf64\udacf\udf24\ud98b\udc59\udbdb\udcef\u9d91\udac5\udc07\ud94f\udcaa\ud841\udcf3\ud954\udfeb\udbe4\ude69\ud071\uda0b\udf05\ud9e4\udc97\ud8ba\udc07\udb7f\udce4\udb0b\udd70\u2ec9\ud956\uddca\ud842\udf45\udba2\udd9f\ud9e1\ude9f\ud90a\udf96\ud945\ude95\ud917\ude19\uda5b\udd1f\ud8c6\udd4c\udb4f\ude58\ud9fa\udc2a\udbba\ude32\udb9c\ude6a\ud9de\udf0d\udb6b\udd3e\udb17\udf11\uda06\udc1e",
        40, 86641, 219900849, 2579214077102425601L, -47911L, false, true, (char) 46608, (char) 54480,
        Double.longBitsToDouble(0x3fcc40283ef6a110L), Double.longBitsToDouble(0x3fe6718970a08c42L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-111, -11, 79, -114, -51, 101, 49, 102]]\012",
        Z.run(T, 2, 6, 9, 11, "\ud8c1\ude25\uda7f\udfbe\ud9fd\udd95\u1161\uda96\uded6\udac5\udc3c\ud9e7\udf46\udb57\udf29\ud827\udfa5\ud992\ude77\ud87b\udc7f\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb4b\udf6f\ud839\udc54\uda1f\udc29\ud8a3\udfe4\ud88c\udd04\ud95d\ude81\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\ued97\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        24, 5653, -1836596596, -6179239300856065954L, -63973L, false, false, (char) 33261, (char) 31240,
        Double.longBitsToDouble(0x3fe768a20a6e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 17, 11, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbde\udd37\udb36\uddb5\uda77\udca2\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda56\ude46\udabd\udd67\udb33\udd6f\ud9c2\udf82\udb6f\uddef\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfc7\udae0\udf24\u6f01\ud92f\udfad\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda55\udfaf\ud9b3\udcc7\udb64\udfe2\ud84c\udd6b", "\u6b3e\uaec9\u2d02\u1dda\u531a\u4eac\u1611\u4fb6", "\udb6f\udf65\uda7f\ude3a\uda82\udc9e\udbaa\udfba\u9d72\udac5\udc07\ud94f\udcaa\ud841\udcf3\ud954\udfeb\ud924\udc6a\ud87e\udfa9\ud9e8\udf5b\udbcf\udde1\uda61\udf99\ud951\uddb4\udbe8\udcf3\ud80b\uddcf\udac2\udc7d\ud958\udf0d\udb55\uddf2\udbe0\udf90\uda20\udfce\udbb4\udcd6\udb18\uddb7\ud826\udf19\uda35\udc2e\ud919\udc6a\udbdc\udda9\udbfe\udc80\ud94f\udc32\udac0\udd4b\udbe0\udeea\uda1e\udf24\ud832\udffb",
        18, 25958, 1919796806, 9155732726034205601L, -71246L, true, true, (char) 46241, (char) 43292,
        Double.longBitsToDouble(0x3fe71f5fab3597f6L), Double.longBitsToDouble(0x3fe6ee5d5da548fbL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 9, 11, "\udba6\udd53\ud850\ude34\ud883\udd33\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\uda74\udd22\ud898\udcdf\ud9af\ude89\ud87a\udff3\ud922\udf28\udaac\udfa6\ud841\udf2a\ud888\udfef\uda70\udcdd\uda7b\uddc5\udb33\udcf9\ud9c2\udf82", "\u7ab5\u1de0", "\u6f01\uda12\udc17\ud8f7\udff4\uda5a\udccc\ud8fc\udd8a\udb89\udf90\ud915\udced",
        31, 16584, -1550974021, 6738745416517165929L, -68990L, true, false, (char) 27807, (char) 19792,
        Double.longBitsToDouble(0x3fe5f96f792d65e5L), Double.longBitsToDouble(0x3fe9c1e61010f762L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 1, 3, "\ud8c1\ude25\udb79\udfbb\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb8a\udeef\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\ud96c\udf20\uda2d\udd91\uda9d\udd7a\udae1\udf56\ud9c2\udf82\ud822\udd28\ud8a3\udf3e\ud88c\udd04\ud8b7\udc8b\uda1e\udd97\ud924\ude3e\u6f91\udb91\udc5d\ud815\udd42\udb08\udd69\ud90a\udffa", "\u5667\u9f6d\u34b4\u1599\u14a4\u3393\ubaed\u0687\u3674\u7add\u6b3e\uaec9\u554e\u5bb5\u531a\u4eac\u1611\u4fb6\u34f9\u8989\uc7d5\u385f\u25ee\u5a7c\u35dd\u67f6", "\u6fe4\uda3a\ude9b\udbf8\udd24\uda4a\udf9a\uda45\udc99\udacf\udc93\ud9cf\udc3a\udb5a\udd0d\ud990\udee9\ud8e5\uddec\ud942\udf1e\ud8fa\udfdb\udb6b\udcaa\ud9a6\udf23\ud92c\udf14\uceb9\uda55\udfd0\udb8c\uddf1\ud8b4\udea4\ud997\uddfe\uda84\udc3b\udb3b\udf22",
        28, 12040, 435660183, 5516406886741038770L, -98965L, false, true, (char) 5725, (char) 52466,
        Double.longBitsToDouble(0x3fd1b50176ab3a82L), Double.longBitsToDouble(0x3fe73a995b09c7a7L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 17, 14, "\ud90b\ude6b\uda7f\udfbe\ud894\udcde\ud8ad\ude50\uda64\udcdf\ud988\uddbe\udacf\udefd\udb57\udf29\ud9ce\udd75\udb93\uddf6\ud87a\udff3\ud922\udf28\ud9fb\uddd5\ud881\udd61\ud8e9\udfea\uda2b\udc60\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\uda2e\uddb5\ud8b7\udc8b\udb1d\udf3c\udae0\udf24\u6f01\udb47\udca8\ud8f8\udc1f\ud912\uddc9\udbe6\ude36\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\ud9f9\udfde\udb5c\udf73\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1\ud9ef\udf8d", "\uaec9\u968c\ua126\u9115\uc9ae\u165c\u4fb6", "\udb6f\udf65\uda86\udedf\uda82\udc9e\udbaa\udfba\u9d72\udac5\udc07\ud94f\udcaa\ud841\udcf3\udb1b\udc2b\u1a2d\ud98f\ude92\ud8ab\udefa\ud9f7\udfdf\udadc\ude5f\udb20\udfb2\udb88\udfce\ud824\udeff\udaf8\udfeb\ud9c8\uddf0\udb9c\uddd8\ua5ca\ud939\udca5\udae4\udcca\udb5a\udd37\ud8a2\udd9d\ud9d9\udc8d\uda33\udc5d\ud94e\udcfa\ud928\udc8f\udb62\udd51\ud86a\udc8c\udb2e\udc4b\ud9ff\udd9e\uda7f\udcda",
        -5, 50860, -603959446, -289773007048511974L, 52675L, true, true, (char) 6786, (char) 60495,
        Double.longBitsToDouble(0x3faf8dfc0fd873e0L), Double.longBitsToDouble(0x3fe974fdf5f9a6f9L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 7, 9, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb1\ud82c\udea4\udb57\udf29\udae9\udd67\udb4e\udfb5\ud87b\udc52\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda48\udded\uda00\udc8f\udb38\udf26\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\ud85d\udf01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u91c9\u2d02", "\ud9f2\uddfe\ud87d\udfaf",
        16, 73076, 2112654412, -690175481817435537L, 67405L, true, false, (char) 2447, (char) 26433,
        Double.longBitsToDouble(0x3fe374ae2c772ac2L), Double.longBitsToDouble(0x3fd737e7e09dc784L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 3, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\udae8\udeaa\ud855\udf4c\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073628774702186766L, -61200L, true, false, (char) 41080, (char) 2447,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 16, 5, "", "\u0e65", "\udb36\uddb5\ud82f\ude1d\udb57\udf29\udae9\udd67\ud9cf\uddc6\ud87a\udff3",
        57, 93160, 695607523, -2361322681679528957L, -100000L, false, false, (char) 30012, (char) 56104,
        Double.longBitsToDouble(0x3fcaf1917d500bf8L), Double.longBitsToDouble(0x3fe54e860cd88d3fL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 9, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\uda00\udfe0\ud96f\ude4e\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6ba4\uaec9\u2d02", "\ud9f2\uddfe\ud87d\udfaf",
        16, 73076, 2112654412, -2025774247663514986L, 67405L, true, false, (char) 2447, (char) 26433,
        Double.longBitsToDouble(0x3fe374ae2c772ac2L), Double.longBitsToDouble(0x3fd737e7e802b518L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-111, -11, 79, -114, 100, -82, -48, 73]]\012",
        Z.run(T, 1, 9, 1, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud9d7\uddf8\udb57\udf29", "\u493e\u65f6\u7922\uca06\u26b1\ua98b\ub8b5\ud0e8\u387d\u6972\u0594\ua463\u0f55\u2ea7", "\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\udbbd\udebd\ud915\udc79\uda11\udd38\udbad\udeff\udb20\udcff\ud800\ude4b\uda02\udfb2\ud941\udf6e\ud984\udd14",
        1, 8055, 770677868, -8621489420631252691L, 85813L, false, false, (char) 42266, (char) 48498,
        Double.longBitsToDouble(0x3fb32df80873ef60L), Double.longBitsToDouble(0x3fe4b71f1f9004e1L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 1, 3, 14, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\udb10\udfab\ud8dd\uddd5\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud88f\udc64\udbbb\udff7\uda57\udef2\udaf3\udd20\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\ud89a\udcfd\udad9\udf3c\udb2b\udca8\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\ud8bc\ude66\ud800\uddc3\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, -61200L, true, false, (char) 41080, (char) 2447,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 5, 8, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb77\uddd2\ud87a\udff3\udbb8\udd82\u402e\ud892\udc35\ud9da\udff8\uda85\udcbb\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud9ee\ude7b\u6f68\udb91\udc5d\ud8f7\udff4\udb41\udc54\ud90a\udfe4\ud96b\ude91\uda81\udced\udbcd\udfb5\ud855\udfd3\udaca\udfff\ud93e\udeae\uda02\udfb2\ud941\udf6e\ud8e6\udcce\uda78\udc3a", "\u6b3e\u52d4\u3ea1", "\ud9f2\uddfe\ud897\udcdb",
        40, 25247, 2112654412, -2025774247663514986L, 49767L, true, false, (char) 30419, (char) 26433,
        Double.longBitsToDouble(0x3fe374ae2c772ac2L), Double.longBitsToDouble(0x3fd737e7e689f10eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 15, 9, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde", "\u112a\u392a\u62c7\u0aa7\ua057\ud2a8", "\udbcc\ude44\uda23\udf0f\uda57\ude46\uda5f\udd58\udb33\udd6f\ud946\udd05\ud8c2\uddfc\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d",
        -4, 36937, -1172348678, 6307448196773496285L, 14664L, true, false, (char) 46855, (char) 50216,
        Double.longBitsToDouble(0x3fb0db02e1b84b40L), Double.longBitsToDouble(0x3fbb2c3908696f78L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 11, 12, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde", "\u10dc\u392a\u252f\ub004\u38f0\ud2a8\u65f6\u7922\u6cb1\u1a26\ua98b\ub8b5\ud0e8\u958b\u20f6\u046a\ua463\u88e2\u2ea7\u636a\u88fb\u9f74\u6852\u4a80\u2bca\u595f\uabec\ud7ab\u1756\ud120\u7769\u133c\uba08\u7bd7\u0687\u3674\u7add\u8422\uaec9\u2d02\u30ba\u17cc\ua5b0\uc266\u4f17\u34f9\ud18a\u0fbc\u385f\ubbee\u5a7c\u35dd\u5259\u94ac\u2586\u1abe\u8d74\u2ca4\u0f20\u720f\uc0f7\u3715\u8c04", "\udbfe\udd04\udae4\ude97\udbb9\udd4d\ud95c\ude60\udb9f\uded0\u69ed\ud81a\ude98\udab6\udea3\ud985\udf04\udb94\udee7\ud831\ude27\udb1a\udc38\ud8fa\udc58\ud912\ude96\u4aa1\uda1a\udf44\ud93a\ude0f\ud8ed\udd09\ud904\udc88\ud9f7\udd91\udb50\udff5\ud9e0\udc31\ud8d5\ude86\udb84\udc0e\ud98a\udd81\ud943\udf40\uda65\udf1d\ud8bb\udefe\ud9d6\udf49\uda71\udcaa\ud922\udc39\ud867\udcfb\udb4a\udf97\udb99\udf6c\ud88c\udf36\udad8\ude0e\udb18\udd1f\ud8d2\udd80\ud8a3\ude08\uda13\udf2b\u145d\udb67\ude15\udbb4\udd40\uda8a\ude15",
        41, 55596, -2071865405, -9076446539348138744L, 21521L, true, true, (char) 55891, (char) 53850,
        Double.longBitsToDouble(0x3feebe79a7596a30L), Double.longBitsToDouble(0x3fe5a26710431efcL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud912\udca0\udb59\udfd4\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud82d\udf5c\u6f6a\udb91\udc5d\ucab3\u5975\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud9a7\udd7b\udb13\udc03\ud800\ude50\ud9af\udf23\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u6fea\u9ec9", "\ud9f2\uddfe",
        22, 58301, -1210006924, 9073781606818464782L, -61200L, true, false, (char) 41080, (char) 2263,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\ud8a0\ude7e", "\u252f\u24c2\u8d7b\u3a31\u65f6\u183b\ud5c2", "\uda8d\udf99\udb33\udd6f",
        21, 37084, -1938925900, 7061293295460228987L, -42852L, true, true, (char) 61850, (char) 1804,
        Double.longBitsToDouble(0x3fd19e3ea0d031deL), Double.longBitsToDouble(0x3fd685df5bbaaf70L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-111, -11, 79, -114, 100, -82, -48, 73]]\0121=java.lang.Boolean:false |a0=[B:[[-111, -11, 79, -114, 100, -82, -48, 73]]\012",
        Z.run(T, 2, 9, 9, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\ud9c3\udcf6\ud817\udc36\ud8ae\udfed\udbd1\udddf\udab7\uddef\ud9ec\udf54\uda5c\udf99\udad7\ude46\uda8d\udf99\udae7\udd69\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud82d\udf5c\u6f6a\udb91\udc5d\ud8f7\udfa9\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\udb57\udcd9\ud984\udd14\ud9dc\uddf1", "\u6b3e\u6fea\u9ec9\u1dda\u7e1a\u4eac\u1611\u4fb6\u34f9\ud18a", "\uda82\udc9e\udbaa\udfba\u9d72\udac4\udf4f\ud94f\udcaa\ud841\udcf3\ud954\udfeb\ud916\ude63\ud8b3\udffc\ud916\udce0\udb9a\ude16\uda15\uddc5\ud8ea\udd19\ud9c8\udd26\ud8fb\udc6e\ud8f9\udf52\uf29c\u491a\ud808\udd1e\ud882\udcec\ud81f\udcd7\udb16\udcc1\ud8ae\ude58\ud80f\uddb5\ud818\udc9d\ue9b4\udb44\ude9e\ud83a\udc32\ud9d1\udfb6\udb63\udde1\ud844\ude3f\ud8de\udde8\udbeb\udf64\udbc1\udf56",
        3, 83164, -1939095925, -2676517206086026485L, 53485L, false, true, (char) 32569, (char) 30111,
        Double.longBitsToDouble(0x3fe85adf7cff86c5L), Double.longBitsToDouble(0x3fb61413ead0e1b8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 11, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud822\udd28\udb59\udf97\ue9dc\ud8b7\udc56\udaf9\udfe5\ud82d\udf5c\uda3c\udc79\udbb8\udf46\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\udbee\udfe3\uda11\udd38\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u6fea\u9ec9", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, -61200L, true, false, (char) 41080, (char) 2263,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 12, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb82\udf1c\ud81e\udc11\udb57\udf29\ud984\ude75\ud8ee\udca0\ud838\udd93\ud922\udf28\udb94\ude19\ud93a\ude54\ud9cd\udea0\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud93f\ude58\u6f6a\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud94f\udccb\ud9fd\uddbd\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\udbf7\udc8b\ud965\udf21\ud9dc\uddf1", "\u6b3e\u6fea", "\ud8b1\udc63\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, 93408L, true, false, (char) 26433, (char) 26675,
        Double.longBitsToDouble(0x3fee6b2e1ff48576L), Double.longBitsToDouble(0x3fe5bb332b97c5e8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 9, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\udb43\udf33\udb33\udca9\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud82d\udf5c\u6f6a\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u6fea\u9ec9", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, -61200L, true, false, (char) 41080, (char) 2263,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 12, 8, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\ud9b2\udfa9\ud879\udcb6\uda5e\udeaa\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud961\udd19\ud918\udc00\ud98b\udf8b\udb12\udcd8\uda78\udf21\udbf7\uddc8\udb97\uddf0\ud926\udc36\ud867\udc92\ud9f5\ude70\ud96f\ude93\ud915\udced\uda28\udf38\ud855\udfd3\ud9cf\ude89\ud95d\udea8\ud9af\udf23\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u6fea\u9ec9", "\ud9f2\uddfe",
        55, 48954, 1619305814, 9073781825861779726L, -61200L, true, false, (char) 41080, (char) 2263,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda8d\udf99\uda53\udd20\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud82d\udf5c\u6f6a\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud943\udfe2\uda11\udd38\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u6fea\u9ec9", "\ud9f2\uddfe\ud87d\udfaf\ud91b\udffc",
        38, 67298, -474335218, 351784989528987536L, 93505L, true, false, (char) 26433, (char) 26675,
        Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L), Double.longBitsToDouble(0x3fe02eaa38c2d7f5L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-111, -11]]\012",
        Z.run(T, 2, 6, 9, 11, "\ud8c1\ude25", "\u2022\ube82\u112a\u392a\u252f\u24c2\u8d7b\u3a31\u65f6\u7922\uca06\u26b1", "\udb33\udd6f\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud82d\udf5c\u6f6a",
        11, 77229, 418367769, 6770458800458062184L, 33233L, false, false, (char) 62743, (char) 50362,
        Double.longBitsToDouble(0x3fe03508ab2356cbL), Double.longBitsToDouble(0x3fe54246f4436cffL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 15, 11, "\ud8c1\ude25\udb4e\udcbe\ud894\udcde\uda38\udf75\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udace\udfdb\ud9e0\udc15\uda5b\udcf4\ud922\ude6e", "\u2003\ua98b\u626e\ud01e\ua3c9\u8d98\u453c\ua463\u39f2\uca1c\u3c82", "\ud8f7\udff4\ud8a4\ude91",
        25, 17048, 2142192605, -397013140566670072L, 14682L, false, false, (char) 45432, (char) 60120,
        Double.longBitsToDouble(0x3fb0db3fe1bb0340L), Double.longBitsToDouble(0x3fbb2c3923696f78L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 16, 6, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\ud8c2\udf73\udb36\udd04\ud82f\udefe\udb57\udf29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud81f\udde6\udabc\udd8e\ud9ec\udf54", "\u9af7\ub133\u5843\u6972\u453c\ua463\u0f55\u2ea7\ud059\u8955\u9f74\u6852\u16a7\u4fc4\ua55f\uabec", "\ud8d0\udf42\ud841\udd9f\udacf\udf5f\udad3\udf10",
        -2, 85067, -1327231771, 3310036236803699725L, -14173L, true, false, (char) 43239, (char) 56668,
        Double.longBitsToDouble(0x3fa87e8682bf7750L), Double.longBitsToDouble(0x3fe3a7d7f44cb7e0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\ud863\udc4d\ud98a\udef9\ud924\udfa6", "\u7922\uca06\u26b1\ua98b\u9af7\ud0e8\u387d\u6972\u453c", "\udaf9\udfe5\ud82d\udf5c\u6f6a\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud8f2\uddae\udb13\udc46\ud800\ude50\ud9af\udf23",
        12, 86648, 1617491011, -5700417797210792852L, -63437L, true, true, (char) 25962, (char) 43840,
        Double.longBitsToDouble(0x3fe15b088030fd0dL), Double.longBitsToDouble(0x3fda5f7754e9f5fcL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 16, 9, "\ud8c1\uddfd\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud809\uddfe\ud957\ude29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud8e2\udf4f\uda5c\udf99\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud8c7\udcdb\udb5a\udc22\ud88c\udd04\udb29\udd23\udaf9\udfe5\ud82d\udf5c\ud823\udd6c\uda74\udd68\ud867\udf32\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\ud8f7\udf69\ud984\udd14\ud9dc\uddf1\ud9ef\udf8d", "\u6fea\u9ec9\u45ea\u7e1a\u4eac\ucc10\u4fb6", "\udb6f\udf65\udaee\udd93\uda82\udc9e\udba4\udcba\u9d72\ud8de\udc9b\udbfb\udef5\udb6f\ude6d\uda0a\udcde\ud839\udefe\uda69\udc6c\udb8e\udedb\udae4\udf4f\uda7a\udc55\uda8a\ude1d\ud827\uded5\ud940\udd0f\ud87e\uddb4\ud918\ude8c\ud8ea\udc5d\udbe4\uddd5\uda23\udc7f\udac9\udfce\ud88e\udcaf\ud9b5\udee5\udb01\udd58\ud92b\udfac\udb1e\udcb7\ud848\udc49\uda3a\udcd0\udb73\ude15\udb8b\udf1d\udbcb\udee6\ud8c8\udd42",
        42, 40578, 649931875, 4746206890995386907L, -47939L, false, true, (char) 37263, (char) 26494,
        Double.longBitsToDouble(0x3f9689f188409f00L), Double.longBitsToDouble(0x3fe5be15b8e406c7L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 9, 11, "\000", "\u2022z\u112a", "\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99",
        13, 57121, 1005095400, 5948717055740879676L, -18295L, false, true, (char) 55146, (char) 41320,
        Double.longBitsToDouble(0x3fc226c975dbb1c8L), Double.longBitsToDouble(0x3fd9ced6f233c7d4L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 9, 9, 11, "\udb46\uddc8\udbfa\udca4\ud894\udcde\uda00\udf79\udbd3\udd37\uda09\udc3e\ud82f\udeac\udb57\udf29\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\ud8c0\udc8b\udaf9\udfe5\ud82d\udf5c\u6f6a\uda9b\udc61\udbc7\uded2\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u6fea\u9ec9", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447690L, -61200L, true, false, (char) 8876, (char) 2271,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 10, 11, "\ud8c1\ude25\uda7f\udfbe\ud9fd\udd95\u1161\uda96\uded6\udac5\udc3c\ud9e7\udf46\udb57\udf29\ud827\udfa5\ud992\ude77\ud87b\udc7f\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb4b\udf6f\ud839\udc54\uda1f\udc29\ud8a3\udfe4\ud88c\udd04\ud95d\ude81\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\ued97\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud83a\udfc1", "\u6b3e\uaec9", "\ud8a6\udd63\ud9f2\uddfe\uda55\udd9f\u5909\ud9c9\udc18\ud8e0\udd8a\uda19\udcbf\ud91d\udd00\udb05\udecb\ud941\udc65\udac6\udc7b\uda57\udd3d\udb4f\uddaa\udbe7\udc59\ud954\udfeb\udb07\ude7c\udaf9\udc61\ud9b8\udeea",
        11, 54179, -1910515929, -681549246809184922L, -91092L, false, true, (char) 48397, (char) 58036,
        Double.longBitsToDouble(0x3fc8689af3890588L), Double.longBitsToDouble(0x3fec67cecf6b3e4bL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 10, 11, "\ud8c1\ude25\uda7f\udfbe\ud9fd\udd95\u1161\uda96\uded6\udac5\udc3c\ud9e7\udf46\udb57\udf29\ud827\udfa5\ud992\ude77\ud87b\udc7f\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb4b\udf6f\ud839\udc54\uda1f\udc29\ud8a3\udfe4\ud88c\udd04\ud95d\ude81\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\ued97\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        24, 5653, -1836596596, -6179239300856065954L, -63973L, false, false, (char) 33261, (char) 31240,
        Double.longBitsToDouble(0x3fe768a20a6e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 3, 0, "\ud8c1\ude25\udb5e\udc7a\uda07\ude95\u1161\uda96\uded6\udac5\udc3c\ud9e7\udf46\udb57\udf29\ud827\udfa5\ud966\ude7b\ud87b\udc7f\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb4b\udf6f\ud839\udc54\uda1f\udc29\ud8a3\udfe4\uda34\udcf8\ud95d\ude81\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\uda5f\ude8b\ud915\udced\uda11\udd38\ud89d\udc77\ued67\ud800\ude50\ud929\udfde\ud941\udf6e\ud984\udd14\uda77\uddff", "\u6a6f\u5c35\ua9dd\u893d\u30c5\ua557\u073d\u541d\u68cd\u10f5\u087a\u8f6a\u4645\ua07f\u441d\u340e\u9505\u6b1b\u1a63\u6130\ucf36\u7816\ub169\u5c69\u66fe\u9abf\u4add\u6c8c\ub24a\u5c6b\u0247\u40bf\uac63\uc2be\u46e9\u76f4\u1794\u7959\u23fd\u0f0b\u7eae\u138b\uc97d\u4b1f\u3cce\u6214\ua14e\u0807\u78f0", "\udbf0\udeac\udb76\udc80\ud88e\udc74\ud872\udf70\u6bf0\ud976\udeb9\uda97\udcb8\ud919\udd11\ud9d1\ude0c\ud82b\udfd3\ud9bd\udf55\ud927\ude18\ud8bb\udd9c",
        7, 75927, 1798861098, 5828129905571232324L, 92131L, false, true, (char) 64720, (char) 34589,
        Double.longBitsToDouble(0x3fc786e64891c528L), Double.longBitsToDouble(0x3fda7961d58fb304L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 6, 11, 0, "\ud8c1\ude25", "\u57b3\u6367\ua6c5", "\ud827\udfa5\ud992\ude77\ud87b\udc7f\ud922\udf28",
        0, 19523, -549788280, 2768372378509457648L, 96608L, false, true, (char) 33904, (char) 19810,
        Double.longBitsToDouble(0x3ecfc00000000000L), Double.longBitsToDouble(0x3fcb11a000a1ab98L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 7, "\ud8c1\ude25\udbe0\udfcb\uda06\udff4\u1161\uda96\uded6\udb39\uded5\ud9e7\udf8b\udb57\udf29\uda8f\udf59\ue0b2\ud9d0\udea6\udaf7\uddf1\udaac\udf59\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb4b\udf6f\ud839\udc54\uda1f\udc29\ud8a3\udfe4\ud88c\udd04\ud95d\ude81\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\ued97\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        24, 5653, -1836596596, -6179239300856065954L, -63973L, false, false, (char) 63469, (char) 31240,
        Double.longBitsToDouble(0x3fe768a20a6e95c5L), Double.longBitsToDouble(0x3fbdcab09f449898L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:1 |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=java.lang.Integer:1 |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 3, 3, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbde\udd37\udb36\uddb5\uda77\udca2\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\uda6c\udf2d\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda56\ude46\udabd\udd67\udb33\udd6f\ud9c2\udf82\udb6f\uddef\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfc7\udae0\udf24\u6f01\ud92f\udfad\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda55\udfaf\ud9b3\udcc7\udb64\udfe2\ud84c\udd6b", "\u6b3e\uaec9\u2d02\u1dda\u531a\u4eac\u1611\u4fb6", "\udb6f\udf65\uda7f\ude3a\uda82\udc9e\udbaa\udfba\u9d72\udac5\udc07\ud94f\udcaa\ud841\udcf3\ud954\udfeb\ud924\udc6a\ud87e\udfa9\ud9e8\udf5b\udbcf\udde1\uda61\udf99\ud951\uddb4\udbe8\udcf3\ud80b\uddcf\udac2\udc7d\ud958\udf0d\udb55\uddf2\udbe0\udf90\uda20\udfce\udbb4\udcd6\udb18\uddb7\ud826\udf19\uda35\udc2e\ud919\udc6a\udbdc\udda9\udbfe\udc80\ud94f\udc32\udac0\udd4b\udbe0\udeea\uda1e\udf24\ud832\udffb",
        18, 25958, 1919796806, 9155732726034205601L, -71246L, true, true, (char) 46241, (char) 43292,
        Double.longBitsToDouble(0x3fe71f5fab3597f6L), Double.longBitsToDouble(0x3fe6ee5d5da548fbL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 17, 14, "\ud90b\ude6b\uda7f\udfbe\ud894\udcde\ud8ad\ude50\uda64\udcdf\ud988\uddbe\udacf\udefd\udb57\udf29\ud9ce\udd75\ud986\udc30\ud868\udfb3\ud922\udf28\ud9fb\uddd5\ud881\udd61\ud8e9\udfea\uda2b\udc60\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\uda2e\uddb5\ud8b7\udc8b\udb1d\udf3c\udae0\udf24\u6f01\udb47\udca8\ud8f8\udc1f\ud912\uddc9\udbe6\ude36\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\ud9f9\udfde\udb5c\udf73\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1\ud9ef\udf8d", "\uaec9\u968c\ua126\u9115\uc9ae\u165c\u4fb6", "\udb6f\udf65\uda86\udedf\uda82\udc9e\udbaa\udfba\u9d72\udac5\udc07\ud94f\udcaa\ud841\udcf3\udb1b\udc2b\u1a2d\ud98f\ude92\ud8ab\udefa\ud9f7\udfdf\udadc\ude5f\udb20\udfb2\udb5e\ude0f\ud824\udeff\udaf8\udfeb\ud9c8\uddf0\udb9c\uddd8\ua5ca\ud939\udca5\udae4\udcca\udb5a\udd37\ud8a2\udd9d\ud9d9\udc8d\uda33\udc5d\ud94e\udcfa\ud928\udc8f\udb62\udd51\ud86a\udc8c\udb2e\udc4b\ud9ff\udd9e\uda7f\udcda",
        42, -1000, 0, 0L, 52675L, true, true, (char) 6786, (char) 60495,
        Double.longBitsToDouble(0x3faf8dfc0fd873e0L), Double.longBitsToDouble(0x3fe974fdf5f9a6f9L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 7, 9, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb1\ud82c\udea4\udb57\udf29\udae9\udd67\udb4e\udfb5\ud87b\udc52\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda48\udded\uda00\udc8f\udb38\udf26\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\ud85d\udf01\udb91\udc5d\ud8f7\udff4\ud850\udd27\000\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\u91c9\u2d02", "\ud9f2\uddfe\ud87d\udfaf",
        30, -1000, 2112618496, -690175481817435537L, 67405L, false, false, (char) 31445, (char) 26433,
        Double.longBitsToDouble(0x3fe374ae2c772ac2L), Double.longBitsToDouble(0x3fd737e7e09dc784L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 12, 3, 12, "\000", "\u085a", "\ud82f\ude1d\udb57\udf29\udae9\uddb9\ud9cf\uddc6\ud87a\udff3",
        0, 47904, 695660659, -2361322681679528957L, -100000L, true, true, (char) 27432, (char) 54885,
        Double.longBitsToDouble(0x3fcaf19164fb94bcL), Double.longBitsToDouble(0x3feb9b91c4d88dd9L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 5, 8, "\udbe2\udf60\udbf2\udee7", "\uc849\u59ee\u5819\u1a74\u3135\u0889\uc7a5\u5316\u0cc7\uca07\u58e8\u3cbe\ub8b5\u2817\u387d\u4d4d\u0bdc\ub1c9\u0f55\ub5c3\u9eb9\u8962\u9f74\u6852\u1293\u2afc\u1937\u4741\u4636\uca47\u0434\u274c\uad9b\u8180\ub654\u01df\uca24\u4ff8\u6b3e\u52d4\u3ea1\u786b\u5242\u24ad\u1e15\uaa61\u7b10\ud18a", "\ud898\ude88\udbbc\udca0\ud8c4\udfeb\ud9c2\udf76\udb80\udd21\ud841\udd3f\ud954\udfeb\ud915\udd02\ud947\udf96\ud928\udd5c\udae1\udf09\ud95d\uded3\ud817\udf6e\uda0a\udfa1\u1fea\ud884\udec7\udabf\uded3\uda11\udd30\ud890\udd19\ud80d\udcd7\ud99f\udd7e\ud82c\udff6\udaaf\udcc0\ua9e0\ua189\udacf\udc3b\ud8bc\ude58\udabf\udc59\uda6b\udc59\ud90f\udc33\ue183\udab8\udee2\ud956\udd2c\ud975\udeb6",
        20, 45767, -1495678953, 7465414846135121632L, -31264L, true, true, (char) 8227, (char) 35130,
        Double.longBitsToDouble(0x3fc4de99dc4249b4L), Double.longBitsToDouble(0x3fb9a722ce041420L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 15, 15, 9, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde", "\u112a\u392a\u62c7\u0aa7\ua057\ud2a8", "\udbcc\ude44\uda23\udf0f\uda57\ude46\uda5f\udd58\udb33\udd6f\ud946\udd05\ud8c2\uddfc\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d",
        -4, 36937, -1172348678, 6307448196773496285L, 14664L, true, false, (char) 46855, (char) 50216,
        Double.longBitsToDouble(0x3fb0db02e1b84b40L), Double.longBitsToDouble(0x3fbb2c3908696f78L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 10, 9, "\ud8a6\udf78\uda93\ude37\ud894\udcde", "\u3d0b\u392a\u62c7\u0aa7\ua057\ud2a8", "\u5a4a\uda23\udf0f\uda57\ude46\uda5f\udd58\udb33\udd6f\ud946\udd05\ud8c2\uddfc\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d",
        -4, 36937, -1172348678, 6307448196773496285L, 14664L, true, false, (char) 46855, (char) 50216,
        Double.longBitsToDouble(0x3fb0db02e1b84b40L), Double.longBitsToDouble(0x3fbb2c3908696f78L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 12, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\ud8a0\ude7e", "\ud171\u3a9d\uaae1\uae8a\u27f5\u1818\ud5c2\u59bd\uba33\u9ae0\ud0e8\u387d\u6972\uabba", "\udb24\udd50\udb75\udcd9\ud991\udc5b\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1",
        0, 4473, 1506473542, 5908960680730784999L, 53213L, false, false, (char) 12145, (char) 19408,
        Double.longBitsToDouble(0x3fe9318054c1b997L), Double.longBitsToDouble(0x3fe2fdd62552d5feL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-111, -11, 79, -114, 100, -82, -48, 73]]\0121=java.lang.Boolean:false |a0=[B:[[-111, -11, 79, -114, 100, -82, -48, 73]]\012",
        Z.run(T, 2, 9, 9, 5, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\ud9c3\udcf6\ud817\udc36\ud8ae\udfed\udbd1\udddf\udab7\uddef\ud9ec\udf54\uda5c\udf99\udad7\ude46\uda8d\udf99\udae7\udd69\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\ud82d\udf5c\u6f6a\udb91\udc5d\ud8f7\udfa9\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udb13\udc03\ud800\ude50\ud9af\udf23\udb57\udcd9\ud984\udd14\ud9dc\uddf1\ud85b\udc5d\uda5b\udeff\udbb8\uddff", "\u1dda", "\ud87d\udfaf\ud9d5\udd59\udbaf\ude33\udafc\udfb7\udb6f\udf65\uda86\udedf\uda82\udc9e\udbaa\udfba\u9d72\udac4\udf4f\ud94f\udcaa\ud841\udcf3\ud954\udfeb\ud916\ude63\ud930\ude3b\ud8ea\udcae\udb9a\ude16\uda15\uddc5",
        17, 45163, 955582739, -9145193679417254309L, -81632L, true, true, (char) 52074, (char) 7733,
        Double.longBitsToDouble(0x3fe251ee452b2771L), Double.longBitsToDouble(0x3fdc0c535e48a54aL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 14, 6, "\ud8c1\udde4", "\u2022\u519c\u1079\u392a\u252f\u9627\u8d50\u3a31\uc517\ub70a\uca06\u2629", "\ufab6\ud9ca\udf48\ud822\udd28\udb59\udf97\000\000\000\ud87e\udefe\u6f5b",
        50, -844, 0, 6770458353781482856L, 33233L, false, true, (char) 494, (char) 45366,
        Double.longBitsToDouble(0x3fb692b196499a48L), Double.longBitsToDouble(0x3fe542450c436cffL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 10, 11, "\ud8c1\ude25\uda7f\udfbe\ud9fd\udd95\u1161\uda96\uded6\udac5\udc3c\000\000\ud819\udf4b\ud992\ude77\ud87b\udc7f\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\u3c03\uda5f\udd58\udb4b\udf6f\ud839\udc54\uda1f\udc29\ud8a3\udfe4\ud88c\udd04\ud95d\ude81\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\ued97\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        24, -1000, -1836596596, -6179239300856065954L, -63973L, false, false, (char) 33261, (char) 31240,
        Double.longBitsToDouble(0x3fe768a20a6e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 12, 11, "\ud8c1\ude25\uda7f\udfbe\ud8e0\udc91\udabc\ude96\ud8a0\udf00", "\ud171\u3a9d\uaae1\uae8a\u27f5\u1818\ud5c2\u59bd\uba33\u9ae0\ud0e8\u387d\u6972\uabba", "\udb24\udd50\udb75\udcd9\ud991\udc5b\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1",
        0, 81713, 1506473689, 5908960680730784999L, 221L, true, false, (char) 12145, (char) 19408,
        Double.longBitsToDouble(0x3fe9318054c1b997L), Double.longBitsToDouble(0x3fe2fdd62552d5feL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 1, 6, 9, 11, "\ud8c1\ude25\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud82f\udefe\udb57\udf29\udae9\udd67\udb93\uddf6\ud87a\udff3\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda5f\udd58\udb33\udd6f\ud9c2\udf82\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\udaf9\udfe5\udae0\udf24\u6f01\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud90a\udfe4\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u6b3e\uaec9\u2d02", "\ud9f2\uddfe",
        4, 58301, -1210006924, 9073781606818447630L, -61200L, true, true, (char) 65028, (char) 2447,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[48, -8, -67, 100, -82, -35, -3, -92]]\012",
        Z.run(T, 2, 6, 9, 11, "\ud060\ud928\udeed\ud894\udcde\udb0d\udc2d\udbd4\udf9c\udb36\uddb5\ud82f\udefe\udb57\udf29\ud984\ude75\ud808\udc36\ud849\udc7b\ud9d9\udc57\udaac\udfa6", "\ua98b\u9af7\u44bc\u2c8e\u6972", "\u421a",
        58, 71025, -328030063, -1337844560412665444L, -66104L, false, true, (char) 7573, (char) 65100,
        Double.longBitsToDouble(0x3fc60e384eefc570L), Double.longBitsToDouble(0x3fef40269a06a115L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-17, 113, 79, -114, 100, -82, -48, 73]]\012",
        Z.run(T, 2, 6, 9, 11, "\ud81f\udda1\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\udb36\uddb5\ud994\uddf0\udb42\udea3\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\udae2\ude1a\udaf1\udfd5\ud99f\udf70\u6fd5\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udad7\udc89\udb8e\udce0\ud975\ude96\ud868\ude56\udbbf\udd1b\ud9dc\uddc8", "\u6391\u6fea\u9ec9", "\ud9f2\uddfe",
        11, 76515, -1224530457, 9073781605737706779L, 39614L, false, false, (char) 41080, (char) 2263,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[113, 24, 79, -114, 100, -82, -48, 73]]\012",
        Z.run(T, 1, 9, 4, 9, "\ud8a1\udc48\uda7f\udfbe\ud894\udcde\uda00\udf79\udbd3\udd37\ud80e\udfbe\ud82c\udea4\udb57\udf29\udae9\udd67\udb4e\udfb5\ud884\udef7\ud922\udf2b\udaac\udfa6\ud9ec\udf54\uda5c\udf99\uda57\ude46\uda48\udded\uda00\udc8f\udb38\udf26\ud822\udd28\ud8a3\udf9c\ud88c\udd04\ud8b7\udc8b\ud8b5\udc20\udb06\ude7f\uda3f\udda4\udb91\udcb8\ud8f7\udff4\ud850\udd27\000\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udaca\udfff\ud800\ude50\uda02\udfb2\ud941\udf6e\ud984\udd14\ud9dc\uddf1", "\u2d9e\u4cd2\u7093", "\ud8cd\uddc5\ud87e\udc10",
        30, 18510, 2112618496, -690175481817435537L, 72269L, true, true, (char) 31445, (char) 26433,
        Double.longBitsToDouble(0x3fe374ae2c772ac2L), Double.longBitsToDouble(0x3fd737e7e09dc784L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[48, -8, -67, 100, -82, -35, -3, -92]]\0121=java.lang.Boolean:false |a0=[B:[[48, -8, -67, 100, -82, -35, -3, -92]]\012",
        Z.run(T, 2, 9, 9, 15, "\ud060\ud928\udeed\ud894\udcde\udb0d\udc2d\udbd4\udf9c\ud989\udeff\ud82f\udefe\udb57\udf29\ud984\ude8f\ud808\udc36\ud849\udc7b", "\u2664\u92d0\uadf9\u9af7\u44bc\u2c8e\u6972\u453c\u074b\u2130\u2ea7\u3c82\u8964\u9f74\u6852\u16a7\u78f1\uc59a\ud10d\u2d45\u1756\ua172\u7769\uba96\u92ff\u5e35\u15b0\u3cd6", "\ud88b\udd3f\ud852\udd10",
        55, 59929, 1422525075, -7661787876129081371L, -67670L, true, false, (char) 58462, (char) 61357,
        Double.longBitsToDouble(0x3fd47bedf17fd834L), Double.longBitsToDouble(0x3fcfc4801a71db28L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-17, 113, 79, -114, 61, 26, -47, -71]]\0121=java.lang.Boolean:false |a0=[B:[[-17, 113, 79, -114, 61, 26, -47, -71]]\012",
        Z.run(T, 2, 9, 9, 11, "\ud81f\udda1\uda7f\udfbe\ud86d\ude4a\udb01\udde9\udbd3\udd37\udb36\uddb5\ud994\uddf0\udb42\udea3\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\ud91e\udc19\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\udae2\ude1a\udaf1\udfd5\ud99f\udf70\u6fd5\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udad7\udc89\udb8e\udce0\ud975\ude96\ud868\ude56\udbbf\udd1b\ud9dc\uddc8", "\u6391\u6fea\u9ec9", "\ud9f2\uddfe",
        11, 76515, -1224530457, 9073781605737706779L, 39614L, false, false, (char) 41080, (char) 2263,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[113, 82, 106, 26, 61, 26, -47, -71]]\0121=java.lang.Boolean:false |a0=[B:[[113, 82, 106, 26, 61, 26, -47, -71]]\012",
        Z.run(T, 2, 9, 9, 11, "\udba1\udd82\uda9a\udd4a\ud86d\ude4a\udb01\udde9\udbd3\udd37\udb36\uddb5\ud994\uddf0\udb42\udea3\ud984\ude75\ud808\udc36\ud8ae\udfed\ud922\udf28\udaac\udfa6\ud9ec\udf54\ud91e\udc19\uda57\ude46\uda8d\udf99\udb33\udd6f\ud9c2\udf82\ud822\udd28\udb59\udf97\ud88c\udd04\udae2\ude1a\udaf1\udfd5\ud99f\udf70\u6fd5\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud96f\ude93\ud915\udced\uda11\udd38\ud855\udfd3\udad7\udc89\udb8e\udce0\ud975\ude96\ud868\ude56\udbbf\udd1b\ud9dc\uddc8", "\u6391\u6fea\u9ec9", "\ud9f2\uddfe",
        11, 76515, -1224530457, 9073781605737706779L, -8417L, false, false, (char) 41080, (char) 2263,
        Double.longBitsToDouble(0x3fe768a2a26e95c5L), Double.longBitsToDouble(0x3fbdcab0ab9bf3f0L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-57, 113, 107, -43, 100, -17, 90, 31]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 17, 6, "\ud9f7\udfa1\ud99b\ude05\ud894\udd1f\ub58a\uda4f\uddf2\ud8d9\ude43\ud82f\udefa\udb57\udf29\ud984\ude75\ud808\udc36\ud96b\udc0b\udb26\ude49\udb52\udd42\ud83a\udcf6\udb4f\udc59\ud9be\ude04\uda84\udd03\udb33\udd15\udbf9\ude7b\ud822\udd28\ud81b\udcbe\udb14\udec8\udaf3\udc54\udafa\udc09\ud82d\udf5c\ud913\ude66\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud984\uddfc\ud915\udced\ud8a8\udcf7\ud855\udfae\udb13\udc03\ud800\ude50\ud9af\udf23\ud941\udf6e\ud9c8\udd97\ud952\ude56", "\uccce\u6fea\u9ec9\u1dda\u0807\u4eac\u1611", "\udafc\udfb7\ud9d7\udf59\uda86\udedf\uda82\udc9e\udbaa\udfba\u9d72\udac4\udf4f\ud94f\udcaa",
        23, 2906, 369543331, 5927666328705642042L, -47589L, false, true, (char) 17417, (char) 64671,
        Double.longBitsToDouble(0x3fe96bbe39ed9733L), Double.longBitsToDouble(0x3fef9c9a6720e15eL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[-57, 113, 107, -43, 100, -17, 90, 31]]\0121=java.lang.Boolean:true |a0=[B:[[-57, 113, 107, -43, 100, -17, 90, 31]]\012",
        Z.run(T, 2, 9, 9, 13, "\ud9f7\udfa1\ud99b\ude05\ud894\udd1f\ub58a\uda4f\uddf2\ud8d9\ude43\ud82f\udefa\udb57\udf29\u0d95\ud808\udc36\ud96b\udc0b\udb26\ude49\uc4fc\ud8ab\udda6\udbf5\udcfc", "\uba09\ud2fa\u6972", "\udaf3\udc54\ud9c3\udfce\ud82d\udf5c\ud913\ude66\udb91\udc5d\ud8f7\udff4\ud8a4\ude91\ud9f5\uddf1\ud963\udf02\ud915\udced\ud8e2\udfb4\uda07\udf9b\udb13\udc03",
        29, 78102, 1217438499, -1301642923236789075L, 69878L, true, true, (char) 1910, (char) 4717,
        Double.longBitsToDouble(0x3fca2a1330d61000L), Double.longBitsToDouble(0x3fe15aa1c7f4c40dL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readNewEntry|boolean|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readOldAsciiEntry||new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readOldBinaryEntry|boolean|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|available||new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|close||new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|closeEntry||new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|ensureOpen||new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|getNextCPIOEntry||new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|matches|[B,int|static",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readAsciiLong|int,int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readBinaryLong|int,boolean|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readCString|int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readFully|[B,int,int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|skip|int|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readNewEntry|boolean|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readOldAsciiEntry||new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|readOldBinaryEntry|boolean|new:org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
