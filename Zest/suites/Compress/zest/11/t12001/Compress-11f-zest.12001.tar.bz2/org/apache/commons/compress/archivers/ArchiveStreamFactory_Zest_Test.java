package org.apache.commons.compress.archivers;
import org.junit.Test;
import static org.junit.Assert.*;
public class ArchiveStreamFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 4, 3, "\uda42\udf4b\ud848\udca9\udb55\udca0\udb48\ude58\udbff\udff2\ud9b5\ude7f\ud8f9\udd85\ud9cc\udcbb\ud9a4\ude2b\uda48\uddf3\ud936\udc91\u7df4\ud8d4\udd1c\udb33\udc8a\udbbb\ude1b\ud8f1\udc73\ud9ec\udfa1\ud8c7\udfd2", "\u098d\ua6d1\ucbaf\u180b\u74ea\ube14", "\uda0b\udffd",
        9, 11250, 1869026647, 755196685867847154L, 31178L, true, false, (char) 62142, (char) 2477,
        Double.longBitsToDouble(0x3fe78051e4ac283bL), Double.longBitsToDouble(0x3fd24139a0674cb0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 4, 3, "\uda42\udf26\ud848\udca9\udb55\udca0\udb48\ude58\udbff\udff2\udbdd\udf79\udb44\udd4a\ud807\udfc6\u05aa\ud999\ude29\udad2\udf20\u7df4\ud8d4\udd1c\udb33\udc8a\udbbb\ude1b\ud8f1\udc73\ud9ec\udfa1\ud8c7\udfd2", "\u098d\u671c\u3433\ubc46\u7a3c\u077d", "\uda0b\udffd",
        9, 11250, 1869026647, -2250111640471796866L, 31178L, true, false, (char) 62142, (char) 2477,
        Double.longBitsToDouble(0x3fe78051e4ac283bL), Double.longBitsToDouble(0x3fd24139a0674cb0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 4, 3, "\uda42\udf4b\ud848\udca9\udb55\udca0\udb48\ude58\udbff\udff2\ud9b5\ude7f\ud8f9\udd85\ud9cc\udcbb\ud9a4\ude2b\uda48\uddf3\ud936\udc91\u7df4\ud8d4\udd1c\udb33\udc8a\udbbb\ude1b\ud8f1\udc73\ud9ec\udfa1\ud8c7\udfd2", "\u99aa\u579b", "\ud964\udc3a\ud9bc\udf1b\udad3\udc15\udbe7\udecd\uda0b\udffd\udba8\udc3a\udb43\udebd\udaa8\udfe7\ud83e\udc00\udaf6\udd24\ud8d2\udead\uda55\udda9\ua342\ud8a9\udda9\ud91d\udf56\udae8\udf53\ud983\udf4d\udbfd\udd4e\udad7\uddd3\ud87e\udf8c\udbb9\udfa3\ud9fc\udc0e\u6ec4\ud9a5\udff7\ud8aa\udee7",
        -5, 67196, -2020055569, 5684515108960514612L, -31306L, false, false, (char) 52078, (char) 52622,
        Double.longBitsToDouble(0x3fbe857d5613c568L), Double.longBitsToDouble(0x3fcaee0a31fa8400L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 4, 3, "\uda42\udf4b\ud848\udca9\udb55\udca0\udb48\ude58\udbff\udff2\ud9b5\ude7f\ud8f9\udd85\ud9cc\udcbb\ud9a4\ude2b\uda48\uddf3\ud936\udc91\u7df4\ud8d4\udd1c\udb33\udc8a\udbbb\ude1b\ud8f1\udc73\ud9ec\udfa1\ud8c7\udfd2", "\u098d\ua6d1\ucbaf\u180b\u74ea\ube14", "\uda0b\udffd",
        9, 11250, 1869026647, 755196685867847154L, 31178L, true, false, (char) 62142, (char) 2477,
        Double.longBitsToDouble(0x3fe78051e4ac283bL), Double.longBitsToDouble(0x3fd24139a0674cb0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 3, 3, "\uda24\udc00\ud848\udca9\udb55\udca0\udb48\ude58\udbff\udff2\ud9b5\ude7f\u1b55\ud82f\ude0e\uc68f\udaf2\udf62\u0ee2\ud842\ude1f\ud8d3\udf82\udbcb\udd37\ud900\udd85\udacd\udc13\ud902\udd1b\udad1\udd92\ub484\ud820\udf9e\ud9cc\udc1f\udbc7\ude8c\u8de0\udb7d\ude3f\udaf1\udf29\udbf5\udc46\udad3\udc15\udbe7\udecd\uda0b\udffd\udba8\udc3a\uda00\udcdb\udaa9\udc06\ud8d7\udfb8\udb63\udf66\uca84\udbd3\udcf6\ua355\ud8a9\udda9\ud91d\udf56\udae8\udf53\ud959\ude98\ua0d1\udadb\udf93\udbad\udd54\udbad\udd17\udba6\udc98\ud978\udd94\ud89e\udc04\ud894\ude13\ud8bb\udf37\udafe\ude5a", "\u3bb7\ubbb8\u39bc\u1bc5\ud134\u6c34\u2d8b\ua7b6", "\ud981\udd22\ud94f\udec4\uda2e\ude06\uda68\udc09\uda28\udf8d\ud926\udcec\uda10\ude7b",
        29, 30907, -1354403002, 1019877976866181963L, 42369L, true, false, (char) 12684, (char) 53353,
        Double.longBitsToDouble(0x3fea5fca0af5713eL), Double.longBitsToDouble(0x3fe5902c86f569f2L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\012",
        Z.run(T, 1, 3, 2, 3, "\uda42\udf4b\ud848\udca9\udb55\udca0\udb48\ude37\udbff\udff2\ud9b5\ude7f\ud8f9\udd85\ud9cc\udcbb\ud9a4\ude2b\uda48\uddf3\ud94f\ude5f\u7793\ud8d4\udd1c\udb33\udc8a\udbbb\ude92\ud8f1\udc73\ud9ec\udfa1\ud9f4\udc07", "\ubd00\u8d65\ua594\u23f9\ud283\ua304", "\uda2e\uddfd",
        9, 11250, 1869026647, 755196685867860465L, 31178L, true, false, (char) 62142, (char) 58620,
        Double.longBitsToDouble(0x3fc04a5192b0a200L), Double.longBitsToDouble(0x3fd6b91800674cb0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\012",
        Z.run(T, 2, 3, 3, 1, "\udbde\udc07\ud857\udc4a\udb55\udca0\ud97f\uded3\udbff\udff2\ud9b5\ude7f\ud8f9\udd85\ud9cc\udcbb\ud9a4\ude2b\uda48\uddf3\ud936\udc91\u7df4\ud8d4\udd1c\udb33\udc8a\ud98a\udfe2\ud9dd\uddf5\ud9ed\udc4d\ud8c7\udfd2", "\u53d4\uc17b\ubdd1\u180b\u7569\ube14\ucef7\uaed9", "\ud96e\udff8\udaa9\udc62\ud83e\udc00\udaa7\udcd2\ud934\uddb8\uda55\udda9\ua342\ud8a8\udf4a",
        35, 1355, 171718323, 2899186694171008172L, -59814L, false, false, (char) 56221, (char) 34181,
        Double.longBitsToDouble(0x3fea3b2650ae3f02L), Double.longBitsToDouble(0x3fe30b4558d40003L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 3, "\uda42\udf4b\ud848\udca9\udb55\udca0\udb48\ude58\udb23\uddc4\ud9ee\udf4e\ud8f9\udd71\ud9cc\udcbb\ud9a4\ude2b\uda48\uddf3\ud936\udc91\u7df4\ud8d4\udd1c\udb33\udc8a\udbbb\ude1b\ud8f1\udc73\ud9ec\udfa1\ud8c7\udfd2", "\u098d\ua6d1\ucbaf\u180b\u74ea\ube14", "\uda0b\udffd",
        9, 11250, 1869026647, 755196685867847154L, 31178L, true, false, (char) 62142, (char) 2477,
        Double.longBitsToDouble(0x3fe78051e4ac283bL), Double.longBitsToDouble(0x3fd2413f60674cb0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 4, "\uda42\udf4b\ud848\udca9\ud8af\udc40\uda9c\udf17\udb17\udd48\ud9b5\ude7f\udae7\udebd\ud9cc\udcae\ud82c\ude38\ud9e2\udc9d\ud936\udc91\u7df4\ud8d4\udd1c\udbdb\udd49", "\u944c\ua1ff\u51d7\u4256\u3467", "\udb68\udf76\ud964\udc3a\ud821\udfad\udad3\udc15\ua387\udaa4\udfa8\ud929\udd1d\ud82e\ude13\udbf8\udeca\ud83e\udc00\ud8f9\uddc3\ud934\uddf1\uda55\udda9\ua342\ud8a9\udda9\ud91d\udf56\udae8\udf53",
        35, 80032, -973837304, -6458077877659627469L, -9174L, true, true, (char) 48479, (char) 56820,
        Double.longBitsToDouble(0x3fd534872b466e1cL), Double.longBitsToDouble(0x3fe4eb9d07354593L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\012",
        Z.run(T, 1, 3, 0, 2, "\udb74\udfa7\ud848\udd24\udb55\udca0\udb48\ude58\udbff\udff2\ud9b5\ude7f\ud8f9\udd85\ud9cc\udcbb\ud9a4\ude2b\uda48\uddf3\ud936\udc91\u7df4\ud8d4\udd1c\udb33\udc8a\udbbb\ude1b\ud8f1\udc73\ud9ec\udfa1\ud8c7\udfd2", "\u77ba\ua6d1\ucbaf\u180b\u74ea", "\ud833\udd73\uda0b\udf5b\udba8\udc3a",
        10, 20647, 175832930, 8409502474213542792L, -57449L, true, true, (char) 2403, (char) 1324,
        Double.longBitsToDouble(0x3fc5850764904e68L), Double.longBitsToDouble(0x3fa9d32c0a91c0d0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 3, "\uda42\udf4b\ud848\udca9\udb55\udca0\udb48\ude58\udbff\udff2\ud9b5\ude7f\ud8b9\udf29\ud9d5\udd89\ud97d\udd58\uda48\uddf3\ud936\udc91\u7df4\ud8d4\udd1c\udb33\udc8a\udbbb\ude1b\ud8f1\udc73\ud9ec\udfa1\uda37\udfca", "\u99aa\u579b", "\uda8d\udcca\ud90e\uddd6\udad3\udc15\udbe7\udecd\uda0b\udffd\udba8\udc3a\udb43\udebd\udaa8\udfe7\ud83e\udc00\udaf6\udd24\ud8d2\udead\uda55\udda9\ua342\ud8a9\udda9\ud91d\udf56\udae8\udf53\ud983\udf4d\udbfd\udd4e\udad7\uddd3\ud87e\udf8c\udbb9\udfa3\ud9fc\udc0e\u6ec4\ud9a5\udff7\ud8aa\udee7",
        -5, 67196, -2020055569, 5684515108960514612L, -31306L, false, false, (char) 52078, (char) 52622,
        Double.longBitsToDouble(0x3fbe857d5613c568L), Double.longBitsToDouble(0x3fcaee0a31fa8400L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 3, "\udbf3\ude48\uda97\udf3b\ud898\uddc5\udaa2\udfde\udb26\ude5b\ud967\udf36\u9a01\ud967\udfb9\ud99a\udeba\uda48\uddf3\uda0a\udfd9\u7dc0\ud83f\udf87\uda77\uded0\udbbb\ude1b\udb04\ude7d\ud9ec\udfc8\ud8c7\udfd2", "\u27c1\u579b\ucb10", "\ud9bc\udf1b\udad3\udc15\udbe7\udecd",
        12, 93074, 742668336, 8027408324393369442L, -55954L, false, false, (char) 41939, (char) 1329,
        Double.longBitsToDouble(0x3fd6f3a7f5826996L), Double.longBitsToDouble(0x3fc58507765c4e68L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 4, 3, "\uda42\udf4b\ud848\udca9\udb55\udca0\udb48\ude58\udbff\udff2\ud9b5\ude7f\ud8f9\udd85\ud9cc\udcbb\ud9a4\ude2b\uda48\uddf3\ud936\udc91\u7df4\ud8d4\udd1c\udb33\udc8a\udbbb\ude1b\ud8f1\udc73\ud9ec\udfa1\ud8c7\udfd2", "\u098d\ua6d1\ucbaf\u180b\u74ea\ube14", "\udad2\udde4\ud99d\udd3c\udb43\udebd\udaa8\udfe7\ud83e\udc00\udaa7\udcd2\ud934\uddb8\uda55\udda9\ua342\ud8a9\udda9",
        46, 1355, 171718323, 2899186694171008172L, 19282L, false, false, (char) 48783, (char) 54312,
        Double.longBitsToDouble(0x3fb2b3a6f7e7bfa0L), Double.longBitsToDouble(0x3fccd4f02b6cd30cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ArchiveStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 2, 3, "\ud8f2\udee9\uda93\ude4f\ud898\uddc5\udaa2\udfde\udb26\ude5b\ud967\udf36\udb3b\udf6e\udbee\ude2e\ud99a\udedb\uda48\uddf3\uda0a\udfd9\udb15\udcbb\ud83f\udfab\uda77\uded0\udbbb\ude1b\udaf8\ude0a\ud9ec\udfc8\ud8ec\uded2", "\u0570\u579b\u256f\u0188\u74ea\u1232\ucc97\uaeae\u2384\ua734\u3ac8\ubaba\u92cd\u3d57\ua751\u9818\u1ec6\uc22b", "\ud9c9\udc8b",
        42, 39408, -1803924073, -5024390089425649283L, -80784L, true, true, (char) 12947, (char) 51522,
        Double.longBitsToDouble(0x3fdd041fdd13f930L), Double.longBitsToDouble(0x3fe7b8c6368b11e5L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.lang.String,java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveOutputStream|java.lang.String,java.io.OutputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "C|org.apache.commons.compress.archivers.ArchiveStreamFactory|<init>|",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.lang.String,java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
