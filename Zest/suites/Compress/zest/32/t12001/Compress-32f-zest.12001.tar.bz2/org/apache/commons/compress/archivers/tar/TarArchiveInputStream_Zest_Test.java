package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 8, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud83e\udc6f\udbc7\udc14", "\u1155", "\udacf\udcd2\ud804\udde2\ud932\uddfb\udbe4\udc74\udab1\udc93\udb51\udd1a\ud980\ude79\u6cfe\uda9e\ude2d\uae05\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        -4, 46801, -803440182, -1218917001020722206L, -85025L, false, false, (char) 20949, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90ff0ac2f7L), Double.longBitsToDouble(0x3fe512b82a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 3, 12, "\udb32\udfa4\udb14\udec6\ud853\udc15\uda94\ude7f\ud9e5\ude82\udadd\udccd\udbbb\udc3d\ud89d\udec9", "\u1155\u2be7\u7c77", "\ud932\ude48\udbe4\udc74\udb59\udc27\udb1f\udd45\udab7\udc70\u6cd5\uda9e\ude2d\uae05\ud9db\udee8\udae9\udd7e\ud860\udd7d\udbbf\udca1\ud989\udeec\ud934\udc34\udbec\udd4b\ud8ea\udf40\udba3\udf43\ud9e1\udd01\ud845\udf13",
        42, 18404, -1023943967, 6297709077603212194L, 47242L, true, false, (char) 53335, (char) 16551,
        Double.longBitsToDouble(0x3fb89e8aebd27f20L), Double.longBitsToDouble(0x3fd849bfe2ab0f6aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 2, "\udb1c\udfa4\uda76\ude78\ud9b5\udedd\uda81\udda8\ud978\udc9e\udadd\udccd\ud83e\udc6f\udbc7\udc14", "\u1155", "\ud91b\udfb1\ud804\ude21\ud932\uddfb\udbe4\udc74\udab1\udc66\udb51\udd1a\ud9b4\uddd3\ud88b\udc7b\ud973\udf5c\uda9c\udea5\udb18\ude87\udae9\udd7e\ud860\udd7d",
        -4, 46801, -803440182, -1218917001020722206L, -85025L, false, false, (char) 20949, (char) 37884,
        Double.longBitsToDouble(0x3fd22f2718152b32L), Double.longBitsToDouble(0x3fe512b8f3cbeda5L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 3, 5, "\udaff\udfad\ud915\udcec\ud942\uddb2\ud805\ude08\udb36\udcaa\udadd\udcda\ud83e\udc6f\udbed\ude14", "\u1f38", "\udabe\udeed\ud804\udde2\ud8aa\udd37\udaf1\ude19",
        55, 49940, -1757714266, 4461159957476877572L, -23977L, false, false, (char) 63832, (char) 56891,
        Double.longBitsToDouble(0x3fd727f6c7c5de2aL), Double.longBitsToDouble(0x3febeadeebd98100L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-112, -24, 99, 116, -123, -83, 95, -4]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 12, 2, "\udac0\udf18\uda93\udea4\ud9b5\udedd\uc98f\u2d2c\udb78\udedb\ud83e\udc6f\udbfc\udc14", "\u1155", "\udacf\udcd2\ud804\udde2\udbe4\udffd\ud9f8\udd33\udab1\udc93\udaf2\udd76\udb7b\udc0f\u6cfe\uda9e\ude2d\udbd3\udec4\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        -4, 8481, -1159749645, 3506129202807128386L, -85025L, false, false, (char) 20949, (char) 54864,
        Double.longBitsToDouble(0x3fa89431f0a5cba0L), Double.longBitsToDouble(0x3fe516f02a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 12, 3, "\udaba\udda8\ud8a3\udd79\uda37\udced\udbce\udc8d\udbd7\udd0b", "\u06d0\u45c6\uc75f\u9c4f\u2be7\uc425\u1efd\u0140\u5f7e\ub67f\u17fa\ua701\u7034\u74f4\u2af2\ub6cf\ud4b2\u79ca\uc861\uc978\u4472\u1828\u3ff5", "\ud95f\ude97",
        28, 63554, -152794719, 8887681108402247466L, 58449L, true, false, (char) 54911, (char) 59210,
        Double.longBitsToDouble(0x3fda0186e6b0e7b8L), Double.longBitsToDouble(0x3fd856e31a1a7e00L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 13, 9, "\ud9de\udc78\udb8a\udf33\ud9b5\udeb7\uda94\ude7f\udb80\ude2f\ud9d7\ude5e\u0c99\ud97a\ude28\uda69\udc8f\udb0b\udcd6", "\u1b11\ud4a2\u38e5\u9ed5\ube57\u4659\u9e60\u7393\u8308\uacd8\uc5a6\u5c8f\u79ca\uc8ea", "\ud98c\udf87\udb24\udc72\ud873\udd44\u4faa\ud976\uddfd\ud845\udfab\ud91f\ude0b\uf343\udb03\udd87\ud973\udffc",
        47, 14134, 529967001, -5099210109287827990L, -33776L, false, false, (char) 21646, (char) 5175,
        Double.longBitsToDouble(0x3fe30fc3ca1c3a25L), Double.longBitsToDouble(0x3f95cc188fc1a820L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 3, 8, "\udafd\udf1b\udb21\ude76\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud83e\udc6f\udbc7\udc14", "\u1155", "\udacf\udcd2\ud804\udde2\ud932\uddfb\udbe4\udc74\udab1\udc93\udb51\udd1a\ud980\ude79\u6cfe\uda9e\ude2d\uae05\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        -4, 38920, -803440182, -1218917001020722206L, -85025L, false, false, (char) 20949, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90ff0ac2f7L), Double.longBitsToDouble(0x3fe512b82a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 8, 5, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud83e\udc6f\ud8c0\udc31", "\u1140", "\udacf\udcd2\ud804\udde2\uda22\udeac\u4717\ud970\ude40\ud886\ude58\ud980\ude79\udb86\udc89\udb78\ude25\ud8a2\udce0\uda61\udf17\udae9\udd7e\udbe2\udd5e",
        -4, 46801, -954435126, 542174546351976734L, -59941L, false, false, (char) 11908, (char) 64248,
        Double.longBitsToDouble(0x3fe70f90ff0ac2f7L), Double.longBitsToDouble(0x3fe512b82ad1cca5L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 8, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\uda06\udf6a\udadd\udccd\ud817\udd86\udbc7\udc14", "\u586a", "\udacf\udcd2\ud804\udde2\ud932\uddfb\udbe4\udc74\udab1\udc93\udb51\udd1a\ud980\ude79\u6cfe\uda9e\ude2d\uae05\udb46\udfe8\udb80\ude8a\ud831\ude7e",
        -4, 46801, -803440182, -1218917001020722206L, -85025L, false, false, (char) 20949, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90ff0ac2f7L), Double.longBitsToDouble(0x3fe512b82a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 0, 0, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud83e\udc6f\udbc7\udc14", "\u1155", "\udacf\udcd2\ud804\udde2\ud932\uddfb\ud9cd\udc09\uda92\ude29\udb51\udd1a\ud980\ude79\u6cfe\uda9e\ude2d\uae05\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        -4, 46801, -803440182, -1218917001020722206L, -85025L, false, false, (char) 20949, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90070ac2f7L), Double.longBitsToDouble(0x3fe512b82a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-124, 85, 83, 104, -123, -83, 100, 79]]\012",
        Z.run(T, 2, 0, 15, 8, "\udab4\udd85\uda83\ude98\ud9b5\udedd\uda94\ude7f\u2d2c\udaa4\ude72\udb3f\udc43\udbc7\udc14\udb89\udcda\udbb5\udf05\udb29\uddd7\ud8c3\udc60\u06a2", "\u6d56\u2547\u6cb4\u98a3\u18f1\ud516\uac05\u79f3\u9b96\u0198\uc860\ub8d5\u1999", "\ud873\udd44",
        53, 35398, 833647770, -140544395438854821L, -13875L, false, false, (char) 48786, (char) 19913,
        Double.longBitsToDouble(0x3fdd8523302aca84L), Double.longBitsToDouble(0x3fdb62e9df7f7208L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 1, 5, 8, 8, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud868\udd17\udbc7\udc14", "\u1155", "\udacf\udcd2\ud804\udde2\ud932\uddfb\udbe4\udc74\ud8f1\udc93\udb51\udd1a\ud980\ude79\u6cfe\uda9e\ude2d\uae05\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        -4, 46801, -803440182, -1218917000719649822L, -85025L, false, false, (char) 20949, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90ff0ac2f7L), Double.longBitsToDouble(0x3fe512b82a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 14, 14, 8, "\udb59\udda1\uda76\ude78", "\ub16b\ud413\u9904\u515b\u4f05\ub067\u1155\ud303\ua891\ud4a0", "\uceb9\udac9\udd79\udb51\udd1a",
        19, 9836, 1469785348, 2369509357596841901L, -23977L, false, false, (char) 58252, (char) 56744,
        Double.longBitsToDouble(0x3fa651a8be2ef150L), Double.longBitsToDouble(0x3fef10bbcd818100L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 0, 8, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud8bb\ude0e\udbc7\udc14", "\u6bbf", "\udacf\udcd2\udb24\ude72\ud932\uddfb\udbe4\udc74\uda75\udcaf\ud944\ude70\ud980\ude79\u6cfe\uce59\uae39\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        51, 76510, -803440293, -8496733997535259472L, -34948L, true, true, (char) 15231, (char) 29033,
        Double.longBitsToDouble(0x3fe512b82a3acca5L), Double.longBitsToDouble(0x3fe41e7c2eb39eb4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 2, 8, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud83e\udc6f\udbc7\udc14", "\ub962", "\udacf\udcd2\ud804\udde2\ud932\uddfb\udbe4\udc74\udab1\udc93\udb51\udd1a\ud980\ude79\u6cfe\uda9e\ude2d\uae05\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        -4, 46801, -803440182, -1218917001020722206L, -85025L, false, false, (char) 20949, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90ff0ac2f7L), Double.longBitsToDouble(0x3fe512b82a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 1, 8, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\udbbe\udd76\udbc7\udc14", "\u1155", "\udacf\udcd2\ud804\udde2\ud932\uddfb\udbe4\udc74\udb69\udc8f\udb51\udd1a\ud980\ude79\u6cfe\uda9e\ude2d\uae05\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        -4, 46913, -93485808, -1218877457256827934L, -85025L, false, false, (char) 20949, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90ff0ac2f7L), Double.longBitsToDouble(0x3fe512b82a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[38, -91]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 3, 8, "\udb56\udfd5", "\u1de8\u448f\u9f3f\u4d04", "\ud9c7\udf8f\udba1\udfea\udaa8\udf6f\udadc\udf67\udbe0\uddda",
        7, 25474, 1265499139, 6891767927996543824L, 43413L, false, false, (char) 64451, (char) 47716,
        Double.longBitsToDouble(0x3fe7814d175960a3L), Double.longBitsToDouble(0x3fdcaf8cd6bfa038L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 2, 2, 8, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud83e\udc6f\udbc7\udc14", "\u902a", "\udacf\udcd2\ud804\udde2\ud932\uddfb\udbe4\udc74\udab1\udc93\udb51\udd1a\ud980\ude79\u6cfe\uda9e\ude2d\uae05\udb46\udfe8\udae9\udd7e\ud860\udd7d",
        19, 91189, -803440182, -1218917001020722206L, -85025L, false, false, (char) 20951, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90ff0ac2f7L), Double.longBitsToDouble(0x3fe512b82a3acca5L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[2, 116, 111, 88, -123, -83, 100, 79]]\0121=java.lang.Boolean:false |a0=[B:[[2, 116, 111, 88, -123, -83, 100, 79]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 15, 12, 2, "\udb32\udfa4\ud99f\ude88\ud9b5\udedd\uda94\ude7f\u2d2c\uda71\udf7a\ud83e\udc6f\ud99a\ude1e", "\u1155", "\ud916\udf02\udbbd\udeda\ud950\udd47\udbe4\udc74\udab1\udc93\udb51\udd1a\ud980\ude79\u6cfe\ud8a2\udc6f\ud8ce\udec9\ud9af\uddbe\udae9\udd44\uda36\uddc8",
        14, 93212, -803440182, -1218917001020722206L, -85025L, false, false, (char) 20949, (char) 63312,
        Double.longBitsToDouble(0x3fe70f90ff0ac2ddL), Double.longBitsToDouble(0x3fda25705d6053d4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 8, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\uda00\udf4f\udbc8\ude8d\ud83e\udc6f\udbc7\udc14\ud904\uddc0\ud98b\udf2c\uda6f\udc23\ud8d1\udd02\ud904\udee3\udb87\ude9f\ud962\udc80\ud808\ude9f\udb14\udd45\uda9d\udfed\u3965\ud980\ude79", "\u5437\ud4b2\u79ca\u6062\u4544\uc562\uc907", "\u5466\ud940\udd97\ud845\udfab\uda45\uddfe\ud8cf\udf47\ud8c5\udf48\uda02\udf75\ud8d3\udf9b\ud8ec\udf03\ud8b5\udd48\udb01\udea5\udac7\udefe\ud86d\ude3e\ud8a5\udfde",
        55, 58906, 43933512, 212214885587108347L, -35212L, true, false, (char) 29444, (char) 9476,
        Double.longBitsToDouble(0x3fe8dcd54592c659L), Double.longBitsToDouble(0x3fd821f77c36efd6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-124, 78, 117, 84, -123, -83, 100, -20]]\012",
        Z.run(T, 1, 15, 3, 6, "\ud8b4\udd7e\udba5\udd84\ud9b5\udedd\uda94\udf1c\ud815\udd30\ud9fb\udef2\ud83e\udf78\udbc7\udc14", "\ua4aa", "\udbd5\udc65\ud807\udce2\ud81a\ude7f\uda7a\udd1b",
        56, 54942, -135995007, 6627568408204092922L, 87968L, true, true, (char) 46933, (char) 8082,
        Double.longBitsToDouble(0x3feacb0519a57f84L), Double.longBitsToDouble(0x3f966fcf5436eca0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[32, 70, 114, -123, -83, 100, 79]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 0, 12, 13, "\ufb50\uda76\udea2\ud9b5\udedd\uda94\ude7f", "\u9904\u515b\u4f05", "\ud89b\udc96\udb1e\udd21\ud846\udd4b\udb41\udd1c\ud979\udd1b\udbad\udf7a\udab1\udc93",
        11, 77294, -1546634920, 6312680001177268277L, -99651L, true, true, (char) 4329, (char) 55412,
        Double.longBitsToDouble(0x3fdcaf8cd2e5a038L), Double.longBitsToDouble(0x3feebf78ab2700b1L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[2, 116, -28, -106, 35, -27, -92, 31]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[2, 116, -28, -106, 35, -27, -92, 31]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 12, 12, 2, "\udb32\udfa4\udb14\udec6\ud853\udc15\udad4\ude4f\udb2b\uddd9\udac9\ude8f\udbbb\udc3d\ud89d\udec9", "\u1155\u2be7\u7c77", "\udaf8\udc44\udb74\udf1a\uda76\ude3a\udb1f\udd45\udb15\udf25\u6cd5\uda9e\ude2d\uae05\ud9db\udee8\udb36\udd25\uda77\ude8f\udaa6\udecc\ud989\udefa\ud934\udc34\udbec\udd4b\ud8ea\udf40\udba3\udf43\ud9e1\udd01\ud845\udf13",
        0, 18404, -1023943967, -8552579644008249867L, 66150L, true, false, (char) 14518, (char) 16551,
        Double.longBitsToDouble(0x3fb89e4aebd27f20L), Double.longBitsToDouble(0x3fd849bfe2ab0f6aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=null |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 5, 5, 8, "\udb32\udfa4\udb14\udec6\ud9b2\ude19\uda94\ude7f\ud9e5\ude82\udadd\udccd\udbbb\udc3d\ud89d\udec9", "\u1155\u2be7\u7c77", "\ud932\ude48\udbe4\udc74\udb59\udc27\udb1f\udd45\udab7\udc70\u6d9c\ud9e2\udf32\uae31\ud9db\udee8\udae9\udd7e\ud860\udd7d\udbbf\udca1\ud989\udeec\ud934\udc34\udadb\udfc3\ud8d8\uded6\udba3\udf43\ud87f\udd06\ud845\udf13",
        42, 18404, -1023943967, 6297709077603212194L, 47242L, true, false, (char) 53335, (char) 23691,
        Double.longBitsToDouble(0x3fb89e8aebd27f20L), Double.longBitsToDouble(0x3fd849bfe2ab0f6aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 6, 14, "\udb1c\udfbb\uda76\ude78\ud9b5\udedd\uda81\udda8\udaa1\udff4\uda26\udfbc\ud95d\udc6a\udbc7\udc14\ud8b9\udf7b\udb40\udff4\ud858\udd6e\ud90c\udca0\udb7f\udef2\ud91b\udfb1\ud804\ude21\ud932\uddfb", "\u8e77\u6f70\u4d7a\u994b\uab03\u1b51\u397f\ua22e\u5ff7\ub151\u5dbf\u6d65\u3f69\uc6db\u4a81\u72d0\u473f\ub60c\u266f", "\ud8ef\udd46\ud9d8\ude06\ufa15\udb77\udd67\ud895\udd26\uda8b\udd02\udb2e\udc3a\ud990\udd7b\ud8af\udd7b\uda3f\udedc\udbc1\ude75\udb63\udcbe\ud95c\udd0b\uda78\udcc7\udbdb\udd90\ud961\udc50\ud97a\udfb9\udaa0\udcb4\uda69\udcfb\udae6\ude03\udb4c\udc76\ud9e4\udcb3\ud80d\udfdb",
        33, 82841, 2100486590, 92841624890939242L, 89384L, true, true, (char) 23972, (char) 54491,
        Double.longBitsToDouble(0x3fec12c34516af8fL), Double.longBitsToDouble(0x3fdc219fb21e5a4eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:true |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 12, 12, 2, "\udac0\udf18\udb8a\udf20\ud9b5\udedd\uc98f\u2d2c\u06e4\ud83e\udd24\udbfc\udc14", "\u1155", "\udacf\udcd2\ud804\udde2\udbe4\udfa2\ud873\udc31\ud998\udec4\udabe\ude1c\ud9c1\udf8a\u6cfe\uda9e\ude2d\udbd3\udec4\udb46\udfe8\udae9\udd7e\ud8d0\udf75",
        -4, 43249, -1159788203, 3506129202807128386L, 49553L, false, true, (char) 24743, (char) 56130,
        Double.longBitsToDouble(0x3fa8b5f655d2c3f0L), Double.longBitsToDouble(0x3fe5d65d3bd5517cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-112, -24, 99, 116, 2, -37, -67, 92]]\0121=java.lang.Boolean:false |a0=[B:[[-112, -24, 99, 116, 2, -37, -67, 92]]\012",
        Z.run(T, 2, 15, 15, 2, "\udac0\udf18\uda93\udea4\ud832\ude0b\udaed\ude8c\ud8aa\udffd\udbd8\udd09\ud960\udcdb\udbc6\udfbf", "\ud043\u91a4\ua023\u0b1f\u1f9e\uaa37\u8305\u3cc4\ua305\u837d\u82e1\uacd8\u05fc", "\ud9cc\uddd3",
        -1, 8481, -1159749645, 3506129204166082882L, -85025L, false, false, (char) 63882, (char) 8145,
        Double.longBitsToDouble(0x3fa8941670a5cba0L), Double.longBitsToDouble(0x3fe516f02e9afe50L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 13, 13, "\udaba\udda8\ud8a3\udd79\uda37\udced\udbce\udc8d\udbd7\udd0b", "\u06d0\u45c6\uc75f\u9c4f\u2be7\uc425\u1efd\u0140\u5f7e\ub67f\u17fa\ua701\u7034\u74f4\u2af2\ub6cf\ud4b2\u79ca\uc861\uc978\u4472\u1828\u3ff5", "\ud95f\ude97",
        28, 63554, -152794719, 8887681108402247466L, 58449L, true, false, (char) 54911, (char) 59210,
        Double.longBitsToDouble(0x3fda0186e6b0e7b8L), Double.longBitsToDouble(0x3fd856e31a1a7e00L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[-48]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 13, 12, 3, "\000", "\u23c0", "\ue86d",
        50, 43656, 1942730274, 6974784544687461964L, 84025L, false, false, (char) 0, (char) 57072,
        Double.longBitsToDouble(0x3fec2d0d2350f2e2L), Double.longBitsToDouble(0x3fc1413bb330d6dcL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Integer:0 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 1, 1, 5, "\ud99a\udd58\uda45\uddb9\uda5d\uded4\u1d6d\ud94f\udc0d\udadd\udd24\ud9dc\udf3f\ud8ee\udedf", "\u10f9\ub603\uc630\ud4bd\u2a00\u77e6\u7eba\u1a8d\u806c\uc936\u4443\ucd78\u23b1\uc7f3\uc50c\u226d\u4179\u975c\u769a", "\udb9e\uddde",
        30, 8612, 28653596, -999806522823812383L, -1022L, true, false, (char) 4462, (char) 8937,
        Double.longBitsToDouble(0x3fd14408f6a337daL), Double.longBitsToDouble(0x3fe9f200641d87eaL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 15, 14, 13, "\udb32\udfa4\uda76\ude78\ud9b5\udedd\uda94\ude7f\u2d2c\udadd\udccd\ud868\udd17\ud8d3\udfe2\ud852\udd18\udac4\udeaa\ud919\udc50\ud89b\udc96\ud966\udd13", "\u9229\u4619\u2004\u8e77\u0c7a\u79a5\u3987\u44e8\u1dc2\ucf8a\uc861\u4179\u3ed1\uc907\u9342\u8a41\ub520\u8b5f\u2df7", "\ud9f6\ude50\udbd2\udc93\udae5\udc2c\ud9af\udd5a\ud928\ude4e\ud89d\udf28\ud957\udfae",
        14, 25843, -1895640257, -3878552038797264730L, 94380L, true, true, (char) 33792, (char) 42460,
        Double.longBitsToDouble(0x3fe6e5e19457511fL), Double.longBitsToDouble(0x3fe7a5998a131f3eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Integer:512 |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 3, 8, "\u70c5\uda76\ude78", "\u0844\u4582\u9904\u515b\u4fa1\ub067\u1155\u2be7\u1144\ud4bd\u0c28\ud4d4\u4569\u3d05\u8e77\u0c7a\u82b8\uacd8\u5437\ud4b2\u79ca\uc861\u4179\u3ed1\ub246", "\u5466\ud95f\ude97\ud845\udfab\uda45\uddfe\uda9c\udc72\ud8c5\udf48\udb6f\udc2a\ud8d3\udf9b\ud8c7\ude50\ud81a\uddfa\uda5b\udcc4\u8091\ud9e3\udf77\ud8fb\udfa5",
        0, 9704, -1666605615, 5248370464443319985L, 33827L, false, false, (char) 8993, (char) 61031,
        Double.longBitsToDouble(0x3fde379c2fd1ce7cL), Double.longBitsToDouble(0x3fd1016b0d75c9e6L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, -92, 90, -105, -123, -83, 95, 52]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[0, -92, 90, -105, -123, -83, 95, 52]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 12, 12, 2, "\ud930\uddd4\udb8a\udec7\ud9b5\udedd\uc98f\u2d64\u06e4\ud83e\udd24\udbfc\udc14", "\u1155", "\udacf\udcd2\ud804\udde2\udbe4\udfa2\ud873\udc31\udb2a\udfce\udabe\ude1c\ud9c1\udf8a\u6cfe\uda9e\ude2d\udbd3\udec4\udb46\udfe8\udae9\udd7e\ud8a0\udf75",
        -4, 43249, -1296150320, 3495941806657340228L, 3830L, true, false, (char) 19426, (char) 3027,
        Double.longBitsToDouble(0x3fe516f02a4af0f8L), Double.longBitsToDouble(0x3fa89e7355d2c3f0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, -92, 90, -105, -123, -83, 95, 79]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 8, 2, "\ud930\uddd4\udb8a\udec7\ud9b5\udedd\uc98f\ud97f\udeee\u076d\ud83e\udd24\udbfc\udc14", "\u10bb", "\ud917\udf7e\ud804\udde2",
        3, 14424, 2113813602, -2690456232814289483L, 65721L, false, false, (char) 51019, (char) 46023,
        Double.longBitsToDouble(0x3fc920a7e6060400L), Double.longBitsToDouble(0x3fed997aa26aa329L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[0, 0, 90, -105, -123, -83, 95, 52]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=java.lang.Boolean:false |a0=[B:[[0, 0, 90, -105, -123, -83, 95, 52]] |this=org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 12, 12, 2, "\ud930\ude30\udb8a\udec7\ud9b5\udedd\uc98f\u2d64\u06e4\ud83e\udd24\udbfc\udc14\ud893\udc67\ud8f6\udea3\ud919\udc50\ud89b\udc96\ud966\udd13\udacf\udcd2\ud804\udde2\udbe4\udfa2\ud873\udc31\udb2a\udfce\udabe\ude1c\ud9c1\udf8a\u6cfe\uda9e\ude2d\udbd3\udec4\udb46\udfe8\udae9\udd7e\ud8a0\udf75\udbbf\udca1\udb04\udc4a\ud9b9\udc42\udbbd\udf68\ud880\udf93\ub94d\ud805\udc4b\ud960\ude3a\ud96d\uddf2\udad7\ude90\udb43\udda8\ud96b\udd09\ud8dc\uddbf\ud9e9\udc15\uda20\udecc", "\u6420", "\ud8a3\uddbf\ud868\udd52\udadb\udf80\ud98c\udd4b\ud85e\udd9f\ud804\udfd7\ud946\udfee\udac9\udcab",
        27, 6860, -1896526482, 7008523454226392510L, 17485L, false, true, (char) 49183, (char) 20560,
        Double.longBitsToDouble(0x3feddc7d16964c38L), Double.longBitsToDouble(0x3fe22d134feabc95L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|applyPaxHeadersToCurrentEntry|java.util.Map|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|available||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|canReadEntryData|org.apache.commons.compress.archivers.ArchiveEntry|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|close||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|consumeRemainderOfLastBlock||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getCurrentEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getLongNameData||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getNextTarEntry||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getRecord||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|getRecordSize||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|isAtEOF||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|isEOFRecord|[B|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|mark|int|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|markSupported||new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|matches|[B,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|applyPaxHeadersToCurrentEntry|java.util.Map|new:org.apache.commons.compress.archivers.tar.TarArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
