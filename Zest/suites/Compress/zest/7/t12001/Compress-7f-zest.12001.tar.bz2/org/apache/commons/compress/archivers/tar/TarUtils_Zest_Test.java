package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 6, 8, "\ud9aa\uddaa\ud8cb\uddbb\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\uda97\ude42\ud851\udeb8", "\ub970\u170b\ub08d\u58c1\u0250\u2b8a", "\udbd0\udefb\udba3\udd7c\ud9b1\udd51\ud816\uddca\ud86e\udfd8\udb2d\udc2b",
        39, 59399, 1761268906, 5555337467143891837L, 12090L, false, true, (char) 15975, (char) 16302,
        Double.longBitsToDouble(0x3feef1748d2c2728L), Double.longBitsToDouble(0x3fec6ba21be23429L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 6, 8, "\ud9aa\uddaa\uda7d\uddb4\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\uda97\ude42\ud851\udeb8", "\ub970\u170b\ub08d\u58c1\u0250\u2b8a", "\udbd0\udefb\udba3\udd7c\ud9b1\udd51\ud816\uddca\ud86e\udfd8\udb2d\udc2b",
        39, 59399, 1761268906, 5555337467143891837L, 12090L, false, true, (char) 15975, (char) 16302,
        Double.longBitsToDouble(0x3feef1748d2c2728L), Double.longBitsToDouble(0x3fec6ba21be23429L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 8, "\udb6f\ude6c\udaf1\udfaf\ud87b\udc70\uda73\udff2\ud9cf\ude89\uda08\udfdf\uda39\udd07\udb7d\udc9d", "\u2749\u19af\ub08d\u58c1\u0250\u8391\u8380\uc667", "\udbeb\udd4e\ud816\uddca\ud86e\udfd8\udb2d\udc2b\uda04\udc1c\uda0b\udd86\udb16\udf21",
        53, 35629, -992259065, 8900720186029199692L, 55253L, false, false, (char) 23448, (char) 3368,
        Double.longBitsToDouble(0x3fef11a26dbdd7daL), Double.longBitsToDouble(0x3fc9f1d8917e6ce8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 7, 1, "\ud8eb\udf8b\ud96e\udd83\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\uda97\ude42", "\u06ef", "\ud8a4\udc01\ud8d6\ude39\u7e72\u5e09",
        24, 12126, 569327868, -8430531371604977867L, 60047L, true, true, (char) 49886, (char) 46776,
        Double.longBitsToDouble(0x3fe303f225fe6833L), Double.longBitsToDouble(0x3fd7d4d189f6610eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 6, 0, "\ud9aa\uddaa\ud9aa\udca8\ud915\udc88\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\uda97\ude42\ud851\udeb8", "\ub970\u170b\ub08d\u6144\ua34c\u9241", "\udbd0\ude8f\udba3\udd7c\ud9b1\udd51\ud816\uddca\ud86e\udfd8\udb2d\udc2b",
        -1, 59399, 1761268906, 5555337467143891837L, 50030L, false, true, (char) 15975, (char) 16302,
        Double.longBitsToDouble(0x3feef1748d2c2728L), Double.longBitsToDouble(0x3fec6ba21be23429L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 6, 8, "\ud9aa\uddaa\ud8cb\uddbb\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\uda7b\udff4\uda9a\udfd9", "\ub970\u170b\ub08d\u58c1\u0250\u2b8a\u8380\uc667\u2934", "\ud816\uddca\ud86e\udfd8\udb2d\udc2b\uda04\udc1c\uda0b\udd86\udb16\uded9\ud83a\ude89\ud865\ude59\udbf0\udc33\ud9ff\udd21\u5bbb\uda4c\udf36\uda27\udc49\ud8df\udf47",
        31, -374, -503784478, 2858258950828839825L, 98629L, false, false, (char) 50582, (char) 28494,
        Double.longBitsToDouble(0x3fba47bb58de1230L), Double.longBitsToDouble(0x3fe2f0be6edfba8eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 6, 2, "\ud979\udf20\ud930\udf41\uda85\udd14\ud872\ude4d\ud9cf\ude89\uda75\udea4\uda0a\udd87\ud9de\ude03", "\u59cf\u4b97\u2aba\u588b\u60de\ud1fe", "\udb22\udddd\ud9e8\udf37\ud9b1\udd51\ud816\uddca\ud88a\udfc5\udbbd\ude52",
        46, 59399, -1803507798, 8783936504876989353L, 44349L, false, true, (char) 26726, (char) 46328,
        Double.longBitsToDouble(0x3febd263819a3554L), Double.longBitsToDouble(0x3fea61e2d3e23429L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 8, 8, "\ud9aa\uddaa\ud8cb\uddbb\ud9c5\udc76\uda6b\udfd7\ud9cf\ude89\ud88d\udfd1\uda97\ude42\ud851\udeb8\udaff\udcf5\ud92e\udd8a", "\u94cc\u58c1\u0250\uc881", "\udbd0\udefb\udba3\udd7c\ud9b1\udd51\ud83d\udc5e\ud86e\udfd8\udb2d\udc2b",
        39, 59399, 1761088938, 5555337467143891837L, -57243L, true, true, (char) 55918, (char) 34007,
        Double.longBitsToDouble(0x3fec6ba21be23429L), Double.longBitsToDouble(0x3fe0e385b4ae64bcL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 8, "\ud9aa\uddda\ud955\udeb5\udaf6\udd6e\ud872\ude4d\udb29\uded5\ud88d\udfd1\ud84a\udf3b\ud851\udeb8\udaff\udcf5\ud92e\udd8a\ud98f\udf56\udba4\ude99\udb36\udc4e", "\ua45a\u8370\uc667", "\ud9b1\udd51\ud816\uddca\udaac\ude6b\udb2d\udc2b\uda04\udc1c\ud9dc\udd22\udb16\uded9",
        48, 35629, 1188779015, 6738992366054249354L, 55253L, false, false, (char) 50259, (char) 27600,
        Double.longBitsToDouble(0x3fef11a14cafa87aL), Double.longBitsToDouble(0x3fef0b8f83a556a1L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Long:893 |a0=[B:[[122, 122, -101, -117, -58, 62, 66, 29]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 8, "\ud9aa\uddaa\ud8cb\uddbb\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud99f\udd30\uda97\ude42\ud851\udeb8", "\ub970\u170b\ub08d\u58c1\u0250\u2b8a", "\udbd0\udefb\udba3\udd7c\ud9b1\udd51\ud816\uddca\ud86e\udfd8\udb2d\udc2b",
        39, 59399, 1761268906, 5555337467143891837L, 12090L, false, true, (char) 15975, (char) 16302,
        Double.longBitsToDouble(0x3feef1748ae1d328L), Double.longBitsToDouble(0x3fe80a5443e23429L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 6, 8, "\ud9aa\uddaa\ud8cb\uddbb\udaf6\udd6e", "\uc652\ua97a\u13e5\ubc6f\u236a", "\ud877\udc73\ud9a3\udfdd\udbfd\udf00\u5e09",
        29, 12261, 569327868, -8430531371604977867L, 60047L, true, true, (char) 49886, (char) 13178,
        Double.longBitsToDouble(0x3fc54086d7f9a3e8L), Double.longBitsToDouble(0x3febea68c4073087L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 3, "\ud9aa\uddaa\ud8cb\uddbb\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\ud84f\ude3e\ud851\udeb8\udaff\udcf5\ud92e\udd8a\ud98f\udf56\udba4\ude99\udb36\udc4e\uda97\udc10\udbfd\udf00", "\uaa94\u2934\u7a7c\u4cf0\ud5d7\ub5cd", "\ud99f\udd50\ud902\ude50\udb2f\ude56\ud865\ude59\udbf0\udc33\ud961\udd93\udbf2\udc12\uda4c\udf36\u5000\u534b\u741f\udbe4\ude9f\udbb0\udd9d\ud947\udf8c\udb46\udf01",
        19, 78825, 1263571981, 2119702770888327018L, -75375L, false, true, (char) 21106, (char) 12527,
        Double.longBitsToDouble(0x3feffc4f6ed8802bL), Double.longBitsToDouble(0x3fe0528352782d49L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 6, 8, "\000", "\u00cd\uc71a\u11ab\u3067\000\ubc0d\u6314\ub970\u170b\ub08d\ua471\u0250\u2b8a\000\ua5f0\u2934\u79b7\u6a1c\ud5d7\u5c54\ucb90\u7ffb\ub9fd\u3116\uab42\ub200\u7903", "\000\ud9fe\udebe\uabde\u9d2c\udba6\udf12\uda7b\udfc4\udbd1\udcb0\ud57e\ud859\udd92\ud9e3\ude5a\udaa0\udc38\udb3a\ude30\ud9a7\udf81\udb08\udec1\ud932\udffd\udacb\udcd1\ud90e\udda7\ud8f2\udc42\ud9ea\udeac\ud919\udc6d\ud94a\udcf9",
        23, 81306, -1866889088, -4384736995655540128L, 36535L, true, false, (char) 2833, (char) 22702,
        Double.longBitsToDouble(0x3fd6d06016ef03c8L), Double.longBitsToDouble(0x3fd982941b101bfaL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Long:938 |a0=[B:[[122, 122, -101, -117, -48, 97, 66, 29]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 8, "\ud9aa\uddaa\ud8cb\uddbb\udb00\ude91\ud872\ude4d\ud9cf\ude89\udbe5\ude1c\udbf4\udcc0\ud851\udf30", "\ub970\u170b\ub08d\u58c1\u0250\u2b8a", "\udacd\udfd8\udba3\udd7c\ud9b1\udd51\ud916\uddcf\ud92f\udc43\udb2d\udc71\uda04\udc1c\uda0b\udd86\udb16\uded9\ud83a\ude89\ud865\ude59\udbf0\udc33\ud9ff\udd21",
        59, 38922, 781296011, 2821533609330956844L, -18455L, false, false, (char) 18838, (char) 49575,
        Double.longBitsToDouble(0x3fbac08fd91ebf28L), Double.longBitsToDouble(0x3fc7531c203d06a4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=java.lang.Long:867 |a0=[B:[[122, 122, 36, -24, -58, 62, 66, 29]]\012",
        Z.run(T, 2, 8, 1, 8, "\ud9aa\uddaa\uda54\udf18\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\ud8fa\udefb\ud859\uddc2", "\uca31\ud6df\u33df\u677d\u7dc5\u2b8a", "\udbd0\udefb\udbc3\udf8c\ud9b1\udd51\ud8d0\udfb8\udbb3\udc11\ud8ad\udce9\uda04\udc1c\ud9a6\udcf5\ud902\udd90\ud913\udfc2\ud8ba\udc4a\udbf0\udcc0\udad8\udd6e",
        2, 4371, 781296011, 2821694138469293356L, 87384L, true, false, (char) 38019, (char) 24544,
        Double.longBitsToDouble(0x3fc2265a79cb0254L), Double.longBitsToDouble(0x3fdfde687542eb12L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 5, 4, "\ud9d5\udca6\udafd\udcea\udaf6\udda3\ud872\ude4d\ud9cf\ude89", "\u13e5\ubc6f\u6314\ub970\u170b\u1707\u58c1\u0250\u2b8a\u8380\uc667", "\ud9b1\udd51\ud816\uddca\ud86e\udfd8\udb2d\udc2b\uda04\udc1c\uda0b\udd86\udb16\uded9",
        48, 35629, 1188779015, 8900720186029199692L, 55253L, false, true, (char) 50259, (char) 27600,
        Double.longBitsToDouble(0x3fef11a14a568aaaL), Double.longBitsToDouble(0x3fe3bb9f7d55c030L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 0, 8, "\ud8cd\udf7c\000\udaf6\udd4f\uc4cd\ud9cf\ude89\ud853\udcd1\uda97\ude42\ud851\udeb8", "\ub970\u170b\ub08d\u58c1\ud088\000", "\udbd0\udefb",
        4, 47749, 1371260153, -6528406164707769947L, 42663L, false, false, (char) 61175, (char) 63636,
        Double.longBitsToDouble(0x3f7cc00280000000L), Double.longBitsToDouble(0x3fd4c7b851f7cad6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 2, 8, 8, 5, "\ud979\udc86\udbfc\ude58", "\uc71a\u11ab\ubc2d\u3f32\u8675\u984c\ub9e0\u170b\ub08d\u26c1\uc92f\u3d91\u646b\u34d9\u9d6c\u7975\u6a1c\ud5d7\ub5f4\ucb90\u0eb0\uba44\u3116\ub95d\u6dd4\ub801\u3840\uce3c\u9d31\u0e5e\u4526\u06f8\u2d60\ub393\u85d7", "\ub6d7\udade\udda4\uda5c\udf85\udbfe\udc27\ud8f5\udfae",
        3, 58833, -1869467884, -1891957517687714562L, -91545L, true, false, (char) 49328, (char) 30859,
        Double.longBitsToDouble(0x3fea377d17a1a93fL), Double.longBitsToDouble(0x3fd1f47bee71a046L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!java.lang.NegativeArraySizeException\012",
        Z.run(T, 2, 7, 0, 0, "", "\000\u3509\ube2d\u13e9\u3067", "\ud889\udcd7",
        -5, -1000, 0, 206970179026944L, 32743L, false, false, (char) 24831, (char) 8687,
        Double.longBitsToDouble(0x3fe80000000067b2L), Double.longBitsToDouble(0x3fd2f51bb00000ccL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Long:853 |a0=[B:[[122, -79, -101, -117, -58, 62]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 3, 4, "\ud9aa\udde1\ud8cb\uddbb\udaf6\udd6e", "\u59f6\u7c9d\u13e5\ubc6f\u6314", "\udb36\udc4e\uda97\udc10\udbfd\udf00\u5e09",
        46, 12102, 569327868, -8430531371604977867L, 60047L, true, false, (char) 180, (char) 48505,
        Double.longBitsToDouble(0x3feb50245dfe684eL), Double.longBitsToDouble(0x3febea68c4073087L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Long:741 |a0=[B:[[119, -124, -73, 1, -52, 7, 66, 29]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 2, 6, "\ud9a7\udeb4\ud9e7\ude31\udafc\udc37\ud872\ude4d\ud805\ude04\ud86d\udc1f\u192f\ud851\uded5", "\u6538\u170b\u44eb\ua29b\u3bf0\u8d8f", "\udb06\udef6\udba3\udd7c\uda56\ude0f\ud938\udc9d\ud86e\udff3\uda4d\udf9a\udb31\udd17\ud92a\udd63\ud8c7\udd0f\uda48\udd25\ud865\ude59\ud946\ude07\ud9ff\udd1b",
        2, 19165, 781296011, 2821694138469293356L, 25169L, true, true, (char) 64830, (char) 21558,
        Double.longBitsToDouble(0x3fe89a21a8dfa705L), Double.longBitsToDouble(0x3fe0450d6a962799L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Long:893 |a0=[B:[[122, 122, -101, -117, -58, 62, 66, 29]]\0121=java.lang.Long:893 |a0=[B:[[122, 122, -101, -117, -58, 62, 66, 29]]\012",
        Z.run(T, 2, 1, 1, 8, "\ud9aa\uddaa\ud8cb\uddbb\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\uda97\ude42\ud851\udeb8", "\u30c6\u6287\uba09\ub155\u2bfa\u10dc", "\udb21\ude03\udba3\uddb9\ud97e\udc51\ud816\uddca\ud86e\udfd8\udb2d\udc2b",
        39, 59399, 1761268906, 5555337467143891837L, 12090L, false, true, (char) 21249, (char) 56825,
        Double.longBitsToDouble(0x3fe1e7bd452c2784L), Double.longBitsToDouble(0x3fe8e29a597f5649L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 6, 2, "\ud9aa\uddaa\ud8cb\uddbb\udaf6\udd6e\ud91e\udf42\ud9cf\ude89\ud88d\udfd1\uda97\ude42\ud851\udeb8", "\ub9fe\u170b\ub08d\u58c1\u0250", "\udadb\ude24\uda9a\ude60\udba3\udddf\ud9b1\udd51\ud816\uddca\ud86e\udfd8",
        2, 10223, 70659399, 7564592352025150974L, 55253L, false, true, (char) 50259, (char) 27600,
        Double.longBitsToDouble(0x3fef11a149e6c022L), Double.longBitsToDouble(0x3fb599d0d20da528L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:-1003\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 6, 8, "\ud8cd\udf7c\000\037\000\ud9b3\udd19\ud88d\udfd1\uda80\ude9f\ud83c\ude5d", "\ub970\u170b\ub08d\u58c1\u00ab\u2b24", "\udbd0\udefb\udba3\udd7c\ud9b1\udd51\ud816\uddca\ud86e\udfd8\udb2d\udc2b",
        -3, -1000, 0, 814197504L, 12090L, false, false, (char) 107, (char) 0,
        Double.longBitsToDouble(0x3feef170052c2728L), Double.longBitsToDouble(0x3fc1ae886f88d000L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 6, 2, "\ud9aa\uddaa\uda7d\uddb4\udaf6\udd6e\udb83\udcd5\uda9b\udd0d\ud88d\udfd1\udb66\udfaa\ud851\udeb8", "\ub970\u170b\ub08d\u58c1\u0250\u2b8a", "\udbd0\udefb\udba3\udd7c\udba5\ude11\ud816\uddca\ud86e\udfd8\udb2d\udc2b",
        39, 59399, 16438442, 0L, 12090L, false, true, (char) 15975, (char) 16302,
        Double.longBitsToDouble(0x3feef1748d2c2728L), Double.longBitsToDouble(0x3fec6ba21be23429L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 7, 8, "\udb6f\ude6c\udaf1\udfaf\ud87b\udc70\uda73\udff2\ud9cf\ude89\uda08\udfdf\000\000", "\u2749", "\uda97\udc10\udbfd\udf00\ud981\ude1d\ud915\uddef\u1259\udb74\udeed\udba3\udd7c\udbeb\udd4e\ud816\uddca\ud86e\udfd8\udb2d\udc2b\uda04\udc1c\uda0b\udd86\udb16\udf21\ud826\uddd0",
        19, 64935, 2072360410, -1915347831298500357L, -66498L, false, true, (char) 3368, (char) 4143,
        Double.longBitsToDouble(0x3fdbdd7da19f1d88L), Double.longBitsToDouble(0x3fb7e6ce95548e30L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 1, 3, "\udb6f\ude6c\udaf1\udfaf\uda27\udc06\uda91\udc7b\ud9cf\ude22\uda08\udfdf\uda39\udd07\udb7d\udc9d", "\u2749\u19af\u2c84\u58c1\u38db\u8391\u51e1\ub6f0", "\udb93\uddc3\ud816\uddca\ud86e\udfd8\udb2d\udc2b\uda04\udc1c",
        39, 29978, 1293432133, 3496952188043482119L, 55253L, false, false, (char) 23448, (char) 3368,
        Double.longBitsToDouble(0x3fef11a26dbdd7daL), Double.longBitsToDouble(0x3fc9f1d8917e6ce8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 7, 8, "\udb6f\ude32\udaf1\udfaf\ud805\udd16\uda1a\ude0f\udb8c\udd07\ud9ec\udd36\udba0\udd00\udb7d\udc9d", "\u2749\u8437\u7655\u0bf0\u3f0a\u5458\u7139\u7b71", "\udbeb\udd4e\ud816\uddca\ud86e\udfd8\udb2d\udc2b\uda04\udc1c\uda0b\udd86\udb16\udf21",
        1, 46733, 1573540357, 8914364798912385356L, 55253L, false, false, (char) 23448, (char) 3243,
        Double.longBitsToDouble(0x3fef11a268bcf1daL), Double.longBitsToDouble(0x3fe16c7624d3f615L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 2, 8, 8, 1, "\udb6f\ude6c\ud8f8\udfae\ud87b\udc70\uda73\udff2\uda32\udf8d\ud895\uded1\uda35\udf64\uf6eb", "\u2749\u19af\ub08d\u58c1\u0250\u8391\u4951\u829a", "\udbeb\udd4e\ud816\uddca\uda3a\udd7e\uda22\ude4c\uda04\udc1f\uda0b\udd86\udb16\udf21",
        53, 35629, -992259065, 8900720186195202380L, 55253L, false, false, (char) 23448, (char) 3368,
        Double.longBitsToDouble(0x3fde2344d2cb8c9eL), Double.longBitsToDouble(0x3fed694a1e911ccdL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Long:887 |a0=[B:[[-85, -45, 62, 68, -58, 62, 1, 114]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud9db\udf03\ud96e\udd74\udaf6\udd6e\uda31\udea2\ud97a\uddcf", "\u3ebf\u5b74\u06bd\u0895\u8e3f\u4da3\u1a23\ub9e7\u2b8a\uc67e\u22cd", "\ud9b1\udd51\ud816\uddca\ud86e\udfd8\ud870\udf0d\ud8bd\udc57\ud8b9\ude4b\u6cbc",
        2, 48021, 1707955451, 4417272606982232981L, -43683L, true, true, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429e1f21d7L), Double.longBitsToDouble(0x3fe2a73168ea7b3eL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 7, 1, "\ud8eb\udf8b\034\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\ud88d\udfd1\uda97\ude42", "\000", "\ud8a4\udc01\ud8d6\ude39\u7e72\u5e09",
        0, 12126, 569327868, -8430531371604977867L, 60047L, true, true, (char) 49886, (char) 46776,
        Double.longBitsToDouble(0x3fe303f225fe6833L), Double.longBitsToDouble(0x3fd7d4d189f6610eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\012",
        Z.run(T, 1, 8, 7, 8, "\ud8eb\udf8b\ud96e\udd83\udaf6\udd6e\ud872\ude4d", "\u3067\ua9b1\u4eb2\u06d0\u3211\u8d5d\u4da3\ud6c7\ub9e7\u2b8a\u6380\uc667\u2934", "\ud812\udd67\udb4f\udd27\udaa9\udf15\uda4d\udda3\udbca\udcd3\u6c84\ud83a\ude89\ud845\udc59\uda75\ude4b\ud898\ude00\u64ec\ud8a8\udd6f\ud8ac\ude09\udb64\uded7",
        5, 94107, 918059362, -2762180938421204698L, 64911L, false, true, (char) 43653, (char) 5592,
        Double.longBitsToDouble(0x3f89c81eb8485c40L), Double.longBitsToDouble(0x3fd122d982e5c0f2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 2, 8, "\ud9a1\udcf6", "\uca88\uc707\u11ab\u3067\u81e5", "\ud98f\udf56\udba4\ude99\udb36\udc4e\ud878\udf40\ud990\udf2e\udb67\udcbf",
        1, 56654, 569327760, -8430531371604977867L, 60047L, true, true, (char) 37415, (char) 18719,
        Double.longBitsToDouble(0x3fc54086d7f9a214L), Double.longBitsToDouble(0x3febea68c4073087L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:-412 |a1=[B:[[-1, 123, 55, 17, -9, -28, 64, -37]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 2, 5, "\ud9aa\uddaa\uda86\uded6", "\u072f\u11ab\u3067\u1441\u4927\u6314\ub970\u170b\ub08d\u6144\ua34c\u5d5e\ubc12\ubb29\u28c8", "\ud816\uddca\ud86e\udfd8\udb2d\udc2b\uda37\udf65\uda0b\udd86\udb16\uded9\ud83a\ude89\ud865\ude59\ud8be\udf9b\ud9ff\udcb7\udbf1\udfba\uda4c\udf36\uda27\udc49\udb09\ude2c",
        7, -419, 424139746, 8903624596918189641L, -70236L, true, true, (char) 35930, (char) 18119,
        Double.longBitsToDouble(0x3fe2b60e11c9a644L), Double.longBitsToDouble(0x3fea6b77ca8bbbdeL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 4, 0, "\ud9aa\uddaa\ud9aa\udca8\ud915\udc88\ud872\ude4d\ud81a\udc4e\ud88d\udfd1\uda97\ude42\ud851\udeb8", "\u088d\u0cc1\ub08d\ua243\ua34c\u1848", "\udbd0\ude8f\uda05\udf6d\ud9b1\udd1e\udb74\udd7a\ud86e\udfd8\udb2d\udc2b\uda37\udf65\ud9fb\udf7f\uda14\udce2\ud83a\ude0e\udb0c\udf53",
        7, 16702, -1352733713, 1804697799171875211L, -72854L, true, true, (char) 9164, (char) 48808,
        Double.longBitsToDouble(0x3fd064dfb58227d8L), Double.longBitsToDouble(0x3fe527110385220fL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Long:244 |a0=[B:[[122, 122]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 8, "\ud9aa\uddaa", "\uca88\uc71a\u11ab\u00a3\000\u5669\u48a5\ub970\u170b\ub08d\u8c4f\000\000\u82f9\uc667\u2934\u43b7\u6a1c\ud5d7\ub5cd\ucb90\u00bf\u8cfd\u3116\ub95d\u8501\007", "\uda4c\udf36\uda27\udc49\ud8df\udf47\udb3d\udc19\udbe4\udecc\udbec\ude1c\ud993\uddb5\ud809\udf5a\ud8f6\udf96\uda33\udebd\ud8a7\udfbf\ud9f3\udee0\uda48\ude9d\udb01\udcc5",
        9, 93942, -1932359969, 3263993116880825504L, 58443L, true, true, (char) 25332, (char) 62577,
        Double.longBitsToDouble(0x3fe0d778d9c663b1L), Double.longBitsToDouble(0x3fef924f1c31e2c1L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 6, 8, "\udb88\ude96\ud94b\udf70\udaf6\uddac\ud889\uddb8\udb09\ude86\ud9c2\udd8a\udbe0\udd37\uda9a\udfd9", "\ub970\u69b4\ub08d\u58c1\u0250\u2b8a\ua879\uc6b2", "\ud88a\udc5e\ud8aa\udd88\ud9f7\udd76\udb2d\udc2b\uda63\udeeb",
        5, 29906, 1293452798, 3496952190224520199L, 55253L, false, true, (char) 37866, (char) 43052,
        Double.longBitsToDouble(0x3f9c14296bfc3900L), Double.longBitsToDouble(0x3fec893d543c4097L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[122, 122, -101, -117, -58, 62, 119, -97]]\0121=java.lang.Integer:-343 |a1=[B:[[64, -37, 64, -111, 32, 90, 80, 55]]\012",
        Z.run(T, 2, 7, 4, 8, "\ud9aa\uddaa\ud8cb\uddbb\udaf6\udd6e\ud8a7\uddcf\uda38\udc15\udaba\uddaa\uda81\udef6\uda9a\udfd9", "\ub970\u170b\uc170\u58c1\u0250\u2b8a\u8380\uc667\u2934", "\ud816\uddca\ud86e\udfd8\ud92a\udfd7\uda03\udf90\uda0b\udd86\udb16\uded9\ud83a\ude89\ud865\ude59\udbf0\udc33\ud9ff\udd21\u5bbb\udb1f\udcad\uda0d\udcec\ud8df\udf47",
        31, -374, -516652471, 2858258950828839825L, -45854L, false, false, (char) 50582, (char) 28494,
        Double.longBitsToDouble(0x3fba47bb59fe1230L), Double.longBitsToDouble(0x3fe2f0be6ee495d8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:I\u00f0 |a0=[B:[[73, -16, 0, 17, 24, -28, 66, 29]]\012",
        Z.run(T, 1, 0, 6, 2, "\ud979\udf20\ud930\udf41\uda48\udd14\ud872\ude4d\ud9cf\ude89\uda75\ude7c\uda0a\udd87\udaa7\udee7", "\u59ad\uc6f2\u2aba\ub0cd\u606d\u0a7c\u5d7e\u55b7", "\ud9b1\udd51\ud9a6\ude25",
        0, 1983, 329958348, 331604197173052330L, 44349L, false, true, (char) 26726, (char) 46328,
        Double.longBitsToDouble(0x3febd26421b2d954L), Double.longBitsToDouble(0x3fe6d5c2d360429fL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 4, 4, 4, "\ud979\udf20\ud930\udf41\ud8d5\uddd5\ud872\ude4d\ud9cf\ude89\ud958\ude80\uda0a\udd97\ud964\udded", "\u59cf\u518d\u2aba\u0f8b\ua7d0\ud189", "\udb22\udddd\udbff\udfa2\ud9f4\ude77\ud81f\ude85\ud88a\udfc5\udb46\udf5b",
        4, 79900, -1803507798, 8742693823719111593L, 34822L, false, true, (char) 16383, (char) 46328,
        Double.longBitsToDouble(0x3febd26380e1b954L), Double.longBitsToDouble(0x3fcac78b4cc8d23cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 8, "\ud9aa\uddda", "\u957f\u7bda\u11ab\u74cf\u13e5\ubc6f\u6314\ub970\u7417\ub77a\u58c1\u47ab\000\u82f9\uc667\u2934\ubc62\u69e7", "\udb64\udda6\uda04\udc1c\ud9dc\udd22\udb16\uded9\ud83a\ude89}",
        0, 7930, 716936074, -7051694756471987829L, 87362L, true, false, (char) 64976, (char) 2630,
        Double.longBitsToDouble(0x3fece9a51af5c604L), Double.longBitsToDouble(0x3fed8507d8f0ebddL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Integer:-405 |a1=[B:[[42, 64, 55, 4]]\0121=java.lang.Integer:-405 |a1=[B:[[42, 64, 55, 4]]\012",
        Z.run(T, 2, 4, 4, 8, "\ud882\ude6f\udad2\udf41\udaf6\udd6e\ud872\ude4d\udb29\uded5\ud88d\udfd1\ud84a\udf3b\ud851\udeb8\udaff\udcf5\ud999\ude8c\ud98f\udf56\udba4\ude99\udb36\udc4e", "\ua45a\u8370\uc667\u2934", "\ud816\uddca\udaac\ude6b\udb2d\udc2b\uda04\udc1c\ud9dc\udd22\udb16\uded9\ud83a\ude89\ud865\ude59\udbf0\udc33\udbb4\udf5c\udaaf\ude0e\uda4c\udf36\uda27\udc49\udae5\udf2c",
        14, -419, -1468343326, 6480834547391542987L, -32965L, false, false, (char) 1360, (char) 32625,
        Double.longBitsToDouble(0x3fde44a708bafba8L), Double.longBitsToDouble(0x3faf2e6946e852c0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Long:208 |a0=[B:[[-48]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 5, 3, "\000", "\ub1fb\u8cb7\u11ab\u3067\000\ubc0d\u6314\ub970\u170b\ub08d\ua471\u0250\u2b8a\000\ua5f0\ub89c\uc07a\u6a1c\ud5d7\u5c54\ucb90\u7ffb\ub9fd\u3116\uab42\ub200\u7903", "\000\ud9fe\udebe\uabde\u9d2c\udba6\udf12\uda7b\udfc4\udbd1\udcb0\ud57e\ud859\udd92\ud9ff\udf5a\ud8fb\udce4\ud84d\udef3\ud8b2\udfd3\udb25\udfb2\ud932\udffd\udacb\udcd1\ud801\udc9a\ud974\ude9a\ud9ea\udeac\ud919\udc6d\ud94a\udcf9\ud9fd\udec6\udb01\udcb5\ud8c4\uddf1\udbf6\udc3f\udb68\ude48\udb10\udddb\uda4d\ude5c\ud87f\udd26\ub12b\udb61\udd6c\ud95f\udd8e\ud83e\ude7d\ud9b2\udda3\ud97f\udde5\ud822\ude6b\ud9e0\udf41\udac0\udd4e",
        38, 84354, -320856191, -3802811764363504053L, -30969L, false, false, (char) 46810, (char) 21416,
        Double.longBitsToDouble(0x3fe66a403b367ac6L), Double.longBitsToDouble(0x3fe5e0157c591433L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Long:331 |a0=[B:[[-20, 30, 21, 44]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 5, "\uda1c\udf4e\ud945\udf5c", "\uc71a\u684a\u6501\u145d\ubc6f\u62bc\ub970\u170b\ub08d\u58c1\u0250\u2b8a\u3606\uc2d8\u5bb0\u0bc9", "\ud98d\uded4\udb2d\udc71\uda04\udc1c\uda0b\udd86\udb16\uded9\ud83a\ude89\ud903\udca9\ud858\udd0d\ud9ff\udd21\udbaa\udf16\uda6e\ude2d\uda27\udc49\udae5\udc2c\udaf3\udf79\ud8e7\udc48\uda66\uddf8\ud915\udf0d\uda79\udfcb\udb03\udf26\uda99\udc8b\ud83a\uddd8\ud839\udf4f\udb88\udf4d\udac4\udfd0\ud8eb\udd0f\uda54\udd86\ud9ca\udf31",
        1, 26180, -626936182, 6077242889547186734L, -57160L, true, false, (char) 18760, (char) 34512,
        Double.longBitsToDouble(0x3f9d42eaa6712bc0L), Double.longBitsToDouble(0x3fe4d7a87fa7d06bL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarUtils:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 8, "\ud9aa\uddaa\uda54\udf18\udaf6\udd6e\ud872\ude4d\ud9cf\ude89\uf3e8\000\000", "", "\000\udb32\ude98",
        22, 25550, 0, 0L, -100000L, false, true, (char) 53841, (char) 59945,
        Double.longBitsToDouble(0x3fedfd55a0b50633L), Double.longBitsToDouble(0x3fc54088acff2d8cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\u00fe^8 |a0=[B:[[-99, 76, -55, 75, -2, 94, 56, 0]]\0121=java.lang.String:\u00fe^8 |a0=[B:[[-99, 76, -55, 75, -2, 94, 56, 0]]\012",
        Z.run(T, 2, 0, 0, 8, "\ud8cd\udf7c\udbf9\udf7b\ud92e\udd8e\udb68\udc30\uda88\udf07\ud837\udee2\uda80\udf3b\ud866\udcb8", "\u5722\uc76e\ub08d\u58c1\ud088\000", "\udbd0\udefb",
        4, 47749, 1371260153, -6528406164707769947L, 42663L, false, false, (char) 61175, (char) 29845,
        Double.longBitsToDouble(0x3f7cc10280000000L), Double.longBitsToDouble(0x3fd4c7b851f7cad6L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Integer:-1005\0121=java.lang.Integer:-1005\012",
        Z.run(T, 2, 4, 4, 2, "", "\000\u3509\ube2d\u13e9\u3067", "\ud873\udd27",
        -5, -1000, 0, 206970179026944L, 32827L, false, false, (char) 24831, (char) 8687,
        Double.longBitsToDouble(0x3fe8000003199b1bL), Double.longBitsToDouble(0x3fd2f518800000ccL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 0, "", "\000\u3509\ube2d\u13e9\u3067", "\ud906\ude7d",
        8, 22512, 0, 6040378495412994048L, 32743L, false, false, (char) 24831, (char) 56980,
        Double.longBitsToDouble(0x3fcd2f1640019f98L), Double.longBitsToDouble(0x3fd2f51bb117466eL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=java.lang.Long:0\012",
        Z.run(T, 2, 7, 7, 7, "", "\000\u3509\ube2d\u13e9\u3067", "\ud889\udcd7",
        -5, -1000, 0, 206970179026944L, 32743L, false, false, (char) 24831, (char) 20601,
        Double.longBitsToDouble(0x3fe80000000067b2L), Double.longBitsToDouble(0x3fd2f51bb00000ccL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 3, 4, "\ud9aa\udde1\uda71\ude8f\udae0\uded2", "\u01ea\u639d\u13e5\ubc6f\u6314\ub970\u170b\ub08d\u58c1\u1e14", "\ud953\uddb9\udb81\udedf\ud860\udcf0\udbce\ude40\ud851\udcd0\uda7f\udd9f",
        1, 83759, 889728129, 1246955494109119956L, -12953L, false, true, (char) 53236, (char) 52848,
        Double.longBitsToDouble(0x3fe006048c56fb14L), Double.longBitsToDouble(0x3f92d1d324c6d660L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 2, 2, "\ud9a7\udeb4\u3609\ud962\udcb2\ud86b\udd73\uabfd\ud86d\udc1f\u192f\ud851\uded5", "\u2adb\u626a\u44eb\ua29b\u3bf0\u8d8f", "\udb06\udef6\udba3\udd7c\uda56\ude0f\ud938\udc9d\ud86e\udff3\uda4d\udf9a\ud856\udefe\ud92a\udd63\ud8c7\udd0f\ud8bf\udd3c\ud865\ude59\ud946\ude07\ud9ff\udd1b",
        3, 94669, 781296011, 2821694138469293356L, 32660L, true, true, (char) 6792, (char) 34059,
        Double.longBitsToDouble(0x3fe89a20c8dfa705L), Double.longBitsToDouble(0x3fe0450d6d962799L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Long:915 |a0=[B:[[6, 32, -28, 19, -46, -58, 37, -71]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud936\ude50\udb14\udd43\udb02\uddf6\ud955\udde9\udac7\udd7f", "\u7366\u1752\u0679\u0895\u8e3f\u4da3\u1a23\ub9e7\u2b8a\u5db5\u22cd\u2891\u79b7\u6a1c\ud5d7\ub5cd\u150c\u9534\u7c13\u9a17\u4ec2", "\udb4e\udda4\udafd\udfc7\ud92f\udd12\ud8bd\udc9f\ud833\udd58\ud8f7\uddf1\ud94f\udfe9",
        1, 85319, 2067693140, -8103901067646049472L, 74731L, false, false, (char) 28629, (char) 46935,
        Double.longBitsToDouble(0x3fe534c79800bb5dL), Double.longBitsToDouble(0x3fe4b708d06b15fdL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Long:844 |a0=[B:[[-85, -45, 32, 55, -58, 62, 1, 114]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud9db\udf03\ud950\udd67\udaf6\udd6e\uda31\udea2\ud97a\uddcf", "-\u5b74\u06bd\u0895\u8e3f\u4da3\ud722\ub9e7\u2b8a\uc67e\u22cd", "\ud9b1\udd51\ud816\uddca\ud86e\udfd8\ud870\udf0d\ud8bd\udc57\ud8b9\ude4b\u6cbc",
        2, 48021, 1707955451, 4417272606982232981L, -43683L, true, true, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429e1f21d7L), Double.longBitsToDouble(0x3fe2a73168ea7b3eL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Long:944 |a0=[B:[[-85, -45, 0, -26, 71, -110, 1, 114]]\0121=java.lang.Long:0 |a0=[B:[[-85, -45, 0, -26, 71, -110, 1, 114]]\012",
        Z.run(T, 2, 1, 7, 1, "\ud9db\udf03\uda30\ude16\ud977\uddc2\uda31\udea2\ud97a\uddcf", "\u3ebf\u5b74\u0658\u0895\u5806\u4da3\ub423\ub9e7\u2b8a\uc67e\u22cd", "\ud9b1\ude00\udb16\udf2a\ud86f\udc0e\ud870\udf0d\ud8bd\udc57\ud8b9\ude4b\u6cbc",
        2, 99605, 1707955451, 4417272606982232981L, -43683L, true, false, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429fb121d7L), Double.longBitsToDouble(0x3fcfcecb43a9ef20L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Long:244 |a0=[B:[[122, 122]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 4, 5, "\ud9aa\uddaa", "\u2c12\u0527\u7341\u91df\u2cfd", "\ud833\udf6d\ud9a3\udd41\udb36\udc4e\ud9e4\ude3a\ud835\udee1",
        1, 10782, 1510203848, 2392045337775987159L, -84641L, false, true, (char) 9995, (char) 54110,
        Double.longBitsToDouble(0x3fe930319a7d9daeL), Double.longBitsToDouble(0x3fd83e4cb7b29a30L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 1, 8, "\uccc5", "\u957f\u7bda\u11ab\u74cf\u13e5\ubc6f\u6314\ub970\u35e9\u60e9\ub356\u47ab\000\u3350\uc606\u2934\ubc62\u69e7", "\udb64\udda6\uda04\udc1c\ud9dc\udd22\udb16\uded9\ud83a\ude89}",
        0, 7930, 716936074, -7051694756471987829L, 1056L, true, false, (char) 64976, (char) 2630,
        Double.longBitsToDouble(0x3fece9a092f5c604L), Double.longBitsToDouble(0x3fed8507d8d3654bL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 2, 2, "\ud9a7\udeb4\u3609\uda66\udc74\ud843\udd4d\uabfd\ud86d\udc1f\u192f\ud851\uded5", "\u2adb\u626a\u44eb\ua29b\u3bf0\u8d8f", "\udb06\udef6\udba3\udd7c\uda56\ude0f\ud938\udc9d\ud86e\udff3\uda4d\udf9a\ud856\udefe\ud92a\udd63\ud8c7\udd0f\ud8bf\udd3c\ud865\ude59\ud946\ude07\ud9ff\udd1b",
        3, 94669, 781296011, 2821694138469293356L, 32660L, true, true, (char) 6792, (char) 34059,
        Double.longBitsToDouble(0x3fe89a20c8dfa705L), Double.longBitsToDouble(0x3fe0450d6d962799L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:910 |a0=[B:[[39, 48, 102, 91, -46, -58, 37, -71]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud957\udc60\ud996\udd8b\udb02\uddf6\ud955\udde9\udac7\udd7f", "\u7366\u1752\u0679\u0895\u8e3f\u4da3\u1a23\ub9e7\u48df\u5bb5\u22cd\u2891\u7979\u6a1c\ud5d7\ub5cd\u156c\u9534\u7c13\ua48a\uc9ed", "\udb4e\udda4\udafd\udfc7\ud92f\udd12\ud8bd\udc9f\ud833\udd58\ud8f7\uddf1\ud94f\udfe9",
        1, 85319, 2067693140, -8103901067646049472L, 74731L, true, false, (char) 64132, (char) 46935,
        Double.longBitsToDouble(0x3fe534c79800bb5dL), Double.longBitsToDouble(0x3fe4b708d06b15fdL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Long:879 |a0=[B:[[-85, -45, 32, 55, 51, -12, 1, 114]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud9db\udf03\ud950\udd67\udb63\ude24\uda31\udea2\ud97a\uddcf", "-\u5b74\u06bd\u0895\u7718\u4da3\ud722\ub9e7\u2b8a\uc67e\u22cd", "\ud9b1\udd51\ud816\uddca\ud86e\udfd8\ud870\udf0d\ud8bd\udc57\ud8b9\ude4b\u6cbc",
        2, 48021, 1707955451, 4417272606982232981L, -43683L, true, true, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429e1f21d7L), Double.longBitsToDouble(0x3fe2a73168eae67dL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-85, -45, 0, -26, 71, -110, 1, 114]]\0121=java.lang.Long:0 |a0=[B:[[-85, -45, 0, -26, 71, -110, 1, 114]]\012",
        Z.run(T, 2, 7, 7, 1, "\ud9db\udf03\uda30\ude16\ud977\uddc2\uda31\udea2\ud97a\uddcf", "\u3ebf\u5b74\u0658\u0895\u5806\u4da3\ub423\ub9e7\u2b8a\uc67e\u22cd", "\ud9b1\ude00\udb16\udf2a\ud86f\udc0e\ud870\udf0d\ud8bd\udc57\ud8b9\ude4b\u6cbc",
        2, 99605, 1707955451, 4417272606982232981L, -43683L, true, false, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429fb121d7L), Double.longBitsToDouble(0x3fcfcecb43a9ef20L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 6, 8, "\ud9aa\uddaa\ud8cb\uddbb\udb1e\udc6e\ud84f\udd49\ud9ed\udc96\ud88d\udfd1\uda97\ude42\udb0d\udfd6", "\ub970\u170b\u1522\ubfce\u0250", "\u122c\udbd0\udefb\udba3\udd27\udae1\udd49\ud816\uddca\ud86e\udfd8",
        47, 83759, 70659399, 7564592352025150974L, 55253L, false, true, (char) 34644, (char) 7395,
        Double.longBitsToDouble(0x3fef13d94bb52e72L), Double.longBitsToDouble(0x3f921e2e95056700L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Long:837 |a0=[B:[[39, 48, 32, 88, -46, -58, 37, -71]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud957\udc60\uda50\ude88\udb02\uddf6\ud955\udde9\udac7\udd7f", "\u7366\u1752\u0679\u0895\u8e3f\u4da3\u1a23\ub9e7\u48df\u5bb5\u22cd\u2891\u7979\u6a1c\ud5d7\ub5cd\u156c\u9495\u7c13\ua48a\uc9ed", "\udb4e\udda4\udafd\udfc7\ud92f\udd12\u00fd\ud833\udc7f\ud8f7\uddf1\ud94f\udfe9",
        1, 85319, 2067693140, -8103901067646049472L, 74731L, true, false, (char) 64132, (char) 46935,
        Double.longBitsToDouble(0x3fe534c79800005dL), Double.longBitsToDouble(0x3fe4b708d06b15fdL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Long:821 |a0=[B:[[-85, -45, 32, 32, -58, 62, 1, 114]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud9db\udf03\ud950\ude50\udaf6\udd6e\uda31\udea2\ud97a\uddcf", "-\u5b74\ua708\u4834\u737c\u041f\uc0b8\ub9e7\u2b8a\u0d59\u707b", "\ud9b1\udd51\ud816\uddca\ud86e\udfd8\udac2\udf36\ud8bd\udc57\ud8b9\ude4b\uecbc",
        2, 75525, 984090752, 4417272920514845589L, -82339L, true, true, (char) 16991, (char) 52979,
        Double.longBitsToDouble(0x3fe45552061f21d7L), Double.longBitsToDouble(0x3fe2a73168ea7b3eL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Long:660 |a0=[B:[[-85, -45, 32, 55, 32, 44, 1, 114]]\0121=java.lang.Long:7 |a0=[B:[[-85, -45, 32, 55, 32, 44, 1, 114]]\012",
        Z.run(T, 2, 1, 7, 1, "\ud9db\udf03\ud950\udd67\ud950\ude5c\uda31\udea2\ud97a\uddcf", "-\u5b74\u06bd\u0895\u8e3f\u4da3\ud722\ub9e7\u2b8a\uc67e\u22cd", "\ud9b1\udd51\ud816\uddca\ud86e\udfd8\ud870\udf0d\ud8bd\udc57\ud8b9\ude4b\u6cbc",
        2, 48021, 1707955451, 4417272606982232981L, -43683L, true, true, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429e1f21d7L), Double.longBitsToDouble(0x3fe2a73168c87b3eL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Long:856 |a0=[B:[[39, 48, 48, 91, -46, -58, 37, -71]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 0, "\ud957\udc60\ud960\udd8b\udb02\uddf6\ud955\udde9\udac7\udd7f", "\u7366\u1752\u0679\u0895\u8e3f\u64fd\u87f0\ub9e7\u48df\u5bb5\u22cd\u2891\u7979\u6a1c\uaf32\ub5cd\u156c\u9534\u16cb\u9feb\u8f46", "\udb4e\udda4\udafd\udfc7\ud92f\udd12\ud8bd\udc9f\ud833\udd58\ud8f7\uddf1\ud94f\udfe9",
        1, 85319, 2067693140, -8103901067646049472L, 74731L, true, false, (char) 64132, (char) 46935,
        Double.longBitsToDouble(0x3fe534c79800bb5dL), Double.longBitsToDouble(0x3fe4b708d06b15fdL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Long:7 |a0=[B:[[-85, -45, 32, 55, 32, 44, 1, 114]]\0121=java.lang.Long:7 |a0=[B:[[-85, -45, 32, 55, 32, 44, 1, 114]]\012",
        Z.run(T, 2, 7, 7, 1, "\ud9db\udf03\ud950\udd67\ud950\ude5c\uda31\udea2\ud97a\uddcf", "-\u5b74\u06bd\u0895\u8e3f\u4da3\ud722\ub9e7\u2b8a\uc67e\u22cd", "\ud9b1\udd51\u39c7\ud86e\udfd8\ud870\udf0d\ud8bd\udc57\ud8b9\ude4b\u6cbc",
        2, 48021, 1707955451, 4417272606982232981L, -43683L, true, true, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429e1f21d7L), Double.longBitsToDouble(0x3fe2a73168c87b3eL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=java.lang.String:\u009dL\u00c9K\u00fe^8 |a0=[B:[[-99, 76, -55, 75, -2, 94, 56, 0]]\0121=java.lang.String:\u009dL\u00c9K\u00fe^8 |a0=[B:[[-99, 76, -55, 75, -2, 94, 56, 0]]\012",
        Z.run(T, 2, 0, 0, 8, "\ud8cd\udf7c\udbf9\udf7b\ud92e\udd8e\udb68\udc30\uda88\udf07\ud837\udee2\ud973\uddd1\udad2\udeda", "\u5722\uc76e\ub08d\u58c1\ud088\000", "\u8645",
        0, 47749, 1371260153, -6528406164707769947L, 42663L, false, false, (char) 61175, (char) 29845,
        Double.longBitsToDouble(0x3f7cc10280000000L), Double.longBitsToDouble(0x3fd4c7b851f7cad6L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Long:682 |a0=[B:[[-85, -45, 32, 55, 48, 50, 1, 114]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud9db\udf03\ud950\udd67\udb60\udc62\uda31\udea2\ud97a\uddcf", "\u1838\u7e6e\u06bd\u0895\u8e3f\u4da3\ud722\ub9e7\u2b8a\u20e4\ub6d7", "\ud844\udedb\udbac\udc59\ud821\udea0\ue143\ud8bc\udfec\ud8b9\ude06\u6cbc",
        2, 48021, 1707955451, 4482935518015521159L, -43683L, true, true, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429e1f219bL), Double.longBitsToDouble(0x3fe2a73168c87b3eL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Long:658 |a0=[B:[[-85, -45, 32, 55, 48, 50, 57, 34]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\ud9db\udf03\ud950\udd67\udb60\udc62\uda69\udd52\ud97a\uddcf", "\u5ccd\u3cde\u55fe\ucd75\u37c3\u4da3\ud722\ub9e7\u24b9\u6720\ub6d7", "\ud844\udedb\udbac\udc59\ud821\udea0\uda98\udcf3\ud8bc\udfe7\ud8be\udcbb\u6cbc",
        2, 4333, 436229188, 3795978562994700750L, -43683L, true, true, (char) 28187, (char) 45390,
        Double.longBitsToDouble(0x3fe451429e1f219bL), Double.longBitsToDouble(0x3fe2a73168c87b3eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseName|[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|computeCheckSum|[B|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatCheckSumOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatNameBytes|java.lang.String,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatUnsignedOctalString|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
    "C|org.apache.commons.compress.archivers.tar.TarUtils|<init>|",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseName|[B,int,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
