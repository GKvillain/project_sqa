package org.apache.commons.compress.archivers.ar;
import org.junit.Test;
import static org.junit.Assert.*;
public class ArArchiveInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\ud91f\udf40\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua7ac", "\uda5b\udea0\ud9f1\udcc4\udba9\udc4b",
        29, 84207, 1811201283, 4524728174538624230L, -66782L, false, false, (char) 60048, (char) 25321,
        Double.longBitsToDouble(0x3fe48da332a4ea78L), Double.longBitsToDouble(0x3fe8de439bac1b9bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\ud91f\udf40\uda4a\uddab\ud8a4\udc96\ud81f\udfa1\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud935\udf24\ud8f4\udd06\uda39\udce2", "\ua7ac", "\uda5b\udea0\ud9f1\udcc4\udba9\udc4b",
        29, 84207, 1811201283, 4524728174622510310L, -66782L, false, false, (char) 60048, (char) 25321,
        Double.longBitsToDouble(0x3fe48da332a4ea78L), Double.longBitsToDouble(0x3fe8de439bac1b9bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 8, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\uda5d\udef8\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua7ac", "\uda5b\udea0\ud9f1\udcc4\udba9\udc4b",
        29, 84207, 1811201283, 4524728174538624230L, -66782L, false, false, (char) 60048, (char) 25321,
        Double.longBitsToDouble(0x3fe48da332a4ea78L), Double.longBitsToDouble(0x3fe8de439fac1b9bL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 9, 4, "\udb23\udd71\udab4\ude65\uda4b\udd4d\ud91f\udf40\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud92e\udeb6\ud96c\ude84\ud8e8\udc71\udb16\udc92\ud90a\udeab\ud85c\ude14\ud946\udfe5\uda17\udfaa\ud8f9\udf0c\uda39\udce2", "\u6860", "\uda7c\udf98\ud9ec\uddd1\udba9\udc4b\ud84c\udd7a",
        37, 68283, 1053495373, 4364987381699976660L, 91861L, true, false, (char) 44316, (char) 13328,
        Double.longBitsToDouble(0x3fed60dcdefe3b11L), Double.longBitsToDouble(0x3fecc6843ca553b4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 9, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\ud91f\udf40\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud820\udfee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14\ud991\ude7c\udb24\udec5\ud89b\udf7b\uda39\udce2", "\ua7ac", "\uda5b\udea0\ud9f1\udcc4\ud83d\udfd5",
        33, 78766, 630586428, 4524728866028358886L, -66782L, false, false, (char) 60034, (char) 25321,
        Double.longBitsToDouble(0x3fe48da332a4ea78L), Double.longBitsToDouble(0x3fe8de439bac1b9bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 9, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\ud91f\udf40\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\uddda\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\u8a7d\ud96c\ude98\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua7ac", "\uda5b\udea0\ud9f1\udcc4\udba9\udc4b",
        29, 84207, 1811201283, 4524728174538624230L, -66782L, false, false, (char) 60048, (char) 11741,
        Double.longBitsToDouble(0x3fe1c88c8aa4ea78L), Double.longBitsToDouble(0x3fe8de439bac1b9bL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\ud91f\udf40\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud944\ude3e\000\000\000\000\000\ud948\udc83\ud96c\ude84\u008d\uda04\udf81\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua7ac", "\udba9\ude27\udbe9\udc94\udba9\udc4b",
        29, 84207, 1811201283, 4524728174538624230L, -66782L, false, false, (char) 60048, (char) 30185,
        Double.longBitsToDouble(0x3fe0000002a4ea78L), Double.longBitsToDouble(0x3fe8de4398000000L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 1, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\ud91f\udf40\udb87\udf6a\ud9e9\ude19\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\udb64\udff5\uda4e\udde2\uda10\udd0c\ud969\udfcc\uda08\udf4c\ud8e8\udc92\udac8\udc22\uda02\udd4f\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua7ac", "\uda5b\udea0\ud9f1\udcc4\udba9\udc4b",
        29, 84207, 1811201283, 4524728173741673265L, -66782L, false, false, (char) 7825, (char) 45995,
        Double.longBitsToDouble(0x3fdf1f6b3549d428L), Double.longBitsToDouble(0x3fe8de439bac1b9bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 2, 0, "\udbcf\udee4\ud8ad\uded1\uda19\ude85", "\u9a5c", "\ud9bc\udd5e\ud892\udcc5\ud825\udd7b\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\uda54\udec7\ud971\ude7c\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2\ud969\udc4b\udb67\uddc3\ud820\udf19",
        8, 79045, -881487085, -6497365902708398277L, -64383L, true, true, (char) 31809, (char) 52058,
        Double.longBitsToDouble(0x3fdd43c93a913e94L), Double.longBitsToDouble(0x3fc2f98b18fb72e0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ar.ArArchiveInputStream:@?\012",
        Z.run(T, 1, 7, 9, 4, "\ua34e\uda0e\udd03\ud95d\udfaa\ud988\udf0a\ud955\udc26\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\udbe9\uddaf", "\uc27f\uc784\u26c6\u07a7", "\ud8bf\udcf5",
        42, 48294, 957547182, -4911574735265783255L, 1153L, true, true, (char) 31809, (char) 52144,
        Double.longBitsToDouble(0x3fdd43c93a913e94L), Double.longBitsToDouble(0x3fcb224b18fb72e0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-97, -76, 125, -95, -23, 85, -17, 16]]\012",
        Z.run(T, 1, 6, 9, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\ud91f\udf40\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udd08\ud80a\udcee\u7124\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\udbc0\udc26\ud85c\ude14\ud946\udfe5\ud967\udfc8\uda3f\udc8c\uda39\udce2", "\u378e\u0e53\ubc4f\u509a\uabc6\uc7bb\ud716\u7f28\u34f6\u0350\u8cb1\uab34\uab06\u3308\u79d9\u3ad0\ubd7e\u83db\u250d\u10ce\u4bd3\u4ce7", "\udb22\udfbb\ud942\udc00\udb2d\udcb0\udad4\udc11\ud90d\udda4\udba5\udfc9\uda4a\udd60",
        37, 76611, 727984818, -7590275463982504682L, -2877L, true, true, (char) 39136, (char) 19531,
        Double.longBitsToDouble(0x3feaa48e16a2594aL), Double.longBitsToDouble(0x3fe09df1feacebb1L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-97, -76, 125, -95, 74, 38, -17, 16]]\012",
        Z.run(T, 1, 6, 9, 4, "\udbcf\udee4\ud8ad\uded1\ud97a\ude56\ud91f\udf40\udbab\ude1c\ud9ce\udcdc\udb9d\udc26\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\ud97d\uddab\ud90a\ude14\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua7ac", "\uda5f\udea2\ud9f1\udcc4\udba9\udc4b",
        3, 84207, 1811201283, -2536916040269709336L, -66782L, false, false, (char) 60048, (char) 61673,
        Double.longBitsToDouble(0x3fe48da51aa4ea78L), Double.longBitsToDouble(0x3fe8de439ab1da9bL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 9, "\udbcf\udee4\ud8ad\uded1\ud834\udcb9\uda5d\udef8\u588d\ud935\ude0c\ud960\udf17\ud91c\udf39\ud99d\udc0d\ud892\udcc5\uda3e\udd48\udb6d\udef1\udb4e\udc8a\udbdf\ude62\ud8ba\udc75", "\u8cd7\u2ef2\uc27f\uc784\u26c6\u6fde\u12a2\u76ce\u4b4b", "\uf60b\uda5e\udec9\ud9d1\ude9b\ud9f1\udcc4\udba9\udc4b\ud84c\udd7a\ud84c\udc36\udaaa\udf5f",
        3, 84814, -1613864469, 2330841713093813085L, -29749L, true, false, (char) 44316, (char) 13199,
        Double.longBitsToDouble(0x3fed60dcdae31ea5L), Double.longBitsToDouble(0x3feb032b1297a523L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 8, "\udbcf\udee4", "\u2238", "\ud933\udc41",
        27, 88042, -406801869, 1060650557110636645L, 8514L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fd8d000064f52a2L), Double.longBitsToDouble(0x3fefd80460e9717fL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[91, 84, -55, 119]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 8, "\ud88b\udd84\ud9f9\udea7", "\uac94\uc917\u94c9", "\uda41\ude7c\ud80d\udea1\udb6d\udef1\ud867\udeb7\udbdf\ude62\udb85\udfa8\udb66\ude6c\ud980\ude8c\udbf1\udf6f\udbc7\ude28\ud86e\ude11\ud888\udc75\udae5\udec6\u4f6d\ud8f4\udd06\uda39\udce2\udad1\udf53\udaac\udff0\ud9b7\udd85\uda3f\ude0c\uda4b\udd08\uda5b\udecb\ud9f1\udcc4\udba9\udc4b\ud84c\udd7a\uda66\udf50\udba3\ude8b\ud89b\udec8\ud9f2\udc3b\ud8cd\udcb1\ud9a8\ude0d\uda4e\udd94\udbaf\ude25\ud8fc\ude5d\ud9cc\udd30\ud9d2\udd00\ud92f\udd75\uda01\udee6\ud913\ude8a\ud92c\ude18\ud9f8\udd64\ud999\udd50",
        46, 93972, 1713207477, -4391460858265381569L, 64709L, true, false, (char) 42462, (char) 36461,
        Double.longBitsToDouble(0x3fe8e20e23b37276L), Double.longBitsToDouble(0x3fe7f9430a6775ddL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 9, 4, "\ub454", "\u2238", "\ud960\udf17\u917d\000\udb4d\ude86\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14",
        31, 60112, 3025363, -388998415799544582L, -57682L, false, false, (char) 52684, (char) 7154,
        Double.longBitsToDouble(0x3fa1846df0cc6d40L), Double.longBitsToDouble(0x3fdcdd1540016d42L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ar.ArArchiveInputStream:@?\012",
        Z.run(T, 1, 7, 9, 8, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\uda5d\udef8\ud98f\udda0\uda20\uddae\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua7ac", "\uda5b\udea0\ud9f1\udcc4\udba9\udc4b",
        29, 84207, 1760869635, 7322310164364737002L, -66782L, false, false, (char) 60048, (char) 25321,
        Double.longBitsToDouble(0x3fe48da332a4ea78L), Double.longBitsToDouble(0x3fe0de439fac1b11L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 4, 9, 9, "\udbcf\udee4\uda54\udea2\uda19\ude85\uda5d\udef8\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\udb85\ude05\ud9cf\ude39\ud814\udc10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua7ac", "\uda5b\udea0\ud9f1\udcc4\udba9\udc4b",
        29, 33647, 1811201476, 4524728864065424614L, -66782L, false, false, (char) 60048, (char) 25321,
        Double.longBitsToDouble(0x3fe48da3301824e5L), Double.longBitsToDouble(0x3fe0ab45ffac0433L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 9, 4, "\udb7e\udf1d\udab4\uddcb\uda4b\udd4d\ud91f\udf40\udb87\udf6a\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\ud92e\udeb6\ud96c\ude84\ud8e8\udc71\ud814\udfd2\ud90a\ude0c\ud85c\ude14\ud946\udfe5\uda17\udfaa\ud8f9\udf0c\uda39\udce2", "\u6860", "\uda7c\udf98\ud9ec\uddd1\udba9\udc4b\ud84c\udd7a",
        37, 68283, 1053495373, 4364987381699976660L, -78838L, false, false, (char) 38789, (char) 60048,
        Double.longBitsToDouble(0x3fd757574d2368ccL), Double.longBitsToDouble(0x3fe52753c39cc873L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-13, 65, -108, 117]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 10, 4, "\udb23\udd71\udbc4\udca5", "\u4994\uc917\u3ecf", "\ud892\udcc5\ud9e3\udf5a\udb93\ude74\ud867\udeb7\udbdf\ude62\ud818\udd10",
        14, 2919, -1454277235, 471822633807354875L, 22457L, true, true, (char) 16633, (char) 59234,
        Double.longBitsToDouble(0x3fcf5f534cd9e050L), Double.longBitsToDouble(0x3fd4e3676fffea2eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-97, -76, 125, -95, -23, 85, -17, 16]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\ud91f\udf40\udb87\udf6a\ud986\udf47\ud94b\udf83\ud8d1\udede\ud9bc\udd5e\ud892\udcc5\ud820\udfee\udb6d\udef1\ud867\udeb7\udbdf\ude62\ud818\udd10\udb40\udc17\ud859\uddd4\ud8e8\udc71\udb14\udf89\ud90a\udeab\udae8\uddf9\ud959\udd2a\u2000\uda27\udc61\uda39\udd8d", "\ua5d7", "\uda5b\udea0\ud9f1\udcc4\ud83d\udfd5",
        33, 78766, 630586428, 4524728866028358886L, -66782L, false, false, (char) 60034, (char) 25321,
        Double.longBitsToDouble(0x3fe48da333b67b78L), Double.longBitsToDouble(0x3fdee5b1e759b8f2L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-97, -76, -74, -126, -35, -11, -11, -7]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 4, "\udbcf\udee4\udae6\udeb2\ud90d\ude25\ud925\ude29\udb87\udf6a\udb23\ude16\udb91\udcf1\ud912\udf59\udb05\udc80\ud861\udf8c\ud872\udd57\udb6d\udf69\ud867\udeb7\udb87\udcd0\uda39\udc20\u8a7d\ud960\uddd3\ud8be\udcdb\udbfc\udd55\ud8ac\udf75\ud8b8\udfba\ud946\udfe5\ud967\udfc8\uda9f\udc03\uda39\udce2", "\ucb79\u0e51\ubc4f\u209a\u2461\uc7bb\u26d8\u7f28\u14ad\u3ab9\u2c30\ube4f\u0df9\u7f67\u79d9\u3ad0\u49e9\u9d3b\u38b4\u10ce\ubf61", "\udbac\udd5e\uda81\udccf\udbd4\udf94\u97e8\udb19\udfaa\ud985\ude17\ud9f0\udcc2\ud957\uddc8\uda29\udc16",
        12, 19827, 1998267759, -8903582925958774735L, 61511L, false, true, (char) 6801, (char) 52915,
        Double.longBitsToDouble(0x3fe5718b8f64cd29L), Double.longBitsToDouble(0x3fe966c962a91654L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ar.ArArchiveInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 5, 4, "\udbcf\udee4\uda16\ude85\uda19\udef9\ud91f\udf40\udb87\udf6a\udb23\ude16\ud9e7\udf01\ud912\ude33\ud9bc\udd5e\ud944\ude3e\000\000\u00b3\000\000\ud8a0\udfa2\ud96c\ude70\u008d\uda04\udf81\ud90a\udeab\ud85c\ude14\ud946\udfe5\uda09\ude79\udbc6\udd2f\uda39\udce2", "\ua7ac", "\udba9\ude27\udbe9\udc94\udba9\udc4b",
        29, 84207, 1811201283, 4524728174538624230L, -66782L, false, false, (char) 59981, (char) 30185,
        Double.longBitsToDouble(0x3fe47ae57aa4ea78L), Double.longBitsToDouble(0x3fe8de4398000000L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 6, 9, 4, "\udbcf\udee4\ud8ad\uded1\uda19\ude85\000\udb87\udd22\udb23\ude16\ud960\udf17\ud91c\udf39\ud9bc\udd5e\ud892\udd08\ud80a\udcee\u7124\ud867\udeb7\udbdf\ude62\ud818\udd10\ud969\udfcc\ud96c\ude84\ud8e8\udc71\udb14\udf89\udbc0\udc26\ud85c\ude14\ud946\udfe5\ud967\udfc8\uda3f\udc8c\uda39\udce2", "\u378e\u0e53\ubc4f\u509a\uabc6\uc7bb\u76cb\u0a49\u34f6\u0350\u8cb1\uab34\uab06\u3308\u79d9\u3ad0\ubd7e\u83db\u250d\u10ce\u4bd3\ua13a", "\udb22\udfbb\ud942\udc00\udb2d\udcb0\udad4\udc11\ud90d\udda4\u04f7\000",
        -5, -1000, 0, 905291008L, -2877L, true, true, (char) 39136, (char) 19531,
        Double.longBitsToDouble(0x3feaa48e16a2594aL), Double.longBitsToDouble(0x3fe09df1feacebb1L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 8, 8, "\ud88b\udd84\ud9f9\udea7", "\uac94\uc917", "\ud824\ude43\uda41\ude7c\ud80d\udea1\udb6d\udef1\ud867\udeb7\udbdf\ude62\udb85\udfa8\udb66\ude6c\ud980\ude8c\udbf1\udf6f\udbc7\ude28\ud86e\ude11\ud888\udc75\udae5\udec6\u4f6d\ud8f4\udd06\uda39\udce2\udad1\udf53\udaac\udff0\ud9b7\udd85\uda3f\ude0c\uda4b\udd08\uda5b\udecb\ud9f1\udcc4\udba9\udc4b\ud84c\udd7a\uda66\udf50\udba3\ude8b\ud89b\udec8\udb7d\uddc1\ud8cd\udeaa",
        5, 69030, -26771906, 20488683889617481L, 6933L, true, false, (char) 561, (char) 55870,
        Double.longBitsToDouble(0x3fde65b4bab6cad4L), Double.longBitsToDouble(0x3fc95fe998d1529cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-74, 38, -25, -24]]\0121=new org.apache.commons.compress.archivers.ar.ArArchiveInputStream:@?\012",
        Z.run(T, 2, 6, 7, 7, "\ud9e6\udf56\uda17\udc18", "\uc889\uc917\u94c9\uabcc\u366c\u186d\u7ed5\ucb3c\u27ce\u0550\u2ea9", "\ud8a1\uddc6",
        53, 98911, -1944795318, 5922515185512377360L, 59028L, false, true, (char) 43419, (char) 35135,
        Double.longBitsToDouble(0x3fe5722bfc56392dL), Double.longBitsToDouble(0x3fe23376b02308dbL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[91, 88, -55, 119]]\0121=java.lang.Boolean:false |a0=[B:[[91, 88, -55, 119]]\012",
        Z.run(T, 2, 6, 6, 8, "\ud88b\udd88\ud9f9\udea7", "\uac94\uc917\u94c9", "\uda41\ude7c\ud80d\udea1\udb6d\udef1\ud867\udeb7\udbdf\ude62\udb85\udfa8\udb66\ude6c\ud980\ude8c\udbf1\udf6f\udbc7\ude28\ud86e\uddf6\ud888\udc75\udae5\udec6\u4f6d\ud8f4\udd06\uda39\udce2\udad1\udf53\udaac\udff0\ud9b7\udd85\uda3f\ude0c\uda4b\udd08\udb58\udf8a\ud9e6\ude2e\udba9\udc4b\ud84c\udd7a\uda66\udf50\udba3\ude8b\ud89b\udec8\ud9f2\udc3b\ud8cd\udcb1\ud9a8\ude0d\uda4e\udd94\udbaf\ude25\ud8fc\ude5d\ud9cc\udd30\ud9d2\udd00\ud92f\udd75\uda01\udee6\ud913\ude8a\ud92c\ude18\udb5d\udc56\ud999\udd62",
        46, 93972, 1713207477, -4391460858265381569L, 64709L, true, false, (char) 42462, (char) 36461,
        Double.longBitsToDouble(0x3fe8e20e23b37276L), Double.longBitsToDouble(0x3fe7f9430a6775ddL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[91, 84, -55, 119]]\0121=java.lang.Boolean:false |a0=[B:[[91, 84, -55, 119]]\012",
        Z.run(T, 2, 6, 6, 8, "\ud88b\udd84\ud9f9\udea7", "\uac94\uc917\ubec0", "\uda41\ude7c\ud80d\udea1\udb6d\udef1\ud867\udeb7\ud83d\udeb1\ud80c\uddef\udb57\ude5b\ud980\ude8c\udbf1\udf6f\udbc7\ude28\ud86e\ude11\ud888\udc75\udae5\udec6\u4f6d\ud8f4\udd06\uda39\udce2\udad1\udf53\udaac\udff0\ud9b7\udd85\uda3f\ude0c",
        -1, 14054, -959137757, -3362879352988383795L, -15377L, true, false, (char) 42777, (char) 22724,
        Double.longBitsToDouble(0x3fa7bda411426cc0L), Double.longBitsToDouble(0x3fb66e1192cff338L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.ar.ArArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.ar.ArArchiveInputStream:@?\012",
        Z.run(T, 2, 7, 7, 4, "\udbcf\udee4\uda16\ude85\uda19\udef9\ud91f\udf40\udb87\udf6a\udb23\ude16\ud891\ude55\u09c4\ud9bc\udd15\ud944\ude3e\ud8bc\udc3d\u889d\u6c92\000\ud600\ud8a0\udfa2\ud96c\ude70\u008d\uda04\udf81\ud90a\udeab\uda9d\udf34\ud906\udeb3\ud9cf\udeae\udbc6\udc8e\uda39\udce2", "\ua7ac", "\udba9\ude27\udbe9\udc94\udba9\udc4b\udaff\udff0\ud938\ude20\udaaa\udf5f\udab0\udc6a",
        -3, 31348, 307815752, -7074653719756046786L, -40090L, true, false, (char) 15166, (char) 44270,
        Double.longBitsToDouble(0x3fe8de4398000000L), Double.longBitsToDouble(0x3fec9709617048a8L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 5, 11, "\udbcf\udee4\ud836\udc2a\uda19\ude85\ud91f\udf40\udbf4\udee2\udb94\udf6e\ud960\udf0f\ud91c\udf39\ud9bc\udd5e\ud892\udcc5\ud80a\udcee\udb6d\udef1\ud867\udeb7\udbdf\ude62\uda8f\udfed\ud915\udcdc\ud964\uddb0\ud8e8\udc71\udb14\udf89\ud90a\udeab\ud85c\ude14\ud946\udfe5\ud967\udfc8\ud879\udf06\ud9c1\udcc8", "\u7027\u94aa\u310d", "\udba9\udc4b\ud84c\udd7a\ud84c\udc36",
        3, 64373, 1016302822, -6968724676724333240L, -66782L, false, false, (char) 6033, (char) 25321,
        Double.longBitsToDouble(0x3fe48da332a4ea78L), Double.longBitsToDouble(0x3fa56439bac1b9b0L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[33, 14, 66, 55, 68, 78, -17, 16]]\012",
        Z.run(T, 1, 6, 9, 4, "\ud851\udd3e\uda72\udd67\udb74\udf7e\ud91f\udf40\udbab\ude1c\ud9ce\udcdc\udb9d\udc26\ud85a\ude97\ud9bc\udcca\ud89b\udec5\udafe\udd09\u4f60\ud867\udeb7\udbdf\ude62\ud818\udd10\udbe8\udeeb\udac0\uddbe\ucfaf\ud820\ude43\ud8ce\udc12\ud8b0\udc9f\ud969\ude3d\ud967\udfc8\ud8f4\udd06\uda39\udce2", "\ua825", "\uda24\uddfa\ud9d7\udf67\ud934\udec5",
        59, 84207, 1811201283, -2536916042097654808L, -60085L, false, true, (char) 60205, (char) 61673,
        Double.longBitsToDouble(0x3fe48da51aa4ea78L), Double.longBitsToDouble(0x3fe8de439ab1da9bL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|close||new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|getNextArEntry||new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|read||new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|read|[B|new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|getNextEntry||new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|matches|[B,int|static",
    "C|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|<init>|java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|close||new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|getNextArEntry||new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|read||new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|read|[B|new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.archivers.ar.ArArchiveInputStream|read|[B,int,int|new:org.apache.commons.compress.archivers.ar.ArArchiveInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
