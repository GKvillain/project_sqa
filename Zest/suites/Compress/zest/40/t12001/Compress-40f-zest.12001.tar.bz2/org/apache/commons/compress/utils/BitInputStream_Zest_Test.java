package org.apache.commons.compress.utils;
import org.junit.Test;
import static org.junit.Assert.*;
public class BitInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 1, 1, 1, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\udb44\udf6a\udb74\udc7b\ucf0b\ud8ce\udd88\ud07e\udaf7\udeef\uda8d\udc7b\udae9\udf60\ud8b3\uded7\ud955\udc5a\ud869\udf0e\uda77\udfac\ud933\udd49\udb6e\udd26\udbd2\uddb8",
        0, 39594, -1501327490, -3229166241318187736L, -32898L, false, false, (char) 55734, (char) 40414,
        Double.longBitsToDouble(0x3fcaec55c4d80e0cL), Double.longBitsToDouble(0x3fd73abd6b28e6feL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 1, 1, 0, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\udb44\udf6a\udb74\udc7b\ucf0b\ud80e\udf49\ud07e:\uda8d\udc7b\udae9\udf60\ud8b3\uded7\ud937\udc4b\ud869\udf0e\uda77\udfac\ud933\udd49\udb6e\udd26\udbd2\uddb8",
        0, 39594, -1501327490, -3229166241318187736L, 96608L, true, true, (char) 8005, (char) 45165,
        Double.longBitsToDouble(0x3fe87e9538e47cfaL), Double.longBitsToDouble(0x3fcaec55c4d80e0cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\ud9fd\udc67\ud915\udf18\uf377\ud8ce\udd88\ud07e\udaf7\udeef\uda8d\udc7b\udae9\udf60\ud8b3\uded7\ud955\udc5a\ud869\udf0e",
        48, 36521, 678520276, 8652373227386713692L, -71198L, false, false, (char) 856, (char) 1231,
        Double.longBitsToDouble(0x3fdd92e8b6f6a6bcL), Double.longBitsToDouble(0x3fd2bbf069cda092L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\0121=void |this=org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 2, 1, 1, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\udab7\udd56\udb74\udc7b\ucf0b\ud8ce\udd88\ud07e\udaf7\udeef\uda8d\udc7b\udae9\udf60\ud8b3\uded7\ud955\udc5a\ud869\udf0e\uda77\udfac\ud933\udd49\udb6e\udd26\udbd2\uddb8",
        0, 39594, -1501327490, -3229166241318187736L, -56971L, false, true, (char) 64375, (char) 50760,
        Double.longBitsToDouble(0x3fe87e95d0e47cfaL), Double.longBitsToDouble(0x3fcaec55c4d80e0cL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 1, 3, 1, 2, "\udb7d\udd0a\udbd2\uddd1\ud844\ude3e", "\uc70f\u3980\u7ad2\u6284\u206f\u3b39\uc737\ub984\u2faf", "\ucf0b\ud8ce\udd88\ud07e\udaf7\udeef",
        44, 11061, 33609401, 8646829130002286723L, -86058L, false, true, (char) 22765, (char) 41047,
        Double.longBitsToDouble(0x3fea1c8c59d92e8bL), Double.longBitsToDouble(0x3fdc155db818084eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 1, 3, "\ud9ea\uddfd\udbd2\uddd1\udb91\udcf6\udbdd\udd7a\ud9c2\udc49", "\u74e6\u6284\u896e\u541d\uc737\ub984\u2faf\ua088\u6d6a\u3c29\ua160\u6ea0\u4648\ub990\u7f40\ub118\u2b81\u7338\u1ad9\ud7cb\u81bf\u0683\ud65b", "\ud869\udc16\uda6d\udea5\ud98a\udffb\ud848\udfad\ud9f5\udf3c\ud862\udf4e\udb9f\udd77\udb4d\udcf4\udaeb\udeb4\u890c\ud8f9\udc40\ud9dc\udc41\uda5f\udcb8\ud97c\udff3\ud8e6\uddec\ud911\uddb4\ud850\udf05\ud920\udfa6\uda86\uddf6\udab8\udedb\ud86b\udf1e",
        -5, 71876, -1336104185, -9186521405787159302L, 7703L, true, false, (char) 10391, (char) 58943,
        Double.longBitsToDouble(0x3f95608a7615a560L), Double.longBitsToDouble(0x3feb0adee13b620fL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 1, 1, 1, 2, "\uda55\udd16\udbce\udfb0\ud88b\ude55\uda9e\uddd8\uda27\udf60\ud87b\udfb2", "\u6284\u11b0\u8539\u06e9\ub9ed\u99c1", "\ucf0b\ud8ce\udd88\ud07e\udaf7\udeef",
        44, 11061, 33609401, 8646829130002286723L, -86058L, false, true, (char) 8430, (char) 54474,
        Double.longBitsToDouble(0x3fea1c8c59d92e8bL), Double.longBitsToDouble(0x3fdc155dbc3c324eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 1, 3, 1, 3, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u2cd9\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\udb44\udf6a\udb74\udc7b\ucf0b\ud989\udfbb\uda66\udf66\ud8c6\udda6\ud902\uddc6\udae9\udf60\ud8b3\uded7\ud955\udc5a\ud869\udf0e\uda77\udfac\ud933\udd49\udb6e\udd26\udbd2\uddb8",
        0, 39594, -1501327490, -3229166241318187736L, -32898L, false, false, (char) 55734, (char) 40414,
        Double.longBitsToDouble(0x3fcaec55c4d80e0cL), Double.longBitsToDouble(0x3fd73abd6b28e6feL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\0121=new org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 2, 1, 3, 1, "\udb7d\udd0a\udbd2\uddd1\udb3f\udff0", "\u1dd6\u037a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\udb44\udf6a\udb74\udc7b\ucf0b\udad7\udccd\ud07e\udaf7\udeef\udb25\udc68\udaeb\udc22\ud8b3\uded7\ud955\udc5a\udb0e\ude96\udab1\udc90\ud933\udd49\udb6e\udd26\udbd2\uddb8",
        0, 39594, -1501327490, -3229166241318187736L, -36030L, false, false, (char) 55612, (char) 40414,
        Double.longBitsToDouble(0x3fcaec55d4d80e0cL), Double.longBitsToDouble(0x3fec083135a59308L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 1, 0, 1, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udd26\udb44\udf6a\udaf6\udd6f\ucf0b\ud8ce\udd88\ud07e\udaf7\udeef\udbdb\udc02\udb30\udc6a\ud8b3\uded7\ud955\udc5a\ud869\udf0e\uda77\udfac\ud933\udd49\udb6e\udd26\udbd2\uddb8",
        0, 39594, -1501327490, -3229166241318187736L, -23167L, false, false, (char) 55734, (char) 40414,
        Double.longBitsToDouble(0x3fe6bb1571363f04L), Double.longBitsToDouble(0x3fd73abd6b28e6feL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 2, 1, "\udb7d\udd0a\ud8d7\udf34\udb8c\udd6e", "\u1dd6\u5056", "\ud8e2\ude4a",
        16, 49435, -936273298, -573723933688324147L, 11386L, false, false, (char) 24482, (char) 50238,
        Double.longBitsToDouble(0x3fe5cc71ed480200L), Double.longBitsToDouble(0x3fc06efff2512100L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\udb44\udf6a\udb74\udc7b\ud93f\udf06\ubde5\ud0ae\ud9c6\udcee\udb5c\ude28\udb0b\udc48\ud8b3\uded7\u1ab4\ud961\udca4\uda77\udf52\ud933\udd49\udb6e\udd26\udbd2\uddb8",
        -2, 39709, -1501327490, -3229166241318187736L, 96608L, true, true, (char) 50703, (char) 3711,
        Double.longBitsToDouble(0x3fe87e9538e47cfaL), Double.longBitsToDouble(0x3fcaec55c4d80e0cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.BitInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\ud2a8", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\ud9fd\udc67\ud915\udf18\uf377\ud8ce\udd88\uda78\ude5f\udada\udea6\udaa0\udf37\udae9\udf60\ud8b3\uded7\ud955\udc5a\ud869\udf0e",
        48, 36521, 678520276, 2743650516276623064L, -71198L, false, false, (char) 856, (char) 1231,
        Double.longBitsToDouble(0x3fdd92e8b6f6a6bcL), Double.longBitsToDouble(0x3fd2bbf069cda092L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.utils.BitInputStream:@?\0121=new org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 2, 3, 3, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud994\uded9\udb7e\udca6\ud9fd\udc67\ud85a\udef7\udaa0\ude03\ud8ce\udd86\ud07e\udaf7\udeef\uda8d\udc7b\udae9\udf60\ud977\udfbd\u1a4c\uda36\uddd5\uda77\udfac\udaa4\ude49\ud82a\udfb0\uda03\udeaf\udb78\udd51\ubaab\ue868\udba3\udfc5\uda46\udda5\ud89b\ude01\udb06\udec2\udb13\udfa6\ud87c\ude5b\ud9ec\udcb3\uda1b\udc28\ud8f4\udcca\ud91e\udf77",
        47, 68503, -1073689671, 6518811938177880574L, 11567L, false, true, (char) 23386, (char) 15104,
        Double.longBitsToDouble(0x3fdaa3bae14d5c76L), Double.longBitsToDouble(0x3febef2d47f75d91L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\uadf4\ub1ea", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\ud9fd\udc67\ud915\udf18\uf377\ud8ce\udd88\ud07e\udaf7\udeef\uda8d\udc7b\udae9\udf60\ud8b3\uded7\ud955\udc5a\ud869\udf0e",
        48, 36521, 678520276, -8929679717867702692L, -71198L, false, false, (char) 856, (char) 1231,
        Double.longBitsToDouble(0x3fdd92e8b6f6a6bcL), Double.longBitsToDouble(0x3fd2bbf069cda092L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.utils.BitInputStream:@?\0121=java.lang.Long:0 |this=org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 2, 0, 0, 2, "\udb7d\udd0a\udbd2\uddd1\udb8c\udd62", "\u1dd6\u7e9a", "\ud8e2\ude4a\ud865\udfd1\uda12\udc3e\ud9c9\udcd9\udb7e\udca6\ud9fd\udc67\ud915\udf18\uf377\ud8ce\udd88\ud07e\udaf7\udeef\uda8d\udc7b\udae9\udf60\ud8b3\uded7\udbdf\udd9b\ud8eb\udfd7",
        0, 36521, 678520276, 8652314953270441564L, -71198L, false, false, (char) 856, (char) 1231,
        Double.longBitsToDouble(0x3fdd92e8b6f6a6bcL), Double.longBitsToDouble(0x3fd2bbf069cda092L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.utils.BitInputStream:@?\012",
        Z.run(T, 1, 1, 3, 1, "\udb7d\udd0a\udbcc\udc87\udb8c\udd4f", "\u1dd6", "\udb20\udfe4\ud8de\ude4a\ud86b\ude6d",
        30, 34695, 69391864, 4422006848370854434L, 33956L, false, false, (char) 1079, (char) 24482,
        Double.longBitsToDouble(0x3fe0abb14eb98e3dL), Double.longBitsToDouble(0x3fd480200106effeL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.utils.BitInputStream|readBits|int|new:org.apache.commons.compress.utils.BitInputStream:java.io.InputStream,java.nio.ByteOrder",
    "M|org.apache.commons.compress.utils.BitInputStream|clearBitCache||new:org.apache.commons.compress.utils.BitInputStream:java.io.InputStream,java.nio.ByteOrder",
    "M|org.apache.commons.compress.utils.BitInputStream|close||new:org.apache.commons.compress.utils.BitInputStream:java.io.InputStream,java.nio.ByteOrder",
    "C|org.apache.commons.compress.utils.BitInputStream|<init>|java.io.InputStream,java.nio.ByteOrder",
    "M|org.apache.commons.compress.utils.BitInputStream|readBits|int|new:org.apache.commons.compress.utils.BitInputStream:java.io.InputStream,java.nio.ByteOrder",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
