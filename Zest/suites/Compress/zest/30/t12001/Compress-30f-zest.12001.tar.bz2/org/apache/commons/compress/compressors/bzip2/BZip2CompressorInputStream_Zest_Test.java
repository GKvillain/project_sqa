package org.apache.commons.compress.compressors.bzip2;
import org.junit.Test;
import static org.junit.Assert.*;
public class BZip2CompressorInputStream_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 9, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u5208\u8b1f\u0cc7\u7b50\u9b75\u0556\u15ea\u8f8a\u91bb", "\ud921\uddc3",
        8, 1180, 431350090, 8686135356460306780L, 60288L, false, true, (char) 5857, (char) 15445,
        Double.longBitsToDouble(0x3fc4b071530b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 14, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\uda6b\udeca", "\uca75\u8997\u20c4\u070d\u4ce8\u4744\u5208\u8b1f\u0cc7\u7b50\u2c0d\u0556\u81df\u28b4\ua151\u2c60\ubd1a\u557e\u7d3a\u8d41\ubfc2\u98f4\u05d6N\u25c1\u6244\u22c7\uae61\ub18e\ua571\u456b\uc67c\u5980\u1204\u26ed\u4c20\u9d11\ub52c\u9e0e\u7cae", "\ud932\uddf0\udbc1\udf04\udb43\udf9d\udb82\udf83",
        41, 10459, 134861575, 2981696698129910954L, -40084L, false, true, (char) 3376, (char) 31119,
        Double.longBitsToDouble(0x3fd154ef54278dacL), Double.longBitsToDouble(0x3fc7c744ec8011a0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 13, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u5208\u8b1f\u0cc7\u7b50\u9b75\u0556\u15ea\u8f8a\u91bb", "\ud921\uddc3",
        8, 1180, 431350090, 8686135356460306780L, 60288L, false, true, (char) 5857, (char) 15445,
        Double.longBitsToDouble(0x3fc4b0715309e71cL), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 8, 3, 1, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u5208\u8b1f\u0cc7\u7b50\u9b75\u058f\u191e\u8f8a\u91bb", "\ud921\uddc3",
        8, 1180, 431350090, 8686135356460306780L, 60288L, false, true, (char) 5857, (char) 15445,
        Double.longBitsToDouble(0x3fc4b071530b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 9, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\ud83e\udef2", "\u6b24\u49a8\u5dac", "\ud92d\udd93\udad7\udf63\ud9bb\udd0e\udbb0\ude1f",
        23, 25187, -542110814, -1140166436239924484L, 51006L, false, true, (char) 3522, (char) 30977,
        Double.longBitsToDouble(0x3fe3a54a414a336cL), Double.longBitsToDouble(0x3fe5220b715c788bL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 5, 3, 15, "\ud8bf\udc07\udbe5\uddda\uda26\udcc6\udaf6\ude34\ud9ad\udc8e\ub3b2\uda68\udc50\ud83e\udef2", "\ucbee", "\ud913\udef4\ud902\udc47\ud92d\udd93\udad7\udf63\ud9bb\udd0e\udbb0\ude1f\uda67\udf74\udaa7\udfff\ud9f4\uddba\ud8f7\udfbc\udac4\udc26",
        18, 87582, -1526691457, 6124729195167032322L, 60288L, false, true, (char) 5857, (char) 59733,
        Double.longBitsToDouble(0x3fc4b071530b2b14L), Double.longBitsToDouble(0x3fecc148a0e0b9d2L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 1, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\udec4\ud913\udcd8\u9490\u244f\uda6e\udd43\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u5208\u8b1f\u0cc7\u731b\u9b75\u0556\u15ea\u8e74\u91bb", "\ud921\uddc3",
        8, 1180, 431350090, -3894382706078314148L, 60288L, false, true, (char) 5857, (char) 15445,
        Double.longBitsToDouble(0x3fc4b071530b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\udb78\udc58\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u5208\u8b1f\u948a\u90fc\u9b75\u0556\u15ea\u8f8a\u91bb", "\ud941\udf18",
        8, 1180, 431350050, 8686135354715476316L, 60288L, false, true, (char) 5857, (char) 15445,
        Double.longBitsToDouble(0x3fc4b071530b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\u5521\u8afb\u3836\u0470", "\uda9c\udd96\ud80f\udebe\ud92f\udd78\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\uda67\udf74\udae9\udc1f\ud9f4\uddba\ud8fe\udfe1\ud929\udcfc\udb5b\udf1a\ud817\udddf",
        3, 4641, -1454889982, 3248624151144292706L, 60288L, false, true, (char) 5857, (char) 41812,
        Double.longBitsToDouble(0x3fc4b780330b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\uadbf\udb32\udca1\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u5208\u8b1f\u0cc7\u7b50\u9b75\u0556\u15ea\u8f8a\u91bb", "\ud907\udd02",
        8, 1180, 431350090, 8686135356460306780L, 60288L, false, true, (char) 5857, (char) 15445,
        Double.longBitsToDouble(0x3fc4b071530b2b14L), Double.longBitsToDouble(0x3e94000000000000L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 9, 9, "\ud8be\udf5a\udb96\udf49\ud8a3\udf7e\ud913\udcd8\ud89e\udd8a\uda2c\udcf2\udb26\udfed\ud846\udc57", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u5208\u8b1f\u0cc7\u7b50\u9b75\u0556\u15ea\u8f8a\u91bb", "\ud921\uddc3",
        42, 1180, 431350090, 8686135356460306780L, 60288L, false, true, (char) 5857, (char) 15445,
        Double.longBitsToDouble(0x3fd45838a81d85a8L), Double.longBitsToDouble(0x3fe55d8d60e0b982L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud908\uddd2\ud9c6\udf80\ub3b2\uda68\udc50\ud83e\udef2\ud964\udd65\ud8dc\ude18", "\u1fbc\u05c5\uadc3\u8d86\u5208\u8b1f\u0cc7\u7b50\u9b75", "\ud865\udc79\uda0f\udffe\ud817\udddf\ud869\udc22\ud921\uddc3\udacf\udee5\udb2c\udd7b\udb80\udecd\uda4e\udd30\uda87\udffd\ud88e\ude45\ud846\udf70\ud9c3\udf1c\udb00\udc30\ud942\ude8e\uda33\uddbd\ud891\uded8\ud8e3\udc48\udb85\udfeb\ud966\udd47\uda02\udd88\ud8f5\udfed\ud853\udd95\uda77\udf05\udbe4\udf1d",
        56, 98797, -1979559229, 480198489622916658L, -70743L, true, false, (char) 32041, (char) 46050,
        Double.longBitsToDouble(0x3fe35110e6d39ceeL), Double.longBitsToDouble(0x3fe714a0653a8bafL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 2, 12, "\ud897\udcb8", "\u8666\u4b48\uad6e", "\ud964\udd65",
        15, 62788, -105072615, 6971555935866546540L, 83471L, true, true, (char) 21546, (char) 14041,
        Double.longBitsToDouble(0x3feac35348abdfb0L), Double.longBitsToDouble(0x3fe7e7816a0bc718L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\ud9e5\ude0e\ud964\udd65\ud806\udfe4\ud934\udd61\uda9c\udd96\udb2b\ude69\ud913\udef4\ud902\udc47\ud92d\udd93\ud9a4\udd9c\udb26\udc03\ud8a6\udfe3\udaf1\ude15\udb2e\ude51\ud9f4\uddba", "\u1391", "\ud8bf\udcf3",
        36, 1180, 213246282, 241585901351145820L, 60288L, false, true, (char) 43475, (char) 588,
        Double.longBitsToDouble(0x3fc4b0715309e71cL), Double.longBitsToDouble(0x3fc305229382e748L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\ud95a\uddc5\udb84\ude84\ud88c\udeb3\ud913\udcd8\ud9c6\udf80\ud9aa\ude71\ud9b5\udc83\udb8d\udf22", "\ub17e\u49a8", "\ud9c7\ude99\ud92d\udd93\udad7\udf63\ud9bb\udc5a\udbb0\ude1f",
        23, 25187, -542110814, -1140166436238386948L, 78309L, true, true, (char) 3522, (char) 30977,
        Double.longBitsToDouble(0x3fcf95291f74cc04L), Double.longBitsToDouble(0x3fe0b0cbb26f788bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 12, 10, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d", "\uad6e\u2361\u3836\u0470\u4db2\u6b24\u49a8", "\ud902\udc47\ud92d\udd93\udad7\udf63\ud9dc\udc33\udbb0\ude1f\uda67\udf74\udaa7\udfff\udaac\udd55\ud9e2\udd1b\ud9f3\udfa1",
        12, 6238, 1107227874, 8142468641201702859L, 23210L, false, false, (char) 35208, (char) 63613,
        Double.longBitsToDouble(0x3fdf3518d214bccaL), Double.longBitsToDouble(0x3feffbb2498d8271L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 0, 0, "\000", "", "\ub3b2\uda68\udc50\ud83e\udef2\udb14\udf35\ud806\udf9e\udb10\ude30\ud936\ude1b",
        12, 97240, 677574118, -915446427724968342L, -44236L, true, false, (char) 53156, (char) 7401,
        Double.longBitsToDouble(0x3fc57bf60bf3c000L), Double.longBitsToDouble(0x3f878e3000000000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\udb78\udc58\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f", "\udbc2\udf38",
        50, 69436, 1487472616, -998809578829276254L, -77781L, true, false, (char) 45786, (char) 20671,
        Double.longBitsToDouble(0x3fe0b722ac0254ffL), Double.longBitsToDouble(0x3fd74a94824466d8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 9, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\uda47\udcd2\ud9c6\udf80\ub3b2\udb78\udc58\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u5208\u8b1f\u948a\ub9b0\u9b75\u0556\u15ea\u8f8a\u91bb", "\ud941\udf18",
        8, 1180, -2135563998, 8686135354715476316L, 60288L, false, true, (char) 5857, (char) 15445,
        Double.longBitsToDouble(0x3fc4b071530b2b14L), Double.longBitsToDouble(0x3fc3053d6382e748L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud9f5\udf8a\ud9c7\udc32\ub3b2\udb78\udc58\ud83e\udef2\ud956\udff0\ud806\udfe4\ud934\udd61\uda9c\udd96\udb2b\ude69\ud913\udef4\ud902\udc47", "\u8b1f\u6277\u0205\u9b75\u0556\u15ea\u8f8a\u91bb\u95f3\u77e2\ud6d3\u7d3a\u7b66\ubf9a\u98f4\u8751\u5169", "\udb00\udc30\ud942\ude8e\udbdb\udd81\udadf\udf2d\ud8e3\udc75\ud939\udd46\udbac\ude69\u8361\ud902\udc20",
        54, 12662, -2053320672, 4014938493817612503L, -37135L, false, false, (char) 19227, (char) 46354,
        Double.longBitsToDouble(0x3fe5ee861b04b6eeL), Double.longBitsToDouble(0x3fef5ac1426763caL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\ud8bf\udc07", "\u8e1d\u4b48\uad6e", "\ud956\udff0\ud807\udc01\ud934\udd61",
        11, 3557, 708475163, 2886088984701414995L, -97022L, false, false, (char) 37673, (char) 17956,
        Double.longBitsToDouble(0x3fddedec415a0024L), Double.longBitsToDouble(0x3fe0b722ac0254ffL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\u5521\u8afb\u3836\u0470", "\uda9c\udd96\ud80f\udebe\ud92f\udd78\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e",
        23, 2307, -542110814, -1140135491753630980L, 51006L, true, true, (char) 3522, (char) 30977,
        Double.longBitsToDouble(0x3fe3a54a41622d15L), Double.longBitsToDouble(0x3fe0b0cda95c788bL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 10, 12, "\udbd9\udc50\ud9da\ude64\ud994\ude87\udbde\udc90\udbfd\udc26\u6c14\ud938\udc3f\ud9db\uded0\ud964\udd65\uda08\udd44\ud934\udd36\uda9c\udd96\ud80f\udebe\ud92f\udd78\udad1\udead\ud898\udc09\udbca\udeeb\ud91c\udd0f\udafd\ude8e\udbd8\udf6e\ud8ce\ude1a\udbac\udde5\ud8fe\udfe1\ud929\udcfc\udb5b\udf1a\ud845\udf18\udb6a\udd0f\ud921\udd8c\udacf\udee5\ud86e\udd1c\udb80\udee5\udb72\udd63\uda1f\udc76\ud96e\udff4\uda90\udd19\ud9bd\udd40\udb00\udc30\ud885\udce1\udbdb\udd81\udadf\udf2d\ud8e3\udc75\ud8a0\udff9\udb5c\ude40\ud8c6\ude84\uda3b\ude7e\ud86b\udfb5\ud84d\udec5\ud95c\ude1c", "\uaa91\u8e08\u00b5\u015d\ua321\u9314\ua00b\u58d0\ucf45\u8577", "\udb79\udc97\ud9cb\udcec\uda65\udcf2\udb19\ude39+",
        -4, 2816, 1720235709, -5742556287952977528L, 17655L, false, false, (char) 6777, (char) 34683,
        Double.longBitsToDouble(0x3fd0debb6e0cea36L), Double.longBitsToDouble(0x3feeefc3d0d6328bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u3358\u5521\u8afb\u3836\u65d7", "\udb2b\udff9\ud81e\udd0e\ud83a\uddd0\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\uda67\udf74\udae9\udc1f\ud9f4\uddba\ud8fe\udfe1\ud879\uddc1\udb5b\udf1a\ud817\udddf\ud869\udc22\ud921\uddc3\udacf\udee5\ud86e\udd1c\uda22\udd96",
        37, 1021, -386788447, 6801998804876342174L, 88189L, true, false, (char) 59271, (char) 51627,
        Double.longBitsToDouble(0x3fcc173a4e1958e8L), Double.longBitsToDouble(0x3fd9f86a0081b256L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 0, 0, "\000", "", "",
        53, 33917, 1985160185, 8128184306467194484L, -100000L, true, false, (char) 12217, (char) 53527,
        Double.longBitsToDouble(0x3e48000000000000L), Double.longBitsToDouble(0x3ec1b8b384000000L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 0, 0, "\000", "", "\ub3b2",
        17, 4185, 1892490384, -3467272036574750164L, -100000L, false, false, (char) 36351, (char) 141,
        Double.longBitsToDouble(0x3fe167080204a8d5L), Double.longBitsToDouble(0x3fb93d2ae2ec4dd0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.io.IOException\012",
        Z.run(T, 2, 9, 4, 15, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\ud83e\udef2", "\u6bf7\u49a8\u5dac\u4a1f\uadc3\u066c\u5208\u8b1f\u0cc7\u7b50\u707e\u8c64\u15ea\u8f8a\u91bb", "\ud921\uddc3",
        8, 1180, 431350090, 8686135356460306780L, 60288L, false, true, (char) 5857, (char) 48725,
        Double.longBitsToDouble(0x3fee606f5cc270c3L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\ubf33\000\u9bda\u0470", "\uda9c\udd96\u00cd\ud8f9\udd3c\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\uda67\udf74\udae9\udc1f\ud9f4\uddba\ud8fe\udfe1\ud929\udcfc\udb5b\udf1a\ud817\udddf",
        3, 4641, 2, 3248624151144292706L, 60288L, false, true, (char) 5857, (char) 41812,
        Double.longBitsToDouble(0x3fc4b780330b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\u5521\u8afb\u3836\u0470", "\uda9c\udd96\ud80f\udebe\ud92f\udd78\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\uda67\udf74\udae9\udc1f\ud9f4\uddba\ud8fe\udfe1\ud929\udcfc\udb5b\udf1a\ud817\udddf",
        1, 508, -1454889982, 3248624151144292706L, 60288L, false, true, (char) 5857, (char) 41812,
        Double.longBitsToDouble(0x3fc4b780330b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\ubf33\000\u9bda\u0470", "\uda9c\udd96\u00cd\ud8f9\udd3c\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\uda67\udf74\udae9\udc1f\ud9f4\uddba\ud8fe\udfe1\ud929\udcfc\udb5b\udf1a\ud8c0\udf73",
        53, 51813, 2, 3248624151144292706L, 60288L, false, true, (char) 5857, (char) 41812,
        Double.longBitsToDouble(0x3fc4b780330b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\ubf33\000\u9bda\u0470", "\uda9c\udd96\u00cd\ud8f9\udd3c\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\uda67\udf74\udae9\udc1f\ud9f4\uddba\ud8fe\udfe1\ud929\udcfc\udb5b\udf1a\ud817\udddf",
        3, 18049, 2, 3248624151144292706L, -5248L, true, true, (char) 23182, (char) 57356,
        Double.longBitsToDouble(0x3fc4b79b330b2b14L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\u1899\u7173\u134e\u0470", "\uda9c\udd96\u00cd\ud8f9\udd3c\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\udb91\udc8a\udae8\udf90\ud9f4\uddba\ud973\udf20\ud918\uddfb\udb5b\udf1a\ud8c0\udf73",
        15, 97113, 2, 3248624151144292706L, 60288L, false, true, (char) 5857, (char) 41812,
        Double.longBitsToDouble(0x3fc4b780330b2b14L), Double.longBitsToDouble(0x3fd9b50141c199dcL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\u1899\u7173\u3129\u1b1c", "\ud86b\udf5d\u00cd\ud8f9\udd3c\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\udb91\udc8a\udae8\udf90\udb55\udfab\ud9d5\udd15\ud8f6\uddaa\udb5b\udf1a\ud8c0\udf73",
        13, 2337, 2, -1512308476125805194L, 60288L, false, true, (char) 5857, (char) 11754,
        Double.longBitsToDouble(0x3fc4b737d30b2b14L), Double.longBitsToDouble(0x3fe55280a308f9f6L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50", "\ucd14\u5458\u1899\u7173\u134e\u0470", "\uda9c\udd96\u00cd\ud8f9\udd3c\ud902\udc47\ud898\udc09\udbca\udeeb\ud91c\udd0f\udb28\udf8e\udb91\udc8a\udae8\udf90\ud9f4\uddba\ud973\udf20\uda8a\uddb3\udb5b\udf1a\ud8c0\udf73",
        42, 1878, 2, 3248624151144292706L, 60288L, false, true, (char) 5857, (char) 55892,
        Double.longBitsToDouble(0x3fe54ba9acc2cac5L), Double.longBitsToDouble(0x3fd9b50141c199dcL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\ud8f8\udfe5\udb32\udd3d\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\udb78\udc58\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u1081\u8ab9\u948a\u90fc\u9b75\ucd81\u4f87\u8ea1\u91bb", "\ud941\udf18\udaa9\udc51\udb2c\udd7b\udb80\udea5\ud8b5\udee4\ud9b7\uddac\udafc\udf2c",
        19, 62, -2106509417, -8968151319944263515L, 72184L, false, false, (char) 13234, (char) 46567,
        Double.longBitsToDouble(0x3fefbac3a21573f8L), Double.longBitsToDouble(0x3fe35d5ea0b60a7fL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 5, 15, "\ud8a8\udc9c\ud83d\ude1b\ud88c\ude83\ud913\udcd8\ud9c6\udf80\ub3b2\udb78\udc58\ud83e\udef2", "\u6b24\u8dce\u623d\u4a1f\uadc3\u4744\u5208\u8b1f\u948a\u90fc\u9b75\u0556\u15ea\u8f8a\u91bb", "\udba7\udc7a\udb19\udf3d\ud844\udfa7\ud88c\udd44\uda5b\udc92\ud860\udfbb\ub001",
        17, 215, -646891625, 740901472782616821L, 72184L, false, false, (char) 53630, (char) 48281,
        Double.longBitsToDouble(0x3fdf825d7b21a594L), Double.longBitsToDouble(0x3fe7731e93e241b3L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 10, 9, "\ud8bf\udc07\udb32\udce4\ud88c\ude4d\udbf9\udfa0\udbf8\udf60\ud997\ude77\udb7a\udfdb\uda77\udd9f\ud9ab\udeef\ud806\udfe4\udbd6\udd62\uda9c\udd96", "\u45cc\ubbb5\u5208\u8b1f\u948a", "\ud9f4\uddba\ud8f7\udfbc",
        14, 107, -1928180258, 7372803078635907618L, -72899L, false, true, (char) 28575, (char) 12296,
        Double.longBitsToDouble(0x3fde4827114b0714L), Double.longBitsToDouble(0x3fea364d78982914L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 0, 0, "\000\000\000\000\000\udb13\udeeb", "\u4a41", "\ud8b1\udf78\udbe9\udd61\ud928\udf89\000\000\ud9c1\udced\uda88\udf7d\udbc2\udfb7\ud8b0\udf77\ud867\ude56\ub04e\ud8be\udcc1\udb88\udee3\uda88\ude01\ud835\uddb9\ud89a\udf3e\u85ce\ud9e1\udeab\ud9b7\udfb1\udbe0\udd6d\ud9ec\udcc3\ud8ee\udffe\udaa5\udc23\udbba\udcbc\ue8d3\udab7\uddef\ud95a\udc9d\udb96\ude56\ud8ec\udcc3\udb22\udd11\udbc2\udffc\ud9a6\udd51\ud80d\uddcb\ud997\uddf4",
        0, 72059, 800329889, -4452148165861649093L, -97654L, true, true, (char) 43348, (char) 41308,
        Double.longBitsToDouble(0x3feabfacc9eeb39aL), Double.longBitsToDouble(0x3feed8b26301ba0eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 9, "\ud8f8\udfe5\udb32\udd3d\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\ud8e2\uddce\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u61ee\ua129\u8ab9\u930f\u9015\u9b75\ucd81\u4f87\u8ea1\u91bb", "\ud941\udf18\udaa9\udc51\udb2c\udd7b\udb80\udea5\ud8b5\udee4\ud9b7\uddac\udafc\udf2c",
        54, 62, -2106509417, -8968151319944263515L, 72184L, false, false, (char) 13234, (char) 46567,
        Double.longBitsToDouble(0x3fefbac3a21573f8L), Double.longBitsToDouble(0x3fe35d5ea0b60a7fL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\ud8f8\udfe5\udb32\udd3d\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\udb78\udc58\ud83e\udef2", "\u6b24\u49a8\u5dac\u4a1f\uadc3\u4744\u1081\u8ab9\u948a\u90fc\u9b75\ucd81\u4f87\u8ea1\u91bb", "\uda6f\udc8f\udab9\udc2c\udb2c\udd7b\udb80\udea5\ud8b5\udee4\ud9b7\uddac\udace\udc15",
        32, 62, -2106509417, -8968151319944263515L, 72184L, false, false, (char) 13234, (char) 46567,
        Double.longBitsToDouble(0x3fefbac3a21573f8L), Double.longBitsToDouble(0x3fe35d5ea0b60a7fL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\000\udb32\udca1\ud88c\ude4d\ud913\udcd8\ud9c6\udf80\ub3b2\udb78\udc58", "\u7d89,\000\u5cdf\u4a1f\uadc3\u4744", "\uda39\udcbc\uda37\udd21\udb7e\udf29\uda16\uddb9\ud80f\udf27",
        0, 107, 1199582, -1993598554655954410L, -25547L, true, false, (char) 2155, (char) 65156,
        Double.longBitsToDouble(0x3fed1f415568e964L), Double.longBitsToDouble(0x3fcb7e879b190c34L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 15, "\udbd1\udc50", "\ucd14\u5458\ubf33\000\u9bda\u839f", "\uda9c\udd96\u00cd\uda3e\udebf\ud9a3\ude3d\ud872\udc06\udbca\udeeb\ud91c\udd0f\udb28\udf8e\ud8ca\udca6\udae9\udc1f\udb14\udc4a\ud9be\ude16\ud929\udcdb\udb5b\udf1a\ud817\udddf",
        57, 10724, 2, 3248624151144292706L, 17726L, false, true, (char) 60748, (char) 29878,
        Double.longBitsToDouble(0x3fb92800a6165628L), Double.longBitsToDouble(0x3fc305228382e748L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 0, 0, "\000\000\uda5d\udf0e\ud913\udcd8\ud9c6\udf80\ub3b2\uda68\udc50\ud897\udebf\udb14\udf35\ud806\udf9e\udb10\ude30\ud936\ude1b\udbe9\udd61\ud913\udef4", "\ua711", "\uda67\udf74\udb7a\udf88\uda26\udf53",
        54, 65253, 11, -3262576456428255868L, 28202L, false, true, (char) 6240, (char) 23793,
        Double.longBitsToDouble(0x3fe0c373f4b52c3aL), Double.longBitsToDouble(0x3fb0862d9ff248c0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 9, 2, "\udbd9\udc50\ud9da\ude64\ud9a0\udfcd\uda25\ude2e\udaf7\uddd6\udb2d\ude79\udb51\ude6d\ud8bf\ude67\udbb5\uddae\ud989\udf25", "\uc834", "\ud829\ude34\udbca\udeeb\ud91c\udd0f\udb28\udf8e\udb91\udc8a\udae8\udf90\ud87f\udfa0\udaa2\udf60\ud918\uddfb\udb5b\udf1a\ud932\udd2d",
        15, 665, 2, 1519241892703489482L, -5248L, false, true, (char) 5857, (char) 7509,
        Double.longBitsToDouble(0x3fc4b780330b2b14L), Double.longBitsToDouble(0x3fd9b50145c199dcL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 0, "\udbd9\udc50\ud9da\ude64\ud994\ude87\udbde\udc90\udbfd\udc26\u6c14\udab7\udfe9\ud83e\udef2\ud964\udd65\uda08\udd44\ud934\udd36\uda9c\udd96\ud80f\udebe\ud92f\udd78\ud902\udc47\ud841\udc3c\udbca\udeeb\ud91c\udd0f\udb28\udf8e\uda67\udf74\udae9\udc1f\udbf8\udcdb\ud9cc\udfbf\udb7e\uddec\udb5b\udf1a", "\u557e", "\udb80\udee5\uda4e\udd30\ud826\udd84\ud823\ude6b",
        27, 33, -2106509417, -4899598761165748059L, -10040L, false, false, (char) 39127, (char) 46882,
        Double.longBitsToDouble(0x3fe687f6663fcfe8L), Double.longBitsToDouble(0x3fe5d7ec1fb17e53L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 1, "\udbd9\udc50\ud9da\ude64\ud994\ude87\udbde\udc90\udbfd\udc26\ud9d6\udd22\udb51\ude6d\uda06\udd60\uda48\udfe5\uda08\udd44\ud934\udd36\uda9c\udd96\u00cd", "\u3cdb\u5d48\ua31a\u75a6\u8fd6\u85dd\u0556\ub0ae", "\ud8c0\udf73",
        15, 78785, 6, 3248624151144292706L, 60288L, false, true, (char) 5857, (char) 41812,
        Double.longBitsToDouble(0x3fc4b780330b2b14L), Double.longBitsToDouble(0x3fd9b50141c199dcL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 4, 0, "\udbd9\udc50\ud9da\ude64\ud994\ude87\udbde\udc90\udbfd\udc26\u6c14\udab7\udfe9\ud83e\udef2\ud964\udd65\uda08\udd44\ud934\udd36\uda9c\udd96\ud80f\udebe\ud92f\udd78\ud902\udc47\ud830\udf3c\udbca\udeeb\ud91c\udd0f\udb28\udf8e\uda67\udf74\udb96\udf28\uda18\udc7a\ud9c5\udebf\udb7e\uddec\udb5b\udf1a", "\u557e", "\udb80\udee5\udabf\udd45\udade\udf4a\udae9\udff2",
        31, 33, -2106509417, -4899598761165748059L, -10040L, false, false, (char) 39127, (char) 46882,
        Double.longBitsToDouble(0x3fe687f6663fcfe8L), Double.longBitsToDouble(0x3fe5d7ec1fb17e53L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 8, 4, "\uda4b\udd36\uda94\udcd0\ud994\ude7b\udbde\udc90\udbfd\udc26\uda00\udc8a\udb17\ude0d\uda98\udc4c\ud964\udd65\uda08\udd37\ud96b\udc36\uda9c\udd96\u00cd\ud8f9\udd3c\ud902\udc47\ud898\udc09\ud95f\udd16\udb7c\udc14\udbce\udc5b\udb91\udc8a\ud880\uddc2\ud9f4\udde5\udabb\udf97\ud88f\udded\udb5b\udf1a\ud8c0\udf73\uda9f\ude46\udbdb\udc74\002\ud86e\udd1c\ud8f4\udee0\uda4e\udd30\udaf1\udff2\ud88e\ude45\ud846\udf70\udb58\udf47\udb53\udcfd\ud885\udc74\udbdb\udd81\ud83a\udd7a\uda2c\ude98\ud982\udfca\udb39\udc49\ud8bb\udc5c\uda31\udebc\ud945\uddb9\ud892\ude27\ud8da\uddbe\udbaa\udca4\ud821\udd43\uda70\ude67\udab8\udf2a\ud941\udc41\ud97d\uddf5\uda2c\ude30\ud8da\udf7c\udba0\udf0f\ud8ea\udee8\ud979\udec6\udaf4\ude70\udbdb\udf1e\uda5f\uddf2\udaf3\udf4d\udab7\udc15\ud96a\udcf7\udb58\udf51\udb28\udd69\udaf9\ude7a\udba7\udf93\uda31\udf85\ud8a5\ude01\udb1b\udcd2\ud9d0\udefe\ud994\udf82\udaf6\udef3\udad2\udc38\uda83\udc6b\uda44\uddc2\udad1\udf20\udb9c\udd42\uda1d\uddc6\ud879\uddad\ud8d6\uddd5\ud9b0\udc92\ud8fb\ude45\ud932\udd12\ud9fa\udc30\uda4c\udf93\ud9be\ude29", "\ubc36", "\ud932\ude2d\ud9af\udf9c\ud9ed\udf98\udb83\udfb2\uda3f\udcd9\ud926\udfde\ud9ba\udc4e",
        0, 73842, 1561127466, 2369868277218472724L, 83713L, true, false, (char) 19841, (char) 57719,
        Double.longBitsToDouble(0x3fe383991b0a15a8L), Double.longBitsToDouble(0x3fbd247c88d017b8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|read||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|read|[B,int,int|new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|bsGetBit||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|bsGetInt||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|bsGetUByte||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|bsR|int|new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|close||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|complete||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|createHuffmanDecodingTables|int,int|new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|endBlock||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|getAndMoveToFrontDecode||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|getAndMoveToFrontDecode0|int|new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|hbCreateDecodeTables|[I,[I,[I,[C,int,int,int|static",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|init|boolean|new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|initBlock||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|makeMaps||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|read||new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream|read|[B,int,int|new:org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream:java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
