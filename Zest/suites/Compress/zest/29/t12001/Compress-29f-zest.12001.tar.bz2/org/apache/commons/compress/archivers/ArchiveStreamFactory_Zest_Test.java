package org.apache.commons.compress.archivers;
import org.junit.Test;
import static org.junit.Assert.*;
public class ArchiveStreamFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 34, 28, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, 496873602, -5145998547634977605L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 21, 22, 18, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\u2a0e\udbd4\udea3\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab2\ude21\ud9d8\udd3b\udac0\udc99\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 75859, -1784877160, -5145999127455562565L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fd23ffc543be5f4L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 30, 28, 13, "\ud9a3\udf4f\ud8a1\udc7d\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9b4\udda0", "\u6231\u52ef\u29fd\u404b\u3cc2\ub2df\u228e\ua21c", "\ud9e1\udcf7\udab0\udd21\ud99a\ude9b\ud85d\ude62",
        56, 94593, 743959838, 4333217961398452199L, -2907L, false, true, (char) 55502, (char) 41347,
        Double.longBitsToDouble(0x3fdec834b15edff2L), Double.longBitsToDouble(0x3fe1622ddc592641L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 31, 28, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69", "\u0b39\u00b2\u7e51\uc3c6\u8522\u91d0\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, 496873602, -5145998547634977605L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 34, 13, 32, "\ud9b2\udc4f\uda9d\udeba\ufeb7\ud8d7\udf18\ud9ff\udfe0\u14a0\ud969\udf4c\udb83\udd0e\ud9be\ude24\ud9fa\udd25", "\u52d5\u72cc\u8784", "\udbd6\udeb3\udb19\udda2\ud920\udd62\ud82b\udccf",
        37, 60499, -1163999767, -6435048381115371164L, -80806L, false, false, (char) 31753, (char) 42338,
        Double.longBitsToDouble(0x3fc0529316590ac4L), Double.longBitsToDouble(0x3fc76e12ae3ba628L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 44, 13, 25, "\ud9a3\udf4f\uda9d\udeba\ud9f5\udf6a\udbad\udf2f\udb6b\udf86\udaa5\udde9\ud882\udfda\udb83\udd0e\ud9be\ude24\ud81c\ude3a\udbbe\udd72\udb46\uddd3\udab2\udfed\ud845\udc66\udac6\ude8f\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21", "\u903c\u09c9", "\uda08\udc29",
        3, 53602, -1198146154, -1618335178329076850L, -92462L, false, true, (char) 47272, (char) 25575,
        Double.longBitsToDouble(0x3fb675905f6ae628L), Double.longBitsToDouble(0x3fe0e87e898e9529L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 38, 28, 13, "\ud933\udc0b\udb67\udd23\uda70\udffb\ud8de\udef5\u7925\ud891\ude88\udb7e\udfb7\ud80e\udf0e\udbb2\udc3f", "\u6231\u52ef\u62df\u977f\u3c8d\ub2df\u008b\ua21c\u9eb4\uc24b\u451a\u8de4", "\ud8ad\udcb1\udb96\udf79",
        8, 15868, -260096025, 8185491210299590530L, -2907L, false, false, (char) 17737, (char) 38002,
        Double.longBitsToDouble(0x3f4f74228f7aa800L), Double.longBitsToDouble(0x3fb34c7115a79828L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 0, 31, "", "\u2469\uc88d\000\000\uc000\u592f", "\udbbe\udd72\udb46\uddd3\udab2\udfed\000\uda20\udf70\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\u5440\ud908\ude75\000\000\000\ud960\uded0\udac0\udc99",
        14, 54165, 942318598, 4333217707542396903L, -100000L, false, false, (char) 0, (char) 13313,
        Double.longBitsToDouble(0x3f4905bbde8a3000L), Double.longBitsToDouble(0x3eb2c57800000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 23, 28, 37, "\ud9a3\udf4f\uda9d\udeba\ud9d4\udea0\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda23\udf82\ud9e6\udf4f\uda3d\udfea\udbbc\udc19\udb32\udf8e\ud947\ude1c\ud9a8\udd42\udb4c\udc4b\uda25\udf10\ud980\udd0f\udacd\udd99\ud921\udccb\udabb\ude62\ud8d4\udc92\uda2d\udcc4",
        40, 63187, -2086804094, -1006095653899578645L, 67444L, true, true, (char) 45817, (char) 35354,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e9529b637384L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 6, 28, 13, "\ud9a3\udf4f\uda9d\udeba\ud92d\udccb\ud892\udf36\udb48\udee4\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231\u52ef\u72cc\u4d25\u3cc2\ub2df\uc1d4\u87c3\u9eb4\u5995\u44a8", "\uda37\udc72\ud884\udc61\udb96\udf5c\uda20\udf20\ud8c4\ude17\ud83d\udefd\udb12\udf94\udb2a\ude40\udbdf\udfad\udb34\ude80\uda80\uddc6\ud840\udee2\uda8b\udf9d\ud912\udc85\u2ccb\ud838\udf23\uda4c\ude31\ud824\ude34\ud878\udfd1\ud8a4\udeca\uda24\udd36\uda52\ude6a\udadd\udcc3\ud879\uddfd\ud857\ude17\ud8f8\ude0e\ud810\udf5e\uda83\udcf6\ud822\udd64\u63e2\udbc8\udd9c\ud8f4\udc87\ud930\ude52\udb11\udccc",
        -2, 85229, 1366662588, -6723288930736894556L, 23712L, true, true, (char) 21788, (char) 44585,
        Double.longBitsToDouble(0x3fe39bb226944190L), Double.longBitsToDouble(0x3fdf318750786b48L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 29, 34, 42, "\udb61\ude76\uda9d\udeba", "\uc077\u0b39\u00b2\u7410\uc3c6\u8522\u91d0\u6231\u52ef\u4e0a\u48b4\u3cc2\ub2df\u008b\ua21c\u9eb4\uc24b\u451a\u8de4\u66c5\u695d\ub303\u32e3\u8e97\u099e\u9e81\ubf5d\ubb30\ua0f1\u921c\u5090\u2a29\u632a", "\udb08\udd8b\udbe4\ude4e\ud9dc\ude22\ud878\udfd1\ud8a4\udeca\ud90b\udd21\udb9f\ude2c\ud969\udd14\udb38\udc38\udac8\udd94\ud8d1\udd9e\udb96\ude7e\ud9aa\udd65\ud9fe\uddb2\ud862\udf67\udbba\udf68\uda5c\ude14\udb9f\ude2a\udb2b\udcf4\udb83\ude7c\u8612\ud981\udd92\udb1b\ude7e\ud8fe\udccf\ud8fb\udd9f\ud833\udc22\ud896\udc69\uda00\udefe\uc9f9\udb05\udf5d\udbf1\ude6b\ud9d0\uded4\udbc9\udf80\ud929\udea0\ud8e2\udd0d\uda74\udecd\uda45\udfbe\udb99\udd74\ud82f\udc55\ud815\udeaa\ud90d\udd35\udb3d\udda5\ud9e1\udfbe\ud9b2\udc4e\uda60\udd2d\udbff\udc27\u663e\ud990\udc78",
        20, 90074, -1922766013, 2633082993315648316L, 87974L, false, true, (char) 59028, (char) 24531,
        Double.longBitsToDouble(0x3fde23703c325f1aL), Double.longBitsToDouble(0x3fed6b51abc5bcdbL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 23, 0, "\u3f46\uda9d\udfeb\ud89e\udc54\ud835\ude36\udb9a\udc10\udb1c\udfc8\ud9fd\udccb\udbb1\udecf\ud8d0\udfb4", "\u6179", "\udbb1\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udcb1\udb96\udf79\udaad\udd73\ud936\ude30",
        41, 63187, 496873602, -5145998547634977605L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fe129fa1e1bb329L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 4, 38, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\ub70b\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udcb1\ud8a6\udf01\ud949\udf55\ud8c4\ude17",
        40, 63187, 496873602, -5145998547634977605L, 67971L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 3, 28, 13, "\ud9a3\udf4f\uda9d\udeba\udb33\udd0e\udb4f\ude75\uad97\ud891\uddfd\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6219", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud9c1\udc0f\udbd0\ude8a\ud87d\ude0a\udb0b\udf52\ud992\udf09\udac0\udc99\ud956\udd02\udb1e\udc5b\ud857\udc6f\ud8c4\udddd",
        40, 74466, -2089094041, -5145998202596491475L, 67444L, true, false, (char) 25575, (char) 3980,
        Double.longBitsToDouble(0x3fea1340221de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 25, 16, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\udb93\ude89\ud969\udf4c\udb83\udd0e\ud9e8\uded9", "\u6231\u52ef\u72cc\u4d25\u3cc2\ub2df", "\udadb\udc9f\ud854\ude75\udbb1\udc24\ud8df\uddb1\udbe2\udc84\udad6\udf90\udaf2\udcc1",
        27, 88720, 1008905868, -1117103919288765213L, 14070L, true, false, (char) 37919, (char) 55502,
        Double.longBitsToDouble(0x3fe7bd1461ec834bL), Double.longBitsToDouble(0x3fe57b7fce2c9b36L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 1, 12, "\ud9a3\udf4f\uda9d\udeba\ud939\udc92\udaff\udc69\ud895\udd1b\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, -1231179646, -5145998547634977605L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1d4589L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 21, 21, 13, "\ud9a3\udf4f\ube05\uda0d\udd70\ud858\ude9a\uae3e\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\uda6e\udd7d\udab0\udd21\ud992\udc0f\udac6\ude90\ud8ad\udcb1\udb96\udf79\ud949\udf55\uda5d\udc63\ud83d\ude5c\uda81\udc2b\udad2\udeb5\ud877\udd31\ud87c\udf68\udbad\udd0e\ud840\udf1f",
        41, 17604, 1169901743, 2828575216849223272L, 79683L, false, true, (char) 51983, (char) 23298,
        Double.longBitsToDouble(0x3fec81c011eba314L), Double.longBitsToDouble(0x3fef83679ae462baL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 39, 28, 13, "\ud9a3\udf4f\uda9d\udeba\uda93\udd5e\uda73\udcf2\ud894\ude72\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u800e", "\uda31\udc4c\ud9e6\udf4f\ud94f\udc48\udbd6\udef9\ud91e\udf43\ud908\ude75\ud821\udf17\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud809\udf61\udb96\udf79\ud949\udf55\uda0e\udf7d",
        46, 40631, 496873554, -5145998547634977605L, 70260L, false, true, (char) 22014, (char) 37478,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 41, 14, 32, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\uda39\udea3\ud9cd\udf9e", "\u6231", "\ud82a\udda8\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, 496873602, 6640671952145629261L, -63628L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 27, 28, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\ud9da\udf99\ud9be\udde7", "\u92ba", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udae0\udf69\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, 496873602, -5145998547634977605L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 40, 5, 13, "\ud9a3\udf4f\uda9d\udeba\udb16\ude86\ud9cf\udde3\uad97\ud874\ude99\ud972\ude50\ud998\udf4e\uda63\udcf6", "\u8b50\u52ef\u72cc\u2139\u3cba\ub2df\u008b\ua21c", "\udb3c\udcd0\ud997\udf31",
        39, 90711, 2078686564, 5301360550777508499L, 80997L, false, true, (char) 15696, (char) 13593,
        Double.longBitsToDouble(0x3fc43905bbde89b8L), Double.longBitsToDouble(0x3fdec834b15edff2L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 28, 13, "\ud9a3\udf4f\ud95f\udf77\ud92c\udfe6\udaaa\ude2e\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24\ud81c\ude3a\udbbe\udd72\udb46\uddd3\udab2\udfed\ud80d\uded6\uda31\udc4c\ud9e6\udf4f\uda22\udfea\ud906\ude0a\ud91d\udf16\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f", "\u09c9\u0561\ubdd1\u2d87\u8b85\ubb9b\ua0f1\u921c\u0302\u4dcb\u632a", "\ud84c\udc6d\uda4c\uddd0\ud9dc\ude30\ud878\udfd1\ud8a4\udeca\ud84e\udd4a\ud966\udeeb",
        48, 72240, 168490084, -2156542171135377782L, 20635L, false, true, (char) 52513, (char) 65474,
        Double.longBitsToDouble(0x3fe1faebcb144abaL), Double.longBitsToDouble(0x3fd0fb0348931918L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 38, 31, 13, "\ud9a3\udf4f\uda9d\udeba\u1659\000\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\udbcf\udf22", "\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\000\000\000\000\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udc4d\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, 496828416, -5145998547258179584L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fe80000001de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 32, 25, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\ud81f\udc58\uda09\udcbb\ud983\uddae\ud8d6\ude0e\ud96a\udcba", "\ucca2", "\udbf6\udfae\uda04\ude62\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udaf7\ude14\uda8c\udd3c\udb96\udf79\ud949\udf55\ud8c4\ude17",
        21, 63070, 496873602, -4440026319202382308L, 17615L, false, true, (char) 41867, (char) 57065,
        Double.longBitsToDouble(0x3fe1622e6c592641L), Double.longBitsToDouble(0x3fe9910a8a1de289L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 34, 39, 0, "", "\u2469", "\udb4d\ude86",
        11, -1000, 0, 3746994889262689265L, 44379L, false, false, (char) 0, (char) 64709,
        Double.longBitsToDouble(0x3fd3a816e691d388L), Double.longBitsToDouble(0x3faabef7a7077ba0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 42, 28, 13, "\uda2e\udc48\ud8d1\udeb7\ud929\uddd6\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udba8\udca1\ud9be\ude24", "\u6231", "\uda2f\ude4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\udaf4\udc22\ud876\udf0c\uda1c\udea2\ud9e1\udcf7\udab0\udd21\ud9e7\udfc3\udae7\udd93\udb1e\udf0a\udaa0\udf46\ud884\udc92\ud8c4\udde8",
        2, 63187, 1553838210, -7021402889381051167L, 82532L, false, false, (char) 31719, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e95297d655e4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 33, 38, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\udb2a\udf46\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\uda6c\udd91\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, 496873602, -5145998547634977605L, 67444L, true, false, (char) 25591, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62d1de289L), Double.longBitsToDouble(0x3fd8ea280c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 26, 34, 8, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\u5a63\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\ud9c3\udc64\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb30\udece\uda34\udf24\udab0\udd21\ud980\udd0f\uda72\udc71\ud8ad\udc7e\udb96\udf79\ud949\udf55\uda67\udfeb",
        7, 76400, -979521406, -5145999786280057669L, -90882L, false, true, (char) 10905, (char) 33403,
        Double.longBitsToDouble(0x3fe1622ddc592641L), Double.longBitsToDouble(0x3fef6ae62a1de289L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 41, 24, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, 496873602, -5145998547634977605L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fb9b4f150ef2738L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 34, 35, 13, "\ud9a3\udf4f\uda9d\udeba\ud856\udde0\uda87\udc43\udb1f\ude99\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9df\udf4f",
        26, 57384, 1998782261, 5488894515047949234L, -54515L, false, false, (char) 50840, (char) 58390,
        Double.longBitsToDouble(0x3feaabdf3406be92L), Double.longBitsToDouble(0x3fc52b655f9d03fcL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 35, 25, 11, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\udbbe\ude24\ud81c\ude3a\ud8b1\udd92", "\u72cc\u4d25\ud5a6\ub2df\u6381", "\udb3d\uddec\ud9e1\udcf7",
        23, 44900, -1498276387, 8907906086570440533L, 75756L, false, true, (char) 42338, (char) 30768,
        Double.longBitsToDouble(0x3fd0f959c9b5112aL), Double.longBitsToDouble(0x3fec774c5019a942L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 26, 3, 44, "\ud9b1\ude09\uda9d\udeba\uda29\udd69\udb4f\udf20\uda25\udf70\ud867\udf86\ud9a7\udd4b\ud915\udcd4\ud846\uddc8", "\uac18\u295e\u20b8", "\ud9c5\udc50\ud9df\uddb4\ud944\ude1c\ud869\udf49\ud912\udeec\ud9e1\udcf7\udab0\ude20\ud9d8\udd3b\ud9a5\udce2\ud967\ude03\ud879\udf77\ud8a9\udddc",
        4, 26153, -1212066869, 3112018814835211535L, 77266L, true, false, (char) 29191, (char) 35354,
        Double.longBitsToDouble(0x3fee6367361b4f1aL), Double.longBitsToDouble(0x3fb649b1c1e7fad8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 18, 14, "\ud9a3\udf4f\uda9d\udeba\udb29\udc68\ud87d\udfa1\u35ab\udb24\udc2c\u6f43\ud817\udeee\u0749", "\u6231", "\ud837\udf8e\uda0a\udc90\uda22\udfea\u2a0e\ud958\udf1d\ud85d\udef1\udb3d\uddec\udb81\udc46\udabd\udf15\udac0\uddc3\udb9f\uddf1\ud8ad\udcb1\udb96\udf79\udacb\ude36\ud84d\udd12\ud988\udf3c",
        5, 76597, -1195135978, -1618335178329076850L, -99539L, false, true, (char) 17910, (char) 39939,
        Double.longBitsToDouble(0x3fb64990691ffe28L), Double.longBitsToDouble(0x3f87597f23a55e40L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 21, 32, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\udb19\ude2d\ud8e9\ude8c\udbe3\udddc\udb83\udccb\ud93b\udec4", "\u6231", "\udb6c\udedb\udbb6\udf1f\uda83\udd5f\u2a0e\udbd4\udea3\udab8\udc2c\udb56\ude6e\ud9e1\udcf7\udab2\ude21\ud9d8\udd3b\udac0\udc99\ud9e3\udfed\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 91219, -1784877160, -5145999127455562565L, 39645L, false, true, (char) 62910, (char) 47272,
        Double.longBitsToDouble(0x3fe1622ddc592641L), Double.longBitsToDouble(0x3fbe4b71750ca100L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 31, 42, 18, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\ud832\udce5\ud95a\udf5b\ud81b\udf77", "\u52ef\u72cc\u4d25\u412e\ub2df\u6381", "\udb3d\uddec\ud9e1\udcf7",
        23, 932, -1498276387, 8927890809916897109L, 75756L, true, true, (char) 45666, (char) 30817,
        Double.longBitsToDouble(0x3fe07cace48f78caL), Double.longBitsToDouble(0x3fec774c50a1c82dL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 15, 43, 18, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\u2a0e",
        9, 48416, -1960766256, -1014957209393342637L, 23427L, false, true, (char) 45883, (char) 25240,
        Double.longBitsToDouble(0x3fe461c157e73c22L), Double.longBitsToDouble(0x3fcc7e0ffe622260L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 21, 44, 13, "\ud960\udd2f\ud829\udc88\udbdf\udfc5\udb4f\uded5\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e", "\u91d2\u6231\uba72\u72cc\u4d25\u3cc2\ud353\u6381\ubabc\u9e84\u3cd9\uc3bf\u96e4\u023c", "\ud9ef\udccc\ud949\udf55\ud8c4\ude17\udb61\udecf\uda59\uddd9\ueaba\udba1\udda8\ud82f\udc6e\ud814\udcc6\ud95a\udf0c\uda8b\udf8f",
        27, 23968, 1469682764, -16487894336490205L, 82898L, false, false, (char) 1354, (char) 13799,
        Double.longBitsToDouble(0x3fd5e6a7231fe706L), Double.longBitsToDouble(0x3fe0d79d58071305L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 21, 16, 38, "\ud804\udc26\uda9d\udeba\ud929\udd69", "\u0b39\u00b2\u7e51\uc3c6\u8522\u91d0\u6231", "\udbb7\udc4b\ud8d3\udd53\uda22\udfea\u2a0e\udbd4\udea3\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab2\ude21\ud9d8\udd3b\udac0\udc99\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 75859, -1784877160, -5145999127455562565L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fd23ffc543be5f4L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 21, 7, 18, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\udb3c\udd7c\uda24\udddc\ud88e\ude6c\ud89b\udc03\ud9be\ude24", "\u5199", "\udac6\udd0c\ud822\ude74\udac8\udd15\u3e6c\ud987\udc7b\uda81\udd7e\ud893\udcd3\udab0\ude5f\u3d6e\ud8ca\ude09\udb5e\udd26\udb83\udd1c",
        50, 88598, 1008905868, -1117103921515199005L, 17786L, true, false, (char) 13483, (char) 55502,
        Double.longBitsToDouble(0x3fe1c52c61288c89L), Double.longBitsToDouble(0x3f74790805dd4380L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 21, 36, 15, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24\ud81c\ude3a\udbbe\udd72\udb46\udd77\udab2\udfed\ud845\udc66\uda31\udc4c\ud9e6\udf4f\uda22\udfea\ud824\udf57\udbd4\udea3\ud876\udf0c\udb3d\uddec\ud8e4\udcb9\udab2\ude21\ud9d8\udd3b\udae5\udee8\udbed\ude8f\udb96\udf79\ud949\udf55\ud966\udf46", "\ub180\ua06a", "\ud95a\udf4c\uda8b\udf8f\ud912\udc85\u2ccb\ud84c\udc6d",
        8, 11347, -1792458211, 1510299676212639259L, 11830L, false, false, (char) 25638, (char) 16401,
        Double.longBitsToDouble(0x3f81e01c5478dc80L), Double.longBitsToDouble(0x3fdcd5781626e888L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 27, 25, 18, "\udb6a\udc71\uda9d\udeb0\ud929\udd69\ud9a0\udd69\udbd6\udd3c\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24\ud81c\ude3a\udbbe\udd72\udb46\uddd3\udab2\udfed\ud845\udc66\uda31\udc4c\ud9e6\udf4f\ud9d8\ude24\u2a0e", "\u0bb2\u451a\ud013\u6217", "\udb96\udf31\ud949\udf55\ud8fa\udc0b\ud8c1\udc31\uda59\uddd6\udbf0\udd52\ud89c\udd8b\ud87c\udf68\udb3e\udc43\ud95a\udf4c\ud83e\udd97\ud912\udc85\u2ccb\ud84c\udc6d\uda15\udc55\uda25\udc5e",
        49, 62046, 177845787, 1120782602995680647L, -75869L, false, false, (char) 13520, (char) 5769,
        Double.longBitsToDouble(0x3fd0a56cc0191deaL), Double.longBitsToDouble(0x3fefd0e6b475dfffL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 36, 38, 18, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\udbdc\udcd3", "\u6231\u52ef\u72cc\u4d25", "\ud968\udd62\udbd4\udea3\ud9cd\udd19\udb3b\udf87\uda0e\udcf7\udab2\ude21\uda00\udf09\udac0\udc99\ud8ad\udcb1\udb96\udf79",
        8, 15868, -508613657, -115253766603150264L, -2907L, false, true, (char) 55502, (char) 42101,
        Double.longBitsToDouble(0x3fdec834b15edff2L), Double.longBitsToDouble(0x3fe1622dda946f92L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 35, 17, 10, "\ud9a3\udf4f\uda9b\udf6b\ud929\udd69\udb4f\udf20\uad97\ud90e\udef3\ud9a1\udf87\ud93c\ude8d\ud9be\ude24", "\u6231", "\ud8fc\udec1\ud9e6\udf4f\uda22\udfea\u2a0e\udbd4\udea3\ud876\udf0c\udb8b\uddf3\ud9e1\udcf7\udbf0\ude7f\udae9\udfb4\udb3c\udcb6\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        33, 89787, -442699880, -3998885242458395199L, 67444L, false, false, (char) 25575, (char) 37578,
        Double.longBitsToDouble(0x3fd23ffc543be5f4L), Double.longBitsToDouble(0x3fc1d2a5386d5da0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 25, 22, 33, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\ud8a6\udf4c\uad97\ud891\ude88\ud969\udf4c\ud80a\udfd2\ud879\udfd4\ud81c\ude88\udbbe\udd72\udb3c\udeeb\ud89a\udffa\uda28\udf87\uda31\udc4c\udb00\udf7c\uda37\ude8c\u2a0e\ud8c9\ude9f\ud876\udf0c\udb3d\uddec\ud9c7\udfab\uda9f\uddce\ud9d8\udd3b", "\u09c9\ud0d7\ubdd1\u104e\u5f5e\ub180\ub3ad\u923d\u7964\u5d6c\u08a7", "\ud84c\udc6d\uda15\udc55\uda25\udc40\ud878\udfd1\u4d62\ud983\udc04\udbbe\udce0\ud9ec\udd68\uda73\uddd8\ud8e2\udcb2\ud8ad\udebf\ud88a\udf92\ud821\udd89\ud987\udd0f\udaab\udca7\ud9b0\udc63\udb97\uddd2\uae5d\ud849\udd97\ud944\udfcf\udba5\udc92\uda46\udfba\ud9c2\udef8\ud8d8\udc35\ud837\udc6b\udb67\udf87\ud985\ude53\ud8b8\udc9f\u07a9\ud9ca\udcd7\ud8fd\udc64\udaaa\udeb9\uda2a\uddb5\udb6b\udec1\ud990\udfee\ud853\ude29\ud819\ude5f\uda59\udc03\uda65\ude89\ud9b3\udfcc\ud8ee\udeec\udbbb\udef0\ud82f\udcc1\ud80c\uddfd\udb39\udd3c\ud97e\udc95",
        6, 88240, -2014629343, -3634305708126418631L, 52552L, false, false, (char) 43689, (char) 7055,
        Double.longBitsToDouble(0x3fd8a89c2305654aL), Double.longBitsToDouble(0x3fefaf56165db722L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 21, 40, 19, "\ud9a3\udf4f\ud885\udd3b\ud93b\udfb6\udb4f\udf20\uad97\ud891\ude88", "\uc3c6\u8522\u91d0\u6231\u52ef\u72cc\u4d25\u3c59\ub2df\u6381\u598c\u9eb4\u01b5\u9a62", "\udac0\udc99\ud8c1\udcb1\uda81\udd58\ud933\udd41\ud8c4\ude17\ud83d\udefd\uda59\uddd9\udbf0\udd52\uda44\udcd9\ud87c\udf68\ud9d8\udf30\ud877\udf97\uda67\uded8\ud912\udc85\u2ccb\ud84c\udc6d\uda15\udc55\ud92b\udf81\uda22\udd0d",
        36, 21875, -1583415343, -2517861505728778205L, 82476L, false, false, (char) 37104, (char) 43794,
        Double.longBitsToDouble(0x3fbb0fd8ecfd98f0L), Double.longBitsToDouble(0x3fd13bc3954f015eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 36, 41, 8, "\ud992\udd6a\u5938\uda79\udcc0\udb4f\udf20\u1b97\ud972\udde3\ud81d\udd18\uda78\udd1d\ud856\udd57", "\u2b0a", "\udbed\uddab\ud9e6\udee7\uda22\udfea\uda38\udf86\ud80c\ude9f\udb42\udc32\ud8fa\ude67\ud9b2\ude14\ud87e\ude91",
        21, 57643, 2078686564, -6889883640769370884L, -2907L, false, true, (char) 45262, (char) 40501,
        Double.longBitsToDouble(0x3fdec833c15edff2L), Double.longBitsToDouble(0x3fe1622ddd79491fL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 43, 34, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69", "\u0b39\u00b2\u7e51\uc3c6\u9e21\u91d0\u6231", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\udac5\udce9\ud96f\ude60\ud960\uded0\udac0\udc99\ud8ad\udcb1\udb96\udf79\ud949\udf55\uae8c",
        -5, 7779, 0, 41939771153089723L, -5300L, false, false, (char) 0, (char) 27737,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 31, 31, 11, "\ud9a3\udf4f", "\uc88d\ubb96\u0a43\u00b2", "\ud81c\ude3a",
        53, 70337, -14797829, 246564184260608L, -99947L, false, false, (char) 0, (char) 45260,
        Double.longBitsToDouble(0x3fe29f8f5634a7e3L), Double.longBitsToDouble(0x3fd00a8bb0c94d64L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 31, 15, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c", "\u8522\ud300\u113d\uced3\u72cc\u92c6\ud43a\ub2c9\u008b\ua21c\u9eb4\u3c8e\u16d8\u8e80\u66c5\ucc04\u903c\u09c9\u8e97\ubdd1\u2d87\u98bf\u52f2\ua071\u921c\u7964\u29de\u632a", "\uda35\udfff\udb1f\udeaf\udb93\ude66\ud878\udfd1\ud8a4\udeca\ud9eb\udcce\ud971\udeae\ud812\udc7a\uda15\udcc1\ud834\udcc9\udbbe\udd48\ud809\udfa7\uda31\udcc6\udaea\udeb2\udb1c\udc52\ud881\udf21\ud816\ude24\udac6\udf7f\ud9b5\ude46\udb8e\udf10\ucb88\udb8a\udd53\udb36\udd72\ud9f3\udda8\uda42\udc2c\udb26\udd87\ud926\udec1\udb4f\udcfa\udb46\udca0\uda4c\ude28\udbab\udf2e\ub774\ud8a6\ude62\ud838\udc77\uda14\udd58\uda90\udd3a\udae0\ude7a\ud943\ude33\udb4c\uddfd\udb6a\uddfb\udbf8\udf70\ud9d9\udf81\udbb0\udf4e\udaaa\udee2\uda28\uddfd\ud91e\udd14\uda0c\udfaa\ud8d0\ude98",
        13, 83598, -1269598274, -4986302140076716248L, 9955L, true, false, (char) 18215, (char) 52137,
        Double.longBitsToDouble(0x3fdd9e5f4e5022feL), Double.longBitsToDouble(0x3fec67d013e354adL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 0, 5, "\ud9f8\udd9f\udae5\udd3f\ud94e\udc80", "\u0b39\u00b2\u7e51\uc3c6\u85ca\u8711\u68a6", "\uda31\udc4c\uda02\udc33\uda4c\udcea\uda1c\udecc\u968b\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\udac8\udc12\udabf\udfe0\ud8ad\udcb1\ud80d\udf13\udadd\udc18\udae5\udd54",
        5, 92144, 27508693, -5174821075434179909L, -95743L, true, true, (char) 9737, (char) 36762,
        Double.longBitsToDouble(0x3fe1622ddc592641L), Double.longBitsToDouble(0x3fef6ae62a1de289L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 41, 40, "\ud9a3\udf4f\udbbe\udf76\ud929\udd43", "\uc89d\u1d81\u7e51\uacbf\u8522\u91d0\u6231", "\uda31\udc4c\udafe\udd19",
        0, 15617, 2008742965, 745893774204277968L, 76557L, true, true, (char) 10007, (char) 19233,
        Double.longBitsToDouble(0x3fed0af3bc06be21L), Double.longBitsToDouble(0x3fc1870546891bbcL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 42, 13, 32, "\ud9b2\udcc1\uda9d\udeba\ufeb7\ud8d7\udf18\ud9ff\udfe0\u14a0\ud969\udf4c\udb83\udd0e\ud9be\ude24\ud9fa\udd25", "\u52d5\u72cc\u8784", "\udbd6\udeb3\udb19\udda2\ud920\udd62\ud82b\udccf",
        37, 60499, -1163999767, -6435048381115371164L, -80806L, false, false, (char) 31753, (char) 42338,
        Double.longBitsToDouble(0x3fc0529316590ac4L), Double.longBitsToDouble(0x3fc76e12ae3ba628L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 10, 13, 32, "\ud9b2\udc4f\uda9d\udeba\ufeb7\ud90d\ude24\ud9ff\udfe0\u14a0\udb45\udf5a\udb83\udd0e\ud9be\ude24\ud9fa\udd25", "\u52d5\u3d0a\u197d", "\ud9e5\udd47\udb2b\udc5a\ud920\uddd6\udadd\udf48\ud818\ude35\udab0\udd21\ud904\uddd2\u2058\ud864\udca6\udb96\udf79",
        4, 15868, -260096025, -7739237071718338430L, 65051L, false, true, (char) 17282, (char) 31885,
        Double.longBitsToDouble(0x3fe5ce79d3379e41L), Double.longBitsToDouble(0x3fe3e5dd3ccdc7baL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 23, 23, 40, "\ud9b2\udc65\ud8c5\udcb8\ud9e5\ude2b\ud8d7\ude3a\ud9ff\udfe0\u14a0\ud969\udf4c\udb60\udf5a\ud9aa\udfaa\ud8e8\udd1c", "\uc1bc\ucb8a\u4de0", "\udbd6\udeb3\udb19\udda2\ud920\udd62\ud82b\udccf",
        37, 60499, -1163999767, -6435048381115371164L, -80806L, false, false, (char) 33688, (char) 52343,
        Double.longBitsToDouble(0x3fc0529316590ac4L), Double.longBitsToDouble(0x3fc76e12ae3ba628L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 26, 6, 5, "\ud9a3\udf4f\uda9d\udeba\ud9f5\udf6a\udbad\udf2f\udb6b\udf86\udaa5\udde9\ud882\udfda\udb83\udd0e\ud9be\ude24\ud81c\ude3a\udbbe\udd72\udb46\uddd3\udab2\udfed\ud845\udc66\udac6\ude8f\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21", "\u903c\u09c9", "\uda08\udc29",
        3, 53602, -1198146154, -1618335178329076850L, -92462L, false, true, (char) 47272, (char) 25575,
        Double.longBitsToDouble(0x3fb675905f6ae628L), Double.longBitsToDouble(0x3fe0e87e898e9529L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 19, 19, 9, "\ud9a3\udf4f\ufc8e\uda1c\udca8\udab1\udef1\udb9f\udca6\uda22\udded\ud892\udf71\ud977\ude0b\udabd\udc45\uda4c\udfdb\ud9ae\udf1d\ud95f\ude9f\uda3c\udd73\ud824\udd95\udac6\ude8f\ud9e6\udf4f\udb23\udf0b\udb02\udd8d\ud91e\udfa6\udb7a\udf96\ub033\udba5\udc40\ud919\udf6f", "\uc4fc\u593d\u8e95\ubdc3\u73cb\u8b27\ub2c5\ua0c5\u921c\u7964\u29de\u46c1\u97f0\u639c\u2e55\u8b26\u5c9a\u9bab\ucd52\u6d4c\uc8ea\uc7e6\u487b\u8ae4\u6906\u3dd1\u710e\u99c8\u4ab1\uaf46\u53fd\u64fa\ua8de\u6b28\u6fbb\u7aa4\u6140\u5ff3\u1f68\u27f0\u4999\u0bd3\u940a", "\uda56\udf05",
        6, 8073, 1750759772, 5600830768383384832L, 47761L, true, false, (char) 31584, (char) 27135,
        Double.longBitsToDouble(0x3fba2e11eae42e38L), Double.longBitsToDouble(0x3fd195d18f974faaL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 33, 10, 25, "\ud9a3\udf4f\uda9d\udeba\ud9f5\udf6a\udbad\udf2f\udb6b\udf86\udaa5\udde9\ud882\udfda\udb83\udd0e\ud9be\ude24\ud81c\ude3a\udbbe\udd72\udb46\uddd3\udab2\udfed\ud845\udc66\udac6\ude8f\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udba3\udddc\ud9e1\udcdc\udab0\udd21", "\u903c\u09c9", "\uda08\udc29",
        3, 53602, -1198146154, -1618335178329076850L, -92462L, false, true, (char) 47272, (char) 25575,
        Double.longBitsToDouble(0x3fb675905f6ae628L), Double.longBitsToDouble(0x3fe0e87e898e9529L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 26, 18, 2, "\ud80e\udcb9\uda9d\udeba\ud82c\udce6\udbad\udec3\udb6b\udf86\udaa5\udde9\ud882\udfda\udb83\udd0e\ud9be\ude24\ud81c\ude3a\udbbe\udd72\uda00\uddd0\udba8\ude49\udad8\uded0\udb88\ude90\ud9e6\udf4f\uda22\udfea", "\u0b39\u7d0a\u06e1\u1715\u46f6\ucc04\u903c", "\ud9af\uddba\uda08\udc29\udb12\udf36\udb2a\ude40\uda44\udd60\ud87c\udf68\udb3e\udc43\udbc6\udd21\ud883\ude72\ud912\udc3c",
        1, 58900, -1117804849, 8384668886131925386L, 94990L, true, false, (char) 40392, (char) 15577,
        Double.longBitsToDouble(0x3fd33ca4fbda0684L), Double.longBitsToDouble(0x3fcc01dd6ead6480L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 9, 22, "\ud9a3\udf4f\uda9d\udeba\ud9f5\udf6a\udbad\udf2f\udb6b\udf86\udaa5\udde9", "\uc3c6\u8522\u5316\u4fe9\u2eab\u72cc\u37fa\u3cc2\u7da6\ua0fe\u2e8c\ua5f9\u339f\u21bc\u2f88\u66c5\ucef2\uaa49", "\ud8c4\ude17\uda08\udc29\udb79\udc6c\u89f9\uda27\ude5d\ud9b3\udee4\udb3e\udc43\ud86e\udd1f\ud93a\uddce\ud9f1\udc3d\u2ccb",
        7, 31201, -1205875519, -7348009158548674136L, 47230L, true, false, (char) 46937, (char) 50193,
        Double.longBitsToDouble(0x3fecf0d6f7ecb04aL), Double.longBitsToDouble(0x3feab581c1be7b9eL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 42, 30, 13, "\ud933\udc0b\udb67\udd23\uda70\udffb\ud8de\udef5\ud85e\udf44\ud891\ude36\ud821\udd05\uda78\udeff\udbb2\udc3f\ud816\ude96", "\ub6f4\u11b1\uc3d1\u1f90", "\ud91e\udf43\ud876\udf0c\udb3d\uddec",
        10, 60499, -1464129996, -6435048081625446300L, -32291L, false, false, (char) 31753, (char) 42338,
        Double.longBitsToDouble(0x3fec138cc5961d80L), Double.longBitsToDouble(0x3fc77712aa72a628L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 38, 38, 41, "\ud933\udc0b\udb67\udd23\uda70\udffb\ud8de\udef5\u7925\ud891\ude88\udb7e\udfb7\ud80e\udf0e\udbb2\udc3f", "\u6231\u52ef\u62df", "\uda22\udfea\udbd6\udeb3\ud91e\udf43",
        53, 46744, 1642735052, 5252277185773512244L, -39813L, false, false, (char) 46382, (char) 1896,
        Double.longBitsToDouble(0x3fec13884d961dfdL), Double.longBitsToDouble(0x3fc77712aa3ba628L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 10, 42, "\udb61\ude76\uda9d\udeba", "\uc077\u5adb\u00b2\u7410\uc3c6\u8522\u91d0\u6231\u52ef\u4e0a\u48b4\u3cc2\ub2df\u008b\u7b2f\u9e5e\uc24b\u451a\u8de4\u66c5\u115e\u82db\uc36b\u62b3\u2801\u9f27\ubed2\ubb30\ua0f1\u921c\u5090\u2a29\u3a94", "\udb08\udd8b\udbe4\ude4e\ud9dc\ude22\ud878\udfd1\ud8a4\udeca\ud90b\udd21\uda03\uddbf\ud989\udeed\uda6f\udf3b\ud811\udf5e\uda74\udd35\udb7b\udf0d\ud9aa\udd65\ud9fe\uddb2\ud862\udf67\udbba\udf68\uda5c\ude14\udb9f\ude55\udb2b\udcf4\udb83\ude7c\u8612\ud981\udd92\ud872\udd0a\ud8fe\udccf\ud8fb\udd9f\ud833\udc22\ud896\udc69\uda41\udec6\ufb42\udb05\udf5d\udbf1\ude6b\ud9d0\uded4\ud9bf\udfdb\ud99b\udc4e\ud92b\udd53\udb9e\udd03\uda11\udc8e\udb99\udd74\ud82f\udc55\ud974\udfa4\u4de8\udb3d\udda5\ud9e1\udf58\ud9b2\udc4e\uda60\udd2d\udbff\udc27\u663e\ud899\udcbe",
        0, 90112, -1922766013, 2633082993315648316L, 87974L, false, true, (char) 62346, (char) 38872,
        Double.longBitsToDouble(0x3fcd1a01eebec924L), Double.longBitsToDouble(0x3fee144a91c5bcdbL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 25, 24, 44, "\udb61\ude76\uda9d\udeba", "\u1a02\u0b39\u00b2", "\uda35\udc8f\udbbe\udd50\udb46\uddd3\udab2\udfed\ud83b\udfa4\ud9f7\udc6e\udb4f\udc62\ud97f\udf39\udbd6\udeb3\ud91e\udf43\ud82c\udd20\udbe9\udee1\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udadd\uddf1\udba0\udf41\u4ca5",
        8, 37204, -47931132, -4172397961191509993L, -2907L, false, true, (char) 53670, (char) 41347,
        Double.longBitsToDouble(0x3fdec834b1cadff2L), Double.longBitsToDouble(0x3fe1622dde393941L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 34, 34, 42, "\udb61\ude76\uda9d\udeba", "\uc077\u0b39\u00b2\u7410\u53c6\u8522\u91d0\u6231\u52ef\u4e0a\u48b4\u3cc2\ub2df\u008b\ua21c\u9eb4\uc24b\u451a\u8de4\u66c5\u695d\ub303\u32e3\u8e97\u099e\u9e81\ubf5d\ubb30\ua0f1\u921c\u5090\u2a29\u632a", "\udade\uddd6\udb36\udea0\ud9dc\ude22\ud878\udfd1\ud8a4\udeca\ud90b\udd21\udb9f\ude2c\ud969\udd14\udb38\udc38\udac8\udd94\ud8d1\udd9e\udb96\ude7e\ud9aa\udd65\ud9fe\uddb2\ud862\udf67\udb4e\ude72\ud856\uddcd\udb9f\ude4b\udb2b\udcf4\udb83\ude7c\u8612\ud981\udd92\udb1b\ude7e\ud8fe\udccf\ud8fb\udd9f\ud833\udc22\ud896\udc69\uda00\udefe\uc9f9\udb05\udf5d\udbf1\ude6b\ud9d0\uded4\udbc9\udf80\ud929\udea0\ud8e2\udd0d\uda74\udecd\ud821\ude8d\udb99\udd74\ud82f\udc55\ud83b\ude40\udb2e\udec5\udb51\udc9e\ud9e1\udfbe\ud9b2\udc4e\uda60\udd2d\udbff\udc27\u663e\ud990\udc78",
        20, 90074, -1922766013, 2633082993315648316L, 87974L, false, true, (char) 59028, (char) 24531,
        Double.longBitsToDouble(0x3fde23703c325f1aL), Double.longBitsToDouble(0x3fed6b51aac5bcdbL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 2, 8, 22, 0, "\u3f46\uda9d\udfeb\ud89e\udc54\ud835\ude36\udb9a\udc10\ud8c5\udefb\ud9fd\udccb\udbb1\udecf\ud8d0\udfb4", "\u6179", "\udbb1\udc4c\ud9e6\udf4f\uda22\udfea\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\ud8ad\udcb1\udb96\udf79\udaad\udd73\ud936\ude30",
        2, 26348, 496873602, -5145998547634977605L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62a1de289L), Double.longBitsToDouble(0x3fe129fa1e1bb329L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 11, 27, 13, "\ud9a3\udf4f\ube05\uda0d\udd70\ud858\ude9a\uae3e\ud891\ude88\udb8a\ude5c\ud8b8\udc3f\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f",
        26, 57384, 2008742965, 745893774196020432L, 63875L, false, true, (char) 45883, (char) 25240,
        Double.longBitsToDouble(0x3fe461c157466322L), Double.longBitsToDouble(0x3fcc7e0fe209ee60L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 39, 39, 0, "\ud9a3\udf4f", "\u8cb3", "\ud9f2\udc10\000",
        48, 21437, -2118849551, 207571474448384L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fe000000034a7e3L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 40, 40, 20, "\ud85e\ude1c\uda9d\udeba\ud81c\udc08\ud94c\udce8\udbca\udc0b\ud923\uddf1\uda26\ude31\udad7\ude38\udb40\udc67\ud832\udeb2\u14a6", "\ud6d5\u12f7\u7a46\ub2df\u008b", "\uda49\udca7\udb67\udf95\ud997\udf31\ud911\udda5\udae7\udee8\ud8ad\udcb1\ud926\udf2e\uda5f\udec7\ud8cc\udc91\ud83d\udefd\uda52\udd39\ue6c9\uda44\udd9c\ud87c\udf68\udb3e\udc43\ud93c\udf1d\uda8b\udf9d\ud976\udd18\udb79\udfa3\ud819\udd0f\udabd\udc32\ud83b\udea7\ud825\udf9a\ud94d\udc7b\udbe4\udf4a\uda6d\ude53",
        41, 70672, -579962901, -8034885056330549198L, 35852L, true, true, (char) 1869, (char) 16055,
        Double.longBitsToDouble(0x3facae6242d53db0L), Double.longBitsToDouble(0x3fe518b3ebdd3965L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 32, 25, 13, "\ud9a3\udf0d\uda9d\udeba\udbc9\udeca\uda60\udd0b\ud81f\udc58\ud889\udcb4\ud983\uddae", "\u63b5\u91d0\ucca2\u13d5\u72cc", "\uda22\udfea",
        6, 97909, 1715227360, -1097926428602794106L, -44244L, true, true, (char) 9646, (char) 45670,
        Double.longBitsToDouble(0x3f7afa4b461c1500L), Double.longBitsToDouble(0x3fef39e1146e9c7fL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 24, 9, 13, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\ud81f\udc58\uda09\udcbb\ud983\uddae\ud8d6\ude0e\ud96a\udcba", "\ucca2\u13d5\u72cc\u3d36\ub3d5\ub2df\u008b\ua21c\u9eb4\uc24b\u451a\u8de4\u66c5\u4a3e\u13d8\u09c9\u8e97\ubdd1\u71f8\u8b10\ubb9b", "\ud8ef\udffb\ud9a5\udda7\uda18\udd5a\udbb0\udd54\ud8f5\udd04\udb8e\ude7c\uda89\ude4f\ud812\udd79\udb89\udce5",
        4, -49, 1015896898, -8467488340090156455L, -97006L, false, false, (char) 53737, (char) 41064,
        Double.longBitsToDouble(0x3fbe175ae91bdec0L), Double.longBitsToDouble(0x3fd97993ad213c94L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 35, 35, 8, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\udb2a\udf46\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\uda6c\udd91\udb96\udf79\ud949\udf55\ud8c4\ude17",
        40, 63187, 496873602, 5734698152085870934L, 67444L, true, false, (char) 25591, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62d1de289L), Double.longBitsToDouble(0x3fd8ea280c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 33, 33, 29, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\ud9be\ude24", "\u6231", "\uda31\udc4c\ud9e6\udf4f\udaf9\uddfa\udbd6\udeb3\ud91e\udf43\ud876\udf0c\udb3d\uddec\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99\uda6c\udd91\ud863\udc7e\ud950\udfbb\ud8c4\ude17",
        40, 63187, 496873602, -5145998547634977605L, 67444L, true, false, (char) 25591, (char) 37530,
        Double.longBitsToDouble(0x3fef6ae62d1de289L), Double.longBitsToDouble(0x3fd8ea280c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 35, 25, 40, "\udb59\udd8a\udaa1\udc1a\uda2b\udccd\udb4f\udf20\uad97\ud891\ude88\ud969\udf4c\udb83\udd0e\udbbe\ude24", "\u3ad8", "\uda31\udc4c\udaa9\udfaf\uda22\udfea",
        5, 91255, -1285950733, -7266805951587908588L, -10160L, true, false, (char) 28112, (char) 36530,
        Double.longBitsToDouble(0x3fb5e25d7461c458L), Double.longBitsToDouble(0x3fdc5f3029c78802L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 36, 36, 15, "\ud9a3\udf4f\uda9d\udeba\ud929\udd69", "\u0b39\u00b2\u7e51\uc3c6\u8522\u91d0\u61d5", "\uda31\udc4c\ud9e6\udf4f\uda22\udfea\ud824\udf57\ud8a0\udfa8\ud876\udf2c\udb3d\uddec\ud8e4\udcb9\udab2\ude21\ud9d8\udd3b\udae5\udee8\udbed\ude8f\udb96\udf79\ud949\udf55\udadc\ude2b",
        40, 75859, -1784877160, -5145999127455562565L, 67444L, true, false, (char) 25575, (char) 37530,
        Double.longBitsToDouble(0x3fd23ffc543be5f4L), Double.longBitsToDouble(0x3fd8e9529c3629eaL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream:@?\012",
        Z.run(T, 2, 9, 9, 22, "\ud9a3\udf4f\uda9d\udeba\ud9f5\udf6a\udbad\udf2f\udb5d\udfff\udacd\udcdf", "\u509c\ub537\u13cd\u00b3\ud7a5\u732d\u37fa\u3cc2\u7da6\u723d\u0fbc\u76cc\u2f67\u21bc\u2f88\u66c5\u5269\u4cb5", "\ud8c4\ude17\uda08\udc29",
        2, 27234, -1768600941, -5256399252314305650L, -92462L, false, true, (char) 27747, (char) 30071,
        Double.longBitsToDouble(0x3fc41b0a13057314L), Double.longBitsToDouble(0x3fc347f046a26818L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveInputStream:@?\012",
        Z.run(T, 2, 32, 32, 27, "\ud9a3\udf0d\uda9d\udeba\udbc9\udeca\uda60\udd0b\ud853\udf91\ud9dd\udc3e\u8f63", "\u63b5\u91d0\ud71a\ua0b4\u72cc", "\uda22\udfea",
        6, 97909, 1715227360, -1097926428602794131L, -44244L, true, true, (char) 9646, (char) 45670,
        Double.longBitsToDouble(0x3f7afa4b461c1500L), Double.longBitsToDouble(0x3fef39e1146e9c7fL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=!java.nio.charset.IllegalCharsetNameException\012",
        Z.run(T, 1, 34, 8, 1, "\ud9a3\udf4f\uda9d\udeba\ud874\uddf0\udbdc\udc5d\uda1a\ude4e\ud891\ude88\ud969\udf4c\ud91b\udd5a\ud864\udd63\ub371\udbbe\udd72\u535c\udab2\udf36\ud845\udc66\uda5d\udc98\udba3\uddcc\uda23\udc79\udbd0\uddb3\ud97b\udeb0\u23d7\udb14\udd86\ud9e1\udcf7\udab0\udd21\ud980\udd0f\udac0\udc99", "\u8aa4\ubdd1\u2d87\u8b85\u2d93\u1db0\u7e79\u2de8\u06e8\u4453\u66a2\u6354\u7a52\ud24c\u5a5e\u3f48\u3600\u67cc\u5d48\uac39\u9c0e\ucd77\u962f\u0daa\u4f2c\u254e\uc2c4\u650a\u9343\u5a1f\u94c8\u0a07\ua5d1\u8b85\u2eb9", "\udaf4\udf8f\ud9b7\udcdc",
        34, 67879, -628057616, -4167706685168772373L, 33379L, true, true, (char) 17007, (char) 49144,
        Double.longBitsToDouble(0x3fe7e054a89baff0L), Double.longBitsToDouble(0x3fc8cef77f1e0164L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 22, 6, 43, "\udb4e\udf63\udb15\udfe2\udbd4\udd2f", "\uc550\uca71\u505a\u1079\u07e0\u91d0", "\ud8d9\udd19\uda3a\udea4\ud9e6\udf4f\uda22\udfea\ud909\udeae\uda26\udff7\ud88a\udc66",
        15, -1000, 0, -6341068276835934755L, 45375L, false, false, (char) 6473, (char) 53083,
        Double.longBitsToDouble(0x3fcc7156ad1c0c74L), Double.longBitsToDouble(0x3fec40000400de9eL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 43, 43, 18, "\000\uda9d\ude5e\u1659\udb4f\ude30\uad97\uaff6\000\000\000", "\u4d73", "\000\ud9e6\ude8a:",
        -5, -1000, 0, -8421449828206116660L, -44244L, true, true, (char) 58390, (char) 31803,
        Double.longBitsToDouble(0x3f7af80000000000L), Double.longBitsToDouble(0x3fef380004e3007fL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 44, 44, 10, "\ud9ea\udc40\uda9b\udf6b\ud929\udd69\udb4f\udf13\uad97\ud90e\udef3\ud9a1\udf87\ud93c\ude8d\ud9be\ude24", "\u6231", "\ud8fc\udec1\uda01\udcdb\uda39\udc34\u2a0e\udbd4\udea3\ud876\udf0c\udb8b\uddf3\ud9e1\udcf7\udbf0\ude7f\udae9\udfb4\udb3c\udcb6\ud8ad\udcb1\udb96\udf79\ud949\udf55\ud8c4\ude17",
        33, 89787, -442699880, -3998885242458395199L, 67444L, false, false, (char) 20178, (char) 15717,
        Double.longBitsToDouble(0x3feb17fe2a7a01d1L), Double.longBitsToDouble(0x3fc1d2a7406d5da0L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\012",
        Z.run(T, 2, 42, 42, 27, "\udb44\ude54", "\uc88d", "\uc010\udba8\udca1\\\000\000\000\000\ue840\000\ud9d4\udc8a\uda22\udfea\udbd6\udeb3\udaf4\udc22\ufa70\udb74\udd1a",
        10, 60499, 0, 0L, -100000L, true, false, (char) 0, (char) 42211,
        Double.longBitsToDouble(0x3fc04e331d197274L), Double.longBitsToDouble(0x3fcc33d1c23ba628L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\0121=new org.apache.commons.compress.archivers.tar.TarArchiveOutputStream:@?\012",
        Z.run(T, 2, 41, 39, 38, "\ud9a3\udf4f\uda9d\udeba\ud9f5\udf6a\udbad\udf2f\udacf\uddf9\uda8a\udd82\ud882\udfda\ud99b\udea9\ud9be\ude24\ud81c\ude3a", "\uc942\uacd6\ud219\u8f45\u44a7\u008b\u9b4b\u9eb4\u9990\u6925\u8db6", "\ud892\udfa8\udb96\udf79",
        8, 15868, -780072217, 3812569235668709530L, -2907L, false, true, (char) 59342, (char) 34268,
        Double.longBitsToDouble(0x3fdf8834b9379056L), Double.longBitsToDouble(0x3fe2330edc0e5b2eL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=!org.apache.commons.compress.archivers.ArchiveException\012",
        Z.run(T, 2, 42, 28, 13, "T", "\uc88d\ubb96\u0b39\u00b2", "\ud81c\ude3a\udbbe\udd72\udb46\uddd3\udab2\udfed\ud845\udc66\uda2f\ude4c\ud9e6\udf4f",
        26, 57384, 1998102814, 745893774202397056L, -54515L, false, false, (char) 19858, (char) 58390,
        Double.longBitsToDouble(0x3fe8f2ff34064692L), Double.longBitsToDouble(0x3fe2ea6951e73c22L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.archivers.zip.ZipArchiveInputStream:@?\0121=new org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream:@?\012",
        Z.run(T, 2, 42, 20, 13, "T", "\uc88d\ubb96\u0b39\u00b2", "\ud81c\ude3a\udbbe\udd72\udb46\uddd3\udab2\udfed\ud845\udc66\uda2f\ude4c\ud9e6\udf4f",
        26, 57384, 1998102814, 745893774202397056L, -54515L, false, false, (char) 19858, (char) 58390,
        Double.longBitsToDouble(0x3fd43b20d9a88c1aL), Double.longBitsToDouble(0x3fe2ea6951e73c22L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.lang.String,java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveOutputStream|java.lang.String,java.io.OutputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|<init>|java.io.InputStream",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|<init>|java.io.InputStream,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|<init>|java.io.InputStream,int",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|<init>|java.io.InputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream,short",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream,short,int",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream,short,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream",
    "C|org.apache.commons.compress.archivers.dump.DumpArchiveInputStream|<init>|java.io.InputStream",
    "C|org.apache.commons.compress.archivers.dump.DumpArchiveInputStream|<init>|java.io.InputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|<init>|java.io.InputStream,int,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|<init>|java.io.InputStream,int,int",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveInputStream|java.lang.String,java.io.InputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "M|org.apache.commons.compress.archivers.ArchiveStreamFactory|createArchiveOutputStream|java.lang.String,java.io.OutputStream|new:org.apache.commons.compress.archivers.ArchiveStreamFactory:",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|<init>|java.io.InputStream",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|<init>|java.io.InputStream,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|<init>|java.io.InputStream,int",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveInputStream|<init>|java.io.InputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream,short",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream,short,int",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream,short,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.cpio.CpioArchiveOutputStream|<init>|java.io.OutputStream",
    "C|org.apache.commons.compress.archivers.dump.DumpArchiveInputStream|<init>|java.io.InputStream",
    "C|org.apache.commons.compress.archivers.dump.DumpArchiveInputStream|<init>|java.io.InputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|<init>|java.io.InputStream,int,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|<init>|java.io.InputStream,int,int",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|<init>|java.io.InputStream,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|<init>|java.io.InputStream",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|<init>|java.io.InputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveInputStream|<init>|java.io.InputStream,int",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream,int,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream,int",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream,int,java.lang.String",
    "C|org.apache.commons.compress.archivers.tar.TarArchiveOutputStream|<init>|java.io.OutputStream,int,int",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String,boolean,boolean",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String,boolean",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream,java.lang.String",
    "C|org.apache.commons.compress.archivers.zip.ZipArchiveInputStream|<init>|java.io.InputStream",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
