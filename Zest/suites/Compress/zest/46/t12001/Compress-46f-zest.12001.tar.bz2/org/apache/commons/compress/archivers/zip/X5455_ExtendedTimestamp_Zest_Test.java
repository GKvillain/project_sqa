package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class X5455_ExtendedTimestamp_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 15, 15, 4, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud865\udf95\ud885\udea1\ud987\udea1\ud950\udc72\udab8\udc41\uda3a\udf77\ud979\udd30\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udb86\uded6\udb82\ude89\uda6b\udded\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\udb05\ude29\ud9aa\udeb3\ud9fd\udc04\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94",
        14, 5918, 1596689058, 2610660175296661481L, 60415L, false, false, (char) 8552, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62bdfc34b90L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 15, 8, 4, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u76f4\uc870", "\ud839\udc5c\udaf6\ude24\uda2b\ude30\u8fd9\ud8e3\udd55\ud90d\udcd2\u4b8c\ud950\udc72\udab8\udc41\uda3a\udf77\ud979\udd30\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udb86\uded6\udb82\ude89\uda6b\udded\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\udb59\udf93\ud9aa\ude82\ud9fd\udc04\ud914\ude7b\ud9ff\udd1c\uda9f\udf2f\ud839\udf77\udaaf\udeaa",
        14, 5918, 1596689058, 2610660176085190633L, 1648L, false, false, (char) 8552, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62bdfc34b90L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 15, 15, 4, "\udbb4\udc5b\uda13\udc0a\ubeaa\uda76\ude43\uda81\udfd1\udbff\udf74\ud97e\udf81\ud8b4\uddfd", "\u1b0d\u4de1\u6933\u9af6\u7f27\u85ec\ubcfe\u9df0\u96ed\u4242\u894f\u88ec\u52bc\u779d\u8112\u163f", "\udb82\ude89\uda6b\udded\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\udacc\udf9a\ud9aa\udee1\ud9fd\udc04\ud8c7\udfb6\uda2b\udebc\uda9f\udedb\ud830\udcd2\udaaf\udeb3\ud811\udfbd",
        53, 80058, 607841689, -445566191752151187L, -29234L, true, false, (char) 63953, (char) 57179,
        Double.longBitsToDouble(0x3fe7bcf8a83b6c57L), Double.longBitsToDouble(0x3fdfc34b9491283aL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[B:[[0]] |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 12, 15, 4, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda40\udec2", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud944\ude47\uc956\udb4f\udc11\uda4a\uddbf\ud94f\ude8c\udab8\udc41\uda3a\udf77\ud979\udd30\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udaa3\udec4\udb82\uddf1\uda6b\udded\udad1\udefa\ud8fa\udee4\ud92b\udeda\udb71\uddea\udb90\udc9c\ud8e7\uddf9\ud9fc\udfb9\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud99b\udc48\ud9da\udf2f",
        14, 61674, 1596689058, 2610660175296661481L, 90459L, false, true, (char) 21781, (char) 30437,
        Double.longBitsToDouble(0x3fd393b583082faaL), Double.longBitsToDouble(0x3fb7a032afe1a5c8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 15, 15, 4, "\udaab\udde6\ud85d\ude30\ud9ff\udeb1\uda76\ude43\uda5c\uded1", "\u0bb7\ucd07\u22f9", "\udaff\udc5f\udaf6\ude24\u888c\udb35\ude72\ud980\ude87\ud885\udea1\ubf1c\ud90b\udfb8\udab8\udc41\uda3a\udf77\ud979\udd30\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udb86\uded6\udb82\ude89\ud92c\udd66\udad1\udefa\udad4\ude60\ud92b\udf24\ud98a\udeb8\udb05\ude29\ud9aa\udeb3\ud9fd\udc04\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94",
        40, 5918, 1596689058, 2610660175296661481L, 60415L, false, false, (char) 8552, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62bdfc34b90L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 14, 15, 4, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u1f40\u975b", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb",
        22, 80027, -1902275248, 6769731477215462612L, 21967L, false, true, (char) 36396, (char) 63451,
        Double.longBitsToDouble(0x3fe48e6db62844faL), Double.longBitsToDouble(0x3fe3954153e1a741L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 4, 15, 3, "\ud8b9\udded\ud9af\udf59\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud865\udf95\ud885\udea1\ud987\udea1\ud950\udc72\udab8\udc41\uda3a\uded6\ud979\udd30\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udb06\udc08\udb8b\udc98\uda6b\udded\udad1\udefa\ud950\udedd\ud90e\udeca\ud87c\udcfe\ud9ee\udefc\ud9aa\udeb3\ud9fd\udc04\udb1d\udf81\ud83f\udc61\udb1f\ude0b\ud9e2\udcf8\udaaf\udf94",
        14, 5918, 1596689058, 2610660175296661481L, 60415L, false, false, (char) 8552, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62bdfc34b90L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 9, 4, "\ud8b9\udded\ud85d\ude30\ubeaa\uda56\udfae\uda5c\uded1", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\udb1b\udda8\ud9b6\udf17\ud865\udf95\ud885\udea1\ud934\ude9a\ud81b\udeb9\ud8c8\udf36\udbac\udc6d\u8ef3\udae5\udf7a\udba1\udf77\udb31\ude09\uda91\udea1\udb86\uded6\udb82\ude89\uda6b\udded\udad1\udefa\uda10\udffe\ud92b\udeda\ud84f\udca1\udb05\ude29\ud9aa\udeb3\ud9fd\udc04\udbc4\udc93\ucfe1\ud8b5\udd1f\ud845\ude4b\udaaf\udf94",
        14, 5918, 1596689058, 2610660177343481833L, 13712L, false, false, (char) 8552, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62bdfc34b90L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[B:[[0]] |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 6, 15, 4, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud865\udf95\ud885\udea1\ud987\udea1\ud950\udc72\udab8\udc41\uda3a\udf77\ud979\udd30\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udb86\uded6\udb82\ude89\uda6b\udded\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\udb05\ude29\ud9aa\udeb3\ud9a4\uddc0\ud799\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94",
        14, 5918, 1596689058, 2610660175296661481L, 60415L, false, false, (char) 8552, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62bdfc34b90L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 2, 2, 9, "\ud8b9\udded\ud85d\ude30\ud9ff\udd16\ud8ec\ude8b\uda2b\ude60", "\u4c1e\u9444\uc870", "\udb0b\udfa3\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud865\udf95\ud885\udea1\ud987\udea1\ud950\udc72\udab8\udc41\uda3a\udf77\ud979\udd30\udae6\udc3a\udb0a\udf52\ud934\udeab\uda91\udea1\udb86\uded6\udb82\ude89\uda99\udeea\udad1\udefa\udaea\udf4f\ud92b\udf4e\ud98a\udeb8\udb05\ude29\udaca\ude73\ud9fd\udc04\ud8ea\udf83\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94",
        11, 5918, 1596689058, 2610660175296661481L, 60415L, false, false, (char) 8552, (char) 13522,
        Double.longBitsToDouble(0x3fb057270e1170a8L), Double.longBitsToDouble(0x3fadb63dbc436630L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 15, 4, "\ud8b9\udded\ud85d\ude30\ud9f7\udf2d\udb56\ude92", "\u53e4\u0bb7", "\uc798\udbca\udc48\udac0\ude6a\udaf6\ude98\uda18\udf30\ud97e\ude09\uda8f\udf4a\ud9b4\ude8f\uda75\udc42\udb84\udcda\uda78\udd98\ud9d9\udf8a\uda77\udc72\udae6\udc3a\udb0a\udf52\ud97b\udca9",
        22, 30750, 1370205886, 3899522979961939510L, 32290L, true, true, (char) 22146, (char) 26554,
        Double.longBitsToDouble(0x3fed4b3e5bef49f1L), Double.longBitsToDouble(0x3fe365a714f5986eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 2, 15, 4, "\ud8b9\udded\ud85d\udd82\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud93b\udfec\udacf\ude93\ud800\uddbe\udab3\udec6\u8585\uda3a\udf77\ud979\udd30\udae6\udc3a\udb28\udfae\ud97b\udca9\uda91\udea1\udb86\uded6\ud9d1\udcb0\uda6b\udd93\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\ud90f\ude2e\ud9aa\udeb3\ud9fd\udc04\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94\ud811\udf04",
        4, 80083, 607841689, -445566191752151187L, -29234L, true, false, (char) 63953, (char) 57179,
        Double.longBitsToDouble(0x3fe7bcf8a83b6c57L), Double.longBitsToDouble(0x3fdfc34b9a103026L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 3, 15, 4, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud865\udf95\ud885\udea1\ud987\udea1\ud950\udc72\udab8\udc41\uda3a\udf77\ud979\udd30\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udb86\uded6\udb82\ude89\uda6b\udded\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\udb05\ude29\ud9aa\udeb3\ud9fd\udc04\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94",
        14, 5918, 1596689058, 2610660175296661481L, 60415L, false, false, (char) 8552, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62bdfc34b90L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 15, 14, "\udbb4\udc5b\uda13\udc0a\ubeaa\uda76\ude43\uda81\udfd1\udbff\udf74\ud97e\udf81\ud8b4\uddfd", "\u1b0d\u4de1\u6933\u9af6\u7f27\u85ec\ubcfe\u9df0\u96ed\u4242\u894f\u88ec\u52bc\u779d\u8112\u163f", "\udb82\ude89\uda6b\udded\udad1\udefa\uda10\udffe\ud92b\udeda\ud930\udcca\udacc\udf9a\ud9aa\udee1\ud9fd\udc04\ud8c7\udfb6\uda2b\udebc\uda9f\udedb\ud830\udcd2\ud96b\uddd1\ud882\ude48",
        53, 80058, 607841689, -445566191752151187L, -29234L, true, false, (char) 63953, (char) 57179,
        Double.longBitsToDouble(0x3fe7bcf8a83b6c57L), Double.longBitsToDouble(0x3fdfc34b9491283aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=[B:[[0]] |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 3, 6, 4, "\udab0\udc48\ud835\ude38\ubeaa\uda76\ude43\uda40\udec2", "\u6c23\u31b4\ub53f\u3ea3\u887b\u6933\u9af6\u7f27\u97ff\uc870\u9b62\u5130\ud467\u894f\u88ec\u52bc\u779d\u3c73\uac2d", "\udb82\uddf1\udbb3\udcf0\udad1\udefa",
        -4, 79360, 1794723741, 8569648327631072724L, -27180L, false, false, (char) 51790, (char) 21936,
        Double.longBitsToDouble(0x3fea40144239c36cL), Double.longBitsToDouble(0x3fc7d4c7e67c4530L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipLong:ZipLong value: -103741463\012",
        Z.run(T, 1, 0, 0, 0, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda40\udec2", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud944\ude47\uc956\udb4f\udc11\uda4a\uddbf\ud94f\ude8c\udab8\udc41\ud92a\uddef\000\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udaa3\udec4\udb82\uddf1\ud919\udde4\udad1\udefa\ud8fa\udee4\ud92b\udeda\u009d\000\ud8e7\udd25\ud9fc\udfb9\udb1d\udf81\u4b6c\uda9f\ude97\ud99b\udc48\000",
        -5, -1000, 0, -103741463L, 90459L, false, true, (char) 21781, (char) 10667,
        Double.longBitsToDouble(0x3fd393b583080000L), Double.longBitsToDouble(0x3fb7a032afe1a5c8L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 2, 14, "\udaab\uddd1\ud839\ude30\ud9ff\udeb1\uda76\ude43\uda5c\uded1", "\u0bb7\ucd07\u22e9", "\udaff\udc5f\udaf6\ude24\u888c\udb35\ude72\ud980\ude87\ud885\udea1\ubf1c\ud862\udf25\udab8\udc41\uda3a\udf77\ud979\udd30\udae6\udc3a\udb0a\udf52\ud97b\udca9\uda91\udea1\udb86\uded6\udb82\ude89\ud92c\udd66\udacc\udefa\udad4\ude60\ud92b\udf24\ud98a\udeb8\udaab\udc3b\ud9aa\udeb0\ud9fd\udc04\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94",
        59, 5861, 1596689058, 2610660175296661481L, 60415L, true, false, (char) 8557, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62befc34b90L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 21589 |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 1 |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 11, 13, 12, "\udaab\udde6\ud85d\ude30\udb7b\udd10\ud8e1\udd79\uda5c\uded1\udbff\udf74\udb9e\udfec\ud8b4\uddfd\ud961\uddae\ud944\udeb8", "\u4434\u9af6\u1690\ub6dc\u9055\u9df0\u37eb\u5114\u894f\u8858\u52bc\u8705\u3c73\uac2d\u3452\u4fbe\ua233\u756e\u9735\u79dd\uacc5\uad35\u8fde\u7917\u8d17\u163e\u870d\u5ef1\u5b9c\u750f", "\udb1c\udc3d",
        34, 85537, -927957139, 3141697661193229422L, -43216L, false, false, (char) 40848, (char) 23701,
        Double.longBitsToDouble(0x3fe3b40ed0bb3b11L), Double.longBitsToDouble(0x3fd98cc680fb7994L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 1 |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=[B:[[0]] |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 13, 6, 4, "\ud893\udf3b\ud98a\udfa7\ud9ff\udedf\uda76\ude43\uda5c\uded1", "\u88c1\u6d34\u58f7", "\udbf7\uddd7\udb5b\ude24\ud8c4\udef2",
        35, 85229, 1777277027, 6911478919234062901L, -17504L, false, false, (char) 34112, (char) 14365,
        Double.longBitsToDouble(0x3fc5a89f5afb8358L), Double.longBitsToDouble(0x3fd45b8ab8e17caaL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 2, 15, "\ud894\uddaa\ud85d\ude30\ud8ee\udf8e\udb00\udcbf\udbc6\udfb1", "\ube9b\u9502\uc3ca", "\udb0b\udfa3\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\udbd1\udc0b\ud953\udc11\ud97a\udffe\ud950\udc72\udab8\udc41\udbd2\udf24\ud802\udccb\udb7a\udc6d\udb5c\ude5a\ua32e\uda91\udf03\udb11\udf5c\udb82\ude89\udba1\udeee\ud98c\udd5b\udad1\udcc7\ud92b\udf4e\udb05\udc58\udb01\udf2a\udace\udf6b\ud9fc\udfb5\udb85\udc2b\ud83f\udcdd\uda9f\udf2f\ud9b2\udf44\udaaf\udf94",
        11, 91190, 1596689058, -4036371399229071124L, 1729L, false, false, (char) 8751, (char) 13522,
        Double.longBitsToDouble(0x3fe03ae4e7465674L), Double.longBitsToDouble(0x3fadb6583c436630L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 4, 4, 8, "\ud8b9\udded\ud85d\ude30\ud9f7\udf2d\udb56\ude92", "\u53e4\u0bb7", "\uc798\udbca\udc48\udac0\ude6a\udaf6\ude98\uda18\udf30\ud97e\ude09\uda8f\udf4a\ud9b4\ude8f\uda75\udc42\udb84\udcda\uda78\udd98\ud9d9\udf8a\uda77\udc72\ud831\udd95\udb0a\udea0\ud97b\udca9",
        22, 30750, 1372434110, 3899522979961939510L, 32290L, true, true, (char) 22146, (char) 26554,
        Double.longBitsToDouble(0x3fed4b3e5bef49f1L), Double.longBitsToDouble(0x3fe365a714f5986eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 0, 4, "\ud8b9\udded\ud85d\udd82\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud93b\udfec\udacf\ude93\ud800\uddbe\udab3\udec6\u8585\uda3a\udf77\ud979\udd30\udae6\udc3a\udb28\udfae\ud97b\udca9\uda91\udea1\udb86\uded6\ud9d1\udcb0\uda6b\udd93\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\ud90f\ude2e\ud9aa\udeb3\ud9fd\udc04\uebef\ud83f\udc61\u0098\000\000\000",
        7, 80083, 607841689, -445566191752151187L, -29234L, true, false, (char) 63953, (char) 52,
        Double.longBitsToDouble(0x3fe7b800003b6c57L), Double.longBitsToDouble(0x3fdfc34b9a103026L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 2, 3, 4, "\ud8b9\udded\ud85d\udd82\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud93b\udfec\udacf\ude93\ud800\uddbe\udab3\udec6\u8585\uda3a\udf77\ud979\udd30\udae6\udc3a\udb28\udfae\ud97b\udca9\udab1\ude18\udb50\udc0a\ud9bf\udcc5\uda6b\udd93\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\ud90f\ude2e\ud9aa\udeb3\ud9fd\udc04\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94\ud811\udf04",
        4, 80083, 607841689, -445566191752151187L, -29234L, true, false, (char) 63953, (char) 57179,
        Double.longBitsToDouble(0x3fe7bcf8a93b6c57L), Double.longBitsToDouble(0x3fdfc34b9a103026L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 2, 2, 4, "\ud8b9\udded\ud85d\udd82\ubeaa\uda76\ude43\udbc3\udc41", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud93b\udfec\udacf\ude93\ud800\uddbe\udab3\udec6\u8585\uda3a\udf77\ud979\udd30\udae6\udc3a\udb28\udfae\ud97b\udca9\uda91\udea1\udb86\uded6\ud9d1\udcb0\uda6b\udd93\udad1\udefa\uda10\udffe\ud92b\udeda\ud98a\udeb8\ud90f\ude2e\ud9aa\udeb3\ud9fd\udc04\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud830\udcd2\udaaf\udf94\ud811\udf04",
        4, 80083, 607841689, -445566191752151187L, -29234L, true, false, (char) 63953, (char) 57179,
        Double.longBitsToDouble(0x3fe7bcf8a83b6c57L), Double.longBitsToDouble(0x3fdfc34b9a103026L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipShort:ZipShort value: 1 |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=[B:[[0]] |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 7, 6, 4, "\ud838\udded\ud839\udc2d\ubeaa\uda76\ude43\uda5c\uded1", "\u0bb7\u847e\u00c7", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud9ac\udcfb\ud93b\udfec\udacf\ude93\ud800\uddbe\udab3\udec6\u8585\uda3a\udf77\ud855\ude5e\udabd\udd47\udae2\udf1a\udb0c\udeef\uda63\ude9d\udb86\uded6\ud930\udedf\uda6b\udda2\udad1\udefa\ud865\udc68\udbfb\udd7a\ud98a\udeb8\ud90f\ude2e\ud917\udcc3\ud870\ude40\udb1d\udf81\ud83f\udc61\uda0a\udf26\ud830\udcd2\ud800\udf3c",
        41, 42630, -970224930, 2596081553048679899L, 60415L, false, false, (char) 8552, (char) 63953,
        Double.longBitsToDouble(0x3fa3b19a6f79f150L), Double.longBitsToDouble(0x3fadb62bdfc34b90L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[B:[[0]] |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=[B:[[0]] |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 6, 6, 4, "\udab0\udc48\ud835\ude38\ubeaa\uda76\udea0\uda40\udec2", "\u6c23\u31b4\ub53f\u3ea3\u887b\u6933\u9af6\u7f27\u97ff\uc870\u9b62\u5130\ud467\u894f\u88ec\u52bc\u5081\u0ddb\uac2d", "\udb82\uddf1\udbb3\udcf0\ud9e1\udf82",
        31, 79360, 1794723741, 8569648327631072724L, -27180L, false, false, (char) 51790, (char) 21936,
        Double.longBitsToDouble(0x3fea40144139c36cL), Double.longBitsToDouble(0x3fc9d4cec7ba9b2cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 3, 3, 4, "\udab1\udf48\ud835\ude38\ubeaa\uda76\ude43\udaa1\uddb0", "\u6c96\ua37e\u3105\u97aa\u04cb\u651a\u7093\u187c\u0269\u5d83\u095f\u5130\ud467\u8d44\u2854\u1d0b\u0a2e\u3c73\ua3e0", "\udb82\uddf1\udbb3\udcf0\uda15\udd7c",
        5, 99296, 1774203746, 8553153837527448045L, 86897L, false, true, (char) 51824, (char) 21936,
        Double.longBitsToDouble(0x3fea40144239c36cL), Double.longBitsToDouble(0x3fc7d4c7e67c4530L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipLong:ZipLong value: -103741463\0121=org.apache.commons.compress.archivers.zip.ZipLong:ZipLong value: -103741463\012",
        Z.run(T, 2, 0, 0, 0, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda0f\udee0", "\u0bb7\u76f4\u2a19", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\ud944\ude47\uc956\udb4f\udc11\uda4a\uddbf\ud94f\ude8c\udab8\udc41\ud92a\uddef\000\udae6\udc3a\udb0a\udf52\ud98b\ude7d\udade\udfc9\udaa3\udec4\udb82\uddf1\ud919\udde4\udad1\udefa\ud8fa\udee4\ud92b\udeda\u009d\000\udb10\uddd7\ua96e\udb1d\udf81\ud970\udd1a\ud9e6\udf2d\udbbd\udda3\u2462",
        -4, -942, 0, -103741463L, -2250L, false, true, (char) 21781, (char) 10667,
        Double.longBitsToDouble(0x3fd39f1593080000L), Double.longBitsToDouble(0x3fb7a032afe1a5c8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 1, 15, 15, 4, "\ud8b9\udded\ud85d\ude30\ubeaa\uda76\ude43\uda5c\uded1", "\u0b7f\u40df\uc870\u1b0d\u4de1\u6933\u9af6\u7f27\u85ec\ubcfe\u9df0\u96ed\u4242\u894f\u88ec\u52bc\u3d49\u0d81\u3e39\u33ee\u4fbe\ua233\u844a\u96aa\u1260\uac7b\uad35\u8fde\u7ef8\ub74b\u72e8\u86ad\u1211\u81a7\u750f\u2d4a\u43f1\ub36d\u9889", "\ud962\ude1a\ud819\udeb8\ud80d\uddd2\uda15\udefc\udab3\uddf8\uda61\uddd5",
        54, 49396, -851363847, -7366839834470404336L, 35316L, false, false, (char) 29680, (char) 53589,
        Double.longBitsToDouble(0x3fe6ae43c2afc06aL), Double.longBitsToDouble(0x3fda47cebef7b596L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0  |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0  |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 1, 1, 9, "\ud8b9\udded\udb0f\ude49\ubeaa\uda76\ude43\ud958\udf4f", "\u0bb7\u1ca5\ua4f1\u14c5\ua471\u0c69\u3ac1\u7f27\u97ff\uc870\u9b62\u5130\u405c\ua192\uc153\u62f6\u7048\u3c73\ucb43\u8eea\u3ec2\ua1b0\ud1ec\u96aa\u1bb2\u9d70P\000\u77ed\u8b73\u397d\u4b14\u1179", "\000\000\000",
        18, 85537, -1177125011, -2391515307024738342L, 14347L, true, true, (char) 35203, (char) 63784,
        Double.longBitsToDouble(0x3fdfc34b9e694c12L), Double.longBitsToDouble(0x3fe448b666f03675L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \0121=null |this=org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:0x5455 Zip Extra Field: Flags=0 \012",
        Z.run(T, 2, 14, 14, 4, "\uda45\udf2e\udacc\udfc8\ud8ac\udf7a\uda76\ude43\uda0a\udc58", "\u964e\u1f04", "\uda78\ude26\ud8d8\ude19\udaf6\ude24\uda2b\ude30\udad4\udea7\ud865\udf95",
        50, 58752, 1576200937, 3761988385018188269L, -17504L, false, false, (char) 53273, (char) 7495,
        Double.longBitsToDouble(0x3fd289c924e5eb10L), Double.longBitsToDouble(0x3fa331a0ef614a60L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipLong:ZipLong value: 0\0121=org.apache.commons.compress.archivers.zip.ZipLong:ZipLong value: 0\012",
        Z.run(T, 2, 2, 2, 4, "\ud8b9\udded\ud85d\udd82\ubeaa\uda76\ude43\udbc3\udc41", "\u0bb7\u76f4\uc870", "\udaff\udc5f\udaf6\ude24\uda2b\ude30\u00dd\ud93b\udfec\udacf\ude93\ud800\uddbe\udab3\udec6\u8585\uda3a\udf77\ud979\udd30\udae6\udc3a\udb28\udfae\ud97b\udca9\000\000\udbdf\uddef\uda6b\udd93\udad1\udefa\uda10\udffe\udbcb\udc09\000\000\000\ud9fc\udf5b\udb1d\udf81\ud83f\udc61\uda9f\udf2f\ud830\udcd2\ua3f2\000",
        -5, 80083, 153, 0L, -100000L, true, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3dfdb60000000000L), Double.longBitsToDouble(0x3fdfc34b9a103026L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|unixTimeToZipLong|long|static",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|clone||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|dateToZipLong|java.util.Date|static",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|equals|java.lang.Object|new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getAccessJavaTime||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getAccessTime||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getCentralDirectoryData||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getCentralDirectoryLength||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getCreateJavaTime||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getCreateTime||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getFlags||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getHeaderId||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getLocalFileDataData||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getLocalFileDataLength||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getModifyJavaTime||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|getModifyTime||new:org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp:",
    "M|org.apache.commons.compress.archivers.zip.X5455_ExtendedTimestamp|unixTimeToZipLong|long|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
