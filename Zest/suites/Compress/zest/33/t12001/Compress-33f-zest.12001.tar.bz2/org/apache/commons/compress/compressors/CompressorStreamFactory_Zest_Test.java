package org.apache.commons.compress.compressors;
import org.junit.Test;
import static org.junit.Assert.*;
public class CompressorStreamFactory_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 7, "\ud8a3\udd37", "\uc0dc\u64e9\uc57d\ua86a\uc932\u5388\u2219\ub674\u104b\ud65e\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\u3a78\u1f66\ua4c7\u1ddf\u6699\u7ee4\ua1a2", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud89a\udd40\udb4e\ude48\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, 989672612, -6639137024543361472L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 7, "\ud8a3\udd37", "\uc0dc\u64e9\uc57d\ua86a\uc932\u5388\u2219\ub674\u104b\ud65e\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\u3a78\u1f66\ua4c7\u1ddf\u6699\u7ee4\ua1a2", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud89a\udd40\udb4e\ude48\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, 2096968868, -6639137024543361472L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[115, 7, 35, 38]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 7, "\ud8a3\udd37\uda53\udc56", "\u64e9\uc57d\ua86a\uc932\u33e8\u2219", "\ud9b3\ude61",
        57, 9185, -130487191, 592384237056093182L, 92668L, true, true, (char) 670, (char) 3187,
        Double.longBitsToDouble(0x3fdd29161499047eL), Double.longBitsToDouble(0x3fede234188a0feaL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 4, 9, "\ud9ce\udd49\udb04\ude0f\ud8b5\ude8c\ud884\udff1\ud820\ude27\uda73\udf54\udb52\udf13\ud8fd\udc02\udbab\ude2c\udb2c\udea8\ud8b4\udd83", "\u99ac\u6027\u1480\u4c11\u21f1\ub3da", "\udb31\udd76\ud824\uddc1\ud944\udc11\udb2f\udc42\ud855\udcac\udac5\udcab\ud876\udf12\ud902\udd0d\udb74\udfb1\ud93d\ude57\ufc6d",
        35, 81872, -2008407911, 1660513226327600182L, 45107L, false, true, (char) 51740, (char) 59602,
        Double.longBitsToDouble(0x3fc408ef3918d068L), Double.longBitsToDouble(0x3fed79996cc79beeL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 4, 7, "\uda34\udf3b", "\uc0dc\u458b\uc57d\ua86a\uc932\u5388\u2219\ub674\u104b\ud65e\uc250\u6027\u2f44\u4eb9\u6b90\ub3da\u28b5\u5d5c\u3a78\u1f66\ua4c7\ud48a\u9307\u7ee4\ua1a2", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\uda4e\udf8c\ud92d\udc02\udbc3\udf09\ud89a\uddaa\udb4e\ude48\ud959\udd75\ud900\udd36\ud82a\udd1e",
        40, 20140, 989672612, -6639137024544625600L, -62167L, true, true, (char) 54680, (char) 617,
        Double.longBitsToDouble(0x3fead2a6ee2027b8L), Double.longBitsToDouble(0x3fe254d2951f8e46L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 3, 7, "\ud8a3\udd37", "\uc0dc\u64e9\uc57d\ud710\uc9c3\u5388\u2219\ub674\u104b\ud65e\u99ac\u7801\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\u060b\u27a0\ua4c7\u1ddf\u6699\u7ee4\ua1a2", "\ud8e3\udc73\udaf5\udf96\udae9\ude1d\ud9b9\udce9\ud859\ude1e\udbbe\ude01\uda7c\udd64\ud8ab\udc79\u2086\ud9ac\udd8c\ud89a\udd40\udb4e\ude48\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, 989672612, -6639137024543361472L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d4581f8e46L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 1, 9, "\udab7\udec7", "\u2046\u8873\uc597\ua86a\u129aX\u2219\ub674\u104b\u7498", "\uda90\udff3",
        8, 13318, -1163126318, 7830887550764445296L, 21473L, false, true, (char) 38675, (char) 4666,
        Double.longBitsToDouble(0x3fc141fd46495970L), Double.longBitsToDouble(0x3fe04ca070336f1eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 7, "\ud90a\udd2c\uda53\udc56\ud8e6\udda1\ud914\uddb7\ub047\uda73\udf54\u7017\ud8fd\udc02\udbab\ude2c", "\u104b\ud65e\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\u80a5\u3a78", "\u83a2\ud8d5\udeab\udb71\udda0\ud9ee\udf35\ud98f\udc95",
        -2, 8887, 1782955769, -5974095259809273744L, -55949L, false, true, (char) 21204, (char) 12339,
        Double.longBitsToDouble(0x3fd8c123125b51d6L), Double.longBitsToDouble(0x3fea300a2ae4ef38L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\012",
        Z.run(T, 2, 6, 4, 7, "\uda45\udcba", "\uc0dc\u64e9\uc57d\ua86a\uc932\u36e6\ub4b4\ub674\u104b\ud65e\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbaa\u10cf\u3a78\u1f66\ua4c7\u1ddf\u6699\u7ee4\ua1a2", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud89a\udd40\udb4e\ude48\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, 989672612, -6639137024543361472L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 12, 8, "\ud8db\udc2a\ud9e0\udc49\ud904\udfec", "\uc57d\ua86a\uc932\u5388\ud409\u7b96\u6233\ucd7f\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\u3a78\u1f66\u7128\ucec2\u6ea6\u7ee4\ua1a2", "\uda62\udf71\ud833\ude79\ud99a\udf9b\uda8d\udd1c\udb9d\udc62\udb79\udc08",
        42, 58284, -70051643, -4363357889888925395L, 64194L, false, true, (char) 12569, (char) 38496,
        Double.longBitsToDouble(0x3fef891734a46ecbL), Double.longBitsToDouble(0x3f8a75fb9028f740L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 7, 3, "\uda25\udc18", "\uc0dc\u64e9\uc57d\ua86a\uc932\u5388\u2219\u0cad\u10d7\ud65e\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\ud617\u1f66\ua4c7\u1ddf\u7e4d\u4855\ua1a2", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\uda64\udea7\uda8d\udd56\uda7c\udd64\udaa7\udc77\udab3\udfd5\ud9e8\udf18\uda0a\udfc4\ud87e\udcc4\ud959\udcac\ud900\udd36\ud821\udcb2",
        3, 20135, 989672612, -6639137024543361472L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 4, 7, "\uda9e\udca1", "\uc0dc\u64e9\uc57d\u21ab\uc932\u5388\u2219\u6918\u104b\ud65e\u99ac\u6027\u2331\u4e40\u9f45\u8287\u8cc9\u1057\u905a\u1f66\ua4c7\u1ddf\u6699\u7ee4\ua1a2", "\uda62\udf6a\udb7e\udcdf\ud8c6\udc84\uda8d\udcad\ud8d1\udf90\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud88b\udf48\udb4e\ude48\ud959\udd75\ud900\udd36\ud952\udc4a",
        3, 20135, 989672612, -6639137026086865344L, -61412L, true, true, (char) 36920, (char) 43817,
        Double.longBitsToDouble(0x3fe254d459108e46L), Double.longBitsToDouble(0x3fd4660187f623e6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 4, 7, "\000", "\u2b88\000\u96ba\000\ub92f\u5388\u2219\ub674\u0fde\ud65e\u99ac\u6027\u2331\u4c11\u20f3\ub3da\u9c3e\u10cf\u3a78\u0081\000\u2392\u6699\u765a\ua192", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda96\udffb\000\000\000\036\ud868\udc13\udb4e\ude02\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, -1000, 0, -6639137080377936320L, -100000L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe8060998000000L), Double.longBitsToDouble(0x3fe0000000008e46L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.compressors.CompressorStreamFactory:@?\012",
        Z.run(T, 1, 6, 4, 7, "\ud8a3\udd37", "\uc0dc\u64e9\uc57d\ua86a\u1003\u3e0e\u39da\ub674\u0554\u2487\u9922 \000\u4bbe\u21f1\ub3da\ubbf8\u10cf\u3a78\u1f66\ua4c7\u1ddf\u6699\u7ee4\ua1a2", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud89a\udd40\udb4e\ude48\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, 989672612, -6639137024543361472L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 7, "\ud8a3\udd37", "\uc0dc\u64e9\uc57d\ua86a\uc932\u5388\u2219\ub674\u104b\u09f3\u99ac\u6027\u2331\u4c11\u0df1\ub3da\ubbf8\u5d8c\u1e42\u1f66\ua4c7\ua676\ubd25\u7ee4\ua1a2", "\uda61\udfdd\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud89a\udd40\udb4e\ude48\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, 989697152, -6639137024543361472L, -29881L, false, false, (char) 17757, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 7, "\ud945\udee9", "\uc00f\u64e9\uc57d\ua86a\uc932\u5388\u2219\ub674\ua636\ud65e\u99ac", "\u72cf\uda25\udf12\uda46\udea3\ud9c1\ude61",
        23, 58398, -1855858047, -9061258039817678260L, -97814L, false, true, (char) 25111, (char) 65360,
        Double.longBitsToDouble(0x3fd27387fdf24cd6L), Double.longBitsToDouble(0x3f6b522870ad1700L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 7, 2, 7, "\ud8a3\udd37\uda53\udc56\ud8e6\udda1\ud884\udff1\ud820\ude27", "\uc932\u5388\u2219\ub674\u104b", "\ud8ae\udd5d\uda90\udff3\u72cf\uda25\udf12\uda8e\udea7",
        0, 75053, 837955398, -7970849619993169454L, 83228L, false, false, (char) 63469, (char) 25111,
        Double.longBitsToDouble(0x3fa9b78f127387f0L), Double.longBitsToDouble(0x3fe7c93358036a45L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 15, 12, "\ud8a3\udd37", "\ubafc\ud721\uc57d\ua86a\uc932\u5388\u2219\ub674\u104b\ud65e\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\u102e\u3a78\u1f66\ua4c7\u1ddf\u6699\ub997\ud5ce", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud89a\udd40\udadb\ude09\udb4f\uddea\ud900\udd73\ud821\udcb2",
        3, 20135, 989672612, -6639137024549267648L, -61412L, true, true, (char) 36920, (char) 18999,
        Double.longBitsToDouble(0x3fe254d45d1f8e46L), Double.longBitsToDouble(0x3fd9b15d1fe6b304L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-16, -126]]\0121=java.lang.Boolean:false |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\012",
        Z.run(T, 2, 2, 4, 7, "\ud820\uddb2", "\u36a5\u65b8\uc57d", "\udbab\ude2c\udb2c\udea8",
        26, 24461, -1787687767, 8033513029893541920L, 28223L, false, true, (char) 60506, (char) 670,
        Double.longBitsToDouble(0x3fe4098f91d29161L), Double.longBitsToDouble(0x3fe26411fbbc4683L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-123, 92]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 9, "\ud8b5\udd8c", "\uc0dc\u64e9\uc57d\ua86a\uc932\u4045\u479c\ub674\ub098\u761a\u12c5\u9fbc\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\ud278\u1f66\ua4c7\u1ddf\u6699\u7ee4\ua1a2", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud89a\udd40\udb4e\ude48\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, -134400860, -7849494035877937949L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 7, "\ud8a4\udc35", "\ubf61\u64e7\uc57d\ua86a\uc932\u5388\u59d4\ub674\u104b\u69e5\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\u3a78\u1f66\ua4c7\u1ddf\u6699\u7ee4\ua1a2", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\ud89a\udd40\udb4e\ude48\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, 989672612, -6639137024543361472L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=java.lang.Boolean:false |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\012",
        Z.run(T, 2, 4, 4, 7, "\ud8a3\ude16", "\u062e\u64e9\uc57d\ua86a\uc932\u5388\u2219\ub674\u104b\ud65e\u99ac\uac09\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\uc446\ub2c4\ua4c7\u1ddf\u6699\u7ee4\ud36a", "\udb51\udf5f",
        11, 60111, -486837778, -5674592422067204587L, -404L, true, false, (char) 14578, (char) 34458,
        Double.longBitsToDouble(0x3fea30084e72ef34L), Double.longBitsToDouble(0x3fc4035766811de4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 14, 7, "\uda50\udc63\uda0a\ude56", "\ucde8\uc57d", "\udbe2\udd57\ud916\udc58",
        12, 68129, -1782801321, -5740163685402011196L, 29247L, false, true, (char) 63268, (char) 53863,
        Double.longBitsToDouble(0x3fdd970e239ee0aaL), Double.longBitsToDouble(0x3fdf2ef3f0a4454aL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 10, 7, "\udb1a\udfa4\uda52\udffb", "\u64e9\uc57d\ua86a\ub4cc\u233c\u2219\u49fd\u104b\ud65e\u6402\uaa46\u2331\u52b7", "\ud9c1\ude61\ud8da\udf1b\ud9fd\udf16\ud86c\udffc\udb68\ude68\udb45\ude73\ud855\udcac\udb3f\uddc8\ud8c3\udc62",
        0, 42195, 990692766, -249897139025516880L, 87965L, false, true, (char) 65376, (char) 49350,
        Double.longBitsToDouble(0x3fdc2e5f6f6190c2L), Double.longBitsToDouble(0x3fec97fabc3165f3L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[115, 7, 35, 38]]\0121=java.lang.Boolean:false |a0=[B:[[115, 7, 35, 38]]\012",
        Z.run(T, 2, 2, 2, 9, "\ud8a3\udd37\uda53\udc56", "\u25e9\uc57d\ua86a\uc932", "\ud8b4\udd83\udb82\ude2f\udbc5\udd49\ud807\udfd1\ud880\udf0e\uda90\udff3\uda71\uddd2\uda25\udf12\uda8e\udea7\ud9c1\ude61\ud8da\udf1b\ud9f0\ude37\ud86c\udffc\udb68\ude68\udb45\ude73",
        10, 43482, -1485647273, 8934054483446048066L, 88674L, false, true, (char) 12088, (char) 26706,
        Double.longBitsToDouble(0x3fd1b093a47edd58L), Double.longBitsToDouble(0x3fde0f6f445531c2L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=new org.apache.commons.compress.compressors.CompressorStreamFactory:@?\012",
        Z.run(T, 2, 7, 7, 0, "\ud8a3\udd37\ud951\udc55", "\uc3b8\uc57d\u44ca\uc980\u06b5\u823d", "\ud9b3\ude61\ud817\udcfa\udbd5\udc19",
        10, 59281, 876932094, -8681540542958923821L, 18921L, true, false, (char) 33574, (char) 36311,
        Double.longBitsToDouble(0x3fe42a7954bf0f78L), Double.longBitsToDouble(0x3fddbc88d735a9a0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[120, -47, -102, 60, 92]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 3, 11, "\ud8a8\ude01\u2bca\uda6c\udd8c", "\u475d", "\ud993\udf68\udb0f\udc3a",
        21, 24461, -1787687817, 5404556538911827396L, -53993L, false, true, (char) 22241, (char) 24552,
        Double.longBitsToDouble(0x3fdbd769de8d323eL), Double.longBitsToDouble(0x3fc0263e474a4584L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\0121=void |this=org.apache.commons.compress.compressors.CompressorStreamFactory:@?\012",
        Z.run(T, 2, 5, 5, 9, "\udab7\udec7", "\u8961\u8873\uc597\ua86a\u129a\u9c00\u2219\u4cad\u104b\u7498\u74ec\u8f16", "\ud9aa\uddcd\ud81b\uddbc\ufc97\ud8f8\udf70\ud9f0\ude37\ud86c\udffc\udb9e\udc82\uda4d\uddfd\ud859\uddf7\udb71\udda0\uda04\udf35\ud978\udd95\ud976\udda9\udbb6\ude63",
        41, 64778, -143791236, -445332572967302091L, -97635L, true, true, (char) 4290, (char) 55672,
        Double.longBitsToDouble(0x3fc75baf35ade6ccL), Double.longBitsToDouble(0x3fecd9fccc124a2dL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-48]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 9, 0, "\000", "\uc0dc\u64e9", "\ud8fc\udfe0\000\udb2c\uddce\uda55\udd5d\udb82\ude2f",
        13, 78578, -1924739072, -560438219185456734L, -83487L, false, true, (char) 39826, (char) 87,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 2, 2, 7, "\ud8a3\udd37\uda53\udc56\ud8e6\udda1\ud884\udff1\ud820\ude27", "\uc932\u5388\u2219\ub674\u612e\u3f75\u99ac\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\ua179\u3a78", "\udb8d\udf77\ud855\udcac\udb71\udda0\ud9ee\udf35\ud98f\udc95",
        -2, 91479, 1782955769, 7526289047292404869L, -84208L, true, true, (char) 4782, (char) 6702,
        Double.longBitsToDouble(0x3fef5477c964ed06L), Double.longBitsToDouble(0x3fc46df624102914L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[120, -47, -118, -111, 60, 70]]\0121=java.lang.Boolean:false |a0=[B:[[120, -47, -118, -111, 60, 70]]\012",
        Z.run(T, 2, 2, 2, 6, "\ud8a8\ude01\ud8ba\udfc1\uda6c\udd76", "\u475d", "\ud9d0\udc1b\udb0f\udc3a\ud8ab\udc08\udb4e\ude8e\ud9e9\udd2f\ud98c\udd55\udb66\udc02\ufbaf\udb2f\udcd2",
        36, 19015, 1990043116, 8878839778715553550L, 89160L, false, true, (char) 17701, (char) 64763,
        Double.longBitsToDouble(0x3fdf077d549f95faL), Double.longBitsToDouble(0x3fd43d9124592060L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 4, 7, "\ud8a3\udd37", "\uc0dc\u64e9\uc57d\ua86a\uc932\u5388\u2219\ub674\u104b\u1c93\u75da\u6027\u2331\u4c11\u21f1\ub3da\ubbf8\u10cf\u3a78\u1f66\ua4c7\u1ddf\u6699\u7ee4\ucb51", "\uda62\udf6a\ud8f9\udd3c\ud8aa\udf20\uda8d\udc91\udbea\udd8a\uda8d\udd56\uda7c\udd64\udaa7\udc77\u2086\ud9ac\udd8c\udbcd\udefa\udb71\udceb\ud959\udd75\ud900\udd36\ud821\udcb2",
        3, 20135, 989672612, -6639137024543361472L, -62167L, true, true, (char) 54680, (char) 13446,
        Double.longBitsToDouble(0x3fe82e099eacd38aL), Double.longBitsToDouble(0x3fe254d45d1f8e46L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[120, -38, -18, 33, -83, 25]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 3, 11, "\ud8a8\ude0a\ud81e\ude51\ud9dd\ude49", "\ua4a1", "\ud993\udf68",
        13, 4223, -1188369299, -5479093379724676516L, 250L, true, true, (char) 14478, (char) 22241,
        Double.longBitsToDouble(0x3fd649684b7aed3aL), Double.longBitsToDouble(0x3fea34c8fc8131f2L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[120, -38, -18, 33, -83, 25]]\0121=java.lang.Boolean:true |a0=[B:[[120, -38, -18, 33, -83, 25]]\012",
        Z.run(T, 2, 2, 2, 11, "\ud8a8\ude0a\ud81e\ude51\ud9dd\ude49", "\ua4a1", "\ud9af\ude20",
        13, 39215, -1188369299, -5479093379724703889L, 250L, true, true, (char) 14478, (char) 51805,
        Double.longBitsToDouble(0x3fe2cbfa8db41520L), Double.longBitsToDouble(0x3fea34c8fcd231f2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[120, 94, -106, 60, 92, 18, -33, -108]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 11, 12, "\ud8a8\udd8e\ub5c6\uda6c\udd8c\ud942\udf0f\udac4\udc2c\ud953\udc64\u6fe0\ud8fd\udc02\ud993\udf68\udb0f\udc3a\udb8d\udfaf\udb82\ude2f\ud9b3\ude2f\uda0e\udff5\udb66\udc02\ud9c7\udef9\udb4a\ude04\ud90a\udf20\uda8e\udea7\ud9f0\udc61\ud857\udd2f\ud810\uddc7\ud9f2\udefb\udbb6\ude8c\udaa8\udc32", "\u4541\u2fd3\ub3af\u2450\u9f7a\u8027", "\udaba\udcbc\ud8aa\udce9\ud838\ude70\ud987\udce2\udb0a\udfe7\ud947\udfb2\uda0d\udfab\uda37\udcd7\ud916\udc44\udb47\udc37\u4b93\udab2\udc22\ud8f3\udcc2\ud988\udc9e\uda80\uddd2",
        15, 13047, 89127845, -1314891435900263292L, 22497L, false, false, (char) 14852, (char) 11012,
        Double.longBitsToDouble(0x3fe742dc95b3c41cL), Double.longBitsToDouble(0x3fdcf4ec9272cec0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[120, 94, -55, 59, 60, -35, 18, -33]]\0121=java.lang.Boolean:true |a0=[B:[[120, 94, -55, 59, 60, -35, 18, -33]]\012",
        Z.run(T, 2, 2, 2, 3, "\ud8a8\udd8e\ud9f9\udd6b\uda6c\udd0d\ud942\udf0f\udac4\udc2c\ud953\udc64\u6fe0\ud8fd\udc02\udaf9\udd0f\ud952\uddcb\ud9b2\udc0a\udadd\udfc3\ud9b3\ude2f\uda0e\udff5\udb66\udc02\ud9c7\udef9\udb4a\ude04\ud90a\udf20\uda8e\udea7\ud998\udcd6\uda9b\ude1a\ue32a\ud9f2\udefb\udbb6\ude8c", "\uca2c\u2ef6\u306e\ub3af\u2450\u08f6\u7f92\u5e85\u7c70\ucc59\u9050\u42dc\u23e0\u95b8\ucf84\u7dc0\uc8e6\u5ebe\u164e\u658f\u1a84\u39eb", "\udbcc\uddb5\ud9a9\ude4c\ud832\uddbd\udabe\udc21\uda0d\udf26\udae0\udc99\ud924\udf3e\u62d9\udbf3\udd87",
        57, 90728, 1321819571, 7449171276070115641L, 97696L, true, true, (char) 28004, (char) 28769,
        Double.longBitsToDouble(0x3fd1cd13915c2e62L), Double.longBitsToDouble(0x3fe3db48d8488dffL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[120, 1, -102, 60, 92]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 3, 11, "\ud8a8\ude31\u2bca\uda6c\udd8c", "\u47e1", "\ud993\udf68\udb0f\udc3a",
        21, 24461, -1787687817, 5404556538911827396L, -53993L, true, true, (char) 22344, (char) 24552,
        Double.longBitsToDouble(0x3fdbd769de8d323eL), Double.longBitsToDouble(0x3fc0263e474a4584L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[120, 1, -102, 60, 92]]\0121=java.lang.Boolean:true |a0=[B:[[120, 1, -102, 60, 92]]\012",
        Z.run(T, 2, 2, 2, 16, "\ud8a8\ude31\u2bca\uda6c\udd8c", "\u47e1", "\ud993\udf68",
        13, 13951, 1640164461, -7678060708214286454L, 250L, true, true, (char) 12501, (char) 22344,
        Double.longBitsToDouble(0x3fd649684b7aed3aL), Double.longBitsToDouble(0x3fea34c8fc8131f2L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[120, -100, -18, 33, -83, 25, 18, -33]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 3, 6, "\ud8a8\uddcc\ud81e\ude51\ud9dd\ude49\ud942\udf0f\udaa2\udd3b\uda27\uddcd\udbca\udea8\ud8e8\udf8c\ud993\udf68", "\u1176\u277b", "\ud9c7\udef9\ud916\uddf6\ud912\udd43\uda8e\udea7\ud91d\ude15\udb9f\udf3d\ud9f0\ude37\ud80b\ude87\udb6c\ude86",
        6, 95115, 1328615314, -1148570714560840058L, -59787L, false, true, (char) 19873, (char) 42151,
        Double.longBitsToDouble(0x3fe1a838b9058ae7L), Double.longBitsToDouble(0x3fbcec743c488e10L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[120, -100, 60, -88, -5, -51, -32, -120]]\0121=java.lang.Boolean:true |a0=[B:[[120, -100, 60, -88, -5, -51, -32, -120]]\012",
        Z.run(T, 2, 2, 2, 0, "\ud8a8\uddcc\ud96c\uddd8\ud82b\udcfd\ud910\uddb8\udaa2\udd3b\uda27\uddcd\udbca\udea8\ud8e8\udf8c\ud993\udf68", "\u1176\u277b", "\ud9c7\udef9\udbd6\udd35\ud912\udd43\uda4b\udc24\uda65\udd1e\uda02\udcb5\ud9f0\ude37\ud80b\ude87\udb6c\ude86",
        47, 22177, -553308283, 8260721334027239046L, -59787L, false, true, (char) 19902, (char) 17153,
        Double.longBitsToDouble(0x3fe05b14b1058ae7L), Double.longBitsToDouble(0x3fbcec743c488e10L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.compressors.CompressorStreamFactory|createCompressorInputStream|java.io.InputStream|new:org.apache.commons.compress.compressors.CompressorStreamFactory:",
    "M|org.apache.commons.compress.compressors.CompressorStreamFactory|createCompressorInputStream|java.lang.String,java.io.InputStream|new:org.apache.commons.compress.compressors.CompressorStreamFactory:",
    "M|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|matches|[B,int|static",
    "M|org.apache.commons.compress.compressors.CompressorStreamFactory|createCompressorOutputStream|java.lang.String,java.io.OutputStream|new:org.apache.commons.compress.compressors.CompressorStreamFactory:",
    "M|org.apache.commons.compress.compressors.CompressorStreamFactory|getDecompressConcatenated||new:org.apache.commons.compress.compressors.CompressorStreamFactory:",
    "M|org.apache.commons.compress.compressors.CompressorStreamFactory|setDecompressConcatenated|boolean|new:org.apache.commons.compress.compressors.CompressorStreamFactory:",
    "C|org.apache.commons.compress.compressors.CompressorStreamFactory|<init>|",
    "C|org.apache.commons.compress.compressors.CompressorStreamFactory|<init>|boolean",
    "M|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|available||new:org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|close||new:org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|read||new:org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|read|[B,int,int|new:org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream:java.io.InputStream",
    "M|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|skip|long|new:org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream:java.io.InputStream",
    "C|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|<init>|java.io.InputStream",
    "C|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|<init>|java.io.InputStream,org.apache.commons.compress.compressors.deflate.DeflateParameters",
    "M|org.apache.commons.compress.compressors.CompressorStreamFactory|createCompressorInputStream|java.io.InputStream|new:org.apache.commons.compress.compressors.CompressorStreamFactory:",
    "M|org.apache.commons.compress.compressors.CompressorStreamFactory|createCompressorInputStream|java.lang.String,java.io.InputStream|new:org.apache.commons.compress.compressors.CompressorStreamFactory:",
    "M|org.apache.commons.compress.compressors.deflate.DeflateCompressorInputStream|matches|[B,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
