package org.apache.commons.compress.archivers.tar;
import org.junit.Test;
import static org.junit.Assert.*;
public class TarUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\uda9c\ude73",
        9, 76106, 1477675244, 8357018718595285294L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\uda9c\ude73",
        9, 76106, 1477675244, 8357018718595285294L, 76015L, false, false, (char) 26903, (char) 17677,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefd977fa35L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 4, "\udb6b\udd5b\ud8d2\ude16\udac5\ude71\ud8ba\udfb2\ud916\udf4f\ua8d1\ud98f\udf13\uda52\udd28\uda94\udd38\uda0e\udcf5\udaf2\udc98\uda8d\udd91\udbcd\udebb", "\u6679\u2f11\uc6d7\u32da\ub761\u19a0\u99ba\ubfe5\u0811\u6966\u5864\ud04a\u554b\uc1b3\u6d85\uc975\u65ec\u7763\uaef3\u0f4f\u8fd2\u4727\u45e5\u1e3f\u4f85\u24f0\u0af4\u5a24\u0221\u33b9\u9bb9\u51c0\u9442\u5ff5\u34b7\u53d1\u6271\u7f99\u5b9e", "\udb26\ude4f\udac4\udccc\udb62\udea8\uda47\udff4\uda7e\ude14\ud8c8\udd51\udacf\uddde\udb60\udca2\ud8c5\udc91\ud99a\udece\ud80a\udd40",
        4, 62488, -679121037, -9153996333638803174L, -52618L, true, false, (char) 31632, (char) 60241,
        Double.longBitsToDouble(0x3fbeddec5fec5c80L), Double.longBitsToDouble(0x3fe0f4136cb004f8L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 13, 8, 2, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\ud8fe\uddba",
        31, 76106, 1477675244, 8357018718595285294L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 6, 14, "\udb45\udfa7", "\u5894\ucd06\u9703\u9dff\u401c\u0af5\ud155", "\u7643\udacf\udeed\udaf2\udc0e\udaeb\udf2b\ud913\ude37\udb11\ude49\udba8\udc69\udb45\udec9\uda8c\udccd\udaf0\udc20\ud852\udfbe",
        56, 23617, 957410645, 9037344940179556588L, -1318L, true, false, (char) 56472, (char) 60041,
        Double.longBitsToDouble(0x3fdb15477f59923eL), Double.longBitsToDouble(0x3fcbd4795ac4fd60L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13", "\ud1e8\ud328\u30d9\u08d8\u00c6\u2f61\u67aa\u8f50\ub0e1\u32da\ub761\u25ee\u0e2d\u0476\u0811\u89e5\u8883\u9a4b\u9bc9\uca9c", "\udbf5\ude10\ud9a0\udd36\ud8bb\udec3\udbd7\ude06\ud803\uddfe\udb74\udeae\uda7a\udef5\ud9d6\udf16\ud9d8\udc70\ud967\udcdd\udbd0\udc5a\ud91c\udd6c\udb80\ude9c\udbb9\udc8c\ud86b\uddab",
        12, 10573, -207612936, -5659394185621130622L, -96861L, true, true, (char) 40424, (char) 13533,
        Double.longBitsToDouble(0x3fd730771b166fb6L), Double.longBitsToDouble(0x3fdfdfe958219f64L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Long:1015 |a0=[B:[[26, -82, -104, -112, -107, 65, 101, -52]]\012",
        Z.run(T, 1, 1, 6, 4, "\ud94a\udede\ud8c8\udfc0\udac5\ude71\udb95\udefc", "\u9eae\u971c\u0af5\u3f42", "\udb76\udce1\udbba\udde4\udaf2\udcef\u4bbf\ud90f\udc79\ud9c7\udcc3\uda2a\udc36\ud882\udd84\ud83e\udc55\udaf0\udc5a\udb23\ude87\uda0f\ude9b\ud8ed\udfed\uda6c\udd0a\ud919\udf4b",
        24, 17202, 1193902382, 1266994318746496911L, -36855L, false, true, (char) 16552, (char) 26121,
        Double.longBitsToDouble(0x3fea6aefde77fa35L), Double.longBitsToDouble(0x3fc5ca8c009ccf94L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 5, 6, 4, "\udb45\udfa7\ud8d2\ude04\uda7d\udecd\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\ud9e4\udf82\ud9ca\udd3f", "\u4113\ubb1c\u09d9\u9ce5\u2f85", "\udb45\udec9\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\uda9c\ude73\ud85a\udde4\udb6e\udd8b\u5625\uda08\udcbf\uda45\udd5f\ud8e5\udda8\ud942\udce1\ud9b4\ude99\udada\udf77\udb6c\ude3c",
        -1, 8592, 1863715688, -1854936767552151889L, -83649L, true, false, (char) 38260, (char) 47049,
        Double.longBitsToDouble(0x3fb22b98a83c67a8L), Double.longBitsToDouble(0x3fa06d64c145e110L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd7c", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\uda9c\ude73",
        9, 76106, 1477675244, 8357018718595285294L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd479560d2918L), Double.longBitsToDouble(0x3feaf849b677fa35L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 4, 1, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\udabd\uddfd\ud97f\udd59\ud88e\uddbd\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u051d\u2f11\uc6d7", "\uda93\udd04\udaf0\udc20\udb23\ude87\udbab\udf0a\udb84\udce2",
        25, 76106, 1477675244, 8357018718600879160L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\uaed2\ud902\udc85\ua8d1\ud9e4\uddc5\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\uda05\uddd0\uda37\udcef\uda9c\ude73",
        3, 70384, 1477658332, 8357018718595285294L, 76015L, false, true, (char) 27893, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 6, 4, "\udbb7\udef0\ud8a3\udfe8\ud9d0\udfcc\ufb72", "\u9de7\u401c\u53ee\ua71a", "\u7e94\ue3ad\udaf2\udc0e\uda9e\ude03\ud85d\udda0\ud8c4\udc42\udba8\udc69\udb70\udfc9\uda8c\udccd\ud90e\ude65\udb23\ude87\uda37\udcef\uda9c\ude73\ud85a\udde4\ud8b6\udd8f\udb05\ude1c\udab3\udf14\udb2e\udf08\ud88a\udd88\ud810\udfa1\udaef\udf77\udaae\udd92\uda04\udca7",
        17, 34390, 1409479097, -1340781111233846969L, -46551L, false, true, (char) 17851, (char) 34780,
        Double.longBitsToDouble(0x3fa91f959e354be0L), Double.longBitsToDouble(0x3fe3d3c3aaf1f3faL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud838\ude50\ud847\udc29\udb8d\udf36\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u16d7\u1583\u8807", "\uda8c\udccd\ud95c\udf98\udb23\uddfe\uda37\udcef\uda9c\ude73",
        9, 76106, 1477675244, 8357018718608785710L, -13777L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fd45c5deceff596L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 11, 8, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda1c\udd3c\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u4478\uadf6\u6f20", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef",
        18, 26629, 1810083114, 6346566849029573364L, -17153L, true, true, (char) 12547, (char) 28004,
        Double.longBitsToDouble(0x3fed664e9cdea3caL), Double.longBitsToDouble(0x3fdd73f58565b210L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 6, 4, "\udb45\udfa7\ud810\udee5\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\ud89a\udf0a\ud9cb\udcbb\uda99\udc61\uda06\udd16\uda8f\udc58\udb76\udd8f", "\ub523\ud173", "\udb45\udec9\uda8c\udccd\udaf0\udc20\udb29\udf87\uda38\ude67\ud97c\udc3e\ud85a\uddb4\ud8b6\udd8f\udb05\ude1c\udab3\udf14\ud956\ude5d\ud8e5\udda8\ud810\udfa1\ud9b4\udef8\udada\udf77\udb6c\ude0d\udaa0\udc99\udb5f\udc3a",
        2, 42607, 1869647307, 1494206541655154552L, -36029L, true, true, (char) 21377, (char) 54158,
        Double.longBitsToDouble(0x3fefd58f49e0ace2L), Double.longBitsToDouble(0x3fde141bf311d2c8L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 9, 4, "\udb45\udfa7\udb95\ude6c\ud841\udf7e\ud80a\udf7a\ud902\udc85\u5b87\udaad\udf42\uda13\udc78\uda94\udd38\ud8a4\udd76\udb56\udcd8\uda8e\udc60\udb76\udd8f", "\u6679\u9848\u7f9f\ub68f\u357e\u9676\ua7fb\ua371\u36da\uc96d\u8821\u8cab\u694f\ud1b3\u0d85\uc975\u4888\u707c\u05c5\u2f50\u5f16\u9739\u87cc\ua661\u6ac4\u57b0\u220a\u38f0\u8a0e\uc7ab\uc35b\u3aea\ua26f\u262f\u6a31\u53e8\ud22b\u675c\ua906\u3691\u6186\u42df\u68b2\uc3a2\ucab6\u9561\u7c01\u640d\u7731\u3610\u6998\u5bbb\u09a9\u94d6\u2668\u513d\u899e\u4503\u9dd4\ud420\u1b2a\u2898\u1a93\u4e70\u7b3a\u81de\ub25f\u2a17\u4fd5\u312f\uc275\u4ddb\u33e7\u7245\u9fda\ubf26", "\uda7f\uddc3\udb3c\udfde\ud9c1\ude55\u7d94\udb0d\udd4b\udae2\udff9\ud921\udd65\ud8f4\ude98\ud82d\udffb\udad6\udeb2\ud805\udd7d\udb86\udcaf\uda93\udfdf\ud8b5\ude60\u8e82\u618e\uff51\ud9f7\udd01\ud996\udc6a\ud84f\udc86\ud846\udfd3\uda50\udcb3\ud8ab\udcba",
        22, 33029, 1004750885, -1409077390829520703L, 69793L, false, false, (char) 60982, (char) 65116,
        Double.longBitsToDouble(0x3f9c44617ac41260L), Double.longBitsToDouble(0x3fe443116ed99c13L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 0, 6, 4, "\udb15\udf89\ud8d2\uddf1\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\uda2b\udff7\uda52\udc9e\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u00c2", "",
        -2, -1000, -151621290, 9088053706305306853L, 25796L, true, true, (char) 29382, (char) 19393,
        Double.longBitsToDouble(0x3fafac0992e73fa0L), Double.longBitsToDouble(0x3ea4f8f119500000L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 10, 6, 6, "\udbd7\udfbc\udbc0\uddf3\udac5\ude71\ud80a\udf7a\ud825\udec2\ud909\udc66\ud96c\uddb8\ud9b9\udebb\udb54\udf03", "\u5137\u2ed8\ub0fb", "\udba4\ude2c\ud8c4\udc42\udba8\udc69\ud995\ude3f\uda8c\udccd\udaf0\udc20\uda37\udd30\ud8c8\udc8e\udae0\udc63\ud80d\udcbc\ud8b0\udcf7\udae0\udf29\udab3\udf14\ud906\udf01\ud8e5\udda8\udb77\udca2",
        10, 79809, -1547030612, 4564570701213472689L, 53295L, false, true, (char) 64995, (char) 11181,
        Double.longBitsToDouble(0x3fc990159d1487bcL), Double.longBitsToDouble(0x3fbeef77f65d0c58L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud846\udf78\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\ud8fa\ude23", "\u6673\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\uda9c\ude73",
        9, 76106, 1477675244, 8357018718595285294L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 8, 1, "\udb25\udc4a\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda04\udfa2", "\ud4a3", "\udad7\udf32\udaf2\udc0e\uda9e\ude03\ud90e\udf9f\ud8c4\udc0e\udba8\udc69\udb45\udec9\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\uda9c\ude73\ud98b\ude56\udaa6\udd47",
        14, 4047, 1193902382, 1266994318746496911L, 7341L, true, false, (char) 38775, (char) 32991,
        Double.longBitsToDouble(0x3fe5a55c5cecfa2aL), Double.longBitsToDouble(0x3fd9f800cd8452b2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 4, 0, 2, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\uda6f\uddbc", "\u6679\u2f11\uc6d7\u32da\ub761", "\udb23\ude87\ud9df\udd64\ud997\udf85\ud85a\udde4\ud8b6\udd8f\udb05\ude1c\udab3\udf14\uda45\udd5f\ud8e5\udda8\ud810\udfa1\ud9b4\udef8\udada\udf77\udb6c\ude3c",
        24, 28529, -97148083, -3043485057380080373L, -22773L, true, false, (char) 9065, (char) 53400,
        Double.longBitsToDouble(0x3fedca5f554f341eL), Double.longBitsToDouble(0x3fd6404528966144L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 6, 4, "\udb45\udfa7\ud968\udf25\ud83b\udcf4\ud80a\udf0e\udba7\ude38\udaa6\udfbe\ud983\ude1a\uda52\udd28\uda94\udd38\udbf1\udf46\ud936\udd1f\udb91\udfda\udb78\udd05", "\u244c\ub407\uc6d7", "\udbab\udfbc",
        31, 16029, -1088543975, 8633940396438515029L, -69516L, true, false, (char) 62759, (char) 22127,
        Double.longBitsToDouble(0x3fb47c652b78f390L), Double.longBitsToDouble(0x3fc52ed17eb1a3b8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 7, 4, "\udb6b\udd5b\ud8d2\ude16\udac5\ude71\ud8ba\udfb2\ud916\udf4f\ua8d1\ud98f\udf13\uda52\udd28\uda94\udd38\uda0e\udcf5\udaf2\udc98\uda8d\udd91\udbcd\udebb", "\u6679\u2f11\u0918\u32da\ub761\u19a0\u99ba\ubfe5\u7d5a\u6966\u5864\ud04a\u554b\uc1b3\u428e\u9812\u6594\u7763\uaef3\u0f4f\u8fd2\u4727\u45e5\u1e3f\u4f85\u245c\u0af4\u5a24\u0221\u33b9\u9bb9\u51c0\u9442\u5ff5\u34b7\u53d1\u6271\u7f99\u5b9e", "\udb26\ude4f\udac4\udccc\udb62\udea8\uda47\udff4\uda7e\ude14\ud8c8\udd51\udacf\uddde\udb60\udca2\ud8c5\udc91\ud99a\udece\ud80a\udd40",
        4, 62488, -679121086, -9153996333638803174L, -52618L, true, false, (char) 31632, (char) 60241,
        Double.longBitsToDouble(0x3fbeddec5fec5c80L), Double.longBitsToDouble(0x3fe0f41244b004f8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 10, 4, "\udb6b\udd5b\uda6b\udc62\udac5\ude71\ud8ba\udfb2\ud916\udf4f\ua8d1\ud98f\udf13\uda52\udd28\udbed\ude0d\ud8c6\udd34\ud878\udf0b\udad5\udfa4\udbcd\udebb", "\u6679\u2f11\u16f9\ucc54\u9412\uc529\u997e\ubfe5\u0811\u541d\u164b\ud0c9\u554b\uc1b3\u6d85\uc975\u65ec\u7763\uaef3\u604f\u824e\u56bc\u45e5\u1e8f\u4f85\u24f0\u5672\u488c\u0221\u33b9\u9bb9\u51c0\u9d7e\u7e13\u3513\u53d1\u6a5e\u7f99\u5b9e", "\udb26\ude4f\udac4\udccc\udb62\udea8\uda47\udff4\uda8b\ude14\ud8c8\udd51\ufdd6\udb7a\udf9f\ud8c5\udc91\ud99a\udece\ud80a\udd40",
        4, 62488, -679121037, -9153996333638803174L, -52618L, true, false, (char) 31632, (char) 60241,
        Double.longBitsToDouble(0x3fbeddec5fec5c80L), Double.longBitsToDouble(0x3fe0f4136cb004f8L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 6, 11, "\udb6b\udd5b\ud97a\ude80\udad3\udd95\ud99c\ude0d\ud916\udf4f\ud95c\udc3e\ud993\ude39\uda52\udd28\uda94\udd38\uda0e\udcf5\udaf2\udc98\uda8d\udd91\udbcd\udebb", "\u0cf2\u65d1\u70f5\u7eed\ub761\u19a0\u99ba\ubfe5\u0811\u6966\u5864\ud04a\u554b\uc1b3\u6d85\uc975\u65ec\u7763\uaef3\u0f4f\u8fd2\u4727\u45e5\u1e3f\u4f85\u24f0\u0af4\u5a24\u0221\u33b9\u9bb9\u51c0\ub924\u5ff5\u34b7\u4038\u59e7\u9be3\u0694", "\udb26\ude4f\udac4\udccc\udb62\udea8\uda47\udff4\uda7e\ude14\ud8c8\udd51\ucdd1\ud837\udd9c\ud8c5\udc91\ud99a\udece\ud80a\udd40",
        4, 62488, -679121037, -8660289224481556236L, -38619L, true, false, (char) 31632, (char) 60241,
        Double.longBitsToDouble(0x3fbeddec6c99bc80L), Double.longBitsToDouble(0x3fef1a7e1cb004acL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 8, 8, "\udb6b\udd5b\ud8d2\ude16\udac5\ude71\ud8ba\udfb2\ud916\udf4f\ua8d1\ud98f\udf13\uda52\udd28\uda94\udd38\uda0e\udcf5\udaf2\udc98\uda8d\udd91\udbcd\udebb", "\u6679\u2f11\uc6d7\u32da\ub761\u19a0\u99ba\ubfe5\u0811\u6966\u5864\ud04a\u554b\uc1b3\u6d85\uc975\u4e83\u0a4d\u219a\u0f4f\u8fd2\u4727\u45e5\u1e3f\u4f85\u24f0\u0af4\u5a24\u0221\u33b9\u9bb9\u51c0\u9442\u5ff5\u34b7\u53d1\u6271\u7f99\u5b9e", "\udb26\ude4f\udac4\udccc\udb62\udea8\uda47\udff4\uda7e\ude14\ud8c8\udd51\ud80b\udd7d\udb1c\udd99\ud8c5\udc91\ud99a\udece\ud80a\udd40",
        4, 62488, -679121037, -9153996333638803174L, -52618L, true, false, (char) 31632, (char) 60241,
        Double.longBitsToDouble(0x3fbeddec5fec5c80L), Double.longBitsToDouble(0x3fe0f4136cb004f8L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Long:0\012",
        Z.run(T, 1, 13, 8, 2, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\ud8fe\uddba",
        31, -958, 1477640192, 8357018718595285294L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-18, -48, -107, 49, 74, -46, 85, 82]]\012",
        Z.run(T, 1, 13, 8, 2, "\uc01e\000\udac5\ude61\u557a\ud902\udc85\u3482\ud954\udf2a\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\ud8fe\uddba",
        -1, -1000, 1476395008, 8357018717401382912L, -13871L, false, true, (char) 139, (char) 12204,
        Double.longBitsToDouble(0x3fcbd4795800fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[21, 119, -92, -44, -107, 65, 74, -46]]\012",
        Z.run(T, 1, 13, 8, 2, "\udb45\udfa7\ud8d4\udd04\udac5\ude71\ubf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda64\uddea\udb7a\udeb8\udb8a\udc40\uda8f\udc58\ud95f\udd81\ud923\ude94\udaf2\udc0e\uda9e\ude03", "\u32da\ub761\uce9f\u0e2d\u0476\u0811\u3580\u8837\u8d7a\u694f\uc1b3\u6d85", "\ud9b4\udef8\udada\udf77\udb6c\ude3c\udaa0\udc99\udb5f\udc3a",
        2, -953, 1084997700, -6392210015617721501L, -10161L, true, true, (char) 47062, (char) 34685,
        Double.longBitsToDouble(0x3fe2bc3942b48ff3L), Double.longBitsToDouble(0x3f99e6943f50cfa0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-50, -43, -79, 10, 26, 20, -114, -35]]\012",
        Z.run(T, 1, 14, 6, 4, "\ud9fe\udc05\ud9e1\udd3a\udb4a\ude44\ud8be\udc0d", "\u9eae\ua098", "\udb05\udcb1\ud98f\udf06\udbb0\udd8c\ud8ad\udd3d\udbf6\udc42\ud86e\udf31\ud865\uddea\udba6\ude18\udba8\udc69\ud80f\udcad",
        2, 3326, -388335643, 2247616280092732260L, 76349L, true, true, (char) 4582, (char) 53347,
        Double.longBitsToDouble(0x3feabe01484f7239L), Double.longBitsToDouble(0x3fe1d30d9d57a88bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Long:706 |a0=[B:[[26, -82, -97, 42, 101, -52]]\012",
        Z.run(T, 1, 1, 6, 4, "\ud94a\udede\u94cf\ucf5a\udb95\udefc", "\u9dc5", "\udadd\udeb9\ub907\uda8c\ude51\udb76\udce1\udbba\udde4\udaf2\udcef\u4bbf\ud90f\udc79\ud82e\ude77\000\ud853\udf69\ud83e\udc55\udaf0\udc5a\udb23\ude87\uda0f\ude9b\ud8ed\udfed\uda6c\udd0a\ud919\udf4b\uda47\udf6e\udac0\uddd5",
        57, 74103, -1124073472, 3845844265749509801L, 7341L, true, false, (char) 34062, (char) 35852,
        Double.longBitsToDouble(0x3fec5a5c04ce48a8L), Double.longBitsToDouble(0x3fdca69cf227e956L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Long:37 |a0=[B:[[26, 11]]\012",
        Z.run(T, 1, 1, 6, 4, "\ud94a\udf3b", "\ucde7\u0969\ud662\uc530\u0fc2\u0a82\u3f42\u341e", "\udbba\udde4\udaf2\udcef\u4bbf\ud90f\udc79\ud9c7\udcc3\uda2a\udc36\ud882\udd84\uda76\ude9c\udb07\uddf6\udb23\ude87\uda0f\ude9b\ud8ed\udfed\uda6c\udd0a\udb5d\udc8c\ud8ac\udedd\udac0\ude77",
        16, 16111, -1118654577, 3836555593463023609L, 7341L, true, false, (char) 34062, (char) 35852,
        Double.longBitsToDouble(0x3fef8a3c9e3c79dcL), Double.longBitsToDouble(0x3fe4816d18552c67L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Long:668 |a0=[B:[[-50, -90, -104, -112]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 2, "\ud9fe\udcd6\ud8c8\udfc0", "\u299f\u9b7c\u48af\u232b\u3775", "\uda8c\ude51\uda62\udec4\ud9ce\udcfd\udaf2\udc65\u4bbf\ud923\udfa2\ud9c7\udcc3\ud934\udc3b\ud882\udd84\ud83e\udc55\ud865\ude55\udbbd\udff4\uda16\uddcb\udb7c\ude9d\uda98\uddd4\ud919\udf4b\ud8a1\udd5b\ud9b2\udd0e",
        34, 97722, 826068205, 3824733642488779945L, 86482L, false, true, (char) 87, (char) 22701,
        Double.longBitsToDouble(0x3fc5ca8c009ccf94L), Double.longBitsToDouble(0x3fec2093f1d035b4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Long:86 |a0=[B:[[86]]\012",
        Z.run(T, 1, 1, 6, 4, "\u0086", "\000\000\000\000\u971c\u0af5\u3f42", "\udb76\udce1\udbba\udde4\udaf2\udcef\u4bbf\ud90f\udc79\ud9c7\udcc3\uda2a\udc36\ud882\udd84\ud95e\udd06\udaf0\udc5a\udb23\ude87\uda0f\ude9b\ud8ed\udfed\000\ud8f6\udf7a",
        24, 17202, 1193902382, 75448571834255L, -36855L, false, true, (char) 16552, (char) 26121,
        Double.longBitsToDouble(0x3fea6aefde77fa35L), Double.longBitsToDouble(0x3fc5ca8c009ccf94L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Long:1121 |a0=[B:[[-6, -99, -104, 43, -107, 65, 101, -52]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 6, 4, "\ud92a\udccd\ud8c8\udf5b\udac5\ude71\udb95\udefc", "\u9eae\u971c\u0af5\u3f42\u341e\uca8b\u4065\u76d6\uaa54\u6869\u2feb\u3171\u692a\uce67\ub404\u0e67\u0476\u01b0\ubf0d\ud319\u79c2\u4d2f\u1d17\u6d85\u07f2\ub675\u690d\u8e08", "\udb5f\udc3a\uda7a\udef5\udbca\udf6f\udbaa\udfbc\ud872\udfb5\udbdd\uddbc\ud9d6\ude6c\uda46\ude44\ud9e3\udd14\udbb5\ude42\ud94b\udfb0\udac2\udcc8\ud86f\ude7b\ud8c1\udfad\ud91d\udcb6\udb62\udf0c\udb44\udfc3\ud983\udf05\uda1f\udcec\udb20\udfe4\ud84a\udcd0\udae1\uded1\ud976\udcac\udaf9\udead\ud9a5\uddd0\udb1f\udff3\ud9b0\udcb9\ud860\udce1",
        42, 9576, -307999375, 6516437076849274474L, 78094L, true, false, (char) 60828, (char) 26443,
        Double.longBitsToDouble(0x3fea558834ec0fb7L), Double.longBitsToDouble(0x3feff4db52bb779aL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\012",
        Z.run(T, 1, 15, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\ude62\udb8a\udc40\udbf3\udf4a\000", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\000\000",
        48, -1000, 1477640192, 8357018718595285294L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd47940000000L), Double.longBitsToDouble(0x3feaf849b677fa35L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Long:993 |a0=[B:[[21, 119, -67, -68, 39, 62, 124, -5]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 8, 1, "\udb45\udfa7\u88ed\udaec\udd57\udb6e\udcac\udb2b\udc1f\udbab\udf75\ud962\udf13\udabd\uddfd\ud97f\udd59\udb47\udcba\ud9d0\uddbc\uda8f\udc79\udb76\udd8f", "\u4d63\ub667\u6afb", "\uda1c\udd24\ud908\udedb\ud86c\ude6a",
        18, 41784, -1380615036, -4407426262934255380L, 87448L, true, false, (char) 49443, (char) 59331,
        Double.longBitsToDouble(0x3fe54bb45facc9d3L), Double.longBitsToDouble(0x3fcbd4794dbb4944L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Long:1238 |a0=[B:[[-10, 54, -94, -44, 123, 20, -33, -58]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 5, 15, "\uda26\udd66\ud8d2\ude04\udbab\udf44\ud80f\udff6", "\u9ea4\u214c\u3443\uc468", "\udb76\udd8f\udad2\udeef\udaf2\udc0e\udabc\udca6\ud90e\udf9f",
        18, 23573, -825341520, 2056970023261388978L, 87623L, true, true, (char) 63300, (char) 29382,
        Double.longBitsToDouble(0x3fcd985aa0fd604cL), Double.longBitsToDouble(0x3fac39fd49f477e0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-54, 0, -124, -58, -81, 12, -38, -69]]\0121=java.lang.Long:0 |a0=[B:[[-54, 0, -124, -58, -81, 12, -38, -69]]\012",
        Z.run(T, 2, 0, 0, 1, "\udbfa\udd30\ud8b4\udcf6\ud9df\udd3c\ud80a\udceb\ud902\udc85\ua8d1\ud95f\udd13\ud837\uddfa\ud97f\udd59\ud88e\uddbd\udbd1\udce4\udb6f\udd5e\udb61\udd13", "\u051d\u2f11\uc6d7\u32da\u4d58\u3d2b\u0e2d\u0476\ua240\u6c0f\u32a0\u8cab\u694f\uc1b3\ud789\u0758\u1210", "\udb6c\ude24\ud8b1\udfda\udaa0\udeb6\ud9df\udde0\uda52\uddcc\ud834\ude1a\ud972\udd09\uda9a\ude5b\uda73\udee2\ud9be\ude08",
        1, 3506, -1515747581, -4799882761799192045L, 28404L, false, false, (char) 22046, (char) 20837,
        Double.longBitsToDouble(0x3fe5e12826497f0fL), Double.longBitsToDouble(0x3fc35c9f8049ba9cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Long:848 |a0=[B:[[-83, 83, 100, 25, -15, 92, 78, 56]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 4, 11, "\ud8dd\udd83\udb94\ude49\ubd21\uda8c\udd7e\uda68\udc7c\uda21\udd76\ud957\udd0f\udabd\uddfd\ud97f\udd59\ud88e\uddbd", "\u4113\u3cb0\u5974\u971c\u2f11", "\udb45\udec9\uda93\udd04\udaf0\udc20\udb23\ude87\udb88\udedd\uda9a\ude3a\ud845\udc63\ud8b6\udd8f\udb05\ude1c\udab3\udf14\uda66\udc6e\ud8e5\udda8\u73a8\ud9b4\udef8\udb12\udda8\ud8b8\udc88",
        53, 28548, -97180339, 7354482055036350360L, 53467L, false, false, (char) 60790, (char) 25333,
        Double.longBitsToDouble(0x3f984e29f45aff40L), Double.longBitsToDouble(0x3fe9150ead37bc0eL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Long:1025 |a0=[B:[[21, 119, -94, -44, -107, 65, 87, -46]]\0121=java.lang.Long:1025 |a0=[B:[[21, 119, -94, -44, -107, 65, 87, -46]]\012",
        Z.run(T, 2, 1, 1, 1, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\u3287\ud902\udc85\ua8d1\ud962\udf13\udab6\udcfd\ud97f\udd59\ud88e\uddbd\udb8a\udc40\uda8f\udcf4\ud839\udf51", "\u051d\u1b9c\uc74d", "\u14fe\udaf0\udc20\udb77\udff1\udbd5\udf2c\udb84\udce2",
        8, 76106, 1477675244, 8464759863002557400L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fece866569bcca6L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 4, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud838\ude50\ud847\udc29\udb8d\udf36\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u16d7\u1583\u8807", "\uda8c\udccd\ud95c\udf98\udb23\uddfe\uda37\udcef\ud954\udf70",
        9, -958, 1477640192, 8357018718608785710L, -13777L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fd45c5deceff596L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 6, 12, "\udb45\udfa7\ud873\udd69\ud928\udf2c\ud9e2\udd35\ud818\udfbf\udb56\ude90\ube7c\ud975\udefa\udbce\udc0a\uda62\ude8a\udb8a\udc40\uda8f\udc58\ud9c2\udfcb\ud8fd\ude1f\udacc\ude60\ud928\ude08\udb99\udd46\ud811\udc74\udba8\udc59\udb45\udec9\ud8ec\udc9c\udbc5\udfb8\udb4c\udfc4\uda37\udd56\uda9c\ude73\ud85a\udde4\ud8b6\udd8f\ud86c\udd71\udab1\udd64\ud9ab\ude6b\udbd8\udf49\u0e8f\ud9ed\udff5", "\u67ee\u49cb\ua33f\u5dff\u57aa\u9703", "\udb7d\ude9f\udbee\udd46\ud8f0\udfec\uda5c\udf87\udaa2\udc5c\ud946\udd15\udb87\ude9c\uda51\udc66\ud8d9\udc23\ud8e2\udca0\uf360\udb33\udf34\u9a3e\udb84\udcb6\udb55\ude16\ud957\udf44\ud836\udc71\uda07\udffd\udbf9\uddd5",
        29, 106, -1257577506, -3219033339487394623L, 8033L, true, false, (char) 218, (char) 52430,
        Double.longBitsToDouble(0x3fd7ba2cd66c2ceeL), Double.longBitsToDouble(0x3fe62fd1b83c12c0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Integer:-997 |a1=[B:[[-32, -6, -26, 126, -20, -59, 37]]\012",
        Z.run(T, 1, 8, 6, 4, "\udbf9\udf7b", "\u4210\u1c2a\u7716\u9eae\u401c\u0af5\ud155", "\udb76\udd8f\udaa1\uddf8\udaf2\udcbe",
        3, -1000, 305816173, 7321642293537950128L, 80224L, false, true, (char) 3060, (char) 2709,
        Double.longBitsToDouble(0x3fd5577d1a558b38L), Double.longBitsToDouble(0x3fcd985aa0fd604cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 4, 2, 1, "\udb45\udfa7\ud8d2\ude04\udac5\ude71\ud80a\udf7a\ud902\udc85\ua8d1\ud837\ude8e\uda52\udd28\uda1c\udd3c\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u4478\uadf6\u6f20", "\uda8c\udccd\udaf0\udc20\ud802\udd6e\ud8da\udc7d",
        4, -667, 1810055771, 6346566849033737428L, -17153L, false, false, (char) 53703, (char) 28004,
        Double.longBitsToDouble(0x3fbd7481a6f2e650L), Double.longBitsToDouble(0x3fee2fd2c47f4c63L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 6, 0, "\udb45\udfa7\000\000\u54eb\ud902\udc85\ua8d1\ud962\udf13\ud89a\udf0a\ud9cb\udcbb\uda99\udc61\uda06\udd16\000\udb76\udd8f", "\u4b11\ud10a", "\udb45\udec9\uda8c\udccd\udaf0\udc20\udb29\udf87\uda38\ude67\ud97c\udc3e\ud85a\uddb4\ud8b6\udd8f\udb05\ude1c\udab3\udf14\ud956\ude5d\ud8e5\udda8\ud810\udfa1\ud9b4\udef8\ud8c5\udd6b\udb6c\ude0d\udaa0\udc99\udb5f\udc3a",
        2, 42607, 203, 0L, -36256L, true, true, (char) 21377, (char) 54158,
        Double.longBitsToDouble(0x3fefd58f49e0ace2L), Double.longBitsToDouble(0x3fde141bf311d2c8L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Long:688 |a0=[B:[[21, 119, 101, 60, 17, 78, -38, 74]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 9, 4, "\udb45\udfa7\udb95\ude6c\ud841\udf7e\ud80a\udf7a\ud902\udc85\u5b87\udbe3\udf3d\uda13\udc78\uda94\udd38\ud8a4\udd76\udb56\udcd8\uda8e\udc60\udb76\udd8f", "\u6679\u9848\u7f9f\ub68f\u357e\uab01\u4681\ua371\u36da\uc96d\u8821\u8cab\u694f\ud1b3\u0d85\uc975\u4888\u22f1\u05c5\u2f50\u5f16\u9739\u87cc\ua661\u6ac4\u57b0\u220a\u38f0\u8a0e\uc7ab\u5b64\u7643\u8451\u262f\u6a31\u53e8\ud22b\u675c\ua906\u3691\u6186\u25df\u68b2\uc3a2\ucab6\u9561\u7c01\u640d\u7731\u3610\u6998\u5bbb\u09a9\u94d6\u2668\u513d\u899e\u4503\u9dd4\ud420\u1b2a\u2898\u1a93\u4e70\u7b3a\u81de\ub25f\u2a17\u4fd5\u312f\uc275\u4ddb\u33e7\u7245\u9fda\ubf26", "\uda7f\uddc3\udb3c\udfde\ud9c1\ude55\u7d94\udb0d\udd4b\udae2\udff9\ud921\udd65\ud88c\udd84\uda04\udf62\udaac\udfbf\udad3\udf07\ud8d8\udf62\uda93\udfb2\ud8b5\ude60\u8e82\u2482\ud8f8\udc47\ud9f7\udd01\ud996\udc6a\ud84f\udc86\ud846\udfd3\uda50\udcb3\ud873\udf3f",
        58, 33029, 1004750885, -1409077390829520703L, 69793L, false, false, (char) 60982, (char) 65116,
        Double.longBitsToDouble(0x3f9c4461c21bf260L), Double.longBitsToDouble(0x3fe80e4f1c179cd2L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 1, 4, "\udb15\udf89\ud8d2\uddf1\udac5\ude71\ud80a\udf7a\ud902\udc85\uda16\ude86\ud88a\udde0\uda52\udc9e\uda94\udd38\udbf1\udf46\ud8fc\udd4a\uda8f\udc58\udb76\udd8f", "\ua3f3", "",
        -2, -1000, -2066386602, -1082080502417939255L, 25778L, true, true, (char) 7799, (char) 49171,
        Double.longBitsToDouble(0x3fe75a35312e2098L), Double.longBitsToDouble(0x3ea4f8f119500000L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Long:1035 |a0=[B:[[73, 117, -112, -61, -107, 65, -38, 74]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 6, "\uda79\udfa5\udbc0\uddf3\udac5\ude71\ud80a\udf7a\ud825\udec2\ud909\udc66\ud96c\uddb8\ud9b9\udebb\udb54\udf03", "\ua136\u2ed8\ub0fb", "\ud9f2\udcc1\ud8c4\udc42\udba8\udc69\ud995\ude3f\uda8c\udccd\udaf0\udc20\ud9e3\udff6\ud8c8\udc8e\udae0\udc63\ud80d\udcbc\ud8b0\udcf7\ud845\udfbd\udadb\udf23\ud906\udf01\ud965\udd81\udb5c\udd26",
        10, 79809, -1547030612, 4564570701207749041L, 53295L, false, true, (char) 64995, (char) 11181,
        Double.longBitsToDouble(0x3fc990159d14d3bcL), Double.longBitsToDouble(0x3fbeef77f65d0c58L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 6, 4, "\udb45\udfa7\ud8d2\ude04\uda91\udf17\000\ud8c7\udd42\ua8d1\ud962\udf13\ud8e3\udf91\000\000\000\000\000", "\u6673", "\udba8\udc69\udb45\ude19\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\uda9c\ude73\ud85a\udde4",
        23, -1000, 1945770047, 11682508908610719L, -92828L, true, false, (char) 63871, (char) 16552,
        Double.longBitsToDouble(0x3eb61a6aefd80000L), Double.longBitsToDouble(0x3e3b2f3120000000L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 7, 7, 4, "\udb6b\udd5b\ud8d2\ude16\udac5\ude71\ud8ba\udfb2\ud916\udf4f\ua8d1\ud98f\udf13\uda52\udd28\uda94\udd38\uda0e\udcf5\udaf2\udc98\uda8d\udd91\udbcd\udebb", "\u6679\u2f11\u0918\u32da\ub761\ubc25\u99ba\ubfe5\u7d5a\u6966\u5864\ud04a\u554b\uc1b3\u428e\u9812\u6594\u7763\uaef3\u0f4f\u8fd2\u4727\u45e5\u1e3f\u4f85\u245c\u0af4\u5a24\u0221\u33b9\u9bb9\u51c0\uca41\u5ff5\u34b7\u53d1\u6271\u7f99\u5b9e", "\udb26\ude4f\udac4\udccc\udb62\udea8\uda47\udff4\uda7e\ude14\ud8c8\udd51\udacf\uddde\udb60\udca2\ud8c5\udc91\ud99a\udece\ud80a\udd40",
        4, 62488, 28482, 0L, -52618L, true, false, (char) 31632, (char) 60241,
        Double.longBitsToDouble(0x3fbeddec5fec5c80L), Double.longBitsToDouble(0x3fe0f41244b004f8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 8, 2, "\udb45\udfa7\ud8d2\ude04\udaf1\udd06\ud8c3\udd9d\ud902\udc62\ua8d1\ud962\udf13\uda52\udd28\uda94\udd38\udbf1\udf46\ud996\uddde\uda03\uded4\udb76\udd8f", "\u6679\u2ffb\uc6d7", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcef\ud8fe\uddba",
        31, -958, 1477640192, 8357018718595285294L, 76015L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[43, 54, -50, 71, -108, -38, -125, -1]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 15, 2, "\ud85b\udd66\ud9fe\ude77\udbc4\udc0a\udab3\ude2f\ud938\ude4e\ua8d1\uda73\udc9b\udb49\udeb0\uda94\udd38\udb55\uddab\u4e2f\udbb4\ude6b\udb76\udd8f", "\u8cb1\ua76b\u1b15\u32da\ub761\uce9f\u0e2d\u0476\u0811\u3580\u8837*\ub862\uc1b3\u6d85", "\ud852\udc4b\uda57\udd06\udb6c\uddea\uda7d\udd59\udb5f\udc3a",
        2, 68023, 502513623, 6522916431017505086L, -75355L, false, true, (char) 48983, (char) 55762,
        Double.longBitsToDouble(0x3fd2b85123920966L), Double.longBitsToDouble(0x3fe8935aa5e0edc0L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[21, 119, -92, -44, -107, 65, 74, -46]]\0121=java.lang.Integer:-951 |a1=[B:[[-86, 49, 111, -3, 70, -31, 80, 7]]\012",
        Z.run(T, 2, 13, 8, 2, "\udb45\udfa7\ud8d4\udd04\udac5\ude71\ubf7a\ud902\udc85\ud808\udfd1\ud962\udf13\uda52\udd28\uda64\uddea\udb7a\udeb8\udb8a\udc40\uda8f\udc58\ud95f\udd81\ud923\ude94\udaf2\udc0e\uda9e\ude03", "\u32da\ub761\uce9f\u0e2d\u0476\u0811\u3580\u8837\u8d7a\u694f\uc1b3\u6d85", "\ud9b4\udef8\udada\udf77\udb6c\ude3c\udaa0\udc99\udb5f\udc3a",
        2, -953, 1084997700, -6392210015617721501L, -10161L, true, true, (char) 47062, (char) 34685,
        Double.longBitsToDouble(0x3fe2bc3942b48ff3L), Double.longBitsToDouble(0x3f99e6943f50cfa0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Long:668 |a0=[B:[[-50, -90, -104, -112]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 10, 2, "\ud9fe\udcd6\ud8c8\udfc0", "\u7753\u84e8\ub4b5\u232b\ud1b5", "\uda8c\ude51\uda62\udec4\ud9ce\udcfd\udaf2\udc65\u4bbf\ud923\udfa2\ud9c7\udcc3\ud934\udc3b\ud882\udd84\ud989\udcfd\ud841\ude24\udb30\udc44\ua5bf\udb7c\ude9d\u683a\udbe4\udfbf\ud8a1\udd3a\ud9b2\udd0e",
        34, 97722, 826068205, 3824733642488779945L, 86482L, false, true, (char) 87, (char) 22701,
        Double.longBitsToDouble(0x3fc5ca8c009ccf94L), Double.longBitsToDouble(0x3fec2093f1d035b4L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Long:668 |a0=[B:[[-50, -90, -104, -112]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 6, 2, "\ud9fe\udcd6\ud8c8\udfc0", "\u299f\ua64d\u48af\u232b\u3775", "\uda8c\ude51\uda62\udec4\ud9ce\udcfd\udaf2\udc65\u4bbf\ud923\udfa2\ud9c7\udcc3\ud934\udc3b\ud882\udd84\ud83e\udc55\ud865\ude55\udbbd\udff4\uda16\uddcb\udb7c\ude9d\uda98\uddd4\ud919\udf4b\ud8a1\udd5b\ud9b2\udd0e",
        34, -462, 826068205, 3824733642488779945L, 86482L, false, true, (char) 87, (char) 22701,
        Double.longBitsToDouble(0x3fc5ca8c009ccf94L), Double.longBitsToDouble(0x3fec2093f1d035b4L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=java.lang.Long:809 |a0=[B:[[-50, -90, -22, -53]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 2, 2, "\ud9fe\udcd6\ud91a\udffb", "\u299f\u9b7c\u48af\u232b\u3775", "\uda8c\udf26\uda62\udec4\ud9ce\udcfd\udaf2\udc65\u4bbf\udb8b\udfb2\ud967\udf46\ud84d\udedb\ud882\udd84\ud83e\udc55\ud865\ude55\udbbd\udff4\ud904\udc94\udb7c\ude61\uda98\uddd4\ud919\udf4b\ud8a1\udd5b\ud9b2\udd0e",
        34, 97722, 826068205, -4678062453986716503L, 86482L, true, false, (char) 87, (char) 22701,
        Double.longBitsToDouble(0x3fc5ca8c009ccf94L), Double.longBitsToDouble(0x3fec2093f1d035b4L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.Long:668 |a0=[B:[[-50, -90, -104, -112]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 0, 2, "\ud9fe\udcd6\ud8c8\udfc0", "\u299f\u0ad2\u48af\u232b\u3775", "\uda8c\ude51\uda62\udec4\u283c\000\udbf9\udefc\ud923\udf99\ud973\udcb9\000\ud882\udd84\000\ud865\udd69\udba7\udc89\uda16\uddb3\udb7c\ude9d\uda98\uddd4\ud919\udf4b\ud8a1\udd5b\udb1d\udc84",
        -5, -1000, 826068205, 3819104142954566825L, 86482L, false, true, (char) 87, (char) 64053,
        Double.longBitsToDouble(0x3df399f280000000L), Double.longBitsToDouble(0x3fec2093f1d035b4L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Long:993 |a0=[B:[[21, 119, -67, -68, 39, 62, 124, -5]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 1, "\udb45\udfa7\u88ed\udaec\udd57\udb6e\udcac\udb2b\udc1f\udbab\udf75\uda87\udd24\ud9f9\ude74", "\uce38\uad47\uc012\u3cb0", "\udafc\ude1c\ud8e3\udc65\udb7c\ude97\uda4f\udecd\uda1c\udd24\ud908\udedb\ud86c\ude6a",
        18, 41784, -2081752700, -4453170945991669524L, 87448L, true, true, (char) 7262, (char) 59331,
        Double.longBitsToDouble(0x3fe54bb45facc9d3L), Double.longBitsToDouble(0x3fcbd4794dbb4944L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Long:993 |a0=[B:[[21, 119, -67, -68, 39, 62, 124, -5]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 13, 12, "\udb45\udfa7\u88ed\udaec\udd57\udb6e\udcac\udb2b\udc1f\udbab\udf75\ud962\udf13\udabd\uddfd\ud97f\udd59\udb47\udcba\ud9d0\uddbc\uda8f\udc79\udb76\udd8f", "\u4d63\ub667\u6afb", "\uda1c\udd24\ud908\udedb\ud86c\ude6a",
        43, 41784, 213220484, -4885168940657342573L, 87448L, true, false, (char) 49443, (char) 59331,
        Double.longBitsToDouble(0x3fe54bb45facc9d3L), Double.longBitsToDouble(0x3fcbd4794dbb4944L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Long:1091 |a0=[B:[[-10, 54, -29, 123, 20, -33, -58]]\0121=void |a1=[B:[[-10, 54, -29, 123, 20, -33, -58]]\012",
        Z.run(T, 2, 1, 5, 15, "\uda26\udd66\023\udbab\udf44\ud80f\udff6", "\000\u214c\u3443\uc468", "\udb76\udd8f\udad2\udeef\udaf2\udc0e\udabc\udca6\ud90e\udf9f",
        37, -1000, -825341696, 371483148288L, 87623L, true, true, (char) 63300, (char) 50588,
        Double.longBitsToDouble(0x3fcd985aa0fd604cL), Double.longBitsToDouble(0x3f3cfea4fa3bf000L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Long:796 |a0=[B:[[6, -94, -44, -48, -48]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 5, 15, "\u0a36\ud8d2\ude04\000\000", "", "\ud97f\udd59",
        30, 31200, -822192324, 38717955046834176L, -100000L, false, false, (char) 0, (char) 52822,
        Double.longBitsToDouble(0x3fc6439160000000L), Double.longBitsToDouble(0x3e38000000000000L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-54, 0, -124, -58, -81, 12, -38, -69]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 11, 6, "\udbfa\udd30\ud8b4\udcf6\ud9df\udd3c\ud80a\udceb\ud902\udc85\ua8d1\ud95f\udd13\ud837\uddfa\ud97f\udd59\ud88e\uddbd\udbd1\udce4\udb6f\udd5e\udb61\udd13", "\u051d\u2f11\uc6d7\u32da\u4d58\u3d2b\u8537\uccc2\u0e27\u6c0f\u6767\u553c\u694f\uc1b3\ud789\u0758\u1210", "\udb6c\ude24\ud8b1\udfda\udaa0\udeb6\ud9df\udde0\uda52\uddcc\ud834\ude1a\ud972\udd09\uda9a\ude5b\uda73\udee2\ud9be\ude08",
        1, 3506, -1515747581, -4799882762210222822L, 28404L, false, false, (char) 22046, (char) 20837,
        Double.longBitsToDouble(0x3fe5e12826497f0fL), Double.longBitsToDouble(0x3fc35c9f8049ba9cL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 8, 6, 1, "\udb97\udc3f\u5f3f\udac5\ude71\ud838\ude50", "\u9eae\u401c\u0af5\ud155\ucaa3\uad26\u4113\u5ff1\uaa23\u8ed7\u5094\ua58d", "\uda8c\udccd\ud95c\udf98\uda0c\ude12\ud945\udd18\udb99\uddc7",
        9, -958, 1477640192, 8357018718608785710L, 4143L, false, true, (char) 27956, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fd45c5deceff596L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 6, 12, "\u77f9\ud873\ude28\ud928\udf2c\ud9e2\udd35\ud818\udfbf\udb56\ude90\ube7c\ud975\udefa\udbce\udc0a\ud918\udd24\u362e\uda8f\udc58\ud9c2\udfcb\u2e27\udacc\ude60\ud845\udf58\udb99\udcd2\ud811\udc74\udba8\udc59\u311b\udb4b\udf4b\uda56\udf9e\udb4e\udf4b\uda37\udd56\uda9c\ude73\ud821\udd87\ud862\udf12\ud9d1\udc5d\udab5\udde8\udbe2\udfe7\udbd8\udf49\u0e8f\ud9ed\udff5", "\u67e5\u49cb\ua33f\u5dff\u57aa\u5d43", "\ud95f\uddb1\u38de\ud8f0\udfec\uda5c\udf87\udbe9\udc4c\u26f8\ud97c\udcd3\uda51\udc66\ud9cc\udcaa\ud8e2\udca0\uda5b\udc6f\udb33\udf68\udad8\udc12\ud83f\udd2e\udb55\ude16\udbc4\udce6\ud81f\udf1f\uda07\udffd\udbf9\uddd5",
        29, 116, -1257577709, -3219033339487394623L, -43463L, false, true, (char) 38536, (char) 29286,
        Double.longBitsToDouble(0x3fbee8b351b0b3b8L), Double.longBitsToDouble(0x3fa27c80e7925f20L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=java.lang.Integer:-997 |a1=[B:[[-32, -6, -26, 6, -20, -59, 37]]\012",
        Z.run(T, 1, 8, 6, 4, "\u327c", "\u4210\u1c2a\u7716\u9e36\u401c\u0af5\ud155", "\udb76\udd8f\udaa1\uddf8\udaf2\udcbe",
        3, -1000, 305816173, 7321642293537950128L, 80224L, true, false, (char) 56406, (char) 36628,
        Double.longBitsToDouble(0x3fd3677d1a558b38L), Double.longBitsToDouble(0x3fcd985abcfd604cL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 6, 4, "\udbf9\udf7b", "\u4210\u1c2a\u7716\u9eae\u401c\u0af5\ud155", "\udb76\udd8f\udaa1\uddf8\udaf2\udcbe",
        3, 48350, 305816132, 7321642293537950128L, 80224L, false, true, (char) 52717, (char) 51936,
        Double.longBitsToDouble(0x3fd5577d1a558b38L), Double.longBitsToDouble(0x3fcd985aa0fd604cL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=java.lang.Integer:-995 |a1=[B:[[112, 53, -48, 102, 126, -48, -59, 37]]\012",
        Z.run(T, 1, 8, 6, 4, "", "\u7aa0\u3f65\000\u7696\u9eae\u2000\u0af5\ud155\ubee8\uad26\u4113\ud62a\000\u8a14", "\udba8\udcdc",
        5, -1000, -1451933696, -1667889474443336935L, -39243L, false, false, (char) 19393, (char) 0,
        Double.longBitsToDouble(0x3fe656c673527022L), Double.longBitsToDouble(0x3fe4bb3b6c07b653L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 6, 4, "\udbd7\uddc4", "\u4210\u1c2a\u7716\u9eae\u6fb5\u0af5\ud155\ubee8\uad26\u4113\u5ff1\uaa23\u8a14\u714b\u90cf\u334d\ub761\000\u096e\u03ed", "\ud85a\udde4\ud89c\ude8f\udb05\ude1c\udbbd\udda1\udbc1\udf4f\udb63\udca3\uda5c\udee6\ud85f\udf4b\ud928\udc26\uda14\ude6e\udaf2\uddc8\udb70\uddd0\uda44\udc15\ud9d8\udd8f\udac7\ude5f\udae7\ude7e",
        2, 41600, 855321619, -7477479856770790651L, -76775L, false, true, (char) 812, (char) 24381,
        Double.longBitsToDouble(0x3fdcc9d2f9d0a7f8L), Double.longBitsToDouble(0x3fd9f40a0b005710L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=java.lang.Integer:-997 |a1=[B:[[-32, -96, -92, 120, 50, -59, 37]]\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 2, 4, "\uda0b\udc2a", "\u4210\u69d0\u36d4\u28a8\u0c62\u0af5\ud155", "\udb76\udd8f\udaa1\uddf8\udaf2\udc6f",
        3, -1000, 305816173, 7321642293537950128L, -50848L, true, false, (char) 52747, (char) 30500,
        Double.longBitsToDouble(0x3fc131ba34ab1528L), Double.longBitsToDouble(0x3fe76616a83f1e84L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 6, 13, "\ud972\udfd0", "\u20e0\uc282\u7716\u9eae\u401c\u22a9\u027d\u8332\u4fb9\u4113\u5684\ua9c6\u8a14\000\u8807\u334d\ub761\000\u096e\u03ed\u0811", "\ud8b6\udd8f\udb05\ude1c\udb26\udc0e\udbd0\udc2c\ud901\udf51\udb1c\udf59\ud8ef\udd92\ud8d6\udfef\ud9d1\udd3f\ud98b\udcdf\udbfe\ude09\ud907\udcde\udb51\uddc8\u3434\uda30\udcbd\ud8ed\udeaf\ud982\udf3f\udafa\udefb\ud867\udd7f\ud84b\udc5f\udac9\udfce\udb30\udd0a\udaed\udc39\ud8ae\udf98\udbe3\udfe2\udbcb\udc1b\ud861\udf07\ud865\uded8\uda87\udcd0\ud809\udfd9",
        0, 28831, -990347598, -5728951819348138840L, 58869L, true, true, (char) 28467, (char) 3207,
        Double.longBitsToDouble(0x3fd4701ec70dd7d8L), Double.longBitsToDouble(0x3fe4c6c1e5dd5388L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=java.lang.Long:1403 |a0=[B:[[73, 117, -112, -61, -32, -38, -69, -11]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 7, 6, "\uda79\udfa5\udbc0\uddf3\u0710\ud80a\udeeb\ud825\udec2\ud909\udc66\ud96c\uddb8\ud9b9\udebb\udb54\udf03", "\ua136\u2ed8\ub0fb", "\ud9f2\udcc1\ud8c4\udc42\udba8\udc69\ud995\ude3f\uda8c\udccd\udaf0\udc20\ud9e3\udff6\ud8c8\udc8e\udae0\udc63\ud80d\udcbc\ud8b0\udcf7\ud845\udfbd\udadb\udf23\ud906\udf01\ud965\udd81\udb5c\udd26",
        10, -791, -1547030612, 4564570701207749041L, 53295L, false, true, (char) 64995, (char) 11181,
        Double.longBitsToDouble(0x3fc990159d14d3bcL), Double.longBitsToDouble(0x3fbeef77f65d0c58L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=java.lang.Long:1035 |a0=[B:[[73, 117, -112, -61, -107, 65, -38, 74]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 6, "\uda79\udfa5\udbc0\uddf3\udac5\ude71\ud80a\udf7a\ud825\udec2\ud909\udc66\ud96c\uddb8\ud9b9\udebb\udb54\udf03", "\ua136\u2ed8\ub0fb", "\ud9f2\udcc1\ud8c4\udc42\udba8\udc69\ud995\ude3f\uda8c\udccd\udaf0\udc20\ud9e3\udff6\ud8c8\udc8e\udae0\udc63\ud80d\udcbc\ud8b0\udcf7\ud845\udfbd\udadb\udf23\ud906\udf01\ud965\udd81\udb5c\udd26",
        10, 79809, 12204, 1571078577L, 53295L, false, true, (char) 64995, (char) 11181,
        Double.longBitsToDouble(0x3fc990159d14d3bcL), Double.longBitsToDouble(0x3fbeef77f65d0c58L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Long:1019 |a0=[B:[[57, 117, -112, -61, -107, 65, -38, 74]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 6, "\uda69\udfa5\udbc0\uddf3\udac5\ude71\ud80a\udf7a\ufb7f\ud909\udc66\ud96c\uddb8\ud9b9\udebb\udb54\udf03", "\ua0f4\u2ed8\ub0fb", "\ud9f2\udcc1\ud8c4\udc42\udba8\udc69\ud995\ude3f\uda8c\udccd\udaf0\udc20\ud9e3\udff6\ud8c8\udc8e\udae0\udc63\ud80d\udcbc\ud8b0\udcf7\ud845\udfbd\udadb\udf23\ud906\udf01\ud965\udd81\udb5c\udd26",
        10, 79809, 12204, 0L, -100000L, false, false, (char) 64995, (char) 11181,
        Double.longBitsToDouble(0x3fc990159d14d3bcL), Double.longBitsToDouble(0x3fbeef77f65d0c58L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[21, 119, -94, -44, 97, -25, -48, -105]]\0121=void |a1=[B:[[21, 119, -94, -44, 97, -25, -48, -105]]\012",
        Z.run(T, 2, 13, 5, 4, "\udb45\udfa7\ud8d2\ude04\uda91\udf17\000\ud8c7\udd42\ua8d1\ud962\udf13\ud8e3\udf91\000\000\000\000\000", "\u6673", "\udba8\udc69\udb45\ude19\ud955\udcb1\udb9f\udc7d\uda64\udc2e\uda4f\udcf5\uda9c\ude73\ud85a\udde4",
        23, -1000, -1186800462, 11806985650783391L, -92828L, true, false, (char) 27263, (char) 6606,
        Double.longBitsToDouble(0x3eb61faaefd80000L), Double.longBitsToDouble(0x3e3ff73120000000L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 3, 2, "\uda84\udc6f\uda6b\udf06\udaf1\udd06", "\u6245\u9eae\u6030\u0af5\ud155\ub77f\uc792\u4113\u6f3a\ua973\u6679\u49be\uc688", "\uda8c\udccd\udaf0\udc20\udb23\ude87\uda37\udcff\ud8fe\uddba",
        31, -958, 1477640192, 8357018718595285294L, 10479L, true, false, (char) 28042, (char) 63871,
        Double.longBitsToDouble(0x3fe6f51e563aa7beL), Double.longBitsToDouble(0x3fd4d5d5cdcf8b34L)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[43, 54, -50, 71, -108, -38, -125, -1]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 2, "\ud85b\udd66\ud9fe\ude77\udbc4\udc0a\udab3\ude2f\ud938\ude4e\ua8d1\udafb\udd5f\uda29\udf1c\uda94\udc61\udb55\uddab\ueafb\udb58\uddd2\ud9f5\ude06", "\u8cb1\ua76b\u1b15\u32da\ub761\uce9f\u0e2d\u0476\u0811\u3580\u8837*\ub862\uc1b3\u6d85", "\ud852\udc4b\uda57\udd06\udb6c\uddea\uda7d\udd59\udb5f\udc3a",
        2, 68023, 502513623, 6522916431017505086L, -75355L, false, true, (char) 48983, (char) 55762,
        Double.longBitsToDouble(0x3fd2b85123920966L), Double.longBitsToDouble(0x3fe8935aa5e0edc0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[-73, 10, -50, 71, -108, -38, -125, -1]]\0121=java.lang.Boolean:false |a0=[B:[[-73, 10, -50, 71, -108, -38, -125, -1]]\012",
        Z.run(T, 2, 14, 14, 2, "\ud9e7\udf3a\ud9fe\ude77\udbc4\udc0a\udab3\ude2f\ud938\ude4e\ua8d1\uda73\udc9b\udb49\udeb0\uda94\udd38\udb55\uddab\u4e2f\udbb4\ude6b\udb76\udd8f", "\u8cb1\ua76b\u1b15\u4361\ub761\uce9f\u0e2d\u0476\u0811\u3580\u8837\ub9a4\ud114\uc184\u6d85", "\ud852\udc4b\uda57\udd06\udb6c\uddea\uda7d\udd59\udb5f\udc3a",
        2, 68023, 502513623, 6522916431017505086L, -75355L, false, true, (char) 42839, (char) 33721,
        Double.longBitsToDouble(0x3fd2b85123920966L), Double.longBitsToDouble(0x3fe8935aa5e0edc0L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[21, 119, -92, -44, -107, 65, -111, -67]]\0121=java.lang.Integer:-967 |a1=[B:[[-86, 49, 111, -3, 70, -31, 80, 7]]\012",
        Z.run(T, 2, 13, 8, 7, "\udb45\udfa7\ud8d4\udd04\udac5\ude71\udac1\udced\udab8\ude1e\ud808\udfd1\ud962\udf13\uda52\udd28\uda64\uddea\udb7a\udeb8\uda6b\udc94\uda8f\udc58\ud95f\udd81\ud923\ude94\udaf2\udc0e\ud930\udee1", "\u32da\ub761\uce9f\u0e2d\u0476\u0811\u3580\u8837\u8d7a\u694f\uc1b3\u6d85", "\ud9b4\udef8\udada\udf77\udb6c\ude3c\udaa0\udc99\ue71e",
        8, -975, 1084997700, -6392210015617721501L, -10161L, true, true, (char) 47062, (char) 34685,
        Double.longBitsToDouble(0x3fe2bc3942b48ff3L), Double.longBitsToDouble(0x3f99e6943f50cfa0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-101, -127, 82, -8, -68, 39, 52, 26]]\0121=java.lang.Long:0 |a0=[B:[[-101, -127, 82, -8, -68, 39, 52, 26]]\012",
        Z.run(T, 2, 13, 13, 12, "\ud8cb\uddb1\ud882\udd28\udaec\udd57\u5564\udb4a\udc03\udbab\udf75\ud962\udf13\udabd\uddfd\udb9c\udf48\uda0a\udeb6\ud9d0\uddbc\ud840\udf86\udb76\udd8f", "\u4d63\ub667\u6afb\u6584\u3832\ubf2b\u2215\u6969\u343d\uace8\u0b94\u0461\uce97\u4348", "\udab3\udfd2\ud9b4\ude44\udada\udf77\udb6c\ude3c\udb4b\udf9f\ud92a\udec1L\ud873\udd96\ud94a\udf99\ud8db\ude41\ud983\udf80\udb0f\ude1e\ud8dc\udf84\uda81\udced\udb61\udf3c\ud825\udfe3\ud87e\udcce\udb7f\udcc1\ud834\ude0e\ud8cc\ude22",
        29, -522, -1795175527, -2319679458472868624L, -74765L, true, true, (char) 60439, (char) 51679,
        Double.longBitsToDouble(0x3fc7cb6b4e7e08d8L), Double.longBitsToDouble(0x3fe43427ef6efcdaL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=void |a1=[B:[[-12, -112, -29, 123, 20, -33, -58]]\0121=void |a1=[B:[[-12, -112, -29, 123, 20, -33, -58]]\012",
        Z.run(T, 2, 5, 5, 15, "\uda24\udcc0\023\udbab\udf44\ud80f\udff6", "\u196a\u214c\u3443\u86c6", "\udb76\udd8f\udad2\udeef\udaf2\udc0e\udabc\udca6\ud90e\udf9f",
        39, -1000, -825341696, 81735343603712L, -68025L, true, false, (char) 34897, (char) 46160,
        Double.longBitsToDouble(0x3fcd985aa0fd604cL), Double.longBitsToDouble(0x3fe9b087d079d920L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=java.lang.String: |a0=[B:[[-10, 54, -29, 123, 20, -33, -58]]\0121=java.lang.String: |a0=[B:[[-10, 54, -29, 123, 20, -33, -58]]\012",
        Z.run(T, 2, 15, 15, 7, "\uda26\udd66\023\udbab\udf44\ud80f\udff6", "\000\u30c6\u3443\uc468", "\udb76\udd8f\udad2\udeef\udaf2\udc0e\udabc\udca6\ud90e\udf9f",
        37, -1000, -825341696, 371483148288L, 87623L, true, true, (char) 63300, (char) 50588,
        Double.longBitsToDouble(0x3fcd985aa0fd604cL), Double.longBitsToDouble(0x3f3cfea4fa3bf000L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Long:0\0121=void\012",
        Z.run(T, 2, 13, 5, 0, "\udbc0\udcf3", "\000\ub9c2\u6245\u9eae\u201c", "",
        -5, -1000, 0, -1468661760L, -7066L, false, false, (char) 36263, (char) 44699,
        Double.longBitsToDouble(0x3fd56ceceb9f65ecL), Double.longBitsToDouble(0x3fea88ec6b1fe8f9L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Long:0 |a0=[B:[[-101, -127, 82, -8, -68, 39, -37, 46]]\0121=java.lang.Long:0 |a0=[B:[[-101, -127, 82, -8, -68, 39, -37, 46]]\012",
        Z.run(T, 2, 13, 13, 12, "\ud8cb\uddb1\ud882\udd28\udaec\udd57\ud80b\udd5e\udb4a\udc03\udbab\udf75\ud962\udf13\udabd\uddfd\udb9c\udf48\uda0a\udeb6\ud9d0\uddbc\udb2d\udd26\ud975\udcde", "\u4d63\ub667\u6afb\u6584\u3832\u4d18\u2215\u6969\u343d\uace8\u0b94\u0461\uce97\u4348", "\udac3\udfd2\ud9b4\ude44\ud840\udd27\udbc6\udfbb\udb4b\udf9f\ud92a\udec1L\ud873\udd96\ud94a\udf99\ud8db\ude41\ud983\udf80\udb0f\ude1e\ud8dc\udf84\ud9fc\ude4a\ud868\udc5a\ud825\udfe3\ud87e\udcce\udb7f\udcc1\ud834\ude0e\ud8cc\ude22",
        29, -522, -1736819559, -2319679458472868624L, -74838L, false, true, (char) 60439, (char) 51679,
        Double.longBitsToDouble(0x3fc7cb6b4e7e08d8L), Double.longBitsToDouble(0x3fe43427ee6efcdaL)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=void |a1=[B:[[58, -43, -37, -76, -14, -113, -33, -58]]\0121=void |a1=[B:[[58, -43, -37, -76, -14, -113, -33, -58]]\012",
        Z.run(T, 2, 5, 5, 15, "\ud96a\udf05\ud90b\udce4\udb22\udcbf\ud80f\udff6", "\u2053\u214c\u3443\u86c6", "\udb76\udd8f\udad2\udeef\udaf2\udc0e\udabc\udca6\ud90e\udf9f",
        39, -1000, -825341696, 81735343603712L, -74859L, false, false, (char) 19393, (char) 28754,
        Double.longBitsToDouble(0x3fe9b087d079d920L), Double.longBitsToDouble(0x3fedcfdfbc70c978L)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 6, 0, "\udb45\udfa7\ud8d2\ude04\udb5a\udffb\ud811\udf51\uda04\ude38\ua900\ud962\udf13\ud8a2\udd30", "\u2c12\u2239\uc612", "\ud86f\ude3a\udba4\udef7\udbfc\ude3e",
        13, 41280, 1570546341, 9088204718952978275L, 25796L, true, true, (char) 29382, (char) 19393,
        Double.longBitsToDouble(0x3fafac0992e12fa0L), Double.longBitsToDouble(0x3fccfaca530ef444L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 6, 4, "\udb45\udfa7\udb9f\udf50\udac5\ude71\uaed2\ud902\udc85\ua8d1\ud9e4\uddc5\uda52\udd28\uda94\udd38\udbf1\udf46\udb8a\udc40\uda8f\udc58\udb76\udd8f", "\u6679\u2f11\uc6d7", "\uda8c\udccd\udaf0\udc20\uda05\uddd0\uda37\udcef\uda9c\ude73",
        3, 70384, 1477658332, 8357018718595285294L, 76015L, false, true, (char) 27893, (char) 63871,
        Double.longBitsToDouble(0x3fcbd4795ac4fd60L), Double.longBitsToDouble(0x3fea6aefde77fa35L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[B:[[3, -79, 1, 29, 53, -48]]\012",
        Z.run(T, 1, 14, 0, 4, "3\ud9e1\udd31\ud94d\udf65\u6300", "\u37e9\ua00e", "\udb04\udfc1\ud98f\udf06\udbb0\udd8c\ud8ad\udd3d\udbf6\udc42\uaf90\000\000\udae9\uddf3\ud80f\udcad",
        2, 3326, -388335643, 2247616280092732260L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3feab801484f0039L), Double.longBitsToDouble(0x3fe1d30d9800a88bL)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=java.lang.Long:329 |a0=[B:[[21, 119, -67]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 8, 1, "\udb45\udfa7\u88ed", "\u7ec4\ubb61\u9eae\u214c\u3443\uafaa\uce38\uad47\u7b08\u6407\u7138\u9e40\u7b03\u6afb\u2320\u0092\u856f\u7a57\u6969", "\ud9eb\udfaa\ud8b6\udd8f\udb05\ude1c\ud9c0\udd68\uda41\udf8c\udb4a\udf5a\uda88\udc0e\ud9b6\udd26",
        1, 18220, -766403362, -4072648870980541272L, -80793L, true, false, (char) 50548, (char) 1828,
        Double.longBitsToDouble(0x3fb1d679f9ae0028L), Double.longBitsToDouble(0x3fe83f6ef52be43cL)));
  }
  @Test(timeout = 4000)
  public void test89() throws Throwable {
    assertEquals("0=java.lang.Integer:-951 |a1=[B:[[-27, 49, 111, -3, 94, -22, 80, 7]]\0121=java.lang.Integer:-951 |a1=[B:[[-27, 49, 111, -3, 94, -22, 80, 7]]\012",
        Z.run(T, 2, 8, 8, 2, "\udb45\udfa7\ud8d4\udd04\uda4c\ude00\udaee\udc4f\ud8ef\udef2\ud808\udfd1\ud962\udf13\uda52\udd28\uda64\uddea\udb7a\udeb8\udb8a\udc40\uda8f\udc58\ud95f\udd81\udaf0\udc3a\ud933\udea7\uda9e\ude03", "\u4015\ub761\uce9f\u0e2d\u888e\u6f1a\u3580\u8837\u8d7a\u694f\uc1b3\u6d85", "\ud94a\udf0a\udabc\uddd9\ud9a0\udc96\udaa0\udc5b\udb5f\udc3a",
        2, -953, 1084997700, -6392210015617721501L, -10161L, true, true, (char) 47062, (char) 34685,
        Double.longBitsToDouble(0x3fe2bc3942b48ff3L), Double.longBitsToDouble(0x3f99e6943f50cfa0L)));
  }
  @Test(timeout = 4000)
  public void test90() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[B:[[43, 54, 32, -27, 22, -100, 50, 100]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 0, 2, "\ud85b\udd66\ud950\udd15\udb46\udecc\ud862\ude94\udac9\udec4\uda70\udf8b\udafb\udd5f\uda29\udf1c\uda94\udc61\udb55\uddab\ueafb\udb58\uddd2\ud9f5\ude06", "\ua683\ua76b\u1b15\u32da\ub761\uce9f\u6e61\u0476\u0811\u64ee\u8837*\ub862\uc1b3\u6d85", "\ud852\udc4b\uda57\udd06\udb6c\uddea\uda7d\udd59\udb5f\udc3a",
        2, 68023, 502513623, 6522916431017505086L, -75355L, false, true, (char) 48983, (char) 55762,
        Double.longBitsToDouble(0x3fd2b85123920966L), Double.longBitsToDouble(0x3fe8935aa5e0edc0L)));
  }
  @Test(timeout = 4000)
  public void test91() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 1, 8, 6, 13, "\000", "\u20e0\uc282\u7716\u9eae\u401c\u22a9\u027d\u8332\u4fb9\u4113\u5684\ua9c6\u8a14\000\u8807\u334d\ub761\000\u096e\u03ed\u0811", "\ud8b6\udd8f\udb05\ude1c\udb26\udc0e\udbd0\udc2c\ud818\udc5d\000\000\ud8d6\udfef\ud9d1\udd3f\ud98b\udcdf\udbfe\ude09\ud907\udcde\udb51\uddc8\u3434\uda30\udcbd\ud8ed\udeaf\ud982\udf3f\udafa\udefb\ud867\udd7f\ud84b\udc5f\udac9\udfce\udb30\udd0a\udaed\udc39\ud8ae\udf98\udbe3\udfe2\udbcb\udc1b\ud861\udf07\ud865\uded8\uda87\udcd0\ud809\udfd9",
        0, 28831, -990347598, -5728951819348138840L, 58869L, true, true, (char) 28467, (char) 3207,
        Double.longBitsToDouble(0x3fd4701ec70dd7d8L), Double.longBitsToDouble(0x3fe4c6c1e5dd5388L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|computeCheckSum|[B|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|exceptionMessage|[B,int,int,int,byte|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatBigIntegerBinary|long,[B,int,int,boolean|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatCheckSumOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongBinary|long,[B,int,int,boolean|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatLongOctalOrBinaryBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatNameBytes|java.lang.String,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatNameBytes|java.lang.String,[B,int,int,org.apache.commons.compress.archivers.zip.ZipEncoding|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatOctalBytes|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|formatUnsignedOctalString|long,[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseBinaryBigInteger|[B,int,int,boolean|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseBinaryLong|[B,int,int,boolean|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseBoolean|[B,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseName|[B,int,int|static",
    "M|org.apache.commons.compress.archivers.tar.TarUtils|parseOctal|[B,int,int|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
