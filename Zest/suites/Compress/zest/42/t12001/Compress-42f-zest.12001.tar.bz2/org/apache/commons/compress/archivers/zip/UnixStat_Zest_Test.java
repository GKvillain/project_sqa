package org.apache.commons.compress.archivers.zip;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnixStat_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 15, "\udb58\udf24\ud802\ude36\ud93e\udd51\ud90a\udec3\ud934\ude48\udb0e\udf6e", "\u7617\u41a3\ua1f2\u746b", "\ud93f\uded7\ud9c3\udc4a",
        -3, 63228, -2146856585, -1940509635880127407L, -51929L, true, true, (char) 57789, (char) 37003,
        Double.longBitsToDouble(0x3fcffaff4706c778L), Double.longBitsToDouble(0x3fc6f49b7ad27aa8L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 15, "\udb58\udf24\ud802\ude36\ud93e\udd51\ud90a\udec3\ud934\ude48\udb0e\udf6e", "\u7617\u41a3\ua1f2\u746b", "\ud93f\uded7\ud9c3\udc4a",
        -3, 63228, -2146856585, -1940509635880127407L, -51917L, true, true, (char) 57789, (char) 37003,
        Double.longBitsToDouble(0x3fcffaff4706c778L), Double.longBitsToDouble(0x3fc6f49b7ad27aa8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null]] |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 14, 4, 15, "\udb58\udf24\ud802\ude36\ud93e\udd51\ud90a\udec3\ud934\ude48\udb0e\udf6e", "\u6cfa\ucb17\ucf08\ud42e", "\ud93f\uded7\udbfe\udebd",
        -3, 63228, -2146856585, -1606398840186141312L, -12971L, false, true, (char) 15696, (char) 17424,
        Double.longBitsToDouble(0x3fc306e4c551fd4cL), Double.longBitsToDouble(0x3fcffaff4706c778L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 10, 0, "\udb7d\uddcb", "\u437b\u451b\u3053\u1313\u60f6\u4d18\u4bb2\u35aa\u3c55\ud1e3\uaa09\u8828\u9e1d\u4cca\u090d\u3114\ua3db\u23c4\u08c5", "\ud8de\udd08",
        21, 36154, 1537894514, 374841746236968844L, 88051L, false, true, (char) 22005, (char) 9636,
        Double.longBitsToDouble(0x3fe6e730a2e8e646L), Double.longBitsToDouble(0x3fbf7c694947c5d8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 15, "\udb58\udf24\uda33\udc69\ud927\udfbf\ud8ec\udd94\ud934\ude48\udb0e\udf6e", "\uac50\u2b2e\ua1f2\u746b", "\ud93f\uded7\ud891\udc48",
        -3, 63228, -2146856585, -1940509635880127407L, -51929L, true, true, (char) 57789, (char) 37003,
        Double.longBitsToDouble(0x3fcffaff4706c778L), Double.longBitsToDouble(0x3fd7fa4db357848aL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Long:0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 10, 14, 2, "\udb58\udf24\ud8e5\udce8\ud93e\udd51", "\ub6b5\u633d\u436c\u1186\u3a92\ua1f2\u746b\u9f18\u6c57\u5008\u3354\u7307\ub68f", "\ud82f\udcc5",
        32, 62052, -1521212103, -388515977135706387L, 32897L, true, false, (char) 65189, (char) 12538,
        Double.longBitsToDouble(0x3fdc1b1de16f49b6L), Double.longBitsToDouble(0x3feeeaadb4da3f99L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 3, "\udb83\udf73\ud802\ude36\ud93e\udd51\ud90a\udec3\ud934\ude48", "\ua572\u7653\u41a3\ua1f2", "\udb4b\udf75\ud93f\uded7\ud8da\udc22\uda97\udd4f\udb74\udea3\ud9ce\uddec",
        12, 75561, 1237179062, -1050552201873447623L, 96595L, false, true, (char) 17386, (char) 57789,
        Double.longBitsToDouble(0x3fd547f371ffaff4L), Double.longBitsToDouble(0x3fdc1b1de16f49b6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 2, 14, "\udb58\udf24\ud802\ude36\ud93e\udd51\ud90a\udec3\ud934\ude48\ud99b\udf20\ud993\ude53\ud80e\udebf\ud96d\udc38\udb03\uddcc", "\u9f18\u082e\u4a21\u2d2a\u6263\u8043\u695c\u53ac\u4ba7", "\ud819\udfe1\ud8d5\udea6\uda93\udcf2\ud8a8\uddf7\uda74\udc78\ud941\ude82\udbb8\uded9\ud8e0\udfbc\udbf7\udc61\uda0c\udefa\ud8a4\udffa\uda50\ude48\ud843\udc9a\uda7c\udf03\udba4\udfbd",
        56, 77023, 1426644048, -713563355460138508L, 95951L, false, true, (char) 7490, (char) 31761,
        Double.longBitsToDouble(0x3fbc51047698f830L), Double.longBitsToDouble(0x3fd46220e7fcd502L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 15, "\udb58\udf24\ud802\ude36\ud93e\udd51\ud90a\udec3\ud934\ude48\udb0e\udf6e", "\u7617\u41a3\u08f3\u1e07", "\ud90b\udf48\ud9c3\udc4a",
        -3, 63228, -906146441, -1940509635880127407L, -51929L, true, true, (char) 57789, (char) 37003,
        Double.longBitsToDouble(0x3fcffaff4ee1cb78L), Double.longBitsToDouble(0x3fb93405f5a4f550L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null]] |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 4, 15, "\udb58\udf24\ud975\udecf\ud93e\udd7c\ud90a\udec3\udb44\ude71\u1b7b", "\u7617\u41a3\ua1f2\u746b\u9f18\u082e\u5008", "\ud90b\udeec\ud9ce\uddec\udace\udf2d\ud94c\udf47\udbb6\udeaa\ucf7b\ud819\udfe1\udb6c\udfc9\udaef\udf8a\ud901\udfd0\u0a61",
        19, 70580, -1310828289, -6567416210270840649L, -61925L, true, false, (char) 17700, (char) 57573,
        Double.longBitsToDouble(0x3fdf2cd12119c908L), Double.longBitsToDouble(0x3fd51fce24379160L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 15, "\ud818\udc29\udaa4\udfc7\ud853\ude16\uda91\udd25\uda59\uddb9\udb0e\udf6e", "\u7617\ub286\uc349\u300b", "\ud933\udfcb\udacd\udd28\udbbd\udf72\udb76\udc6e\uda95\uddb8\ud97e\udd92\uda24\ude17\ud950\udc6d\ud9ae\udc72\uda1e\uddf8\udb7a\udd73\udbb0\ude72\ud8e4\udcc0\uda53\udf5c\udb09\uded0",
        14, 49711, -1529095743, -4059404938340519207L, -50672L, false, false, (char) 44604, (char) 3663,
        Double.longBitsToDouble(0x3fea7543e5293b4fL), Double.longBitsToDouble(0x3fdcf5fc3cfab092L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 13, 2, "\udb80\udfec\uda47\ude18\udbf7\ude0f\udad2\udd94\ud932\udf4c\udb0e\udf6e", "\u7617\uccc0\u9f97\u8541", "\ud93f\uded7\ud9a1\udf4a",
        -3, 63228, -2146856585, -1940509639717623471L, -11243L, false, false, (char) 64235, (char) 35730,
        Double.longBitsToDouble(0x3fcf1a859ad27aa8L), Double.longBitsToDouble(0x3fcc73a90b58a0ecL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null... |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 4, 5, 15, "\ueac1\udb56\ude34\udbed\ude65\ud90a\udec3\ud934\ude48\ud818\udea2", "\u75ec\u41a3\ua1f2\u629f", "\ud93f\uded7\ud9c3\udc4a\ud9c1\udc0a\ud90b\udeec\ud9ce\uddec\udace\udf2d\ud94c\udf47\udbb6\udeaa\ucf7b\ud819\udfe1\udb6c\udfc9\udaef\udf8a\ud901\udfd0\u0a61\ud8ec\ude17\ud88d\udef8",
        56, 43257, -1633019721, -2811830888366064585L, 90198L, true, false, (char) 16624, (char) 7271,
        Double.longBitsToDouble(0x3fe5c0db9296a7d5L), Double.longBitsToDouble(0x3feaf8f69e41ba72L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 2, 0, "\udb58\udf24\ud953\udfde\udbcd\udf8f\u2002\uf491\ud9dd\uddf6\udbd0\udc00\ud8b2\udcb1\udb04\ude0b\udb03\uddcc\udbc4\udefa\udaad\udddf\uda98\ude5b\ud965\uddd1\ud93f\uded7\ud9c3\udc4a\ud9a7\ude4e\ud90b\udeec\ud9ce\uddec\udace\udf2d\ud94c\udf47\udbb6\udeaa", "\u49c8\u4fc2\u1d10\ub8a0\u05d1", "\udbf7\udc61\uda0c\udefa\udac9\udd6c\ud82f\udfdb\u2f62\ud80a\udf2e\u4261\udbf4\udfd7\ud94d\ude80\udba5\ude79\udb3e\udc59\ud9f7\ude6e\ud98f\udd63\ud863\udfee\udaab\udec3\uda65\udc1b\udafa\uddea\ud8a1\udf10\udb87\uddb0\udb18\udf74\udad7\udeda\ud9d3\udf9e\ud83a\udc36\uda27\udc21\udba9\ude0e\udba9\udc9d\ud94d\ude0d\udabc\uded2\ud8b6\udf46\ud8ce\udd79\udbe6\uddf7\ud8c2\udc55\ud940\ude10\ud9f4\udd84\ud976\udebd\uda82\ude0a\uda23\udd63\udbdf\udd4c\ud985\ude98\uda41\udf2a\ud816\udf8e\ud826\udfc7\uda09\ude66\uda4d\udd0c\uda57\udfae\ud9be\udf26\udbd4\udc59\ud84a\udc63\udb05\udc79\ud94f\udf73\ud92a\uddf6",
        31, 70912, 2125882430, 6950410420718356126L, 78413L, true, true, (char) 40849, (char) 55843,
        Double.longBitsToDouble(0x3fe5c91afcc29e14L), Double.longBitsToDouble(0x3fd18356a810be5aL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 9, 15, "\udbd7\udee4\ud802\ude46\ud93e\udd51\ud90a\udec3\ud934\ude48\udb0e\udf6e", "\u7617\u41a3\ua1f2\u746b", "\ud93f\uded7\ud9c3\udc4a",
        -3, 63228, -2146856585, -1940509635880127407L, -25689L, true, true, (char) 41696, (char) 25470,
        Double.longBitsToDouble(0x3facfc8b2a035ef0L), Double.longBitsToDouble(0x3fe4c1bee1547f37L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 15, "\udb58\udf24\udb8e\udcbc\ud96b\udf65\ud903\udc24\udb42\ude07\ud9a8\ude41", "\u7617\u30c0\ua193\u746b\u312b\u43d1", "\ud9b8\udc4e\ud90b\udeec\ud9ce\uddec\udace\udf2d\udae0\udf51\udbb6\udeaa\ucf7b",
        52, 34175, 1386889259, 4390803118404011809L, 35508L, true, false, (char) 35743, (char) 48530,
        Double.longBitsToDouble(0x3fe5a4f5531f580fL), Double.longBitsToDouble(0x3fd40438d2ca18a2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 9, 3, 4, "\udb58\udf24\ud802\ude36\udb04\ude73\ud86b\udede\ud8d6\udc90\udbd7\udfb2", "\u75cf\u41a3\ud450\u746b", "\ud93f\uded7\udb01\udca8",
        51, 83134, 538462826, -6790890639331134383L, -51929L, true, true, (char) 57789, (char) 37003,
        Double.longBitsToDouble(0x3fcffaff4706c778L), Double.longBitsToDouble(0x3fc6f49b7ad27aa8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null]] |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 15, "\udb58\udef9\ud802\ude36\ud93e\udd51", "\ub6b5\u633d\uab45\u7617\u41a3\ua1f2\u746b\u9f18\u082e\u2f8d\ubc4c\u6263\u3e24", "\ud94c\udf47",
        51, 20255, 55846201, 8572707684218241011L, 32897L, false, false, (char) 37003, (char) 12538,
        Double.longBitsToDouble(0x3fdc1b1de16f49b6L), Double.longBitsToDouble(0x3fe5a4f551c2bf65L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 2, 15, "\uda10\udf1e\ud802\ude36\udab6\udd8d\udbbd\udc76\ud934\ude8c\ud8aa\udddb", "\u331e\u41a3\u9160\u90b0\u9f18\u082e\u5008", "\ud90b\udeec\ud853\udf2d\ud994\udf5e\ud8de\udf50\udbb6\udeaa\ucf7b\ud819\udfe1\udb6c\udfc9\udaef\udf8a\ud901\udfd0\u0a61",
        19, 37324, -1310828289, -6567416210270840649L, -39080L, false, false, (char) 46810, (char) 2168,
        Double.longBitsToDouble(0x3fd33db74d1df790L), Double.longBitsToDouble(0x3fd1007f9a698f64L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 13, 13, 10, "\ud8ff\udf95\ud898\udece\udac0\udc32\udb72\udf8d\ud934\ude48\udb0e\udf6e\uda6a\udea6\ud80e\ude89\ud96d\udc38\udb03\uddcc\ud8d9\udc82\udb78\udc9d\ud81b\ude23\uda37\udd92", "\u8d82\u4921\u69cd\u574f\uc841\u7649\u5f0f\u6867\u9dfd\u4fc2\u4c71\ua87d\u595f\u8d77", "\ud8a1\udd61\ud877\udf9e\ud9b7\udf97\ud86b\udc0f\ud9a2\ude20\ud939\udd0f\ud9a8\uddf4\udbc5\udf43\ud861\ude2f\ud8c8\udd7a\uda0f\udfd7\ud803\udff0\ud8e9\ude25\ud826\udc48",
        58, 4869, 506172160, 4130625760168721751L, -56514L, true, true, (char) 38701, (char) 39381,
        Double.longBitsToDouble(0x3fe3ff140485d4fcL), Double.longBitsToDouble(0x3fd41e1cacbeceaaL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.GeneralPurposeBit:org.apache.commons.compress.archivers.zip.GeneralPurposeBit@0 |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 14, 14, 3, "\udb12\udc31\ud81e\udc16\ud98c\ude37\udaea\udeab\ud810\udc22\udb8a\ude46", "\u6cfa\ucb17\ucf08\ud42e", "\ud93f\uded7\udbfe\udebd",
        -3, 63228, -2146856585, -1606398840186141312L, -12971L, false, true, (char) 15696, (char) 17424,
        Double.longBitsToDouble(0x3fc306e4c551fd4cL), Double.longBitsToDouble(0x3fcffaff4706c778L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null]] |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null... |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 4, 5, 10, "\udb58\udf24", "\u4792\u6858", "\ud80e\ude89\ud972\udc63\ud903\udc88\uda97\udf1d\ud891\udd06\uda04\ude02\udb45\ude29\ud93f\uded7\uda4a\ude3a\ud8e1\udca3\ud872\udf41\udb0c\udfe5\ud89d\udf57\ud8a5\ude40\ud8fd\uded0\udb73\udf5b",
        39, 30750, -115933190, -8626351269945669855L, 32468L, false, true, (char) 35847, (char) 18027,
        Double.longBitsToDouble(0x3fee3a7ef8e279d8L), Double.longBitsToDouble(0x3fedb82025a251aaL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=java.lang.Boolean:false |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 6, 6, 14, "\udb58\udf24\ud802\ude36\ud9fd\udf90\ud8c5\udc46\udaa2\ude93\udb0e\udf6e\uda6a\udea6\ud80e\ude89\ud925\udd94", "\ud42e\u2d19\u532d\u5008\ucd62\u1a64\u3e24\u69cd\uca57\ubc24\ud5d2\u8c94\u4b90\u9676", "\u0a61\udbbf\udc18\ud88d\udef8\ud8e1\udc64",
        5, 62180, 1923965598, 9093695778186952490L, 76900L, true, false, (char) 29098, (char) 7264,
        Double.longBitsToDouble(0x3fb7a6c70b637780L), Double.longBitsToDouble(0x3fe674903da3aa8cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=org.apache.commons.compress.archivers.zip.ZipArchiveEntry: |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 3, 3, 3, "\udb83\udf73\udb14\udf31\ud93e\udd51\ud90a\udec3\ud934\ude48", "\ua572\u7653\u41a3\ua1f2", "\udad5\udd10\ud93f\uded7\ud8da\udc22\uda97\udd4f\udb74\udea3\ud9ce\uddec",
        12, 98609, 1237179062, -1050552200128810183L, 78718L, false, true, (char) 20202, (char) 57789,
        Double.longBitsToDouble(0x3fd547f371ffaff4L), Double.longBitsToDouble(0x3fdc1b1de16f49b6L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=null |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 11, 11, 15, "\udb58\udf24\ud802\ude36\ud93e\udd51\ud90a\udec3\uda02\udd10\ud947\udde7\ubb6b\uda58\ude79\ud96d\udc38\udb03\uddcc", "\u9f18\u07e3\u4ec6\u2d46\u6263\u8043\u695c\u53ac\u99a0", "\uda5e\udf23\ud981\udf67\uda88\udeba\ud8a8\uddf7\uda74\udc78\ud941\ude82",
        39, 49543, -1529095743, 6749234165050203828L, 88369L, false, true, (char) 54118, (char) 50779,
        Double.longBitsToDouble(0x3fde955083e9b230L), Double.longBitsToDouble(0x3fc4152215bd5284L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null... |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null... |a0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\012",
        Z.run(T, 2, 5, 5, 15, "\ueac1\udb56\ude34\udbcd\udd34\uda99\udfed\ud934\udebc\ud818\udea2", "\u75ec\u41a3\ua1f2\u629f", "\ud93f\uded7\ud9c3\udc4a\ud9c1\udc0a\udb86\udeb6\ud9ce\ude40\udace\udf2d\ud94c\udf47\udbb6\udeaa\ucf7b\ud8e0\ude5d\udb6c\udfc9\udaef\udf8a\ud901\udfd0\u0a61\ud8ec\ude17\ud89e\udcf8",
        56, 43257, -1633019721, -2811830888366064585L, 90198L, false, false, (char) 34469, (char) 38361,
        Double.longBitsToDouble(0x3fc7036e4a5a2d30L), Double.longBitsToDouble(0x3feaf8f69f36ba72L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 0, "\uda2f\uded2\uda49\uddef\ud973\udcdb\udbd0\ude60\ud97a\udcc3\ud91e\udea1\udbd0\udc00\ud8b2\udcb1\udb04\ude0b\ud8e1\udfb4\ud95b\udd83\udaad\udddf\uda98\ude5b\ud965\uddd1\ud93f\uded7\ud9c3\udc4a\ud9a7\ude4e\ud9ea\udf7d\ud810\udc6c\udace\udec2\ud94c\udf47\udbb6\udeaa", "\u49c8\u4fc2\u1d10\ub8a0\u05d1", "\udbf7\udc61\uda0c\udefa\udac9\udd6c\ud82f\udfdb\u2f62\ud312\u4261\udbf4\udfd7\ud94d\ude80\udba5\ude79\udb3e\udc59\ud9f7\ude6e\ud98f\udd63\ud863\udfee\udbff\udd4e\uda72\udf04\udafa\uddc2\ud8a1\udf10\udb87\uddb0\udb18\udf74\udad7\udeda\ud9d3\udf9e\ud83a\udc36\uda27\udc21\udba9\ude0e\udba9\udc9d\ud94d\ude0d\udabc\uded2\ud8b6\udf46\ud8ce\uddfe\udbe6\uddf7\ud8c2\udc55\ud940\ude10\ud9f4\udd84\ud976\udebd\uda82\ude0a\uda23\udd63\uda9e\ude27\ud96c\ude28\uda41\udf2a\ud816\udf8e\ud826\udfc7\uda09\ude66\uda4d\udd0c\uda57\udfae\ud9be\udf26\udbd4\udc59\ud84a\udc63\udb05\udc79\ud94f\udf73\ud900\udcfa",
        31, 70912, 2125882430, 6950410420718356126L, -91369L, false, true, (char) 52491, (char) 41162,
        Double.longBitsToDouble(0x3fd551190810be5aL), Double.longBitsToDouble(0x3fe9797371accfe4L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=[B:[[]] |this=org.apache.commons.compress.archivers.zip.ZipArchiveEntry:\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 15, "\udb58\udf24\u5a21\000\000\ud934\ude48\udb0e\udf6e", "\u7617\u41a3\ua1f2\u746b", "\ud93f\uded7\ud9c3\udc4a",
        -3, 63228, -2146856585, -1940509635882486703L, -51929L, true, true, (char) 57789, (char) 37003,
        Double.longBitsToDouble(0x3fcffaff4706c778L), Double.longBitsToDouble(0x3fc6f49b7ad27aa8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|isUnixSymlink||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|addAsFirstExtraField|org.apache.commons.compress.archivers.zip.ZipExtraField|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|addExtraField|org.apache.commons.compress.archivers.zip.ZipExtraField|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|clone||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|copyOf|[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|copyOf|[Lorg.apache.commons.compress.archivers.zip.ZipExtraField;,int|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|equals|java.lang.Object|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getAllExtraFields||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getAllExtraFieldsNoCopy||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getCentralDirectoryExtra||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExternalAttributes||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraField|org.apache.commons.compress.archivers.zip.ZipShort|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraFields||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getExtraFields|boolean|new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getGeneralPurposeBit||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|getInternalAttributes||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
    "M|org.apache.commons.compress.archivers.zip.ZipArchiveEntry|isUnixSymlink||new:org.apache.commons.compress.archivers.zip.ZipArchiveEntry:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
