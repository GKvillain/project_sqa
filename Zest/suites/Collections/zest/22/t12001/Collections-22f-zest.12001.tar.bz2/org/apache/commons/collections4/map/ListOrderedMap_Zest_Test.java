package org.apache.commons.collections4.map;
import org.junit.Test;
import static org.junit.Assert.*;
public class ListOrderedMap_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 6, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u954d\u1086\ub602\u0f73\u9998\u30bd", "\uda0d\udc8b\udab3\udd60\ud8d3\udfff\uda6a\udf64\udb88\udc4d\ud974\udc0d",
        9, 36949, -867934802, -8137624713911952930L, 40189L, true, true, (char) 52370, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.list.UnmodifiableList:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 10, 2, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u954d\u1086\ub602\u0f73\u9998\u30bd", "\uda0d\udc8b\udab3\udd60\ud8d3\udfff\uda79\udfcc\udb6f\udcb0\ud974\udc0d",
        9, 36949, -867934802, -8137624713911952930L, 40189L, true, true, (char) 52370, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 6, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\uc4b5\u1036\u9e4e\u0f73\u4fd1\u2447", "",
        15, 68664, 14878, 2000420864L, -85930L, false, false, (char) 476, (char) 9653,
        Double.longBitsToDouble(0x3fdde8f117c417acL), Double.longBitsToDouble(0x3fb8f05d1e39d368L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 1, 10, 0, 15, "\udbb6\udccd\000\udbaf\udcb6\ud969\udf19\ud886\ude18\ud81b\udcbb", "\000\000\000\u0eb4\u9998\u0c76", "\000\udab3\udd60\u3a1e\uda6a\udfd4\udb88\udc4d\ud974\udc0d",
        9, 36949, -867934802, -8137624713911952930L, 40189L, false, false, (char) 35839, (char) 21268,
        Double.longBitsToDouble(0x3f4cc673ba480000L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 16, 6, 9, "\ud8a0\udd8f\ud8a9\udd63\udbab\udf21\udb1d\udf2e\udb32\udf2f\ud9e5\udfef", "\u9aa4", "\udb1c\udce6\u07cb\ud8fd\udd0f\udb35\udf09\uda79\udfad\uda45\udde2",
        34, 61390, 355492231, 8639762491649370329L, 5266L, false, true, (char) 9653, (char) 10479,
        Double.longBitsToDouble(0x3fef14a6b47bc174L), Double.longBitsToDouble(0x3fee39d36cf13fa2L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap$ListOrderedMapIterator:Iterator[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 10, 13, 9, "\udaf6\udf60\uda0b\uddc3\uda94\udc5f\ud867\udeb8\ud886\ude18\ud81b\udcbb", "\u5d42\u91f8\u1928\u0f73\u9998", "\udbaf\udc7d",
        29, 76130, 1664631576, 4726729599068720711L, 46850L, true, true, (char) 10491, (char) 32159,
        Double.longBitsToDouble(0x3f8f9126f1ceaa40L), Double.longBitsToDouble(0x3fef4d851207e75aL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 10, 14, 6, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud900\udc23\ud881\udcc0\udada\udfbc", "\u3e0e\u7bec\u9d5d\u0f73\u9998\u30bd", "\udb4b\udc8a\udab3\udd60\ud8d3\udfff\uda6a\udf64\udb88\udc4d\ud973\udf55",
        17, 68845, -1552629090, -8137624409218311714L, 40189L, true, true, (char) 52382, (char) 64902,
        Double.longBitsToDouble(0x3fdb9e6339c49232L), Double.longBitsToDouble(0x3fd776ff544799c6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 12, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\u87c8\ud81b\udcbb", "\u954d\u1086\ub602\u0f73\u9998\u30bd", "\uda0d\udc8b\udab3\udd60\ud8d3\udfff\uda6a\udf64\udb88\udc4d\ud974\udc0d",
        9, 36949, -867934802, -8137624713911952930L, 40189L, true, true, (char) 42131, (char) 172,
        Double.longBitsToDouble(0x3fd4d02109dd2492L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u8cfa\u7bad\u87cb\ud1b0\u9998\u30bd", "\uda0d\udc8b\udbc8\udd2a\uda05\udfbb\ud8ca\udd56\ud9f0\udc77\ud973\udfad",
        9, 36949, -867934802, -8137624713911952930L, 40189L, true, true, (char) 11408, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.list.UnmodifiableList:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 15, 9, 12, "\ud9b7\ude6d\ud847\ude6d\ud8c3\udfd0\udb6d\ude3a\ud895\udff3\ud81b\udcbb", "\u954d\u1086\ub602\u012b\u9998\u30bd", "\uda0d\udc8b\udab3\udd60\ud8d3\udfff\udb12\udea0\udb80\ude0c\ud974\udc0d",
        34, 28478, -867934783, -8137624713911952930L, 40189L, true, true, (char) 52370, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6333952492L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 12, 14, "\udadb\ude28\ud9a3\udde1\ud877\udd15\ud98a\ude19\ud8f4\udd50\ud8cb\ude64", "\u6354\u585e\u20a6\ub577", "\ud86f\udf06\udbaf\udc7d\uda0a\udf02\udaf1\udf5d\ud8d3\udfff\ud812\udf22\udbd6\udf57\uda18\udf45\udb87\udc5c",
        24, 91462, -675916528, -1212240815104667177L, -68746L, true, false, (char) 46698, (char) 5272,
        Double.longBitsToDouble(0x3fdee5a2a54a4af0L), Double.longBitsToDouble(0x3fe11e66a6c6504aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 10, 12, 14, "\udbb6\udccd\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\udaca\udc52\udb33\udd02\ud9a1\udcbf\udb66\uddad\ud8fd\udd12\ud86f\udf06\udbaf\udc7d\uda0d\udc8b", "\ub545\u3e99\u40da\uc74b\u0e41\u785d\uc396\ubfe5\u29c1\u21a3\u3732\u5a0c\u1480\ua13a\u366c\u388d\u183f\u566a\u92e8\u1134\u76fc\u8338\u2b96\ube18\ud4c3\u4fa7\u6cdf\u6f89\u9246\u4824\u8b97\uabb4", "\ud935\ude8f\ud933\udf66\udafc\udfc8\ud98b\udfe4\ud9ed\udced",
        12, 86184, 249307540, -4592512265675692274L, -77228L, true, true, (char) 34971, (char) 16576,
        Double.longBitsToDouble(0x3fe24eb6f81ccfa5L), Double.longBitsToDouble(0x3fe83ec376bee5c7L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 5, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf0e\ud886\ude18\ud81b\udcbb", "\u7b99\ub2c3\u9463\u6124\u464b\u9711", "\ud8f4\udd34\udab3\udd60\ud8d3\udfff\uda6a\udf64\udb88\udc97\ud974\udc0d",
        9, 36949, -867934802, -8137624713911952930L, 40189L, true, true, (char) 52370, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.util.NoSuchElementException\012",
        Z.run(T, 1, 11, 6, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud89f\ude9e", "\u3eeb\u1086\ub602\u0f73\u9998\u30bd", "\uda0d\udc8b\udab3\udd60\ud8d2\udf9d\uda6a\udf64\ud93e\udf23\ud832\ude8c",
        44, 36949, -867934802, -8137624713911952930L, 40189L, true, true, (char) 47060, (char) 53403,
        Double.longBitsToDouble(0x3fe5b8df4218a910L), Double.longBitsToDouble(0x3faaceb9a4bfc950L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 10, 10, 0, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u954d\u1086", "\000\udb6e\udc96\ud86f\udf06\u00f2\000\udab3\udce0",
        5, 30495, 2000478535, -972451132653188854L, -8318L, false, false, (char) 40407, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fdb9e6339dd2492L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 0, 0, 14, "\udbb6\udc9f", "\u0694\u8f48\000", "\udaef\udd6b\u0c50\udb05\udfa2\000\uda74\ude79\udb71\udd0c",
        -1, 56618, 43002, 2233785416849701406L, -42329L, true, false, (char) 62091, (char) 30684,
        Double.longBitsToDouble(0x3fdaea42d0e19800L), Double.longBitsToDouble(0x3e917c4000000000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$EntrySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 6, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud868\udd18\ud8dd\udd5d", "\u922f\u765e\uc7c2\u0f73\u9998", "\udbaf\udc7d\uda0d\udc8b\udab3\udd60\ud8d3\udfff\uda6a\udf64\udb88\udc4d\ud974\udc0d\uda8b\udef6\udad3\uddab",
        53, 70600, 198613470, -4506805931145831325L, 67153L, false, true, (char) 38124, (char) 63556,
        Double.longBitsToDouble(0x3fd2130f544799c6L), Double.longBitsToDouble(0x3fde3b2cc4f4ca28L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 0, 0, 2, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0", "\u58c8\u2c15\u5401", "\udb33\udcf7\ud9a1\udcbf\udb66\uddad\ud8fd\udd12\ud86f\udf06\udbaf\udc7d\uda0d\udc8b\udab3\udd60",
        5, 30495, 3989831, -972451132653188854L, 70240L, false, false, (char) 0, (char) 28212,
        Double.longBitsToDouble(0x3fce27f44c51f738L), Double.longBitsToDouble(0x3fdb9e6331dd2400L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.UnmodifiableList:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 9, 5, 14, "\uda97\ude20\udb82\udf44\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u954d\u1086\ub602\u0f73\u927c\u663d", "\uda0d\udc8b\udbef\udd31\ucac8\uda6a\udfc4\udb88\udc4d\ud974\udc0d",
        9, 68573, 1221381558, 447945361995819891L, 40189L, true, true, (char) 52370, (char) 40583,
        Double.longBitsToDouble(0x3fdd87fd59dd2492L), Double.longBitsToDouble(0x3fd2130f5ec599c6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=java.lang.Integer:-1 |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 10, 8, 14, "\uda67\udde6\udba6\uddf4\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u954d\u1086\ub602\u0f73\u9998\u30bd", "\uda0d\udc8b\udab3\udd60\ud8d3\udfff\uda6a\udf64\udb88\udc4d\ud974\udc0d",
        9, 36949, -867934802, -8137624713911952930L, 40156L, true, true, (char) 52370, (char) 31312,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fd2130f54479926L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 8, 1, 14, "\udbb6\udccd\ud847\ude6d\ud83c\udc09\uda34\uddb5\ud886\udea0\ud81b\udcbb", "\ud2e1\u0d1e\u29f9\u0f73\ud795\u1714", "\udbbf\udf38\udbaa\udf45\udbea\udcd9\ud817\ude8b\uda74\udff4\udb5c\uddb4",
        9, 37071, 642014638, -8137678160885532706L, -38303L, true, true, (char) 52370, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fd2130f5c4799c6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 6, 14, "\ud96e\udc68\ud825\udc6f\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u5583\u1086\ub602\u0f73\ub9e3\u05ed", "\uda0d\udc20\uda8a\udc16\ud8d3\udfff\uda6a\udf64\udb88\udc4d\ud87a\uddf0",
        -2, 14069, -1752976036, -1836461546657118422L, 40189L, true, true, (char) 52370, (char) 53474,
        Double.longBitsToDouble(0x3fdb959ae9dd2492L), Double.longBitsToDouble(0x3fd2130f5447993cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.UnmodifiableList:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 7, 14, "\udbb6\udccd\udbf9\udf87\ud86d\udd94\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u904a\u15e4\u08de\u0f73\u9998\u30bd", "\uda0d\udc8b\udab3\udd60\ud8d3\udfff\uda6a\udf64\ud84a\udc4e\ud974\udc0d",
        -3, 36949, -867934891, -8137624713911952930L, 40189L, true, false, (char) 16098, (char) 52181,
        Double.longBitsToDouble(0x3fdb90bf79dd24caL), Double.longBitsToDouble(0x3fe7a3e7a923cce3L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$ListOrderedMapIterator:Iterator[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 13, 11, 13, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\udb36\udd7f\ud92b\udee8\ud8b8\ude53", "\u954d\u1086\ub602\u0f73\u9998\u30bd", "\uda0d\udc8b\uda38\udd62\uda44\ude33\uda6a\udee1\udb88\udc4d\ud974\udc0d\uda8b\udef6\udad3\uddab\ud9fe\udea1\ud9b3\ude84\uda4c\ude90\ud988\udc32\ud9db\udfd4\u3787",
        42, 40988, -1840684615, -7417474732269198055L, 49003L, false, false, (char) 41565, (char) 42023,
        Double.longBitsToDouble(0x3fdd1257e1c44504L), Double.longBitsToDouble(0x3fe74fbb5cd9cc41L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 12, 12, 6, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\udad5\udc20\ud9e4\udf93", "\u954d\uc745\u4017\u6719\u7be1\u30bd\u4f11", "\udab3\udd60\ud8cd\udfd7\uda6a\udf64\udbbb\udfa7\ud949\udf5e\uda5b\udcb5\udad3\ude03\ud9fe\udea1\ud973\uddce",
        50, 66474, 970513507, 2633035020093000945L, 71591L, false, false, (char) 30157, (char) 9991,
        Double.longBitsToDouble(0x3fdb72464cd2a694L), Double.longBitsToDouble(0x3fdd2b32bc494bd4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 14, "\udbb6\udccd", "\u06e0\ubfdb\u58c8", "\ud9d6\udfeb\ud801\udcc1\udb33\udcf7\ud9a1\udcbf\udb66\uddad",
        52, 80971, -372547854, -4195763304798567552L, -53017L, true, true, (char) 40981, (char) 48011,
        Double.longBitsToDouble(0x3fe8aee63daea42dL), Double.longBitsToDouble(0x3fd70cc44220d822L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 14, 14, 14, "\udba6\udda4\ud847\ude32\ud8c3\udfd0\uda91\udc0c\ud886\ude18\ud81b\udcbb", "\u954d\ua414\ub657\u0f73\u9998\uc4e8", "\uda0d\udc8b\udab3\udd60\uda69\udf4b\uda6a\udee3\udb88\udc4d\ud974\udc0d",
        9, 36949, -2143003218, -8118426957423142434L, 40189L, true, true, (char) 52370, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.UnmodifiableList:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.list.UnmodifiableList:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 9, 9, 12, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud9cd\udd18\ud886\ude18\ud914\uded8", "\u9d77\u1043\ub602\u0f73\u9998\u5c2b", "\uda0c\udff0\ud88a\udd0c\ud95b\udf91\uda6a\udf64\udb88\udc4d\ud974\udc0d\uda8b\udef6\udad3\uddab",
        53, 70600, 198613470, 6710928663453792376L, 67153L, false, true, (char) 18413, (char) 41459,
        Double.longBitsToDouble(0x3fd21d56d44799c6L), Double.longBitsToDouble(0x3fed2109565e4719L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.UnmodifiableList:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.list.UnmodifiableList:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 2, 2, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud801\udd8a", "\u94c6\u1086\ub602\u0f73\u9998\uc42d", "\uda0d\udc8b\udab3\udd60\udbe8\uddfd\ud973\udfaf\udb6f\udcb0\ud974\udc0d",
        10, 36949, -867910568, -8137624713911952930L, -69552L, true, true, (char) 5402, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fd2130f544799c6L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 15, 15, 15, "\udbb6\udccd\ud847\ude6d\udbbd\udfcd\ud969\udf19\ud886\ude18\ud81b\udcbb", "\u954d\u1086\uc7dc\u0f73\u9998\u30bd", "\uda0c\udfed\udab3\udd60\udb62\ude47\uda6c\udf98\udbec\udd69\ud973\udf60",
        9, 36949, -867934802, -8137625010264696354L, 40189L, true, false, (char) 20315, (char) 29521,
        Double.longBitsToDouble(0x3fc77d7936c79350L), Double.longBitsToDouble(0x3fd21418c44799c6L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$ListOrderedMapIterator:Iterator[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap$ListOrderedMapIterator:Iterator[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 13, 13, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "Y\ud3fd\u9e4e\u0f73\u4fd1\u2447\000", "\udab3\udd60",
        53, -1000, 2000420864, -972451132049209078L, -8318L, false, true, (char) 40407, (char) 28212,
        Double.longBitsToDouble(0x3fb6bc5e1df4a0e0L), Double.longBitsToDouble(0x3fde80391b18054aL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 1, 1, 9, "\ud8a0\udd8f", "\u2f10\u8267", "\ud81e\uddd8\ud8c1\udf6f\udb9f\udefe\udb60\udfcd\udb1c\udce6\u07cb",
        49, 3203, -237268861, -3756283563669142656L, -75033L, false, false, (char) 41151, (char) 48011,
        Double.longBitsToDouble(0x3fe9937e3800a42dL), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 3, 3, 1, "\uda42\udc13\ud847\ude59\ud8c3\udfd0\ud8fc\ude02\ud8fd\udf52\udada\udfbc", "\ua5f7\u88ec\u4970\u62a3\u3eee\u0948\ub62a", "\udb8f\udf8e\uda38\ude3e\ud932\udeb0\udb21\uddfd\ud87f\udf59\udbb6\udc3a\uc77a",
        26, 70671, 2042403294, -6606401471184511901L, 32287L, true, true, (char) 34350, (char) 8444,
        Double.longBitsToDouble(0x3fecbb7fa8212162L), Double.longBitsToDouble(0x3fe85b2d78b8ca16L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 1, 12, 6, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud9c7\udf28\ud886\udeb5\ud8b6\ude42", "\u8cfa\u7bad\u87cb\ud1b0\u569c\u30bd", "\uda0d\udc8b",
        56, 89051, -2031253129, 6458935530767004850L, 56907L, true, false, (char) 9809, (char) 10479,
        Double.longBitsToDouble(0x3fef105eb463c174L), Double.longBitsToDouble(0x3fee39d36cee3fa2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$EntrySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap$EntrySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 4, 4, 10, "\uda10\udf89\ud847\ude6d\ud8c3\udfd0\udb6d\ude3a\ud8ea\udd5d\ud9e9\udf4e", "\ud3e7\u31de\u9334\u0cdd\u9998\ub4a2\u4f5b\u6d9a\uc2f6\u53f7", "\udb9c\udc34\udbd9\udfff\ud84f\udc8f",
        23, 47489, -1894698587, 853037429432818658L, 44327L, true, false, (char) 53474, (char) 4077,
        Double.longBitsToDouble(0x3fecd16b823e0ac3L), Double.longBitsToDouble(0x3fe5867f606784cbL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 6, 14, "\udbb6\udccd\ud847\ude6d\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb", "\ub089\u6dc1\uabda\u19f7\uc633\u4006", "\ud9f0\udebc\udab3\udd60\ud8d3\udfff\uda6a\udf64\udb88\udc4d\uda03\udd55",
        58, 36949, -867934802, -8137624713911952930L, 40189L, true, true, (char) 52370, (char) 53474,
        Double.longBitsToDouble(0x3fdb9e6339dd2492L), Double.longBitsToDouble(0x3fc0661eab4bfe60L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\012",
        Z.run(T, 2, 10, 12, 14, "\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\ub545\u3e99\u40da\uc74b\u0e41\u785d\uc396\ubfe5\u29c1\u21a3\u3732\000\000\ua13a\u366c\u388d\u183f\u566a\u1ae5\u1134\u76fc\u8338\u2b96\u3b22\000\u8070\000\000\u9246\u4824\u25ab\u3e85", "\ud935\ude8f",
        -5, -1000, -46268416, 2424012961321453485L, -91404L, true, false, (char) 26450, (char) 40233,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fe0bbf420671000L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\udaaa\ude06\ud969\udf19\ud87c\udf73\uda54\ude3e\uda3e\udc56\ud94b\ude75\udaef\udd6b\u0c50\udb33\udd02\udaba\uddb7=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\012",
        Z.run(T, 2, 14, 12, 14, "\ud820\udcc2\ud847\udeec\udaaa\ude06\ud969\udf19\ud87c\udf73\uda54\ude3e\uda3e\udc56\ud94b\ude75\udaef\udd6b\u0c50\udb33\udd02\udaba\uddb7,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\ub545\u3e99\u40da\uc74b\u0e41\u785d\uc396\ubfe5\u29c1\u21a3\u3732\000\000\ua13a\u366c\u388d\u183f\u1993\u1ae5\u1134\u76fc\u82d8\u2b96\u3b22\000\u8070\000\u1ed0\u9209\u4824\u25ab\u3e85", "\ud935\ude8f",
        -5, 85848, -40090759, 2424012961321453485L, -91404L, true, false, (char) 60241, (char) 40233,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fe0bbf420671000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 12, 6, "\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud886\ude18\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\ub545\u3e99\u3f60\u3aa7\u0e41\u785d\uc396\ubfe5\u29c1\u21a3\u3732\000\000\ua150\u366c\u742a\uacf3\u566a\u1ae5\u1134\u76fc\u8338\u2b96\u3b22\000\u8070\000\000\u9246\ubdef\u1bb2\u3e85", "\ud935\ude8f",
        11, 79904, 1726580851, 2424012962869712618L, -91404L, true, false, (char) 11370, (char) 40173,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fe0b86420671000L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\0121=void |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 1, 3, 12, "\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\ub545\u4498\u7ada\uc74b\u0e41\u785d\ubce3\ubfe5\u29c1\u21a3\u3732\000\000\ua13a\u366c\u388d\u183f\u566a\u7169\uabaa\u896f\u2c8c\u39ce\u0101\000\u8070\000\000\u9246\u84d6\u2593\u3e85", "\ud935\ude8f",
        -5, -1000, -46268416, 2424012961321453485L, -91404L, true, false, (char) 26450, (char) 40233,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fe0bbf420671000L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud8c2\udeea\ud887\udcc2\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\0121=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud8c2\udeea\ud887\udcc2\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\012",
        Z.run(T, 2, 12, 12, 14, "\ud820\udcc2\ud8c2\udeea\ud887\udcc2\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\ub545\u3e99\u40da\uc74b\u0e41\u785d\uc396\ubfe5\u29c1\u21a3\u3732\000\000\ua13a\u366c\u9521\000\u0694\u1ae5\u1134\u76fc\u00da\u2b96\u3b22\000\u8070\000\000\u9246\u4824\u25ab\u3e85", "\ud935\ude8f",
        -5, -1000, -46268416, 2424012961321451693L, -91404L, true, false, (char) 26450, (char) 40233,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3f3fa10338800000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$ListOrderedMapIterator:Iterator[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 0, 14, "\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud91f\udcbd\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\ub545\u3e99\u40da\uc74b\u0e41\u785d\uc396\ubfe5\u29c1\u21a3\u3732\000\000\ua13a\u366c\u388d\u183f\u566a\u1ae5\u1134\u76fc\uc42d\u2b96\u3b22\000\u37d9\000\000\u9246\u4824\u25ab\u3e85", "\ud935\ude8f",
        53, -1000, -46268416, 2424012961321453485L, -91404L, true, false, (char) 26450, (char) 40135,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fe7cafc20675741L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\udb73\udee2\udaf4\uddc5\ud969\udf19\ud886\ude18\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\ud92a\udcda\uda0d\udc15}\0121=java.lang.String:\ud820\udcc2\udb73\udee2\udaf4\uddc5\ud969\udf19\ud886\ude18\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\udb73\udee2\udaf4\uddc5\ud969\udf19\ud886\ude18\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\ud92a\udcda\uda0d\udc15}\012",
        Z.run(T, 2, 1, 11, 4, "\ud820\udcc2\udb73\udee2\udaf4\uddc5\ud969\udf19\ud886\ude18\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\ud92a\udcda\uda0d\udc15", "\ub545\u3e99\u3f60\u3aa7\u0e41\u785d\uc396\ubfe5\u29c1\ubcd6\u7edd\000\000\ua150\u514d\u84ec\uacf3\u566a\u1ae5\u1134\u76fc\u8338\u2b96\u995e\ub2e7\u810b\000\000\u9246\ubdef\u1bb2\u3e85", "\ud935\ude8f",
        11, 79904, 1726580851, 2424012962869712618L, -91404L, true, false, (char) 11370, (char) 40173,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fe0b86420671000L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud886\ude18\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\0121=org.apache.commons.collections4.map.ListOrderedMap$ListOrderedMapIterator:Iterator[] |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud886\ude18\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\012",
        Z.run(T, 2, 0, 13, 11, "\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud886\ude18\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\u415b\uae8c\u3f19\uac58\u0c2f\u785d\uc396\ubfe5\u29c1\u21a3\u3732\000\000\ua150\u366c\u742a\uacf3\u566a\u1ae5\u1134\u76fc\u8338\u2b96\u3b22\000\u2fd8X\000\u9246\ubdef\u1bb2\u3e85", "\ud935\ude8f\udb8b\udcd1\udab9\udfda\uda45\ude83\ud9ed\udced\ud815\udc80\udb1d\uddad\ud8ab\udd5c",
        0, 25237, -1037603997, 2836044060551282875L, -87609L, true, true, (char) 61073, (char) 1485,
        Double.longBitsToDouble(0x3fe8c97cef877f6bL), Double.longBitsToDouble(0x3fee17334607f21bL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud99c\udeef\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\udb45\ude33\udb11\udfe3\u0c50\udb33\udd02\ud983\udebf=\ud846\udea3\ud8ca\udee3\udbaf\udc3e\udb71\udf7d}\0121=java.lang.String:\ud99c\udeef\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\udb45\ude33\udb11\udfe3\u0c50\udb33\udd02\ud983\udebf |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud99c\udeef\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\udb45\ude33\udb11\udfe3\u0c50\udb33\udd02\ud983\udebf=\ud846\udea3\ud8ca\udee3\udbaf\udc3e\udb71\udf7d}\012",
        Z.run(T, 2, 1, 5, 6, "\ud99c\udeef\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\udb45\ude33\udb11\udfe3\u0c50\udb33\udd02\ud983\udebf,\ud846\udea3\ud8ca\udee3\udbaf\udc3e\udb71\udf7d", "\ub5a1\u4498\u7ada\uc74b\u0e9c\u8157\ubce3\ubfe5", "\u3787\000\uda61\udd36\ud920\udfbf\uda7f\udf47",
        32, 19952, -359837738, 3242816115780149310L, -99954L, true, false, (char) 54818, (char) 199,
        Double.longBitsToDouble(0x3e2a05d5f0000000L), Double.longBitsToDouble(0x3fbf6fbba6000000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\udade\udc3b\udaef\uddcc\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\0121=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\udade\udc3b\udaef\uddcc\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\012",
        Z.run(T, 2, 1, 1, 8, "\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcbb\uda3e\udc56\udade\udc3b\udaef\uddcc\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\ub545\u4498\u7ada\uc74b\u0e41\u785d\ubce3\ubfe5\u29c1\u21a3\u3732\000\000\ua13a\u366c\u388d\u183f\u566a\u7169\uabaa\u896f\u2c8c\u39ce\u0101\000\u8070\000\000\u9246\u84d6\u2593\u3e85", "\ud935\ude8f",
        -5, -1000, -43425237, -2323913637392932861L, -91404L, true, false, (char) 26450, (char) 40233,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fe0bbf420671000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud862\uded0\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud95c\udc0a\ud94d\udd86\u00fa}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 2, "\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud862\uded0\ud81b\udcbb\uda3e\udc56\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud95c\udc0a\ud94d\udd86\u00fa", "\ub545\u4498\u2f68\uc74b\u0e41\u785d\ubce3\ubfe5\u29c1\u21a3\u3732\000\000\ua13a\u366c\u388d\u5a23\u566a\u7169\uabaa\u896f.\u4211\u0101\000\000\000\000\u9246\u84d6\u2593\u3e85", "\ud935\ude8f",
        -5, -1000, -46268416, 2424012961321453485L, -100000L, true, false, (char) 26450, (char) 12742,
        Double.longBitsToDouble(0x3fe8661000000000L), Double.longBitsToDouble(0x3fe0bbf420671000L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcfa\uda3e\udc56\udb93\udf19\ud9e6\uddab\udb78\uddd2\udb39\udc02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\0121=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcfa\uda3e\udc56\udb93\udf19\ud9e6\uddab\udb78\uddd2\udb39\udc02\ud983\udebf] |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcfa\uda3e\udc56\udb93\udf19\ud9e6\uddab\udb78\uddd2\udb39\udc02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\012",
        Z.run(T, 2, 1, 10, 12, "\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud81b\udcfa\uda3e\udc56\udb93\udf19\ud9e6\uddab\udb78\uddd2\udb39\udc02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\ub545\u4498\u7ada\ub4fc\u62f8\u6ba0\ubc38\ubfe5\u29c1\u330d\u369e\000\000\ua13a\u366c\u388d\u183f\u566a\u7169\uabaa\u896f\u2c8c\u39ce\u0101\000\u8070\000\000\u9246\u84d6\u2593\u3e85", "\ud935\ude8f",
        -5, -1000, -46268416, 2424012961321453485L, -91404L, true, false, (char) 26450, (char) 40233,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fd617e840cfe968L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud91f\udcbd\udab3\udfb0\ud855\udf10\u62b8\ud996\ude39\ud934\udf0b\ud90a\udd4b=\000\ud97c\udc69\udbaf\udc26\uda0d\udc8b}\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 14, "\ud820\udcc2\ud847\udeec\ud8c3\udfd0\ud969\udf19\ud886\ude18\ud91f\udcbd\udab3\udfb0\ud855\udf10\u62b8\ud996\ude39\ud934\udf0b\ud90a\udd4b,\000\ud97c\udc69\udbaf\udc26\uda0d\udc8b", "\ub545\u3e99\u40da\uc74b\u0e41\u785d\uc396\ubfe5\u29c1\u21a3\u3732\u2c0c\u6b13\ua13a\u366c\u388d\u183f\u566a\u1ae5\u1134\u76fc\uc42d\u2b96\u3b22\000\u37d9\000\000\u9246\u4824\uc74b\u3ea6", "\ud935\ude8f",
        53, -1000, -46268416, 2424012961321453485L, -91404L, true, false, (char) 26450, (char) 40135,
        Double.longBitsToDouble(0x3fe8661138000000L), Double.longBitsToDouble(0x3fe7cafc20675741L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud963\udc46\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\0121=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud963\udc46\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\012",
        Z.run(T, 2, 0, 16, 11, "\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud963\udc46\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\u415b\uae8c\u3f19\uac58\u0c2f\u785d\uc396\u946e\u6543\u2230\u3732\000\000\ua150\u366c\u284f\uacf3\u566a\u1ae5\u1134\u76fc\u8338\u95ac\uc60a\000\u2fd8X\000\u9246\ubdef\u1bb2\u3e85", "\ud935\ude8f\udb8b\udcd1\udab9\udfda\uda45\ude83\ud9ed\udced\ud815\udc80\udb1d\uddad\ud8ab\udd5c",
        0, 25237, -1037603997, 2836044060551282875L, -87609L, true, true, (char) 61073, (char) 1485,
        Double.longBitsToDouble(0x3fe8c97cef877f6bL), Double.longBitsToDouble(0x3fee17334607f21bL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud963\udc46\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\0121=java.lang.String:\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b |this=org.apache.commons.collections4.map.ListOrderedMap:{\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud963\udc46\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf=\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b}\012",
        Z.run(T, 2, 0, 7, 6, "\ud820\udcc2\udb73\udee2\ud8c3\udfd0\ud969\udf19\ud963\udc46\udb22\udc9e\uda3e\udc3f\u9683\udaef\udd6b\u0c50\udb33\udd02\ud983\udebf,\000\ud86f\udeb3\udbaf\udc7d\uda0d\udc8b", "\u415b\uae8c\u3f19\uac58\u0c2f\u785d\uc396\u946e\u6543\u2230\u3732\000\000\ua150\u366c\u284f\uacf3\u566a\u1ae5\u1134\u76fc\u8338\u95ac\uc60a\000\u2fd8X\u9e6b\u0683\ubdef\u1bb2\u3e85", "\ud935\ude8f\udb8b\udcd1\udab9\udfda\uda45\ude83\ud9ed\udced\ud815\udc80\udb1d\uddad\ud8ab\udd5c",
        0, 25237, -1037603997, 2836044060551282875L, -87609L, true, true, (char) 61073, (char) 1485,
        Double.longBitsToDouble(0x3fe8c97cef877f6bL), Double.longBitsToDouble(0x3fe46f334607f21bL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\0121=org.apache.commons.collections4.map.ListOrderedMap$KeySetView:[] |this=org.apache.commons.collections4.map.ListOrderedMap:{}\012",
        Z.run(T, 2, 10, 10, 14, "\udbb6\udccd\ud847\ude9a\ud8c3\udfd0\ud969\udf19", "\u2c15\u5401\u954d\u4544\u46ee\u0f73\u14d9\u30c5\u4f11\u6d9a\uc2f6\u6143\ub05e\ub545\u3f32\u40da\uc74b\u0e41\u785d\uc396\ubfe5\u29c1\u21a3\u0099\u947d\u626b", "\udb9e\ude1d",
        30, 95938, -1895868484, 5856036308997200071L, 2440L, false, true, (char) 21392, (char) 51420,
        Double.longBitsToDouble(0x3fe10355b4bb3d01L), Double.longBitsToDouble(0x3fd0071ad1dbcb50L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections4.map.ListOrderedMap|putAll|int,java.util.Map|new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|putAll|java.util.Map|new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|asList||new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|clear||new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|entrySet||new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|firstKey||new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|get|int|new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|getValue|int|new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|indexOf|java.lang.Object|new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|keyList||new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|keySet||new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|lastKey||new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|listOrderedMap|java.util.Map|static",
    "M|org.apache.commons.collections4.map.ListOrderedMap|mapIterator||new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|nextKey|java.lang.Object|new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|previousKey|java.lang.Object|new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|putAll|int,java.util.Map|new:org.apache.commons.collections4.map.ListOrderedMap:",
    "M|org.apache.commons.collections4.map.ListOrderedMap|putAll|java.util.Map|new:org.apache.commons.collections4.map.ListOrderedMap:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
