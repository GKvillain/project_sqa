package org.apache.commons.collections4;
import org.junit.Test;
import static org.junit.Assert.*;
public class IteratorUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 0, 14, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud81a\udee7\u12c8\ud851\udf05\ud8d2\udd30]]\012",
        Z.run(T, 2, 2, 8, 12, "\ud81a\udee7\u12c8\ud851\udf05\ud8d2\udd30", "\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u25ef\u595e\u5d90\u2e32\uc02b\uc8e1\u1bb9\ubd0e\u3e71\ua1c4\u37c1\uad98", "\udbeb\udc41\ue1de\ud888\uddf2\ud9bf\udcd6",
        1, 41962, 2012701437, 2926048312099705148L, -46622L, true, false, (char) 36947, (char) 45719,
        Double.longBitsToDouble(0x3fe2a4ee9a9cc9b2L), Double.longBitsToDouble(0x3fb43d2c8a8361f8L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 14, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u513d\u2bf2", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de",
        0, 41945, 26603986, 6154387326261224189L, 59428L, false, false, (char) 27495, (char) 12259,
        Double.longBitsToDouble(0x3fe8bea9e682fc15L), Double.longBitsToDouble(0x3fe2a4ee9a9cc9b2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 14, "\ud8ce\udee1", "\u9f38\u0556\u5154\u92ef\u4962\u334d\ubed6\ua7ad\u63e7\u3fa6\u0a13\u36c5\u7b7d\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\uda34\ude5b\ud8be\udda2\udb55\udeba\ue1eb\ud888\uddf2",
        55, 74026, 1432944226, 8644486848369617264L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 0, 14, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud888\uddf2\ud9bf\udcd6\udbac\udde9\udb45\udfb5\udb7e\ude0e\ud8c8\udf67\ud82d\udf40\ud8ab\udee3\ud9c2\udf0e\udb47\ude00\udbb8\udedb\udb9a\udcb8\udaf0\udf20\ud9cc\uddf1\uda89\udf47\ud857\udfe8\udbfc\udeb8\ud810\udf2e\ud8a1\udf0c",
        3, 70467, 694146102, -5429654112088426340L, -62503L, true, false, (char) 30356, (char) 52182,
        Double.longBitsToDouble(0x3fe06d0f55fe0da7L), Double.longBitsToDouble(0x3fe80c921d0d6d18L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 11, 14, "\udab4\udf52", "\u9f38\u0556\u6b59\u8c0e\u740f\u0491\uc7d1\ua7ad\u63e7\u804a\u07bf\ua705\u0cc5\u8f78\u93e0\ucada\u119e\u2d37\u8b88\u37c1\u86a8\u672e\u29bb\u64cf\ub99e\u5eab\u7b1b\u1bb3\u3be4\u492c\u9014\u5155", "\udb47\uddb9",
        57, 37434, -911057324, -6939340467592703968L, -2234L, true, false, (char) 3466, (char) 783,
        Double.longBitsToDouble(0x3fdc83de90810ceeL), Double.longBitsToDouble(0x3faef4d147b50cb0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 11, 14, "\ud8ce\udee1", "\u9f38\ua17b\u511d\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\u815b\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae5484aaL), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 10, 14, "\ud8ce\udee1", "\u9f38\u0556\ub424\u5ca9\u7357\u0491\uc7d1\ua7ad\u63e7\u3fa6\u54b4\u521a\u982a\ud237\ud1a1\u1b85\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:[[]]\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 0, 14, "\ud8ce\udee1", "\u6338\u0556\u5154\u83d2\uc7a9\u891a\uc799\ua7ad\u63e7\uc16c\u97d8\u319f\u7bbb\u726e\u7aae\u04a9\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud855\udd58",
        16, 39986, 1432929962, 8644486846809336176L, -9720L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 12, "\uae71", "\u9f38", "\udbcf\udc32\ud849\udce8|\ud94e\ude07\udace\udf34\ud94e\udfcb\uf2d9\ud8c3\udfd6\ud86b\udde0\ud9a7\uddbb\udb5e\udf6c\udb15\udcb9\udb97\udef1\000\000\000\udb15\udf24\ud8c7\uddbf",
        35, 72698, -2121869364, 26559311775444772L, 27442L, false, false, (char) 47205, (char) 57703,
        Double.longBitsToDouble(0x3fd3c009b0b1bcaaL), Double.longBitsToDouble(0x3fbfb9d281ff3d18L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 16, 0, "\ud8ce\udee1", "\u9f38\u0556\u5154\ucc1e\u1865\u0491\uc7d1\ua7ad\u63e7\u3fa6\uc161\ua65a\u7bbb\u7246\u7aae\u5145\u5326\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud888\uddf2",
        55, 39986, -549659978, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae073644L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 16, 14, "\udace\udfe1", "\u2d2c\u0556\u5154\u4d4e\u81ab\u0491\ubf9e\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u3bbc", "\ud99b\udc73\u579f\ud802\udec7\ud8f5\udf16\ud915\ude5b\ud8be\ude46\udbcc\udc57\ud91a\udece",
        24, 41945, 26603986, 3292912712175501713L, 59428L, false, false, (char) 27592, (char) 12259,
        Double.longBitsToDouble(0x3fe8bea9e682fc15L), Double.longBitsToDouble(0x3fe2a4ee9a9cc9b2L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 0, 0, 16, "\ud8ce\udee1\udaab\udeba\udae3\uded7\udb50\udcdd\ue7c2\uda7b\udc2a\udad4\ude35\ud914\udc8c\ud8ec\udfb2\ud992\uddf9", "\u72c6\ub60f\ua6f7\uadce\ua5fe\u67e6\u2f74\u5406\u2d17\u88a3\u37c1\uad98\u7a2b\u9651\u51e6\u2052\u5e9a\u7b1b\u1bb3\u3be4", "\ud82d\udf40\ud8b5\udcbb\ud9d6\udf9f\udb47\ude58\udbb8\udedb\udb9a\udcb8\udaf0\udf20\ud9cc\uddf1\ud85a\ude50\uda1a\udd20\ud8fe\udc4c\ud91e\udd0d\ud997\udeee",
        48, 45572, 1500048453, 2406594878340967099L, -78956L, false, true, (char) 51408, (char) 37551,
        Double.longBitsToDouble(0x3fd8cea1c3587ac2L), Double.longBitsToDouble(0x3fdab99193bbe95cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@?\012",
        Z.run(T, 1, 17, 7, 14, "\ud8ce\udee1", "\u9f38\u0b56\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\ud915\ude5b\ud929\udedc\ud9b6\udc7b\udb90\ude84\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe5dfe0affded73L), Double.longBitsToDouble(0x3fb64472790f20a8L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 8, 7, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua6f2\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\udb35\udd79\ud8be\uddfb\udbcc\udc57\ue1de\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809336176L, -81186L, false, false, (char) 19534, (char) 22787,
        Double.longBitsToDouble(0x3fbd97c1dfdc7168L), Double.longBitsToDouble(0x3fdde2d2e460c6feL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 1, 3, "\uda1c\udea7\ud909\udc35\ud851\udf05", "\u5154\u4d4e\u7330\u0491\uc7d1\ubf2d\u6457\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u592a\ud0c5\uad98\u7a2b\u171e\u51e6\ub99e\u5eab\u7b1b\u1bb3\u3be4", "\ud82d\udf40\ud8ab\udee3\ud9c2\udf0e\udb47\uddb9\udbb8\udedb\udb9a\udcb8\udaf0\udf20\ud9cc\uddf1\udbb9\udcdf\ud861\udd93\udb74\udd0d\ud9a7\udfdb\ud9de\udf72\ud976\ude79\ud8d1\udd57\ud8e1\udc5b\ud9d5\udf3a\ud97e\udcc8\udb2f\uddf6\udaa0\udd42\ud806\ude29\udaf1\udf2f\ud94a\udd83\ud8c2\uddb0\udb9f\udcd6\udab0\udf5a\ud8ee\udd75\udb9d\udc5c\u65c1\uda4e\udedd\uda67\udd46\udbc0\udc85\udb00\ude09\ud89b\udea2\uda59\udd8d\ud9ef\udc25\uda55\udd44\udb40\udd97\ud927\udf25\ud88b\udc6d\ud9b6\udf38\ud965\udc3c\uda16\udd91\ud9e2\uddcb\udae6\udd86\ud943\udfac",
        55, 47357, -907878175, 2033003951761651997L, 99383L, false, true, (char) 46086, (char) 16625,
        Double.longBitsToDouble(0x3fef1a21acdfcdebL), Double.longBitsToDouble(0x3fdeb2e297b92fd2L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 9, 7, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809312880L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=org.apache.commons.collections4.iterators.ObjectArrayListIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udee1]]\012",
        Z.run(T, 2, 2, 13, 14, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\u2751\u63e7\u3fa6\u0f37\ua6bb\u7bbb\u7246\u7aae\u9c31\u8016\u2d17\u8b88", "\ud915\ude5b\udb2e\udf44\udb04\udc53\ue1de\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 15, 14, "\ud8ce\udee1\u12c8\uf362\ud99d\udd8b", "\u4d4e\u224d\u0437\u327d\ua9bd\ua9fa\ua16a\u0a13\u3314\u88cb\u73aa\u7aae\u1bae\u5406\u2d17\u8b88\u37c1\uad98", "\udbcc\udc57\ue1de\ud888\ude24\ud9bf\udcd6",
        1, 41962, 2012701437, 2495197104800892162L, -68382L, true, false, (char) 36947, (char) 40052,
        Double.longBitsToDouble(0x3fe6e3c62e7a349cL), Double.longBitsToDouble(0x3fb43d2f438101a8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 10, 3, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\uc3d2\u65c5\u3ff5\u2b8f\ua62d\u7bbb\u7246\ua79e\u246d\u128d\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud95b\udd7b",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 4, 14, "\ud8cf\udddd", "\u9f38\u0556\ubf8c\ub35d\u735c\u0491\uc7d1\ua7ad\u63e7\u26b9\u1b14\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\uafc2\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ud963\udd54\ud944\udce5",
        45, 40023, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d91b9f4b2L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 14, 14, "\ud8ce\udf56", "\u7778\u0556\u5154\u7c9c\u2ae4\u041a\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u3e80\ub59b\u1637\u2d17\u9de4", "\ud915\ude5b\ud8be\ude46\ud853\uddbf\udb15\udde6\ud888\ude8b",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 7, 14, "\ud8ce\udee1\u12c8\ud851\udf05\uda15\udd1b\ue793\uda06\udd7d\udbcf\udc32\udb93\udf4e\uda50\udf4b\udb53\udf80\ud9fa\udd01\udb8f\udf27\udbab\ude91\ud8d7\udf57\ud86b\udde3\ud9a7\uddbb\udb5e\udf6c\udb15\udcb9", "\u2d17\u5bb9\u5f1b\u31dc\ua26d\uaa61\u51e6\ub99e", "\udbac\udde9\uda04\udfb2\ud8d5\ude3b\ud8c8\udf67\udabc\udd3c\ud9da\udefb\udb1c\udf07\udb6c\ude8c\udbb8\udedb\udb9a\udcb8\udaf0\udf20\ud9cc\uddf1\uc79d\uda13\uddda\ud83d\udc38\ud9e4\ude4d\ud800\udcad\uda89\udd52\udab7\udd20\udae3\udf26\udbee\udd2c\uda77\uddb4\uda3b\ude91\ud9e0\udf36\ud80f\uddb4\ud9be\udd37\ud83b\udc9c\ud952\udde4\ud9c9\udeea\udbae\ude8d\udb4c\udcf6\ud929\udf82",
        22, 92849, -409962074, 3227650727054921047L, 12712L, false, false, (char) 52428, (char) 55050,
        Double.longBitsToDouble(0x3fb543b903f28ff8L), Double.longBitsToDouble(0x3fc259904c5847b8L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udee0]]\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 0, 14, "\ud8ce\udee0", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb", "\udbdd\udd34\ud826\ude23\ud95e\udfaf\ud9b3\udd71\udb16\udc1e\ud8c7\uddbf\ud915\ude5b\ud83b\udc8d\ud869\udf37",
        43, 79989, 450906945, 114263251246171818L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud926\uddd6]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 15, 14, "\ud926\uddd6", "\u9f38\u0556\u5154\ub88d\u73e4\u0491\uc7d1\ua7ad\u63e7\u3fa6\u6f08\ua62d\u7c3b\ub1f4\ucf05\u6094\u5b5d\ud285\u8bfa", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ud823\ude5c\udbc3\udf6b\uda87\uded9",
        1, 41962, 1408721661, -7378187635324018628L, -68382L, true, false, (char) 36947, (char) 45719,
        Double.longBitsToDouble(0x3fe2a4ee9a9cc9b2L), Double.longBitsToDouble(0x3fb43d2c8744da90L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 5, 14, "\ud8ce\udee1", "\u872b\ub026\u5154\u4d4e\u7330\u0491\uc7d1\uba87\u6422\u3fa6\u0a13\ua62d\u7bbb\u7246\u8d0c\u1bae\ub65a\u2ab6\uba46", "\ud915\ude5b\ud97d\udd26\ud948\udcf7\udad3\udee4\udace\udc96",
        55, 39986, 1432929962, 8644486846809336176L, -81186L, false, false, (char) 19534, (char) 22787,
        Double.longBitsToDouble(0x3fddb799733ab83eL), Double.longBitsToDouble(0x3fef74fce352c152L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:[[]]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 12, 15, "\ud8ce\udf2e", "\u8609\u1727\u5154\u4d4e\u7330\u0491\u3c45\uce2f\u63e7\u3fa6\u0a81\u35be\u0724\uc348\u9432\u1b77\u5406\u2d17\u2892", "\ud915\ude5b\ud96e\ude9e\ud92f\udea0\uda63\ude38\udb73\udeb5",
        36, 39986, 1432929962, 8644486846809336176L, 76040L, false, false, (char) 62542, (char) 37098,
        Double.longBitsToDouble(0x3fe26010ae549d39L), Double.longBitsToDouble(0x3fe77023ddac1fdfL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 14, 16, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a2c\ua62d\u7bbb\u7246\u7aae\u1bae\u2584\u2db2\u8b88", "\ud915\ude5b\ud8be\ude46\uda37\udc2c\u8a63\uda3e\udc2d",
        21, 44577, -449136040, 8644485846081956208L, 10504L, false, true, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 6, 14, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u9dc0\u59e7\u5a5c\u22ae\u3fbc\u5f61\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe96a8d93722319L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:[[]]\0121=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:[[]]\012",
        Z.run(T, 2, 2, 2, 6, "\ud8f9\udd81\u11fa\ud851\udf05\uda15\udd1b\ue793\ud8f9\udd49\uda79\udd7f\ud842\ude69", "\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7b89", "\ud90f\udd2d\ud826\ude23\ud8b0\udc57\uda3b\ude08\udb16\udc1e\ud8c7\uddbf\ud926\udc63\ud939\udc42\ud85a\udf28",
        52, 460, 450906945, -6119876418774461481L, 10405L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fd82fc15ca9507eL), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\012",
        Z.run(T, 2, 2, 2, 6, "\ud8ce\udee1", "\u8bfe\u056e\u0ce3\u4dad\u7330\ucea3\u1186\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud888\uddf2",
        59, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fb2948545c3d418L), Double.longBitsToDouble(0x3fe5458fc5fdf4b2L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 17, 0, 12, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u6e1b\u6982\u1713\u63e7\ucbf5\u518b\u602c\u8a7b\u7246\ubeb8\u1bae\u3757\uce19\u1186", "\ud915\ude5b",
        3, 38636, -480355442, -6351571754708754111L, 493L, true, false, (char) 12274, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 8, 12, "\ud81a\udee7\ud968\udfb9\uda92\udda9\ud8d5\udcfe", "\u4d4e\u5753\u0491\uc7d1\ua7ad\u63e7\u25ef\u595e\u98de\u2e32\uc02b\uc8e1\u1bb9\ubd0e\u3e71\ua1c4", "\ud915\ude5b\u4c6d\udbeb\udc41\ue1de\udab1\udccc\ud9bf\udca1\udbac\udde9\uda04\udfb2\udb7e\ude0e",
        -3, 74396, -1527540955, 5966820407921489451L, -2364L, false, false, (char) 54671, (char) 40987,
        Double.longBitsToDouble(0x3febb27fa4cfacc7L), Double.longBitsToDouble(0x3fc735ed520ed710L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud81a\udf35]]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 8, 0, "\ud81a\udf35", "\u6b83\u86af\u5154\u4d4e\u7330\u6fca\u1a06\ua7ad\u63e7\u25ef\u595e\u5d90\u2e32\uc02b\uc8e1\u1bb9\ubd0e\u3e71\u5157", "\ud915\ude41\ud889\udd67\udb63\udc27\ud801\udc59\ud888\uddf2",
        55, 17274, 1426359940, 8644486088344955248L, -24853L, false, false, (char) 49980, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549d9bL), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 3, 6, "\ud81a\udee7\u12c8\ud851\udf05\ud8d2\udd30", "\u2e5b\u8b50\ucf92\uc7d1\u5ab1\uba1b\u76c0\u58ac\u4335\ua522\u855c\uc8e1\u1bb9\ubd0e\u1755\u8b27\u37c1\uad98", "\udaee\udc03\udb6d\udcc2\uda72\udfbe\ud98e\udf51",
        58, 27410, -495176849, 8679255265764397793L, -3749L, false, true, (char) 32158, (char) 30284,
        Double.longBitsToDouble(0x3fe16ea74b791c46L), Double.longBitsToDouble(0x3fe8560280101e0fL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\uda2b\udd2f\udbe3\udf91\ud850\ude05\ud8d2\udd30]]\0121=org.apache.commons.collections4.iterators.CollatingIterator:@?\012",
        Z.run(T, 2, 8, 1, 17, "\uda2b\udd2f\udbe3\udf91\ud850\ude05\ud8d2\udd30", "\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u706a\u1bb4\u6ced\u1674\u2509\u41ce\u1bb9\ubd0e\ua55a\ua1c4\u37c1\uad98", "\udbeb\udc41\ue1de\ud951\uded6\ud9bf\udcd6",
        1, 49597, -146667925, -5775588445009922075L, -46622L, true, false, (char) 36947, (char) 45719,
        Double.longBitsToDouble(0x3fe2a4ee9a9cc9b2L), Double.longBitsToDouble(0x3fb43d2c8a8361f8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayListIterator:@? |a0=[Ljava.lang.Object;:[[\ud81a\udee7\u12c8\ud851\udf05\ud8d2\udd30]]\0121=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud81a\udee7\u12c8\ud851\udf05\ud8d2\udd30]]\012",
        Z.run(T, 2, 14, 8, 17, "\ud81a\udee7\u12c8\ud851\udf05\ud8d2\udd30", "\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u25ef\u595e\u5d90\u2e32\uc02b\uc8e1\u1bb9\u0c78\u680f\u2faf\u37c1\uad98", "\udbeb\udc41\ue1de\ud888\uddf2\ud9bf\udcd6",
        1, 41962, 2012701437, 2926048312099705148L, -46622L, true, false, (char) 36947, (char) 45719,
        Double.longBitsToDouble(0x3fe2a4ee9a9cc9b2L), Double.longBitsToDouble(0x3fb43d2c8a8361f8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud81a\udee7\ud969\ude4a\ud851\udeee\ud8d2\udd30]]\0121=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud81a\udee7\ud969\ude4a\ud851\udeee\ud8d2\udd30]]\012",
        Z.run(T, 2, 8, 8, 12, "\ud81a\udee7\ud969\ude4a\ud851\udeee\ud8d2\udd30", "\u4d4e\u7330\u3b79\ucd2e\u311b\u63e7\u25ef\ucd37\u5513\u0d64\ubad1\u9f69\u19c7\ubd0e\u610a\uc4cc\u0fd5\uad98", "\udbeb\udc41\ue1de\ud888\uddf2\ud9bf\udcd6",
        1, 87330, 115369592, 2926211044115583292L, -46622L, true, false, (char) 36947, (char) 45719,
        Double.longBitsToDouble(0x3fd549dd3529b024L), Double.longBitsToDouble(0x3fb43d2c8a8361f8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 0, 14, "\000", "\u499a\u0522\u5154\u4d4e\u7330\u0491\uc7d1\ua7ad\u63e7\u3fa6\u0a13\003\u314a\u7246\u7aae\u00ee\000\000\ubda0", "\ud915\ude5b",
        3, 38432, -480355442, -6351571754848072895L, -99830L, true, false, (char) 57703, (char) 10967,
        Double.longBitsToDouble(0x3fb6379540e99a50L), Double.longBitsToDouble(0x3faff3d1b17003c0L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayListIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udee1]]\0121=org.apache.commons.collections4.iterators.ObjectArrayListIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udee1]]\012",
        Z.run(T, 2, 14, 14, 2, "\ud8ce\udee1", "\u9f38\u0556\u5154\u4d4e\u7330\u0491\u3999\u033a\uc767\u204d\u0a13\ua62d\u7bbb\u7246\u7aae\u69e6\uad8a\u513d\u2bf2", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de",
        0, 41945, 26603986, 6154387326261224189L, 59428L, false, false, (char) 54146, (char) 12259,
        Double.longBitsToDouble(0x3fe8bea9e682fc15L), Double.longBitsToDouble(0x3fe2a4ee9a9cc9b2L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayListIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udeac\u12c8\ud851\udf05\uda15\udd1b\ue793\uda7b\udc2a\ud8cb\ude70\uda8d\udfa3\udaed\udc6e\uda6c\udddc\udbbe\udeb8\ud94f\udc4a]]\0121=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udeac\u12c8\ud851\udf05\uda15\udd1b\ue793\uda7b\udc2a\ud8cb\ude70\uda8d\udfa3\udaed\udc6e\uda6c\udddc\udbbe\udeb8\ud94f\udc4a]]\012",
        Z.run(T, 2, 13, 7, 14, "\ud8ce\udeac\u12c8\ud851\udf05\uda15\udd1b\ue793\uda7b\udc2a\ud8cb\ude70\uda8d\udfa3\udaed\udc6e\uda6c\udddc\udbbe\udeb8\ud94f\udc4a", "\u0ee4\u7b7d\u7246", "\ud826\ude23\ud9ca\ude77\ud925\udcbd\udb92\udd2f",
        31, 84147, -404532466, 8477137669311060891L, 97022L, true, false, (char) 57703, (char) 50953,
        Double.longBitsToDouble(0x3fd21ae45d0d8e40L), Double.longBitsToDouble(0x3fc022794ae94218L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayListIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udee1]]\0121=org.apache.commons.collections4.iterators.ObjectArrayListIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udee1]]\012",
        Z.run(T, 2, 13, 13, 14, "\ud8ce\udee1", "\u129c\u389c\u5168\u4d4e\u7330\u0491\uc7d1\u32ef\ud259\uc821\u0a13\u9465\u5a50\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\udb38\udedb\ud8be\ude46",
        56, 77899, -1478840540, 1936630582340874706L, 59428L, false, false, (char) 27592, (char) 12259,
        Double.longBitsToDouble(0x3fe91ea9e682fc15L), Double.longBitsToDouble(0x3fc830954a7326c8L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@?\0121=org.apache.commons.collections4.iterators.CollatingIterator:@?\012",
        Z.run(T, 2, 17, 1, 15, "\udb9a\udfad", "\u9f38\ua17b\u4600\uc29f\u35eb\u0491\u88e5\u7860\u63e7\u3fa6\u0a13\ua62d\u7bbb\u376a\u71e1\u1bae\u5406\ub700\u44a1", "\ud915\ude5b\ud8be\ude46\uda6d\udd91\ua97f\ud866\udcc1",
        15, 52013, -1569535064, 7490577667227748907L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae5484c6L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udee1]]\0121=org.apache.commons.collections4.iterators.ObjectArrayIterator:@? |a0=[Ljava.lang.Object;:[[\ud8ce\udee1]]\012",
        Z.run(T, 2, 7, 7, 17, "\ud8ce\udee1", "\u0cda\u5453\u5154\u4d4e\u7330\u91d3\uc7d1\u2751\u63e7\u3fa6\uc310\uce8d\ud294\u7c18\uc43a\ua5cb\u1f4b\ubb3f\u8b88", "\ud969\udc7b\udb2e\udf44",
        58, -442, -1478840540, 1936630582340874706L, 59428L, false, false, (char) 27592, (char) 12077,
        Double.longBitsToDouble(0x3feb5d39a649fc15L), Double.longBitsToDouble(0x3fe2a4ee989cc9b2L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 0, 14, "\ud8ce\udee1", "\u9f38\u0556\u5154\u0bd3\ub0c0\uad19\uc766\ua7ad\u63e7\u3fa6\u0a13\ua62d\u7bbb\u7246\u7aae\u1bae\u5406\u2d17\u8b88", "\ud915\ude5b\ud8be\ude46\udbcc\udc57\ue1de\ud888\uddf2",
        55, 39986, 1432929962, 8644486846809336176L, 10504L, false, false, (char) 12259, (char) 36947,
        Double.longBitsToDouble(0x3fe417e0ae549dd3L), Double.longBitsToDouble(0x3fe4e64d9450f4b2L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.CollatingIterator:@? |a1=[Ljava.util.Iterator;:@?\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 15, 14, "q\ud887\udec3\uf362\ud92c\udf7f", "\u4d4e\u224d\u0437\ud7e8\000\000\ua0fa\u0a13\u9069\u9817\u7334\u7aae\u1bae\u5406\u2fc2\u8b88\u07c1\uad98", "\udbcc\udc57\ue1de\ud888\ude24\ud9bf\udcd6",
        1, -830, 2012701437, 2495197104800892162L, -68382L, true, false, (char) 60, (char) 40052,
        Double.longBitsToDouble(0x3fe6e3c62e7a349cL), Double.longBitsToDouble(0x3fb43d2f438101a8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections4.IteratorUtils|collatedIterator|java.util.Comparator,java.util.Collection|static",
    "M|org.apache.commons.collections4.IteratorUtils|collatedIterator|java.util.Comparator,java.util.Iterator,java.util.Iterator|static",
    "M|org.apache.commons.collections4.IteratorUtils|collatedIterator|java.util.Comparator,[Ljava.util.Iterator;|static",
    "M|org.apache.commons.collections4.IteratorUtils|apply|java.util.Iterator,org.apache.commons.collections4.Closure|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayIterator|java.lang.Object|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayIterator|java.lang.Object,int|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayIterator|java.lang.Object,int,int|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayIterator|[Ljava.lang.Object;|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayIterator|[Ljava.lang.Object;,int|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayIterator|[Ljava.lang.Object;,int,int|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayListIterator|java.lang.Object|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayListIterator|java.lang.Object,int|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayListIterator|java.lang.Object,int,int|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayListIterator|[Ljava.lang.Object;|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayListIterator|[Ljava.lang.Object;,int|static",
    "M|org.apache.commons.collections4.IteratorUtils|arrayListIterator|[Ljava.lang.Object;,int,int|static",
    "M|org.apache.commons.collections4.IteratorUtils|collatedIterator|java.util.Comparator,java.util.Collection|static",
    "M|org.apache.commons.collections4.IteratorUtils|collatedIterator|java.util.Comparator,java.util.Iterator,java.util.Iterator|static",
    "M|org.apache.commons.collections4.IteratorUtils|collatedIterator|java.util.Comparator,[Ljava.util.Iterator;|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
