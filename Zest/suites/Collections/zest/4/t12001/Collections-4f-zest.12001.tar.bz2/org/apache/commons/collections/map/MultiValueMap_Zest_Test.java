package org.apache.commons.collections.map;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiValueMap_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 14, 13, 8, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud91a\ude35", "\u06d7\ud5e7\u51a6\u97cb\u2f65\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, 416465617, -1788035283122760192L, 59268L, true, false, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b328af04L), Double.longBitsToDouble(0x3fee1611c5b518a6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 14, 13, 8, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud91a\ude35", "\u06d7\ud5e7\u51a6\u97cb\u2f65\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, 416465617, -1788035283122760192L, 59268L, true, false, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654bd58eef4L), Double.longBitsToDouble(0x3fee161645b518a6L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\u06d7\u8bed\ubda4\u4818\u9df6\u236e\u8b47\u1f73\u846b\u6b81\ubda3 |this=org.apache.commons.collections.map.MultiValueMap:{\u6122\ud8e3\udc34\uda64\ude4b\ud8a7\udd81\uda7f\ude5b\udbf5\ude3c\ud91a\ude35=[\u06d7\u8bed\ubda4\u4818\u9df6\u236e\u8b47\u1f73\u846b\u6b81\ubda3]}\012",
        Z.run(T, 1, 0, 15, 2, "\u6122\ud8e3\udc34\uda64\ude4b\ud8a7\udd81\uda7f\ude5b\udbf5\ude3c\ud91a\ude35", "\u06d7\u8bed\ubda4\u4818\u9df6\u236e\u8b47\u1f73\u846b\u6b81\ubda3", "\ud99b\udf62\udbc7\udeff\udbd1\udc8c\ud8c7\uddf0\ud925\uddd2\ud96a\udee0\ud838\ude0e",
        38, 61046, 416472843, -1788035284448160256L, 90474L, true, true, (char) 28480, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b64caf04L), Double.longBitsToDouble(0x3f96245bb5da7b80L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{\uda54\udd3d\ud8e2\udff6\ud8bb\ude28\ud855\udd9a=[null]}\012",
        Z.run(T, 1, 16, 13, 8, "\uda54\udd3d\ud8e2\udff6\ud8bb\ude28\ud855\udd9a", "\u7916", "\uda52\udc6d\ud95b\udf65\uda03\udd03\ud805\udd05\u686a\ud8a1\udd87\udb15\ude39\u528b\ud8d0\udc32",
        7, 2391, -905320381, -4124872861381174676L, 96800L, true, true, (char) 30145, (char) 30293,
        Double.longBitsToDouble(0x3fab1b692945aec0L), Double.longBitsToDouble(0x3feb10c03600e72fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap$Values:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 15, 7, 0, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud947\udf35\udbf9\ude97\udbf3\udfa7\ud808\udc6b\ud9b0\udc82\ud970\udc99\uba0f\ud80f\udfc4\ud8b4\udc9e\ud879\ude7a\ud98d\ude35\ud8c2\udc6d\udb86\udd11\udbf6\udc18\ud8b2\udfb4\ud994\udf6a\uda66\udc75\udb1a\udf6a", "\u39b5\u2979\ua193\uc006\u7227\uc7d6", "\uda25\udeeb\ud95e\udcf8\ud9bb\udd29\uda76\udf77\ud867\udffb\udac3\udc13\ud881\udd08\udb76\udd35\uda68\udcfb\uda47\uded4\uea3f\ud940\udd61\uda85\ude1c\ud90e\ude04\ub052\udb55\udd7a",
        47, 57567, -132011377, 2525740036962606667L, 96461L, false, false, (char) 41560, (char) 52582,
        Double.longBitsToDouble(0x3fe0e9273a54ab1aL), Double.longBitsToDouble(0x3fe688c1995a1c33L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=null |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b=[null]}\012",
        Z.run(T, 2, 6, 16, 11, "\ud8e4\ude4b", "\u9b3a\ua33c\uaeae\uc5d4\ud056\u6ff3\u06d7", "\uba0f\ud80f\udfc4\udad5\udf64",
        2, 60053, 1025612126, -4437220561509977800L, -30099L, true, true, (char) 56427, (char) 28121,
        Double.longBitsToDouble(0x3fc46cbae30091b8L), Double.longBitsToDouble(0x3fec6e7279727c4fL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 12, 7, 14, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\udb82\udf1d\udbde\udfa5\ud91a\ude35", "\u06d7\ubbae\u9070\u7de7\u563e\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, 416465617, -1788035283122760192L, 59268L, true, false, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b328af04L), Double.longBitsToDouble(0x3fdfed8782039a42L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 6, 1, 8, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud8b1\udc1d", "\u7916\ud09e\u73f3\ud051", "\udbc4\uddbd\udb85\udf6f\ud8b4\udc9e\u1f27\ud90b\ude9a\ud8b9\ude87\udb86\udd11\ua1f6\uda8c\udeb1\u670e",
        24, -902, 1836122679, -1900163656515125110L, -72065L, true, false, (char) 61853, (char) 64318,
        Double.longBitsToDouble(0x3fe1458e9600e72fL), Double.longBitsToDouble(0x3fdd8279a3531506L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 3, 13, 8, "\ud81c\udfee\ud950\udccd\ud841\udcd8\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud98b\udfc1", "\u6090\ud5e7\u51a6\u94d2\uca62\u23d5\u4b93\u672e\u9c94\ub67e\ud7b7", "\uda87\udfda\ud970\udd91\ud99c\ude78\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, -1734688047, -1820734892076791513L, 59268L, true, false, (char) 38393, (char) 15594,
        Double.longBitsToDouble(0x3fdeb654b328af04L), Double.longBitsToDouble(0x3fee1611c5b518a6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 2, 13, 1, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud91a\ude35", "\u06d7\ud5e7\u51a6\u0818\ua5fa\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, 416465617, -1788035283122760192L, 59268L, true, false, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b328af04L), Double.longBitsToDouble(0x3fee1611c5b518a6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 4, 12, 8, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud84a\ude0e\uda7f\ude5b\udbf5\ude3c\ud91a\ude35", "\u06d7\ud5e7\u51a6\u97cb\u2f65\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udef9\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, 416465617, -1788035283122760192L, -69621L, false, true, (char) 9014, (char) 39302,
        Double.longBitsToDouble(0x3fee1611c19618a6L), Double.longBitsToDouble(0x3fcb0b1ff1dc86b4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.collections.iterators.EmptyIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 11, 10, 8, "\uda8d\udc69\ud8dd\udca6\ud83c\udce0\udb22\udc08\uda7f\ude5b", "\ub593\u73cd\u123d\u6a1a\uade8\uc879\u2f65\u236e\uc763", "\udb86\udd11\udbf6\udc18\uda8c\udeb1",
        30, 85994, 374530586, -7587343233107563655L, -35373L, false, true, (char) 25776, (char) 61853,
        Double.longBitsToDouble(0x3fe689c3776218d2L), Double.longBitsToDouble(0x3fe007397dd8279aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 5, 9, 8, "\uda54\udd3d\ud8e2\udff6\uda64\udeeb\ud853\udc0e\uda7f\ude5b\ud9ae\udd39\uf2f8", "\u6cd7\ud5e7\u51a6\u97cb\u2f65\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 60859, 416465617, -1788035284162947584L, 24617L, false, false, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fea6fea5994574dL), Double.longBitsToDouble(0x3fee1611c2b518a6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 14, 13, 8, "\uda54\udd3d\ud85c\udff3\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud9a4\udf35\uda3a\udef9\udaf8\udff4", "\u86af\u97cb\u2f65\u236e\u1824\u8454\u01d2\ud457\ubda3\u0ae0", "\udb1a\udf6a\udb9d\udd69\uda7e\ude34",
        36, 43261, 106432596, -8493997154943236239L, -17131L, true, false, (char) 49197, (char) 9014,
        Double.longBitsToDouble(0x3fcd6aed6775ea2cL), Double.longBitsToDouble(0x3fd74c74c6904014L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ua989\udb84\udd5a\uda3a\udeb9\ud98e\ude54\uda7f\ude5b\udbf5\ude3c\ud8c9\udfed=[\u06d7\ud5e7\u51a6\u97cb\u2f65\u236e\u21cc\u7e5c\u01d2\ud457\ubda3]}\012",
        Z.run(T, 1, 1, 13, 8, "\ua989\udb84\udd5a\uda3a\udeb9\ud98e\ude54\uda7f\ude5b\udbf5\ude3c\ud8c9\udfed", "\u06d7\ud5e7\u51a6\u97cb\u2f65\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\udb6d\ude15\ud99a\udc63\ud9ee\udc49",
        59, 61036, 785564369, -1788034772021651968L, 59268L, false, true, (char) 52260, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b328af04L), Double.longBitsToDouble(0x3fee1611c5b587a6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 8, 13, 8, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\uddf4\udbf5\ude3c\ud91a\ude35\udbf9\ude97\udaf8\udff3\udad4\udfce\ud9b0\udccf\ud970\udc99\uba0f\ud80f\udfc4\ud8b4\udc9e\udb15\udd88", "\u00b3\ubda3\ua429", "\udb1a\udf6a\ud999\udd87\uda50\udec8",
        36, 3037, -329713294, -1593860477108222020L, 79275L, true, false, (char) 57372, (char) 49327,
        Double.longBitsToDouble(0x3fd945782f858470L), Double.longBitsToDouble(0x3fdb518a63e82b72L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.collections.iterators.EmptyIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.map.MultiValueMap$Values:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 11, 15, 14, "\uda54\udd3d\ud8e2\udff6\uda60\udc7f\ud8a7\udd78\udab5\udc20", "\ud04a\u73f3\u06d7\ud5e7\u990a\u8f6c", "\udb93\udfa7\uda2c\ude1b\ud8dd\udd2f\uda1b\udcb6\ud9d4\ude81\uda8c\udefc\u670e\ud8f9\uded1",
        -4, 94463, 611241436, 1797750681311838980L, 62468L, false, true, (char) 64169, (char) 1130,
        Double.longBitsToDouble(0x3fcbee088180b794L), Double.longBitsToDouble(0x3fd327d68897e1d2L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 7, 13, 8, "\uda57\uddf0\ud8c0\udf55\uda64\ude4b\ud853\udc0e\uda7f\ude5b\ud897\ude8c\ud946\udff9", "\u5555\u68f6\u2b1a\u7f13\u2f65\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, 416465617, -1788035283122760192L, 59268L, true, true, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b328af04L), Double.longBitsToDouble(0x3fee17aab5b518a6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 4, 8, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbdb\udf3f\uda24\uddfa", "\u1e89\u58f6\uc27c\u97cb\u2f65\u236e\u7fdd\u7e5c\u01d2\ud457\ubda3", "\ud8d9\ude2a\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 17068, 416465609, -1788035283122760192L, 59268L, true, false, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b108fd48L), Double.longBitsToDouble(0x3fee1611c5b518a6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 14, 4, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud91a\ude35", "\u06d7\u33c8\u51a6\u97cb\u2f65", "\ud85e\udcf0\ud991\udfb5\u3550\udb14\udd32\uda8c\udeb1\u670e\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8",
        36, 3037, -329713294, -1593860477108222020L, -17131L, true, false, (char) 49197, (char) 9014,
        Double.longBitsToDouble(0x3fd945782f858470L), Double.longBitsToDouble(0x3fe5a8c5348745f6L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 2, 13, 12, "\uda54\udd3d\ud8e2\udff6\ud8b5\udeb2\ud853\udc59\uda7f\ude5b\udbf5\ude3c\ud91a\ude35\udbf9\ude97\udaf8\udff3", "\u51a6\u97cb\u2f65\u236e\u21cc\u7e5c\u01d2\ud457\ubda3\u0ae0\u202d\u286b", "\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49\ud903\udf09\ud92a\udf0f\ud9df\udc47\uda7b\uddeb\ud9c2\udc55",
        7, 77772, 525253707, 1202591579018866558L, -86004L, false, true, (char) 32347, (char) 19067,
        Double.longBitsToDouble(0x3fec003cd003acabL), Double.longBitsToDouble(0x3fde1a1d2cd34188L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{\udaab\udefc\ud8e3\udc34\uda64\ude4b\ud8a7\udd81\uda7f\ude5b\udbf5\ude3c\ud91a\ude35\udbf9\ude97\udaf8\udff3\udad4\udfce\ud997\udced\ud824\udee3\ud968\udc0e\ud9e0\udc8b\udb8f\ude42\udadd\udc36\udb2b\ude72\uda5b\udd39\ud8d5\udfdf\uda81\udfeb\ud97f\udf4a\udb74\udf1f\ud97a\ude47\udad1\udc04=[null]}\0121=org.apache.commons.collections.map.MultiValueMap$Values:[null] |this=org.apache.commons.collections.map.MultiValueMap:{\udaab\udefc\ud8e3\udc34\uda64\ude4b\ud8a7\udd81\uda7f\ude5b\udbf5\ude3c\ud91a\ude35\udbf9\ude97\udaf8\udff3\udad4\udfce\ud997\udced\ud824\udee3\ud968\udc0e\ud9e0\udc8b\udb8f\ude42\udadd\udc36\udb2b\ude72\uda5b\udd39\ud8d5\udfdf\uda81\udfeb\ud97f\udf4a\udb74\udf1f\ud97a\ude47\udad1\udc04=[null]}\012",
        Z.run(T, 2, 0, 15, 2, "\udaab\udefc\ud8e3\udc34\uda64\ude4b\ud8a7\udd81\uda7f\ude5b\udbf5\ude3c\ud91a\ude35\udbf9\ude97\udaf8\udff3\udad4\udfce\ud997\udced\ud824\udee3\ud968\udc0e\ud9e0\udc8b\udb8f\ude42\udadd\udc36\udb2b\ude72\uda5b\udd39\ud8d5\udfdf\uda81\udfeb\ud97f\udf4a\udb74\udf1f\ud97a\ude47\udad1\udc04", "\u87c8\u1a57\u7db5\uc919\ucf40\ua379", "\ud832\udffa\ud9c3\udd94\ud9ca\udd78\udb15\udf8e\ud89f\udd76\ud8c2\udf13\uda4c\uddee\ud815\udd7c\udad4\udf54\ud888\udcd0\udabf\ude92\udaf2\udc0b\uda42\uddfe\uda01\udec5\ud868\udef9\ud96b\udfa2",
        -3, 35846, -256493356, 4413843080086604046L, -14804L, false, true, (char) 53650, (char) 27901,
        Double.longBitsToDouble(0x3fb0d650775d5d80L), Double.longBitsToDouble(0x3fee6a363640787bL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 8, 0, 16, "\ud9f3\udde2\ud8e3\udc12\uda64\ude4b\ud8a7\udd81\uda7f\ude5b\ud992\udfff\udaea\ude73\ud836\udf1c\ud889\ude23\udb80\uddc2\ud9ab\udded\ud824\udee3\udbbe\udc2a\uda80\udc49\ud9fc\udc1f\uda19\udeb0\udb19\ude1e\ud880\udea0\ud8d6\udc12\udbf6\udc18\uda8c\udeb1\u670e\ud99b\udf62\ud8ce\udc3d\ud9d7\udf3a\ud8de\udd24", "\u55e4\uc42b\u6b17\u6d48\u4e0c\u574e\u852f\u7013\u3938", "\ud8c2\udf13\udaed\uddef",
        14, 63264, 1028589387, -4268460669930164122L, 79608L, false, false, (char) 12154, (char) 29241,
        Double.longBitsToDouble(0x3fce2896d8d27d5cL), Double.longBitsToDouble(0x3feb8d7c0a31c00cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 7, 13, 8, "\uda54\udd3d\ud8e2\udff6\ud8bb\ude28\ud855\udd9a", "\u7916", "\uda52\udc6d\ud95b\udf65\uda03\udd03\ud881\udd03\u686a\ud8a1\udd87\udb15\ude39\u528b\u2b70",
        7, 2391, -905320381, -4124872861381174676L, 96800L, true, true, (char) 30145, (char) 30293,
        Double.longBitsToDouble(0x3fab1b692945aec0L), Double.longBitsToDouble(0x3feb10c03600e72fL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\u6e1f |this=org.apache.commons.collections.map.MultiValueMap:{\uda54\udd3d\ud8e2\udff6\ud8bb\ude28\ud855\udd9a=[\u6e1f]}\0121=java.lang.Integer:1 |this=org.apache.commons.collections.map.MultiValueMap:{\uda54\udd3d\ud8e2\udff6\ud8bb\ude28\ud855\udd9a=[\u6e1f]}\012",
        Z.run(T, 2, 16, 13, 8, "\uda54\udd3d\ud8e2\udff6\ud8bb\ude28\ud855\udd9a", "\u6e1f", "\ud9a6\udf36\ud95b\udeff\uda03\udd03\ud805\udd05\u686a\ud8a1\udd87\udb15\ude39\u528b\ud8d0\udc32",
        -2, 61382, -905321787, -4124872861381174676L, 48889L, true, true, (char) 19208, (char) 19487,
        Double.longBitsToDouble(0x3feb10c03600e72fL), Double.longBitsToDouble(0x3fdd67dd4e6fb0feL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{\ud9ae\udd8e\ud8b7\udd43\ud8bb\ude28\ud855\udd9a=[null]}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{\ud9ae\udd8e\ud8b7\udd43\ud8bb\ude28\ud855\udd9a=[null]}\012",
        Z.run(T, 2, 16, 17, 16, "\ud9ae\udd8e\ud8b7\udd43\ud8bb\ude28\ud855\udd9a", "\u7916", "\uda52\udc6d\ud95b\udf65\uda03\udd03\ud805\udd05\ubb91\ud9d2\ude0e\udb15\ude39\ud88e\udda9\udbef\udc4b",
        58, 2391, -905320381, -4124753014613747092L, 59668L, false, true, (char) 12078, (char) 51541,
        Double.longBitsToDouble(0x3fab1b692945aec0L), Double.longBitsToDouble(0x3feb10c03600e72fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 12, 5, 5, "\uda54\udd3d\ud8e2\udff6\ud8bb\ude28\ud855\udd9a\udaa1\udf8d\udbf5\ude3c\ud91a\ude35\uda3c\udc38\udb94\udd6f\ud864\udfe9\ud8ad\udc55\uda03\udd03\ud805\udd05\ud871\uddf4\ud92a\udf33\ud829\udc90\u52a2\ud8d0\udc32\udb1a\udd93\ud92f\ude3d\udb9d\udd14\ud961\ude9d\ud83d\uddcf\udb09\udce3\ud999\udd87\uff83\ud8e0\ude50\udaf8\udd08\ud891\udeae\uda94\udeef", "\u348c\ubf66\uaa05\u4388\uc426\uba75\u1aa2\u46d8\ua529\u1f07\u105c\ud56c\u98cc", "\uda61\udf06\udac4\udf24\ud98d\udeec\ud867\uddfb",
        55, 84773, -1601593058, 5322783663260080818L, -92202L, true, false, (char) 53775, (char) 62574,
        Double.longBitsToDouble(0x3fde9aa86e222aaaL), Double.longBitsToDouble(0x3fb9333fc624fbd8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 7, 7, 0, "\uda54\udd3d\ud8d7\udcf6\uda64\ude4b\ud853\udc0e\udb20\udc4b\udbf5\ude3c\ud947\udf35\udbf9\ude97\udbf3\udfa7\ud808\udc6b\uda3c\udffc\ud96f\udff8\uba0f\ud80f\udfc4\ud8b4\udc9e\ud879\ude7a\ud98d\ude35\ud8c2\udc6d\ud8b0\udd92\udbf1\udc36\ud8b2\udfb4\ud994\udf6a\uda66\udc75\udb1a\udf6a", "\u6c13\u28aa\u743c\ua02c\ube0f\u0aee", "\uda25\udeeb\ud9bb\ude26\ud9d3\uddcc\uda76\udf77\ud867\udffb\udaad\udf13\ud881\udd08\udb76\udd35\uda68\udcfb\uda47\uded4\uea3f\ud940\udd61\uda85\ude1c\ud90e\ude04\udbda\udd78\ud8a2\udd57",
        47, 57567, -132011377, 2525740036962606667L, 96461L, false, false, (char) 41560, (char) 25447,
        Double.longBitsToDouble(0x3fe71f91b254ab1aL), Double.longBitsToDouble(0x3fe688c1995a1c33L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=null |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 10, 10, 11, "\ud8b6\ude75", "\u9b3a\ucfea\u6a3c\uc5d4\ud056\u6ff3\u06d7", "\ud69b\ud80f\udfc4\udad5\udf64",
        2, 64101, 1025601831, -4437220561496128200L, -4714L, true, false, (char) 56427, (char) 28121,
        Double.longBitsToDouble(0x3fc46cbae30091b8L), Double.longBitsToDouble(0x3fec6e727ade25ddL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b=[null]}\0121=null |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b=[null, null]}\012",
        Z.run(T, 2, 0, 16, 11, "\ud8e4\ude4b", "\u9b3a\ua33c\uaeae\uc5d4\ud056\u6ff3\u06d7", "\uba0f\ud80f\udfc4\udad5\udf64",
        2, 60053, 1025612126, -4437220561509977800L, -30099L, true, true, (char) 56427, (char) 28121,
        Double.longBitsToDouble(0x3fd1c11d721e900eL), Double.longBitsToDouble(0x3feb03c311727c4fL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\udb08\udd7e\udaa2\udd77\uda6a\udf4f\ud853\udc0e\udbd6\ude55\udb93\udf5c\ud94a\uddbe=[\u9b77\ud5e7\u51a6\uc017\u2c92\u4dd7\ubbaf\u7e5c\u01d2\u2a6d\u9c39]}\0121=java.lang.String:\u9b77\ud5e7\u51a6\uc017\u2c92\u4dd7\ubbaf\u7e5c\u01d2\u2a6d\u9c39 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 1, 12, 3, "\udb08\udd7e\udaa2\udd77\uda6a\udf4f\ud853\udc0e\udbd6\ude55\udb93\udf5c\ud94a\uddbe", "\u9b77\ud5e7\u51a6\uc017\u2c92\u4dd7\ubbaf\u7e5c\u01d2\u2a6d\u9c39", "\udadd\udde2\udb1a\udfd7\udadd\udde9\uda78\udec8\ud925\uddd2\ud925\udd35\udb2a\udc81",
        28, 35750, 1745048148, 5806523884277181380L, -1287L, true, true, (char) 2213, (char) 19782,
        Double.longBitsToDouble(0x3fc918c984daa83cL), Double.longBitsToDouble(0x3fe028750d86e706L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.util.ArrayList:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 6, 6, 11, "\ud8e4\ude4b", "\ubba4\ua355\uaeae\uc211\u621e\u6ff3\u06d7", "\uba0f\ud80f\udfc4\udad5\udf64",
        2, 60053, 1025612126, -4437220561509977800L, -30099L, true, true, (char) 56427, (char) 28121,
        Double.longBitsToDouble(0x3fc46cbae30091b8L), Double.longBitsToDouble(0x3fec6e7279727c4fL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\udb3b\udead\ud95e\udd1a\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udba4\udef3\uda43\udd05\uda36\udfd7\udaf7\udff3\ud859\uded0\ud93c\udcd7\ud95b\ude0a=[\ub05c\u5e25\u6700]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\udb3b\udead\ud95e\udd1a\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udba4\udef3\uda43\udd05\uda36\udfd7\udaf7\udff3\ud859\uded0\ud93c\udcd7\ud95b\ude0a=[\ub05c\u5e25\u6700]}\012",
        Z.run(T, 2, 17, 5, 16, "\udb3b\udead\ud95e\udd1a\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udba4\udef3\uda43\udd05\uda36\udfd7\udaf7\udff3\ud859\uded0\ud93c\udcd7\ud95b\ude0a", "\ub05c\u5e25\u6700", "\ud847\uddc6\uda7e\udcb1\udbfb\udf01\ud8f9\uded1\udb1a\udf6a\ud999\udd07",
        15, 70736, 1804338829, -1093094389217315801L, 48752L, false, false, (char) 6069, (char) 30414,
        Double.longBitsToDouble(0x3fecf3df26ca9e43L), Double.longBitsToDouble(0x3fe86ea909b9ba2bL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b=[null]}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 7, 11, "\ud8e4\ude4b", "\u6e7d\ubf79\u9c9a\ub621\uad5e\u8f80\u073c", "\uba0f\ud80f\udfc4\udad5\udf64",
        5, 60053, 1025612126, 8316973583203266872L, -30099L, true, true, (char) 3948, (char) 64098,
        Double.longBitsToDouble(0x3fed124ce2211d08L), Double.longBitsToDouble(0x3fec4e4aa972dd4fL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 14, 14, 17, "\udb5c\udeb7\ud9b9\udd02", "\ua33c\uaeae\uc5d4\ud056\u6ff3", "\ud970\udc99\uba0f\ud80f\udfc4\udad5\udf64\udb3b\udf6b\ud9de\ude23\ud8dd\udcf8\udbf1\udfc7\udb6c\udfa0\uda7e\udcb1\u6702\ud8f9\uded1",
        -4, 94463, 611233955, -3580642352016981107L, 69828L, true, true, (char) 32310, (char) 17451,
        Double.longBitsToDouble(0x3fd6fcbbb99eab7eL), Double.longBitsToDouble(0x3f9eae6d88f9b0c0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.String:\u88c6\uaeae |this=org.apache.commons.collections.map.MultiValueMap:{\udb0c\ude1c\uda1c\udd18=[\u88c6\uaeae]}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{\udb0c\ude1c\uda1c\udd18=[\u88c6\uaeae]}\012",
        Z.run(T, 2, 16, 4, 11, "\udb0c\ude1c\uda1c\udd18", "\u88c6\uaeae", "\ud86b\udd58\udaab\udc69\uda4b\udc7d\udb05\udf2e\ud92f\udff9",
        7, 31206, 969937288, 2838530989367480254L, 49462L, false, true, (char) 25172, (char) 42738,
        Double.longBitsToDouble(0x3fd3c73077abe1a0L), Double.longBitsToDouble(0x3fc46cbbeb9599b8L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.String:\u9964\uaeae\uc5d4\ud056\u6ff3\u06d7\ud5e7\u51a6\u97cb\u2f65\u4dd7\ubbaf\u7e5c\u01d2\u2a6d\ua8c9\ua8df\u2dfd\u286b |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b\ud8e2\udff6=[\u9964\uaeae\uc5d4\ud056\u6ff3\u06d7\ud5e7\u51a6\u97cb\u2f65\u4dd7\ubbaf\u7e5c\u01d2\u2a6d\ua8c9\ua8df\u2dfd\u286b]}\0121=org.apache.commons.collections.map.MultiValueMap$ValuesIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b\ud8e2\udff6=[\u9964\uaeae\uc5d4\ud056\u6ff3\u06d7\ud5e7\u51a6\u97cb\u2f65\u4dd7\ubbaf\u7e5c\u01d2\u2a6d\ua8c9\ua8df\u2dfd\u286b]}\012",
        Z.run(T, 2, 16, 11, 13, "\ud8e4\ude4b\ud8e2\udff6", "\u9964\uaeae\uc5d4\ud056\u6ff3\u06d7\ud5e7\u51a6\u97cb\u2f65\u4dd7\ubbaf\u7e5c\u01d2\u2a6d\ua8c9\ua8df\u2dfd\u286b", "\u0b6e\ud925\udd22\ubf05\udb15\udf78\uda09\udde8\ud9be\udd55\udab0\ude81\u7d9a\udaa1\ude74",
        38, 19179, -514998692, -5231030185540800414L, -83407L, true, true, (char) 30508, (char) 51651,
        Double.longBitsToDouble(0x3fee252e55c2e23eL), Double.longBitsToDouble(0x3fcda98ce028e82cL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\u01d2\ua835\u410e\ua8df |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\udb79\udd45\udbdd\udf22\udb07\uddb8\udad4\udfce\ud9bf\udfcf\ud970\udc99\uba0f\ud80f\udfc4\udad5\udf64=[\u01d2\ua835\u410e\ua8df]}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 16, 9, 3, "\ud8e4\ude4b\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\udb79\udd45\udbdd\udf22\udb07\uddb8\udad4\udfce\ud9bf\udfcf\ud970\udc99\uba0f\ud80f\udfc4\udad5\udf64", "\u01d2\ua835\u410e\ua8df", "\udb1a\udf6a\udb7e\udcfb\udb8e\udd99",
        44, 3037, -881657486, -8957628599923174368L, -2933L, false, true, (char) 22232, (char) 31695,
        Double.longBitsToDouble(0x3fe10d6aa11befbfL), Double.longBitsToDouble(0x3fe4351f8ebbf0c8L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b=[\u9b3a\ua33c\uc757\ub1c4\u0157\u6ff3\uc982]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\ude4b=[\u9b3a\ua33c\uc757\ub1c4\u0157\u6ff3\uc982, \u9b3a\ua33c\uc757\ub1c4\u0157\u6ff3\uc982]}\012",
        Z.run(T, 2, 17, 17, 16, "\ud8e4\ude4b", "\u9b3a\ua33c\uc757\ub1c4\u0157\u6ff3\uc982", "\ud9c4\ude99\udac7\udc74\udad5\udf64",
        2, 60053, 1028233566, -4437220561496602680L, 92172L, true, true, (char) 56427, (char) 28121,
        Double.longBitsToDouble(0x3fc46cbae30091b8L), Double.longBitsToDouble(0x3fec6e727f2baa4fL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{\ud8a9\udfd4=[null]}\0121=java.lang.Integer:1 |this=org.apache.commons.collections.map.MultiValueMap:{\ud8a9\udfd4=[null]}\012",
        Z.run(T, 2, 0, 14, 15, "\ud8a9\udfd4", "\u9b3a\ua33c\uc6ad\uc5d4\ud056\u6ff3\u5b2f", "\uba0f",
        -5, -1000, 9754633, 6411999970494355806L, -30099L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x3fc46cbae0000000L), Double.longBitsToDouble(0x3fec6e7001727c4fL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 13, 13, 11, "\uda54\udd3d\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud91a\ude35", "\u06d7\ud5e7\u51a6\u0818\ua5fa\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 44620, 416465565, -1788035283122760192L, 59268L, true, false, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b328af04L), Double.longBitsToDouble(0x3fee1611c5b518a6L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=null |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 12, 12, 12, "\udbdb\udfc6\ud8d6\udced\ud83c\udce0\udb22\udc08\uda54\udca9\ud840\udefa\ud94c\ude79\ud8eb\udf71\udb35\udedd\ud8b1\udf26\ud966\udf0b\ud823\udd1e\ud88a\uddbc\uda43\udf40\uda1e\udc71\udb29\udef3\ud9de\udd9e\ud8dd\udcf8\udb86\udd11", "\u6ebd\ud792\u448f\ud2ba\u7843", "\ud9b3\udece\uf08c",
        31, 41430, 869179342, -227247994795047753L, 84721L, false, false, (char) 7916, (char) 38819,
        Double.longBitsToDouble(0x3fcdcb01a5050c0cL), Double.longBitsToDouble(0x3fd463fd43d41fbeL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 7, 7, 5, "\uda62\udc21\ud85c\udff3\uda60\ude49\udac3\udf26\uda7f\ude44\ud9fb\ude30\ud9a4\udf35\uda3a\udeec\udaf8\udff4\ud98a\udfc9\ud882\udf58\udb4a\uddde\ub990\ud80f\udfc4\ud855\udca1\udba4\udf5d\ud9e0\udc1b", "\u38ee\u21f1\u202d\u286b\u448f\u7f0a\u2379\ud5da\u0e56\u33a9\u46e1\u7252\u38dc\u1a02\u0b16\u9a0c", "\udb15\udfa6\ud89f\udd76\udb7e\udf11",
        56, 84361, -1871716865, -5063915928548662778L, -5157L, true, true, (char) 26576, (char) 62811,
        Double.longBitsToDouble(0x3fef0900b6a22f72L), Double.longBitsToDouble(0x3fa8af8a4dc20720L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap$Values:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.map.MultiValueMap$Values:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 15, 15, 7, "\uda46\udfb6\ud949\udfb7\udb57\udcef\ud853\udc0e\uda7f\ude5b\udbf5\ude3c\ud9a4\udf35\uda3a\udef9\ud884\udef9", "\u3321\u960f\u82be\u236e\u1824\u56b2\u3a52\ud3fa\ubda3", "\udb6a\udc16\ud8d2\udfba\udbf0\udc42\ud82a\udd7f\udaeb\udef4\ud91f\ude7b\udac2\udcb3\ud800\udd8d\uda37\ude2b\ud845\udfac\uda6e\udef4\ud9ac\udce9\ud9f6\udf74\udb06\udd65",
        20, 88002, 1699474163, 6299337322878726379L, 62444L, false, false, (char) 57108, (char) 60787,
        Double.longBitsToDouble(0x3fbfd7fa75518928L), Double.longBitsToDouble(0x3fde3f4c2c4e751aL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.collections.iterators.EmptyIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.iterators.EmptyIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 11, 11, 16, "\uda57\uddf0\ud8c0\udf55\uda64\ude4b\ud943\udf46\ud879\udcd8\ud897\uded0\udae1\ude34", "\u5555\u68f6\u2b1a\u7f13\uae68\u236e\u21cc\u7e5c\u01d2\ud457\ubda3", "\ud8f9\uded1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, 416465617, -1788035283122760192L, -89957L, false, true, (char) 9014, (char) 42006,
        Double.longBitsToDouble(0x3fee17a915b518a6L), Double.longBitsToDouble(0x3fce65c675602b98L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 2, 3, 13, "\uda57\uddf0", "\u8894\u9d97\u8eab\ud2db\u0fc9\u53f3\u5555", "\uda7e\udd71\ud80f\udfc4\ud8b4\udc9e\udb15\udd88\ud9de\ude23\ud8dd\udcf8\ud886\udd70\udb60\udf12\uda89\udf26\udb93\udeeb\udb4f\udc96\uda7d\ude4b",
        24, 79827, -1596812362, -472551438883734072L, 94628L, true, false, (char) 16834, (char) 15617,
        Double.longBitsToDouble(0x3fd5a3c9a4a93ee8L), Double.longBitsToDouble(0x3fd5f17bc6083c9cL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 9, 2, "\udaab\udefc\ud8e3\udc34\uda64\ude4b\ud8a7\udd81\uda7f\ude5b\udbf5\ude3c\ud91a\ude35\udbf9\ude97\udaf8\udff3\udad4\udfce\ud997\udced\ud824\udee3\ud968\udc0e\ud9e0\udc8b\udb8f\ude42\udadd\udc36\udb2b\ude72\uda5b\udd39\ud8d5\udfdf\uda81\udfeb\ud97f\udf4a\udb74\udf1f\ud97a\ude47\udad1\udc04", "\u87c8\u1a57\u7db5\uc919\ucf40\ua379", "\ud832\udffa\ud9c3\udd94\ud9ca\udd78\udb15\udf8e\ud89f\udd76\ud8c2\udf13\uda4c\uddee\ud815\udd7c\udad4\udf54\ud888\udcd0\udabf\ude92\udaf2\udc0b\uda42\uddfe\uda01\udec5\ud868\udef9\ud96b\udfa2",
        -3, 35846, -256493356, 4413843080086604046L, -14804L, false, true, (char) 53650, (char) 27901,
        Double.longBitsToDouble(0x3fb0d650775d5d80L), Double.longBitsToDouble(0x3fee6a363640787bL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{\ud9ae\udd8e\ud8b7\udd43\ud8bb\ude28\ud855\udd9a=[null]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud9ae\udd8e\ud8b7\udd43\ud8bb\ude28\ud855\udd9a=[null]}\012",
        Z.run(T, 2, 0, 4, 16, "\ud9ae\udd8e\ud8b7\udd43\ud8bb\ude28\ud855\udd9a", "\u7916", "\uda52\udc6d\ud95b\udf65\uda03\udd03\ud805\udd05\ubb91\ud9d2\ude0e\udb15\ude39\ud88e\udda9\udbef\udc4b",
        31, 2391, -905320381, -4124753014613747092L, 59668L, false, true, (char) 12078, (char) 51541,
        Double.longBitsToDouble(0x3fe9b1b69430702fL), Double.longBitsToDouble(0x3feb10c5e600e72fL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 1, 17, 16, "\ud9ae\udd8e\ud8b7\udd43\ud8bb\ude28\ud855\udd9a", "\u7916", "\uda52\udc6d\ud95b\udf65\uda03\udd03\ud805\udd05\ubb91\ud9d2\ude0e\udb15\ude39\ud88e\udda9\udbef\udc4b",
        58, 2391, -905320381, -4124753014613747092L, 59668L, false, true, (char) 12078, (char) 51541,
        Double.longBitsToDouble(0x3fab1b692945aec0L), Double.longBitsToDouble(0x3feb10c03600e72fL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 2, 2, 3, "\udb08\udd53\ud994\udf49\uda6a\udebc\ud853\udc0e\udbd6\ude55\udbff\udf5a\ud94a\uddbe\u16a4\udb54\uddcf\ud8ba\udd5e\ud9b0\udccf\ud970\udc99\ud921\udda7\ud80f\udcf1\udad5\udf64\udb3b\udf6b\uda3a\ude1b\ud8dd\udcf8\udbf1\udfc7", "\u2021", "\ud8a8\ude05\uda99\udee7\ud925\uddd2\uda02\udf06\udb15\udd81\ud8c0\udd9f\uda19\ude4f\ud89a\udc75",
        -2, 47252, -1008285802, 9146386871940584811L, -36368L, false, false, (char) 43845, (char) 18598,
        Double.longBitsToDouble(0x3fd86e70683b6466L), Double.longBitsToDouble(0x3fe3e20d08e64990L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 5, 5, 16, "\udb3b\udead\ud95e\udda9\uda64\ude4b\ud853\udc0e\uda7f\ude5b\udba4\udef3\uda43\udd05\uda36\udfd7\udaf7\udff3\ud903\udf74\ud93c\udcd7\ud857\udf06", "\ub05c\u5e25", "\uda0f\ude6f\ubba5\udab3\udebd\udbfb\udeb4\ud8f9\uded1\ud819\udd87\uda7b\udfb9\u6353\udae1\ude9b\ud8d7\udcb6\ud86e\udf80\ud86a\udce5\ud80e\udc40\ub08f\ud9ce\ude1b\udbbc\udc6e\udbda\udfe5\ud9ed\udec0\ud8b5\udc43\ud8c8\udebc\ud8be\uddcb\ud993\udc7e\udb6e\udcb4\ud9b1\udda3\ud916\udcd4\ud8ee\ude90\uda10\ude48\ud9e1\udfbf\ud93d\uddc4\u1c76\ud848\udcd9\ud8b4\udeec\udb1a\udc9d\uda9b\udde1\ud9e1\ude40\uda85\udf67\ud9ae\uddd4",
        50, 77562, -1672976310, -1540423573823610241L, -45395L, true, true, (char) 63501, (char) 33041,
        Double.longBitsToDouble(0x3fe783643b0b150fL), Double.longBitsToDouble(0x3fd6e3b1788bf3eeL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 3, 3, 4, "\ud8dd\ude61", "\u6e7d\ubf79\u9c9a\ub621\uad5e\u8f80\u073c\ud5e7\u51a6\u97cb\u2f65\u4dd7\u28af\u1330", "\udb6c\udfa0\udab2\udd0b\u6702\ud8f9\uded1",
        57, 64364, 487096226, -3939169590144972663L, -65807L, false, false, (char) 33846, (char) 3546,
        Double.longBitsToDouble(0x3fdf3946d2b1b8caL), Double.longBitsToDouble(0x3fc2a6cc83c12148L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 8, 8, 16, "\ud8e4\ude4b", "\u6e7d\ubf79\u9c9a\ub621\uad5e\u8f80\u044c", "\uba0f\ud80f\udfc4\udad5\udf64\udb17\udc6b\ud9de\ude23",
        1, 73313, -1577114948, 3454947891563037737L, 59767L, false, false, (char) 51518, (char) 24361,
        Double.longBitsToDouble(0x3fec4e4aa972dd4fL), Double.longBitsToDouble(0x3fe96854e461ea19L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 4, 4, 1, "\uda90\udcf4", "\u6e7d\ubf79\u9c9a\u7678\u3ebf\u8fed\ua491", "\uda7a\udc67\ud810\udc4c\udb3d\ude4f\udaf4\ude9e",
        23, 40684, 2104218473, 8860195443503418482L, 9286L, false, true, (char) 52695, (char) 142,
        Double.longBitsToDouble(0x3fe10a584789c955L), Double.longBitsToDouble(0x3fd68dd4f684c4e8L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 14, 13, 8, "\udbd6\udf2f\ud8e2\udff6\uda64\ude4b\ud853\udc0e\uda7f\uddc0\udbf5\ude3c\ud928\udcdd", "\u0428\u2431\u51a6\u97cb\u2f65\u236e\u21cc\u7e5c\u01d2\u95bc\u328b", "\ud8d9\udfc1\udb1a\udf6a\ud999\udd87\uda50\udec8\ud925\uddd2\ud96a\udee0\ud9ee\udc49",
        59, 61036, 416465617, -1788035283122760192L, 59268L, true, false, (char) 38393, (char) 49197,
        Double.longBitsToDouble(0x3fdeb654b328af04L), Double.longBitsToDouble(0x3fee1611c5b518a6L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.map.MultiValueMap|put|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|putAll|java.lang.Object,java.util.Collection|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|putAll|java.util.Map|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|clear||new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|containsValue|java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|containsValue|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|createCollection|int|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|decorate|java.util.Map|static",
    "M|org.apache.commons.collections.map.MultiValueMap|decorate|java.util.Map,java.lang.Class|static",
    "M|org.apache.commons.collections.map.MultiValueMap|decorate|java.util.Map,org.apache.commons.collections.Factory|static",
    "M|org.apache.commons.collections.map.MultiValueMap|getCollection|java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|iterator|java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|removeMapping|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|size|java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|totalSize||new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|values||new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|put|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|putAll|java.lang.Object,java.util.Collection|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|putAll|java.util.Map|new:org.apache.commons.collections.map.MultiValueMap:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
