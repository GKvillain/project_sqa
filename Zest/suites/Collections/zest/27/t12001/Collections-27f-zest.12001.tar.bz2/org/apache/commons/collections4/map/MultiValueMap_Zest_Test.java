package org.apache.commons.collections4.map;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiValueMap_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13]}\012",
        Z.run(T, 1, 13, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389994625, 8651310665172324538L, 24158L, true, false, (char) 4152, (char) 44409,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\udabf\udc83\ud89b\udd22\udaf0\uddfe\udbb5\udc14\udb83\udf5a\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a6\u6322\u8347\u2c45\ucac1\u8552\u60ee\u8315\u8185\u0861\u10ea]}\012",
        Z.run(T, 1, 13, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\udabf\udc83\ud89b\udd22\udaf0\uddfe\udbb5\udc14\udb83\udf5a\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u2c45\ucac1\u8552\u60ee\u8315\u8185\u0861\u10ea", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        8, 71657, -389994625, 8651310665172324538L, -67993L, false, true, (char) 51951, (char) 54244,
        Double.longBitsToDouble(0x3fd33f30441306e0L), Double.longBitsToDouble(0x3fd3ea140c2642acL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 15, 7, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udb13\ude71\udad0\uded0\ud981\udea7\uda0f\udffb\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u5348\u8347\u5c53\u2a03\u3f2c\u1ab6\u7171\u09a8\u18c3\u4c13", "\uda31\udce3\udb42\udf98",
        2, 67998, 1429252337, -1675014157976493769L, -65842L, false, true, (char) 54244, (char) 4152,
        Double.longBitsToDouble(0x3fe04c1b853ea140L), Double.longBitsToDouble(0x3fe0990ab6945c20L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap:{}\0121=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 10, 10, 2, "\ud998\udf2d\uda10\udcd3\udbda\udfd7\ud829\udf90\ud89e\udf87\ud81f\udc8f\udb07\udd0b\udb17\uddf8\udbd7\udfbf\ud830\udc6e\ud90d\udd60\udb8a\udf6a\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8cc\udfd3\uda2f\ude6d", "\u6feb\u215a\u6322\u8347\u1ed6\u95b2\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        18, 337, 1733869618, 8651310819791147194L, 23143L, true, true, (char) 51951, (char) 54244,
        Double.longBitsToDouble(0x3fd33f30441306e0L), Double.longBitsToDouble(0x3fd3e4f19c2688acL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 13, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udadd\uded9\uda8e\uddb4\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u6322", "\ud880\udd1b\uda3c\udee4\ud91d\udda0\ud8d1\ude8e\udadd\udfb1\uda41\udd3e\udbf4\udcae\uda92\udf01\ud84b\udff0\uda31\udce3\udb42\udf98\udb8c\udf58\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud912\udc4a\udb18\udf04",
        35, 73295, -1343357575, 4453526776702080535L, -71821L, false, false, (char) 49465, (char) 4351,
        Double.longBitsToDouble(0x3fd9d4512efbe092L), Double.longBitsToDouble(0x3fe4a4cc93f01e1dL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udbfa\uddc0\uda44\udf39\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud862\udf99\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u5c53\ucb34\u022a\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389994625, 8651310665173508016L, -69306L, true, true, (char) 51951, (char) 54244,
        Double.longBitsToDouble(0x3fd33f30441306e0L), Double.longBitsToDouble(0x3fd3ea140d12f9e6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\ucf60\u280a\u91b3\u9128\ud344\u39a9\uc5c7\u18e6\ubd69\u5ab4\u4dbd\u1aae\u093f\u3510\u8106\u58e8\uaea7\u47fa\ub695\u9718\ud7f4\ub999\u1f35 |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3=[\ucf60\u280a\u91b3\u9128\ud344\u39a9\uc5c7\u18e6\ubd69\u5ab4\u4dbd\u1aae\u093f\u3510\u8106\u58e8\uaea7\u47fa\ub695\u9718\ud7f4\ub999\u1f35]}\012",
        Z.run(T, 1, 12, 14, 2, "\uda46\uddb3", "\ucf60\u280a\u91b3\u9128\ud344\u39a9\uc5c7\u18e6\ubd69\u5ab4\u4dbd\u1aae\u093f\u3510\u8106\u58e8\uaea7\u47fa\ub695\u9718\ud7f4\ub999\u1f35", "\udb93\uddbd\u08fd\ud87d\udfe4\uda7e\udccb\ud880\udd83\uda3c\udee4\uda53\udd9b\ud8d1\ude8e\udaad\udcd9\udae5\ude09\ud988\udc76",
        40, 34160, 1674292994, -3626023801314306874L, -75735L, false, false, (char) 63112, (char) 23415,
        Double.longBitsToDouble(0x3fdf91e676055fdaL), Double.longBitsToDouble(0x3fb28f73a99f9880L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 3, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\udb95\udc60\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc9\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u3cf1\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud912\udc4a\udb18\udf04\ud887\ude9a\udace\uded1\u38c1\ud991\udea6\ud85f\udd53\udb17\udddb\uda1f\udc73\udbe9\udf34\udb78\udf80\udb0e\udf31",
        19, 62992, 1573115793, -5553129829288693466L, -58581L, true, true, (char) 26166, (char) 54695,
        Double.longBitsToDouble(0x3fd505c4db2f9e2eL), Double.longBitsToDouble(0x3fe64854a5a0d08eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.EmptyIterator:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 8, 0, 7, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\ud8c5\udfeb\uda44\udeb2\udba7\udd7b", "\ubd69\u5ab4\u4dbd\u1aae\u09cd\u3510\u8106\u58e8\u7ce2\ubed2\ub695\u9718\ud7f4\uc899\u1f35", "\udb93\uddbd\u08fd\ud9a1\udeb6\uda71\udc53\ud880\udd1b\uda3c\udee4\ud971\udf38\ud8d1\ude8e\udadd\udfb1\uda41\udd3e\udbf4\udcae",
        28, 34160, 1674292994, -3626023801314306874L, -75735L, false, false, (char) 63112, (char) 23415,
        Double.longBitsToDouble(0x3fd791e676055fdaL), Double.longBitsToDouble(0x3fe0b9ee7533f304L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 9, 12, 2, "\uda46\uddb3\uda10\udcd3\ud98e\udc4a\udbe7\udd3d\ud9fc\ude76\udbc0\udce0\ud814\udc8e\ud8b5\udef0\udba7\udd7b\ud830\udc6e\udb0a\udc3f\uda49\udc52\uda54\udd87\ud88f\udcb5\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\udaae\udef0\udb8d\udee8\udaae\udf02\udaa9\udca2\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u9363\u9c0b\u8347\u5c53\u2a03\u3f2c\u6410\ubcf8\u81ad\u7f6e\u064a", "\uda31\udd3f\udb42\udf98\udb8c\udf58\uda9b\ude4f\ud88d\ude01\ud90d\ude20\ud912\udca7\udb18\udf04\ud881\uddba\udace\uded1\u38c1\udba9\udeeb",
        54, 86507, -1589630455, 2402368303338122771L, -5052L, false, true, (char) 53780, (char) 34612,
        Double.longBitsToDouble(0x3f9f1910df12a420L), Double.longBitsToDouble(0x3fc3541af5fee778L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap$1:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 7, 7, 4, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udb45\udc1c\ud99c\udf80\udabf\udff3\u6ac3\ud981\udd18\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389994625, 8651310666598387898L, 24158L, true, false, (char) 24237, (char) 44304,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 10, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\ud8e8\udfc8\ud856\udf13\ud8ae\udca5", "\u6560\u5425\uc0df\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13\u16a0\u812f\ud694\uc2eb\u60fb\u3d16", "\ud912\udc4a\udb18\udf04\ud887\ude9a\udace\uded1",
        20, 50506, -217803241, -8975641954545030647L, -71821L, false, false, (char) 49465, (char) 14716,
        Double.longBitsToDouble(0x3fdc84b64f0ecd6cL), Double.longBitsToDouble(0x3fee8280725079cdL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 1, 0, 15, "\uda46\uddb3\uda10\udcd3\uda43\udf26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\ud9b6\udff9\uda07\udf52\udb8e\udfb2\ud830\udc6e\udb0a\udc3f\ud8e1\ude34\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\ub5fa\ua879\u6322\u8347\u5c53\u2a03", "\ud8d1\ude8e\udadd\udfb1\uda41\udd3e\udbf4\udcae\ud91e\ude87\u5814\udaf6\udfa6\ud967\udf1d\udb8c\udf6c\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud912\udc4a\udb18\udf04\ud887\ude9a\udace\uded1",
        20, 50506, -217803241, -8975641954058491383L, -71821L, false, false, (char) 49465, (char) 33001,
        Double.longBitsToDouble(0x3fa845cf81730de0L), Double.longBitsToDouble(0x3febba7805eb914eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.HashMap$EntrySet:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 5, 14, 2, "\uda4e\udeb3\udbdf\udefc\ud936\ude34\udbe7\udd3d\ud89e\udf87\uda4d\udc65\udb07\udd0b\udb64\udc75\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\ud931\ude67\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\udab1\udf54\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u7974\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\ua5c0\uc570\u65bc\u6d05", "\ud928\udff1\udb23\udf34\udb8c\udf58\u6ace\ud8b7\uddf3\ud90d\ude20\udaee\ude57\udb18\udf04\ud887\ude9a\udbc4\udecd\udb4d\udc09",
        -4, 52759, -1325941709, -6827410816391254722L, -18710L, true, false, (char) 26776, (char) 6001,
        Double.longBitsToDouble(0x3fc7306c232931b0L), Double.longBitsToDouble(0x3fe0515dedc0e4a6L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 15, 9, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f", "\u39a9\uc5c7\u18e6\u120b\u5ad4", "\udbb5\udc14\ud99c\udf80\udabf\udff3",
        25, 85576, -1771633374, 2787860914570086276L, -22510L, false, true, (char) 62191, (char) 58868,
        Double.longBitsToDouble(0x3fec955b4ccfd62fL), Double.longBitsToDouble(0x3fe6ab39f4992f6aL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 6, 15, 1, "\uda46\uddb3\uda10\udcd3\udb61\udd20\udbe7\udd3d\ud89e\udf87\ud81f\udc8f", "\u19a9\uc5c7\u18e6\ubd69\u5ab4", "\udbb5\udc14\ud99c\udf80\udabf\udff3\udb7a\udc24\ud992\ude26\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d\udb6f\udc80\udb05\udcdd",
        21, 6326, 1920817671, -8359735653106623833L, 15505L, true, false, (char) 52226, (char) 7667,
        Double.longBitsToDouble(0x3fe643288040a1e5L), Double.longBitsToDouble(0x3fed2ff1b09830f0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 9, 10, 2, "\uda87\uddd3\udbdf\ude1c\uda45\udd32\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc12\ud99c\udf80\udabf\udff3\ud8c8\udf15\udbd9\udf96\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\ud9dd\udfa7\udb42\udf98\udb8c\udf58",
        38, 337, -389994625, 8651310665172324538L, 24158L, true, false, (char) 4152, (char) 44409,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 2, 1, 2, "\uda46\uddb3\uda10\udcd3\ud9f5\udc48\udbe7\udd3d\ud865\ude9c\ud84a\udcbc\udb07\udd0b\uda44\udedc\ud893\udf31\udad1\uddc2\udaac\udc88\ud8e6\ude2b\ud910\udea0\uda37\udea2\ud921\udcb8\ud9de\udd02\ud99c\udf7c\udb5f\udc38\ud892\uddd4\ud809\udff0\ud8fb\udfaf\udaae\udf02\udafc\udd19\ud8f2\uddc7\udb2e\udf93", "\u40dc\ua895\u4818\u0cd9\u974b\uce24\ub3c0\ua794\uc6a0\u94a2", "\uda41\ude85\u4814\ud8ab\udfe1\uda6d\udfef\udb8c\udf58\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud912\udc4a\udb18\udf04\ud887\ude9a\udace\uded1",
        20, 50506, -217803241, -8975641954058491383L, -71821L, true, false, (char) 23097, (char) 50990,
        Double.longBitsToDouble(0x3fd1d7d38e921010L), Double.longBitsToDouble(0x3f9b26a5c1f53ce0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 14, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\udac8\ude71\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb85\udc39\ud910\uddf9\uda37\udea2\udb5f\ude06\ud836\uddc9\ud8a8\udf51\udbf3\ude58\ud8a7\udc17\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\ua1f9\uab35\u5c70\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389994625, 8651310665172324538L, 24158L, true, false, (char) 60476, (char) 9767,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13]}\0121=void |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13]}\012",
        Z.run(T, 2, 13, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389994625, 8651310665172324538L, 24158L, true, false, (char) 4152, (char) 44409,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 4, 14, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda30\ude60\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udb77\udf3a\ud8f1\uddba\uda0e\udcea\ud974\udf94\ud8b5\ude91\uda8e\udde1\ud8f2\uddc7\uda24\ude66", "\u6feb\u49a6\u6322", "\ud880\udd1b\uda3c\udee4\ud91d\udda0\ud8d1\ude8e\udadd\udfb1\uda41\udd3e\udbf4\udcae\ud91e\ude87\u4814\uda31\udce3\udb42\udf98\udb8c\udf58\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud912\udc4a\udb18\udf04",
        35, 73295, -1343357575, 4453526776702080535L, 26366L, true, true, (char) 49496, (char) 34945,
        Double.longBitsToDouble(0x3feea5342b2b510dL), Double.longBitsToDouble(0x3fdcb08dfb127c04L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\ud8d3\udeea\udbbc\udf42\uda45\udd26\udbe7\udd3d\ud89e\udf87\u21d6\udb1e\uddcb\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\ud87e\udf2e\ud9be\udc02\ud86e\udc7e\ud84e\udc4a\udb8f\udee3\ud92d\udf18\uda59\udf21\ud8a6\udf9b\udbf6\udc44\ud83c\udd15\ud9a6\uddb3\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a5\u6322\u6373\u5c53\u2a03\u16c2\u1b07\u2e49\u8185\u7f6e\u58bf]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\ud8d3\udeea\udbbc\udf42\uda45\udd26\udbe7\udd3d\ud89e\udf87\u21d6\udb1e\uddcb\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\ud87e\udf2e\ud9be\udc02\ud86e\udc7e\ud84e\udc4a\udb8f\udee3\ud92d\udf18\uda59\udf21\ud8a6\udf9b\udbf6\udc44\ud83c\udd15\ud9a6\uddb3\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a5\u6322\u6373\u5c53\u2a03\u16c2\u1b07\u2e49\u8185\u7f6e\u58bf]}\012",
        Z.run(T, 2, 13, 3, 15, "\ud8d3\udeea\udbbc\udf42\uda45\udd26\udbe7\udd3d\ud89e\udf87\u21d6\udb1e\uddcb\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\ud87e\udf2e\ud9be\udc02\ud86e\udc7e\ud84e\udc4a\udb8f\udee3\ud92d\udf18\uda59\udf21\ud8a6\udf9b\udbf6\udc44\ud83c\udd15\ud9a6\uddb3\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a5\u6322\u6373\u5c53\u2a03\u16c2\u1b07\u2e49\u8185\u7f6e\u58bf", "\uda31\udce3\udb42\udf98\ud8ef\udf38\uda49\ude46\ud80e\udef4\ud909\udfff\ud912\udc4a\udb18\udf04\ud887\ude9a\uda30\udcbc\udaee\udc0f\ud916\udf96\ud85f\udd53\udba5\ude61\uda1f\udcda\ud83d\udf47\uda13\udf92\uda35\ude95\udb36\udc4f",
        56, 34893, -1922224881, -5210220711057066166L, 95449L, true, true, (char) 55496, (char) 9069,
        Double.longBitsToDouble(0x3fd95f8833ef66a4L), Double.longBitsToDouble(0x3fe254f4e17326fcL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.EmptyIterator:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=org.apache.commons.collections4.map.MultiValueMap$1:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 8, 7, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb95\udf24\ud8ae\udca9\ud910\uddf9\uda37\udea2\udb13\ude71\udad0\uded0\ud981\udea7\uda0f\udffb\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u5348\ua0e6\u5c26\u2a03\u3f2c\u1ab6\u7171\u09a8\u18c3\u4c13", "\uda15\udf5e\udb42\udf98",
        2, 67998, 1429252337, -1675014157976493769L, -65842L, false, true, (char) 3925, (char) 49492,
        Double.longBitsToDouble(0x3fd098370a7d42e0L), Double.longBitsToDouble(0x3fe0990ab6945c20L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap:{}\0121=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 10, 10, 2, "\ud998\udf2d\uda10\udcd3\udbda\udfd7\ud829\udf90\ud89e\udf87\ud81f\udc8f\udb07\udd0b\udb17\uddf8\udbd7\udfbf\ud830\udc6e\ud90d\udd60\udb8a\udf6a\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b", "\ub695\u9718\u2602\ub999\u1f35\uad0a\u6feb\u215a\u6322\u8347\u1ed6\u95b2\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13\u99a5\ubf1d\u3d49\uc2eb\u60fb\u9856\ua5e8\u9aae\u0fa7\ubdee", "\u38c1\ud991\udea6\ud85f\udd53\udb17\udddb\ud91f\udeb2\u2945\u7855\ud9a1\uddbf\uda9d\ude2d",
        38, 18723, 2070930342, 790378415963828706L, 51195L, false, true, (char) 34410, (char) 18319,
        Double.longBitsToDouble(0x3fe61f1bdd852818L), Double.longBitsToDouble(0x3fea8e2a128af528L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.EmptyIterator:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=org.apache.commons.collections4.iterators.EmptyIterator:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 8, 8, 15, "\u3fc9\udb81\udde0\udb01\udf62\ud829\udf90\ud89e\udf87\ud81f\udc8f\udb07\udd0b\udb17\uddf8\udbd7\udfbf\ud830\udc6e\ud9a2\udeea\udb8a\udf6a\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8bf\udf0d\uda3c\uddde", "\u6feb\u215a\ua793\uc295\u6f28\u95b2\u3f2c\ub306\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udbd3\udffc",
        14, 8207, -1038602208, -3696578250489393031L, 7783L, true, true, (char) 51951, (char) 54244,
        Double.longBitsToDouble(0x3fd33f30441306e0L), Double.longBitsToDouble(0x3fd3e4f19c2688acL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 0, 2, "\u66d6\udaef\udf2f\ud97e\ude6a\uda0e\udf8c", "\u9128\ua261\uc8d3\u8b2a\u1748\uc420\u27f3\u6088", "\ud9c5\udcbd\udabf\udff3\ud8a6\udf9b",
        16, 6626, 649099451, -5761432665996639304L, -87024L, false, false, (char) 4220, (char) 63168,
        Double.longBitsToDouble(0x3fea19c7b5979786L), Double.longBitsToDouble(0x3fe53c5a6f425b47L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 3, 3, 0, "\ud998\udf2d\uda10\udcd3\udbda\udfd7\ud829\udf90\ud89e\udf87\ud81f\udc8f\udb07\udd0b\udb17\uddf8\udbd7\udfbf\ud830\udc6e\ud90d\udd60\udb8a\udf6a\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8cc\udfd3\uda2f\ude6d", "\u6feb\u215a\u6322\u8347\u1ed6\u95b2\u3f2c\u1b07\u8315", "\udbf4\udcae\ud91e\ude87\u4814",
        44, 8544, 1871484102, -672404796938868495L, 31719L, false, true, (char) 54244, (char) 4152,
        Double.longBitsToDouble(0x3fe04c1b853e4f19L), Double.longBitsToDouble(0x3fe09a22b5e9a845L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 1, 1, 2, "\ud998\udf2d\uda10\udcd3\udac7\uded0\ud829\udf90\ud8a2\udf7b\ud81f\udc38\udb07\udd0b\udb17\uddf8\udbd7\udfbf\udb11\udf72\ud90d\udd60\udb8a\udf6a\ud910\uddf9\uda37\udea2\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\udb38\udd04\ud89f\udc62\udaae\ude6b\uda8e\udde1\ud8cc\udfd3\uda2f\ude6d", "\u6feb\u215a\u6322\u8347\u1ed6\u95b2\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        18, 337, 1733869618, 8651310819791147194L, 23143L, true, true, (char) 51951, (char) 54244,
        Double.longBitsToDouble(0x3fd33f30441306e0L), Double.longBitsToDouble(0x3fd3e4f19c2688acL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 11, 2, "\ud91b\ude96\uda10\udd4a\ud9d8\udf56\ue9ef\ud85a\udf85\ud81f\udc8f\udb07\udd0b\udb17\uddf8\udbd7\udfbf\ud830\udc6e\ud90d\udd60\udb8a\udf6a\ud910\uddf9\ud841\udc47\udaf0\ude6c\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\ud860\ude0b\ud9c2\udd22\uda2f\ude6d", "\u6feb\u215a\u6322\u8347\u1ed6\u8ecd\u61fd\uc5dc\uab5f\u6c63\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        59, 23389, 907047600, 8651310819791147194L, 23143L, true, true, (char) 51951, (char) 54244,
        Double.longBitsToDouble(0x3fd33f30441306e0L), Double.longBitsToDouble(0x3fd3e4f19c2688acL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap$1:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=org.apache.commons.collections4.map.MultiValueMap$1:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 7, 7, 4, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud94c\ude06\udb40\udd07\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb0a\udc3f\udb6a\udd39\ud910\uddf9\uda37\udea2\udaf0\uddfe\udb45\udc1c\ud99c\udf80\udabf\udff3\u6ac3\ud981\udd18\udb8d\udee8\udaae\udf02\uda8e\udde1\ud951\udd73\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\udaa2\ude3c\ud9d0\udc35\udb8c\udf06",
        38, 337, -389994625, 8651310666598387898L, 24158L, true, false, (char) 24237, (char) 44304,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.String:\u39a9\uc5c7\u18e6\u1ec8\u3f8f |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f=[\u39a9\uc5c7\u18e6\u1ec8\u3f8f]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 12, 15, 13, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f", "\u39a9\uc5c7\u18e6\u1ec8\u3f8f", "\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d\ud8ec\udf40\udb8c\uddda\ud9d0\udd8f",
        59, 19232, -1957851753, -4046461446732663918L, 35893L, true, false, (char) 42396, (char) 44781,
        Double.longBitsToDouble(0x3fcd438dcdd5835cL), Double.longBitsToDouble(0x3fd9a98b926f829cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 15, 15, 9, "\uda46\uddb3\udac2\udfb0\ud967\ude26\u37b3\ud89e\udf87", "\ud344\u39a9", "\uda0a\uddeb\ud910\ude19\u6e36\ud35e\udba0\udfc6\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udba0\udcb8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\ud969\udee3\udb8c\udf80",
        13, 30001, 126538062, 7303046187820354967L, -80434L, true, false, (char) 4861, (char) 60761,
        Double.longBitsToDouble(0x3fbd55d694ffeb68L), Double.longBitsToDouble(0x3fe023789ec2f2fcL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 14, 14, 9, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f", "\u39a9\uc5c7\u18e6\u120b\u5ad4\u4dbd\u1aae\u09cd\u3510\u20b3\u5def\u0e9e\u47fa\ub695\u9718\ud7f4\ub999\u1f35\uad0a", "\u08fd\ud9a1\udeb6\u7dac\ud880\udd1b\uda3c\udee4\ud91d\udda0\uda28\udd78\ud882\uddd1\udb01\udf90\ud99c\udff0\ud9f5\udf2c\udb8f\udd83\udb88\udfb0\uda0f\ude78",
        58, 31347, 1518033080, -1390782880689243000L, 11192L, false, true, (char) 39073, (char) 24895,
        Double.longBitsToDouble(0x3fdbfd62ec2d909cL), Double.longBitsToDouble(0x3f91203352dae500L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\udac2\udcf1\udbe7\udcc1\ud944\udec9\ud81f\udc8f=[\u0c87\u0cb4\u7bcc\u916f\ucb9a]}\012",
        Z.run(T, 2, 4, 13, 1, "\uda46\uddb3\uda10\udcd3\udac2\udcf1\udbe7\udcc1\ud944\udec9\ud81f\udc8f", "\u0c87\u0cb4\u7bcc\u916f\ucb9a", "\udba1\udc14\ud99c\udf80\udabf\udff3\udb7a\udc24\ud992\ude26\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d\udb6f\udc80\udb05\udcdd",
        21, 6326, 529662262, -145005036103443801L, 15505L, true, false, (char) 52226, (char) 9375,
        Double.longBitsToDouble(0x3fefe4f81840a1e5L), Double.longBitsToDouble(0x3fed2ff1b09830f0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\ude3c\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a6\u5dcc\u35e1\ua4be\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13]}\0121=org.apache.commons.collections4.map.MultiValueMap$ValuesIterator:@? |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\ude3c\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a6\u5dcc\u35e1\ua4be\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13]}\012",
        Z.run(T, 2, 13, 8, 11, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\uda8e\ude3c\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u5dcc\u35e1\ua4be\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\uda36\udc31\ud995\ude66",
        53, 337, -389994625, 8651310665172324538L, 24158L, true, false, (char) 4152, (char) 16263,
        Double.longBitsToDouble(0x3fe09a2756132156L), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\ud91c\udd13\uda10\udcd3\uda45\udd26\udbe7\udd3d\u6727\ud81f\udd0a\uda47\udf1e\ud9d0\udc76\udb84\udc7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda1e\udc45\uda4f\udd8b\udb15\udf72\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d=[\u5601\u49a6\u6322\u8347\u81e4\u25a1\u69ed\ube98\ua86b\u8135\u7f6e\u4c13]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\ud91c\udd13\uda10\udcd3\uda45\udd26\udbe7\udd3d\u6727\ud81f\udd0a\uda47\udf1e\ud9d0\udc76\udb84\udc7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda1e\udc45\uda4f\udd8b\udb15\udf72\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d=[\u5601\u49a6\u6322\u8347\u81e4\u25a1\u69ed\ube98\ua86b\u8135\u7f6e\u4c13, \u5601\u49a6\u6322\u8347\u81e4\u25a1\u69ed\ube98\ua86b\u8135\u7f6e\u4c13]}\012",
        Z.run(T, 2, 13, 13, 2, "\ud91c\udd13\uda10\udcd3\uda45\udd26\udbe7\udd3d\u6727\ud81f\udd0a\uda47\udf1e\ud9d0\udc76\udb84\udc7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda1e\udc45\uda4f\udd8b\udb15\udf72\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d", "\u5601\u49a6\u6322\u8347\u81e4\u25a1\u69ed\ube98\ua86b\u8135\u7f6e\u4c13", "\uda31\udce3\ud8a8\udcf1\udb8c\udf83",
        38, 337, -389994625, 1705543979404837760L, -24972L, false, true, (char) 51936, (char) 7909,
        Double.longBitsToDouble(0x3fdc9f30441306e0L), Double.longBitsToDouble(0x3fd3ea140c2642acL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\udac4\udccd\uda45\udd26\udbe7\udd3d\ud89e\udf87\udb90\udda7\ud92e\ude8c\uda44\ude96\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\ud8a3\ude4e\ud8f2\udd47\uda40\ude05=[\u6feb\ud1e3\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13]}\0121=java.lang.String:\u6feb\ud1e3\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13 |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\udac4\udccd\uda45\udd26\udbe7\udd3d\ud89e\udf87\udb90\udda7\ud92e\ude8c\uda44\ude96\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\ud8a3\ude4e\ud8f2\udd47\uda40\ude05=[\u6feb\ud1e3\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13, \u6feb\ud1e3\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13]}\012",
        Z.run(T, 2, 13, 12, 2, "\uda46\uddb3\udac4\udccd\uda45\udd26\udbe7\udd3d\ud89e\udf87\udb90\udda7\ud92e\ude8c\uda44\ude96\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\ud8a3\ude4e\ud8f2\udd47\uda40\ude05", "\u6feb\ud1e3\u6322\u8347\u5c53\u2a03\u3f2c\u1b07\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389994625, 8651310665172324538L, 24158L, true, true, (char) 40083, (char) 44319,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud955\uddec\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\uda9f\udd02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a6\u1405\u13a2\u5c53\u2a03\u3f2c\uaa31\u8315\u8185\u7f6e\u4c13]}\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud955\uddec\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\uda9f\udd02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[\u6feb\u49a6\u1405\u13a2\u5c53\u2a03\u3f2c\uaa31\u8315\u8185\u7f6e\u4c13]}\012",
        Z.run(T, 2, 13, 2, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udaf0\uddfe\udbb5\udc14\ud955\uddec\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\uda9f\udd02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u1405\u13a2\u5c53\u2a03\u3f2c\uaa31\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389994625, 8651310665172324538L, 20574L, true, false, (char) 4152, (char) 44409,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=null |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 6, 6, 1, "\ud937\ude1b\udbe8\udfe4\ud868\udd92", "\ua346\u15e9\ud344\u39a9\ubd93", "\ud9be\udc02\udba5\udc7f\ud84e\udc4a\uacf2\ud907\udf2d\udb49\udebb\ud811\udc5b\udbf6\udc18\ud83c\udd15\ud9a6\uddb3\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d\udbf2\ude3b\udabb\uded9\ud825\udff5\ud937\udc5a\udb55\ude35\uda65\udeb8\uda6c\udefc\ud880\udd1b\udbec\uddaf\ud91d\udcd6\uda13\udd01\ud909\uddba",
        42, 78894, 929622891, 9151424468668362498L, -9021L, false, true, (char) 48900, (char) 31883,
        Double.longBitsToDouble(0x3fd3780c1174f01eL), Double.longBitsToDouble(0x3feb1cf92c637a70L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 9, 2, "\ud9ab\ude9d\udaef\udfcc\ud97e\ude6a\uda0e\udf8c", "\u9128\ua261\uc8d3\u8b2a\u1748\uc420\u27f3\u6088", "\ud9c5\udcbd\udabf\udff3\ud8a6\udf9b",
        16, 6626, 649099451, -5761432665349798984L, 78023L, true, true, (char) 4133, (char) 63168,
        Double.longBitsToDouble(0x3fea19c7b5979786L), Double.longBitsToDouble(0x3fe53c5a6c425b47L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 13, 13, 2, "\ud91c\udd13\uda10\udcd3\uda45\udd26\udbe7\udd3d\u6727\ud81f\udd0a\ud967\uddcf\udae4\ude4c\udaf6\udd1e\ud830\udc0c\ud8e9\udfcf\u6e9b\uda1e\udc45\udbc3\ude1f\udab9\udd89\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d", "\u5601\u49a6\u80c2\u58ee\u009b\u25a1\u69ed\ube98\ua86b\u8135\u03c4\uc92e", "\uda31\udce3\ud8a8\udcf1\udb8c\udf83",
        38, 337, -389966465, 1705543979404837760L, -24972L, true, false, (char) 51511, (char) 7909,
        Double.longBitsToDouble(0x3fdc9f30441306e0L), Double.longBitsToDouble(0x3fd3ea140c2642acL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:\u381e\u6cde\u3246\u8347\u8274 |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\ud8cf\udd14\uda45\udd26\udbe7\udd3d\ud89e\udf87\udb90\udda7\ud92e\ude8c\uda44\ude96\udba7\udd7b\ud82f\udfa6\ud8e9\udfcf\uf122\u623b\ud8a3\ude03\udaf0\ude93\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\ud8a3\ude4e\ud8f2\udd47\ud860\udf15=[\u381e\u6cde\u3246\u8347\u8274]}\0121=java.lang.String:\u381e\u6cde\u3246\u8347\u8274 |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\ud8cf\udd14\uda45\udd26\udbe7\udd3d\ud89e\udf87\udb90\udda7\ud92e\ude8c\uda44\ude96\udba7\udd7b\ud82f\udfa6\ud8e9\udfcf\uf122\u623b\ud8a3\ude03\udaf0\ude93\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\ud8a3\ude4e\ud8f2\udd47\ud860\udf15=[\u381e\u6cde\u3246\u8347\u8274, \u381e\u6cde\u3246\u8347\u8274]}\012",
        Z.run(T, 2, 12, 12, 2, "\uda46\uddb3\ud8cf\udd14\uda45\udd26\udbe7\udd3d\ud89e\udf87\udb90\udda7\ud92e\ude8c\uda44\ude96\udba7\udd7b\ud82f\udfa6\ud8e9\udfcf\uf122\u623b\ud8a3\ude03\udaf0\ude93\udbb5\udc14\ud99c\udf80\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udaae\udf02\ud8a3\ude4e\ud8f2\udd47\ud860\udf15", "\u381e\u6cde\u3246\u8347\u8274", "\ud91d\udda0\ud8d1\ude8e\udb59\ude14\ud801\udefe\udb67\udea7\ud9a3\udd16\ud98d\udc68\uda0f\udefe",
        49, 88758, -1448270941, 6138592044756576127L, 64205L, false, true, (char) 28552, (char) 7136,
        Double.longBitsToDouble(0x3fe8157f6b173dceL), Double.longBitsToDouble(0x3fd829711413062cL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 2, 2, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbfa\ude2e\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda27\udee5\uda4f\udd8b\udb68\udc04\udbb5\udc14\ud955\uddec\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\uda9f\udd02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\ubfea\u1405\u13a2\u5c53\u2a03\u3f2c\uaa31\u8315\u8185\u8203\u4be4", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389952186, 8651310665172324538L, 20574L, true, false, (char) 30655, (char) 44409,
        Double.longBitsToDouble(0x3fd3ea140c2642acL), Double.longBitsToDouble(0x3fe4a2e102e44e55L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\ud988\ude75\uda20\udf26\udaf0\uddfe\udbb5\udc14\ud955\uddec\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\uda9f\udd02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[null]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\ud988\ude75\uda20\udf26\udaf0\uddfe\udbb5\udc14\ud955\uddec\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\uda9f\udd02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d=[null]}\012",
        Z.run(T, 2, 12, 2, 2, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\ud8e9\udfcf\u6e9b\ud988\ude75\uda20\udf26\udaf0\uddfe\udbb5\udc14\ud955\uddec\udabf\udff3\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\uda9f\udd02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u1405\u13a2\u5c53\u2a03\u3f2c\uaa31\u8315\u8185\u7f6e\u4c13", "\uda31\udce3\udb42\udf98\udb8c\udf58",
        38, 337, -389957505, 8651310665172324538L, 23911L, false, true, (char) 55362, (char) 54244,
        Double.longBitsToDouble(0x3fd2d830444bb2e0L), Double.longBitsToDouble(0x3fd3ea140c2642acL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.map.MultiValueMap:{}\0121=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 9, 9, 2, "\ud9ab\ude9d\udaef\udfcc\ud97e\ude6a\uda0e\udf8c", "\ua8dc\uc445\u2958\ubbea\u1769\uc420\u27f3\u6088", "\ud9c5\udcbd\udabf\udff3\ud8a6\udf9b",
        16, 6626, 1571846331, -5761432390471892040L, 78023L, true, true, (char) 4133, (char) 59247,
        Double.longBitsToDouble(0x3fea19c7b5979786L), Double.longBitsToDouble(0x3fe0a4005c42e907L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 1, 13, 7, 8, "\uda46\uddb3\uda10\udcd3\uda45\udd26\udbe7\udd3d\ud89e\udf87\ud81f\udc8f\udb07\udd0b\uda44\ude6f\udba7\udd7b\ud830\udc6e\udb48\udc5d\udbdf\udf6c\ud8e8\udc9e\uda37\udea2\udaf0\uddfe\ud9ba\udf76\ud99c\udede\udabf\udff3\ud8a6\udf9b\ud992\uddf2\ud9ce\ude08\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d", "\u6feb\u49a6\u6322\u8347\u33c8\u5da1\u0d1e\u1a5c\u8315\u6c85\u7f6e\u4c13", "\uda16\udf8f\udb42\udf98\udb8c\udf58",
        -3, 86122, -394804802, 8651310665172324538L, 24158L, true, false, (char) 4152, (char) 44409,
        Double.longBitsToDouble(0x3fd3ea140e36387aL), Double.longBitsToDouble(0x3fe59581e2e48bd6L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.util.ArrayList:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 4, 4, 1, "\uda46\udd5d\uda10\udcd3\udac2\udcf1\udbe7\udcc1\ud944\udec9\ud81f\udc8f", "\u0c87\u2922\u7bcc\u916f\ucb9a", "\udba1\udc14\ud99c\udf80\udabf\udff3\udb7a\udc24\ud992\ude26\udb8d\udee8\udaae\udf02\uda8e\udde1\ud8f2\uddc7\uda2f\ude6d\udb6f\udc80\udb05\udcdd",
        7, 6326, -686161610, -145222812420187481L, 15505L, true, false, (char) 52226, (char) 9375,
        Double.longBitsToDouble(0x3fefa700de026ceeL), Double.longBitsToDouble(0x3fec03c9b0663cc8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.util.HashMap$EntrySet:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.util.HashMap$EntrySet:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 5, 5, 2, "\ud8e8\udeac\uda0c\udd5c\uda45\udd26\udbe7\udd39\u6727\ud81f\udd0a\ud967\uddcf\udae4\ude4c", "\u780f", "\udbc3\ude1f\udab9\udd89\ud971\udf78\ud9ec\udd62\udb47\udd76\udb0e\uddc5\udaef\udd08\ud9ca\udced\ud8e4\ude0f\ud811\udf50\ud8f2\uddc7\uda2f\ude6d",
        14, 52076, -1893721271, 1027264389320813494L, -67395L, false, true, (char) 63982, (char) 16881,
        Double.longBitsToDouble(0x3fef117b516d3279L), Double.longBitsToDouble(0x3fe3632880831f82L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.util.ArrayList:[] |this=org.apache.commons.collections4.map.MultiValueMap:{}\012",
        Z.run(T, 2, 4, 4, 15, "\uda6f\udf57\uda3b\udf59\uda45\udd26\udbe7\udd3d\ud89e\udf87\u21d6\udb1e\uddcb\ud86b\udfc1\udba7\udd13\ud830\udc6e\udb0a\udc3f\ud87e\udf2e\ud9be\udc02\ud86e\udc7e\ud84e\udc4a\udb8f\udee3\ud92d\udf18\uda59\udf21\ud8a6\udf9b\udbf6\udc44\ud83c\udd15\uda43\ude97\ud90b\udee1\ud944\udc44\uda17\udd5b", "\u9583\u0d9f\u6322\u6373\u5c53\u2a03\u16c2\u1b07\u7b38\u8185\u7f6e\u58bf", "\uda4b\udcd3\udbd8\udea6",
        17, 75454, 1426855409, -9169003939093562736L, 31719L, true, true, (char) 40005, (char) 4152,
        Double.longBitsToDouble(0x3fe380a0a554a140L), Double.longBitsToDouble(0x3fe09908a9f7196cL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.iterators.EmptyIterator:@? |this=org.apache.commons.collections4.map.MultiValueMap:{}\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\ud91c\udd13\uda10\udcd3\uda45\udd26\udbe7\udd3d\u3227\ud81f\udd0a\uda47\udf1e\ud9d0\udc76\udb84\udc7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda1e\udc45\uda4f\udd8b\udb15\udf72\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d\udb6f\udc80\ud92f\udc92\ud839\udd22\udb93\uddbd\udacb\udf2c\ud9a1\udeb6\ud925\ude54\udac5\udcdd\ud83f\udd16\ud946\udd31\ud9db\udf92\udadd\udf61\uda41\udd3e\udbf4\udcae\ud91e\ude87\u4814\uda31\udce3\ud8a8\udcf1\udb8c\udf83\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud88d\udfd4\ud9d8\udcc3\ud81c\udefd\uda4a\ude93\ud815\udc57\udaf8\udffb\ud85f\udd53\udb17\ude71\uda1f\udc73\udbe9\udf34\ud31f\ud934\ude60\ud81e\ude7d\ud995\udc7d\udba2\udda1\ud88b\udeb9\u91f0\ud8c5\udd91\ud8c2\udc48\ud9b9\udc37\uda2d\udcd7\udbee\udf35\ud871\ude44\ud948\udc01\ud96f\udf69\uda49\udedb\ud8ce\udcd2\ud9ff\udd95\ud868\udc2d\uda68\udc7e\ud98d\ude31\ud901\udc26\uda41\udf42\ud805\udc5a\udb18\udf47\udb54\udedd\udb4f\udee7\uda4b\uddd5\ud90b\udd6c\ub764\ud96a\ude61\uda82\ude67\ud9da\ude90\ud90e\ude92\udb74\udd6b\ud902\uddef\ud9f9\uddc8\ud9a6\udfe1\udb59\udc21\udbd6\udde8\udb85\udce8\ud996\udf0c\ud82b\udc00\udbd1\ude93\ud91d\udd3d\udbd3\udc1c\udbc9\udf9a\ud9ee\udf5e\ud813\udf38\udb20\udd51\uda90\udd90\ud90d\udd90\udb2b\udfe3\uda55\udf65\ud8ca\udece\udb10\udf2f\udae7\uddee\ud8e1\ude06\ud81b\udcf8\ud846\udf1d\udbf3\ude98\udb4a\udcf7\udbd8\udebd\udb1e\udd9c\ud895\ude6d\udaed\ude1b\uda8b\udd25\udadb\udce1\ud86d\udfda\ud9c7\udf38\ud81c\udcf3\u82db\ud8bd\ude01\udba0\ude53\ud9e9\udd75\ud9cf\udedc\udaa8\udefe\ud900\uded1\udbcc\udefc\uda40\uddaa\udbe9\udc18\udbb0\uddb0\ud853\udf3c\ud96d\udf36\ud89b\udde8\ud903\ude82\ud9c6\udd5d\uda20\udde2\ud813\udc20\ud917\ude38\udaf9\udee2\uda92\uddf9\uda03\udc72\udbb8\ude7d\udb06\udf45\ud847\udcad...\012",
        Z.run(T, 2, 8, 13, 2, "\ud91c\udd13\uda10\udcd3\uda45\udd26\udbe7\udd3d\u3227\ud81f\udd0a\uda47\udf1e\ud9d0\udc76\udb84\udc7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda1e\udc45\uda4f\udd8b\udb15\udf72\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d\udb6f\udc80\ud92f\udc92\ud839\udd22\udb93\uddbd\udacb\udf2c\ud9a1\udeb6\ud925\ude54\udac5\udcdd\ud83f\udd16\ud946\udd31\ud9db\udf92\udadd\udf61\uda41\udd3e\udbf4\udcae\ud91e\ude87\u4814\uda31\udce3\ud8a8\udcf1\udb8c\udf83\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud88d\udfd4\ud9d8\udcc3\ud81c\udefd\uda4a\ude93\ud815\udc57\udaf8\udffb\ud85f\udd53\udb17\ude71\uda1f\udc73\udbe9\udf34\ud31f\ud934\ude60\ud81e\ude7d\ud995\udc7d\udba2\udda1\ud88b\udeb9\u91f0\ud8c5\udd91\ud8c2\udc48\ud9b9\udc37\uda2d\udcd7\udbee\udf35\ud871\ude44\ud948\udc01\ud96f\udf69\uda49\udedb\ud8ce\udcd2\ud9ff\udd95\ud868\udc2d\uda68\udc7e\ud98d\ude31\ud901\udc26\uda41\udf42\ud805\udc5a\udb18\udf47\udb54\udedd\udb4f\udee7\uda4b\uddd5\ud90b\udd6c\ub764\ud96a\ude61\uda82\ude67\ud9da\ude90\ud90e\ude92\udb74\udd6b\ud902\uddef\ud9f9\uddc8\ud9a6\udfe1\udb59\udc21\udbd6\udde8\udb85\udce8\ud996\udf0c\ud82b\udc00\udbd1\ude93\ud91d\udd3d\udbd3\udc1c\udbc9\udf9a\ud9ee\udf5e\ud813\udf38\udb20\udd51\uda90\udd90\ud90d\udd90\udb2b\udfe3\uda55\udf65\ud8ca\udece\udb10\udf2f\udae7\uddee\ud8e1\ude06\ud81b\udcf8\ud846\udf1d\udbf3\ude98\udb4a\udcf7\udbd8\udebd\udb1e\udd9c\ud895\ude6d\udaed\ude1b\uda8b\udd25\udadb\udce1\ud86d\udfda\ud9c7\udf38\ud81c\udcf3\u82db\ud8bd\ude01\udba0\ude53\ud9e9\udd75\ud9cf\udedc\udaa8\udefe\ud900\uded1\udbcc\udefc\uda40\uddaa\udbe9\udc18\udbb0\uddb0\ud853\udf3c\ud96d\udf36\ud89b\udde8\ud903\ude82\ud9c6\udd5d\uda20\udde2\ud813\udc20\ud917\ude38\udaf9\udee2\uda92\uddf9\uda03\udc72\udbb8\ude7d\udb06\udf45\ud847\udcad\uafaf\ud9a4\udd4e\ud8e4\udca9\ud9f8\udeca\uda5c\udd84\ud854\udf36\ud9dc\udd6b\uda5b\udf08\udabf\udc6f\uda60\udf8d\udbc4\ude55\udb2d\udcfb\ud944\udffd\u063d", "\u91f3\u2b83\uba37\u4e32\u3827\u5778\u7af7\u5979\u2267\u8777\u0acd\u864e\u9bf3\u7efc\u15de\u8e5e\ua6a0\u1b94\uc2b9\u9a39\u6430\u109b\u9ae2\uce66\u9ca4\u0418\u98dd\u19ec\uaad7\ucf3b\u33d0\uc28d", "\udbe1\udc8e\ud96a\udc76",
        16, 60627, 428304781, -7885268151399707205L, -33339L, false, false, (char) 60866, (char) 31914,
        Double.longBitsToDouble(0x3fd278bab534c18cL), Double.longBitsToDouble(0x3febd60be61263d7L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.String:\u91f3\u2b83\uba37\u4e32\u3827\u5778\u7af7\u5979\u2267\u8777\u0acd\u864e\u9bf3\u7efc\u15de\u8e5e\ua6a0\u1b94\uc2b9\u9a39\u6430\u109b\u9ae2\uce66\u9ca4\u0418\u98dd\u19ec\uaad7\ucf3b\u33d0\uc28d |this=org.apache.commons.collections4.map.MultiValueMap:{\ud91c\udd13\uda10\udcd3\uda4c\udf4c\udb58\ude14\u3227\ud81f\udd0a\uda47\udf1e\ud9d0\udc76\udb84\udc7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda1e\udc45\uda4f\udd8b\udb15\udf72\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d\udb6f\udc80\ud92f\udc92\ud839\udd22\udb93\uddbd\udacb\udf2c\ud9a1\udeb6\ud925\ude54\udac5\udcdd\ud83f\udd16\ud946\udd31\ud9db\udf92\udadd\udf61\uda41\udd3e\udbf4\udcae\ud91e\ude87\u4814\uda31\udce3\ud8a8\udcf1\udb8c\udf83\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud88d\udfd4\ud9d8\udcc3\ud81c\udefd\uda4a\ude93\ud815\udc57\ud8b4\udd98\ud9fb\uddbc\u1268\udb9a\udc78\udbc1\udeeb\ud31f\ud934\ude60\ud81e\ude7d\ud995\udc7d\udba2\udda1\ud88b\udeb9\u91f0\ud8c5\udd91\ud8c2\udc48\ud9b9\udc37\uda2d\udcd7\udbee\udf35\ud871\ude44\ud948\udc01\ud96f\udf69\uda49\udedb\ud8ce\udcd2\ud9ff\udd95\ud868\udc2d\uda68\udc7e\ud98d\ude31\ud901\udc26\uda41\udf42\ud805\udc5a\udb18\udf47\udb54\udedd\ud990\ude07\uda4b\ude9e\ud90b\udd6c\ub764\ud96a\ude61\uda82\ude67\ud9da\ude90\ud90e\ude92\udb74\udd6b\ud902\uddef\ud9f9\uddc8\ud9a6\udfe1\udb59\udc21\udbd6\udde8\udb85\udce8\ud996\udf0c\ud82b\udc00\udbd1\ude93\ud91d\udd3d\udbd3\udc1c\udbc9\udf9a\ud9ee\udf5e\ud813\udf38\udb20\udd51\uda90\udd90\ud90d\udd90\udb2b\udfe3\uda55\udf65\ud8ca\udece\uda23\udfb4\udae7\ude2a\ud8e1\ude06\ud81b\udcf8\ud846\udf1d\udbf3\ude98\udb4a\udcf7\udbd8\udebd\udb1e\udd9c\ud895\ude6d\udaed\ude1b\uda8b\udd25\udadb\udce1\ud86d\udfda\ud9c7\udf38\ud81c\udcf3\u82db\ud8bd\ude01\udba0\ude53\ud9e9\udd75\ud9cf\udedc\udaa8\udefe\ud900\uded1\udbcc\udefc\uda40\uddaa\udbe9\udc18\udbb0\uddb0\ud853\udf3c\ud96d\udf36\ud89b\udde8\ud903\ude82\ud9c6\udd5d\uda20\udde2\ud813\udc20\ud917\ude38\udaf9\udee2\uda92\uddf9\uda03\udc72\ud806\udd63\ud95a\uddf3\ud847\udd69\uafaf...\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.map.MultiValueMap:{\ud91c\udd13\uda10\udcd3\uda4c\udf4c\udb58\ude14\u3227\ud81f\udd0a\uda47\udf1e\ud9d0\udc76\udb84\udc7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda1e\udc45\uda4f\udd8b\udb15\udf72\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d\udb6f\udc80\ud92f\udc92\ud839\udd22\udb93\uddbd\udacb\udf2c\ud9a1\udeb6\ud925\ude54\udac5\udcdd\ud83f\udd16\ud946\udd31\ud9db\udf92\udadd\udf61\uda41\udd3e\udbf4\udcae\ud91e\ude87\u4814\uda31\udce3\ud8a8\udcf1\udb8c\udf83\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud88d\udfd4\ud9d8\udcc3\ud81c\udefd\uda4a\ude93\ud815\udc57\ud8b4\udd98\ud9fb\uddbc\u1268\udb9a\udc78\udbc1\udeeb\ud31f\ud934\ude60\ud81e\ude7d\ud995\udc7d\udba2\udda1\ud88b\udeb9\u91f0\ud8c5\udd91\ud8c2\udc48\ud9b9\udc37\uda2d\udcd7\udbee\udf35\ud871\ude44\ud948\udc01\ud96f\udf69\uda49\udedb\ud8ce\udcd2\ud9ff\udd95\ud868\udc2d\uda68\udc7e\ud98d\ude31\ud901\udc26\uda41\udf42\ud805\udc5a\udb18\udf47\udb54\udedd\ud990\ude07\uda4b\ude9e\ud90b\udd6c\ub764\ud96a\ude61\uda82\ude67\ud9da\ude90\ud90e\ude92\udb74\udd6b\ud902\uddef\ud9f9\uddc8\ud9a6\udfe1\udb59\udc21\udbd6\udde8\udb85\udce8\ud996\udf0c\ud82b\udc00\udbd1\ude93\ud91d\udd3d\udbd3\udc1c\udbc9\udf9a\ud9ee\udf5e\ud813\udf38\udb20\udd51\uda90\udd90\ud90d\udd90\udb2b\udfe3\uda55\udf65\ud8ca\udece\uda23\udfb4\udae7\ude2a\ud8e1\ude06\ud81b\udcf8\ud846\udf1d\udbf3\ude98\udb4a\udcf7\udbd8\udebd\udb1e\udd9c\ud895\ude6d\udaed\ude1b\uda8b\udd25\udadb\udce1\ud86d\udfda\ud9c7\udf38\ud81c\udcf3\u82db\ud8bd\ude01\udba0\ude53\ud9e9\udd75\ud9cf\udedc\udaa8\udefe\ud900\uded1\udbcc\udefc\uda40\uddaa\udbe9\udc18\udbb0\uddb0\ud853\udf3c\ud96d\udf36\ud89b\udde8\ud903\ude82\ud9c6\udd5d\uda20\udde2\ud813\udc20\ud917\ude38\udaf9\udee2\uda92\uddf9\uda03\udc72\ud806\udd63\ud95a\uddf3\ud847\udd69\uafaf...\012",
        Z.run(T, 2, 12, 13, 2, "\ud91c\udd13\uda10\udcd3\uda4c\udf4c\udb58\ude14\u3227\ud81f\udd0a\uda47\udf1e\ud9d0\udc76\udb84\udc7b\ud830\udc6e\ud8e9\udfcf\u6e9b\uda1e\udc45\uda4f\udd8b\udb15\udf72\ud971\udf78\uda50\udf97\udb47\udd3e\ud8a6\udf9b\ud992\uddf2\udb8d\udee8\udb70\udf03\ud811\udea4\ud8f2\uddc7\uda2f\ude6d\udb6f\udc80\ud92f\udc92\ud839\udd22\udb93\uddbd\udacb\udf2c\ud9a1\udeb6\ud925\ude54\udac5\udcdd\ud83f\udd16\ud946\udd31\ud9db\udf92\udadd\udf61\uda41\udd3e\udbf4\udcae\ud91e\ude87\u4814\uda31\udce3\ud8a8\udcf1\udb8c\udf83\uda9b\ude4f\ud8b7\uddf6\ud90d\ude20\ud88d\udfd4\ud9d8\udcc3\ud81c\udefd\uda4a\ude93\ud815\udc57\ud8b4\udd98\ud9fb\uddbc\u1268\udb9a\udc78\udbc1\udeeb\ud31f\ud934\ude60\ud81e\ude7d\ud995\udc7d\udba2\udda1\ud88b\udeb9\u91f0\ud8c5\udd91\ud8c2\udc48\ud9b9\udc37\uda2d\udcd7\udbee\udf35\ud871\ude44\ud948\udc01\ud96f\udf69\uda49\udedb\ud8ce\udcd2\ud9ff\udd95\ud868\udc2d\uda68\udc7e\ud98d\ude31\ud901\udc26\uda41\udf42\ud805\udc5a\udb18\udf47\udb54\udedd\ud990\ude07\uda4b\ude9e\ud90b\udd6c\ub764\ud96a\ude61\uda82\ude67\ud9da\ude90\ud90e\ude92\udb74\udd6b\ud902\uddef\ud9f9\uddc8\ud9a6\udfe1\udb59\udc21\udbd6\udde8\udb85\udce8\ud996\udf0c\ud82b\udc00\udbd1\ude93\ud91d\udd3d\udbd3\udc1c\udbc9\udf9a\ud9ee\udf5e\ud813\udf38\udb20\udd51\uda90\udd90\ud90d\udd90\udb2b\udfe3\uda55\udf65\ud8ca\udece\uda23\udfb4\udae7\ude2a\ud8e1\ude06\ud81b\udcf8\ud846\udf1d\udbf3\ude98\udb4a\udcf7\udbd8\udebd\udb1e\udd9c\ud895\ude6d\udaed\ude1b\uda8b\udd25\udadb\udce1\ud86d\udfda\ud9c7\udf38\ud81c\udcf3\u82db\ud8bd\ude01\udba0\ude53\ud9e9\udd75\ud9cf\udedc\udaa8\udefe\ud900\uded1\udbcc\udefc\uda40\uddaa\udbe9\udc18\udbb0\uddb0\ud853\udf3c\ud96d\udf36\ud89b\udde8\ud903\ude82\ud9c6\udd5d\uda20\udde2\ud813\udc20\ud917\ude38\udaf9\udee2\uda92\uddf9\uda03\udc72\ud806\udd63\ud95a\uddf3\ud847\udd69\uafaf\ud9a4\udd4e\ud8e4\udca9\ud9f8\udeca\uda5c\udd84\ud854\udf36\ud9dc\udd6b\uda5b\udf08\udabf\udc6f\uda60\udf8d\udbc4\ude55\udb2d\udcfb\ud944\udffd\u063d", "\u91f3\u2b83\uba37\u4e32\u3827\u5778\u7af7\u5979\u2267\u8777\u0acd\u864e\u9bf3\u7efc\u15de\u8e5e\ua6a0\u1b94\uc2b9\u9a39\u6430\u109b\u9ae2\uce66\u9ca4\u0418\u98dd\u19ec\uaad7\ucf3b\u33d0\uc28d", "\udbe1\udc8e\ud96a\udc76",
        16, 60627, 428304781, -7885268151399707205L, -33339L, false, false, (char) 60866, (char) 31914,
        Double.longBitsToDouble(0x3fd278bab534c18cL), Double.longBitsToDouble(0x3febd60be61263d7L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections4.map.MultiValueMap|readObject|java.io.ObjectInputStream|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|clear||new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|containsValue|java.lang.Object|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|containsValue|java.lang.Object,java.lang.Object|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|createCollection|int|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|entrySet||new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|getCollection|java.lang.Object|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|iterator||new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|iterator|java.lang.Object|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|multiValueMap|java.util.Map|static",
    "M|org.apache.commons.collections4.map.MultiValueMap|multiValueMap|java.util.Map,java.lang.Class|static",
    "M|org.apache.commons.collections4.map.MultiValueMap|multiValueMap|java.util.Map,org.apache.commons.collections4.Factory|static",
    "M|org.apache.commons.collections4.map.MultiValueMap|put|java.lang.Object,java.lang.Object|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|putAll|java.lang.Object,java.util.Collection|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|putAll|java.util.Map|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|removeMapping|java.lang.Object,java.lang.Object|new:org.apache.commons.collections4.map.MultiValueMap:",
    "M|org.apache.commons.collections4.map.MultiValueMap|readObject|java.io.ObjectInputStream|new:org.apache.commons.collections4.map.MultiValueMap:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
