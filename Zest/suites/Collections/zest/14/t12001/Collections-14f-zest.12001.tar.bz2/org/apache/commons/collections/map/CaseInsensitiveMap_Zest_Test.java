package org.apache.commons.collections.map;
import org.junit.Test;
import static org.junit.Assert.*;
public class CaseInsensitiveMap_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 4, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\u6eb6\u8580\ubf3c\u6615\u2bc1\ua3dc\u69af\u0423\u99ab\u745b\u2b46\u6827\u2c05\u3de2\u4fb3\u97f1", "\ud94e\udc1d\ud8b6\ude50\uda62\udc16\udbb9\udd58\ub009",
        18, 38054, -1046000677, -1691064096003315118L, -86460L, false, true, (char) 19267, (char) 16403,
        Double.longBitsToDouble(0x3fa1ddda62ddeb20L), Double.longBitsToDouble(0x3fe8b3e4b6d8ded7L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.String:\ud90b\udd5a |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 4, 2, "\ud90b\udd5a", "\ua70c", "\uda3d\udce8\udb07\udf61\ud831\udce5\ud8e5\udc0c",
        54, 96739, 721529014, -2966757991989412607L, -82979L, false, true, (char) 28104, (char) 26187,
        Double.longBitsToDouble(0x3fe3acfd60b2ad0bL), Double.longBitsToDouble(0x3fe68b30953f308cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.String:\ud82b\udc67\uda4f\udc30 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 4, 7, "\ud82b\udc67\uda4f\udc30", "\u9ce1\u00c4\u4aed\u24f9\u51e2\u5819\u85ba", "\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\ud9c6\udd91\udb97\udeb5\ud9a5\uddad\uda0c\udec8\ud9a7\udcbb\udbc0\uddd3\udb62\udcff\ud8b1\udfec\uda5a\udc1b",
        14, 26008, 1525043906, 9013905112689126588L, 31476L, true, false, (char) 59458, (char) 59591,
        Double.longBitsToDouble(0x3fe1560d3a52e888L), Double.longBitsToDouble(0x3fe8308a731cf8afL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 7, "\ud810\udd4b\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec", "\u35ef\u5819\u2735\u5e2e\u5f53\ua905\u622c\ubf3c\u6615\u2bc1\ua3dc\u04c9\u0423\u99ab\u1881\ub94e\uc808\u2c57\u3de2\u4fb3\u8e3c\u8490\u0dd7\u0e2e\u2207\ub2fc\u3c0e\u0b71\u4259\u0fd1\u39f6\u5e59\u8ed4\u2e5a\u6694\ud783\u44bb\u3140\ua4aa\u61d6\uabc8\u2861\u7b67\u89fb\u37cf", "\udb6a\uddf4",
        45, 80212, 17262853, 2176040052702901371L, -15080L, true, true, (char) 46707, (char) 33166,
        Double.longBitsToDouble(0x3f8bdef768536e80L), Double.longBitsToDouble(0x3fc33477f6a908d4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 7, 4, 0, "\uda1a\udda5\udac0\udfdf\ud9f5\uddd2\udae6\udfb4\uda96\udd41\udbd8\udddb\udb77\ude18\uda81\udebe\ud841\udc0e\ud8e5\udc27\u02eb\ud93d\udf60", "\ua14f\u66cf\uaca5\u363a\ud4e3\u4d18", "\ud888\udcc2\uda3e\ude54\ud97e\ude40\ud910\udfdf\ud90f\udf6e\uda42\uded6\ud910\udf27\ud964\udc84\udb0b\udd92\ud8ca\ude54\udb3a\ude52\udbc1\udd03\udbb9\udd40\ub009\ud8a8\udfba\ud816\uded6\uda8d\udfd7\udbc6\udd44\udb9a\udd94\ud82b\udc10",
        54, 90680, 2881422, -4921127963007470557L, -69580L, true, true, (char) 13188, (char) 18834,
        Double.longBitsToDouble(0x3fe1fac7dc66a488L), Double.longBitsToDouble(0x3fe1b549e935a8faL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Object:@? |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 4, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb5f\udfb9\ud9be\udf8f\udb1e\uddec\ud964\udcdb", "\u73b6", "\udb7a\udfde\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\ud9c6\udd91\udb97\udeb5\ud833\uddb4\ud881\udd42\ud9a7\udcbb\udbc0\uddd3\udb81\udefa",
        -2, 33542, 763849534, -2759232983953681726L, 52388L, false, false, (char) 2014, (char) 7151,
        Double.longBitsToDouble(0x3fd3e5b057b739d8L), Double.longBitsToDouble(0x3fe9560d3ef4e888L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\ud908\udd3d\ud9e4\udf82\udae8\ude51\udb75\udc7c\ud9be\udf8f |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 4, 7, "\ud908\udd3d\ud9e4\udf82\udae8\ude51\udb75\udc7c\ud9be\udf8f", "\u24f9\u51e2\u585f\uc260", "\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udbce\ude2d\ud809\udee5\ud8f5\udea9\ud9a5\uddad\uda0c\udec8\ud9a7\udcbb\udbc0\uddd3\udb62\udcff\ud8b1\udfec\uda5a\udc1b",
        27, 26008, 1525043906, 9013905112689126588L, 31422L, true, false, (char) 10888, (char) 27604,
        Double.longBitsToDouble(0x3fe1560fd252e888L), Double.longBitsToDouble(0x3fe8308a731cf8afL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 4, 4, 7, "\udade\udf48\ud96a\udf2d\ud9f5\uddf8\udb75\udc7c\ud9ca\udf95\ud826\ude87\uda99\udc64\ud806\udf51\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\u6eb6\u8580\ubf3c\u6615\u2bc1\ua3dc\u69af\u0423\u99ab\u745b\u2280\u205c\u2c29\u3de2\u4fb3\ub461", "\ud94e\udc1d\ud85e\udec5\udba5\udf17\u4ef4\u2b43\ud9dd\udfce",
        50, 56895, -393731542, 359185795559406967L, 75566L, false, false, (char) 41448, (char) 19716,
        Double.longBitsToDouble(0x3fe6c6f6bf35d36aL), Double.longBitsToDouble(0x3fcaf0324d6c62c4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 1, 4, 4, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\ud805\udcd6\uda3d\udd21\udb07\udf61\uda6b\uddc3\ud8e2\udcb3\uda5e\uddf9\udb60\udca8", "\u8580\ud71c\u6c6f\u2bc1\ua3dc\u69af", "\ud98e\udd65\uda0c\udec8\ud9a7\udcbb",
        39, 3577, -599156217, 2548674576788187966L, 9886L, false, true, (char) 29853, (char) 42467,
        Double.longBitsToDouble(0x3fdf54027cbadb24L), Double.longBitsToDouble(0x3fd3e5b057b739d8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\ud9fc\udef3\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=org.apache.commons.collections.map.CaseInsensitiveMap:{} |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 1, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\ud9fc\udef3\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\u4374\u8c32\ubfec\u6615\u2bc1\ua3dc\u69af\u0423\u99ab\u745b\u2b46\u6827\u2c05\u3de2\u4fb3\u97f1", "\ud94e\udc1d\ud8b6\ude50\uda62\udc16\udbb9\udd58\ub009\udb8f\uddfa\ue5d1",
        53, 66458, 2125033042, 4700138993543277907L, -15043L, true, false, (char) 32684, (char) 41865,
        Double.longBitsToDouble(0x3fe5588a84f48f98L), Double.longBitsToDouble(0x3fe225b521ff3a58L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udda5\uda4f\udc30\uda23\uddc9\udb75\udc7c\ud9be\udf3f\udb1e\uddec\ud9c8\udfaf\ud95c\uddf1\ud827\uddb7\ud965\udf15\ud9cc\udde7 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 7, 7, "\uda1a\udda5\uda4f\udc30\uda23\uddc9\udb75\udc7c\ud9be\udf3f\udb1e\uddec\ud9c8\udfaf\ud95c\uddf1\ud827\uddb7\ud965\udf15\ud9cc\udde7", "\u6eb6", "\ud844\udf8d\udbb4\udf37\uda25\udcf8",
        10, 4909, 1712470194, 3498358827282980927L, 34701L, true, true, (char) 11447, (char) 37455,
        Double.longBitsToDouble(0x3fe9f11b54612d87L), Double.longBitsToDouble(0x3fe616cdaaf15ae6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 4, 4, 7, "\uda45\udd7c\uda1d\udd84\ud9f5\uddd2\udb75\udc7c\uda47\udc53\uda4c\ude6d\uda50\udf53\ud9e6\udf40\ud817\ude00\uda35\ude01\uda0e\udf1b", "\u6eb6\ucb6c\uad38\u1e32\u2bc1\ua3dc\ud35c\u7287\u9728\u9cda\u1830\u79cc\u7ed8\u3807\ucc1b", "\udb33\udd8a\ud94e\udc1d\ud97c\ude53\uda62\udc16\udbfd\udd5a\ud821\udf63\ud881\udfba\ud8f5\udf67\ud97a\udc2e\udbc4\udcc7\ud816\udf57\ud805\udd04\ud808\udf50\ud915\udd02\ud8db\udcc1\ud8e3\udd16\uda19\udf98\ud987\uddc3",
        31, 16248, -1996231768, 5537062481091764279L, -54677L, true, false, (char) 8124, (char) 47981,
        Double.longBitsToDouble(0x3feb5592037d071dL), Double.longBitsToDouble(0x3fe33d57ad4a78e5L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 5, 4, 7, "\uda1a\udda5\uda4f\udc30\ud8e3\udde8\udb75\udc7c\udb45\udc85\ud8fe\udf1d\ud85d\uddf8\ud868\udfa8\ud841\udc0e\ud81e\udedb\ud9cc\ude90", "\u6f25\u8580\ubfee\ub5a5\u80fa\ua3dd\u6944\u0423\u99ab\u279e\u4857\u6827\u2c05\u3de2\u4fb3\u97f1", "\ud9bb\udf55\ud810\udf92\udabb\udebe\ud88d\udc5f\ub009",
        18, 38054, -1046000677, 1020264507883006546L, -86645L, false, true, (char) 19267, (char) 16403,
        Double.longBitsToDouble(0x3fa1ddda62ddeb20L), Double.longBitsToDouble(0x3fe6fbe4b6d8deeeL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udd7d\uda4f\udc30\ud9f5\uddd2\uf340\ud8c5\udda1\ud999\udfe9\ud8a8\udec5\udb70\udff9\ub9f0\ud8e5\udc27\ud8e1\udd4f\uda0b\udc03\udb7a\udfde\ud967\udf85\ud933\udfdc\udbee\udf58\ud844\udf8d\udb10\ude24\ud8b3\uded6 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 4, 7, "\uda1a\udd7d\uda4f\udc30\ud9f5\uddd2\uf340\ud8c5\udda1\ud999\udfe9\ud8a8\udec5\udb70\udff9\ub9f0\ud8e5\udc27\ud8e1\udd4f\uda0b\udc03\udb7a\udfde\ud967\udf85\ud933\udfdc\udbee\udf58\ud844\udf8d\udb10\ude24\ud8b3\uded6", "\ua73c\u771f\u2b46\u6827\u2c05", "\uda5a\udc1b\ud93f\udfad\ud90c\uddf6\ud94e\udc1d\ud8b6\ude50\uda62\udc16\udbb9\udd58\ub009\ud890\udc10\uda84\ude2a\ud979\udfa6",
        38, 60314, -122743034, 1880476167115061120L, 4915L, false, true, (char) 64943, (char) 25449,
        Double.longBitsToDouble(0x3fe1c8f3e2e88b6fL), Double.longBitsToDouble(0x3fe0a3bc9f353388L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.String:\uda25\udfa5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\udb9f\udc64\ud893\udcdf |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=java.lang.String:\uda25\udfa5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\udb9f\udc64\ud893\udcdf |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 0, 0, "\uda25\udfa5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\udb9f\udc64\ud893\udcdf", "\u2fe6\u735a\uc718\u7cf3\ud264\ua3dc\u69af\u0423\u99ab\u55a4\u2b46\u6827\ua1b7\ub709\u4fb3\u97f1", "\ud94e\udc1d\ud8b6\ude50\udac7\udf49\udbb9\udc74\ub009",
        10, 38032, -1046000677, -4961279442450206268L, -44916L, false, false, (char) 36110, (char) 16403,
        Double.longBitsToDouble(0x3fa1ddda632deb20L), Double.longBitsToDouble(0x3fe8b3e4b6d8ded7L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\ud8f3\udcbe\udb83\uddd2\ud8ea\udc22\udb88\udd4f\ud87e\udc61\ud8e7\udf67\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\ud9c6\udd91\udb97\udeb5\ud9a5\uddad |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 6, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\ud8f3\udcbe\udb83\uddd2\ud8ea\udc22\udb88\udd4f\ud87e\udc61\ud8e7\udf67\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\ud9c6\udd91\udb97\udeb5\ud9a5\uddad", "\u2c05\u3de2\u4fb3\u97f1\u1134\u96d5\u1e7e\ub733\u1030\u9ed6\u0b71\u423e\u0fd1\u39f6", "\uda69\ude97\ud80b\udca7",
        14, 83832, 1068782130, -2399657140251367891L, 23176L, true, false, (char) 16177, (char) 31924,
        Double.longBitsToDouble(0x3fef03fde52a31b1L), Double.longBitsToDouble(0x3fe1a3bd67a67f8bL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\uddc8\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 7, "\uda1a\uddc8\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61", "\u85ba\u301f\u5f5d\u6eb6\u8580\ubf3c\u421c\u2bc1\ua3dc", "\udaeb\udeb7\ud9a5\uddad\uda0c\udec8\ud9a7\udcbb\udb9f\udfc3\ud900\udf3e\udbc1\udd5b\uda36\udef4\udb79\uddec\ud90c\uddf6\ud94e\udc1d",
        19, 84204, 105573626, 7895374830376365661L, 8872L, true, true, (char) 45613, (char) 23388,
        Double.longBitsToDouble(0x3fd4d798df0035f4L), Double.longBitsToDouble(0x3fdc85d7b465dbc0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 1, 5, 7, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\u6eb6\u8580\ubf3c\u6615\u2bc1\u0163\u4712\u0423\u99ab\u745b\u2b46\u6827\u2c05\u3de2\ucc15\u97f1", "\ud94e\udc1d\ud8b6\ude50\ud893\uded5\ud930\udd42\ub009",
        18, 38054, -1046000677, -1691064096003315118L, -86460L, false, true, (char) 19267, (char) 16403,
        Double.longBitsToDouble(0x3fa1ddda62ddeb20L), Double.longBitsToDouble(0x3fe8b3e4b6d8ded7L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Object:@? |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=org.apache.commons.collections.map.CaseInsensitiveMap:{} |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 1, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udbf2\uddf6\ud8d9\uddf7\udbab\udf85\udb31\udd3a\udbea\uded4", "\u5f5d\u6eb6\u8580\ubf3c\u6615\u2bc1\ua3dc\u34f1\ua8f1\ub21c\u745b\u73dd\u638a\u5add\uab2d", "\ud9a5\udd36\u44e2\ud9a2\uddae\uda61\uddd0\uda62\udc16\udbb9\udd58\uafa2\ud8a8\udfba\ud8f5\udf67\ud97a\udc2e\udbc4\udcc7\uaaa2\ud8cb\udf23\u24a7\ud915\udd02\uda0b\udcaf\udac8\ude4b\udb3f\ude4b\ud8f8\udfdb\udb8e\udc18\ud87d\uddb2\ud983\udcd7\ud81a\udefc\udbeb\ude15\ud8bd\ude6d\udab0\udf2a\ud97f\udeab\udaa9\uddc0\udb4a\ude4b\uda22\udf2e",
        50, 2601, -1653784118, -1418983639326515699L, -86107L, true, false, (char) 13301, (char) 60379,
        Double.longBitsToDouble(0x3fde510b071dee16L), Double.longBitsToDouble(0x3fd3d7706c13fc76L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 4, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\u6eb6\u8580\ubf3c\u6615\u2bc1\ua3dc\u69af\u9466\u99ab\u745b\u2b46\u6827\u2c05\u3de2\u4fb3\u97f1", "\ud94e\udc1d\ud8b6\ude50\uda62\udc16\udbb9\udd58\ub009",
        -3, 38054, -1051243557, -1691064096003315118L, -86460L, false, true, (char) 19267, (char) 16403,
        Double.longBitsToDouble(0x3fa1ddda62ddeb20L), Double.longBitsToDouble(0x3fe8b3e4b6d8ded7L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\uda52\udc92\ud83e\udf76\ud8e5\udc27\ud9cc\ude90\udb60\udc7d\udb88\udfde\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\u5378\ud9e1\udd64\ud9cb\udd4c\uda0c\udf17\ud9a7\udcbb\udbc0\uddd3\udb62\udcff\ud8b1\udfec\uda5a\udc1b\udb79\uddec\ud90c\uddf6\ud94e\udc1d\ud8b6\ude50\uda62\udc16\ud8c1\udc3b\udb7e\udc2b\ud8a8\udfda\ud8f5\udf67\ud97a\udc2e |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\uda52\udc92\ud83e\udf76\ud8e5\udc27\ud9cc\ude90\udb60\udc7d\udb88\udfde\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\u5378\ud9e1\udd64\ud9cb\udd4c\uda0c\udf17\ud9a7\udcbb\udbc0\uddd3\udb62\udcff\ud8b1\udfec\uda5a\udc1b\udb79\uddec\ud90c\uddf6\ud94e\udc1d\ud8b6\ude50\uda62\udc16\ud8c1\udc3b\udb7e\udc2b\ud8a8\udfda\ud8f5\udf67\ud97a\udc2e |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 0, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\uda52\udc92\ud83e\udf76\ud8e5\udc27\ud9cc\ude90\udb60\udc7d\udb88\udfde\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\u5378\ud9e1\udd64\ud9cb\udd4c\uda0c\udf17\ud9a7\udcbb\udbc0\uddd3\udb62\udcff\ud8b1\udfec\uda5a\udc1b\udb79\uddec\ud90c\uddf6\ud94e\udc1d\ud8b6\ude50\uda62\udc16\ud8c1\udc3b\udb7e\udc2b\ud8a8\udfda\ud8f5\udf67\ud97a\udc2e", "\u3ae6\u5225", "\uda87\ude2b\uda40\ude2c\ud877\udf9c\uda42\udd79\u32d5",
        28, 696, -1951583388, 7289877643249989751L, 54757L, false, true, (char) 43860, (char) 41271,
        Double.longBitsToDouble(0x3fe860777923fce8L), Double.longBitsToDouble(0x3fb48aa889aecf88L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90\uda75\udfa9\ud952\udc34\ud96c\udc04\ud91a\uddba\udbee\udf58\ud844\udf8d |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90\uda75\udfa9\ud952\udc34\ud96c\udc04\ud91a\uddba\udbee\udf58\ud844\udf8d |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 0, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90\uda75\udfa9\ud952\udc34\ud96c\udc04\ud91a\uddba\udbee\udf58\ud844\udf8d", "\u69af\u79b2\u99ab", "\udb32\udda1\udbe0\udfc6",
        57, 25967, 593409542, 3280708766952406072L, 91738L, false, true, (char) 7151, (char) 59458,
        Double.longBitsToDouble(0x3feedce7622aa4a7L), Double.longBitsToDouble(0x3fe297444706114eL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 6, 5, 5, "\u2173\uda4e\udff6\ud9f5\uddd2\udb75\udc7c\udb0b\udf3f\ud821\udf44\udb69\ude18\udb46\udd5a\ud8b5\udc08", "\u76e5\ubd4b\u6d1f\u8586\ubf3c\u6520\u2bc1", "\udb4f\udcb4\udb29\uded9\ud9a5\uddad\uda0c\udec8\ud9a7\udcbb",
        39, 25449, -603311913, 3413365705242265468L, 9886L, false, false, (char) 63730, (char) 14521,
        Double.longBitsToDouble(0x3fd94063bcbbf924L), Double.longBitsToDouble(0x3fca8f048126100cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Object:@? |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=java.lang.Object:@? |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 0, 3, "\uda1a\udda5\uda4f\udc30\udb04\udeef\udb10\udf5a\ud90f\udf4b\udb43\ude18\uda3d\udce8\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\u7ca6\u1167\ubf3c\u6074\u2bc1\ua3dc\uc60d\u8738\u76e6\u745b", "\udbc0\uddd3\udb62\udcff\uda67\ude27\uda58\uded6\ud8a0\udcdf\ud82c\uddd7\ud842\udc1c\ud8be\udc48\udae3\udece\udb3f\udd35\ud975\udee2\uf192\ud8f5\udf45\ud995\udf2e",
        38, 93794, 1483089776, 1894064116500936576L, -42360L, true, true, (char) 57241, (char) 34810,
        Double.longBitsToDouble(0x3fde7496d63ba734L), Double.longBitsToDouble(0x3fe6bd4dd29eebf4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\u3597 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 4, 7, "\u3597", "\000", "\000",
        32, 77859, 1846322603, 10696049115004928L, -77216L, true, true, (char) 46845, (char) 36670,
        Double.longBitsToDouble(0x3fd0000bbd813a10L), Double.longBitsToDouble(0x3fc78d31f9d58ab0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 4, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\ud963\udcdb\udb07\udf61\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\u6eb6\u8580\ubf3c\u6615\u2bc1\u7fdc\u69af\u153d", "\uda0c\udec1\udaeb\udd9d\ud870\udecf\udbb2\udf89\ud8f0\ude4e\uda5a\udd14\udb79\uddec",
        -1, 43906, 2098713329, 4100998860582677754L, 10173L, false, true, (char) 59591, (char) 58321,
        Double.longBitsToDouble(0x3fe297444706114eL), Double.longBitsToDouble(0x3fe8e7c57f801a2fL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Object:@? |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 5, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udba3\udc8f\ud8f4\udcbc\udb07\udf7a\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\ub2dc\u85d9\ubf3c\u6615\u2bc1\ua473\u69af\u0423\u99ab\u745b\u2b46\u6827\u06e0\u3de2\ud59f\u98a8", "\ud94e\udc1d\ud8b6\ude50\ud94e\udc0c\udb34\udeb5\udba6\udf76",
        42, 87734, 1323332934, -1691063683686454702L, -86460L, false, true, (char) 19267, (char) 16403,
        Double.longBitsToDouble(0x3fa1ddda62ddeb20L), Double.longBitsToDouble(0x3fe8b3e4b6d8ded7L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.CaseInsensitiveMap:{} |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 1, 5, 2, "\udbd7\udde7", "\uacf5", "\ud93f\ude56\udb07\udf7f\ud831\udce5\ud8e5\udc0c\ud9d1\udf90\udb60\udc7d\udb3c\udf3e\ud896\ude9e\ud81c\udd42\ub56b\uda71\udeab",
        7, 70131, 449903804, -5977631447575283534L, 59818L, false, false, (char) 25876, (char) 44903,
        Double.longBitsToDouble(0x3fb1c32b727173e8L), Double.longBitsToDouble(0x3f77d9601e5e1780L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 4, 7, "\ud82b\udc67\uda4f\udc30", "\u9ce1\u00c4\u06c7\u85c0\uab65\u5819\u85ba", "\udb54\udff8\ud933\udf6a\udbee\udf58\ud844\udf8d",
        41, 95208, 1655504060, -5977624202552657742L, 22943L, false, false, (char) 50453, (char) 35593,
        Double.longBitsToDouble(0x3fe03c958606dc49L), Double.longBitsToDouble(0x3fe9f11af4382d87L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 6, 6, 3, "\ud82b\udc67\uda4f\udc29", "\u9ce1\u00c4\u4aed\u24f9\u51e2\u5819\u85ba", "\udb31\ude0d\ud933\udf6a\udbee\udf58\ud844\udf8d",
        41, 48885, -357761860, -5943878730407331662L, 23057L, false, false, (char) 49941, (char) 16512,
        Double.longBitsToDouble(0x3fe03c958606dc49L), Double.longBitsToDouble(0x3fe0011af3054640L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 5, 5, 7, "\ud82b\udc53\uda4f\udc30", "\u28dc\u0d5d\u6ad1\u5aa4\u51e2\u5819\u85ba", "\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\ud9c6\udd91\udb97\udeb5\ud984\udf9d\uda0c\udec8\ud9a7\udcbb\udbc0\uddd3\udb62\udcff\ud8b1\udfec\ud9d9\udd3a",
        6, 26008, 1525043906, 9013905112689126588L, 31476L, true, false, (char) 59458, (char) 59591,
        Double.longBitsToDouble(0x3fe1560d3a52e888L), Double.longBitsToDouble(0x3fe8308a73b1daafL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 5, 7, "\udb58\udf9e\ud9d6\ude8b\udaad\udfe7\ud9e5\udf1a\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb07\udf61\ud844\udc0e\ud8e5\udc27\ud9cc\ude90\udb60\udc7d\udb8b\ude68\ud9c4\udc56\ud81d\udd07\u2855\ud844\udf8d\ud9a7\udf3d\udb2a\udceb\uda95\udf48\ud9c6\udd91\udb97\udeb5\ud9a5\uddad\uf4e1", "\u3de2\u4fb3\u97f1\u1134\u96a0\u1e7e\ub733\u1030\u270d\u0bc4\u423e", "\ud834\uddd6\ud816\udf57\uda69\ude97\ud84b\ude08\uda2d\udea7\u98f4\udbcb\udd85\udb76\uded7\udb94\udf7a\udb7f\udf84\udb97\udf58\ud87a\udd6b\ud9cc\uddad",
        -5, 16561, 447464869, 78623662274452328L, -84449L, true, true, (char) 52362, (char) 22640,
        Double.longBitsToDouble(0x3fe3659752e4a102L), Double.longBitsToDouble(0x3feb1290bd67dc56L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Object:@? |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 5, 4, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb5f\udfb9\ud9be\udf8f\udb1e\uddec\ud964\udcdb", "\u73b6", "\udb7a\udfde\udb4f\udd15\ud933\udf6a\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\ud9c6\udd91\udb97\udeb5\ud833\uddb4\ud881\udd42\ud9a7\udcbb\udbc0\uddd3\udb81\udefa",
        -2, 33542, 763849534, -2759232983953681726L, 52388L, false, false, (char) 2014, (char) 7151,
        Double.longBitsToDouble(0x3fd3e5b057b739d8L), Double.longBitsToDouble(0x3fe9560d3ef4e888L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.CaseInsensitiveMap:{} |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=org.apache.commons.collections.map.CaseInsensitiveMap:{} |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 1, 1, 4, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb5f\udfb9\ud9be\udf8f\udb1e\uddec\ud964\udcdb", "\ud3b5", "\ud8e8\udf75",
        47, 32801, -782058734, -2397140396245745395L, -35300L, true, false, (char) 10085, (char) 41265,
        Double.longBitsToDouble(0x3fc334b681795434L), Double.longBitsToDouble(0x3fe822508d6cca75L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=org.apache.commons.collections.map.CaseInsensitiveMap:{} |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 6, 1, 7, "\ud865\uddac\udbb9\udfa6\uda5d\udf43\ud866\udcfa\udb45\udc0b\ud8fe\udf1d\ud85d\uddf8", "\ubbc6\u85ba\u5f6a\ud466\u128c\u8580\u744a\uac31\u6226\ua373\u6944\u0423\u99ab\u279e\u4857\u790a\u2c05\u3de2\u4fb3\u97f1\u1134\u971c\u85e5\u7969\u1d73\ua51f\u0b71\u423e\u0fd1\u39f6\u88f2\u1ab9\uc3ae\u4316\u6f47\u6759\u2e1e\ua4aa\u9f27", "\udb72\udeef\ud822\ude1f\udaf0\udd65\udbda\udced\ud82c\udca2\uda41\udeca\udb82\udc18\udbcf\udc72\udbcf\uddda\udbe8\udf48\ud949\udfa2\ud8a9\udd97\udaf9\udecd",
        2, 95548, -1613323288, -1690236472711572278L, -82101L, true, false, (char) 19984, (char) 46647,
        Double.longBitsToDouble(0x3fee455b7477b6bdL), Double.longBitsToDouble(0x3fcb1ef22f68e948L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 5, 4, 7, "\uda1a\udda5\uda4f\udc30\ud8e3\udde8\udb75\udc7c\udb45\udc85\ud8fe\udf1d\ud85d\uddf8\ud868\udfa8\ud841\udc0e\ud81e\udedb\ud9cc\ude90", "\u6f25\u8580\ubfee\ub5a5\u80fa\ua3dd\u6944\u0423\u99ab\u279e\u4857\u6827\u2c05\u3de2\u4fb3\u97f1", "\ud9bb\udf55\ud810\udf92\udabb\udebe\ud88d\udc5f\ub009",
        18, 38054, -1046000677, 1020264507883006546L, -86645L, false, true, (char) 19267, (char) 60946,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe0000006d8deeeL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 5, 5, 7, "\udb5b\udc66\uda38\udfd0\ud9f5\uddd2\udb24\udd33\ud9be\udf8f\udbb0\udf54\ud8f4\udcbc\udb07\udf7a\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\u4d8a\u78ed\u21a4\u6615\u2bc1\ua473\u16a9\u590c\u99ab\ud32b\u2b5e\u6827\u06e0\u3de2\u50e3\u985e", "\ud94e\udc1d\ud8b6\ude50\ud94e\udc0c\udb34\udeb5\udba6\udf76",
        42, 87734, 1323332934, -1691063683686454702L, -86460L, false, true, (char) 19267, (char) 16403,
        Double.longBitsToDouble(0x3fa1ddda62ddeb20L), Double.longBitsToDouble(0x3fe8b3e4b6d8ded7L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\000\000\ud9f5\uddd2\ud8c6\udc24\ud99b\udcac\udba3\udc8f\ud8f4\udcbc\udb07\udf7a\ud841\udc0e\ud8e5\udc27\ud9cc\ude90 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 5, 7, "\000\000\ud9f5\uddd2\ud8c6\udc24\ud99b\udcac\udba3\udc8f\ud8f4\udcbc\udb07\udf7a\ud841\udc0e\ud8e5\udc27\ud9cc\ude90", "\ub2dc\u85d9\ubf3c\u6615\u2bc1\ua473\u69af\u0423\u99ab\u745b\u2b46\u6827^\u3d71", "\udb79\uddec",
        42, 43906, 2098713329, 4052022214836022522L, -38584L, false, false, (char) 30160, (char) 29034,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e4e000000000000L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udda5\uda4f\udc30\ud98f\udcf1\uda55\udcf7\ud925\udd0f\udb1e\uddec\uda3d\udce8\ud899\udf29\ud841\udc0e\ud980\ude35\ud9cc\ude90 |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=new org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 4, 7, "\uda1a\udda5\uda4f\udc30\ud98f\udcf1\uda55\udcf7\ud925\udd0f\udb1e\uddec\uda3d\udce8\ud899\udf29\ud841\udc0e\ud980\ude35\ud9cc\ude90", "\u6eb6\u4b76\ubd6b\u6615\u2bc1\ua3dc\u69af\u0423\ud226\u8a94\u2bd7\u6827\u2c05\u3de2\uad1e\u97f1", "\udbec\udd27\uda6a\uddd0\uda62\udc16\udbb9\udd58\ud848\uddf7",
        36, 38054, -1046000677, -1691064096003315118L, -86460L, false, true, (char) 11331, (char) 59901,
        Double.longBitsToDouble(0x3fc1caebdb73d030L), Double.longBitsToDouble(0x3fe8b3e4b476ded7L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb08\udc31\ud841\udc0e\ud8e5\udc27\ud9cc\ude90\uda75\udfa9\ud952\udc34\ud96c\udc04\ud91c\udc4f\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\udaf6\udf09\udb97\udeb5\ud9a5\uddad\uda0c\udec8\udb32\udda1\ud94b\udd3c\ud9ef\udebe\uda9a\udd02\uda5a\udc1b\ud924\udf82\ud854\ude28\udb46\udf8e\ud8b6\uddeb\uda62\udc16\udbb9\udd58\ub009\ud8a8\udfba\ud8f5\udf67\udb8d\ude78\ud878\udcc1\ud816\udf57\ud931\udebb\udb66\udc33\ud936\udfb5\ud9c9\udcab\ud886\udd45\ud8c1\udd0d\udaa2\udda6\ud8fe\ude9f\ud817\udc36\ud886\uddfd\ud99f\udee8\udbd4\uddde\ud8e1\udeed\ud9de\udd21\ud916\udec4\ud865\udfc4\uda00\ude8a\uda1c\udfab\ud86e\udda1\ud95c\ude98\udb51\udfd6\udb62\ude52\ud991\ude61\uda6d\ude09\ud8cd\udc1e\ud836\udf43\u36c0\udba9\udc7b\ud919\udd64\ud8f8\udc3b |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\0121=java.lang.String:\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb08\udc31\ud841\udc0e\ud8e5\udc27\ud9cc\ude90\uda75\udfa9\ud952\udc34\ud96c\udc04\ud91c\udc4f\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\udaf6\udf09\udb97\udeb5\ud9a5\uddad\uda0c\udec8\udb32\udda1\ud94b\udd3c\ud9ef\udebe\uda9a\udd02\uda5a\udc1b\ud924\udf82\ud854\ude28\udb46\udf8e\ud8b6\uddeb\uda62\udc16\udbb9\udd58\ub009\ud8a8\udfba\ud8f5\udf67\udb8d\ude78\ud878\udcc1\ud816\udf57\ud931\udebb\udb66\udc33\ud936\udfb5\ud9c9\udcab\ud886\udd45\ud8c1\udd0d\udaa2\udda6\ud8fe\ude9f\ud817\udc36\ud886\uddfd\ud99f\udee8\udbd4\uddde\ud8e1\udeed\ud9de\udd21\ud916\udec4\ud865\udfc4\uda00\ude8a\uda1c\udfab\ud86e\udda1\ud95c\ude98\udb51\udfd6\udb62\ude52\ud991\ude61\uda6d\ude09\ud8cd\udc1e\ud836\udf43\u36c0\udba9\udc7b\ud919\udd64\ud8f8\udc3b |this=org.apache.commons.collections.map.CaseInsensitiveMap:{}\012",
        Z.run(T, 2, 0, 0, 7, "\uda1a\udda5\uda4f\udc30\ud9f5\uddd2\udb75\udc7c\ud9be\udf8f\udb1e\uddec\uda3d\udce8\udb08\udc31\ud841\udc0e\ud8e5\udc27\ud9cc\ude90\uda75\udfa9\ud952\udc34\ud96c\udc04\ud91c\udc4f\udbee\udf58\ud844\udf8d\udbb4\udf37\uda25\udcf8\udaa2\ude8c\udaf6\udf09\udb97\udeb5\ud9a5\uddad\uda0c\udec8\udb32\udda1\ud94b\udd3c\ud9ef\udebe\uda9a\udd02\uda5a\udc1b\ud924\udf82\ud854\ude28\udb46\udf8e\ud8b6\uddeb\uda62\udc16\udbb9\udd58\ub009\ud8a8\udfba\ud8f5\udf67\udb8d\ude78\ud878\udcc1\ud816\udf57\ud931\udebb\udb66\udc33\ud936\udfb5\ud9c9\udcab\ud886\udd45\ud8c1\udd0d\udaa2\udda6\ud8fe\ude9f\ud817\udc36\ud886\uddfd\ud99f\udee8\udbd4\uddde\ud8e1\udeed\ud9de\udd21\ud916\udec4\ud865\udfc4\uda00\ude8a\uda1c\udfab\ud86e\udda1\ud95c\ude98\udb51\udfd6\udb62\ude52\ud991\ude61\uda6d\ude09\ud8cd\udc1e\ud836\udf43\u36c0\udba9\udc7b\ud919\udd64\ud8f8\udc3b", "\u3b41", "\uda64\udc01\udb9b\udcd6\udbf4\udf98\ud863\udd13\ud881\udd0b\udbaf\udc64\ud9a9\udc2c\udba0\udd99",
        42, 28000, -1192775046, 2762884311179624928L, 13574L, false, true, (char) 54323, (char) 42858,
        Double.longBitsToDouble(0x3fadf3d24603e1b0L), Double.longBitsToDouble(0x3fe0a174436aa39eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.map.CaseInsensitiveMap|convertKey|java.lang.Object|new:org.apache.commons.collections.map.CaseInsensitiveMap:",
    "M|org.apache.commons.collections.map.CaseInsensitiveMap|clone||new:org.apache.commons.collections.map.CaseInsensitiveMap:",
    "M|org.apache.commons.collections.map.CaseInsensitiveMap|readObject|java.io.ObjectInputStream|new:org.apache.commons.collections.map.CaseInsensitiveMap:",
    "M|org.apache.commons.collections.map.CaseInsensitiveMap|writeObject|java.io.ObjectOutputStream|new:org.apache.commons.collections.map.CaseInsensitiveMap:",
    "C|org.apache.commons.collections.map.CaseInsensitiveMap|<init>|java.util.Map",
    "C|org.apache.commons.collections.map.CaseInsensitiveMap|<init>|int,float",
    "C|org.apache.commons.collections.map.CaseInsensitiveMap|<init>|int",
    "C|org.apache.commons.collections.map.CaseInsensitiveMap|<init>|",
    "M|org.apache.commons.collections.map.CaseInsensitiveMap|convertKey|java.lang.Object|new:org.apache.commons.collections.map.CaseInsensitiveMap:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
