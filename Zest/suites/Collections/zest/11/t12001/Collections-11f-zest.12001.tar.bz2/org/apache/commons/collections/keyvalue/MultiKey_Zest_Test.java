package org.apache.commons.collections.keyvalue;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiKey_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 7, 11, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9", "\u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2\ud9a7\udd43",
        32, 14481, -400340157, -3888874801453510007L, -16995L, false, false, (char) 44922, (char) 57279,
        Double.longBitsToDouble(0x3fc52dd3ef53c1e0L), Double.longBitsToDouble(0x3fea2d468d7125b5L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u0c76]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\035\000\ud85b\udcb4\ud86d\udce9]\0121=java.lang.String:MultiKey[\uda6d\udcd5\035\000\ud85b\udcb4\ud86d\udce9] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\035\000\ud85b\udcb4\ud86d\udce9]\012",
        Z.run(T, 2, 1, 7, 11, "\uda6d\udcd5\035\000\ud85b\udcb4\ud86d\udce9", "\u0c76", "\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\uda27\udee4\udb12\udf13\uf930\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udb34\udd52\000\uda26\udd93\ud876\udeb0",
        1, 22843, 520441, -2061150505696763201L, 59945L, false, true, (char) 64321, (char) 22514,
        Double.longBitsToDouble(0x3fe6906093c953b1L), Double.longBitsToDouble(0x3fde5f1da152dd3eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u8b29\ub4a8]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcc9\ud89c\udf60\ud897\udd57\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcc9\ud89c\udf60\ud897\udd57\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac]\012",
        Z.run(T, 2, 1, 2, 11, "\uda6d\udcc9\ud89c\udf60\ud897\udd57\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac", "\u8b29\ub4a8", "\ud8fa\ude5b\ud8df\udfef\udb5e\udd2f\udbd7\ude49\ud915\udf44",
        16, 85303, 202554307, -4862877344180053047L, 26977L, false, true, (char) 44148, (char) 52005,
        Double.longBitsToDouble(0x3fef6fd3bbc243daL), Double.longBitsToDouble(0x3fe6e4b43a616152L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9e4\ude97, \u8333\u13e5\u75b8\u8baa\ube60\u06cc\u039c\u80ac\u96b6\u1438\u054a\u4ce5, \ud9d5\uddad\udbef\udf5b\udabf\udd28\ud918\udeb2]\0121=java.lang.String:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9e4\ude97] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9e4\ude97]\012",
        Z.run(T, 2, 11, 7, 5, "\uda6d\udcd5\ud988\uddf6\ud9e4\ude97", "\u8333\u13e5\u75b8\u8baa\ube60\u06cc\u039c\u80ac\u96b6\u1438\u054a\u4ce5", "\ud9d5\uddad\udbef\udf5b\udabf\udd28\ud918\udeb2",
        15, 90046, 660704351, -1719275980724899591L, -28904L, true, false, (char) 31868, (char) 1213,
        Double.longBitsToDouble(0x3fdd34a327db9d3cL), Double.longBitsToDouble(0x3fe693dce3c953b1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 7, 11, "\uda6d\udcd5\ud988\uddf6\ud8e0\udcd4\ud8aa\udea5\ud88a\udcd1", "\u0c76\u1ddb\ucaad\u2176\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\udb28\ude49\udb22\uddb7\ud827\udd49\udab5\udf33\ud918\udeb2\ud9a7\udd43",
        32, 14481, -400340157, -3888874801453510007L, -16995L, false, false, (char) 44922, (char) 16567,
        Double.longBitsToDouble(0x3facea4fbd4f0780L), Double.longBitsToDouble(0x3fe2a47fbdc625e4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:-1507390514 |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\udbfc\udc1c\udbfe\udc9c\ud9fd\udcca\uda20\ude76\ud8b7\udd64]\0121=java.lang.String:MultiKey[\udbfc\udc1c\udbfe\udc9c\ud9fd\udcca\uda20\ude76\ud8b7\udd64] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\udbfc\udc1c\udbfe\udc9c\ud9fd\udcca\uda20\ude76\ud8b7\udd64]\012",
        Z.run(T, 2, 5, 7, 11, "\udbfc\udc1c\udbfe\udc9c\ud9fd\udcca\uda20\ude76\ud8b7\udd64", "\u0c76\u1ddb\ucaad\u06cc\u039c\u80ac", "\uf930\uda2b\udf3e\ud9c9\udf01\u7f7a\ud859\ude6b\ud85c\udc14\udab5\udf33\ud918\udeb2\ud9a7\udd43\ud876\udeb0",
        1, 18923, -251137799, -2060970705480850753L, -65239L, false, true, (char) 16474, (char) 22514,
        Double.longBitsToDouble(0x3fe6906093c953b1L), Double.longBitsToDouble(0x3fdf136da152dd3eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9, \u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6, null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 7, 11, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9", "\u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2\ud9a7\udd43",
        32, 14481, -400340157, -3888874801453510007L, -16995L, false, false, (char) 44922, (char) 57279,
        Double.longBitsToDouble(0x3fc52dd3ef53c1e0L), Double.longBitsToDouble(0x3fea2d468d7125b5L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Integer:-329684653 |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9, \u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6]\012",
        Z.run(T, 2, 5, 10, 6, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9", "\u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\udb9d\ude55\ud9a7\udccc",
        32, 81217, -389232903, -3888874801453510007L, -16995L, false, false, (char) 31813, (char) 57279,
        Double.longBitsToDouble(0x3fc52dd3ef53c1e0L), Double.longBitsToDouble(0x3fea2d468d7125b5L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\000\ud988\uddd9\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\000\ud988\uddd9\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\000\ud988\uddd9\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9, \u0c76\u1ddb\ucaad\000\000\000\u96b6]\012",
        Z.run(T, 2, 0, 10, 11, "\000\ud988\uddd9\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9", "\u0c76\u1ddb\ucaad\000\000\000\u96b6", "\uda2b\udf3e",
        1, 21439, -144117046, -4861422879634122420L, 79111L, true, false, (char) 28338, (char) 1728,
        Double.longBitsToDouble(0x3fcf3d046a27281cL), Double.longBitsToDouble(0x3fe5ff1b28131753L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9, \u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6, \uda2b\udf3e\ud9c9\udf01\ud9cf\udc7c\ud92a\udfeb\ud87d\udd50\udab5\udf33\ud918\udeb2\ud8ee\udf46, \uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9, null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 7, 11, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9", "\u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud9cf\udc7c\ud92a\udfeb\ud87d\udd50\udab5\udf33\ud918\udeb2\ud8ee\udf46",
        34, 14481, -400340157, -3888874801453510007L, -16995L, false, true, (char) 25011, (char) 23683,
        Double.longBitsToDouble(0x3fe81940f2d19531L), Double.longBitsToDouble(0x3fd70f7c429a327eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.String:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud917\udcd2\ud896\udd23\ud83f\udf7d\udacb\udc7b\udb8c\udd48\ud934\udfcc\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud868\udec0\uda5b\udf40\uf930\uda2b\udf3e\udb68\uddd1\ud8e9\udc5e\ud97a\ude48\ud87d\uddac] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud917\udcd2\ud896\udd23\ud83f\udf7d\udacb\udc7b\udb8c\udd48\ud934\udfcc\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud868\udec0\uda5b\udf40\uf930\uda2b\udf3e\udb68\uddd1\ud8e9\udc5e\ud97a\ude48\ud87d\uddac]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud917\udcd2\ud896\udd23\ud83f\udf7d\udacb\udc7b\udb8c\udd48\ud934\udfcc\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud868\udec0\uda5b\udf40\uf930\uda2b\udf3e\udb68\uddd1\ud8e9\udc5e\ud97a\ude48\ud87d\uddac] |a0=[Ljava.lang.Object;:[[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud917\udcd2\ud896\udd23\ud83f\udf7d\udacb\udc7b\udb8c\udd48\ud934\udfcc\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud868\udec0\uda5b\udf40\uf930\uda2b\udf3e\udb68\uddd1\ud8e9\udc5e\ud97a\ude48\ud87d\uddac]]\012",
        Z.run(T, 2, 7, 8, 1, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud917\udcd2\ud896\udd23\ud83f\udf7d\udacb\udc7b\udb8c\udd48\ud934\udfcc\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud868\udec0\uda5b\udf40\uf930\uda2b\udf3e\udb68\uddd1\ud8e9\udc5e\ud97a\ude48\ud87d\uddac", "\u8ad9\u7154", "\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud85d\udc79\uda84\udfc0\ud893\udce9\ud842\udff3\u60a7\u15f1\ud87a\ude0c\udb57\udc2f\uda6c\udcbc\ud883\udfef\ud81c\ude6a\ud928\udea5\ud894\udeca",
        5, 2346, -600714102, -2698611807948328682L, 60535L, true, false, (char) 30363, (char) 8883,
        Double.longBitsToDouble(0x3fefd8323d08bbf1L), Double.longBitsToDouble(0x3fef46bac617ab3aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 11, 13, "\uda6d\udcd5\ud988\uddf6\ud9ec\udec0\ud85b\udcb4\ud86d\udce9", "\u5159\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud96f\udf45\ud87d\uddc9\udab5\udf33\ud818\udef3\ud9a7\udd43",
        32, 14481, -400340157, -3888874801705154935L, -16995L, false, false, (char) 44922, (char) 57279,
        Double.longBitsToDouble(0x3fc52dd3f1ee41e0L), Double.longBitsToDouble(0x3fea2d468d718dd7L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud997\uddd4\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9, \ub479\u3cab\u6930\u06cc\u039c\u80ac\ub360, \uda30\ude3d\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\ud856\udc42\ud86f\ude16\udbcd\uded4]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud997\uddd4\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9] |a0=[Ljava.lang.Object;:[[\ud997\uddd4\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9]]\012",
        Z.run(T, 2, 11, 9, 11, "\ud997\uddd4\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9", "\ub479\u3cab\u6930\u06cc\u039c\u80ac\ub360", "\uda30\ude3d\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\ud856\udc42\ud86f\ude16\udbcd\uded4",
        59, 14481, 444091203, 5460409999889381999L, -16995L, false, false, (char) 44922, (char) 57279,
        Double.longBitsToDouble(0x3fc52dd3f19531e0L), Double.longBitsToDouble(0x3fe5ba4fd5712576L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u0c76\u1ddb\ucaad\u06cc\u1668\u79c4\u96b6]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda59\udf6e\ud988\uddf6\ud9e6\udc9a\ud85b\udcb4\ud86d\udce9]\0121=[Ljava.lang.Object;:[[\uda59\udf6e\ud988\uddf6\ud9e6\udc9a\ud85b\udcb4\ud86d\udce9]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda59\udf6e\ud988\uddf6\ud9e6\udc9a\ud85b\udcb4\ud86d\udce9]\012",
        Z.run(T, 2, 1, 4, 11, "\uda59\udf6e\ud988\uddf6\ud9e6\udc9a\ud85b\udcb4\ud86d\udce9", "\u0c76\u1ddb\ucaad\u06cc\u1668\u79c4\u96b6", "\udad9\udece\ud9c9\udf75\ud8e8\udfa9\udbb8\ude47\ud87d\uddac\udab5\udf33\ua53b\ud97e\udc32",
        32, 9800, -1645384611, 9193720449751463154L, -16995L, false, false, (char) 44922, (char) 15646,
        Double.longBitsToDouble(0x3fedc8f6e3d4f078L), Double.longBitsToDouble(0x3fea2d468d7125b5L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud83a\udd3f\udbba\udcea\ud833\udc75\ud85b\udcb4\ud86d\udce9] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud83a\udd3f\udbba\udcea\ud833\udc75\ud85b\udcb4\ud86d\udce9]\0121=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud83a\udd3f\udbba\udcea\ud833\udc75\ud85b\udcb4\ud86d\udce9] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud83a\udd3f\udbba\udcea\ud833\udc75\ud85b\udcb4\ud86d\udce9]\012",
        Z.run(T, 2, 0, 0, 13, "\ud83a\udd3f\udbba\udcea\ud833\udc75\ud85b\udcb4\ud86d\udce9", "\u0c76\u07a2\u9b39", "\ud9a1\udeb1\uda27\udee4\udb12\udf13\udae9\udd85",
        32, 76276, -397816561, -608110427569077850L, 44273L, false, true, (char) 60517, (char) 55580,
        Double.longBitsToDouble(0x3fe44e503ae08a57L), Double.longBitsToDouble(0x3fe6838a98113f2bL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 7, 11, "\uda6d\udcd5\ud988\uddf6\udb69\uddda\ud8f5\udd0d\ud86d\udce9", "\u0c76\u52af\u5fef\u7095\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2\ua678",
        3, 70617, -400340157, -3888874803060485541L, -16995L, false, false, (char) 44922, (char) 57227,
        Double.longBitsToDouble(0x3fc52dd3ef53c1e0L), Double.longBitsToDouble(0x3fea2d468d7125b5L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 7, 11, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9", "\u0c76\u1ddb\ucaad\u06cc\u334a\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\udae5\udf4c\ud87d\uddac\ud951\udc41\udaa6\udd96\ud9a7\udd43",
        32, 14481, 790842179, -3838044597944757623L, -16995L, false, false, (char) 44922, (char) 57279,
        Double.longBitsToDouble(0x3fc52dd3ef53c1e0L), Double.longBitsToDouble(0x3fea2d468d7125b5L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9] |a0=[Ljava.lang.Object;:[[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9]]\0121=java.lang.Integer:-329684653 |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9]\012",
        Z.run(T, 2, 9, 5, 8, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9", "\u0c76\u0dc1\u0de4\u50b2\u9da9\u80ac\u96b6", "\uda2b\udf3e\udbd4\ude06\ud97d\udfff\ud969\udf1b\ud87d\uddac\u4381\ud859\udc73\ud9a7\udd43\ud876\udeb0\ud8a1\udcef\ud992\udf6e\udb06\udfe2\ud8de\udfee\ud960\udccc\udb28\udfda\udadb\udcc7\udb7a\udff9\ud822\udd57\ud9cf\udf32\udb5e\udc18\uda2c\udef3\ud8fe\ude47\udabd\udfbe\udaf1\udeb0\udb73\udd7d\ud999\udfa8\uda0a\udf74\u1f8b\ud81a\udcc7\uda00\udf10\ud94a\ude80\uda1c\udcdb\uda77\udcdc\udbf3\udd32\udb07\udf8d\udb13\udd6b\u6c0d\ud874\udc2e\uda44\ude45\udacc\udca5\uda1b\udc48\udab8\udc38\ud89d\udff4\ud990\udcee\udbd1\udf7a\ufe28\ud964\udf81\udb16\uddf8\ud9d5\uddab\uda3c\udfbe",
        11, 70230, 195181680, -8709662746346514316L, -93469L, true, false, (char) 25119, (char) 64395,
        Double.longBitsToDouble(0x3fe602b1c4193416L), Double.longBitsToDouble(0x3fe03df5c24c5f63L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\uda9d\udce0\ud9e2\udec6, \u0c76\u02b6\u697c\u06cc\u039c\u7cc6\u33c0, \uda32\udf80\ud9f9\udeef\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud8d1\ude0e\ud9a7\udd43, null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 5, 11, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\uda9d\udce0\ud9e2\udec6", "\u0c76\u02b6\u697c\u06cc\u039c\u7cc6\u33c0", "\uda32\udf80\ud9f9\udeef\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud8d1\ude0e\ud9a7\udd43",
        13, 14481, -400340157, -3872291967083392375L, 3849L, false, true, (char) 44922, (char) 51903,
        Double.longBitsToDouble(0x3feefc95c3d4f067L), Double.longBitsToDouble(0x3fc648da2bec6ee0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\ua1d8\u3696\ud3fc\u3024\u7fc7\u909b\u2be9\u50f0\ub3c0\ucd4f\u7154\u1b1d\uc6fa\u0d8d]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\u7881\ud9bd\udd3e\ud85b\udd45\ud86d\udce9\ud932\udcbc\udaa9\udc1d\ud931\udd85\ud83d\udd07\ud989\ude42\udbb3\udff7\udb9b\udcae]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\u7881\ud9bd\udd3e\ud85b\udd45\ud86d\udce9\ud932\udcbc\udaa9\udc1d\ud931\udd85\ud83d\udd07\ud989\ude42\udbb3\udff7\udb9b\udcae] |a0=[Ljava.lang.Object;:[[\uda6d\udcd5\u7881\ud9bd\udd3e\ud85b\udd45\ud86d\udce9\ud932\udcbc\udaa9\udc1d\ud931\udd85\ud83d\udd07\ud989\ude42\udbb3\udff7\udb9b\udcae]]\012",
        Z.run(T, 2, 1, 9, 4, "\uda6d\udcd5\u7881\ud9bd\udd3e\ud85b\udd45\ud86d\udce9\ud932\udcbc\udaa9\udc1d\ud931\udd85\ud83d\udd07\ud989\ude42\udbb3\udff7\udb9b\udcae", "\ua1d8\u3696\ud3fc\u3024\u7fc7\u909b\u2be9\u50f0\ub3c0\ucd4f\u7154\u1b1d\uc6fa\u0d8d", "\ud9ef\uddd0\udadb\udcc7\udb7a\udff9\ud86e\udf83\ud85d\udc79\uda84\udfc0\ud9b4\udcf6\ud80c\udd77\ud913\ude80\ud972\udc93\ud964\udf39\udb04\udea1\uda9d\ude38\ud8ef\udd05\ud8de\udffe\ud868\udf08\udb73\udd50\udbe5\udc30",
        53, 82192, 687259646, 4173787702522326957L, -61460L, false, true, (char) 2717, (char) 11407,
        Double.longBitsToDouble(0x3fdcc65e85822e4aL), Double.longBitsToDouble(0x3fce22605778a624L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud957\udc49\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud8f5\uddad, \u8f77\u1d94\ucaad\u4ab2\u039c\u80ac\u2fb6, \uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud94b\ude53\udabb\udfa9\ud9f4\udd6e\ud9c6\ude8b, \ud957\udc49\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud8f5\uddad, null]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud957\udc49\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud8f5\uddad, \u8f77\u1d94\ucaad\u4ab2\u039c\u80ac\u2fb6, null]\012",
        Z.run(T, 2, 13, 11, 5, "\ud957\udc49\ud988\uddf6\ud9f8\uddc0\ud85b\udcb4\ud8f5\uddad", "\u8f77\u1d94\ucaad\u4ab2\u039c\u80ac\u2fb6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud94b\ude53\udabb\udfa9\ud9f4\udd6e\ud9c6\ude8b",
        -2, 14481, -400340157, -3888874801453510007L, 87485L, true, true, (char) 56427, (char) 38577,
        Double.longBitsToDouble(0x3fec384831ebe8bdL), Double.longBitsToDouble(0x3fea2fbc9d7125b5L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda38\udde3\uda63\udeef\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9\ud9aa\ude57, \u87fe\u1138\u603a\u25c8\u80ac\u96b6\ua1d8\u36de\u7c48\u47ff\u9b8f\u9010\u01b0\u1f2a\ub3c0\u8b29\u7154\u1b1d\uc6fa\u1902, \ud858\udce7\ud99d\udff7\udb7a\udff9\ud86a\udc95\ud85d\udc79\uda84\udfc0\uda2c\udef3\udbc6\udf9a\ud90b\udc64\ud9f8\ude83\udb73\udd97\uda13\udfe5\ud842\udf02\uda68\udc57\ud90b\udc9a\u3c02\udaf5\ude3b\udb4f\ude8e]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda38\udde3\uda63\udeef\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9\ud9aa\ude57, \u87fe\u1138\u603a\u25c8\u80ac\u96b6\ua1d8\u36de\u7c48\u47ff\u9b8f\u9010\u01b0\u1f2a\ub3c0\u8b29\u7154\u1b1d\uc6fa\u1902, \ud858\udce7\ud99d\udff7\udb7a\udff9\ud86a\udc95\ud85d\udc79\uda84\udfc0\uda2c\udef3\udbc6\udf9a\ud90b\udc64\ud9f8\ude83\udb73\udd97\uda13\udfe5\ud842\udf02\uda68\udc57\ud90b\udc9a\u3c02\udaf5\ude3b\udb4f\ude8e]\012",
        Z.run(T, 2, 11, 11, 11, "\uda38\udde3\uda63\udeef\ud9f8\uddc0\ud85b\udcb4\ud86d\udce9\ud9aa\ude57", "\u87fe\u1138\u603a\u25c8\u80ac\u96b6\ua1d8\u36de\u7c48\u47ff\u9b8f\u9010\u01b0\u1f2a\ub3c0\u8b29\u7154\u1b1d\uc6fa\u1902", "\ud858\udce7\ud99d\udff7\udb7a\udff9\ud86a\udc95\ud85d\udc79\uda84\udfc0\uda2c\udef3\udbc6\udf9a\ud90b\udc64\ud9f8\ude83\udb73\udd97\uda13\udfe5\ud842\udf02\uda68\udc57\ud90b\udc9a\u3c02\udaf5\ude3b\udb4f\ude8e",
        56, 63817, -1387903934, 8916192760573793394L, -67676L, true, false, (char) 16647, (char) 21561,
        Double.longBitsToDouble(0x3fd459bee6b97040L), Double.longBitsToDouble(0x3fc44fb31de2d904L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda18\udf6b\ud9a2\udd45\udac0\udda5\ud881\udefa\ud86d\udd2f, \u0c76\u5ada\ucaad\u06cc\u039c\u80ac\u10fe, \uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2\ud8e8\udc03\ud876\ude78, \uda18\udf6b\ud9a2\udd45\udac0\udda5\ud881\udefa\ud86d\udd2f, null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 3, 2, "\uda18\udf6b\ud9a2\udd45\udac0\udda5\ud881\udefa\ud86d\udd2f", "\u0c76\u5ada\ucaad\u06cc\u039c\u80ac\u10fe", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2\ud8e8\udc03\ud876\ude78",
        1, 22843, -905449223, 6837035963606360767L, 59945L, false, true, (char) 60905, (char) 19345,
        Double.longBitsToDouble(0x3fd664184792fcdcL), Double.longBitsToDouble(0x3fde5f1da152dd3eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u1b1d\uc6fa\u1902\u18a2\uc664\ucaf0\u8121\u3175\u382a\u2212\ua203\u8304\ud101\uce40\u5e55\ub02a\u835d\u4bdd\uc46a\u810a\u5d40\ub8df]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\udaf6\udfc2\ud86d\udce9\ud919\uddf0\udb37\udcec\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\udb9b\udc5c\ud98d\ude1d\uda27\udee4\udb12\udf13\uf930\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2]\0121=void |a0=[Ljava.lang.Object;:[[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\udaf6\udfc2\ud86d\udce9\ud919\uddf0\udb37\udcec\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\udb9b\udc5c\ud98d\ude1d\uda27\udee4\udb12\udf13\uf930\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\udaf6\udfc2\ud86d\udce9\ud919\uddf0\udb37\udcec\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\udb9b\udc5c\ud98d\ude1d\uda27\udee4\udb12\udf13\uf930\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2]\012",
        Z.run(T, 2, 1, 1, 12, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\udaf6\udfc2\ud86d\udce9\ud919\uddf0\udb37\udcec\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\udb9b\udc5c\ud98d\ude1d\uda27\udee4\udb12\udf13\uf930\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\ud918\udeb2", "\u1b1d\uc6fa\u1902\u18a2\uc664\ucaf0\u8121\u3175\u382a\u2212\ua203\u8304\ud101\uce40\u5e55\ub02a\u835d\u4bdd\uc46a\u810a\u5d40\ub8df", "\ud960\udced\ud9be\udf55",
        18, 7339, -551632544, -9030210690301788693L, 5013L, true, false, (char) 19926, (char) 56429,
        Double.longBitsToDouble(0x3fe0b9aba08521c1L), Double.longBitsToDouble(0x3fed14d815d43f9dL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 7, 11, "\ud932\ude98\ud83e\ude51\ud80d\udcdb", "\u80d3\u13dc\u0c76\u1ddb\ucaad\u06cc\u039c", "\udae8\udc73\udbfb\udf78\udb6a\ude43\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\uda87\uddef\ud89b\uddf4\ud97f\udca7\ud876\udeb0\ud950\udc47\u09db\udb1f\uddca\ud9b6\udcd9",
        48, 49907, 1137340617, 4957187668672755319L, 4146L, true, true, (char) 57279, (char) 46920,
        Double.longBitsToDouble(0x3feea783c345a8d1L), Double.longBitsToDouble(0x3fd7125b59b9ff68L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\udb88\ude22\udbf0\udff2\ud9f8\uddfb\ud85b\udcb4\ud86d\udce9, \u0c76\u6da1\u7eab\ud49a\u8fb5\u80ac\u96b6, \uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\uda2c\ude14\ufd6a\ud918\udeb2\ud9cb\ude42\ud876\udeb0\ud950\udc10\u09db\udb1f\uddca\ud8c3\udfa3\ud97a\udce6, \udb88\ude22\udbf0\udff2\ud9f8\uddfb\ud85b\udcb4\ud86d\udce9, \u0c76\u6da1\u7eab\ud49a\u8fb5\u80ac\u96b6]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 3, 11, "\udb88\ude22\udbf0\udff2\ud9f8\uddfb\ud85b\udcb4\ud86d\udce9", "\u0c76\u6da1\u7eab\ud49a\u8fb5\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\uda2c\ude14\ufd6a\ud918\udeb2\ud9cb\ude42\ud876\udeb0\ud950\udc10\u09db\udb1f\uddca\ud8c3\udfa3\ud97a\udce6",
        41, 3848, 1154185196, -7192329457467475005L, 10413L, true, true, (char) 46920, (char) 54281,
        Double.longBitsToDouble(0x3fea2d468d7125b5L), Double.longBitsToDouble(0x3fd2633b9a7e5fa6L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud838\udf23\ud9cd\udc72, \u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6, \uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud8da\ude9c\udab5\udf33\ud918\udeb2\ud9a7\udd43, \uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud838\udf23\ud9cd\udc72, \u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud838\udf23\ud9cd\udc72, \u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6, \uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud8da\ude9c\udab5\udf33\ud918\udeb2\ud9a7\udd43]\012",
        Z.run(T, 2, 13, 11, 11, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud838\udf23\ud9cd\udc72", "\u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud8da\ude9c\udab5\udf33\ud918\udeb2\ud9a7\udd43",
        32, 14481, -400321140, -3888874801453510007L, -31885L, true, false, (char) 55747, (char) 48485,
        Double.longBitsToDouble(0x3fee1ce17ed20c12L), Double.longBitsToDouble(0x3fee4a9d8de5f1daL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud87f\udcb0\ud98e\udee0, \u586f\u9828\uafca\u1ddb\u4e83\u06a4\u039c, \ud92e\ude7c\ud8ea\ude8c\uda31\udc25\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud926\udee0\ud9c9\ude66\ud918\udeb2\udb65\ude48\udbb3\ude5b\udb87\udec2\u7f09\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud9ef\uddc3\ud955\udfc5\ud87a\udd18\ud9f6\udf0c\uda6c\udcb2\udbad\udcb7\udb0f\udea4\udbc7\udc35, \uda6d\udcd5\ud87f\udcb0\ud98e\udee0, null]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud87f\udcb0\ud98e\udee0, \u586f\u9828\uafca\u1ddb\u4e83\u06a4\u039c, \ud92e\ude7c\ud8ea\ude8c\uda31\udc25\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud926\udee0\ud9c9\ude66\ud918\udeb2\udb65\ude48\udbb3\ude5b\udb87\udec2\u7f09\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud9ef\uddc3\ud955\udfc5\ud87a\udd18\ud9f6\udf0c\uda6c\udcb2\udbad\udcb7\udb0f\udea4\udbc7\udc35, \uda6d\udcd5\ud87f\udcb0\ud98e\udee0, null]\012",
        Z.run(T, 2, 13, 13, 12, "\uda6d\udcd5\ud87f\udcb0\ud98e\udee0", "\u586f\u9828\uafca\u1ddb\u4e83\u06a4\u039c", "\ud92e\ude7c\ud8ea\ude8c\uda31\udc25\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud926\udee0\ud9c9\ude66\ud918\udeb2\udb65\ude48\udbb3\ude5b\udb87\udec2\u7f09\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud9ef\uddc3\ud955\udfc5\ud87a\udd18\ud9f6\udf0c\uda6c\udcb2\udbad\udcb7\udb0f\udea4\udbc7\udc35",
        2, 74889, 632619806, 7792535159948541890L, 81022L, false, false, (char) 63474, (char) 44611,
        Double.longBitsToDouble(0x3f991916715c2ca0L), Double.longBitsToDouble(0x3feecea104e948e6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\035\000\ud85b\udcb4\ud86d\udce9, \u0c76]\012",
        Z.run(T, 1, 10, 7, 11, "\uda6d\udcd5\035\000\ud85b\udcb4\ud86d\udce9", "\u0c76", "\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\uda27\udee4\udb12\udf13\uf930\uda2b\udf95\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udb34\udd52\000\uda26\udd93\ud876\udeb0",
        1, 22843, 520441, 7871819947444638671L, 59945L, false, true, (char) 64321, (char) 22514,
        Double.longBitsToDouble(0x3fe6906093c953b1L), Double.longBitsToDouble(0x3fde5f1da152dd3eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u8b29\ub4a8]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\udb30\udf4b\u15d4\ud89e\udf98\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\ud812\uddb2\udbfe\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\udb30\udf4b\u15d4\ud89e\udf98\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\ud812\uddb2\udbfe\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac] |a0=[Ljava.lang.Object;:[[\udb30\udf4b\u15d4\ud89e\udf98\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\ud812\uddb2\udbfe\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac]]\012",
        Z.run(T, 2, 1, 8, 7, "\udb30\udf4b\u15d4\ud89e\udf98\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\ud812\uddb2\udbfe\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac", "\u8b29\ub4a8", "\ud8fa\ude5b\ud8df\udfef\udb5e\udd2f\udbd7\ude49\ud915\udf44",
        16, 85303, 202554307, -4862877344180053047L, -33433L, false, true, (char) 44148, (char) 52005,
        Double.longBitsToDouble(0x3fefbfd3bbc243daL), Double.longBitsToDouble(0x3fe6e4b43a616152L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcc9\ud89c\udf60\ud897\udd57\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcc9\ud89c\udf60\ud897\udd57\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac]\012",
        Z.run(T, 2, 2, 2, 11, "\uda6d\udcc9\ud89c\udf60\ud897\udd57\ud85b\udcb4\ud86d\udce9\ud9aa\ude57\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb\udaf3\udccc\ud930\udd27\ud9b4\udd22\uda27\udee4\udb12\udf13\udb28\udce6\uda25\udc23\uda38\udc57\ud8e8\udfa9\uda55\udde2\ud87d\uddac", "\u8b29\ub4a8", "\ud8fa\ude5b\ud8df\udfef\udb5e\udd2f\udbd7\ude49\ud915\udf44",
        16, 85303, 202554307, -4862877344180053047L, 26977L, false, true, (char) 44148, (char) 52005,
        Double.longBitsToDouble(0x3fef6fd3bbc243daL), Double.longBitsToDouble(0x3fe6e4b43a616152L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\udbf5\udfec\ud89c\udfa9\udbc1\uddad\ud85b\udcb4\ud86d\udce9\ud842\udd44\ud923\udeb4\ud8a4\udfbd\ud920\uddca\ud9cc\udcd2\ud829\udf9a\udaef\udf52\ud9b4\udd22\ud9c2\uddd1\uda63\udf6c\uda0a\udc20\udbaa\udc8e\uda47\udec6\ud8e8\udfa9\uda55\udde2\ud93e\ude2d, \u10c4, null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 9, "\udbf5\udfec\ud89c\udfa9\udbc1\uddad\ud85b\udcb4\ud86d\udce9\ud842\udd44\ud923\udeb4\ud8a4\udfbd\ud920\uddca\ud9cc\udcd2\ud829\udf9a\udaef\udf52\ud9b4\udd22\ud9c2\uddd1\uda63\udf6c\uda0a\udc20\udbaa\udc8e\uda47\udec6\ud8e8\udfa9\uda55\udde2\ud93e\ude2d", "\u10c4", "\ud94c\udf63",
        58, 12083, 419082167, 802236267092537545L, -40526L, true, true, (char) 41745, (char) 23309,
        Double.longBitsToDouble(0x3febdf8b82015b7bL), Double.longBitsToDouble(0x3fdcc3791747d41cL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\u571d\ud9cf\udde7, \u8333\u13e5\u75b8\u8baa\ube60\u06cc\u5ccb\u80a1\u96b6\u1438\u054a\u8cb1]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\u571d\ud9cf\udde7, \u8333\u13e5\u75b8\u8baa\ube60\u06cc\u5ccb\u80a1\u96b6\u1438\u054a\u8cb1]\012",
        Z.run(T, 2, 10, 10, 5, "\uda6d\udcd5\u571d\ud9cf\udde7", "\u8333\u13e5\u75b8\u8baa\ube60\u06cc\u5ccb\u80a1\u96b6\u1438\u054a\u8cb1", "\ud9d5\uddad\udbef\udf5b\udabf\udd28\u9239",
        -5, 89800, 660704351, 665719930880L, -28904L, true, false, (char) 31868, (char) 1213,
        Double.longBitsToDouble(0x3fdd34a327db9d3cL), Double.longBitsToDouble(0x3fe693dce3c953b1L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud868\udfb4\ud86d\udce9] |a0=[Ljava.lang.Object;:[[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud868\udfb4\ud86d\udce9]]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud868\udfb4\ud86d\udce9] |a0=[Ljava.lang.Object;:[[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud868\udfb4\ud86d\udce9]]\012",
        Z.run(T, 2, 8, 8, 6, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud868\udfb4\ud86d\udce9", "\ucf93\u635d\u2dd7\u06cc\u039c\u80ac\u96b6", "\uda2b\udf3e\ud9c9\udf01\ud8e8\udfa9\ud97a\ude48\ud87d\uddac\udab5\udf33\udb9d\ude55\ud9a7\udccc",
        32, 81217, -389232903, -3888874801453510007L, -55646L, true, false, (char) 48054, (char) 32551,
        Double.longBitsToDouble(0x3feddc18aed20c12L), Double.longBitsToDouble(0x3fd163f2fbcbe3b4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb8c\udd48\udbb8\uddd0\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ud942\udf03\uda14\udd89\ud981\udefc\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\u174c\uda8c\udc65\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udf32\ud91a\udf6f\ud992\udd0d\udaef\udfa2\ud8d6\udff8\uda8a\udea2\ud817\udee9\ud9ab\udf66\uda7d\udd0a\ud9d6\udc9e\udbe7\udf3a\ud94a\uddbe\ud851\udd34\ud9bd\ude07\udb68\udc74\ud9a6\uddde\udb9c\ude96\ud89a\uddf0\udb32\udd36\ud872\udf26\ud89e\udfee\udb7d\udef0, \uad02\ubf8e\uc713\u599b\u3890\u6c11, \ud9c9\ude7b\uf0a9\uda96\udd1c\udbd1\udf3d\udb58\udd9e\ud8d5\udccb\ud9d3\udc67\uda9e\udf2a\udbf6\udc26\ud814\udf68\udb72\udfa6, \uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb8c\udd48\udbb8\uddd0\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ud942\udf03\uda14\udd89\ud981\udefc\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\u174c\uda8c\udc65\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udf32...\0121=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb8c\udd48\udbb8\uddd0\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ud942\udf03\uda14\udd89\ud981\udefc\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\u174c\uda8c\udc65\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udf32\ud91a\udf6f\ud992\udd0d\udaef\udfa2\ud8d6\udff8\uda8a\udea2\ud817\udee9\ud9ab\udf66\uda7d\udd0a\ud9d6\udc9e\udbe7\udf3a\ud94a\uddbe\ud851\udd34\ud9bd\ude07\udb68\udc74\ud9a6\uddde\udb9c\ude96\ud89a\uddf0\udb32\udd36\ud872\udf26\ud89e\udfee\udb7d\udef0] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb8c\udd48\udbb8\uddd0\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ud942\udf03\uda14\udd89\ud981\udefc\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\u174c\uda8c\udc65\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udf32\ud91a\udf6f\ud992\udd0d\udaef\udfa2\ud8d6\udff8\uda8a\udea2\ud817\udee9\ud9ab\udf66\uda7d\udd0a\ud9d6\udc9e\udbe7\udf3a\ud94a\uddbe\ud851\udd34\ud9bd\ude07\udb68\udc74\ud9a6\uddde\udb9c\ude96\ud89a\uddf0\udb32\udd36\ud872\udf26\ud89e\udfee\udb7d\udef0]\012",
        Z.run(T, 2, 13, 0, 1, "\uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb8c\udd48\udbb8\uddd0\uda59\udfc5\udaf3\udccc\udb9b\udc5c\ud9b4\udcb1\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ud942\udf03\uda14\udd89\ud981\udefc\udb1f\uddca\ud9b6\udcd9\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\u174c\uda8c\udc65\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udf32\ud91a\udf6f\ud992\udd0d\udaef\udfa2\ud8d6\udff8\uda8a\udea2\ud817\udee9\ud9ab\udf66\uda7d\udd0a\ud9d6\udc9e\udbe7\udf3a\ud94a\uddbe\ud851\udd34\ud9bd\ude07\udb68\udc74\ud9a6\uddde\udb9c\ude96\ud89a\uddf0\udb32\udd36\ud872\udf26\ud89e\udfee\udb7d\udef0", "\uad02\ubf8e\uc713\u599b\u3890\u6c11", "\ud9c9\ude7b\uf0a9\uda96\udd1c\udbd1\udf3d\udb58\udd9e\ud8d5\udccb\ud9d3\udc67\uda9e\udf2a\udbf6\udc26\ud814\udf68\udb72\udfa6",
        -4, 33159, 1852682905, 5138308595848962797L, -85712L, false, true, (char) 9271, (char) 14540,
        Double.longBitsToDouble(0x3fe177c84c573ae5L), Double.longBitsToDouble(0x3fe740310c58a212L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud932\ude5a\ud83e\ude51\ud80d\udcdb\ud85b\udcee\udbef\udcca\uda28\udc13\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb, \u80ac\u96b6\ucf37\u0743\u6693\u47ff, \ud87d\uddac, \ud932\ude5a\ud83e\ude51\ud80d\udcdb\ud85b\udcee\udbef\udcca\uda28\udc13\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb]\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\ud932\ude5a\ud83e\ude51\ud80d\udcdb\ud85b\udcee\udbef\udcca\uda28\udc13\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb, \u80ac\u96b6\ucf37\u0743\u6693\u47ff, \ud87d\uddac, \ud932\ude5a\ud83e\ude51\ud80d\udcdb\ud85b\udcee\udbef\udcca\uda28\udc13\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb]\012",
        Z.run(T, 2, 12, 12, 9, "\ud932\ude5a\ud83e\ude51\ud80d\udcdb\ud85b\udcee\udbef\udcca\uda28\udc13\udb37\udcd9\udb8c\uddaf\ud8be\udfbe\ud9d1\udeeb", "\u80ac\u96b6\ucf37\u0743\u6693\u47ff", "\ud87d\uddac",
        52, 50477, -1818847894, -2134199972432933807L, -96153L, true, false, (char) 50724, (char) 19558,
        Double.longBitsToDouble(0x3fc921767fb10f28L), Double.longBitsToDouble(0x3fe3ba265806e578L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb1d\ude52\udbb8\uddd0\uda59\udfc5\udaf3\udccc\ud8e8\udde3\ud9b3\udd78\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ua557\uda29\ude9d\ud981\udefc\ud82f\udf97\ud9b6\udcac\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\uda8c\udcee\udbb2\ude40\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udfe5\ud912\udc6f\ud94d\udecc\udaef\udfa2\ud8d6\udff8\uda8a\udea2\ud817\udee9\ud9ac\udc84\uda7d\udd0a\ud9d6\udc9e\udbe7\udf3a\ud94a\uddbe\ud851\udd34\ud9bd\ude07\udb68\udc74\ud9a6\uddde\udb9c\ude96\ud89a\uddf0\udb32\udd36\ud872\udf26\ud89e\udfee\udb7d\udef0, \uad02\ubf8e\uc713\u599b\u3890\u6c11, \ud9c9\ude7b\uf0a9\ud90a\uddb6\udbd1\udf3d\udb58\udd9e\ud8d5\udccb\ud9d3\udc67\uda9e\udf2a\udbf6\udc26\ud814\udf68\ud935\udca7, \uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb1d\ude52\udbb8\uddd0\uda59\udfc5\udaf3\udccc\ud8e8\udde3\ud9b3\udd78\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ua557\uda29\ude9d\ud981\udefc\ud82f\udf97\ud9b6\udcac\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\uda8c\udcee\udbb2\ude40\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udfe5...\0121=new org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb1d\ude52\udbb8\uddd0\uda59\udfc5\udaf3\udccc\ud8e8\udde3\ud9b3\udd78\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ua557\uda29\ude9d\ud981\udefc\ud82f\udf97\ud9b6\udcac\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\uda8c\udcee\udbb2\ude40\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udfe5\ud912\udc6f\ud94d\udecc\udaef\udfa2\ud8d6\udff8\uda8a\udea2\ud817\udee9\ud9ac\udc84\uda7d\udd0a\ud9d6\udc9e\udbe7\udf3a\ud94a\uddbe\ud851\udd34\ud9bd\ude07\udb68\udc74\ud9a6\uddde\udb9c\ude96\ud89a\uddf0\udb32\udd36\ud872\udf26\ud89e\udfee\udb7d\udef0, \uad02\ubf8e\uc713\u599b\u3890\u6c11, \ud9c9\ude7b\uf0a9\ud90a\uddb6\udbd1\udf3d\udb58\udd9e\ud8d5\udccb\ud9d3\udc67\uda9e\udf2a\udbf6\udc26\ud814\udf68\ud935\udca7, \uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb1d\ude52\udbb8\uddd0\uda59\udfc5\udaf3\udccc\ud8e8\udde3\ud9b3\udd78\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ua557\uda29\ude9d\ud981\udefc\ud82f\udf97\ud9b6\udcac\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\uda8c\udcee\udbb2\ude40\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udfe5...\012",
        Z.run(T, 2, 13, 12, 13, "\uda6d\udcd5\ud9c3\udd92\ud9f8\uddbf\ud917\udcd2\uda14\udc2b\ud828\udd7d\udacb\udc7b\udb1d\ude52\udbb8\uddd0\uda59\udfc5\udaf3\udccc\ud8e8\udde3\ud9b3\udd78\ud9ed\udfe6\uda6d\udf6c\uf930\uda2b\udf3e\ud965\udca7\ud8e8\udfe7\ud97a\ude48\ud99a\udd78\udad1\udccf\ud918\udeb2\ud9a7\udcf3\ua557\uda29\ude9d\ud981\udefc\ud82f\udf97\ud9b6\udcac\udbb9\udc1e\ud986\uddcb\udadb\udcc7\udb7a\udff9\ud868\udd95\ud8fc\udca8\ud9c5\udfda\ud893\udce9\ud86f\udc82\u604e\u15f1\ud87a\ude0c\udb0a\ude53\ud8a0\udc09\ud9ca\udca8\udb96\udef7\ud928\udee3\ud894\udeca\udbf5\ude93\udb56\udf40\udb3c\ude6d\uda8c\udcee\udbb2\ude40\ud968\udd29\ud94c\udfb4\udb5a\ude48\uda4a\udfe5\ud912\udc6f\ud94d\udecc\udaef\udfa2\ud8d6\udff8\uda8a\udea2\ud817\udee9\ud9ac\udc84\uda7d\udd0a\ud9d6\udc9e\udbe7\udf3a\ud94a\uddbe\ud851\udd34\ud9bd\ude07\udb68\udc74\ud9a6\uddde\udb9c\ude96\ud89a\uddf0\udb32\udd36\ud872\udf26\ud89e\udfee\udb7d\udef0", "\uad02\ubf8e\uc713\u599b\u3890\u6c11", "\ud9c9\ude7b\uf0a9\ud90a\uddb6\udbd1\udf3d\udb58\udd9e\ud8d5\udccb\ud9d3\udc67\uda9e\udf2a\udbf6\udc26\ud814\udf68\ud935\udca7",
        -4, 33159, 1852682905, 5138308595848962797L, -85712L, false, true, (char) 9271, (char) 14540,
        Double.longBitsToDouble(0x3fe177c84c573ae5L), Double.longBitsToDouble(0x3fe740310c58a212L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6]] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud871\uddb4\ud86d\udce9]\0121=java.lang.String:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud871\uddb4\ud86d\udce9] |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud871\uddb4\ud86d\udce9]\012",
        Z.run(T, 2, 1, 7, 11, "\uda6d\udcd5\ud988\uddf6\ud9f8\uddc0\ud871\uddb4\ud86d\udce9", "\u0c76\u1ddb\ucaad\u06cc\u039c\u80ac\u96b6", "\ud863\udf80\ud9e3\udcae\ud8e8\udfa9\ud97a\ude48",
        2, 108, 134910521, -7811850178190521233L, 75479L, true, false, (char) 19558, (char) 31868,
        Double.longBitsToDouble(0x3fef621e567744cbL), Double.longBitsToDouble(0x3fee1ce17ed20c12L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\uda76\udfa4\ud9a2\udd45\udac0\udda5\udaa2\udfa2\ud898\uddcc |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda76\udfa4\ud9a2\udd45\udac0\udda5\udaa2\udfa2\ud898\uddcc]\0121=java.lang.String:\uda76\udfa4\ud9a2\udd45\udac0\udda5\udaa2\udfa2\ud898\uddcc |this=org.apache.commons.collections.keyvalue.MultiKey:MultiKey[\uda76\udfa4\ud9a2\udd45\udac0\udda5\udaa2\udfa2\ud898\uddcc]\012",
        Z.run(T, 2, 3, 3, 2, "\uda76\udfa4\ud9a2\udd45\udac0\udda5\udaa2\udfa2\ud898\uddcc", "\u6220\u1d83\u36a3\uadcb\u039c\u80ac\uc3a7", "\udaf5\udef6\u47ea\ud8e8\udfa9\uda7d\udf0a\ud995\uddc1\udab5\udf33\ud918\udeb2\ud8e8\udc03\uda4d\ude94\ud950\udc29\u09db\udb1f\uddca\uda45\udcfc\ud8c6\ude0c",
        0, 79430, 1321957356, 2681185623652400568L, -35418L, false, true, (char) 46920, (char) 63439,
        Double.longBitsToDouble(0x3fc8c392f0ccf1acL), Double.longBitsToDouble(0x3f79f35cfd923300L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.keyvalue.MultiKey|readResolve||new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections.keyvalue.MultiKey|calculateHashCode|[Ljava.lang.Object;|new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections.keyvalue.MultiKey|equals|java.lang.Object|new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections.keyvalue.MultiKey|getKey|int|new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections.keyvalue.MultiKey|getKeys||new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections.keyvalue.MultiKey|hashCode||new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections.keyvalue.MultiKey|size||new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections.keyvalue.MultiKey|toString||new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
    "C|org.apache.commons.collections.keyvalue.MultiKey|<init>|[Ljava.lang.Object;,boolean",
    "C|org.apache.commons.collections.keyvalue.MultiKey|<init>|[Ljava.lang.Object;",
    "C|org.apache.commons.collections.keyvalue.MultiKey|<init>|java.lang.Object,java.lang.Object",
    "C|org.apache.commons.collections.keyvalue.MultiKey|<init>|java.lang.Object,java.lang.Object,java.lang.Object",
    "C|org.apache.commons.collections.keyvalue.MultiKey|<init>|java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object",
    "C|org.apache.commons.collections.keyvalue.MultiKey|<init>|java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object",
    "M|org.apache.commons.collections.keyvalue.MultiKey|readResolve||new:org.apache.commons.collections.keyvalue.MultiKey:[Ljava.lang.Object;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
