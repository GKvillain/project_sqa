package org.apache.commons.collections4.list;
import org.junit.Test;
import static org.junit.Assert.*;
public class SetUniqueList_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55]\012",
        Z.run(T, 1, 15, 3, 13, "\udabb\ude55", "\u5a89\u944e", "\uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\udad8\ude98\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1",
        5, 52095, -1950533288, -2620733125107775663L, 11505L, false, false, (char) 31541, (char) 23895,
        Double.longBitsToDouble(0x3f843bc6fdf59ac0L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55]\012",
        Z.run(T, 1, 15, 3, 13, "\udabb\ude55", "\u18a8\uafac", "\uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b",
        33, 37341, -2064795202, -8042751810944901672L, -79524L, true, true, (char) 50777, (char) 10383,
        Double.longBitsToDouble(0x3fa4a778b658eb10L), Double.longBitsToDouble(0x3fe758c133c71fb2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 3, 13, "\udabb\ude55", "\u1a01", "\u00a9\000\ud850\udd48\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43",
        54, 52281, 20476, -576460752956371442L, 14729L, true, true, (char) 38673, (char) 31488,
        Double.longBitsToDouble(0x3fd5827c2239177aL), Double.longBitsToDouble(0x3ec4200000000000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 4, 13, "\udabb\ude55", "\u5a89\u944e", "\uda81\udeff\ud9ea\udc39\uda9f\udd51\uda0b\udda7\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\udad8\ude98\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1",
        5, 52095, -1950545320, -2620733125107775663L, 11505L, false, false, (char) 31541, (char) 23895,
        Double.longBitsToDouble(0x3f843bc6fdf59ac0L), Double.longBitsToDouble(0x3feb091cf99067e6L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 3, 13, "\udabb\ude55", "\u5a89", "\ud8db\udf47\uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\uda87\ude4e\ud8d9\udd60\ud8ec\ude7d\ud832\udd43",
        54, 52281, -534753436, -555346775333614024L, 14729L, true, true, (char) 38673, (char) 39801,
        Double.longBitsToDouble(0x3fd5827c2239177aL), Double.longBitsToDouble(0x3fea8edd088fa2daL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 12, 3, 13, "\udabb\ude55", "\u5a89\u944e", "\ud929\udf4d\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\ud825\udd74\ud8ec\ude7d\ud832\udd43\ud985\udf7e\ud8f3\udec5\udaa3\udd51\udad8\ude98\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1",
        5, 52095, -1950533288, -2620733125107775663L, -77993L, true, true, (char) 62347, (char) 638,
        Double.longBitsToDouble(0x3fe95926a3f7b124L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\ud957\udf1a]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 3, 13, "\ud957\udf1a", "\uc387\u5ce5", "\ud9e0\udf8d\ud9f5\udc00\ud852\udd7d\ud8da\udf44\u6565\udb3a\udc7a\ud8c3\udf27\udbcf\udd6a\ud8ec\ude7d\udb9a\udcb6\udac0\udf5c\udbed\udde2\ud820\uddf2\udbb5\uddb9\udb3b\uddd5\u90a8\ud89b\udf53\ud8d4\ude75",
        20, 52095, -650430120, -5857404407605754031L, 11505L, false, false, (char) 31541, (char) 4288,
        Double.longBitsToDouble(0x3f84b460fdf59ac0L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.list.SetUniqueList:[]\012",
        Z.run(T, 1, 6, 3, 13, "\u5b8e", "\u5a89\u944e\u18a0\u1550\u259f\u103b\u251b\uc727\uac3f\u3d3d\u5957\u3f12\u77e0\uc98c\ubca8\uab2b\u1235\u81ea\u77ed\u2d0a\u81de\ua804\u635d\u82e6\ucf8c\ube00\u80ea\u4cfa\u8c04\u2323\u9e85", "\ud9d3\udf95\ud9f5\udcde\udb5f\udd0d\u9381\udac6\udc4d\uda58\udea7\udaaf\udf7e",
        5, 55657, 659167120, -1518924857123234845L, 25274L, false, true, (char) 9166, (char) 7414,
        Double.longBitsToDouble(0x3fec2e56b42e2f45L), Double.longBitsToDouble(0x3fe5ab7ccde66964L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55]\012",
        Z.run(T, 1, 10, 3, 13, "\udabb\ude55", "\u5a89\u944e", "\uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8f6\udc44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud8ef\udc9b\ud985\udf7e\udbed\udde2\ud853\ude1b\udad8\ude98\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1",
        5, 52095, -1950533288, -2620733125107775663L, 11505L, false, false, (char) 14909, (char) 23895,
        Double.longBitsToDouble(0x3f843bc6fdf59ac0L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude89, \uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\udaf1\udd10\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1]\012",
        Z.run(T, 1, 4, 3, 13, "\udabb\ude89", "\u5a89\u944e", "\uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\udaf1\udd10\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1",
        5, 52095, -1950533288, -2620733125107775663L, 11505L, false, false, (char) 13621, (char) 26905,
        Double.longBitsToDouble(0x3feff25cc3f7d6a6L), Double.longBitsToDouble(0x3fe5febccd794de6L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 3, 13, "\udabb\ude55", "\u5a89\u944e", "\uda81\udeff\ud9e9\udf52\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\udad8\ude98\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1",
        5, 31783, 381853663, 2204807660108908369L, 11505L, false, false, (char) 31541, (char) 23895,
        Double.longBitsToDouble(0x3f843bc6fdf59ac0L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55]\012",
        Z.run(T, 1, 13, 2, 9, "\udabb\ude55", "\u01ec\u944e", "\uda9c\uddff\udb1c\udd3e\ud852\uddc3\ud8fb\udc33\ud8c7\udd14\uda4d\udea1\ud96a\udeda\ud95d\udce5\ud922\uded7\uda61\uddd0\ud8b2\udf53\udbed\udde2\udb53\udedf\udad8\udf1f\udb5c\udfc2\ud881\ude4f\uda54\udd7b\ud947\udcd1",
        5, 52095, -1958397608, -2620733125107775663L, 11505L, false, false, (char) 14034, (char) 24112,
        Double.longBitsToDouble(0x3fc7a23c71b0cebcL), Double.longBitsToDouble(0x3fe5f8fd7822cce6L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55, \uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\ud848\uddf2\uda5d\udcad\udbd7\udc9b\udb16\udf41\ud81b\udcf2]\012",
        Z.run(T, 1, 1, 3, 13, "\udabb\ude55", "\u5a89\u944e", "\uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\ud848\uddf2\uda5d\udcad\udbd7\udc9b\udb16\udf41\ud81b\udcf2",
        3, 52095, -1950533288, -2620733125107775663L, 11505L, true, true, (char) 28624, (char) 52104,
        Double.longBitsToDouble(0x3febf9938e2b80e5L), Double.longBitsToDouble(0x3fe5f843999067e6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\u4c21]\012",
        Z.run(T, 1, 15, 3, 13, "\u4c21", "", "",
        54, 65641, 1528695201, -8188882314294365661L, 20524L, false, true, (char) 9001, (char) 63926,
        Double.longBitsToDouble(0x3fc7c4801f5c0000L), Double.longBitsToDouble(0x3fdd800009c237feL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.set.UnmodifiableSet:[\u1189\u947f] |this=org.apache.commons.collections4.list.SetUniqueList:[\ud849\ude56]\012",
        Z.run(T, 1, 5, 3, 13, "\ud849\ude56", "\u1189\u947f", "\ud876\udd5e\ud8a8\udf5d\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\ud8e6\udd9f\ud853\udd53\ud8d3\udf9f\ud86c\udec3\udad8\udf1c\uda54\ude37\ud947\udcd1",
        5, 52095, -1950533288, -2620733125107775663L, 11505L, false, false, (char) 31541, (char) 23895,
        Double.longBitsToDouble(0x3f843bc6fdf59ac0L), Double.longBitsToDouble(0x3fe0e02d399067e6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 3, 13, "\udabb\ude55", "\u5a89\u944e", "\uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\ud967\uddb6\uda47\udd11\ud9c0\udd6e\ud95c\udf8d\udbed\udde2\ud853\ude1b\udad8\ude98\udb5c\udfc2\ue58b\uda41\udf52\ud947\udcd1",
        5, 52095, -1950533288, -2620733125107775663L, -54031L, false, false, (char) 31541, (char) 23895,
        Double.longBitsToDouble(0x3f843bc6fdf59ac0L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\u45ab]\012",
        Z.run(T, 1, 11, 3, 1, "\u45ab", "\u5a3d\u944e\u18a0", "\ud9ea\udc39\udb8a\udf1d\udb41\udd66\ud8c7\udcd9\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud896\ude72\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\udad8\ude98\udb5c\udfc2\udbe3\udc20\ud8c8\uddfa\ud947\udcd1\ud89e\udcc9\udb4f\ude1e\uff1d\ud983\uddcc\ud9c0\udd23\udbf2\udd73\udb7d\udc03\ud9e2\udd6f",
        35, 71112, -697616782, -2911129694774047041L, 42612L, false, false, (char) 12603, (char) 31789,
        Double.longBitsToDouble(0x3fa1e20b134609c0L), Double.longBitsToDouble(0x3fd23850bd5517c8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udabb\ude55\ud97e\udc29\u0719\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39] |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\ud97e\udc29\u0719\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 3, 13, "\udabb\ude55\ud97e\udc29\u0719\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39", "\uac3f\u3d3d\ud04b", "\ud832\udd43\ud91c\udc88\udbed\uddd8",
        21, 78253, 18140686, -76247371840845184L, 63563L, true, true, (char) 24858, (char) 54489,
        Double.longBitsToDouble(0x3fea8edd088fa2daL), Double.longBitsToDouble(0x3fe37cbdda9cf8e6L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\udabf\udf10]\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\udabf\udf10]\012",
        Z.run(T, 2, 13, 13, 13, "\udabf\udf10", "\u1a01\u3f45", "\udb71\udeb7\ud968\udf01\udacb\udc95\udb30\udc9e\udbca\udede\ud87a\udde5",
        -5, 18431, -879380034, -8042752695712817704L, -79524L, false, false, (char) 50702, (char) 32023,
        Double.longBitsToDouble(0x3fa4a778b658eb10L), Double.longBitsToDouble(0x3fe758c133000000L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55, \uda81\udeff\ud9ea\udc39\uda9f\udd51\uda0b\udda7\ud8c7\udd14\udaf6\udcd4\udbbf\udda6\udbbc\udc89\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\u8ee3\ud9c5\udd8b]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 13, "\udabb\ude55", "\u602e\u6128", "\uda81\udeff\ud9ea\udc39\uda9f\udd51\uda0b\udda7\ud8c7\udd14\udaf6\udcd4\udbbf\udda6\udbbc\udc89\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\u8ee3\ud9c5\udd8b",
        26, 32649, 1538950604, -5132231446581182741L, -31816L, false, true, (char) 58177, (char) 45929,
        Double.longBitsToDouble(0x3fef455dde06cf9fL), Double.longBitsToDouble(0x3fdd471b8470a63eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55]\012",
        Z.run(T, 1, 12, 3, 13, "\udabb\ude55", "\u5886\ubd3c", "\ud929\udf4d\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\000\000\ud8ec\uddbf\ud832\udd43\u00d8\000\udaa3\udd51\udad8\ude98\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1",
        1, 52095, -1950533288, -2620733125107775663L, -100000L, true, true, (char) 62347, (char) 638,
        Double.longBitsToDouble(0x3fe95926a3f7b124L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\ud957\udf1a\udb9e\udf1f\udb80\udcee\udbb6\udf37]\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\ud957\udf1a\udb9e\udf1f\udb80\udcee\udbb6\udf37]\012",
        Z.run(T, 2, 15, 15, 4, "\ud957\udf1a\udb9e\udf1f\udb80\udcee\udbb6\udf37", "\u1d32\u88c7\u0b02\u251b\uc727\u8d43", "\ud937\udd0f\udbdc\udc2c",
        33, 58421, 286896665, 6391070454435607709L, 73054L, true, false, (char) 8678, (char) 18270,
        Double.longBitsToDouble(0x3fee3d51795827c2L), Double.longBitsToDouble(0x3fdbad93bea2816cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\ud957\udf1a, \ud9e0\udf8d\ud9f5\udc00\ud852\udd7d\udadb\uddc2\udb19\udf9d\ud9a7\uddf0\ud8b4\ude83\udbcf\udd6a\ud8ec\ude7d\udb9a\udcb6\udac0\udf5c\udbed\udde2\ud820\uddf2\udbb5\uddb9\udb3b\uddd5\u90a8\ud89b\udf53\ud8d4\ude75]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 3, 13, "\ud957\udf1a", "\uc387\u5ce5", "\ud9e0\udf8d\ud9f5\udc00\ud852\udd7d\udadb\uddc2\udb19\udf9d\ud9a7\uddf0\ud8b4\ude83\udbcf\udd6a\ud8ec\ude7d\udb9a\udcb6\udac0\udf5c\udbed\udde2\ud820\uddf2\udbb5\uddb9\udb3b\uddd5\u90a8\ud89b\udf53\ud8d4\ude75",
        20, 52095, -650430120, -5857404407605754031L, 77041L, true, true, (char) 30877, (char) 41406,
        Double.longBitsToDouble(0x3f84b52efdf59ac0L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.list.SetUniqueList:[]\0121=org.apache.commons.collections4.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[]\012",
        Z.run(T, 2, 6, 10, 1, "\ud957\udf1a\udb9e\udf1f\udb80\udcee\udbb6\udf37\udad0\udd63\ud8bb\udc54\ud80c\ude5e\ud9e0\udf8d\ud9f5\udc00\ud852\udd7d\ud8da\udf44\udb2b\ude6e\udb3a\udca5\ud8c3\udf27\udbcf\udd6a\ud8ec\ude7d\udb9a\udcb6", "\ubdd6\u1844\u33b3\u4c66\u9f42\u6b76\uaffc\u3c72\u234b\ud45d\u80ea\u4cfa\u7d04\u90fc", "\uda7b\udc4c\udbfe\udc72\ud833\udd32\udb58\ude11\ud95a\udc58\ud9bd\ude5d\ud9f0\udf05\ud9b9\uddf6\ud9fe\udcd3",
        58, 45474, 159746856, -7059830241827832432L, 76565L, false, true, (char) 40507, (char) 27075,
        Double.longBitsToDouble(0x3fee952cf836c260L), Double.longBitsToDouble(0x3fe42c38281975edL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\ud957\udf1a]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 14, 15, "\ud957\udf1a", "\uc387\u5ce5", "\ud9e0\udf8d\ud9f5\udc00\ud852\udd7d\ud8da\udf44\u6565\udb3a\udc7a\ud831\udfbe\udbbc\udd67\ud8ec\ude7d\udb9a\udcb6\udac0\udf5c\udbed\udde2\ud820\uddf2\udbb5\uddb9\udb3b\uddd5\u90a8\ud872\uddb9\ud8d4\ude75",
        20, 52095, -650430120, -5857404407605754031L, 52560L, false, false, (char) 49302, (char) 4288,
        Double.longBitsToDouble(0x3f84b460fdf59ac0L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\ud957\udf1a]\0121=org.apache.commons.collections4.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\ud957\udf1a]\012",
        Z.run(T, 2, 10, 11, 13, "\ud957\udf1a", "\uc387", "\ud82d\udc6e\ud9e0\udf8d\ud983\udc26\uda84\udeec\udb0e\udf9e\u6565\udb3a\udc7a\ud8c3\udf27\udbcf\udd6a\ud8ec\ude7d\udb9a\udcb6\udac0\udf5c\udbed\udde2\ud820\uddf2\udbb5\uddb9\udb3b\uddd5\u90a8\ud89b\udf53\ud8d4\ude75\ud89e\udc97\udb4f\ude1e\ud83d\udf0f\uda7f\udcef\udac6\uddd3",
        36, 54119, 1902185116, -6172735431613847959L, 36201L, true, false, (char) 61813, (char) 48377,
        Double.longBitsToDouble(0x3fdd4c8093694ec6L), Double.longBitsToDouble(0x3fc5313027b6666cL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.list.SetUniqueList:[]\0121=void |this=org.apache.commons.collections4.list.SetUniqueList:[]\012",
        Z.run(T, 2, 6, 6, 15, "\ud957\udf1a", "\ucc0d\u5ce5", "\ud901\ude2d\ud9f5\udc00\ud854\udd7d\udb39\ude57\ud956\udf2c\udb51\udd34\ud8c3\udf27\ud820\udc59\udac5\udda0\uda09\udfc9\udac0\udf5c\udbed\udde2\ud820\uddf2\udbb5\uddb9\udb3b\uddd5\u90a8\ud975\udd83\uda54\udd53",
        49, 77100, 568488316, -5857404407605754031L, 11505L, false, false, (char) 31541, (char) 4288,
        Double.longBitsToDouble(0x3f84b46137b59ac0L), Double.longBitsToDouble(0x3fe82a3c157254b5L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\ud863\ude15]\012",
        Z.run(T, 1, 4, 3, 13, "\ud863\ude15", "", "",
        54, 17029, 549338156, -7575246438200675805L, 20524L, true, true, (char) 6327, (char) 9204,
        Double.longBitsToDouble(0x3fc7c4801268b800L), Double.longBitsToDouble(0x3fdd800009c237feL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.list.SetUniqueList:[\u4c21]\012",
        Z.run(T, 1, 2, 4, 11, "\u4c21", "", "",
        54, 65641, 1528695201, -8188882314294365661L, 20524L, false, true, (char) 27944, (char) 63926,
        Double.longBitsToDouble(0x3fc7c48014f1ff88L), Double.longBitsToDouble(0x3fe0b00004e1bbdcL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udabb\ude55\ud97e\udc29\u0719\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39] |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\ud97e\udc29\u0719\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39]\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\ud97e\udc29\u0719\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39, \udabb\ude55\ud97e\udc29\u0719\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39]\012",
        Z.run(T, 2, 9, 3, 13, "\udabb\ude55\ud97e\udc29\u0719\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39", "\uac3f\u3d3d\ud04b\u3f12\ub6c8\u538d\u8707", "\udad8\ude98\ud915\ude1e\u9d5b\udb1a\udfdc",
        0, 25595, 667057095, -8377476682329536228L, -38703L, true, false, (char) 899, (char) 53066,
        Double.longBitsToDouble(0x3fe7bd9c5a863d00L), Double.longBitsToDouble(0x3fe36007fadb7eebL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udabb\ude55\ud97e\udc29\uef7d\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39] |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\ud97e\udc29\uef7d\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39]\0121=java.util.TreeSet:[\uac3f\u3d3d\ud04b] |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\ud97e\udc29\uef7d\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39]\012",
        Z.run(T, 2, 9, 9, 13, "\udabb\ude55\ud97e\udc29\uef7d\ud85a\udea8\udb72\udfb3\ud895\udf68\ud8db\udf47\uda81\udeff\ud9ea\udc39", "\uac3f\u3d3d\ud04b", "\ud832\udd43\ud91c\udc88\udbed\uddd8",
        21, 78253, 18140686, -76247371840845184L, 63563L, false, false, (char) 26243, (char) 15180,
        Double.longBitsToDouble(0x3fea8edcb88fa2daL), Double.longBitsToDouble(0x3fbbe5eed4e7c730L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\u7e51, \uda81\udeff\ud9ea\udc39\uda9f\udd51\uda0b\udda7\ud8c7\udd14\udaf6\udcd4\udbbf\udda6\ud834\udcce\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud9c5\udfae\ud853\uddf6]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 2, 15, "\u7e51", "\u602e\u39b0", "\uda81\udeff\ud9ea\udc39\uda9f\udd51\uda0b\udda7\ud8c7\udd14\udaf6\udcd4\udbbf\udda6\ud834\udcce\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud9c5\udfae\ud853\uddf6",
        19, 24181, 1530528654, 1857355175097827051L, -31816L, false, true, (char) 8833, (char) 45929,
        Double.longBitsToDouble(0x3fef455dde06cf9fL), Double.longBitsToDouble(0x3fdd471b82f2a63eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55, \uda81\udeff\ud9ea\udc39\uda9f\udd51\uda0b\udda7\ud8c7\udd14\udaf6\udcd4\udb27\ude5a\udbbc\udc89\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\u8ee3\ud9b6\udf75]\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55, \uda81\udeff\ud9ea\udc39\uda9f\udd51\uda0b\udda7\ud8c7\udd14\udaf6\udcd4\udb27\ude5a\udbbc\udc89\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\u8ee3\ud9b6\udf75, \udabb\ude55]\012",
        Z.run(T, 2, 1, 4, 0, "\udabb\ude55", "\u602e\u8028", "\uda81\udeff\ud9ea\udc39\uda9f\udd51\uda0b\udda7\ud8c7\udd14\udaf6\udcd4\udb27\ude5a\udbbc\udc89\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\u8ee3\ud9b6\udf75",
        26, 32649, -1478009396, -5132231446581182741L, -92488L, false, true, (char) 58177, (char) 45929,
        Double.longBitsToDouble(0x3fef455dde06cf9fL), Double.longBitsToDouble(0x3fefb4e95a3853b4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\udb99\udd4d\ud8d9\udef6\udbc4\udd7d\ud890\udfa6\ud830\udf11\ud9b1\udf7e\uda81\udeff, \udaaf\ude5f\ud9e3\ude77\udb72\udf33\ud9c4\ude7e]\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\udb99\udd4d\ud8d9\udef6\udbc4\udd7d\ud890\udfa6\ud830\udf11\ud9b1\udf7e\uda81\udeff, \udaaf\ude5f\ud9e3\ude77\udb72\udf33\ud9c4\ude7e, \udabb\ude55\udb99\udd4d\ud8d9\udef6\udbc4\udd7d\ud890\udfa6\ud830\udf11\ud9b1\udf7e\uda81\udeff]\012",
        Z.run(T, 2, 1, 1, 6, "\udabb\ude55\udb99\udd4d\ud8d9\udef6\udbc4\udd7d\ud890\udfa6\ud830\udf11\ud9b1\udf7e\uda81\udeff", "\u91a3\uac3f\u1098\uc6f5\uca30\u77e0\u538d\u5707\u5925", "\udaaf\ude5f\ud9e3\ude77\udb72\udf33\ud9c4\ude7e",
        0, 52051, -1950545320, -2598516393156933807L, -61064L, false, false, (char) 31628, (char) 23895,
        Double.longBitsToDouble(0x3fe99b83722f2a05L), Double.longBitsToDouble(0x3fef09c269997e11L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\ud864\ude44]\0121=org.apache.commons.collections4.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\ud864\ude44]\012",
        Z.run(T, 2, 11, 11, 15, "\ud864\ude44", "\uc387\u5ce5", "\ud9e0\udf8d\ud9f5\udc00\ud852\udd7d\ud8da\udf44\u6565\udb3a\udc7a\ud831\udfbe\udbbc\udd67\ud8ec\ude7d\udb9a\udcb6\udac0\udf5c\udbed\udde2\ud820\uddf2\ud9ea\udf64\udac0\uddab\ud89b\udf81\uda11\udde3\uad8d",
        20, 52095, -650430120, -5857404407605754031L, 2379L, true, false, (char) 8762, (char) 62347,
        Double.longBitsToDouble(0x3fe5febcc99067e6L), Double.longBitsToDouble(0x3feb457a184959afL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\ud863\ude15]\012",
        Z.run(T, 1, 1, 3, 13, "\ud863\ude15", "", "",
        54, 17029, 549338156, -7575246438200675805L, 20524L, true, true, (char) 6327, (char) 9204,
        Double.longBitsToDouble(0x3fc7c4801268b800L), Double.longBitsToDouble(0x3fdd800009c237feL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.set.UnmodifiableSet:[\uce8f\u8ca1\u2077\u025f\u5eea\u6328\u89c2\u6670\uab01\u5ac6\u09c6\u47da\u6f05\uc7ec\u40ae\u9471\u25e8\u3fb6\u9c72] |this=org.apache.commons.collections4.list.SetUniqueList:[\uda40\udc25\udb27\udfb5\ud86e\uddb0\uda57\udd08\uda78\udf30\udbf1\ude40\ud8f5\udfe7\udbf6\udf0f\ud9e8\udc49\ud8bd\ude52\ud874\uddb9\ud985\udddf\ud91c\udf5f\ud9ab\udd46\ud873\udd7e\udbec\udf73\udbd9\udf00\udad2\udc95\uda97\udf98\ud847\uddfd\udb24\udf0f\udb91\udcea\udb25\udec8\ud824\ude97\ud8be\udedb\udb50\udf6b]\0121=org.apache.commons.collections4.set.UnmodifiableSet:[\uce8f\u8ca1\u2077\u025f\u5eea\u6328\u89c2\u6670\uab01\u5ac6\u09c6\u47da\u6f05\uc7ec\u40ae\u9471\u25e8\u3fb6\u9c72] |this=org.apache.commons.collections4.list.SetUniqueList:[\uda40\udc25\udb27\udfb5\ud86e\uddb0\uda57\udd08\uda78\udf30\udbf1\ude40\ud8f5\udfe7\udbf6\udf0f\ud9e8\udc49\ud8bd\ude52\ud874\uddb9\ud985\udddf\ud91c\udf5f\ud9ab\udd46\ud873\udd7e\udbec\udf73\udbd9\udf00\udad2\udc95\uda97\udf98\ud847\uddfd\udb24\udf0f\udb91\udcea\udb25\udec8\ud824\ude97\ud8be\udedb\udb50\udf6b]\012",
        Z.run(T, 2, 5, 5, 2, "\uda40\udc25\udb27\udfb5\ud86e\uddb0\uda57\udd08\uda78\udf30\udbf1\ude40\ud8f5\udfe7\udbf6\udf0f\ud9e8\udc49\ud8bd\ude52\ud874\uddb9\ud985\udddf\ud91c\udf5f\ud9ab\udd46\ud873\udd7e\udbec\udf73\udbd9\udf00\udad2\udc95\uda97\udf98\ud847\uddfd\udb24\udf0f\udb91\udcea\udb25\udec8\ud824\ude97\ud8be\udedb\udb50\udf6b", "\uce8f\u8ca1\u2077\u025f\u5eea\u6328\u89c2\u6670\uab01\u5ac6\u09c6\u47da\u6f05\uc7ec\u40ae\u9471\u25e8\u3fb6\u9c72", "\ud9a8\uddae\ud829\udf6a\udaba\udd6d\ud882\udfdf\udadf\ude37\ud9f4\udc77\ud96b\udede\ud9af\uddf4\uda5b\udd08\udb9f\udff9\ud82c\udcdc\udbfc\udf44\udb4b\udc10\ud806\uddc7\u4fe8\ud9d7\udd22\ud8dd\udda6\udbe0\udf1d\udb5f\udd3c",
        18, 41176, 679219416, -8870237841972173903L, 48531L, false, true, (char) 46320, (char) 18575,
        Double.longBitsToDouble(0x3fe16620c1312116L), Double.longBitsToDouble(0x3fdac6914423e7dcL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55]\012",
        Z.run(T, 1, 15, 3, 13, "\udabb\ude55", "\u5a89\u944e", "\uda81\udeff\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\ud832\udd43\ud985\udf7e\udbed\udde2\ud853\ude1b\udad8\ude98\udb5c\udfc2\udbe3\udc20\uda54\udd7b\ud947\udcd1",
        5, 52095, -1950533288, -2620733125107775663L, 11505L, false, false, (char) 46530, (char) 23895,
        Double.longBitsToDouble(0x3f843bc6fdf59ac0L), Double.longBitsToDouble(0x3fe5febcc99067e6L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude89, \ud8e3\udf44\ud89a\udf93\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\udb25\udfdc\ud985\udf7e\udbed\udde2]\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude89, \ud8e3\udf44\ud89a\udf93\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\udb25\udfdc\ud985\udf7e\udbed\udde2, \udabb\ude89]\012",
        Z.run(T, 2, 4, 4, 6, "\udabb\ude89", "\ua6fb\u69c0\u0cf7\u1550\ua09f", "\ud8e3\udf44\ud89a\udf93\ud8c2\udd1b\ud890\udff3\udbcf\udd6a\ud8ec\ude7d\udb25\udfdc\ud985\udf7e\udbed\udde2",
        21, 2461, 806342158, 6831669863534149673L, 63563L, false, false, (char) 57389, (char) 36956,
        Double.longBitsToDouble(0x3fec86fe988fa2daL), Double.longBitsToDouble(0x3fe1caa1546cf8e6L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\ud811\udfff\udaae\udfe8]\0121=org.apache.commons.collections4.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections4.list.SetUniqueList:[\ud811\udfff\udaae\udfe8]\012",
        Z.run(T, 2, 10, 10, 9, "\ud811\udfff\udaae\udfe8", "\u9b51\u593c\ub523\ubae7\u662d\u1a62\u91a3\ua0fd", "\udb3a\udc49\ud95b\udcbf",
        -5, 16122, 298093170, 8439833645655318649L, 21313L, false, true, (char) 619, (char) 64945,
        Double.longBitsToDouble(0x3fecddab9a5827c2L), Double.longBitsToDouble(0x3fe8e45def51dbf0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 3, 13, "", "", "",
        -5, 24889, 1927314857, 68471012883917312L, -100000L, false, false, (char) 0, (char) 0,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\udb9c\udc79\udb7a\udc7e\ud85a\udea8\udb72\udfb3\ud898\udd68\udbb6\udeb4\uda81\udf59\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udc6d\ud890\udff3\udbcf\udd6a\ud817\udc91\ud82b\udf78\ud985\udf7e\udbeb\uddaa\uda14\udd9c\udac0\ude5c\udbf1\udd3e\ud83d\ude26\u1fad\udade\udd49\ud860\ude3a\udb4f\ude1e\u627e\ud90b\uddf7\ud803\ude20\udbb8\ude0a\udb7d\udc03\ud8c7\ude64\ud9f7\udede\udbfc\udc59\ud9c1\udc01\ud9d9\udeaa\ud9f5\udcde\udbbb\udf21\ud8ce\udc9e\udb45\udd63\udb0c\udc34\udb6b\udf3a\ud9ff\udce8\udabc\udf72\udb08\udd54\udb75\udcdd\udbfd\udf4a\udad0\udf70\uda96\ude70\uda1b\ude09\ud946\ude64\udb21\udd2a\ud875\udf0a\ud843\udcf1\ud8df\udfed\ue5bf\ud9ab\udecb\uda35\ude50\uda43\udd09\udb9d\ude4a\ud8a2\udeea\ud856\udc0f\ud913\udd82\udbc2\udd20\u4a5d\udab6\udd1d\udb59\udd60, \ud8c8\udf7a\udb34\udc6c\udb09\udc27\ud86f\udfc7\udba9\ude1e\ud843\uddbd\ud868\udf85\udac4\ude8a\ud87a\ude1b\uda39\ude09\ud89b\udd25\ud851\udeae\ud81c\udcde\udab6\udc6d\ud930\udf91\uda85\udded]\0121=java.lang.Boolean:true |this=org.apache.commons.collections4.list.SetUniqueList:[\udabb\ude55\udb9c\udc79\udb7a\udc7e\ud85a\udea8\udb72\udfb3\ud898\udd68\udbb6\udeb4\uda81\udf59\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udc6d\ud890\udff3\udbcf\udd6a\ud817\udc91\ud82b\udf78\ud985\udf7e\udbeb\uddaa\uda14\udd9c\udac0\ude5c\udbf1\udd3e\ud83d\ude26\u1fad\udade\udd49\ud860\ude3a\udb4f\ude1e\u627e\ud90b\uddf7\ud803\ude20\udbb8\ude0a\udb7d\udc03\ud8c7\ude64\ud9f7\udede\udbfc\udc59\ud9c1\udc01\ud9d9\udeaa\ud9f5\udcde\udbbb\udf21\ud8ce\udc9e\udb45\udd63\udb0c\udc34\udb6b\udf3a\ud9ff\udce8\udabc\udf72\udb08\udd54\udb75\udcdd\udbfd\udf4a\udad0\udf70\uda96\ude70\uda1b\ude09\ud946\ude64\udb21\udd2a\ud875\udf0a\ud843\udcf1\ud8df\udfed\ue5bf\ud9ab\udecb\uda35\ude50\uda43\udd09\udb9d\ude4a\ud8a2\udeea\ud856\udc0f\ud913\udd82\udbc2\udd20\u4a5d\udab6\udd1d\udb59\udd60, \ud8c8\udf7a\udb34\udc6c\udb09\udc27\ud86f\udfc7\udba9\ude1e\ud843\uddbd\ud868\udf85\udac4\ude8a\ud87a\ude1b\uda39\ude09\ud89b\udd25\ud851\udeae\ud81c\udcde\udab6\udc6d\ud930\udf91\uda85\udded, \udabb\ude55\udb9c\udc79\udb7a\udc7e\ud85a\udea8\udb72\udfb3\ud898\udd68\udbb6\udeb4\uda81\udf59\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udc6d\ud890\udff3\udbcf\udd6a\ud817\udc91\ud82b\udf78\ud985\udf7e\udbeb\uddaa\uda14\udd9c\udac0\ude5c\udbf1\udd3e\ud83d\ude26\u1fad\udade\udd49\ud860\ude3a\udb4f\ude1e\u627e\ud90b\uddf7\ud803\ude20\udbb8\ude0a\udb7d\udc03\ud8c7\ude64\ud9f7\udede\udbfc\udc59\ud9c1\udc01\ud9d9\udeaa\ud9f5\udcde\udbbb\udf21\ud8ce\udc9e\udb45\udd63\udb0c\udc34\udb6b\udf3a\ud9ff\udce8\udabc\udf72\udb08\udd54\udb75\udcdd\udbfd\udf4a\udad0\udf70\uda96\ude70\uda1b\ude09\ud946\ude64\udb21\udd2a\ud875\udf0a\ud843\udcf1\ud8df\udfed\ue5bf\ud9ab\udecb\uda35\ude50\uda43\udd09\udb9d\ude4a\ud8a2\udeea\ud856\udc0f\ud913\udd82\udbc2\udd20\u4a5d\udab6\udd1d\udb59...\012",
        Z.run(T, 2, 1, 1, 1, "\udabb\ude55\udb9c\udc79\udb7a\udc7e\ud85a\udea8\udb72\udfb3\ud898\udd68\udbb6\udeb4\uda81\udf59\ud9ea\udc39\ud852\udd7d\ud8da\udf44\ud8c7\udd14\ud8c2\udc6d\ud890\udff3\udbcf\udd6a\ud817\udc91\ud82b\udf78\ud985\udf7e\udbeb\uddaa\uda14\udd9c\udac0\ude5c\udbf1\udd3e\ud83d\ude26\u1fad\udade\udd49\ud860\ude3a\udb4f\ude1e\u627e\ud90b\uddf7\ud803\ude20\udbb8\ude0a\udb7d\udc03\ud8c7\ude64\ud9f7\udede\udbfc\udc59\ud9c1\udc01\ud9d9\udeaa\ud9f5\udcde\udbbb\udf21\ud8ce\udc9e\udb45\udd63\udb0c\udc34\udb6b\udf3a\ud9ff\udce8\udabc\udf72\udb08\udd54\udb75\udcdd\udbfd\udf4a\udad0\udf70\uda96\ude70\uda1b\ude09\ud946\ude64\udb21\udd2a\ud875\udf0a\ud843\udcf1\ud8df\udfed\ue5bf\ud9ab\udecb\uda35\ude50\uda43\udd09\udb9d\ude4a\ud8a2\udeea\ud856\udc0f\ud913\udd82\udbc2\udd20\u4a5d\udab6\udd1d\udb59\udd60", "\u447b\u4900\u962d\u9bb9\u07ba\u0667\u6f7e\u61f3\uc538\u7764\u428a\u5b5c\u3985\u608b\u627d\u1d31\u411b\ub276\ud0e8\u7611", "\ud8c8\udf7a\udb34\udc6c\udb09\udc27\ud86f\udfc7\udba9\ude1e\ud843\uddbd\ud868\udf85\udac4\ude8a\ud87a\ude1b\uda39\ude09\ud89b\udd25\ud851\udeae\ud81c\udcde\udab6\udc6d\ud930\udf91\uda85\udded",
        16, 56084, 353538554, 1780900382848496933L, -87450L, true, false, (char) 54437, (char) 46946,
        Double.longBitsToDouble(0x3fe9b86937368de0L), Double.longBitsToDouble(0x3fe77413b9ec0dbfL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.list.SetUniqueList:[]\012",
        Z.run(T, 2, 1, 1, 1, "", "", "",
        29, 44254, -840794711, 6565696278487580396L, 3771L, false, false, (char) 0, (char) 8759,
        Double.longBitsToDouble(0x3fae973d1be24000L), Double.longBitsToDouble(0x3f885fdb76240000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections4.list.SetUniqueList|subList|int,int|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|add|java.lang.Object|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|add|int,java.lang.Object|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|addAll|int,java.util.Collection|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|addAll|java.util.Collection|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|asSet||new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|clear||new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|contains|java.lang.Object|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|containsAll|java.util.Collection|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|createSetBasedOnList|java.util.Set,java.util.List|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|iterator||new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|listIterator||new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|listIterator|int|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|remove|java.lang.Object|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|remove|int|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|removeAll|java.util.Collection|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections4.list.SetUniqueList|subList|int,int|new:org.apache.commons.collections4.list.SetUniqueList:java.util.List,java.util.Set",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
