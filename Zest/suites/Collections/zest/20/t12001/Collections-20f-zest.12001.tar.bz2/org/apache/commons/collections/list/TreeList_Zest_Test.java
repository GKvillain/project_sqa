package org.apache.commons.collections.list;
import org.junit.Test;
import static org.junit.Assert.*;
public class TreeList_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 12, 5, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, 1973680754413823841L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 12, 5, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\ud9f2\udf81\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ubd09\uae16\u61b2\u7471\u4216\ubc2f\u4ffc\u83c3\ub8b2\u7882", "\ud9a5\udf5a\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3",
        16, 11559, -849381121, 4575790121040992048L, -59741L, true, true, (char) 3348, (char) 18432,
        Double.longBitsToDouble(0x3fa404b0ba7faea0L), Double.longBitsToDouble(0x3fd7786330930c3eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 12, 5, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\udb2e\ude66\ud84e\udcc6\uda9b\udd5d\ud8a6\udcfb", "\ub107\uc04c\u5ad4\u08ca\u6d8c]\u65aa\u7802\ub09c\ub24d\u3d14\u7471\u4216\uc844\u4ffc\u83c3\u5700\u4f77\u6aa6", "\udb9f\udd81\udaa1\udd79",
        -5, 1246, -275414441, 8169381286750746847L, -73535L, false, false, (char) 35399, (char) 61998,
        Double.longBitsToDouble(0x3fee2ee23cee5c52L), Double.longBitsToDouble(0x3fdb76ad894442c2L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 7, 4, 5, "\udba6\udeb5\udbf3\uddc8\udb75\udd6a\ud915\udfb3\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u2b86\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u8adf\u5700\u4f77", "\ud9a5\udf90\udac7\udf32\udb91\udf97\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, -5520871975484127768L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[]] |this=org.apache.commons.collections.list.TreeList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 12, 9, 2, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\ud9f3\udeb2\ud984\udc5b", "\u4a90\u59be\u8b56\ud6bd", "\ud890\udf06\ud809\udf33\ud831\udfe1\ud9a7\udeb5\udb93\uddd1\udbe8\ude14\ud9a5\udfd1\udb3f\udf2d\udbe3\udc2b\ud9b4\udf29\uda33\udf25\udbe8\udc08\udafb\udd12\ue243\ud9aa\udfe8",
        24, 54376, 1424366177, -7759486117584280208L, 82673L, false, false, (char) 14421, (char) 199,
        Double.longBitsToDouble(0x3feb3eccabbaa468L), Double.longBitsToDouble(0x3fd4fb480e9c39feL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Integer:-1 |this=org.apache.commons.collections.list.TreeList:[]\0121=void |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 6, 3, 5, "\ud989\udf2b\udbc9\udd26\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\ud868\udd14\udbb1\udc9c", "\u9783\u1c2b\u13d1\u29c6\ub107\uc04c\u5ad4\uab7c\u5885\u88c0\u64f7\u7802\ub09c\u396d\u11d2\u6806\ub2e7\u484d\u2791\u83c3\u5700", "\uda36\udeba\ud9a5\udf90\ud8e8\udc42\udbef\udfad\uda76\udfc8\uda0d\udc11\udaf1\udc85\udb80\udf14\ud948\udc55\ud8b7\ude4b\ud875\uddad\udab1\udd2b",
        21, 24810, 30607129, -4765291566977146895L, -70215L, true, true, (char) 42368, (char) 64909,
        Double.longBitsToDouble(0x3fea77afaf4f339fL), Double.longBitsToDouble(0x3fc360c56b45b3e4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 3, 4, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, 1973680754413823841L, -2028L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 10, 12, 5, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\ud6ed\u41a1\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, 1973680754413823841L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fb0073624d033a0L), Double.longBitsToDouble(0x3fee126bad778633L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 12, 5, "\udba6\udeb5\udbc9\udcac\uda2e\udc44\udb7c\uddd5\ud983\udfe2\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\u00f0\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\u299c\u1bc9\u61ab\u7471\u4216\ubc2f\u00e8\u914a\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        44, 29975, 1065353216, 1973680752620994657L, -100000L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755770000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.TreeList:[]\0121=[Ljava.lang.Object;:[[]] |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 4, 12, 1, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\uc6cf\ucc3e\u16d6\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf8c\ud8e8\udc42\udb92\udcb5\ud9ab\udfd3\ud8e1\udd7d\ud932\udd5f\ud8a7\ude03\u6c9d\uade7\ud875\uddc4\udab1\udd2b\uda13\udc29\ud824\udca2\udb50\udd35\udbd4\udf39\uda13\ude44\ud91f\udfdb\ud9c7\udc79\ud991\udebf\udaa7\ude1b\uda83\udc32\udbac\udf2c\ud85c\udf5b",
        48, 21453, -1892851174, 6416482363039112591L, 25530L, true, false, (char) 25398, (char) 4790,
        Double.longBitsToDouble(0x3fde528c143be022L), Double.longBitsToDouble(0x3feef9d8fb663a6aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 12, 5, "\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        44, 27879, -2095154977, 5126345355976668350L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[]] |this=org.apache.commons.collections.list.TreeList:[]\0121=[Ljava.lang.Object;:[[]] |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 12, 12, 5, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\udbc3\udf3a\udb2c\udfd6\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\ud9c0\udd15", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u0c21\u1817\u6ba9\u6bf0", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, 1973680754413823841L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd757af5a5aL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 10, 5, "\udba6\udeb5\udbc9\udd13\ud86d\udfc5\ud9f8\udf60\ud984\udc45\udabb\ude82\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u10c4\u91d1\u39c4\u65aa\u7802\ub0de\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\u4e14\uda43\udd96\uda0d\udc11",
        44, 27879, 1065384159, 1973680754413823841L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.TreeList:[]\0121=java.lang.Integer:-1 |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 4, 6, 5, "\udb48\uded0\uda8c\ude7c\udbaf\uded1\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\udbf5\udda3\ud9a1\udec3\u7492", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\u055a", "\udb33\udcad\ue243\ud9aa\udfe8\udbfd\udf11\ud9d4\ude88\udb49\udf61\ud838\uddb8",
        37, 898, 1640788429, -6742805886087884753L, -76272L, false, true, (char) 26773, (char) 17983,
        Double.longBitsToDouble(0x3fa81fc07611b630L), Double.longBitsToDouble(0x3fae356e4d60fe30L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 14, 3, "\udad8\udf25\uda8d\udd15\uda2e\udc44\uda76\uddd2", "\u77b6\ub52f\u59be\u8b56\ud6bd\u6b2a\u405a\u59a3", "\ud854\uddf2\udb4c\udd71",
        19, 56321, -1683222597, 5824307046383615477L, -30864L, false, true, (char) 6823, (char) 37646,
        Double.longBitsToDouble(0x3feea2762a682536L), Double.longBitsToDouble(0x3fe30808be7d54e6L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.list.TreeList:[\udba6\udeb5\udbc9\udd13\uda2e\udc44\ub9cf\ud984\udc5b]\0121=[Ljava.lang.Object;:[[]] |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 14, 12, 12, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\ub9cf\ud984\udc5b", "\u4a90\u59be\u8b56\ud6bd", "\ud8d7\udd15\ud8b2\ude73\ud96e\ude6a\udb30\udf4d\udb93\uddd1\udbe8\ude14\ud9a5\udfd1\udb3f\udf2d\ud82d\ude11\udbde\udcdf\ud950\udce8\udb2d\udcd0\udb33\udcad\ue243\ud9aa\udfe8\udbfd\udf11\ud9d4\ude88",
        47, 90373, 964593282, -8327057260126899763L, 59697L, true, false, (char) 14421, (char) 199,
        Double.longBitsToDouble(0x3fcffdf2a37c257cL), Double.longBitsToDouble(0x3fa81fc07611b630L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 12, 5, "\uda65\udf2f\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\uda97\udcc0\uda51\ude4d\uda29\udf05\ud967\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\ucd33\uc097\ub09c\u683b\u622e\u7471\u59ca\u79e5\u4ffc\u83c3\uadef\u4f77", "\ud9a5\udf90\ud932\ude2b\udb74\ude70\u2593\ud9a8\udf9f",
        24, 23934, 1647484742, 1973680754413823841L, 9782L, false, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd754951935L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.list.TreeList:[\udba6\udeb5\udbc9\udd13\ud8fe\udc4c\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01]\0121=new org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 14, 13, 5, "\udba6\udeb5\udbc9\udd13\ud8fe\udc4c\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ua394\u7151\ub41c\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9e9\ude13\ud8d7\udc83\udb92\udcc6\ud8c9\udd21\udbb6\udd2a",
        44, 27879, 1384151263, 1973508008613955681L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.list.TreeList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 0, 12, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udbfa\udfcf\ud984\udc5b\u60a5\ud8fa\udedd\ud81b\udc97\uda22\uddfb\udba2\uddd2\ud9ba\udc36\ud9f1\udc72", "\u740b\u3a4a\ubda5\u083a\ud692\u88c0\u65aa\u1bdd\ub7bb\u683b\u622e\u83bb\u05c5\ub5c6\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud917\udf45\uda12\udf51\ud990\ude4c\ud84c\udd36",
        44, 84695, 1065384159, 1973680754413823841L, 9782L, true, false, (char) 36876, (char) 52126,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 2, 5, "\ud856\udfef\udbc9\udda1\uda2e\udc44\udb7c\uddd5\ud87a\udf15\u0621\ud995\udee8\ud87e\udec7\uda02\udc1b\uda9c\udd9d\udba8\udc9a\uda1e\udd01", "\u064f\u3bc3\u919f\uaf49\u8b0a\u88c0\u65aa\u35ae\u412f\u05c1\u61b9\u7471\u4216\u6e7f\uafd8\uc40e\u99a0\u02b2\u53df\u99e2\u4d80", "\ud80d\udc9e\udb33\udece\uda39\udcd4\uda01\udc31\uda0b\udf9b\ud8dd\udc74\uda9e\udfe3\udab4\udc80\udb13\udf02",
        50, 17596, -548818859, -5058652521448677214L, 39232L, true, true, (char) 4879, (char) 42339,
        Double.longBitsToDouble(0x3fd41b287ffdc11cL), Double.longBitsToDouble(0x3feef4184559de38L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.TreeList:[]\0121=new org.apache.commons.collections.list.TreeList:[\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\ud972\udf81\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01]\012",
        Z.run(T, 2, 4, 14, 5, "\udba6\udeb5\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\ud972\udf81\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u22d8\u6411\ud692\u88c0\u01ab\u7802\ubd09\u636f\u5953\u7471\u4216\ubc2f\u4ffc\u83c3\ub8b2\u7882", "\ud9a5\udf5a\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3",
        16, 11559, -849381121, 4575790121040992048L, -59741L, true, true, (char) 3348, (char) 18432,
        Double.longBitsToDouble(0x3fa404b0ba7faea0L), Double.longBitsToDouble(0x3fd7786330930c3eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.list.TreeList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 5, 5, "\ud843\udd6c\uda5a\udd27\udaa4\udf18\udaaf\udcb2\ud8b8\udc5e\u0ba3\udb1d\udf8a\udb9d\ude85\udb2e\ude66\ud84e\udcc6\udbfa\udcc6\ud84b\udfe6", "\ub107\u407c\u5ad4\u08ca\u6d8c]\u65aa\u7802\u0935\ua88c\u3d14\u7471\u4216\ub3b7\ud386\u7c74\u9e97\u4f77\u6aa6", "\ud8ea\ude84\udaa1\udd79",
        -5, 1246, -275414441, 8169381286750746847L, -73535L, false, false, (char) 35399, (char) 61998,
        Double.longBitsToDouble(0x3fee2ee23cee5c52L), Double.longBitsToDouble(0x3fdb76ad89a7f8c2L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 4, 5, "\udba6\udeb5\udbf3\uddc8\udb75\udd6a\ud915\udfb3\ud9e5\ude8b\ud81e\udc3e\u99d9\ud8aa\udc0d\uda29\udf05\ud86b\ude86\ud8ea\udf74\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u2b86\ub08d\u683b\u622e\u7471\u4216\ubc2f\u4ffc\ucf05\u5700\u4f77", "\ud9a5\udf90\udac7\udf32\udb91\udf97\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, -5520871975484127768L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805013c6L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.TreeList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 2, 9, "\udba6\udeb5\udbff\uddc8\udb75\udd6a\ud915\udfb3\ud984\udc5b\ud982\uddda\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\u20a7\u4aee\u5ad4\u08ca\ud692\u88c0\u65aa\u2b86\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u8adf\u5700\u4f77", "\ud9a5\udf90\udac7\udf32\udb91\udf97\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, -5520871975484094141L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad8f208f06L), Double.longBitsToDouble(0x3f657a4577864700L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.TreeList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 4, 4, 5, "\ud98d\ude9b\udbf3\udd7f\udb56\ude6a\ud915\udfb3\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u2b86\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u8adf\u5700\u4f77", "\ud9a5\udf90\udac7\udf32\udb91\udf97\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, -5520871975484127768L, 9782L, true, false, (char) 54563, (char) 63845,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 1, 13, 6, 0, "\udba6\udeb5\udbf3\uddc8\udb75\udd6a\uda02\udd0a\ud862\udd87\ud959\udc0d\udb60\udc97\uda5f\udeb5\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\u4966\ud046\u5ad4\u08ca\uae91\u88c0\u65aa\u2b86\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u8adf\u5700\u4f77", "\ud9a5\udf90\udac7\udf32\uda68\udc42\ud996\udf09\uda0d\udc11",
        44, 27879, -109020961, -5520893145377929752L, 9782L, true, false, (char) 36876, (char) 42791,
        Double.longBitsToDouble(0x3fd18e76a2c1ca0cL), Double.longBitsToDouble(0x3fbc11fe4e718270L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\0121=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 7, 8, 5, "\udba6\udeb5\udbf3\uddc8\udb75\udd6a\ud90d\udf18\ud84a\udc4f\uda57\udf15\udafa\udfc3\ud96e\ude82\ube6b\uda99\uddb9\udba8\udc9a\uda1e\udd01", "\ua5c4", "\ud9d0\uded0\ud8c5\udf33\uda7d\udf0f\ub85c",
        12, -558, 1777484458, 6485253293795154990L, 96221L, false, false, (char) 37640, (char) 65085,
        Double.longBitsToDouble(0x3fdc661cce0120d8L), Double.longBitsToDouble(0x3fc9704a327aaedcL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[]\0121=void |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 3, 3, 5, "\udba6\udeb5\udbf3\uddc8\udb75\udd6a\ud915\udfb3\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\u27c2\u88c0\u65aa\u2b86\u00a2\u6791\u622e\u7471\u4216\ubc2f\u4ffc\u8adf\u5700\u28f9", "\ud9a5\udf90\udac7\udf32\000\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, -5520871975484127768L, 9782L, true, false, (char) 36876, (char) 82,
        Double.longBitsToDouble(0x3fdb7000005012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 2, 4, 0, "\u00e7\udb07\udc0a\udb0d\udeb6\udb13\udea8\ud984\udc5b\uda17\udfa4\000\uda5f\ude5b\000\000\ud954\udcab\ud85d\ude0e", "\000\000\000\u460d\uc059\000\000\u2b86\u1fb9\u4c72\u622e\u3bf6\u076c\u6471", "\000\000\000\uda36\ude30\ud1d9",
        -5, -1000, 0, 9079256848503505495L, -100000L, false, false, (char) 4281, (char) 0,
        Double.longBitsToDouble(0x3fee280004000052L), Double.longBitsToDouble(0x3fdb76ad805012c2L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\0121=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 7, 7, 5, "\udba6\udeb5\udbf3\uddc8\udb75\udd6a\ud915\udfb3\ud984\udc67\ud84a\ude7e\ud940\udda0\uda5f\ude64\ud879\udd0b\ud9b6\udf6b\udba8\udc9a\uda1e\udd01", "\ub024\uc04c\u5ad4\u08ca\ud692\u88c0", "\udbde\udcdf\ud950\udce8\udb2d\udcd0\udb33\udcad\ue243\ud9aa\udfe8\udbfd\udf11\udbfb\ude1c\udb49\udf61\ud838\uddb8\udbe4\ude2e\uda36\udeba\ud9a5\udf90\udac7\udf32",
        8, 57579, 2121305246, -1182896017365409653L, 36144L, false, true, (char) 44824, (char) 48312,
        Double.longBitsToDouble(0x3fe5efa48bc5dc47L), Double.longBitsToDouble(0x3fcdcb8a56ddab60L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\0121=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 8, 8, 5, "\ud989\udf2b\ud891\udfad\u573b\udb75\udc85\ud984\udc5b\uda8c\udf1e\ud9e1\ude94\u779b", "\u9783\u1bde\u13d1\u29c6\ub107\uc04c\u5ad4\uab7c\u9a74\u8862\u64f7\u7802\ub09c\u396d\u11d2\u6806\ub2e7", "\ud9d4\ude88\udb49\udf61\ud838\uddb8\ud96a\udde5\uda36\udeba\uda1d\udd4c\ud8e8\udc42\udbef\udfad\u3688\ud83c\udc72\udb9f\uddcc\udbbb\udcf8\udb3b\udfe5\udb88\udd96",
        45, 10588, -2133152554, 1499294957609092889L, 55822L, true, true, (char) 45964, (char) 26220,
        Double.longBitsToDouble(0x3fe372d9e4c608c8L), Double.longBitsToDouble(0x3fea77afaf4f339fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.list.TreeList:[\udba6\udeb5\udbc9\udd13\uda2e\udc44]\012",
        Z.run(T, 1, 14, 2, 1, "\udba6\udeb5\udbc9\udd13\uda2e\udc44", "\u7421\u8f09\u4a90\u59be\u8b56", "\udba6\udffb\ud88c\udcd1",
        44, 75963, 112106217, 3772779245760217025L, -69186L, false, false, (char) 43381, (char) 9262,
        Double.longBitsToDouble(0x3fe001640f3eb8d0L), Double.longBitsToDouble(0x3fef463b64417990L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.list.TreeList:[\udba6\udeb5\udbc9\udcac\uda7e\udfad\uda07\udfda\ud80e\udcb7\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud9ca\udd8d\udb90\udde3\uda1e\udd01]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 1, 8, "\udba6\udeb5\udbc9\udcac\uda7e\udfad\uda07\udfda\ud80e\udcb7\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud9ca\udd8d\udb90\udde3\uda1e\udd01", "\u00f0\uc04c\u5ad4\u08ca\ud692\u2964\u1512\u779c\u299c\u83ab\u61ab\u7471\u4216\ubc2f\u00e8\u914a\u5700\u4f77", "\ud9a5\udf90\udb7a\udfcb\udb92\udcc6\ud935\uddd7\uda25\ude51",
        21, 75567, 92274688, 1973680722556223585L, -100000L, true, false, (char) 36876, (char) 8185,
        Double.longBitsToDouble(0x3fdb76a2a05012c2L), Double.longBitsToDouble(0x3fed3fd55210c219L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01]\0121=[Ljava.lang.Object;:[[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01]] |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01]\012",
        Z.run(T, 2, 1, 12, 5, "\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        0, 27879, -2095154977, 5126345355976668350L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.list.TreeList:[\udad8\udf25\uda8d\udd15\uda2e\udc44\ud814\udea2]\0121=new org.apache.commons.collections.list.TreeList:[\udad8\udf25\uda8d\udd15\uda2e\udc44\ud814\udea2]\012",
        Z.run(T, 2, 14, 14, 9, "\udad8\udf25\uda8d\udd15\uda2e\udc44\ud814\udea2", "\u1856\ub52f\u489e\u6fc1\ud6bd\u6b2a\u405a\u0c9b\u81d6\u663e\u63e3\u17b9", "\ud970\uddd1",
        28, 70709, -1842834305, 8149983152746286591L, -32269L, false, true, (char) 61341, (char) 61882,
        Double.longBitsToDouble(0x3fe5b21f7cfcdbd0L), Double.longBitsToDouble(0x3f959fd5a72b1a20L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.list.TreeList:[\udad8\udf25\uda8d\udd15\uda2e\udc44\uda76\uddd2]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 2, 1, "\udad8\udf25\uda8d\udd15\uda2e\udc44\uda76\uddd2", "\u77b6\ub52f\u35d8\u3ec9\ud6bd\ub3c1\u5a8d\u8d29", "\udb1c\uddf6\udb4c\udd71\ud987\udf93\ud918\udd01\udba8\ude56\ud83e\udfa7\ud87a\uddd1\ud84f\udc44\udbca\udc56\udb4e\udcde\uda82\ude3b\ud981\udee2\ud98c\ude05\ud9d4\ude78",
        47, 29597, -1833315210, -7640524532851783094L, 95916L, true, true, (char) 11774, (char) 12967,
        Double.longBitsToDouble(0x3fc622d5c12bb514L), Double.longBitsToDouble(0x3fe7d7f0245f310aL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 2, 8, "\ud8a8\udd8d\udbc9\udd13\uda40\udc44\udb7c\uddd5\ud937\udcc7\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc3f\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u3518", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        0, 27879, -2095154977, 5126345355976668350L, 9782L, true, false, (char) 24715, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805192c2L), Double.longBitsToDouble(0x3fed3d861d778633L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\uda5f\ude5b\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01]\0121=java.lang.String:\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\uda5f\ude5b\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01 |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 1, 0, 0, "\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\uda5f\ude5b\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01", "\ub017\u4c72\u5ad4\u08ca\uc059\u6600\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u9fe8\000\000\000", "\000\ud8e7\udf7c\udb2e\udc33\000\udb9b\udf6c",
        0, 27879, -2095154977, 10256179283784704L, -100000L, false, false, (char) 36805, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd750778633L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01]\0121=void |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01, \ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01]\012",
        Z.run(T, 2, 1, 1, 5, "\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01", "\ub107\uc04c\u5ad4\u08ca\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        0, 27879, -2095154977, 5126345355976668350L, 9712L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd755778633L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.TreeList$TreeListIterator:@? |this=org.apache.commons.collections.list.TreeList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 2, 8, "\ud8a8\udd8d\udbc9\udd13\uda40\udc44\ud854\udfe2\udb11\udda3\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc3f\uda1e\udd01", "\ub107\uc04c\u5ad4\u3938\ud692\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u3518", "\uf80d\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        0, 15823, 104390636, 5126344492688241854L, -55754L, true, false, (char) 24715, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805192c2L), Double.longBitsToDouble(0x3fed3d861d778633L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[null]\0121=null |this=org.apache.commons.collections.list.TreeList:[]\012",
        Z.run(T, 2, 1, 0, 0, "\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\uda5f\ude5b\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01", "\ub017\u4c72\u5ad4\u08ca\uc059\u6600\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u9fe8\000\000\000", "\000\ud8e7\udf7c\udb2e\udc33\000\udb9b\udf6c",
        0, 27879, -467765025, 10256179283784704L, -100000L, false, false, (char) 36805, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd750778633L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\uda5f\ude5b\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\uda5f\ude5b\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01]\012",
        Z.run(T, 2, 1, 4, 7, "\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\uda5f\ude5b\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01", "\ub017\u4c72\u5ad4\u08ca\uc059\u6600\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u9fe8\000\000\000", "\000\ud8e7\udf7c\udb2e\udc33\000\udb9b\udf6c",
        0, 27879, -2095154977, 10256179283784704L, -100000L, false, false, (char) 36805, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd750778633L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\ud937\udea6\uda29\udf1a\ud953\ude11\udba7\udff8\uda1e\udd01]\0121=java.lang.String:\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\ud937\udea6\uda29\udf1a\ud953\ude11\udba7\udff8\uda1e\udd01 |this=org.apache.commons.collections.list.TreeList:[\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\ud937\udea6\uda29\udf1a\ud953\ude11\udba7\udff8\uda1e\udd01]\012",
        Z.run(T, 2, 1, 10, 7, "\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\u60a5\u8dd3\ud937\udea6\uda29\udf1a\ud953\ude11\udba7\udff8\uda1e\udd01", "\ub017\u4c72\u5ad4\u08ca\uc059\ubce1\ua78e\u7802\ub09c\u6871\u622e\u7471\u9a59\u9cba\ud558p\000\000", "\000\ud8e7\udf7c\udb2e\udc33\000\udb9b\udf6c",
        0, 27879, -2095154977, 10256179283784704L, -95151L, false, true, (char) 36805, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd750778633L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.TreeList:[null]\0121=java.lang.Integer:0 |this=org.apache.commons.collections.list.TreeList:[null]\012",
        Z.run(T, 2, 1, 6, 14, "\ud8a8\udd8d\udbc9\udd13\uda2e\udc44\udb7c\uddd5\ud864\udd3e\udbed\udfef\udbb0\udd9b\uda5f\ude5b\uda29\udf05\ud953\ude11\udba7\udff8\uda1e\udd01", "\ub017\u4c72\u5ad4\u08ca\uc059\u6600\u65aa\u7802\ub09c\u683b\u622e\ua8f7\u4216\u3dd9\u9fe8\000\000\000", "\u00b0\ud8e7\udf7c\udb2e\udc33\000\udb9b\udf6c",
        0, 27879, -467765025, 10256179283784704L, -100000L, false, false, (char) 36805, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad805012c2L), Double.longBitsToDouble(0x3fed3fd750778633L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 12, 5, "\udba6\udeb5\udbc9\udd13\udb02\udc43\udb7c\uddd5\ud984\udc5b\u60a5\udb1e\udc50\uda5f\ude64\uda29\udf05\ud953\ude11\udba8\udc9a\uda1e\udd01", "\ub107\uc04c\u5ad4\u7d77\u74b1\u88c0\u65aa\u7802\ub09c\u683b\u622e\u7471\u4216\ubc2f\u4ffc\u83c3\u5700\u4f77", "\ud9a5\udf90\ud8e8\udc42\udb92\udcc6\ud9ab\udfd3\uda0d\udc11",
        44, 27879, 1065384159, 1973680754413823841L, 9782L, true, false, (char) 36876, (char) 18752,
        Double.longBitsToDouble(0x3fdb76ad8fcaf496L), Double.longBitsToDouble(0x3fed3fd7e5778633L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.list.TreeList|remove|int|new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|add|int,java.lang.Object|new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|checkInterval|int,int,int|new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|clear||new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|contains|java.lang.Object|new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|get|int|new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|indexOf|java.lang.Object|new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|iterator||new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|listIterator||new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|listIterator|int|new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|set|int,java.lang.Object|new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|size||new:org.apache.commons.collections.list.TreeList:",
    "M|org.apache.commons.collections.list.TreeList|toArray||new:org.apache.commons.collections.list.TreeList:",
    "C|org.apache.commons.collections.list.TreeList|<init>|",
    "C|org.apache.commons.collections.list.TreeList|<init>|java.util.Collection",
    "M|org.apache.commons.collections.list.TreeList|remove|int|new:org.apache.commons.collections.list.TreeList:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
