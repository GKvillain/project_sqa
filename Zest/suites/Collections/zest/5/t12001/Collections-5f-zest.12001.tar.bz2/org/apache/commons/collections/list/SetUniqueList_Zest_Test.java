package org.apache.commons.collections.list;
import org.junit.Test;
import static org.junit.Assert.*;
public class SetUniqueList_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\012",
        Z.run(T, 2, 2, 12, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, 256282218643517204L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\012",
        Z.run(T, 2, 2, 12, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, -4499518986921816771L, 15425L, false, false, (char) 49459, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 12, 13, "\ud896\ude45\ud8c0\udc06\udb03\udc6e\uda51\udcdb\ud9c3\uddcd", "\u84c6", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda11\udf3f\udbf7\udf07\uda3b\uddfc\ud894\udd38\ud8a7\udefc\uf937\uda8b\udf87\udaef\udded\udb6d\udd0c",
        42, 99794, 1915054246, -539262677799164794L, 84139L, false, true, (char) 28845, (char) 56250,
        Double.longBitsToDouble(0x3fe916a7dd9c6517L), Double.longBitsToDouble(0x3faec125e179e340L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 14, 2, "\u183d\ud9c2\udd00\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\000", "\ud92d\udc72\udbeb\udfd5\ud957\udcd1\udac6\udeec\udb12\udc48\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ue26a\ud8eb\uddb1\uda45\udfbb\\\uda13\udf28",
        -3, 89392, -1468973472, 256282218643517204L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1080d1032cL), Double.longBitsToDouble(0x3f3aca8b448ff000L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 12, 3, "\ud896\ude45\ud92b\udcdb\ud9d4\ude30\uda51\udd26\ud9c3\uddcd", "\u85f9", "\uda41\ude7f\udbf4\ude7e\ud957\udcd1\ud811\uddf2\ud946\udcac\ud8c9\udc69\uda8a\udcbf\ud96b\udc9d\ud8dc\ude0c\ud8f9\udee8\uda45\udfbb\ud9ed\udddd",
        56, 28597, 589628650, -6309193020871901358L, -3238L, false, true, (char) 53614, (char) 11886,
        Double.longBitsToDouble(0x3feba3912c86f884L), Double.longBitsToDouble(0x3fd3440cbe96d654L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\ud9b5\uddd6\ud957\udc08\ud9e5\udf73\ud8e0\udf1c\ud8ce\udcfd\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\0121=void |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\ud9b5\uddd6\ud957\udc08\ud9e5\udf73\ud8e0\udf1c\ud8ce\udcfd\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc, \ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\012",
        Z.run(T, 2, 2, 3, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\ud9b5\uddd6\ud957\udc08\ud9e5\udf73\ud8e0\udf1c\ud8ce\udcfd\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -680444320, 222396322542448404L, 91638L, false, true, (char) 19078, (char) 39532,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 11, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u8695", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\ud928\udfee\ud840\uddac\u7f37\ud8eb\uddf1\uda45\udfbb\uda9c\udd35\uda27\udc81",
        16, 90650, -1468973472, 256282218647189008L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf]\012",
        Z.run(T, 2, 2, 14, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\uc3b6\u1c3c\u76fa\u70dd", "\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf",
        0, 52122, -87548352, 3054871271250436188L, -19979L, false, false, (char) 24965, (char) 24771,
        Double.longBitsToDouble(0x3fec47f23923ecb0L), Double.longBitsToDouble(0x3fc2c84d0ec9f5f8L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud890\uddce\ud92b\udcd1\ud833\ude5d\ud99a\udf89]\0121=org.apache.commons.collections.list.SetUniqueList:[\ud890\uddce\ud92b\udcd1\ud833\ude5d\ud99a\udf89]\012",
        Z.run(T, 2, 7, 8, 12, "\ud890\uddce\ud92b\udcd1\ud833\ude5d\ud99a\udf89", "\u2727\u85f9\u5cef\u69af\u1fe2", "\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\ud93b\udeb7\udbbf\udc5e\ud84c\uddb0\udb68\ude4c\ud81a\ude47\ud9cf\udc7f\udbdb\udc9d\ud914\udfdf\udb6d\udd96\ud908\udffb\udaca\udeb6\ud82a\udf94",
        40, 23750, -583040716, 3466954174494320744L, 90609L, false, false, (char) 1443, (char) 3087,
        Double.longBitsToDouble(0x3fb9481a1688b200L), Double.longBitsToDouble(0x3fec1db536861dccL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud9eb\udd8e\uda53\ude2b\udb03\udd17\ud9b0\uddcb\ud91a\udfb3, \udb46\udc53\ud8b1\udca1\uda8a\udc7f\uda27\udcbb\ud98e\udf15\ud8eb\udde1\uda8c\udc48\uda61\udfc7\udb8b\udfe6\ud894\udce0\ud88a\udf0d\udb94\udd2e\udbf9\ude5a\ud98d\udf56\udb6d\udd0c]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 13, 4, "\ud9eb\udd8e\uda53\ude2b\udb03\udd17\ud9b0\uddcb\ud91a\udfb3", "\u55aa\u0879\u1012\u1fe2\u3ff3", "\udb46\udc53\ud8b1\udca1\uda8a\udc7f\uda27\udcbb\ud98e\udf15\ud8eb\udde1\uda8c\udc48\uda61\udfc7\udb8b\udfe6\ud894\udce0\ud88a\udf0d\udb94\udd2e\udbf9\ude5a\ud98d\udf56\udb6d\udd0c",
        42, 66506, 1915079898, -539262676882643834L, 17880L, true, true, (char) 57664, (char) 7666,
        Double.longBitsToDouble(0x3f9d40dafbd67f00L), Double.longBitsToDouble(0x3fd2476b1d17301cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\0121=org.apache.commons.collections.set.UnmodifiableSet:[\u85f9, \ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc] |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\012",
        Z.run(T, 2, 2, 4, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, 256282218643517204L, 56399L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fc66d6545a00318L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 15, 12, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, 256282218643517204L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 10, 12, 16, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud87b\udf87\ud996\ude09\udb03\udffc\ud97d\udf86\uda27\udc9d\ud805\ude70\ud8eb\ude2d\uda91\ude01\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, 256202431036059412L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1080d1032cL), Double.longBitsToDouble(0x3fea5930b16891feL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 15, 7, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, 256282218643517204L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 9, 0, 15, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\u7c6c\udae5\udfd2\ud957\udcd1\ueae6\000\ud8d6\udeee\uda8a\udcbf\u5653\000\000\000\000\000",
        12, 1090, 0, 0L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 5, 12, 16, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\ud375", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8af\uddf3\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, 808375392, 256282218643517204L, 91638L, false, true, (char) 47465, (char) 55513,
        Double.longBitsToDouble(0x3fdea7c532688196L), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 5, 0, 3, "\udb44\udfe9\ud818\udf6c\udb03\udcc5\udb9a\udfc7\udad3\uddf3", "\u85f9", "\uda7e\ude1a\udb0e\uddab\ud95c\uded1\ud941\uddea\ud880\udc9a\udb5c\udfbb\uda8a\udcbf\uda21\udd74\udb53\udec1\uda6d\ude14\udb72\udefe\ud886\udeaa\ud8e4\udf66\ud8b7\ude88",
        18, 15726, -1485078702, -2008344960110628606L, 76625L, false, false, (char) 42487, (char) 40202,
        Double.longBitsToDouble(0x3fd074007c9b0834L), Double.longBitsToDouble(0x3fe6b638d2f066d6L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\u49e6\udb24\udc02\uda51\udcdb\ud9c3\uddcd\ud9a6\udefa\udbb4\udd4c\udbfd\udd12\ud8cc\udc4f\udb40\udee3\ufefb\udbf4\ude0e\udb1f\udd96\ud947\uddfa\uda80\udf1f\uda0f\udef7\udabe\udcf1\uda27\udcbd\uda7d\ude6c, \udacb\udc74\ud9ad\udd12]\0121=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\u49e6\udb24\udc02\uda51\udcdb\ud9c3\uddcd\ud9a6\udefa\udbb4\udd4c\udbfd\udd12\ud8cc\udc4f\udb40\udee3\ufefb\udbf4\ude0e\udb1f\udd96\ud947\uddfa\uda80\udf1f\uda0f\udef7\udabe\udcf1\uda27\udcbd\uda7d\ude6c, \udacb\udc74\ud9ad\udd12]\012",
        Z.run(T, 2, 2, 9, 1, "\ud896\ude45\u49e6\udb24\udc02\uda51\udcdb\ud9c3\uddcd\ud9a6\udefa\udbb4\udd4c\udbfd\udd12\ud8cc\udc4f\udb40\udee3\ufefb\udbf4\ude0e\udb1f\udd96\ud947\uddfa\uda80\udf1f\uda0f\udef7\udabe\udcf1\uda27\udcbd\uda7d\ude6c", "\uaea3\u09e7\u319e\u469b\u81f4\u1fb3\u5981\u6e13\u0953", "\udacb\udc74\ud9ad\udd12",
        18, 235, 1144406376, 4316039693929208357L, -39827L, false, false, (char) 43522, (char) 6768,
        Double.longBitsToDouble(0x3feac955c60e7117L), Double.longBitsToDouble(0x3fe06f3c2d2726c1L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud89e\ude2f\ud92b\udcdb\udb03\udcc5]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 12, 12, 3, "\ud89e\ude2f\ud92b\udcdb\udb03\udcc5", "\u1aee\u2727\uade3\u5cef\u26b9\u1fbb\u4c1a\u9f44\uc22e\u45d0\u086b\u43dd\ube50", "\uda45\udfbb\uda6c\udefc\ud861\udca0\ud9bb\ude82\ud8a7\udefc\uf937\uda8b\udf87\udaef\udded",
        47, 23161, -326151246, 8225205531011458932L, 64148L, true, true, (char) 54118, (char) 33826,
        Double.longBitsToDouble(0x3fef39ea0e2e5b2aL), Double.longBitsToDouble(0x3fd77abb9c438952L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\ud963\ude07\uda51\udcf9\ud9c3\uddcd, \ud941\uddea\udb12\udcf9]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\ud963\ude07\uda51\udcf9\ud9c3\uddcd, \ud941\uddea\udb12\udcf9, \ud896\ude45\ud92b\udcdb\ud963\ude07\uda51\udcf9\ud9c3\uddcd]\012",
        Z.run(T, 2, 2, 2, 4, "\ud896\ude45\ud92b\udcdb\ud963\ude07\uda51\udcf9\ud9c3\uddcd", "\u8f9d\ucadd\u6d1e\u2fa8", "\ud941\uddea\udb12\udcf9",
        9, 90224, 1172395603, 2292932693916655168L, 6539L, false, false, (char) 45581, (char) 34811,
        Double.longBitsToDouble(0x3fe301192f52a871L), Double.longBitsToDouble(0x3fbe82b8c91f63f0L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 5, 9, 15, "\udb1b\udea0\ud92b\udc1a\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u9ff9", "\ufeaf\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda39\ude7f\udbb5\udea8\ud887\udd5e\udb98\udcea\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, -25745979921092039L, 91638L, false, false, (char) 35294, (char) 51905,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ud9ed\udddd\uda3b\uddfc\ud894\udd38\ud8a7\udefc\uf937\uda8b\udf87\udaef\udded\udb6d\udd0c\ud908\udffb\udaca\ude8c\ud82a\udf94\ud829\udf03]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 16, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9\u5cef\u69af\u1fe2\u009e\u5f6a\ubeae\uaca1\u3456\u4492\u3308\u0b56", "\ud9ed\udddd\uda3b\uddfc\ud894\udd38\ud8a7\udefc\uf937\uda8b\udf87\udaef\udded\udb6d\udd0c\ud908\udffb\udaca\ude8c\ud82a\udf94\ud829\udf03",
        51, 12724, -1856558314, 7741196725059742550L, 56037L, true, true, (char) 65074, (char) 30035,
        Double.longBitsToDouble(0x3fef4ff5b3b0d5d2L), Double.longBitsToDouble(0x3fe27f3da3d91f34L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\012",
        Z.run(T, 1, 8, 12, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, 256282218643517204L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc]\012",
        Z.run(T, 2, 2, 11, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, 256282218643517204L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fe44674254fb31cL), Double.longBitsToDouble(0x3fe62c1a71681661L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\0121=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\012",
        Z.run(T, 2, 9, 9, 12, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\ud810\udf69\uf61f\ud834\udce2\ud834\udf01\ud8af\udd8c\uda8a\udcbf\uda27\udcbb\ud805\ude70\udb91\udeaf\uda43\udcbb\ud9ed\udddd\uda3b\uddfc",
        25, 99130, -1257357763, 40247854735749062L, 91638L, false, true, (char) 29308, (char) 11747,
        Double.longBitsToDouble(0x3fc0db9f44d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf, \ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\0121=java.lang.String:\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\012",
        Z.run(T, 2, 16, 13, 2, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u3af6\u4863\u69af\u1fe2", "\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf",
        0, 52122, -87548352, 3054871271250436188L, 82123L, false, false, (char) 24965, (char) 10180,
        Double.longBitsToDouble(0x3fd3dc18e83648ccL), Double.longBitsToDouble(0x3fb820cd5727b0b0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud8b8\udc05\udb03\udc6e\uda51\udcdb\udbc2\udfec\udaee\udf00\udb86\udc4e\udb93\udd27\uead0\ud937\udfed\ud958\udd3d\udbf4\ude7e\udb98\udf16\udaf1\udc10\udb12\udcf9\ud892\udd77\ud90e\uddb3]\0121=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud8b8\udc05\udb03\udc6e\uda51\udcdb\udbc2\udfec\udaee\udf00\udb86\udc4e\udb93\udd27\uead0\ud937\udfed\ud958\udd3d\udbf4\ude7e\udb98\udf16\udaf1\udc10\udb12\udcf9\ud892\udd77\ud90e\uddb3]\012",
        Z.run(T, 2, 8, 8, 7, "\ud896\ude45\ud8b8\udc05\udb03\udc6e\uda51\udcdb\udbc2\udfec\udaee\udf00\udb86\udc4e\udb93\udd27\uead0\ud937\udfed\ud958\udd3d\udbf4\ude7e\udb98\udf16\udaf1\udc10\udb12\udcf9\ud892\udd77\ud90e\uddb3", "\u3a1c\u1bc5\u4ba1\uc6cb\u787f\u6757\ube3e", "\uda0e\udcd9\uda08\uddf7\ud961\udfe5\ud903\udd73\ud89c\ude92\u1729\ud864\ude8d\ud9a8\udcc5\ud89a\udee5\udaad\ude88\u8af2\ud9fd\udd60\ud97e\udcdf\uda5a\ude79",
        42, 20249, 200606085, -7385277167382820030L, 95669L, false, true, (char) 57608, (char) 42355,
        Double.longBitsToDouble(0x3fe07d6217ac7a0bL), Double.longBitsToDouble(0x3fc8238d0e93b1e0L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ubb40\ud8c4\ude06\udb03\udc6e\ud88a\udf7f\ud83b\uddf9]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ubb40\ud8c4\ude06\udb03\udc6e\ud88a\udf7f\ud83b\uddf9]\012",
        Z.run(T, 2, 10, 10, 4, "\ubb40\ud8c4\ude06\udb03\udc6e\ud88a\udf7f\ud83b\uddf9", "\u84d5\u4a86\u733b\ub6c8", "\ud918\ude03\udb12\udcf9\udb7f\udc2c\ud839\udf6d\uda2f\udf74\ud805\udee3\udafa\udd78\ud842\udeea",
        48, 70116, -2096023403, 2569274904149624160L, 46948L, false, true, (char) 12003, (char) 53552,
        Double.longBitsToDouble(0x3fc4c5b1e674e90cL), Double.longBitsToDouble(0x3fc0dda354ba849cL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 1, 13, "\ud84e\udf84\ud933\ude05\uda33\uddfa\uda51\udcdb\ud9c3\uddcd", "\u0592", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udf90\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda11\udf3f\udbf7\udf07\uda3b\uddfc\ud894\udd38\ud8a7\udefc\ud961\ude93\uda8b\udf87\udbd5\udec2\udb6d\udd0c",
        42, 99794, 1915054246, -539262677799164794L, 84139L, false, true, (char) 28845, (char) 42382,
        Double.longBitsToDouble(0x3fe916a7da9c6517L), Double.longBitsToDouble(0x3faec125e5b90780L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[\u183d\ud9c2\udd00\udb03\udcc5\uf291\000]\012",
        Z.run(T, 1, 3, 14, 2, "\u183d\ud9c2\udd00\udb03\udcc5\uf291\000", "\000", "\000",
        27, 77092, 7463654, 2793073995995602890L, 53171L, false, false, (char) 7680, (char) 5636,
        Double.longBitsToDouble(0x3fb70a9940000000L), Double.longBitsToDouble(0x3fc2af2f00000000L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 5, 5, 3, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u3b02", "\ufefb\ud9b5\uddd6\ud957\udc08\ud9e5\udf73\ud8e0\udf1c\ud8ce\udcfd\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\ufa9f",
        35, 90583, -680444320, 222636325314948884L, -73482L, false, true, (char) 19078, (char) 20899,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[, ]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[, ]\012",
        Z.run(T, 2, 2, 0, 0, "", "\u0364", "",
        3, 44521, 1443454977, 1367808340329889921L, -100000L, true, true, (char) 22004, (char) 28891,
        Double.longBitsToDouble(0x3fd0b264399085ecL), Double.longBitsToDouble(0x3fe29a1a9000e4feL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[\ufefb\udb0e\ude59\ud824\udcc9\ud9e5\udf73\ud8e0\udf1c\ud8ce\udcfd\uda8a\udcbf, \ud96b\ude2c\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud96b\ude2c\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd, \ufefb\udb0e\ude59\ud824\udcc9\ud9e5\udf73\ud8e0\udf1c\ud8ce\udcfd\uda8a\udcbf, \ud96b\ude2c\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\012",
        Z.run(T, 2, 3, 0, 3, "\ud96b\ude2c\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udb0e\ude59\ud824\udcc9\ud9e5\udf73\ud8e0\udf1c\ud8ce\udcfd\uda8a\udcbf",
        0, 52122, -87548352, 3054871271250436188L, -19979L, false, false, (char) 58324, (char) 12004,
        Double.longBitsToDouble(0x3fe186f7e123ec7eL), Double.longBitsToDouble(0x3fc2c84d16c9f5f8L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\u63d3\uda16\udf0a\000\000]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 3, 3, "\ud896\ude45\u63d3\uda16\udf0a\000\000", "", "",
        5, 51492, 50357673, 8355484846347575869L, 71275L, false, false, (char) 39333, (char) 49000,
        Double.longBitsToDouble(0x3fe20222353cfac8L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\012",
        Z.run(T, 2, 11, 11, 16, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u8695", "\ufefb\ud9de\ude82\uda8b\udccb\ud941\uddea\udb12\udcf9\ud8d6\udfb8\ud928\udfee\ud849\udd3f\u7f37\ud8eb\uddf1\ud8a5\ude6b\ud91a\udc32\uda27\udc81",
        0, 90650, -1468973472, 256282218647189008L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b59516891feL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud8ec\udf2d\ud92b\udcdb\udb94\udead\udbd7\udc2e\ud976\udc40]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 14, 14, 4, "\ud8ec\udf2d\ud92b\udcdb\udb94\udead\udbd7\udc2e\ud976\udc40", "\ucddb", "\udb46\udf9f\udbf4\ude2c\uda0d\udd6e\udba5\udcea\ud9a8\ude11\udaa7\udf84\u452c\uda36\udd01\udaab\udead\ua743\udb76\udf53\ud807\uddd5\uda27\udc81",
        16, 90650, -1468973472, 256282218647189008L, 95662L, false, false, (char) 47458, (char) 48537,
        Double.longBitsToDouble(0x3fc5e02d501820e4L), Double.longBitsToDouble(0x3fd65d6933e7dbf0L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.UnmodifiableSet:[\u69af\u1fe2\uacae\u7a0c\ubeae\uaca1\u36d7] |this=org.apache.commons.collections.list.SetUniqueList:[\ud85e\udd1b\ud937\udc80\ud833\ude5d\ud99a\udf89\ud9c3\uddcd\ud9a6\udefa\udbb4\ude14]\0121=org.apache.commons.collections.set.UnmodifiableSet:[\u69af\u1fe2\uacae\u7a0c\ubeae\uaca1\u36d7] |this=org.apache.commons.collections.list.SetUniqueList:[\ud85e\udd1b\ud937\udc80\ud833\ude5d\ud99a\udf89\ud9c3\uddcd\ud9a6\udefa\udbb4\ude14]\012",
        Z.run(T, 2, 4, 4, 7, "\ud85e\udd1b\ud937\udc80\ud833\ude5d\ud99a\udf89\ud9c3\uddcd\ud9a6\udefa\udbb4\ude14", "\u69af\u1fe2\uacae\u7a0c\ubeae\uaca1\u36d7", "\ud805\ude70\uda65\udd57\ud93b\udeb7\udbbf\udc5e\ud84c\uddb0\udb68\ude4c\ud81a\ude47\ud9cf\udc7f\udbdb\udc9d\ud914\udfdf\udb6d\udd96\ud908\udffb\udaca\udeb6\ud82a\udf94\ud821\udf42\uda0e\udc57\udac7\udf27",
        7, 77872, 1881003615, 7162667965565032001L, 70705L, true, true, (char) 48209, (char) 37232,
        Double.longBitsToDouble(0x3fd3717bdf1ee338L), Double.longBitsToDouble(0x3fe858f9e6a01517L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 15, 15, 12, "\ud890\uddce\ud957\ude89\uaa0e\ud99b\udc04", "\u2727\u85f9\ua084\ud10b\u1fe2", "\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\ud93b\udeb7\udbbf\udc5e\ud84c\uddb0\udb68\ude4c\ud81a\ude47\ud9cf\udc7f\udbf9\udc9d\ud914\udfdf\udb6d\udd96\ud908\udffb\ud8cd\udd69\ud82a\udf94",
        40, 23750, -583040716, 3466954174491764840L, 90609L, true, false, (char) 1443, (char) 3087,
        Double.longBitsToDouble(0x3fb9481a1688b200L), Double.longBitsToDouble(0x3fec1db536861dccL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\ud9eb\udd8e\u8cd3\udb03\udd17\ud9b0\uddcb\ud99f\ude56 |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 13, 4, "\ud9eb\udd8e\u8cd3\udb03\udd17\ud9b0\uddcb\ud99f\ude56", "\ub170", "\ufefb\udb5f\udcf4\ud943\udcd0\udbc1\udf5e\udb46\udc53\ud8b1\udca1\uda8a\udc7f",
        0, 46602, -87548368, 8867905461084705346L, 82211L, false, false, (char) 23657, (char) 37078,
        Double.longBitsToDouble(0x3fe25c447123cdd9L), Double.longBitsToDouble(0x3fc2c84d0ec9f5f8L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd]\0121=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 7, 5, 8, "\ud896\ude45\ud92b\udcdb\udb03\udcc5\uda51\udcdb\ud9c3\uddcd", "\u85f9", "\ufefb\udbf4\ude7e\ud957\udcd1\ud941\uddea\udb12\udcf9\ud8d6\udfb8\uda8a\udcbf\uda27\udcbb\ud805\ude70\ud8eb\uddf1\uda45\udfbb\ud9ed\udddd\uda3b\uddfc",
        2, 90650, -1468973472, 256282218643517204L, 91638L, false, true, (char) 47465, (char) 39321,
        Double.longBitsToDouble(0x3fc0df1084d1032cL), Double.longBitsToDouble(0x3fea5b5956f4c6feL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 2, 0, 0, "", "", "",
        -5, 30736, 45312, 105557411233792L, -100000L, false, false, (char) 51, (char) 22004,
        Double.longBitsToDouble(0x3fcb600000000000L), Double.longBitsToDouble(0x3fc9084000000148L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 16, 0, 0, "", "", "",
        -5, 30736, 45312, 105557411233792L, -100000L, false, false, (char) 51, (char) 22004,
        Double.longBitsToDouble(0x3fcb600000000000L), Double.longBitsToDouble(0x3fc9084000000148L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 2, 2, 0, "", "", "",
        -5, 30736, 756330752, 158046206558208L, -100000L, false, true, (char) 1201, (char) 22004,
        Double.longBitsToDouble(0x3fcb730000000000L), Double.longBitsToDouble(0x3fc9084000000148L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udc7e\udb22\udfc5\ud93d\udd32\u0434\udbcf\udc2b\udbf3\uddba\udbe8\udc9e\ud835\udf91\ud89b\udd5b\ufef0\udb70\udd1b\uc6d9\ud9c2\udc0a\ud8fe\udfc9\ud9b1\udd68\ud8fd\udf38\uda56\udf92\ua185\uda80\ude1c\ud830\uddd1\ud941\udef0\ud9f1\uddcd\ud80a\ude99\ud8cc\udf44\ud848\udffc\uda25\udc75\udaef\udded\udb6d\udd0c\ud908\udffb\ud89c\udfd8\uda1a\udea5\ud829\udef0\uda0e\udc57\ud99a\uddfd\ud97c\udccf\ud95d\udc6d\udace\udff6\ud83f\udcb6\udb53\udf04\ud8c6\uddbc\ud949\udc50\ud917\udfd6\udae2\udc1a\ud8ea\uddb9\uda69\udec2\ud33a\ud95a\udd5a\uda9a\uddfa\udac0\udc1d\ud9ef\udd33\udb6d\udfcd\udb5a\ude01\ud977\ude9f\ud8cc\udec1\ud979\uddf2\ud982\uded2\udb27\udc17\ud802\udd87\ud882\udf1c\ud909\udc02\ud80d\udf05\udb19\udd05\udab7\udce4\ua874\uda40\udc43\udb4c\udc65\udbf2\ude7e\ud82d\udf62\ud85b\udc73\uda18\uded3\udb67\ude1e\uda86\udf96\udb1e\udc0e\uda5e\udf50\udb6c\udc63\ud9d4\udf89\ud9f0\udc64\udb30\uded0\uda5f\uddf4\ud870\ude9e\u84d0\udb24\udf36\udaac\udcd6\u7f24\ud839\ude09\ud808\udd46\u764b\u5a22\udb6c\udc4b\ud967\uddbc\udb87\udca6\ud940\uddfa\uda29\udf5e\ud933\udd2c\udb80\udf7e\uda78\udf43\ud986\udcb2\udb68\udfe0\ud8ed\udd33\ud9b1\ude90\ud9d6\udf73\udb7e\udfde\ud954\udf84\uda38\udcf6\uda24\ude2d\ud9b9\udd30\ud845\udcc0\udb11\udc13\udae3\udd83\uda4b\udfe4\udb77\udd9d\udb27\ude02\uda16\udcab\udab0\udf64\uda74\udd58]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud896\ude45\ud92b\udc7e\udb22\udfc5\ud93d\udd32\u0434\udbcf\udc2b\udbf3\uddba\udbe8\udc9e\ud835\udf91\ud89b\udd5b\ufef0\udb70\udd1b\uc6d9\ud9c2\udc0a\ud8fe\udfc9\ud9b1\udd68\ud8fd\udf38\uda56\udf92\ua185\uda80\ude1c\ud830\uddd1\ud941\udef0\ud9f1\uddcd\ud80a\ude99\ud8cc\udf44\ud848\udffc\uda25\udc75\udaef\udded\udb6d\udd0c\ud908\udffb\ud89c\udfd8\uda1a\udea5\ud829\udef0\uda0e\udc57\ud99a\uddfd\ud97c\udccf\ud95d\udc6d\udace\udff6\ud83f\udcb6\udb53\udf04\ud8c6\uddbc\ud949\udc50\ud917\udfd6\udae2\udc1a\ud8ea\uddb9\uda69\udec2\ud33a\ud95a\udd5a\uda9a\uddfa\udac0\udc1d\ud9ef\udd33\udb6d\udfcd\udb5a\ude01\ud977\ude9f\ud8cc\udec1\ud979\uddf2\ud982\uded2\udb27\udc17\ud802\udd87\ud882\udf1c\ud909\udc02\ud80d\udf05\udb19\udd05\udab7\udce4\ua874\uda40\udc43\udb4c\udc65\udbf2\ude7e\ud82d\udf62\ud85b\udc73\uda18\uded3\udb67\ude1e\uda86\udf96\udb1e\udc0e\uda5e\udf50\udb6c\udc63\ud9d4\udf89\ud9f0\udc64\udb30\uded0\uda5f\uddf4\ud870\ude9e\u84d0\udb24\udf36\udaac\udcd6\u7f24\ud839\ude09\ud808\udd46\u764b\u5a22\udb6c\udc4b\ud967\uddbc\udb87\udca6\ud940\uddfa\uda29\udf5e\ud933\udd2c\udb80\udf7e\uda78\udf43\ud986\udcb2\udb68\udfe0\ud8ed\udd33\ud9b1\ude90\ud9d6\udf73\udb7e\udfde\ud954\udf84\uda38\udcf6\uda24\ude2d\ud9b9\udd30\ud845\udcc0\udb11\udc13\udae3\udd83\uda4b\udfe4\udb77\udd9d\udb27\ude02\uda16\udcab\udab0\udf64\uda74\udd58, \ud896\ude45\ud92b\udc7e\udb22\udfc5\ud93d\udd32\u0434\udbcf\udc2b\udbf3\uddba\udbe8\udc9e\ud835\udf91\ud89b\udd5b\ufef0\udb70\udd1b\uc6d9\ud9c2\udc0a\ud8fe\udfc9\ud9b1\udd68\ud8fd\udf38\uda56\udf92\ua185\uda80\ude1c\ud830\uddd1\ud941\udef0\ud9f1\uddcd\ud80a\ude99\ud8cc\udf44\ud848\udffc\uda25\udc75\udaef\udded\udb6d\udd0c\ud908\udffb\ud89c\udfd8\uda1a\udea5\ud829\udef0\uda0e\udc57\ud99a\uddfd\ud97c\udccf\ud95d\udc6d\udace\udff6\ud83f\udcb6\udb53...\012",
        Z.run(T, 2, 14, 2, 1, "\ud896\ude45\ud92b\udc7e\udb22\udfc5\ud93d\udd32\u0434\udbcf\udc2b\udbf3\uddba\udbe8\udc9e\ud835\udf91\ud89b\udd5b\ufef0\udb70\udd1b\uc6d9\ud9c2\udc0a\ud8fe\udfc9\ud9b1\udd68\ud8fd\udf38\uda56\udf92\ua185\uda80\ude1c\ud830\uddd1\ud941\udef0\ud9f1\uddcd\ud80a\ude99\ud8cc\udf44\ud848\udffc\uda25\udc75\udaef\udded\udb6d\udd0c\ud908\udffb\ud89c\udfd8\uda1a\udea5\ud829\udef0\uda0e\udc57\ud99a\uddfd\ud97c\udccf\ud95d\udc6d\udace\udff6\ud83f\udcb6\udb53\udf04\ud8c6\uddbc\ud949\udc50\ud917\udfd6\udae2\udc1a\ud8ea\uddb9\uda69\udec2\ud33a\ud95a\udd5a\uda9a\uddfa\udac0\udc1d\ud9ef\udd33\udb6d\udfcd\udb5a\ude01\ud977\ude9f\ud8cc\udec1\ud979\uddf2\ud982\uded2\udb27\udc17\ud802\udd87\ud882\udf1c\ud909\udc02\ud80d\udf05\udb19\udd05\udab7\udce4\ua874\uda40\udc43\udb4c\udc65\udbf2\ude7e\ud82d\udf62\ud85b\udc73\uda18\uded3\udb67\ude1e\uda86\udf96\udb1e\udc0e\uda5e\udf50\udb6c\udc63\ud9d4\udf89\ud9f0\udc64\udb30\uded0\uda5f\uddf4\ud870\ude9e\u84d0\udb24\udf36\udaac\udcd6\u7f24\ud839\ude09\ud808\udd46\u764b\u5a22\udb6c\udc4b\ud967\uddbc\udb87\udca6\ud940\uddfa\uda29\udf5e\ud933\udd2c\udb80\udf7e\uda78\udf43\ud986\udcb2\udb68\udfe0\ud8ed\udd33\ud9b1\ude90\ud9d6\udf73\udb7e\udfde\ud954\udf84\uda38\udcf6\uda24\ude2d\ud9b9\udd30\ud845\udcc0\udb11\udc13\udae3\udd83\uda4b\udfe4\udb77\udd9d\udb27\ude02\uda16\udcab\udab0\udf64\uda74\udd58", "\u34c8\uc254\ub8f0\u785b\u65e0\u2e59", "\ud819\udfcf\uda71\udf90\ud944\udd66\ud83f\udc17\ud860\udd2c\ud92e\udc0f",
        8, 44755, 1698765680, -2078956531066143906L, 19840L, false, true, (char) 60480, (char) 16828,
        Double.longBitsToDouble(0x3fd06769d078e552L), Double.longBitsToDouble(0x3feeeaaf34543ac4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|int,java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|add|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|add|int,java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|asSet||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|clear||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|contains|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|containsAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|decorate|java.util.List|static",
    "M|org.apache.commons.collections.list.SetUniqueList|iterator||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|listIterator||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|listIterator|int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|remove|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|remove|int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|removeAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|retainAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|int,java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
