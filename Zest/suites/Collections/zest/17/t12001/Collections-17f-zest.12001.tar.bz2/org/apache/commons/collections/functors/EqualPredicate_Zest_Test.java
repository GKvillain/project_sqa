package org.apache.commons.collections.functors;
import org.junit.Test;
import static org.junit.Assert.*;
public class EqualPredicate_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.functors.EqualPredicate:@?\0121=java.lang.String:\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4 |this=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 1, 5, 3, "\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4", "\u303f\u6e24\u5f5d", "\udbd8\udc1d\ud8d6\ude65\udb9c\udca9\udbd4\ude1d\ud98c\udcc4\ud9d1\udd3e\ud8f0\udc45",
        17, 93313, -1166162065, -6214563699747635387L, -55952L, true, false, (char) 24020, (char) 1555,
        Double.longBitsToDouble(0x3fe767fe7a6182e5L), Double.longBitsToDouble(0x3fe7b60f0720beb1L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 1, 4, 1, 3, "\ua43a", "\u7507\u07fd\u36e3\u8803\u9eea\u7674\u0925\ua4fc\u73dd\u3788\u114f\u6707\ub9a4\u3ae7\u121a\u4800\u35ff\u250d\u4906\u7e62\u00fd\u995a\u6068", "\ud94d\udee7",
        25, 78708, -991911327, 2542267651728564000L, 13813L, false, false, (char) 20965, (char) 22202,
        Double.longBitsToDouble(0x3fd6763a9a85aa4aL), Double.longBitsToDouble(0x3fe428dda1ec3aebL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.NullPredicate:@?\0121=null |this=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 3, 5, 2, "\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4", "\u4f89\ub9d1\u5f5d", "\udbd8\udc1d\ud8d6\ude65\udb9c\udca9\udbd4\ude1d\ud98c\udcc4\ud9d1\udd3e\u49a8",
        7, 40001, -1008694008, 8144198598613632143L, -55952L, true, true, (char) 65341, (char) 41829,
        Double.longBitsToDouble(0x3fe767fe7a6182e5L), Double.longBitsToDouble(0x3fe7b60f0720beb1L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.functors.EqualPredicate:@?\0121=new org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 1, 7, 3, "\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4", "\u303f\u6e24\u5f5d", "\udbd8\udc1d\ud8d6\ude65\udb9c\udca9\udbd4\ude1d\ud98c\udcc4\ud9d1\udd3e\ud8f0\udc45",
        17, 93313, -1166162065, -6214563699747635387L, -55952L, true, false, (char) 24020, (char) 1555,
        Double.longBitsToDouble(0x3fe767fe7a6182e5L), Double.longBitsToDouble(0x3fe7b60f0720beb1L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.functors.EqualPredicate:@?\0121=java.lang.String:\ud9cd\udf16\udabc\udd69\u97a0\uda92\udf85\ud858\udd27\ud96b\uded7\uda17\ude86\ud886\udf33\ud802\udd0d\udbe9\udc7c\ud8f4\udfb6\uda28\udf21\ud8d6\ude65\udb9c\udca9\udbd4\ude1d\uda7a\udd7b\udbdc\udfef\ud876\uddbb\ud83f\udcf3\udb39\ude1b\ud93d\udc3d\udb70\ude28\ud8d0\udfa5\udb8b\ude13\ud976\udf56\udbd8\ude6f\ud872\ude33\ud9c0\udd19\ud86c\udc01\ud8bf\ude45 |this=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 6, 5, 3, "\ud9cd\udf16\udabc\udd69\u97a0\uda92\udf85\ud858\udd27\ud96b\uded7\uda17\ude86\ud886\udf33\ud802\udd0d\udbe9\udc7c\ud8f4\udfb6\uda28\udf21\ud8d6\ude65\udb9c\udca9\udbd4\ude1d\uda7a\udd7b\udbdc\udfef\ud876\uddbb\ud83f\udcf3\udb39\ude1b\ud93d\udc3d\udb70\ude28\ud8d0\udfa5\udb8b\ude13\ud976\udf56\udbd8\ude6f\ud872\ude33\ud9c0\udd19\ud86c\udc01\ud8bf\ude45", "\uc188\ua3f0\u0a7f\u0b62\u3671\ud4f7\ud4a9\u6018\u1afb\u964d\u5754\u40ea\u37c0\ubdf9", "\ud854\udc57\ud9ac\udd57\uda88\uddfa\ud918\ude16\ud8f4\udd55\ud87f\udfbe\ud8ae\udc97\ud975\ude64\udbdf\ude70\ud882\udf4d\uda4c\udc2b",
        -4, 7361, -2108504333, -1466231314791438666L, 45548L, true, false, (char) 21531, (char) 56495,
        Double.longBitsToDouble(0x3fc632d5483b9f10L), Double.longBitsToDouble(0x3fd277088345c770L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.String:\uda96\uddb1\ud8e6\udc47\udbfc\udcd4\uda67\udca4 |this=org.apache.commons.collections.functors.EqualPredicate:@?\0121=java.lang.String:\uda96\uddb1\ud8e6\udc47\udbfc\udcd4\uda67\udca4 |this=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 5, 5, 3, "\uda96\uddb1\ud8e6\udc47\udbfc\udcd4\uda67\udca4", "\u303f\ud7f3\u2d65", "\udbd8\udc1d\uda20\udf37\udb9c\udc9f\udbd4\ude1d\ud98c\udcc4\ud98f\ude3d\ud8f0\udd09",
        31, 93223, -1166162065, -6214563699747635387L, -55952L, true, false, (char) 35153, (char) 28343,
        Double.longBitsToDouble(0x3fc4a4bf89860b94L), Double.longBitsToDouble(0x3fe7b60f0720beb1L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.EqualPredicate:@?\0121=new org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 4, 2, 3, "\ua43a\ud824\udce9", "\u07fd\u0853\u303f\u4ee7\u220a\ub513\u8b83\u72a4", "\udb1a\udc32\uf8a9",
        9, 52329, 435362310, 7177488695228745583L, 80411L, false, false, (char) 33627, (char) 48928,
        Double.longBitsToDouble(0x3f90c2dddbc9c160L), Double.longBitsToDouble(0x3fd9f6c357550b38L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.EqualPredicate:@?\0121=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 4, 4, 0, "\ud9b5\udd46\ud9f0\udc80\udb8d\udc84\ud92e\udd40\udac4\udce2\uda76\udef5\ud8b0\udea2\udb85\ude02\ud802\udd2a\ud8c4\udf9f\ud907\udcbc\uda4c\ude97\ud8d6\ude65\udaf1\udc28\udbd4\ude1d\ud9ab\udd49\ud8de\ude23\udac2\udea2\ud886\udc2d", "\u4906\u7e62\uc8a3\u1424\u11b2\u06ff\ub484\ua2f8\u23f5\uc3fb\u425b\uabb2\u09a8\u022a\u39b4\u4d6d\u29af\u5e9b\u3814\u05a5\u8c2a\u17b4\u58ff", "\u14c3\uda41\udf84\ud896\udc99\udb2f\udc39\udb1b\udda0\uda59\udd66\uda0b\udc72",
        33, 30259, -479929347, -8642439145406359495L, 65307L, false, true, (char) 17672, (char) 22494,
        Double.longBitsToDouble(0x3fc70b93a98e469cL), Double.longBitsToDouble(0x3fec810cab020a6aL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.functors.EqualPredicate:@?\0121=java.lang.Boolean:true |this=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 6, 0, 3, "\ua43a\ud8c7\udf5a\udbfc\udd03\uda67\udca4", "\u92fe\ub8d7\u5f5d", "\udbd8\udc1d\ud8d6\ude65\ud851\ude43\ud87b\udfb8\ud98c\udcc4\ud922\udc59\uda66\ude4d",
        42, 93313, -1166162065, -6214563699748880571L, -55952L, false, true, (char) 46654, (char) 11477,
        Double.longBitsToDouble(0x3fe767fee5a72338L), Double.longBitsToDouble(0x3fe0066fa7730db8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.EqualPredicate:@?\0121=java.lang.String:\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4 |this=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 3, 5, 7, "\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4", "\u303f\u6e24\u5f5d", "\udbd8\udc1d\ud81a\ude47\udb75\udd0a\ud954\udec7\ud998\ude9e\ud9d1\udd3e\ud8f0\udc45",
        9, 28325, -1166167599, -6214563699747635387L, 34335L, true, true, (char) 31912, (char) 10178,
        Double.longBitsToDouble(0x3fe767fe7a6182e5L), Double.longBitsToDouble(0x3fe7b60f0720beb1L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 5, 3, "\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4", "\u303f_\u5ee6", "\udbd8\udc1d\ud8d6\ude65\udb9c\udca9\udbd4\ude1d\ud98c\udcc4\ud9d1\udd3e\ud8f0\udc45",
        17, -759, 0, -6214563966035607739L, -55952L, true, false, (char) 24020, (char) 1555,
        Double.longBitsToDouble(0x3fe767fe7a6182e5L), Double.longBitsToDouble(0x3fe7b60f0720beb1L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.functors.EqualPredicate:@?\0121=null |this=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 5, 5, 3, "\ud95a\uddcb\udab3\udcab\ud89a\ude13\uda90\udd2e\ud89e\udd6f\ud91b\udd26\ud892\udd84\ud9bc\udca8", "\u8bc9\u628c\u819b\u114f\u40a6\ub95b\u3ae7\u121a", "\u379d\udaa8\udd08\ud8d0\udfb7\ub845",
        34, 67853, 375469738, 5902803961934770512L, 77428L, true, false, (char) 56534, (char) 51480,
        Double.longBitsToDouble(0x3fdcace96efd2dc8L), Double.longBitsToDouble(0x3fe11d74b3fd9d52L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.EqualPredicate:@?\0121=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 3, 3, 5, "\ua43a\ud824\udce9\ud9fb\udc88\udbfd\udfcb", "\u303f\ua669\u5f2b", "\udbd8\udc1d\uda48\udf11\udb9b\udfed\udbd4\ude1d\ud8ca\udc22\udab8\udc42\udab6\udee3\uda42\udf83\udae3\uddcf\ud940\udf56",
        14, 97949, -875146408, -328983636457522740L, 72987L, true, true, (char) 64750, (char) 57071,
        Double.longBitsToDouble(0x3fe30c1782f6c1e0L), Double.longBitsToDouble(0x3fa054d8dccd78a0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 1, 4, 1, 3, "\ua43a\udb99\udc04\udbfc\udcd4", "\u36e3", "\ud948\udfb1",
        47, 722, 1741832617, 4935107756858417087L, 64239L, true, true, (char) 54490, (char) 47156,
        Double.longBitsToDouble(0x3fef88ca5f6f639bL), Double.longBitsToDouble(0x3fe9f5d3ef45a9c1L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.NullPredicate:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 6, 2, "\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4", "\u4f89\ub9d1\u5f5d", "\udbd8\udc1d\ud8d6\ude65\udbbc\udeb9\ud88a\udf64\udbd6\ude52\udb7d\udf1e\udbdb\udef1",
        15, 40001, -1008694008, 8144198598613632143L, -55952L, true, true, (char) 65284, (char) 41829,
        Double.longBitsToDouble(0x3fe767fe7a6182e5L), Double.longBitsToDouble(0x3fe7b60f0720beb1L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.collections.functors.NullPredicate:@?\0121=org.apache.commons.collections.functors.NullPredicate:@?\012",
        Z.run(T, 2, 3, 3, 0, "\udb42\udcc5\ub98f\ud835\udd5f\uda67\udc3a\u868e\uda06\udebb\ud854\udca4\ud999\udc56\ud8a1\udd3c\udbd8\udc8a\ud8f4\udfb6\udbd8\udc1d\ud8d6\ude65", "\ub9a4\u3ae7\ua965\u01e2\ud4db\ucdc5\ua76e\u4bc9\u1d85\u46df\u5685\u6b18\ub7af\ua8a0\u72c7\u38b8\u30c0\u9faa\u06ea\u22bc\u9e59\u794c\u5820\u1092\ucdc2\u93e0\u7faf\u33b7\u1cdd\u0e81", "\udb16\udff0\udac0\ude47\udb5b\udca6\udae5\udf65\udbb3\uddc4\uda88\ude7a\ud8c4\udcf2",
        0, 42518, -1842225091, -3361435681261687409L, 85257L, false, true, (char) 54279, (char) 1056,
        Double.longBitsToDouble(0x3fd4b5ab7670d042L), Double.longBitsToDouble(0x3f917f415dc2c760L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.functors.EqualPredicate:@?\0121=java.lang.String:\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4 |this=org.apache.commons.collections.functors.EqualPredicate:@?\012",
        Z.run(T, 2, 1, 5, 3, "\ua43a\ud824\udce9\udbfc\udcd4\uda67\udca4", "\u303f\u6e24\u4f77", "\udba0\udff0\ud8d6\ude65\udb9c\udca9\udb9a\udd1d\ud98c\udcc4\ud9d1\udd3e\ud8f0\udc45",
        17, 93313, -1166162065, -6214563699747635387L, -55952L, true, false, (char) 24020, (char) 1555,
        Double.longBitsToDouble(0x3fe767fe7a6182e5L), Double.longBitsToDouble(0x3fe7b60f0720beb1L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.functors.EqualPredicate|evaluate|java.lang.Object|new:org.apache.commons.collections.functors.EqualPredicate:java.lang.Object",
    "C|org.apache.commons.collections.functors.EqualPredicate|<init>|java.lang.Object",
    "C|org.apache.commons.collections.functors.EqualPredicate|<init>|java.lang.Object,org.apache.commons.collections.functors.Equator",
    "M|org.apache.commons.collections.functors.EqualPredicate|equalPredicate|java.lang.Object|static",
    "M|org.apache.commons.collections.functors.EqualPredicate|equalPredicate|java.lang.Object,org.apache.commons.collections.functors.Equator|static",
    "M|org.apache.commons.collections.functors.EqualPredicate|getValue||new:org.apache.commons.collections.functors.EqualPredicate:java.lang.Object",
    "M|org.apache.commons.collections.functors.EqualPredicate|evaluate|java.lang.Object|new:org.apache.commons.collections.functors.EqualPredicate:java.lang.Object",
    "C|org.apache.commons.collections.functors.EqualPredicate|<init>|java.lang.Object",
    "C|org.apache.commons.collections.functors.EqualPredicate|<init>|java.lang.Object,org.apache.commons.collections.functors.Equator",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
