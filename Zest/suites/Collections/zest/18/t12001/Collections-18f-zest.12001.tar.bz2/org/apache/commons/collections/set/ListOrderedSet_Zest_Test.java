package org.apache.commons.collections.set;
import org.junit.Test;
import static org.junit.Assert.*;
public class ListOrderedSet_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 13, 8, 14, "\udb9b\udca5\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u83f8\u4c42\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\ud883\udc8e\udb59\udef9\ud920\udf30\udbba\udda2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud839\udde3\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud89e\uddb3\udaaa\udeb0\udb63\udcb2",
        2, 96509, -1253826553, -7421589866557361761L, -93767L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 13, 8, 14, "\udb9b\udca5\uda06\uddbf\ud86a\udfcd\udbbd\udc1a", "\u0c59\u24ff\u83f8\u4c42\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\ud883\udc8e\udb59\udef9\ud80a\udd24\udbba\udda2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud8b0\ude32\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\ud96a\udf94\ud8e4\udd36\uda77\udfbe\ud8bd\ude78\uda6e\udf9f\ud93a\ude56\u341e\udaaa\ude56\udb63\udcb2",
        2, 96509, -1253826553, -7421589866557361761L, -93767L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3fb5fc83445b8b40L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 13, 0, 14, "\udb9b\udca5\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\ud767\u1a53\u0406\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\udb8d\udc93\ud901\udcf7\ud920\udf30\udbba\udda2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\udb3d\udf19\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\ua8eb\uda23\udeab\udafe\udfdf\ud9ad\udf34\ud87e\ude5b\ud89e\uddb3\udaaa\udeb0\udb63\udcb2",
        2, 96509, 1732517895, -8289344281652121181L, -93767L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=java.lang.Integer:-1 |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 13, 8, 14, "\udb88\ude66\uda2e\udd73\ud888\udeba\udbbd\udc1a\uda98\udfd3\ud8f7\udd15\udb7e\udd43\ud84f\udff7", "\u754e\u6371\u47b2\u8b84\u9c5a\u0411\ua31b\ucd6b\u848f\u832c\u4c42\u52e9\u9f97\ua29a\u2938\u7069\u3e36\u9046", "\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud89e\uddb3\udaaa\udeb0\udb63\udcb2\ud887\udc68\ud8bf\udcdf\ud9f8\udf9f\ud86a\udd44\udb0a\udc2c\ud8da\udc0d\ud900\udf09",
        10, 8248, -59607529, 8042368180406819875L, -52784L, false, true, (char) 32832, (char) 31927,
        Double.longBitsToDouble(0x3fefc963b2816e6bL), Double.longBitsToDouble(0x3feb529de2cf3f45L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udd44\uda2e\udd73\ud888\udeba\udbbd\udc1a]\0121=java.lang.Integer:-1 |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 11, 8, 14, "\udb9b\udd44\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u93f8\u4c42\ub9eb", "\ud97d\udde3\udae2\udd10\uda76\udefb\ud9ae\udce4\ud883\udc8e\udb59\udef9\ud920\udf30\uda30\udf3a\udb5f\udc8f\uda22\udca1\udb62\udd0b\ud8ce\udf1b\udba1\udc10\u7658\ud820\ude4e\udb73\udd6e\ud9b9\udd5e\uda34\udf58\u200a\uda56\udde4\uda77\udf62\ud884\udd70\u9954\ud80a\udf35\ud89e\uddb3\u8ee1\udb63\udcb2",
        24, 96509, 759439367, -7421589196542463585L, -93767L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet:[\udabc\udc52\uda45\udf73\ud888\udeba\udbbd\udc1a]\012",
        Z.run(T, 1, 10, 8, 14, "\udabc\udc52\uda45\udf73\ud888\udeba\udbbd\udc1a", "\ub02d\u8142\u2f4d\u4c42\u754e\uaf6b\u6fc3\u68c4\ua2ed\u0411\ua31b\ucd6b\u8537\u8ad8\u4c42\u52e9\u35c9\u8ebe\ub552\u1dc0\u3e36\u9046", "\uda34\udf58\udbe9\udcb2\ud9f9\udeb9\uda6b\udfe8\ud884\udd70\ud9ad\udf58\ud961\udf59\ud89e\uddb3\udaaa\udeb0\udb63\udcb2\ud887\udc68\ud8bf\udcdf\ud9f8\udf9f\ud86a\udd44\udb0a\udc2c\u68b9\ud8f4\udfa7",
        15, 8219, -59607529, 8042368050668608547L, -83477L, false, false, (char) 47205, (char) 6026,
        Double.longBitsToDouble(0x3fecddbb189fda25L), Double.longBitsToDouble(0x3fe5502178691fb7L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[null]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 7, 14, "\udb9b\udca5\uda2e\udd73\ud888\udeba\ud9d1\udf0f", "\u0c59\u24ff\u83f8\u4c42\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\ud883\udc8e\udb59\udef9\ud920\udf30\udbbb\udfa2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud839\udde3\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud89e\uddb3\udaaa\udeb0\udb63\udcb2",
        57, 28357, -1253826553, -7421589866557361761L, -93767L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 8, 14, "\udb9b\udca5\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u83f8\u614b\u7539\u6310", "\uda6e\ude1f\udb51\ude53\uda6b\udfd8\ud883\udc8e\ud979\ude55\ud920\udeee",
        22, 4635, 882217285, 113936596733067973L, 10767L, true, true, (char) 20245, (char) 32550,
        Double.longBitsToDouble(0x3fae4afaa8634cc0L), Double.longBitsToDouble(0x3fe2d9275dfe7fe7L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 15, 13, 8, "\udb48\ude7b\udbc7\udf95", "\u2f78\u0868\u0e5e\u5d36\u84e6\u4c42\u0307\u6371\u47b2\u8b84\u9c5a\u0411\ua31b\u0ee6\u9664\uc767\uadf8\u1294\ud6f4\u9f9d\u2938\ube43\u0219\u9046\ud716\ub634\u469b\u5f2a\u3fb7\u9ae1\u9c49\u210a\ub4a1\u34fe\u3279\ub662\u52fa\ud4d4", "\udb1c\ude1e\ud8da\udc0d\ud900\udf09\uda4b\udf59",
        8, 82471, 1868118848, -1004975465793314985L, -84614L, false, false, (char) 48363, (char) 20865,
        Double.longBitsToDouble(0x3fcea8f9576c6f80L), Double.longBitsToDouble(0x3fdd0bff964afba8L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 8, 14, "\udb9b\udca5\ud927\ude90\udbe6\udd15\udb7f\udec1", "\u0c59\u7a53", "\udb74\udd8a\ud8e7\uddd4\ud8a0\udca6\ud83a\udf02\uda80\udfdd\udb51\ude53\uda6b\udfd8\ud883\udc8e\udb59\udef9\ud920\udf30\udbba\udda2\udb5f\udcfd\udbbe\ude11\udb62\udc3e\ud9d3\udd17\ud839\udde3\u7687\ud820\ude4e",
        17, 44019, 885844028, 8243903467247567451L, 62718L, false, false, (char) 61898, (char) 23531,
        Double.longBitsToDouble(0x3fcf6beb1b02550cL), Double.longBitsToDouble(0x3fea65c787450cefL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet$OrderedSetIterator:@? |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 9, 8, 14, "\udb7b\udeb9\udb9a\udc7e\ud893\udf81\ud882\uddc9\uda99\udcd2\ud8f7\udd15\udb9b\udc40\ud8d8\udd91\ud957\udc88\udb30\udc25\udb74\uddcc\ud8e7\uddd4\ud8a0\udca6\uda60\udf35", "\uaa87\ucd6b\u848f\u4752\u11ee\u52e9\u9f97\ua29a\u7232\u2368", "\udb73\udd6e\ud8a3\udda3\udba9\udf62\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud89e\uddb3\udaaa\udeb0\ud8f9\udea0\udb86\udde3\ud8ec\udcc4\ud9f8\udf9f",
        34, 15855, -1016138849, 4137655385442418947L, 61303L, false, true, (char) 49590, (char) 4453,
        Double.longBitsToDouble(0x3fc16e2d118e1ef0L), Double.longBitsToDouble(0x3fdc336491d3aff4L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 8, 14, "\udb9b\udca5\uda2e\udd73\ud888\udeba\udbbd\udc1a\uda98\udfd3", "\u24ff\u83f8\u4c42\u754e", "\uda60\udf35\uda6e\ude1f",
        31, 90055, 1921705485, 211463787671363598L, -89645L, true, true, (char) 7760, (char) 47544,
        Double.longBitsToDouble(0x3fe34663d3af3b11L), Double.longBitsToDouble(0x3fd876329c5f0ae4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 0, 8, 14, "\udb9b\udca5\uda2e\udd73", "\uc16d\u0868\u0c59\u94b2\u14dc\u4c42\u08dc\u03bf\ua224\u8b84\u6338\u0411\ua31b\ucd6b\u848f\u832c\u5609\u4315\u2a3f\ua29a\u2de3\u42c7\ub1c5\u9098\ud716\ub634\uc6c0\u8e47\u31f2\ud572\ub79c\ubeb6\ub4b0\u34fe\u3279\ub662\u52fa\uc4da", "\udb0a\udc2c\ud8da\udc0d\ud900\udf09\uda4b\udf59",
        8, 82471, 1872509760, -1004975465793314985L, -73476L, false, false, (char) 6294, (char) 25424,
        Double.longBitsToDouble(0x3fe4174990b4bce6L), Double.longBitsToDouble(0x3fbb08ce4d282358L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 8, 14, "\udb9b\udca5", "\u82f5\u0dfd\u2975\u69a5\u24ff", "\udb33\udd6a\ud8e7\uddd4\udace\udc9d\uda6e\udd35\uda6e\ude1f\udbab\udc20\uda9b\udeec\ud883\udc8e\udb59\udef9\ud920\udf30\udbba\udda2\udb0e\uddb4\ud919\udc6a\udb62\udcd2\udb38\udcc1\ud839\udde3\u7687\ud820\ude4e",
        16, 44019, 885844028, 2660284354238284379L, 62718L, false, false, (char) 61898, (char) 32581,
        Double.longBitsToDouble(0x3fd0cc5b191382e2L), Double.longBitsToDouble(0x3fe3477f88450cefL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 6, 11, 8, "\udb9b\udca5\uda2e\udd73\ud87c\uddba", "\u3ec3\u0c59\u24ff\u0e47\u4c42\u49f3\u396e\u4211\u8b84\u9c5a\u0411\u3556\u728f\u5a70\u1be6\u4c42\u91ad\u5a71\u7675\u2938\u94da\u3e36\u9046\ud716\u8276\u9d7c\ua2d0\u99bb\u9ae1", "\ud93a\uddf4\ud89e\uddb3\uda7b\udd14\udb63\udcb2",
        2, 88069, 1449298540, -7702156943545103617L, -93767L, false, false, (char) 50636, (char) 26352,
        Double.longBitsToDouble(0x3fe8d45394ff537aL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=java.lang.Integer:-1 |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 13, 8, 14, "\udb9b\udca5\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u83f8\u4c42\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\ud883\udc8e\uda86\ude94\ud920\udf72\udbba\udda2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud839\udde3\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud89e\uddb3\udaaa\udeb0\udb63\udcb2",
        2, 96509, -1253826553, -7421589866557361761L, -93767L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udca5\uda2e\udd73\ud888\udefc\udbbd\udc1a]\012",
        Z.run(T, 1, 4, 8, 14, "\udb9b\udca5\uda2e\udd73\ud888\udefc\udbbd\udc1a", "\u0c59\u24ff\u83f8\u605a\u0c23\u3823\u4849\u8b04\u7c83\u071d\ua31b\ucd6b\u848f\u832c\u4c42", "\udb62\udcd2\ud8e1\udd14\udba1\udc38\u7687",
        11, 54887, -1779069981, 3804671130236304006L, 73340L, false, false, (char) 23992, (char) 61898,
        Double.longBitsToDouble(0x3f96fb2f1f6be860L), Double.longBitsToDouble(0x3fee04ab64803b97L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.UnmodifiableList:[] |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 5, 14, 8, "\udbbe\udd95\uda17\udcc2\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u83f8\u31e3\u7a33", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\uda6a\udd58\ud8bd\udc52\udbb6\uddba\ud85f\uddd5\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud839\udde3\u7687\ud820\ude4e\uda25\udde7\ud8a3\udd82\ud94b\udebf",
        24, 45115, -867292915, 6509740315931869874L, -68278L, true, false, (char) 33795, (char) 24725,
        Double.longBitsToDouble(0x3fb1433bc03a70c8L), Double.longBitsToDouble(0x3feab5aa249f9901L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 12, 8, 14, "\udb9b\udca5\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u83f8\u4c42\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\ud883\udc8e\udb59\udef9\ud920\udf30\udbba\udda2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud839\udde3\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud89e\uddb3\udbff\udcb0\udb63\udcb2",
        2, 96509, -1253826553, -7421589866557361761L, -93767L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 12, 14, "\udb9b\udca5\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u59f9\u4c42\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda3f\udee2\uda99\udcc4\udb59\udef9\ud920\udf30\udbba\udda2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud839\udde3\u7687\ud820\ude4e\ud901\udc44\ud8a3\uddb2\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\udb0e\udcf8\udb03\udf5b\udac6\ude56\udae7\udf0b\ud964\ude61",
        2, 96509, -1253826553, -7421589866557361761L, -93767L, false, false, (char) 23271, (char) 17196,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 13, 13, 14, "\ud9d9\udda4\uda2e\udded\udb33\udf18\udb22\udf88", "\u0c59\ud767\u1a55\u0406\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\udb8d\udc93\ud901\udcf7\ud920\udf30\udbba\udda2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud8f0\udf19\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\ua8eb\uda23\udeab\udafe\udfdf\ud9ad\udf34\ud87e\ude5b\udb65\udf3e\udaef\ude35\udb63\udcb2",
        2, 96509, 1498554375, -8289344281652121181L, -93767L, false, false, (char) 50636, (char) 4080,
        Double.longBitsToDouble(0x3fea07e5fc236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 12, 14, "\udb88\ude66\uda2e\udd73\ud888\udeba\udbbd\udc1a\uda98\udfd3\ud8f7\udd15\udb7e\udd43\ud84f\udff7", "\u754e\ub945\u47c2\u8b84\u9c5a\u0411\ua31b\ucd6b\u848f\u832c\u9357\u52e9\u2164\ud211\u4292\u6510\u3e36\u9046", "\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud89e\uddb3\udaaa\udeb0\udb63\udcb2\ud887\udc68\ud8bf\udcdf\ud9f8\udf9f\ud86a\udd44\udb0a\udc2c\ud8d9\ude80\udb8e\udc49",
        10, 8248, -59607529, 8042368180406819875L, -52784L, false, true, (char) 32832, (char) 31927,
        Double.longBitsToDouble(0x3fefc963b2816e6bL), Double.longBitsToDouble(0x3fdd053bc59e7f72L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 0, 0, 14, "\udb88\ude66\uda2e\udd73\ud888\udeba\udbbd\udc1a\uda98\udfd3\ud8f7\udd15\uf762\000", "", "",
        -5, -1000, -1635143714, 214973181722624L, 96608L, false, false, (char) 0, (char) 10355,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fc8a03281a09c00L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 14, 9, "\udab3\udea0\uda2e\uddca\ud888\udeba\udbbd\udc1a\uda61\udfb6\ud87a\udc93\udb7e\udd2d\ud84f\udff7", "\u754e\u6371\u47b2\u8b84\u9c5a\u70ce\ub450\ub844\u848f\u832c\u4c42\u52e9\u3997\ua29a\u2938\u7069\u3e36\u9046", "\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud89e\uddb3\udaaa\udeb0\udb63\udcb2\ud887\udc68\ud8bf\udcdf\ud9f8\udf9f\ud86a\udd44\udb0a\udc2c\ud8da\udc0d\ud900\udf09",
        10, 42056, -1862949448, 8062457597876083747L, -52784L, false, true, (char) 32832, (char) 31927,
        Double.longBitsToDouble(0x3fcbbb0ed2a43b34L), Double.longBitsToDouble(0x3feb571fe2cf3f45L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 13, 3, 14, "\udbfc\udd5f\uda0f\udc9d\ud888\udec8\udae4\udc4d\udb1e\ude2a\ud8f7\udd15\udb29\udf7b\ud8fe\udf95\ud8aa\udf66\ud84f\udf0d\udb71\udd5d\ud916\ude9b\ud846\udd3d\uda60\udf35\uda57\udd1f\udb51\ude53", "\u848f\u832c\u4c42\u52e9", "\ud8e1\udd14\ud839\udde3",
        23, 93495, -213660113, -7641047385131395088L, 97335L, false, true, (char) 41532, (char) 23992,
        Double.longBitsToDouble(0x3fe516394416fb2fL), Double.longBitsToDouble(0x3fcf6be8716d1d0cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udd44\ud9a9\ude41\ud888\udeba\udbbd\udc1a]\0121=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udd44\ud9a9\ude41\ud888\udeba\udbbd\udc1a]\012",
        Z.run(T, 2, 11, 10, 14, "\udb9b\udd44\ud9a9\ude41\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff", "\udb85\ude27\ud8e7\uddd4\ud8a0\udca6\ud97d\udde3\udae2\udd10\uda01\udf81\ud822\udcb7\ud919\udf98\udb50\ude19\ud920\udf30\uda30\udf3a\ud948\ude0b\uda22\udca1\udb62\udd0b\ud8ce\udf1b\udba1\udc10\u7658\udab0\udd7f",
        17, 46242, 218797035, 725005577261759328L, 62718L, false, false, (char) 48135, (char) 32644,
        Double.longBitsToDouble(0x3fcf76287b01905cL), Double.longBitsToDouble(0x3fefe32780450cefL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udd44\uda2e\udd73\ud888\udeba\udbbd\udc1a]\0121=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udd44\uda2e\udd73\ud888\udeba\udbbd\udc1a]\012",
        Z.run(T, 2, 11, 11, 14, "\udb9b\udd44\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u9422\u4c42\ub9eb", "\ud97d\udde3\udae2\udd10\uda76\udefb\uda73\udfa7\uda9e\udc7a\udb53\udd99\ud920\udf30\uda30\udf3a\udb5f\udc8f\uda22\udca1\udb62\udd0b\ud8ce\udf1b\udba1\udc10\u7658\ud820\ude4e\udb73\udd6e\ud9b9\udd5e\uda34\udf58\u200a\uda56\udde4\uda77\udf62\ud884\udd70\u9954\ud80a\udf35\ud89e\uddb3\u8ee1\udb63\udcb2",
        24, 96509, 759439367, -7421589196542479724L, -93767L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 8, 14, "\udb9b\udd44\ud904\ude1d\ud888\uded7\udbbd\udc1a", "\u9cc3\u24ff\uc58a\uc350\uc930", "\ud97d\udde3\udae2\udd10\uda76\udefb\ud9ae\udce4\ud883\udc8e\udb59\udef9\udba9\udcf4\udaaf\udce7\udb74\udd59\uda22\udca1\udaa5\udc15\ud8ce\udf1b\udba1\udc10\u7658\uda2b\udd54\ud97a\udc06\ud9b9\udd5e\uda34\udf58\u200a\uda56\udde4\uda77\udf62",
        45, 25226, -76657798, 6864475488746166523L, -91801L, false, true, (char) 19104, (char) 25300,
        Double.longBitsToDouble(0x3fd858622f741e06L), Double.longBitsToDouble(0x3fe2e0e9ce1760d9L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udd94\uda0c\udc73\udaf9\udff3\ud9a6\uddc6\uda59\udd12\ud8f7\udd15\udb7e\udd43\ud84f\udff7\ud954\uddf7\udaaa\uddad\udb85\ude27\ud8e7\uddd4\ud8a0\udd20\ud97d\udde3\udae2\udd10]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udd94\uda0c\udc73\udaf9\udff3\ud9a6\uddc6\uda59\udd12\ud8f7\udd15\udb7e\udd43\ud84f\udff7\ud954\uddf7\udaaa\uddad\udb85\ude27\ud8e7\uddd4\ud8a0\udd20\ud97d\udde3\udae2\udd10]\012",
        Z.run(T, 2, 4, 3, 0, "\udb9b\udd94\uda0c\udc73\udaf9\udff3\ud9a6\uddc6\uda59\udd12\ud8f7\udd15\udb7e\udd43\ud84f\udff7\ud954\uddf7\udaaa\uddad\udb85\ude27\ud8e7\uddd4\ud8a0\udd20\ud97d\udde3\udae2\udd10", "\u4bb1\ua8b9\ucb65\u2a2d\u527b\u7dc3\ua2d3\u7d8b\uae82\u9b5c\u649e\uc0bb\u8d0f\u46d0\u8bb9", "\uda0e\udd75\udae7\udf57\ud80a\udf35\ud89e\uddb3\u8ee1\udb63\udcb2\uda04\udfd7\ud8bf\udcdf\udb9e\udeb1\uda47\ude6d\ud869\uddb2\ud96c\uddbd\ud820\udf46\udb51\ude30\ud8d9\udc8c\ud973\udde1\udb38\uddd3\ud9aa\udea3\uda22\udd67\ud870\udfda\udbdf\udf13\ud96f\udeb4\udb16\ude90\udaed\udc0f\uda5f\udca6\udb04\udddb\ud9bf\udf48\ud93b\udf74\udaee\udf86\ud9d2\udf3a\u3eab\udb60\udeea\ud8df\ude76\ud8b8\udc3c\ud9b6\udfb7\ud9ed\ude4f",
        32, 40608, 1943221156, 6836289143717749938L, 15333L, true, true, (char) 33508, (char) 56460,
        Double.longBitsToDouble(0x3fbef85f3a070d28L), Double.longBitsToDouble(0x3fc2672e29dc68d4L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udbcf\udc23\ud8ca\udfd4\ud84e\udc36\udbbc\udfbb\udaae\udf05]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[\udbcf\udc23\ud8ca\udfd4\ud84e\udc36\udbbc\udfbb\udaae\udf05]\012",
        Z.run(T, 2, 4, 0, 10, "\udbcf\udc23\ud8ca\udfd4\ud84e\udc36\udbbc\udfbb\udaae\udf05", "\ub016\ucf07\ua9b1\ua93b", "\udab5\ude11\udb43\udc6c\udbba\udff1\ud963\udd27\uda3d\udfa3\ud9a7\udf22\udb1a\udf2d\ud86d\udd3a\ud9f7\ude03\u437d\ud9b5\udefc\ud80f\udc56\udba1\udc9f\udbc4\uddcc\udab4\udeb3\udb73\udd83\uda24\ude33\udbe0\udde0\ud8cb\udf83\uda56\udde4\ud952\udf90\ud89b\uddff\udb61\udf05\udb03\udfa1\uda10\udc8e\udba8\udeda\udb63\udc50",
        24, 20189, -1391779833, -8784546219316541024L, -42912L, true, false, (char) 25662, (char) 44914,
        Double.longBitsToDouble(0x3fe207e3940c3a50L), Double.longBitsToDouble(0x3fe89dbfa89567d5L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet:[\udbe9\ude2a\uda0d\ude12\ud888\udeba\udbbd\udc1a\uda98\udfd3\udacb\udfc0\udb35\udea9\ud84f\udff7\ud95b\udc88\udb30\udc25\udbd6\udd70\ud8e7\uddd5\ud8a0\udca6]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 11, 2, 12, "\udbe9\ude2a\uda0d\ude12\ud888\udeba\udbbd\udc1a\uda98\udfd3\udacb\udfc0\udb35\udea9\ud84f\udff7\ud95b\udc88\udb30\udc25\udbd6\udd70\ud8e7\uddd5\ud8a0\udca6", "\u101c\u7d09\ucd6b\u848f\u832c\u64b5\u527b\u7dc3\ua2d3\u783a\uade1\u3e07\u9046\ud716", "\u200a\udaf1\udff2\uda64\udd80\ud884\udd70",
        6, 202, 1598260246, 7212331165010685632L, -26203L, true, false, (char) 25910, (char) 19104,
        Double.longBitsToDouble(0x3feb0481a8a73c4fL), Double.longBitsToDouble(0x3fe1f1c8216aceecL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 10, 4, "\udb9b\udca5\uda2e\udd73\ud888\udeba\ud9d1\udf0f", "\u50ed\u24ff\u83f8\u4c42\u754e", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\ud883\udc8e\udb59\udef9\ud920\udf30\udbbb\udfa2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\udba7\ude5a\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud9cd\ude71\uda8f\udf78\ud814\udfbd",
        25, 28357, -1253826553, -7421589866557361761L, -93767L, false, false, (char) 60299, (char) 28419,
        Double.longBitsToDouble(0x3feebebb14f8be8aL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udaea\udcbc\udb50\udfe8\ud8aa\udfb5\ud9e8\udd2f\ucbc1\uda0e\udd3e]\0121=void |this=org.apache.commons.collections.set.ListOrderedSet:[\udaea\udcbc\udb50\udfe8\ud8aa\udfb5\ud9e8\udd2f\ucbc1\uda0e\udd3e]\012",
        Z.run(T, 2, 1, 2, 14, "\udaea\udcbc\udb50\udfe8\ud8aa\udfb5\ud9e8\udd2f\ucbc1\uda0e\udd3e", "\ua653\u6c94\u97d9\u6371\u47b2\u8b84", "\uda6b\udffc\ud883\udc8e\ud9e9\ude31",
        3, 31248, -984340365, 3789094387067439291L, 72791L, true, false, (char) 44208, (char) 43998,
        Double.longBitsToDouble(0x3fef1f36483c95f5L), Double.longBitsToDouble(0x3fe6a466625b24ebL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udb9b\udca7\ud995\udf64\ud888\udeba\ud9d1\udf0f]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 1, 15, 14, "\udb9b\udca7\ud995\udf64\ud888\udeba\ud9d1\udf0f", "\u0c59\uc5d8\u843c\uceda\u75f2", "\udb60\udcc0\uda6e\ude1f\udb51\ude53\uda6b\udfd8\udbe4\udc17\ud86b\udd7a\udb9e\uddef\uda43\udd3e\udbf1\udf5d\ud919\udc5e",
        29, 52534, 990970461, -3951433479064390464L, 60797L, false, false, (char) 28498, (char) 10054,
        Double.longBitsToDouble(0x3fe533ff3b9e2655L), Double.longBitsToDouble(0x3fe596d83226c728L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 11, 14, "\udb9b\udca5\uda2e\udd73\ud937\ude12\ud9d1\udf0f", "\u0c59\u24ff\u83f8\u4c42\u754e", "\ud884\udd30\uda6e\ude1f\ud901\udfe3\ud870\udf1b\ud883\udc8e\udb59\udef9\ud920\udf30\udbbb\udfa2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud839\udde3\u3387\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\ud9ad\udf58\ud93a\ude59\ud9a5\udff8\udaaa\udeb0\udb63\udcb2",
        57, 28357, -1253826553, -7421589866557361761L, -49466L, false, false, (char) 50636, (char) 55024,
        Double.longBitsToDouble(0x3fea07e394236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 12, 14, "\udb88\ude66\ud81e\udd4a\ud9f6\udd49\udbbd\udc1a\uda98\udfd3\ud8f7\udd15\udb7e\udd43\ud84f\udff7", "\u754e\ub945\u47c2\u8b84\u9c5a\u0411\ud153\ud6ba\u848f\u832c\u9357\u52e9\u2164\ud211\u4292\u6510\u3e36\u4d50", "\uda19\ude0b\udbe9\udcb2\uda56\udde4\uda77\udf62\ud884\udd70\uda8a\udd86\ud972\udfc5\ud944\udc14\ud8f0\udcd1\udb63\udcb2\ud84e\ude34",
        4, 35886, 119680946, -4784488059593109651L, 3488L, false, false, (char) 55024, (char) 11328,
        Double.longBitsToDouble(0x3fa19fce757f20d0L), Double.longBitsToDouble(0x3fd8b71685930806L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet$OrderedSetIterator:@? |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=org.apache.commons.collections.set.ListOrderedSet$OrderedSetIterator:@? |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 9, 9, 4, "\ud82b\udf55\uda2e\udd73\ud888\udeba\udbbd\udc1a\uda98\udfd3\ud9f7\udddc\udb7e\udd2f\ud84f\udff7\ud957\udc88\uda21\udfea\ud988\udd4f\udb1c\udceb\udabd\ude01\ud9aa\udfc3\uda6c\udd4a\udb51\ude53\ud93d\udc01\ud911\uddd6\udb59\udf1c\ud920\udf30\ud8e4\udd97\ud840\udd05\u09c3\u8209\uda9f\udc68\ud86e\udfd4\u7687\ud820\ude39\uda0f\ude3c\ud89d\udc95\ud923\udc67\udbe9\udcb2\udbef\udcd1\ud929\udd7e", "\ub4ec\ud068\u5792\ub662\u52fa\ud4d4\u8da8\uc543\ud394\uc917\ua0b5\u3354", "\udb38\uddd3",
        39, 26083, -217891176, -6326386306636741307L, 56054L, true, true, (char) 52334, (char) 26839,
        Double.longBitsToDouble(0x3fd2158e559e7f72L), Double.longBitsToDouble(0x3fea70147ca0fce5L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet:[\udb88\ude66\udbca\udc92\ud99e\uded6\ud84b\udd5f\uda98\udf86\ud8f7\udd15\udb7e\udd43\ud84f\udff7\ud957\udc88\ud804\udc9a\udb74\udd8a\ud9c2\udc81\ud8a0\udcb6\uda60\udf35\uda6e\ude1f]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 10, 12, 14, "\udb88\ude66\udbca\udc92\ud99e\uded6\ud84b\udd5f\uda98\udf86\ud8f7\udd15\udb7e\udd43\ud84f\udff7\ud957\udc88\ud804\udc9a\udb74\udd8a\ud9c2\udc81\ud8a0\udcb6\uda60\udf35\uda6e\ude1f", "\ucd6b\u848f\u832c\ua682\u796a\u27bd\ucf1f\u3cce\u6510\u3e36\u9046\ud716\u1423\u3dca\u8e47\u31f2\u5ac3\u57cd\u6753\ub4ec\u34fe\u3279\ub662\u52fa\ud4d4\ua773", "\ud8d9\ude80\udb8e\udc49\ud91e\udda0",
        8, 14951, 1262107493, -1005123607805288617L, 26183L, false, true, (char) 31806, (char) 52334,
        Double.longBitsToDouble(0x3fe40b735dd053bcL), Double.longBitsToDouble(0x3fe679fdc9a9348bL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=void |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 6, 6, 1, "\uda60\ude72\uda2e\udd73\ud888\udeba\udbbd\udc1a\uda98\udfd3\ud8f7\udd15\udb7e\udd43\ud84f\udff7\ud957\udc88\udb30\udc2d\udb74\udd8a", "\u8b84\u9c5a\u0411\ua31b", "\ud920\udf30\ud935\udc8f\uda3c\udc6f\u09c3\udb44\udf9a\udb8d\udc68\ud86e\udfd4\u7687\ud820\uddfc",
        17, 44019, 885844028, 2660284354238284379L, 62718L, false, false, (char) 61898, (char) 32581,
        Double.longBitsToDouble(0x3fcf6be87b02550cL), Double.longBitsToDouble(0x3fed2b2780450cefL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udbfc\udd5f\uda0f\udc9d\ud92e\udebb\udae4\udc4d\udb3e\udd2a\udbea\uddb0\udaf6\ude9c\ud8fe\udf95\ud8aa\udf66\ud84f\udf0d\udb71\udd5d\ud916\ude9b\ud846\udd3d\uda60\udf35\uda57\udd1f\udb51\ude53]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[\udbfc\udd5f\uda0f\udc9d\ud92e\udebb\udae4\udc4d\udb3e\udd2a\udbea\uddb0\udaf6\ude9c\ud8fe\udf95\ud8aa\udf66\ud84f\udf0d\udb71\udd5d\ud916\ude9b\ud846\udd3d\uda60\udf35\uda57\udd1f\udb51\ude53]\012",
        Z.run(T, 2, 1, 1, 12, "\udbfc\udd5f\uda0f\udc9d\ud92e\udebb\udae4\udc4d\udb3e\udd2a\udbea\uddb0\udaf6\ude9c\ud8fe\udf95\ud8aa\udf66\ud84f\udf0d\udb71\udd5d\ud916\ude9b\ud846\udd3d\uda60\udf35\uda57\udd1f\udb51\ude53", "\u848f\u832c\u4c42\u49ef", "\ud905\udd14\ud839\udde3",
        23, 93495, -213660113, -7641047385131395088L, 88375L, true, true, (char) 58014, (char) 2552,
        Double.longBitsToDouble(0x3fcef402e6fab5fcL), Double.longBitsToDouble(0x3fcf6bf8916d1d0cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udbfc\udd5f\uda0f\udc9d\ud888\udec8\udae4\udc4d\udb1e\ude2a\ud8f7\udd15\udb29\udf7b\ud8fe\udf95\ud8aa\udf66\ud84f\udf0d\udaa8\udc73\ud9c9\udf6d\ud846\udd3d\uda60\udf35\uda57\udd1f\ud810\udc72\ud9a8\ude55]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[\udbfc\udd5f\uda0f\udc9d\ud888\udec8\udae4\udc4d\udb1e\ude2a\ud8f7\udd15\udb29\udf7b\ud8fe\udf95\ud8aa\udf66\ud84f\udf0d\udaa8\udc73\ud9c9\udf6d\ud846\udd3d\uda60\udf35\uda57\udd1f\ud810\udc72\ud9a8\ude55]\012",
        Z.run(T, 2, 4, 4, 14, "\udbfc\udd5f\uda0f\udc9d\ud888\udec8\udae4\udc4d\udb1e\ude2a\ud8f7\udd15\udb29\udf7b\ud8fe\udf95\ud8aa\udf66\ud84f\udf0d\udaa8\udc73\ud9c9\udf6d\ud846\udd3d\uda60\udf35\uda57\udd1f\ud810\udc72\ud9a8\ude55", "\u832c\u4c42\u9ba0\u9f97\ua29a\u2938\ubf11", "\udb73\udd6e\ud8a3\udda3\uda64\udde6\ud996\udd66\udb31\udea8\ud8ce\udc1a\ud99f\udfcc\ud9ad\udf58\ud8f1\udc1e\ud8fb\udc49\ud829\udc4d\udbe5\udf90\udb00\udcea\ud8ba\udca0",
        15, 23314, -909063333, 2727501139440968022L, 97783L, false, true, (char) 48583, (char) 45037,
        Double.longBitsToDouble(0x3fdcf2dee8918d32L), Double.longBitsToDouble(0x3fca42b9c67b4e10L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.ListOrderedSet:[\udb78\ude69\ud8fd\udf9c\udab8\udecf\udbbd\udc1a\ud852\udda1\udb94\ude32\uda21\udf19\ud850\udc4b\udab4\ude79\ud87b\udcf8\ud939\ude54\uda61\udd5e\ud9f3\udd1a\uda0c\udfc8\udae2\udd10\uda76\udefb\ud9ae\udce4\ud883\udc8e\udb59\udef9\udbc4\udef4\udaaf\udce7\udb74\udd59\uda22\udca1\udb27\udc55\ud8ce\udeda\udba1\udc10\udb33\udf63\ud9e6\udd8c\udbd2\udc96\u9b52\uda34\udf84\u200a\ud997\udf30\ud8d5\udc12\ud8ac\uddc1\ud935\uddcd\ud80a\udf35\ud89e\uddb3\u8ee1\ud9cc\udf75\udada\udd85]\0121=org.apache.commons.collections.set.ListOrderedSet:[\udb78\ude69\ud8fd\udf9c\udab8\udecf\udbbd\udc1a\ud852\udda1\udb94\ude32\uda21\udf19\ud850\udc4b\udab4\ude79\ud87b\udcf8\ud939\ude54\uda61\udd5e\ud9f3\udd1a\uda0c\udfc8\udae2\udd10\uda76\udefb\ud9ae\udce4\ud883\udc8e\udb59\udef9\udbc4\udef4\udaaf\udce7\udb74\udd59\uda22\udca1\udb27\udc55\ud8ce\udeda\udba1\udc10\udb33\udf63\ud9e6\udd8c\udbd2\udc96\u9b52\uda34\udf84\u200a\ud997\udf30\ud8d5\udc12\ud8ac\uddc1\ud935\uddcd\ud80a\udf35\ud89e\uddb3\u8ee1\ud9cc\udf75\udada\udd85]\012",
        Z.run(T, 2, 10, 10, 15, "\udb78\ude69\ud8fd\udf9c\udab8\udecf\udbbd\udc1a\ud852\udda1\udb94\ude32\uda21\udf19\ud850\udc4b\udab4\ude79\ud87b\udcf8\ud939\ude54\uda61\udd5e\ud9f3\udd1a\uda0c\udfc8\udae2\udd10\uda76\udefb\ud9ae\udce4\ud883\udc8e\udb59\udef9\udbc4\udef4\udaaf\udce7\udb74\udd59\uda22\udca1\udb27\udc55\ud8ce\udeda\udba1\udc10\udb33\udf63\ud9e6\udd8c\udbd2\udc96\u9b52\uda34\udf84\u200a\ud997\udf30\ud8d5\udc12\ud8ac\uddc1\ud935\uddcd\ud80a\udf35\ud89e\uddb3\u8ee1\ud9cc\udf75\udada\udd85", "\u8212", "\udb8a\uddef\ud8b5\ude2d\ud9d4\udc61\udbeb\udfcb\ud8c7\udd7d\ud813\udcc1\uda65\udd54\ud960\ude48\udbe9\udff9\ud8f6\ude2d\ud952\udd0e\udaa1\udcf2\ub0f7\udad6\udc59\udae5\ude95\uda47\udc68",
        58, 3772, 1000603337, 5216164358470250640L, -50187L, true, false, (char) 58483, (char) 13583,
        Double.longBitsToDouble(0x3fe225021809758fL), Double.longBitsToDouble(0x3fdb4ce16e1b0666L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 15, 15, 12, "\ud826\udf2d\ud934\udf86\udbd7\udc61\uda97\udf6d", "\u0c59\uc5d8\uba95\u2150\ub7ad\u8337", "\uda6e\ude1f\udb51\ude53",
        40, 93632, -589219956, 2198809644149796179L, 63106L, true, false, (char) 21138, (char) 16874,
        Double.longBitsToDouble(0x3fa81d88cc0c9290L), Double.longBitsToDouble(0x3fcb56d8ef8f544cL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\ud9ed\udf6a\uda2e\udd73\ud8e6\ude42\ud8c5\ude6a\uda99\udc38\udb96\udea6\udb7e\udd43\ud84f\udff7\ud957\udc88\udb30\udc25\udb74\udd8a\ud8e7\uddd4\ud8a0\udca6]\0121=java.lang.String:\ud9ed\udf6a\uda2e\udd73\ud8e6\ude42\ud8c5\ude6a\uda99\udc38\udb96\udea6\udb7e\udd43\ud84f\udff7\ud957\udc88\udb30\udc25\udb74\udd8a\ud8e7\uddd4\ud8a0\udca6 |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 1, 14, 3, "\ud9ed\udf6a\uda2e\udd73\ud8e6\ude42\ud8c5\ude6a\uda99\udc38\udb96\udea6\udb7e\udd43\ud84f\udff7\ud957\udc88\udb30\udc25\udb74\udd8a\ud8e7\uddd4\ud8a0\udca6", "\uc340", "\udb59\udef9\ud920\udf30\udbbb\udfa2",
        0, 82285, 26527931, 2824041487460794984L, 49895L, true, false, (char) 32550, (char) 32305,
        Double.longBitsToDouble(0x3fe431a6625b24ebL), Double.longBitsToDouble(0x3fd1c7fe773c4d3cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.UnmodifiableList:[] |this=org.apache.commons.collections.set.ListOrderedSet:[]\0121=org.apache.commons.collections.list.UnmodifiableList:[] |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 5, 5, 3, "\udb88\ude66\ud81e\udd4a\ud9f6\udd49\udbbd\udc1a\uda98\udfd3\ud8f7\udd15\udb7e\udd43\ud84f\udff7", "\u754e\ub945\u47c2\u8b84\u9c5a\u0411\ud153\ud6ba\u848f\u3f44\ua97a\u529b\u2164\ud211\u4292\u6510\u3e36\u4d50", "\uda19\ude0b\ud976\uddb3\uda56\udde4\udac6\udd9a\ud884\udd70\uda8a\udd86\ud972\udfc5\ud944\udc14\ud8f0\udcd1\udb63\udcb2\ud84e\ude34",
        4, 35886, 119680946, -4784488059593109651L, 22688L, false, false, (char) 55024, (char) 11328,
        Double.longBitsToDouble(0x3fa19fce757f20d0L), Double.longBitsToDouble(0x3fef7b8b42c9c6a5L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[null]\0121=null |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 1, 14, 3, "\ud9ed\udf6a\uda2e\udd73\ud8e6\ude42\ud8c5\ude6a\uda99\udc38\udb96\udea6\udb7e\udd43\ud84f\udff7\ud957\udc88\udb30\udc25\udb74\udd8a\ud8e7\uddd4\ud8a0\udca6", "\uc340", "\udb59\udef9\ud920\udf30\udbbb\udfa2",
        0, 15917, -1785411397, 2824041487460794984L, 49895L, true, false, (char) 32550, (char) 32305,
        Double.longBitsToDouble(0x3fe431a6625b24ebL), Double.longBitsToDouble(0x3fd1c7fe773c4d3cL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\ud9ed\udf6a\ud868\udd70\udaf2\ude81\ud8ee\udccf\uda99\udc38\udb96\udea6\udb7e\udd43\ud84f\udff7\udb5d\ude0c\ud93c\udf87\udb74\udd8a\ud8e7\uddd4\udb4d\udc22]\0121=java.lang.String:\ud9ed\udf6a\ud868\udd70\udaf2\ude81\ud8ee\udccf\uda99\udc38\udb96\udea6\udb7e\udd43\ud84f\udff7\udb5d\ude0c\ud93c\udf87\udb74\udd8a\ud8e7\uddd4\udb4d\udc22 |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 2, 3, 14, 3, "\ud9ed\udf6a\ud868\udd70\udaf2\ude81\ud8ee\udccf\uda99\udc38\udb96\udea6\udb7e\udd43\ud84f\udff7\udb5d\ude0c\ud93c\udf87\udb74\udd8a\ud8e7\uddd4\udb4d\udc22", "\uc340", "\udb59\udef9\ud920\udf30\ud87e\udd99",
        0, 15917, -1097545541, 3404112034872027117L, 86751L, true, true, (char) 13889, (char) 35257,
        Double.longBitsToDouble(0x3fc0c69989a09b1cL), Double.longBitsToDouble(0x3feb53ff3b9e879eL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[]\012",
        Z.run(T, 1, 13, 8, 14, "\udb9b\udd06\uda2e\udd73\ud888\udeba\udbbd\udc1a", "\u0c59\u24ff\u83f8\u4c42\u7500", "\uda60\udf35\uda6e\ude1f\udb51\ude53\uda6b\udfd8\ud883\udc8e\udb59\udef9\ud920\udf30\udbba\udda2\udb5f\udcfd\ud919\udc5e\udb62\udcd2\ud8e1\udd14\ud839\udde3\u7687\ud820\ude4e\udb73\udd6e\ud8a3\udda3\uda34\udf58\udbe9\udcb2\uda56\udde4\uda77\udf62\ud871\udc26\ud9ad\udf4a\ud93a\ude59\ud89e\uddb3\udaaa\udeb0\ud98a\udc72",
        45, 96605, -1253826553, -7421589866557361761L, -93767L, false, false, (char) 13743, (char) 43958,
        Double.longBitsToDouble(0x3fea07e7a4236f9cL), Double.longBitsToDouble(0x3feabf90688b7168L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 3, 12, 14, "\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3", "\u24ff\u80c0\u4b9d\u754e", "\ud9c1\udf06\uda6e\ude3f\udb32\ude2d\udbf3\udddd\ud8b8\udf8b",
        0, 15930, 621940584, 6797102210147980917L, 67640L, false, true, (char) 37309, (char) 4316,
        Double.longBitsToDouble(0x3fd19ab72e4ed57aL), Double.longBitsToDouble(0x3fe77c72398634ccL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3]\0121=void |this=org.apache.commons.collections.set.ListOrderedSet:[\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3]\012",
        Z.run(T, 2, 3, 2, 6, "\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3", "\u24ff\u80c0\u4b9d\u754e", "\ud9c0\udd08\uda6e\ude3f\udb32\ude2d\udbf3\udddd\ud8b8\udf8b",
        0, 15930, 621940584, 6797102210147980917L, 76405L, false, true, (char) 37309, (char) 4316,
        Double.longBitsToDouble(0x3fd19ab72e4ed57aL), Double.longBitsToDouble(0x3fe77c723d9ec6ccL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.set.ListOrderedSet:[\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3]\0121=void |this=org.apache.commons.collections.set.ListOrderedSet:[\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3]\012",
        Z.run(T, 2, 2, 2, 8, "\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3", "\u24ff\u80c0\u4b9d\u754e", "\ud878\udd04\uda6e\ude3f\udb32\ude2d\udbf3\udddd\ud8b8\udf8b",
        0, 15930, 621940584, 6797102210147980936L, 76405L, false, true, (char) 4898, (char) 4316,
        Double.longBitsToDouble(0x3fd19ab72e4ed57aL), Double.longBitsToDouble(0x3fe77c723d9ec6ccL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.set.ListOrderedSet:[\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.set.ListOrderedSet:[\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3]\012",
        Z.run(T, 2, 3, 3, 2, "\udbc7\udca4\ud833\udd61\ud9f6\udd49\udbbd\udc1a\uda98\udfd3", "\u24ff\u80c0\u4b9d\u754e", "\ud9c1\udf06\uda6e\ude3f\udb32\ude2d\udbf3\udddd\ud8b8\udf8b",
        0, 15930, 621940584, 6797102210147980917L, 67640L, false, true, (char) 37309, (char) 4316,
        Double.longBitsToDouble(0x3fd19ab72e4ed57aL), Double.longBitsToDouble(0x3fe77c72398634ccL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.set.ListOrderedSet|retainAll|java.util.Collection|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|add|java.lang.Object|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|add|int,java.lang.Object|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|addAll|int,java.util.Collection|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|addAll|java.util.Collection|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|asList||new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|clear||new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|get|int|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|indexOf|java.lang.Object|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|iterator||new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|listOrderedSet|java.util.List|static",
    "M|org.apache.commons.collections.set.ListOrderedSet|listOrderedSet|java.util.Set|static",
    "M|org.apache.commons.collections.set.ListOrderedSet|listOrderedSet|java.util.Set,java.util.List|static",
    "M|org.apache.commons.collections.set.ListOrderedSet|remove|java.lang.Object|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|remove|int|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|removeAll|java.util.Collection|new:org.apache.commons.collections.set.ListOrderedSet:",
    "M|org.apache.commons.collections.set.ListOrderedSet|retainAll|java.util.Collection|new:org.apache.commons.collections.set.ListOrderedSet:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
