package org.apache.commons.collections.map;
import org.junit.Test;
import static org.junit.Assert.*;
public class Flat3Map_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 9, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 9, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\ud96b\uded8\udace\udce2\udb21\ude0d\ud9a3\udddd\udbf7\udc98\ud9d9\ude83", "\u2e1b\ua72e\ub9f6\ubc13\u28ec\u6ef4\uae86\u4c4d\u3e14", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae",
        20, 11849, 1235132829, 8288153887873171688L, 33994L, true, false, (char) 25344, (char) 9820,
        Double.longBitsToDouble(0x3fe3ee677157c385L), Double.longBitsToDouble(0x3fe1d911c79d6c9bL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 1, 11, 9, 4, "\ud817\udc69\ud8cd\udda8\ud86d\ude7d\uda58\udead\ud9a5\udcae\uda73\udd94\ud94f\udd8e\udbf7\udc98", "\u04bf\u14d3\ud03c\ud23f\u79c7\u0b50\ua328\u9da9\u621d\u5be7\u8a82\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u7f13", "\udbfa\udc31\udb56\udff6\ud88e\udc1f\ud88b\udf67\ud8fe\udf6a\ua591\udad1\ude5e\udbc3\ude02\ub508",
        9, 80265, 565173250, 3853803335209556505L, 40980L, false, false, (char) 17578, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fe092588a59d5baL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 8, 9, 4, "\u32ae\ud86b\udd8b\ud86d\ude95\udb0b\udc26\uda47\udd80\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua701\ub9f6\u5b06\u6b9b\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\udae8\udcff\udbc2\ude13\ud9e9\uddd8\ud914\udfe3\ub421",
        9, 96489, 1432989449, -6785966196293299870L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 0, 0, 4, "\ud9ac\udfab\ud84c\udee5\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 9, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\udb07\udd55\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u9ed5\ub0b6\u6e05\u4823\u20de\uc85e\u454b", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67",
        -4, 17419, -1143951459, -3439472484206296768L, 6884L, true, false, (char) 33013, (char) 7179,
        Double.longBitsToDouble(0x3fad071d5c48fe60L), Double.longBitsToDouble(0x3fae6ebec2fd8f80L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 10, 8, "\ud9ac\udfab\ud850\udd49\uda3a\udc3b\udac7\ude5f\uda61\uddd6\uda73\udd94\ud9c3\udd53\udbf7\udc98\ud9d9\ude83\ud971\udf13\udb38\udd5b\udb4c\udd8b\ud8b9\udf22\udb64\udea3\ud8d6\udcb7\uda6b\udf71\udb24\udeed\uda60\udfc5\udb5c\udec7\ud90a\uddd1\udad8\udfe8\uda37\udcd5\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud8f9\udcae\ud882\udfb9\ud85e\udef5\ud983\udfd7\ud8ed\udf0c\u372e\udac8\udfb4\ud9b3\ude22\udbfa\udc31\ud9fc\udc07\uda26\udc54\udb21\uddf1", "\ub6cc\u596d\ub5df\ucd81\ua087\u0bef\u3eac\ud3b1", "\u3cfe\uda9c\udeb7\udb15\udd9e\uda77\udc6a\ud87b\uddef",
        49, 9297, 869864325, -3032315545701889070L, 34L, false, false, (char) 34157, (char) 63232,
        Double.longBitsToDouble(0x3fd6600f28ce83a0L), Double.longBitsToDouble(0x3feb3f73381d6f80L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 13, 1, 2, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\uda00\udf52\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\u7b4e\ubd37", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud8eb\udfae",
        19, 11896, 1235132829, 8288153887873171688L, 1474L, true, false, (char) 17933, (char) 9948,
        Double.longBitsToDouble(0x3fe3ee6771660f85L), Double.longBitsToDouble(0x3fe1d911c59d6c9bL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 2, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\ud892\udeaa\uda47\uddc9\uda73\udd94\ud9c3\udd53\ud843\udee9\ue4cc\udad3\udd69\ud9da\uddc3\udb4c\udd8b\udbc4\udd26", "\ucc38\ua3b0\u9da9\ua7d3\u0a5c\u4a06\ua97d\ub58f\ua85a\u32da", "\ud882\udf41",
        19, 2829, 604336140, 921847527711388699L, 66397L, false, false, (char) 9948, (char) 41835,
        Double.longBitsToDouble(0x3fd660f852764470L), Double.longBitsToDouble(0x3feceb64da00bbd0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\udaa9\ude89=\ubae2}\012",
        Z.run(T, 2, 11, 14, 4, "\udaa9\ude89", "\ubae2", "\ud9c3\udd53\ud9b9\udd99\ud841\udefc",
        27, 54650, -552215231, -6633155370471692258L, 70720L, true, true, (char) 57132, (char) 31617,
        Double.longBitsToDouble(0x3fe7a6f01b43ab87L), Double.longBitsToDouble(0x3fe595e2253acc4cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 3, 9, 4, "\ud9ac\udfab\ud850\udd49\udaeb\uded4\uda58\udead\uda6e\udff2\ud94f\udc3d\uda17\udd3b\udbf7\udc98", "\u04bf\u9b93\ua6e7\ub9f6\u5b06\uccbf\u3697\u74e2\ucaa1\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f",
        9, 80265, 565173250, 3853803335203438234L, -16445L, true, true, (char) 56338, (char) 8535,
        Double.longBitsToDouble(0x3fe466c7c3262056L), Double.longBitsToDouble(0x3fec2b9e351433d9L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.HashedMap:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 6, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda4c\udc60\uda73\uddd5\ud9c3\udd53\udbf7\udc98", "\u93c3\u6a01\ua774\ub9f6\u198b\u0b7a\ua328\u9da9\ucab6\ubd9b\u8a81\u93c9\u84d8\u0824\u4b0b\u896a\u6a07\uaff2\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\udb4b\udc90\ub873\ud9ca\udf24\ud8eb\ude65\uda0c\udca1\ud92c\ude3d\udb1a\udee9\ud93a\udf10",
        3, 82505, -2122750970, 3853803335203438234L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3f95d8f859f600e0L), Double.longBitsToDouble(0x3fec2890ad1433d9L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 8, 0, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\ud931\udf94\ud9c3\udd53\udbf7\udc98", "\u3edc\ua7f0\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u9f78\u937c\u9733\u4a52\u3de1\u092d\u37a6\u3fd5\u20de\uc85e\u3713", "\udbe4\ude68\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\ud8bd\udf2d\ud801\udc57",
        9, 52777, 2092673322, 6911331866792705677L, -85106L, false, false, (char) 55784, (char) 28467,
        Double.longBitsToDouble(0x3fdc48ff2079bafaL), Double.longBitsToDouble(0x3fa7ec7c481bb280L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 15, 15, "\ud9ac\udfab\ud850\udd49\ud813\udca7\uf703\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98\ud9d9\ude83", "\ub48c\ub2ea\ub9f6\u1755\u5d1f\u79a8\u1765\u11d2\ua99b", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae",
        20, 577, 1235094669, -4823232002285895642L, 33994L, true, false, (char) 17933, (char) 9948,
        Double.longBitsToDouble(0x3fb3f33b9078fbd0L), Double.longBitsToDouble(0x3fe1d911c59d6c9bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 7, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\udad8\udca7\ud91b\udec5\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\uc37d\u757b\u9da9\ucab6\ubd9b\u8a81\u54ac\ua13e\u6243\u8f78", "\ud881\udeb2",
        19, 2829, 1929736204, 7670757062729506885L, 66397L, false, false, (char) 9948, (char) 41835,
        Double.longBitsToDouble(0x3fd660f854764470L), Double.longBitsToDouble(0x3feceb64da00bbd0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 4, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 11, 9, "\ud9ac\udfab\ud857\udf49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\u0cca\ub9ed\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u8fd7", "\udbfa\udc31\ud97a\udc06\uda26\udc54\ud88b\udf67\ud8fe\udf6a\udb27\udccf\ud931\udc66\udb81\udf2f\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 41512L, false, false, (char) 13738, (char) 33796,
        Double.longBitsToDouble(0x3fa7c63ec81bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 1, 5, 0, 4, "\ud9ac\udfab\udb5d\udc6d\uda09\udcf3\udb89\udc76\ud8c2\udd64\udb52\ude6f\ud9c3\udd53\udbf7\udc98", "\u053c\u5b93\ud4d2\u69b6\u5ae9\u0b50\ua328\u9da9\ucab6\u756e\u5384\u54ac\ub43f\u75ae\u4bbc\u896a\u92f1\u37c3\u61e8\u6924\uc85e\u4971", "\udbd3\udd9d\ud9fc\udc02\ud8ba\ude5d\udbdd\udfaa\udb7f\udda3\ud9e0\ude0d\ud922\udf98\ud9b5\udc08\ub49f\ud1ee\udad5\udf65",
        6, 21335, -1149813640, -4221665894167725347L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa6c47c1aa0b410L), Double.longBitsToDouble(0x3fefda188961f734L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 15, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude74\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98\ud9d9\ude83\ud99e\udfb0\udb38\udcfe\udb4c\udd8b\ud8b9\udf22\udb64\udea3\ud8d6\udcb7\uda6b\udf71\ud924\udeed\udbd4\udda0\u3881\udbc1\udfb0\udba6\udf3e\uda37\udc82\ud9a0\udd34", "\u896a", "\ud85e\udef5\uda97\uddf3\ud8ed\uded3",
        27, 9901, -1502999702, -7111898479218808640L, 41699L, false, true, (char) 5235, (char) 7224,
        Double.longBitsToDouble(0x3fe005de8740d044L), Double.longBitsToDouble(0x3fe66567aaaa7609L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 9, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\udaa1\udc03\uda47\udf8c\ud93c\udd78\udaf9\ude6b\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u4cda\u4afc\u896a\u57f4\u4bc2\u3ef2\u8975\ub30f\u3713", "\udbfa\udc35\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\udb77\udc17\ud922\udf22\udb81\udf2f\ub44f",
        9, 80265, -575677438, 3853739168392035994L, 78657L, false, false, (char) 47274, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e}\0121=java.lang.String:\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e}\012",
        Z.run(T, 2, 14, 9, 4, "\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e", "\ud9a0\udd34\udbcf\ude51\ud871\udf45",
        13, 50578, -512145783, -4246321644761084610L, -99768L, true, false, (char) 17849, (char) 7278,
        Double.longBitsToDouble(0x3fc813a9ad5dee14L), Double.longBitsToDouble(0x3fdd47fee2cd65acL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 12, 9, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0be1\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 46130L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 15, 6, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\ud96b\uded8\udace\udce2\udb21\ude0d\ud9a3\udddd\udbf7\udc98\ud9d9\ude83", "\u2e1b\ua72e\ub9f6\ubc13\u28ec\u6ef4\uae86\u4c4d\u3e14", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae",
        20, 11849, 1235132829, 8288153887873171688L, 33994L, true, false, (char) 25344, (char) 9820,
        Double.longBitsToDouble(0x3fe3ee677157c385L), Double.longBitsToDouble(0x3fe1d911c79d6c9bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 4, 4, "\ud9aa\udc54\udbe9\udc95\ud86d\ude8a\ud96b\uded8\udace\udce2\u806d\ud84a\udd5f\uda5f\udc2d\uda82\udf7f\uda9f\udfca\ud97f\ude96\ud8b4\udf21\uda91\udcf9", "\ua842\ua1c6\u65a8\u5968\uac67\ua90a\u3695\u959c\ua494\ub172\u3416", "\ud85e\udef5",
        29, 84308, 1782050116, 4201753195804227946L, -21835L, true, false, (char) 31175, (char) 38108,
        Double.longBitsToDouble(0x3fe1d911c79d4a9bL), Double.longBitsToDouble(0x3fd3d9db77526584L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 9, 9, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\ud96b\uded8\udaa7\udee2\ud9f1\ude77\udbf9\udce7\udbf7\udc98\ud9d9\ude83", "\u2e1b\ua72e\ub9f6\ubc13\u28ec\u6ef4\u271f\ua491\u3e14", "\ud9de\udc0a\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae\ud882\udfb9\ud85e\udef5",
        38, 17513, 1785987304, 4201753194070149994L, -21174L, true, false, (char) 59861, (char) 22599,
        Double.longBitsToDouble(0x3fa313ba79d6c9a0L), Double.longBitsToDouble(0x3fd462242ffbe6daL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.HashedMap:{} |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.HashedMap:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 6, 6, 15, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\ud96b\uded8\udace\udce2\udaed\udeb3\ud9e2\udf1c\udbbf\udef6\ud8b0\udd1b", "\ua0f6\ubc76\u1118\u787e\u1cda\uc6e1\u1a15", "\ud80c\udfe2\ud873\udcd3\ud9a0\udd34",
        34, 1651, -867432782, 3616530385889468516L, -10301L, false, false, (char) 50415, (char) 64322,
        Double.longBitsToDouble(0x3fe53881b124574bL), Double.longBitsToDouble(0x3fc53a3cee61ef84L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 9, 9, 3, "\ud9ac\udfab\udbb8\ude7d", "\u6adf\u7a90\u5e46\u14a0\u2866\u079a\u0d7f\ud157\uabab\ub9de\ubc13", "\udada\ude52\ud9a8\ude9e\ud9dd\udfe3\udad8\udfe8\ud865\uded3",
        29, 41751, -1128680637, -3725595430893021894L, -72889L, true, true, (char) 54208, (char) 29677,
        Double.longBitsToDouble(0x3fd456a742d5a8f0L), Double.longBitsToDouble(0x3fe3712d10d7aa29L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 3, 9, 4, "\udbd4\udc1c\udb8e\udc38\ud86d\ude9a\ud96b\uded8", "\u178c\u13ad\u031d\u21ee\u0abe\u2e1b\ua72e\ub9f6\ubc13\u28ec\u6ef4\u1c77\u4aca\ucdf3\u3a23\u05d1\ua125\u53e7\u4afc\u64f9\u3ec5", "\ud958\udc94\udafa\udf3f\u36a6\udac8\udfb4\ud8ee\ude7e\u137c\udbf7\udc03\uda26\udc54\uda54\udeec\udbfe\udf5b\uda0c\udca1\ud83b\udd31\u8122\udb8f\udcc0\udacd\udfc7\ud80a\udc9f",
        19, 57038, -1088169677, -6082193424129380379L, 91905L, false, true, (char) 47416, (char) 34192,
        Double.longBitsToDouble(0x3fe851122e19d36dL), Double.longBitsToDouble(0x3fd901002d4de474L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.AbstractHashedMap$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 7, 4, "\u32ae\ud86b\udd8b\udb81\udf3e\udb0b\udc53\uda47\udd80\uda73\udd94\ud9c3\udd53\ud976\ude02", "\u1a1c\ud734\ua701\ub9f6\u5b06\u6b9b\u1c33\u4a32\u24d0\ua15f\u8a81\u54ac\u7548\u53e7\u4afc\u896a\u6a07\u7dd2\u5e4f\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\udae8\udcff\udbc2\ude13\uda2d\udf9c\uda64\udeb7\ub421",
        9, 96489, 1432989449, -6785966196293299870L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 15, 1, 4, "\u32ae\ud86b\udd8b\udac4\udcc0\udb0a\udfb8\uda47\udd80\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u39b2\u95f7\ua701\ub9f6\u5b06\u6b9b\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u4718\u3781\u8687\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\u8493\ud8d7\udd72\uda3a\udee4\udb49\udd80\ud991\ude15\u8c41",
        9, 96489, 1432989449, -6785966196293299870L, -55223L, true, false, (char) 13679, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c4c05c280L), Double.longBitsToDouble(0x3fefb373051433d9L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 9, 4, "\u32ae\ud86b\udd8b\ud86d\ude95\udb0b\udc26\uda47\udd80\uda73\udd94\ud993\uddcd\udbf7\udc98", "\u4d56\u12ef\ua2a7\u06fc\u736c\uac0d\u65c1\u9da7\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u8f22\ud134\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\ud9bc\udd32\udbd6\udd44\ud908\udd20\ud88b\udf67\udae8\udcff\udbc2\ude13\ud9e9\uddd8\ud99d\udd40\ub421",
        9, 96489, 1432989449, -7434484542634651294L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec43c81bb280L), Double.longBitsToDouble(0x3fec28908cb465d9L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\u0d7a\ud86b\udd17\ud86d\ude95\udb0b\udc26\uda47\udd80\uda73\udd94\uda4c\udfd8\ud88b\udd00\ud93e\udd89\ue8d2\udbc8\udd44=\ua3c9\u30d3\u6bd7\u4c1f}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{\u0d7a\ud86b\udd17\ud86d\ude95\udb0b\udc26\uda47\udd80\uda73\udd94\uda4c\udfd8\ud88b\udd00\ud93e\udd89\ue8d2\udbc8\udd44=\ua3c9\u30d3\u6bd7\u4c1f}\012",
        Z.run(T, 2, 14, 3, 15, "\u0d7a\ud86b\udd17\ud86d\ude95\udb0b\udc26\uda47\udd80\uda73\udd94\uda4c\udfd8\ud88b\udd00\ud93e\udd89\ue8d2\udbc8\udd44", "\ua3c9\u30d3\u6bd7\u4c1f", "\ud90a\uddd1\udad8\udfe8",
        46, 83462, 202345884, -4880578996686027086L, 61655L, true, false, (char) 27732, (char) 47530,
        Double.longBitsToDouble(0x3fb35cc1422b53a0L), Double.longBitsToDouble(0x3feb51d27e03a66aL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 8, 8, 13, "\u32ae\uda03\udd97\ud86d\ude95\udb0b\udc26\uda47\udd80\uda73\udd94\ud9c3\udd53\udbf7\udc98\ud9d9\ude83\uda3a\uddbe\udb38\uddcb\udb4c\udd8b\ud8b9\udeaf\udb64\udea3\ud8d6\udcb7", "\u9da9\ucab6\ubd9b", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae",
        -4, 77079, 1235132829, 8288153887873171688L, 33994L, true, false, (char) 17933, (char) 9948,
        Double.longBitsToDouble(0x3fe3ee6771660f85L), Double.longBitsToDouble(0x3fa0fc9c67e21120L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 0, 4, "\ud9ac\udfab\ud84c\udee5\ud87e\udf95\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u4c27\u9fc9\u6b1f\u5bcf\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\uab81\u53f1\u4afc\u9caa\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\ud8c5\udf39\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 78657L, false, false, (char) 14052, (char) 36862,
        Double.longBitsToDouble(0x3fa7ec7c681bb280L), Double.longBitsToDouble(0x3fc560987450cf64L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 15, 14, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\udb50\udea9\uda47\udd1e\uda73\udd94\udb07\udd55\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\u1856\u9dbb\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u9ed5\ub0b6\u6e05\u4823\u20de\uc85e\u454b", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f\udaa2\udc25\uda1c\udd67\ud8b1\uddfe\udb6c\udcdd\ud959\udf5e\ud841\ude10\udacf\udc5d\u3cfe",
        32, 82242, -578968124, -2812409749549593553L, 90423L, true, false, (char) 34107, (char) 16009,
        Double.longBitsToDouble(0x3fde9303b9ae6914L), Double.longBitsToDouble(0x3fef7e95574f92c0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 10, 8, "\ud9ac\udfab\ud850\udd49\uda3a\udc3b\udac7\ude5f\uda61\uddd6\uda73\udd94\udb5f\uddc0", "\u127c\u051c\uc2af\ua774\u6bb2", "\udb24\udeed\uda60\udfc5\udb5c\udec7\ud90a\uddd1\udad8\udfe8\uda37\udcd5\ud9a0\udd34\udbcf\ude51",
        41, 70770, -724746438, -5883521317084883431L, -5723L, false, false, (char) 2745, (char) 17849,
        Double.longBitsToDouble(0x3fe01d3350c09d4dL), Double.longBitsToDouble(0x3feabbdc2e7dcceeL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud9ac\udf90\udbdc\udccf\ud9de\udcb1\udac7\ude5f\uda4e\udd8c\uda73\ude7a\ud9c3\udd53\ud8b0\udf94\ud9da\udcb6\ud971\udefb\udb38\udd5b\udb4c\udd8b\ud9e1\udc15=null}\0121=java.lang.Integer:1792267351 |this=org.apache.commons.collections.map.Flat3Map:{\ud9ac\udf90\udbdc\udccf\ud9de\udcb1\udac7\ude5f\uda4e\udd8c\uda73\ude7a\ud9c3\udd53\ud8b0\udf94\ud9da\udcb6\ud971\udefb\udb38\udd5b\udb4c\udd8b\ud9e1\udc15=null}\012",
        Z.run(T, 2, 14, 10, 8, "\ud9ac\udf90\udbdc\udccf\ud9de\udcb1\udac7\ude5f\uda4e\udd8c\uda73\ude7a\ud9c3\udd53\ud8b0\udf94\ud9da\udcb6\ud971\udefb\udb38\udd5b\udb4c\udd8b\ud9e1\udc15", "\u2b2f\ua305\u5853\u56b3\u59c4\u8a34\ub723", "\udb2f\udc1b",
        13, 28562, -1369864055, 5719173612291164984L, -99768L, false, false, (char) 1153, (char) 48570,
        Double.longBitsToDouble(0x3fe572a09e84ff5eL), Double.longBitsToDouble(0x3fe38b01b9667e85L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 10, 8, "\ud9ac\udfab\ud850\udd49\uda3a\udc3b\udac7\ude5f\uda61\uddd6\uda73\udd94\ud9c3\udd53\udaf3\udfd6\ud9d9\ude59\ud971\udf13\udb38\udd5b\udb4c\udd8b\ud8ce\udd7c\udb7f\udcb7\ud8d6\udcb7\uda6b\udf71\udb24\udeed\uda60\udfc5\ud85b\udf68\udb3a\udc2d\udad8\udfe8\uda37\udcd5\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud8f9\udcae\ud882\udfb9\ud85e\udef5\ud983\udfd7\ud8ed\udf0c\u372e\udac8\udfb4\ud9b3\ude22\udbfa\udc31\ud9fc\udc07\uda26\udc54\udb21\uddf1", "\u8206\u0b8f\u8708\ucd81\ua087\u0bef\u3eac\ud3b1", "\u3cfe\uda9c\udeb7\udb15\udd9e\uda77\udc6a\ud87b\uddef",
        49, 9297, 869864325, -3032315545701889070L, 34L, false, false, (char) 34157, (char) 23042,
        Double.longBitsToDouble(0x3fe76be44cc706b8L), Double.longBitsToDouble(0x3fdada6f303ae39aL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 1, 1, 2, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\ud8c3\udeb2\udb41\udcf1", "\u04bf\uc2af\u6474\ub9f6\u93a1\u0b50\ua328\u9da9\u7b4e\u289b", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\uda03\udc31\udb31\udcf8\ud851\ude6f\ud85e\udf24\uda97\uddf3\ud8ed\uded3\u372e\udb71\ude88\ud81f\udf20\udbfa\udc31\ud8a1\udebf\udb58\udebf\ud88b\udf67\ud8fe\udf6a\uda0c\udca1",
        51, 78088, -1388453844, -8269045728415116325L, 17986L, true, false, (char) 11437, (char) 21234,
        Double.longBitsToDouble(0x3fb0a97c1b5cad60L), Double.longBitsToDouble(0x3fcc0877da0b1e14L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 1, 2, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\uda00\udf52\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u32a2\u0d74\u9da9\u7b4e\ubd37", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud8eb\udfae",
        19, 11896, 1235132829, 8288153887873171688L, 1474L, true, false, (char) 17933, (char) 9948,
        Double.longBitsToDouble(0x3fe3ee6771660f85L), Double.longBitsToDouble(0x3fe1d911c59d6c9bL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 13, 13, 2, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\ud980\uded3\udbb6\udca1\ue38e\udacf\udd96", "\u04bf\u1515\u6fba\uc86a\u5b06\u0bcc\u686f\u8b96", "\udad8\udfe8\uda37\udcd5\udaa3\ude17\udbeb\udc50\ud871\udf45\udbe8\udfa5\ud8eb\udfae\ud851\uddaf\ud85e\udf24\uda97\uddf3\ud8ed\uded3\u372e",
        14, 78234, -1655867901, 8900705780298064727L, -88417L, true, true, (char) 51836, (char) 39328,
        Double.longBitsToDouble(0x3fefe50662408d53L), Double.longBitsToDouble(0x3fcafbd3875d13a8L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud9ac\udf35\ud861\udc49\ud86d\ude95\ud892\udeaa\uda50\udec9\udbb7\udfc0\ud9cc\ude66\udba8\udf7e\udb2e\udcce\udad3\udd69\ud9da\uddc3=\u0f54\u9f43\u6e81\u0f64}\0121=java.lang.Integer:-1491660688 |this=org.apache.commons.collections.map.Flat3Map:{\ud9ac\udf35\ud861\udc49\ud86d\ude95\ud892\udeaa\uda50\udec9\udbb7\udfc0\ud9cc\ude66\udba8\udf7e\udb2e\udcce\udad3\udd69\ud9da\uddc3=\u0f54\u9f43\u6e81\u0f64}\012",
        Z.run(T, 2, 14, 10, 2, "\ud9ac\udf35\ud861\udc49\ud86d\ude95\ud892\udeaa\uda50\udec9\udbb7\udfc0\ud9cc\ude66\udba8\udf7e\udb2e\udcce\udad3\udd69\ud9da\uddc3", "\u0f54\u9f43\u6e81\u0f64", "\u9b7a\uda8b\udd0b\ud900\udd34\udb6a\udca6\udbae\udec5\udb2c\udf2c\udbe8\udf6a\ud95f\udf09\ud882\udf41\ud85e\udef5",
        46, 52140, 214634353, 4201634266425723754L, 53408L, true, true, (char) 41835, (char) 57578,
        Double.longBitsToDouble(0x3fd3b2238f3ad936L), Double.longBitsToDouble(0x3fcfdb1a12b540f4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 2, 2, 12, "\ud9ac\udfab\ud850\udd49\uda5e\udc6c\u8d34\ud8d2\uddb6\uda73\udd94\ud9c3\udd53\ud8b8\ude63\udb03\udfe5\udb11\udd00\udaf3\udfc8\udb4c\udd8b\u8921", "\ucc11\ua3b0\u4af2\u7001\u0a5c\u4a06\ua97d\u4753", "\ud885\udd8b",
        39, 98825, -893938151, -4213221231927040761L, -7857L, false, false, (char) 9864, (char) 17933,
        Double.longBitsToDouble(0x3feabbdc2c39cceeL), Double.longBitsToDouble(0x3fa6a83313b22340L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 2, 4, "\ud882\ude2d", "\u982e\u14da\u8049\u4c48", "\ud930\udf38\ud9ed\uddf3\uda60\udd95\udbc4\udd26\ud947\udefe\udaa3\ude68\udb47\udf31\ud931\udf3b\uda60\udfc5\ub79c\ud801\ude7a\uda96\uddb7\udb21\udc44\uda6e\udf5a\udbe2\udc83\udb2c\udf2c\u90f0\udbda\uddcd\ud882\udf66\ud85e\udef5\uda97\uddf3\ud99c\ude2b\u1832\udb6b\udf89\ud9b3\ude22\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud992\ude4a\ud82b\udde9\uda4c\udf9e\ud922\udf98\ud911\ude17\udaad\udca4\ud935\udd7e\ud9ce\udfe0\ud83e\ude57",
        46, 17101, 1953427803, 874528033700661157L, -81371L, false, true, (char) 24737, (char) 55193,
        Double.longBitsToDouble(0x3fe679beb5f22d3cL), Double.longBitsToDouble(0x3fe915d4ea49423fL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\udaa9\ude89=\u39d5}\012",
        Z.run(T, 2, 5, 14, 4, "\udaa9\ude89", "\u39d5", "\ud9c9\udc53\u4abd\ud841\udefc",
        27, 44106, -552224702, -6633155370471692258L, -77766L, true, true, (char) 10118, (char) 31705,
        Double.longBitsToDouble(0x3fe7a6f01b43ab87L), Double.longBitsToDouble(0x3fc6578894eaf458L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\udaa9\ude89=\ubae2}\0121=java.lang.String:\ubae2 |this=org.apache.commons.collections.map.Flat3Map:{\udaa9\ude89=\ubae2}\012",
        Z.run(T, 2, 14, 14, 5, "\udaa9\ude89", "\ubae2", "\ud9c3\udd53\ud9b9\udd99\ud841\udefc",
        27, 54650, -552215231, -6633155370471692258L, 70720L, true, true, (char) 57132, (char) 31617,
        Double.longBitsToDouble(0x3fe7a6f01b43ab87L), Double.longBitsToDouble(0x3fe595e2253acc4cL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 11, 11, "\udaa9\ude89", "\ubb9c", "\ud92b\udeae\ud9b9\udd99\udbe6\uddf7",
        25, 14376, -250019095, 5774372670788281882L, -20602L, false, false, (char) 53172, (char) 232,
        Double.longBitsToDouble(0x3fd289234a7a1168L), Double.longBitsToDouble(0x3fddce9725d0f136L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\ud9ac\udfab\ud850\udd49\ud804\udca7\uf703\uda47\udd1e\ud97b\udf58\ud87c\udc34\ud8e3\ude10\ud9d9\ude83=\u732c\uad80\ub9da\u6bef\ua9a0\u658a\u6055\u8efc\ua99b}\012",
        Z.run(T, 2, 5, 14, 6, "\ud9ac\udfab\ud850\udd49\ud804\udca7\uf703\uda47\udd1e\ud97b\udf58\ud87c\udc34\ud8e3\ude10\ud9d9\ude83", "\u732c\uad80\ub9da\u6bef\ua9a0\u658a\u6055\u8efc\ua99b", "\ud9a0\udd34\ud9e2\ude9b",
        34, 32920, 1925497764, 2694940358944006003L, -71316L, false, false, (char) 60581, (char) 17849,
        Double.longBitsToDouble(0x3fe01d335529d7d0L), Double.longBitsToDouble(0x3fe4b3df3e9cb41bL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 15, 15, 15, "\ud937\udd95\ud850\udd49\udb84\udfbf\udbfd\udcc7\ud907\udc6a\ud8b7\ude6b\ud9c3\udcea\udbf7\udc98\ud9d9\ude83", "\ub48c\ub2ea\ub9f6\u1755\u5d1f\u79a8\u1765\u11d2\u47ae", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae\udb40\udeef\uda73\udf59",
        24, 21788, 1785997606, 4201753194070149994L, 53408L, true, true, (char) 20797, (char) 51746,
        Double.longBitsToDouble(0x3fe1d911c59d6c9bL), Double.longBitsToDouble(0x3fd2300b30d3d41aL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\uda99\udd02\ud86f\ude24\ud813\udca7\uf703\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98\ud9d9\ude83=null}\0121=org.apache.commons.collections.map.Flat3Map$EntrySet:[\uda99\udd02\ud86f\ude24\ud813\udca7\uf703\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98\ud9d9\ude83=null] |this=org.apache.commons.collections.map.Flat3Map:{\uda99\udd02\ud86f\ude24\ud813\udca7\uf703\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98\ud9d9\ude83=null}\012",
        Z.run(T, 2, 14, 7, 15, "\uda99\udd02\ud86f\ude24\ud813\udca7\uf703\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98\ud9d9\ude83", "\ub48c\ub2ea\ub9f6\uc655\u5d1f\u79a8\u089a\u11d2\u0fe8", "\ud9a0\udd10\ud836\udea1\ud8fd\udfd6\udbe8\udf8c",
        32, 98945, -759720423, 5304691209695948812L, 66397L, false, false, (char) 9948, (char) 20797,
        Double.longBitsToDouble(0x3fe078fbd23b2238L), Double.longBitsToDouble(0x3fdc0d27ca6cc1c8L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 12, 7, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda59\udfad\uda47\udd1e\udad8\udca7\ud91b\udec5\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\uc37d\u757b\u9da9\ucab6\ubd9b\u8a81\u54ac\ua13e\u692d\u8ed2", "\ud881\udeb2\ud921\udd55\udb0f\udcf6\ud904\udc6a\u372e\udac8\udfb4\ud9b3\ude22\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\ud833\udd87\udafb\udf4a\udbf7\udc27",
        57, 55645, 1744595674, -3338920296970011730L, 8837L, false, true, (char) 32750, (char) 36155,
        Double.longBitsToDouble(0x3fee18aa94f2878aL), Double.longBitsToDouble(0x3fef6deee3b858e5L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 4, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\ubb7c\u7e71\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 78657L, false, false, (char) 13738, (char) 35839,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d040f4bL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 4, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\udbf3\udcb4\udba9\udf6f\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de", "\udac8\udfb4\ud9b3\ude22\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f\udaa2\udc25\uda1c\udd67\ud8b1\uddfe",
        41, 18978, -982933116, -7944285020172390603L, 44442L, false, true, (char) 11706, (char) 9512,
        Double.longBitsToDouble(0x3fc037650e144844L), Double.longBitsToDouble(0x3fd1433d90fe3492L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 3, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\udaa1\udc03\uda47\udf8c", "\u90c2\ua1ed\u8b97\u80ee\uc2af", "\ud8d6\udcb7\uda6b\udf71",
        43, 7611, 2024899499, 2368861519218273351L, 97350L, true, true, (char) 52906, (char) 49910,
        Double.longBitsToDouble(0x3fd3acc4c8b17d9aL), Double.longBitsToDouble(0x3fe0cd74119dcab7L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 4, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\u2b19\uda47\udf8c\ud852\ude23\udaf9\ude6b\udbf7\udc98", "\ub534\ud3a3\ua774\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u4cda\u4afc\u896a\u57f4\u4bc2\u3ef2\u8975\ub30f\u3713", "\udbfa\udc35\ud9fc\udc07\uda1e\udc15\ud88b\udf67\ud93e\udf9e\uec85\udbb4\udf60\ud831\uddc5\ub44f",
        9, 80265, -575677438, 3853739168392035994L, 78657L, false, false, (char) 47274, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481b9930L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 8, 9, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\udaa0\udf61\uda47\udf8c\ud93c\udd78\ud9a5\ude60\ud9fa\udcf3", "\u0556\u2cf5\u01c1\ub9f6\u7674\u3e04\ub4db\u2902\u82ce\u05cb\u61cb\u9034\u153f\u15d0\uc9d3\u896a", "\udb30\udd5e\ud88e\udc4e\udb1f\udda0\ud82a\udf50\ud989\udc46\uda3b\udee6\ud863\ude81\ud893\udc5b\udb4e\uddbe\ud88b\udf67\ud915\udebf\ud80c\uddad",
        6, 13408, -1406713536, -3239853073619173231L, -49659L, false, false, (char) 44679, (char) 2827,
        Double.longBitsToDouble(0x3fcdec2bc78588a8L), Double.longBitsToDouble(0x3fad071d615cb660L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=null}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=null}\012",
        Z.run(T, 2, 14, 9, 4, "\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e", "\ud9a0\udd34\udbcf\ude51\ud871\udf45",
        13, 37202, 0, 1240894720L, -100000L, true, false, (char) 17849, (char) 7278,
        Double.longBitsToDouble(0x3fc813a9ad5dee14L), Double.longBitsToDouble(0x3fdd47fee2cd65acL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud9f3\udf01\ud85a\udc5c\ud99e\udf8e\ud87f\udf8e\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbe2\udc98\udbc6\ude39\ud9db\udffc\ud8a7\udf77\ud83f\udfd8\ud8b9\udf22\udb64\udea3\ud8d6\udcb7\uda6b\udf71\udae3\udecd\uda5d\udda0\udb5c\udec7\ud809\udd50\ud9fd\udee9\udbcc\udc15\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae=\u4ce7\uc85e\ud0f8\u4561\u713c}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{\ud9f3\udf01\ud85a\udc5c\ud99e\udf8e\ud87f\udf8e\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbe2\udc98\udbc6\ude39\ud9db\udffc\ud8a7\udf77\ud83f\udfd8\ud8b9\udf22\udb64\udea3\ud8d6\udcb7\uda6b\udf71\udae3\udecd\uda5d\udda0\udb5c\udec7\ud809\udd50\ud9fd\udee9\udbcc\udc15\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae=\u4ce7\uc85e\ud0f8\u4561\u713c}\012",
        Z.run(T, 2, 14, 4, 8, "\ud9f3\udf01\ud85a\udc5c\ud99e\udf8e\ud87f\udf8e\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbe2\udc98\udbc6\ude39\ud9db\udffc\ud8a7\udf77\ud83f\udfd8\ud8b9\udf22\udb64\udea3\ud8d6\udcb7\uda6b\udf71\udae3\udecd\uda5d\udda0\udb5c\udec7\ud809\udd50\ud9fd\udee9\udbcc\udc15\ud9a0\udd34\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae", "\u4ce7\uc85e\ud0f8\u4561\u713c", "\ud802\udee1\udb78\udd47\udb5a\udccb\ud9a3\udefb",
        13, 50002, 185184814, 8964545444469410234L, 81506L, true, false, (char) 12458, (char) 12916,
        Double.longBitsToDouble(0x3fe1d49ad74bd853L), Double.longBitsToDouble(0x3fe8a88cf9177758L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\udbfc\uddde\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u559e}\0121=java.lang.String:\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u559e |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 14, 0, 4, "\uda13\udcdb\ud85a\udc5c\udbfc\uddde\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u559e", "\ud9a0\udd34\udbcf\ude51\ud871\udf45",
        13, 50578, -512145783, -4246321644761084610L, -99768L, true, false, (char) 17849, (char) 7278,
        Double.longBitsToDouble(0x3fc813a9ad5dee14L), Double.longBitsToDouble(0x3fdd47fee2cd65acL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\ubfb4\u25f3\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e}\0121=org.apache.commons.collections.map.Flat3Map$FlatMapIterator:Iterator[] |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\ubfb4\u25f3\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e}\012",
        Z.run(T, 2, 14, 13, 4, "\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\ubfb4\u25f3\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e", "\ud9a0\udd34\udbcf\ude51\ud871\udf45",
        13, 50578, -512145783, -4246321644761084610L, -99768L, true, false, (char) 17849, (char) 7278,
        Double.longBitsToDouble(0x3fc813a9ad5dee14L), Double.longBitsToDouble(0x3fdd47fee2cd65acL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e}\012",
        Z.run(T, 2, 14, 5, 14, "\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e", "\udbda\udca8\ufe1e\ud871\udf45",
        13, 50578, -512145783, -4246321644761084610L, -75063L, true, false, (char) 17849, (char) 15981,
        Double.longBitsToDouble(0x3fc3d3652e1e0720L), Double.longBitsToDouble(0x3fdd47fee2cd98a8L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\u04bf\uc2af\ua774\ub9f6\ub00f\u8b45\ub831\u8f69\ucab6\u567e}\0121=org.apache.commons.collections.map.Flat3Map$KeySet:[\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98] |this=org.apache.commons.collections.map.Flat3Map:{\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98=\u04bf\uc2af\ua774\ub9f6\ub00f\u8b45\ub831\u8f69\ucab6\u567e}\012",
        Z.run(T, 2, 14, 12, 4, "\uda13\udcdb\ud85a\udc5c\ud99e\udf8e\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\uc2af\ua774\ub9f6\ub00f\u8b45\ub831\u8f69\ucab6\u567e", "\ud9a0\udd34\udbcf\ude51\ud871\udf45",
        47, 13175, -512145783, -4246321644761084610L, -99768L, true, false, (char) 12503, (char) 35618,
        Double.longBitsToDouble(0x3fc813a9ad5dee14L), Double.longBitsToDouble(0x3fdd47fee2cd65acL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 13, 14, "\uda1d\ude74\ud85a\udc5c\ud900\udf1e\ud967\udf9c\ud854\udf53\uda73\udd94\ud96e\udfe9\udb76\udc11", "\u04bf\uc2af\ua774\ub9f6\u5b06\u0b50\ub831\u8f69\ucab6\u567e", "\ud9a0\udd34\udbcf\ude51\ud871\udf45",
        13, 50578, -1306507639, -4246243699694596802L, -99768L, true, false, (char) 17849, (char) 7278,
        Double.longBitsToDouble(0x3fc813a9ad5dee14L), Double.longBitsToDouble(0x3fdd47fee2cd65acL)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 12, 12, 4, "\ud9ac\udfab\ud850\udd49\ud897\udf4a\uda58\udeb6\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04b0\uc2af\ua774", "\uda6c\udc02\udb24\udeed\uda60\udfc5\udb5c\udec7\ud90a\uddd1\udad8\udfe8\ud9f6\udcb5\ud9a0\udc7c\udbcf\ude51\ud871\udf45\udbe8\udfa5\ud90e\udeae\ud882\udfb9\ud860\udef5",
        25, 28763, 1783648040, 4201753194070149994L, 53408L, true, true, (char) 41835, (char) 57578,
        Double.longBitsToDouble(0x3fe1d911c79d6c9bL), Double.longBitsToDouble(0x3fe005de8140d044L)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 3, 3, 4, "\udbd4\udc1c\udb8e\udc38\ud86d\ude9a\ud96b\uded8", "\u178c\u13ad\u031d\u21ee\u0abe\u2e1b\ua72e\ub9f6\ubc13\u28ec\u6ef4\u1c77\u6ecb\ucdf3\u3a23\ud18e\ua125\u53e7\u4afc\u4cea\u3ec5", "\ud958\udc94\udafa\udf3f\u36a6\udac8\udfb4\ud8ee\ude7e\ueea2\udbf6\udf73\uda26\udc54\uda54\udeec\udbfe\udf5b\uda0c\udca1\ud83b\udd31\u8122\udb8f\udcc0\udacd\udfc7\ud80a\udc9f",
        19, 57038, -1088169677, -6082193424129380379L, 91905L, false, true, (char) 47416, (char) 34192,
        Double.longBitsToDouble(0x3fe851122e19d36dL), Double.longBitsToDouble(0x3fd901002d4de474L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.AbstractHashedMap$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 12, 11, "\ud8a7\udebb\ud86b\uddbb\udb81\udf3e\udb0b\udc53\uda47\udd80\uda73\udd94\udaa3\udd74\ud976\udd1c\udb1c\udc0a\ud9c2\udf76\uda9e\udea8\ud9d9\udcbf\ud8b9\udea9\udb64\udea3", "\u1c33", "\ud885\udd9e\udaf1\udde8",
        46, 16614, 202345884, 9189046562868430514L, -314L, false, true, (char) 32845, (char) 56118,
        Double.longBitsToDouble(0x3fcd0e60a115a9d0L), Double.longBitsToDouble(0x3fe8fefdfe03a66aL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\u0d7a\ud86b\udd17\ud86d\ude95\uda58\udc36\ud96a\ude1d\uda73\udd94\uda4c\udfd8\udb75\udc21\udb25\udd3f\ud8e9\udd49\ud948\uddf9\ud8e6\udfde\ud8b9\udf75\udb8d\udeb6\ucd98\ud8bb\udd51\udb65\udfbb\uda6d\udc93\ud9a1\udf03\ud900\uddc5=\u6f5c\ub11c\u40c0\u8999\u0b19}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\u0d7a\ud86b\udd17\ud86d\ude95\uda58\udc36\ud96a\ude1d\uda73\udd94\uda4c\udfd8\udb75\udc21\udb25\udd3f\ud8e9\udd49\ud948\uddf9\ud8e6\udfde\ud8b9\udf75\udb8d\udeb6\ucd98\ud8bb\udd51\udb65\udfbb\uda6d\udc93\ud9a1\udf03\ud900\uddc5=\u6f5c\ub11c\u40c0\u8999\u0b19}\012",
        Z.run(T, 2, 14, 5, 12, "\u0d7a\ud86b\udd17\ud86d\ude95\uda58\udc36\ud96a\ude1d\uda73\udd94\uda4c\udfd8\udb75\udc21\udb25\udd3f\ud8e9\udd49\ud948\uddf9\ud8e6\udfde\ud8b9\udf75\udb8d\udeb6\ucd98\ud8bb\udd51\udb65\udfbb\uda6d\udc93\ud9a1\udf03\ud900\uddc5", "\u6f5c\ub11c\u40c0\u8999\u0b19", "\uda97\uddf3\ud9fa\udd48\ud847\udff9\ud9a5\udf99\ud84b\ude24\udb95\udcbe\udabe\udf34\ud801\ude67\ud90d\udc10",
        6, 24154, 1836360584, -7082103724731471599L, 16244L, false, true, (char) 14365, (char) 59577,
        Double.longBitsToDouble(0x3fe714b630ee7c18L), Double.longBitsToDouble(0x3fe7f9086bf48df0L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\udbb2\udd89\ud86b\udd17\ud86d\ude7b\udb0b\udc26\uda47\udd80\uda73\udd94\uda4c\udfd8\ud88b\udd00\ud93e\udd89\ue8d2\udbc8\udd44\udb4c\uddb0\ud8b9\udeaf\uceaa\ud86a\udd12\ud8b2\udf51\udada\udcd3=null}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\udbb2\udd89\ud86b\udd17\ud86d\ude7b\udb0b\udc26\uda47\udd80\uda73\udd94\uda4c\udfd8\ud88b\udd00\ud93e\udd89\ue8d2\udbc8\udd44\udb4c\uddb0\ud8b9\udeaf\uceaa\ud86a\udd12\ud8b2\udf51\udada\udcd3=null}\012",
        Z.run(T, 2, 14, 5, 10, "\udbb2\udd89\ud86b\udd17\ud86d\ude7b\udb0b\udc26\uda47\udd80\uda73\udd94\uda4c\udfd8\ud88b\udd00\ud93e\udd89\ue8d2\udbc8\udd44\udb4c\uddb0\ud8b9\udeaf\uceaa\ud86a\udd12\ud8b2\udf51\udada\udcd3", "\ubd9b\u8a81", "\u6b18\uda28\udf3e",
        20, 317, -1369864055, 6766823475477651770L, -99923L, true, false, (char) 17849, (char) 7278,
        Double.longBitsToDouble(0x3fc6e6e235cf78c8L), Double.longBitsToDouble(0x3fefc559346c8bacL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 3, 3, 15, "\uda5b\udc17\uda80\udf90\ud978\ude69\ud80c\uddc2\uda47\udcf6\uda73\udd94\uda7f\udeb2\ud871\ude34\ud809\udc99\ue8d2\udbc8\udd44", "\ub699\u247a\u19d8\u4c1f", "\ud90a\uddd1\udad9\udc7c",
        1, 60871, 1271106972, -3981266445283816819L, 61624L, true, false, (char) 21142, (char) 29123,
        Double.longBitsToDouble(0x3fd6f74bdc3e7954L), Double.longBitsToDouble(0x3feb50732603a66aL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 5, 4, "\uda6e\uddb3\ud84c\udee5\ud87e\udf95\uda58\udead\uda47\udd1e\udb88\udeb9\ud9c3\udd53\udbf7\udc98", "\u4c27\u9fc9\u6b1f\u5bcf\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\uab81\u53f1\u4afc\u9caa\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\ud8c5\udf39\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 78657L, false, false, (char) 14052, (char) 36862,
        Double.longBitsToDouble(0x3fa7ec7c681bb280L), Double.longBitsToDouble(0x3fc560986280cf64L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud99a\uddf8\ud861\udc49\ud86d\ude95\ud892\udeaa\uda50\udec9\udbb7\udfc0\ud9cc\ude66\udba8\udf7e\udb2e\udcce\udad3\udd69\ud9da\uddc3\udb4c\udd8b\udbc4\udd26=null}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\ud99a\uddf8\ud861\udc49\ud86d\ude95\ud892\udeaa\uda50\udec9\udbb7\udfc0\ud9cc\ude66\udba8\udf7e\udb2e\udcce\udad3\udd69\ud9da\uddc3\udb4c\udd8b\udbc4\udd26=null}\012",
        Z.run(T, 2, 14, 0, 4, "\ud99a\uddf8\ud861\udc49\ud86d\ude95\ud892\udeaa\uda50\udec9\udbb7\udfc0\ud9cc\ude66\udba8\udf7e\udb2e\udcce\udad3\udd69\ud9da\uddc3\udb4c\udd8b\udbc4\udd26", "\u325c\uaee0\u9da9\ua7d3\u0a5c\u5f27\ua97d", "\udbf9\udf31\uda16\ude07",
        28, 98825, -893937940, 5296710590956662796L, 66277L, false, false, (char) 4316, (char) 25956,
        Double.longBitsToDouble(0x3fd660f852764470L), Double.longBitsToDouble(0x3fe4eb64dcfed8d0L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\ud882\ude2d=\u982e\u14da\u8049\u4c48}\012",
        Z.run(T, 2, 5, 14, 13, "\ud882\ude2d", "\u982e\u14da\u8049\u4c48", "\ud930\udf38\ud9ed\uddf3\uda60\udd95\udbc4\udd26\ud947\udefe\udaa3\ude68\udb47\udf31\ud931\udf3b\uda60\udfc5\ub79c\ud801\ude7a\uda96\uddb7\udb21\udc44\uda6e\udf5a\udbe2\udc83\udb2c\udf2c\u90f0\udbda\uddcd\ud882\udf66\ud85e\udef5\uda97\uddf3\ud99c\ude2b\u1832\udb6b\udf89\ud9b3\ude22\udbfa\udc31\ud9fc\udc07\uda26\udc54\ud992\ude4a\ud82b\uddde\ud96c\udf4f\ud922\udf53\ud911\ude17\udaad\udca4\ud935\udd7e\ud9ce\udfe0\ud83e\ude57",
        46, 17101, 1953427803, 874528033700661157L, -81371L, false, true, (char) 24737, (char) 55193,
        Double.longBitsToDouble(0x3fe679beb5f22d3cL), Double.longBitsToDouble(0x3fe915d4ea49423fL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\udbac\udf4b=\u7290}\012",
        Z.run(T, 2, 5, 14, 4, "\udbac\udf4b", "\u7290", "\ud9c9\udc53\uda67\ude86\ud874\udd45",
        27, 44106, -552224702, -6633155370471699309L, -77971L, true, true, (char) 10118, (char) 31705,
        Double.longBitsToDouble(0x3fe38d381b43ab87L), Double.longBitsToDouble(0x3fc6578894eaf458L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\000=\u404b}\012",
        Z.run(T, 2, 5, 14, 4, "\000", "\u404b", "\ud906\udc02\u4a9c\u2220",
        39, 66594, -552271872, -6701272314835671010L, -40608L, false, false, (char) 13261, (char) 51232,
        Double.longBitsToDouble(0x3fd4ef23700001e6L), Double.longBitsToDouble(0x3fe000000343ab87L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\udac2\udd65\uda99\udc4e\ud8b9\udc9f=\ub98e\uae02\u81f0\ua2f8\ud058\u038f\u193f\ua73b\ub9f6\ubad3\u4faa\u2d5c\u9d86\u15b9\u0185\u34a6\u8b4c\uc9a4}\012",
        Z.run(T, 2, 5, 14, 4, "\udac2\udd65\uda99\udc4e\ud8b9\udc9f", "\ub98e\uae02\u81f0\ua2f8\ud058\u038f\u193f\ua73b\ub9f6\ubad3\u4faa\u2d5c\u9d86\u15b9\u0185\u34a6\u8b4c\uc9a4", "\ud9e6\udcc0\udbbb\udd3c\uda9d\udfec\uda9d\udd27\ud9f9\udf96\ud900\ude45\udbce\udc3a\ud8d5\ude10\ud8d8\udc72\ud992\ude46\ud870\uddb0\uda28\udc28\ud9ad\udc6e\udb18\udd60\uda11\udd36\ud906\udeea\ud86f\udd06\ud92f\ude2c\ud982\udd12\ud849\udf62\uda12\ude2d",
        9, 2288, 959203181, 4489923596886247178L, 35718L, false, true, (char) 5918, (char) 11692,
        Double.longBitsToDouble(0x3f9c2e01b75724a0L), Double.longBitsToDouble(0x3fe2957474ed5150L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\udb68\udf66\uda99\udc4e\ud98f\udcbd\uda53\udcad=null}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{\udb68\udf66\uda99\udc4e\ud98f\udcbd\uda53\udcad=null}\012",
        Z.run(T, 2, 14, 4, 10, "\udb68\udf66\uda99\udc4e\ud98f\udcbd\uda53\udcad", "\ub28d\u2301\ua2c8\uaa50\u877c\u45b7\ub86d\u4973\uae4d\u05c0\ubf67\ubc85\ucab6", "\ud864\udec7\ud92d\udd93\u32a9\udb0c\ude13\ud84f\udf38\udbfb\udca6\udac5\udf65",
        2, 16281, -1853302857, -8799533754477794291L, 55986L, false, false, (char) 43528, (char) 47482,
        Double.longBitsToDouble(0x3fe665c365b02f11L), Double.longBitsToDouble(0x3fd52417364d600eL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 15, 15, 15, "\ud937\udd95\ud850\udd49\udb84\udfbf\udbfd\udcc7\ud907\udc6a\ud8b7\ude6b\ud9c3\udcea\udbf7\udc98\ud9d9\ude83", "\u1aee\ub2ea\ub9f6\u1755\u5d1f\u79a8\u1765\u11d2\u4d9a", "\ud9a0\udd34\udbcf\ude51\ud871\udf45\udab4\udc0a\uda41\uddc7\udb40\ude91\uda7e\udc78",
        24, 21788, 1786039816, 4201753194070149994L, 53408L, false, true, (char) 20797, (char) 51746,
        Double.longBitsToDouble(0x3fe1d911c59d6c9bL), Double.longBitsToDouble(0x3fd2300b30d3d41aL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 9, 4, "\ud9ac\udfab\ud850\udd49\ud86d\ude95\uda58\udead\uda47\udd1e\uda73\udd94\ud9c3\udd53\udbf7\udc98", "\u04bf\u3a86\u23d1\ub9f6\u5b06\u0b50\ua328\u9da9\ucab6\ubd9b\u8a81\u54ac\ua1ba\u53e7\u4afc\u896a\u6a07\u37c3\u3ef2\u20de\uc85e\u3713", "\uda20\udd27\uda1d\udffd\ud93c\ude77\ud88b\udf67\ud8fe\udf6a\uda0c\udca1\ud922\udf98\udb81\udf2f\ub44f",
        9, 80265, 565173250, 3853803335203438234L, 78657L, false, false, (char) 13738, (char) 11706,
        Double.longBitsToDouble(0x3fa7ec7c481bb280L), Double.longBitsToDouble(0x3fec28908d1433d9L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 7, 7, 4, "\uda72\udd94\ud909\udc64\ud86d\udee6\uda58\udead\uda47\udd1e", "\u45b6\uac24\u0470\u0545\uc2af\ua774\ub9f6\u5b06\uc37d\u757b\u9da9\ucab6\ubd62\u8a81\u54ac\ua13e\u6243\u8f78\ua97a\u761f\u32bc", "\ud8ed\uded3\u372e\udac8\udfb4\uda73\udc61\udb0b\udd99\ud9fc\udc25\uda26\udc54\ud88b\udf67\ud8fe\udf53\udb96\udd67\ud881\udf4a",
        47, 41231, -979360491, 1608966278950645414L, 77318L, false, true, (char) 60014, (char) 6970,
        Double.longBitsToDouble(0x3fede197552b8a1fL), Double.longBitsToDouble(0x3fdf49399f2f5deeL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{=}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{=}\012",
        Z.run(T, 2, 14, 4, 0, "", "", "\uda47\udd1e",
        52, 77278, -1248877316, -2407494844535721035L, 60058L, false, true, (char) 42468, (char) 14570,
        Double.longBitsToDouble(0x3fd9c6b03686181eL), Double.longBitsToDouble(0x3fe595e2253acc4cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.map.Flat3Map|remove|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|clear||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|clone||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|containsKey|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|containsValue|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|convertToMap||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|createDelegateMap||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|entrySet||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|equals|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|get|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|hashCode||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|isEmpty||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|keySet||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|mapIterator||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|put|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|putAll|java.util.Map|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|remove|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
