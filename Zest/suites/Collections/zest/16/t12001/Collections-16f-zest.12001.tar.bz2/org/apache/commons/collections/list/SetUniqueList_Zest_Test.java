package org.apache.commons.collections.list;
import org.junit.Test;
import static org.junit.Assert.*;
public class SetUniqueList_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 9, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 9, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3ece\u676b\u419c\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\udacc\ude69\ud9c6\udf20\udaa9\ude51\ud98f\ude27\ud82a\udd7d",
        12, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 6, 11, "\ud903\udde7\ud1ad", "\u980b\uae9e\u95f7\u612b\u57c7\u904a\u8994\u23a3\u7d85\ud5fd\u2af7\u2aed\u59f1\uabd7\u172f\ud197\u3216\ub06d\u3ce0\u6708\u98eb\u663a\u7b32\u29d7\ud3ff\u531f\ua84e\u28e1\ub79b", "\uda91\uddad\u1727\udb58\ude24\ud8aa\udd9c\ud965\udf74\ud887\ude73\udb80\udc72\ud826\ude1a\ud98f\ude27\uda5b\uddce",
        53, 99911, 1889994036, 4693458755083361294L, 71629L, false, true, (char) 48232, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 6, 11, "\udbf9\udfc9\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u485e\u55fc\u1782\ubee0\ucf60\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\ud90d\udc3a\udb31\udf02] |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 0, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2b11\u59f1\uabd7\u3ddf\u0f6b\u765c\u43d5\u3c37\u6708\u4383\u96d3\u13d8\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud9d0\udc4a\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud84b\ude25\uda5b\uddce",
        53, 99911, -559479500, 7796550825189366798L, -59443L, true, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.UnmodifiableSet:[\u980b\uae9e\u95f7\u6104\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u9ed0\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b] |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 6, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u6104\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u9ed0\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\u20b4\ud9d9\uddf6\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 12, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u974b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u7b46\u1cad\u2aed\u59f1\uabd7\u67ed\u9937\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\u5fbf\u6909\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e",
        51, 91556, 1982244650, -1119154144273489275L, -99272L, true, false, (char) 1185, (char) 51282,
        Double.longBitsToDouble(0x3f8cd81f257a2c00L), Double.longBitsToDouble(0x3febb953db32b462L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 1, 15, 9, "\ud90d\udc3a\udb31\udf02\ud925\udf6c\ud9e0\udcf5\uda5e\ude3c\ud9c8\udc40\ud857\udf33\ud96d\udd76\udac7\uddcf\ud9d6\udc5a\u4476\ud8fe\ude17", "\u5a93\u2aed\u59f1\uabd7\u172f", "\u5cec\ud9ad\uddc2",
        24, 604, -1028516125, -4981093955775446693L, 82409L, true, false, (char) 22554, (char) 21245,
        Double.longBitsToDouble(0x3fe44b911cb4ad96L), Double.longBitsToDouble(0x3fe7ebb47ac0e7a9L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1c02\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6e24\u087d\u3afc\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\ud84a\udc09\uda9a\udf89\udb25\udd8d\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd7768c1a35L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 1, 7, 9, 11, "\ud90d\udc7a\udb31\udf02", "\u3014\uae9e\ua082\u612b\u57c7\u1b84\u338b\u02c1\u8cf3\u3c0d\u1cad\u2aed\u59f1\uabd7\u172f\u5c43\uaf5a\u4300\u3c37\u6708\u291b\ud208\u1782\ubeb7\ub75f\u0878\u7b79\u2887\ua29b", "\udaa6\udf72\ud820\udfb3\udad8\uddb1\ud962\udd9e\uda9d\udd0f\uda07\udf81\ud9d9\ude20\udaa9\ude51\ud944\udf62\uda5b\uddce",
        10, 99911, -2119760588, 8300641131015707649L, -64905L, false, true, (char) 16717, (char) 62090,
        Double.longBitsToDouble(0x3fedf323029e96d4L), Double.longBitsToDouble(0x3fefb533355110abL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02, \ud8f3\udf4b\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud938\udc9e\udac0\udc94\ue989\udbbd\ude4b\ud957\ude06\uda62\ude22]\012",
        Z.run(T, 1, 2, 12, 1, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u0d76\u6565\u57c7\u1b94\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u84df\u981e\u1735\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u7d23\ubf6d\u779b\u0878\u7b79\u2887\ub79b", "\ud8f3\udf4b\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud938\udc9e\udac0\udc94\ue989\udbbd\ude4b\ud957\ude06\uda62\ude22",
        53, 99911, -559479500, 8463196304333788250L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fe328d301505431L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02, \uda91\uddad\uda9a\udfb0\udb4d\ude86\ud962\udd9e\ud965\udf74\u20b4\000\000\ud98f\udda2\uda5b\uddce]\012",
        Z.run(T, 1, 5, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb4d\ude86\ud962\udd9e\ud965\udf74\u20b4\000\000\ud98f\udda2\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 10, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3c37\u2037\u98eb\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 1, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u26e4\uab3e\u016d\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad1c\u43d5\u3c37\u6708\u98eb\u73dc\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\ud951\udecc\udacc\udcea\udb2c\udf28\ud962\udd9e\ud965\udf74\ud90d\udfd5\ud9a5\udf14\uda9e\ude9d\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc65\udb31\udf02]\012",
        Z.run(T, 1, 11, 3, 11, "\ud90d\udc65\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u15ed\u9ae5\ucea8\ucfff\ud197\uad36\u43d5\u86ba\u66f3\u98eb\ub397\u83f2\ubee0\ub75f\u786e\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud9c0\udd62\uda0d\ude76\uda9b\udec2\udaa9\udef3\ud98f\ude27\uda5b\uddce",
        53, 99911, -1767648516, 7841633155570261006L, 71629L, false, true, (char) 31892, (char) 32129,
        Double.longBitsToDouble(0x3fe2f99602c68f35L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 13, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 9, 14, 12, "\ud90d\udc3a\udb31\udf02", "\u980b\u269e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u3725\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\u1673\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, true, true, (char) 27518, (char) 11599,
        Double.longBitsToDouble(0x3fe2f8c4de563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02, \uda91\uddad\uda9a\udfb0\udb25\udd8d\udbb3\udde7\ud8ce\udf3f\uda12\ude3c\ud9d9\ude20\udb6f\udd14\udae1\udf81\ufa7e]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02, \uda91\uddad\uda9a\udfb0\udb25\udd8d\udbb3\udde7\ud8ce\udf3f\uda12\ude3c\ud9d9\ude20\udb6f\udd14\udae1\udf81\ufa7e, \ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 2, 2, 5, 0, "\ud90d\udc3a\udb31\udf02", "\u0f38\uae9e\u94c7\ub504\u57c7\u1b84\u3dc0\u457d\u81aa\u6250\u1cad\u2aed\u59f1\uabd7\u172f\ud197\u7217\u78c4\u3c37\u6708\u6ab3\u7994\u1723\ubee0\ub75f\u0878\u1279\uba79\u765c", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\udbb3\udde7\ud8ce\udf3f\uda12\ude3c\ud9d9\ude20\udb6f\udd14\udae1\udf81\ufa7e",
        11, 89510, -561367231, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 56358,
        Double.longBitsToDouble(0x3fecd3bf97571341L), Double.longBitsToDouble(0x3fedf3242a9e96d4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.UnmodifiableSet:[\u980b\u1709\u4631\u612b\u57c7\ucbe2\u3dc0\ub945\u81aa\u6c4f\u0eb4\u2afc\ua533\u4f5b\u3fe9\ud0d0\u6f5a\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\u51be\u08dc\u7b79\u2887\ub79b] |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\0121=org.apache.commons.collections.set.UnmodifiableSet:[\u980b\u1709\u4631\u612b\u57c7\ucbe2\u3dc0\ub945\u81aa\u6c4f\u0eb4\u2afc\ua533\u4f5b\u3fe9\ud0d0\u6f5a\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\u51be\u08dc\u7b79\u2887\ub79b] |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 2, 6, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\u1709\u4631\u612b\u57c7\ucbe2\u3dc0\ub945\u81aa\u6c4f\u0eb4\u2afc\ua533\u4f5b\u3fe9\ud0d0\u6f5a\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\u51be\u08dc\u7b79\u2887\ub79b", "\uda91\uddad\uda37\udd5f\udb4c\udd69\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce\ud9d9\udf75\ud8f3\udc9e\udb92\udf3c",
        37, 8486, 712744085, -5448618410260374734L, -17426L, true, false, (char) 24742, (char) 18462,
        Double.longBitsToDouble(0x3fe4f4b6a35e059cL), Double.longBitsToDouble(0x3fbf5200597b3ca8L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 10, 2, 11, "\ud903\udde7\ud1ad", "\u980b\uae9e\u9ef6\u612b\u57c7\u76d5\u8994\u23a3\u7d85\ud5fd\u2af7\u2aed\u59f1\uabd7\u172f\ud197\u3216\ub06d\u3ce0\u6708\u98eb\u663a\u7b32\u29d7\ud3ff\u531f\ua84e\u28e1\ub79b", "\udb3c\ude31\u1727\udb58\ude24\ud8aa\udd9c\ud965\udf74\ud887\ude73\udb80\udc72\ud826\ude1a\ud98f\ude27\uda5b\uddce",
        53, 99911, 1889994036, 4693458755083361294L, 61911L, false, true, (char) 24932, (char) 14480,
        Double.longBitsToDouble(0x3fe2fbafc6563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[\ud91d\udc9b\udae3\uddd9, \udaee\udd4e\uda9a\udf9c\uda3f\udcba\ud965\udc50\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\udaf4\udd19\uda7c\udfad]\012",
        Z.run(T, 1, 3, 6, 11, "\ud91d\udc9b\udae3\uddd9", "\u979b\u7bc1\u970e\ua48a\u57b6\u1b84\uaa7d\ub945\u81aa\u2d47\u6ec0\ubcba\u59f1\ud7d7\ub8aa\ud197\uacf6\ud7c6\u3c37\u6708\u485e\u55fc\u3066\ubec6\u1b60\u7a77\u7b79\u2887\uc8ee", "\udaee\udd4e\uda9a\udf9c\uda3f\udcba\ud965\udc50\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\udaf4\udd19\uda7c\udfad",
        1, 26588, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd7706d3335L), Double.longBitsToDouble(0x3fe40ede24e1c921L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ud96c\udd50\udb31\udf02]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud96c\udd50\udb31\udf02]\012",
        Z.run(T, 2, 10, 9, 10, "\ud96c\udd50\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2b11\u59f1\uabd7\u3ddf\u0f6b\u765c\u43d5\u3c37\u6708\u4383\u96d3\u7908\u8d93\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\ud973\udebd\ud896\udcf0\uc7a7\ud94f\uddf6\udafc\udc8c\ud9d9\ude20\udaa9\ude51\udb6b\udfd6\udbcc\ude37",
        52, 99911, -559479500, 7796550825189366798L, -59443L, true, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.String:\ud90d\udc3a\udb31\udf02 |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 1, 15, 13, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae97\u95f7\u6104\u57c7\u1b84\u236a\ub945\u8ecd\u11d1\u1cad\u2aed\u9ed0\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub788\u0878\u7b79\u2887\ub79b", "\uda8f\udfcb\uda9a\udf11\udb25\udd8d\ud962\udd9e\ud965\udf74\u20b4\ud9d9\uddf6\udaa9\ude51\ud98f\ude27\uda5b\uddce\ud9d9\udf75\ud8f3\udc9e",
        0, 31187, -391062514, 3061212534223838829L, -97161L, true, true, (char) 16717, (char) 63882,
        Double.longBitsToDouble(0x3fedf323029e96d4L), Double.longBitsToDouble(0x3fe1400335783d4cL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.UnmodifiableSet:[\u6154\u57c7\u1b84\u3dc0\ua6e2\u9a01\u2d47\u1cad\u2aed] |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02\ud9a3\udf6b\ud9e0\udcf5\uda5e\ude3c]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 3, 11, "\ud90d\udc3a\udb31\udf02\ud9a3\udf6b\ud9e0\udcf5\uda5e\ude3c", "\u6154\u57c7\u1b84\u3dc0\ua6e2\u9a01\u2d47\u1cad\u2aed", "\udb42\uded7\uda05\udc5e\uda74\ude23\u9f35\uda02\udf13\uda6f\udcaa\uda6b\udc62",
        -5, 30688, 757645659, -3702033369820247404L, 82409L, true, false, (char) 22554, (char) 63741,
        Double.longBitsToDouble(0x3fe44d791c08ad96L), Double.longBitsToDouble(0x3fe7ebb47ac0e7a9L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc7a\udb31\udf02, \udaa6\udf72\ud820\udfb3\udad8\uddb1\ud962\udd9e\uda9d\udd0f\uda07\udf81\ud9d9\ude20\udaa9\ude51\ud944\udf62\uda5b\uddce]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 2, 13, 11, "\ud90d\udc7a\udb31\udf02", "\ub044\uae9e\ua082\u612b\u57c7\u1b84\u338b\u02c1\u8cf3\u3c0d\u1cad\u2aed\u59f1\uabd7\u172f\u5c43\uaf5a\u4300\u3c37\u6708\u291b\ud208\u1782\ubeb7\ub75f\u0878\u7b79\u2887\ua29b", "\udaa6\udf72\ud820\udfb3\udad8\uddb1\ud962\udd9e\uda9d\udd0f\uda07\udf81\ud9d9\ude20\udaa9\ude51\ud944\udf62\uda5b\uddce",
        10, 99911, -2119760588, 8300641131015707649L, -64905L, false, true, (char) 16717, (char) 62090,
        Double.longBitsToDouble(0x3fedf323029e96d4L), Double.longBitsToDouble(0x3fefb533355110abL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 7, 15, 11, "\ud915\udf7a\udb67\udc7a", "\u9014\uae9e\ua082\u612b\u52af\u6692", "\udb18\ude2d\ud9cd\ude61\ud809\ude37\udbfb\udd39\ud8f0\udfe9\ud952\udd49\udae9\udcd4",
        22, 7536, -1361124568, -8605174512849877115L, -75505L, false, false, (char) 58870, (char) 38359,
        Double.longBitsToDouble(0x3fe4a664fb03ad38L), Double.longBitsToDouble(0x3fe7c2cd204b7299L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc7a\udb31\udf02, \udbe5\ude08\ud80e\udd6d\udad8\uddb1\ud962\udd9e\uda9d\udd0f\uda07\udf81\ud9d9\ude20\udaa9\ude51\ud944\udf62\uda5b\uddce]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc7a\udb31\udf02, \udbe5\ude08\ud80e\udd6d\udad8\uddb1\ud962\udd9e\uda9d\udd0f\uda07\udf81\ud9d9\ude20\udaa9\ude51\ud944\udf62\uda5b\uddce]\012",
        Z.run(T, 2, 5, 9, 11, "\ud90d\udc7a\udb31\udf02", "\u3014\uae9e\ua082\u612b\u57c7\u1b84\ub7fc\uc12a\u0c50\u3c0d\u1cad\u2aed\u0ae7\u821a\u1784\u5c43\uaf5a\u4300\u2012\u8c20\u277f\u3bb9\u1cd9\u670d\ub75f\u0878\u7b79\u2887\ua29b", "\udbe5\ude08\ud80e\udd6d\udad8\uddb1\ud962\udd9e\uda9d\udd0f\uda07\udf81\ud9d9\ude20\udaa9\ude51\ud944\udf62\uda5b\uddce",
        10, 99911, -2119760588, 662536163323324162L, 94583L, false, true, (char) 16717, (char) 62090,
        Double.longBitsToDouble(0x3fedf323036d8575L), Double.longBitsToDouble(0x3fefb5301d5110abL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02, \udaf3\udeb8\ud924\udde6\uda74\ude23\udaed\udcf7\uda02\udf59\uda6f\udcaa\uda4e\udc73\ud96f\udd21\uda62\udc6d\ud838\udf63\udb90\udd78\ud871\uddb3\ud8b1\udf03\udaf0\udea5\udbea\udca1\udbf1\udd81\udbc5\ude4c\ud8f3\udfa5]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02, \udaf3\udeb8\ud924\udde6\uda74\ude23\udaed\udcf7\uda02\udf59\uda6f\udcaa\uda4e\udc73\ud96f\udd21\uda62\udc6d\ud838\udf63\udb90\udd78\ud871\uddb3\ud8b1\udf03\udaf0\udea5\udbea\udca1\udbf1\udd81\udbc5\ude4c\ud8f3\udfa5, \ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 2, 2, 2, 13, "\ud90d\udc3a\udb31\udf02", "\u1bf2\u083c\u0d76\u6565\u57c7\u1b94\u3dc0\ub945\uc07a\u4ac7\u8c17\u2aed", "\udaf3\udeb8\ud924\udde6\uda74\ude23\udaed\udcf7\uda02\udf59\uda6f\udcaa\uda4e\udc73\ud96f\udd21\uda62\udc6d\ud838\udf63\udb90\udd78\ud871\uddb3\ud8b1\udf03\udaf0\udea5\udbea\udca1\udbf1\udd81\udbc5\ude4c\ud8f3\udfa5",
        5, 92021, -322071872, -8796638084046657006L, -73088L, true, true, (char) 47793, (char) 1691,
        Double.longBitsToDouble(0x3fad9bae534fff30L), Double.longBitsToDouble(0x3fd33de278b57500L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udaaf\udd2b\udb31\udf02\ud925\udf6c\ud9e0\udcf5\ud928\udda1\ud91a\uddee\ud8d6\uddce\ud96e\uddb0\udacc\uddcf] |this=org.apache.commons.collections.list.SetUniqueList:[\udaaf\udd2b\udb31\udf02\ud925\udf6c\ud9e0\udcf5\ud928\udda1\ud91a\uddee\ud8d6\uddce\ud96e\uddb0\udacc\uddcf]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 0, 1, 1, "\udaaf\udd2b\udb31\udf02\ud925\udf6c\ud9e0\udcf5\ud928\udda1\ud91a\uddee\ud8d6\uddce\ud96e\uddb0\udacc\uddcf", "\ub945\uc254", "\ud8e9\udd67\udb84\udf08\ud945\ude0b\ud91a\udddb\uda05\udc18\uda7a\udea7\udab9\udf26\uda02\udf57\uda6f\udcaa\uda6b\udc62\udaab\udc55",
        52, 53610, -861963136, -5964794968309253373L, 77585L, false, false, (char) 36605, (char) 18339,
        Double.longBitsToDouble(0x3fc695b1fbf5da3cL), Double.longBitsToDouble(0x3fd829aa90ee4b4cL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud9f8\udd1f\ud9df\udef9, \uda91\uddad\uda9a\udfb0\udb4d\ude86\ud962\udd9e\uda55\udeec]\0121=org.apache.commons.collections.list.SetUniqueList:[\ud9f8\udd1f\ud9df\udef9]\012",
        Z.run(T, 2, 5, 10, 11, "\ud9f8\udd1f\ud9df\udef9", "\u980b\u85cd\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u2fc9\u6708\u98eb\u6647\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb4d\ude86\ud962\udd9e\uda55\udeec",
        47, -1000, -973078528, 4428466851933799753L, -94283L, true, false, (char) 34123, (char) 51431,
        Double.longBitsToDouble(0x3fe995a314e983c6L), Double.longBitsToDouble(0x3fd7204a7cbef5dcL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 13, 5, 16, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u3c64\u1cad\u2aed\u5a75\uabd7\ub5ed\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2328\u45ce", "\uda91\uddad\uda9a\udfb0\udb51\ude8d\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud813\udfca\ud91d\udcab\u97f9\ud8f3\udc9e",
        0, 31187, -391062514, 3061212534223838829L, -97161L, true, true, (char) 40998, (char) 54333,
        Double.longBitsToDouble(0x3fee33d79a9ea865L), Double.longBitsToDouble(0x3fc81a62a9bc9d7cL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\uda3b\udc16\ud94c\udd23]\0121=java.util.TreeSet:[\u6ace\u144f\u9515\u1c63\u17e5\uc355\u0c66\ub945\u81aa\u2d47\u1cad\u2aed\u93f0\ud74b\u9ba7\ud186\uad36\u43d5\u3c37\u49b3\u637c\u9197\u3ab9\ubee0\ub75f\u0878\u7b79\u2887\ub79b] |this=org.apache.commons.collections.list.SetUniqueList:[\uda3b\udc16\ud94c\udd23]\012",
        Z.run(T, 2, 9, 16, 14, "\uda3b\udc16\ud94c\udd23", "\u6ace\u144f\u9515\u1c63\u17e5\uc355\u0c66\ub945\u81aa\u2d47\u1cad\u2aed\u93f0\ud74b\u9ba7\ud186\uad36\u43d5\u3c37\u49b3\u637c\u9197\u3ab9\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\ud8fa\udfa9\udb25\udd8d\uda45\ude50\ud881\udd87\ud90a\udd3d\ud9a6\uddd2\udaa9\ude51\udbab\udfce\uda66\udcdb",
        29, 99873, -559479500, 7786699202917948430L, 71629L, true, false, (char) 31387, (char) 57678,
        Double.longBitsToDouble(0x3fe2f8c636563335L), Double.longBitsToDouble(0x3fedf323020496d4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 14, 14, 12, "\ud90d\udc3a\udb31\udf02", "\uaf1b\uc9fa\u0130\ubf19\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ucccb\u6696\u43d5\u3c37\u924a\ua11a\u96e0\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\ud975\ude1a\udaec\uddf7\udb25\udd8d\ud962\udd9e\ud965\udf74\u1673\ud9d9\ude20\udaa9\ude51\uda9c\udd8e\ud80a\udf9e",
        5, 99911, -559479500, 7786699201004493838L, 71629L, true, true, (char) 27518, (char) 34127,
        Double.longBitsToDouble(0x3fe544e6ce563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc67\uda5e\udf37\uda53\udf05\ud9e0\udcf5\udaa8\ude75\ud95c\udcae\ud9a1\udcc1\ud9cd\uddca\udaf4\ude09\ud9d6\udc5a\ud806\udfd0\udb6e\udeff\ud914\udda3\ud9dc\udd24\ud809\udef5\udbfb\udd39\ud8f0\udfe9\udb26\udcd1\udb23\udd31]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc67\uda5e\udf37\uda53\udf05\ud9e0\udcf5\udaa8\ude75\ud95c\udcae\ud9a1\udcc1\ud9cd\uddca\udaf4\ude09\ud9d6\udc5a\ud806\udfd0\udb6e\udeff\ud914\udda3\ud9dc\udd24\ud809\udef5\udbfb\udd39\ud8f0\udfe9\udb26\udcd1\udb23\udd31]\012",
        Z.run(T, 2, 11, 12, 7, "\ud90d\udc67\uda5e\udf37\uda53\udf05\ud9e0\udcf5\udaa8\ude75\ud95c\udcae\ud9a1\udcc1\ud9cd\uddca\udaf4\ude09\ud9d6\udc5a\ud806\udfd0\udb6e\udeff\ud914\udda3\ud9dc\udd24\ud809\udef5\udbfb\udd39\ud8f0\udfe9\udb26\udcd1\udb23\udd31", "\uc82c\u82d0\u0be2\u7da7\u663a\ud6de\ubee0\ub75f\u0878\u7b79\u2887", "\udaa2\udca1\ud99b\uddf1\uda50\udf67\ud902\udf1a\ud8fd\udce2\ud974\udee8\udb80\udc5c\uda23\ude86\udaa7\uddc2\ud8b7\udd5d\uda5b\uddce\udb11\udd1a\ud8f3\udc9e\ud9ec\udc4c\ud8ee\udd8a\udbe6\udf45",
        35, 22053, 1376822219, -8424992629362372002L, 16310L, false, true, (char) 26994, (char) 58338,
        Double.longBitsToDouble(0x3fa6214f7a290a00L), Double.longBitsToDouble(0x3fe66fe625112354L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\ud90d\udc3a] |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a]\0121=java.util.TreeSet:[\u0093\u9734\000] |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a]\012",
        Z.run(T, 2, 0, 0, 0, "\ud90d\udc3a", "\u0093\u9734\000", "\uda91\udeca",
        19, 52383, -1362979028, 6143803742861971601L, 87583L, false, false, (char) 55352, (char) 8049,
        Double.longBitsToDouble(0x3feeefad2e36c4b6L), Double.longBitsToDouble(0x3fefea154222aedeL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 7, 7, 3, "\ud8a3\udfd0", "\ub2ab\ud011\uae9e\ua082\u0ce2\u76c1\u4988\u3c56\u1d62\u8cf3\u3c0d\u1cad\u2aed\u1a6f\u1208\u0ab8\u8630\u3513\u4300\u92d9\u9ebc\u71e8\u8620\u6890\u2972\u9d59\u08cf\ud541", "\ua2b7\udbcd\udce7\ud9fa\udf08\udac9\udcfb\ud93f\uded7\uda8a\udea9\ud81e\udd9a\uda00\ude5a\ud83d\udf31\uda95\udcc8",
        54, 73540, 1454199059, -7151560246881945243L, -50512L, false, false, (char) 13830, (char) 12351,
        Double.longBitsToDouble(0x3fee3bc731554ecdL), Double.longBitsToDouble(0x3fc32f06d3cd5e50L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\udae6\ude9c\ud8ca\udfe8\udb77\udd63\udba7\udc4d\udb80\udec5\uda81\ude08\udbcf\ude90\ud96d\udd76\ud95a\udf4f\udb29\udcb6\udbcd\udf1f\ud855\udc37\ud940\udcb3\ud836\udfd8\udbfa\udcdd\ud857\udcd4]\0121=org.apache.commons.collections.list.SetUniqueList:[\udae6\ude9c\ud8ca\udfe8\udb77\udd63\udba7\udc4d\udb80\udec5\uda81\ude08\udbcf\ude90\ud96d\udd76\ud95a\udf4f\udb29\udcb6\udbcd\udf1f\ud855\udc37\ud940\udcb3\ud836\udfd8\udbfa\udcdd\ud857\udcd4]\012",
        Z.run(T, 2, 10, 10, 16, "\udae6\ude9c\ud8ca\udfe8\udb77\udd63\udba7\udc4d\udb80\udec5\uda81\ude08\udbcf\ude90\ud96d\udd76\ud95a\udf4f\udb29\udcb6\udbcd\udf1f\ud855\udc37\ud940\udcb3\ud836\udfd8\udbfa\udcdd\ud857\udcd4", "\ubeb4\u1bf4\u1fd2\u373f", "\ud8ee\ude06\ud9cc\udf07\udbe4\udde6",
        55, 3355, -1388787052, 6459493389038112504L, 79969L, false, false, (char) 62006, (char) 33966,
        Double.longBitsToDouble(0x3fdf942e1315f90eL), Double.longBitsToDouble(0x3fc987f540333350L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 9, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u59f1\uabd7\u172f\ud197\uad36\u43d5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub75f\u0878\u7b79\u2887\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699202627950522L, -97161L, false, true, (char) 16717, (char) 63882,
        Double.longBitsToDouble(0x3fedf323029e96d4L), Double.longBitsToDouble(0x3feaea8d67de321eL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 2, 12, 12, 1, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u0d76\u6565\uc070\u1b94\u3dc0\ub945\u81aa\u2d47\u1cad\u2aed\u84df\u981e\u1735\ud197\u25b8\u5973\u2016\u6708\u98eb\u663a\u7d23\ubf6d\u779b\ub6eb\u83c5\u34ae\ub79b", "\ud8f3\udf4b\uda9a\udfb0\udbab\udfb1\ud85b\udcb7\ud938\udc9e\udac0\udc94\ue989\udbbd\ude4b\ud957\ude06\uda62\ude22",
        53, 99911, -559479500, 8463196304340145242L, 71629L, false, true, (char) 55590, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd772676bf9L), Double.longBitsToDouble(0x3fda44abe2a0a830L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\u00e4\000]\012",
        Z.run(T, 1, 4, 2, 11, "\u00e4\000", "", "",
        -5, -1000, -447369472, 3784994296955258183L, -94723L, false, false, (char) 0, (char) 241,
        Double.longBitsToDouble(0x3e31c8d000000000L), Double.longBitsToDouble(0x3feba19fefdd4ea5L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\udaaf\udd2b\udb31\udf02\ud925\udf6c\ud9e0\udcf5\ud928\udda1\ud91a\uddee\uda1c\udfbb\ud96e\uddb0\udacc\uddcf]\0121=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\udaaf\udd2b\udb31\udf02\ud925\udf6c\ud9e0\udcf5\ud928\udda1\ud91a\uddee\uda1c\udfbb\ud96e\uddb0\udacc\uddcf]\012",
        Z.run(T, 2, 11, 11, 1, "\udaaf\udd2b\udb31\udf02\ud925\udf6c\ud9e0\udcf5\ud928\udda1\ud91a\uddee\uda1c\udfbb\ud96e\uddb0\udacc\uddcf", "\ub945\uc254", "\ud8e9\udd67\udb84\udf08\ud945\ude0b\ud91a\udddb\uda05\udc18\uda7a\udea7\udab9\udf26\uda02\udf57\uda6f\udcaa\uda6b\udc62\udaab\udc55",
        52, 77162, -861963136, -5964794968309253373L, 77585L, false, false, (char) 36605, (char) 18339,
        Double.longBitsToDouble(0x3fc695b1fbf5da3cL), Double.longBitsToDouble(0x3fd829aa90ee4b4cL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\u00e4\000]\012",
        Z.run(T, 1, 2, 15, 16, "\u00e4\000", "", "",
        55, 16136, -447369472, 3784994296955258183L, -94723L, false, false, (char) 48059, (char) 241,
        Double.longBitsToDouble(0x3e39c8d000000000L), Double.longBitsToDouble(0x3fed96bc27dd4ea5L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 1, 9, 6, 10, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u612b\u57c7\u1b84\u3dc0\ub945\u6b6f\u2d96\u8c83\u2aed\u59f1\uabd7\u172f\ud197\uad36\u5da5\u3c37\u6708\u98eb\u663a\u1782\ubee0\ub75f\u0878\u39c2\u3c1c\ub79b", "\uda91\uddad\uda9a\udfb0\ud821\ude56\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9d9\ude20\udaa9\ude51\ud98f\ude27\uda5b\uddce",
        53, 99911, -559479500, 7786699201004493838L, 71629L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud90d\udc3a\udb31\udf02]\012",
        Z.run(T, 2, 13, 13, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae97\u95f7\u6104\u57c7\u1b84\u236a\ub945\u2ffd\u11d1\u1cad\u2aed\u9ed0\u69d7\u172f\ud197\uad36\u43d5\u3c37\u6708\u42ff\u6583\u1e6a\u2468\u54f0\u0308\u7b79\u2887\ub79b", "\uda8f\udfcb\uda7d\ude11\uda17\udd86\ud962\udd9e\ud965\udf74\u20b4\ud9d9\uddf6\udaa9\ude51\ud98f\ude27\uda5b\uddce\ud9d9\udf75\ud8f3\udc9e",
        0, 31187, -391062514, 3061212534223838829L, -97161L, true, true, (char) 16717, (char) 63882,
        Double.longBitsToDouble(0x3fedf323029e96d4L), Double.longBitsToDouble(0x3fe1400335783d4cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 15, 6, 11, "\ud90d\udc3a\udb31\udf02", "\u980b\uae9e\u95f7\u9ffb\u5e28\u5932\u00c2\ub945\u81aa\uad57\u1cad\u2aed\u28c7\u2651\u172f\ud197\uad36\u43d5\u3c37\u0708\u02a4\u663a\u1782\ubee0\ub7a7\u40c2\ucabc\u1f41\ub79b", "\uda91\uddad\uda9a\udfb0\udb25\udd8d\ud962\udd9e\ud965\udf74\uda0d\ude76\ud9bf\udc94\ud871\udd50\ud989\udfb4\uda5b\uddce",
        53, 99911, -559479500, 7786699202061458446L, -9485L, false, true, (char) 30895, (char) 24857,
        Double.longBitsToDouble(0x3fe2fbd776563335L), Double.longBitsToDouble(0x3fedf323029e96d4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.list.SetUniqueList|createSetBasedOnList|java.util.Set,java.util.List|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|subList|int,int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|add|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|add|int,java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|int,java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|asSet||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|clear||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|contains|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|containsAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|decorate|java.util.List|static",
    "M|org.apache.commons.collections.list.SetUniqueList|iterator||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|listIterator||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|listIterator|int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|remove|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|remove|int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|createSetBasedOnList|java.util.Set,java.util.List|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|subList|int,int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
