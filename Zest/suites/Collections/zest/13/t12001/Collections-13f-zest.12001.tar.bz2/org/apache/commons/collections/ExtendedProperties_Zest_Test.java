package org.apache.commons.collections;
import org.junit.Test;
import static org.junit.Assert.*;
public class ExtendedProperties_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 13, 10, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\uda45\udf31",
        31, 50445, 573257731, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 13, 10, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ue459\ud959\udd24\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua85b\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\ud913\uddf3\ud9c4\udf3b\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\uda45\udf31",
        31, 50445, 573257731, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 6, 5, 10, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u55d5\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\udb16\ude0d\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\udb22\udd5f",
        16, 50445, 573257731, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 8, 10, "\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\u6b05\u8930\u7afe\ua6af\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\udb1d\udc4b\udbaa\udd25\ud828\udeb2\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\ud825\udcef\uda45\udf84",
        31, 28237, 573257885, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1bf74781L), Double.longBitsToDouble(0x3febc92e4fde2febL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 1, 11, 13, 10, "\udb87\udd8e\ud8ea\uded0\ud9d7\udf61\ud97c\udc7b\udb50\ude30\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\u97a5\u2dcc\u7265\u7ae4\ucba1\u19bc\u4008\u8622\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\u2863\uda7f\udff9\u75d4\udb12\udddd\ud958\uddab\ud850\udc5b\uda3d\udc02\ud8f9\udd31\udb01\udeb4\udb0e\udee0\ud881\uddd4\udab3\udc57\uda45\udf31",
        31, 50445, 573257731, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3faf14b1ad588fe0L), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 1, 12, 13, 10, "\udb87\udd8e", "\u6f33\u53df\u1416\u0489\u1b1f\u9309\u7a7d\u9144", "\ud931\udc08\ud984\udfb7\uda13\udde3",
        50, 87727, 679986500, 221926877849768480L, 12347L, true, true, (char) 51838, (char) 32863,
        Double.longBitsToDouble(0x3f8b277837945fc0L), Double.longBitsToDouble(0x3f8913bafc296440L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 6, 13, 10, "", "", "",
        -5, 31056, -2146016980, -9181603111358509716L, -68183L, false, false, (char) 25966, (char) 7926,
        Double.longBitsToDouble(0x3feff30fe9673f32L), Double.longBitsToDouble(0x3fe0ba6108519c34L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\udb8f\udeed\udac8\udca9\uda9d\udc81\uda67\udfc3\udae3\udca3\ud9e3\uddea\uda73\udf59\ud953\udd00\uda28\ude57\uda90\udcf1\ud96b\udfe2\udb99\udfd4\uda58\uddf9\ud931\udc08\ud984\udfb7\ud9a3\uddeb\ud803\ude09\udb94\udf58\uda1b\ude37\ud862\udf54\ud812\udfad\ud9ae\udc94\ud901\udf90\ud97f\udf79\udbac\udd17\ud954\uddfa\012",
        Z.run(T, 1, 9, 13, 6, "\udb8f\udeed\udac8\udca9\uda9d\udc81\uda67\udfc3\udae3\udca3\ud9e3\uddea\uda73\udf59\ud953\udd00\uda28\ude57\uda90\udcf1\ud96b\udfe2\udb99\udfd4\uda58\uddf9\ud931\udc08\ud984\udfb7\ud9a3\uddeb\ud803\ude09\udb94\udf58\uda1b\ude37\ud862\udf54\ud812\udfad\ud9ae\udc94\ud901\udf90\ud97f\udf79\udbac\udd17\ud954\uddfa", "\ua7ec\u1809", "\ud876\udcd1",
        29, 55035, -1249404755, -4572230674783857411L, 67360L, false, true, (char) 34884, (char) 29549,
        Double.longBitsToDouble(0x3fe0a476c0533947L), Double.longBitsToDouble(0x3fd87d28dc1d23f4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 1, 4, 10, 10, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\ud996\udede", "\ud6e5\ucd99\u6dfa\u7265\u8348\u8864\u2aa1\u9ed9\u5572\u39b6\u4e01\u8949\u6003\uce71\u5f65\u8c3c\ua4df\u848f", "\ud96c\udd47\ud850\udc5b",
        22, 85579, -796227965, 2692757497731400144L, 51283L, true, false, (char) 17261, (char) 28908,
        Double.longBitsToDouble(0x3fb4ce683c3e9468L), Double.longBitsToDouble(0x3fd3b24e711ecbe6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 1, 7, 15, 10, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u4ca2\ucf73\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud8d7\udf1f\u23b7\ud9b3\ude93\uda42\udc44\udab3\udc57\uda45\udf31",
        31, 50445, 585965571, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d380a88L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 13, 10, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud8fb\udc23\ud9f8\udf73\ud8c4\ude3a\uda93\udd1b", "\uafa1\u6a0d\ucc3c\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e",
        35, 46045, 1800674288, -4320653192650875368L, -70269L, true, false, (char) 26935, (char) 59181,
        Double.longBitsToDouble(0x3febfb3464270e5dL), Double.longBitsToDouble(0x3fd40abdb21b03e0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Byte:44 |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 1, 14, 13, 9, "\ud8f7\udd0c\udb44\udeef\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7265\u7ae4\ucba1", "\ud9b7\udfcc",
        44, 24564, -1078217355, -199527834537807404L, -54841L, true, true, (char) 3378, (char) 40425,
        Double.longBitsToDouble(0x3fef85a46cd06b54L), Double.longBitsToDouble(0x3fe0c6204ac22663L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 12, 13, 10, "\udb77\udde5\ud878\uded8\ud9a3\udffc\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8b5f", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\uda45\udf31",
        31, 50445, 573257731, -7419080867830745319L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2=\u4be9\u0986\u9630\u6dc6\u7265}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 10, "\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2", "\u4be9\u0986\u9630\u6dc6\u7265", "\ud8ed\udefe\ud845\ude39\ud832\udf0a\ud982\udd71\ud86a\ude6e\ud99a\udded\ud902\udf9b\udab5\udc4b\ucc0b\udbbc\udd96\uda6f\ude89\udaea\udd0e\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b",
        22, 85579, -791050621, 2692757497731400144L, 44591L, true, true, (char) 30403, (char) 58255,
        Double.longBitsToDouble(0x3fb4ce682c3e9468L), Double.longBitsToDouble(0x3fe0748fd451caebL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 6, 13, 10, "\udb87\udd8e\ud8ea\uded0\uda60\udc25\ud990\uddf0\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\u43ae\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u7f95\ubb47\u6003\uce71\u9894\u0edf\ubd46\u848f\ub29f\ubb24\u05bf\u2397\u5bf1\u402d\u4e43\u54f7\ucb5a\u0485\u506d\u0bd7\uc02b\u3882", "\ud941\udda5\ud887\udf0b\ud90c\udefc\udab1\udc65\udade\udf5c\udbf9\udfd1\uda21\udd7b\uda0d\udccc\ud8e5\udd38\ud9cd\uddf9\udb0c\ude95\uda81\uddd9",
        -1, 47240, 2012900764, -3325237165274393693L, 52276L, false, false, (char) 33423, (char) 22502,
        Double.longBitsToDouble(0x3fd51e37b536525cL), Double.longBitsToDouble(0x3fd4fb166f22cc04L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b=\u7f1e\u1ce6\uc76b\uc9f9\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949}\012",
        Z.run(T, 1, 2, 13, 5, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\u7f1e\u1ce6\uc76b\uc9f9\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud92c\udd86\ud9cf\uddb6\udb97\udd47\udadf\udff6\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\udabd\udf2d",
        31, 50445, 573257731, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 10, 12, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b\uda28\ude86\ud82c\ude7e\ud997\udc04\ud8f3\udd67\ud895\uddbc", "\u8713\ubbcf\ua8a3\u5572\u39b6\u4e01\u9310", "\ud8bd\udd00\udb20\udcb1\ud933\uddd0\ud8b0\ude0b\ue4ed\ud8b0\ude43\ud87e\udcfa\udb50\udf04\udb06\udce6\udac2\udeb8\ud805\ude68\udb6b\udf8b\ud8da\udf19\ud85a\udd6a\ud8f7\uddd7",
        36, 49145, 573257860, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3fe6a94b1a464648L), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\012",
        Z.run(T, 1, 8, 13, 10, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud33a\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ub044\u6e3b\u7265\u7ae4\ucba1\u4791\ua948\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\uda45\udf31",
        31, 15245, 39093786, -8153730625755356652L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 14, 10, "\udb5a\udd8e\ud8ea\uded0\ud984\udf07\ud807\ude60", "\u9191\u0599\u52e1", "\u5eda\uda58\ude51\ud931\udc08\uda65\udeff\u4a53\ud999\udcc8\ud845\uddf2\ud9b7\udfcc\ud862\udf54\ud812\udfad\ud9f9\udc79\u8142\ud99b\udfa3\ud957\udead\ud86a\udf06\ud931\udffa\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud952\udf1d\u2388\udb0e\udee0\ud819\udfdb\udab3\udc57\uda45\udf31\ud866\uddd2\udb23\uddc7\ud9d6\ude06\udb70\ude96\uda03\udd78\ud941\udda5\ud8b9\udc02",
        -4, 16179, 694371307, 5105797561809427014L, -73548L, true, true, (char) 15207, (char) 53186,
        Double.longBitsToDouble(0x3fd42490e73a97f6L), Double.longBitsToDouble(0x3fed4ef95f58a861L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 13, 4, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\ud8db\udcb1", "\u7152\u1734\ucfdc", "\udaa1\udc53\ud8c6\udf83\ud845\ude0b\ud9b7\udfcc\ud862\udf54\ud812\udfad\ud99a\uddab",
        4, 72919, -805830270, -6576187397885704423L, 91476L, false, true, (char) 24612, (char) 57889,
        Double.longBitsToDouble(0x3fe611331c23153fL), Double.longBitsToDouble(0x3fe2099540add08aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Byte:31 |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 1, 15, 13, 10, "\udb87\udd8e\udab8\uded7\ud9a4\udc07\ud807\ude60\ud959\udd27\ud9d9\udf13\uda0c\udf31\uda93\udd1b", "\u60e8\ucd99\u6dfa\u7265\u7ae4\ucba1\u2d4c\u6955\u2cef\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\udbcc\udcdd\udab2\udffa\uda44\udc31",
        31, 50445, 573257731, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 542,
        Double.longBitsToDouble(0x3feea9491a4630dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 11, 10, 10, "\udb87\udd8e\ud8ea\uded0\ud97b\udeba\u7560\uda25\udcb8\uda6a\udf13\u0f4d\ud971\udd8b", "\ud6e5\ucd99\u6dfa\u7265\u7543\uc5f0\u0b31\ua8a3\uba46\u992c\u5756\u2383", "\ud896\udc7c\uda36\udd3e\ud94e\udc04\udba7\udc70\udafe\udcc2\ud915\udcc5\uda92\udeb8\ud999\udcf5\udb16\udde0\ud8d7\udf1f",
        -5, 48461, 1720500688, 1034987332569908263L, 51283L, true, false, (char) 17261, (char) 29164,
        Double.longBitsToDouble(0x3fb40e6808c5f180L), Double.longBitsToDouble(0x3fcff704dceb51b8L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 1, 15, 5, 10, "\ud970\udf45\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud916\udca9\udbc5\udc02", "\ucab1\uade4\u08f9", "\uda13\udde3\ud999\udc35\ud845\uddf2\ud9b8\udc2f\ud97d\udc63\uda8b\udd8b\ud99a\udde7",
        38, 49454, -1032468913, -6576187397885704423L, 91476L, false, true, (char) 24612, (char) 57889,
        Double.longBitsToDouble(0x3fdc226639a9fe56L), Double.longBitsToDouble(0x3fec199546830e7bL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 5, 10, "\udb87\udd8e\ud8f8\uded0\ud8ee\udc6d\ud94d\udc8d\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6e1a\u7265\u7ae4\ucba1\ubbcf\ua8a3\u55d5\u39b6\u4e01\u55bb", "\ud957\ude41\ud86a\udf06\ud944\udcd3\udafe\udd9c\ud982\udce9\ud8d6\udfc0\ud96c\udd47\ud8fe\udf32\udaff\udc6e\ud8d7\udf1f\u240e\udb0e\udee0\ud849\udfdb\udab3\udc57\udb28\ude5f",
        11, 49919, -815618557, -7224156225223488421L, -33817L, false, false, (char) 28942, (char) 22814,
        Double.longBitsToDouble(0x3feeab68fa4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.String:\ud9e1\udf24\u691f\ud9a3\udfe9\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b\012",
        Z.run(T, 1, 9, 5, 10, "\ud9e1\udf24\u691f\ud9a3\udfe9\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7254\u7ae4\ua473\u2698\u3de8\u3865\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\udb16\ude0d\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\udb22\udd5f",
        15, 50445, 573257731, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.String:\udb87\udd8e\uda58\ude06\ud9b5\udf50\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b\012",
        Z.run(T, 1, 9, 5, 10, "\udb87\udd8e\uda58\ude06\ud9b5\udf50\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u55d5\u39b6\u4e01\u8949", "\ud833\udddc\ud9df\udd17\ud93f\udce7\udafe\udd9c\udadf\udf99\udb11\uddb5\udb95\udc81\ud850\udc5b\udb16\ude0d\ud8c5\udf1f\u23b7\udb8e\udee0\ud849\udfdb\udab3\udc57\udb22\udd5f",
        16, 50445, 573257731, -8153730558795770886L, 95975L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Byte:-5 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ubebe\ud868\udcbb\udb59\udc8a\udaaf\udcb6=\ud6e5\u6b05\u8930\u7afe\ua6af\ucba1\ua791\ua8a3\u5572\uc994\u5c4b\u667b}\012",
        Z.run(T, 2, 15, 3, 10, "\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ubebe\ud868\udcbb\udb59\udc8a\udaaf\udcb6", "\ud6e5\u6b05\u8930\u7afe\ua6af\ucba1\ua791\ua8a3\u5572\uc994\u5c4b\u667b", "\udbf5\udd38\ud86a\udf06\uda5a\ude93\ud802\udfe3\udacc\ude4f\uda2b\udfa1",
        -5, 21595, 308103063, 7169121155802402902L, 82561L, true, false, (char) 24655, (char) 46363,
        Double.longBitsToDouble(0x3f8b03e027592680L), Double.longBitsToDouble(0x3fd424a2042870ceL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 12, 11, 10, "\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ud986\udd06\ud9e3\ude60\ud9e5\uddd9\ud8c3\udff0", "\ud6e5\u6b05\u8930\u7afe\ua6af\u705f\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\udb1d\udc4b\udbaa\udd25\ud8a3\udf8f\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\ud825\udcef\uda45\udf84",
        29, 28237, 573257885, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1bf74781L), Double.longBitsToDouble(0x3fe950e6a7de2febL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b=\ud6e5\u6b05\u8930\u7afe\ua6af\ud783\u0289\ua8a3\u5572\u39b6\uc4d5\u39b1}\0121=java.lang.String:\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b\012",
        Z.run(T, 2, 1, 9, 10, "\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\u6b05\u8930\u7afe\ua6af\ud783\u0289\ua8a3\u5572\u39b6\uc4d5\u39b1", "\ud957\udead",
        35, 56297, -1981960045, -5436667131583951376L, 55755L, false, false, (char) 35170, (char) 47402,
        Double.longBitsToDouble(0x3fc5ba1147409578L), Double.longBitsToDouble(0x3fe3fb346394357eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b=\ud6e5\u6b05\u8930\u2d11\ua6af\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949}\012",
        Z.run(T, 2, 7, 3, 10, "\ud9d4\udef5\uda22\udd61\uda28\udc91\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\u6b05\u8930\u2d11\ua6af\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud9ae\udda8\ud93f\udc8e\udafe\udd9c\udadf\udf99\udb1d\udc4b\udbaa\udd25\ud828\udeb2\uda3d\udc02\ud889\ude39\u233d\udb0e\udee0\ud849\udfdb\ud825\udcef\uda45\udf84",
        31, 28237, 573257885, -8153730557035879916L, -33831L, false, false, (char) 28942, (char) 41519,
        Double.longBitsToDouble(0x3fea2ba053f74781L), Double.longBitsToDouble(0x3febc92e4fde2febL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 12, 12, 10, "\ud9d4\udef5\uda22\udd61\uda28\udc91\ud89d\udf5f\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\u612d\u6b05\u157e\u821a\ubd50\u8b22\u0aa8\ua8a3\u5572\u39b6\u4e01\u8949", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\udb1d\udc4b\uda80\udf70\ud828\udeb2\uda3d\udc02\ud8d7\udf1f\u23b7\uac08\ud849\udfc8\ud825\udcef\uda45\udf84",
        31, 4829, 573257885, -1865880517088321004L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1bf74781L), Double.longBitsToDouble(0x3febc92e4fde2febL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\ud8ea\uded0\ud9d7\udf61\ud97c\udc7b\udb50\ude30\ud877\uddfd\ud854\ude57\udb7c\udd12=\ud6e5\u97a5\u2dcc\u7265\u0b09\ub834\u19bc\u3fdc\u8622\u39b6\u4e01\u5e9f}\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 1, 13, 10, "\udb87\udd8e\ud8ea\uded0\ud9d7\udf61\ud97c\udc7b\udb50\ude30\ud877\uddfd\ud854\ude57\udb7c\udd12", "\ud6e5\u97a5\u2dcc\u7265\u0b09\ub834\u19bc\u3fdc\u8622\u39b6\u4e01\u5e9f", "\udb5f\udd74\ud86a\udf06\u2863\uda7f\udff9\udb14\ude67\udaf2\udedf\udab6\ude59\ud8d2\uddfc\uda35\udf79\udb75\udfde\udb01\udecb\udb0e\udee0\ud881\uddd4\udab3\udc57\ud983\udc40\ud866\uddfc\udb23\uddc7\ud9d6\ude06\udb70\ude96\ud963\udc79\ud941\udda5\ud887\udf0b\ud90c\udefc",
        49, 96307, -1996614594, -5857816606894697046L, 28043L, true, true, (char) 54190, (char) 42955,
        Double.longBitsToDouble(0x3fcd3e6b2d1c34dcL), Double.longBitsToDouble(0x3fe1d2614b1afe57L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\uda36\udd84\012",
        Z.run(T, 1, 9, 8, 10, "\uda36\udd84", "\u6f33\u62f9\u1416\u0489\u1b1f\u9309\u7ab4\u9144", "\ud931\udc08\ud984\udfb7\uda13\udde3",
        50, 87831, 679986500, 221926877849768480L, 12347L, true, true, (char) 51838, (char) 32863,
        Double.longBitsToDouble(0x3fe06c9de0de517fL), Double.longBitsToDouble(0x3f8913bafc296440L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 1, 7, 13, 10, "\udb87\udd8e", "\u3233\u53df\u6929\u04c8\u1b1f\u654f\u9b39\u91e0", "\ud931\udc08\ud97e\ude7e\udbc2\udfe8",
        1, 87727, -444086972, 7884429086727483444L, 83079L, false, true, (char) 61753, (char) 32842,
        Double.longBitsToDouble(0x3f8b277837a39fc0L), Double.longBitsToDouble(0x3f8913bafc296440L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\u3e82=\u2a33\u683e\u4389}\012",
        Z.run(T, 1, 1, 9, 3, "\udb87\udd8e\u3e82", "\u2a33\u683e\u4389", "\ud82c\ude7e\uda75\udeda\udb23\uddb0\ud95a\udddb\udb7c\udeab\uda7a\ude48\ud9e0\ude60\ud9c0\uddc5\udac5\udf32\ud9b9\udfa7\ud9ba\udd80\ud817\udf51\udaf9\udc19\udbf7\ude1f",
        31, 47693, 1941745767, 3330560451017528286L, -27888L, true, true, (char) 8441, (char) 60157,
        Double.longBitsToDouble(0x3fb0ed2f7c755538L), Double.longBitsToDouble(0x3fe32de9ec723c97L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Byte:5 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 14, 13, 10, "\udb6a\udf8e", "\u6f33\u53df\u1416\ubd74\u81c4\u564c\u7a8f\u9144\u7896\u6dfa\u292d\u7b8d\u04a5\ubf42", "\ud8da\udf7b\ud817\udfdf\ud805\udd80\udafe\udc43\ud8ba\udc41\ud957\ude88\ud950\udfd9\ud8f6\udde3",
        5, 66284, 465367024, 4970567443307421290L, -92296L, true, true, (char) 36648, (char) 56862,
        Double.longBitsToDouble(0x3fc8396629f6c694L), Double.longBitsToDouble(0x3fdc10f64daa19d4L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\uda65\udf32\ud930\udfed\u00a0\000\udaae\ude27=\u4701\u7036}\012",
        Z.run(T, 1, 1, 3, 10, "\uda65\udf32\ud930\udfed\u00a0\000\udaae\ude27", "\u4701\u7036", "\ud884\udc71\uda87\uddf4\ud913\udd9a\ud9bb\udcdb\ud923\udd45",
        47, 16360, 943175143, 4339050926212803131L, -25199L, true, false, (char) 64186, (char) 34129,
        Double.longBitsToDouble(0x3fe44247af6f3ed0L), Double.longBitsToDouble(0x3fa16675fc0f4350L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.String:\uda80\udcb3\ud8db\udf5a\uda75\udca2\012",
        Z.run(T, 1, 9, 8, 9, "\uda80\udcb3\ud8db\udf5a\uda75\udca2", "\ubdc7\u9486\ucdd3\ubd26\u7a82\ud6e5\uc183", "\udbc9\udfea\ud95b\udebb",
        -3, 34166, -553893574, -7452493006373729720L, 63742L, true, false, (char) 12228, (char) 44150,
        Double.longBitsToDouble(0x3fe928ac8ad1a1b5L), Double.longBitsToDouble(0x3feb413d1f8bf42cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\udb8f\udeed\udac8\udca9\ud8c4\udcb6\uda84\udd00\udae3\udca3\ud975\udfc1\ud8a5\ude9f\ud953\udd00\uda28\ude57\uda90\udcf1\u04de\udb99\udfd4\udbc6\udf90\udab4\udc60\ud824\udd80\ud9a3\uddeb\ud803\ude09\udb94\udf58\uda1b\ude37\ud862\udf54\ud812\udfad\ud9ae\udc94\ud901\udf90\ud8e5\ude91\udbac\udcec\ud954\uddfa\ud93f\udc8e\uda32\udd96\ud93c\udf66\udb51\udf41\ud8fc\udf88\ud996\udf45\ud876\udcd1\ud8d7\udf1f\ud860\udcdf\012",
        Z.run(T, 1, 9, 13, 6, "\udb8f\udeed\udac8\udca9\ud8c4\udcb6\uda84\udd00\udae3\udca3\ud975\udfc1\ud8a5\ude9f\ud953\udd00\uda28\ude57\uda90\udcf1\u04de\udb99\udfd4\udbc6\udf90\udab4\udc60\ud824\udd80\ud9a3\uddeb\ud803\ude09\udb94\udf58\uda1b\ude37\ud862\udf54\ud812\udfad\ud9ae\udc94\ud901\udf90\ud8e5\ude91\udbac\udcec\ud954\uddfa\ud93f\udc8e\uda32\udd96\ud93c\udf66\udb51\udf41\ud8fc\udf88\ud996\udf45\ud876\udcd1\ud8d7\udf1f\ud860\udcdf", "\u1603\u506d\uaffe\uc0c6\u1166\u1325\u51f7\u8a75\u8b21\u23a9\u1bad\u6019\u8db6\u8968\u5bd7\u1338\u458d\u2f98\u0c1c", "\udb3f\udefa",
        21, 11208, -1251545662, -1397905215844322122L, 61972L, false, false, (char) 37394, (char) 22772,
        Double.longBitsToDouble(0x3fcfcc00e736c51cL), Double.longBitsToDouble(0x3fd7f56c6222b532L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\udb8f\udeed\udac8\udca9\uda9d\udc81\uda67\udfc3\udabf\udf5e\ud9e3\uddea\\,\ud953\udd00\ud9f5\udd1a\u3790\000\udb94\udda9\uda58\uddf9\ud931\udc08\ud984\udfb7\ud9a3\uddeb\udae5\uddfa\u00cf\uda1b\ude37\000\000\ud980\udf1f\u1e73\udb23\uddd1\udbac\udd17\ud954\uddfa\012",
        Z.run(T, 1, 9, 13, 6, "\udb8f\udeed\udac8\udca9\uda9d\udc81\uda67\udfc3\udabf\udf5e\ud9e3\uddea,\ud953\udd00\ud9f5\udd1a\u3790\000\udb94\udda9\uda58\uddf9\ud931\udc08\ud984\udfb7\ud9a3\uddeb\udae5\uddfa\u00cf\uda1b\ude37\000\000\ud980\udf1f\u1e73\udb23\uddd1\udbac\udd17\ud954\uddfa", "\u93ec", "\ud850\udc5b\ud95f\udfc5\000\000\000\000\000\uda45\udf31\uda7f\udc91\udb23\ude62\uda7f\udcda\udb70\ude96\ud868\udd74\ud941\udda5\ud887\udf0b\uda8c\udcfc",
        36, 42613, -364430225, 5405098271951905223L, 78250L, true, false, (char) 7234, (char) 62290,
        Double.longBitsToDouble(0x3fe102f66474a5e8L), Double.longBitsToDouble(0x3fd8eecbd7a09cd6L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb8f\udeed\udac8\udca9\uda9d\udc81\uda67\udfc3\udae3\udca3\ud9e3\uddea\uda73\udf59\ud953\udd00\uda28\ude57\uda90\udcf1\ud96b\udfe2\udb99\udfd4\uda58\uddf9\ud931\udc08\ud984\udfb7\ud9a3\uddeb\ud803\ude09\uda40\udd62\uda1b\ude37\ud862\udf54\ud812\udfad\ud9ae\udc94\ud901\udf90\ud97f\udf79\udbac\udd17\ud954\uddfa=\ua8be\u1809\u05bf\u2397\u3c2b\u402d\u4e43\ua069\u9938\u1603\u0d77\uaffe\uc0c6\u1166\u1325\u51f7\u8a75\u8b21\u4507\ub61a\u6a05\u7bcf\u81ea}\012",
        Z.run(T, 1, 1, 13, 6, "\udb8f\udeed\udac8\udca9\uda9d\udc81\uda67\udfc3\udae3\udca3\ud9e3\uddea\uda73\udf59\ud953\udd00\uda28\ude57\uda90\udcf1\ud96b\udfe2\udb99\udfd4\uda58\uddf9\ud931\udc08\ud984\udfb7\ud9a3\uddeb\ud803\ude09\uda40\udd62\uda1b\ude37\ud862\udf54\ud812\udfad\ud9ae\udc94\ud901\udf90\ud97f\udf79\udbac\udd17\ud954\uddfa", "\ua8be\u1809\u05bf\u2397\u3c2b\u402d\u4e43\ua069\u9938\u1603\u0d77\uaffe\uc0c6\u1166\u1325\u51f7\u8a75\u8b21\u4507\ub61a\u6a05\u7bcf\u81ea", "\uda5f\udd7f",
        30, 22526, -1602798847, -8955223700441931810L, 19056L, false, true, (char) 63866, (char) 58289,
        Double.longBitsToDouble(0x3fd09fc4e3cd0df2L), Double.longBitsToDouble(0x3fd848531801d7e2L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\uda9b\udc37\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\udb27\udec9\ud8e3\ude80\ud996\udede=\ud70b\ucd99\u6dfa\u7265\u8348\u8864\u2aa1\u9ed9\u36a9\u5729\u1910\uccbe\u6022\u7e2c\uc901\u8c3c\ua4df\u848f}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\uda9b\udc37\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\udb27\udec9\ud8e3\ude80\ud996\udede=false}\012",
        Z.run(T, 2, 1, 10, 10, "\uda9b\udc37\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\udb27\udec9\ud8e3\ude80\ud996\udede", "\ud70b\ucd99\u6dfa\u7265\u8348\u8864\u2aa1\u9ed9\u36a9\u5729\u1910\uccbe\u6022\u7e2c\uc901\u8c3c\ua4df\u848f", "\ud96c\udd47\ud850\udc5b",
        -4, 17542, -796254362, 2692757497731400144L, 51283L, true, false, (char) 17261, (char) 39660,
        Double.longBitsToDouble(0x3fb4ce7efc3e9468L), Double.longBitsToDouble(0x3fd3b24e711ecbe6L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 7, 7, 14, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud8cf\udf04\ud968\udcb7\udaf3\udf6f\ud8c4\udda2\uda93\udd1b\ud820\udfd2\ud82c\ude7e\ud997\udc04\u5eda\ud908\udde0\ud912\udd17\ud984\udfb7", "\u9d85", "\ud811\ude78\udb82\udde9",
        20, 88479, -805806934, -6576187397885704423L, 28208L, false, false, (char) 4389, (char) 2931,
        Double.longBitsToDouble(0x3fe4199540add08aL), Double.longBitsToDouble(0x3fe19ee2f37f37faL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 10, "\udb77\udde5\ud878\uded8\ud9a3\udffc\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\u8b5f", "\ud957\udead\ud86a\udf06\ud93f\udc75\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc43\uda3d\udc02\ud8d7\udf1f\u23b7\udb0e\udee0\ud902\uddd8\ud8a8\udcd3",
        4, 64576, 1346482445, 2462123205096776002L, -5709L, true, true, (char) 20488, (char) 52238,
        Double.longBitsToDouble(0x3fe8000007d52963L), Double.longBitsToDouble(0x3fe23236dcaaaeb4L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb66\udd4e\ud848\udd9f\ud9a3\udffc\ud807\ude60\ud959\udd71\ud9e3\ude13\ud8c4\udda2\uda93\udd1b=\ud6e5\u7d82\u3d6e\u7265\u06a7\u3833\u6ac6\ua8a3\u5572\u39b6\u4e01\u8b5f}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\udb66\udd4e\ud848\udd9f\ud9a3\udffc\ud807\ude60\ud959\udd71\ud9e3\ude13\ud8c4\udda2\uda93\udd1b=[\ud6e5\u7d82\u3d6e\u7265\u06a7\u3833\u6ac6\ua8a3\u5572\u39b6\u4e01\u8b5f, \ud6e5\u7d82\u3d6e\u7265\u06a7\u3833\u6ac6\ua8a3\u5572\u39b6\u4e01\u8b5f]}\012",
        Z.run(T, 2, 3, 3, 13, "\udb66\udd4e\ud848\udd9f\ud9a3\udffc\ud807\ude60\ud959\udd71\ud9e3\ude13\ud8c4\udda2\uda93\udd1b", "\ud6e5\u7d82\u3d6e\u7265\u06a7\u3833\u6ac6\ua8a3\u5572\u39b6\u4e01\u8b5f", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd0e\ud850\udc5b\uda3d\udc02\udbf0\udf7c\ud94a\udffd\udb0e\udee0\ud849\udfdb\udab3\udc57\uda41\udfac",
        31, 50445, 573257731, -7419080867830745319L, -33831L, false, false, (char) 28942, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc535d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb77\udde5\ud878\uded8=\u05f2\u3dec\u9191\u0599\u932c}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\udb77\udde5\ud878\uded8=\u05f2\u3dec\u9191\u0599\u932c}\012",
        Z.run(T, 2, 2, 7, 10, "\udb77\udde5\ud878\uded8", "\u05f2\u3dec\u9191\u0599\u932c", "\u5eda\uda58\ude51\ud931\udc08\ud984\udfb7\uda13\udde3\ud999\udc35",
        51, 51489, 571765074, -3433785275095075467L, 20417L, false, true, (char) 32863, (char) 60373,
        Double.longBitsToDouble(0x3fc26b93f0322774L), Double.longBitsToDouble(0x3fef85a46cd06b54L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Byte:31 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Byte:31 |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 15, 14, 3, "\udb77\udde5\ud878\uded8\ud9a3\udffc\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\udb89\udf95", "\ud6e5\ucd99\u6dfa\ud28e\uc5f3\u5897\ubbcf\ua8a3\ua431\u543c\u4e01\u8b5f", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\uda0e\udf3b\ud960\udc74\udaf0\udd3d\ud849\udfdb\udab3\udc57\uda45\udf31",
        31, 50445, -999328765, -7408440876621017575L, -33831L, false, false, (char) 55822, (char) 63262,
        Double.longBitsToDouble(0x3fd416b314c26adaL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud81d\udcbe\ud936\udd45=\uad86\u3dec\u9191\u733b\u4999\u4c73\u0986\u9630\u6dc6\u7265\u7ae4\u4730\uc6de\ua8ea\u369f\u9d41\ua410\u898b\u6003\u738f\u348c\u2eb1\u6f63\uaf9e\ub29f\ubb24\u0570\u2397\u5bf1\u402d\ud6a0\u54f7\ud1b1}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 10, "\ud81d\udcbe\ud936\udd45", "\uad86\u3dec\u9191\u733b\u4999\u4c73\u0986\u9630\u6dc6\u7265\u7ae4\u4730\uc6de\ua8ea\u369f\u9d41\ua410\u898b\u6003\u738f\u348c\u2eb1\u6f63\uaf9e\ub29f\ubb24\u0570\u2397\u5bf1\u402d\ud6a0\u54f7\ud1b1", "\udb6e\uded6\ud9c1\udc37\ua722",
        20, 18447, -762482605, -7927745439725755890L, -9231L, false, true, (char) 44648, (char) 35644,
        Double.longBitsToDouble(0x3fdb674d238f824eL), Double.longBitsToDouble(0x3fc9af248c240ea0L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2=\u3be1\u097c\u9630\u9128\u1f02}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 1, 4, 7, "\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2", "\u3be1\u097c\u9630\u9128\u1f02", "\ud8ed\udefe\ud845\ude39\ud832\udf0a\ud982\udd71\ud86a\ude6e\ud99a\udded\ud902\udf9b\udab5\udc4b\ucc0b\udbbc\udd96\uda6f\ude89\udaea\udd0e\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b",
        22, 85579, 1826195075, -7311429173945515738L, 44591L, true, true, (char) 30403, (char) 58255,
        Double.longBitsToDouble(0x3fb4ce682c3e9468L), Double.longBitsToDouble(0x3fe0748fd451caebL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Byte:22 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 0, 10, "\ud9fe\udd09\ud931\udd07\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2", "\u4be9\u0986\u9630\u6dc6\u7265", "\ud8ed\udefe\ud845\ude39\ud832\udf0a\ud982\udd71\ud86a\ude6e\ud99a\udded\ud902\udf9b\udab5\udc4b\ucc0b\udbbc\udd96\uda6f\ude89\udaea\udd0e\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b",
        22, 85579, -791050621, 2692757497093865936L, 44591L, true, true, (char) 30259, (char) 58255,
        Double.longBitsToDouble(0x3fb4ce682c3e9468L), Double.longBitsToDouble(0x3fe0748fd582caebL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2=\u4be9\u0986\u9630\u6dc6\u7265}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2=[\u4be9\u0986\u9630\u6dc6\u7265, \u4be9\u0986\u9630\u6dc6\u7265]}\012",
        Z.run(T, 2, 1, 1, 10, "\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2", "\u4be9\u0986\u9630\u6dc6\u7265", "\ud8ed\udefe\ud845\ude39\ud832\udf0a\ud982\udd71\ud86a\ude6e\ud99a\udded\ud902\udf9b\udab5\udc4b\ucc0b\uda98\udec4\uda6f\ude89\udaea\udd0e\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b",
        22, 85579, -791050621, 2692757497731400144L, 44591L, true, true, (char) 30403, (char) 58255,
        Double.longBitsToDouble(0x3fb4ce682c3e9468L), Double.longBitsToDouble(0x3fe0748fd451caebL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2=\ud584\u3369\u9630\u6dc6}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2=\ud584\u3369\u9630\u6dc6}\012",
        Z.run(T, 2, 1, 2, 10, "\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7\ud8c4\udda2", "\ud584\u3369\u9630\u6dc6", "\uda13\udde3\ud8ed\udefe\ud806\udc83\ud81c\udf9a\ud982\udd71\ud86a\ude6e\ud99a\udded",
        4, 60135, 960874667, -7350983338974299367L, 91476L, false, true, (char) 24612, (char) 57889,
        Double.longBitsToDouble(0x3fe611331c23153fL), Double.longBitsToDouble(0x3fe4199540add0d9L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 10, "\udb87\udd8e\ud8ea\uded0\uda60\udc25\ud990\uddf0\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\u43ae\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u7f95\ubb47\u6003\uce71\u9894\u0edf\ubd46\u848f\ub29f\ubb24\u05bf\u2397\u5bf1\u402d\u4e43\u54f7\ucb5a\u0485\u506d\u0bd7\uc02b\u3882", "\ud941\udd7b\ud887\udf0b\ud90c\udefc\udab1\udc65\udade\udf5c\udbf9\udfd1\udb25\udd4b\ud811\udd7b\ud8e5\udd38\ud9cd\uddf9\udb0c\ude95\uda81\uddd9",
        -1, 47240, 2012900764, -3325237165274393693L, 52276L, false, false, (char) 33423, (char) 22502,
        Double.longBitsToDouble(0x3fd51e37b536525cL), Double.longBitsToDouble(0x3fd4fb166f22cc04L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 4, 4, 12, "\udb87\udd8e\ud8ea\uded0\ud97b\udeba\u7560", "\uac2c\u05dd\u932c", "\u5eda\uda58\ude51\ud931\udc08\udbaf\udd6c\ud906\udeca\u8e3c",
        59, 18276, 266892882, -5412780991049098526L, -99967L, true, false, (char) 19011, (char) 4959,
        Double.longBitsToDouble(0x3fc26b93fedee774L), Double.longBitsToDouble(0x3fe6a08dfc4d20f6L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 11, 11, 10, "\udb87\udd8e\ud8ea\uded0\ud97b\udeba\u7560\uda25\udcb8\uda6a\udf13\u0f4d\ud971\udd8b", "\ud6e5\ucd99\u6dfa\u7265\u7543\uc5f0\u0b31\ua8a3\uba46\u992c\u2d44\u2383", "\ud896\udc7c\uda36\udd3e\ud94e\udc04\udba7\udc70\udafe\udcc2\ud915\udcc5\uda92\udeb8\ud999\udcf5\udb16\udde0\ud8d7\udf1f",
        -5, 48461, 1720500688, 1034987332569908263L, 51283L, true, false, (char) 17261, (char) 29164,
        Double.longBitsToDouble(0x3fb40e6808c5f180L), Double.longBitsToDouble(0x3fcff704dceb51b8L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Byte:57 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Byte:57 |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 14, 14, 11, "\ud8fe\udfca\ud8ea\uded0\uda55\uddfa\ud97c\udd23\udb50\ude30\ud877\uddfd\ud854\ude57\udb7c\udd12", "\ud6e5\u97a5\u2dcc\u7265\u0b09\ub834\u19bc\u3fdc\u8622\u39b6\u4e01\u5e9f", "\udb5f\udd74\ud86a\udf06\u2863\uda7f\udff9\udb14\ude67\udbc0\udee6\udab6\ude59\ud8d2\uddfc\uda35\udf79\ud9aa\udfe0\udb01\ude6f\udb0e\udee0",
        57, 90767, -374305391, -9083750096188624627L, -91486L, false, true, (char) 43507, (char) 53268,
        Double.longBitsToDouble(0x3fe0748fd523cbebL), Double.longBitsToDouble(0x3fef5bd99c3e2963L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e=\u9d63\u8df6\u7071\u76e7\u30a3\u1da3\u1109\ub9cc\uaee7\u9128\ucc0a\u39b4\u2342\u5cb4\ua8ea\u5dbb\u4a1a\u9b43\u898b\u6003\u5b68\u6f00\u2ed9\u6f63\u3401\ub29f\u50f5\u222e\u6207\u7a7a\u0688\u4e33\uc429\ucab0\u405f\uc576\uc712}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\udb87\udd8e=[\u9d63\u8df6\u7071\u76e7\u30a3\u1da3\u1109\ub9cc\uaee7\u9128\ucc0a\u39b4\u2342\u5cb4\ua8ea\u5dbb\u4a1a\u9b43\u898b\u6003\u5b68\u6f00\u2ed9\u6f63\u3401\ub29f\u50f5\u222e\u6207\u7a7a\u0688\u4e33\uc429\ucab0\u405f\uc576\uc712, \u9d63\u8df6\u7071\u76e7\u30a3\u1da3\u1109\ub9cc\uaee7\u9128\ucc0a\u39b4\u2342\u5cb4\ua8ea\u5dbb\u4a1a\u9b43\u898b\u6003\u5b68\u6f00\u2ed9\u6f63\u3401\ub29f\u50f5\u222e\u6207\u7a7a\u0688\u4e33\uc429\ucab0\u405f\uc576\uc712]}\012",
        Z.run(T, 2, 1, 1, 5, "\udb87\udd8e", "\u9d63\u8df6\u7071\u76e7\u30a3\u1da3\u1109\ub9cc\uaee7\u9128\ucc0a\u39b4\u2342\u5cb4\ua8ea\u5dbb\u4a1a\u9b43\u898b\u6003\u5b68\u6f00\u2ed9\u6f63\u3401\ub29f\u50f5\u222e\u6207\u7a7a\u0688\u4e33\uc429\ucab0\u405f\uc576\uc712", "\ud85b\udd67\ud951\udc7c\ud93f\udca5\ud887\udf0b\ud8ae\udeed",
        6, 73840, 1412770536, 8506878322043334458L, 18719L, true, false, (char) 64125, (char) 28375,
        Double.longBitsToDouble(0x3fe9da80cfc4fb29L), Double.longBitsToDouble(0x3fbec2c796a54600L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=java.lang.String:\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\udb94\udc19\ud8c4\udda8\0121=java.lang.String:\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\udb94\udc19\ud8c4\udda8\012",
        Z.run(T, 2, 9, 9, 7, "\udb87\udd8e\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\udb94\udc19\ud8c4\udda8", "\u3be1\u097c\u9630\u9128\u1f02", "\ud8ed\udefe\ud845\ude39\ud832\udf0a\ud982\udd71\ud86a\ude6e\ud99a\udded\ud902\udf9b\udab5\udc4b\ucc0b\udbbc\udd96\uda6f\ude89\udbd2\udddf\udade\ude6e\ud8b0\ude43\ud96c\udd47\ud850\udc5b",
        22, 85579, 1826195075, -7311429173945515738L, -5232L, false, true, (char) 30369, (char) 58255,
        Double.longBitsToDouble(0x3f9d55a0b0fa51a0L), Double.longBitsToDouble(0x3fe0748fd451caebL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 1, 6, 13, 10, "\udb87\udd8e\ud8ea\uded0\udaf8\udc12\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\ud6e5\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u4e01\ubcd7", "\ud957\udead\ud86a\udf06\ud93f\udc8e\udafe\udd9c\udadf\udf99\ud8b0\ude43\ud96c\udd47\ud850\udc5b\uda3d\udc02\ud8d7\udf1f\u23b7\udaa7\udc2c\udb2d\ude25\udbcd\udf56\uda45\udf31",
        31, 50445, 590034947, -8153729874136079852L, -33831L, false, false, (char) 46051, (char) 48926,
        Double.longBitsToDouble(0x3feea94b1a4646dbL), Double.longBitsToDouble(0x3fc555d69d500928L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.String:\000\012",
        Z.run(T, 1, 9, 9, 10, "\000", "", "",
        26, 30020, -2137758562, -3541292294127208560L, -2793L, false, false, (char) 7926, (char) 63275,
        Double.longBitsToDouble(0x3feec8d994d8690bL), Double.longBitsToDouble(0x3fe4ed7da7a88784L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 10, "\udb77\udde5\ud878\uded8\ud9a3\udffc\ud807\ude60\ud959\udd71\ud9e3\udde7\udab0\udeb7\ud8b1\udeb3", "\u4ba3\ubd58\u18bb\ua350\uc454\ucba1\ubbcf\u2b35\ud0ae\u71d1\u8730\u7f59", "\ud957\udead\ud86a\udf06\ud859\udca6\ud868\udda2\udadf\udf99\ud8b0\ude43\ud928\udec4\ud850\udcfa\uda3d\udc02\ud850\udc24\ud9bc\udc05\ud9ee\udeed\ud908\ude14\udab3\udc57\uda45\udf31\ud866\uddd2\udb23\uddc7\ud9d6\ude06\udaa4\udf30\udac8\ude75\ud941\udda5\ud887\udf0b\ud90c\udefc\ue469\ud973\ude5b\udbf7\udc01",
        41, 7418, -350792855, 7606343154029209622L, -81981L, true, false, (char) 58987, (char) 65397,
        Double.longBitsToDouble(0x3fe6262c6b389cfaL), Double.longBitsToDouble(0x3fc52f8e9f5f03fcL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.Byte:4 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Byte:4 |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 15, 15, 10, "\udb87\udd8e\ud914\udfb8\udb9f\udcb4\uda8b\ude41\u7d35\ud9e3\udde7\ud8c4\udda2", "\u4be9\u85ab\u7675\u5cab\ucb65", "\ud8ed\udefe\udba7\udc0a\ud8d8\udcd1\uda2d\udc6b\uda35\udf3d\uda0d\udfde\uda10\udda7\udab5\udc6f\ucc0b\udbbc\udd96\ud8a5\udfe5\ud881\udf45\u3e48\ud8b0\ude1a\ud96c\udd47\ud9b0\udeb2\uda3d\udc02\ud8d7\udf1f\uda92\udfbb\udb0e\udee0\ud849\udfdb\udaf7\udcc6\uda90\udf19\u7abc",
        4, 69679, -763830250, 4152337646155034707L, -83118L, true, false, (char) 16511, (char) 56292,
        Double.longBitsToDouble(0x3fd220886f6b2ca2L), Double.longBitsToDouble(0x3fe36a8002943ea7L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.ExtendedProperties:{}\0121=null |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 15, 15, 8, "\udb87\udd8e\ud8ea\uded0\ud9a4\udc07\ud807\ude60\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b\uda28\ude86\ud82c\ude7e\ud9ac\udf6f\ud8f3\udda6\ud86a\udec6", "\uc6b7\ub06b\uc752\u5572\u39b6\u4e01\u9310", "\ud8bd\udd00\udb20\udcb1\ud933\uddd0\ud8b0\ude0b\ue4ed\ud8b0\ude43\ud87e\udcfa\udb50\udf04\udb06\udce6\udac2\udeb8\ud805\ude68\udb6b\udf8b\ud8da\udf19\ud85a\udd6a\ud8f7\uddd7",
        36, 49145, 573257860, 6867463048658957336L, -76739L, true, true, (char) 34872, (char) 3001,
        Double.longBitsToDouble(0x3fe4edccf859a5baL), Double.longBitsToDouble(0x3fe5e87cb5414a88L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3dec, \u738e\u096b\u097cP\000\u0af7\u7ae4\ucba1]}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 1, 4, 7, "", "\ud61e\u8715\u5134\u3dec,\000\u738e\u096b\u097cP\000\u0af7\u7ae4\ucba1", "\ud9ab\uddfe\ud982\udd71\ud86a\ude6e\ud99a\udded\ud98e\ude80\udab5\udc4b\ucc0b\udbbc\udd96\uda6f\ude89\udaea\udd0e\udadf\udf8d\u00f0\ud92f\udc77\ud850\udc5b\uda3d\udc02\ud8d7\udf1f",
        50, 29239, 1720500518, 3701118311352484903L, 44591L, true, true, (char) 30403, (char) 58255,
        Double.longBitsToDouble(0x3fb4ce682c3e9468L), Double.longBitsToDouble(0x3fe0748fd451caebL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3df2, \u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1]}\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 12, 7, "", "\ud61e\u8715\u5134\u3df2,\u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1", "\ud9ab\uddfe\ud982\udd71\ud86a\ude6e\ud99a\udded\ud98e\ude80\udab4\udfe6\ud959\udefd\ub2c2\uda6f\ude89\udaea\udd0e\udadf\udf8d\u00f0\ud92f\udc77\ud850\udc5b\uda3d\udc02\ud8d7\udf1f",
        50, 29239, 1720500518, 3701118311352484903L, -37329L, false, true, (char) 37137, (char) 51430,
        Double.longBitsToDouble(0x3fd966a83b0fa33eL), Double.longBitsToDouble(0x3fe0748fd451ca53L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\udafa\uddc1\ud914\udfb8\udb9f\udcb4=\u3dec}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 1, 4, 1, "\udafa\uddc1\ud914\udfb8\udb9f\udcb4", "\u3dec,", "\u15c9\ud999\ude9aP\000\ud971\uddb7\ud92d\udd90\uda13\udde3\ud8ed\udefe\udb27\udfe9\ud9ab\uddb7\ud982\udd71\udb49\udfff\udba3\udede",
        56, 60135, 960874667, -7350983338974299367L, 91488L, false, false, (char) 0, (char) 57889,
        Double.longBitsToDouble(0x3fea01331c23153fL), Double.longBitsToDouble(0x3fec1993dde77a5aL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3dec, \u738e\u096b\u7388P\000\u0af7\u7a78\ucba1]}\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 13, 7, "", "\ud61e\u8715\u5134\u3dec,\000\u738e\u096b\u7388P\000\u0af7\u7a78\ucba1", "\uda55\udf13\u6998\ud86a\ude6e\ud99a\udded\ud98e\ude80\udab5\udc4b\ucc0b\udbbc\udd96\uda6f\ude89\udaea\udd0e\udadf\udf8d\u00f0\ud92f\udc77\ud8a6\udc23\uda2a\udf4d\ud8d7\udf1f",
        50, 29239, 1720500518, 3701118311352484903L, 44591L, true, true, (char) 30403, (char) 58255,
        Double.longBitsToDouble(0x3fb4ce682c3e9468L), Double.longBitsToDouble(0x3fe0748fd45141ebL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3df2, \u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1]}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3df2, \u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1, \ud61e\u8715\u5134\u3df2,\u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1]}\012",
        Z.run(T, 2, 1, 3, 7, "", "\ud61e\u8715\u5134\u3df2,\u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1", "\ud9ab\uddfe\ud982\udd71\ud86a\ude6e\ud99a\udded\ud98e\ude80\udab4\udfe6\ud959\udefd\ub2c2\uda6f\ude89\udaea\udd0e\udadf\udf8d\u00f0\ud92f\udc77\ud850\udc5b\uda3d\udc02\ud8d7\udf1f",
        50, 29239, 1720500518, 3701118311352484903L, -37329L, false, true, (char) 37137, (char) 51430,
        Double.longBitsToDouble(0x3fd966a83b0fa33eL), Double.longBitsToDouble(0x3fe0748fd451ca53L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ua7ff\u8715\u5134\u3dec, \u738e\u096b\u6891, \u0af7\u7a78\u0642]}\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 13, 7, "", "\ua7ff\u8715\u5134\u3dec,\000\u738e\u096b\u6891,\000\u0af7\u7a78\u0642", "\uda55\udf13\u6998\ud86a\ude6e\ud99a\udded\ud98e\ude80\udab5\udc4b",
        7, 10818, -1298187495, -8512542147335089152L, -34464L, false, false, (char) 15611, (char) 35170,
        Double.longBitsToDouble(0x3fe608fd45e73ed9L), Double.longBitsToDouble(0x3fd269a886fecd18L)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3df2, \u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1]}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3df2, \u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1, \ud61e\u8715\u5134\u3df2, \u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1]}\012",
        Z.run(T, 2, 1, 1, 13, "", "\ud61e\u8715\u5134\u3df2,\u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1", "\ud9ab\uddfe\ud982\udd71\ud86a\ude6e\ud99a\udded\ud98e\ude80\ud85d\udf19\uda25\ude50\ub23a\uda6f\ude89\udaea\udd0e\udadf\udf8d\u00f0\ud92f\udc77\ud850\udc5b\uda3d\udc02\ud8d7\udf1f",
        50, 29239, 1720500518, -5161965755312651225L, 18620L, true, false, (char) 49895, (char) 51430,
        Double.longBitsToDouble(0x3fd966a83b0fa33eL), Double.longBitsToDouble(0x3fe0748fd451ca53L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 6, 6, 1, "\udb87\udd8e\ud8ea\uded0\uda60\udc25\ud990\uddf0\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\u43ae\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u7f95\ubb47\u6003\uce71\u809f\u0edf\ubd46\ubd73\uc167\u43da\u054d\u2397\u5bf1\u402d\u4e43\u54f7\ucb5a\u0485\u506d\u0bd7\uc02b\u3882", "\ud941\udd7b\ud887\udf0b\uda2f\udf85\udba5\uddd7\udade\udf5c\udbf9\udfd1\udb25\udd4b\ud811\udd7b\ud8e5\udd38\ud9cd\uddf9\uda65\udde2\uda81\ude8d\ud854\udd47",
        -3, 70764, -134162837, -9086975821121441776L, -11944L, true, true, (char) 22502, (char) 16589,
        Double.longBitsToDouble(0x3fe2396c314fb166L), Double.longBitsToDouble(0x3fec8b301779240fL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=\ud61e\u8715\u5134\u3df2\\\u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{=false}\012",
        Z.run(T, 2, 1, 12, 3, "", "\ud61e\u8715\u5134\u3df2\\\u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1", "\udb09\udf4c\ud90b\udde0\ud86a\ude6e\ud99a\udded\ud98e\ude80\udab4\udfe6\udb54\udd9c\ub2c2\uda6f\ude89\udaea\udd0e\udadf\udf8d\u00f0\ud92f\udc77\udb21\udd27\ud90e\udc1f\ud932\udf18",
        44, 29239, 1720500518, 3701118311352484903L, -37329L, true, false, (char) 37137, (char) 51430,
        Double.longBitsToDouble(0x3fd966a83a3a273eL), Double.longBitsToDouble(0x3f8d23f514639200L)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ub881\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7,=\u096b}\0121=java.lang.Byte:5 |this=org.apache.commons.collections.ExtendedProperties:{\ub881\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7,=5}\012",
        Z.run(T, 2, 1, 13, 7, "\ub881\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udde7,", "\u096b", "\000\ud971\uddb7\ud984\udf4b\uda13\udde3\ud8ed\udefe\ud9ad\ude2d\uda55\udf13\u6998\ud86a\ude6e\ud99a\udded\ud98e\ude80\udab5\udc4b\ucc0b\udbbc\udd96\uda6f\ude89\udaea\udd0e\udadf\udf8d\u00f0\ud92f\udc77\ud8a6\udc23",
        -1, 85579, 1826195075, -7311429173945515738L, 44591L, true, true, (char) 30403, (char) 58255,
        Double.longBitsToDouble(0x3fb4ce682c3e9468L), Double.longBitsToDouble(0x3fe0748fd45141ebL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 6, 6, 1, "\ue587\ud8ea\uded0\uda60\udc25\ud990\uddf0\ud959\udd71\ud9e3\udde7\ud8c4\udda2\uda93\udd1b", "\u43ae\ucd99\u6dfa\u7265\u7ae4\ucba1\ubbcf\ua8a3\u5572\u39b6\u7f95\ubb47\u7b7e\uce2b\uc3a5\u35b2\ubda8\ubd73\u611c\u43f6\u054d\u2397\u5bf1\u402d\u4e43\u54f7\ucb5a\u0485\u506d\u0bd7\uc02b\u9d09", "\ud97f\udcb9\ud887\udf0b\uda2f\udf85",
        3, 3595, 1188789157, 8137809518009054546L, 79723L, false, true, (char) 17788, (char) 45514,
        Double.longBitsToDouble(0x3fd28eac7b385162L), Double.longBitsToDouble(0x3fe35bbfd3a3f800L)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=\ud5f8\ud399\u5134\u3df2\\\u8ec5\u0c2e}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud5f8\ud399\u5134\u3df2\\\u8ec5\u0c2e, \ud5f8\ud399\u5134\u3df2\\\u8ec5\u0c2e]}\012",
        Z.run(T, 2, 1, 1, 3, "", "\ud5f8\ud399\u5134\u3df2\\\u8ec5\u0c2e", "P\ud953\udcde\ud923\udf6d\udac0\udfc8\uda10\udcb6\ud8ed\udefe\ud9ad\ude2d\udb2f\udf8f\udbc0\udd07\ud8c5\uddaf\ud99a\udded\ud98e\ude80\udab4\udfe6\udb54\udd9c",
        27, 65505, -1981980667, -5436667184933764880L, -99512L, false, true, (char) 8171, (char) 20708,
        Double.longBitsToDouble(0x3fde76c0f226d510L), Double.longBitsToDouble(0x3febfb346427335dL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\u98e6\udae1\udc34\udb67\udcbb\udb4f\udcb5\ud8ae\ude59\ud811\ude3b,\000\u2e25\udad6\udfca\udaab\udc74,\000\ubf58\ud984\udf4c\ud978\udeb7\ud9c8\udcf2\ud827\udc86\ud900\udf28\u6998\ud87e\ude6e\ud99a\udded\ud9a4\ude8b\udab5\udc4b\ucc0b\udbbc\udd96=\ubfe9\u59e4}\0121=java.lang.String:\u98e6\udae1\udc34\udb67\udcbb\udb4f\udcb5\ud8ae\ude59\ud811\ude3b\\,\000\u2e25\udad6\udfca\udaab\udc74\\,\000\ubf58\ud984\udf4c\ud978\udeb7\ud9c8\udcf2\ud827\udc86\ud900\udf28\u6998\ud87e\ude6e\ud99a\udded\ud9a4\ude8b\udab5\udc4b\ucc0b\udbbc\udd96\012",
        Z.run(T, 2, 1, 9, 7, "\u98e6\udae1\udc34\udb67\udcbb\udb4f\udcb5\ud8ae\ude59\ud811\ude3b,\000\u2e25\udad6\udfca\udaab\udc74,\000\ubf58\ud984\udf4c\ud978\udeb7\ud9c8\udcf2\ud827\udc86\ud900\udf28\u6998\ud87e\ude6e\ud99a\udded\ud9a4\ude8b\udab5\udc4b\ucc0b\udbbc\udd96", "\ubfe9\u59e4", "\uda2a\udf4d\uda59\ude00\ud88c\ude75",
        14, 23500, 812974975, 3241063662663578759L, -20666L, false, false, (char) 2374, (char) 32779,
        Double.longBitsToDouble(0x3feac2e9dacf7707L), Double.longBitsToDouble(0x3fd2aa88f7ff94acL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 6, 6, 0, "\ue587\ud8ea\uded0\uda60\udc25\ud990\uddf0\ud959\udd71\013\000\000", "\u43ae", "",
        -5, -1000, 0, -7191122705003839407L, -100000L, false, false, (char) 34061, (char) 0,
        Double.longBitsToDouble(0x3fd591100879b724L), Double.longBitsToDouble(0x3fa36160f7b740d0L)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=java.lang.Byte:44 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.String:\udbf2\udf39\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udded\\\\\012",
        Z.run(T, 2, 14, 9, 3, "\udbf2\udf39\ud914\udfb8\udb9f\udcb4\ud80d\ude42\u7d35\ud9e3\udded\\", "\u08d9\u097cP\u55e2\u2c39\u98fb", "\ud9ad\ude2d",
        44, 31040, 1692732540, -4630907994234084738L, -85835L, false, true, (char) 29044, (char) 4773,
        Double.longBitsToDouble(0x3f413ba3c2d23400L), Double.longBitsToDouble(0x3e48631024000000L)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 11, 8, 14, "\udbf2\udf39\ud914\udfb8\udae3\udcaf\ud80d\ude42\u7d35\ud9e3\udded\\", "\u08d9\u8d61\u0790\u6d89\u2c39\u98fb", "\ud9ad\ude2d",
        44, 31040, 1692910696, -4630907994234084738L, -85835L, false, true, (char) 29044, (char) 4773,
        Double.longBitsToDouble(0x3f413ba3c2d23400L), Double.longBitsToDouble(0x3fb0e6b759457ab0L)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=java.lang.String:\udbf2\udf39\ud914\udfb8\udb9f\udcb4\udab7\udd37\ud9ef\udfa4\uda49\udc42\\\\\ud85d\udfb2\udb96\uddb7\ud9fc\udd20\0121=java.lang.String:\udbf2\udf39\ud914\udfb8\udb9f\udcb4\udab7\udd37\ud9ef\udfa4\uda49\udc42\\\\\ud85d\udfb2\udb96\uddb7\ud9fc\udd20\012",
        Z.run(T, 2, 9, 9, 7, "\udbf2\udf39\ud914\udfb8\udb9f\udcb4\udab7\udd37\ud9ef\udfa4\uda49\udc42\\\ud85d\udfb2\udb96\uddb7\ud9fc\udd20", "\u82a8\u2c29\u98fb\ub030\ua54b\ub961\ucdb2\u9e56\ua279\u898b", "\udb58\udc9c",
        7, 28116, -366357564, -5436666691012484663L, 89647L, true, false, (char) 26841, (char) 14798,
        Double.longBitsToDouble(0x3fea9c97f85bcb62L), Double.longBitsToDouble(0x3fe92d44bd85ff8dL)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 8, 8, 14, "\udbf2\udf39\ud914\udfb8\udae3\udcaf\ud80d\ude42\u7d35\ud9e3\udded\\", "\u08d9\u8d61\u0790\u6d89\u2c39\u98fb", "\ud9ad\ude2d",
        44, 31040, 1692910696, -4630907994234084738L, -85835L, false, true, (char) 29044, (char) 4773,
        Double.longBitsToDouble(0x3f413ba3c2d23400L), Double.longBitsToDouble(0x3fb0e6b759457ab0L)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ua7ff\u8715\u6252\u3dec, \u738e\u3f31\u8766, \u9b91\u1790\u06b5]}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ua7ff\u8715\u6252\u3dec, \u738e\u3f31\u8766, \u9b91\u1790\u06b5, \ua7ff\u8715\u6252\u3dec, \u738e\u3f31\u8766, \u9b91\u1790\u06b5]}\012",
        Z.run(T, 2, 1, 1, 7, "", "\ua7ff\u8715\u6252\u3dec,\000\u738e\u3f31\u8766,\000\u9b91\u1790\u06b5", "\ud846\udfdf\u6998\ud86a\ude6e\ud99a\udded\uda78\udeab\udab5\udc92",
        7, 10818, -1298187495, -8512542147335089152L, -34464L, false, false, (char) 15611, (char) 35170,
        Double.longBitsToDouble(0x3fe608fd45e73ed9L), Double.longBitsToDouble(0x3fd269a880fecd18L)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.String:\udb87\udd8e\udb02\udc74\uda66\udf78\u75c2\uda25\udcb8\uda6a\udf13\u0f4d\ud971\udd8b\uda4e\udd7d\ud82c\ude7e\ud997\udc04\u5eda\uda58\ude51\ud931\udc08\udbaf\udd6c\udb27\uddda\uda0e\ude4a\ud845\ude2e\ud9ff\udcd3\ud80a\uded8\ud894\udf9c\udaa8\udd52\udbc8\ude71\uda18\udfea\ud896\udc7c\uda36\udd3e\ud94d\udf86\udbc9\udf61\udb03\udd1e\ufea8\udba8\udd6d\ud981\udcf5\udb16\udde0\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\udb22\udd5f\ud9b2\udd04\udb18\udda3\udb70\uddae\udbd6\ude84\ud865\ude29\ud8c5\ude16\ud8d8\udfdb\ud9a6\udf08\0121=java.lang.String:\udb87\udd8e\udb02\udc74\uda66\udf78\u75c2\uda25\udcb8\uda6a\udf13\u0f4d\ud971\udd8b\uda4e\udd7d\ud82c\ude7e\ud997\udc04\u5eda\uda58\ude51\ud931\udc08\udbaf\udd6c\udb27\uddda\uda0e\ude4a\ud845\ude2e\ud9ff\udcd3\ud80a\uded8\ud894\udf9c\udaa8\udd52\udbc8\ude71\uda18\udfea\ud896\udc7c\uda36\udd3e\ud94d\udf86\udbc9\udf61\udb03\udd1e\ufea8\udba8\udd6d\ud981\udcf5\udb16\udde0\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\udb22\udd5f\ud9b2\udd04\udb18\udda3\udb70\uddae\udbd6\ude84\ud865\ude29\ud8c5\ude16\ud8d8\udfdb\ud9a6\udf08\012",
        Z.run(T, 2, 9, 9, 11, "\udb87\udd8e\udb02\udc74\uda66\udf78\u75c2\uda25\udcb8\uda6a\udf13\u0f4d\ud971\udd8b\uda4e\udd7d\ud82c\ude7e\ud997\udc04\u5eda\uda58\ude51\ud931\udc08\udbaf\udd6c\udb27\uddda\uda0e\ude4a\ud845\ude2e\ud9ff\udcd3\ud80a\uded8\ud894\udf9c\udaa8\udd52\udbc8\ude71\uda18\udfea\ud896\udc7c\uda36\udd3e\ud94d\udf86\udbc9\udf61\udb03\udd1e\ufea8\udba8\udd6d\ud981\udcf5\udb16\udde0\ud8d7\udf1f\u23b7\udb0e\udee0\ud849\udfdb\udab3\udc57\udb22\udd5f\ud9b2\udd04\udb18\udda3\udb70\uddae\udbd6\ude84\ud865\ude29\ud8c5\ude16\ud8d8\udfdb\ud9a6\udf08", "\u9d30\u8608\u80db\u9070\u6b32", "\ud944\udee8\ud91b\udc8d",
        32, 26735, -1000118502, 369263526798988217L, 82576L, true, true, (char) 25380, (char) 57944,
        Double.longBitsToDouble(0x3fd8f4b115a7552eL), Double.longBitsToDouble(0x3fc758a9161fb658L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.String:\u0c97\udae1\udc9e\udb67\udca1\ud910\udeb7\ud8ae\ude59\ud811\ude3b\\,\udbbf\udc30\u2f04\udad6\udfca\udaab\udc74\\,\000\ubf58\udba2\udc3b\ud978\udf61\ud9c8\udcf2\ud827\udc86\ud900\udf28\ud930\udf96\udbf0\udefe\ud998\udf69\ud9a4\ude8b\udab5\udc4b\ucc0b\udbbc\udd96\0121=java.lang.String:\u0c97\udae1\udc9e\udb67\udca1\ud910\udeb7\ud8ae\ude59\ud811\ude3b\\,\udbbf\udc30\u2f04\udad6\udfca\udaab\udc74\\,\000\ubf58\udba2\udc3b\ud978\udf61\ud9c8\udcf2\ud827\udc86\ud900\udf28\ud930\udf96\udbf0\udefe\ud998\udf69\ud9a4\ude8b\udab5\udc4b\ucc0b\udbbc\udd96\012",
        Z.run(T, 2, 9, 9, 7, "\u0c97\udae1\udc9e\udb67\udca1\ud910\udeb7\ud8ae\ude59\ud811\ude3b,\udbbf\udc30\u2f04\udad6\udfca\udaab\udc74,\000\ubf58\udba2\udc3b\ud978\udf61\ud9c8\udcf2\ud827\udc86\ud900\udf28\ud930\udf96\udbf0\udefe\ud998\udf69\ud9a4\ude8b\udab5\udc4b\ucc0b\udbbc\udd96", "\ubfe9\u59e4", "\uda2a\udf4d\uda59\ude00\udbe2\ude04",
        39, 23500, 812974975, -7509354103311595719L, -23763L, false, false, (char) 26781, (char) 2518,
        Double.longBitsToDouble(0x3fd2aa88f7ff94acL), Double.longBitsToDouble(0x3fcb7c47a708b850L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3df2, \u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1\u5cb4\u1800\ud312\u49a3\uc1b5\u2583\ud7a3\u5b03\ubfce\u2ffa\u6f63\u3401\u832b,]}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{=[\ud61e\u8715\u5134\u3df2, \u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1\u5cb4\u1800\ud312\u49a3\uc1b5\u2583\ud7a3\u5b03\ubfce\u2ffa\u6f63\u3401\u832b,, \ud61e\u8715\u5134\u3df2,\u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1\u5cb4\u1800\ud312\u49a3\uc1b5\u2583\ud7a3\u5b03\ubfce\u2ffa\u6f63\u3401\u832b\\]}\012",
        Z.run(T, 2, 1, 3, 7, "", "\ud61e\u8715\u5134\u3df2,\u8ec5\u0c2e\u08d9\u097cP\u55e2\u105f\u7ae4\ucba1\u5cb4\u1800\ud312\u49a3\uc1b5\u2583\ud7a3\u5b03\ubfce\u2ffa\u6f63\u3401\u832b\\", "\uda3d\udc02",
        29, 13075, -1705011737, 7389493458422793087L, -88894L, true, false, (char) 51430, (char) 6169,
        Double.longBitsToDouble(0x3fd87d19f3fb23f4L), Double.longBitsToDouble(0x3fb472864b0314c8L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.ExtendedProperties|convertProperties|java.util.Properties|static",
    "M|org.apache.commons.collections.ExtendedProperties|addProperty|java.lang.String,java.lang.Object|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|addPropertyDirect|java.lang.String,java.lang.Object|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|addPropertyInternal|java.lang.String,java.lang.Object|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|clearProperty|java.lang.String|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|combine|org.apache.commons.collections.ExtendedProperties|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|countPreceding|java.lang.String,int,char|static",
    "M|org.apache.commons.collections.ExtendedProperties|display||new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|endsWithSlash|java.lang.String|static",
    "M|org.apache.commons.collections.ExtendedProperties|escape|java.lang.String|static",
    "M|org.apache.commons.collections.ExtendedProperties|getBoolean|java.lang.String|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getBoolean|java.lang.String,boolean|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getBoolean|java.lang.String,java.lang.Boolean|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getByte|java.lang.String|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getByte|java.lang.String,byte|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getByte|java.lang.String,java.lang.Byte|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|convertProperties|java.util.Properties|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
