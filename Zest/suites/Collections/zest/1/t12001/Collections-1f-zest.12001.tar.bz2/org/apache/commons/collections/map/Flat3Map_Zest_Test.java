package org.apache.commons.collections.map;
import org.junit.Test;
import static org.junit.Assert.*;
public class Flat3Map_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 7, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\uad8f\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fd18d6e74b6353eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 12, 4, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda", "\uc2ec\u52bd\u12a0\ua00b\u85c6", "\udabe\udf1a\ud99d\udfc2\ud91a\udfa3\ud990\uddb6\ud952\udcc2\udbfa\udef6\udbb3\udf36\ud8c6\udd0b\ud8a9\uddd1\udb20\udcc8\udafe\uded1\udb2f\udf06\ud902\udf2e\uda1e\udc20\ud8ed\udff3\ud809\udf26\ud820\udc0c\ud934\uddb1",
        4, 39088, -1027162980, 1918464777609978459L, -72949L, false, false, (char) 47647, (char) 37292,
        Double.longBitsToDouble(0x3fdf7e886ddc12f8L), Double.longBitsToDouble(0x3fdf89e9162af198L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud934\udf35=\uae0e\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u7286}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud934\udf35=\uae0e\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u7286}\012",
        Z.run(T, 2, 13, 7, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud934\udf35", "\uae0e\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u7286", "\uda97\udd50",
        -4, 7017, 644767279, -8799028701817778824L, -60691L, true, false, (char) 53960, (char) 60492,
        Double.longBitsToDouble(0x3fe7679a3fc683ecL), Double.longBitsToDouble(0x3fd307bc4539555cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 8, 7, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\udb0f\udc86\ud881\udec8\ud934\udf5d", "\u9537\u5ab9\u3687\uc2ec\u52bd\u12a0\u4776\u0155\u72eb\ubb75\u75aa\u1662\uc9ad\u5595", "\ud8a3\udd77",
        52, 87396, 778985007, -8799180551477047944L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fd18d6e74b6353eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 1, 10, 7, 14, "\ud8cf\udcf4\ud93b\udca9\udba9\udfce\ud927\udc68\u236b\ud8f8\udc45\ud881\udebc\ud934\udf5d", "\uad8f\u5ab9\u3687\u902a\u5312\u12a0\ua00b\u0155\u5b24\ua2d7\u7566\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 1332633135, -8799134256024564360L, -50348L, false, false, (char) 39562, (char) 63036,
        Double.longBitsToDouble(0x3fd307bc43c7555cL), Double.longBitsToDouble(0x3fd18d6e74b6353eL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 1, 0, 8, 14, "\ud8cf\udd16\ud93b\udca9\ubbb1\ufc14\000\000\ud881\udebc\ud934\udf5d", "\ub1b5\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\\\ubb75\u75ac\u1662\uc9ad\u5595", "\ud921\udd76",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, false, (char) 39475, (char) 56006,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fd18d6e70b6353eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 1, 1, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udf2c\ud8f8\udc1b\ud954\ude85\ud934\ude89", "\uad8f\u5ab9\u6d8c\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud9be\udee7\ud873\udfa3\ud9cb\udeb5\u6b1f\udafe\uded1\udb2f\udf06\ud94c\udf48\ud893\udeef\ud938\ude1d\ud918\uddaf\ud9de\ude9b\ud849\udf9c\ud825\udd08\udb35\udc28\u5a30\uda94\udea9\ud953\udf4f\udb03\udc45",
        7, 17726, -965620675, -2537236485257022403L, 14361L, true, true, (char) 483, (char) 44682,
        Double.longBitsToDouble(0x3fc235c6f6d285fcL), Double.longBitsToDouble(0x3feedde5b6fbc1cfL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 7, 6, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda62\udf73\uda77\udd76\ud881\udebc\ud934\udf5d", "\uad8f\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\ua58c\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fc54d83e96c6a7cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.HashedMap:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 5, 6, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda36\uddae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\uad8f\u5ab9\u3687\uc2ec\u52a5\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fddc5e8b4b6353eL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 7, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\udb23\udc6c\ud813\ude46\ud99d\udc4d\ud95b\udfd6\udb3e\udcff", "\uba52\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, -1150394833, 4501432578312457592L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fd18d6e74b6353eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 1, 14, 6, 4, "\uaa45\udbd5\udeb7\uda5a\udfc3\ud927\udd4d\udbc2\udfac\ud8f8\udc1b\udbf6\udd7e\uae38", "\uad8f\u18bb\u6f37\u74d1\u446a\u2a52\u10c7\u82ff\u6c1d\uc247\u9064\ud261\uc9ad\u5595", "\ud9a3\udc18",
        58, 7017, 644767279, -8798958656286667400L, 88113L, true, false, (char) 62248, (char) 34845,
        Double.longBitsToDouble(0x3fae24b3fc683900L), Double.longBitsToDouble(0x3fd307bc4939555cL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 3, 1, 12, "\ud8cf\udd16\ud9a8\udf94\udba9\udfce\uda67\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\udb7f\ude95\ud9a2\udc57\udb8d\udef4", "\u52bd\u6f8d\u4141\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595\u6b73\u0e5d\ub23c\u04ba\ub0ab\u6bbb\uc949\u4be8\ud082\u9834\u9f2a\u8d6d\u49c4", "\udb35\udc28\u5a30\uda94\udea9\ud93b\udee3\uda0e\udcef\ud87e\ude62\udbe1\udf2f\udb73\ude03\uda12\udf2e\ud8db\uddad\ud9e3\udf80\ud981\ude8f\u7de8\ud916\udfdd\udb7d\udc0f\udb07\udfa5\udbc0\udf41\uda48\udcb9\uda4f\uddae\udb22\udedb\udb34\udcd8\udaa9\udc83\ud9c5\ude2a\u2349\ud8f4\udf6e\udbd4\udfdb\ud842\ude3f\ud813\udf01\uda2f\udc7d\ud964\udf0f\u2759\ud958\udf31\ud985\udc66\ud89c\udd31\udac0\udca9\udbb4\udf65\udb70\udfe7\ud8d7\ude32",
        3, 31907, 977938367, 1052244792226473414L, -24554L, true, false, (char) 48086, (char) 45069,
        Double.longBitsToDouble(0x3fdb0449e96fdc12L), Double.longBitsToDouble(0x3fca4dafc5e88550L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 11, 12, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae", "\u2b63\u70cc\ud4a0\uad8f\u5ab9\u3687\u74ec\u52bd\u12a0\ua00b\u0155\u72eb", "\ud99d\udfc2\ud91a\udfa3\ud990\uddb6\ud8cd\udf80\udbd7\ude73\ud8a3\udd77\ud8c6\udd0b\ud995\udf28\udb20\udc72\udafe\uded1\udb2f\udf06\ud94c\udf48\ud893\udeef\ud938\ude1d\udb42\udf64\ud820\udc18\ud849\udf9c\udb0a\uddff\udb35\udc28\u5a30\uda94\udea9\ud8d3\udc90\ud9fa\ude8f\ud8db\udee2\ud8aa\udca4\udb85\udefa\uda80\ude04\ud972\udeed\ud9e9\ude5a",
        20, 16902, 1785438321, -3757522494384252988L, -2273L, true, true, (char) 38211, (char) 39400,
        Double.longBitsToDouble(0x3feaa85ad1052646L), Double.longBitsToDouble(0x3fe05e94ee0ee111L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 2, 7, 14, "\ud8cf\udc19\ud93b\udca9\udba9\udfce\ud927\udc68\udbfa\udc0a\000\ud856\ude0b\ud934\udf5d", "\uad8f\u5ab9\u3687+\u5237\u12a0\ua00b\u173a\000\ubafa\000\000\uc9ad\u00d0", "\ud8f2\udf98",
        47, 6848, 644767279, 17179869184L, -100000L, false, false, (char) 71, (char) 56242,
        Double.longBitsToDouble(0x3fa83de200000000L), Double.longBitsToDouble(0x3f98d6e7400013e0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.HashedMap:{} |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 5, 4, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\udb7f\ude95\uda0c\udfc8\ud81b\uddba\udb0a\udf0a\udb53\udc3a\uda57\udcc6\ud98e\udee8\u8656\uda9d\udd04\ud95d\udcd0\ucb23\udab7\udc29", "\u5595\u1d08\u0e5d", "\ud9af\udd28\udb20\udc72\udafe\uded1",
        50, 52660, 138149725, 4481792409603445911L, 39077L, false, false, (char) 38911, (char) 48377,
        Double.longBitsToDouble(0x3fea8e44a1d3d96fL), Double.longBitsToDouble(0x3fe4d35e538fdd43L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 9, 12, 13, "\ud83f\udc20\ud8d8\udf82\udba9\udfce\ud927\udc68\uda40\udfae\ud8b0\udd57\ud888\udc87\ud8fd\udf5d\ud98e\udf57\udb7f\ude95\uda9b\ude74\uda4e\udde8\ud8db\udc67\ud87f\udf51", "\u391e\u7b31\u0215\u9b75\ud34c\ud61f\ua867", "\udbd7\ude73\udbb1\udd7e\ud8c6\udd0b\ud839\udf05",
        47, -516, -1834005128, 1358198315606042227L, -61961L, false, false, (char) 37667, (char) 23567,
        Double.longBitsToDouble(0x3fd8ae0c13e75aa0L), Double.longBitsToDouble(0x3fe36eef4a5bf39fL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\uda84\udcea\udb9f\udc42\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d=\uad8f\ud742N\u701f\u3dff\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595}\012",
        Z.run(T, 2, 6, 13, 14, "\ud8cf\udd16\uda84\udcea\udb9f\udc42\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\uad8f\ud742N\u701f\u3dff\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        52, 60042, 644767279, -242919486620253425L, -47003L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fb83379d2d8d4f8L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 0, 0, 0, "", "\u8598\ud2b3", "\ud881\udebc\ud934\udf5d\ud98e\udf57\udb7f\ude95\ud9a2\udc57\ud96a\uddea\ud839\udf59\u5b37\udae4\udef1?\udb97\udfcb\ud9c6\udf5a\ud8bc\udc82\udbcb\ude2c",
        54, 72915, -1101701246, 8436934044503213771L, 31072L, true, false, (char) 47217, (char) 34395,
        Double.longBitsToDouble(0x3fe16490067312d9L), Double.longBitsToDouble(0x3fe39841dc973e32L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 8, 11, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\ud8f6\udc8f\ud8f8\udc1b\ud881\udec0\udbf4\udf91", "\u226c\u1361\u8b0f\u2058\u52bd\u12a0\ua00b\u0155\ub5e1\ubb75", "\ud931\udeb0\uda03\udd4e",
        47, 36822, -1648172974, -5076497882668289405L, -71844L, false, true, (char) 56475, (char) 54347,
        Double.longBitsToDouble(0x3fb0415d66286978L), Double.longBitsToDouble(0x3fcb0e6e9bb3ce3cL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 7, 7, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\uad8f\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4f39555cL), Double.longBitsToDouble(0x3fdb39c935b4433eL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 10, 14, 13, "\ud8cf\udd16\ud857\udeb7\udba9\udfce\ud927\udc68\uda40\udfae\ud8c0\udc88\ud881\udebc\ud934\udf5d", "\u8c77\u5a49", "\udb04\ude77\uda2e\ude27\udbb0\udfee\ud88f\udf59\ud8bc\udc82\udbcb\ude2c\udab7\udc2f\udb4a\udda7\uda9b\udf8c\ud960\udd29\ud8cd\udf80\udbd7\ude73\udb36\udf37\ud969\udc0b\ud995\udf6a\udb20\udc72\udafe\uded1\ud91f\udedd\uda57\udd98\ud833\udd29\ud827\udd1e\ud8a5\ude51\ud820\udc18",
        33, 52174, -1431432912, -2961190851761422056L, 69527L, true, true, (char) 34559, (char) 19692,
        Double.longBitsToDouble(0x3fecb8ee7ad6195cL), Double.longBitsToDouble(0x3fd69432bb7c2912L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 7, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\uadf6\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8798952991224803976L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc48b3d55cL), Double.longBitsToDouble(0x3fe8c6b73a5b1a9fL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 14, 0, "\ud8cf\udd16\ud93b\udca9\udba9\udf1d\ud927\udc68\uda40\udfae\ucd99\000\ud8fb\udd7d", "\uad8f", "\udb94\udf2a\udb04\uddf1\ud9fc\udd1d\udbb0\udfee\ud9c6\udf5a\ud8bc\udc82",
        26, 27689, 195, -4731770819569515824L, 34666L, false, true, (char) 21338, (char) 64919,
        Double.longBitsToDouble(0x3fe000000204266eL), Double.longBitsToDouble(0x3fd7885e3000015eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 3, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\u2a8c\ua829\u4753", "\uda2e\ude27\udbb0\udfee\ud9c6\udf5a\ud8bc\udc82\udbcb\ude2c\udab7\udc2f\ud99d\udfc2\ud91a\udfa3\ud990\uddb6\ud8cd\udf80\udbd7\ude73\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, true, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc43b1075cL), Double.longBitsToDouble(0x3fdc34fac4b6353eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 2, 7, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\ud968\udcac\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\u99d7\u33e0\u9612\u23d1\u51fa\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\u8c6c\u5595", "\ud90b\udc2b",
        2, 7017, -146585243, -8837758795353926024L, 98616L, false, false, (char) 53960, (char) 62970,
        Double.longBitsToDouble(0x3fe7672b57c683ecL), Double.longBitsToDouble(0x3fd307bc4939555cL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 6, 11, 14, "\ud8cf\udc44\ud93b\udca9\ud86a\uddd2\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\u19a1\u5b24\u7e3e\ub2da\u9fab\u652a\u9774\ucb98\u72e8\ubb75\u75ac\u1662\u8c4f\u2954", "\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fd18d6e74b6353eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 3, 3, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\ud3d9", "\udbab\ude61\udb04\ude77\uda2e\ude27\udbb0\udfee\ud9c6\udf5a\ud8bc\udc82",
        8, 3240, -854689085, -4731770819568074032L, 34666L, false, true, (char) 21338, (char) 64919,
        Double.longBitsToDouble(0x3fe178439204266eL), Double.longBitsToDouble(0x3fd7885e3459255eL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\uda47\udd52\ud93b\udca9\udba9\udfce\uda02\uddf9\udbdf\uddc9\udab0\udea5\ud881\udebc\ud934\udf5d=\uad8f\u5ab9\u3687\uc2ec\u52bd\u4d5f\u3b2f\u1b64\u0383\u976a\u75ac\u1662\uc9ad\u5566}\0121=org.apache.commons.collections.map.Flat3Map$EntrySet:[\uda47\udd52\ud93b\udca9\udba9\udfce\uda02\uddf9\udbdf\uddc9\udab0\udea5\ud881\udebc\ud934\udf5d=\uad8f\u5ab9\u3687\uc2ec\u52bd\u4d5f\u3b2f\u1b64\u0383\u976a\u75ac\u1662\uc9ad\u5566] |this=org.apache.commons.collections.map.Flat3Map:{\uda47\udd52\ud93b\udca9\udba9\udfce\uda02\uddf9\udbdf\uddc9\udab0\udea5\ud881\udebc\ud934\udf5d=\uad8f\u5ab9\u3687\uc2ec\u52bd\u4d5f\u3b2f\u1b64\u0383\u976a\u75ac\u1662\uc9ad\u5566}\012",
        Z.run(T, 2, 13, 6, 14, "\uda47\udd52\ud93b\udca9\udba9\udfce\uda02\uddf9\udbdf\uddc9\udab0\udea5\ud881\udebc\ud934\udf5d", "\uad8f\u5ab9\u3687\uc2ec\u52bd\u4d5f\u3b2f\u1b64\u0383\u976a\u75ac\u1662\uc9ad\u5566", "\ud82b\udc18",
        49, 89974, -1427415505, -6266583168434114565L, -31127L, true, false, (char) 21008, (char) 60492,
        Double.longBitsToDouble(0x3fe7679a3fc683ecL), Double.longBitsToDouble(0x3fe983de249caaaeL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 2, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda96\udfd8\ud9d9\udc61\ud881\udebc\ud934\udf5d", "\uadcb\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, false, (char) 39623, (char) 56242,
        Double.longBitsToDouble(0x3fdc7b9c49382a7cL), Double.longBitsToDouble(0x3fd18d6e74b6353eL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 11, 11, 4, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\uda27\udc68\ud806\uded0\ud8a7\udc66\ud981\udf98\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda", "\uc2ec\u7a48\u12a3\ua00b\u85c6", "\udabe\udf1a\udb8a\udf78\uda50\ude09\u2f01\ud952\udc73\udbfa\udef6\udbb3\udf36\ud80b\udd2c\uda79\udff2\udb20\udcc8\udafe\uded1\udbfd\udf04\ud90c\ude02\uda1e\udc20\ud8ed\udff3\ud809\udf26\ud820\udc0c\udb65\udf27",
        22, 39088, -1027162980, 1918464777609978459L, 98050L, true, true, (char) 22930, (char) 35218,
        Double.longBitsToDouble(0x3fea80aa5fdf381bL), Double.longBitsToDouble(0x3fcec7a11ecc90acL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 1, 1, 4, "\uda88\udd61\udaf9\udc0c\udba9\udfce\udbb2\ude9c\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udea9\ud98e\udf57\udabb\uddff\ud817\udcda", "\u0124\ua81f\u5f93\ua00b\u5578\u272d\ucd88\u47ab\u1662\uc9ad\u5595\u6656\u9ae0\ua812\u04ba\u6699\u6c11\uc949\u4be8\u5228\ud665\u76f7\u1d62\u49b8", "\udb35\udc28\uda38\udee0\ud950\ude5a\uda0d\ude98\uda40\uddc6\udbb6\udfa5\udacb\ude7b\ud923\udf95\ud810\udca8\ud96c\udcfb\udb42\udc94\ud821\ude86\udb6d\udd77\ud986\uddec\udace\udc6b\udb49\udfb8\udb12\ude52",
        54, 73926, 1167543142, -8874898407001010659L, 66687L, true, false, (char) 62438, (char) 23627,
        Double.longBitsToDouble(0x3fd3319358d6b4f6L), Double.longBitsToDouble(0x3fec30c57ac52e99L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 12, 4, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda", "\uc2ec\u52bd\u12a0\ua00b\u85c6", "\udabe\udf1a\ud99d\udfc2\ud91a\udfa3\ud990\uddb6\ud952\udcc2\udbfa\udef6\udbb3\udf36\ud8c6\udd0b\ud8a9\uddd1\udb20\udcc8\udafe\uded1\udb2f\udf06\ud902\udf2e\uda1e\udc20\ud8ed\udff3\ud809\udf26\ud820\udc0c\ud934\uddb1",
        4, 39088, -1027162980, 1918464777609978459L, -5114L, false, false, (char) 32473, (char) 9055,
        Double.longBitsToDouble(0x3feed6b771d577d7L), Double.longBitsToDouble(0x3fdf7e886ddc12f8L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 10, 4, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda", "\uc2ec\u52bd\u12a0\ua00b\u527d", "\udabe\udf1a\ud99d\udfc2\ud91a\udfa3\ud990\uddb6\ud952\udcc2\udbfa\udef6\udbb3\udf36\ud8c6\udd0b",
        10, 83365, -2048683516, -7876992045471534276L, 34084L, true, false, (char) 15976, (char) 39475,
        Double.longBitsToDouble(0x3feccd3a21307bc4L), Double.longBitsToDouble(0x3fc39555c6370b18L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud800\udc94\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda=\uc2ec\u52bd\u12a0\ua00b\u85c6}\0121=org.apache.commons.collections.map.Flat3Map$KeySet:[\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud800\udc94\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda] |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud800\udc94\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda=\uc2ec\u52bd\u12a0\ua00b\u85c6}\012",
        Z.run(T, 2, 13, 11, 4, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud800\udc94\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda", "\uc2ec\u52bd\u12a0\ua00b\u85c6", "\udabe\udf1a\ud99d\udfc2\ud91a\udfa3\ud990\uddb6\ud952\udcc2\udbfa\udef6\udbb3\udf36\ud8c6\udd0b\ud8a9\uddd1\udb20\udcc8\udafe\uded1\udb2f\udf06\ud902\udf2e\uda1e\udc20\ud8ed\udff3\ud809\udf26\ud820\udc0c\ud934\uddb1",
        4, 39088, -1027147952, 1918464777609978459L, -72949L, false, false, (char) 47647, (char) 37292,
        Double.longBitsToDouble(0x3fdf7e886ddc12f8L), Double.longBitsToDouble(0x3fdf89e9162af198L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ue9ab\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud941\udd70=\ua5c2\u516d\u716e\uc2df\u52bd\u12a0\ua00b\u0155\u862f\u129a\u75ac\u1662\uc9ad\u7286}\0121=org.apache.commons.collections.map.Flat3Map$FlatMapIterator:Iterator[] |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ue9ab\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud941\udd70=\ua5c2\u516d\u716e\uc2df\u52bd\u12a0\ua00b\u0155\u862f\u129a\u75ac\u1662\uc9ad\u7286}\012",
        Z.run(T, 2, 13, 12, 12, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ue9ab\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud941\udd70", "\ua5c2\u516d\u716e\uc2df\u52bd\u12a0\ua00b\u0155\u862f\u129a\u75ac\u1662\uc9ad\u7286", "\ud848\udc9f",
        7, 6981, 644767279, -8799028700811145864L, -87310L, true, false, (char) 53058, (char) 56575,
        Double.longBitsToDouble(0x3fed23db56bb307aL), Double.longBitsToDouble(0x3fe0aa7402c63244L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 2, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\ud804\udef6\udb11\udca6", "\uaf84\u45c9\u3687\uc2ec\ub7ee\u2e4b\u4f66\u0155\ud466\ud0c2\u75ac\u63aa\uc9ad\u7286", "\uda97\udcdf\ud8ea\udf0b\ud995\udf28\udb20\udc72\ud86a\udec7\ud99a\udedb\uda92\udd94\ud893\udeef\ud938\ude1d\ud969\udcf8\ud820\udc18",
        7, 90210, -1431432912, 8742079084509492437L, 28856L, true, true, (char) 59321, (char) 41958,
        Double.longBitsToDouble(0x3fedd8a8bcafe8beL), Double.longBitsToDouble(0x3fefe46af8579e56L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud80f\udf22=\u6239\u8a9a\u3687\uc2ec\u52bd\u12a0}\0121=java.lang.Integer:-502751146 |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud80f\udf22=\u6239\u8a9a\u3687\uc2ec\u52bd\u12a0}\012",
        Z.run(T, 2, 13, 9, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud80f\udf22", "\u6239\u8a9a\u3687\uc2ec\u52bd\u12a0", "\ud8bc\udc82\udbcb\ude2c",
        54, 72915, -1101701246, 1567818713497179550L, -83186L, false, false, (char) 33884, (char) 26273,
        Double.longBitsToDouble(0x3fe02133757885e3L), Double.longBitsToDouble(0x3fe97e9d7d7a49e8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud802\udc9c\ud98e\udf57\udb99\udea8\ud9a2\udc8b\udb8d\udef4\ud839\udf59\udbab\ude61\udb1c\udd77\uda2e\ude27\udbb0\udfee\udb87\ude43\uda91\ude0d\u21d0\udb0b\udcd7\ud82f\udcac\ud91a\udfa3=\u0e5d\u12cb\u0e11\u2e83\u6bbb\uc949\u28f2\u6bd1\u9834\u682a\u8d6d\u49c4\ubbdd\u6a76\uac10\ubbc8\u5f5f\u158f\ua2d0\u41e5\u42d5\ud46f\u4fef\u3a17\u85b1\u1ab2\u3a19}\0121=java.lang.String:\u0e5d\u12cb\u0e11\u2e83\u6bbb\uc949\u28f2\u6bd1\u9834\u682a\u8d6d\u49c4\ubbdd\u6a76\uac10\ubbc8\u5f5f\u158f\ua2d0\u41e5\u42d5\ud46f\u4fef\u3a17\u85b1\u1ab2\u3a19 |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud802\udc9c\ud98e\udf57\udb99\udea8\ud9a2\udc8b\udb8d\udef4\ud839\udf59\udbab\ude61\udb1c\udd77\uda2e\ude27\udbb0\udfee\udb87\ude43\uda91\ude0d\u21d0\udb0b\udcd7\ud82f\udcac\ud91a\udfa3=\u0e5d\u12cb\u0e11\u2e83\u6bbb\uc949\u28f2\u6bd1\u9834\u682a\u8d6d\u49c4\ubbdd\u6a76\uac10\ubbc8\u5f5f\u158f\ua2d0\u41e5\u42d5\ud46f\u4fef\u3a17\u85b1\u1ab2\u3a19}\012",
        Z.run(T, 2, 13, 13, 13, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud802\udc9c\ud98e\udf57\udb99\udea8\ud9a2\udc8b\udb8d\udef4\ud839\udf59\udbab\ude61\udb1c\udd77\uda2e\ude27\udbb0\udfee\udb87\ude43\uda91\ude0d\u21d0\udb0b\udcd7\ud82f\udcac\ud91a\udfa3", "\u0e5d\u12cb\u0e11\u2e83\u6bbb\uc949\u28f2\u6bd1\u9834\u682a\u8d6d\u49c4\ubbdd\u6a76\uac10\ubbc8\u5f5f\u158f\ua2d0\u41e5\u42d5\ud46f\u4fef\u3a17\u85b1\u1ab2\u3a19", "\ud95e\udfc4\ud939\udf5c\ud8e8\udc8b\udb85\udfee\ud800\udedf\udb8c\udf7e\ud8c5\ude85\udad8\udeb9\ud896\udd30\ud995\udc44\udb8b\udef0\ud8dd\ude7c\udbef\udcdb\udbd9\udee8\udaa5\udf51\udb4f\udd08\udbe0\udd8b\u4850\udab4\uddcc\ud9d4\udc4d\u12e4\udabd\udfef",
        -2, 1636, 1644243841, 5332212134167243925L, -86573L, false, true, (char) 63703, (char) 40405,
        Double.longBitsToDouble(0x3fa287c90eee1170L), Double.longBitsToDouble(0x3fcf22e8a3f18edcL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud8fa\udf57=\uae0e\u5ab9\u3687\uc2ec\u52bd}\0121=java.lang.String:\uae0e\u5ab9\u3687\uc2ec\u52bd |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud8fa\udf57=\uae0e\u5ab9\u3687\uc2ec\u52bd}\012",
        Z.run(T, 2, 13, 8, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud8fa\udf57", "\uae0e\u5ab9\u3687\uc2ec\u52bd", "\ud9c6\udf5a\ud8bc\udc82\udbcb\ude2c\udab7\udc2f\ud99d\udfc2\ud8a2\udea6\ud859\uddfb\ud906\udfb3\udbd6\udd03\uda97\udd50\ud8ea\udf0b\ud995\udf28\ud843\udd06\udafe\uded1\ud99a\udedb\uda95\uddd2\ud893\udeef\ud938\ude1d\udb42\udf64\ud820\udc18\ud849\udf9c\ud8af\udf11\udb35\udc28\ud99f\udd87",
        -2, 5791, -17939237, -7218352991641444835L, 59914L, false, false, (char) 7043, (char) 47858,
        Double.longBitsToDouble(0x3fbfc3aee8911570L), Double.longBitsToDouble(0x3fd9a08a6296811aL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.AbstractHashedMap$KeySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 11, 14, "\ud8b4\udf8a\ud93b\udd42\udba9\udfce\uda23\uddf2\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud934\udf35", "\uae0e\u5d19\ua77f\u84fa\u0b69\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u7286", "\uda97\udd50",
        -4, 7017, 644767279, 1314085735242091726L, -89134L, true, false, (char) 53960, (char) 60492,
        Double.longBitsToDouble(0x3fe7679a3fc683ecL), Double.longBitsToDouble(0x3fd307bc4539555cL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud901\udd82\udbec\udf35\u572b\ud89d\udc00\ud86e\uded2=null}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud901\udd82\udbec\udf35\u572b\ud89d\udc00\ud86e\uded2=null}\012",
        Z.run(T, 2, 13, 8, 3, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud901\udd82\udbec\udf35\u572b\ud89d\udc00\ud86e\uded2", "\uae0e\u0da8\u35f8\uc2c8\ub080\u3c8b\u767f\u0185\ubfea\u8692\u7619\ua31f\u4913\u45c9", "\uda97\udcfc\ud99a\udde2\ue2eb",
        53, 6280, -416652943, -7760670457025879714L, -20278L, true, false, (char) 42886, (char) 2480,
        Double.longBitsToDouble(0x3fb8570ed0303950L), Double.longBitsToDouble(0x3feca4a78dc4fae9L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.iterators.EmptyMapIterator:@? |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 12, 12, 14, "\ud8cf\udd16\ud93b\udca9", "\u0175\u072a\u871b\u2b3b\u70cc\u0091\uae0e\u5ab9", "\udb04\ude77\uda2e\ude27",
        46, 79746, 1465955164, 849946107629035393L, 72158L, false, false, (char) 34445, (char) 230,
        Double.longBitsToDouble(0x3fccfdfa738af0d8L), Double.longBitsToDouble(0x3fe54d37762f0872L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\u2854\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\udab2\udc18\udadb\udc09\ud934\udf35=\u54a2\u5ab9\u3687\uc2ec\u52bd\ubb38\u7b7f\u957a\u72eb\ubb75\u0fa7\u8ac5\ubc65\ub6a3}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{\u2854\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\udab2\udc18\udadb\udc09\ud934\udf35=\u54a2\u5ab9\u3687\uc2ec\u52bd\ubb38\u7b7f\u957a\u72eb\ubb75\u0fa7\u8ac5\ubc65\ub6a3}\012",
        Z.run(T, 2, 13, 3, 14, "\u2854\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\udab2\udc18\udadb\udc09\ud934\udf35", "\u54a2\u5ab9\u3687\uc2ec\u52bd\ubb38\u7b7f\u957a\u72eb\ubb75\u0fa7\u8ac5\ubc65\ub6a3", "\uda97\udd50\ud8ea\udf0b\ud995\udf28\udb20\udc72\udafe\uded1\ud99a\udedb\uda95\uddd2\ud893\udeef\ud93d\ude1d\udb42\udf64",
        9, 18052, 2073450296, -6147957544944330084L, 75890L, false, false, (char) 8197, (char) 40619,
        Double.longBitsToDouble(0x3fd432d2d28dd6e0L), Double.longBitsToDouble(0x3fe869442db22b8aL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud934\udf35=\uae0e\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u145d}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud934\udf35=\uae0e\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u145d}\012",
        Z.run(T, 2, 13, 2, 12, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud95a\udfad\uda40\udfae\ud8f8\udc1b\udadb\udc09\ud934\udf35", "\uae0e\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u145d", "\ud8c4\udc2f",
        2, 7017, 644767279, -1888536548594463368L, -60691L, true, false, (char) 53960, (char) 60358,
        Double.longBitsToDouble(0x3fe7679a3fc683ecL), Double.longBitsToDouble(0x3fd307bc4539555cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\ud937\udf65\u8dd4=\u871b\u2b3b\u70cc\u1f16\u340a\ua67b\u3687\uc2ec\u52bd\u12a0\ud30b\u0155\u72eb\ubb75}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\ud937\udf65\u8dd4=\u871b\u2b3b\u70cc\u1f16\u340a\ua67b\u3687\uc2ec\u52bd\u12a0\ud30b\u0155\u72eb\ubb75}\012",
        Z.run(T, 2, 13, 4, 2, "\ud8cf\udd16\ud93b\udca9\ud937\udf65\u8dd4", "\u871b\u2b3b\u70cc\u1f16\u340a\ua67b\u3687\uc2ec\u52bd\u12a0\ud30b\u0155\u72eb\ubb75", "\ud90a\udea3\ud9bb\uddaf\ud9da\ude2c\uda5a\udedf\udbd4\udc59\ud8ea\udf0b\ud995\udf28\udb20\udc72\udafe\uded1\ud99a\udedb\udb75\ude21\ud98c\ude75\ud938\ude1d\udb42\udf64\ud820\udc18\ud849\udf9c\ud8af\udea9\udb35\udc28\udb9a\ude45",
        43, 62848, -735170326, 7116994116940297559L, -16480L, true, false, (char) 35641, (char) 2384,
        Double.longBitsToDouble(0x3fb9625b94a97678L), Double.longBitsToDouble(0x3fd4a162713af01cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udc19=\u78e7}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udc19=\u78e7}\012",
        Z.run(T, 2, 13, 4, 0, "\ud8cf\udc19", "\u78e7", "\udadb\udc09\ud934\udf35\u3a38",
        3, 20858, -1850589952, 6601338013598087979L, 62111L, true, false, (char) 5063, (char) 29091,
        Double.longBitsToDouble(0x3fd7b5760f021796L), Double.longBitsToDouble(0x3f33dd0000000000L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 8, 8, 0, "\ud8cf\udd16\ud8f1\udd34\udb0b\udd18\ud8f5\udd5d\ud83a\ude4b\udb37\udf30\ud868\udd4d\ud934\udf5d", "\u9537", "\ud9ad\ude71\udb04\ude77\uda38\ude27\udb9a\udf59\ud9c6\udf5a\ud8bc\udc82",
        19, 47807, -854689085, -3987218271503514938L, 35178L, false, true, (char) 32858, (char) 19089,
        Double.longBitsToDouble(0x3fe1784397c02e6eL), Double.longBitsToDouble(0x3fdbcf5da459255eL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 0, 14, "\ud807\udc12\uda86\uddaf\udba9\udfce\ud927\udc68\uda40\udfae\udabc\udef5\ud881\ude4d\ud934\udf5d", "\u9537\u5ab9\u3687\uc2ec\u52bd\u0468\u4776\u7a45\u72eb\ubb75\u75aa\u1662\uc9ad\u5595", "\ud8a3\udd77",
        52, 87396, 778985007, -8799180551477047944L, -8237L, true, false, (char) 54771, (char) 60492,
        Double.longBitsToDouble(0x3fe7679a3fc683ecL), Double.longBitsToDouble(0x3fd307bac939555cL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 9, 2, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udf2c\ud8f8\udc1b\ud954\ude85\ud934\ude89", "\ua63f\u1014\u6d8c\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\ubb75\u8e1a\u168f\uc9ad\u5595", "\ud9be\udee7\ud873\udfa3\ud9cb\udeb5\u6b1f\udafe\uded1\udb2f\udf06\ud94c\udf48\ud893\udeef\ud938\ude1d\ud918\uddaf\ud9de\ude9b\ud849\udf9c\ud825\udd08\udb35\udc28\ud985\udfe7\uda70\ude95\ud953\udf4f\udb03\udc45",
        7, 17726, -965620675, -2537236485257022403L, 14361L, true, true, (char) 483, (char) 44682,
        Double.longBitsToDouble(0x3fc235c6f6d285fcL), Double.longBitsToDouble(0x3feedde5b6fbc1cfL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 6, 6, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda62\udf73\uda77\udd76\ud881\udebc\ud934\udf5d", "\uad8f", "\udbab\ude61\udb04\ude77\uda2e\ude27\udbb0\udfee\udbfc\udff5\ud8bc\udc82",
        19, 27689, -854689085, -4731770819568074032L, 34666L, false, true, (char) 21338, (char) 64919,
        Double.longBitsToDouble(0x3fc67d0e48137ce4L), Double.longBitsToDouble(0x3fd78857bab7255eL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.AbstractHashedMap$EntrySet:[] |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 6, 14, "\ud8d4\udf42\u66f3\udb93\udf4a\ud927\udc68\uda62\udf73\uda77\udd76\ud881\udebc\ud934\udf5d", "\uad8f\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\ua58c\u1cce\u0d80\u75db\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -89504L, true, true, (char) 53960, (char) 60492,
        Double.longBitsToDouble(0x3fe7679a3fc683ecL), Double.longBitsToDouble(0x3fc08f78927254ccL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=org.apache.commons.collections.map.Flat3Map:{} |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 1, 4, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda62\udf73\uda77\udd76\ud98a\udeb2\ud934\udf5d", "\uad8f\u5ab9\u3687\uc2ec\u0e97\u130c\ua00b\ua58c\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8799028702908297864L, -61961L, false, false, (char) 39475, (char) 56242,
        Double.longBitsToDouble(0x3fd307bc4939555cL), Double.longBitsToDouble(0x3fc54d83e96c6a7cL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 3, 3, 11, "\ud8cf\udd16\ud9a8\udf94\udba9\udfce\uda67\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\udb7f\ude95\ud9a2\udc57\udb8d\udef4", "\u52bd\u6f8d\u4141\u0155\u72eb\ubb75\ud227\u1662\uc9ad\u5595\u6b73\u5c02\ub23c\u04ba\ub0ab\ubdce\u1401\u4be1\ud082\u9834\u9f2a\u8d6d\u49c4", "\udb35\udc28\u5a30\uda94\udea9\ud93b\udee3\uda0e\udcef\ud87e\ude62\uda49\udda4\ud8e1\udc73\uda12\udf2e\ud8db\uddad\ud9e3\udf80\ud90a\udcf4\u7de8\udb32\ude2b\udb7d\udc0f\udb07\udfa5\udbc0\udf41\uda48\udcb9\uda4f\uddae\udb22\udedb\udb34\udcd8\udaa9\udc83\ud9c5\ude2a\u2349\ud8f4\udf6e\udbd4\udfdb\ud9a9\udfcb\ud801\udfc5\uda2f\udc7d\ud964\udf0f\u2759\ud958\udf31\ud985\udc66\ud89c\udd31\udac0\udca9\udbb4\udf65\udb70\udfe7\ud8d7\ude32",
        3, 31907, 977938367, 1052244792226473414L, -24554L, true, false, (char) 48086, (char) 45069,
        Double.longBitsToDouble(0x3fdb0449e96fdc12L), Double.longBitsToDouble(0x3fca4dafc5e88550L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 2, 14, "\ud8cf\udc19\ud93b\udca9\udba9\udfce\ud927\udc68\udbfa\udc0a\000\ud856\ude0b\ud934\udf5d", "\uadc2\u5ab9\u3687+\u5237\u12a0\uc78b\u173a\u630f\ubafa\000\000\u1125\ubb05", "\ud913\udf98\u164b\ud995\ude7f",
        34, -996, 469762048, 1358198315606042227L, 22264L, true, false, (char) 186, (char) 56242,
        Double.longBitsToDouble(0x3fa83db900000000L), Double.longBitsToDouble(0x3f98d6e7400013e0L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 14, 14, 14, "\udb91\ude50\ud93b\udca9\udba9\udfce\uda81\udf36\u133c\ud942\udd90\uda13\udd46\u0b27", "\u31b5\u5a52\u9086", "\uda6e\udce6\udac9\udebe",
        13, 45336, 50371840, 227787889246208L, -94293L, true, true, (char) 22242, (char) 9842,
        Double.longBitsToDouble(0x3fd00000084d2d62L), Double.longBitsToDouble(0x3fd8d4189314281aL)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 2, 2, 5, "\ud8cf\udc19\ud93b\udca9\udbc3\udfdb\ud927\udc68\udbfa\udc0a\000\ud856\ude0b\ud811\udc8b\uda60\uddbf", "\u5ab9\u3687+\u5237\u12a0\u27c8\u173a\000", "\000\ud91a\udfa3\u00d0\ud8cd\udeb5\udbd7\ude73\ud8f2\udf98\u164b\udb3d\udff4\udb30\udd6c\ud9dc\udf69\uda50\ude48\udb34\udcf3\ud893\udeefs\000\ud8a8\udc04\ud820\udcb0\ud8af\udf110\udbe7\udd93\ud954\udc21\ud9c9\udc85\uda9b\udc7d\ud92d\ude12\ufe36\ud875\udc60\ud990\udca2\ud9e6\udcf2\ud834\udd9f",
        39, 68937, 5359704, -3051911737176564530L, 24693L, true, false, (char) 22284, (char) 43422,
        Double.longBitsToDouble(0x3fdcd259d6d98376L), Double.longBitsToDouble(0x3fd92970390600bcL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 3, 14, "\ud8b4\udf19\udb2d\udc76\udba9\udfce\udb52\udc08\000\000\ud856\ude0b\000", "\uad3c", "\000\udb04\uddf1?\000\000\000",
        4, -1000, 0, -4731770821532450608L, 34666L, false, false, (char) 21323, (char) 22016,
        Double.longBitsToDouble(0x3fe178439004266eL), Double.longBitsToDouble(0x3e31600000000000L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\udab5\udeea\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\udb7f\ude95\uda0c\udfc8\ud81b\uddba\udb0a\udf0a\udb53\udc3a\uda57\udcc6\ud98e\udee8\u8656\uda9d\udd04\ud95d\udcd0\ucb23\udab7\udc29=null}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\udab5\udeea\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\udb7f\ude95\uda0c\udfc8\ud81b\uddba\udb0a\udf0a\udb53\udc3a\uda57\udcc6\ud98e\udee8\u8656\uda9d\udd04\ud95d\udcd0\ucb23\udab7\udc29=null}\012",
        Z.run(T, 2, 13, 4, 14, "\udab5\udeea\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d\ud98e\udf57\udb7f\ude95\uda0c\udfc8\ud81b\uddba\udb0a\udf0a\udb53\udc3a\uda57\udcc6\ud98e\udee8\u8656\uda9d\udd04\ud95d\udcd0\ucb23\udab7\udc29", "\u5595\u1d08\u0e5d", "\ud9af\udd28\udb20\udc72\udafe\uded1",
        50, 86580, 138149725, 4481792409603445911L, 39077L, false, false, (char) 38911, (char) 48377,
        Double.longBitsToDouble(0x3fea8e44a1d3d96fL), Double.longBitsToDouble(0x3fe4d35e538fdd43L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud9f2\udfa8\ud93b\udca9=\u0175\u072a\u7ce6\u2b63\u70cc\ud4a0\ua147\ua9f3}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\ud9f2\udfa8\ud93b\udca9=\u0175\u072a\u7ce6\u2b63\u70cc\ud4a0\ua147\ua9f3}\012",
        Z.run(T, 2, 13, 4, 11, "\ud9f2\udfa8\ud93b\udca9", "\u0175\u072a\u7ce6\u2b63\u70cc\ud4a0\ua147\ua9f3", "\u4f45\ud8ff\udf2a\u8656\uda9d\udd04\ud95d\udcd0\ucb04\u2fb7\ud99d\udfc2\ud91a\udfa3",
        14, 55083, 117837322, 2492754770351024742L, 55183L, false, false, (char) 54107, (char) 19987,
        Double.longBitsToDouble(0x3feaec764673083bL), Double.longBitsToDouble(0x3fc2e7c64361cdd0L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 4, 13, "\ud83f\udc20\ud8d8\udf82\ud92b\udf20\ud840\udc11\ud8f9\udc2f\uda1f\ude63\ud911\udc0c\ud8fd\udf56\udb72\udc68\udb36\uddb5\udb6f\uddd3\uda4e\udde8\ud8db\udc67\ud87f\udf51", "\u391e\u56be\u6ab0\u9b75\ud34c\u4c84\ud654", "\ud83e\ude87\udb47\udf65\ud9c1\udf08\uda0c\udec6\uda78\ude41\ud9a1\udf99\udb2f\udf06",
        16, 54785, 1053145605, 8319437786836322520L, 59843L, false, true, (char) 61251, (char) 41046,
        Double.longBitsToDouble(0x3fe2df9cf920c7f3L), Double.longBitsToDouble(0x3fd1c7e45e30a7aeL)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 2, 2, 13, "\ud801\udd9e\ud8c5\ude59\udb8d\udc27\uda21\udd85", "\u96b1\u2762\ud4f2\uc302\u7fa2\ub7c9\u73bf\u55af\uc1ce\u3dee\u880e\u6651\u192a\u9b75\ud396\ud61f\ua867\u5595\u1ce3\u76f4\u125b\u5c23\ub869\u9b4c\ubda2\uc495\ud082\u83b7\ubd4d\u1f16\u49c4\u52c2\u2a95\u038a\u4b53\u853f\u7d29\u0c8b\u481c\uc359\u35d0\u6480\u3027", "\ud841\udd27",
        45, 12423, -960983025, 371464980996147644L, -84620L, true, false, (char) 39199, (char) 7710,
        Double.longBitsToDouble(0x3febf1044f023260L), Double.longBitsToDouble(0x3fdb8ee1908c2348L)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 8, 8, 11, "\ud8cf\udd16\udbc1\udc8c\udba9\udfce\ud927\udc68\ud8f6\udc8f\ud8f8\udc1b\ud881\udec0\udbf4\udf91", "\u226c\u1361\u8b0f\u2058\u52bd\u12a0\ua00b\u0155\ub5e1\ubb75", "\ud931\udeb0\uda03\udd4e",
        47, 36822, -1648172974, -5076497882668289405L, -71844L, false, true, (char) 56475, (char) 54347,
        Double.longBitsToDouble(0x3fb0415d66286978L), Double.longBitsToDouble(0x3fcb0e6e9bb3ce3cL)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 8, 11, "\ud8c5\ude16\ud93b\udca9\udba9\udfce\udb2c\udc6b\ud8f6\udc8f\ud8f8\udc1b\ud881\udec0\udbf4\udf91", "\u226c\u1361\u8b0f\ub0ff", "\udbb0\udfee\ud332\ud9e6\udccc\udbcb\ude2c",
        57, 77193, -199794844, 8470873292688033483L, -26354L, false, false, (char) 27663, (char) 54943,
        Double.longBitsToDouble(0x3fe024f3757885e3L), Double.longBitsToDouble(0x3fe16493797312d9L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 14, 14, 12, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\uadf6\u5ab9\u3687\ubff6\u9431\u12a0\u091a\u0155\u72eb\ubb75\u75ac\u1662\uc9ad\u5595", "\ud8a3\udd77",
        -5, 64049, 644767279, -8798952991224803976L, -6046L, false, false, (char) 26566, (char) 56245,
        Double.longBitsToDouble(0x3fd307bc42b3d55cL), Double.longBitsToDouble(0x3fe2216bc2906e3fL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\ud835\udc0f\uda17\uded7\udbde\udc6b\ud927\udc96\udaaa\udc37\ud8d8\udc2e\udbe2\udfb2=\u9cc5\u71e1\u5ad3\u3687\uc2ec}\012",
        Z.run(T, 2, 4, 13, 4, "\ud835\udc0f\uda17\uded7\udbde\udc6b\ud927\udc96\udaaa\udc37\ud8d8\udc2e\udbe2\udfb2", "\u9cc5\u71e1\u5ad3\u3687\uc2ec", "\udbb0\udfee\ud9c6\udf5a\ud8bc\udc82\uda02\udea7\udab7\udc2f\ud99d\udfc2\uda2e\udf4c",
        14, 61707, 117837322, 3719747351130910963L, -80725L, false, false, (char) 31052, (char) 36525,
        Double.longBitsToDouble(0x3fc2e7c64361cdd0L), Double.longBitsToDouble(0x3fef679a39446370L)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 10, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68\uda40\udfae\ud8f8\udc1b\ud881\udebc\ud934\udf5d", "\uadf6\u5ab9\u3687\uc2ec\u52bd\u12a0\ua00b\u0155\u72eb\uc7be\u7326\u27f4\uc9ad\u5595", "\ud8a3\udd77",
        -5, 7017, 644767279, -8798952991224803976L, -63431L, true, false, (char) 53960, (char) 60492,
        Double.longBitsToDouble(0x3fef679a3d578ba1L), Double.longBitsToDouble(0x3fd410c838b3d4eaL)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 4, 3, 5, "\uda28\udf13\udadc\udc57\udbaa\udeb1\ud927\udc68\uda40\udfae\ucd99\000\ud8fb\udd7d", "\uad8f", "\udb94\udf2a\udb04\uddf1\ud9fc\udd1d\u3ff3\ud911\udcfd\uda76\ude76",
        20, 17778, 152, -4731770819569515824L, 44715L, true, false, (char) 24064, (char) 7792,
        Double.longBitsToDouble(0x3fd7885363b97a56L), Double.longBitsToDouble(0x3fee426dbe3fad54L)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68=\u7ce6\u2b63\u70cc\ud4a0\uadcb}\012",
        Z.run(T, 2, 4, 13, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud927\udc68", "\u7ce6\u2b63\u70cc\ud4a0\uadcb", "\udbab\ude61\udb04\ude77\uda2e\ude27\udbb0\udfee\ud9c6\udf5a\ud8bc\udc82",
        19, 27689, -854689085, -4731770819568074032L, 34666L, false, true, (char) 21338, (char) 64919,
        Double.longBitsToDouble(0x3fe178439204266eL), Double.longBitsToDouble(0x3fd7885e3459255eL)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.Flat3Map:{}\0121=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\uda43\udcad\udb9d\udcce\ud927\udc68\ud9d9\udcfa\ud8a4\ude6f\ud9e2\udeac\ud982\ude8d=\uadcb\u5ab9\u1820\u251d\u52bd\u3a67\uc92f\u0155\u5e52\u3fdf\u75ac\u1662\uc9ad\u5595}\012",
        Z.run(T, 2, 4, 13, 7, "\ud8cf\udd16\uda43\udcad\udb9d\udcce\ud927\udc68\ud9d9\udcfa\ud8a4\ude6f\ud9e2\udeac\ud982\ude8d", "\uadcb\u5ab9\u1820\u251d\u52bd\u3a67\uc92f\u0155\u5e52\u3fdf\u75ac\u1662\uc9ad\u5595", "\ud8f5\udc5d",
        21, 7017, 644767279, 2586174512247557496L, -60691L, true, false, (char) 62606, (char) 22645,
        Double.longBitsToDouble(0x3fe7679edfc683ecL), Double.longBitsToDouble(0x3fddcb9c49382a7cL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\ud989\udcbe\uda55\udee5\ud9f7\udca8\ud8fb\ude97\ud9da\udef3\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda=null}\0121=java.lang.Integer:-1572365859 |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\ud989\udcbe\uda55\udee5\ud9f7\udca8\ud8fb\ude97\ud9da\udef3\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda=null}\012",
        Z.run(T, 2, 13, 9, 4, "\ud8cf\udd16\ud93b\udca9\ud989\udcbe\uda55\udee5\ud9f7\udca8\ud8fb\ude97\ud9da\udef3\ud934\udf5d\ud98e\udf57\uda9d\udf65\ud817\udcda", "\uc2ec\ucde7\u52ef\ua091\u85c6", "\udabe\udf1a\ud99d\udfc2\ud91a\udfa3\ud990\uddb6\ud952\udcc2\udbfa\udef6\udbb3\udf36\ud8c6\udd0b\ud8a9\uddd1\udb20\udcc8\udafe\uded1\udb4a\udd0a\ud902\udf2e\uda1e\udc20\ud8ed\udff3\ud809\udf26\ud820\udc0c\ud934\uddb1",
        4, 81944, -1530804086, 1913180125294928475L, -72949L, false, false, (char) 47647, (char) 37292,
        Double.longBitsToDouble(0x3fdf7e886ddc12f8L), Double.longBitsToDouble(0x3fdf89e9162af198L)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 9, 9, 8, "\u6900", "", "\ud8f8\udc1b",
        54, 99232, 319633976, -8780349577089008152L, 30938L, true, true, (char) 60330, (char) 5063,
        Double.longBitsToDouble(0x3f4408e000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud901\udd82\udbec\udf35\u572b\ud89d\udc00\ud86e\uded2=null}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud901\udd82\udbec\udf35\u572b\ud89d\udc00\ud86e\uded2=null}\012",
        Z.run(T, 2, 13, 4, 8, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\ud901\udd82\udbec\udf35\u572b\ud89d\udc00\ud86e\uded2", "\uae0e\u0da8\u35f8\uc2c8\ub080\u3c8b", "\ud899\udd82\ud8ba\udd83\udab7\udc9c\udb15\udffe\ud9ce\udca5\uda06\udf5d\udb5d\udc04\ud842\udcc5\uda97\udcfc\ud99a\udde2\ue2eb\uda39\udf28\udaed\udddc\ud92b\udffa\ud872\udcfd\ud91f\uddf8\ud9e1\udd28\ud8d2\udf34\ud820\udc18\ud8cf\uddfd",
        52, 65192, -1874453861, 3494450905534792717L, -3423L, false, false, (char) 23855, (char) 6709,
        Double.longBitsToDouble(0x3fdc4fae9048a156L), Double.longBitsToDouble(0x3fe2b6b0c2e0369dL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\uda16\ude2d\udbec\udf35\uda9d\udeee\ud987\udd97\ud86e\uded2=null}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{\ud8cf\udd16\ud93b\udca9\udba9\udfce\uda16\ude2d\udbec\udf35\uda9d\udeee\ud987\udd97\ud86e\uded2=null}\012",
        Z.run(T, 2, 13, 3, 14, "\ud8cf\udd16\ud93b\udca9\udba9\udfce\uda16\ude2d\udbec\udf35\uda9d\udeee\ud987\udd97\ud86e\uded2", "\uae0e\u0da8\u35f8\u62ec\ub080\u3c52\u767f\u0185\ubfea\u8692\u7619\ua31f\u4913\u51c9", "\uda97\udcfc\ud99a\udde2\ue2eb",
        53, 6280, -416652943, -7760670457025879714L, -20278L, true, false, (char) 42886, (char) 2480,
        Double.longBitsToDouble(0x3fb8570ed0303950L), Double.longBitsToDouble(0x3fef42778dc4fae9L)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{\u2854\ufea9\udba9\udfce\ud8e6\udc33\ud99a\udec2\udab2\udc18\udadb\udc09\udaac\udf31=null}\0121=void |this=org.apache.commons.collections.map.Flat3Map:{\u2854\ufea9\udba9\udfce\ud8e6\udc33\ud99a\udec2\udab2\udc18\udadb\udc09\udaac\udf31=null}\012",
        Z.run(T, 2, 13, 4, 0, "\u2854\ufea9\udba9\udfce\ud8e6\udc33\ud99a\udec2\udab2\udc18\udadb\udc09\udaac\udf31", "\u54a2\u5ab9\u3687\uc2ec\u52bd\ubb97\u7b7f\u957a\u72eb\ubb75\u0fa7\u8ac5\u1a63\ub6a3", "\uda9c\udc52\ud8fe\udd65\ud995\udf28\udb20\udc72\uda70\udd89\ud9ab\ude45\uda95\uddd2\ud924\udcf7\udbb6\ude7f\ud904\udd38",
        18, 87727, -501223863, -6147957544944330084L, 75890L, false, false, (char) 8197, (char) 40619,
        Double.longBitsToDouble(0x3fd432d2d28dd6e0L), Double.longBitsToDouble(0x3fe869442db22b8aL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.Flat3Map:{}\012",
        Z.run(T, 2, 10, 7, 13, "\ud913\udc7a\ud93b\udcd1\ud8e4\udc0b\ud8d6\udd1f\ud8bf\udf7b\ud9ed\udfa8\ud819\udebe\ud9b0\udd45\udafe\uddf7\udb7f\ude95\ud9a2\udc57\ud9d2\udc35\ud839\uded9", "\u12a0\ua00b\u6417\u1ab4\u0676\u75ac\u1662\uc9ad\ua6bf\u5daa\u0e5d\ub23c", "\ud87f\ude42\udb24\udd77",
        13, 89700, 23107244, 4481792406608569231L, 35472L, false, false, (char) 57702, (char) 43738,
        Double.longBitsToDouble(0x3fdff2b489a4b1e4L), Double.longBitsToDouble(0x3fef764945b98df6L)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.Flat3Map:{=}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.Flat3Map:{=}\012",
        Z.run(T, 2, 13, 3, 6, "", "", "",
        1, 66746, 1535111219, -3084713578309273032L, -59506L, true, true, (char) 10725, (char) 2722,
        Double.longBitsToDouble(0x3fd86aee98266386L), Double.longBitsToDouble(0x3fe2ba89af6a9782L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.map.Flat3Map|clear||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|clone||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|containsKey|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|containsValue|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|convertToMap||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|createDelegateMap||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|entrySet||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|equals|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|get|java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|hashCode||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|isEmpty||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|keySet||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|mapIterator||new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|put|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|putAll|java.util.Map|new:org.apache.commons.collections.map.Flat3Map:",
    "M|org.apache.commons.collections.map.Flat3Map|readObject|java.io.ObjectInputStream|new:org.apache.commons.collections.map.Flat3Map:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
