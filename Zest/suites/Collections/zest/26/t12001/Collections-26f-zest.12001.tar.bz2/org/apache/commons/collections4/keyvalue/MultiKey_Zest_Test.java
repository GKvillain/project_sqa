package org.apache.commons.collections4.keyvalue;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiKey_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a\u307e]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\0121=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\012",
        Z.run(T, 2, 1, 4, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f", "\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a\u307e", "\ud8a7\udc06\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34",
        4, 65393, 829908308, 3646691050305414278L, 81792L, false, false, (char) 29301, (char) 52404,
        Double.longBitsToDouble(0x3fc45843d8985084L), Double.longBitsToDouble(0x3fdb9191993a3afaL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\uad1a\ub6fb\u322d\u079e\u905d\u5d28\ud628\u0a8b\u7f1e\u61e8\u575a\ua2dc]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\udb22\udc7f\uc73f]\0121=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\udb22\udc7f\uc73f]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\udb22\udc7f\uc73f]\012",
        Z.run(T, 2, 1, 4, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\udb22\udc7f\uc73f", "\uad1a\ub6fb\u322d\u079e\u905d\u5d28\ud628\u0a8b\u7f1e\u61e8\u575a\ua2dc", "\ud8ac\uddcd\udaf2\udfa8\ud85e\udc0e\udaf4\udfff\udb47\udd55",
        5, 66290, 2061957054, -5123921407515302252L, -60422L, false, false, (char) 5921, (char) 27749,
        Double.longBitsToDouble(0x3fc30b70d1597234L), Double.longBitsToDouble(0x3fea84e25960976eL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84, \ua09b\uab27\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a, \ud95f\udc89\ud894\udca8\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23, \udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84, \ua09b\uab27\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a]\0121=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84]\012",
        Z.run(T, 2, 13, 4, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84", "\ua09b\uab27\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a", "\ud95f\udc89\ud894\udca8\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23",
        5, 66290, 233240510, -5123921407515302252L, 31633L, true, false, (char) 16971, (char) 31252,
        Double.longBitsToDouble(0x3fdf6f06233a6486L), Double.longBitsToDouble(0x3fd98f90a3483e40L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u1fbd]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a]\012",
        Z.run(T, 1, 1, 4, 1, "\udba9\uddaf\ud815\udd4a", "\u1fbd", "\udb05\udd2b\ud815\udc49\ud91e\ude4b\udb63\udea0\ud9e4\udf18\uda38\udcf9\ud900\udfe9\ud9c2\ude4d\ud92c\udd86\ud98d\udc2c\ud90a\ude75\uda74\udd9a",
        46, 2680, -1471024847, 312096586872535880L, -56619L, true, false, (char) 42060, (char) 41335,
        Double.longBitsToDouble(0x3fdef43e6d1e3738L), Double.longBitsToDouble(0x3fd0e37a52b31e98L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud8a6\udcb8]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud8a6\udcb8]\0121=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud8a6\udcb8]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud8a6\udcb8]\012",
        Z.run(T, 2, 4, 4, 9, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud8a6\udcb8", "\u2e88\u7e57\u322d\u079e\ub596\ucb7d\u7c5f\u0ab6\uccd0\u5e94\u426d\ua44e", "\ud8a7\udc06\ud936\ude72\uda63\uddce\ud92e\udfaa\udb47\udd60\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34\ud9da\udef3\ud962\udee0\ud9ba\udc43\ud9e2\udd2b",
        44, 35449, 1690010423, 7644932790712472575L, 45495L, false, true, (char) 40435, (char) 65381,
        Double.longBitsToDouble(0x3fc4585db8985084L), Double.longBitsToDouble(0x3fee28c8cc9da94fL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 12, 2, "\udba9\uddaf\ud815\udd4a\uda34\udc79\ud942\udd8f\uc73f", "\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a\u307e", "\ud8a7\udc06\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34",
        4, 65393, 829908308, 3646691050305414278L, 81792L, false, false, (char) 29301, (char) 52404,
        Double.longBitsToDouble(0x3fc45843d8985084L), Double.longBitsToDouble(0x3fdb9191993a3afaL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u8aad\ucd8f\u322d\u079e\ud353\ud578\uce5f\u0ab6\u0718\u9fbc\uc70d\u149f]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud941\ude8f\uc73f]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud941\ude8f\uc73f, \u8aad\ucd8f\u322d\u079e\ud353\ud578\uce5f\u0ab6\u0718\u9fbc\uc70d\u149f, \uda69\udd9b\ud936\udefc\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\u9972\uda39\udea7\ud8be\ude8a\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9bb\udf2c\udaca\udf4d\udb49\udebd\uda70\udc88\ud969\udfef\ud828\udd4f\uda3b\udd45\ud919\udcff\ud9dc\udc64\uda1a\uded1\udb3a\udc02\ud8f1\udeda\ud99c\udc38\uda5a\uddec\udae0\udf7d\udbb6\udc77]\012",
        Z.run(T, 2, 1, 11, 1, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud941\ude8f\uc73f", "\u8aad\ucd8f\u322d\u079e\ud353\ud578\uce5f\u0ab6\u0718\u9fbc\uc70d\u149f", "\uda69\udd9b\ud936\udefc\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\u9972\uda39\udea7\ud8be\ude8a\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9bb\udf2c\udaca\udf4d\udb49\udebd\uda70\udc88\ud969\udfef\ud828\udd4f\uda3b\udd45\ud919\udcff\ud9dc\udc64\uda1a\uded1\udb3a\udc02\ud8f1\udeda\ud99c\udc38\uda5a\uddec\udae0\udf7d\udbb6\udc77",
        -4, 8822, 1545091279, 2888692745821574153L, 51928L, true, true, (char) 6794, (char) 40969,
        Double.longBitsToDouble(0x3fe042e4be45f804L), Double.longBitsToDouble(0x3fe7cdce53fe7664L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\ua57f\u61e8\u575a\u307e]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f] |a0=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]]\012",
        Z.run(T, 2, 1, 8, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f", "\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\ua57f\u61e8\u575a\u307e", "\ud815\udc65\ud936\udebf\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34\udb4e\udd5c\ud962\udee0\ud8f0\udc3e",
        24, 12774, 1535572313, -8393696615330791004L, -13262L, true, true, (char) 18385, (char) 64250,
        Double.longBitsToDouble(0x3fe7a29a4aa4bfd1L), Double.longBitsToDouble(0x3feef186b8a2c21eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0a90\u7f1e\u61e8\u575a\u307e]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f, \u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0a90\u7f1e\u61e8\u575a\u307e, \ud8a7\udc86\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd84\udba2\udd34, \udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\012",
        Z.run(T, 2, 1, 12, 8, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f", "\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0a90\u7f1e\u61e8\u575a\u307e", "\ud8a7\udc86\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd84\udba2\udd34",
        4, 65393, 829908308, 3646691050305414278L, 81792L, false, false, (char) 26981, (char) 52404,
        Double.longBitsToDouble(0x3fc45843d8985084L), Double.longBitsToDouble(0x3fdb9191993a3afaL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u2e88\u7856\u322d\uc32e\ud353\u5a7d\u9569\ud383\ub98a\u61e8\u016a\u5a62\u1744\u24d8]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud80e\udd08\ud906\ude6c\ud942\udd8f\uc9f6]\0121=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud80e\udd08\ud906\ude6c\ud942\udd8f\uc9f6] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud80e\udd08\ud906\ude6c\ud942\udd8f\uc9f6]\012",
        Z.run(T, 2, 1, 0, 9, "\udba9\uddaf\ud80e\udd08\ud906\ude6c\ud942\udd8f\uc9f6", "\u2e88\u7856\u322d\uc32e\ud353\u5a7d\u9569\ud383\ub98a\u61e8\u016a\u5a62\u1744\u24d8", "\udac6\ude65",
        -3, 34235, 861035965, -6216813591330883650L, -93492L, false, true, (char) 52675, (char) 4611,
        Double.longBitsToDouble(0x3fd54dcf6c6062eeL), Double.longBitsToDouble(0x3fc0c6536565cc30L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f] |a0=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]]\0121=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\012",
        Z.run(T, 2, 9, 4, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f", "\u2e88\u7e57\u322d\u079e\u1f46\u5a7d\u7c5f\u0ab6\ud56b\u6138\u575a\u307e", "\ud8a7\udc06\ud936\ude72\udaf5\ude5a\000\udb47\udc98\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34",
        4, 2537, 829908308, 3646691050305414278L, 81792L, false, false, (char) 29301, (char) 52404,
        Double.longBitsToDouble(0x3fc45843d8985084L), Double.longBitsToDouble(0x3fdb919198003afaL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 1, 2, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f\ud94f\udc11\udb17\udec8\ud8bf\udc4d\ud815\udc25\ud91e\ude4b\udb63\udea0\u0808\uda38\udc72\ud900\udfe9\ud9c2\ude4d\ud96e\udca7\ud98d\udc2c\ud952\ude79\uda74\udd9a\udbbd\udfbb\udb65\udf73\ud8a7\udc06\ud936\ude72", "\u7a53", "\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9e2\udd2b\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\uda3b\udd45\ud97e\ude47\ud826\ude24\udb3f\udd78",
        46, 28340, -1038181410, 1450458844892505638L, -37379L, true, true, (char) 31635, (char) 49614,
        Double.longBitsToDouble(0x3fcf7f8dc74fa0c0L), Double.longBitsToDouble(0x3fcc8b391d19b1f4L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a\u307e]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\012",
        Z.run(T, 2, 1, 2, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f", "\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a\u307e", "\ud8a7\udc06\ud936\ude72\u54ac\uda8c\ude3b\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34",
        4, 65393, 829908308, 3646691050318455942L, 81792L, false, false, (char) 29301, (char) 52404,
        Double.longBitsToDouble(0x3fc45843d8985084L), Double.longBitsToDouble(0x3fdb9191993a3afaL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\udd30, \uba28\u1fbd\u2219\u0755\u00dc\000\u3169\ua264\ud30e\u5a7d, \ud853\udd79, null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 12, 0, 0, "\udba9\udd30", "\uba28\u1fbd\u2219\u0755\u00dc\000\u3169\ua264\ud30e\u5a7d", "\ud853\udd79",
        -5, -1000, 0, -2694109220411738784L, -34464L, true, false, (char) 17903, (char) 42060,
        Double.longBitsToDouble(0x3fedf54dc8a10de6L), Double.longBitsToDouble(0x3fe4a5c720000007L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf, \uba28\u1fbd\u2219\u0755\u2e88\u7e57\u322d\u079e\ud353\u5a7d, \ud92c\udd86\ud98d\udc2c]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf, \uba28\u1fbd\u2219\u0755\u2e88\u7e57\u322d\u079e\ud353\u5a7d, \ud92c\udd86\ud98d\udc2c, \udba9\uddaf]\012",
        Z.run(T, 2, 11, 12, 2, "\udba9\uddaf", "\uba28\u1fbd\u2219\u0755\u2e88\u7e57\u322d\u079e\ud353\u5a7d", "\ud92c\udd86\ud98d\udc2c",
        12, 44739, -627271184, 269791194640689L, 46248L, false, false, (char) 21133, (char) 17903,
        Double.longBitsToDouble(0x3fcf466a5efaa6e4L), Double.longBitsToDouble(0x3fc421bcda52e390L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\0121=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\012",
        Z.run(T, 2, 0, 0, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f", "\u2e88\u7e57\u322d\u079e\ud353\uc57c\u7c5f\u0ab6\u7f1e\u61e8\u575a\u52eb", "",
        37, 45649, 874920776, 281474574057472L, -100000L, false, false, (char) 0, (char) 40596,
        Double.longBitsToDouble(0x3fe53d4038000038L), Double.longBitsToDouble(0x3e05370000000000L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u8330\u5c61\u7f1e\u61e8\u575a\u307e]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\ud990\udfe3\udb29\ude31\uda63\udf9b\ud942\udd8f\uc73f]\0121=!java.lang.ArrayIndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 3, 1, "\ud990\udfe3\udb29\ude31\uda63\udf9b\ud942\udd8f\uc73f", "\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u8330\u5c61\u7f1e\u61e8\u575a\u307e", "\ud8a7\udc06\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34",
        4, 65393, 829908308, 3646691050305414278L, 81792L, false, false, (char) 29301, (char) 52404,
        Double.longBitsToDouble(0x3fc45843d8985084L), Double.longBitsToDouble(0x3fdb9191993a3afaL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f, \u721c\u4f6b\u322d\u079e\ud353\u5a7d\u7c5f\u93b5\u7f1e\u61e8\u575a\u307e, \ud8a7\udc06\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34, \udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f, \u721c\u4f6b\u322d\u079e\ud353\u5a7d\u7c5f\u93b5\u7f1e\u61e8\u575a\u307e, \ud8a7\udc06\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34, \udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f]\012",
        Z.run(T, 2, 12, 12, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\uc73f", "\u721c\u4f6b\u322d\u079e\ud353\u5a7d\u7c5f\u93b5\u7f1e\u61e8\u575a\u307e", "\ud8a7\udc06\ud936\ude72\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64\udba2\udd34",
        4, 65393, 829908308, 3646691050305414278L, -570L, false, false, (char) 18575, (char) 15582,
        Double.longBitsToDouble(0x3fdb1a1d9bb213f0L), Double.longBitsToDouble(0x3fde0c11a5e8a692L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.String:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud93f\udc80\uc73f] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud93f\udc80\uc73f]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud93f\udc80\uc73f, \u2e88\u7e57\u322d\u079e\ud353\u25bf\ud4de\u0b0b\u1f9c\u4f8b\u5b05\u361d]\012",
        Z.run(T, 2, 7, 10, 12, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud93f\udc80\uc73f", "\u2e88\u7e57\u322d\u079e\ud353\u25bf\ud4de\u0b0b\u1f9c\u4f8b\u5b05\u361d", "\ud8a7\udc06\udbe3\udf29\ud87b\udc74\ud855\udf92\udb6d\ude21\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb5a\udd64",
        57, 23289, -587854607, -8189403037602088899L, -68869L, false, true, (char) 55020, (char) 17614,
        Double.longBitsToDouble(0x3fd3f5a278f907c4L), Double.longBitsToDouble(0x3fdd912983c18234L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 8, 4, 2, "\ud9c7\udcaa\udb3c\udd0a\uda6f\udf19\u1332\uc73f", "\u2e88\u7e57\u322d\u69de\u6087\u5aef\u7c5f\u0ab6\ud557\u61e8\u5e5b\u3363", "\ud8a7\udc06\ud8ea\udd50\ud838\udca2\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udbde\udd8e",
        50, 34772, 1865945767, 365356928649353969L, 94905L, false, true, (char) 52519, (char) 32462,
        Double.longBitsToDouble(0x3fe6978f79b1a1d9L), Double.longBitsToDouble(0x3fdd909f83c18234L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u8bef]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udb9f\udd08]\0121=void |a0=[Ljava.lang.Object;:[[\udb9f\udd08]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udb9f\udd08]\012",
        Z.run(T, 2, 1, 1, 2, "\udb9f\udd08", "\u8bef", "\ud927\udcdf",
        10, 65883, 2143302340, 5181569920481949509L, 38092L, true, true, (char) 54726, (char) 1440,
        Double.longBitsToDouble(0x3fef9d7ea2eb7d19L), Double.longBitsToDouble(0x3fdf0e9b4ac1b538L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud87c\udecc\ud9c8\ude16, \u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a\u053c, \ud8a7\udc06\ud936\ude72\udaf5\ude5a\udb85\udc07\udb47\udd23\ud930\udd08\uda65\udd0d\udb90\udf28\udb16\udc38\udb5a\udcf4\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9e2\udd2b\udaca\udf4d\udb49\udebd\uda6a\ude88]\012",
        Z.run(T, 1, 11, 4, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud87c\udecc\ud9c8\ude16", "\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a\u053c", "\ud8a7\udc06\ud936\ude72\udaf5\ude5a\udb85\udc07\udb47\udd23\ud930\udd08\uda65\udd0d\udb90\udf28\udb16\udc38\udb5a\udcf4\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9e2\udd2b\udaca\udf4d\udb49\udebd\uda6a\ude88",
        2, 34463, -1579593006, 718396367975366105L, 17492L, false, false, (char) 52404, (char) 53952,
        Double.longBitsToDouble(0x3fe130a10db91919L), Double.longBitsToDouble(0x3fc3a3afb0f2682cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\ud8c0\udf51\udb2b\udffd\ud91f\udf6b\ud942\udd8f\udbbe\udd84\ud8ea\udc49\udaf9\udc5e\ud864\ude5f\udb8c\udc5f\ud91e\ude4b\udb63\udea0\ud9e4\udf18\uda38\udcf9\ud900\udfe9\uda9f\udc7b\udacc\udd88\udaa1\udc0c\ud89d\udd34\uda72\ude9c\udbbd\udfbb\ud95f\udc89\ud894\udca8, \u4f80, \ud970\udfe4, \ud8c0\udf51\udb2b\udffd\ud91f\udf6b\ud942\udd8f\udbbe\udd84\ud8ea\udc49\udaf9\udc5e\ud864\ude5f\udb8c\udc5f\ud91e\ude4b\udb63\udea0\ud9e4\udf18\uda38\udcf9\ud900\udfe9\uda9f\udc7b\udacc\udd88\udaa1\udc0c\ud89d\udd34\uda72\ude9c\udbbd\udfbb\ud95f\udc89\ud894\udca8, null]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\ud8c0\udf51\udb2b\udffd\ud91f\udf6b\ud942\udd8f\udbbe\udd84\ud8ea\udc49\udaf9\udc5e\ud864\ude5f\udb8c\udc5f\ud91e\ude4b\udb63\udea0\ud9e4\udf18\uda38\udcf9\ud900\udfe9\uda9f\udc7b\udacc\udd88\udaa1\udc0c\ud89d\udd34\uda72\ude9c\udbbd\udfbb\ud95f\udc89\ud894\udca8, \u4f80, \ud970\udfe4, null]\012",
        Z.run(T, 2, 13, 12, 5, "\ud8c0\udf51\udb2b\udffd\ud91f\udf6b\ud942\udd8f\udbbe\udd84\ud8ea\udc49\udaf9\udc5e\ud864\ude5f\udb8c\udc5f\ud91e\ude4b\udb63\udea0\ud9e4\udf18\uda38\udcf9\ud900\udfe9\uda9f\udc7b\udacc\udd88\udaa1\udc0c\ud89d\udd34\uda72\ude9c\udbbd\udfbb\ud95f\udc89\ud894\udca8", "\u4f80", "\ud970\udfe4",
        30, 5081, -1475877228, 8014176045460932913L, -60404L, true, false, (char) 15961, (char) 11232,
        Double.longBitsToDouble(0x3feb77c854d43f1aL), Double.longBitsToDouble(0x3fea7d7a3910a4bdL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84, \ua09b\uab27\ud538\uc611\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a, \ud979\udd81\ud894\udca8\ud985\udf2b\udad0\uddeb\uda5a\ude22\udb47\udcc6\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb58\udd64\udba2\udd34\ud9da\ude7d\ud962\udee0\ud995\udcf1\ud989\udfb1\ud902\udcec\ub134\uda66\udf6d, \udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84, null]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84, \ua09b\uab27\ud538\uc611\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a, \ud979\udd81\ud894\udca8\ud985\udf2b\udad0\uddeb\uda5a\ude22\udb47\udcc6\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb58\udd64\udba2\udd34\ud9da\ude7d\ud962\udee0\ud995\udcf1\ud989\udfb1\ud902\udcec\ub134\uda66\udf6d, \udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84, null]\012",
        Z.run(T, 2, 13, 13, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84", "\ua09b\uab27\ud538\uc611\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a", "\ud979\udd81\ud894\udca8\ud985\udf2b\udad0\uddeb\uda5a\ude22\udb47\udcc6\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\ud8aa\udc70\udb58\udd64\udba2\udd34\ud9da\ude7d\ud962\udee0\ud995\udcf1\ud989\udfb1\ud902\udcec\ub134\uda66\udf6d",
        -5, 38794, -1591721943, -132412885659702368L, 27525L, false, false, (char) 9499, (char) 63893,
        Double.longBitsToDouble(0x3fe5d8acb103b5bbL), Double.longBitsToDouble(0x3fd9b278d1cf5734L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84, \u2cca\uab27\u322d\u137a\ubd0c\u5a7d\u7c5f\uccde\u7c93\u61e8\u575a, \ud95f\udc89]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84, \u2cca\uab27\u322d\u137a\ubd0c\u5a7d\u7c5f\uccde\u7c93\u61e8\u575a, \ud95f\udc89]\012",
        Z.run(T, 2, 11, 11, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\udbbe\udd84", "\u2cca\uab27\u322d\u137a\ubd0c\u5a7d\u7c5f\uccde\u7c93\u61e8\u575a", "\ud95f\udc89",
        39, 45649, 874920776, -287750731783383413L, -5542L, false, true, (char) 14983, (char) 40824,
        Double.longBitsToDouble(0x3fe53d403a316f38L), Double.longBitsToDouble(0x3fdf10512da01bd0L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf, \uba28\ubd73\u2470\u5c3c\ua4d9\u7de0\u419d\uac54\ud353\u5a7d, \uda4d\udff2\uda85\udf93, \udba9\uddaf, null]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 13, 8, 2, "\udba9\uddaf", "\uba28\ubd73\u2470\u5c3c\ua4d9\u7de0\u419d\uac54\ud353\u5a7d", "\uda4d\udff2\uda85\udf93",
        31, 45882, 137136867, 7513887099235444179L, 46248L, false, false, (char) 21133, (char) 17903,
        Double.longBitsToDouble(0x3fcf466a5efaa6e4L), Double.longBitsToDouble(0x3fc421bcda52e390L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud941\ude8f\uc73f]\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud941\ude8f\uc73f]\012",
        Z.run(T, 2, 2, 2, 1, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud941\ude8f\uc73f", "\u8aad\ucd8f\u322d\u0518\ucc7e\ud578\uce5f\u0ab6\u0718\u9fbc\uc70d\u149f", "\uda58\udd9b\ud936\udefc\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\u9972\uda39\udea7\ud8be\ude8a\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9bb\udf2c\udaca\udf4d\udb49\udebd\uda70\udc88\ud969\udfef\ud828\udd4f\uda3b\udd45\ud919\udcff\ud9dc\udc64\uda1a\uded1\udb3a\udc02\ud948\udfd0\ud99c\udc38\uda5a\uddec\udae0\udf7d\udbb6\udc77",
        -4, 8822, 1545091279, 2888692745821574153L, 51928L, true, true, (char) 6794, (char) 40969,
        Double.longBitsToDouble(0x3fe042e4be45f804L), Double.longBitsToDouble(0x3fe7cdce53f59964L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\u6cb2\ud941\ude8f\uc73f] |a0=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\u6cb2\ud941\ude8f\uc73f]]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\u6cb2\ud941\ude8f\uc73f] |a0=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\u6cb2\ud941\ude8f\uc73f]]\012",
        Z.run(T, 2, 8, 8, 8, "\udba9\uddaf\ud815\udd4a\u6cb2\ud941\ude8f\uc73f", "\u8aad\ucd8f\u2736\u07e4\ud353\ud578\uce5f\u0ab6\u0718\u9fbc\uc70d\u5de8", "\uda69\udd9b\ud936\udefc\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\udba2\udd24\u9972\uda39\udea7\ud8be\ude8a\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9bb\udf2c\udaca\udf4d\udba4\udcab",
        54, 9208, 1512510463, -6784300300819174991L, 48845L, false, true, (char) 49743, (char) 52242,
        Double.longBitsToDouble(0x3fc45843cea857a8L), Double.longBitsToDouble(0x3fde99adc93a3b3eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud80e\udd08\ud906\ude6c\ud942\udd8f\uc9f6, \u2e88\u7856\u322d\uc32e\ud353\u5a7d\u9569\ud383\ub98a\u61e8\u016a\u5a62\u1744\u24d8]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud80e\udd08\ud906\ude6c\ud942\udd8f\uc9f6, \u2e88\u7856\u322d\uc32e\ud353\u5a7d\u9569\ud383\ub98a\u61e8\u016a\u5a62\u1744\u24d8]\012",
        Z.run(T, 2, 10, 10, 9, "\udba9\uddaf\ud80e\udd08\ud906\ude6c\ud942\udd8f\uc9f6", "\u2e88\u7856\u322d\uc32e\ud353\u5a7d\u9569\ud383\ub98a\u61e8\u016a\u5a62\u1744\u24d8", "\udac6\ude65",
        -3, 34235, 861035965, -6216813590254520386L, -93492L, false, true, (char) 52675, (char) 4611,
        Double.longBitsToDouble(0x3fd54dcf6c6062eeL), Double.longBitsToDouble(0x3fc0c6537965cc30L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud948\udc31]\0121=[Ljava.lang.Object;:[[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud948\udc31]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud948\udc31]\012",
        Z.run(T, 2, 1, 4, 2, "\udba9\uddaf\ud815\udd4a\uda48\ude87\ud942\udd8f\ud948\udc31", "\u2e88\u7e57\u322d\u079e\ud353\u5a7d\u7c5f\u0ab6\u7f1e\u61e8\u575a", "\udb65\udf73\ud8a7\udc06\ud936\ude72\udaff\udcff\ud833\udeb1\udb33\udfc1",
        5, 66290, 233240510, -5123921407515302252L, -80679L, true, false, (char) 58442, (char) 19923,
        Double.longBitsToDouble(0x3fc0c65ae565cc30L), Double.longBitsToDouble(0x3fd665b863491706L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\u1258\u1fea\ua37f\u5dbc\u444f\ubd00\u854b\u4154\u6553\u9405\u5e2c\u3fc9\u2311\u3021\ucdb9\u6806\uaa0d\u524b\u82fc\u2aae\u0726\u7b97\u57d3\u1d4d\u89ba\uc208\u3f23\ub884\u62c7\u7e93]] |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udaab\udec6\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\ud906\udf34\ud9f3\udce8\udb9d\udf58\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud878\ude15\udbc5\udfb7\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\udb93\udc47\udb5a\udd1f\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9b8\udd23\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud90a\udf4b\udb70\udc29\udbf4\ude86\ud9af\udc28\udb9e\ude72\ud9d1\udc87\ud825\uddee\ud8ef\udc81\ud892\ude0c\uda6f\ude4a\ud93b\udc3b\ud80f\udfcb\ud844\uddfa\ud8f7\udc76]\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udaab\udec6\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\ud906\udf34\ud9f3\udce8\udb9d\udf58\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud878\ude15\udbc5\udfb7\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\udb93\udc47\udb5a\udd1f\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9b8\udd23\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud90a\udf4b\udb70\udc29\udbf4\ude86\ud9af\udc28\udb9e\ude72\ud9d1\udc87\ud825\uddee\ud8ef\udc81\ud892\ude0c\uda6f\ude4a\ud93b\udc3b\ud80f\udfcb\ud844\uddfa\ud8f7\udc76, \u1258\u1fea\ua37f\u5dbc\u444f\ubd00\u854b\u4154\u6553\u9405\u5e2c\u3fc9\u2311\u3021\ucdb9\u6806\uaa0d\u524b\u82fc\u2aae\u0726\u7b97\u57d3\u1d4d\u89ba\uc208\u3f23\ub884\u62c7\u7e93, \u67b8, \udaab\udec6\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\ud906\udf34\ud9f3\udce8\udb9d\udf58\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud878\ude15\udbc5\udfb7\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\udb93\udc47\udb5a\udd1f\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9b8\udd23\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud90a\udf4b\udb70\udc29\udbf4\ude86...\012",
        Z.run(T, 2, 1, 12, 8, "\udaab\udec6\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\ud906\udf34\ud9f3\udce8\udb9d\udf58\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud878\ude15\udbc5\udfb7\udaf5\ude5a\udaf4\udfff\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8f\udb93\udc47\udb5a\udd1f\udba2\udd34\ud9da\ude7d\ud962\udee0\ud8f0\udc3e\ud9b8\udd23\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud90a\udf4b\udb70\udc29\udbf4\ude86\ud9af\udc28\udb9e\ude72\ud9d1\udc87\ud825\uddee\ud8ef\udc81\ud892\ude0c\uda6f\ude4a\ud93b\udc3b\ud80f\udfcb\ud844\uddfa\ud8f7\udc76", "\u1258\u1fea\ua37f\u5dbc\u444f\ubd00\u854b\u4154\u6553\u9405\u5e2c\u3fc9\u2311\u3021\ucdb9\u6806\uaa0d\u524b\u82fc\u2aae\u0726\u7b97\u57d3\u1d4d\u89ba\uc208\u3f23\ub884\u62c7\u7e93", "\u67b8",
        -5, 14183, -522637533, 7428739734621580013L, 31581L, false, false, (char) 40104, (char) 51232,
        Double.longBitsToDouble(0x3fe58fd54af250d8L), Double.longBitsToDouble(0x3fe8968fabffd14fL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udaab\udf40\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\udabc\udd6f\ud9e2\udebe\ud893\ude86\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud84e\udc23\udbc5\udfb7\ufb79\uda88\udef4\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8e\udb93\udc47\uda2c\udfa8\ud83f\uddbd\ud9da\ude92\ud962\udee0\ud8f0\udc3e\uda64\udc27\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud957\ude1a\ud84c\udd2c\udb7e\uddab\ud9af\udc28\uda11\udf73\ud9d1\udc87\udb38\udc57\ud91a\udc25\ud892\ude0c\uda6f\ude4a\ud93b\udc3b\ud80f\udfcb\ud810\udea0\ud8f7\udc76, \u1258\u1fea\u8607\u5dbc\u444f\ubd00, \ud9f7\udc0e\udab2\udd7c\udb69\udff1\udb29\udd01, \udaab\udf40\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\udabc\udd6f\ud9e2\udebe\ud893\ude86\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud84e\udc23\udbc5\udfb7\ufb79\uda88\udef4\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8e\udb93\udc47\uda2c\udfa8\ud83f\uddbd\ud9da\ude92\ud962\udee0\ud8f0\udc3e\uda64\udc27\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud957\ude1a\ud84c\udd2c\udb7e\uddab\ud9af\udc28\uda11\udf73\ud9d1\udc87\udb38\udc57\ud91a\udc25\ud892\ude0c\uda6f\ude4a\ud93b\udc3b\ud80f\udfcb\ud810...\0121=new org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\udaab\udf40\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\udabc\udd6f\ud9e2\udebe\ud893\ude86\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud84e\udc23\udbc5\udfb7\ufb79\uda88\udef4\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8e\udb93\udc47\uda2c\udfa8\ud83f\uddbd\ud9da\ude92\ud962\udee0\ud8f0\udc3e\uda64\udc27\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud957\ude1a\ud84c\udd2c\udb7e\uddab\ud9af\udc28\uda11\udf73\ud9d1\udc87\udb38\udc57\ud91a\udc25\ud892\ude0c\uda6f\ude4a\ud93b\udc3b\ud80f\udfcb\ud810\udea0\ud8f7\udc76, \u1258\u1fea\u8607\u5dbc\u444f\ubd00, \ud9f7\udc0e\udab2\udd7c\udb69\udff1\udb29\udd01, \udaab\udf40\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\udabc\udd6f\ud9e2\udebe\ud893\ude86\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud84e\udc23\udbc5\udfb7\ufb79\uda88\udef4\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8e\udb93\udc47\uda2c\udfa8\ud83f\uddbd\ud9da\ude92\ud962\udee0\ud8f0\udc3e\uda64\udc27\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud957\ude1a\ud84c\udd2c\udb7e\uddab\ud9af\udc28\uda11\udf73\ud9d1\udc87\udb38\udc57\ud91a\udc25\ud892\ude0c\uda6f\ude4a\ud93b\udc3b\ud80f\udfcb\ud810...\012",
        Z.run(T, 2, 13, 12, 8, "\udaab\udf40\ud815\udd9c\uda48\ude87\ud942\udd8f\ud824\udc78\ud94f\udc11\ud992\udd25\ud8be\udff4\ud815\udc25\ud857\ude45\udabc\udd6f\ud9e2\udebe\ud893\ude86\ud9d8\udee0\ud9c2\ude27\ud92c\udd86\ud9fe\udd25\ud9ff\udfcc\uda74\udcbe\udbbd\udfbb\udb8f\udfbf\ud84e\udc23\udbc5\udfb7\ufb79\uda88\udef4\udb47\udd23\ud8e6\udcc3\ud970\udfe4\udae2\udc8e\udb93\udc47\uda2c\udfa8\ud83f\uddbd\ud9da\ude92\ud962\udee0\ud8f0\udc3e\uda64\udc27\udaca\udf4d\udb49\udebd\uda6a\ude88\ud969\udfef\ud828\udd4f\ud92e\uddde\ud97e\ude47\ud964\ude82\ud9e1\udec8\ud8b3\udef2\ud9cd\udc1b\udbc0\udf5e\ud871\uddd8\uda7f\udfa0\udba7\udf75\udbef\udc14\udaaf\udd6b\uda7f\udcce\uda71\udd83\ud957\ude1a\ud84c\udd2c\udb7e\uddab\ud9af\udc28\uda11\udf73\ud9d1\udc87\udb38\udc57\ud91a\udc25\ud892\ude0c\uda6f\ude4a\ud93b\udc3b\ud80f\udfcb\ud810\udea0\ud8f7\udc76", "\u1258\u1fea\u8607\u5dbc\u444f\ubd00", "\ud9f7\udc0e\udab2\udd7c\udb69\udff1\udb29\udd01",
        22, 2121, 1361360270, -7591260400261643357L, 16341L, false, true, (char) 65180, (char) 47550,
        Double.longBitsToDouble(0x3fe65173732b6b1aL), Double.longBitsToDouble(0x3fbd0b92f4132118L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.String:\ud990\udfe3\udb29\ude31 |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\ud990\udfe3\udb29\ude31]\0121=java.lang.String:\ud990\udfe3\udb29\ude31 |this=org.apache.commons.collections4.keyvalue.MultiKey:MultiKey[\ud990\udfe3\udb29\ude31]\012",
        Z.run(T, 2, 3, 3, 1, "\ud990\udfe3\udb29\ude31", "\u1fbd", "\ud861\udc3e\ud815\udc6a\ud91e\ude4b\udb63\udea0\ud9e4\udf18\uda38\udcf9\ud8b0\udca0\ud952\udf7e\ud92c\udd86\ud98d\udc2c\ud90a\ude75\uda74\udd9a",
        0, 19766, -1471024847, -6259136490481763512L, -55083L, false, true, (char) 42116, (char) 41335,
        Double.longBitsToDouble(0x3fc421bcda52e390L), Double.longBitsToDouble(0x3fc598bfafe63100L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections4.keyvalue.MultiKey|readResolve||new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections4.keyvalue.MultiKey|calculateHashCode|[Ljava.lang.Object;|new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections4.keyvalue.MultiKey|equals|java.lang.Object|new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections4.keyvalue.MultiKey|getKey|int|new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections4.keyvalue.MultiKey|getKeys||new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections4.keyvalue.MultiKey|hashCode||new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections4.keyvalue.MultiKey|size||new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
    "M|org.apache.commons.collections4.keyvalue.MultiKey|toString||new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
    "C|org.apache.commons.collections4.keyvalue.MultiKey|<init>|[Ljava.lang.Object;,boolean",
    "C|org.apache.commons.collections4.keyvalue.MultiKey|<init>|[Ljava.lang.Object;",
    "C|org.apache.commons.collections4.keyvalue.MultiKey|<init>|java.lang.Object,java.lang.Object",
    "C|org.apache.commons.collections4.keyvalue.MultiKey|<init>|java.lang.Object,java.lang.Object,java.lang.Object",
    "C|org.apache.commons.collections4.keyvalue.MultiKey|<init>|java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object",
    "C|org.apache.commons.collections4.keyvalue.MultiKey|<init>|java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object,java.lang.Object",
    "M|org.apache.commons.collections4.keyvalue.MultiKey|readResolve||new:org.apache.commons.collections4.keyvalue.MultiKey:[Ljava.lang.Object;",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
