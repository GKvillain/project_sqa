package org.apache.commons.collections4.trie;
import org.junit.Test;
import static org.junit.Assert.*;
public class AbstractPatriciaTrie_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 7, 6, 10, "\ud841\udc3d", "\u42ba", "\ud891\udf07",
        22, 87148, -577595697, -4569946585305916920L, 32501L, false, true, (char) 59528, (char) 54088,
        Double.longBitsToDouble(0x3f9a1e1b65dc41c0L), Double.longBitsToDouble(0x3fd3de8ceef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 7, 6, 10, "\udbee\udd33", "\ubc4e\u95ca\u23b2\u2170\u39e6\u2880\u3e01", "\ud828\udc17\udba0\udf3c",
        44, 59737, 505115706, -2157782662137343186L, 8843L, true, true, (char) 23822, (char) 46239,
        Double.longBitsToDouble(0x3fe09a496417e0c0L), Double.longBitsToDouble(0x3fedb77c5d12c5daL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 0, 11, 10, "\udb95\udd15", "\uccb9\ubb8d\u5d35\u9d67\ub77f", "\ud899\ude0e",
        40, 5690, -1460209045, -1690567951145238529L, 35315L, false, true, (char) 17917, (char) 5277,
        Double.longBitsToDouble(0x3fe703be85331ab2L), Double.longBitsToDouble(0x3fa1928e2e7806e0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 4, 5, 2, "\udaba\ude0c", "\u42ba\ub096", "\udab1\udef1\ud938\ude81\uda57\udcc7\ud899\ude0e\udadc\udf3a\ud828\udc17\udba0\udf3c\ud404\ud8dd\uddac\ud8ab\udcbb\ud8ba\ude56\ud82a\uddd0\ud905\udf61\ud922\ude24\udbbe\uddc5\udbba\udd6e",
        14, 75701, 1033624836, 7363645228787126590L, 5679L, false, false, (char) 37766, (char) 28749,
        Double.longBitsToDouble(0x3fee69f1c1c12d3eL), Double.longBitsToDouble(0x3fe5704da85bb8b7L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 2, 6, 10, "\ud841\udc3d", "\u42ba\ub096\u1a59\u69bf\uba15", "\ud952\udcce\ud85d\uddb5\ud82b\udc17\udb89\udfdf\ud404\udb24\udc10\ud8c1\udc44",
        4, 10030, 1748494680, -6644173428939233241L, -3230L, false, true, (char) 38880, (char) 58987,
        Double.longBitsToDouble(0x3fbc779e449fbbe0L), Double.longBitsToDouble(0x3fd75b75c3abb7b6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry:RootEntry(key=null [-1], value=null, parent=null, left=ROOT, right=null, predecessor=ROOT) |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 14, 9, 6, "\ud841\udc3d", "\u42ba", "\ud891\udf07",
        22, 87148, -577595697, -4569946585305916920L, 32501L, false, true, (char) 59528, (char) 54088,
        Double.longBitsToDouble(0x3f9a1e1b65dc41c0L), Double.longBitsToDouble(0x3fd3de8ceef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$EntrySet:[] |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 6, 2, 7, "\udb88\udc82", "\u42ba", "\ud891\udf07\udab1\udef1\ud938\ude81",
        18, 10395, 341105160, -892714580924827029L, -99999L, true, false, (char) 13630, (char) 30012,
        Double.longBitsToDouble(0x3fd3de8ceef0d06eL), Double.longBitsToDouble(0x3fb3d4da006f3600L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.util.NoSuchElementException\012",
        Z.run(T, 1, 8, 6, 6, "\ud841\udc3d", "\u42ba", "\udb54\ude33",
        0, 85558, 2089981647, -6947962235856560632L, 32501L, false, true, (char) 59528, (char) 54088,
        Double.longBitsToDouble(0x3f9a1e1b65dc41c0L), Double.longBitsToDouble(0x3fd3de8ceef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 9, 11, 10, "\udaae\udf9c", "\u67d2\ub0a8\u8353\u2170\u399b\ubf8d\u3e01", "\ud827\udf74\udba0\udf3c",
        23, 61071, 1125887360, 4448047785533870894L, 50904L, true, true, (char) 23581, (char) 21406,
        Double.longBitsToDouble(0x3fdd1b83280e52d6L), Double.longBitsToDouble(0x3fee1ee394fc8e41L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 6, 5, "\ud82c\udd73", "\u42ba", "\ud891\udf07",
        22, 87148, -577595697, -9118140205280205630L, -19979L, false, true, (char) 60643, (char) 35235,
        Double.longBitsToDouble(0x3fe5571bf32ee20eL), Double.longBitsToDouble(0x3fd3de8ce8b3ca8aL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 2, 6, 10, "\ud841\udc3d", "\u42ba", "\ud891\udf07",
        22, 87148, -577595697, -4569946585305916920L, 82421L, false, true, (char) 59528, (char) 54088,
        Double.longBitsToDouble(0x3f9a1e1b65dc41c0L), Double.longBitsToDouble(0x3fc1c9b9cde1a2a8L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$EntrySet:[] |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 7, 6, 15, "\udb23\udfef", "\u42ba", "\ud891\udf07\udab1\udef1\ud938\ude81\udbbb\udd94\u4a12\udb0e\udd81\ud828\udc17\udba0\udf3c\ud404\ud831\udcb7\ud8ab\udc4b\ud8ea\udea4\udbbd\ude9a\udbff\ude44\uda2f\udc07\ud9fd\udfc5\uda4f\udcea\udbf6\ude88\udbe1\udd30\ud9c9\udf6e\uda9f\udc1d\ud975\udff8\ud81f\udff0\ud81e\udecf\ud942\udd56\ud9ae\udd00\udba8\udf03\ud948\ude17\ud836\udfca\udb03\udcce\uda66\udec4\ud9a2\udf6a\udab5\ude6a\uda02\udc1d\udb4f\ude77\udb91\udd24\ud90d\ude5f\udb30\ude57\udb31\udfab\uda9d\udc86\udad6\udcef\uda11\udcbe\ud848\udd6d\ud9e3\udc91\uda56\udccb\ud89e\udf7d\ud9eb\ude78\uda04\uddaf\ua0ba\uda0d\uddaa\udbd3\udde7\ud9c4\udecf\ud805\udc73",
        48, 81974, 1542807514, 4327813231320984777L, 66708L, false, true, (char) 34108, (char) 20634,
        Double.longBitsToDouble(0x3fed7fc238d7a10cL), Double.longBitsToDouble(0x3fca58801b8b0b60L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry:RootEntry(key=null [-1], value=null, parent=null, left=ROOT, right=null, predecessor=ROOT) |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 14, 7, 10, "\udb89\ude3a", "\u42ba", "\ud8bc\udcea",
        55, 87148, -1335650609, 7380000798497976948L, 32501L, false, true, (char) 59528, (char) 54088,
        Double.longBitsToDouble(0x3f9a1e1b65dc41c0L), Double.longBitsToDouble(0x3fd3de8ce2f0d06eL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.trie.PatriciaTrie:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 7, 9, "\uf2dc\uda91\udea7\ud832\udd3b\u8ce2\udbe5\udfaf\ud8cb\udd1d\ud826\ude01\uda86\udf00\uda24\uddf7\ud82d\udd7b\ud899\ude0e\udb61\udddd\udbab\udc72\ud9a8\udf19\udb55\uddf8\ud9be\udd76\udab1\udd44\udb0d\udf51\uda93\udc40\ud85c\udc24\ud913\udde3", "\u6c2b\u0cee\u0bde\uc078\u20c0\u4e93\u5a79\u9333\u8d53\u58a7\u9126\u9fe8\u76ee\u430a\u0481\uce19\u6e61\u1006\ud218\u8c2c\uaaaa\u14d0\ubaad\ub3f4\u8108\ub368\u1adf", "\ud898\uded8\u83e6",
        37, 35239, 1001855421, 8534607181649885990L, -51161L, true, false, (char) 13913, (char) 41124,
        Double.longBitsToDouble(0x3fed2a70bf12c765L), Double.longBitsToDouble(0x3fd8d93eeeeb9068L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 13, 3, 12, "\ud82a\udede\ud9e7\udd06", "\u9059\u0180\u2349\u1934", "\ud88d\udc7c",
        25, 80099, 324574952, -1999946095222625339L, -94173L, false, true, (char) 6662, (char) 53086,
        Double.longBitsToDouble(0x3fef675d129bc4a6L), Double.longBitsToDouble(0x3fe98a475bd65f53L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer:@? |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 3, 6, 10, "\ud841\udc3d\ud92e\udcbb\uda60\ude25\ud950\udf96", "\u2170\u39e6\u2880", "\udadc\udf3a\ud828\udc17\udba0\udf3c\ud404\ud8dd\uddac",
        51, 6961, -206793938, 7509691117039855480L, -72378L, false, true, (char) 8638, (char) 16798,
        Double.longBitsToDouble(0x3fbe04d2c0ef0090L), Double.longBitsToDouble(0x3fb22b0b2fac6f40L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 9, 6, 10, "\ud841\udc3d", "\u42ba", "\ud891\udf07",
        22, 87148, -577595697, -4569946585305916920L, 32501L, false, true, (char) 59528, (char) 54088,
        Double.longBitsToDouble(0x3f9a1e1b65dc41c0L), Double.longBitsToDouble(0x3fd3de8ceef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 8, 10, "\ud841\udc3d", "\u42ba", "\uda9d\udd2f",
        47, 1657, -629961797, 4935048757811301143L, 76021L, false, true, (char) 57499, (char) 54088,
        Double.longBitsToDouble(0x3fd1a1e1b65c5920L), Double.longBitsToDouble(0x3fd3de8ced2ad06eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 12, 8, 15, "\udbee\udd33", "\ubc4e\u95ca\u23b2\u206b\u39e6\u2880\u3e01", "\ud828\udc17\udba0\udf3c",
        44, 17761, 505111483, -9210701153576250577L, 8843L, true, true, (char) 23822, (char) 46239,
        Double.longBitsToDouble(0x3fe09a496417e0c0L), Double.longBitsToDouble(0x3fe9177c5d12c5daL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer:@? |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 11, 1, "\udbee\udd33\ud95a\ude81\ud80a\udccb\ud93c\udfda\udb5f\udc5d\udb82\udcdf\ud88b\ude83\udbb2\udd6d", "\u46a0\u43c2\u0a23\u5204\ua0c1\ud0ae\uc7e8\u1072\uad14\u31a9\u0505", "\udb79\udded\ud97b\udd3e\udb99\udd15",
        5, 69200, 1019257363, 7863614900685950902L, 56560L, true, true, (char) 19558, (char) 106,
        Double.longBitsToDouble(0x3fbffd304dc73118L), Double.longBitsToDouble(0x3fe6854fed019ff4L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 13, 4, 2, "\udb95\udd15", "\uadb2\u0303\u5d31\u9b32\ub77f", "\ud899\ude0e",
        40, 5690, -1460209045, -1690567951145238529L, 35315L, false, true, (char) 17917, (char) 5277,
        Double.longBitsToDouble(0x3fe703be85331ab2L), Double.longBitsToDouble(0x3fa1928e65f806e0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 4, 1, 2, "\uda6d\udfba", "\u42ba\u5267\ud4c6\u2170\uc205\u28c9", "\udbdd\udec5\ud828\udc17\udba0\udf3c\ud404\ud8dd\uddac",
        51, 76074, -389115090, 7509727350349375352L, -16841L, true, false, (char) 55446, (char) 39987,
        Double.longBitsToDouble(0x3fb48f66c9f33180L), Double.longBitsToDouble(0x3febca0edfcf7a6fL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=void |this=org.apache.commons.collections4.trie.PatriciaTrie:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 5, 2, "\udaba\ude0c", "\u42ba\ub096", "\udab1\udef1\ud938\ude81\uda57\udcc7\ud899\ude0e\udadc\udf3a\ud828\udc17\udba0\udf3c\ud404\ud8dd\uddac\ud8ab\udcbb\ud8ba\ude56\ud82a\uddd0\ud905\udf61\ud922\ude24\udbbe\uddc5\udbba\udd6e",
        14, 89125, 1033624836, 7363645228787126590L, 71215L, false, false, (char) 65523, (char) 47760,
        Double.longBitsToDouble(0x3fee69f1c6ccc42bL), Double.longBitsToDouble(0x3fe5704da95bb8b7L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 9, 12, 2, "\udaba\ude0c", "\u42ba\ub096", "\udab1\udef1\ud938\ude81\uda57\udcc7\ud899\ude0e\udadc\udf3a\ud828\udc17\udba0\udf3c\ud404\ud8dd\uddac\ud8ab\udcbb\ud8ba\ude56\ud82a\uddd0\ud905\udf61\ud922\ude24\udbbe\uddc5\udbba\udd6e",
        14, 75701, 1033624836, 7363645228787126590L, 5679L, false, false, (char) 37766, (char) 28749,
        Double.longBitsToDouble(0x3fee69f1c1c12d3eL), Double.longBitsToDouble(0x3fe5704da85bb8b7L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry:RootEntry(key=null [-1], value=null, parent=null, left=ROOT, right=null, predecessor=ROOT) |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 4, 14, 3, "\udaba\ude0c", "\u42ba\u5e00", "\udab1\udef1\ud938\ude81\uda57\udcc7\ud8c2\udc0e\udadc\udf3a\ud828\udc17\ud9ad\udf02\ud453\ud8dd\uddac\ud8ab\udcbb\ud8ba\ude56\ud82a\uddd0\ud905\udf61\udaec\ude29\ud9c8\udf07\ud825\ude81",
        14, 75701, -1246575100, -8997362334120822032L, 61612L, false, false, (char) 37766, (char) 28749,
        Double.longBitsToDouble(0x3fee69f1c1c12d3eL), Double.longBitsToDouble(0x3fe9184da81abd9fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$EntrySet:[] |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 2, 6, 10, "\udb86\uddb6", "\u57bd\ub079\ub9f1\u69bf\uba15\u5765\ua031\ua0e9\u0f73\u1623\ucea6\u82f5\uc964\u462d", "\udb53\udf96\uda04\udf8d\ud8ca\udfeb\ud91b\udf5a\ud81c\uddc0\uda90\udcd7\uda9d\udec1",
        21, 4025, -1218672493, 7076383672938831723L, 78195L, true, false, (char) 50424, (char) 37923,
        Double.longBitsToDouble(0x3fadfc8a014f0b40L), Double.longBitsToDouble(0x3fc021e75701ee90L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 15, 6, 9, "\uda8e\udfed", "\u0be9\u1635\ubfdf\u4c4d\ucb13", "\ud884\uddb6\ud8c3\udd0d\udba3\udedf\ud958\udc19\ud404\udb24\udc10\ud8c1\udc44",
        4, 10030, -1363115285, 994988202547156472L, -3230L, false, true, (char) 38880, (char) 55923,
        Double.longBitsToDouble(0x3fd7181d1d5e440aL), Double.longBitsToDouble(0x3fd75b7293abb7b6L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 2, 6, 10, "\000", "\u42ba\ub096\u1a59\u69bf\uba15", "\ud952\udcce\ud85d\uddb5\ud82b\udc17\udb89\udfdf\ud404\udb24\udc10\ud8c1\udc44",
        4, 10030, 1748494680, -6644173428939233241L, -3230L, false, true, (char) 38880, (char) 58987,
        Double.longBitsToDouble(0x3fbc779e449fbbe0L), Double.longBitsToDouble(0x3fd75b75c3abb7b6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 13, 15, 12, "\ud841\udc3d", "\u42ba\ub096\u1a1f\u69bf\ub1c1", "\ud952\udcce\ud85d\uddb5\ud82b\udc17\udb89\udfdf\ud404\udb24\udc10\ud8c1\udc44\ud8ba\ude56\ud810\udcd0\udb8a\udf1f\udbaa\ude69\uda7e\udc08\ud8e9\udf5a\ud81c\uddc0\udba7\ude15\uda9a\ude02\ud8a8\udcc7\uda39\udff0\ud853\udc4b\udad4\udf53\ud9bb\udf4b\udbfb\udf03\ud992\udf60\ud873\ude77\ud9d2\udd60\uda35\uded9\ud98c\udf09\ud9e5\udf26\ud890\udf35\udb8c\udca5\uda4f\udc35\ud896\ude06\udbfb\udf4e\uda7f\udd67\ud883\udcf6\udb50\udddc\uda0d\udfed\udadf\udfa8\uda33\ude8f\ud8fd\udf84\uda75\udc85\ud9e1\uddce\udba5\udc04\ud8f4\udd60\ud8ef\uddb0\uda8d\udd5d",
        34, 26686, -1067325462, 2552910592925115073L, -3530L, false, false, (char) 29600, (char) 61841,
        Double.longBitsToDouble(0x3fe3edd66566797eL), Double.longBitsToDouble(0x3fe49275500c0d44L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 12, 8, 10, "\udadb\uddc9", "\u11ff\u9322\ub52c", "\ud884\udd8e\uda43\udfa6",
        40, 21105, -664961326, -8779310284750068378L, 20225L, false, true, (char) 47019, (char) 2337,
        Double.longBitsToDouble(0x3fe0bfe0b173b42bL), Double.longBitsToDouble(0x3fefa216372717caL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 15, 6, "\ud841\udc3d", "\u42ba", "\udb1a\udd00",
        11, 87148, -572531249, -4569946585305916920L, 32361L, false, true, (char) 6200, (char) 37128,
        Double.longBitsToDouble(0x3f9a1e1b65dc41c0L), Double.longBitsToDouble(0x3fdc2fcc8ef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry:RootEntry(key=null [-1], value=null, parent=null, left=ROOT, right=null, predecessor=ROOT) |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 14, 9, 6, "\ud841\udc3d", "\u42ba", "\ud891\udf07",
        22, 87148, -1584452866, -3099571544521681392L, 29643L, false, false, (char) 4408, (char) 54088,
        Double.longBitsToDouble(0x3f9a1e1b05dc41c0L), Double.longBitsToDouble(0x3fd1014e6ef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 9, 9, 6, "\ud841\udc3d", "\u2421", "\ud891\udf27\udab1\udef1\ud938\ude81\uda57\udcc7\ud899\ude0e\udadc\udf3a\ud828\udc17\udba0\udf3c\ud404",
        4, 13381, -502397926, -1671236586978556439L, 2116L, false, false, (char) 10778, (char) 49815,
        Double.longBitsToDouble(0x3feed7d54d0c0c26L), Double.longBitsToDouble(0x3fdbc57358c6d0c6L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 1, 1, "\ud841\udc3d\ud9ff\udf06\udadb\uddf8\udadc\udce6\uda09\ude45\udba5\udee5\uda64\udf8a\ud98c\udfa5\ud938\ude81\uda57\udcc7\ud899\ude0e\ud912\ude22\ud995\ude88\ud9d5\udc11", "\uc6a3\u309c\uc7b0\u2cc2\u99d8\u9776\u9f50\uc849\u70b5\u7939\u34cc\u54ec\u446f\u6b55\ud747", "\ud886\udef0\ud857\ude3f\udb5d\ude3a\ud9f4\udd33\ud940\udda2\udb02\udc8b",
        48, 20027, -1374162342, 7772118015809569425L, 64675L, true, true, (char) 19220, (char) 9068,
        Double.longBitsToDouble(0x3fb31887b7a3af98L), Double.longBitsToDouble(0x3fedbc6daa96c7a4L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry:RootEntry(key=null [-1], value=null, parent=null, left=ROOT, right=null, predecessor=ROOT) |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 14, 9, 6, "\ud841\udc3d", "\u42ba", "\ud891\udf07",
        22, 87148, -577595697, -4569946587151410680L, 32501L, false, true, (char) 59528, (char) 54088,
        Double.longBitsToDouble(0x3feb48f0db2ea0dcL), Double.longBitsToDouble(0x3fd3de8cef407d9cL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=void |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 0, 0, 0, "\uda9f\ude28\ud800\ude4b", "\u174e", "\ud9b5\uddd7\udbd8\udd74\ud8fb\udd8f\ud81e\udfe4\udaac\udf21\ud828\udc17\udbf1\udc46\ud9d3\uddb7",
        -5, 13381, 867828762, -6928979145895714744L, 20323L, false, true, (char) 46635, (char) 59472,
        Double.longBitsToDouble(0x3fcca6bd02a190d4L), Double.longBitsToDouble(0x3fc9bd7ae2c9c064L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 12, 13, 12, "\ud96a\udf93\ud9d4\udca9\udadb\ude94\udadc\udce6\ud9b6\uddee\ud89a\udd09\ud8f6\udf58\uda83\ude94\ud93f\udcec\ud990\udda7\uc325\udbb2\udc8b\ud992\uddda\udba0\udf3c\ud404", "\ud733", "\ud921\udc62",
        7, 38682, -181298384, 8620961025142109450L, -38062L, true, true, (char) 62184, (char) 8671,
        Double.longBitsToDouble(0x3fdd520b90b4b3deL), Double.longBitsToDouble(0x3fde61335e30c690L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 4, 4, 2, "\ud957\udc3e", "\uaecb", "\ud856\udc4c\udab1\udef1\udb06\udc77\udace\udd0a\udbe2\udf6b\udadc\udf3a\ud828\udc17\udba0\udf3c\udac0\udde8\ud9ae\uddbc\ud9cb\udcd9\ud8bf\ude11\ud82a\uddd0\ud90a\ude3d\udbcc\udd55\uda3e\udecc\udac0\udf58\ud941\udf88\ud919\udcb7\uaa01\ud884\udf42\uda7e\udc0a\udb75\udff9\uda78\udef7\ud99c\ude44\udbe3\udc1c\ud90e\ude72\ud8eb\ude76",
        58, 22888, 1284099056, 1692694748567184928L, -72317L, false, false, (char) 37026, (char) 26233,
        Double.longBitsToDouble(0x3feb79f0360df1c1L), Double.longBitsToDouble(0x3fed8baa916f7687L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 9, 11, 10, "\000", "\u67d2\ub0a8\u8353\u2170\ud653\000\u7f31", "\udb93\udf3b\udba0\udf3c",
        23, 61071, 1125887360, 4448047785533870894L, 50904L, true, true, (char) 49949, (char) 41117,
        Double.longBitsToDouble(0x3fdd1b83280e52d6L), Double.longBitsToDouble(0x3fee1ee394fc8e41L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 12, 13, 5, "\ud82c\udd73", "\u42ba", "\udb47\uded9",
        7, 87148, -577595697, -7172585166256175106L, -19979L, false, true, (char) 60643, (char) 35235,
        Double.longBitsToDouble(0x3fe5571bf32ee20eL), Double.longBitsToDouble(0x3fd3de8ce8b3ca8aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$EntrySet:[] |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$EntrySet:[] |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 6, 6, 5, "\ud82c\udd73", "\u604e", "\ud891\udf07",
        22, 87148, 232566479, -9103784161129208638L, -19979L, false, true, (char) 5789, (char) 56754,
        Double.longBitsToDouble(0x3fe5571bf32ee20eL), Double.longBitsToDouble(0x3fd3db3ce8b3ca8aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry:RootEntry(key=null [-1], value=null, parent=null, left=ROOT, right=null, predecessor=ROOT) |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 1, 8, "\ud82c\udd46", "\ub94a\ub11f", "\ud98b\udf2f\ud91e\udcd8\uda57\udcc7\uda87\udc53\udad7\uddf0\ud828\udc17\udb54\udddb\ud9ac\udeaf",
        2, 24833, -1656282404, -1671397733539997123L, -6230L, false, true, (char) 10672, (char) 35248,
        Double.longBitsToDouble(0x3fedd3d444887e22L), Double.longBitsToDouble(0x3feb91a492f2e0d0L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.trie.PatriciaTrie:!toString:java.lang.NullPointerException\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$EntrySet:!toString:java.lang.NullPointerException |this=org.apache.commons.collections4.trie.PatriciaTrie:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 5, "\ud82c\udd73", "\u91ba\ub016\u1a59\u2170\u39e6\u2880\u464e\u358c\u3c8a\u0a23\u6881\u9708\u3037\uac9f\u0540\u4182\u998f\uc68a\u2f60\u998c\u1e38\ubf0f\u50ec\u9675\u7cbe\u8d0f", "\udbaf\udf0e\ud997\udee2\ud93e\ude7b\ud8e3\uddc8\ud9cc\udf97\uda48\udffc\ud842\udd8f\udabd\udfec\uea11\ud85a\udc62\udb57\udd06\u5c7e\uda4b\udca8\udb74\udd8b\ud890\udf3d\udbf6\udcd0\udbab\udc17\udb0d\udceb\ud922\udc58\ud882\ude05\ud969\udc55\uda0b\udcb8\ud8f9\udf85",
        13, 31307, -656339744, -5395906980605122058L, 10057L, true, true, (char) 18764, (char) 18735,
        Double.longBitsToDouble(0x3fd6c93cfebb20f0L), Double.longBitsToDouble(0x3f9fd36dec5fb6a0L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.trie.PatriciaTrie:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 8, 10, "\ud841\udc3d", "\u42ba", "\uda9d\udd2f",
        47, 39541, -629962726, 4935048757811301143L, 76021L, false, true, (char) 57499, (char) 19272,
        Double.longBitsToDouble(0x3fd1afee565c5920L), Double.longBitsToDouble(0x3fd3de8ced2ad06eL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$PrefixRangeMap:{} |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 15, 8, 10, "\udabf\udd3e", "\u42ba", "\uda9d\udd2f",
        -5, -1000, -629997568, 4935048758918597399L, 76128L, false, true, (char) 59547, (char) 54005,
        Double.longBitsToDouble(0x3fd1a1e1b0000120L), Double.longBitsToDouble(0x3fd3de8ced2ad06eL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer:@? |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer:@? |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 3, 3, 7, "\udbee\udd33\ud95a\ude81\udb54\udd34\ud8f8\udfd8\udb5f\udc5d\udb82\udcdf\ud8c9\udeb7\udbb4\udea6\ud938\ude81\uda57\udcc7\ud899\ude0e\ud865\ude7e", "\ubbdf\ud0ae", "\ud98b\udcce\ud8ad\udc83\uda91\udd5b\udb11\udf42\udb18\udc30\ud8c7\udc80\ud971\ude57\ud867\ude3a",
        22, 64944, -1739293117, 7863614900685950902L, 56560L, true, true, (char) 19558, (char) 16658,
        Double.longBitsToDouble(0x3febffa609b8e600L), Double.longBitsToDouble(0x3fe6854fed019ff4L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 2, 2, 1, "\udaba\ude0c\ud966\ude4c", "\ub096\u1a59", "\udbaf\udeb2\uda57\udcc7\ud899\ude0e\udadc\udf3a\ud828\udc17\udba0\udf3c",
        7, 34652, 505106077, -2157782662137343186L, -89896L, true, true, (char) 15620, (char) 63621,
        Double.longBitsToDouble(0x3fda51af2fa35efeL), Double.longBitsToDouble(0x3fda34e7c9f469d8L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 12, 12, 0, "\udadb\uddc9", "\u11ff", "\ud8e5\udde5\ud904\uddfc",
        29, 69392, 2087646970, -2884186053074387246L, 41210L, true, true, (char) 52138, (char) 39017,
        Double.longBitsToDouble(0x3fe2fde80558e8ceL), Double.longBitsToDouble(0x3febff81601d2104L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry:RootEntry(key=null [-1], value=null, parent=null, left=ROOT, right=null, predecessor=ROOT) |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry:RootEntry(key=null [-1], value=null, parent=null, left=ROOT, right=null, predecessor=ROOT) |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 14, 14, 10, "\ud841\udc3d\ud9ff\udf06\ud880\udf0a", "\ud68e\u8f2e\u2f79\u309d", "\ud881\ude9e\udb7d\udd54\udba0\udf3c\udb75\udd2f\ud8dd\uddac",
        51, 76074, 350664750, 7509727157158160248L, -48137L, true, true, (char) 12309, (char) 10757,
        Double.longBitsToDouble(0x3fe8f64adb48cfe2L), Double.longBitsToDouble(0x3fda5f83aac83dd2L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 9, 9, 6, "\ud841\udc3d", "\u2421", "\ud891\udf27\udab1\udef1\ud938\ude81\uda57\udcc7\ud899\ude0e\ue208\ud828\udc17\udba0\udf3c\ud404",
        4, 13381, 1050, -1671236784547052055L, 2116L, false, false, (char) 10778, (char) 49815,
        Double.longBitsToDouble(0x3fcb5f5534303098L), Double.longBitsToDouble(0x3fdbc57358c6d0c6L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=java.lang.Boolean:false |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 4, 4, 2, "\ud957\udc3e", "\uaecb", "\ud856\udc4c\udab1\udef1\udb06\udc77\udace\udd0a\udbe2\udf6b\udadc\udf3a\ud828\udc17\udba0\udf3c\udac0\udde8\ud9c4\udce8\ud8a6\ude52\ud8bf\udd60\ud82a\uddd0\ud90a\ude3d\udbcc\udd55\uda3e\udecc\udac0\udf58\ud941\udf88\ud919\udcb7\uaa01\ud884\udf42\uda7e\udc0a\udb75\udff9\uda78\udef7\ud99c\ude44\udbe3\udc1c\ud90e\ude72\ud8eb\ude76",
        58, 79136, -1488547991, 1561926953047736543L, -72317L, false, false, (char) 37026, (char) 26233,
        Double.longBitsToDouble(0x3fd6f3e06c1b2458L), Double.longBitsToDouble(0x3fed8baa916f7687L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 2, 2, 1, "\udaba\ude0c\ud966\ude4c\udab6\udcc5\udbc6\udfe6\ud92c\udf4a", "\u1575\u9a25\u3e01\u46a0\ub220\u0a23\u5204\u9fd0\u2ae1\ua24b\u309c\uc7b0\u2cc2\u6c56\u93b3\u4032", "\ud80b\udc71\ud9a2\udcc1\u22d9\ud8bd\udd46\ucc89\ud87b\udec8\ud8a8\udc22\uda15\uddb8\udb02\udfcf\uda85\udfcf\ud94a\udea2\ud9fb\udebc\ud99e\udf6f",
        53, 23956, 129199974, -6617994828982018858L, 43158L, false, true, (char) 15005, (char) 27373,
        Double.longBitsToDouble(0x3fe05dfb7e89bc69L), Double.longBitsToDouble(0x3fd71b272ecf8beeL)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 1, 7, 6, 10, "\ud841\udc3d", "\u42ba", "\udb04\ude00",
        22, 87148, -577595697, -3200852297486130313L, -13814L, true, false, (char) 37871, (char) 10846,
        Double.longBitsToDouble(0x3fcb2c966cbb8838L), Double.longBitsToDouble(0x3fdeee8ceef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 9, 9, 6, "\000", "\000", "\ucc00\udab1\ude9e\u74b4\udbdf\uddef\u49cb\000\000\udba0\udf3c\ud404",
        4, 32725, 26, 0L, -100000L, false, false, (char) 10240, (char) 23703,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e40000000000000L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 9, 9, 6, "\000\ud946\udfc2", "\u31e8\u0c4f\u794a\u033b", "\ud979\udcfa\u818b\000\ud84a\udd2d\u6a12\uda41\ude13\udae7\udfa2\u48b9\000\ud9f2\ude39\ud80d\udc05\000\udb8f\uddc7\ud8e9\ude2ep\000\000\000\ud97a\udda7\udb4f\udc26\ud834\udddd\udb94\udd9c\ud837\udc3b\udb7f\udd74\ud922\ude91\uda5f\udc13\ud88f\udc70\udb24\udc0c\uda6a\uddb7",
        29, 17020, -999200044, -3469910741071576735L, 3675L, false, true, (char) 21660, (char) 57364,
        Double.longBitsToDouble(0x3fa2225f1862c9b0L), Double.longBitsToDouble(0x3fef016a33c7f215L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 9, 9, 9, "\000\000\ud947\udf1f\000\udbf9\udc5c\uda38\udeaa\ud818\udefe", "\ucd25\u0cf5\u8f59\ua3df\u8725\u2601\u2a2a\u95f2\u96b2\u0f13\000\000\u5a68\u2914\u8dbe\u3aa5\u7c2f\u0b3b\000\u201e\u69fb\u86e8\u6498\u762d", "\udabf\udd27\udbc4\udff7\ud8e0\udcfe\ud9c8\udeed\udbbe\udfc7\ud94f\udc98\ud8a4\ude95",
        10, 32251, 1113438370, -6460976534091185071L, -95527L, false, true, (char) 61907, (char) 57329,
        Double.longBitsToDouble(0x3fe3187075609ed0L), Double.longBitsToDouble(0x3fe2647f8ffde06aL)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 9, 9, 9, "\000\000\000\000\000\uda38\udeaa\ud818\udefe", "\ucd25\u491a\000\ua352\u8725\u2601\u2a2a\u95f2\u96b2\u0f13\000\000\u5a68\u2914\u8dbe\u3aa5\u7c2f\u0b3b\000\u201e\u69fb\u12fb\u6ac9\u762d", "\udabf\udd27\ud822\ude06\000\u7d00\udbbe\udfc7\ud93a\udc7d\ud8a4\ude95",
        10, 32251, 1113438370, -6460976534091185071L, -95527L, false, true, (char) 41355, (char) 0,
        Double.longBitsToDouble(0x3fe3187075609ed0L), Double.longBitsToDouble(0x3fe2647f8ffde06aL)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$PrefixRangeMap:{} |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 0, 15, 0, "\000", "\u42ba", "\udb1a\udd00",
        7, -1000, 0, 335544320L, 32361L, false, true, (char) 6200, (char) 37128,
        Double.longBitsToDouble(0x3f9a1e1b000001c0L), Double.longBitsToDouble(0x3fd000000ef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=org.apache.commons.collections4.trie.AbstractPatriciaTrie$PrefixRangeMap:{} |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$PrefixRangeMap:{} |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 15, 15, 0, "\000", "\u42ba", "\ud9c7\udd0d",
        7, -1000, 0, 1530704640L, 32361L, false, true, (char) 25144, (char) 37039,
        Double.longBitsToDouble(0x3f9a1e1b000001c0L), Double.longBitsToDouble(0x3fd000000ef0d06eL)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections4.trie.PatriciaTrie:!toString:java.lang.NullPointerException\0121=org.apache.commons.collections4.trie.AbstractPatriciaTrie$PrefixRangeMap:{} |this=org.apache.commons.collections4.trie.PatriciaTrie:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 15, 0, "\000", "\u85a8", "\udb12\udf00",
        7, -1000, 0, 335544320L, 32361L, false, true, (char) 6200, (char) 37128,
        Double.longBitsToDouble(0x3f9a1e1b000001c0L), Double.longBitsToDouble(0x3fbc513e7bc341b8L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\0121=null |this=org.apache.commons.collections4.trie.PatriciaTrie:Trie[0]={\012}\012\012",
        Z.run(T, 2, 2, 2, 2, "\000", "\u09ff\ub096\u4f1a\u69bf\uba15\u5765\ua031\u6e42\u78a0\u62ab\ud232\uc377\uc964\u462d", "\ud905\udf7c\udbaa\ude08\uda7e\udc08\ud820\ude76\udbf8\uded1\ud80f\udef8\uda9a\udd90",
        41, 4025, -1218672493, -4473097570656424826L, 35888L, false, true, (char) 53851, (char) 32392,
        Double.longBitsToDouble(0x3fe4209d7aea0d7bL), Double.longBitsToDouble(0x3fe857c234261ab7L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|clear||new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|addEntry|org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry,int|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|ceilingEntry|java.lang.Object|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|comparator||new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|containsKey|java.lang.Object|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|decrementSize||new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|entrySet||new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|firstEntry||new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|firstKey||new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|floorEntry|java.lang.Object|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|followLeft|org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|followRight|org.apache.commons.collections4.trie.AbstractPatriciaTrie$TrieEntry|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|get|java.lang.Object|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|getEntry|java.lang.Object|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|getNearestEntryForKey|java.lang.Object,int|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|getPrefixMapByBits|java.lang.Object,int,int|new:org.apache.commons.collections4.trie.PatriciaTrie:",
    "M|org.apache.commons.collections4.trie.AbstractPatriciaTrie|clear||new:org.apache.commons.collections4.trie.PatriciaTrie:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
