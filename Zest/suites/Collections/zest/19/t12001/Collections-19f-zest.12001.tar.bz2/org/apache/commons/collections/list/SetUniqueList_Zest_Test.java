package org.apache.commons.collections.list;
import org.junit.Test;
import static org.junit.Assert.*;
public class SetUniqueList_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 1, 8, 13, 13, "\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\ud41a\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u4abf\u2353\u659f\u285c\u5791\uad56\uad31\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\ud960\udfe0\ud913\ude79\ud89b\udc35\udbc4\udfbe",
        20, 6563, 1688896647, -343208605189075739L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 1, 8, 13, 13, "\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u887b\u0ac0\u9cf1\u924a\u4a6b\u08a1\u4f59\u536c\ubce2\u962d\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\u0eda\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u4abf\u2353\u659f\u285c\u5791\uad56\uad31\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\ud960\udfe0\ud913\ude79\ud89b\udc35\udbc4\udfbe",
        20, 6563, 1688896647, -343208605189075739L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb1976a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 8, 13, 0, "\ud9e0\uddbc\ub141\000\u5500\ud9fb\udd14\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\000\000\u39ff", "\ud956\udfc5\ud8a3\udf9c",
        1, 95892, 2062540816, 8975312088891880065L, -80242L, true, false, (char) 26364, (char) 31163,
        Double.longBitsToDouble(0x3fee527826fae22bL), Double.longBitsToDouble(0x3fcb4a876593f428L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 0, 13, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u30de\uae73\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08c5\u4f59\u6073\u8e4d\u95c5\u0bc6\u186f\uc417\u9253\u9006\u3c21\u97b6\u8603\u7161\u947c\u9180\u6e5f\u671d\uc9ee\u9bb6\u5b86\u4abf\u2353\u659f\u285c\u5791\uad56\uad31\ucecd\uc496\ub96c\u1eab\u68ca\u7cf3\u1775", "\udbaa\uddb1\udb22\udf29\ud8e1\udf5e\udb1f\udebe\ud8ce\udc8e\ud97f\udcf3\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\ud889\ude67\ud954\udf29\ue48f\ud8b1\udf38\ud255\udbf9\udf09\udac2\udd92\udad3\udcaf\ud89b\udc35\udbc4\udfbe",
        20, 6563, 546079879, -343208605189075739L, 44583L, false, false, (char) 22006, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea01ebc8L), Double.longBitsToDouble(0x3fd7635a813123e4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 1, 6, 5, 13, "\udae7\udc6b\ud86d\udfeb\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u2057\udabb\ude0c\ud8b7\ude04", "\ud37e\u8201\u39ff\u5975\u3187\u3e01\u887b\ub21a\u8247\uc30f\ua420\ua98a\u2e5a\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\u030d\u1baf\u221b\u9180\u6e5f\u66fe\ud29b\u9bb6\u5b86\u4abf\u2353\u659f\u140c\u56f0\uad56\uad31\ucecd\uc496\u3c9e\u1eab", "\ud8ff\ude9f\ud98d\udc64\u0305",
        34, 23149, -871662530, 3155646861401733763L, -41740L, true, false, (char) 38963, (char) 32797,
        Double.longBitsToDouble(0x3fe19771697f11cdL), Double.longBitsToDouble(0x3fedfdad56e1f815L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 1, 10, 10, 13, "\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u6373\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\ud41a\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u4abf\u99c9\u65bc\u285c\u5791\uad56\uad31\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\ud960\udfe0\ud913\ude79\ud8ab\udf1c\ud8d1\udfc8",
        20, 6563, 1688896647, -343208605189075739L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2] |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2]\012",
        Z.run(T, 1, 9, 2, 14, "\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2", "\u6bd5\u687e\u8201", "\ud95b\ude8a\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd3d\ud96c\udffe\udb28\udd77\udbc9\ude56",
        16, 74639, -500468790, 5266064671512087803L, 29671L, false, true, (char) 5740, (char) 45970,
        Double.longBitsToDouble(0x3fefbafa0a6448aeL), Double.longBitsToDouble(0x3fd6b210006e889aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud8e9\udfbf\ud84f\udc92\uda0b\ude1f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud8e9\udfbf\ud84f\udc92\uda0b\ude1f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 2, 8, 13, 13, "\ud8e9\udfbf\ud84f\udc92\uda0b\ude1f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\ud196\u5975\u3187\u3e01\u887b\uca8b\u9cf1\uc29d\u9e43\u08a1\u3a7c\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u4557\u9f0d\u3c21\u0ab4\u2029\u65db\u21c8\u9180\u6e5f\u7bbc\u1071\u113a\ub65c\ud5cb\u9e2a\u659f\u3355\u56fe\uad56\u4065\u3230\uc908\u9a62\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud803\udf0d\ud965\udd67\uda0b\udd48\uda48\udf47\ud8c0\udc79\ud941\udd0b\udb86\udd70\ud219\udbf9\udf09\ud960\udfe0\uda74\udf77\ud89b\udc35\udbc4\udfbe",
        20, 6563, 1688896647, 2272538353383050469L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fd3e3bd6a81e54eL), Double.longBitsToDouble(0x3fb18d6a28148f90L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.UnmodifiableSet:[\u480b\u35e4\u39ff\u1276\u3187\u3b8b\u60b9\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u2401\u8d41\u1090\u97fe\ud41a\u1b01\u221b\u79d9\u214c\u5fe2\u3b1c\ua8ce\u5b0c\u0cf7\u85ec\u6b8b\u2821\u5791\ud71d\u2ef4\uce26\uc454\ua15a\u456c\ua9b0\u9c4b\u1775] |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud97a\udf5e\ud971\udfd7\udbb4\udfec\udb28\udf76\ud919\udfd1]\012",
        Z.run(T, 1, 5, 13, 13, "\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud97a\udf5e\ud971\udfd7\udbb4\udfec\udb28\udf76\ud919\udfd1", "\u480b\u35e4\u39ff\u1276\u3187\u3b8b\u60b9\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u2401\u8d41\u1090\u97fe\ud41a\u1b01\u221b\u79d9\u214c\u5fe2\u3b1c\ua8ce\u5b0c\u0cf7\u85ec\u6b8b\u2821\u5791\ud71d\u2ef4\uce26\uc454\ua15a\u456c\ua9b0\u9c4b\u1775", "\uda69\udc81\udb1d\udfbb\udabe\udd0d\ud82d\udc36\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\udba4\udc99\udb08\udc13\udbc2\udde7\uda16\ude64\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\udb14\udfb2\udba2\udee5\uda1a\udd8e\udbc8\udf2d",
        20, 6563, 531858567, -298234486509204251L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb30d6a0025a470L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 2, 13, 13, "\ud9e0\uddbc\ud8c4\udc0c\ud829\udea6\ud870\udfaa\udacd\udc12\udb23\udeaa\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\uac88\u3c21\u97b6\ud41a\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u4abf\u2353\u659f\u285c\u5791\uad56\uad31\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\ud960\udfe0\ud913\ude79\ud89b\udc35\udbc4\udfbe",
        20, 6563, 1688896647, -343208605202059291L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 14, 5, 5, "\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud960\udd17\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u5d46\u8298\u39ff\u5975\u3187\u3e01\ua585\uca99\u28b4\u96fd\u4a6b\u08a1\u1ba4\ud77f\u8dc5\u95c5\u0bc6\u186f\ucf8b\u192c\u1a26\u3c21\u97b6\ud41a\u1b01\u221b\u4487\u32d0\u90d6\u0c74\u9bb6\u5b86\u4abf\u8f72\ubab6\u285c\u5791\uad56\u080c\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udad2\ude16\udb1d\udfb4\ud8e1\udf5e\udb10\udf5d\ud807\udeff",
        20, 3644, 391195775, 9067013361302831689L, 45791L, true, true, (char) 14071, (char) 33561,
        Double.longBitsToDouble(0x3fe1e2c9657210b7L), Double.longBitsToDouble(0x3fe8a90756afbb65L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 12, 0, 13, "\ud8be\udee4\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\ud41a\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u5601\u2353\u659f\u285c\u5791\uad56\uad31\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\ud960\udfe0\ud913\ude79\ud89b\udc35\udb6d\udc33",
        42, 6563, 1688896647, -343208605189075739L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 13, 13, "\ud9e0\uddbc\udab0\udfc2\ud869\udf9e\ud879\udc87\ud9fb\udd1f\ud833\udef1\uda9a\udc46\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\uce77\u887b\u818c\u9cf1\u8d9e\uadd7\u088a\u4f59\u1010\u8df4\u95c5\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\ud41a\u1b01\u212c\u9180\u6e5f\u66fe\ua589\u14cb\u5b86\u4abf\u2340\u659f\u272c\u9f7d\u5f77\uacf6\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\u565a\ud9ce\udfe8\uda30\udd46\udb3a\ude7d\ud9b6\udf32\udb93\udde2\ud932\udcbc\uda83\udc2a\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud854\udd75\ud8f8\udf5f\ud29d\udbf9\udf09\ud960\udfe0\udaf4\udc13\udb68\udc3a\udbc4\udfbe",
        20, 6563, 1688896647, -343208605189075739L, 44431L, false, true, (char) 34898, (char) 9918,
        Double.longBitsToDouble(0x3fb34b026a0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\udb99\udfb9\ud84f\udc92\ud86c\udf4f\udb69\udcff\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 1, 11, 13, 13, "\udb99\udfb9\ud84f\udc92\ud86c\udf4f\udb69\udcff\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\uac21\ud05a\uadba\u6015\u186f\u0acf\u4b9f\u54be\u3c21\u97b6\ud41a\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u4abf\u2353\u659f\u285c\u980e\uad56\u287b\u3692\u8dfe\u3ce1\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\ud8b2\uded4\udab4\udf86\udb3b\udc52\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\ud960\udfe0\ud913\ude79\ud89b\udc35\udbc4\udfbe",
        20, 42859, 1113576565, -343208605189075739L, 44583L, false, false, (char) 42022, (char) 52846,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\udab0\udfc2\ud928\udeee\ud842\udd21\ud9fb\udd1f\ud833\udef1\u3351\udac5\udd53\udbd1\udec0]\012",
        Z.run(T, 1, 15, 13, 13, "\ud9e0\uddbc\udab0\udfc2\ud928\udeee\ud842\udd21\ud9fb\udd1f\ud833\udef1\u3351\udac5\udd53\udbd1\udec0", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u887b\uca6b\u9cf1\u91c4\ubc90\u08a1\u4f59\u536c\u5672\u1101\u7a04\u186f\u0a71\ua135\u596a\ua7cd\u97b6\ud41a\ua36c\u221b\u661f\u6e7f\u66fe\u3b04\u9bb6\u5b86\u4abf\u323d\u5fe3\u71dc\u1367\uae36\uad31\ucecd\uc496\u3c9e\u1eab\u5775\u052c\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud94e\udf86\ud8fb\ude25\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud867\udc73\ud255\udbce\ude52\udbba\udc28\ud913\ude79\ud89b\udc35\udb34\udc11",
        18, 6563, 1688896647, -8338786790947615515L, -55064L, false, true, (char) 45394, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\udbdc\udf18\udb67\uddb8\ud879\udc87\udaed\udd98\udb1b\udf28\u3351\udb28\udfc2\udb83\udc03, \udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64]\012",
        Z.run(T, 1, 4, 13, 13, "\ud9e0\uddbc\udbdc\udf18\udb67\uddb8\ud879\udc87\udaed\udd98\udb1b\udf28\u3351\udb28\udfc2\udb83\udc03", "\u687e\ub22f\u39ff\u5975\u7b4e\u3e01\u8f97\uca8b\u9cf1\u91c4\u6127\u08a1\u4f5d\u536c\u73b2\u553c\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\u7888\u1bdf\u99c9\u1d22\u6df7\u66fe\u3b04\u9bb6\u5b86\u4abf\u2162\u659f\u285c\u5791\uad56\uad31\uba47\uca37\u1591\u1f0c\u5775\ub4ea\u7a12", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64",
        4, 23998, -108469356, -6067989873098270850L, 84782L, true, true, (char) 37225, (char) 14071,
        Double.longBitsToDouble(0x3fee549a7e3c592cL), Double.longBitsToDouble(0x3fbc842dd8a90470L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\udb99\ude18\udb5f\udde2\udab2\udf1d\u5500\ud9fb\udd14\ud833\udef1\u3351\udbdc\udcff\ud976\udfa8, \uc5bc]\012",
        Z.run(T, 1, 1, 7, 1, "\udb99\ude18\udb5f\udde2\udab2\udf1d\u5500\ud9fb\udd14\ud833\udef1\u3351\udbdc\udcff\ud976\udfa8", "\000\000\u39ff\u5975\u3187\u3e01\u5033\uca8b\u18a3\uaba9\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\u1820\ub144\u914a\u4837\u01ef\u7fbf\u05a1\u141e\u03fc", "\uc5bc",
        -2, 11254, 1323535236, 5204274976375759423L, -94960L, true, false, (char) 35672, (char) 46216,
        Double.longBitsToDouble(0x3fc3b1e62f369238L), Double.longBitsToDouble(0x3fedcecc15f09b9bL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\ud8ed\udc47\ud865\udf58\ud879\udc87\ud9fb\udd1f\u1aa4\udbf7\udda2\udb28\udfc2\ud919\udfd1]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\ud8ed\udc47\ud865\udf58\ud879\udc87\ud9fb\udd1f\u1aa4\udbf7\udda2\udb28\udfc2\ud919\udfd1, \udad7\udd9e\ud8ed\udc47\ud865\udf58\ud879\udc87\ud9fb\udd1f\u1aa4\udbf7\udda2\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 2, 8, 4, 13, "\udad7\udd9e\ud8ed\udc47\ud865\udf58\ud879\udc87\ud9fb\udd1f\u1aa4\udbf7\udda2\udb28\udfc2\ud919\udfd1", "\u08e2\u8201\u3a20\u3046\uc0d1\u3e03\u6606\uca8b\u9cf1\u91c4\u4a6b\u08c5\u4f59\u8922\u59ea\u95c5\u0bc6\u186f\uc417\u9253\u9006\ua8de\u97b6\u8603\u7161\u947c\u9180\u6e5f\u671d\u032a\u836c\u4ba2\u88e0\ud005\u731a\u27ca\u5c02\ua867\uad31\ucecd\uc496\ub96c\u1eab\u68ca\u7cf3\u1775", "\udb96\udfb1\udb22\udf29\ud8e1\udf5e\udb1f\udebe\ud8ce\udc8e\ud97f\udcf3\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\udafe\udce2\ud8df\udfee\ue48f\ud8b1\udf38\ud255\udbf9\udf09\udac2\udd92\ud8b5\udca1\ud89b\udc76\udbc4\udfbe",
        20, 11115, 546099228, -343208601383594011L, 44473L, false, false, (char) 22006, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea01ebc8L), Double.longBitsToDouble(0x3fd7635a813123e4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\uda23\udde9\udbd7\ude69\udb28\udfc2\ud919\udfd1] |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\uda23\udde9\udbd7\ude69\udb28\udfc2\ud919\udfd1]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 0, 13, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\uda23\udde9\udbd7\ude69\udb28\udfc2\ud919\udfd1", "\ua68e\u8201\u39ff\u30de\u311e\u7dde\u887b\uca8b\ua26b\u9260\u4a6b\u08c5\u4f59\u8273\u8e4d\u95c5\u0bc6\u186f\uc417\u9253\u9006\u3c21\u97b6", "\udb72\udcc1\udb67\udc55\ud9ce\udd71\ud89a\udc89\udad0\udcb0\udbe6\udf31",
        10, 3070, -325457327, 7645159298524197317L, -24597L, false, true, (char) 33429, (char) 41701,
        Double.longBitsToDouble(0x3f87c11653304280L), Double.longBitsToDouble(0x3fe81b8439453ae0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 8, 14, 14, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2", "\u6bd5\u687e\u8201", "\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\ud898\udc15\udbc9\udede",
        16, 74639, -500468790, -5001090870565416667L, 29671L, false, true, (char) 5996, (char) 15241,
        Double.longBitsToDouble(0x3fe00e811c5a52f8L), Double.longBitsToDouble(0x3fd6b213da6e889aL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91]\0121=java.lang.String:\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91 |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91]\012",
        Z.run(T, 2, 8, 0, 13, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91", "\u08c5\u4f59\u6073\u8e4d\ucace\u0c06\u186f\uc417\u9253\u941d\u4c00\u984a\u8603", "\udb67\udc55",
        0, 57847, -1411519066, -3797534847917018913L, 36623L, false, true, (char) 39902, (char) 400,
        Double.longBitsToDouble(0x3fd8b1fe728b5028L), Double.longBitsToDouble(0x3fe6315e79df5106L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f, \udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\ud898\udc15\udbc9\udede\udad1\uddbe\ud838\udec7\udbd8\ude07\udbb4\ude42\ud96e\udfa2\ud821\udf05\ud96f\udcfe\ud8a7\udc0c\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud86d\udca0\uda64\udd45\udac7\uddad\udbf5\udf0b\ud98c\udf95\udacf\ude3d\ud932\udd2c]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 1, 0, 13, "\udad7\udd9e\udb57\udcfc\ud865\udf3f", "\ud273\u16e1\ud641\ud4c0\ua50a\u6bd5\u687e\u8201\u39ff\u30de\uc3c7\u3e01\u887b", "\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\ud898\udc15\udbc9\udede\udad1\uddbe\ud838\udec7\udbd8\ude07\udbb4\ude42\ud96e\udfa2\ud821\udf05\ud96f\udcfe\ud8a7\udc0c\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud86d\udca0\uda64\udd45\udac7\uddad\udbf5\udf0b\ud98c\udf95\udacf\ude3d\ud932\udd2c",
        15, 20757, 1625797057, -6335335923486582459L, -83948L, true, true, (char) 50212, (char) 47928,
        Double.longBitsToDouble(0x3fe2540715be6790L), Double.longBitsToDouble(0x3fecbe8e60887c97L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\udaff\udd21\ud89b\udda5\uda35\udc90\ud854\ude4e\udb80\udcd6]\0121=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 10, 6, 13, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\udaff\udd21\ud89b\udda5\uda35\udc90\ud854\ude4e\udb80\udcd6", "\u6822\u8201\u39ff\u3422", "\ud8a3\udf9c\udace\udf5c\ud8aa\udf91\udaa3\ude0c\ud8a8\udcea\ud915\udd61\u93fb\udacc\udc6f",
        11, 42211, 1325700639, -2149497086128124326L, 91360L, true, false, (char) 34109, (char) 5996,
        Double.longBitsToDouble(0x3fe5e40b7601d023L), Double.longBitsToDouble(0x3fe32537c5fe2100L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\udbb0\udda3\ud804\udcca\ud80b\uddff\u124e\udb28\udfc2\ud919\udfd1, \udbaa\uddb1\udb22\udf29\ud8e1\udf5e\ud831\udea7\ud8ce\udc56\ud97f\udcf3\ud842\udd17\ud8cd\udd6c\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\ud889\ude67\ud954\udf29\ue48f\ud8b1\udf38\ud255\udbf9\udf09\udac2\udd92\udad3\udcaf\ud89b\udc35\uda80\udfd7]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 4, 3, 15, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\udbb0\udda3\ud804\udcca\ud80b\uddff\u124e\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u30de\uae73\u18ab\uad73\uca8b\u9cf1\u91c4\u4a6b\ubbbf\u6d83\u6073\u0964\u95c5\u0bc6\u186f\uc417\u9253\u9006\u3c21\u97b6\u8603\u7161\u947c\u9180\u6e5f\u671d\uc37f\u19e7\u5b86\u4abf\u2353\u659f\u285c\u5791\uad56\uad31\ucecd\uc496\ub96c\u1eab\u68ca\u7cf3\u1775", "\udbaa\uddb1\udb22\udf29\ud8e1\udf5e\ud831\udea7\ud8ce\udc56\ud97f\udcf3\ud842\udd17\ud8cd\udd6c\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\ud889\ude67\ud954\udf29\ue48f\ud8b1\udf38\ud255\udbf9\udf09\udac2\udd92\udad3\udcaf\ud89b\udc35\uda80\udfd7",
        20, 6563, 546079879, -343208602085290779L, 61029L, false, true, (char) 22151, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea01ebc8L), Double.longBitsToDouble(0x3fd7635a813123e4L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\udb71\udd42\ud80f\udf2e\ud919\udfd1]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\udb71\udd42\ud80f\udf2e\ud919\udfd1]\012",
        Z.run(T, 2, 15, 15, 13, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\udb71\udd42\ud80f\udf2e\ud919\udfd1", "\u687e\u8201\u39ff\ua20c\uadec\u3e01\u040a\u45b8\u9cf1\u91c4\u4a6b\u08c5\u4f59\u6073\u8e4d\u95c5\u0bc6\u186f\uc417\u54b3\ua182\u4f20\u97b6\u8603\u7161\u947c\u9180\u6e5f\u671d\uc9ee\u9bb6\u5b86\u834b\uae3c\u659f\u7aec\u14e0\uad56\uad31\ucecd\uc496\ub96c\u1eab\u68ca\u7cf3\u1775", "\udbaa\uddb1\udb22\udf29\ud8e1\udf5e\udb1f\udebe\ud8ce\udc8e\ud97f\udcf3\ud9b6\udf32\udb93\udde2\ud938\udc07\ud91a\udd2a\uda4d\ude4c\uda0b\udd1d\ud889\ude67\ud954\udf29\udb94\ude3e\ud8b1\udf8b\ud255\udbf9\udf09\udac2\udd92\udad3\udcaf\ud89b\udc35\udbc4\udfbe",
        20, 6563, 546079879, 4346164508865899026L, 44583L, false, false, (char) 22006, (char) 14931,
        Double.longBitsToDouble(0x3fb37f672a01ebc8L), Double.longBitsToDouble(0x3fd7635a813123e4L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 6, 12, 13, "\udad7\udd9e\udabd\ude4f\udbba\udf79\ud879\udc87\u3b6a\ud833\ude67\u3351\udb28\udfc2\ud932\udcd1", "\u6860\u7b30\ua68c\u6bbc\uaeb0\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08c5\u4f59\u8c73\u8e4d\u95c5\u0bc6\u7603\uc417\u9253\u9006\u3c21\u97b6\u8603\u7161\u2a6a\u968e\u6eae\u671d\u76f5\u9bb6\u5b86\u4abf\u2353\uc9ac\u7d41\u2f9b\ua69e\uad31\u85b3\u90a1\u92ff\u1bb8\u68ca\u7cf3\u1775", "\udbaa\uddb1\udb22\udf29\ud8e1\udf5e\udb00\udda1\ud89d\udf55\ud8ee\udf00\ud9b6\udf32\udb93\udde2\ud956\udcf3\udba8\udd3c\uda25\udf3e\uda0b\udd1d\ud889\ude67\ud954\udf29\ud937\udc1d\udb5a\udcdd\ud86f\udc94\ud8e5\udc34\udac2\udd92\udad3\udcaf\udbe4\udc4f\udbc4\udfbe",
        20, 6563, 546079879, -2030369615592720780L, 17561L, false, false, (char) 22006, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea01ebc8L), Double.longBitsToDouble(0x3fd760fa813123e4L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 6, 6, 5, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\uda59\ude5a\ud97e\udd1e", "\u687e\u8201\u39ff\u30de\uae73\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08c5\u4f59\u6073\u8e4d\u95c5\u611b", "\ud96e\udfa2\u9b70\ud96f\udcfe\ud8a7\udc0c\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55",
        0, 57847, -1411517274, -3797534847917018913L, 36623L, false, true, (char) 39902, (char) 400,
        Double.longBitsToDouble(0x3fd8b1fe728b5028L), Double.longBitsToDouble(0x3fe6315e79df5106L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.UnmodifiableSet:[\ud37e\u8201\u39ff\u7932\u239e\u3d77\u887b\ub21a\u8247\uc30f\ua420\ua98a\u44c7\u8dd0\u920a\u95a6\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\u030d\u1baf\u221b\u9180\u6e5f\u66fe\ud29b\u9bb6\u5b86\ubf26\u1d11\u9c33\u13c6\u56f0\uad56\uad31\ucecd\uc496\u3c9e\u1eab] |this=org.apache.commons.collections.list.SetUniqueList:[\udae7\udc6b\ud86d\udfeb\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u2057\udabb\ude0c\ud8b7\ude04]\0121=org.apache.commons.collections.set.UnmodifiableSet:[\ud37e\u8201\u39ff\u7932\u239e\u3d77\u887b\ub21a\u8247\uc30f\ua420\ua98a\u44c7\u8dd0\u920a\u95a6\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\u030d\u1baf\u221b\u9180\u6e5f\u66fe\ud29b\u9bb6\u5b86\ubf26\u1d11\u9c33\u13c6\u56f0\uad56\uad31\ucecd\uc496\u3c9e\u1eab] |this=org.apache.commons.collections.list.SetUniqueList:[\udae7\udc6b\ud86d\udfeb\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u2057\udabb\ude0c\ud8b7\ude04]\012",
        Z.run(T, 2, 5, 5, 13, "\udae7\udc6b\ud86d\udfeb\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u2057\udabb\ude0c\ud8b7\ude04", "\ud37e\u8201\u39ff\u7932\u239e\u3d77\u887b\ub21a\u8247\uc30f\ua420\ua98a\u44c7\u8dd0\u920a\u95a6\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\u030d\u1baf\u221b\u9180\u6e5f\u66fe\ud29b\u9bb6\u5b86\ubf26\u1d11\u9c33\u13c6\u56f0\uad56\uad31\ucecd\uc496\u3c9e\u1eab", "\ud8ff\ude9f\ud98d\udc64\udb1d\udc85",
        34, 23149, -871662530, 3155646861401733763L, -41740L, true, false, (char) 38963, (char) 32797,
        Double.longBitsToDouble(0x3fe197716dc5e312L), Double.longBitsToDouble(0x3fedfbef36e1f815L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\0121=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 2, 10, 10, 13, "\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u6373\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\ud41a\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u4abf\u99c9\u65bc\u285c\u5791\uad56\uad31\u13ff\uc492\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud866\udcc8\ud941\udc87\ud8b1\udf38\ud255\udbf9\udf09\ud960\udfe0\ud913\ude79\ud8ab\udf1c\ud8d1\udfc8",
        20, 6563, 1688896647, -343208605189075739L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud8be\udee4\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 1, 12, 0, 13, "\ud8be\udee4\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\ud41a\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u5601\u2353\u659f\u285c\u5791\uad56\uad31\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\ud960\udfe0\ud913\ude79\ud89b\udc35\ud870\udc74",
        0, 6563, 1688896647, -343208605189075739L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 3, 13, 13, "\ud9be\uddbc\udab0\udfc2\ud869\udf9e\ud879\udc87\ud9e9\udc1f\ud833\ude08\uda9a\udc46\udb28\udfc2\u11a7", "", "",
        56, 38826, -432173041, 106527729334482L, 77801L, false, false, (char) 50872, (char) 36886,
        Double.longBitsToDouble(0x3fe294477f6bbf91L), Double.longBitsToDouble(0x3fe0ff1ce3ca4f04L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud98c\udc8c\ud8ed\udca5, \ud9e3\ude42\ud89f\udd28\ud93f\udd09\ud956\udfc7\ud93d\udcf0\ud9c7\udda4\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\uda1a\ude75\ud9bd\udc63\udad1\uddbe\ud838\udec7\udbd8\ude07\ud9de\uddf7\ud945\udd9a\u9b70\ud8a4\udec6\udbb2\udc22\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud9ce\udd71\ud89a\udc89\ud90e\ude27\ud84a\uddd5]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud98c\udc8c\ud8ed\udca5, \ud9e3\ude42\ud89f\udd28\ud93f\udd09\ud956\udfc7\ud93d\udcf0\ud9c7\udda4\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\uda1a\ude75\ud9bd\udc63\udad1\uddbe\ud838\udec7\udbd8\ude07\ud9de\uddf7\ud945\udd9a\u9b70\ud8a4\udec6\udbb2\udc22\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud9ce\udd71\ud89a\udc89\ud90e\ude27\ud84a\uddd5, \ud98c\udc8c\ud8ed\udca5]\012",
        Z.run(T, 2, 4, 4, 13, "\ud98c\udc8c\ud8ed\udca5", "\u8a35\u4f44\u2027\ud641\u3a16\ua56a\u6bd5", "\ud9e3\ude42\ud89f\udd28\ud93f\udd09\ud956\udfc7\ud93d\udcf0\ud9c7\udda4\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\uda1a\ude75\ud9bd\udc63\udad1\uddbe\ud838\udec7\udbd8\ude07\ud9de\uddf7\ud945\udd9a\u9b70\ud8a4\udec6\udbb2\udc22\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud9ce\udd71\ud89a\udc89\ud90e\ude27\ud84a\uddd5",
        57, 23925, 1433686718, 1968207982077358387L, 53286L, true, true, (char) 48278, (char) 56855,
        Double.longBitsToDouble(0x3fea872161453ae0L), Double.longBitsToDouble(0x3fe0ee68de4a80e2L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb3c\ude6e\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2, \udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud938\udd73\uda13\udd3c\ud85f\ude22\ud915\udd61\ud96c\udffe\ud898\udc15\udbc9\udede]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb3c\ude6e\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2, \udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud938\udd73\uda13\udd3c\ud85f\ude22\ud915\udd61\ud96c\udffe\ud898\udc15\udbc9\udede, \udad7\udd9e\udb3c\ude6e\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2]\012",
        Z.run(T, 2, 1, 1, 14, "\udad7\udd9e\udb3c\ude6e\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2", "\u6bd5\u687e\u8201", "\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud938\udd73\uda13\udd3c\ud85f\ude22\ud915\udd61\ud96c\udffe\ud898\udc15\udbc9\udede",
        16, 74639, -500468790, -5001090870565416667L, 32743L, false, true, (char) 5996, (char) 15241,
        Double.longBitsToDouble(0x3fe00e8119f381f8L), Double.longBitsToDouble(0x3fe5fd73a6f773edL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud86b\udfc9\udb57\uddac\ud865\udf3f\ud879\udc87\u6113\ud835\udc5d\u3351\udb28\udfc2\ud919\udfd1\udb84\ude0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud86b\udfc9\udb57\uddac\ud865\udf3f\ud879\udc87\u6113\ud835\udc5d\u3351\udb28\udfc2\ud919\udfd1\udb84\ude0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91, \ud86b\udfc9\udb57\uddac\ud865\udf3f\ud879\udc87\u6113\ud835\udc5d\u3351\udb28\udfc2\ud919\udfd1\udb84\ude0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91]\012",
        Z.run(T, 2, 12, 3, 11, "\ud86b\udfc9\udb57\uddac\ud865\udf3f\ud879\udc87\u6113\ud835\udc5d\u3351\udb28\udfc2\ud919\udfd1\udb84\ude0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91", "\u4cc2\u4f59\u6073\u8e4d\ucace\u0c06\u186f\uc417\u9253\u941d\u4c00\u984a\u8603", "\udb67\udc55",
        0, 57847, -1411519066, -3797534847917018913L, 60104L, true, true, (char) 32114, (char) 16729,
        Double.longBitsToDouble(0x3fe6315e79df5106L), Double.longBitsToDouble(0x3fe95cea3c8038e1L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44] |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44]\0121=java.lang.String:\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44 |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44]\012",
        Z.run(T, 2, 9, 0, 13, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44", "\u08c5\u4f59\u6073\u8e4d\ucace\u0c06\u186f\uc417\u9253\u941d\u4c63\u984a\u8603", "\udb67\udc55",
        0, 85579, -1411519031, -3797534847917018913L, 57103L, false, true, (char) 39902, (char) 400,
        Double.longBitsToDouble(0x3fd8b1fe728b5028L), Double.longBitsToDouble(0x3fe6315e79df5106L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[\udb67\udc55, \udad7\ude55\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\ud926\udd7d\udb28\udfae\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91]\0121=java.lang.String:\udb67\udc55 |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\ude55\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\ud926\udd7d\udb28\udfae\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91]\012",
        Z.run(T, 2, 2, 0, 13, "\udad7\ude55\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\ud926\udd7d\udb28\udfae\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8aa\udf91", "\u08c5\u4f59\u095d\u39c4\ucace\u0c06\u186f\uc417\u9253\u941d\u4c00\u984a\u8603", "\udb67\udc55",
        0, 57847, -1422864364, -3797534847055426954L, 36623L, false, true, (char) 39902, (char) 400,
        Double.longBitsToDouble(0x3fd8b1fe728b5028L), Double.longBitsToDouble(0x3fe6315e79df5106L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud9be\uddbc\udab0\udfc2\ud869\udf9e\ud907\udc8e\ud9e9\udc1f\uda18\udf9a\u8e12\udaeb\udf8e\ue240]\012",
        Z.run(T, 1, 4, 13, 13, "\ud9be\uddbc\udab0\udfc2\ud869\udf9e\ud907\udc8e\ud9e9\udc1f\uda18\udf9a\u8e12\udaeb\udf8e\ue240", "", "",
        56, 43210, -1127280926, -1800968873769082197L, 83012L, false, false, (char) 8312, (char) 17045,
        Double.longBitsToDouble(0x3f8b4d574b90ba00L), Double.longBitsToDouble(0x3fe294477f6bbf91L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud9be\uddbc\udab0\udfc2\ud869\udf9e\ud879\udc87\ud9e9\udc1f\ud9f7\udf15\ud811\udfe2\ud8ca\udcf1\u11a7]\012",
        Z.run(T, 1, 1, 13, 13, "\ud9be\uddbc\udab0\udfc2\ud869\udf9e\ud879\udc87\ud9e9\udc1f\ud9f7\udf15\ud811\udfe2\ud8ca\udcf1\u11a7", "", "",
        56, 38826, -432173041, 106527729334482L, -90644L, false, false, (char) 50872, (char) 36886,
        Double.longBitsToDouble(0x3fe294477f6bbf91L), Double.longBitsToDouble(0x3fe0ff1ce3ca4f04L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.String:\udad7\udd9e\udac5\udcf3\ud865\udf3f\udba6\udefe\ud942\udc4e\ud833\ude3f\u3351\udb28\udfc2\ud951\udfcd\udb8e\udf0e\udb6d\udd5e\uda61\udf81\ud858\udc76\ud9e3\ude84\ud89f\uddc0\udb6d\udccc\ud97f\uddf1\ud8a3\udf9c\udace\udf5c\ud90f\udd44 |this=org.apache.commons.collections.list.SetUniqueList:[\ud823\udeed]\0121=java.lang.String:\ud823\udeed |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udac5\udcf3\ud865\udf3f\udba6\udefe\ud942\udc4e\ud833\ude3f\u3351\udb28\udfc2\ud951\udfcd\udb8e\udf0e\udb6d\udd5e\uda61\udf81\ud858\udc76\ud9e3\ude84\ud89f\uddc0\udb6d\udccc\ud97f\uddf1\ud8a3\udf9c\udace\udf5c\ud90f\udd44]\012",
        Z.run(T, 2, 0, 0, 13, "\udad7\udd9e\udac5\udcf3\ud865\udf3f\udba6\udefe\ud942\udc4e\ud833\ude3f\u3351\udb28\udfc2\ud951\udfcd\udb8e\udf0e\udb6d\udd5e\uda61\udf81\ud858\udc76\ud9e3\ude84\ud89f\uddc0\udb6d\udccc\ud97f\uddf1\ud8a3\udf9c\udace\udf5c\ud90f\udd44", "\u14b9\u500e\u6073\u0e02\u91ea\u914c\u186f\u7334\u547b\u6257\u251a\u984a\u8603", "\ud823\udeed",
        0, 85579, -1411519031, -3797534847917018913L, 57103L, false, true, (char) 39902, (char) 51620,
        Double.longBitsToDouble(0x3fd8b071328b5028L), Double.longBitsToDouble(0x3fe7e46d61df5106L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\udad7\ude55\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\ude07\ud8ef\udf0f\ud926\udd0a\udb28\udfae\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud8e5\udd82\ud950\udef8\ud89f\udddf\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8ba\udf91 |this=org.apache.commons.collections.list.SetUniqueList:[\udb67\udc55]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udb67\udc55]\012",
        Z.run(T, 2, 0, 15, 9, "\udad7\ude55\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\ude07\ud8ef\udf0f\ud926\udd0a\udb28\udfae\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud8e5\udd82\ud950\udef8\ud89f\udddf\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud8ba\udf91", "\u08c5\u4f59\u095d\u39c4\ucace\u0c06\u186f\uc417\u9253\u941d\u4c00\u984a\u8603", "\udb67\udc55",
        0, 57847, -1422864364, -3797534847055426954L, 36623L, false, true, (char) 39902, (char) 400,
        Double.longBitsToDouble(0x3fd8b1fe728b5028L), Double.longBitsToDouble(0x3fe8e8da01f29c94L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud9be\uddbc\udab0\udfc2\ud869\udf9e\ud907\udc8e\ud9e9\udc1f\uda18\udf9a\u8e12\udaeb\udf8e\ue240]\012",
        Z.run(T, 1, 13, 13, 13, "\ud9be\uddbc\udab0\udfc2\ud869\udf9e\ud907\udc8e\ud9e9\udc1f\uda18\udf9a\u8e12\udaeb\udf8e\ue240", "", "",
        56, 69378, -1127280967, -1800968873769082197L, 83012L, false, false, (char) 8312, (char) 17045,
        Double.longBitsToDouble(0x3f8b4d574b90ba00L), Double.longBitsToDouble(0x3fe294477f6bbf91L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udac5\udcf3\ud865\udf3f\uda3a\uddb8\ud942\udc4e\ud833\ude3f\u3351\udb28\udfc2\uda81\udd91\ud952\udd2c\ud94f\udfc7\uda5e\udf93\ud858\udc88\ud9e3\ude84\ud8f9\udfae\udb9c\udccc\ud97f\uddf1\ud8a3\udf9c\ud90f\udd9c\ud90f\udd44]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udac5\udcf3\ud865\udf3f\uda3a\uddb8\ud942\udc4e\ud833\ude3f\u3351\udb28\udfc2\uda81\udd91\ud952\udd2c\ud94f\udfc7\uda5e\udf93\ud858\udc88\ud9e3\ude84\ud8f9\udfae\udb9c\udccc\ud97f\uddf1\ud8a3\udf9c\ud90f\udd9c\ud90f\udd44]\012",
        Z.run(T, 2, 12, 12, 12, "\udad7\udd9e\udac5\udcf3\ud865\udf3f\uda3a\uddb8\ud942\udc4e\ud833\ude3f\u3351\udb28\udfc2\uda81\udd91\ud952\udd2c\ud94f\udfc7\uda5e\udf93\ud858\udc88\ud9e3\ude84\ud8f9\udfae\udb9c\udccc\ud97f\uddf1\ud8a3\udf9c\ud90f\udd9c\ud90f\udd44", "\u14b9\ua1f7\u0c54\ua674\ua2e7\u90d8\uc8c5\ud22a\u547b\u2c9a\u6459\u2fc1\u349f", "\ud94b\udd11",
        0, 65784, 1417962114, -7093921617763432240L, 79831L, true, false, (char) 35801, (char) 51485,
        Double.longBitsToDouble(0x3fc704c2658968f4L), Double.longBitsToDouble(0x3febc257fb64cca5L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1]\012",
        Z.run(T, 1, 8, 13, 13, "\ud9e0\uddbc\ud84f\udc92\ud86c\udf4f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1", "\u687e\u8201\u39ff\u5975\u3187\u3e01\u887b\uca8b\u9cf1\u91c4\u4a6b\u08a1\u4f59\u536c\u8dc5\u95c5\u0bc6\u186f\u0acf\u1958\u750d\u3c21\u97b6\ud41a\u1b01\u221b\u9180\u6e5f\u66fe\u3b04\u9bb6\u5b86\u4abf\u2353\ua5a1\u285c\u5791\uad56\uad31\ucecd\uc496\u3c9e\u1eab\u5775\u7caf\u1775", "\udbaa\uddb1\udb1e\udc0a\ud8e1\udf5e\udadf\udf64\uda8c\ude01\ud82b\uddb5\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\uda48\udf47\ud8c0\udc79\ud941\udd0b\ud8b1\udf38\ud255\udbf9\udf09\ud925\udd31\ud913\ude79\ud89b\udc35\udbc4\udfbe",
        20, 6563, 1688896647, -343208605189075739L, 44583L, false, false, (char) 42022, (char) 14931,
        Double.longBitsToDouble(0x3fb34b1dea0793c8L), Double.longBitsToDouble(0x3fb18d6a04c48f90L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.util.TreeSet:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44] |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44]\0121=java.util.TreeSet:[\u08c5\u4f59\u6073\u8e4d\ucace\u0c06\u186f\uc417\u9253\u941d\u4c63\u984a\u8603] |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44]\012",
        Z.run(T, 2, 9, 9, 13, "\udad7\udd9e\udb57\udcfc\ud865\udf3f\ud879\udc87\ud9fb\udd1f\ud833\udef1\u3351\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb71\udf87\ud854\udf85\ud9e3\ude21\ud89f\uddc0\udb6d\udccc\ud956\udfc5\ud8a3\udf9c\udace\udf5c\ud90f\udd44", "\u08c5\u4f59\u6073\u8e4d\ucace\u0c06\u186f\uc417\u9253\u941d\u4c63\u984a\u8603", "\udb67\udc55",
        0, 85579, -1411519031, -3797534847917018913L, 57103L, false, true, (char) 39902, (char) 400,
        Double.longBitsToDouble(0x3fd8b1fe728b5028L), Double.longBitsToDouble(0x3fe6315e79df5106L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud818\uddb4\uda0f\udcc9\ud84c\udfdb\ud879\udc87\ud9fb\udd1f\ud833\udef1\ud926\udd7d]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud818\uddb4\uda0f\udcc9\ud84c\udfdb\ud879\udc87\ud9fb\udd1f\ud833\udef1\ud926\udd7d]\012",
        Z.run(T, 2, 11, 11, 3, "\ud818\uddb4\uda0f\udcc9\ud84c\udfdb\ud879\udc87\ud9fb\udd1f\ud833\udef1\ud926\udd7d", "\ua50a\u6bd5\u687e\u8201\u39ff\u30de", "\ud8a3\udf9c\udace\udf5c\ud8aa\udf91\udb6f\udf4a\ud85f\uddd6\ud915\udd61\ud96c\udffe\udbc9\ude0c",
        33, 64923, 1325700703, 2030983560874725071L, -4935L, true, false, (char) 48917, (char) 5996,
        Double.longBitsToDouble(0x3fe0dc0b76ccd323L), Double.longBitsToDouble(0x3fe32537c56b2100L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.String:\udad7\udd9e\udac5\udcf3\ud865\udf3f\ud8ea\udc60\ud80f\ude2e\ud833\ude3f\u3351\udb28\udfc2\ud951\udfcd\ud846\udf0b\ud9a2\udf78\uda48\udd8d\ud858\udc76\ud9e3\ude84\ud89f\uddc0\udb6d\udccc\ud97f\uddf1\ud8a3\udf9c\udace\udf5c\ud90f\udd44 |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 14, 13, "\udad7\udd9e\udac5\udcf3\ud865\udf3f\ud8ea\udc60\ud80f\ude2e\ud833\ude3f\u3351\udb28\udfc2\ud951\udfcd\ud846\udf0b\ud9a2\udf78\uda48\udd8d\ud858\udc76\ud9e3\ude84\ud89f\uddc0\udb6d\udccc\ud97f\uddf1\ud8a3\udf9c\udace\udf5c\ud90f\udd44", "\u14b9\u7c16\uc3e4\u9c1f\u91ea\u914c\u186f\u7334\u547b\u6257\u251a\u984a\u8603", "\ud823\udeed",
        0, 85579, -1411519031, -3797534847917018913L, -4593L, true, true, (char) 39902, (char) 51620,
        Double.longBitsToDouble(0x3fd8b071328b5028L), Double.longBitsToDouble(0x3fefe46d6200cc5bL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\ude5f\ud8ed\udc47\ud865\udf58\ud879\udc87\ud9fb\udd1f\u1aa4\udbf7\udda2\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb3b\udf8c\ud854\udf85\ud9e3\ude42\ud89f\udd28\ud93f\udcf6\ud956\udfc7\ud89b\uddb3\udace\udf5c\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\uda1a\ude75\udbbc\ude7b\udad1\uddbe\ud838\udec7\udbd8\ude07\udbb4\ude42\ud96e\udfa2\u9b70\ud978\udfa3\ud8a7\udc0c\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud9ce\udd71\ud89a\udc89\ud90e\ude27\ud84a\uddd5\udbd6\udd8b\udb70\udd80\ud8a9\udfc7\ud819\udc57\ud5e7\ud96a\udf80\uda38\udf6d\udbd0\udfd9\ud964\udf8c\ud9a0\udc04\ud88c\udc55\udab5\udfed\ud8b5\ude7b\ud8a3\ude45\ud8ff\ude9f\ud98d\udc64\u0305\udb96\udfb1\udb22\udf29\ud8e1\udf5e\udb1f\udebe\ud8ce\udc8e\ud97f\udcf3\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\udafe\udce2\ud8df\udfee\ue48f\ud8b1\udf38\ud255\udbf9\udf09\udac2\udd92\ud8b5\udca1\ud89b\udc76\udbc4\udfbe\ud882\udfa4\ud8b9\udf23\ud80c\ude07\ud85d\udd50\uda93\ude6a\udb1a\udf9b\ud995\uddf8\ud8c6\udfd0\ud93c\ude82\udb5a\ude46\ud990\udfec\ud9f0\udc69\udaa1\udef9\udaa5\udd06\udb57\udcbb\udb8c\udc3e\udaf8\udfe2\udbb4\ude7a\ud309\udbb1\ude74\u2c4f\udb95\udc78\ud8d4\udf55\uda61\udd10\udb66\udd3a\ud882\udef6\udb49\udf65]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\udad7\ude5f\ud8ed\udc47\ud865\udf58\ud879\udc87\ud9fb\udd1f\u1aa4\udbf7\udda2\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb3b\udf8c\ud854\udf85\ud9e3\ude42\ud89f\udd28\ud93f\udcf6\ud956\udfc7\ud89b\uddb3\udace\udf5c\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\uda1a\ude75\udbbc\ude7b\udad1\uddbe\ud838\udec7\udbd8\ude07\udbb4\ude42\ud96e\udfa2\u9b70\ud978\udfa3\ud8a7\udc0c\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud9ce\udd71\ud89a\udc89\ud90e\ude27\ud84a\uddd5\udbd6\udd8b\udb70\udd80\ud8a9\udfc7\ud819\udc57\ud5e7\ud96a\udf80\uda38\udf6d\udbd0\udfd9\ud964\udf8c\ud9a0\udc04\ud88c\udc55\udab5\udfed\ud8b5\ude7b\ud8a3\ude45\ud8ff\ude9f\ud98d\udc64\u0305\udb96\udfb1\udb22\udf29\ud8e1\udf5e\udb1f\udebe\ud8ce\udc8e\ud97f\udcf3\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\udafe\udce2\ud8df\udfee\ue48f\ud8b1\udf38\ud255\udbf9\udf09\udac2\udd92\ud8b5\udca1\ud89b\udc76\udbc4\udfbe\ud882\udfa4\ud8b9\udf23\ud80c\ude07\ud85d\udd50\uda93\ude6a\udb1a\udf9b\ud995\uddf8\ud8c6\udfd0\ud93c\ude82\udb5a\ude46\ud990\udfec\ud9f0\udc69\udaa1\udef9\udaa5\udd06\udb57\udcbb\udb8c\udc3e\udaf8\udfe2\udbb4\ude7a\ud309\udbb1\ude74\u2c4f\udb95\udc78\ud8d4\udf55\uda61\udd10\udb66\udd3a\ud882\udef6\udb49\udf65, \udad7\ude5f\ud8ed\udc47\ud865\udf58\ud879\udc87\ud9fb\udd1f\u1aa4\udbf7\udda2\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb3b\udf8c\ud854\udf85\ud9e3\ude42\ud89f\udd28\ud93f\udcf6\ud956\udfc7\ud89b\uddb3\udace\udf5c\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\uda1a\ude75\udbbc\ude7b\udad1\uddbe\ud838\udec7\udbd8\ude07\udbb4\ude42\ud96e\udfa2\u9b70\ud978\udfa3\ud8a7\udc0c\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud9ce\udd71\ud89a\udc89\ud90e\ude27\ud84a\uddd5\udbd6\udd8b\udb70\udd80\ud8a9\udfc7\ud819...\012",
        Z.run(T, 2, 8, 4, 13, "\udad7\ude5f\ud8ed\udc47\ud865\udf58\ud879\udc87\ud9fb\udd1f\u1aa4\udbf7\udda2\udb28\udfc2\ud919\udfd1\udb8e\udf0e\udb6d\udd5e\udb3b\udf8c\ud854\udf85\ud9e3\ude42\ud89f\udd28\ud93f\udcf6\ud956\udfc7\ud89b\uddb3\udace\udf5c\ud8aa\udf91\udab7\udf4e\ud85f\ude22\ud915\udd61\ud96c\udffe\uda1a\ude75\udbbc\ude7b\udad1\uddbe\ud838\udec7\udbd8\ude07\udbb4\ude42\ud96e\udfa2\u9b70\ud978\udfa3\ud8a7\udc0c\ud9f9\udc90\udbc9\udf48\udb72\udcc1\udb67\udc55\ud9ce\udd71\ud89a\udc89\ud90e\ude27\ud84a\uddd5\udbd6\udd8b\udb70\udd80\ud8a9\udfc7\ud819\udc57\ud5e7\ud96a\udf80\uda38\udf6d\udbd0\udfd9\ud964\udf8c\ud9a0\udc04\ud88c\udc55\udab5\udfed\ud8b5\ude7b\ud8a3\ude45\ud8ff\ude9f\ud98d\udc64\u0305\udb96\udfb1\udb22\udf29\ud8e1\udf5e\udb1f\udebe\ud8ce\udc8e\ud97f\udcf3\ud9b6\udf32\udb93\udde2\ud938\udc07\ud828\udd3c\uda25\udf3e\uda0b\udd1d\udafe\udce2\ud8df\udfee\ue48f\ud8b1\udf38\ud255\udbf9\udf09\udac2\udd92\ud8b5\udca1\ud89b\udc76\udbc4\udfbe\ud882\udfa4\ud8b9\udf23\ud80c\ude07\ud85d\udd50\uda93\ude6a\udb1a\udf9b\ud995\uddf8\ud8c6\udfd0\ud93c\ude82\udb5a\ude46\ud990\udfec\ud9f0\udc69\udaa1\udef9\udaa5\udd06\udb57\udcbb\udb8c\udc3e\udaf8\udfe2\udbb4\ude7a\ud309\udbb1\ude74\u2c4f\udb95\udc78\ud8d4\udf55\uda61\udd10\udb66\udd3a\ud882\udef6\udb49\udf65", "\u590d\u8ec5", "\uda51\udc65\u6626\udb6c\udd4d\udbb0\udd3d\udb2c\udf62\ud8fe\udc2b\ud99c\udeda\udb91\udcfe",
        1, 70031, 872771996, 3640623095183586973L, -85467L, true, false, (char) 52311, (char) 61941,
        Double.longBitsToDouble(0x3fe232420d623d84L), Double.longBitsToDouble(0x3fc9e4f625e6413cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 4, 4, 0, "", "", "",
        -5, -1000, 990839296, -1887574158022405721L, -87281L, false, false, (char) 55582, (char) 8859,
        Double.longBitsToDouble(0x3f495376b0000000L), Double.longBitsToDouble(0x3fccbea7039d07a4L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.list.SetUniqueList|set|int,java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|add|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|add|int,java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|int,java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|asSet||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|clear||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|contains|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|containsAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|createSetBasedOnList|java.util.Set,java.util.List|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|iterator||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|listIterator||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|listIterator|int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|remove|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|remove|int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|removeAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|set|int,java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
