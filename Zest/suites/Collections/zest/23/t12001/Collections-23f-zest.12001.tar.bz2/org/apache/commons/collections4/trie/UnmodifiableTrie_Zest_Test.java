package org.apache.commons.collections4.trie;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnmodifiableTrie_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 13, "\ud8a0\udea6\udadd\udf0d\udbd0\udece\udb50\udcb5\u98b1\ud87e\udd6d", "\u9b35\uaa31\ub0a8\u93c8\u2bbb\u4ac2\u3724\uc3a0\uba0a\u5bb7\ub805\u87b4\u2ec4", "\ud905\uddae\ud882\udedd\ud950\udc58\ud846\udc27\udb57\udd3c",
        28, 66424, 1648677070, 7112286338932079244L, -28806L, false, false, (char) 61625, (char) 63108,
        Double.longBitsToDouble(0x3fe2e5b6454a6662L), Double.longBitsToDouble(0x3fe57e4f6ebc5a3bL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 13, "\uda09\udda8\ud914\ude77\udb35\udcc0\udb77\udc1e\udab5\udf07\ud969\udfef", "\u479e\uaa31\ub0a8\u93c8\u2bbb\u24c2\u5210\u24fb\uc15a\u8f03\ub805\u87b4\u77a6\u28c5\u97b9", "\ud95c\udc5e\ud846\udc27\udb57\udd3c\udad9\udeee\ud96f\udd0c\uda0b\ude98\ud820\udc8f\udb59\udcb8\udbe3\udef4\ud9fa\udd64\ud8a7\udf9f\udb8f\udeeb",
        12, 54652, -907205302, 6501991348314334908L, -78659L, true, false, (char) 56733, (char) 57699,
        Double.longBitsToDouble(0x3fd8360940a52a1aL), Double.longBitsToDouble(0x3fc07c5fa31f14c0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 13, "\udba0\ude47\uda90\udc19\udbd0\udf6d\udb50\udcb5\u2f43\udab3\udeee", "\u9123\u0ce9\u8bba\u9352\u061a\u9c96\u3724\u97ad\u6b97\u2403\ud32f\u87b4\u2ec4", "\ud91b\udde0\ud882\udeb4\ud9da\uded1\udaed\uded8\udb90\udecc\ud85e\ude76\ud9d9\udfda\uda0b\ude98\ud820\udc8f\udb59\udcb8",
        54, 94822, -216616862, -5973953837112095892L, 84798L, true, true, (char) 13105, (char) 4460,
        Double.longBitsToDouble(0x3fec0515d9a75081L), Double.longBitsToDouble(0x3fcb6b5c746732a0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 14, 15, 7, "\udbd4\udce5\ud9a7\udcad\udbd0\udece\udb50\udcb5\u98b1\ud87e\udd6d\ud98e\ude93\uda2e\udc98\udaec\udea6\ud842\udc19\ud994\udca7\udba3\udf40\udadf\udd0f\ud98e\udf08\ud90b\uddc6\ud8c1\udf2f", "\ub805\u87b4\u2ec4\u2e2f\u97b9\u1656\u9a3a\u0397\ub0be\u29d9\u7826\u6580\u4f93\u9330\ud64a\uad29\u409e\u7114\u4b61\uc3a4\u5bb5\u4d33\ud52d\u84d1\u4ff7\uce99\ub97d\uc0d8\u6dc1\u9f9c\u4c26\u0f99", "\udb55\udcce\uda15\udee1\uda1b\udfb4\udba0\udf1e\uda13\udd7c\uda09\uddae\udb6f\udfd3\u0fe5\ud8cd\uded8\udbae\udce2\uda38\udd66\u91f6\udb4d\udecf\ud975\udc82",
        -1, 71383, -1751088602, 4862407585465448884L, -70674L, true, true, (char) 9797, (char) 26027,
        Double.longBitsToDouble(0x3fc79918a6374f50L), Double.longBitsToDouble(0x3fc83639d9dcce68L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 0, 10, 0, "\ud8a0\udea6\udadd\udf0d\uc960", "\000", "\ud88e\udcd3\udb7e\udc17\ud994\udca7\u839f\000\000\ud8b3\udd18\ud898\udcd3\udb98\udfc4\uda8c\udca8\ud815\udfa3\ud9b8\uddb0\udbcb\udd71",
        56, 1216, -347744537, 809082319520L, 11367L, true, false, (char) 16336, (char) 3945,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3e2e6fe000000000L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 10, 0, "", "\u0634\ud110\u0d9f\u80f2\ua901\u0aad\u9b35\uaa31", "\udadf\udd0f",
        33, 40966, 518440705, 409353584640L, -21230L, false, true, (char) 16950, (char) 3407,
        Double.longBitsToDouble(0x3fe000056bbceb45L), Double.longBitsToDouble(0x3fe50789d2d96110L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|unmodifiableTrie|org.apache.commons.collections4.Trie|static",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|clear||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|comparator||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|containsKey|java.lang.Object|new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|containsValue|java.lang.Object|new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|entrySet||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|equals|java.lang.Object|new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|firstKey||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|get|java.lang.Object|new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|hashCode||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|headMap|java.lang.Object|new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|isEmpty||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|keySet||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|lastKey||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|mapIterator||new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|nextKey|java.lang.Object|new:org.apache.commons.collections4.trie.UnmodifiableTrie:org.apache.commons.collections4.Trie",
    "M|org.apache.commons.collections4.trie.UnmodifiableTrie|unmodifiableTrie|org.apache.commons.collections4.Trie|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
