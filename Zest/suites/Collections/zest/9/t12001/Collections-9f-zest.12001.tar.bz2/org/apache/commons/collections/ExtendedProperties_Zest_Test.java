package org.apache.commons.collections;
import org.junit.Test;
import static org.junit.Assert.*;
public class ExtendedProperties_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, 77896, 440528067, -6172712799639620507L, -96223L, true, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60}\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 3, 13, 14, "\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, 77896, 447381691, 8605390881227879472L, -96223L, true, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 13, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda40\udf92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u18e4\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, -912, 436207616, -6172712799639620507L, -96223L, true, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.util.NoSuchElementException\012",
        Z.run(T, 1, 10, 6, 6, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\u0374\ua735\u511c\uaf81\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\ud8d5\ude6e\ud9b5\ude1a",
        55, 77853, 440528001, -6172712799639620507L, -96223L, true, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Byte:21 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 14, 13, 14, "\ud9e7\ude5f\udab6\udf59\ud8ec\udcc8\udbd8\udc76\uda0b\udc62\ud969\udd1a\ud8c2\udf8d\udb24\udcbd\ud80a\udd05\uda95\udc11\uda88\udf30\ud8f9\udcc2\ud81b\ude43\uda39\udd57\ud91b\udf4f\uda50\udc95\u7eac\udb26\udfc4\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21\ud96a\uddab\udb6f\udf17\ud855\ude4f\uda6e\udd5d\ud969\udff2", "\u2073\u90c8\u65a7", "\uda3c\ude81\ud832\udcb9\udb7a\ude44\uda69\uded1",
        21, 98866, -1457784226, -8320617102675925153L, -15080L, false, false, (char) 8669, (char) 26297,
        Double.longBitsToDouble(0x3febae7fde37de17L), Double.longBitsToDouble(0x3fd09a4148042232L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 13, 13, 14, "\ud8de\udd0d\udb85\udf0b\ud8ec\udd3f\udbd8\udc76\ud81f\udc6c\udb63\udd96", "\ub9a0\u2557\ua3e6\uab9a\ua73b\u3297\u4830\u5c92\u3ebd\ub1ee\u897f\u5313\u08b8\u5823", "\ud96a\uddab\udb6f\udf17\uc852\ud8ac\uddf4\ud9d8\udcea\ud9a9\udcfe\ud87c\udeee\ud9af\uded4\udbc3\udc01\ud977\udffa\udb55\udc0b\udb0a\udda3\ud846\udebf\udbc0\udc11\udb80\udf09\ud8e3\udce3\uda0c\udcd4",
        48, 71846, -1658046511, 1187274003576666415L, -18568L, true, false, (char) 15795, (char) 20052,
        Double.longBitsToDouble(0x3fcb2cf57b4515f8L), Double.longBitsToDouble(0x3fd208f39fea0250L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:\udb2d\udd9a\udb5e\udcaa\ud810\udc35\ud9a0\ude84\udb90\udfe3\uda59\udc92\uda7c\udf39\ud9ed\uded5\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 9, 12, 11, "\udb2d\udd9a\udb5e\udcaa\ud810\udc35\ud9a0\ude84\udb90\udfe3\uda59\udc92\uda7c\udf39\ud9ed\uded5", "\ua3e6\uab9a\ua73b\uaa96\u66be\u1ae5", "\ud842\ude37\udb8f\ude51\uda1a\udf4d\ud9c6\ude34\u474c",
        50, 93037, -925384104, -6356879464435671446L, 33238L, false, false, (char) 10053, (char) 58669,
        Double.longBitsToDouble(0x3fec4094c2aeb487L), Double.longBitsToDouble(0x3fedc0e92be00deeL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 1, "\ud905\ude0d\ud838\ude2d\ud8ec\udd3f\udbd8\udc76\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\udf9e\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, 77896, 440528067, -6172712799639620507L, 1404L, false, false, (char) 20055, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 13, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda2c\udcb0\uda26\udf59", "\ua3e6\uab9a\ua79e\u511c\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u6df1\udaf7\ude36",
        36, 77896, 440528067, -6172712799639620507L, -96223L, true, false, (char) 35695, (char) 26834,
        Double.longBitsToDouble(0x3fef05df7804e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\udbc0\udd69\ud9ea\udd1d\ud90e\udedc\ud8b6\udcbb\uda76\udee3\udb53\udf16\uda3c\udfb1\udaa3\ude74\uda95\udc11\uda88\udf30\ud8f9\udcc2\ud915\udc60=\u5c60\u24c6\ub1ee\u897f\u93d5\u1e84\u1783\u3b36\u4228\u1878\u80f8\ubbe1}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 1, "\ud905\ude0d\udbc0\udd69\ud9ea\udd1d\ud90e\udedc\ud8b6\udcbb\uda76\udee3\udb53\udf16\uda3c\udfb1\udaa3\ude74\uda95\udc11\uda88\udf30\ud8f9\udcc2\ud915\udc60", "\u5c60\u24c6\ub1ee\u897f\u93d5\u1e84\u1783\u3b36\u4228\u1878\u80f8\ubbe1", "\udad4\udd54\udbfd\udf0f\ud9af\ude2e\udbc3\udc01\ud9a1\udd81\uda0d\udeae\ud820\uddaf\udbf6\ude7e\ud832\udcb9",
        47, 11677, -1298569110, -2674510129871235309L, 47058L, true, false, (char) 28290, (char) 2726,
        Double.longBitsToDouble(0x3fc8008a0abd5724L), Double.longBitsToDouble(0x3fc981d018b110ecL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\ud9a0\ude95\ud82e\udc65\ud8a2\udfcb=\u281f\u1c98\ua73b\u511c}\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 3, 6, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\ud9a0\ude95\ud82e\udc65\ud8a2\udfcb", "\u281f\u1c98\ua73b\u511c", "\u7eac\udb26\udfc4\ud8d8\ude78",
        -4, 93432, -475452777, 8439754932522822863L, -84216L, true, false, (char) 3323, (char) 62669,
        Double.longBitsToDouble(0x3fec5627ce3a1e67L), Double.longBitsToDouble(0x3fe8b071793facc6L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7=[\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60, \ua3e6\uab9a\ua73b\u511c\uaf90\u5c60]}\012",
        Z.run(T, 2, 3, 1, 12, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\udb69\udd2e\udbd1\udd2a\ud9d1\udf53",
        36, 77896, -113120061, 2531776915266180420L, 8248L, true, false, (char) 35716, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fe264220d6d1082L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\u983a", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21\ud96a\uddab\udb6f\udf17\ud855\ude4f\uda6e\udd5d\ud9d8\udcea\udad4\udd54\udbfd\udf0f",
        17, 82079, -1260368207, 2100320709758207416L, 88412L, false, true, (char) 38379, (char) 4831,
        Double.longBitsToDouble(0x3fef38facfd265c1L), Double.longBitsToDouble(0x3fc010cc7f1f02d4L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\uddb6=\u87f6\u34a9\ua1d6\ucc91\u8da6\u22a6\u25a5\ua3e6}\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 6, 7, "\ud905\uddb6", "\u87f6\u34a9\ua1d6\ucc91\u8da6\u22a6\u25a5\ua3e6", "\udbc8\udd51\uda15\udc30\uda50\udc95\u7eac\ud828\udfc5\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud92c\udf8c\ud810\udc44\udb6f\udf17\ud872\ude3e\uda6e\udd8c\ud9d8\udcea\udad4\udd54\udbfd\udf0f\ud9af\ude2e\udbc3\udc01\uda78\ude43\udae6\udc46",
        36, 46445, -2076106740, 1188705435556349293L, -32635L, true, true, (char) 58215, (char) 11798,
        Double.longBitsToDouble(0x3fc8ee598180ea48L), Double.longBitsToDouble(0x3fef42c1c4d08051L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud901\udcb5\ud878\udd65\ud8ec\udd3f\udbeb\udd76\ud87c\uddfa\uda95\udc07\ud9c3\udeb2\ud9a9\udfee=\u1859\uab9a\ua73b\u23e8\u673d\u5414}\0121=!java.lang.NumberFormatException\012",
        Z.run(T, 2, 3, 15, 11, "\ud901\udcb5\ud878\udd65\ud8ec\udd3f\udbeb\udd76\ud87c\uddfa\uda95\udc07\ud9c3\udeb2\ud9a9\udfee", "\u1859\uab9a\ua73b\u23e8\u673d\u5414", "\ud83d\ude26\ud91b\uded7\ud905\udd66\ud9b4\udd21\u474c\ud9d2\udc21",
        21, 82176, -1121614933, -6172712799639620507L, -96223L, true, true, (char) 17806, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 11, 13, 14, "\ud905\ude34\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\udbc5\udd3a\udbf3\udc4d", "\ua3e6\uab9a\u9143\u5140\uaf90\u5c60\u3ebd\ub1ee", "\ud912\uddac\ud9b4\udceb\udad3\udf4c\ud9d2\udc21\udbde\udd44\ud974\udc0d\ud855\ude4f\uda6e\uddd0\ud9d8\udcea",
        5, 18711, -1058061006, 6454334189524860147L, -49384L, false, false, (char) 2136, (char) 42381,
        Double.longBitsToDouble(0x3fd6d107ffc70cd8L), Double.longBitsToDouble(0x3fe38cf5a24db818L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.String:\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 9, 13, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f", "\ud9b4\udceb\u474c\ud9d2\udc21\ud96a\uddab\udb6f\udf17\ud855\ude4f\uda6e\udd5d\ud9d8\udcea\ud889\udd8f\udbfd\udf0f\ud9af\ude2e\udbc3\udc01\uda78\ude43\udae6\udc46\ud820\uddaf",
        34, 36812, 276767091, -5808652390068007543L, 56952L, false, false, (char) 21862, (char) 36321,
        Double.longBitsToDouble(0x3fee1ce4073625c8L), Double.longBitsToDouble(0x3fe6f8c0fc6a2387L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 4, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda22\udcdf", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, 77896, 440528067, -6172712799639620507L, -96223L, true, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd3037adada20feL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\udbf4\udcc2\ud8ff\udead\udbd8\udc76\uda0b\udc62\uda59\udc92\udb83\udff9\uda5a\uddb0=\ua3e6\uab9a\ua73b\u511c}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 14, "\ud905\ude0d\udbf4\udcc2\ud8ff\udead\udbd8\udc76\uda0b\udc62\uda59\udc92\udb83\udff9\uda5a\uddb0", "\ua3e6\uab9a\ua73b\u511c", "\u7eac\udb27\udc2a\ud8d8\ude78",
        -4, 93432, -475452777, 8439754932522822863L, -84216L, true, false, (char) 14507, (char) 57019,
        Double.longBitsToDouble(0x3fec5627ce3a1e67L), Double.longBitsToDouble(0x3fe8b071793facc6L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 13, 14, "\ud811\udf44\ud829\udc75\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\udb23\udf0a", "\ua3e6\uab9a\ua73b\u511c\uaf7d\u5c60", "\ud99a\udf17\ud92c\udeb1\ud912\uddac\ud9b4\udceb\ud891\ude0c\ud883\udfb6",
        18, 14712, 440528067, -6172712799505795995L, -50054L, false, true, (char) 40453, (char) 32140,
        Double.longBitsToDouble(0x3fe47da706a41706L), Double.longBitsToDouble(0x3fea23dc3804e8c5L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbc8\udd41\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7\ud80a\udd05\ud9be\ude66\u30cd\ud8d1\udece\udb9f\udc6b\ud9f9\udd48\ud91b\udf4c\uda50\udc95\u7eac=\u620d\u08b8\u7100\uc83e\u1b88\u6af1\ubcc3\u7ec4\u9945\u4968\u9728\ud0f5\u6d4b\ub3f8\u65a7\ub11a\ubc46\uc776}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbc8\udd41\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7\ud80a\udd05\ud9be\ude66\u30cd\ud8d1\udece\udb9f\udc6b\ud9f9\udd48\ud91b\udf4c\uda50\udc95\u7eac=\u620d\u08b8\u7100\uc83e\u1b88\u6af1\ubcc3\u7ec4\u9945\u4968\u9728\ud0f5\u6d4b\ub3f8\u65a7\ub11a\ubc46\uc776}\012",
        Z.run(T, 2, 3, 2, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbc8\udd41\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7\ud80a\udd05\ud9be\ude66\u30cd\ud8d1\udece\udb9f\udc6b\ud9f9\udd48\ud91b\udf4c\uda50\udc95\u7eac", "\u620d\u08b8\u7100\uc83e\u1b88\u6af1\ubcc3\u7ec4\u9945\u4968\u9728\ud0f5\u6d4b\ub3f8\u65a7\ub11a\ubc46\uc776", "\ud89a\udf80\ud876\udc72\ud940\uddb8\uda5b\udf47\ud862\udc7d\udbfb\udfcd\udb17\udf60\ud9e3\udc47",
        16, 93953, -1997566112, -2046138454993954869L, 27663L, true, false, (char) 59703, (char) 38246,
        Double.longBitsToDouble(0x3fe92738418cb94bL), Double.longBitsToDouble(0x3fe6c96afbe8d12dL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:0\012",
        Z.run(T, 1, 6, 13, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\ud896\udc75\uda1b\udfac\uda59\udc92\uda21\udd48\uda26\udea7", "\ua4a5\uab9a\ud525\u9946\u243f\u19ed\u2986\ub1ee\u897f\ubab9\u82e6\u70d8\u3b36\u6f9f\ua0fb\ubd17\ubbe1\u78e2\u7e6f\ubea9\uab33\u3928\u3cb8\u65a7\ub11a\u8492\u8858\u8b56\ua372\u1314\u2e64\u9ecc", "\ud8f4\udf5c\ud866\udc8c\ud955\udce2\ud982\udda8",
        12, 44181, 957960102, -1164555281609511268L, -13890L, true, false, (char) 18110, (char) 28406,
        Double.longBitsToDouble(0x3fdf9c39bbbcd19aL), Double.longBitsToDouble(0x3fbb293e62f07390L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud85c\udcfa\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\udaa2\udded\uda21\udd48\uda26\udea7=\ua26b\uab9a\ua73b\u511c\uaf90\u5c60}\012",
        Z.run(T, 2, 7, 1, 11, "\ud85c\udcfa\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\udaa2\udded\uda21\udd48\uda26\udea7", "\ua26b\uab9a\ua73b\u511c\uaf90\u5c60", "\ud95e\ude7b\ud840\udebb\ud912\uddac\ud800\ude86\ud927\ude73\ud9ce\udc1e",
        36, 77896, -1506743101, -6172712799639620507L, 34935L, false, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fe705dc424c0d1eL), Double.longBitsToDouble(0x3fd3a066bbd10c4eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\ud8f0\udc25\udbd8\udc76\ud9ea\uddd1\uda59\udc84\uda21\udd48\uda26\udea7=\ua3e6\uab9a\ua73b\u511c\uaf90\ua838}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\ud8f0\udc25\udbd8\udc76\ud9ea\uddd1\uda59\udc84\uda21\udd48\uda26\udea7=[\ua3e6\uab9a\ua73b\u511c\uaf90\ua838, \ua3e6\uab9a\ua73b\u511c\uaf90\ua838]}\012",
        Z.run(T, 2, 1, 1, 14, "\ud905\ude0d\ud878\udd65\ud8f0\udc25\udbd8\udc76\ud9ea\uddd1\uda59\udc84\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\ua838", "\ud8d8\ude78\ud92c\udebe\ud912\uddac\ud9b4\udceb\u474c\ud9f4\udc53",
        53, 17776, -1610985155, 3717563410792697338L, -96223L, true, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 4, 13, 14, "\udbb6\udc87\ud857\udc07\uda61\udd6e\udaab\udf6e\uda6a\udf3f\uda59\udc92\uda21\udd48\uda26\udea7", "\u5ea5\u9c19\u2750\u8e0c\u9759\u5c60", "\ud89d\udf2c\ud983\udda4\uda86\udf9e\ud913\udf54\udb16\udccd\ud9dc\ude52\ud96a\uddab\ud863\udf11\ud855\ude4f\udbb7\udcd7\ud8bf\ude24\ud9cc\udf9b",
        47, 61653, 784986431, -8511716773125040497L, 25686L, true, false, (char) 48741, (char) 32111,
        Double.longBitsToDouble(0x3fe74ab329ccc22cL), Double.longBitsToDouble(0x3fe6e8ee3b204cbdL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 11, 8, 14, "\udbee\udc8b\udb14\udcdf\ud98d\udfc6\udafd\udd17\uda36\udd53\udb02\ude78\ud951\udca2\ud961\udee9", "\u51df\ua058\ua73b\ub708\u5a2b", "\udb26\udfc4\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud80b\udf76\ud9e6\udea7\ud9d2\udc21\uda42\udf92\udb44\udf17\udba2\ude6d",
        23, 31907, -781302344, 1022098332672013692L, 93460L, false, true, (char) 2250, (char) 42381,
        Double.longBitsToDouble(0x3fd6d107f621f1eeL), Double.longBitsToDouble(0x3fd2efb1061fd194L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\ud8d2\udce9\ud878\udd65\ud9df\ude79\ud9d8\udc80\uda0b\udc35\uda59\udc92\uda21\udd48\uda20\ude23\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8d2\udce9\ud878\udd65\ud9df\ude79\ud9d8\udc80\uda0b\udc35\uda59\udc92\uda21\udd48\uda20\ude23=\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60}\012",
        Z.run(T, 2, 9, 2, 14, "\ud8d2\udce9\ud878\udd65\ud9df\ude79\ud9d8\udc80\uda0b\udc35\uda59\udc92\uda21\udd48\uda20\ude23", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, 77896, 447381691, -3572342510376635189L, -52442L, false, true, (char) 40453, (char) 32313,
        Double.longBitsToDouble(0x3fe47da47bb81d25L), Double.longBitsToDouble(0x3fef05dc4004e8c5L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, 77896, 447381691, 8605390881227879472L, -96223L, true, false, (char) 35695, (char) 55772,
        Double.longBitsToDouble(0x3fbcbbef80274138L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Byte:37 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 15, 12, 5, "\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7\ud80a\udd05\uda95\udc11\uda88\udf30\ud8f9\udcc2\ud81b\ude43\ud9f9\udd48\ud91b\udf4c\uda50\udc95", "\u897f\u620d\u08b8\u6f5a\uafb8\u5b22", "\ud906\ude4d\udab5\udc73\ud9d8\udcb5\udad4\udd54\ud94d\udf17\ud9af\ude2e\udbc3\udc01\uda78\ude43\udae6\udc46\ud820\uddaf\uda3c\ude81\ud832\udcb9",
        37, 72469, 2074898853, -3047602459083996277L, -59794L, false, true, (char) 60302, (char) 27115,
        Double.longBitsToDouble(0x3fe3d4332df9d142L), Double.longBitsToDouble(0x3fe128ec85ebe18bL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.util.NoSuchElementException\012",
        Z.run(T, 2, 11, 10, 14, "\uda8a\udf43\uda5c\udef9\ud988\udde8\ud8a9\udf97", "\u7fd8\u0915\u88a0\u7864\ua439\u687f", "\udbbc\udd2a\uda50\udcc5",
        41, 25685, -2040350301, -8012607240655472442L, 80257L, true, false, (char) 27124, (char) 24067,
        Double.longBitsToDouble(0x3fc4bf3af5a86aa8L), Double.longBitsToDouble(0x3fa85bb678ac4f90L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=\u50dc\uab9a\u3492\u4d86\u1cff\u5a28}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 3, 4, 14, "\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7", "\u50dc\uab9a\u3492\u4d86\u1cff\u5a28", "\ud9b2\udd81\ud92c\udf84\udbe1\udd94\ud889\udd06\u474c",
        50, 36221, -925384104, 1921489733677776234L, -97834L, true, true, (char) 2507, (char) 40453,
        Double.longBitsToDouble(0x3fbd8bb6f55a8550L), Double.longBitsToDouble(0x3fdb879256b77710L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8a5\udc6b\uf982\ud860\udc49\uda0b\udc35\ud8f7\udfc1\ud90b\udd70\ud848\uddb5=\ua3e6\ucfc0\u5f68\u515b}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 5, 14, "\ud8bd\udee1\ud8a5\udc6b\uf982\ud860\udc49\uda0b\udc35\ud8f7\udfc1\ud90b\udd70\ud848\uddb5", "\ua3e6\ucfc0\u5f68\u515b", "\u7eac\udb26\udfc4\ud8d8\ude78",
        -4, 93432, -475454569, 8439754931286757437L, -67894L, false, false, (char) 48259, (char) 25761,
        Double.longBitsToDouble(0x3fe8fc99799b83bfL), Double.longBitsToDouble(0x3fe58976d8a0af56L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60}\012",
        Z.run(T, 2, 3, 7, 10, "\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, 77896, 447381691, 8605390881227879472L, -96223L, true, true, (char) 35574, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 5, 14, "\ud8bd\udee1\ud878\udd65\ud8de\udd6a\ud9cd\udc82\uda2e\udf6d\uda59\udc92\udb9d\udd8f\uda50\udf84\uda2d\udddf\uda95\udc11", "\ua73b\ua0f8\u41f6\u5c60\u3ebd\uba5b\ua755\uc3c4\u165b", "\u4b62\ud806\udd54\udb6d\udc37\ud9c3\ude14\ud869\udcd3\ud9fb\udc79\ud837\udf01\u34be\ud97f\udcd3\udbd5\udce7\uda78\ude61\udae6\udc46\ud953\ude69\ud943\udc19\ud832\udcb9\udb7a\ude44\ud8ae\uddd2\udb49\udc71\udbc1\udf61\udbd2\udc26\uda14\udd84\ud87c\udc7c\udaa2\ude6f\udaf0\udda7\ud83d\ude04",
        57, 82212, -1722136762, 4267214032193217077L, -78488L, true, false, (char) 25456, (char) 59979,
        Double.longBitsToDouble(0x3feb4c8ac339a2d7L), Double.longBitsToDouble(0x3fd573c33c2887daL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.String:\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\udb5b\udf85\uda26\udea7\ud80a\udd05\ud9cf\udc47\uda88\udf30\ud8f9\udcc2\ud81b\ude43\ud9f9\udd48\ud81d\udc73\ud960\uddb7\udb4c\uddfe\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 9, 4, 12, "\ud8bd\udee1\ud878\udd65\ud9df\ude79\ud8a9\udf97\uda0b\udc35\uda59\udc92\udb5b\udf85\uda26\udea7\ud80a\udd05\ud9cf\udc47\uda88\udf30\ud8f9\udcc2\ud81b\ude43\ud9f9\udd48\ud81d\udc73\ud960\uddb7\udb4c\uddfe", "\u633c\u08b8\u7100\u3777", "\udb6f\udf17\ud906\ude4d\udab5\udc73",
        54, 11818, 237962329, -5996829781103218369L, -74683L, true, false, (char) 42130, (char) 38379,
        Double.longBitsToDouble(0x3fdb7d3adc3d8280L), Double.longBitsToDouble(0x3fde4c78ee5eb2dcL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Byte:55 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.lang.StringIndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 6, 6, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\u0374\ua735\u511c\uaf81\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\ud8d5\ude6e\ud9b5\ude1a",
        55, 77853, 440500097, -6172712799639620507L, -96223L, true, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Byte:55 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Byte:55 |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 15, 15, 6, "\ud939\ude07\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\u0374\ua735\u511c\uaf81\u5c60", "\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\ud8d5\ude6e\ud9b5\ude1a",
        55, 77853, 440528001, -6172712799639620507L, -96223L, true, false, (char) 35695, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Byte:47 |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Byte:47 |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 14, 14, 14, "\ud8d5\udd43\ud800\udeb3\udb87\udc83\udbd8\udc76\udb9b\udc1c\udbdd\udc58\ud8be\udd31", "\u25a5\u09e7\uab9a\ua73b\ub4f4\uaf93", "\udb26\udfc4\ud881\udeab\ud92c\udeb1",
        47, 54223, 1965033573, 4062155392286455701L, 35997L, false, false, (char) 57019, (char) 56422,
        Double.longBitsToDouble(0x3fe6e0074a5c0e2fL), Double.longBitsToDouble(0x3fe92d6636b12e24L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.String:\ud9e7\ude5f\udab6\udf59\ud8ec\udcc8\udbd8\udc76\uda0b\udc62\ud969\udd1a\ud8c2\udf8d\udb24\udcbd\ud80a\udd05\uda95\udc11\uda88\udf30\ud8f9\udcc2\ud81b\ude43\uda39\udd57\ud91b\udf4f\uda50\udc95\ud909\udea0\udb26\udfc4\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21\ud81c\udda4\udb6f\udf17\ud855\ude4f\uda6e\udd5d\udbf8\ude3a\012",
        Z.run(T, 2, 8, 9, 14, "\ud9e7\ude5f\udab6\udf59\ud8ec\udcc8\udbd8\udc76\uda0b\udc62\ud969\udd1a\ud8c2\udf8d\udb24\udcbd\ud80a\udd05\uda95\udc11\uda88\udf30\ud8f9\udcc2\ud81b\ude43\uda39\udd57\ud91b\udf4f\uda50\udc95\ud909\udea0\udb26\udfc4\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21\ud81c\udda4\udb6f\udf17\ud855\ude4f\uda6e\udd5d\udbf8\ude3a", "\ua6a1\u36df\u65a7", "\uda3c\ude81\ud832\udcb9\ud8d1\ude70\uda69\udf11",
        13, 37342, -1457784226, 4822012509898024934L, -15080L, false, false, (char) 8669, (char) 26297,
        Double.longBitsToDouble(0x3febae7fdea3de17L), Double.longBitsToDouble(0x3fd09a41463501e4L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.String:\udb2d\udd9a\udb5e\udcaa\ud810\udc35\ud9a0\ude84\udb90\udfe3\uf9a4\uda7c\udf2b\0121=java.lang.Boolean:true |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 9, 12, 11, "\udb2d\udd9a\udb5e\udcaa\ud810\udc35\ud9a0\ude84\udb90\udfe3\uf9a4\uda7c\udf2b", "\u25a5\ua3e6", "\ud891\udc35\ud89c\udf73\uda36\udf11\u9cf5\udb26\udfc4\ud842\ude37\udb8f\ude51\uda1a\udf4d\uda41\ude32\u4768\ud9d2\udc21\udb98\udda2\ud915\udc29\ud80f\ude9c\uda6e\udd5d\ud9d8\udcea\udaa9\udfdf\ud972\udd7c\ud81f\udedd\ud840\udd00\ud988\udf3f",
        55, 95059, -1978801184, -1047094938634471170L, 7302L, true, false, (char) 32683, (char) 19398,
        Double.longBitsToDouble(0x3fed0179956f1f7dL), Double.longBitsToDouble(0x3fb756db486beca0L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.String:\udb2d\udd9a\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 9, 12, 0, "\udb2d\udd9a", "\u3c5b\000\000\u3db2\u67db\u7171\u25a5\ua3e6\uab9a<\u4b5d\u66be\u1ae5\uabfc\ub1ee\u3bf0", "\ud9f2\ude2a\u474c",
        50, 93037, -925384104, -6356879464435671446L, 33238L, false, false, (char) 10053, (char) 58669,
        Double.longBitsToDouble(0x3fec4094c0000087L), Double.longBitsToDouble(0x3e3f006f70000000L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:\udb2d\udd9a\udb5e\udcaa\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 9, 7, 11, "\udb2d\udd9a\udb5e\udcaa", "\u5cfa\u2d9d\u67ba\u22fb\ub835\u7137\ua401\uab9a\ua73b\uaa96\u66be\u1ae5\uabfc\ub1ee\u3bf0\u147f", "\u474c\ud9d2\udc21\udb98\udda2\u3366\ud80f\ude9c\uda6e\udd5d",
        42, 97954, 237979194, 6632985408778570017L, 95922L, false, true, (char) 61901, (char) 55980,
        Double.longBitsToDouble(0x3fe95b89a64d6bd4L), Double.longBitsToDouble(0x3fea8c63a9e7526eL)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=java.lang.String:\udb5e\ude71\udb5e\udcaa\ud810\udc35\ud9a0\ude84\udb90\udfe3\uda59\udc92\uda7c\udf39\ud9ed\uded5\ud804\uddd6\uda95\udc11\ud81b\udf59\ud91e\udd67\ud81b\ude43\ud891\udc35\ud93f\ude79\udb9e\udc1c\uda67\udc2c\udb26\udfc4\ud842\ude37\udb8f\ude51\uda1a\udf4d\ud9c6\ude34\u474c\ud9d2\udc21\udb98\udda2\udb6f\udf17\ud80f\ude9c\uda6e\udd5d\ud9d8\udcea\uda61\udf3b\udbfd\udf0f\udae1\ude82\uda14\ude39\ud988\udecc\0121=java.lang.Boolean:true |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 9, 12, 9, "\udb5e\ude71\udb5e\udcaa\ud810\udc35\ud9a0\ude84\udb90\udfe3\uda59\udc92\uda7c\udf39\ud9ed\uded5\ud804\uddd6\uda95\udc11\ud81b\udf59\ud91e\udd67\ud81b\ude43\ud891\udc35\ud93f\ude79\udb9e\udc1c\uda67\udc2c\udb26\udfc4\ud842\ude37\udb8f\ude51\uda1a\udf4d\ud9c6\ude34\u474c\ud9d2\udc21\udb98\udda2\udb6f\udf17\ud80f\ude9c\uda6e\udd5d\ud9d8\udcea\uda61\udf3b\udbfd\udf0f\udae1\ude82\uda14\ude39\ud988\udecc", "\u9d3b\u083c\uc3d0\u3bfc", "\ud866\udc61\ud998\udcce\udaee\ude12\u9804\udb18\udf2f\u4ab1\udacd\udf9b\ud9a3\ude38\u5f40\ud840\uddb9\ubfae\ud9ce\udd66\ud890\ude5d",
        59, 10708, 2066307597, -257223942529366342L, -87385L, true, false, (char) 1475, (char) 23577,
        Double.longBitsToDouble(0x3fb936823e818698L), Double.longBitsToDouble(0x3fda2cb35c805686L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.lang.String:\uda05\udf3b\udb5e\udd1e\ud931\udfa5\ud90f\ude98\udb81\udf30\uda59\udc92\ud989\udc2e\ud9ed\uded5\0121=java.lang.String:\uda05\udf3b\udb5e\udd1e\ud931\udfa5\ud90f\ude98\udb81\udf30\uda59\udc92\ud989\udc2e\ud9ed\uded5\012",
        Z.run(T, 2, 9, 9, 3, "\uda05\udf3b\udb5e\udd1e\ud931\udfa5\ud90f\ude98\udb81\udf30\uda59\udc92\ud989\udc2e\ud9ed\uded5", "\u2cfe\u1ab4\ud262\uaa96\u7056\u1b60", "\ud854\udec8\ud8e4\udc9a\ud894\udfec\udbd8\udd42\uda05\udf77",
        32, 30776, 982848975, -7882445522761971392L, -17613L, true, true, (char) 25651, (char) 58115,
        Double.longBitsToDouble(0x3fe122323559bd96L), Double.longBitsToDouble(0x3fedc10143e00deeL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.lang.String:\000\0121=java.lang.Boolean:true |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 9, 12, 11, "\000", "\u3c5b\uac6a\ua1d6\u3e84\u67db\u7171\u25a5\ua3e6\uab9a\ua73b\uaa96\u66be\u1ae5\000", "",
        13, 9533, -475434016, 8439754931577028815L, -84128L, true, true, (char) 50737, (char) 57019,
        Double.longBitsToDouble(0x3fec5627ce3afacdL), Double.longBitsToDouble(0x3fd160e2f242b81aL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 12, 12, 1, "\ud8c1\udc9e\udb5e\udcaa\ud810\udc35\ud9a0\ude84\udb90\udfe3\uda59\udc92\uda7c\udf39\ud9ed\uded5", "\ua3e6\uab9a\ua73b\uaa96\u65dd", "\uda95\udd0d\ud82d\udd9b\udb8f\ude51\ud9e5\udf27\ud908\udfb3\u4786",
        50, 93037, -925384104, -6350405539971326395L, 33238L, false, false, (char) 63255, (char) 58669,
        Double.longBitsToDouble(0x3fec4093eaaeb487L), Double.longBitsToDouble(0x3fedc0e92be00deeL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud89c\udc2c\ud911\udf20\udbd8\udc76\ud831\uddf6\uda59\udcd5\u8876\uda33\udfdf\uf685\uda95\udc11\uda88\udf30=\ub25a\uaf68\uc15a\u3ebd\u4ead\u8aa5\u620d\u08b8\u7100\u3b36\u6f9f\u18ac\u80f8\u99e1\u7900\u7e6f\u8393\uaf09\uc46d\ubca1\ud25d}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud89c\udc2c\ud911\udf20\udbd8\udc76\ud831\uddf6\uda59\udcd5\u8876\uda33\udfdf\uf685\uda95\udc11\uda88\udf30=[\ub25a\uaf68\uc15a\u3ebd\u4ead\u8aa5\u620d\u08b8\u7100\u3b36\u6f9f\u18ac\u80f8\u99e1\u7900\u7e6f\u8393\uaf09\uc46d\ubca1\ud25d, \ub25a\uaf68\uc15a\u3ebd\u4ead\u8aa5\u620d\u08b8\u7100\u3b36\u6f9f\u18ac\u80f8\u99e1\u7900\u7e6f\u8393\uaf09\uc46d\ubca1\ud25d]}\012",
        Z.run(T, 2, 3, 1, 1, "\ud905\ude0d\ud89c\udc2c\ud911\udf20\udbd8\udc76\ud831\uddf6\uda59\udcd5\u8876\uda33\udfdf\uf685\uda95\udc11\uda88\udf30", "\ub25a\uaf68\uc15a\u3ebd\u4ead\u8aa5\u620d\u08b8\u7100\u3b36\u6f9f\u18ac\u80f8\u99e1\u7900\u7e6f\u8393\uaf09\uc46d\ubca1\ud25d", "\uda3c\ude81\udac6\udcbc\uda89\udf14\uda25\udc61",
        14, 33281, -192421232, 3956514324878821490L, 99744L, false, false, (char) 59862, (char) 6923,
        Double.longBitsToDouble(0x3fdd9ad32cfc61b6L), Double.longBitsToDouble(0x3fc80d7e803667d0L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 1, 1, "\ud905\ude0d\ud838\ude2d\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d", "\u2ff7\uab9a\ua73b\u511c", "\u7eac\ud87b\udd8d\ud8d8\udf9e",
        -4, 87424, -475452754, 8439754932522822863L, -84216L, true, false, (char) 14646, (char) 57019,
        Double.longBitsToDouble(0x3fec5627ce3a1e67L), Double.longBitsToDouble(0x3fec28c17c27e990L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 1, 1, "\ud905\ude0d\ud838\ude2d\ud8ec\udd3f\udbd8\udc76\uda48\udca8\udbcc\ude91\uda21\udd1d\uda33\udf6d", "\ua3e6\uab9a\ua73b\u511c\uaf90\u5c60", "\ud8d8\udf9e\ud92c\udeb1\ud912\uddac\ud9b4\udceb\u474c\ud9d2\udc21",
        36, 77896, 440528067, -6172712799639620507L, 60765L, false, false, (char) 20055, (char) 58076,
        Double.longBitsToDouble(0x3fef05dc4004e8c5L), Double.longBitsToDouble(0x3fd4c8441ada20feL)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud838\ude2d\ud8ec\udd3f\udbd8\udc76\ud831\uddf6\uda59\udcd5\uda21\udd48\udaba\udd63=\ud5db\u46ac}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud838\ude2d\ud8ec\udd3f\udbd8\udc76\ud831\uddf6\uda59\udcd5\uda21\udd48\udaba\udd63=[\ud5db\u46ac, \ud5db\u46ac]}\012",
        Z.run(T, 2, 2, 1, 1, "\ud905\ude0d\ud838\ude2d\ud8ec\udd3f\udbd8\udc76\ud831\uddf6\uda59\udcd5\uda21\udd48\udaba\udd63", "\ud5db\u46ac", "\ud91b\udf4c\uda50\udc95\u7eac\ud87b\udd8d\udb12\udd79\ud92c\udeb6\ud912\ude37\ud9b4\udceb\u474c",
        50, 36221, 1490535000, 1899144235166604906L, -70773L, false, false, (char) 6114, (char) 35926,
        Double.longBitsToDouble(0x3fdb8e1f57c17710L), Double.longBitsToDouble(0x3f73a314a6422080L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\uda1d\udcd7\000\000\000\000\ud87e\udd00=9}\0121=java.lang.Byte:9 |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\uda1d\udcd7\000\000\000\000\ud87e\udd00=9}\012",
        Z.run(T, 2, 2, 13, 14, "\ud905\ude0d\ud878\udd65\uda1d\udcd7\000\000\000\000\ud87e\udd00", "9", "\000\000\uda16\ude4a\u7eac\udb26\udfc4\ud8d8\ude78\ud92c\udeb1\ud912\uddac\000\000\000\ud92c\ude16\uc258\ud855\ude4f",
        36, 2917, 510130058, 1022112855358439446L, -100000L, false, false, (char) 0, (char) 40911,
        Double.longBitsToDouble(0x3f73a314a6422080L), Double.longBitsToDouble(0x3fd6d107fee53c4aL)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\uddcf\ud878\udd65=\u34a9\ua1d6\u8087\u3059\u17b3\u25a5\ua3e6\uab9a\ua79e\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u889f\ua97d\uce57\ua7f3\ub652\u18ac\u80f8\u9703\u78e2\u6540\uca74\uaf09\u2073\u90c8\u65a7\ub11a\u32c0\u2a8f\ud625\u3cd9}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\uddcf\ud878\udd65=[\u34a9\ua1d6\u8087\u3059\u17b3\u25a5\ua3e6\uab9a\ua79e\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u889f\ua97d\uce57\ua7f3\ub652\u18ac\u80f8\u9703\u78e2\u6540\uca74\uaf09\u2073\u90c8\u65a7\ub11a\u32c0\u2a8f\ud625\u3cd9, \u34a9\ua1d6\u8087\u3059\u17b3\u25a5\ua3e6\uab9a\ua79e\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u889f\ua97d\uce57\ua7f3\ub652\u18ac\u80f8\u9703\u78e2\u6540\uca74\uaf09\u2073\u90c8\u65a7\ub11a\u32c0\u2a8f\ud625\u3cd9]}\012",
        Z.run(T, 2, 2, 1, 14, "\ud905\uddcf\ud878\udd65", "\u34a9\ua1d6\u8087\u3059\u17b3\u25a5\ua3e6\uab9a\ua79e\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u889f\ua97d\uce57\ua7f3\ub652\u18ac\u80f8\u9703\u78e2\u6540\uca74\uaf09\u2073\u90c8\u65a7\ub11a\u32c0\u2a8f\ud625\u3cd9", "\ud8c2\ude51\ud944\ude58\uda27\udfa4",
        18, 61274, -1243739223, -7040857801799901795L, 9808L, true, true, (char) 60408, (char) 49641,
        Double.longBitsToDouble(0x3fec14ba4178a81bL), Double.longBitsToDouble(0x3fd3844cfa3a4aa8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 6, 6, 14, "\ud905\ude0d\ud878\udd65\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\ud9a0\ude95\ud82e\udc65\ud8a2\udf4e", "\u281f\u1c98\ua73b\u511c", "\u7eac\udb26\udfc4\ud8d8\ude78",
        -4, 93432, -475452777, 8439754932522822863L, -84216L, true, false, (char) 3243, (char) 62669,
        Double.longBitsToDouble(0x3fec5627ce3a1e67L), Double.longBitsToDouble(0x3fe8b071797ba4c6L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.ExtendedProperties:{}\0121=null |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 12, 12, 14, "\ud88e\uddc1\ud887\uddfc\ud8ec\udd3f\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\uab9a\ua73b\u511c\uaf90\u983a", "\ud96f\udee3\ud9c1\udc7e\ud941\udd45\ud9b4\udceb\u474c\ud9d2\udc21\ud96a\uddab\udb6f\udf17\ud855\ude4f\uda6e\udd5d\ud9d8\udcea\udad4\udd54\udbfd\udf0f",
        -1, 82079, -1260368207, 2100320709758207416L, 88412L, false, true, (char) 38379, (char) 4831,
        Double.longBitsToDouble(0x3fef38facfd265c1L), Double.longBitsToDouble(0x3fc010cc7f1f02d4L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 11, 11, 15, "\ud905\ude34\uda2d\uddd6\ud8ec\udd3f\uda37\udf7f\ud876\udc37\udb19\udf0e\udb59\udf7f\udb94\udfd8", "\ua3e6\uab9a\u9143\u5140\uaeb0\u5849\u43a2\ub1ee", "\udaf6\uddc7\ud9e8\udd56\udad3\udf4c\ud9e0\udede\udbde\udd17\ud974\udc0d\ud855\ude4f\uda6e\uddd0\udbad\udd5e",
        17, 18711, -1058061006, 6454334189524860147L, 81688L, false, false, (char) 39394, (char) 48849,
        Double.longBitsToDouble(0x3fd6d107ffc70cd8L), Double.longBitsToDouble(0x3fbc67ad126dc0c0L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 7, 7, 7, "\ud9ed\udf63\ud877\udd24", "\u34a9\u2cd2\u8089\uab1c\u88a0\u25a5\u91d3\u4c69\u73d4\u511c\u2f6d\u5c60\u3ebd\ub1ee\ua469\u2ad2\u08b8\u978a\u2684\u5f9c\ubf7d\u4dd9\ua88b\ua5f6\u7e6f\u3ff8\ua182\ud230\u2b3f\u844f\u97d3\uac7a\u426c\u4c5c\u34fe", "\ud9b2\udf0c\udb52\udd5c\ud885\udecb\udbf5\udf8e\uda15\uddf5\ud859\ude49\ud8e7\udc0d\ud9ee\udeed\udbde\udf04\ud9ce\udea3",
        18, 46747, 957233490, 3258214441325218773L, 17648L, false, true, (char) 26344, (char) 40882,
        Double.longBitsToDouble(0x3fd55f0417ca2388L), Double.longBitsToDouble(0x3fc0926960166ed8L)));
  }
  @Test(timeout = 4000)
  public void test56() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65=\u2e47\ua1c8\u8091\u8da6\u88a0\u15a5\ua3e6\uab9a\ua73b\u511c\uaf90\ua838\u3ebd\ub1ee\u897f\u621a\u08b8\u7100\u3b36\u62a9\uc939\u9034\u876e\u755f\ubcd5\u833b\uaf09\uc90b\u4783\uc4a1\ub11a\u8492\u8858\ud559\u3cd9}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65=[\u2e47\ua1c8\u8091\u8da6\u88a0\u15a5\ua3e6\uab9a\ua73b\u511c\uaf90\ua838\u3ebd\ub1ee\u897f\u621a\u08b8\u7100\u3b36\u62a9\uc939\u9034\u876e\u755f\ubcd5\u833b\uaf09\uc90b\u4783\uc4a1\ub11a\u8492\u8858\ud559\u3cd9, \u2e47\ua1c8\u8091\u8da6\u88a0\u15a5\ua3e6\uab9a\ua73b\u511c\uaf90\ua838\u3ebd\ub1ee\u897f\u621a\u08b8\u7100\u3b36\u62a9\uc939\u9034\u876e\u755f\ubcd5\u833b\uaf09\uc90b\u4783\uc4a1\ub11a\u8492\u8858\ud559\u3cd9]}\012",
        Z.run(T, 2, 1, 1, 14, "\ud905\ude0d\ud878\udd65", "\u2e47\ua1c8\u8091\u8da6\u88a0\u15a5\ua3e6\uab9a\ua73b\u511c\uaf90\ua838\u3ebd\ub1ee\u897f\u621a\u08b8\u7100\u3b36\u62a9\uc939\u9034\u876e\u755f\ubcd5\u833b\uaf09\uc90b\u4783\uc4a1\ub11a\u8492\u8858\ud559\u3cd9", "\ud864\uddd7\uda6d\udfb1\uda1b\udd59\ud925\udd09\uda60\udcbf\ud8f4\udc86\udb0b\udfcb\uda62\udf88",
        41, 5761, 137787817, -5474010338686691225L, -28515L, true, true, (char) 44581, (char) 49929,
        Double.longBitsToDouble(0x3fe2a94c60728ae5L), Double.longBitsToDouble(0x3fd9b0764ee70036L)));
  }
  @Test(timeout = 4000)
  public void test57() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{}\012",
        Z.run(T, 2, 4, 4, 14, "\udbb6\udc87\ud857\udc07\uda61\udd6e\udb46\udf9a\ud8b6\udea9\uda59\udc92\uda21\udd48\uda26\udea7", "\u5ea5\u9c19\u2750\u8e0c\u9759\u5c60", "\ud89d\udf2c\ud983\udda4\uda86\udf9e\uda50\udcdf\ud9fe\udd65\ud9b8\udf85\ud96a\uddab\ud863\udf11\ud855\ude4f\udbb7\udcd7\ud8bf\ude24\ud9cc\udf9b\ud9ce\udc6c\ud99f\udd4d\udb81\udc00\udba5\udfba\udae6\udc46\ud876\udff9\ud9c4\ude3a\ud8b4\udd32\uda42\udfd0\ud99a\ude0f\ud8cb\udf44\udbdc\udf8c\udb43\udd26\udaf5\udc67\udae6\udce5\ud99c\uddce\udb7c\udc64\uda59\udeab\udaf6\udfa2\udb58\uddc4\u93d4\ufee7\udbe7\ude4a\ud967\udd87\ud997\udda4\ud89f\ude03\ud9ca\uddd0\ud9c1\ude1e\uda9a\udddd\ud8f8\ude29\ud817\udc06\udb5f\ude65\udb4c\udf85\udabf\udffb\ud82a\udc32\uda60\uddbf",
        20, 18106, 1357892912, -8003301989319335384L, 8635L, false, false, (char) 15594, (char) 38174,
        Double.longBitsToDouble(0x3fd2143f7c484d04L), Double.longBitsToDouble(0x3fd653a523d87ee0L)));
  }
  @Test(timeout = 4000)
  public void test58() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 8, 8, 14, "\udbee\udc8b\udb14\udcdf\ud98d\udfc6\udafd\udd17\uda36\udd53\udb02\ude78\ud951\udca2\ud961\udee9", "\u51df\ua058\ua73b\ub708\u5a2b", "\udb26\udfc4\ud8d8\ude78\ud92c\udeb1\ud912\uddac\ud80b\udf76\ud9e6\udea7\ud9d2\udc21\uda42\udf92\udb44\udf17\udba2\ude6d",
        23, 10835, -2054638394, 1022098332672013692L, 93460L, false, true, (char) 2250, (char) 42381,
        Double.longBitsToDouble(0x3fd6d107f621f1eeL), Double.longBitsToDouble(0x3fd2efb1061fd194L)));
  }
  @Test(timeout = 4000)
  public void test59() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 6, 6, 1, "\ud905\ude0d\udbda\ude2e\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d", "\u2ff7\uab9a\u169a\u510c", "\u7eac\ud87b\udd8d\ud8d8\udf9e\ud92c\udeb1\ud8a9\uddcc\ud9b4\udd02\u474c\ud9d2\udc21\ud96a\uddab\udb6f\udf17\ud855\ude4f\uda6e\udde8\ud9d8\udcea\udad4\udd54\udb6b\udfa6\ud9e5\ude32\uda29\udcaa\udab2\udcf7\udb02\udf1d\ud932\udfc5\udac6\udcd2\udbf8\ude61\ud8e8\udf87\ud848\ude50\ud931\ude48\ud82f\ude90\ud98e\udffb\udaf1\udfee\uda77\udc05\uda43\ude45\udbdd\udd5a\ud847\udd52\ud807\udfd9\udb4f\uddf2\ud9ff\udfee\udb2c\ude99\ud915\uddb5\ud985\ude4b\ud8c4\udd55\ud907\udc47\ud823\ude32\ud947\udf8d\udb18\udfa5\ud97b\udcc6\ud8b1\udd61\u6060\uda99\udf5b\udb21\ude12\ud871\udf1b\ud92c\udc16\ue5fb\ud977\ude0c\ud8f1\udf9a\u11a8\udbc4\udd53\ud9c1\udeed\udab7\udf09",
        9, -216, -1885659672, -8610102060926414557L, 78117L, true, false, (char) 16026, (char) 53681,
        Double.longBitsToDouble(0x3fe5562729767f52L), Double.longBitsToDouble(0x3fd9c03b47d3ee66L)));
  }
  @Test(timeout = 4000)
  public void test60() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 14, "\ud8c7\udcdf\ud86e\ude72\uda22\udd3a\udbd8\udc76\uda0b\udc62\uda59\udc92\uda21\udd48\uda26\udea7\uda7a\udd23\uda95\udc11\uda88\udf30\ud8f9\udcc2\ud81b\ude43\ud9f9\udd48\ud91b\udf4c", "\ub1ee\u897f\u08de\u3e43\u4c16\u4920\u6f9f\u18ac\u80f8\ubbe1\u00e3\u9c76\u032b", "\udbc3\udc01\uda78\ude43\udae6\udc46\ud820\uddaf\uda3c\ude81\ud832\udcb9\udb7a\ude44\udb47\udd7f",
        8, 40136, -1659825706, -7227929780773695367L, -94598L, true, true, (char) 19520, (char) 40610,
        Double.longBitsToDouble(0x3fcfc53af254e6c8L), Double.longBitsToDouble(0x3fe6203b6c5148cdL)));
  }
  @Test(timeout = 4000)
  public void test61() throws Throwable {
    assertEquals("0=java.lang.String:\udb5e\ude71\ud800\uddcb\udb9e\udc63\udb2a\udfdd\udb90\udfe3\udafc\udda0\ud94f\ude23\uda61\udebe\ud81d\uddf0\uda1b\udcd8\udbe1\udd99\uda36\udd1b\ud81b\ude43\ud891\udc35\ud93f\ude79\udb9e\udc1c\uda67\udc2c\udb26\udfc4\ud842\ude37\udb8f\ude51\uda1a\udf4d\ud9c6\ude34\u474c\ud9d2\udc21\udb98\udda2\udb6f\udf17\ud80f\ude9c\uda6e\udd5d\ud9d8\udcea\uda61\udf3b\udbfd\udf0f\udae1\ude82\uda14\ude39\ud988\udecc\0121=java.lang.String:\udb5e\ude71\ud800\uddcb\udb9e\udc63\udb2a\udfdd\udb90\udfe3\udafc\udda0\ud94f\ude23\uda61\udebe\ud81d\uddf0\uda1b\udcd8\udbe1\udd99\uda36\udd1b\ud81b\ude43\ud891\udc35\ud93f\ude79\udb9e\udc1c\uda67\udc2c\udb26\udfc4\ud842\ude37\udb8f\ude51\uda1a\udf4d\ud9c6\ude34\u474c\ud9d2\udc21\udb98\udda2\udb6f\udf17\ud80f\ude9c\uda6e\udd5d\ud9d8\udcea\uda61\udf3b\udbfd\udf0f\udae1\ude82\uda14\ude39\ud988\udecc\012",
        Z.run(T, 2, 9, 9, 9, "\udb5e\ude71\ud800\uddcb\udb9e\udc63\udb2a\udfdd\udb90\udfe3\udafc\udda0\ud94f\ude23\uda61\udebe\ud81d\uddf0\uda1b\udcd8\udbe1\udd99\uda36\udd1b\ud81b\ude43\ud891\udc35\ud93f\ude79\udb9e\udc1c\uda67\udc2c\udb26\udfc4\ud842\ude37\udb8f\ude51\uda1a\udf4d\ud9c6\ude34\u474c\ud9d2\udc21\udb98\udda2\udb6f\udf17\ud80f\ude9c\uda6e\udd5d\ud9d8\udcea\uda61\udf3b\udbfd\udf0f\udae1\ude82\uda14\ude39\ud988\udecc", "\u9d3b\u1fc3\uc3d0\u3bfc", "\udbde\udd9d\ud8a4\udfb0\udaee\ude12\u703c\udb18\udf2f\u4ab1\udacd\udf9b\ud9a3\ude38\u5f40\ud840\uddb9\ubfae\ucf7b\ud81e\udd91",
        59, 10708, 2066307597, -257223942529366342L, -87432L, true, false, (char) 1475, (char) 59417,
        Double.longBitsToDouble(0x3fb936823e818698L), Double.longBitsToDouble(0x3fda2cb35c805686L)));
  }
  @Test(timeout = 4000)
  public void test62() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\015\ua796\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u620d\u08b8\u7100\u3b36\u6f9f\u03a3\u80c4\ub055\u9af4}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\015\ua796\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u620d\u08b8\u7100\u3b36\u6f9f\u03a3\u80c4\ub055\u9af4", "\ud967\udf84\ud9af\uded7\udbc3\udc01",
        5, 77044, -272712520, -1718347070663745532L, 65229L, true, true, (char) 26007, (char) 55398,
        Double.longBitsToDouble(0x3fe85ac178a4bdcdL), Double.longBitsToDouble(0x3fd8b6f264406fa8L)));
  }
  @Test(timeout = 4000)
  public void test63() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 6, 6, 1, "\ud905\ude48\ud844\ude2d\u9c7d\ud8a3\udc0b\ud945\udd9f\uda7b\udcd9\uda21\udd48\uda33\udf6d", "\uc7f6\uab9a\ua73b\u511c", "\u7ee5\ud87b\udd8d\udb17\udd32",
        -4, 87424, -475452754, 8439754932522822863L, -84216L, true, false, (char) 14646, (char) 57019,
        Double.longBitsToDouble(0x3fd8ac4f91813ce4L), Double.longBitsToDouble(0x3fd56ca48723783aL)));
  }
  @Test(timeout = 4000)
  public void test64() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\u2c54\u65b7\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u620d\u08b8\u7100\u3b36\u6f9f\u03a3\u80c4\ub055\u9af4}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\u2c54\u65b7\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u620d\u08b8\u7100\u3b36\u6f9f\u03a3\u80c4\ub055\u9af4", "\ud967\udf84\ud9af\uded7\udbc3\udc01",
        5, 77044, -272712520, -1718347070663745532L, 65277L, true, false, (char) 26007, (char) 55398,
        Double.longBitsToDouble(0x3fe85ac178a4bdcdL), Double.longBitsToDouble(0x3fe8b099322037eeL)));
  }
  @Test(timeout = 4000)
  public void test65() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\015\ua796\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u620d\u08b8\u7100\u3b36\ubff7\u03a3\u80c4\ub055\u9af4}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud8bd\udee1\ud8fd\udc66\ud9df\ude60\ud8a9\udf97\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\015\ua796\u511c\uaf90\u5c60\u3ebd\ub1ee\u897f\u620d\u08b8\u7100\u3b36\ubff7\u03a3\u80c4\ub055\u9af4", "\ud967\udf84\ud9af\uded7\udbc3\udc01",
        5, 77044, -272712520, -1718347070663745532L, 65229L, true, true, (char) 26007, (char) 55398,
        Double.longBitsToDouble(0x3fe85ac2e0a4bdcdL), Double.longBitsToDouble(0x3fd8b6f264406fa8L)));
  }
  @Test(timeout = 4000)
  public void test66() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc44\ud9df\ude60\ud8a9\udf97\uda0b\udc35\ud955\udfd0\udbf0\udff9\udb90\udd09=\u2691\u8d7c\ua796\u511c\uaf90\u3585\uad68\ub1ee\uc866\u6244\u08b8\u273d\u3b36\uab79\u03a3\u80c4}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc44\ud9df\ude60\ud8a9\udf97\uda0b\udc35\ud955\udfd0\udbf0\udff9\udb90\udd09=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud8bd\udee1\ud8fd\udc44\ud9df\ude60\ud8a9\udf97\uda0b\udc35\ud955\udfd0\udbf0\udff9\udb90\udd09", "\u2691\u8d7c\ua796\u511c\uaf90\u3585\uad68\ub1ee\uc866\u6244\u08b8\u273d\u3b36\uab79\u03a3\u80c4", "\ud850\udef2\ud95c\udce7\ud884\ude00\ud9b0\uddc5\udbc3\udc01\ud9cf\udf19\ud82f\udf0b\ud9fa\udc02\ud8be\udf0a\ud832\udcb9\ud9eb\udeb9\udaa8\ude89\ud917\uded3\ud8c2\uddc2\ud97a\udd5d\ud926\udf24",
        40, 87096, 718432800, 145827914872980096L, -13264L, true, true, (char) 42251, (char) 9568,
        Double.longBitsToDouble(0x3fe93611ecdb9ba8L), Double.longBitsToDouble(0x3fde3ade5d0395caL)));
  }
  @Test(timeout = 4000)
  public void test67() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\udbff\ude19\ud9ba\udc15\ud8e0\ude9c\ud8dd\udfab\uda59\udc92\uda21\udd48\uda26\udea7=\ua3e6\015\ua796\u511c\uaf90\ua606\u3e25\ub1ee\u897f\u620d\u5e2a\u5600\u9814\u40cc\u03a3\u80c4\ub055\u9af4}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\udbff\ude19\ud9ba\udc15\ud8e0\ude9c\ud8dd\udfab\uda59\udc92\uda21\udd48\uda26\udea7=false}\012",
        Z.run(T, 2, 3, 10, 1, "\ud8bd\udee1\udbff\ude19\ud9ba\udc15\ud8e0\ude9c\ud8dd\udfab\uda59\udc92\uda21\udd48\uda26\udea7", "\ua3e6\015\ua796\u511c\uaf90\ua606\u3e25\ub1ee\u897f\u620d\u5e2a\u5600\u9814\u40cc\u03a3\u80c4\ub055\u9af4", "\udb00\uddd0\ud9af\uded7\udbc3\udc91",
        25, 68002, -272712520, -1718347070663745532L, 65229L, true, true, (char) 26007, (char) 55398,
        Double.longBitsToDouble(0x3fe85ac178a4bdcdL), Double.longBitsToDouble(0x3fd8b6f264406fa8L)));
  }
  @Test(timeout = 4000)
  public void test68() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=\u3b36\u6f9f\u03a3\u34f2\ub8f7\u28dc\u997f\ud7e4\ud279\u211c\u90c8\u8cc3\uc9da\u0974\u4897\ud5fc\uc155\u3392\ua0ac\u56d1}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9", "\u3b36\u6f9f\u03a3\u34f2\ub8f7\u28dc\u997f\ud7e4\ud279\u211c\u90c8\u8cc3\uc9da\u0974\u4897\ud5fc\uc155\u3392\ua0ac\u56d1", "\udb8c\uddc4",
        5, 19352, -1096453499, 1367748292035191588L, -80030L, false, true, (char) 50888, (char) 3431,
        Double.longBitsToDouble(0x3fccd3c0d2b46ce8L), Double.longBitsToDouble(0x3fd7e52f08ed516aL)));
  }
  @Test(timeout = 4000)
  public void test69() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud91e\udd9e\ud8a9\udfde\udb55\udd9b\uda59\udc92\uda21\udd48\uda26\udea7=\ua488\u2c54\u65b7\u511c\uaf90\u653b\u07ac\u9016\u8962\u624d\u08b8\u31a0\ub205\ucc9e\u03a3\u80c4\ub055\ucaef}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud91e\udd9e\ud8a9\udfde\udb55\udd9b\uda59\udc92\uda21\udd48\uda26\udea7=false}\012",
        Z.run(T, 2, 3, 10, 5, "\ud8bd\udee1\ud8fd\udc66\ud91e\udd9e\ud8a9\udfde\udb55\udd9b\uda59\udc92\uda21\udd48\uda26\udea7", "\ua488\u2c54\u65b7\u511c\uaf90\u653b\u07ac\u9016\u8962\u624d\u08b8\u31a0\ub205\ucc9e\u03a3\u80c4\ub055\ucaef", "\ud967\udf84\ud9af\uded7\udbc3\udc01",
        5, 77044, -1165968200, -1683567039681060860L, 65277L, true, false, (char) 26007, (char) 61073,
        Double.longBitsToDouble(0x3fe85f12e0a4bdcdL), Double.longBitsToDouble(0x3fe8b099322037eeL)));
  }
  @Test(timeout = 4000)
  public void test70() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud90e\ude44\ud9df\ude60\ud8a9\udf97\uda0b\udc35\ud955\udfd0\uda9c\uddf3\udb90\udd09=\u2691\u8d7c\ua796\u511c\uaf90\u32f2\uad68\ub1ee\uc866\u6244\u08b8\u273d\ua924\uab79\u03a3\ud542}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud90e\ude44\ud9df\ude60\ud8a9\udf97\uda0b\udc35\ud955\udfd0\uda9c\uddf3\udb90\udd09=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud8bd\udee1\ud90e\ude44\ud9df\ude60\ud8a9\udf97\uda0b\udc35\ud955\udfd0\uda9c\uddf3\udb90\udd09", "\u2691\u8d7c\ua796\u511c\uaf90\u32f2\uad68\ub1ee\uc866\u6244\u08b8\u273d\ua924\uab79\u03a3\ud542", "\ud850\udef2\ud95c\udce7\ud884\ude00\ud9b0\uddc5\udbc3\udc01\ud9cf\udf19\ud82f\udf0b\ud9fa\udc02\ud934\udfe5\ud848\udc12\uda9b\udc86\udac6\ude13\ud917\uded3\ud8c2\uddc2\ud97a\udd5d\ud926\udf24",
        40, 87096, 718432800, 145827913582117504L, -13264L, true, true, (char) 42251, (char) 9568,
        Double.longBitsToDouble(0x3fe93611ecdb9ba8L), Double.longBitsToDouble(0x3fde3ade5d0395caL)));
  }
  @Test(timeout = 4000)
  public void test71() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\u48e1\uda26\ude75\ud895\udc58\ud8ec\ude9c'\000\udb94\udf0a\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=\u3b36\u00cf\u03a3\u34f2\ub8f7\u28dc\u997f\u73dc\000\u211c\u90c8\u8cc3\uc9da\u0974\u4897\ud5fc\uc155\u3392\ua0ac\u56d1}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\u48e1\uda26\ude75\ud895\udc58\ud8ec\ude9c'\000\udb94\udf0a\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\u48e1\uda26\ude75\ud895\udc58\ud8ec\ude9c'\000\udb94\udf0a\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9", "\u3b36\u00cf\u03a3\u34f2\ub8f7\u28dc\u997f\u73dc\000\u211c\u90c8\u8cc3\uc9da\u0974\u4897\ud5fc\uc155\u3392\ua0ac\u56d1", "\udb8c\uddc4",
        42, 93184, -1096453499, 1367748292035191588L, -80030L, false, true, (char) 50888, (char) 3431,
        Double.longBitsToDouble(0x3fccd3c0d2b46ce8L), Double.longBitsToDouble(0x3fd7e52f08ed516aL)));
  }
  @Test(timeout = 4000)
  public void test72() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\udb1a\udc7c\ud806\udd74\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\ud8fb\udc46\u56aa\udbec\udddb\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9\ud93f\udcf8=\u6f9f\u03a3\u34f2\u9891\u28dc}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\udb1a\udc7c\ud806\udd74\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\ud8fb\udc46\u56aa\udbec\udddb\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9\ud93f\udcf8=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\udb1a\udc7c\ud806\udd74\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\ud8fb\udc46\u56aa\udbec\udddb\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9\ud93f\udcf8", "\u6f9f\u03a3\u34f2\u9891\u28dc", "\ud87b\udc41\ue11f\udb2c\udd88\ud8e8\ude91\uda0e\ude69\ud892\ude59\udbc8\udf1b\ud832\udd5c\ud91d\udc15",
        -3, 60127, -1948186510, 6354381912635457547L, 50294L, false, false, (char) 48440, (char) 45407,
        Double.longBitsToDouble(0x3fe92097d94330e7L), Double.longBitsToDouble(0x3fdfea6d637051beL)));
  }
  @Test(timeout = 4000)
  public void test73() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud927\udc52\u7238\udbc7\udc86=\u03a3\u34f2\ub8f7\u28dc}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud927\udc52\u7238\udbc7\udc86=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\uda21\udd48\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud927\udc52\u7238\udbc7\udc86", "\u03a3\u34f2\ub8f7\u28dc", "\uc569\ud9af\uded7\udbc3\udc01\ud9cf\udf6f\uda5c\udd40\udb04\udfc2\udbc8\udf1b\ud832\udd5c\ud939\udd15",
        -3, 60127, -1948186510, 6354381732815527179L, 50294L, false, false, (char) 1337, (char) 63096,
        Double.longBitsToDouble(0x3fe92097d94330e7L), Double.longBitsToDouble(0x3fdfea6d637051beL)));
  }
  @Test(timeout = 4000)
  public void test74() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud91e\udd9e\ud8a9\udfde\udb55\udd9b\uda59\udc92\uda21\udd48\udb54\udd84=\ua488\u2c54\u65b7\u511c\uaf90\u653b\u07ac\u9016\u8962\u624d\u08b8\u31a0\ub205\ucc9e\u03a3\u4d25\uacd3\ucaef}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud8bd\udee1\ud8fd\udc66\ud91e\udd9e\ud8a9\udfde\udb55\udd9b\uda59\udc92\uda21\udd48\udb54\udd84=false}\012",
        Z.run(T, 2, 3, 10, 5, "\ud8bd\udee1\ud8fd\udc66\ud91e\udd9e\ud8a9\udfde\udb55\udd9b\uda59\udc92\uda21\udd48\udb54\udd84", "\ua488\u2c54\u65b7\u511c\uaf90\u653b\u07ac\u9016\u8962\u624d\u08b8\u31a0\ub205\ucc9e\u03a3\u4d25\uacd3\ucaef", "\ud967\udf84\ud9af\uded7\udbc3\udc01",
        5, 77044, -1165968200, -1683567039681060860L, 65277L, true, false, (char) 26007, (char) 61073,
        Double.longBitsToDouble(0x3fe85f12e0a4bdcdL), Double.longBitsToDouble(0x3fe8b099322037eeL)));
  }
  @Test(timeout = 4000)
  public void test75() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\u48e1\udbf8\ude1d\ud895\udc58\ud8ec\ude9c'\000\udb94\udf0a\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=\u3b36\u00cf\u03a3\u34f2\ub8f7}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\u48e1\udbf8\ude1d\ud895\udc58\ud8ec\ude9c'\000\udb94\udf0a\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=false}\012",
        Z.run(T, 2, 3, 10, 2, "\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\uda59\udc92\u48e1\udbf8\ude1d\ud895\udc58\ud8ec\ude9c'\000\udb94\udf0a\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9", "\u3b36\u00cf\u03a3\u34f2\ub8f7", "\u73dc",
        -5, 78431, 786166079, -8872004744269342016L, -27316L, true, false, (char) 39580, (char) 46308,
        Double.longBitsToDouble(0x3fe23ab030725d25L), Double.longBitsToDouble(0x3fc0b17c202d60bcL)));
  }
  @Test(timeout = 4000)
  public void test76() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udab8\udeda\ud8a4\udefa\uda07\ude35=\u8da6\u22b0\u2eaf\u170a\u5418\u64a3\ucd41\uaf9d\ub5a3\uc81c\u416b\ucc44\u05e6\ud7ea\u488a\ub190\uc0aa\u03a3\uc034}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udab8\udeda\ud8a4\udefa\uda07\ude35=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud927\uddd0\ud920\udf2e\udab8\udeda\ud8a4\udefa\uda07\ude35", "\u8da6\u22b0\u2eaf\u170a\u5418\u64a3\ucd41\uaf9d\ub5a3\uc81c\u416b\ucc44\u05e6\ud7ea\u488a\ub190\uc0aa\u03a3\uc034", "\ud8c2\ude92\u1fda\udae8\udea1\ud9af\uded7\udbc3\udc01\ud9cf\udf6f\udb9b\udcf1\uc8b6\udbe8\udfd9\ud832\udd5c\ud96b\udfc6\ud9c7\udf17\ud8d7\udfc4\ud852\udd9a\ud97a\uddb7\ud923\udc24\udb8c\uddc4\ud8b6\ude4f\ud9ff\udd6c",
        36, -285, 820486948, -6424744120297737730L, -11538L, false, true, (char) 24300, (char) 34791,
        Double.longBitsToDouble(0x3fd7e52f04707494L), Double.longBitsToDouble(0x3fefcb74e075f06bL)));
  }
  @Test(timeout = 4000)
  public void test77() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udab8\udeda\ud8a4\udefa\uda07\ude35=\u8da6\u22b0\u2eaf\u170a\u5418\u64a3\ucd41\uaf9d\ub5a3\u9443\u6edc\ucc44\u05e6\ud7ea\u488a\ub190\uc0aa\u03a3\uc034}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udab8\udeda\ud8a4\udefa\uda07\ude35=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud927\uddd0\ud920\udf2e\udab8\udeda\ud8a4\udefa\uda07\ude35", "\u8da6\u22b0\u2eaf\u170a\u5418\u64a3\ucd41\uaf9d\ub5a3\u9443\u6edc\ucc44\u05e6\ud7ea\u488a\ub190\uc0aa\u03a3\uc034", "\ud8c2\ude92\u1fda\udae8\udea1\ud9af\uded7\udbc3\udc01\ud9cf\udf6f\udb9b\udcf1\uc8b6\udbe8\udfd9\ud832\udd5c\ud96b\udfc6\ud9c7\udf17\ud8d7\udfc4\ud852\udd9a\ud97a\uddb7\ud923\udc24\ud8fa\udf7f\ud8b0\udc00\ud9ff\udd6c",
        36, -285, 820486948, -6424744120297737730L, -11538L, false, true, (char) 24300, (char) 51855,
        Double.longBitsToDouble(0x3fd7e52f04707494L), Double.longBitsToDouble(0x3fefcb74e075f06bL)));
  }
  @Test(timeout = 4000)
  public void test78() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\ud8b8\udeda\ud8a4\udefa\uda07\ude35=\u8da6\u22b0\u2eaf\u170a\u5418\u64a3\ucd41\uaf9d\u571e\ub329\u416b\ucc44\u05e6\ud7ea\u488a\ub190\uc0aa\u03a3\u9fc0}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\ud8b8\udeda\ud8a4\udefa\uda07\ude35=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud927\uddd0\ud920\udf2e\ud8b8\udeda\ud8a4\udefa\uda07\ude35", "\u8da6\u22b0\u2eaf\u170a\u5418\u64a3\ucd41\uaf9d\u571e\ub329\u416b\ucc44\u05e6\ud7ea\u488a\ub190\uc0aa\u03a3\u9fc0", "\ud8c2\ude92\u1fda\udae8\udea1\ud9af\uded7\udbc3\udc01\ud9cf\udf6f\udb9b\udcf1\uc8b6\udbe8\udfd9\ud832\udd5c\ud96b\udfc6\ud9c7\udf17\ud8d7\udfc4\ud852\udd9a\ud97a\uddb7\ud923\udc24\udb8c\uddc4\ud8b6\ude4f\ud9ff\udd6c",
        36, -285, 820486948, -6424744120297737730L, -11538L, false, true, (char) 24300, (char) 13544,
        Double.longBitsToDouble(0x3fd7e52f04707494L), Double.longBitsToDouble(0x3fefcb74e075f06bL)));
  }
  @Test(timeout = 4000)
  public void test79() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\udb21\udc2e\udac1\ude4e\uda1c\udf36\udbeb\udf9c\uda0f\udd45\uda13\udc98\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=\u3b36\u6f9f\u03a3\u34f2\u03a3\u68be\u997f\ud7e4\ud279\u211c\u90c8\u8cc3\uc9da\u0974\u4897\ud5fc\uc155\u3392\ua0ac\u56d1}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\udb21\udc2e\udac1\ude4e\uda1c\udf36\udbeb\udf9c\uda0f\udd45\uda13\udc98\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=false}\012",
        Z.run(T, 2, 3, 10, 3, "\ud927\uddd0\udb21\udc2e\udac1\ude4e\uda1c\udf36\udbeb\udf9c\uda0f\udd45\uda13\udc98\uda26\udea7\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9", "\u3b36\u6f9f\u03a3\u34f2\u03a3\u68be\u997f\ud7e4\ud279\u211c\u90c8\u8cc3\uc9da\u0974\u4897\ud5fc\uc155\u3392\ua0ac\u56d1", "\udb8c\uddc4\udb2b\ude61\ue3af\u9eab\ud94c\udcf1\udb2d\ude05\udb6b\udc01",
        29, 59992, -2086839872, 7829685841595908326L, -28962L, false, false, (char) 1934, (char) 25012,
        Double.longBitsToDouble(0x3fe0952770c16ea1L), Double.longBitsToDouble(0x3fc51ff0b87d84e0L)));
  }
  @Test(timeout = 4000)
  public void test80() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\udb0a\udeb1\ud8b4\udd7e\ud9ea\uddd1\uda59\ude84\uda0b\udcad\ud874\ude8d=\u6039\uab9a\ua73b\u511c\uaf90\ua838\u3ebd\ub1ee\u897f\u621a\u08b8\u7100\u3b36\u62a9\uc939\uad89\u84f4\ucdea\ucdb5t\uaf09\u2073\u7523\u6504\ub11a\u8492\u8858\ud559\u3cd9\u1e14\u06d6\u3623\ubbe6\u42e4\u82c1\u84d6\uabff\u4ab3\u04a2\ud46b\u1d2d\u1780\u2f35\u14bd\ua2d9\u63a6\u432b\u6083\u46ad\u7219\u022b\u5394\u348b\uc1a8\uab76\u16f6\ua77c\u8060\u736b\u9920\u9df4q\u2f46\u2e09\u92ae}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud878\udd65\udb0a\udeb1\ud8b4\udd7e\ud9ea\uddd1\uda59\ude84\uda0b\udcad\ud874\ude8d=[\u6039\uab9a\ua73b\u511c\uaf90\ua838\u3ebd\ub1ee\u897f\u621a\u08b8\u7100\u3b36\u62a9\uc939\uad89\u84f4\ucdea\ucdb5t\uaf09\u2073\u7523\u6504\ub11a\u8492\u8858\ud559\u3cd9\u1e14\u06d6\u3623\ubbe6\u42e4\u82c1\u84d6\uabff\u4ab3\u04a2\ud46b\u1d2d\u1780\u2f35\u14bd\ua2d9\u63a6\u432b\u6083\u46ad\u7219\u022b\u5394\u348b\uc1a8\uab76\u16f6\ua77c\u8060\u736b\u9920\u9df4q\u2f46\u2e09\u92ae, \u6039\uab9a\ua73b\u511c\uaf90\ua838\u3ebd\ub1ee\u897f\u621a\u08b8\u7100\u3b36\u62a9\uc939\uad89\u84f4\ucdea\ucdb5t\uaf09\u2073\u7523\u6504\ub11a\u8492\u8858\ud559\u3cd9\u1e14\u06d6\u3623\ubbe6\u42e4\u82c1\u84d6\uabff\u4ab3\u04a2\ud46b\u1d2d\u1780\u2f35\u14bd\ua2d9\u63a6\u432b\u6083\u46ad\u7219\u022b\u5394\u348b\uc1a8\uab76\u16f6\ua77c\u8060\u736b\u9920\u9df4q\u2f46\u2e09\u92ae]}\012",
        Z.run(T, 2, 1, 1, 14, "\ud905\ude0d\ud878\udd65\udb0a\udeb1\ud8b4\udd7e\ud9ea\uddd1\uda59\ude84\uda0b\udcad\ud874\ude8d", "\u6039\uab9a\ua73b\u511c\uaf90\ua838\u3ebd\ub1ee\u897f\u621a\u08b8\u7100\u3b36\u62a9\uc939\uad89\u84f4\ucdea\ucdb5t\uaf09\u2073\u7523\u6504\ub11a\u8492\u8858\ud559\u3cd9\u1e14\u06d6\u3623\ubbe6\u42e4\u82c1\u84d6\uabff\u4ab3\u04a2\ud46b\u1d2d\u1780\u2f35\u14bd\ua2d9\u63a6\u432b\u6083\u46ad\u7219\u022b\u5394\u348b\uc1a8\uab76\u16f6\ua77c\u8060\u736b\u9920\u9df4q\u2f46\u2e09\u92ae", "\ud8ba\uddc3\ud86e\udd22\uda05\udc3a\ud81c\uddf9\ud86f\udc9e\ud8af\udf15\ud857\uddd6\udb95\udc9a\uda75\udc8c\ud800\udf00\ud83b\udfc4\ud902\ude7e\udaf3\udebb\uda88\uded8",
        41, 70825, 632272057, -6026059480653710650L, 52103L, true, false, (char) 42279, (char) 33001,
        Double.longBitsToDouble(0x3fee7e0df076f5bcL), Double.longBitsToDouble(0x3fefbd6cc9db374dL)));
  }
  @Test(timeout = 4000)
  public void test81() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\ud8d0\udc4d\ud9f7\udca1\uda26\udeee\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=\u3b36\u1e42\u03a3\u34f2\ub8f7\u4ab6\u442a\ud7e4\ud279\u211c\ub101\u8cae\uc9da\u6f7b\u03f6\ud5fc\u0a15\u8c82\ua0ac\u56d1}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.ExtendedProperties:{\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\ud8d0\udc4d\ud9f7\udca1\uda26\udeee\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9=false}\012",
        Z.run(T, 2, 3, 10, 14, "\ud927\uddd0\ud920\udf2e\udac1\ude4e\ud8a4\udefa\uda0b\udc35\ud8d0\udc4d\ud9f7\udca1\uda26\udeee\ud895\udc58\ud8ec\ude9c\u2f5c\udb77\udc62\udbc4\udf60\udbec\udd82\ud942\udde0\uda50\udcc5\ud964\udd07\ud845\udd15\udbfc\ude4a\ud877\udeb9", "\u3b36\u1e42\u03a3\u34f2\ub8f7\u4ab6\u442a\ud7e4\ud279\u211c\ub101\u8cae\uc9da\u6f7b\u03f6\ud5fc\u0a15\u8c82\ua0ac\u56d1", "\udb8c\uddc4",
        5, 19352, -1096453499, 1367748292035191588L, -80030L, false, true, (char) 50888, (char) 3431,
        Double.longBitsToDouble(0x3fccd3c0d2b46ce8L), Double.longBitsToDouble(0x3fd7e52f08ed516aL)));
  }
  @Test(timeout = 4000)
  public void test82() throws Throwable {
    assertEquals("0=java.lang.Integer:1\012",
        Z.run(T, 1, 6, 0, 14, "\uf78a\ud878\udd65\uda1d\udcd7\ud896\udc21\uda1b\udfac\uda59\udc92\000\ud9ea\udd75", "\ua4a5\u6b4f\ua1e9\u9946\u243f\u19ed\u2986\ub1ee\u897f\u3b40\000\u4669\u0865\000\000\ud6a4\ubb1e\u0ed0\u7e6f\u008a\u64f9\u3928\u3cb8\u65a7\ub11a\u8492\u8858\u8b56\ua372\u1314\u2e64\u5d3b", "\ud8f4\udf5c\ud984\udf8a\ud955\udce2\ud982\udda8",
        12, 44181, 957960102, -1164555281609511268L, -79426L, false, false, (char) 0, (char) 60433,
        Double.longBitsToDouble(0x3fdf9c39bbbcd19aL), Double.longBitsToDouble(0x3f449f2000000000L)));
  }
  @Test(timeout = 4000)
  public void test83() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud838\ude2d\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d=[\u2ff7\u43ec, \u511c]}\012",
        Z.run(T, 2, 6, 1, 1, "\ud905\ude0d\ud838\ude2d\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d", "\u2ff7\u43ec,\u511c", "\ud80b\ude22\ud87b\udd8d\ud8d8\udf9e",
        -4, 44744, -1464546819, 8439754962587593935L, -84216L, true, false, (char) 5942, (char) 676,
        Double.longBitsToDouble(0x3fee5e27ce3a1e67L), Double.longBitsToDouble(0x3fec28c17c27e990L)));
  }
  @Test(timeout = 4000)
  public void test84() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud874\ude66\u56be\udb98\udf34\udbfd\udc3b\ud9e5\udfef\uda59\udcd5\uda21\udd48\uda33\udf6d=\u3087\u43ec}\012",
        Z.run(T, 2, 6, 1, 1, "\ud874\ude66\u56be\udb98\udf34\udbfd\udc3b\ud9e5\udfef\uda59\udcd5\uda21\udd48\uda33\udf6d", "\u3087\u43ec,", "\ud981\uddec\ud80b\ude22\udbbf\udf6f\ud8e5\udeb7\ud90e\udd06\uba0e\udb83\udef6\ud9dd\udcf8\ud9cd\udd59\ud931\udd21\udb6f\udf17\ud96f\ude7c",
        1, 42999, 510130123, 1742688795361290117L, -40330L, true, true, (char) 26767, (char) 57979,
        Double.longBitsToDouble(0x3fe26dd33234371cL), Double.longBitsToDouble(0x3fe44b3d43270dfaL)));
  }
  @Test(timeout = 4000)
  public void test85() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\udb6e\uddf5\ud9f4\uddd3\udbfd\udcc3\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d=\u2ff7\u43ec,\u511c}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\udb6e\uddf5\ud9f4\uddd3\udbfd\udcc3\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d=[\u2ff7\u43ec,\u511c, \u2ff7\u43ec, \u511c]}\012",
        Z.run(T, 2, 3, 1, 1, "\ud905\ude0d\udb6e\uddf5\ud9f4\uddd3\udbfd\udcc3\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d", "\u2ff7\u43ec,\u511c", "\udb02\udfb8\ud850\udfe9\ud8d8\udf9e\u786a\uda41\udd38\u9cd8\u4753\udaa1\udd89\u121a",
        26, 66067, 833486069, -4253138613289093173L, -89883L, true, false, (char) 40484, (char) 55251,
        Double.longBitsToDouble(0x3fea26e11d6fe9abL), Double.longBitsToDouble(0x3fe39f4bfb4fa018L)));
  }
  @Test(timeout = 4000)
  public void test86() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud838\ude2d\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d=[\u2ff7\u43ec, \u511c]}\0121=void |this=org.apache.commons.collections.ExtendedProperties:{\ud905\ude0d\ud838\ude2d\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d=[\u2ff7\u43ec, \u511c, \u2ff7\u43ec, \u511c]}\012",
        Z.run(T, 2, 1, 1, 1, "\ud905\ude0d\ud838\ude2d\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda59\udcd5\uda21\udd48\uda33\udf6d", "\u2ff7\u43ec,\u511c", "\ud80b\ude22\ud87b\udd8d\ud8d8\udf9e",
        -4, 44744, -1464546819, 8439754962587593935L, -84216L, true, false, (char) 5942, (char) 676,
        Double.longBitsToDouble(0x3fee5e27ce3a1e67L), Double.longBitsToDouble(0x3fe428c17c27e990L)));
  }
  @Test(timeout = 4000)
  public void test87() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud9cf\udc99\ud838\ude88\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda45\uddcf\uda21\udd48\uda33\udf6d=[\u2ff7\u43ec, \u511c]}\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 14, 1, "\ud9cf\udc99\ud838\ude88\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda45\uddcf\uda21\udd48\uda33\udf6d", "\u2ff7\u43ec,\u511c", "\ud80b\ude22\ud87b\udd8d\ud8d8\udf9e",
        -4, 44744, -1464546819, -4223416850754589644L, -84216L, true, false, (char) 5942, (char) 676,
        Double.longBitsToDouble(0x3fb25fcc0158f128L), Double.longBitsToDouble(0x3fe42a9d7c27e990L)));
  }
  @Test(timeout = 4000)
  public void test88() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.ExtendedProperties:{\ud9cf\udc99\ud838\ude88\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda45\uddcf\uda21\udd48\ud8b7\udfdf=[\u2ff7\u4b59, \u4f3b]}\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 11, 7, "\ud9cf\udc99\ud838\ude88\udb98\udf34\udbfd\udc3b\ud831\uddf6\uda45\uddcf\uda21\udd48\ud8b7\udfdf", "\u2ff7\u4b59,\u4f3b", "\ud845\ude00\ud931\udf1e\u4b5b\udabf\udd91\ud83a\udfb4\ud942\udcf1\udbf6\udf4d\ud9d1\udf86\ud954\uddab\udb6f\udf17\ud855\ude4f\ud9db\udfe2\udb74\udc75\udb13\ude0f",
        -1, 38037, 235768871, -8533260282027983262L, 57556L, false, true, (char) 5022, (char) 34677,
        Double.longBitsToDouble(0x3fd62389a4987b70L), Double.longBitsToDouble(0x3fbffd25f3119310L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.ExtendedProperties|combine|org.apache.commons.collections.ExtendedProperties|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|addProperty|java.lang.String,java.lang.Object|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|addPropertyDirect|java.lang.String,java.lang.Object|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|addPropertyInternal|java.lang.String,java.lang.Object|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|clearProperty|java.lang.String|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|convertProperties|java.util.Properties|static",
    "M|org.apache.commons.collections.ExtendedProperties|countPreceding|java.lang.String,int,char|static",
    "M|org.apache.commons.collections.ExtendedProperties|display||new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|endsWithSlash|java.lang.String|static",
    "M|org.apache.commons.collections.ExtendedProperties|escape|java.lang.String|static",
    "M|org.apache.commons.collections.ExtendedProperties|getBoolean|java.lang.String|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getBoolean|java.lang.String,boolean|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getBoolean|java.lang.String,java.lang.Boolean|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getByte|java.lang.String|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getByte|java.lang.String,byte|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|getByte|java.lang.String,java.lang.Byte|new:org.apache.commons.collections.ExtendedProperties:",
    "M|org.apache.commons.collections.ExtendedProperties|combine|org.apache.commons.collections.ExtendedProperties|new:org.apache.commons.collections.ExtendedProperties:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
