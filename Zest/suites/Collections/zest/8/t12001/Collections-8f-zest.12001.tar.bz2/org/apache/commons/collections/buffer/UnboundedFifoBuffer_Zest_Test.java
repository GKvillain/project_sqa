package org.apache.commons.collections.buffer;
import org.junit.Test;
import static org.junit.Assert.*;
public class UnboundedFifoBuffer_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 6, 4, 1, "\udade\udd02\ud803\ude76", "\u98d8\u43b8\u5d64\ucfa3", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\ud8e8\udf30\ud8c3\udef0\udb57\udf53\ud864\udf13\ud9d8\udcb4\udadd\udfb5\udb8b\udf09\uda61\udfad\udabd\udfaa\udbf7\udcab",
        28, 12051, -298582288, 4893250210299372967L, -21845L, false, false, (char) 51307, (char) 47815,
        Double.longBitsToDouble(0x3fd99c13fac05a16L), Double.longBitsToDouble(0x3fefae0459c821beL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 6, 4, 0, "\udade\udd02\ud803\ude76", "\u98d8\u43b8\u5d64\ucfa3", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud872\udf68\ud8e8\udf30\ud8c3\udef0\udb57\udf53\ud864\udf13\ud9d8\udcb4\udadd\udfb5\udb8b\udf09\uda61\udfad\udabd\udfaa\udbf7\udcab",
        28, 12051, -298632428, 4893250210299372967L, -21845L, false, false, (char) 51307, (char) 47815,
        Double.longBitsToDouble(0x3fd99c13fac05a16L), Double.longBitsToDouble(0x3fefae0459c821beL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 6, 12, 6, "\udade\udd02\ud803\ude76", "\u986b\u43b8\u5d64\ucfa3", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\ud89e\uddd9\ud998\udf83\uda24\udc37\ud8b0\udcdb\ud8e5\udc9c",
        9, 62887, 827541547, 1908082740796820600L, 76883L, false, true, (char) 41129, (char) 56226,
        Double.longBitsToDouble(0x3febfe7cb1b473bbL), Double.longBitsToDouble(0x3fb98ab5d1416228L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\ud838\udfd9\ud8f4\udf10]\012",
        Z.run(T, 1, 2, 6, 1, "\ud838\udfd9\ud8f4\udf10", "\ua7f1\u1451\u6fde", "\u7b2f\udaa0\udeab\ufcb0",
        51, 23297, 1300043544, 708809323858850426L, -81559L, false, false, (char) 22196, (char) 27588,
        Double.longBitsToDouble(0x3fd6d7afce29e106L), Double.longBitsToDouble(0x3fe9298a9d71b7cdL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Integer:27 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 3, 7, 1, "\udade\udd02\ud803\ude76", "\u98d8/\000\ucfa3", "\udaa0\udeab\ufcb0\u00bd\ud922\udeeb\ud955\udf1f\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\ud8e8\udf30\ud8c3\udef0\udb57\udf53\ud864\udf13\ud9d8\udcb4\udadd\udfb5\udb8b\udf09\000\udabd\udf8a\udbf7\udcab",
        28, -1000, -298647552, 4893250210299372967L, -87381L, false, false, (char) 51307, (char) 47815,
        Double.longBitsToDouble(0x3fd99c13fac05a16L), Double.longBitsToDouble(0x3fceb811632086f8L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 5, 0, "\ud975\ude28\udabb\ude26", "\u06fb\u7270\u5cdc\ucfa3", "\udb10\ude08\ufcd1\udb9a\udd33\ud90b\udf80\ua3a9\ud97c\udeac\uda71\udc03\uda49\udd60\ud889\udcf5\udb94\udc37\ud977\udc9c\ud8c3\ude94\udb57\udf53\ud864\udf13\ud9d8\udcb4\udb69\uddbb\udbaa\udd10\udb2c\udc49\udabd\udfaa\ud88b\ude96",
        56, 73115, 1257937078, 9010098519515588007L, -21845L, false, false, (char) 51307, (char) 29639,
        Double.longBitsToDouble(0x3feedc7d75602d0bL), Double.longBitsToDouble(0x3fefae0459c821beL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 11, 4, 1, "\udade\udd02\uda9f\udd84", "\u98d8\u43b8\u5d64\ucfa3\ua8c4\u9f79\u6856\u7c51\u43db\u4bb0\u0ae4\u75cc\u7166\u7e59\u9597\u4708\u925a", "\ud864\udf13\ud9d8\udcb4\udadd\udfb5\udbb8\udf83\uda61\udfad\udabd\udfaa\udbf7\udcab\udba8\udf18\uda59\ude44\ud9e7\udde3\ud9d7\udd24\ud9ef\ude01\uacf1\uda49\udf29\ud84b\udfa9\uda55\udfca\udae5\ude26\uda27\udc40\uda88\udda2\ud823\uddf2\ud95f\udecb\ud830\udc6e\uda9f\udc09\ud98b\ude82\ud9b2\udea9\udbdc\udf87\udbfd\udca9\ud90c\udd96\ud8a7\udfa5\ud973\udc02\ud945\udd4f\udbf4\udc50\udbf1\uddd9\ud9f1\ude35\uda5b\udf52\udb43\ude95\ud9b9\udfaa\udac9\udd2a\ud81a\udf13\ud959\uddea\uda9f\udd47\udbb2\ude8f\ud8a7\udccf\ud974\uddc4\udb47\udd3b\ud849\udf1b\ud935\udf2e\u51b2\ud9cd\uddf0\udab1\udf1a\udb09\ude3a\udaff\udedd\ud886\ude66\udbf5\udc2a",
        42, 8224, -1588262895, 2646368938976448188L, -77253L, true, true, (char) 34486, (char) 20550,
        Double.longBitsToDouble(0x3fe60f29e5632943L), Double.longBitsToDouble(0x3fae85b6a54bfe80L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 11, 4, 1, "\uda54\udc69\ud803\ude76", "\u7595\u43b8\u9222\ucfa3", "\udaa0\udeab\ud85d\udcbf\uda91\ude68\ud90b\udf80\u1718\000\uda54\udd89\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\ud8e8\udf30\000\000\000\ud9d8\udcb4\udadd\udfb5\udb91\udf8d\000\000\000",
        -5, 57192, -298582288, 4893250210299372967L, -21845L, false, false, (char) 51307, (char) 47815,
        Double.longBitsToDouble(0x3fd99c13fac05a16L), Double.longBitsToDouble(0x3ec1672086f80000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.apache.commons.collections.BufferUnderflowException\012",
        Z.run(T, 1, 8, 4, 1, "\udade\udd02\ud803\ude76", "\u98d8\u43b8\u5d64\ucfa3", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\udad1\udf95\ud8c9\uded6\ud8c3\udf25\udb57\udf53\ud864\udf13\ud9d8\udcb4\udb5e\udcd3\udb8b\udf09\uda61\udfad\udabd\udfaa\udbf7\udcab",
        28, 12051, -298582288, 4893250210299372967L, -21845L, false, false, (char) 51307, (char) 47815,
        Double.longBitsToDouble(0x3fd99c13fac05a16L), Double.longBitsToDouble(0x3fefae0459c821beL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Integer:10 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 5, 2, 6, "\udade\udd02\ud803\ude76", "\u1d90\u43b8\u5d5e\u910a", "\ud95f\udfea\ufcb0\udb9a\udd33\ud9a7\udd93\ucbce\uda4c\udec4\udb2a\udffd\udab3\uddbf\ud8c4\udd9d\ud879\udf0a\udbf8\udf7e\ud8c3\udef0\udb57\udf53\ud864\udf13\ud9d8\udcb4\udb5d\udcd1\udb8b\udf60\uda61\udfad\ud83a\udead\udbf7\udcab",
        9, 64215, -298582288, 2825575213905732892L, -21845L, false, false, (char) 51307, (char) 47815,
        Double.longBitsToDouble(0x3fd4aaf3f6f72216L), Double.longBitsToDouble(0x3fefae0459c821beL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.collections.buffer.UnboundedFifoBuffer$1:@? |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 7, 1, 1, "\uda25\udf05", "\ub25f\u7067\u59db\u5d64\ucfa3\ua8c4\u9f79\u34c8\u7c51\u43db\u96f2\u9b4b\u8961\u0af9\ua058\u9597\u4708\u925a\ud3f8\u53bc\ucaa0\ub287\ubcc9\u3eaa\u092a\u6d93\u4901\u5e68\u7362\u29d8\u01a0\u4cc3\u215e\u1e72\u6cb0", "\udaab\udcce\uda88\udda2\ud92e\udd9f\ud9e4\udea3\ud9ba\udf9b\u5ddf\u8666\ud8ed\udd2c\ud8d4\ude2d\ud9ff\udfaa\ud837\udd53\ud9fe\udc43\ud8f1\udd56\ufee8\ud96c\udf11\ud985\udea0\ud82a\udc05\udb9a\udda4\uda55\udf51\udad4\udda8\udb53\udfde",
        11, 36352, 589473509, 3395225957491469346L, 91717L, false, true, (char) 47344, (char) 36161,
        Double.longBitsToDouble(0x3fe4dbf5478838ecL), Double.longBitsToDouble(0x3fec2366ab5929c2L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.apache.commons.collections.BufferUnderflowException\012",
        Z.run(T, 1, 4, 6, 8, "\ud994\udce3\ud8ff\ude7a\ud93c\udc70\udbae\udf2a\ud8ff\udc35\uda0e\ude53\udaf8\udf20\udb5e\udeda\ud9ad\ude4d\u7b91\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\udacb\udce7\uda91\udd46\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\ud8e8\udf30\ud8c3\udef0\udb57\udf53\ud864\udf13\ud9d1\uddff\udadd\udfb5\udb8b\udf09", "\u0eb7\u5e68", "\ud808\udebe\uda93\udf0c\udadd\udc33\udac5\udef8\ud918\udded\uda46\udc96\ud90e\udf86\uda27\udc40\uda88\udda2",
        28, 23840, -2108500530, -6946161481741829644L, -72234L, true, true, (char) 40967, (char) 17172,
        Double.longBitsToDouble(0x3fbd9339934c4900L), Double.longBitsToDouble(0x3fe8de5f03471d0eL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\udb04\udf23\ud803\ude76]\0121=java.lang.String:\udb04\udf23\ud803\ude76 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\udb04\udf23\ud803\ude76]\012",
        Z.run(T, 2, 2, 4, 7, "\udb04\udf23\ud803\ude76", "\ud744\u588c\uc07d\u6b08", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\uda2d\udc12\ud8c3\udef0\udb57\udf53\ud864\udf13\ud9d8\udcb4\udadd\udfb5\udb8b\udf09\uda61\udfad\udabd\udfaa\udbf7\udcab",
        31, 12051, 1967396848, -7920340480264044186L, -9790L, true, false, (char) 51272, (char) 17475,
        Double.longBitsToDouble(0x3fe8cdce3a604391L), Double.longBitsToDouble(0x3fefae0458c821beL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.Integer:16 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\udade\udd02\ud803\ude76\ud93c\udc70]\012",
        Z.run(T, 2, 3, 2, 4, "\udade\udd02\ud803\ude76\ud93c\udc70", "\u0c36\ud216\u2ae7\u245d\u9f79\u34c8\u7c51\u43db\u96f2\u0aef\u75cc\u7166\u7e59\u3690\u4708\u925a\u9d6c\u1f3f", "\udadd\udfb5\udb8b\udf09\uda61\udfad\udabd\udfaa\udbf7\udcab\udba8\udf18\uda59\ude44",
        17, 17596, 100656551, 6558014649174405451L, 79700L, true, false, (char) 7049, (char) 14955,
        Double.longBitsToDouble(0x3fefae0459c8e3beL), Double.longBitsToDouble(0x3fbb76d0b7414b80L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 5, 5, 3, "\udade\udd02\ud803\ude76", "\ucf9b\u43b8\u5d64\u01cc", "\udaa0\udeab\ufcb0\udb9a\udd33\ud9be\ude83\ud9ae\uddd9\u8a1e\uda71\udc03\udbc2\udf7c\ud8c4\ude6a\ud85f\udcde",
        36, 95909, -492816113, 3554263880894635813L, 29146L, true, false, (char) 27038, (char) 41129,
        Double.longBitsToDouble(0x3fad1bb4a3374960L), Double.longBitsToDouble(0x3fe785ea5039ee33L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 4, 1, "\udade\udd02\ud803\ude76", "\u98d8\u43b8\u5d64w", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\ud9e2\udf2d\ud8c3\udef0\udb57\udf53\ud864\udf13\ud9d8\udcb4\udadd\udfb5\udb8b\udf09\uda61\udfad\udabd\udfaa\udbf7\udcab",
        28, -1000, 0, 4893160995238700455L, -21845L, false, false, (char) 51307, (char) 60302,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fefae0001c821beL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=!org.apache.commons.collections.BufferUnderflowException\012",
        Z.run(T, 2, 6, 4, 1, "\udade\udd02\ud803\ude76", "\u98d8\u43b8\u5d64\ucfa3", "\udaa0\udeab\ufcb0\udb9a\udcc3\ud90b\udf80\ua3a9\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud9f1\udf46\ud819\udde4\ud9cc\udc1d\ud912\udd31\udb70\ude48\ue490\udae7\udea0\udb8b\udf09\uda61\udfad\udabd\udfaa\udbf7\udcab",
        28, 12051, -299415241, 4893250210299372967L, -21845L, false, false, (char) 1906, (char) 52633,
        Double.longBitsToDouble(0x3fcb2aeeb583d5bcL), Double.longBitsToDouble(0x3fefae0459c821beL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 10, 12, 6, "\udbf0\udfb9\ud843\ude76", "\u986b\u43b8\u5d64\ucfa3", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\ud893\udd1b\ud998\udf83\uda24\udc37\ud8b0\udcdb\ud96d\udc60",
        7, 62887, 827541547, 1908082740796820600L, 76799L, false, true, (char) 41129, (char) 56226,
        Double.longBitsToDouble(0x3febfe7cb1b473bbL), Double.longBitsToDouble(0x3fb98ab5d1416228L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 12, 6, "\udade\udd02\ud803\ude76", "\u0daf\u43b8\u5d64\ucfa3", "\udaa0\ude95\ufcca\udb9a\udd33\ud90b\udf80\ua3a9\udbfe\udece\ud89e\uddd9\ud998\udf83\uda24\udc37\udaea\uddd7\ud8e6\ude77",
        51, 62887, -1373739682, -4763234922685035492L, -90812L, true, false, (char) 27453, (char) 41267,
        Double.longBitsToDouble(0x3febfe78f1b473bbL), Double.longBitsToDouble(0x3fb98ab5d1416228L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Integer:5 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 12, 12, "\udade\udd02\ud803\ude76\ud93c\udc70\ud9f1\udc3b\ud8fe\udfc8\uda0e\ude53\udaf8\udf20\udb5e\udeda\uda33\udce6\ud801\udc31\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\ud89e\uddd9\ud998\udf83", "\uacb8\ud3f8\u6e3e\ucaa0\u4e87\u4e8a\u3eaa\u092a", "\uda74\udd5f\u9251\udb42\ude41\udb9f\udf01\udbe4\udf1c\udb16\udebe\ud933\udfe1\udb95\ude9b\udb9f\udd88\udafc\udca5\ud97c\udf10\udabe\udf24\ud909\uddf3\udb45\udc7b",
        6, 5807, 1726712075, 5177056312337441032L, 50553L, true, true, (char) 6249, (char) 10266,
        Double.longBitsToDouble(0x3fc3ed421d7a3848L), Double.longBitsToDouble(0x3fe64f114ab89d62L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 9, 6, "\udade\udd02\ud803\ude76", "\u986b\u43b8\u5d64\ucfa3", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\ud89e\uddd9\ud998\udf83\uda24\udc37\ud8b0\udcdb\ud8e5\udc9c",
        9, 62887, 827541547, 1908082740796820600L, 76883L, false, true, (char) 41129, (char) 39486,
        Double.longBitsToDouble(0x3febe3ef11b473bbL), Double.longBitsToDouble(0x3fb98ab5d1416228L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Integer:32 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 3, 10, 0, "\ud8dd\udffe\ud8f4\udf10\uda65\udf99\uda1e\udf51\ud817\udf35", "\u363b\u3c54\u578e\u480b\u06ef\ub269\u5256\u84b3\uaf39\u7172\ub7e3\u7b38", "\u457b\ud8ae\udcfb",
        0, 3589, -1053893614, 7758536552802549911L, -22650L, false, true, (char) 30516, (char) 11063,
        Double.longBitsToDouble(0x3fd9b9d462eefe68L), Double.longBitsToDouble(0x3fd41d4989ab82ccL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\ud9b1\udd5e\udbd4\udcb1]\0121=new org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 2, 11, 3, "\ud9b1\udd5e\udbd4\udcb1", "\ua7f1\u8e7f\u6fde", "\ud947\udea0\ud845\udf06\ufcb0\ud90b\udeeb\ud909\udf43\ua3a9\udbfb\udd2e\uda6d\udf03\ud81c\ude29\ud865\udecc\udbf5\udd20\uda79\uddd4\ud877\udce0\ud89d\udd4d\udb11\udea5\udb11\udc63\udb2d\udd41\uda04\udfab\ud824\udd3b\ud85c\udf4d\uda50\udc13\ud8ff\udff5\uda5b\ude19",
        35, 15421, -1958414643, 5893513876852907180L, 77124L, false, true, (char) 62871, (char) 54775,
        Double.longBitsToDouble(0x3fd6b54eab2a1236L), Double.longBitsToDouble(0x3fe10a6c8168cee0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Integer:29 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=java.lang.Integer:29 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 5, 5, 4, "\uda0e\uddef\ud95d\ude5c\ud896\udfd2\udbd4\udf5c\udac2\udfb7\udb1b\udfbc\ud8dd\uddd3\udb6c\udea9\udb11\udfb8\udb2a\ude5c\ud92f\udcff\uda5f\udf7f\ud940\udd26\ud813\udfa4\ud865\udf30\ud86c\udf8c\ud9cb\udec3\uda73\ude86\ud91a\udcfa\ud928\udd93\ud977\udc21\ud8de\udc94\udb1d\udc1f\ud864\udf7d\ud9d8\udcb4", "\u17f2\uba24", "\udaa9\udc2a\uda09\ude7e\ud9dc\udd85\ud951\udd72\ud981\udd8e\uda77\uddff\udbea\udf74\ud9a9\udf38\ud9e4\udd9a\uda1a\ude82\uda88\udda2",
        28, 63000, -2039553304, 5220306253564958130L, -47425L, true, true, (char) 41201, (char) 24406,
        Double.longBitsToDouble(0x3fdb5517e51df230L), Double.longBitsToDouble(0x3fad50092ba85980L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=!org.apache.commons.collections.BufferUnderflowException\012",
        Z.run(T, 2, 6, 8, 0, "\ud975\ude28\udabb\ude26", "\u06fb\u7270\u5cdc\ucfa3", "\udb10\ude08\ud977\udd0d\ud937\udfe3\ud90b\udea3\ua3a9\ud97c\udeac\uda71\udc03\uda49\udd60\ud889\udcf5\udb94\udc37\ud977\udc9c\ud8c3\ude94\udb57\udf53\ud864\udf13\ud9d8\udcb4\udb69\uddbb\udbaa\udd10\udb2c\udc49\udabd\udfaa\ud88b\ude96",
        56, 73115, 1257937078, 9010098519515588007L, -21845L, false, false, (char) 51307, (char) 29639,
        Double.longBitsToDouble(0x3feedc7d75602d0bL), Double.longBitsToDouble(0x3fefae0459c821beL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:29 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=new org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 3, 10, 1, "\ud8a7\udf65\uda75\ude49", "\u56dc\u442d\u0f90", "\ud84d\udf65\ud80c\udd40",
        30, 11233, -220645713, 56305571201834240L, 53383L, true, false, (char) 61234, (char) 22196,
        Double.longBitsToDouble(0x3fb4da0e400002b8L), Double.longBitsToDouble(0x3fc4e0001c940000L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.Integer:10 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=new org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 5, 11, 4, "\udb04\udf23\ud803\ude76\ud93c\udc70\udbc9\udcb6\uda0d\udfbd\ud87d\udd99\ud99b\ude3b\udbb7\udf41\ud918\udc39", "\u7c51\u43db\u9df2\u0aef", "\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\udb3f\udc1b",
        9, 62887, 827541547, 1908082743095299192L, -587L, false, false, (char) 5270, (char) 56226,
        Double.longBitsToDouble(0x3fe19ba457f0bd4aL), Double.longBitsToDouble(0x3fb31d510b3490a8L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=new org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=new org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 10, 11, 7, "\udb04\udf23\ud803\ude76", "\ud744\u588c\uc07d\u6b08\ua8c4\u9f79\u34c8\u7c51\u1fc0", "\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\uda2d\udc12\ud893\udca9\udb57\udf9b\ud864\udf13\ud9d8\udcb4\udadd\udfb5\udb8b\udf09",
        56, 80688, 929675602, 8397705023081601587L, -14932L, true, true, (char) 45533, (char) 19010,
        Double.longBitsToDouble(0x3fe1f92b55d10a78L), Double.longBitsToDouble(0x3fdb4f68e633738eL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\ud907\udf0d\ud803\ude76]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\ud907\udf0d\ud803\ude76, \ud907\udf0d\ud803\ude76]\012",
        Z.run(T, 2, 2, 2, 7, "\ud907\udf0d\ud803\ude76", "\ud744\u588c\uc07d\u6b08", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\uda2d\udc12\ud8c3\udef0\udb57\udf53\ud864\udf13\ud927\udcb9\udadd\udfb5\udb8b\udf09\udb54\udc38\udabd\udfaa\udbf7\udcab",
        31, 12051, 1967396848, -7920340480264044186L, -9790L, true, false, (char) 51272, (char) 17475,
        Double.longBitsToDouble(0x3fe8cdce3a604391L), Double.longBitsToDouble(0x3fefae0458c821beL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\udb04\udef4\ud803\ude76]\0121=java.lang.String:\udb04\udef4\ud803\ude76 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 2, 8, 1, "\udb04\udef4\ud803\ude76", "\ud744\u588c\ubab8\u6b08", "\udaa0\udeab\ufcb0\udb9a\udd33\ud90b\udf80\ua3a9\uda4c\udeb4\uda71\udc03\udbc2\udf7c\ud8c4\udd81\ud879\udf0a\ud9a9\udef7\ud854\udcd0\udb57\udf53\ud864\udf13\ud9d8\udcb4\udadd\udfb5\udb8b\udf09\uda61\udfad\udabd\udfaa\udbf7\udcab",
        31, 12051, 1967427192, -7920340480264044186L, -11326L, true, false, (char) 51272, (char) 17475,
        Double.longBitsToDouble(0x3fe8cdce3a604391L), Double.longBitsToDouble(0x3fefae0458586535L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.apache.commons.collections.buffer.UnboundedFifoBuffer$1:@? |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=org.apache.commons.collections.buffer.UnboundedFifoBuffer$1:@? |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 7, 7, 7, "\udac7\udd24\udbfb\udc6f", "\u0470\u907c\u6f03\u7bd3\u6a4f\ub1d7\u2038\u7c51\u4937\u6c75\u0aef\u75cc\u7166\u7e59\u9597\u4708\ubc21\ud3f8\u6e3e\ucaa0\u4e87\ubcc2\u3e50\u092a\u63cc\u0315\u2e5a\uc93c\u9772\ub205", "\udb17\ude26\udbf4\udedc\uda13\udd42\udb2e\ude99\ud945\udf14\udac1\udea2",
        28, 82849, 1281766606, 4223301451343568077L, -72884L, true, true, (char) 50111, (char) 31518,
        Double.longBitsToDouble(0x3fc0a9d980ac8484L), Double.longBitsToDouble(0x3fdf920c943d3d90L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=java.lang.Integer:0 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 5, 5, 3, "\udbe7\udcd8", "\u7f41\ucf9b\u43b8", "\ud949\udd9b",
        34, 45527, -5497675, -1877523044637548063L, 93073L, false, false, (char) 58860, (char) 37513,
        Double.longBitsToDouble(0x3fefe0c78777873dL), Double.longBitsToDouble(0x3fc2a7e5e43c9ff0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 2, 10, "\udade\udd02\ud800\udeb4", "\u291a", "\udb5e\udeda\ud955\uddb5\ud97f\ude0a\udaa0\ude95\ufcca\udb9a\udd33\ud90b\udf80\ua3a9\udbfe\udece\ud89e\uddd9\ud998\udf83\uda24\udc37\udaea\uddd7\ud8e6\ude77\udba8\udf0b\udb57\udf53\udab2\udc8a\udada\udf2d\ucd44\udbab\ude1b\udaac\udf75",
        8, 34418, -820106189, 8339535658604818868L, 93064L, false, true, (char) 51688, (char) 51521,
        Double.longBitsToDouble(0x3fb3da841bca9090L), Double.longBitsToDouble(0x3fe27c2b99960fbaL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[\ud9a1\udf55\u2586]\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 2, 11, 3, "\ud9a1\udf55\u2586", "\ua7f1\u8e7f\u6fde", "\udbad\udeb2\ud845\udf41\ufcb0\ud90b\udeeb\ud909\udf43\ua3a9\udbfb\udd2e\uda6d\udf03\ud81c\ude29\ud86b\udecf\udbf5\udd20\uda79\uddd4\udacc\udfe8\ud89d\udcbe\udb11\udeac\udb11\udc63\udb0d\ude41\uda04\udfab\ud824\udd3b\ud85c\udf4d\uda50\udc13\udba0\udd36\udb33\udf09",
        -5, 93271, -1958450483, 5893513876852907180L, 77124L, false, true, (char) 9880, (char) 54770,
        Double.longBitsToDouble(0x3fe9f7a7c595091bL), Double.longBitsToDouble(0x3fa0a6c8204b65f0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Integer:13 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 1, 3, 4, 7, "\ud8e9\udec8\udad3\udd94\ud93b\udfe8\udbae\udf2a", "\u5d64\ucfa3\ua8c4\u8ed3\u9fc4\u7c85\u2b31\u1b41\u8f3b\u62d5\u9ef4\uc525\u569f\u4708\u61d7\u1268", "\ud9a1\udc6c",
        14, 87485, -924372487, -1782901945813845656L, 86931L, true, false, (char) 16217, (char) 10639,
        Double.longBitsToDouble(0x3feca02ff94b5b02L), Double.longBitsToDouble(0x3fb236f66fa053c0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.lang.Integer:3 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=java.lang.Integer:3 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 3, 3, 7, "\ud911\uded9\uc190\ud866\udde5\ud80a\ude6b\ud903\ude63\ud9eb\uddeb\ud809\ude94\udb42\udf20\udad7\udc2f\ud9ee\ude63\uda53\udf78\udbb6\ude64\udb97\udcbe\ud887\udd35\udab0\udf6c\uda4c\udeee\uda71\udc03", "\u4708\u7e7c\u4225\u013f\ucaa0", "\udac3\udf77\ud8f8\udce5",
        4, 50053, 1955243066, -5959711246319669605L, -58063L, false, true, (char) 12910, (char) 50234,
        Double.longBitsToDouble(0x3fea100bc6be3a7bL), Double.longBitsToDouble(0x3fedd2f9d8604391L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Integer:32 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\0121=java.lang.Integer:32 |this=org.apache.commons.collections.buffer.UnboundedFifoBuffer:[]\012",
        Z.run(T, 2, 3, 3, 10, "\ud911\uded9\uc190\ud866\udde5\ud80a\ude6b\ud903\ude63\ud9eb\uddeb\ud809\ude94\udb42\udf20\udad6\udf9e\udb17\ude58\uda53\udf78\udbb6\ude64\udb97\udcbe\ud887\udd35\udab0\udf6c\uda4c\udeee\uda71\udc03", "\u4708\u91a5\u4225\u013f\u6209", "\udac3\udf77\ud8f8\udce5\u2ec8\udbe3\udc50\ud8a8\udf18\ud8b7\udd53\udb0d\udf7c\ud938\ude30\ud93b\udfc1\udadf\udcca\udac9\udef2\ud89b\udc08\ud9ff\udeb0\udae1\udc5a\ud945\udfb5\ud9fb\udff7\ud8a2\udf14\ud8e2\udf3f",
        -4, 68520, 818928694, 535696286128184009L, 24057L, false, false, (char) 48931, (char) 55984,
        Double.longBitsToDouble(0x3fa127b1a4ab10f0L), Double.longBitsToDouble(0x3fe8096f3d6542adL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|readObject|java.io.ObjectInputStream|new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|writeObject|java.io.ObjectOutputStream|new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|add|java.lang.Object|new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|decrement|int|new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|get||new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|increment|int|new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|isEmpty||new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|iterator||new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|remove||new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|size||new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "C|org.apache.commons.collections.buffer.UnboundedFifoBuffer|<init>|",
    "C|org.apache.commons.collections.buffer.UnboundedFifoBuffer|<init>|int",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|readObject|java.io.ObjectInputStream|new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
    "M|org.apache.commons.collections.buffer.UnboundedFifoBuffer|writeObject|java.io.ObjectOutputStream|new:org.apache.commons.collections.buffer.UnboundedFifoBuffer:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
