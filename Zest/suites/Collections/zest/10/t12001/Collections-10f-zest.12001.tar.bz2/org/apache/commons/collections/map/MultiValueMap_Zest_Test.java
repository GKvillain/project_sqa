package org.apache.commons.collections.map;
import org.junit.Test;
import static org.junit.Assert.*;
public class MultiValueMap_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 7, 0, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3feaf56c6118b20cL), Double.longBitsToDouble(0x3fd108e9ec28297eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 11, 0, 10, "\ud8e4\udddf\ud896\udc6f\udb49\udf41\uda7c\udf38\uda6d\udddb\ud8b9\udd61\udb33\udf04\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\uc065\u456d\u8b0e\u66e6\uc840\ubbb5\u12f9\u800d\u908c\u396e\uaa4f\u8a2a", "\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf\u5fe0\ud961\udffc\ud80a\udeeb\uda83\udd3e\udbc6\ude1a\udaac\udd4a\ud9a3\udf36\ud937\ude93\uca44\ud829\udcc4\udbf6\udec5\ud8ff\udd27\udbfc\ude48\ud81c\udc0c\ud9c2\udea5\uda56\uddab\uda20\udff5\ud89c\udfd1\ud926\udecb\udadf\udfd5\uc4ac",
        17, 22014, -1981000516, 3315803963749654223L, -11134L, false, true, (char) 32636, (char) 50835,
        Double.longBitsToDouble(0x3fec7bc894dc8a23L), Double.longBitsToDouble(0x3fe4772939966927L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 11, 2, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud993\udf54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u1f06\uc7b4\ubbb5", "\udb74\ude41\uda51\udcc2\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 78704, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 25176,
        Double.longBitsToDouble(0x3fe0375d5b691f27L), Double.longBitsToDouble(0x3fdedc20bc28297eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 3, 0, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3fbe526300c007a0L), Double.longBitsToDouble(0x3fd10c07d628297eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=null |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 7, 7, 14, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud944\ude91\ud96e\udc46\udb0e\udda4\udb78\udc31\udb9d\ude46", "\u8138\ub12c\u36fc\u4bb4\uc7b4\u6020\u12f9\u800d\u908c\u396e\uc14f\u8a2a\ua0e6\u07e9\ub45e\u64f2\ua957\u12ef\u9211\u4463\u8cc5\u2ec1\ub7c2\u0f89\u00c7\u82a7\u765d\u52d3\u428e\u37e7", "\udbfc\ude48\ud9f6\ude38\ud9f6\udfa8\uda47\udc48\u3c94\ud999\ude0f\udb85\udf2a",
        59, 21644, -1492756455, -5733573600126159066L, 74478L, false, true, (char) 27037, (char) 43248,
        Double.longBitsToDouble(0x3fd60acb64ec13f6L), Double.longBitsToDouble(0x3fee37da20d5fdf6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 1, 0, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\ud955\ude4b\ud9da\udceb\udb63\udd18\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3feaf56c6118b20cL), Double.longBitsToDouble(0x3fd108e9ec28297eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 10, 0, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\udac4\udea4\udac6\uddd6\ud8b9\udd0b\ud9b0\udec1\ud8b1\udd71\udaf4\ude8f\ud88c\udc2c\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u444a\u8ae7\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud93a\ude6c\ud8af\udd40\ud9f2\udeaa\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025679887L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3fee029a2918b20cL), Double.longBitsToDouble(0x3fd108e9ec28282aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.String:\u771b\u72c6\u610e\u05b2\u97d0 |this=org.apache.commons.collections.map.MultiValueMap:{\ud8c9\udc83\udac0\udea5\ud84e\udfd6\ud85a\uddee\udbe5\udd81\ud8b9\udd61\ud9b0\udec1\ud810\ude64=[\u771b\u72c6\u610e\u05b2\u97d0]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8c9\udc83\udac0\udea5\ud84e\udfd6\ud85a\uddee\udbe5\udd81\ud8b9\udd61\ud9b0\udec1\ud810\ude64=[\u771b\u72c6\u610e\u05b2\u97d0, \u771b\u72c6\u610e\u05b2\u97d0]}\012",
        Z.run(T, 2, 9, 10, 14, "\ud8c9\udc83\udac0\udea5\ud84e\udfd6\ud85a\uddee\udbe5\udd81\ud8b9\udd61\ud9b0\udec1\ud810\ude64", "\u771b\u72c6\u610e\u05b2\u97d0", "\udaee\udc95\udaf8\udd07\udbce\ude28",
        31, 80025, -753210054, -7234065002101522456L, 865L, false, false, (char) 55669, (char) 32080,
        Double.longBitsToDouble(0x3fe90efc09a03c52L), Double.longBitsToDouble(0x3fe63e993e4b4b62L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=null |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 7, 13, 5, "\ud8e4\ude0b\ud9e8\udd18", "\u08b5\u189d", "\uda68\udd63\ud96d\udf9d\udb0e\udda4\ud94b\udc19\udbc2\udd22\ud915\udd75",
        44, 20924, 1757145528, -8400113559713634957L, -70353L, true, true, (char) 4890, (char) 17453,
        Double.longBitsToDouble(0x3fdf69b0a8dd4f9aL), Double.longBitsToDouble(0x3f9e3af655302f60L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 2, 2, 12, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\ud85e\ude91\udab5\udcfc\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud81f\udf16\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ud965\udce6\ud85f\udde1\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3feaf56c6718b20cL), Double.longBitsToDouble(0x3fd10ad36428297eL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=org.apache.commons.collections.iterators.EmptyIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 1, 8, 0, 7, "\ud89f\uddea\ud9e8\udce9\ud9fa\udf5a\udac4\udfc7\udab5\udcc9\ud8b9\udd61\ud9b0\udec1", "\u0a53", "\ud9bd\udc05",
        48, 67232, -2050396322, 1390461884505182137L, 64219L, false, true, (char) 9165, (char) 44602,
        Double.longBitsToDouble(0x3fe80017d96641e5L), Double.longBitsToDouble(0x3fbbbf5800f1d7b0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 2, 0, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\ud96a\udeb7\ud8ec\udcac\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud968\udfc9\uf920", "\u76d2\uc57a\u8b0e\u37df\uc7b4\u6e49", "\udb6e\udd9b\ud993\udcc3\udaf3\udfdf\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud960\ude20\udae3\udc1a\ud895\udcdd\u5fe0\ud961\udffc\ud80a\udeeb\uda83\udd3e\udbc6\ude1a\ud910\udfbd\udba5\udc17\ud937\ude93",
        -2, 97747, -1307797339, -8169950733576230640L, -9523L, false, false, (char) 3631, (char) 43454,
        Double.longBitsToDouble(0x3fe90c80692c77adL), Double.longBitsToDouble(0x3fe35bb941b8d557L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 12, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\ud8b7\udf3e\ud9f2\ude8e\ub5cc\udaa0\udf36\ud81b\udf82\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3feaf56c6118b20cL), Double.longBitsToDouble(0x3fc2b1d3da16126cL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 5, 0, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\udac0\ude4f\ud9f2\ude1f\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3fe9bd6c642b54c7L), Double.longBitsToDouble(0x3fcb07acb8535460L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 0, 10, "\ud8e4\udddf\ud9e8\udd18-\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u0bab\000\000\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\u58a2\000\000\000\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        22, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3feaf56c6118b20cL), Double.longBitsToDouble(0x3fd108e9e000297eL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.util.ArrayList:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 14, 3, 3, "\ud8e4\udddf", "\ua95c", "\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\uda95\udc02\uf8e3\udad4\ude55\ud960\udee4\ud8c4\udf88\ud739\ud8f5\ude5a\udab9\udf5a\ud9ad\udf18\udb6a\udf53\udaad\udcc2\udaaf\ude7f\ud81b\udc8c\uda4e\udd80\ud8ac\udca4\ud816\udec0\ud8f6\ude93\uda50\udf3d\uda2d\ude46\ub5cc\ud85f\ude16\udb12\udd09\uda05\udf75\uda68\uddeb\u978b\udb72\udcb5\ud9cf\udef3\ud850\udc35\ud905\udcad\ud93b\udefe\udb15\ude6b\udbce\udd7d\ud806\udc3a\ud829\udc81\udbf6\udec5\udbd9\uded4\udb61\udf3b\udb06\ude41\ud988\udcf9\ud9cd\ude3c",
        25, 47969, -1103589117, 230820391368950259L, 51100L, false, true, (char) 54332, (char) 34728,
        Double.longBitsToDouble(0x3fdc72b2983e5cd6L), Double.longBitsToDouble(0x3feb93d0ee036a7aL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=null |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 13, 13, 6, "\ud8e4\udddf\ud9e8\udd18\ud902\udedd\ud9e2\udf65\ud819\udc46\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\u26b6\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud9bc\udea3\udb15\udc7f\ud82b\udf70\uda47\udfbf",
        42, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 37964,
        Double.longBitsToDouble(0x3feaf5146918b20cL), Double.longBitsToDouble(0x3fd108e9ec28297eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud9e3\udc18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920=[\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5]}\0121=java.util.ArrayList:[\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5] |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud9e3\udc18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920=[\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5]}\012",
        Z.run(T, 2, 10, 7, 10, "\ud8e4\udddf\ud9e3\udc18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\uda3d\udf6d\u84d3\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, 691920066, 3217534825788519183L, -72024L, false, true, (char) 27797, (char) 35067,
        Double.longBitsToDouble(0x3feaf56c6118b20cL), Double.longBitsToDouble(0x3fd108e9ec28297eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 4, 14, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\uf6ad\000\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf", "\u3927\u8dd9\u8b0e\ua573\uc786\ubbb5", "\udb74\ude41\ud852\ude02\000\000\000\uda41\udfa0\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534536029221647L, -72024L, true, false, (char) 49190, (char) 2044,
        Double.longBitsToDouble(0x3feaf5680118b20cL), Double.longBitsToDouble(0x3fd108e9ec28297eL)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 0, 11, "\ud8ba\udcfd\ud9e8\udd18\udb4e\udc41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udb48\uded7\udbfd\udc7a\ud90e\uddcc\uda07\uddf3\udb43\udf77\ud826\udd31", "\u6171\u69f5\u8b8a\uac0e\ub470\ubc45", "\udbf6\udcbf\ud993\udcc3\uda03\udfe7\ud99e\ude95",
        0, 96215, -1750925296, 7735018714171055942L, 49167L, true, true, (char) 6764, (char) 56165,
        Double.longBitsToDouble(0x3fe8796534377792L), Double.longBitsToDouble(0x3fbaf55467fe8d40L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 6, 4, "\ud981\udc57\uda4f\udcb5\u142c\u12a4\udab5\udcc9\ud903\udfcf\ud9b0\udec1\uda20\udc10\ud83f\ude56\ud96e\udc6e\udb0e\udda4\ud967\udff5\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5\ua3dc\u7fd0\u908c\u3943\u9050\u8a2a\ua0e6\u07e9\ub45e\u64f2", "\uda05\udf75\uda47\udfbf\u5fe0\ud961\udffc",
        7, 22637, 2006102799, -7465831577691750771L, -79051L, false, true, (char) 19690, (char) 13092,
        Double.longBitsToDouble(0x3fd108e9ec28297eL), Double.longBitsToDouble(0x3fe1a00bcff30ed4L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.String:\u189d\u13e5\ua4f6\u8678\u4182 |this=org.apache.commons.collections.map.MultiValueMap:{\ud88d\udff7\udb57\udf88\ud992\udd62=[\u189d\u13e5\ua4f6\u8678\u4182]}\0121=java.lang.String:\u189d\u13e5\ua4f6\u8678\u4182 |this=org.apache.commons.collections.map.MultiValueMap:{\ud88d\udff7\udb57\udf88\ud992\udd62=[\u189d\u13e5\ua4f6\u8678\u4182, \u189d\u13e5\ua4f6\u8678\u4182]}\012",
        Z.run(T, 2, 9, 9, 10, "\ud88d\udff7\udb57\udf88\ud992\udd62", "\u189d\u13e5\ua4f6\u8678\u4182", "\ud801\ude08\udb97\udd76\ud87d\ude77\uda49\udc9c\udafa\ude5e\ud97b\udfab\ud899\udd05",
        10, 93772, -413429180, -3061466464242721190L, 15602L, false, false, (char) 9252, (char) 36650,
        Double.longBitsToDouble(0x3fed60be6a8a97a3L), Double.longBitsToDouble(0x3fe886c26b70e52aL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 0, 0, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u46c3\uc7b4\u8675", "\uda9f\udc55\udbc3\ude11\uda03\udfe7\ud8e6\udca9\uda6a\udc88\uda71\udf07\ud89f\udf4b\ub5cc\ud85f\ude16\ud81b\udefe\ud9b1\ude0b\ud8ab\udef5",
        42, 13659, -523707198, 6000196157787240507L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3fa256c6118b2910L), Double.longBitsToDouble(0x3fd108e9ec28297eL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 6, 12, 8, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud907\ude47\uda79\udc1e\udaa7\udd6c\ud80a\udc54\ud977\uddc2\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8522\u4bc3\uc7b4\ubbb5", "\udb74\ude41\ud993\udcc3\u5162\uda61\udf49\ud9b1\udd83\udbef\udc19\ud9f2\udde9\ub5cc\uda80\udd26\uda46\ude8a\ud866\udfec\uda47\udf35",
        42, 13659, -523707198, 3217534538025710562L, -72024L, true, false, (char) 49190, (char) 5910,
        Double.longBitsToDouble(0x3fc4f5a8a507ccbcL), Double.longBitsToDouble(0x3fd108e9ec28297eL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.collections.iterators.EmptyIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.iterators.EmptyIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 8, 8, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\ud828\uddd5", "\u2c44\u8dd9\u8b0e\u4bc3", "\uda1b\udd59\udaa6\udda5\udb7a\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf\u5fe0\ud961\udffc\ud80a\udeeb\uda83\udd3e\udbc6\ude1a\ud910\udfbd\udba5\udc17\ud937\ude93\uca44\ud829\udcc4\udbf6\udec5\ud9c2\ude69\udbfc\ude48\udb54\udf07",
        2, 17444, -53372154, -4357609337515414341L, -24926L, true, true, (char) 24501, (char) 46251,
        Double.longBitsToDouble(0x3fcdaf3a362a6f84L), Double.longBitsToDouble(0x3fe361c8e9b941f7L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Integer:0 |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 14, 14, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\ub71a\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025710351L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3feaf56c6118b20cL), Double.longBitsToDouble(0x3fd108e9ec28297eL)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 11, 11, 3, "\ud8e4\udddf\ud896\udc6f\udb49\udf41\uda7c\udf38\uda6d\udddb\ud8b9\udd61\udb33\udf04\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\uc065\ub0c5\u8b0e\u66e6\uc840\ubbb5\u12f9\u800d\u908c\u6a6d\uaa4f\u8a2a", "\ud823\udde0\ud84a\udd99\udb18\udfd3\ud816\udfed\uda05\udf75\uda47\udfbf\u5fe0\ud961\udffc\ud80a\udeeb\uda83\udd3e\udbc6\ude1a\udaac\udd4a\ud8b0\udd9d\udb48\udf71\uca44\ud829\udcc4\ud9f2\ude03\uda0c\uddbd\u0f27\uee0c\ud9c2\udea5\uda56\uddab\uda20\udff5\ud89c\udfd1\ud926\udecb\udadf\udfd5\uc4ac",
        17, 22014, -1980957508, 3315803963749654223L, -11134L, false, true, (char) 32636, (char) 50835,
        Double.longBitsToDouble(0x3fec7bc894dc8a23L), Double.longBitsToDouble(0x3fe4772939966927L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 1, 1, 9, "\ud8e4\udddf\ud896\udc6f\udb49\udf41\udbf6\udd3d\ud8dd\udcab\uda99\udd14\udb6f\udebf\udaa7\udcfb\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\uc065\u456d\u8b0e\u66e6\uc840\ubbb5\u12f9\u800d\u908c\uce78\uaa4f\u8a2a", "\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf\u5fe0\ud961\udffc\u7eeb\uda83\udd3e\udbc6\ude1a\udaac\udd4a\ud9a3\udf36\udbf3\udc66\uca44\ud829\udcc4\udbf6\udec5\ud8ff\udd27\udbfc\ude48\ud81c\udc0c\ud9c2\udea5\u7d31\ud8f4\udef7\ud8a9\udff1\ud926\udecb\udadf\udfd5\uc4ac",
        17, 22014, -1981000516, 3315803963749654223L, 97867L, false, true, (char) 32636, (char) 50835,
        Double.longBitsToDouble(0x3fef9bc894447f6bL), Double.longBitsToDouble(0x3fe4772939966927L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 11, 6, 10, "\ud8e4\udddf\ud9e3\udff6\u87e3\uda9b\udec4\uda6d\udddb\ud8b9\udd61\udb33\udf04\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ubfbf\uda84\udf33", "\u8310\u456d\u8b0e\u66e6\uc840\u1e1a\u11a4\u68c6\u30d3\u3ada\u29c4\u8a2a", "\uda28\udfad\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf\uda6f\ude6a\ud961\udffc\ud80a\udeeb\uda83\udd3e\udbc6\ude1a\udaac\udd4a\ud9a3\udf36",
        3, 45733, -1383300704, -5616939410283855592L, 10100L, true, false, (char) 62548, (char) 11377,
        Double.longBitsToDouble(0x3fe154b391ce944dL), Double.longBitsToDouble(0x3fe310865312d4c3L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud896\udc6f\udb49\udf41\uda7c\udf38\uda6d\udddb\ud8b9\udd61\udab5\udda5\udad5\udd6c\ud80a\udc54\uda22\ude77\udb0e\udda4\ud94b\udc19\uf920=[\u8ade\u8746\u8b0e\u66e6\uc840\u27d5\u12f9\u800d\u908c\u396e\uaa4f\u8a2a]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud896\udc6f\udb49\udf41\uda7c\udf38\uda6d\udddb\ud8b9\udd61\udab5\udda5\udad5\udd6c\ud80a\udc54\uda22\ude77\udb0e\udda4\ud94b\udc19\uf920=[\u8ade\u8746\u8b0e\u66e6\uc840\u27d5\u12f9\u800d\u908c\u396e\uaa4f\u8a2a]}\012",
        Z.run(T, 2, 10, 2, 10, "\ud8e4\udddf\ud896\udc6f\udb49\udf41\uda7c\udf38\uda6d\udddb\ud8b9\udd61\udab5\udda5\udad5\udd6c\ud80a\udc54\uda22\ude77\udb0e\udda4\ud94b\udc19\uf920", "\u8ade\u8746\u8b0e\u66e6\uc840\u27d5\u12f9\u800d\u908c\u396e\uaa4f\u8a2a", "\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf\u5fe0\ud961\udffc\ud80a\udeeb\uda83\udd3e\udbc6\ude1a\udaac\udd4a\ud9a3\udf36\uda00\uddf9\ud81f\udda5\ud829\udcc4\udbf6\udec5\ud949\udfec\udbfc\ude48\ud81c\udc0c\ud9c2\udea5\uda56\uddab\uda20\udff5\ud89c\udfd1\ud926\udecb\udadf\udfd5\uc4ac",
        17, 22014, -1981000516, 3315803963749654223L, 73260L, false, true, (char) 32636, (char) 50835,
        Double.longBitsToDouble(0x3fec7bc894dc8a23L), Double.longBitsToDouble(0x3fe477293f966927L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud896\udc6f\udb49\udf41\uda7c\udf38\uda6d\udddb\ud8b9\udd61\udb33\udf04\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud8e3\udd65\uf8e7=[\uc065\u456d\u8b0e\u66e6\uc840\ubbb5\u12f9\ub0f0\ub72c\u396e\uaa4f\u8a2a]}\0121=java.lang.String:\uc065\u456d\u8b0e\u66e6\uc840\ubbb5\u12f9\ub0f0\ub72c\u396e\uaa4f\u8a2a |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 10, 13, 10, "\ud8e4\udddf\ud896\udc6f\udb49\udf41\uda7c\udf38\uda6d\udddb\ud8b9\udd61\udb33\udf04\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud8e3\udd65\uf8e7", "\uc065\u456d\u8b0e\u66e6\uc840\ubbb5\u12f9\ub0f0\ub72c\u396e\uaa4f\u8a2a", "\ud99b\ude1c\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf\u5fe0\ud961\udffc\ud80a\udeeb\uda83\udd3e\udbc6\ude1a\udaac\udd4a\ud9a3\udf36\ud937\ude93\uca44\ud829\udcc4\udbf6\udec5\ud8ff\udd27\udbfc\ude48\ud81c\udc0c\ud9c2\udea5\uda56\uddab\uda20\udff5\ud89c\udfd1\ud926\udecb\udadf\udfd5\uc4ac",
        17, 22014, -1981000516, -7679517922418216245L, -40469L, true, true, (char) 50658, (char) 9708,
        Double.longBitsToDouble(0x3fec7bc894dc8a23L), Double.longBitsToDouble(0x3fe4772939966927L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 4, 6, 2, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\uda9a\udd85\udbb9\ude53\ud820\udd71\ud993\udf54\ud9a7\udf6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u6998\uc7b4\ubbb5", "\udb74\ude9d\uda42\ude4c\ud8ec\udcfc\uda9a\ude62\ud843\udca1\u87ee",
        44, 28802, -450224213, 4346804252561989792L, 75126L, false, true, (char) 43675, (char) 56165,
        Double.longBitsToDouble(0x3fe87965343a6a3aL), Double.longBitsToDouble(0x3fdb8f7eff7a7b44L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 5, 5, 2, "\udab4\udcc9\ud9e8\udd18\udb49\udf41\udb25\udd12\ud87d\udfd3\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud993\udf54\ud96e\udc6e\udb0e\udda4\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u1f06\uc7b4\ubbb5", "\udb74\ude41\uda51\udcc2\uda03\udfe7\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud98c\ude36\u48ec\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 78704, -523707198, 3217534538025710351L, -72024L, false, false, (char) 49190, (char) 25176,
        Double.longBitsToDouble(0x3fe0375d5b691f27L), Double.longBitsToDouble(0x3fdedc20bc28297eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.String:\u39e3\u8dd9\u8b0e\u4c0e\u26af\ub300 |this=org.apache.commons.collections.map.MultiValueMap:{\udb97\ude50\ud908\udc17\udb4e\udc0c\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udb97\udce4\ud94f\udfe7\ud84d\udfbd\ud829\udc3c\ud94b\udc19\uf920=[\u39e3\u8dd9\u8b0e\u4c0e\u26af\ub300]}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{\udb97\ude50\ud908\udc17\udb4e\udc0c\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udb97\udce4\ud94f\udfe7\ud84d\udfbd\ud829\udc3c\ud94b\udc19\uf920=[\u39e3\u8dd9\u8b0e\u4c0e\u26af\ub300]}\012",
        Z.run(T, 2, 9, 1, 4, "\udb97\ude50\ud908\udc17\udb4e\udc0c\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udb97\udce4\ud94f\udfe7\ud84d\udfbd\ud829\udc3c\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4c0e\u26af\ub300", "\udb74\ude41\ud9cc\ude1f\ud8da\ude2f\ud8e6\udd85\udabd\udff2\uda71\udef2\ud9cf\udc74\ud96f\udf79\udb8f\udce1\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 70624, -1427524670, 3217534868738192143L, 4502L, true, false, (char) 49190, (char) 25176,
        Double.longBitsToDouble(0x3fe0375d5b691f27L), Double.longBitsToDouble(0x3fdedc20bc28297eL)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.lang.Boolean:false |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 10, 10, 14, "\ud8e4\udddf\ud9e8\udd18\udb29\udf14\u38a9\000\ud8b9\udcba\ud9b0\udec1\ud925\udca8\u00c4\000\000\ud94b\udc19\uf920", "\u00bc\u88dd\u8ad5\u1f06\u08971", "\u7035",
        33, -1000, 0, 7188767551097143399L, -31248L, false, false, (char) 30455, (char) 12,
        Double.longBitsToDouble(0x3fc0000000000000L), Double.longBitsToDouble(0x3e38780000000000L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=java.util.ArrayList:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=java.util.ArrayList:[] |this=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 3, 3, 10, "\ud8aa\udd35\ud9e8\udd18\udb29\udf41\u12a4\uda19\udebb\000\000\000\000\000\000\ud94a\udf5f\uf920", "\u2e38\u8dd9\u8b0e", "\udb6a\udf53",
        54, -720, -1693814731, -6355175051482481554L, -34480L, false, false, (char) 36419, (char) 42,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fe28a2062fb92b2L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud9e8\udd18\udba5\udf3e\ud9a2\udf9f\udab5\udcc9\udbe4\ude9f\ud9b0\udec1\ud895\udee5=[\u771b\u72c6\u3896\u7e40\u97d0]}\0121=org.apache.commons.collections.map.MultiValueMap$ValuesIterator:@? |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud9e8\udd18\udba5\udf3e\ud9a2\udf9f\udab5\udcc9\udbe4\ude9f\ud9b0\udec1\ud895\udee5=[\u771b\u72c6\u3896\u7e40\u97d0]}\012",
        Z.run(T, 2, 10, 8, 12, "\ud8e4\udddf\ud9e8\udd18\udba5\udf3e\ud9a2\udf9f\udab5\udcc9\udbe4\ude9f\ud9b0\udec1\ud895\udee5", "\u771b\u72c6\u3896\u7e40\u97d0", "\udb4a\udcca\uda7a\udcc4\ud935\udca3\udb6a\udf53\uda1b\udd59",
        21, 55269, -1479679564, -1489780610704641126L, 47609L, false, false, (char) 58347, (char) 38042,
        Double.longBitsToDouble(0x3fea8f6ef9a03c52L), Double.longBitsToDouble(0x3feb654e12bebed8L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud919\udc20\uf920=[\u395c\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5\u12f9\u800d\u908c\u396e\uaa4f]}\0121=java.lang.Integer:1 |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud919\udc20\uf920=[\u395c\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5\u12f9\u800d\u908c\u396e\uaa4f]}\012",
        Z.run(T, 2, 10, 14, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud80a\udc54\ud96e\udc6e\udb0e\udda4\ud919\udc20\uf920", "\u395c\u8dd9\u8b0e\u4bc3\uc7b4\ubbb5\u12f9\u800d\u908c\u396e\uaa4f", "\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\udbe5\ude65\udb5f\ude17\uda9b\ude49\ud97f\udfd7\ud9e3\uded4\uda87\udf2a\uda7b\udd00\ub26c\udba5\udc17\ud937\ude93",
        -2, 36304, 16031865, -4576255252306646768L, 25407L, false, true, (char) 22096, (char) 20687,
        Double.longBitsToDouble(0x3fcca8a0205f235cL), Double.longBitsToDouble(0x3fdeb6e18ebca072L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf=[\u83e1]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf=[\u83e1, \u83e1]}\012",
        Z.run(T, 2, 10, 10, 14, "\ud8e4\udddf", "\u83e1", "\ud9b0\ude99\udbc5\udc75\udaf4\ude8f\ud88c\udc2c\udb0e\udda4\ud963\ude68\uda02\udc41\ud94d\udfce\ud950\uddfa\ud8c4\udf88",
        47, 36954, 542352723, -4245849279172193571L, -58078L, true, false, (char) 48218, (char) 58427,
        Double.longBitsToDouble(0x3fd1e52944c90380L), Double.longBitsToDouble(0x3fe2c6b2604ede6dL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud9e8\udd18\udb49\udf41\udac4\udea4\udac6\uddd6\ud8b9\udd0b\ud9b0\udec1\ud8b1\udd71\udaf4\ude8f\ud88c\udc2c\udb7e\udf5c\ud9e3\udee9\uf920=[null]}\0121=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\ud8e4\udddf\ud9e8\udd18\udb49\udf41\udac4\udea4\udac6\uddd6\ud8b9\udd0b\ud9b0\udec1\ud8b1\udd71\udaf4\ude8f\ud88c\udc2c\udb7e\udf5c\ud9e3\udee9\uf920=[null]}\012",
        Z.run(T, 2, 9, 1, 1, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\udac4\udea4\udac6\uddd6\ud8b9\udd0b\ud9b0\udec1\ud8b1\udd71\udaf4\ude8f\ud88c\udc2c\udb7e\udf5c\ud9e3\udee9\uf920", "\u39e3\u444a\u8ae7\u4bc3\u9d70\ubbb5", "\udb74\ude41\ud993\udcc3\uda03\udfe7\ud8e6\udca9\ud93a\ude6c\ud8af\udd40\ud9f2\udeaa\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 3217534538025679887L, -72024L, true, false, (char) 49190, (char) 35067,
        Double.longBitsToDouble(0x3fee029a2918b20cL), Double.longBitsToDouble(0x3fd108e9ec28282aL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{}\0121=org.apache.commons.collections.map.MultiValueMap:{}\012",
        Z.run(T, 2, 4, 4, 14, "\ud8c9\udc83\udac0\udea5\ud84e\udfd6\ud85a\uddee\udbe5\udd81\ud806\ude44\ud93d\udd79\ud976\udc53", "\u771b\u72c6\u610e\u45e0\u97d0\u836d\u8dd9\uc0d7\u5d8b", "\ud9e1\udd7b\udab0\ude94\ud986\ude4a\ub4d6\uda0f\udf54\ud8e6\udca9\ud946\uded2\udb73\ude69\uda0e\udce6\ud952\udf13\udb27\uddd8\ud803\udfe3\ud87a\udc24\udbd6\ude4e\uda7b\udd77\ud950\uddc7\udb81\udd4c\udbb3\ude13\ud8e7\udc49\ud901\udcfa\uda4c\uddd3\uda17\udc73\ud88e\ude62\uda23\udf0f\u7216\uda84\udda4\uda27\udc1f\ud921\udf11",
        22, 69359, -589907392, 1026077830178906057L, 88240L, true, true, (char) 21363, (char) 59064,
        Double.longBitsToDouble(0x3fbf45692cebaf10L), Double.longBitsToDouble(0x3fe583a2dce55bd6L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=null |this=org.apache.commons.collections.map.MultiValueMap:{}\0121=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 7, 4, 14, "\udaa3\uddd2\ud9ee\udc62\udb49\udf41\u12a4\uda2e\udce6,\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf", "\u8da9\u24c8\u3513\u6c6d\uc292\ubbb5", "\ud86e\udf44\ud852\ude02\000\000\000\uda41\udfa0\ud9f2\udde9\ub5cc\ud85f\ude16\ud8e1\uddc1\udae7\udc7b\u2d9a",
        42, 13659, -523707198, 3217534536029221647L, -72024L, true, false, (char) 49190, (char) 53083,
        Double.longBitsToDouble(0x3feaf56ea118b20cL), Double.longBitsToDouble(0x3fce80b3d92758e4L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.apache.commons.collections.map.MultiValueMap:{\udaa3\uddd2\ud9ee\udc62\udb49\udf41\u12a4\uda2e\udce6=\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf}\0121=org.apache.commons.collections.map.MultiValueMap:{\udaa3\uddd2\ud9ee\udc62\udb49\udf41\u12a4\uda2e\udce6=\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf}\012",
        Z.run(T, 2, 5, 4, 14, "\udaa3\uddd2\ud9ee\udc62\udb49\udf41\u12a4\uda2e\udce6,\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf", "\u948a\u24a2\u3513\u6c6d\uc292\ubbb5", "\ud86e\udf44\ud852\ude02\000\000\000\uda41\udfa0\ud9f2\udde9\ub5cc\ud85f\ude16\ud8e1\uddc1\udae7\udc7b\u2d9a",
        42, 70694, 1293859900, 3217534213906674447L, -72024L, true, false, (char) 32549, (char) 53083,
        Double.longBitsToDouble(0x3feaf56ea118b20cL), Double.longBitsToDouble(0x3fce80b3d92758e4L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{\udad3\udf01\ud9a3\udd9d\ud85a\uddc1\ud83d\udc85\uda2e\udce6=[\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf\ud915\udd75\u00cd\uda76\udf05]}\0121=java.lang.String:\u6c6d\u1dd4 |this=org.apache.commons.collections.map.MultiValueMap:{\udad3\udf01\ud9a3\udd9d\ud85a\uddc1\ud83d\udc85\uda2e\udce6=[\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf\ud915\udd75\u00cd\uda76\udf05], \udad3\udf01\ud9a3\udd9d\ud85a\uddc1\ud83d\udc85\uda2e\udce6,\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf\ud915\udd75\u00cd\uda76\udf05=[\u6c6d\u1dd4]}\012",
        Z.run(T, 2, 11, 9, 14, "\udad3\udf01\ud9a3\udd9d\ud85a\uddc1\ud83d\udc85\uda2e\udce6,\ud9a5\udcd1\udaa7\udd6c\ud80a\udc54\udbc2\uded8\ud87a\uddfd\u26ba\ud99e\udccf\ud915\udd75\u00cd\uda76\udf05", "\u6c6d\u1dd4", "\udaa6\udda5",
        16, 58726, 4043776, 0L, -34480L, true, false, (char) 40342, (char) 55416,
        Double.longBitsToDouble(0x3feb393a918a5637L), Double.longBitsToDouble(0x3fe28a277afb92b2L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.map.MultiValueMap:{\udad3\udf01\ud9a3\udd9d\ud85a\uddc1\udb1b\uddf4\uda2e\udce6=[\udab2\udc38\udaff\udd20\ud80a\udc34\udbc2\uded8\ud87a\uddfd\u26ba\ud9b8\ude5b\ud9cb\udc22\udab7\udd40\uda76\udfe9]}\0121=void |this=org.apache.commons.collections.map.MultiValueMap:{\udad3\udf01\ud9a3\udd9d\ud85a\uddc1\udb1b\uddf4\uda2e\udce6=[\udab2\udc38\udaff\udd20\ud80a\udc34\udbc2\uded8\ud87a\uddfd\u26ba\ud9b8\ude5b\ud9cb\udc22\udab7\udd40\uda76\udfe9, \udab2\udc38\udaff\udd20\ud80a\udc34\udbc2\uded8\ud87a\uddfd\u26ba\ud9b8\ude5b\ud9cb\udc22\udab7\udd40\uda76\udfe9]}\012",
        Z.run(T, 2, 11, 11, 9, "\udad3\udf01\ud9a3\udd9d\ud85a\uddc1\udb1b\uddf4\uda2e\udce6,\udab2\udc38\udaff\udd20\ud80a\udc34\udbc2\uded8\ud87a\uddfd\u26ba\ud9b8\ude5b\ud9cb\udc22\udab7\udd40\uda76\udfe9", "\u6c86\u1dd4\ua34c\u6dbc\u800d", "\uda75\udc03\udb7b\udd5c\u00c5\uda41\udfa0\ud9f2\udde9\ud8db\udd82\ud982\ude40\udafb\udf79\udae7\udc7b\u2d9a\u5fe0\udab7\udc3e\udaf3\udd14\ud8fd\uddf9\ud8fe\udef3\ud87d\udec9",
        32, 71897, 1019232741, 3215782280210179751L, -24927L, true, true, (char) 39700, (char) 47661,
        Double.longBitsToDouble(0x3fe61a3a39e24fcfL), Double.longBitsToDouble(0x3fe3f23613dd9b68L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 5, 10, "\ud8e4\udddf\ud9e8\udd18\udb49\udf41\u12a4\udab5\udcc9\ud8b9\udd61\ud9b0\udec1\udaa7\udd6c\ud87e\udfcf\ud918\udc31\ud895\uddbf\ud94b\udc19\uf920", "\u39e3\u8dd9\u8b0e\u4bc3\uc7b4\u56b5", "\udb74\ude41\ud873\udc33\ud9e5\udc21\ud8e6\udca9\ud82e\udc8a\uda71\udf07\ud9f2\udde9\ub5cc\ud85f\ude16\ud81b\udefe\uda05\udf75\uda47\udfbf",
        42, 13659, -523707198, 551403558622342800L, -79051L, false, true, (char) 19690, (char) 13092,
        Double.longBitsToDouble(0x3fd108e9ec28297eL), Double.longBitsToDouble(0x3fe4b30161f768dcL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.map.MultiValueMap:{\udaa3\uddd2\ud9ee\udc62\udb49\udf41=[, \u50e6\u31a6\u6f87\ud2ea]}\0121=null |this=org.apache.commons.collections.map.MultiValueMap:{\udaa3\uddd2\ud9ee\udc62\udb49\udf41=[, \u50e6\u31a6\u6f87\ud2ea]}\012",
        Z.run(T, 2, 10, 13, 7, "\udaa3\uddd2\ud9ee\udc62\udb49\udf41", ",\u50e6\u31a6\u6f87\ud2ea", "\ud99e\udccf\ud915\udd75\uda16\ude77\udae9\udd3b\udb0b\udd0e\uda63\ude68\uda8b\udc54",
        45, 71353, -1227101783, -3172965992792768203L, -100000L, false, true, (char) 18535, (char) 49727,
        Double.longBitsToDouble(0x3f90f9ad9152f460L), Double.longBitsToDouble(0x3fed5c6cc370e52aL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.map.MultiValueMap|clear||new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|containsValue|java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|containsValue|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|createCollection|int|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|decorate|java.util.Map|static",
    "M|org.apache.commons.collections.map.MultiValueMap|decorate|java.util.Map,java.lang.Class|static",
    "M|org.apache.commons.collections.map.MultiValueMap|decorate|java.util.Map,org.apache.commons.collections.Factory|static",
    "M|org.apache.commons.collections.map.MultiValueMap|getCollection|java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|iterator|java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|put|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|putAll|java.lang.Object,java.util.Collection|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|putAll|java.util.Map|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|readObject|java.io.ObjectInputStream|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|removeMapping|java.lang.Object,java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|size|java.lang.Object|new:org.apache.commons.collections.map.MultiValueMap:",
    "M|org.apache.commons.collections.map.MultiValueMap|totalSize||new:org.apache.commons.collections.map.MultiValueMap:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
