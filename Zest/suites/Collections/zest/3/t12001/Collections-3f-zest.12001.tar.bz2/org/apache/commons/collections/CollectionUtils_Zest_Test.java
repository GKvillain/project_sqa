package org.apache.commons.collections;
import org.junit.Test;
import static org.junit.Assert.*;
public class CollectionUtils_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=null\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 15, 6, 14, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=null\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 15, 6, 14, "\uda2d\ude30", "\u3b6a\ud666\uadd5\uaa94\u3c88\u3838\u0cb5\u7c76\u5b7b\uc662\u31c3\u15e1\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791\ub2c0\u347d\ubdbc\u0e5c\u2208\u6c23\u8533\u8640\u4698\u9087\ub7f2\u7dc2\uafa9\u84d6\u226d\u6c2c\u4028\u34a4", "\u4165\udaab\ude4e\uda82\udfbe\udb08\udc12\ucc53\ud889\udf82\udba6\udf87\ud8cc\ude32\udb0f\ude5b\ud9e6\udf7d\udbbe\udd48\ud9d3\udf39\udb8b\udc98\ud97e\udc56\udb8a\udec0\udb34\udfe9\udae9\uddc1\uda4d\udec4\udb62\ude8d\ud937\udd54\ud8d6\ude33\ud9ac\ude86\ud9ea\udcd2",
        14, 48834, 1955402848, -1699325141900920136L, 86870L, true, true, (char) 59945, (char) 56865,
        Double.longBitsToDouble(0x3fda7d1b0d5a503eL), Double.longBitsToDouble(0x3fd659a0ab099866L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\udb14\udee8\udb85\ude2e\udb69\udfc7\u4bcd\uda5b\uddf5\ud90a\udf23\udb66\uddef\udb67\udcba\uda65\udd22\udaa2\udfec\udab2\udea7\u83c7]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 2, 13, "\udb14\udee8\udb85\ude2e\udb69\udfc7\u4bcd\uda5b\uddf5\ud90a\udf23\udb66\uddef\udb67\udcba\uda65\udd22\udaa2\udfec\udab2\udea7\u83c7", "\u1546\u0c96\ub753\u09c9\u6978\ucd99\u3055\uc30d\u6b43\ua4ba\u4480\ub2bb\u3600\u1c8f\u3dc4\u78f4\u4d10\uc9fb\u00d8\u11e5\u2402\ub7f2\u7576\uafa9\u84d6\u226d\u6c2c\u4028\u34a4", "\ud99c\ude2c\ud95e\udca6\ud906\udf2c\ud961\udd4f\udb64\uddcb\uda28\udeb9\udb34\udfa7\ud98b\udc4c\udb16\udf55\udbb1\udc24\uda2c\udea1\udbf4\udd3b\udb35\udcc0\ud92e\udd58\ud80d\udcdf\ud95d\udfbc\udbda\udd30\udb0c\udfd5\ud8d8\udc33\udaab\udef8\udb46\udfd6",
        21, 79290, 1005035532, -5413957364085970931L, -38545L, false, false, (char) 13939, (char) 25762,
        Double.longBitsToDouble(0x3fc4cb4048444ed0L), Double.longBitsToDouble(0x3f9da13049e2dec0L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\uc194\udb64\udf23\ud984\ude84\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8]\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 0, 6, 14, "\uc194\udb64\udf23\ud984\ude84\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8", "\u0a0a\u7ba5\u5b7b\uc70e\u2e77\u503b\u82f4\u9bce\uc3b1", "\ud82d\udf7b\udbeb\ude95\udb7d\udcad\ud805\udf56\ud987\udeac\udacc\udf5c\udbcf\ude36\udbdd\udce3\ud8e3\udc08\udbe6\udd78\ud89c\udc1e\ud8df\udd6c\ud930\udc4e\ud907\udc9b\udae3\uddb6\ud8ba\udea0\ud850\uddbe\ud90e\udfe5\udb03\udd06\ud97c\udfe6\uda45\ude29\ud91d\ude96\uda1f\uddc4\ud920\udf2d\ud94f\ude61\u4165\ud80b\udffd\ud974\udde9",
        12, 38800, 1336833984, -7109053632272878802L, 33759L, true, false, (char) 26817, (char) 42737,
        Double.longBitsToDouble(0x3fe305736b35e6dfL), Double.longBitsToDouble(0x3fe91e039f323a95L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 4, 6, 14, "\ud917\udee1\udb44\udfe1\ud9ad\ude05\uda80\udde7", "\uaa94\u3c88\u3838\u0cb5", "\ud9f4\uddb0\ud88e\uddbd\ud8a0\ude11\uda76\udf8e\ud844\ude52\udb9d\udd91\ud9a1\udeaf\ud861\udf6e\ud94d\udc15\udb74\udca1\ud8b3\uddbd\udb94\udf4b\uda1d\udf7e\udacc\udfcd\udbcf\ude36\ud85c\udcd7",
        9, 28951, -1267831372, 3058070482584669163L, 5112L, true, true, (char) 3932, (char) 21547,
        Double.longBitsToDouble(0x3fdb0fc3dbbe7150L), Double.longBitsToDouble(0x3fe6f8f99328b019L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udaf4\udf7d\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c]\0121=java.util.ArrayList:[\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udaf4\udf7d\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c]\012",
        Z.run(T, 2, 0, 0, 0, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udaf4\udf7d\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u16b7", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=null\0121=void\012",
        Z.run(T, 2, 15, 14, 11, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fb2d4f7d7be8670L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=null\0121=void |a1=[Ljava.lang.Object;:[[\u82c3\u9bce\ud1a9\u7e8c\u11fd\uc41e\u35e7\ud742\ubf3f\u2791]]\012",
        Z.run(T, 2, 15, 1, 14, "\uda6f\ude31\ud99b\udd2e\ud9ad\ude05\udaee\udd1f\ud93b\udd54\ud854\udf1a\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\u11fd\uc41e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, 50399L, false, false, (char) 43841, (char) 58205,
        Double.longBitsToDouble(0x3fea0c8bc1707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=null\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 15, 11, 14, "\uda2d\ude30\ud99b\udd77\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\ud8c6\udeda",
        39, 96912, 1509324115, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7e4ce0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null\012",
        Z.run(T, 1, 15, 6, 14, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc51\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\udb65\ude56\ud99a\udf7a\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 7, 8, 14, "\uda2d\ude30\ud99b\udd23\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\ud9d0\udc35\udb91\uddb9\udbf4\udc4d\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u50b0", "\ud9a1\udeaf",
        22, 8292, -1947365511, 4539149700766513260L, -41037L, false, true, (char) 9996, (char) 4102,
        Double.longBitsToDouble(0x3fe6bfbe85b43f71L), Double.longBitsToDouble(0x3fe73da373eb0f49L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=null\0121=java.util.ArrayList:[\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791, \uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c]\012",
        Z.run(T, 2, 15, 12, 1, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 6, 14, "\uda2d\ude30\ud99b\udd2e\ud978\udc30\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udb80\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udb18\udf46\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926898881425438L, -91794L, true, false, (char) 11094, (char) 19966,
        Double.longBitsToDouble(0x3fed40de11707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u1e52\u9266\u2e0b\u7e8c\ucb77\uc34e\u35e7\ud742\ubf3f\u2791]\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 7, 6, 14, "\uda2d\ude30\ud99b\udd2e\ud9f3\udd89\udaba\udc47\uda0e\uddda\u028d\udb4f\udd0e\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u1e52\u9266\u2e0b\u7e8c\ucb77\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udcbd\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db486b006cL), Double.longBitsToDouble(0x3fec1213fb759472L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u2a0f\u4756\ud1a9\u7e8c\u3dd3\uc34e\u2f44\u74c7\ubfc6\u2791]\0121=java.util.ArrayList:[\u2a0f\u4756\ud1a9\u7e8c\u3dd3\uc34e\u2f44\u74c7\ubfc6\u2791]\012",
        Z.run(T, 2, 9, 7, 14, "\udb25\udece\ud890\udc2f\ud9ad\ude05\uda80\udde7\uda61\udd0e\ud899\udc21\uda4d\ude48\ud994\udead\uda37\udf4f\udaa7\ude6a\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u2a0f\u4756\ud1a9\u7e8c\u3dd3\uc34e\u2f44\u74c7\ubfc6\u2791", "\udb4b\udc98\ud81b\ude4e\ud85c\udd0b\udbb2\udd3f\ud8df\udd67\u1f3c",
        22, 96912, 1509324115, 6344926901824639006L, -37811L, false, true, (char) 27267, (char) 13298,
        Double.longBitsToDouble(0x3fb194e397be8670L), Double.longBitsToDouble(0x3fe51ccd05b574c2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 7, 14, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7", "\uaa94\u3c88\ua74c\u76f4\u7c76", "\ud88e\uddbd\ud8a0\udef9\udb29\udd07\udaf8\ude60\udb9d\udd91",
        -4, 34819, 2113314308, -8363871182046475110L, -62404L, true, false, (char) 19677, (char) 9996,
        Double.longBitsToDouble(0x3fdaef86c4775866L), Double.longBitsToDouble(0x3fdb43fba5cf68dcL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 6, 14, "\ud87e\udc79\ud974\ude1a\ud9ad\uddf9\udb83\udea9\000\ue57b\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3", "\ud9a1\udeaf",
        54, 1308, 0, 0L, -100000L, false, true, (char) 30797, (char) 0,
        Double.longBitsToDouble(0x3e46d0fdc4000000L), Double.longBitsToDouble(0x3fe73da373eb2a70L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=void |a1=[Ljava.lang.Object;:[[\u82c3\u9bce\ud1a9\u7e8c\ucb6a\u0a83\uade1\ud7a5]]\0121=void\012",
        Z.run(T, 2, 1, 14, 14, "\uda2d\ude30\ud94f\udf8b\ud9ad\ude05\ud9b1\ude7a\uda0c\udd96\ud933\udd80\u884c\u2e3e\ud866\udd6e\ud89c\udc92\udbe3\ude20\ud93c\udcda\ud91b\ude19", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\u0a83\uade1\ud7a5", "\udacc\udf5c\udbcf\ude36",
        49, 1376, -1519264809, -5445294497914129669L, 80383L, false, false, (char) 8837, (char) 3932,
        Double.longBitsToDouble(0x3f9e580d361f87a0L), Double.longBitsToDouble(0x3fd0e38a85be3f10L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 5, 6, 14, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42",
        29, 51474, -493782251, 6408045103389998110L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=null\012",
        Z.run(T, 2, 10, 15, 14, "\udb6c\ude72\ud99b\udd2e\ud955\udda5\uda87\udf42\uda72\udc71\ud98f\udc6e\udb42\udfe5\u63c5\u0887\uda83\ude79\uda66\ude11\udb6c\udfcc\udb7e\udd85", "\u82c3\ua0bb\ua5cf\u7e8c\ucb6a\uc34e\u1046\u7dee\u4da0\u5acd", "\udbb3\udc62\ud9d7\udf94\ud848\ude94",
        58, 62519, -1325884437, 6752372902714169327L, -91760L, false, false, (char) 34200, (char) 45642,
        Double.longBitsToDouble(0x3feb60fd8328b00aL), Double.longBitsToDouble(0x3fd91683735036a2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.util.ArrayList:[\uccd5\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791]\012",
        Z.run(T, 2, 13, 9, 14, "\ud8e0\udc1d\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udbf2\udf16\udaa7\ude89\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\uccd5\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud97d\udf06\ud848\ude06\udbb2\udd3f\ud8df\udd67\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, -90514L, true, false, (char) 62680, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 15, 15, 14, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\ud81d\udd0c\ud899\udc21\ub634\ud9d8\udf33\udaa0\udfc6\udaa7\ude8f\uda63\udd60\ud9d0\udd21\uda4c\udd9f", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42",
        29, 96912, 1509326419, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 46942,
        Double.longBitsToDouble(0x3fb871456e04a3f8L), Double.longBitsToDouble(0x3fa6a9e0af7d0ce0L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=void\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 3, 6, 14, "\ud9bc\udff6\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\ud9ac\udd98\udb7f\ude9f\udb93\udfd1\udaa7\ude8f\uda78\udeaa\ud890\udc43\ud8b1\udc1f", "\ud6aa\u9c88\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\u34d6\u2791", "\udba5\udc5b\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\ud86b\udc8d",
        47, 70036, 1791543127, -1150943075229631268L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fccd4fbebdf4338L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 6, 14, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05", "\uadda\uaa94\u3c88\u3838\u0cb5\u7c76\u5b7b\u566c\uce76\u1546\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e", "\ud84e\ude6c\ud987\udeac\udacc\udf5c\udbcf\ude36\udbb3\udc62\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud99b\udd85\udad5\ude88\udb8f\ude5f\udae3\uddb6\ud8ba\udea0\ud990\ude96\ud90e\udfe5\ud901\udd8a\ud9e6\ude0c\uda45\ude29\ud880\uddb5\udb75\ude00\ud920\udf2d\ud94f\ude61\u4165\u0c5b\udaa6\uddff\ud907\udde5\udab9\udd23\uda85\udf13\ud82f\udcaa\ud9ba\udf43\ud98a\udf75\uda6c\udc3e\uda34\udd84\uda92\uddf2\ud927\udf70\udbd1\udd6b\u8dd1\uda0c\udea2\ud8ee\ude9a",
        -2, 2281, 1230126828, -6179290943154478445L, 66668L, true, false, (char) 53993, (char) 5314,
        Double.longBitsToDouble(0x3fe79b5dd8e91f79L), Double.longBitsToDouble(0x3fef07bb33e7d2b1L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=java.util.ArrayList:[]\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 6, 6, 14, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\uda80\udde7\u9091\ud9ab\udcbe\ud8ab\ude52\udab7\udefa\udb93\udf8b\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u440c\u9bce\ud1a9\u7e8c\ucb6a\uc0d5\u3b9e\ud75b", "\udacc\udf5c\udbcf\ude36\ud958\udd74\ud9d7\udfa7\ud848\ude94\udbb2\udd3f\ud8df\udd67\ud87e\udff3\ud97b\udf95\udb03\udd78\ud983\udcec\udb44\udd2e\ud90e\udfe5\udb03\udd06\udac1\udee9\uda45\ude29\ud84f\udef0\udb83\udfb7\ud920\udf5d\ud94f\ude61",
        23, 91607, -25172134, 4383792206806319446L, -79977L, true, false, (char) 6022, (char) 21124,
        Double.longBitsToDouble(0x3feff853260469f2L), Double.longBitsToDouble(0x3febf34291b3a95eL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=null\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 15, 4, 14, "\uda2d\ude30", "\u3b6a\ud666\uadd5\uaa94\u3c88\u3838\u0cb5\u7c76\u5b7b\uc662\u31c3\u816e\u6b0f\u9bce\u59ce\ua7f6\ud4dc\u601c\u27b9\ud747\ubf3f\u2791\ub2c0\u347d\ubdbc\u0e5c\u2208\u6c23\u8533\u8640\u4698\u9087\ub7f2\u2fbf\u0b98\u346c\u226d\u6c2c\u4028\u34a4", "\u4165\udaab\ude4e\uda82\udfbe\udb08\udc12\ucc53\ud889\udf82\udb3f\udcd3\uda42\udf24\udb0f\ude5b\ud9e6\udf7d\udbbe\udd48\ud9d3\udf39\udb8b\udc98\ud97e\udc56\ud926\udf4e\udb40\uddf7\udae9\uddc1\uda4d\udec4\udb62\udf5c\ud937\udd54\ud8d6\ude33\ud9ac\ude86\ud9ea\udcd2",
        14, 48834, 1955402848, -1699325141900920136L, 86870L, true, true, (char) 59945, (char) 56865,
        Double.longBitsToDouble(0x3fda7d1b0d5a503eL), Double.longBitsToDouble(0x3fd659a0ab099866L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 15, 12, 15, "\uda2d\ude30", "\uc4a3\ud666\uadd5\uaa94\u3c88\u3838\u0cb5\u7c76\u5b7b\uc662\u31c3\u15e1\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791\ub2c0\u347d\ubdbc\u0e5c\u2208\u6c23\u8533\u8640\u959f\u9087\ub7f2\u7dc2\uafa9\u84d6\u226d\u6c2c\u4028\u34a4", "\u4165\udaab\ude4e\uda82\udfbe\udb08\udc12\ucc53\ud889\udf82\udba6\udf87\ud8cc\ude32\udb0f\ude5b\ud9e6\udf7d\udbbe\udd48\ud9d3\udf39\udb8b\udc98\ud97e\udc56\udb8a\udec0\udb34\udfe9\udae9\uddc1\uda4d\udec4\udb62\ude8d\ud937\udd54\uda58\udd14\udae0\udc02\ud9ea\udc8e",
        14, 48834, 1955402848, -1699325141900920136L, 86870L, true, true, (char) 59945, (char) 56865,
        Double.longBitsToDouble(0x3fda7d1b0d5a503eL), Double.longBitsToDouble(0x3fd659a0ab099866L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\u3b6a\u18fd\uadd5\uaa94\u3c88\u3838\u0cb5\u7c76\u5b7b\ubc0c\u8183\uc6d5\u114c]\0121=java.util.ArrayList:[\u3b6a\u18fd\uadd5\uaa94\u3c88\u3838\u0cb5\u7c76\u5b7b\ubc0c\u8183\uc6d5\u114c]\012",
        Z.run(T, 2, 9, 9, 14, "\uda2d\ude30", "\u3b6a\u18fd\uadd5\uaa94\u3c88\u3838\u0cb5\u7c76\u5b7b\ubc0c\u8183\uc6d5\u114c", "\ud9a1\udeaf\ud861\udf6e",
        48, 14489, 1056853146, 2637764044349018844L, -1472L, false, true, (char) 25177, (char) 9896,
        Double.longBitsToDouble(0x3fdb43f714ceaadcL), Double.longBitsToDouble(0x3feb62e76761b0f8L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 4, 5, 10, "\ud87c\udff2\udb39\ude4f\udba9\ude03\ud871\udcf7\udbee\ude6e\udbb9\udc4b", "\u3dfc\u4a58\u45e1\u8ffb\u6bee\u2ee7\u1546\u3d22", "\ud9a1\udeaf\ud861\udf6e\ud94d\udc15\udb74\udca1",
        58, 52714, 1847755009, 483264789326008698L, -91932L, true, false, (char) 37411, (char) 27124,
        Double.longBitsToDouble(0x3fd68e7ebc1e2c9eL), Double.longBitsToDouble(0x3fd5f770683cb01aL)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 4, 4, 14, "\ud917\udee1\udb44\udfe1\ud9ad\ude05\ud990\ude6f\ud88d\udd73\u31fc\uda77\udff8\u8e77", "\ubfa4\ub6c5\u23a0\u3497\u15b1\u5922\ucf59\ub7de\u3217\u49ef\u86dc\u5871\u4225\u4d27\u441a\ub331\u55b5\ud7cf\ucca3\u7ca6\ubc18", "\ud907\udc9b\udae3\uddb6\uda26\udd87\ud9b1\udc7a\ud8da\ude56\udb03\udd06\uda95\udfb5\ud810\udf31",
        12, 19440, 1681991394, -105819811256311848L, -48553L, false, false, (char) 14461, (char) 31266,
        Double.longBitsToDouble(0x3fe1149b5cfded2fL), Double.longBitsToDouble(0x3fd8e74b10202fbeL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 14, 14, 0, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\ud949\udebd\uda14\udc67\ud899\udc21\uda77\udff8\udb78\udc70\udaaa\udca9", "\u5b7b\u5881\u2eaa", "\udaf8\ude60\udb9d\udd91\ud9a1\udeaf\ud861\udf6e\ud943\udd70\ue6e2\uda6c\udde0\ud806\udff8\ud9bc\udfab",
        29, 52240, 796241523, -589909908750520617L, 80383L, false, false, (char) 8837, (char) 55185,
        Double.longBitsToDouble(0x3f9e58a3361f87a0L), Double.longBitsToDouble(0x3fd0e38a853cec0eL)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=void |a1=[Ljava.lang.Object;:[[\u0cb5\u1d76\u5b7b\uc662\u76cf\u15d3\u82c3\u9bce\ud1a9]]\0121=void |a1=[Ljava.lang.Object;:[[\u0cb5\u1d76\u5b7b\uc662\u76cf\u15d3\u82c3\u9bce\ud1a9]]\012",
        Z.run(T, 2, 1, 1, 8, "\uda2d\ude30\ud99b\udd2e\ud9ad\ude05\ud97b\udfcc\uda5b\udd0b\ud899\udc21\uda77\udff8", "\u0cb5\u1d76\u5b7b\uc662\u76cf\u15d3\u82c3\u9bce\ud1a9", "\ud943\udd70\udb74\udca1\ud942\udc50\ud805\udf86\ud90b\udeae\udacc\udf5c\udbcf\ude36\ud9f9\udff8\ud923\udd3f\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42\ud907\udc9b\udae3\uddb6",
        59, 66414, -63046626, 4082602877720732942L, 50440L, false, true, (char) 55337, (char) 57285,
        Double.longBitsToDouble(0x3fe7ea1bde9d9f1eL), Double.longBitsToDouble(0x3fe43fd3ec20b91fL)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 3, 3, 11, "\uda2d\ude30\ud853\udd2a\ud9ad\ude05\uda80\udde7\uda5b\udd0b", "\u3c79\u3838\u0cb5\u7c76\u2e1a\uc65f", "\udb29\udd07\udaf8\ude60\udb9d\udd91\ud9a1\udeaf\ud861\udf6e\ud943\udd70\udb74\udca1\ud942\udc50\ud805\udf86\ud987\udeac",
        35, 60736, -671764801, 4526179267942405940L, -18234L, false, false, (char) 49028, (char) 13128,
        Double.longBitsToDouble(0x3fcc27fa26c3f0f4L), Double.longBitsToDouble(0x3fd0e38a85be3f10L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 11, 11, 14, "\uda2d\ude30\ud99b\udd77\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud9d7\udf94\ud848\ude94\udb10\udcbb\ud8df\udd67\ud8c6\udeda",
        39, 96912, -2128325805, 6344926899663141918L, -90514L, true, false, (char) 43841, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fa6a9efaf7e4ce0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=java.util.ArrayList:[]\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 8, 8, 14, "\udad2\udee3\udbca\udc7d\ud9e4\udf1e\ud868\udd54\uda5b\udd0b\ud899\udc21\ud9d0\udc35\udb91\uddb9\udbf4\udc4d\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u1b75", "\ud9a1\udeaf",
        22, 8292, -1947365511, 4539149700766499980L, -41037L, false, true, (char) 19779, (char) 32942,
        Double.longBitsToDouble(0x3fc14511f45295c4L), Double.longBitsToDouble(0x3fe73da373eb0f49L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=null\0121=null\012",
        Z.run(T, 2, 7, 7, 2, "\uda2d\ude7c\ud806\udd80\ud8d4\udc90\ud85f\udf8b\uda5b\udd0b\ud899\udc21\ucdc9\udb91\ude3c\udbf4\udc4d\uda94\udd8f\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\u50b0", "\ud9a1\udeaf",
        22, 8292, -1947365511, 4539149700766513260L, -41037L, false, true, (char) 9996, (char) 4102,
        Double.longBitsToDouble(0x3fe6bfbe85b43f71L), Double.longBitsToDouble(0x3fe73da373eb0f49L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\000\ud99b\udd23\ud9ad\ude05\uf6a6\udb64\uddf1\ud899\udc21, \ud9e8\udf94\udbf4\udc4d\udaa7\ude8f\uda88\udc03\uda66\udce9\000]\0121=java.util.ArrayList:[\000\ud99b\udd23\ud9ad\ude05\uf6a6\udb64\uddf1\ud899\udc21, \ud9e8\udf94\udbf4\udc4d\udaa7\ude8f\uda88\udc03\uda66\udce9\000]\012",
        Z.run(T, 2, 0, 0, 14, "\000\ud99b\udd23\ud9ad\ude05\uf6a6\udb64\uddf1\ud899\udc21,\ud9e8\udf94\udbf4\udc4d\udaa7\ude8f\uda88\udc03\uda66\udce9\000", "", "\u2267",
        7, 24920, 29604, 0L, -100000L, false, false, (char) 19489, (char) 44811,
        Double.longBitsToDouble(0x3ecea00000000000L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\uda1f\udd38\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda7b\udf1b\ud899\udc00\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa, \u2e77\u1546\u82ad\u9bce\ud1a9]\0121=java.util.ArrayList:[\uda1f\udd38\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda7b\udf1b\ud899\udc00\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa, \u2e77\u1546\u82ad\u9bce\ud1a9]\012",
        Z.run(T, 2, 12, 12, 1, "\uda1f\udd38\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda7b\udf1b\ud899\udc00\uda77\udff8\udb78\udc70\udb93\udfac\udaa7\ude8f\uda78\udeaa", "\u2e77\u1546\u82ad\u9bce\ud1a9", "\ud943\udd70\udb74\udca1\ud942\udc50\ud805\udf86\ud987\udeac\udacc\udf5c\udbc8\uddf4\udba3\udeee\ud9d7\udf94\ud848\ude94\udbb2\udd3f\ud8df\udd67\udad5\udf42\ud907\udc9b\udae3\uddb6",
        31, 66414, -63046626, 4082602140362089742L, 21785L, false, false, (char) 55295, (char) 50117,
        Double.longBitsToDouble(0x3fedb03eb9b26a33L), Double.longBitsToDouble(0x3fcd36ec50a1cf1cL)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 13, 13, 14, "\ud8e0\udc1d\ud99b\udd2e\ud9ad\ude05\uda80\udde7\uda5b\udd0b\ud899\udc21\uda77\udff8\udb78\udc70\udbf2\udf16\udaa7\ude89\uda78\udeaa\udb6c\udfcc\uda4c\udd8c", "\uccd5\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\ubf3f\u2791", "\udbb3\udc62\ud97d\udf06\ud848\ude06\udbb2\udd3f\ud8f5\udd59\udad5\udf42",
        29, 96912, 1509324115, 6344926899663141918L, 29901L, true, false, (char) 62680, (char) 50781,
        Double.longBitsToDouble(0x3fee58db49707f9eL), Double.longBitsToDouble(0x3fd2d53df5efa19cL)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.util.ArrayList:[]\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 0, 0, 0, "", "", "\uab14\ue57b\uda77\udff8\udb78\udc70\udbf2\udf16\udaa7\ude89\u00e0\udb6c\udfcc\ud8b3\udf40l\000\u565f\udaf8\ude60\ufa61\000\ud861\udf53\ud943\udd70\udbff\udf86\000",
        50, 87044, -843258285, 8668724632501988864L, -22615L, false, true, (char) 46421, (char) 0,
        Double.longBitsToDouble(0x3e130b0000000000L), Double.longBitsToDouble(0x3fd000000accb3ecL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 5, 5, 14, "\ud9bc\udff6\ud864\udd12\udbe5\ude01\uda80\udde7\uda5b\udd0b\ud899\udc21\ud9ac\udd98\udb7f\ude9f\udb93\udfd1\udaa7\ude8f\uda78\udeaa\ud890\udc43\udbad\udc1d", "\ud6aa\u9c88\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\u34d6\uc6fd", "\udb7f\ude5b\ud9d7\udf94\uda6a\ude98\ud8e6\udeb9\ud8b2\uddcc\ud86b\udc8d",
        47, 70036, 1791543127, -1150943075229631268L, -90514L, false, true, (char) 26269, (char) 50781,
        Double.longBitsToDouble(0x3fed40db49707f9eL), Double.longBitsToDouble(0x3fccd4fbebdf4338L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 4, 4, 14, "\uda2d\ude30", "\u3b6a\u1167\uadd5\uaa94\u3c88\u3838\u0cb5\u7c76\u5b7b\u3854\u8445\u8135\u6b0f\u9bce\u59ce\ua7f6\ud4dc\u601c\u27b9\ud747\ubf3f\u2791\ub2c0\u347d\ubdbc\u0e5c\u2208\u6c23\ubd70\u6d11\u3e00\u9021\u5418\u2fbf\u0b98\u346c\u226d\u6c2c\u4028\u840c", "\u4165\udaa9\ude4e\uda83\udc41\udb08\udc12\ucc53\ud889\udf82\udb3f\udcd3\uda42\udf24\udb0f\ude5b\ud9e6\udf7d\udbbe\udd48\ud9d3\udf39\udb8b\udc98\ud97e\udc56\ud926\udf4e\udb40\uddf7\udae9\uddc1\uda4d\udec4\udb62\udf5c\ud937\udd54\ud8d6\ude33\ud9ac\ude86\ud9ea\udcd2",
        14, 48834, 1955402848, -1699325141900920136L, 86870L, true, true, (char) 59945, (char) 56865,
        Double.longBitsToDouble(0x3fda7d1b0d5a503eL), Double.longBitsToDouble(0x3fd659a0ab099866L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=void\0121=void\012",
        Z.run(T, 2, 3, 3, 11, "\uda2d\ude30", "\ub823\u52a4,\uab63\u3c79\u3838\u0cb5\u7c76\u2e1a\uc65f\u2e77\u1546\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\u9a4f\u270d\ub2c0\u55b5", "\ud872\udef1\udbb2\udd3f\udabb\ude36\ud9f6\udcd0\ud907\udca0\udae3\uddb6\uda65\udde3\udb26\ude4b\ud90f\udca8\udb03\udd06\udac1\udee9\uda96\udfd1\udaa9\udd48\u8bfa\udb03\ude29\udb14\ude08\ud91e\udd0f\uda42\ude8e\udb1c\udce9\ud861\ude02\ud9a6\udc56\ud9ec\udd0b\udbef\udfef\udb0c\udd43\udaaa\ude73\ud920\udd26\ud90d\udee4\uda6f\udefc\ud9ca\udc85\ud923\udd54\ud918\udc01\ud9a8\udfc1\ud974\udea0\ud9a1\uddb4\ud953\udfd8\ud945\uddf1\uda60\udeb5\ud8be\udc8f\ud8ef\udfcc\uda15\udcf0\ud911\udc85\ud8c6\udd36\uda73\udfa5\ud856\udec2",
        56, 83881, 665575458, -3687982239376837265L, -66186L, false, true, (char) 29725, (char) 21031,
        Double.longBitsToDouble(0x3fbb36f5bc084da8L), Double.longBitsToDouble(0x3fd2e89b2811e596L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=java.util.ArrayList:[]\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 12, 0, 0, "", "", "\uab7a\ue57b\uda77\udff8\udb78\udc70\udbf2\udf16",
        -3, -776, 829448419, 58378793215066220L, -50011L, false, false, (char) 15127, (char) 0,
        Double.longBitsToDouble(0x3e4811f128000000L), Double.longBitsToDouble(0x3febcbefb00000edL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=java.util.ArrayList:[]\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 0, 10, 0, "", "", "\uab14\ue57b\uda77\udff8\ud922\udc75\udbf2\udf16\udaa7\ude89\u00e0\udb6c\udfcc\ud8b3\udf40l\000\u565f\udaf8\ude60\ud847\udea6\ud8dc\ude05\ud8f6\udf37\ud847\uddc9\udb38\udee6\ud806\udda1",
        45, 87044, -843258285, 8668724631160139264L, -22615L, false, true, (char) 46558, (char) 0,
        Double.longBitsToDouble(0x3e130b0000000000L), Double.longBitsToDouble(0x3fd000000accb3ecL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 5, 0, 0, "", "", "\ud953\udc50\udae6\ude1c\ud8dd\udf5f\uda88\udcf8\udbf2\udf16\udaa7\ude89\uda10\udd69\ud99e\udf90\udb37\udd0el\000\u565f\udaf8\ude60\ufa61\000\ud861\udf53\ud943\udd70\uda5c\udd85\000",
        50, 85803, -843258285, -7580286548450103649L, -22615L, false, true, (char) 42876, (char) 45047,
        Double.longBitsToDouble(0x3f1552130b000000L), Double.longBitsToDouble(0x3fd000000accb3ecL)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 4, "\u00b4\ud884\udca2\udb8b\udc2d\uda80\uddd1\ud9f3\udc98\ud850\udd48\udaf6\uddb3\ud9ee\udc53\ud81f\udca2\uda5c\udfc6\u00e0\udaec\udd33\ud81f\udea2\udb21\udfb8\ud8ca\ude02", "\u4e18\ua698", "\udb38\udee6\ud806\udda1",
        59, 86833, -843258285, 8668832387063650560L, -58716L, false, false, (char) 59899, (char) 0,
        Double.longBitsToDouble(0x3fd000000b9c6728L), Double.longBitsToDouble(0x3fe225f99d42f17cL)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=java.lang.Boolean:true\0121=java.lang.Boolean:true\012",
        Z.run(T, 2, 10, 10, 0, "", "", "\uab14\ue57b\uda77\udff8\ud922\udc75\udbf2\udf16\ud82b\udde4\udb93\udc9f\udb6c\udfcc\ud8b3\udf40l\000\udafd\udfb2\ud984\ude33\uda3d\udc09\ud8dc\ude05\ud8f6\udf37\ud847\uddc9\udb38\udee6\ud806\udda1",
        35, 23878, -843258285, -8192752370105257184L, 42189L, false, true, (char) 46558, (char) 0,
        Double.longBitsToDouble(0x3fbbc00004c2c000L), Double.longBitsToDouble(0x3fd000000accb3ecL)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void\0121=java.util.ArrayList:[]\012",
        Z.run(T, 2, 3, 6, 14, "\udb6b\udc01\udb98\ude3b\ud977\udf3a\uda80\ude34\uda5b\udd0b\ud899\udc21\uda77\udff8\udac2\ude95\udb93\udfac\udaa7\ude8f\uda78\udeaa\udb6c\udfcc\udaca\udfa7", "\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u92f1\ud742\uc6a6\ubf17", "\udbb3\udc62\ud9d7\udf94",
        12, 20628, 712012519, -5694630295346266271L, 31685L, false, true, (char) 59434, (char) 35350,
        Double.longBitsToDouble(0x3fba2d87eb9e6120L), Double.longBitsToDouble(0x3fdd1ea3684edfd0L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=java.lang.Integer:1\0121=java.lang.Integer:1\012",
        Z.run(T, 2, 5, 5, 9, "", "", "\ud953\udc50\udae6\ude1c\ud8dd\udf5f\uda88\udcf8\udbf2\udf16\udaa7\ude89\uda10\udd69\ud99e\udf90\udb37\udd0el\000\u565f\udaf8\ude60\ufa61\ud8c6\ude58\ud836\udff8\uda35\ude48\ud984\ude54\u023a",
        50, 85803, -843258285, -7580286548450103649L, -22615L, false, true, (char) 42876, (char) 51952,
        Double.longBitsToDouble(0x3feefcfd40985800L), Double.longBitsToDouble(0x3fd000000accb3ecL)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=void\012",
        Z.run(T, 2, 10, 3, 11, "\uda33\udeb4", "\ub823\u52a4,\uab63\u3c79\u3838\u0cb5\u7c76\u2e1a\uc65f\u2e77\u1546\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\u9a4f\u270d\ub2c0\u55b5\u374a\u5282\uca65\u6c23\u349b\u17a0\u2089\u7073\uc120", "\udb03\udd06",
        20, 28007, 1633278988, -4561187969586685204L, 85046L, true, false, (char) 49396, (char) 15578,
        Double.longBitsToDouble(0x3fe89ffe7f431570L), Double.longBitsToDouble(0x3fe98cb4175484e8L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=java.lang.Boolean:false\0121=java.lang.Boolean:false\012",
        Z.run(T, 2, 10, 10, 10, "\uda33\udeb4", "\ub823\u52a4,\uab63\u3c79\u3838\u0cb5\u7c76\u161b\uc640\u2e77\u1546\u82c3\u9bce\ud1a9\u7e8c\ucb6a\uc34e\u35e7\ud742\u9a4f\u270d\ub2c0\u55b5\u374a\u5282\uca65\u6c23\u349b\u17a0\u2089\u7073\uc120", "\udb03\udd06",
        20, 28007, 1633278988, -4561187969586685204L, 85046L, true, false, (char) 39084, (char) 21702,
        Double.longBitsToDouble(0x3fe8a16ccf4315d8L), Double.longBitsToDouble(0x3fe98cb4175484e8L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=java.util.ArrayList:[\uda26\ude4e, \uab63, \u1237\u538d]\0121=java.util.ArrayList:[\uda26\ude4e, \uab63, \u1237\u538d]\012",
        Z.run(T, 2, 12, 12, 11, "\uda26\ude4e", "\u1237\u538d,\uab63", "\ud9a0\udeeb",
        22, 36587, 667903793, -3280401271990109174L, -49282L, true, false, (char) 13364, (char) 16372,
        Double.longBitsToDouble(0x3fe3e9c417797df6L), Double.longBitsToDouble(0x3f6caf686c3efe00L)));
  }
  @Test(timeout = 4000)
  public void test53() throws Throwable {
    assertEquals("0=java.util.ArrayList:[, , \uda26\ude4e\ud864\udf17\uda8b\ude27]\0121=java.util.ArrayList:[, , \uda26\ude4e\ud864\udf17\uda8b\ude27]\012",
        Z.run(T, 2, 12, 12, 11, "\uda26\ude4e\ud864\udf17\uda8b\ude27", ",", "\udb69\udeb2\ud9a0\udeeb\uda78\udeaa\ud964\udf88\uda4c\udd89\ud88e\uddbd\ud8a0\ude11\udb29\udd07",
        1, 3473, 991987151, 4071822323789241981L, 11613L, false, false, (char) 63362, (char) 48889,
        Double.longBitsToDouble(0x3fa74cabd5e5e1c0L), Double.longBitsToDouble(0x3fef41d04683b795L)));
  }
  @Test(timeout = 4000)
  public void test54() throws Throwable {
    assertEquals("0=java.util.ArrayList:[, , \ud8c0\ude5b\ud84c\udc17\ud9d5\udda6]\012",
        Z.run(T, 1, 12, 12, 11, "\ud8c0\ude5b\ud84c\udc17\ud9d5\udda6", ",", "\udb69\udeb2\ud90b\udc69\udbe5\udce0\ud953\udf8a\udb18\udcd0\ud876\ude14\ud8a0\ude11\udb29\udd07",
        1, 86165, 991987151, 4071822323789241981L, 11613L, false, false, (char) 63362, (char) 56740,
        Double.longBitsToDouble(0x3fa74caba5e5e1c0L), Double.longBitsToDouble(0x3fd025ce1cc46658L)));
  }
  @Test(timeout = 4000)
  public void test55() throws Throwable {
    assertEquals("0=java.lang.Integer:0\0121=java.lang.Integer:0\012",
        Z.run(T, 2, 5, 5, 11, "\udb3c\ude59\udaed\udf22\uda8b\ude27", ",", "\ud891\udcbb\ua5d3\uda78\udeaa\ud964\udf88\uda4c\udd89\udb3a\udfb2\ud87a\udf5f\udb29\udd07",
        1, 3473, 991987151, 4071822323789241981L, 11613L, false, false, (char) 63362, (char) 48889,
        Double.longBitsToDouble(0x3fddd9957abcbc38L), Double.longBitsToDouble(0x3fef41d04083b795L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.CollectionUtils|removeAll|java.util.Collection,java.util.Collection|static",
    "M|org.apache.commons.collections.CollectionUtils|addAll|java.util.Collection,[Ljava.lang.Object;|static",
    "M|org.apache.commons.collections.CollectionUtils|addAll|java.util.Collection,java.util.Enumeration|static",
    "M|org.apache.commons.collections.CollectionUtils|addAll|java.util.Collection,java.util.Iterator|static",
    "M|org.apache.commons.collections.CollectionUtils|addIgnoreNull|java.util.Collection,java.lang.Object|static",
    "M|org.apache.commons.collections.CollectionUtils|cardinality|java.lang.Object,java.util.Collection|static",
    "M|org.apache.commons.collections.CollectionUtils|collect|java.util.Collection,org.apache.commons.collections.Transformer|static",
    "M|org.apache.commons.collections.CollectionUtils|collect|java.util.Collection,org.apache.commons.collections.Transformer,java.util.Collection|static",
    "M|org.apache.commons.collections.CollectionUtils|collect|java.util.Iterator,org.apache.commons.collections.Transformer|static",
    "M|org.apache.commons.collections.CollectionUtils|collect|java.util.Iterator,org.apache.commons.collections.Transformer,java.util.Collection|static",
    "M|org.apache.commons.collections.CollectionUtils|containsAny|java.util.Collection,java.util.Collection|static",
    "M|org.apache.commons.collections.CollectionUtils|countMatches|java.util.Collection,org.apache.commons.collections.Predicate|static",
    "M|org.apache.commons.collections.CollectionUtils|disjunction|java.util.Collection,java.util.Collection|static",
    "M|org.apache.commons.collections.CollectionUtils|exists|java.util.Collection,org.apache.commons.collections.Predicate|static",
    "M|org.apache.commons.collections.CollectionUtils|filter|java.util.Collection,org.apache.commons.collections.Predicate|static",
    "M|org.apache.commons.collections.CollectionUtils|find|java.util.Collection,org.apache.commons.collections.Predicate|static",
    "M|org.apache.commons.collections.CollectionUtils|removeAll|java.util.Collection,java.util.Collection|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
