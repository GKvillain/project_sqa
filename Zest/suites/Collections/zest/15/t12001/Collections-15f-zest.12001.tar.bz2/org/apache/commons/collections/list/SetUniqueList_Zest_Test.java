package org.apache.commons.collections.list;
import org.junit.Test;
import static org.junit.Assert.*;
public class SetUniqueList_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\0121=org.apache.commons.collections.set.UnmodifiableSet:[\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39] |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\012",
        Z.run(T, 2, 15, 5, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud94d\udd3e\udbf6\udc3a\udb5e\udebe\udb6b\udd70\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\0121=org.apache.commons.collections.set.UnmodifiableSet:[\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39] |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud94d\udd3e\udbf6\udc3a\udb5e\udebe\udb6b\udd70\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\012",
        Z.run(T, 2, 15, 5, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud94d\udd3e\udbf6\udc3a\udb5e\udebe\udb6b\udd70\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 49993, 1732679919, -3302081331597845605L, 53793L, true, true, (char) 60279, (char) 32253,
        Double.longBitsToDouble(0x3fdc86a94cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udae5\ude42\udb74\udcda\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf", "\u2599\uaaf6\u94c1\u5e64\u9624\u0fa9", "\ud8c6\ude0e",
        19, 20818, 1872776507, 8889946851537986137L, -23334L, false, true, (char) 5830, (char) 4000,
        Double.longBitsToDouble(0x3fd72f4539db1d42L), Double.longBitsToDouble(0x3fdab6987855a662L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udab4\uded3\uda0c\ude99\ud89b\uddcb\uda46\udcda\uda0e\udc9e\ud8ec\udeda\uda18\udc47\udb74\udc7f\ud9e8\udc89\ud8dd\ude98\udb99\udd6e\udb0d\udfc9\ud931\udff0\udb08\udd5a\ud83b\udccf]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 15, 13, 0, "\udab4\uded3\uda0c\ude99\ud89b\uddcb\uda46\udcda\uda0e\udc9e\ud8ec\udeda\uda18\udc47\udb74\udc7f\ud9e8\udc89\ud8dd\ude98\udb99\udd6e\udb0d\udfc9\ud931\udff0\udb08\udd5a\ud83b\udccf", "\u2f7d\u7c2e\u9509\u25bf\ub484\ud1e5", "\ud8c6\ude88",
        19, 65626, 1872776669, 8889946847758192217L, 88815L, false, false, (char) 5510, (char) 58254,
        Double.longBitsToDouble(0x3fdab6987786cec2L), Double.longBitsToDouble(0x3fec433fca52c3f2L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc79\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 15, 15, 15, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc79\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1", "\u5a41\ud1e5\u0e4b\u4384\u14de\ud3d0\u18f9\ub187\uc1c7\u44c4\u93ec\ub4c2\u9497\u1838\u884b\uab14\ua1ff", "\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc\udb7e\udfb5\ud993\udfbe\ud850\ude90\ud9fb\udf3c\ud81c\udf26\ud8d6\ude7d\udb11\udfb6\ud8d1\udd75\udaad\ude5c\ud8fd\udc9e\uda24\ude1d",
        7, 36771, -2140003881, -7586543982037356601L, -37354L, true, false, (char) 51025, (char) 54608,
        Double.longBitsToDouble(0x3f42bf3580c15000L), Double.longBitsToDouble(0x3fd7aed2a3304698L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u630b\udbee\ude0b\uda0e\udc9e\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\ude67\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ub893\ud8be\udc9f\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 0, 13, "\ubd2c\u00a7\u630b\udbee\ude0b\uda0e\udc9e\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\ude67\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ub893\ud8be\udc9f\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u86a2\u2181\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud987\udc02\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 18808, (char) 63743,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud863\udfe8\udb96\ude61\udb0c\udcd3\uda5b\udc88\uda49\udcfe\udb9e\udc33\udac8\udf01\udb74\udcbf]\0121=org.apache.commons.collections.set.UnmodifiableSet:[\u88b5\u6a7e\u5d4c\u9a88\ud63f\ub01a\u6853\u6f60\uaaf6\u94c1\u0d81\u5a41\ud1e5\u1f45\u7e83] |this=org.apache.commons.collections.list.SetUniqueList:[\ud863\udfe8\udb96\ude61\udb0c\udcd3\uda5b\udc88\uda49\udcfe\udb9e\udc33\udac8\udf01\udb74\udcbf]\012",
        Z.run(T, 2, 10, 5, 13, "\ud863\udfe8\udb96\ude61\udb0c\udcd3\uda5b\udc88\uda49\udcfe\udb9e\udc33\udac8\udf01\udb74\udcbf", "\u88b5\u6a7e\u5d4c\u9a88\ud63f\ub01a\u6853\u6f60\uaaf6\u94c1\u0d81\u5a41\ud1e5\u1f45\u7e83", "\ud8f3\uddf9",
        33, 77168, -1834283295, -3919138401446341498L, 25517L, true, false, (char) 37993, (char) 7453,
        Double.longBitsToDouble(0x3fde93869855a662L), Double.longBitsToDouble(0x3fda7eb974a5864aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 1, 0, 5, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\uda62\ude46\ud9b8\ude5b\udb7f\udecd\udb5a\udf4c\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\u009a\000\udbfe\udfbc\ud8b3\uded8\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\ud855\udfe9\udbbb\udddc\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39", "\udad6\udddd\uda61\udfcb\000\ua1d5\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 49856, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc832460dccd70L), Double.longBitsToDouble(0x3fa8ca804ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\ud8c7\udd61\udbf1\udf00\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud905\uddd7\udb75\udced\ud88e\ude67\ud86f\udf06\ud981\udec4\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\udaab\udecc\ud9b2\udd6b\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 3, 5, "\ubd2c\uda37\udfad\ud8c7\udd61\udbf1\udf00\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud905\uddd7\udb75\udced\ud88e\ude67\ud86f\udf06\ud981\udec4\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\udaab\udecc\ud9b2\udd6b\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u486a\u0271\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.apache.commons.collections.set.UnmodifiableSet:[\u081f\u36ab\u7cc8\u6e58\u86a2\u08ef\u0b17\u324d\u2d39] |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc7d\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud81f\udea6\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud9dd\udf99\udbc4\udddb\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\uddfb\u7d75\ud95b\udd51\udbc5\udc70\udbdf\ude4e]\0121=org.apache.commons.collections.set.UnmodifiableSet:[\u081f\u36ab\u7cc8\u6e58\u86a2\u08ef\u0b17\u324d\u2d39] |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc7d\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud81f\udea6\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud9dd\udf99\udbc4\udddb\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\uddfb\u7d75\ud95b\udd51\udbc5\udc70\udbdf\ude4e]\012",
        Z.run(T, 2, 5, 5, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc7d\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud81f\udea6\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud9dd\udf99\udbc4\udddb\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\uddfb\u7d75\ud95b\udd51\udbc5\udc70\udbdf\ude4e", "\u081f\u36ab\u7cc8\u6e58\u86a2\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda68\udd3d\udb94\udd0b\ua202\ud8f3\udce2\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\uda5d\udc16\uda0f\udf8e",
        53, 49993, -1857644305, -2857657396320410083L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac25d4413c0L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\uda40\udc44\udb8d\ude1d\udb83\udee7\ud89b\udf7c\ud8a7\udd74\udb03\ude64\ud865\udd91\ud923\udd3e\udb08\udd5a\ud83b\udccf\ud9d5\udd5f\udb6d\udf32\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\udb88\udc45\uda20\udc29\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbda\udcc5\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud9a4\udef2\udba3\ude10\udb94\udeef\ud8c5\udfe5\udb13\udc1f\udbdf\udea8]\0121=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 15, 6, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\uda40\udc44\udb8d\ude1d\udb83\udee7\ud89b\udf7c\ud8a7\udd74\udb03\ude64\ud865\udd91\ud923\udd3e\udb08\udd5a\ud83b\udccf\ud9d5\udd5f\udb6d\udf32\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\udb88\udc45\uda20\udc29\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbda\udcc5\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud9a4\udef2\udba3\ude10\udb94\udeef\ud8c5\udfe5\udb13\udc1f\udbdf\udea8", "\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39", "\udb06\udf16\udb35\uddae\udbb1\udc87\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 23969, -1333642984, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud857\uddef\uda27\ude43\ud849\udd58\ud8c7\udfae\udbbe\udcdc\uda75\ude16\udac8\ude86\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\udab5\udd08\udbd8\udc07\ud9c0\ude57\ud850\udc81\udb8f\udfbd\uda74\uddf2\udb7f\udf14\udbea\udfe1\udaee\uddf5\udabb\udd32\u9907\ud816\ude6f\udba4\udd3f\udbfe\udfbc\udab3\uddf7\ud8d2\udf17\ud8f3\uddf9\udaba\udfcd\ud8e9\uded4\uda1f\udfe7\udada\udd61\uda96\udd6c\udbc4\ude80\udbde\udd59\udb9c\udc71\uda9a\udec3\ud808\udf25\udb53\udf05\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\ud856\udd46\udb92\ude07]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud857\uddef\uda27\ude43\ud849\udd58\ud8c7\udfae\udbbe\udcdc\uda75\ude16\udac8\ude86\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\udab5\udd08\udbd8\udc07\ud9c0\ude57\ud850\udc81\udb8f\udfbd\uda74\uddf2\udb7f\udf14\udbea\udfe1\udaee\uddf5\udabb\udd32\u9907\ud816\ude6f\udba4\udd3f\udbfe\udfbc\udab3\uddf7\ud8d2\udf17\ud8f3\uddf9\udaba\udfcd\ud8e9\uded4\uda1f\udfe7\udada\udd61\uda96\udd6c\udbc4\ude80\udbde\udd59\udb9c\udc71\uda9a\udec3\ud808\udf25\udb53\udf05\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\ud856\udd46\udb92\ude07]\012",
        Z.run(T, 2, 15, 11, 13, "\ud857\uddef\uda27\ude43\ud849\udd58\ud8c7\udfae\udbbe\udcdc\uda75\ude16\udac8\ude86\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\udab5\udd08\udbd8\udc07\ud9c0\ude57\ud850\udc81\udb8f\udfbd\uda74\uddf2\udb7f\udf14\udbea\udfe1\udaee\uddf5\udabb\udd32\u9907\ud816\ude6f\udba4\udd3f\udbfe\udfbc\udab3\uddf7\ud8d2\udf17\ud8f3\uddf9\udaba\udfcd\ud8e9\uded4\uda1f\udfe7\udada\udd61\uda96\udd6c\udbc4\ude80\udbde\udd59\udb9c\udc71\uda9a\udec3\ud808\udf25\udb53\udf05\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\ud856\udd46\udb92\ude07", "\ub01f\u9021\uc2f0\u9d2f\u86a2\u5ae3\ucc45\u324d\u2d39\ua656\u42eb\u5aa9\u49a9\ud068\u472f\u2487\u7c00\u9cd9\u032e\uc947\uaf0d\u2f50\u1786\u58dc\u1d19\ua99f\u0e2b\ua852\u86e2\ub5f6\u11c1\ud493\ud6a7\u9039", "\uda74\ude57\udb8c\udc9c\udb3d\udc44\udb57\udd8c\ud8e0\udd10\ud959\udcfa\ud933\udc7e\udb88\udfea",
        8, 66753, -471799296, -8951655108943525802L, 8798L, true, true, (char) 42578, (char) 19090,
        Double.longBitsToDouble(0x3fc6ccd34bf81b90L), Double.longBitsToDouble(0x3feec0adcb33123cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\012",
        Z.run(T, 2, 6, 1, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        55, 50094, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 7, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\ud8c4\udf26\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udeb1\ud923\udd3e\udb08\udd5a\uda29\udcc6\ud96c\udcf6\ud985\ude6a\udb7f\udf53\udbea\udfe1\udaee\uddf5\ud933\uddac\ud8dc\ude0b\ud816\ude6f\ud8a6\udd40\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda84\udd37\ud801\udc67\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u08cf\u36ab\uc269\u207f\u21b4\u08ef\u0b17\u324d\u2d13", "\ud80a\ude9a\uda0a\udc80\udadc\udd2e\udad9\udff2\ud900\udc50\ud9f4\udff8\ud9a3\udde7\ud9a4\udf08\uda80\uddd7\ud86e\udce1\uda0f\udf8e",
        22, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 54984, (char) 30376,
        Double.longBitsToDouble(0x3fe62817a6de397dL), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb51\udcaa\ud87e\udcf1\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 12, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb51\udcaa\ud87e\udcf1\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u3943", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\udefc\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\udefc\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc, \ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\udefc\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\012",
        Z.run(T, 2, 15, 4, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\udefc\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u86a2\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        34, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\ud825\ude04\ud8db\uddd4\udb5b\udc37\ud8fc\udf85\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d6\udc17\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\udac2\udd1c\ud8a5\ude3c\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\0121=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\ud825\ude04\ud8db\uddd4\udb5b\udc37\ud8fc\udf85\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d6\udc17\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\udac2\udd1c\ud8a5\ude3c\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\012",
        Z.run(T, 2, 15, 9, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\ud825\ude04\ud8db\uddd4\udb5b\udc37\ud8fc\udf85\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d6\udc17\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\udac2\udd1c\ud8a5\ude3c\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u8698\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\ud85a\udc13",
        22, 49993, -1857644305, -3290002960143524965L, 53793L, false, false, (char) 43282, (char) 10047,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udbee\ude55\ud8a5\ude25\ud8b6\udf2e\ud816\ude6f\ud89d\udd5c\udbc1\udc02\udb48\udfd1\uda93\uddbd\ud8f3\ude87\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\u688d\udb0b\udcde\ud947\udf3f\udb83\udce1\ud89e\ude31\ud82c\udef6\udba3\ude10\udae9\ude4d\u5e8e\udaa7\ude73\udbdf\uded0]\012",
        Z.run(T, 1, 9, 13, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udbee\ude55\ud8a5\ude25\ud8b6\udf2e\ud816\ude6f\ud89d\udd5c\udbc1\udc02\udb48\udfd1\uda93\uddbd\ud8f3\ude87\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\u688d\udb0b\udcde\ud947\udf3f\udb83\udce1\ud89e\ude31\ud82c\udef6\udba3\ude10\udae9\ude4d\u5e8e\udaa7\ude73\udbdf\uded0", "\u081f\u36ab\uc269\u9d2f\ud46d\u762c\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9c1\udfc4\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 1, 9, 9, 11, "\uda98\udccc\uda2c\udc2b\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udae5\ude42\udb74\udcda\ud9e8\udc89\udb75\udceb\ud8c5\udfe2\udbaa\uddcc\udb78\udc14\udb08\udd5a\ud83b\udccf", "\u2599\uaaf6\u94c1\u5e64\u9624\u0fa9", "\ud8c6\ude0e",
        19, 20818, 1872776507, 8889946851537986137L, -23334L, false, true, (char) 5830, (char) 4000,
        Double.longBitsToDouble(0x3fd72f453430294eL), Double.longBitsToDouble(0x3fe0fd14cc93a453L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 9, 3, 13, "\ubd2c\uda37\udfad", "\u4e47\u654f\u4281\u8444\uc992\u4243", "\ud923\udd3e\udb08\udd5a\ud83b\udccf",
        27, 51832, -732980895, 4035859223820549751L, 62727L, true, true, (char) 9515, (char) 14924,
        Double.longBitsToDouble(0x3fdd05ff509fe588L), Double.longBitsToDouble(0x3fec7a400a597b5fL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ud82c\udd9c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 15, 14, 8, "\ud82c\udd9c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33", "\uad0a\u4243\u88b5\u6a7e\u5d4c\u987e\u869d\uba07\u6853\u2599\uaaf6\u94c1\u5e64", "\ud83b\udcd5\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf",
        37, 97225, -912495379, 7796527577668589538L, -46274L, false, true, (char) 58254, (char) 56114,
        Double.longBitsToDouble(0x3fa56998b020afb0L), Double.longBitsToDouble(0x3fbc20674a95db58L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\udab4\uded3\uda0c\ude99\ud89b\uddcb\uda46\udcda, \ud87a\ude85\udb4e\udfb3\udb97\udda6\ud939\udf5c\ud83b\udcbe\ud8f4\udcaf\ud93b\udecf\ud8cf\udf98\udb6c\udc3c\udaee\ude3d\u563a\ud966\udd66\ud816\ude6f\udba4\udd29\ud9d7\ude49]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud87a\ude85\udb4e\udfb3\udb97\udda6\ud939\udf5c\ud83b\udcbe\ud8f4\udcaf\ud93b\udecf\ud8cf\udf98\udb6c\udc3c\udaee\ude3d\u563a\ud966\udd66\ud816\ude6f\udba4\udd29\ud9d7\ude49]\012",
        Z.run(T, 2, 1, 13, 0, "\udab4\uded3\uda0c\ude99\ud89b\uddcb\uda46\udcda", "\u73f8\u511b", "\ud87a\ude85\udb4e\udfb3\udb97\udda6\ud939\udf5c\ud83b\udcbe\ud8f4\udcaf\ud93b\udecf\ud8cf\udf98\udb6c\udc3c\udaee\ude3d\u563a\ud966\udd66\ud816\ude6f\udba4\udd29\ud9d7\ude49",
        59, 51659, 965074266, -5131754024158138481L, 37186L, true, false, (char) 62786, (char) 5721,
        Double.longBitsToDouble(0x3fcdb1d426ada61cL), Double.longBitsToDouble(0x3fe669bb0f88146cL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\udab4\uded3\uda0c\ude99\ud89b\uddcb\udbc2\ude79\ud8b1\uddf4\ud8ec\udeda\uda18\udc47\udb74\udc7f\ud9e8\udc89\ud8dd\ude98\udbd4\udfa4\udb2f\udcd6\ud931\udff0\udb08\udd5a\ud83b\udccf]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 13, 13, 3, "\udab4\uded3\uda0c\ude99\ud89b\uddcb\udbc2\ude79\ud8b1\uddf4\ud8ec\udeda\uda18\udc47\udb74\udc7f\ud9e8\udc89\ud8dd\ude98\udbd4\udfa4\udb2f\udcd6\ud931\udff0\udb08\udd5a\ud83b\udccf", "\u2f7d\u7b6e\u9509\u25bf\ub484\ud1e5\u1a48\u85e2\u1558\u4468\u3acf\u4c8b\u3a40\u8c45\ubc62\u4227\u1d61\u5588\u3890\u1ce7\u3af7\u0432\u6efe\u374a\ub52a", "\ud80c\udee1\ud9d4\udebd\ud918\udffd",
        37, 69656, -933792364, -6271366137918857390L, -33381L, true, false, (char) 63470, (char) 13603,
        Double.longBitsToDouble(0x3fdcf6d655ef6aceL), Double.longBitsToDouble(0x3fe290e481bcba2dL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\0121=java.lang.String:\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13 |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\012",
        Z.run(T, 2, 15, 0, 13, "\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13", "\u081f\u36ab\uc269\u9d2f\u86a2\u2181\u00ca\u3166\u0cee", "\u21d7\udb40\uddc0\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud987\udc02\ud9a4\udf08\ud852\uded9`\000",
        0, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 18808, (char) 63743,
        Double.longBitsToDouble(0x3eb1800000000000L), Double.longBitsToDouble(0x3fa880004ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud873\udd2d\u00a7\u630b\udbee\ude0b\uda0e\udc9e\u009e\000\udb97\udf2a\ud9e2\ude0e\udb40\udceb\ud88e\ude67\u00ae\udb64\ude68\ud947\udce7\ud83b\udccf\udb57\udd86\ud86c\udf13\udb94\udd57\ud965\udfe4\udaee\uddf5\udb93\ude1d\ud8dc\ude0b\ud816\ude6f\ud9b2\ude06\udb90\udd5b\ud8c6\ude0e\ub893\udb6c\udcd0\udbc2\udebe\ud8d8\udee0\udbb8\udfb9\uda6c\udc44\ud93b\ude54\udbc4\ude80\udbf6\udc29\udbcf\ude43\ud893\udfd7\ud808\udf25\000\ud96c\udcf6\udba3\ude10\udbb2\uddef\u0a8e\uda98\udf6c\udbdf\udebc]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud873\udd2d\u00a7\u630b\udbee\ude0b\uda0e\udc9e\u009e\000\udb97\udf2a\ud9e2\ude0e\udb40\udceb\ud88e\ude67\u00ae\udb64\ude68\ud947\udce7\ud83b\udccf\udb57\udd86\ud86c\udf13\udb94\udd57\ud965\udfe4\udaee\uddf5\udb93\ude1d\ud8dc\ude0b\ud816\ude6f\ud9b2\ude06\udb90\udd5b\ud8c6\ude0e\ub893\udb6c\udcd0\udbc2\udebe\ud8d8\udee0\udbb8\udfb9\uda6c\udc44\ud93b\ude54\udbc4\ude80\udbf6\udc29\udbcf\ude43\ud893\udfd7\ud808\udf25\000\ud96c\udcf6\udba3\ude10\udbb2\uddef\u0a8e\uda98\udf6c\udbdf\udebc]\012",
        Z.run(T, 2, 10, 11, 12, "\ud873\udd2d\u00a7\u630b\udbee\ude0b\uda0e\udc9e\u009e\000\udb97\udf2a\ud9e2\ude0e\udb40\udceb\ud88e\ude67\u00ae\udb64\ude68\ud947\udce7\ud83b\udccf\udb57\udd86\ud86c\udf13\udb94\udd57\ud965\udfe4\udaee\uddf5\udb93\ude1d\ud8dc\ude0b\ud816\ude6f\ud9b2\ude06\udb90\udd5b\ud8c6\ude0e\ub893\udb6c\udcd0\udbc2\udebe\ud8d8\udee0\udbb8\udfb9\uda6c\udc44\ud93b\ude54\udbc4\ude80\udbf6\udc29\udbcf\ude43\ud893\udfd7\ud808\udf25\000\ud96c\udcf6\udba3\ude10\udbb2\uddef\u0a8e\uda98\udf6c\udbdf\udebc", "\u081f\u5f42\u82d9\u33d7\u3c8b\u96e8\u0b17\u324d\ub5b1", "\uda7e\ude52\uda8f\udc50\udb71\uded9\udb56\udd80\ud9ec\udc98\ud9f5\udc10\ud987\udc02\ud9d8\ude62\ud84e\udcd9\udb77\udc43\ud907\udce7",
        1, 49993, 1640418799, -3290003065844833634L, -94376L, false, true, (char) 18673, (char) 17318,
        Double.longBitsToDouble(0x3fe854d1ee0349dbL), Double.longBitsToDouble(0x3fe9bfac24054e8fL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u630b\udbee\ude0b\uda0e\udc9e\u009e\000\udb7f\udf1a\ud9f8\udf7b\ud9d5\udc19\ud875\udd38\u6e51\udb28\udff1\udb08\udd5a\ud83b\udccf\ud821\udd26\ud8ac\udc3c\uda13\ude61\udad2\ude84\ud9b1\udde4\ud957\uddf3\ud8dc\ude33\ud816\ude6f\ud87c\udeeb\udbfa\uddd0\ud8c6\ude0e\ub893\ud8be\udc9f\ufbcf\ud8e9\uded4\uda1e\udce7\ud9b2\udd2e\uda15\udff4\ud9c5\udd76\udbc7\udea7\udb6b\udd71\uda8c\udfbc\ud808\udf25\000\ud819\udecc\uda2b\udf31\ud968\udff2\ud97f\ude70\uda98\udf6c\udbdf\udebc]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u630b\udbee\ude0b\uda0e\udc9e\u009e\000\udb7f\udf1a\ud9f8\udf7b\ud9d5\udc19\ud875\udd38\u6e51\udb28\udff1\udb08\udd5a\ud83b\udccf\ud821\udd26\ud8ac\udc3c\uda13\ude61\udad2\ude84\ud9b1\udde4\ud957\uddf3\ud8dc\ude33\ud816\ude6f\ud87c\udeeb\udbfa\uddd0\ud8c6\ude0e\ub893\ud8be\udc9f\ufbcf\ud8e9\uded4\uda1e\udce7\ud9b2\udd2e\uda15\udff4\ud9c5\udd76\udbc7\udea7\udb6b\udd71\uda8c\udfbc\ud808\udf25\000\ud819\udecc\uda2b\udf31\ud968\udff2\ud97f\ude70\uda98\udf6c\udbdf\udebc, \uda7e\ude52\uda62\udc3d\ud8e5\udcb3\uda39\udfaf\udaf6\ude82\ud9f4\udff8\ud987\udc02\ueda5\uda63\ude47\uda38\udd0c\udb30\udf46]\012",
        Z.run(T, 2, 9, 4, 13, "\ubd2c\u00a7\u630b\udbee\ude0b\uda0e\udc9e\u009e\000\udb7f\udf1a\ud9f8\udf7b\ud9d5\udc19\ud875\udd38\u6e51\udb28\udff1\udb08\udd5a\ud83b\udccf\ud821\udd26\ud8ac\udc3c\uda13\ude61\udad2\ude84\ud9b1\udde4\ud957\uddf3\ud8dc\ude33\ud816\ude6f\ud87c\udeeb\udbfa\uddd0\ud8c6\ude0e\ub893\ud8be\udc9f\ufbcf\ud8e9\uded4\uda1e\udce7\ud9b2\udd2e\uda15\udff4\ud9c5\udd76\udbc7\udea7\udb6b\udd71\uda8c\udfbc\ud808\udf25\000\ud819\udecc\uda2b\udf31\ud968\udff2\ud97f\ude70\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u101e\u2181\ub0b8\u4d53\u2d39", "\uda7e\ude52\uda62\udc3d\ud8e5\udcb3\uda39\udfaf\udaf6\ude82\ud9f4\udff8\ud987\udc02\ueda5\uda63\ude47\uda38\udd0c\udb30\udf46",
        22, 72009, -1857644305, -9053821033829016677L, 53793L, true, true, (char) 18808, (char) 63743,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud864\udc18]\0121=org.apache.commons.collections.list.SetUniqueList$SetListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud864\udc18]\012",
        Z.run(T, 2, 10, 10, 9, "\ud864\udc18", "\ua1e1\u8479\ud2cc\u5066\u3bee\u4e43\u4243\u88b5\u6a7e\ua2e1\u9b2d\u2240\ub01a\u6853\u6f60", "\ud9b0\udd44",
        14, 56698, -387720535, 3228337923846331764L, -12255L, true, true, (char) 31712, (char) 54336,
        Double.longBitsToDouble(0x3fb8f86ae361f8d8L), Double.longBitsToDouble(0x3fef1361924d2c79L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=void |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=void |this=org.apache.commons.collections.list.SetUniqueList:[]\012",
        Z.run(T, 2, 6, 6, 10, "\ubd2c\uda37\udfad\uda2c\udc53\udbeb\udfb9\ud913\ude80\ud8d5\uddbd\udbb9\udce1\udb83\udee7\ud89b\udf7c\ud8a7\udd74\udb03\ude64\ud865\udd91\ud923\udd3e\udb08\udd5a\ud83b\udccf\ud9d5\udd5f\udb6d\udf32\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbd9\udb88\udc45\uda20\udc29\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbda\udcc5\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud9a4\udef2\udba3\ude10\udb94\udeef\ud8c5\udfe5\udb13\udc1f\udbdf\udea8", "\u081f\u36ab\u95f7\u69e8\u1477\u92e0\u0ac6\u324d\u2d39", "\udb06\udf16\udb35\uddae\udbb1\udc87\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e",
        22, 23969, -1339676937, -3290002960143524965L, 53793L, true, true, (char) 17762, (char) 50133,
        Double.longBitsToDouble(0x3fdc8325ccdccd70L), Double.longBitsToDouble(0x3fa8e8424ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\ubd2c\uda37\udfad\uda2c\udc53\u54e6\uda0e\udc43\uda40\udc44\udb8d\ude1d\udb83\udee7\ud89b\udf7c\ud8a7\udd74\udb03\ude64\ud865\udd91\ud923\udd3e\udb08\udd5a\ud83b\udccf\ud9d5\udd5f\udb6d\udf32\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\udb88\udc45\uda20\udc29\ud9b2\udd2e\ud903\udee6\udbc4\ude80\udbda\udcc5\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud9a4\udef2\udba3\ude10\udb94\udeef\ud8c5\udfe5\udb13\udc1f\udbdf\udea8 |this=org.apache.commons.collections.list.SetUniqueList:[\udb06\udf16\udb35\uddae\udbb1\udc87-\udaf3\udf38\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\000\000]\0121=java.lang.String:\udb06\udf16\udb35\uddae\udbb1\udc87-\udaf3\udf38\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\000\000 |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\u54e6\uda0e\udc43\uda40\udc44\udb8d\ude1d\udb83\udee7\ud89b\udf7c\ud8a7\udd74\udb03\ude64\ud865\udd91\ud923\udd3e\udb08\udd5a\ud83b\udccf\ud9d5\udd5f\udb6d\udf32\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\udb88\udc45\uda20\udc29\ud9b2\udd2e\ud903\udee6\udbc4\ude80\udbda\udcc5\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud9a4\udef2\udba3\ude10\udb94\udeef\ud8c5\udfe5\udb13\udc1f\udbdf\udea8]\012",
        Z.run(T, 2, 0, 0, 0, "\ubd2c\uda37\udfad\uda2c\udc53\u54e6\uda0e\udc43\uda40\udc44\udb8d\ude1d\udb83\udee7\ud89b\udf7c\ud8a7\udd74\udb03\ude64\ud865\udd91\ud923\udd3e\udb08\udd5a\ud83b\udccf\ud9d5\udd5f\udb6d\udf32\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\udb88\udc45\uda20\udc29\ud9b2\udd2e\ud903\udee6\udbc4\ude80\udbda\udcc5\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud9a4\udef2\udba3\ude10\udb94\udeef\ud8c5\udfe5\udb13\udc1f\udbdf\udea8", "\u081f\u36ab\u3c3f\u9d2f\u8d73\u086e\u0b17\u324d\u2d39", "\udb06\udf16\udb35\uddae\udbb1\udc87-\udaf3\udf38\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\000\000",
        0, 23969, -1333642984, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud857\uddef\uda27\ude43\ud849\udd58\ud8c7\udfae\udbbe\udcdc\uda75\ude16\uda9e\uddd1\udae1\udc0f\ud9bd\uddc7\ud8c8\ude50\udb10\udc96\uda99\udea4\udbd8\udc07\ud9c0\ude57\ud92f\udd12\udb90\udc45\uda74\uddf2\udb7f\udf14\udbea\udfe1\udad6\udcf5\udabb\udd32\u9907\ud816\ude6f\udba4\udd3f\udbfe\udfbc\udab3\uddf7\ud8d2\udf17\ud8f3\uddf9\udaba\udfcd\ud8e9\uded4\uda1f\udfe7\ua787\uda96\udddf\udbc4\ude80\udbde\udd59\udb9c\udc71\uda9a\udec3\ud808\udf25\udb53\udf05\ud82c\udef6\udba3\ude10\udb94\udeef]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ud857\uddef\uda27\ude43\ud849\udd58\ud8c7\udfae\udbbe\udcdc\uda75\ude16\uda9e\uddd1\udae1\udc0f\ud9bd\uddc7\ud8c8\ude50\udb10\udc96\uda99\udea4\udbd8\udc07\ud9c0\ude57\ud92f\udd12\udb90\udc45\uda74\uddf2\udb7f\udf14\udbea\udfe1\udad6\udcf5\udabb\udd32\u9907\ud816\ude6f\udba4\udd3f\udbfe\udfbc\udab3\uddf7\ud8d2\udf17\ud8f3\uddf9\udaba\udfcd\ud8e9\uded4\uda1f\udfe7\ua787\uda96\udddf\udbc4\ude80\udbde\udd59\udb9c\udc71\uda9a\udec3\ud808\udf25\udb53\udf05\ud82c\udef6\udba3\ude10\udb94\udeef]\012",
        Z.run(T, 2, 11, 11, 13, "\ud857\uddef\uda27\ude43\ud849\udd58\ud8c7\udfae\udbbe\udcdc\uda75\ude16\uda9e\uddd1\udae1\udc0f\ud9bd\uddc7\ud8c8\ude50\udb10\udc96\uda99\udea4\udbd8\udc07\ud9c0\ude57\ud92f\udd12\udb90\udc45\uda74\uddf2\udb7f\udf14\udbea\udfe1\udad6\udcf5\udabb\udd32\u9907\ud816\ude6f\udba4\udd3f\udbfe\udfbc\udab3\uddf7\ud8d2\udf17\ud8f3\uddf9\udaba\udfcd\ud8e9\uded4\uda1f\udfe7\ua787\uda96\udddf\udbc4\ude80\udbde\udd59\udb9c\udc71\uda9a\udec3\ud808\udf25\udb53\udf05\ud82c\udef6\udba3\ude10\udb94\udeef", "\u0997\u5c63\uaf3c", "\ud81c\udfad",
        49, 2056, 953862017, -1744853514885647385L, -71294L, true, true, (char) 22831, (char) 44772,
        Double.longBitsToDouble(0x3fd9096b745b1b50L), Double.longBitsToDouble(0x3fea57ebcb481f6bL)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\ud886\udf69\udb1d\ude1f\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\ud92a\udf4c\ud86c\udd68\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc, \uda7e\ude52\uda62\udc3d\ud939\udefc\ua283\udaf6\ude82\ud965\uddf1\uda76\udccd\uf73a\ud852\uded9\udb77\udc43\uda0f\udf8e]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\ud886\udf69\udb1d\ude1f\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\ud92a\udf4c\ud86c\udd68\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc, \uda7e\ude52\uda62\udc3d\ud939\udefc\ua283\udaf6\ude82\ud965\uddf1\uda76\udccd\uf73a\ud852\uded9\udb77\udc43\uda0f\udf8e, \ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\ud886\udf69\udb1d\ude1f\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\ud92a\udf4c\ud86c\udd68\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\012",
        Z.run(T, 2, 1, 1, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\ud886\udf69\udb1d\ude1f\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d5\udfe5\ud8f3\uddf9\ufbcf\ud8e9\uded4\ud92a\udf4c\ud86c\udd68\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\u4f07\ud82c\udef6\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9582\u86a2\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\ud939\udefc\ua283\udaf6\ude82\ud965\uddf1\uda76\udccd\uf73a\ud852\uded9\udb77\udc43\uda0f\udf8e",
        55, 50094, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 60279, (char) 61181,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\ud9a5\udc2f\udb74\udc66\ud9e8\udc89\ud825\ude04\ud8db\uddd4\udb5b\udc37\ud8fc\udf85\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d6\udc17\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\udac2\udd1c\ud8a5\ude3c\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\0121=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\ud9a5\udc2f\udb74\udc66\ud9e8\udc89\ud825\ude04\ud8db\uddd4\udb5b\udc37\ud8fc\udf85\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d6\udc17\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\udac2\udd1c\ud8a5\ude3c\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc]\012",
        Z.run(T, 2, 9, 9, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\ud9a5\udc2f\udb74\udc66\ud9e8\udc89\ud825\ude04\ud8db\uddd4\udb5b\udc37\ud8fc\udf85\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\ud8c6\ude0e\ud8d6\udc17\ud8f3\uddf9\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\udac2\udd1c\ud8a5\ude3c\udba3\ude10\udb94\udeef\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u9d2f\u8698\u08ef\u0b17\u324d\u2d39", "\uda7e\ude52\uda62\udc3d\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud9bc\udc38\ud9a4\udf08\ud852\uded9\udb77\udc43\ud85a\udc13",
        22, 49993, -1857644305, -3290002960143524965L, 53793L, false, false, (char) 43282, (char) 10047,
        Double.longBitsToDouble(0x3fdc83246cdccd70L), Double.longBitsToDouble(0x3fa8cac24ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\u21d7\udb40\uddc0\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud987\udc02\ud9a4\udf08\ud852\uded9`\000, \ubd2c\udb44\udc88\u0b0e\udbd9\ude0b\uda08\udc43\u009e\udb87\udf62\udb4d\udfb2\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\ud96b\udc1d\ud898\udf38\ub800\uda74\uddfc\ud832\udd1e\ud8e9\uded4\udb82\udd37\udbe6\udfe1\ud97a\udf78\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\0121=java.lang.String:\u21d7\udb40\uddc0\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud987\udc02\ud9a4\udf08\ud852\uded9`\000 |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\udb44\udc88\u0b0e\udbd9\ude0b\uda08\udc43\u009e\udb87\udf62\udb4d\udfb2\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\ud96b\udc1d\ud898\udf38\ub800\uda74\uddfc\ud832\udd1e\ud8e9\uded4\udb82\udd37\udbe6\udfe1\ud97a\udf78\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\012",
        Z.run(T, 2, 3, 0, 13, "\ubd2c\udb44\udc88\u0b0e\udbd9\ude0b\uda08\udc43\u009e\udb87\udf62\udb4d\udfb2\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\ud96b\udc1d\ud898\udf38\ub800\uda74\uddfc\ud832\udd1e\ud8e9\uded4\udb82\udd37\udbe6\udfe1\ud97a\udf78\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13", "\u081f\u36ab\uc269\u9d2f\u86a2\u2181\u00ca\u3166\u0cee", "\u21d7\udb40\uddc0\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud987\udc02\ud9a4\udf08\ud852\uded9`\000",
        0, 49993, -1857644305, -3290002960143524965L, 53793L, true, true, (char) 18808, (char) 63743,
        Double.longBitsToDouble(0x3eb1800000000000L), Double.longBitsToDouble(0x3fa880006d0a83c0L)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\ud8d5\udc8a\ud9db\udf4f\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\ud9ea\udf0c\ud83b\udcef\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\udb02\udf6b\udb12\udd41\ud868\udcb6\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udf83\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\0121=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\ud8d5\udc8a\ud9db\udf4f\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\ud9ea\udf0c\ud83b\udcef\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\udb02\udf6b\udb12\udd41\ud868\udcb6\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udf83\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\012",
        Z.run(T, 2, 12, 9, 12, "\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\ud8d5\udc8a\ud9db\udf4f\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\ud9ea\udf0c\ud83b\udcef\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\udb02\udf6b\udb12\udd41\ud868\udcb6\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udf83\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13", "\u081f\u36ab\uc269\u1d7f\u86a2\uc347\u2e23\u3166\u0cee", "\u21d7\udb40\uddc0\udb94\udd0b\ua202\udaf6\ude82\ud9f4\udff8\ud987\udc02\ud9a4\udf08\ud852\uded9`\000",
        0, 66289, -265112180, -3290059387423859813L, 53793L, true, true, (char) 18808, (char) 63743,
        Double.longBitsToDouble(0x3eb1800000000000L), Double.longBitsToDouble(0x3fa880004ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\uddfb\udae5\udc26\ud91f\udd33\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udae4\udf8f\ud89f\udc1e\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\uda63\udf55\ud90d\uddb2\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\0121=java.lang.String:\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\uddfb\udae5\udc26\ud91f\udd33\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udae4\udf8f\ud89f\udc1e\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\uda63\udf55\ud90d\uddb2\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13 |this=org.apache.commons.collections.list.SetUniqueList:[\u21d7\udb40\uddc0\udb94\udd0b\ua202\udaf6\ude82\udae5\udc00\uda09\ude11\ud9bc\uddd6\ud852\uded9`\000]\012",
        Z.run(T, 2, 9, 0, 13, "\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\udb4d\udf25\ud9e8\udc89\udb75\udceb\ud88e\uddfb\udae5\udc26\ud91f\udd33\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udae4\udf8f\ud89f\udc1e\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\uda63\udf55\ud90d\uddb2\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\ud819\udecc\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13", "\u299a\u36ab\uc269\u9d2f\u86a2\u2181\u00ca\u3166\u0cee", "\u21d7\udb40\uddc0\udb94\udd0b\ua202\udaf6\ude82\udae5\udc00\uda09\ude11\ud9bc\uddd6\ud852\uded9`\000",
        0, 49993, -1857644305, -3290002960143524965L, 53793L, false, false, (char) 51929, (char) 63743,
        Double.longBitsToDouble(0x3eb181c5c8000000L), Double.longBitsToDouble(0x3fa880004ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=!java.lang.IllegalArgumentException\012",
        Z.run(T, 2, 15, 5, 13, "\ubd2c\uda37\udfad\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb41\udcef\ud9e8\udc89\udb75\udceb\ud88e\ude67\ud86f\udf06\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud816\ude6f\udba4\udd3f\udbfe\udfbc\udb8d\uded2\ud8e0\udd09\ud8f3\uddf9\ufbcf\udaeb\uded5\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\ud863\udeae\ud9bf\uddb6\ud9ad\uddb0\ud8bf\udd0c\u5e8e\uda98\udf6c\udbdf\udebc", "\u081f\u36ab\uc269\u373c\u86a2\u08ef\u0b17\u0a01\u6111", "\ud8fe\ude74\uda62\udc3d",
        52, 95765, 2055932746, -928897406797753290L, 47686L, false, true, (char) 28461, (char) 26215,
        Double.longBitsToDouble(0x3fe449ee044b8a56L), Double.longBitsToDouble(0x3fedec8a339bd257L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[N\000\u0b00\udbd9\ude0b\uda08\udc43\u009e\udb87\udf62\udb4d\udfb2\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\u323c\ud9b8\ude5b\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud9cf\ude60\udba4\udd3f\ud96b\udc1d\u4b36\000\uda74\uddfc\ud832\udd1e\ud8e9\uded4\udb82\udd37\udbe6\udfe1\ud97a\udf78\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\udb92\udc08\000\ud826\udc93\u5dd3\000\000]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 3, 0, 13, "N\000\u0b00\udbd9\ude0b\uda08\udc43\u009e\udb87\udf62\udb4d\udfb2\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\udb08\udd5a\ud83b\udccf\u323c\ud9b8\ude5b\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\ud9cf\ude60\udba4\udd3f\ud96b\udc1d\u4b36\000\uda74\uddfc\ud832\udd1e\ud8e9\uded4\udb82\udd37\udbe6\udfe1\ud97a\udf78\udbc4\ude80\udbf6\udc29\udb6b\udd71\uda9a\udec3\ud808\udf25\000\udb92\udc08\000\ud826\udc93\u5dd3\000\000", "", "",
        -5, 58776, -1326934944, 36837934497792L, -96928L, false, false, (char) 21519, (char) 22831,
        Double.longBitsToDouble(0x3e4f1e5800000000L), Double.longBitsToDouble(0x3fe16c6e4b4afd26L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\ud8d5\udc8a\ud9db\udf4f\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\ud9ea\udf0c\ud83b\udcef\udb8f\udfbd\ud9c4\uddfa\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\udb02\udf6b\udb12\udd41\ud868\udcb6\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\uda04\udf51\ud94f\udc43\ud807\udd8b\ud808\ude8f\ud892\udcf9\ud833\udd09\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\0121=org.apache.commons.collections.list.SetUniqueList$SetListListIterator:@? |this=org.apache.commons.collections.list.SetUniqueList:[\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\ud8d5\udc8a\ud9db\udf4f\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\ud9ea\udf0c\ud83b\udcef\udb8f\udfbd\ud9c4\uddfa\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\udb02\udf6b\udb12\udd41\ud868\udcb6\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\uda04\udf51\ud94f\udc43\ud807\udd8b\ud808\ude8f\ud892\udcf9\ud833\udd09\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13]\012",
        Z.run(T, 2, 12, 12, 12, "\ubd2c\u00a7\u0b00\udbd9\ude0b\uda08\udc43\u009e\000\ud8d5\udc8a\ud9db\udf4f\udb75\udceb\ud88e\uddfb\u00ae\ud923\udcb9\ud9ea\udf0c\ud83b\udcef\udb8f\udfbd\ud9c4\uddfa\udb59\udd6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\udb02\udf6b\udb12\udd41\ud868\udcb6\ud898\udf38\ub800\000\ufbcf\ud8e9\uded4\ud819\ude63\ud8c5\udcc2\ud938\udee6\udbc4\ude80\uda04\udf51\ud94f\udc43\ud807\udd8b\ud808\ude8f\ud892\udcf9\ud833\udd09\udba3\ude10\udb7a\udc9d\u5dd3\000\udbdf\ude13", "\u081f\u36ab\uc269\u1d7f\u86a2\uc347\u2e23\u3166\u0cee", "\u21d7\udb40\uddc0\udb94\udd0b\ud8a9\udfb1\udadb\udc8a\ud9c9\udfd7\ud987\udc02\ud9a4\udf08\ud852\uded9`\000",
        0, 66289, -265112180, -3290059387423859813L, 53793L, true, true, (char) 24988, (char) 63743,
        Double.longBitsToDouble(0x3eb1800000000000L), Double.longBitsToDouble(0x3fa880004ca413c0L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=org.apache.commons.collections.list.SetUniqueList:[N\000\ud802\udcff\u1697\uda08\udc43\u009e\udb87\udf62\udb4f\uddb2\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud93e\ude66\udb33\udc84\ud83b\udccd\u0b7e\ud9b8\ude5b\udb8a\ude6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\u82aa\udba4\udd3f\ud96b\udc1d\u4b36\udbb4\udf6a\ud9a1\udda8\udaac\udf0e\udb95\ude57\ud953\ude84\udbe6\udfe1\ud97a\udf78\ud886\ude81\udbf6\udc29\udb6b\udd71\ud930\ude0e\ud808\udf25\000\udb92\udc08\000\ud826\udc93\u5dd3\ud9e1\udd10\u9e7a]\0121=java.lang.Boolean:false |this=org.apache.commons.collections.list.SetUniqueList:[N\000\ud802\udcff\u1697\uda08\udc43\u009e\udb87\udf62\udb4f\uddb2\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud93e\ude66\udb33\udc84\ud83b\udccd\u0b7e\ud9b8\ude5b\udb8a\ude6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\u82aa\udba4\udd3f\ud96b\udc1d\u4b36\udbb4\udf6a\ud9a1\udda8\udaac\udf0e\udb95\ude57\ud953\ude84\udbe6\udfe1\ud97a\udf78\ud886\ude81\udbf6\udc29\udb6b\udd71\ud930\ude0e\ud808\udf25\000\udb92\udc08\000\ud826\udc93\u5dd3\ud9e1\udd10\u9e7a]\012",
        Z.run(T, 2, 9, 1, 12, "N\000\ud802\udcff\u1697\uda08\udc43\u009e\udb87\udf62\udb4f\uddb2\ud9e8\udc89\udb75\udceb\ud88e\uddfb\u00ae\ud93e\ude66\udb33\udc84\ud83b\udccd\u0b7e\ud9b8\ude5b\udb8a\ude6c\udbda\udfe1\udaee\uddf5\ud92f\udfac\ud8dc\ude0b\u82aa\udba4\udd3f\ud96b\udc1d\u4b36\udbb4\udf6a\ud9a1\udda8\udaac\udf0e\udb95\ude57\ud953\ude84\udbe6\udfe1\ud97a\udf78\ud886\ude81\udbf6\udc29\udb6b\udd71\ud930\ude0e\ud808\udf25\000\udb92\udc08\000\ud826\udc93\u5dd3\ud9e1\udd10\u9e7a", "", "",
        -5, 58776, -1326934944, 36837934497792L, -96928L, false, false, (char) 21519, (char) 22831,
        Double.longBitsToDouble(0x3e4f1e5800000000L), Double.longBitsToDouble(0x3fe16c6e4b4afd26L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud917\udec9\uda37\udfcb\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud975\udc8f\udaf3\udc54\udb39\uddee\ud96c\udd62\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\uda2b\udf32\ud8c1\udd22\udba4\udd3f\udbfe\udfbc\ud987\udd62\ud909\udd21\ud8fb\ude83\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\ud988\udea0\ud85d\udec3\ud808\ude5f\ud919\udfe9\ud82c\udf55\udba3\ude10\udbfd\uddb9\u5ec2\uda98\udf6c\ud810\uddc7, \udbd7\udc95\uda7e\ude52\uda62\udc3d\udb94\udd0b\ud83b\udd4b\udaa3\udce4\udad4\ude23\ud921\uddf0\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e\ud91a\ude49\udb5f\udc70\ud818\udf70\ud883\udd0c\uda5f\ude1e\ud9cc\udfa5\udbb0\ude3d\udab1\udc6a\u899d\uda9b\udf5c\udaeb\ude10\uda83\udec6\ud874\udc09\uda71\ude75\ud94f\udc87\ud938\udd70\ud93d\udec3\ud8a9\udcbd\uda7b\udfb9\ud941\udc14\udb3d\udd7d\uda2d\udf4a\ud920\udcbc\ud8e4\udd13\ud834\udd03\ud995\udce1\ud96f\udc20\udba7\udf81\uda93\udeb1\ud94d\udf9b\ud842\udf95\ud9fa\udf56\udb05\udde8\ud8df\udc64\ud924\uddf9\ud952\udfa5\uda19\ude4b\udb8d\udf4d\uda3f\udc51\udb8e\udc96\uda79\udd77\udb1e\udf67\udb4d\udfff\uda04\ude94\uda1f\udfd0\udbeb\udd99\udbe4\udd84\udb4b\udecd\ud8a0\ude43\uda0a\udec7\ud9c5\udce4\udb9c\udf57\udb25\udef1\udaaf\udd97\ud8c0\udc91]\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud917\udec9\uda37\udfcb\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud975\udc8f\udaf3\udc54\udb39\uddee\ud96c\udd62\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\uda2b\udf32\ud8c1\udd22\udba4\udd3f\udbfe\udfbc\ud987\udd62\ud909\udd21\ud8fb\ude83\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\ud988\udea0\ud85d\udec3\ud808\ude5f\ud919\udfe9\ud82c\udf55\udba3\ude10\udbfd\uddb9\u5ec2\uda98\udf6c\ud810\uddc7, \udbd7\udc95\uda7e\ude52\uda62\udc3d\udb94\udd0b\ud83b\udd4b\udaa3\udce4\udad4\ude23\ud921\uddf0\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e\ud91a\ude49\udb5f\udc70\ud818\udf70\ud883\udd0c\uda5f\ude1e\ud9cc\udfa5\udbb0\ude3d\udab1\udc6a\u899d\uda9b\udf5c\udaeb\ude10\uda83\udec6\ud874\udc09\uda71\ude75\ud94f\udc87\ud938\udd70\ud93d\udec3\ud8a9\udcbd\uda7b\udfb9\ud941\udc14\udb3d\udd7d\uda2d\udf4a\ud920\udcbc\ud8e4\udd13\ud834\udd03\ud995\udce1\ud96f\udc20\udba7\udf81\uda93\udeb1\ud94d\udf9b\ud842\udf95\ud9fa\udf56\udb05\udde8\ud8df\udc64\ud924\uddf9\ud952\udfa5\uda19\ude4b\udb8d\udf4d\uda3f\udc51\udb8e\udc96\uda79\udd77\udb1e\udf67\udb4d\udfff\uda04\ude94\uda1f\udfd0\udbeb\udd99\udbe4\udd84\udb4b\udecd\ud8a0\ude43\uda0a\udec7\ud9c5\udce4\udb9c\udf57\udb25\udef1\udaaf\udd97\ud8c0\udc91, \ud917\udec9\uda37\udfcb\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud975\udc8f\udaf3\udc54\udb39\uddee\ud96c\udd62\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\uda2b\udf32\ud8c1\udd22\udba4\udd3f\udbfe\udfbc\ud987\udd62\ud909\udd21\ud8fb\ude83\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\ud988\udea0\ud85d\udec3\ud808...\012",
        Z.run(T, 2, 1, 4, 5, "\ud917\udec9\uda37\udfcb\uda2c\udc53\udbee\udef1\uda0e\udc9e\udb9e\udc33\udac8\udf01\udb74\udcbf\ud975\udc8f\udaf3\udc54\udb39\uddee\ud96c\udd62\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb8f\udfbd\ud956\udec2\udb7f\udecd\udbea\udfe1\udaee\uddf5\ud92f\udfac\uda2b\udf32\ud8c1\udd22\udba4\udd3f\udbfe\udfbc\ud987\udd62\ud909\udd21\ud8fb\ude83\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\ud988\udea0\ud85d\udec3\ud808\ude5f\ud919\udfe9\ud82c\udf55\udba3\ude10\udbfd\uddb9\u5ec2\uda98\udf6c\ud810\uddc7", "\u081f\u36ab\u2bb3\ua78c\u5f3b\u65b1\ud017\u324d", "\udbd7\udc95\uda7e\ude52\uda62\udc3d\udb94\udd0b\ud83b\udd4b\udaa3\udce4\udad4\ude23\ud921\uddf0\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e\ud91a\ude49\udb5f\udc70\ud818\udf70\ud883\udd0c\uda5f\ude1e\ud9cc\udfa5\udbb0\ude3d\udab1\udc6a\u899d\uda9b\udf5c\udaeb\ude10\uda83\udec6\ud874\udc09\uda71\ude75\ud94f\udc87\ud938\udd70\ud93d\udec3\ud8a9\udcbd\uda7b\udfb9\ud941\udc14\udb3d\udd7d\uda2d\udf4a\ud920\udcbc\ud8e4\udd13\ud834\udd03\ud995\udce1\ud96f\udc20\udba7\udf81\uda93\udeb1\ud94d\udf9b\ud842\udf95\ud9fa\udf56\udb05\udde8\ud8df\udc64\ud924\uddf9\ud952\udfa5\uda19\ude4b\udb8d\udf4d\uda3f\udc51\udb8e\udc96\uda79\udd77\udb1e\udf67\udb4d\udfff\uda04\ude94\uda1f\udfd0\udbeb\udd99\udbe4\udd84\udb4b\udecd\ud8a0\ude43\uda0a\udec7\ud9c5\udce4\udb9c\udf57\udb25\udef1\udaaf\udd97\ud8c0\udc91",
        37, 88637, -729757178, -6300752324827401814L, -20856L, false, true, (char) 57580, (char) 34815,
        Double.longBitsToDouble(0x3fe34cd487a27c26L), Double.longBitsToDouble(0x3f97a8fbc57c8f00L)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud917\udec9\uda37\udfcb\udba0\udf49\udbee\ude81\ud8d2\udc80\udb97\udf4b\udac8\udf01\udb74\udcbf\ud975\udc8f\udaf3\udc54\udb39\uddee\ud96c\udd62\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb20\udcb3\udbb4\udfd1\udb7f\udecd\ud842\udc0c\udb13\udcc8\ud92f\udfac\uda2b\udf32\ud8c1\udd22\uda0e\udf73\udbe2\udee2\ud987\udd62\ud909\udd21\ud8fb\ude83\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\ud988\udea0\ud85d\udec3\ud808\ude5f\ud919\udfe9\ud82c\udf55\udba3\ude10\udbfd\uddb9\ud815\ude80\uda98\udf6c\ud810\uddc7, \udbd7\udc95\uda7e\ude52\uda62\udc3d\udb94\udd0b\ud83b\udd4b\ud8c3\udd09\ud870\udcba\ud921\uddf0\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e\ud91a\ude49\udb5f\udc70\ud818\udf70\ud883\udd0c\uda5f\ude1e\ud9cc\udfa5\udbb0\ude3d\udab1\udc6a\u899d\uda9b\udf5c\udaeb\ude10\uda83\udec6\ud874\udc09\uda71\ude75\ud94f\udc87\ud938\udd70\ud93d\udec3\ud8a9\udcbd\uda7b\udfb9\ud969\ude14\udb3d\udd7d\uda2d\udf4a\ud920\udcbc\ud8e4\udd13\ud834\udd03\ud995\udce1\ud96f\udc20\udba7\udf81\uda93\udeb1\ud94d\udf9b\ud842\udf95\ud9fa\udf56\ud83c\udc04\uda56\udf24\uda09\udcfc\ud963\udf05\uda19\ude4b\udb8d\udf4d\uda3f\udc51\udb8e\udc96\uda79\udd77\udb1e\udf67\udb4d\udfff\uda04\ude94\uda1f\udfd0\udbeb\udd99\udbe4\udd84\udb4b\udecd\ud8a0\ude43\uda0a\udec7\ud9c5\udce4\udb9c\udf57\udb25\udef1\udaaf\udd97\ud8c0\udc91\ud46e\udb81\ude1d\udb11\udf75\udb3f\uddfd\ud81c\udfac\ud951\ude37\ud99e\udc6c\ud9c1\uded6\udb49\udf56\uda8d\udcd1\udb75\udde3\ud896\ude81\uda87\ude77\u3d67\udb29\udd12\uda66\udc64\u03a1\ud920\ude96\ud91b\udcc3\ud8b4\udcb9\ud9ca\udcb3\ud98b\ude33\udb24\udee2\udb04\udfa0\ud945\udd20\ud94e\udc53\udb16\udcf5\uda5b\udf34\udb69\uddc2\udb75\udde5\uda22\udd2c\udbfd\ude36\udbd8\udfd2\ud894\udc54\udbb8\ude4a\udbe2\udeca\ud813\ude7c\udbc3\uddb1\ud9c0\uddf1...\0121=java.lang.Boolean:true |this=org.apache.commons.collections.list.SetUniqueList:[\ud917\udec9\uda37\udfcb\udba0\udf49\udbee\ude81\ud8d2\udc80\udb97\udf4b\udac8\udf01\udb74\udcbf\ud975\udc8f\udaf3\udc54\udb39\uddee\ud96c\udd62\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb20\udcb3\udbb4\udfd1\udb7f\udecd\ud842\udc0c\udb13\udcc8\ud92f\udfac\uda2b\udf32\ud8c1\udd22\uda0e\udf73\udbe2\udee2\ud987\udd62\ud909\udd21\ud8fb\ude83\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\ud988\udea0\ud85d\udec3\ud808\ude5f\ud919\udfe9\ud82c\udf55\udba3\ude10\udbfd\uddb9\ud815\ude80\uda98\udf6c\ud810\uddc7, \udbd7\udc95\uda7e\ude52\uda62\udc3d\udb94\udd0b\ud83b\udd4b\ud8c3\udd09\ud870\udcba\ud921\uddf0\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e\ud91a\ude49\udb5f\udc70\ud818\udf70\ud883\udd0c\uda5f\ude1e\ud9cc\udfa5\udbb0\ude3d\udab1\udc6a\u899d\uda9b\udf5c\udaeb\ude10\uda83\udec6\ud874\udc09\uda71\ude75\ud94f\udc87\ud938\udd70\ud93d\udec3\ud8a9\udcbd\uda7b\udfb9\ud969\ude14\udb3d\udd7d\uda2d\udf4a\ud920\udcbc\ud8e4\udd13\ud834\udd03\ud995\udce1\ud96f\udc20\udba7\udf81\uda93\udeb1\ud94d\udf9b\ud842\udf95\ud9fa\udf56\ud83c\udc04\uda56\udf24\uda09\udcfc\ud963\udf05\uda19\ude4b\udb8d\udf4d\uda3f\udc51\udb8e\udc96\uda79\udd77\udb1e\udf67\udb4d\udfff\uda04\ude94\uda1f\udfd0\udbeb\udd99\udbe4\udd84\udb4b\udecd\ud8a0\ude43\uda0a\udec7\ud9c5\udce4\udb9c\udf57\udb25\udef1\udaaf\udd97\ud8c0\udc91\ud46e\udb81\ude1d\udb11\udf75\udb3f\uddfd\ud81c\udfac\ud951\ude37\ud99e\udc6c\ud9c1\uded6\udb49\udf56\uda8d\udcd1\udb75\udde3\ud896\ude81\uda87\ude77\u3d67\udb29\udd12\uda66\udc64\u03a1\ud920\ude96\ud91b\udcc3\ud8b4\udcb9\ud9ca\udcb3\ud98b\ude33\udb24\udee2\udb04\udfa0\ud945\udd20\ud94e\udc53\udb16\udcf5\uda5b\udf34\udb69\uddc2\udb75\udde5\uda22\udd2c\udbfd\ude36\udbd8\udfd2\ud894\udc54\udbb8\ude4a\udbe2\udeca\ud813\ude7c\udbc3\uddb1\ud9c0\uddf1...\012",
        Z.run(T, 2, 1, 4, 5, "\ud917\udec9\uda37\udfcb\udba0\udf49\udbee\ude81\ud8d2\udc80\udb97\udf4b\udac8\udf01\udb74\udcbf\ud975\udc8f\udaf3\udc54\udb39\uddee\ud96c\udd62\ud923\udd3e\udb08\udd5a\ud83b\udccf\udb20\udcb3\udbb4\udfd1\udb7f\udecd\ud842\udc0c\udb13\udcc8\ud92f\udfac\uda2b\udf32\ud8c1\udd22\uda0e\udf73\udbe2\udee2\ud987\udd62\ud909\udd21\ud8fb\ude83\ufbcf\ud8e9\uded4\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80\udbf6\udc29\ud988\udea0\ud85d\udec3\ud808\ude5f\ud919\udfe9\ud82c\udf55\udba3\ude10\udbfd\uddb9\ud815\ude80\uda98\udf6c\ud810\uddc7", "\u081f\u36ab\u2bb3\ua78c\u5f3b\u87fb\ud017\u324d", "\udbd7\udc95\uda7e\ude52\uda62\udc3d\udb94\udd0b\ud83b\udd4b\ud8c3\udd09\ud870\udcba\ud921\uddf0\ud9a4\udf08\ud852\uded9\udb77\udc43\uda0f\udf8e\ud91a\ude49\udb5f\udc70\ud818\udf70\ud883\udd0c\uda5f\ude1e\ud9cc\udfa5\udbb0\ude3d\udab1\udc6a\u899d\uda9b\udf5c\udaeb\ude10\uda83\udec6\ud874\udc09\uda71\ude75\ud94f\udc87\ud938\udd70\ud93d\udec3\ud8a9\udcbd\uda7b\udfb9\ud969\ude14\udb3d\udd7d\uda2d\udf4a\ud920\udcbc\ud8e4\udd13\ud834\udd03\ud995\udce1\ud96f\udc20\udba7\udf81\uda93\udeb1\ud94d\udf9b\ud842\udf95\ud9fa\udf56\ud83c\udc04\uda56\udf24\uda09\udcfc\ud963\udf05\uda19\ude4b\udb8d\udf4d\uda3f\udc51\udb8e\udc96\uda79\udd77\udb1e\udf67\udb4d\udfff\uda04\ude94\uda1f\udfd0\udbeb\udd99\udbe4\udd84\udb4b\udecd\ud8a0\ude43\uda0a\udec7\ud9c5\udce4\udb9c\udf57\udb25\udef1\udaaf\udd97\ud8c0\udc91\ud46e\udb81\ude1d\udb11\udf75\udb3f\uddfd\ud81c\udfac\ud951\ude37\ud99e\udc6c\ud9c1\uded6\udb49\udf56\uda8d\udcd1\udb75\udde3\ud896\ude81\uda87\ude77\u3d67\udb29\udd12\uda66\udc64\u03a1\ud920\ude96\ud91b\udcc3\ud8b4\udcb9\ud9ca\udcb3\ud98b\ude33\udb24\udee2\udb04\udfa0\ud945\udd20\ud94e\udc53\udb16\udcf5\uda5b\udf34\udb69\uddc2\udb75\udde5\uda22\udd2c\udbfd\ude36\udbd8\udfd2\ud894\udc54\udbb8\ude4a\udbe2\udeca\ud813\ude7c\udbc3\uddb1\ud9c0\uddf1\udab8\udfbc\uda0e\udf70\ud99a\ude10\udafc\udec9\udb38\udf25\u75d2\ud9d3\udce4\udaa1\udf39\ud9e3\udf8b\udafc\ude77\ud9c9\udcd3\udb48\ude5d\udb31\udf55\udb43\udf07\udbc3\udc71\uda25\udfe0\uda20\udee8\uda62\udc75\udb9e\udd12\ud8cb\udecb\udb86\udd38",
        59, 91522, 119668873, 6333883705163116269L, 67184L, true, true, (char) 36905, (char) 48492,
        Double.longBitsToDouble(0x3fc6b1dd6eb93640L), Double.longBitsToDouble(0x3fde8f8b36a4f21aL)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=java.lang.String:\ud8e1\uddb3\uda37\udfad\udbeb\udd33\ud844\udca4\ud9dc\udd26\ud8c4\udf26\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud879\udf67\ud86f\udeb1\ud923\udd3e\udb08\udd5a\uda29\udcc6\ud96c\udcf6\udb97\udf8f\ud97b\ude6c\udbea\udfe1\udaee\uddf5\ud933\uddac\ud8dc\ude0b\ud816\ude6f |this=org.apache.commons.collections.list.SetUniqueList:[]\0121=!java.lang.IndexOutOfBoundsException\012",
        Z.run(T, 2, 14, 14, 10, "\ud8e1\uddb3\uda37\udfad\udbeb\udd33\ud844\udca4\ud9dc\udd26\ud8c4\udf26\udac8\udf01\udb74\udcbf\ud9e8\udc89\udb75\udceb\ud879\udf67\ud86f\udeb1\ud923\udd3e\udb08\udd5a\uda29\udcc6\ud96c\udcf6\udb97\udf8f\ud97b\ude6c\udbea\udfe1\udaee\uddf5\ud933\uddac\ud8dc\ude0b\ud816\ude6f", "\u14de", "\ud928\udfec\ud884\udd0f\uda1f\udfe7\ud9b2\udd2e\ud938\udee6\udbc4\ude80",
        0, 63706, -64888462, 7604106070578000299L, 79801L, false, false, (char) 18802, (char) 20240,
        Double.longBitsToDouble(0x3fecd22b8aa2124aL), Double.longBitsToDouble(0x3fc6e2492f32ae98L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.apache.commons.collections.list.SetUniqueList|set|int,java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|add|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|add|int,java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|int,java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|addAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|asSet||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|clear||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|contains|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|containsAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|decorate|java.util.List|static",
    "M|org.apache.commons.collections.list.SetUniqueList|iterator||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|listIterator||new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|listIterator|int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|remove|java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|remove|int|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|removeAll|java.util.Collection|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
    "M|org.apache.commons.collections.list.SetUniqueList|set|int,java.lang.Object|new:org.apache.commons.collections.list.SetUniqueList:java.util.List,java.util.Set",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
