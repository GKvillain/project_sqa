package org.mockito.internal.creation.instance;
import org.junit.Test;
import static org.junit.Assert.*;
public class ConstructorInstantiator_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\0121=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\012",
        Z.run(T, 2, 7, 7, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        29, 4049, 756238482, -2514848416445759492L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\ua2e0\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\u428a\u42a4]]\0121=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\ua2e0\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\u428a\u42a4]]\012",
        Z.run(T, 2, 7, 7, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\uda62\udfcd\udb6c\udc03\udbb2\uddba\ud9fc\udc96\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\ua2e0\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\u428a\u42a4", "\ud9ad\ude85\ud97f\udff0\ud80f\udea7\uda42\udc91\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        29, 4049, 756238482, -2514848416445759492L, -57471L, false, true, (char) 64172, (char) 27286,
        Double.longBitsToDouble(0x3fbcb1393b7def98L), Double.longBitsToDouble(0x3fd24ab1d068863cL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class java.lang.Object, class [Ljava.lang.String;]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\0121=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class java.lang.Object, class [Ljava.lang.String;]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\012",
        Z.run(T, 2, 7, 7, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\ud9ab\udd8a\uda66\uddc9\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        10, 4049, 756238482, -2514848416445759492L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.instance.InstantationException:org.mockito.internal.creation.instance.InstantationException: Unable to create mock instance of 'Integer'.\012Please ensure that the outer instance has correct type and that the target class has parameter-less constructor.\012",
        Z.run(T, 1, 4, 5, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\ucb98\ud8b4\udc4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ud364\u30e7\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        29, 4049, 756238482, -2514848416445759492L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class [I]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u7416\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u7872\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb0]]\0121=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class [I]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u7416\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u7872\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb0]]\012",
        Z.run(T, 2, 7, 7, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udce4\ud954\uded5", "\uaccc\ubfd1\u7416\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u7872\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb0", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\udb45\udd9d\uda89\udca7\ud922\ude46",
        53, 3827, 756238482, -2514848416445759492L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb139137def98L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[]] |a1=[Ljava.lang.Object;:[[\u7cf5\ubfd1\u78a2\u1183\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u175b\ub723\ubc0e\u0344\u33d0]]\0121=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[]] |a1=[Ljava.lang.Object;:[[\u7cf5\ubfd1\u78a2\u1183\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u175b\ub723\ubc0e\u0344\u33d0]]\012",
        Z.run(T, 2, 7, 7, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud933\udd46\udb23\udf80\udb8a\udc3e\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud93d\udd4d", "\u7cf5\ubfd1\u78a2\u1183\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u175b\ub723\ubc0e\u0344\u33d0", "\udb95\uddcd\ud90e\udf61\udb59\udf53\uda55\ude94\ud87c\udc3d\udb8c\udfa6\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbc1\udfbc\udbe3\ude7f\ud911\udd64\ud87c\udf66",
        56, 38682, 1707078134, 2875961646060357778L, -34460L, false, true, (char) 25674, (char) 59433,
        Double.longBitsToDouble(0x3fe5aaae662bb64cL), Double.longBitsToDouble(0x3fe10870154288d4L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 7, 7, 5, "\udb26\udc30\u0eba\udba3\udf62", "\u8054\ub06a\ua384\u79a1", "\udb3b\udc66\ud954\uded5",
        11, 1798, -313367824, -8883110647303109510L, 84193L, true, false, (char) 47814, (char) 36754,
        Double.longBitsToDouble(0x3feadc2b216551c6L), Double.longBitsToDouble(0x3fc9719d07d17900L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class java.util.Date, class [Ljava.lang.String;, class java.lang.Number]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u25df\u0ef1\u829d\ub7d0\ud249\u8f11\u33d0\ua8a5\u911d\ub396\ubbbb\u620f\u16af]]\0121=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 7, 2, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udb38\ude6e\uda5e\udf67\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u25df\u0ef1\u829d\ub7d0\ud249\u8f11\u33d0\ua8a5\u911d\ub396\ubbbb\u620f\u16af", "\ud9ad\ude85\ud980\udc2c\udb1c\uddee\ud8e2\ude46\ud9eb\udd0b\udbe1\udfee\udaf2\udf32\ud911\udd82\uda7e\udf67\ud9fc\udd52\uda2a\udf8a",
        7, 91542, 756238482, -2514848416445759492L, -62443L, false, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fecae17276fbdf3L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 1, 3, 7, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\ud825\udc6d\ud835\udefe\uda9c\udd68",
        29, 4049, 756238482, -2514848416445759492L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud314\u92bd\ua832\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\ud6cc\uaa9f\uc6bf\u0eab\u0986\ud077\ubfb9]]\0121=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 7, 2, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud314\u92bd\ua832\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\ud6cc\uaa9f\uc6bf\u0eab\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\ud965\udc81\ud91b\udc4c\uda7e\udf67\ud835\udefe\uda9c\udd68",
        29, 19393, 1091782802, -2507062074529808388L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class java.lang.Integer, int, class [I]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50]]\0121=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 7, 6, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udba5\udd4e\ud890\udc30\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\udb85\udfb1\ud9ed\ude99\udb3b\udc66\ud9b2\udee4", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50", "\udb5a\udedb\ud8c0\udd71\ud9ad\uddee\uda0d\udcbf\udbd4\udc6e\u0188\udb95\uddcd\ud973\udfb2",
        47, 34301, -1833601362, 5888639950978534921L, -45087L, false, false, (char) 52125, (char) 10908,
        Double.longBitsToDouble(0x3fef0b2df892c6e9L), Double.longBitsToDouble(0x3fe589b89ffcdd19L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.instance.InstantationException:org.mockito.internal.creation.instance.InstantationException: Unable to create mock instance of 'Integer'.\012Please ensure that the outer instance has correct type and that the target class has parameter-less constructor.\0121=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class java.lang.Thread$State]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\012",
        Z.run(T, 2, 4, 7, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\udbdd\udea8\uda31\ude7c\ud835\udefe\uda9c\udd68",
        29, 9727, 756238482, -2514848413425860612L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.instance.ConstructorInstantiator:@?\0121=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ud14f\u01c7\u0344\u33d0\ua8a5\u911d\ub396\u30a8\uc54a\u3960]]\012",
        Z.run(T, 2, 5, 7, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud85a\udd1b\ud970\ude9b\udb45\udc79\ud941\udc74", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ud14f\u01c7\u0344\u33d0\ua8a5\u911d\ub396\u30a8\uc54a\u3960", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\uda62\ude46\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        29, 4049, 756238482, -2514848413878845444L, -62443L, true, false, (char) 34038, (char) 11901,
        Double.longBitsToDouble(0x3fef11d65e5c9d8dL), Double.longBitsToDouble(0x3fd118141edf7be6L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 7, 5, "\udbc7\ude41\ud9fa\udc29\udba3\udf62\udb91\udee3\uda1c\udd51\ud8af\udf8f\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5\ud913\uddfa\ud891\udc2e\ud8a6\uddd6\ud86e\udeaa\ud9b1\ude11\udb6f\udd02\udaeb\udf2d\ud905\udf02\udb7a\udd4e\udab5\uddc4\udab5\udc33\udbc9\udc33\udbcc\ude58\udb0d\udc19\udb5a\udedb", "\u337b\ua8a5\u911d\ub396\u0986\u7557\u0cae\u8d25\u3fb1\u6d25\u3a84\u066e\u67ef\u6040\u3410\ud1f6\u4d37\u0264\u164d\u9936\u2a8e\ua437\u5dfe", "\ud8e2\ude6d\ud8fb\udd83\ud988\udd65\ud835\ude5d",
        0, 19649, 986395970, -2626232031295272789L, -26127L, true, true, (char) 57260, (char) 25547,
        Double.longBitsToDouble(0x3fbee3f7d2075668L), Double.longBitsToDouble(0x3fe1c080c08ba071L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\u28f1\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\0121=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 7, 3, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud9a9\udc1f", "\uaccc\ubfd1\u747c\u28f1\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        29, 4049, 756238482, -2514848416294764548L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 2, 4, 1, "\ud9e1\udf4e\udbbd\udf4c\udba3\udf75\udb91\udee3\ud88f\udd14\uda92\udd75\udb9c\udd0c\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\ud91e\ude50\udb10\udcc9", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\u2c58\u1e50\u7480\u8cd3\u97ee\u3122\u3da3\u338c\ua8a5\ube49\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        29, 4049, 756238482, -2514848416445759492L, -62443L, true, false, (char) 16655, (char) 12055,
        Double.longBitsToDouble(0x3fe711d65d57b0f5L), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\u8b7b\u0710\ub396\u0986\ud077\ubfb9]]\0121=java.lang.String:\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5 |this=org.mockito.internal.creation.instance.ConstructorInstantiator:@?\012",
        Z.run(T, 2, 7, 0, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\u8b7b\u0710\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b",
        28, 21832, -1315227103, 7119730955812382137L, -53042L, true, false, (char) 56597, (char) 7420,
        Double.longBitsToDouble(0x3fd847ac68ae87a6L), Double.longBitsToDouble(0x3fe5aaae662bb64cL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 0, 7, 5, "\udbd8\udda9\udb5b\udcfa\uda50\ude48\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3", "\000", "\ud958\udcf6",
        -5, -1000, -313368064, -8883110648309742470L, 84193L, true, false, (char) 6801, (char) 36754,
        Double.longBitsToDouble(0x3feadc2b276551c6L), Double.longBitsToDouble(0x3fc9733ac7d17900L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.instance.ConstructorInstantiator:@?\0121=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 5, 2, 4, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud991\udd15\ud8dd\ude74\ud8ea\udce8\udb19\uddaa\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u6f9d\ua1c7\u7ee4\u04ab\ubf03\u7bd8\u8071\u6e98\u7480\u8220\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\ud8ce\udd86\ud823\ude7d\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\u1cdf",
        45, 4049, 1209223314, -2514848253237002244L, -62443L, false, true, (char) 21009, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.instance.InstantationException:org.mockito.internal.creation.instance.InstantationException: Unable to create mock instance of 'int[]'.\012Please ensure that the outer instance has correct type and that the target class has parameter-less constructor.\0121=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 4, 6, 5, "\udbac\udd0d\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud821\udcda\udbbe\udceb\ud891\udc2e\ud8a6\uddd6", "\ud317\u7ee4", "\ud8e9\udc1e\udad2\udc2c\udaec\udd5f\udbcc\ude58\udb09\udecd\udb5a\udedb\ud8c0\udd71\ud945\udf3a\uda12\udcc2\ud961\ude42\ud907\udde8\udb95\uddcd\ud973\udfb2",
        47, 34301, -1833601362, 5888639950978534921L, 13771L, true, true, (char) 52125, (char) 10908,
        Double.longBitsToDouble(0x3fef0b2df892c6e9L), Double.longBitsToDouble(0x3fe589689ffcdd19L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class java.lang.Object, class [Ljava.lang.String;]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\u64bc\ud53b\u04ab\u54c2\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\0121=!org.mockito.internal.creation.instance.InstantationException\012",
        Z.run(T, 2, 7, 0, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\udb58\udc51\udb8a\udc6f\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\u64bc\ud53b\u04ab\u54c2\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\udae3\ude99\udaef\udcb2\ud9ab\udd8a\uda66\uddc9\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        10, 4049, 756238482, -2956588208021045252L, -62443L, true, false, (char) 46114, (char) 63766,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7def98L)));
  }
  @Test
  public void test21() {}
// Defects4J: flaky method
//   @Test(timeout = 4000)
//   public void test21() throws Throwable {
//     assertEquals("0=java.util.Date:Tue Sep 29 06:05:25 PDT 2026\0121=java.util.Date:Tue Sep 29 06:05:25 PDT 2026\012",
//         Z.run(T, 2, 3, 3, 1, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u94fe\ud2a6\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\ud9ab\udd8a\uda66\uddc9\ud96f\udef2\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
//         10, 94665, 756238482, -2514848416445759492L, -57471L, false, true, (char) 64172, (char) 27286,
//         Double.longBitsToDouble(0x3fef18cd04df1ed5L), Double.longBitsToDouble(0x3fc2ba45f2a25f68L)));
//   }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.instance.ConstructorInstantiator:@?\0121=new org.mockito.internal.creation.instance.ConstructorInstantiator:@?\012",
        Z.run(T, 2, 5, 5, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\ua352\udad9\udcb5\uda5e\udf53\uda5b\ude1b\ud8c2\udd08\ud803\udcec\udbd8\udfe9\ud93d\udfdf\uda57\udd65\ud970\uddbb\ud86e\udeaa", "\u7eca\u04ab\u011a\u3a07\ucc46\u1e50\ua5d8\u27cd\u601c\u7b1c\u639e\u33d0\ua8a5\u9123", "\udab9\udee2\uda5d\ude6f\ud87c\udc3d\udb8c\udfa6\u9f86\ud97f\udff0\udb1c\uddee\ud9ab\udd8a\uda66\uddc9\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68\udab1\udcc1\udae3\udc83\u8b3a\ud9c1\udca2\u788c\ud8e2\ude6d\ud8fb\udd83\ud988\udd65\ud835\ude5d\ud93d\udefe",
        19, 28970, -1651654686, -2141017382570480755L, -61203L, true, false, (char) 49970, (char) 30916,
        Double.longBitsToDouble(0x3fd3bcc8d17a8c34L), Double.longBitsToDouble(0x3fe77a832be4d3abL)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.instance.InstantationException:org.mockito.internal.creation.instance.InstantationException: Unable to create mock instance of 'Date'.\012Please ensure that the outer instance has correct type and that the target class has parameter-less constructor.\012",
        Z.run(T, 1, 4, 5, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\ud99a\udc28", "\u894e", "\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5\ud913\uddfa\ud891\udc2e\ud8a6\uddd6\ud86e\udeaa\ud9b1\ude11\ud9ed\udd01\udaeb\udf2d\uda63\udf90\udad7\udc8f",
        52, 57217, 1997910166, 6791635817242515956L, 72902L, true, true, (char) 39848, (char) 8765,
        Double.longBitsToDouble(0x3fccf762fce44438L), Double.longBitsToDouble(0x3fdf562048c8adb6L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.instance.InstantationException:org.mockito.internal.creation.instance.InstantationException: Unable to create mock instance of 'ArrayList'.\012Please ensure that the outer instance has correct type and that the target class has parameter-less constructor.\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 0, 4, "\udbd8\udda9\ud9fa\udc29\udba3\udf62", "\u8054\u894e\u1926\u1ef7", "\udb3b\udd1d\ud907\ude7e",
        37, 1798, -313367824, -8883110647537990534L, 84193L, true, false, (char) 29006, (char) 36742,
        Double.longBitsToDouble(0x3fd88850821cd314L), Double.longBitsToDouble(0x3fc9733ac7d17900L)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.instance.InstantationException:org.mockito.internal.creation.instance.InstantationException: Unable to create mock instance of 'State'.\012Please ensure that the outer instance has correct type and that the target class has parameter-less constructor.\0121=new org.mockito.internal.creation.instance.ConstructorInstantiator:@?\012",
        Z.run(T, 2, 4, 5, 5, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb91\udee3\ud88f\udd14\ud8dd\udedb\ucb98\ud962\udfa3\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\uaba2\u777e\ua1b0\u15d4\u04ab\u6183\u5826\uadbc\u1e50\u7480\u829d\ub7d0\ubc0e\u0344\u33d0\u207b\u911d\ud364\u30e7\ud077\uadf1", "\ud9ad\ude8a\ud97f\udff0\udb1c\uddee\ud828\ude38",
        39, 67778, 1791257832, -5648857395529048939L, 77682L, false, true, (char) 56736, (char) 892,
        Double.longBitsToDouble(0x3fe69025c4b9e1e3L), Double.longBitsToDouble(0x3fe98b8861847ac6L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=java.lang.String:\0121=java.lang.String:\udb10\udd0b\ud9d6\ude03\udba3\udf62\udac3\ude81\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udbe5\udc05\uda66\udda1\ud9d9\udf8b\ud884\udd1c\udb3b\udc66 |a1=[Ljava.lang.Object;:[[\udb10\udd0b\ud9d6\ude03\udba3\udf62\udac3\ude81\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udbe5\udc05\uda66\udda1\ud9d9\udf8b\ud884\udd1c\udb3b\udc66]]\012",
        Z.run(T, 2, 3, 2, 5, "\udb10\udd0b\ud9d6\ude03\udba3\udf62\udac3\ude81\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udbe5\udc05\uda66\udda1\ud9d9\udf8b\ud884\udd1c\udb3b\udc66", "\u1f48\u36ac\u8a34", "\ud822\udf78\ud84a\udedc\udb7a\udd4e\ud839\udc26\udad2\udc2c",
        0, 70660, -896574988, 4923611786805200511L, 27769L, true, true, (char) 18754, (char) 53875,
        Double.longBitsToDouble(0x3fede260ae23ee12L), Double.longBitsToDouble(0x3fea9495ae095108L)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.instance.InstantationException:org.mockito.internal.creation.instance.InstantationException: Unable to create mock instance of 'Number'.\012Please ensure that the outer instance has correct type and that the target class has parameter-less constructor.\0121=org.mockito.internal.creation.instance.InstantationException:org.mockito.internal.creation.instance.InstantationException: Unable to create mock instance of 'Number'.\012Please ensure that the outer instance has correct type and that the target class has parameter-less constructor.\012",
        Z.run(T, 2, 4, 4, 5, "\ud91e\udeee\ud9b7\udd25\uda3b\ude25\ud8bf\ude0c\ud8dd\udc29\ud866\udf6f\udb5f\udef5\u50a1\udafb\udfa5\ud976\udd7e\ud884\udc7c\udbaf\udfe0\udb19\udd75", "\uba29\u849d\u747c\ud317\u7ee4\u7ba7\ub989\u8d07\u3316\u25df\u0ef1\uc570\ub770\ud249\u8f11\u3322\uc429\u911d\ub396\ubbbb\u620f\u16af", "\ud9ad\ude85\ud967\udde7\uda98\uddb4\ud9bf\udd54\ud938\udc40\ud8f2\uddd0\udb21\udc47\udb59\uddf2\udbb0\udef8\ud9fc\udd52\uda29\ude8a",
        7, 91542, 527059090, -1789313489646649348L, 73918L, false, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fecae17276fadf6L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=java.lang.String:\udbc7\ude41\ud9fa\udc29\udba3\udf62\udb91\udee3\uda1c\udd51\ud8af\udf8f\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\udaad\udd02\ud956\udcef\udb3b\udc66\ud954\uded5\ud913\uddfa\ud891\udc2e\ud8a6\uddd6\ud86e\udeaa\ud9b1\ude11\udb6f\udd02\udaeb\udf2d\ud905\udf02\udb7a\udd4e\udab5\uddc4\udab5\udc33\udbc9\udc33\udbcc\ude58\udb0d\udc19\udb5a\udedb |this=org.mockito.internal.creation.instance.ConstructorInstantiator:@?\0121=java.lang.String:\udbc7\ude41\ud9fa\udc29\udba3\udf62\udb91\udee3\uda1c\udd51\ud8af\udf8f\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\udaad\udd02\ud956\udcef\udb3b\udc66\ud954\uded5\ud913\uddfa\ud891\udc2e\ud8a6\uddd6\ud86e\udeaa\ud9b1\ude11\udb6f\udd02\udaeb\udf2d\ud905\udf02\udb7a\udd4e\udab5\uddc4\udab5\udc33\udbc9\udc33\udbcc\ude58\udb0d\udc19\udb5a\udedb |this=org.mockito.internal.creation.instance.ConstructorInstantiator:@?\012",
        Z.run(T, 2, 6, 6, 5, "\udbc7\ude41\ud9fa\udc29\udba3\udf62\udb91\udee3\uda1c\udd51\ud8af\udf8f\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\udaad\udd02\ud956\udcef\udb3b\udc66\ud954\uded5\ud913\uddfa\ud891\udc2e\ud8a6\uddd6\ud86e\udeaa\ud9b1\ude11\udb6f\udd02\udaeb\udf2d\ud905\udf02\udb7a\udd4e\udab5\uddc4\udab5\udc33\udbc9\udc33\udbcc\ude58\udb0d\udc19\udb5a\udedb", "\u337b\ua8a5\u911d\ub396\u0986\u7557\u0cae\u8d25\u3fb1\u6d25\ua001\uc26f\u67ef\u6040\u3410\ud1f6\u4d37\u0264\u164d\u9936\u2a8e\ua437\u5dfe", "\ud8e2\ude6d\ud8fb\udd83\ud988\udd65\ud835\ude5d",
        0, 19649, 985887212, -2626232031295272789L, -26127L, true, true, (char) 57260, (char) 25547,
        Double.longBitsToDouble(0x3fbee3f7d2075668L), Double.longBitsToDouble(0x3fe1c080c08ba071L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\ucc21\u01be\ub718\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\0121=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object]] |a1=[Ljava.lang.Object;:[[\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\ucc21\u01be\ub718\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\012",
        Z.run(T, 2, 7, 7, 5, "\udbd8\udda9\uda7b\udf8a\udba3\udf62\udbc1\udcd8\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf4b\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\uaccc\ubfd1\u747c\ud317\u7ee4\u04ab\u011a\u3a07\ucc46\u1e50\ucc21\u01be\ub718\ubc0e\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9a3\udc51\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\uda9c\udd68",
        29, 4049, 756238482, -2514848416445759492L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393de5ef98L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class java.lang.Object, class [Ljava.lang.String;]] |a1=[Ljava.lang.Object;:[[\ub5d6\ubfd1\u747c\u4bb0\u35d6\u14ed\ubc4b\u15b3\u265a, \u39bf\u5a9c\ub7d0\ubc46\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\0121=java.lang.Boolean:false |a0=[Ljava.lang.Class;:[[class java.lang.Object, class [Ljava.lang.String;]] |a1=[Ljava.lang.Object;:[[\ub5d6\ubfd1\u747c\u4bb0\u35d6\u14ed\ubc4b\u15b3\u265a, \u39bf\u5a9c\ub7d0\ubc46\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9]]\012",
        Z.run(T, 2, 7, 7, 4, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb9b\udd88\ud88f\udd14\ud8dd\udedb\udb8a\udcc3\udaf2\udf25\uda5e\udf53\ud9e7\udce1\ud884\udd1c\udb3b\udc66\ud954\uded5", "\ub5d6\ubfd1\u747c\u4bb0\u35d6\u14ed\ubc4b\u15b3\u265a,\u39bf\u5a9c\ub7d0\ubc46\u0344\u33d0\ua8a5\u911d\ub396\u0986\ud077\ubfb9", "\ud9ad\ude85\ud97f\udff0\udb1c\uddee\udaae\ude4c\uda66\ude3b\udbe1\udf2b\udaf2\udf32\ud911\udd82\uda7e\udf67\ud835\udefe\ud8fa\udc18",
        46, 4049, 756238482, -2514848416445759492L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7dece0L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object, interface java.lang.Comparable]] |a1=[Ljava.lang.Object;:[[\u0547\u891b\u7435\ud73d\u35d6\u14ed\ubc4b\u15b3\u265a, \u39bf\u5a9c\u7edc\ua73d\u8285\u33d0\ua8a5\u9c14\u1ff0\u0986\ud077\ubfb9]]\0121=java.lang.Boolean:true |a0=[Ljava.lang.Class;:[[class java.lang.Object, interface java.lang.Comparable]] |a1=[Ljava.lang.Object;:[[\u0547\u891b\u7435\ud73d\u35d6\u14ed\ubc4b\u15b3\u265a, \u39bf\u5a9c\u7edc\ua73d\u8285\u33d0\ua8a5\u9c14\u1ff0\u0986\ud077\ubfb9]]\012",
        Z.run(T, 2, 7, 7, 4, "\udbd8\udda9\ud9fa\udc29\udba3\udf62\udb9b\udd88\udb9f\udfc3\ud8dd\udedb\udb8a\udcc3\udaf2\udf25\uda5e\udf53\ud9e7\udce1\udbf5\ude16\udb3b\udc66\ud954\uded5", "\u0547\u891b\u7435\ud73d\u35d6\u14ed\ubc4b\u15b3\u265a,\u39bf\u5a9c\u7edc\ua73d\u8285\u33d0\ua8a5\u9c14\u1ff0\u0986\ud077\ubfb9", "\ud9ad\udf45\ud97f\udff0\udb1c\uddee\udaae\ude4c\udb80\ude68\udbe0\ude1c\uda09\udc3e\ud936\udd62\uda7e\udf67\ud835\udefe\ud878\udf96",
        46, 4049, 1540114066, 1787165890094825256L, -62443L, true, false, (char) 46114, (char) 12055,
        Double.longBitsToDouble(0x3fef11d65d099d8dL), Double.longBitsToDouble(0x3fbcb1393b7dece0L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.creation.instance.ConstructorInstantiator|newInstance|java.lang.Class|new:org.mockito.internal.creation.instance.ConstructorInstantiator:java.lang.Object",
    "M|org.mockito.internal.creation.instance.ConstructorInstantiator|paramsMatch|[Ljava.lang.Class;,[Ljava.lang.Object;|static",
    "M|org.mockito.internal.creation.instance.ConstructorInstantiator|withParams|java.lang.Class,[Ljava.lang.Object;|static",
    "M|org.mockito.internal.creation.instance.ConstructorInstantiator|noArgConstructor|java.lang.Class|static",
    "M|org.mockito.internal.creation.instance.ConstructorInstantiator|paramsException|java.lang.Class,java.lang.Exception|static",
    "C|org.mockito.internal.creation.instance.ConstructorInstantiator|<init>|java.lang.Object",
    "M|org.mockito.internal.creation.instance.ConstructorInstantiator|newInstance|java.lang.Class|new:org.mockito.internal.creation.instance.ConstructorInstantiator:java.lang.Object",
    "M|org.mockito.internal.creation.instance.ConstructorInstantiator|paramsMatch|[Ljava.lang.Class;,[Ljava.lang.Object;|static",
    "M|org.mockito.internal.creation.instance.ConstructorInstantiator|withParams|java.lang.Class,[Ljava.lang.Object;|static",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
