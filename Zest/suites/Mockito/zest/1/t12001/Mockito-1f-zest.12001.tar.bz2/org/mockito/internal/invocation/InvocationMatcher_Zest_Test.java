package org.mockito.internal.invocation;
import org.junit.Test;
import static org.junit.Assert.*;
public class InvocationMatcher_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 13, "\ud888\udc32\udbd7\udc75\ud957\uddbb", "\u1c98\ub183\u17ae\u05c9", "\udbe3\udff3",
        -3, 70188, 2004933107, -5096555015492890457L, 29383L, false, false, (char) 457, (char) 56017,
        Double.longBitsToDouble(0x3fe5a0dfe3bbe38aL), Double.longBitsToDouble(0x3fc865a60762ca90L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 13, "\ud888\udc32\udbd7\udc75\ud957\uddbb", "\u1c98\ub183\u17ae\u3361", "\udaf5\uded1\ud8f2\ude78\ud8c3\udce9",
        42, 167, 1405958916, 7253963712931952999L, 64802L, true, false, (char) 63951, (char) 28485,
        Double.longBitsToDouble(0x3fe9ee7673ecfb57L), Double.longBitsToDouble(0x3fcaa91d1f20b8ccL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 9, 13, "\ud888\udc1e\udbd7\udc75\u40b9", "\u1c98\ub183\u17ae\u05c9\ua16e\u3518\uaa9b\u0dd6\u846a\ub795\uca62\ubd2a\ubee7\u9436\u5754\uba1c\u3c49\u44f9\u194a\ucd13\ua8d3\u6aae\u7ab7\u1bf6\u22fa\u4da2\u2161\uc018", "\ud92f\udcc3\uda20\udc80\ud998\uded4",
        13, 70062, 1180426768, 869830962684036046L, 8820L, false, false, (char) 1707, (char) 11221,
        Double.longBitsToDouble(0x3fdc9f0fb293827eL), Double.longBitsToDouble(0x3fda0ff6b8348a74L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 14, 13, 11, "\ud831\udd08\uda4c\udfe6", "\u3e13\ud6ec\ub183\u9b6c\u65e2\u2bb5\u37ee\u958c\u7045\u861c\u1437\ub8b6\u6dc2\u6802\u93a2\u6f3b\u693b\ua7c1\u21c3", "\udbf9\udc72\ud8cc\udc82\ud9f8\ude97\ud90f\udda0\udb54\udf14",
        30, 49139, -1027125305, -5300082566826664889L, 55266L, false, true, (char) 39902, (char) 49019,
        Double.longBitsToDouble(0x3fe0ae3b5dff2ca4L), Double.longBitsToDouble(0x3feb03f2f393a618L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 8, "\ud888\udc32", "\u8c74\ubd72\u1c98\ub183\u57ba\u6b19\ucc76\u433a\u22ea\ua6fe\u4c0c\ub795\uca62\u8677\ud234\ub9fe\u5754\u1568\u5a7d\u44f9\u194a\ucd13\ucda9\u11ca\u3497\u021d\u2d4b\u1c59\ua2ed\u3b8d\u527c\u779d\u30d1\u5566\u0525\u1ba8\u0ca0\u054d\u41c9\u5bdc\u7a83\ucabd\u3596\u7d53", "\ud9e3\udcc2\udb95\udfe4\uda7d\udc55\ud9b6\udd31\ud882\udd22",
        23, 64649, 914591083, -3758210401539191034L, 9409L, true, false, (char) 56814, (char) 44561,
        Double.longBitsToDouble(0x3fe0c412ae5a94a8L), Double.longBitsToDouble(0x3fe3e606a1c15342L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 1, 14, 13, "\ud888\udc32\udbd7\udc75\ud957\uddbb", "\u1bce\u7efd\u97cc\u05c9", "\udbe3\udff3",
        -3, 70188, 2004933107, -5096555015492890457L, 29383L, false, false, (char) 457, (char) 56017,
        Double.longBitsToDouble(0x3fe5a0dfe3bbe38aL), Double.longBitsToDouble(0x3fc865a60762ca90L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 11, 13, "\ud853\udfd2\udab1\udea2\ud957\uddbb", "\u1c98\ub2b3\u1729\u05c9\u546f", "\udada\udee9\ud8c3\udcd5\udb8e\udcfd\udbc2\ude0b\udb77\udd8f\udaef\udf7e",
        54, 22336, 2008251454, 2016595713177853620L, -56797L, false, true, (char) 62016, (char) 23878,
        Double.longBitsToDouble(0x3fe99eee785c7e95L), Double.longBitsToDouble(0x3fd558568626d50aL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 14, 13, "\ud99d\udfdb\uda0a\udfbe\ud955\udcc4", "\u1c98\ub183\u17ae\u05c9", "\udbe3\udff3",
        21, 70188, 2004933107, -5096555017486058585L, 71235L, false, true, (char) 457, (char) 56017,
        Double.longBitsToDouble(0x3fe5a0dfe3bbe38aL), Double.longBitsToDouble(0x3fe6196981f5b2a4L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 14, 13, "\ud888\udc32\udbd7\udc75\udbd4\udebe", "\u1c98", "\uda11\uddf3\ud950\udf3d\uda6f\udf73\udbe3\udff3\udada\udee9\ud8c3\udcd5\udb8e\udcfd\udbc2\ude0b\udb77\udd8f\udaef\udf7e\ud985\ude49\ud9f2\udd40\udb7c\udf4b\ud8a7\udcc4\uda8d\udd06",
        49, 17259, -2059466280, 2462290459181815496L, -86492L, false, true, (char) 37182, (char) 41423,
        Double.longBitsToDouble(0x3fcfa20c58c0fa28L), Double.longBitsToDouble(0x3fd05f31b1583b26L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 13, 13, "\ud831\udd08\udb70\udeb8\udac5\udff6", "\ud6ec\ub183\u9b6c\ub776\u2bb4\u3753\u958c\u606a\ucd36\u1437\ub8b6\u6cc2\u607c", "\uda15\udefd\udb27\udce4\ud96a\udd48\ud820\udcea\ud942\ude52\udbf9\udc72\ud8cc\udc82\ud828\uded0\uda45\udde8\udbbc\uddc8\ud993\udd47\udac1\udfd6\ud975\udc0f",
        45, 43071, 215356403, -3420026048584159976L, 85855L, false, true, (char) 61867, (char) 415,
        Double.longBitsToDouble(0x3fdc253962f57bfcL), Double.longBitsToDouble(0x3fb4ab5f66bb0bb8L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 5, 11, "\ud831\udd08\uda4c\udfe6", "\u3e13\ud6ec\ub183\u9b6c\u65e2\u2bb5\u37ee\u958c\u7045\u861c\u1437\ub8b6\u6dc2\u6802\u93a2\u6f3b\u693b\ua7c1\u21c3", "\ud877\udc91\ud8cc\udce5\ud9f8\ude97\ud90f\udda0\udb54\udf14",
        30, 49139, -1027125305, -5300082565336664781L, 55266L, false, true, (char) 39902, (char) 49019,
        Double.longBitsToDouble(0x3fe0ae3b5dff2ca4L), Double.longBitsToDouble(0x3feb03f2f465e218L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 13, 1, 13, "\ud888\udc32\udbd7\udc75\ud957\uddc6", "\u1bce\u7efd\u97cc\u05c9", "\udbe3\udff3",
        -3, 70188, 2004933107, -5096555015492890457L, 29383L, false, false, (char) 457, (char) 56017,
        Double.longBitsToDouble(0x3fe5a0dfe3bbe38aL), Double.longBitsToDouble(0x3fc865a60762ca90L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 13, 9, 13, "\ud853\udfd2\udab1\udea2\ud957\uddbb", "\u1c98\ub2b3\u1729\u0640\u546f", "\udada\udee9\ud8c3\udcd5\udb8e\udcfd\udbc2\ude0b\udb77\udd8f\udaef\udf7e",
        54, 22336, 2008251454, 2016595713177853620L, -56797L, false, true, (char) 62016, (char) 23878,
        Double.longBitsToDouble(0x3fe99eee785c7e95L), Double.longBitsToDouble(0x3fd558568626d50aL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 11, 14, 13, "\ud888\udc32\udbd7\udc75\ud957\uddbb", "\u1c98\ub183\u17ae\u05c9", "\ud828\udf58",
        -3, 70188, 578869747, -5096516532585918297L, -66234L, false, true, (char) 47791, (char) 28485,
        Double.longBitsToDouble(0x3fe6196981d8b21cL), Double.longBitsToDouble(0x3fee82580f771a3fL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.invocation.InvocationMatcher|captureArgumentsFrom|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|createFrom|java.util.List|static",
    "M|org.mockito.internal.invocation.InvocationMatcher|getInvocation||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getLocation||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getMatchers||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getMethod||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSameMethod|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSimilarMethod|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|isVarargMatcher|org.hamcrest.Matcher|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|isVariableArgument|org.mockito.invocation.Invocation,int|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|matches|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|safelyArgumentsMatch|[Ljava.lang.Object;|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|toString||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "C|org.mockito.internal.invocation.InvocationMatcher|<init>|org.mockito.invocation.Invocation,java.util.List",
    "C|org.mockito.internal.invocation.InvocationMatcher|<init>|org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|captureArgumentsFrom|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
