package org.mockito.internal.creation;
import org.junit.Test;
import static org.junit.Assert.*;
public class MockSettingsImpl_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 14, 13, 7, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda70\udc81\uda06\udd88\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\uda48\udc88\ud9c4\udf09\ud94f\udde7\udaaf\udfdf",
        53, 69097, -667037597, -4716735487173680016L, -22308L, true, true, (char) 33109, (char) 33901,
        Double.longBitsToDouble(0x3fc6c07ed61669ccL), Double.longBitsToDouble(0x3fd6ca928ad09662L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 14, 13, 7, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda6f\udfca\uda06\udd88",
        10, 52817, 389141437, 1321435120588126183L, -28494L, true, false, (char) 58598, (char) 30783,
        Double.longBitsToDouble(0x3fcd2c44218fd178L), Double.longBitsToDouble(0x3fe08ec1ec70be8aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 10, 13, 7, "\uda00\udd7d\ud8f9\udde4\udb5b\udd83", "\uc071", "\uda70\udc81\uda06\uddc8\ud826\udd2e\uda9b\udebe\udbb1\udd1a\uda95\udf52\ud9c2\udef9\uda48\udc88\ud9c4\udf09",
        5, 94193, 1646382653, -838218286444457885L, 54512L, false, false, (char) 5641, (char) 37277,
        Double.longBitsToDouble(0x3fe6291485c896a5L), Double.longBitsToDouble(0x3fedb01feb900f72L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 14, 13, 7, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\u55ff\u127b", "\uda06\udd88\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\uda48\udc88\ud9c4\udf09\ud94f\udde7\udaaf\udfdf\ud9c7\udc05\ud9e5\udc39",
        3, 72441, -1819761552, -2880974326533009276L, -10203L, false, true, (char) 24748, (char) 55288,
        Double.longBitsToDouble(0x3fd6ca928ad09662L), Double.longBitsToDouble(0x3feaaa11f1de678eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 8, 1, 7, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda70\udc81\uda06\udd88\ud826\udd2e\uda9b\udee6\udb89\udda6\uda95\udf52\ud9c2\udef9\uda48\udc88\ud9c4\udf09\ud94f\udde7\udaaf\udfdf",
        53, 71713, -667037597, -4716735487173680016L, -22308L, true, true, (char) 29525, (char) 48817,
        Double.longBitsToDouble(0x3f68a17d859a7300L), Double.longBitsToDouble(0x3fd6ca928ad09662L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 4, 13, 7, "\udb49\udf7d\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda70\udc81\uda06\udd88\ud826\udd2e\udaf9\udef5\udae0\udf89\ud84c\udd2b\ud9c2\udef9\uda48\udc88\ud9c4\udf09\ud94f\udde7\udbfc\ude64",
        18, 40144, 1499603704, -4716735487173680016L, -22308L, true, true, (char) 33109, (char) 33901,
        Double.longBitsToDouble(0x3feb481fb5d808c6L), Double.longBitsToDouble(0x3fd414c60ad09662L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 3, 9, 7, "\uda87\udd54\uda37\udc77\ud907\udca9", "\u5563\u127b\u87e6\ub539\u7e6a\u2710\u5165\u773a\u23fa\ub4cb\u3c70\u8920\u50b9\u2f06\u728b\u6f1f\ua143\u347c\uc33c\u11ba\u461f\u1e9a\u31e7\uc27a\u845a\ua697\u2e8a\u5b37\u3987\ua66e", "\ud8bb\udf21\ud824\udc43\udb45\uddd9\udab7\udd47\uda1e\udee0\udb57\udc3c\ud9ef\udd44\ud8e0\udfb2\ud93d\udfa5\uda97\uddfa\ud9b9\udcb0\uda39\uddfb\ud974\udf8f\udb3f\uddb3",
        57, 40703, -1103500154, 8752755241457980436L, -34040L, true, true, (char) 9962, (char) 9422,
        Double.longBitsToDouble(0x3fe0212448910401L), Double.longBitsToDouble(0x3fc0b57212ecf0fcL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 2, 8, 4, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda70\udc81\udb48\ude5c\ud826\udd37\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\uda48\udc88\ud9c4\udf09\ud94f\udde7\uda36\udce8",
        30, 68952, -667037597, -4716735487173680016L, -22308L, true, true, (char) 33029, (char) 33901,
        Double.longBitsToDouble(0x3fc6c07ed61669ccL), Double.longBitsToDouble(0x3fd6ca928ad09662L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 0, 5, 7, ";", "\u2311", "\udbbe\udd25\000",
        -5, -1000, 1040187392, 7325237736429966269L, -3769L, true, false, (char) 11568, (char) 28754,
        Double.longBitsToDouble(0x3f42feb8f6a80800L), Double.longBitsToDouble(0x3f3888431fa2f000L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 4, 11, 5, "\uda3a\udc2c\ud9c5\ude1e\ud953\udc1a", "\u5563", "\uda70\udc81\uda06\udd88\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9f6\ude53\uda47\udf9d\udb94\ude09\u3d27\udba2\udc7d",
        53, 69097, -667037597, -4716735487173680016L, -98488L, true, true, (char) 33109, (char) 33901,
        Double.longBitsToDouble(0x3fd6808f6b7b72ccL), Double.longBitsToDouble(0x3fd6ca928ad09662L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 4, 4, 7, "\udbd9\udd5d\udbf2\ude9a\u48ee", "\u5563\uc0b3", "\udaaa\udc95",
        44, 1918, 389141488, 1321435120588126183L, 27206L, true, false, (char) 58598, (char) 30783,
        Double.longBitsToDouble(0x3fcd2c44218fd178L), Double.longBitsToDouble(0x3fe08ec1ec70be8aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 10, 13, 0, "\ud8af\udd48\u6b8a\udb5b\udd83", "\u5563", "\uda70\udc81\000\ud826\udd2e\u78e9\uad18\uda95\udf52\ud9c2\udef9\uda1c\udf8d\ud9c4\udf09\ud94f\udde7\ud855\udcf1",
        32, 69097, 0, -4755801206503243776L, -100000L, false, false, (char) 0, (char) 60871,
        Double.longBitsToDouble(0x0L), Double.longBitsToDouble(0x3fd6ca900ad09662L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 15, 3, 5, "\uda73\udd90\ud8f2\udf95\ud848\udd59\udb62\udc20\ud82f\udcb7", "\u952b\ub539\u7e6a\u2710\u2923\u84b8\u7f28\u3b9b\u02b3\u1aab\u3d63\u2e2c\u75e1\uc27f\ua143\u347c\ucbe1\u4cc8\uc094\u9995\u6d9f\u62f0", "\ud9a9\udef4\ud909\uddbc\uda7a\uddce\udb53\udf80\ud97c\udf8b\ud8b8\udcf6\ud946\udeb8\ud97a\udfce\udbf9\udddc\ud899\udca8\ud8b5\udcc5\u05c6\ud85d\udf6b\ud963\udffa\ud8aa\uddbe\udae4\udc46\ud9b2\udf26\udadb\udff7\udb0d\udf6b\uda2f\ude5b\u409f\ud986\udf73\ud986\ude93\udbe5\ude97\ud9ed\udc8a\udb7e\udc46\uda1a\udfe1\ud806\ude9a",
        57, 58691, -631943865, 3500998649680340601L, 91075L, true, true, (char) 12262, (char) 17702,
        Double.longBitsToDouble(0x3fdb704271cfc12aL), Double.longBitsToDouble(0x3fe2c62015261b4bL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 4, 13, 7, "\uda87\udd54\ud8f2\udf95\udb5b\udd83\uda55\uddac\ud9b8\udf78\udb40\uddb1\udb0a\uded3\udb61\udd50\uda70\udc81\ud81a\udf53\udad9\ude95", "\u0d4c\ud4ad\u3c70\u6b0e", "\ud98a\udee7\ud9af\ude8d\ud885\ude0b\ud997\udc7d\ud93f\udd5a\uda39\udf2b\ud896\udf94\u47b2\ud9fb\ude7e\ucba3\ud905\udee5\ud95c\udd4e\uda30\ude1c\uda8e\udc91\ud8fc\ude29\udb2f\ude6b\ud8ca\ude48\uda39\udc69\ud971\udfcc\udb29\udc60\uda70\udfdb\ud89d\udf3e\ud9f8\udc83\uda4f\ude2a\udb6f\udd49\udafa\udfc4\udac0\ude57\ud86d\udd6a\ud9bb\udf6e\udb92\udc71\ud987\udd25\uda0f\udd53\udaec\udd19\udadd\udc91\udb45\ude5e\ud9c5\ude3f\uda05\uddfc\ud9b2\ude89\udb2f\udc08\udaa3\uddf9\uda9b\udd1b\u8665\udb2c\udcf8\ud957\udd40",
        23, 80015, -1566784073, -2086595121346509965L, -5335L, false, false, (char) 49609, (char) 39252,
        Double.longBitsToDouble(0x3fe43016362c2bedL), Double.longBitsToDouble(0x3fb2222fd6b83dc0L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 0, 13, 7, "\ud893\udefa\ud94d\udf7e\udaf8\ude8a", "\u5563", "\udb42\ude4b\udb2d\udf6e\ud8eb\udf50\uda45\uddc1\udbb1\udd08\uda95\udf52\ud9c2\udef9\uda48\udc88\u12ea\ud8af\udf62",
        8, 81653, -195162903, -2864904665415628271L, 93693L, false, false, (char) 23859, (char) 21783,
        Double.longBitsToDouble(0x3fcf534e6b1792a0L), Double.longBitsToDouble(0x3fd687ec35f17890L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 2, 9, 13, "\uda87\udd54", "\u3a14\u56cf", "\uda4c\udd62\ud97d\ude0c\uda09\ude1f\udb14\udd4c\uda9b\udee6\ud901\udf25\uda5e\udfa3",
        48, 10907, 608825574, -7497002404592595727L, 34377L, true, false, (char) 41550, (char) 54067,
        Double.longBitsToDouble(0x3feb88380d6a79aeL), Double.longBitsToDouble(0x3fe5199fd0049b49L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 0, 13, 14, "\uda87\udd54\ud961\udeb7\udaec\udc28", "\u91b9\u8e98\u09e7\ub517", "\udb77\ude50\udae5\udd83\ud86c\udfda\udbc7\udd13",
        32, 91871, -190765813, 6367684601634212486L, 43261L, false, false, (char) 46843, (char) 7014,
        Double.longBitsToDouble(0x3fe81371d54a5ad7L), Double.longBitsToDouble(0x3fe6291485c896a5L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 4, 10, 14, "\uda87\udd54\ud8f2\udf8d\udb5b\udd83", "\u5563\u7c42\u87e6", "\udbfe\udf4f\uda85\udd05\udbb1\udd1a\udb2b\udc33\ud9c2\udf0b\uda48\udc88\ud9c4\udf09\ud94f\udde7\udaaf\udfdf\ud9c7\udc05\u93f9",
        46, 72441, -1819761552, -2880974326533009276L, -58698L, false, false, (char) 6876, (char) 9764,
        Double.longBitsToDouble(0x3fd5465322331978L), Double.longBitsToDouble(0x3fe64428da9fab1eL)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 12, 13, 11, "\uda87\udd54", "\u90c1", "\udb28\udf9b\000",
        55, -1000, 0, 389141248L, -3769L, true, false, (char) 61513, (char) 28754,
        Double.longBitsToDouble(0x3fce32feb8f6a808L), Double.longBitsToDouble(0x3fcd2c44218c0178L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 12, 17, 7, "\ud893\udede\ud8f2\udfb0\udb5b\udd83\udb4e\udec9", "\u127b\u1ae7", "\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\uda48\udc88\ud9c4\udf09\ud94f\udde7\udaaf\udfdf\ub263",
        50, 70912, -1098210497, -1114460107501684429L, -53950L, true, true, (char) 34468, (char) 53099,
        Double.longBitsToDouble(0x3fd684b317c15418L), Double.longBitsToDouble(0x3fe9cf181d9a7728L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 6, 13, 3, "\uda83\ude54\ud8f2\udf95\udbfa\ude5e", "\u184c", "\ud8db\ude3a\udbad\udc8d\ud826\udd2e\udbc4\udf7b\uda4a\ude72\udbb5\udf5e\ud806\udc1c\udae4\udc7d\ud909\udd90\udb02\ude91",
        24, 93287, -928373894, -33596658571772121L, -52629L, false, false, (char) 42201, (char) 91,
        Double.longBitsToDouble(0x3fdc896a596c07ecL), Double.longBitsToDouble(0x3fd859a73e3ec69eL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 9, 13, 7, "\udbd2\udc59\udb09\udd5c\udb5b\udd83", "\u8071\u2750\u87e6\uba3a\u41a7\u2710\u69e5\ub770", "\uda23\ude88\uda94\udc71\uda8a\udc25\udbf2\ude44\udb10\udd42\ud9e5\udc39\ud885\ude0b\ud9bb\ude35\ud8ba\udcf8",
        25, 58482, 580906488, -6438566624138777168L, 27161L, true, false, (char) 36670, (char) 42681,
        Double.longBitsToDouble(0x3fceb64077c06d64L), Double.longBitsToDouble(0x3fef53d609d95359L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 12, 15, 16, "\uda87\udd54\ud8f2\udf95", "\u72d0\ub0a1\u173a\u6ee1\ub539\u7e6a\u2710\u5165\u773a\u23fa\ub4cb\u3c70\u6be8\u971d\u2d62\u855a\u6f1f\u68ca\ucb2e\u0eb5\u11ba\u461f\u1e9a\u31e7", "\udb52\udc66\ud968\uddda\ud907\udefc\uda43\uddb5\ud98e\udd60\ud8a9\udd55\ud9d0\ude3d\ud934\udc8d\uda1a\udef0\ud870\udc58\ud8d2\udfa9\udb89\udc0f\udb91\udf82\udb37\udf88\udb9d\udf8f\uda7b\udceb\udaba\udf33\udaaa\udf99\udb2d\uddd5\ud80a\udcd5\ud98d\ude8a\uda04\udc47\udb00\udcc7\ud9db\udf64\ud8ce\udfe3\ud94c\udef6\ud969\ude0a\udb55\udea2\uda56\ude51\uda26\udd7b\ud8b5\udc24\ud955\udf06\ud877\udf01\ud88b\udd7c\uda6d\udc22\ud86d\udf6a\uda3c\udca9\udbbd\udf0b\udb80\udc1a\ud8a6\ude19\uda23\udc9d\ud8e2\udeee\ud9df\udcb0\udb9e\udd9d\ud839\ude52",
        41, 48053, 1292986516, 5110047992583712433L, 76087L, false, true, (char) 48504, (char) 522,
        Double.longBitsToDouble(0x3fe9677516ba10caL), Double.longBitsToDouble(0x3fead65bc12f2f36L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 2, 7, "\uda87\udd54\ud90a\udd81\udb75\udc7f", "\u5563", "\uda6f\udf9e\uda06\udd88",
        10, 38993, 389141437, 1321435120588126183L, -28494L, true, false, (char) 58600, (char) 30783,
        Double.longBitsToDouble(0x3fcd2c44218fd178L), Double.longBitsToDouble(0x3fe08ec1ee70be8aL)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 10, 13, 7, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda6f\udfca\uda06\udd88",
        10, 52817, 389141437, 6669627903369639712L, -28494L, true, false, (char) 58598, (char) 30783,
        Double.longBitsToDouble(0x3fcd2c44218fd178L), Double.longBitsToDouble(0x3fe08ec1ec70be8aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 4, 16, 5, "", "\u9797\u2311\u6dcf\u5563\u73bb\u86ed", "\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\ud8cb\ude28\u1752\000\uda1c\udeee\ud9c7\udc05\ud9e5\udc39",
        3, -1000, -2029018000, 773031510660228041L, 71566L, false, true, (char) 10710, (char) 17876,
        Double.longBitsToDouble(0x3fedf72fc0b789d6L), Double.longBitsToDouble(0x3fd2c701b70a5af0L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 9, 16, 17, "\uda87\udd54\ud8f2\udf95\udb5b\udd83\udb4e\udec9\ud9b0\ude14\uda74\ude39\udad6\udc71\uda62\ude27\uda6f\udfca\uda06\udd88\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\ud8cb\ude28\ud98e\udd75\ud94f\udde7\udaaf\udfdf\ud9c7\udc05\ud9e5\udc39\ud885\ude0b", "\u3315\u2de9\u0767\u0c4c\u0482\u74c3\ua398\u85b7\u7c46\u73da", "\u4216\udb7b\udf60\ud894\udf08",
        42, 23163, -1683451834, -1368457395038204824L, -34659L, true, true, (char) 52481, (char) 62654,
        Double.longBitsToDouble(0x3fe7322326ebeebaL), Double.longBitsToDouble(0x3fd43b647926997cL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=null |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 7, 7, 7, "\u7832\ud8bd\ude8f\udb5b\uddf3\udb4e\udec9\udad4\udce6\ud8e1\udfd8", "\ub482\u7e6a", "\udbb1\udd1a\uda95\udf52\ud904\ude21\uda72\ude78\uda00\udc39\ud88a\udff7\ud991\udcb6",
        53, 39377, -664349473, -4716735485924891536L, -55441L, true, false, (char) 33625, (char) 49015,
        Double.longBitsToDouble(0x3fef85f003994e9fL), Double.longBitsToDouble(0x3fd81e15d45472faL)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 3, 17, 7, "\uda8c\udc48\ud8f2\udf95\udb5b\udd83\udbf7\uddde\ud8ac\udd05\uda74\ude39\udb28\udf9b", "\u7e6a\u2710\u5165\u5a39\u23fa\ub4cb\u3c70\u6be8\u50b9\u2f06\u8478\u9f7e", "\uda5f\uddde\udb37\udec1\ud894\udf63\ud9ab\udfac\ud95f\ude0a",
        14, 52163, -1456980603, 5418152970651139432L, -44433L, false, true, (char) 18196, (char) 24506,
        Double.longBitsToDouble(0x3fdf54c875991646L), Double.longBitsToDouble(0x3fe6755ecb8258d9L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 6, 2, 7, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda70\udc81\uda06\udd88\ud826\udd2e\uda9b\udee6\udb89\udda6\uda95\udf60\ud9c2\udef9\uda48\udc88\udb24\udeba\ud81a\udc9d\ud903\udc8e",
        57, 71713, -667037597, -4716735487173680016L, -22308L, true, false, (char) 49822, (char) 29955,
        Double.longBitsToDouble(0x3f68a17d859a7300L), Double.longBitsToDouble(0x3fd6ca928ad09662L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |a0=[Ljava.lang.Class;:[[interface java.lang.Comparable, interface java.util.List]] |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 1, 4, 13, 7, "\udb49\udf7d\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda70\udc81\uda06\udd88\ud826\udd2e\udaf9\udef5\uda30\ude53\ud84c\udd2b\ud9c2\udef9\uda48\udc88\ud9c4\udf09\ud94f\udde7\udbfc\ude64",
        18, 51584, 1499603704, -4716735487173680016L, -22308L, true, true, (char) 33109, (char) 33901,
        Double.longBitsToDouble(0x3feb481fb5d808c6L), Double.longBitsToDouble(0x3fd416960ad09662L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 12, 4, 15, "\udb49\udf7d\ud8f2\udf95\udb5b\udd83", "\u5563\u127b\u87e6\ub539\u51f8\u796c\uaa94\u7a51\ua614\ub4cb", "\ud94f\udde7",
        55, 85318, 1530595144, 6440748864542263825L, -38198L, true, true, (char) 21372, (char) 45057,
        Double.longBitsToDouble(0x3fd8d4ff928298c0L), Double.longBitsToDouble(0x3fd684b3196ed7c4L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 3, 9, 3, "\uda87\udd54\uda37\udc77\ud907\udca9", "\u33cc\u18dd\u87e6\u2b4b\u2bb6\u48ad\u5165\u773a\u23fa\ub4cb\u3c70\u8920\u50b9\u2f06\u0e65\uceb8\u1601\u17bc\ud45d\u7bb3\u4664\u1e9a\u31e7\uc27a\u43a3\u16dd\u2e8a\u5b37\u3987\ua66e", "\ud8bb\udf21\uda6d\udfd5\udb2e\udf54\udab7\udd47\uda1e\udee0\ud87d\udf2f\ud9ef\udd44\ud8cc\uddb2\ud93d\udfa5\uda97\uddfa\ud9b9\udcb0\uda39\uddfb\udbc2\udf93\udae6\ude9c",
        50, 76677, 491387046, 8752877828414542868L, -34040L, true, true, (char) 9962, (char) 52335,
        Double.longBitsToDouble(0x3fe0212010910401L), Double.longBitsToDouble(0x3fc0b561f2ecf0fcL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 8, 2, 4, "\uda87\udd54\udabb\udf1a\ud80b\udcc5", "\u5563", "\uda41\ude10\ud81d\udca5\ud9ed\udf13\udabc\udf3b\udbb1\udd1a\uda95\udf52\ud9c2\udef9\ud8c1\udde5\udafe\udcd8\ud8d0\udfa4\uda36\udce1",
        30, 68952, 1287358307, -7009745859956398992L, -57886L, true, false, (char) 33104, (char) 33901,
        Double.longBitsToDouble(0x3fc6c07ed61669ccL), Double.longBitsToDouble(0x3fd6ca928ed09662L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 9, 2, 17, "\udbe2\udf6e", "\uc979\u56cf\u5563", "\u6fb3\udaaa\udc95\uda1b\udf80\ud995\udf88\udbb1\udd4d\uda95\udf52\ud9c2\udef9\udb73\udda5\ud9c4\udf09\ud94f\udde7\udbc6\udd01\uda93\udd9f\ud824\udc13",
        52, 72441, -472210320, 3519886045735223326L, -69623L, true, false, (char) 18182, (char) 30903,
        Double.longBitsToDouble(0x3fe460504b3fe256L), Double.longBitsToDouble(0x3fd840c82391ea3eL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 12, 4, 7, "\ud933\udfaa\udab1\udf7c\u48ee", "\u5563\uc0b3\u5ea8\u07db\u438d\u00c2", "\udb3d\udc11\ud9c2\ude8e\uda48\udc88\ud9c4\udf09\udb64\udef6\udbd1\udc4e",
        51, 69056, -1690447773, -5781643284540775312L, -55331L, false, false, (char) 22097, (char) 26459,
        Double.longBitsToDouble(0x3fdcc89d816ac5c0L), Double.longBitsToDouble(0x3fe48a87dd41eb7dL)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 0, 15, 6, "\uda4f\udce8\ud926\udd80\udaf8\ude8a", "\uc507", "\udb42\ude4b\udb2d\udf6c\ud8eb\udf50\uda45\uddc1\udbb1\udd08\ud97e\udf54\ud9c2\udef9\ud8d5\ude23\udb07\udc5f\u9742\ud935\uddca\ud9c7\udc8a\ud9e5\udc39\ud885\ude0b\ud9bb\ude35\uda5f\ude0b\udb37\udec1",
        5, 57709, -1767547208, -549220843055260490L, -84325L, false, true, (char) 27712, (char) 28484,
        Double.longBitsToDouble(0x3fe7aa00840ab701L), Double.longBitsToDouble(0x3fe6f913679a96b5L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 13, 7, "\ud893\udefa\ud94d\udf7e\ud912\ude5e", "\u9cb4\uc7bf\u8c00\u7054", "\udaa7\udfd9\udbb1\udd08\uda95\udf52\ud9c2\udef9\uda48\udc88\u12ea\ud8af\udf62\ud9b1\udfe0\ud9c7\udc05\ud9e5\udc39\ud885\ude0b\ud9bb\ude35",
        23, 92181, -1057304444, 99373184840982200L, -58198L, false, false, (char) 42861, (char) 64555,
        Double.longBitsToDouble(0x3fe7c5e241aef517L), Double.longBitsToDouble(0x3fea50315f42f082L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 16, 16, 17, "\ud893\udefa\ud98b\udd7d\ud9af\udd75", "\u9e38", "\udb42\ude4b\udb2d\udf6e\ud8eb\udf50\ud866\udf4b\udbac\udcd6\ud866\udcb7\ud9c2\udef9\uf30b\u12ae\ud8af\udf62",
        38, 81653, -193438231, -2864904665417659887L, 81013L, false, false, (char) 23859, (char) 21783,
        Double.longBitsToDouble(0x3fcf534e6b1792a0L), Double.longBitsToDouble(0x3fd687ec31917890L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 10, 11, 7, "\udab8\udff0\ud94d\udf97\udaf8\ude8a", "\u5ea2\u986f", "\udb2d\udf6e\udb4f\udd07\uda45\uddc1\udbb1\udd08\uda95\udf52\ud9c2\udef9\uda48\udc88\u12ea\u239e\ud920\udf9e\ud927\udc0b\uda17\ude1d\ud8d9\udf36",
        8, 56202, 1332701222, -4585537939678622877L, -63633L, false, false, (char) 64555, (char) 18752,
        Double.longBitsToDouble(0x3fed26aabc74be35L), Double.longBitsToDouble(0x3fe0f4b5a8cccd9fL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.MockSettingsImpl:@?\0121=new org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 12, 12, 9, "\uda87\udd54\ud8f2\udf95", "\u72d0\ub0a1\u173a\u6ee1\ub539\u7e6a\u2710\u5165\u773a\u23fa\ub4cb\u3c70\u6b97\u971d\u2d62\u855a\u6f1f\u68ca\ucb2e\u0eb5\u11ba\u461f\u1e9a\u31e7", "\udb52\udc66\ud968\uddda\ud907\udefc\uda43\uddb5\ud98e\udd60\ud8a9\udd55\ud9d0\ude3d\ud934\udc8d\uda1a\udef0\ud870\udc58\ud8d2\udfa9\udb89\udc0f\ud9df\udeca\ud8ad\uddbb\udb9d\udfef\uda7b\udceb\udaba\udf33\udaaa\udf99\udb2d\uddd5\ud80a\udcd5\ud98d\ude8a\uda04\udc47\udb00\udcc7\ud9db\udf64\ud8ce\udfe3\ud94c\udef6\ud969\ude0a\udb55\udea2\uda56\ude51\uda26\udd7b\ud8b5\udc24\ud955\udf06\ud877\udf01\ud88b\udd7c\uda6d\udc22\ud86d\udf6a\uda3c\udca9\udbbd\udf0b\udb80\udc1a\ud8a6\ude19\uda23\udc9d\ud8e2\udeee\ud9df\udcb0\udb9e\udd9d\ud839\ude52",
        41, 48053, 1292986516, 5110047992583712433L, 76087L, false, true, (char) 48504, (char) 522,
        Double.longBitsToDouble(0x3fe9677516ba10caL), Double.longBitsToDouble(0x3fead65bc12f2f36L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 11, 15, 16, "\uda36\udfcd\ud912\udeac", "\u3839\u437d\u173a\u6ee1\ub539\u7e6a\ud4ce\ub07e\u773a\u23fa\ub4cb\u0fe6\u6be8\u971d\u2d62\u855a\ud33b\u68ca\ucb2e", "\ud896\udf94\ud9ab\udfac\uda2c\udc8f\udb33\ude03\udbdd\udeb9\udb52\udc66\ud968\uddda\ud907\udefc\uda43\uddb5\ud97d\ude79\uda06\udcc1\udba6\udff1\ud88d\udf77\uda1a\udef0\ud870\udc58\ud8d2\udfa9\udb89\udc0f\ud817\udf66\uda79\udfe5\udb9d\udf8f\uda7b\udceb",
        3, 42066, -1613792895, -3987871397787196440L, -31478L, false, false, (char) 47754, (char) 30067,
        Double.longBitsToDouble(0x3fe486f791963b04L), Double.longBitsToDouble(0x3fb28ea18f933288L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 8, 4, 7, "\uda87\udd54\ud90a\udd81\uda2c\ude5a\udb3a\udf06\ud82e\udf74\uda74\ude39", "\ub4dd\u7e6a", "\udbb1\udd1a\udb0e\udebf\ud914\udfa3\ud8fa\udfae\uda8e\udd75\ud9e2\udde7\ud838\udcc8",
        48, 69097, -667037597, -4685818935912008080L, -47704L, true, true, (char) 12455, (char) 19380,
        Double.longBitsToDouble(0x3fec27a2ee441f67L), Double.longBitsToDouble(0x3fe0f3840ef655deL)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 3, 2, 17, "\uda87\udd54\ud8f2\udf95\udb5b\udd83\udb4e\udec9\ud9b0\ude14\uda74\ude39\udad6\udc71\uda62\ude27\uda6f\udfca\uda06\udd88\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\ud8cb\ude28\ud98e\udd75\ud94f\udde7\udaaf\udfdf\ud9c7\udc05\ud9e5\udc39\ud885\ude0b", "\u3315\u2de9\u0767\u0c4c\u0482\u74c3\ua398\u85b7\u7c46\u73da", "\u4216\udb7b\udf60\ud894\udf08",
        42, 23163, -1683451834, -1368457395038204824L, -34659L, true, true, (char) 52481, (char) 62654,
        Double.longBitsToDouble(0x3fe7322326ebeebaL), Double.longBitsToDouble(0x3fd43b647926997cL)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 3, 3, 17, "\uda87\udd54\ud8f2\udf95\udb5b\udd83\udb4e\udec9\ud9b0\ude14\ud838\udc3a\udad6\udcce\uda62\ude27\uda6f\udfca\uda06\udd88\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\ud8cb\ude28\ud98e\udd75\ud94f\udde7\udaaf\udfdf\ud9c7\udc05\ud9e5\udc39\ud885\ude0b", "\u3315\u2de9\u0767\u0c4c\u0482\u74c3\ua398\u85b7\ub104\u73da", "\u4216\udb7b\udf60\ud894\udf08",
        42, 23163, -1683451834, -1368457395035779992L, -34659L, true, true, (char) 52517, (char) 62654,
        Double.longBitsToDouble(0x3fe7322326ebeebaL), Double.longBitsToDouble(0x3fd43b647926997cL)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 10, 10, 17, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\ucdc7", "\uda51\udc81\uda06\udd88\ud826\udd2e\uda9b\udee6\udb0c\udfb1\ud9f5\udccd\ud9c2\udef9\uda48\udc88\ud804\udd09\ud818\udccb\ud903\udc8e",
        4, 75133, -667037597, -4716735487173680016L, -22308L, true, false, (char) 49822, (char) 46926,
        Double.longBitsToDouble(0x3f68a17d859a7300L), Double.longBitsToDouble(0x3fd6ca9280d09662L)));
  }
  @Test(timeout = 4000)
  public void test46() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=org.mockito.internal.util.MockName:integer |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 9, 7, 7, "\uba3f\ud8f2\udf95\udb5b\udd83", "\u5563", "\uda70\udc81\uda06\udd88\ud826\udd2e\uda9b\udee6\udb89\udda6\uda95\udf60\ud9c2\udef9\uda48\udc88\udb24\udeba\ud81a\udc9d\ud903\udc8e",
        57, 71713, -667037597, -4716735487173680016L, -22308L, true, false, (char) 49822, (char) 29955,
        Double.longBitsToDouble(0x3f68a17d859a7300L), Double.longBitsToDouble(0x3fee754945684b31L)));
  }
  @Test(timeout = 4000)
  public void test47() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 10, 9, 5, "\udb49\udf7d\ud8f2\udf95\udb5b\udd83", "\u5563\u127b\u87e6\ub539\uad4a\u6d07\uaa94\u7a51\ua614\ub4cb", "\ud94f\udde7",
        55, 85318, 1614607784, 6440942571862280721L, -38198L, true, true, (char) 21372, (char) 45057,
        Double.longBitsToDouble(0x3fd8d4ff928298c0L), Double.longBitsToDouble(0x3fd684b3196ed7c4L)));
  }
  @Test(timeout = 4000)
  public void test48() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 9, 9, 4, "\ud88a\ude75\u61d3\ud847\udf6d", "\u55ad", "\udb21\udeed\ud997\udeae\udbbb\uddf9\udabc\udf3b\udbb1\udd1a\uda95\udf52\udbc6\udfba\ud8c1\uddc3\udafe\udcd8\ud8d0\udfa4\uda36\udce1",
        30, 89904, 1287358307, -7009745859956398992L, -57886L, true, false, (char) 33104, (char) 54960,
        Double.longBitsToDouble(0x3f780fda76cd3980L), Double.longBitsToDouble(0x3fd6ca928ed09662L)));
  }
  @Test(timeout = 4000)
  public void test49() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 9, 4, 17, "\udbe2\udf6e\udaed\uddd3\ud93a\udc47\ud9a1\udece\ud9aa\udf14\uda74\ude39\ud9f5\udc97\ud9aa\ude5d", "\u00c2\u77ef\u776d\u280d\ub4cb\u09b9\u6be8\u50b9\ubdb1\ua5ea", "\udb1a\ude15\ud958\udec7\udbcc\udc96\uba56\udb43\udcf2\udb0f\udf41\ud996\udf68\u607a\ud981\udffd\uda8f\udd18",
        27, 23444, -1470973496, -3747596526481474006L, -89618L, true, true, (char) 19167, (char) 24486,
        Double.longBitsToDouble(0x3fe199f166d2a700L), Double.longBitsToDouble(0x3febe7d0decd6ec0L)));
  }
  @Test(timeout = 4000)
  public void test50() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 14, 13, 7, "\uda87\udd54\ud8f2\udf95\udb5b\udd83", "\u5563", "\ud8bc\uddd7\uda06\udda4\ud826\udd2e\uda9b\udee6\udbb1\udd1a\uda95\udf52\ud9c2\udef9\uda48\udc88\ud9c4\udf09\ud94f\udde7\udaaf\udfdf",
        53, 69097, -667037597, -4716735487173680016L, -22308L, true, true, (char) 33109, (char) 33901,
        Double.longBitsToDouble(0x3fc6c07ed61669ccL), Double.longBitsToDouble(0x3fd6ca928ad09662L)));
  }
  @Test(timeout = 4000)
  public void test51() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |a0=[Ljava.lang.Class;:[[interface java.util.List]] |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |a0=[Ljava.lang.Class;:[[interface java.util.List]] |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 4, 4, 7, "\udbd9\udd5d\udbf2\ude9a\u48ee", "\u5563\uc0b3", "\udaaa\udc95\ud8b3\ude6d\udb9a\ude23\ud91f\ude66\uda72\udfeb\ud9c2\udef9\uda48\udc88\ud9c4\udf09",
        5, 87742, 1646382653, -838218286440525725L, -15888L, false, false, (char) 2825, (char) 40998,
        Double.longBitsToDouble(0x3fee028e79f47b12L), Double.longBitsToDouble(0x3fdaee6fa8154474L)));
  }
  @Test(timeout = 4000)
  public void test52() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |a0=[Ljava.lang.Class;:[[interface java.lang.Comparable, interface java.util.List]] |this=org.mockito.internal.creation.MockSettingsImpl:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |a0=[Ljava.lang.Class;:[[interface java.lang.Comparable, interface java.util.List]] |this=org.mockito.internal.creation.MockSettingsImpl:@?\012",
        Z.run(T, 2, 4, 4, 7, "\udba7\udffb", "\uc45b\u964d\u0407\ua2ab\u74e9\ud670\u6fb9\u610a\u80cf\u5499", "\uda48\udc88\ud9c4\udf09\ud94f\udde7\udaa9\udeac\ud9c7\udc05\ud9e5\udc39\udacb\ude0e\ud9bb\ude35\ud92d\ude8e\udb0f\uddbe\ud8d9\udd97",
        38, 94592, 984878836, -6748415159688033270L, 27173L, true, true, (char) 51192, (char) 42105,
        Double.longBitsToDouble(0x3fceb80d586007b0L), Double.longBitsToDouble(0x3fdcfea5c3db9deaL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.creation.MockSettingsImpl|isSerializable||new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|serializable||new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.util.MockUtil|createMock|java.lang.Class,org.mockito.internal.creation.MockSettingsImpl|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.creation.MockSettingsImpl|defaultAnswer|org.mockito.stubbing.Answer|new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|extraInterfaces|[Ljava.lang.Class;|new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|getDefaultAnswer||new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|getExtraInterfaces||new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|getMockName||new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|getSpiedInstance||new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|initiateMockName|java.lang.Class|new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|name|java.lang.String|new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|spiedInstance|java.lang.Object|new:org.mockito.internal.creation.MockSettingsImpl:",
    "C|org.mockito.internal.creation.MockSettingsImpl|<init>|",
    "M|org.mockito.internal.util.MockUtil|getInterceptor|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|getMockHandler|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.util.MockUtil|getMockName|java.lang.Object|new:org.mockito.internal.util.MockUtil:",
    "M|org.mockito.internal.creation.MockSettingsImpl|isSerializable||new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.creation.MockSettingsImpl|serializable||new:org.mockito.internal.creation.MockSettingsImpl:",
    "M|org.mockito.internal.util.MockUtil|createMock|java.lang.Class,org.mockito.internal.creation.MockSettingsImpl|new:org.mockito.internal.util.MockUtil:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
