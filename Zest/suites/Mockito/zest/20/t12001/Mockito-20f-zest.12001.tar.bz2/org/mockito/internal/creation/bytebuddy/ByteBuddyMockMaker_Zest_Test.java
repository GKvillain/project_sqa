package org.mockito.internal.creation.bytebuddy;
import org.junit.Test;
import static org.junit.Assert.*;
public class ByteBuddyMockMaker_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 4, 1, "\ud922\udf42\udb08\uded1\ud843\ude9e", "\u00ac\u595f\uaf32\u06e6\uc81e\u390a\u40fd\u49e5\u3308\u399c\uc683\u2e29", "\ud806\udc25\udbb5\udf57\ud85f\udd84\ud8c6\ude8c\ud868\udc2b",
        53, 41154, -521798517, 664041753445881075L, 76416L, true, false, (char) 25780, (char) 37977,
        Double.longBitsToDouble(0x3fee988b68fe0b16L), Double.longBitsToDouble(0x3fd5881d1a5c7130L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=null |this=org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\012",
        Z.run(T, 2, 8, 5, 0, "\ud924\udef4\udb08\uded1\ud843\ude9e\ud9a9\udfbe\uda1a\udec7\ud9a5\udd37\ud96e\uddd6\ud937\udd75\ud919\udec2\uda21\ude49\ud817\udcab", "\u3308\u399b\ua349", "\ud994\udf24",
        9, 67892, -570020206, -3786439162027643915L, -71462L, true, false, (char) 1883, (char) 24106,
        Double.longBitsToDouble(0x3fe84ef15920320fL), Double.longBitsToDouble(0x3fb1f9828f2556f0L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 6, "\ud922\udf42\udb08\uded1\udbf2\udd97", "\u00ac\u595f\u5fca\u06e6\uc81e\u390a\u4552\u4a2e\u3308\u399c\uc683\u2e29", "\ud806\udc25\udbb5\udf57\ud85f\udd84\ud89a\udd11\ud868\udc2b",
        53, 41154, -521798517, 664041753452827891L, 76416L, true, false, (char) 25780, (char) 37977,
        Double.longBitsToDouble(0x3fee988b68fe0b16L), Double.longBitsToDouble(0x3fd5881d1a5c7130L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.bytebuddy.ClassInstantiator$UsingObjenesis:@?\0121=org.mockito.internal.creation.bytebuddy.ClassInstantiator$UsingObjenesis:@?\012",
        Z.run(T, 2, 6, 6, 6, "\ud9de\udc28\udad4\udc91\ud9e8\udd41\udaf7\udf04\udaf9\udd51\udb27\ude04\udaea\udc58\uda3b\ude70\udb77\uddae\ud95c\udf4d\udaee\udf78\udaa3\udffb\ud8a9\udfe9\udb17\udca3\ud8ad\udc33\uda3f\ude10\udbd1\udccb\udaa3\udf86\udb9c\ude53\ua699\udbb5\udefa\ud891\udd7d\ud8c6\ude8c", "\u4598\u57a5\u1a0d\u80b4\u61f3\u2727\u3361\u147c\u7e92\u15d1\u40b0\u5f80\uad9c\u8f97\ub4b7\u384b\u9b63\u0ecc\ucc5f", "\ud813\udcf1\ud945\ude4e\ud8a6\udf3b\ud83f\ude64\udb2e\udedc\u65a8\udbc9\udc6a\udbdc\udc4b\ud9c3\udc1b",
        56, 56503, 769199233, 2289926469470081357L, -12788L, false, false, (char) 10586, (char) 47603,
        Double.longBitsToDouble(0x3fee46b3a52d20baL), Double.longBitsToDouble(0x3fcc826c96b5ecb8L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=new org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\012",
        Z.run(T, 2, 8, 8, 1, "\ud922\udf42\udb08\uded1\ud843\ude9e", "\u00ac\u595f\uaf32\u06e6\uc81e\u390a\u40fd\u49e5\u3308\u399c\uc683\u2e29\u510a", "\udbb5\udf57\ud85f\udd84\ud8c6\ude8c\ud868\udc2b",
        53, 41154, -521798517, 664041753445881075L, 76416L, true, false, (char) 25780, (char) 37977,
        Double.longBitsToDouble(0x3fee988b68fe0b16L), Double.longBitsToDouble(0x3fd5881d1a5c7130L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 4, 1, "\udb5f\udcae\udaed\udf4f\ud843\ude9e\uda50\udce8\uda1a\udf03\ud9a5\udd37\udb2c\uddd5\ud937\udd75\udb8d\udc36\udb25\ude1e", "\u55da\u32ef\u399c", "\udaff\udfd9\ud994\udf24",
        9, 47457, -554715343, -3786439162027687179L, -71462L, true, false, (char) 1883, (char) 29610,
        Double.longBitsToDouble(0x3fe84ef1592032c5L), Double.longBitsToDouble(0x3fea3f3050fd4476L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=java.lang.String:'java.lang.Thread.State', loaded by classloader : 'null'\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 4, 1, "\ud922\udf42\udb08\uded1\ud943\udd3f", "\uc074\u8ffb\u6d6c\uaca1\uadfa\u9f97\u40fd\u49e5\u3308\u399c\uc683\u2e29", "\ud806\udc25\udbb5\udf57\ud85f\udd84\ud8c6\ude8c\ud868\udc2b",
        53, 41154, -521798517, 664041753445881075L, 76416L, true, false, (char) 55476, (char) 10931,
        Double.longBitsToDouble(0x3fee988b68fe0b16L), Double.longBitsToDouble(0x3fb620746971c4c0L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\012",
        Z.run(T, 1, 8, 4, 1, "\ud922\udf42\udb08\uded1\ud843\ude9e", "\000", "\ud919\uddc6\ube31\ud816\udff9N\000\000\000\000\ud8ad\udd64\udaff\udfa5\ud994\udf24\ud806\udc25\ud94d\udfa3\ud821\udf85",
        -5, -1000, 759489, -536806400L, -99968L, false, false, (char) 47359, (char) 37977,
        Double.longBitsToDouble(0x3fee988b68fe0b16L), Double.longBitsToDouble(0x3fd5881d1a5c7130L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=java.lang.String:'java.lang.String', loaded by classloader : 'null'\012",
        Z.run(T, 2, 8, 3, 8, "\ud922\udf42\udb08\uded1\ud843\ude9e\ud8f4\udfa4\uda1a\udec7\ud9a5\udd37\udb2c\uddd5", "\u04c1\u8003\u22ac\u49e5\u172e\u39b7\uc683\u2e29\u4c23\u45e5\ubef4\u69e3\u4046", "\ud894\udc77\ud9fa\udd69\udb14\udeb5\uda2d\udcfd\uda58\udef4\ud8b1\uddfc\udbc6\ude34\udb12\udd64\u3bd4\udbae\uddc5\ud944\udc58\ud942\udd58\udb66\udcad\ud83d\udfc9\ud87a\udf23\udaa0\udcea\udaf2\ude18\ud9d8\udcf8\uda04\uddc8",
        40, 48391, -1829333873, -7644702091922957355L, 26981L, true, false, (char) 27273, (char) 4067,
        Double.longBitsToDouble(0x3fe0fd0bf41f2b20L), Double.longBitsToDouble(0x3fdd2f874fbeb242L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 5, 1, 1, "\ud974\udd87\udb08\udf0a\ud843\ude9e", "\u00ac\u595f\u7275\u06e6\uc81e\u390a\u40fd\u49e5\u3308\u399c\uc683\u2e29", "\uda9f\ude4c\ud901\udd0b\ud85f\udd84\ud8c6\ude8c\ud868\udc2b",
        53, 41154, -521798517, 664041753445881075L, 76416L, true, false, (char) 25780, (char) 37977,
        Double.longBitsToDouble(0x3fee988b6e1da916L), Double.longBitsToDouble(0x3fdc9a3ced6f6a82L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 5, 4, 1, "\ud922\udf42\udb08\uded1\ud843\ude9e", "\u00ac\u595f\uaf32\u06e6\uc81e\uc32e\u590d\u49e5\u3308\u399c\uc683\u2e29", "\udafe\udebe\udbd1\udf53\ud85f\udd84\ud8c6\ude8c\ud868\udc2b\uda71\udf7c\ud9fa\udd69\ud961\udf26\ud974\udd34\udb08\udec6\ud8b1\uddfc\uda5a\udff1\uda98\udff9\ud902\udeff\udbae\uddac\ud90a\udc7a\ud942\udd8e\udba4\udd0d\udbce\udf70\u1487\ud9d3\udd75",
        26, 11901, -794965589, 7193162035679370660L, -17422L, true, false, (char) 46845, (char) 30519,
        Double.longBitsToDouble(0x3fe835f4151fcbb1L), Double.longBitsToDouble(0x3fd2e47d053c121aL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 1, 4, 1, "\ud8b5\ude94\udb08\uded1\ud81e\udc4c\udb32\ude05\ud812\udf26\u3b90\udae5\uddce\ud937\udd75\ud919\udec2\uda21\ude49\ud9ac\udd35\ud9ab\udceb\ud898\udef2", "\uc5bb\u2e29", "\ud809\udf25\udb24\udeb6\ud9dd\ude3e\uda0a\udc7d\uda2f\udf59\udab4\udf30\udb22\ude1d",
        51, 53709, 942363891, 4831401372278973963L, -16502L, false, true, (char) 28373, (char) 40228,
        Double.longBitsToDouble(0x3fefca0b652e3898L), Double.longBitsToDouble(0x3fdd325fee773722L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.String:'java.util.ArrayList', loaded by classloader : 'null'\0121=java.lang.String:'java.util.ArrayList', loaded by classloader : 'null'\012",
        Z.run(T, 2, 2, 2, 2, "\u6454\ud967\uddce\udb48\uddf4", "\u00ac\u595f\uaf32\uc868\uc81e\u390a\u979b\u49d3\ua44d\u399c\uc683", "\ud966\udc24",
        9, 51657, -565798048, -3786439162027643915L, -71462L, true, false, (char) 4351, (char) 56073,
        Double.longBitsToDouble(0x3fd930307332e4b2L), Double.longBitsToDouble(0x3fb1f9828eb556f0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=java.lang.String:null\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 4, 1, "\ud922\udf42\ud80e\udfb4\ud877\udf78", "\u7de1\u685f\u2477", "\udb00\udfbd\ud9d7\udc61\udb55\udc1a\uda16\udcad\udb5a\udc34",
        -4, 70518, -2124302397, -4798647992014753062L, -38423L, true, true, (char) 46952, (char) 119,
        Double.longBitsToDouble(0x3fb05442e28a1fd8L), Double.longBitsToDouble(0x3fe9a7021ca5ff3cL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 5, 7, 4, "\ud922\udf42\udb08\uded1\ud843\ude9e", "\u00ac\u595f\uaf32\u06e6\u173b\u390a\u40fd\u49e5\u2d67\u6e7a\u1f0a\u2e18", "\ud806\udc25\udbb5\udf57\ud85f\udd84\ud8c6\udec1\ud868\udc2b\ud8f1\udd73",
        23, 39878, 158125897, -2437761369998679287L, -3815L, false, true, (char) 37977, (char) 1771,
        Double.longBitsToDouble(0x3fcc78da1c25ee48L), Double.longBitsToDouble(0x3fdbddfc8bf51f56L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.String:null\012",
        Z.run(T, 1, 2, 4, 0, "", "\000", "",
        -5, 90000, 0, 4615345193151938097L, -100000L, false, false, (char) 49775, (char) 41185,
        Double.longBitsToDouble(0x3fdcf560000180f0L), Double.longBitsToDouble(0x0L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=java.lang.String:null\012",
        Z.run(T, 2, 5, 3, 4, "\ud922\udf42\udb08\uded1\ud903\udc53", "\u00ac\u595f\uaf32\u72de\uca84\ub3b1\u63b6\ua01e\u32fe\u39d1\u9f98", "\udbac\ude58\uda7f\udfd6\udaaa\udfc3\ud886\udfc2\ud8c6\ude3b",
        2, 73753, -1726451846, -8798348622913133055L, -43433L, false, true, (char) 28241, (char) 37201,
        Double.longBitsToDouble(0x3fc4c2769dd3da10L), Double.longBitsToDouble(0x3fcfc162d56238b4L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=java.lang.String:'java.lang.String', loaded by classloader : 'null'\0121=java.lang.String:'java.lang.String', loaded by classloader : 'null'\012",
        Z.run(T, 2, 3, 3, 8, "\ud914\udcd2", "\u78a5\u674d\u00ac\u396b\uaf32\u06e6\uc81e\u422b\u40c2\u49e5\u3308\u1dd3\u621c\uc298\u510a\u57ff\u3d4e\u721c\u3e4d\u5f5d\ucfc3\uaf43\u123c\u4fae\u1161\u44da\u7e5d\uca5b\u3361\u4c84\u72f1\u4940\u9f9a\u648f\ub2ac\u18db\u61a0", "\uda32\udeda\ud8a3\udf75\udb44\udde3\udafa\udecb\udad7\udd00\udb3a\udfa5\udaee\udeff\uda54\udd6f\udb60\udf7e\udbb6\udf5f\ud81b\udf52",
        3, 16191, -1633566702, 9122182237685824800L, -96289L, false, false, (char) 56287, (char) 3618,
        Double.longBitsToDouble(0x3fe5130cc21ac439L), Double.longBitsToDouble(0x3f972458313f82e0L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=null |this=org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\0121=null |this=org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:@?\012",
        Z.run(T, 2, 5, 5, 0, "\uda95\udd0c\ud902\udc3b\ud938\udf40\ud9ab\udd70\uda1a\udec7\udaff\udf45\ud8ef\udded\ud9e2\uddfe\ud940\udfd2\uda21\ude49\ud817\udcab", "\u3308\u399b\ua349", "\ud994\udf24",
        9, 67892, -570020206, -3786439162027643915L, -71462L, true, false, (char) 1883, (char) 24106,
        Double.longBitsToDouble(0x3fe84ef15920320fL), Double.longBitsToDouble(0x3fb1f982a1bb36f0L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=java.lang.String:null\0121=java.lang.String:null\012",
        Z.run(T, 2, 2, 2, 0, "\ud924\udef4\uda33\udce5\udaf6\udc03\ud9a9\udfbe\uda1a\udec7\ud9a5\udd37\ud96e\uddd6\ud9c9\udcde\ud919\uddf1\uda21\ude49\ud817\udcab", "\ub808\ua547\uc81e", "\ud994\udf24",
        9, 67892, -570020206, -8706340279953200139L, -44248L, true, false, (char) 59837, (char) 34389,
        Double.longBitsToDouble(0x3fdbb8a6cb158b52L), Double.longBitsToDouble(0x3fccee85676d2ac8L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=java.lang.String:null\0121=java.lang.String:null\012",
        Z.run(T, 2, 3, 3, 8, "\ud922\udf42\udb08\uded1\ud843\ude9e", "\u00ac\u595f\uaf32\ub214\u04c1\u8003\u22ac\u49e5\u172e\u39b7\uc683\u2e29", "\udb88\ude07\udbb5\udf57\udb41\udc74\ud8c6\ude8c\ud868\udc2b\ud820\udd3d\ud9fa\udd0e\udb14\udeb5\udbc5\udf49\uda50\udd2f",
        24, 92347, 1626704814, 8038535287693738175L, 85656L, false, true, (char) 21958, (char) 28760,
        Double.longBitsToDouble(0x3fd88f37b33c72e4L), Double.longBitsToDouble(0x3feda84113511571L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 2, 7, 4, 3, "\ud922\udf42", "\u2670\ua275\uad71\uadd0\uaf32\u06e6\uc81e\u7a14\uaa6f\u49e5\u2d6c\uc8ba\u4105\u57e9\u510a\u57ff\uacb0\u699f\u4046\u745c\ucfc3\u992d\u76ca\u4fae\u1161\u44da\u092a\u1493\u55d5\u4236\u598e\u94f7\uc370\u486c\u9127\u53ea\ub486", "\udafd\udf06",
        40, 90883, 638885473, -5984587122489719095L, -65738L, false, true, (char) 13954, (char) 45755,
        Double.longBitsToDouble(0x3febbeac45e6b4e4L), Double.longBitsToDouble(0x3fd392eeafe50eccL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|createMock|org.mockito.mock.MockCreationSettings,org.mockito.invocation.MockHandler|new:org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:",
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|asInternalMockHandler|org.mockito.invocation.MockHandler|static",
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|describeClass|java.lang.Class|static",
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|describeClass|java.lang.Object|static",
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|ensureMockIsAssignableToMockedType|org.mockito.mock.MockCreationSettings,java.lang.Object|new:org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:",
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|getHandler|java.lang.Object|new:org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:",
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|initializeClassInstantiator||static",
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|resetMock|java.lang.Object,org.mockito.invocation.MockHandler,org.mockito.mock.MockCreationSettings|new:org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:",
    "C|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|<init>|",
    "M|org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker|createMock|org.mockito.mock.MockCreationSettings,org.mockito.invocation.MockHandler|new:org.mockito.internal.creation.bytebuddy.ByteBuddyMockMaker:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
