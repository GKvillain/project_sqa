package org.mockito.internal.configuration;
import org.junit.Test;
import static org.junit.Assert.*;
public class DefaultInjectionEngine_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\ud939\udc32\uda55\ude57\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\u301c\u02ba", "\uda52\udccb\ud825\udf0c\ud9c5\udfc0\udbed\udcae\ud902\udce8\udbc3\ude50\udbac\udc0c\udab2\udebe\udba9\udeee\udb29\udddf\udb96\udda6",
        -4, 38404, 1203317294, -3815653416696452054L, -91937L, true, false, (char) 26167, (char) 43107,
        Double.longBitsToDouble(0x3fe9f749eca87830L), Double.longBitsToDouble(0x3fd2f95af2e022e2L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\ud939\udc32\ud9b0\udda4\ud953\udd9e\udb22\ude99\ud858\udcf3\uda7f\udfb8", "\u301c\u02ba", "\uda52\udccb\ud825\udf0c\ud9c5\udfc0\udbed\udcae\udb90\udf30\udbc3\ude50\udbac\udc0c\udbbf\udf37\ud8c6\udc18\udb29\udddf\udb96\udda6",
        -4, 38404, 1203317294, -3815653416696452054L, -71523L, true, false, (char) 32379, (char) 51794,
        Double.longBitsToDouble(0x3fd2f95af2e022e2L), Double.longBitsToDouble(0x3fd22d46460ff746L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\ud939\udc32\ud8dd\ude1b\uda8a\udf5f\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\u4076\u2687", "\uda52\udccb\ud825\udf0c\ud85b\udecb\udaa2\udce6\udb24\udc1a\udbc3\uddd5\udbac\udc0c\udab2\udebe\udba9\udeee\udb29\udddf\uda60\udd86",
        39, 38404, 1203317294, -3775121020050117590L, 68476L, false, true, (char) 1439, (char) 20432,
        Double.longBitsToDouble(0x3fe9efb156e3ceafL), Double.longBitsToDouble(0x3fd5fdcfd86d8858L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 3, "\ud939\udc32\ud9b9\udc8d\ud800\ude33\ud809\uddd4\udabc\ude29\udb68\udc65\uda70\udee1\uda20\udd6c\ud976\udd83\udb97\ude0c\ud9ff\udf31\udb4c\udc86\uda52\udccb\ud825\udf0c\u2983\udba8\udcc7\ud902\udce8\udbc3\ude50\udbac\udc0c\udab2\udebe\ud991\udee2\udb33\udcf2\ucf76\udb7a\udda2\ud941\udd07\ud99a\ude75\udb6b\udd37\ud977\udd98\ud92f\udc76\udb0b\ude8e\udb7e\udfa9\udb4c\udf0b", "\u9405\u3a21\uaea6\u35db\u7583\u2c69\u07df\uc02b\u6f45\u3bfb\u5e63\u97e6\u03fb", "\ud81e\udc63\ud8e5\uddc5\uda68\uddbc\ud9cf\udd89\udb7d\udd21\ud937\udfde\ud9b8\uddcb\ud9de\udc3f\uda80\udf85\u3706\udb93\udde5\ud83a\udc70\ud868\ude0a\ud879\udd30\ud84a\udf15\ud828\udfb0\ud864\udf0b\ud981\udf73\udad2\udfe8\ud83b\udcdf\ud80b\udd42\uda5d\udc34\uda56\udff8\ud96b\udd5c\ud871\ude14\ud8f9\udd2e\udba6\udf07\udbd9\udd40\udb1d\udd5c\uda64\udf02\u5688\uda9e\udd7f\uda12\udd60\udb27\udfa1\udb07\ude4a\uda66\udcf2\ud963\udfaf",
        40, 53947, 12356077, -2874041850422061710L, 4045L, false, true, (char) 29623, (char) 9453,
        Double.longBitsToDouble(0x3fe63d0f53a5b92bL), Double.longBitsToDouble(0x3fdee34312d76e0eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\ud939\udc32\uda55\ude57\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\ua22f\u3ca6", "\uda52\udccb",
        14, 20404, 1494280438, -1455593736160799262L, 56294L, true, false, (char) 44812, (char) 9056,
        Double.longBitsToDouble(0x3fc3c3a2faf18314L), Double.longBitsToDouble(0x3fe175c26b6f47b9L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 2, 0, 2, "\ud939\udc81\uda55\ude57\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\u5772\ubf3e\u0f60\u7a24\u803d\u9dfd\u1459\ubbd3\u5d87\uce7c\u485c\u276e\u5db4\u7932", "\ud936\ude82\ud801\ude68\uda38\ude27\udac7\udc9f",
        5, 50532, -335511211, -6673243378328975803L, -45187L, false, true, (char) 62680, (char) 55006,
        Double.longBitsToDouble(0x3fd7011711785ea2L), Double.longBitsToDouble(0x3fd976737478cbd0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 1, 0, 0, 2, "\ud939\udc32\uda55\ude57\u3307\ud918\udf06\ud84d\udc00\uda6f\udee8", "\u301c\ud0f2\ub552\u261b", "\ud9b2\udd97\udbed\udcae\ud902\udce8",
        5, 84335, 1499831674, 5320389524649436471L, 61950L, false, true, (char) 27607, (char) 23336,
        Double.longBitsToDouble(0x3fa565862c907cd0L), Double.longBitsToDouble(0x3fe0e0efa4d64b7bL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 2, "\ud939\udc32\uda55\ude57Z\ud918\udef1\ud821\ude10\uda7f\udfb8", "\u301c\000", "\uda52\udccb\ud825\udf0c\ud9c5\udfc0\udbed\udcae\ud902\udce8\udbc3\ude50\udbac\udc0c\udab2\udebe\udba9\udeee\udb29\udddf\ud96b\udff1",
        -5, -1000, 0, -3815653893437821910L, -91937L, true, false, (char) 26167, (char) 43107,
        Double.longBitsToDouble(0x3fe9f749eca87830L), Double.longBitsToDouble(0x3f42b5e000000000L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Field;:[[private static final sun.util.calendar.BaseCalendar java.util.Date.gcal, private static sun.util.calendar.BaseCalendar java.util.Date.jcal, private transient long java.util.Date.fastTime, private transient sun.util.calendar.BaseCalendar$Date java.util.Date.cdate, private static int java.util.Date.... |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 1, 2, 0, 2, "\ud939\udc32\uda55\ude57\udab1\udf79\ud918\udef1\udb36\udcd6\uda7f\udfb8", "\u301c\u1fd8", "\uda52\udccb\uda99\udc46\ud9a8\ude97\udbed\udcae\ud902\udce8\udbc3\ude50\udbac\udc0c\ud804\ude5e\uda33\udc2c\udbeb\uddc3\udb96\udd74",
        -4, 38404, 1203317294, -3815653158998414294L, -54750L, true, true, (char) 21451, (char) 36902,
        Double.longBitsToDouble(0x3fe231203e881df6L), Double.longBitsToDouble(0x3fe493a7903bfbc6L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 1, 3, 2, 2, "\uda4f\uddc1\ud97f\udc0f\udaef\udf5e\uda80\ude14\ud84d\udc00\uda7f\udfb8", "\u301c\u6fa0", "\uda52\udccb\ud825\udf0c\ud9c5\udfc0\udbed\udcae\ud902\udce8\udbc3\ude50\udbac\udc0c\udab2\udebe\udba9\udeee\udb29\udddf\udb96\udda6",
        -4, 38404, 1203317294, -3815653416696452054L, -91937L, true, false, (char) 34249, (char) 43107,
        Double.longBitsToDouble(0x3fe9f749eba87830L), Double.longBitsToDouble(0x3fd1ec44f2e022e2L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 1, 0, 0, 2, "\ud939\udc32\uda55\ude57\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8\uda70\udee1", "\u02ba\u0f14\u9924\u803d\u8353\u1459\ubbd3\ub703\u615d\u9fdd\u276e\u7a17\u8195\ud26a\u934f\u41c2", "\uf399\udbb7\udc8c\udaff\ude56\udb7e\udfa9\udb4c\udf0b\udb41\uddbc\udbaa\udc04\uda5a\udd8b\ud8c1\ude53\ud817\ude64\ud860\ude36\ud88e\udf36\udbc5\udfc5\ud936\udf2d\udb09\udf73\udaa7\udf46\udb16\udf8d\ud970\udde8\udbee\uddbf\udae5\udf9c\ud9ab\udd05\ud817\ude76\ud8ce\ude3d\ud8ef\udfa7\udba7\udc87\ud9e1\udea8",
        17, 25795, 197953847, -5387683364550670289L, -52771L, true, false, (char) 43686, (char) 49423,
        Double.longBitsToDouble(0x3fec81faf89a1a3bL), Double.longBitsToDouble(0x3fe794c3c474cc20L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Field;:[[private static final long java.lang.Number.serialVersionUID]] |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 1, 2, 2, 2, "\ud93b\udfa5\uda55\ude57\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\u301c\u02ba", "\uda52\udccb\ud825\udf0c",
        49, 83758, 448489301, -9017871455101827521L, 62804L, true, true, (char) 9056, (char) 38325,
        Double.longBitsToDouble(0x3fe5e3062a2eb84dL), Double.longBitsToDouble(0x3feb7a3dcc2acb0cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 3, 3, "\ud866\udf73\ud96a\udef5\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\035\ub0b9", "\uda52\udccb\ud825\udf0c\ud9c5\udfc0\udbed\udcae\ud8ee\udd7a\uda0c\uddb6\udb55\udefa\udab4\udfed\udba9\udeee\udb29\udddf\udb96\udda6",
        -4, 38404, 1203317294, -3815653416696452054L, 79921L, false, true, (char) 1765, (char) 13540,
        Double.longBitsToDouble(0x3fdf4b68349cde56L), Double.longBitsToDouble(0x3fe04b7f15c7453dL)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=void |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 2, 0, 0, 2, "\udbb4\udd30", "\u82d6\u3efb\u434a\u90f6\u82fd\u301c\u02ba\u0f14\u9924\u803d\u2baf\u21a6\u050f\ub703\u615d\u3cbb\u276e\u1b92\ucfc3\ud26a\uc034\u9ee5\ua72f\u5cac\u4d69", "\udb7e\udfa9\uda26\udf57\udb3d\udf74\udbaa\udc04\uda72\udde1\ud8c1\ude53\ud817\ude64",
        50, 43812, 293052249, 4296875710479627694L, 66809L, true, false, (char) 23657, (char) 12231,
        Double.longBitsToDouble(0x3feb361bf15fe204L), Double.longBitsToDouble(0x3f89782413ce9e40L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 1, "\ud939\udc32\uda55\ude57\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\u301c\u02ba", "\uda52\udccb\ud825\udf0c\ud9c5\udfc0\udbed\udcae\ud902\udce8\udbc3\ude50\udbac\udc0c\udab2\udebe\udba9\ude7d\udb29\udddf\udb96\udda6",
        -4, 38404, 1203317294, -3815653416696452054L, -91937L, true, false, (char) 26167, (char) 43107,
        Double.longBitsToDouble(0x3fe9f149eca87830L), Double.longBitsToDouble(0x3fd2f95af2e022e2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=new org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud939\udc32\ud801\udf25\udb2b\udcd4\ud993\udf25\ud84d\udc00\udbed\ude79\ud8a4\ude87\uda90\udf13\ud91b\udf95\ud838\udee1\udb0d\udcd8\u3fc2\ud881\ude24\ud884\udc98\ud8de\udeda\ud99d\udf80\ud8ec\udc05\udbc3\ude81\udb67\udfa9\uda9f\udf9b\udb89\udcbe\ud87a\udea6\udb96\udda6\udbc7\ude51\ud936\ude82\ud801\ude68\uda65\ude1f\u8106\udb08\udc2d\ud9c5\udca7\ud8f7\udd35\ud936\udf45\ud909\udc67\udaa8\udf65\ud8b5\udefd\ud90f\ude9e\u22ad\udb83\ude1c\ud82b\ude9e\uda2d\udd8a", "\u56f5\ub2f6\u48c8\ud567\u3045\u0648", "\ud854\ude6f\ud92b\ude58\udba0\udc94",
        -5, 73315, -1579500565, 5590515106977582573L, 77902L, true, true, (char) 39872, (char) 32525,
        Double.longBitsToDouble(0x3fef021b0138ea0dL), Double.longBitsToDouble(0x3fdb4e1eeeeb43ceL)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=new org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 2, 3, 3, 2, "\ud939\udc32\uda55\ude57\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\ua22f\u3ca6", "\uda52\udccb",
        14, 20404, 1494280438, -1455593736160799262L, 56294L, true, false, (char) 44812, (char) 9056,
        Double.longBitsToDouble(0x3fa6058ba288c370L), Double.longBitsToDouble(0x3fc65f5a5490d7a0L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 1, 3, 0, 2, "\uda80\udc55\uda44\udc7b\ud903\udf13\ud9e6\udee1\ud84d\udc00\uda7f\udfb8", "\ua22f\u3ca6", "\uda52\udced",
        53, 20404, 1494280438, -1455611070648805918L, -3586L, false, false, (char) 57979, (char) 23336,
        Double.longBitsToDouble(0x3fe8c04648b45d06L), Double.longBitsToDouble(0x3fd7de4a4520ffc4L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=new org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 1, 2, "\ud939\udc32\uda9d\ude3a\ud9d9\ude19\ud923\udd62\ud84d\udc00\uda7f\udfb8", "\ua22f\u3ca6", "\uda52\udccb\ud825\udf0c\ud94b\udfbb\udabb\ude35\ud8cc\udc05\udbda\udf81\udbac\udc0c\udab2\udebe\udba9\udeee\udb29\udddf\udb96\udda6",
        -4, 42748, 1203317384, -2178313476872546582L, -1618L, true, false, (char) 22894, (char) 35344,
        Double.longBitsToDouble(0x3fd0b2a5820d0c26L), Double.longBitsToDouble(0x3fc19f4afdc12640L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Field;:[[private static final sun.util.calendar.BaseCalendar java.util.Date.gcal, private static sun.util.calendar.BaseCalendar java.util.Date.jcal, private transient long java.util.Date.fastTime, private transient sun.util.calendar.BaseCalendar$Date java.util.Date.cdate, private static int java.util.Date.... |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 3, "\u81d5\ud888\udcf4\ud9b1\udf4b\ud9bd\ude0f\ud834\udd5f\ud9bb\uddf6", "\u6c5b\u3cce\u99da\u5545\u2a6f\u8353\u3744\u1b7f\ud091\ua569\u134b\u2d25\u348a\u8195\u4d6d\u934d\u1f44\u9712\ua861\ubf82\u80c6\u87b3\u1fef", "\uda13\udf30\ud8d0\udd3d\ud82e\uddbd\ud90b\udf78\ud800\udf94\ud941\udfdf\ud963\ude21\udaf4\udcfc\udb1f\udf78\uda04\udcdd\uda43\udf35\ud8ff\udfa1\ud969\uddb4\udaaf\ude95\uda57\udd6e\uda5f\udc63\uda1a\ude00\udb96\udf42\ud812\udd46\ud83f\ude5a\ud8af\udfa0\udb73\ude55\uda65\ude4c",
        10, 53433, -1861308739, 5461581696464883478L, -77589L, true, true, (char) 27144, (char) 35122,
        Double.longBitsToDouble(0x3fead67ef77f3af9L), Double.longBitsToDouble(0x3fc7600a77176eecL)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Field;:[[public static final java.lang.Thread$State java.lang.Thread$State.NEW, public static final java.lang.Thread$State java.lang.Thread$State.RUNNABLE, public static final java.lang.Thread$State java.lang.Thread$State.BLOCKED, public static final java.lang.Thread$State java.lang.Thread$State.WAITING, p... |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\ud939\udc32\uda55\ude57\udab1\udf79\ud918\udef1\udb36\udcd6\uda7f\udfb8", "\u301c\u1fd8\u0f14\u9924\u803d\u1398\u772f\ubbd3\ub703\u615d\u9fdd\u6ef2\u73ed\u4c8a", "\ud936\ude82\ud801\ude68\ud848\udc8c\udac7\udc9f",
        53, 20764, 337337461, 649327664057370299L, -43395L, false, true, (char) 29810, (char) 21451,
        Double.longBitsToDouble(0x3fe1cf2f6a462407L), Double.longBitsToDouble(0x3fe440efb69274f2L)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Field;:[[private static final sun.util.calendar.BaseCalendar java.util.Date.gcal, private static sun.util.calendar.BaseCalendar java.util.Date.jcal, private transient long java.util.Date.fastTime, private transient sun.util.calendar.BaseCalendar$Date java.util.Date.cdate, private static int java.util.Date.... |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=[Ljava.lang.reflect.Field;:[[private static final sun.util.calendar.BaseCalendar java.util.Date.gcal, private static sun.util.calendar.BaseCalendar java.util.Date.jcal, private transient long java.util.Date.fastTime, private transient sun.util.calendar.BaseCalendar$Date java.util.Date.cdate, private static int java.util.Date.... |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud939\udfc0\ud925\udda1\udab1\udf90\ud918\udef1\ud8ed\ude52\uda6c\udf8c\ud82f\ude03\uda20\udd6c", "\u6f91\uc831\u1fa9\ua2bb\ua3d0\ubbd3\ub703\u615d", "\uda33\udc2c\udbeb\uddc3\udb96\udd74",
        -4, 38404, 1203317294, -3815653158998414294L, -34923L, true, false, (char) 14460, (char) 29810,
        Double.longBitsToDouble(0x3fc9bcdfa8e797b4L), Double.longBitsToDouble(0x3fe2312038775b41L)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Field;:[[]] |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=[Ljava.lang.reflect.Field;:[[]] |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 2, 2, 2, 2, "\udb76\udca4\ud999\udc46", "\ubd80\ucc50\u19e2\u4874\u301c\ua03a\u3edb\u8c30\ubf19\u0e61\u8fec\u496c\u225f\ucfae\u4686\u40f5", "\udb27\udd4f\uda4c\udf5b\ud936\ude9f\ud96b\udc7d\ud848\udc50\ud96d\udfd3\ud908\udfed\uda56\udd21\uda7d\udca7\uda97\udee3\ud9bd\udd5b\ud8a7\ude54\udb90\udd18\ud9d6\udc69\udaec\udd8b\ud887\udddc\udaf2\udf31\udb72\uddac\ud9ed\udd20\ud940\udd14\ud9af\udd38\uda2a\udff4\udb2f\udc0b\udb00\udeb8\ud98a\udc01\u435e\ud9b3\udc7b\ud99a\ude90\ud9c7\udc17\ud908\ude39\udad5\udc99\udb94\udf5d\uda91\udc6c\ud8b3\udff6",
        -1, 17798, -2124714966, -7867236428351058000L, 7438L, true, true, (char) 57582, (char) 54391,
        Double.longBitsToDouble(0x3fc7e9c48c2db564L), Double.longBitsToDouble(0x3fbf2b9d96a690b0L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Field;:[[public static final int java.lang.Integer.MIN_VALUE, public static final int java.lang.Integer.MAX_VALUE, public static final java.lang.Class java.lang.Integer.TYPE, static final char[] java.lang.Integer.digits, static final byte[] java.lang.Integer.DigitTens, static final byte[] java.lang.Integer... |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=[Ljava.lang.reflect.Field;:[[public static final int java.lang.Integer.MIN_VALUE, public static final int java.lang.Integer.MAX_VALUE, public static final java.lang.Class java.lang.Integer.TYPE, static final char[] java.lang.Integer.digits, static final byte[] java.lang.Integer.DigitTens, static final byte[] java.lang.Integer... |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\012",
        Z.run(T, 2, 2, 2, 1, "\ud939\udc32\uda55\ude57\udab1\udf79\ud918\udef1\ud84d\udc00\uda7f\udfb8", "\uac87\u8336", "\uda52\udd41\ud825\udf0c\ud9c5\udfc0\ud833\udf52\ud95f\udc97\udbc3\ude50\udbac\udc0c\udab2\udebe\udba9\ude7d\udb29\udddf\ud946\udee5",
        43, 38404, 1203317294, -3815653416696452054L, -91937L, true, false, (char) 26167, (char) 43107,
        Double.longBitsToDouble(0x3fe9f149eca87830L), Double.longBitsToDouble(0x3fe734ad79701007L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 0, 3, "\ud939\udc32\udbb5\ude79\ud967\ude07\ud918\udef1\ud8c6\udc7c\udb4f\udf0c", "\u301c\u02ba", "\udaea\udd16\udba9\ude94\ud9a4\udc91\udbed\udcae\ud902\udce8\udbcb\udefd\uda22\udd33\uda95\ude13\uda69\udc30\ud898\udcbd\udbd6\udcb6\udb71\udcb7\ud85a\udfbc\ud801\ude68\ud848\udc50\udac7\udc9f\uda44\udc26\udb0b\ude8e\udb7e\udfa9\udb4c\udf0b\udb41\uddbc\udbb3\udc04\ud820\udc32\udaf3\udca7\ud817\ude64\ud860\ude36\udbf1\ude26\ud84b\ude18\udb1a\udf69\udb70\udf26\ud891\udf4d",
        39, 40041, -1771722034, 3968994094883043222L, -29113L, true, false, (char) 23038, (char) 50906,
        Double.longBitsToDouble(0x3fbcb25c63108c08L), Double.longBitsToDouble(0x3feb1b9a2382b6baL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=[Ljava.lang.reflect.Field;:[[private static final sun.util.calendar.BaseCalendar java.util.Date.gcal, private static sun.util.calendar.BaseCalendar java.util.Date.jcal, private transient long java.util.Date.fastTime, private transient sun.util.calendar.BaseCalendar$Date java.util.Date.cdate, private static int java.util.Date.... |this=org.mockito.internal.configuration.DefaultInjectionEngine:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 0, "\u81d5\ud888\udcf4,\000\000\ud9bb\uddf6", "\u555b\u3cce\u0a27\u354b\u2a6f\u8353\u8233\u1b7f\ud091\ua569\u134b\u2d25\u348a\u8195\u4d6d\u934d\u1f44\u9712o\000\u6fa2\u87b3\u1fef", "\uda13\udf30\ud8d0\udd3d\ud82e\uddbd\ud90b\udf78\ud800\udeac\ud941\udfdf\ud963\ude21\udaf4\udcfc\udaf9\ude9b\uda04\udcdd\uda43\udf35\ud8ff\udfa1\ud969\uddb4\udaaf\ude95\uda57\udd6e\uda5f\udc63\uda1a\ude00\udb96\udf42\ud812\udd46\ud831\udd5a\ud8af\udfa0\udb73\ude55\uda65\ude4c",
        10, 53433, 44733, 5461458972069367574L, -77589L, true, true, (char) 27144, (char) 35122,
        Double.longBitsToDouble(0x3fead67ef77f3af9L), Double.longBitsToDouble(0x3fc7600017176eecL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.configuration.DefaultInjectionEngine|injectMockCandidate|java.lang.Class,java.util.Set,java.lang.Object|new:org.mockito.internal.configuration.DefaultInjectionEngine:",
    "M|org.mockito.internal.configuration.DefaultInjectionEngine|injectMocksOnFields|java.util.Set,java.util.Set,java.lang.Object|new:org.mockito.internal.configuration.DefaultInjectionEngine:",
    "M|org.mockito.internal.configuration.DefaultInjectionEngine|orderedInstanceFieldsFrom|java.lang.Class|new:org.mockito.internal.configuration.DefaultInjectionEngine:",
    "C|org.mockito.internal.configuration.DefaultInjectionEngine|<init>|",
    "M|org.mockito.internal.configuration.DefaultInjectionEngine|injectMockCandidate|java.lang.Class,java.util.Set,java.lang.Object|new:org.mockito.internal.configuration.DefaultInjectionEngine:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
