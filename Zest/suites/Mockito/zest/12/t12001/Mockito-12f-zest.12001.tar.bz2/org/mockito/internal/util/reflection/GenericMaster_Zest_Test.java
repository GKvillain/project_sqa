package org.mockito.internal.util.reflection;
import org.junit.Test;
import static org.junit.Assert.*;
public class GenericMaster_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud85c\udc68\udb22\uddc0\ud9bc\udce8\ud8fa\udf24\udbee\uddf2\udbab\udd56\udaa8\udd92\ud879\udc8b\ud84b\udcdf\udbcf\udc15\ud86a\udc6f\ud83f\uddf3\udb5f\ude2f\u8c97\uda45\udd10\udad9\ude5f\ud8f3\udc64\udbd3\udd55\udbcb\ude8e\ud840\udc28\udb51\udcde\ud8a8\uddc3\ud879\uddb6\uda8e\uddbf\u4b91\udb0b\udd1a\udbb2\udf6a\uda93\udd7e\u94d7\uda69\ude9a\ud8ed\udca3\ud9f0\udf77", "\u0fc9\u1b88\u3a89\uad36", "\ud9af\ude0f\udb11\udf35\ud9d9\uddb4\udb86\udd47",
        17, 22086, -117590203, 5465671474353650937L, -99673L, false, false, (char) 47285, (char) 49061,
        Double.longBitsToDouble(0x3fbd8dbdab92e1a0L), Double.longBitsToDouble(0x3fe2359b8cfc412cL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 0, 1, "\ud85c\udc68\udb22\uddc0\ud9bc\udce8\ud8c4\udf29\udb49\udd3f\udab0\udf52\udac7\udec1\ud879\udc8b\u0abc\ud87e\udc31\udaac\udde5\ud83f\uddf3\uda05\udc29\u8c97\uda45\udd10\udad9\ude5f\ud92a\udddf\udbd3\udd55\udbcb\ude8e\ud840\udc28\udb51\udcde\udaf5\udfcb\ud8ad\udef8\uda9d\udc5c\ud8a8\udd30\udb0b\udcab\udbb2\udf6a\uda93\udd7e\u94d7\udbbd\udf83\udb38\udf98\ud8ea\udca9", "\uba20\u3c8c\u796d\uad36", "\ud9af\ude0f\udb11\udf35\ud9d9\uddb4\udb86\udd47\uda84\ude4d\uda81\udd6f\ud8db\udedb\ud930\udfb7\udb3c\ude9e\ud88c\udf6b\udbc9\udfcb\ud8bb\udf8e\uda83\udf98\ud880\udfa4\ub9e5\u18ef\ud8e4\ude1d\ud9d9\ude0e\uda1c\udcfe\ud887\udcff\ud837\udcdb",
        50, 23733, 926049272, -3205137718363410427L, -16358L, true, false, (char) 62510, (char) 46211,
        Double.longBitsToDouble(0x3fd0758565df215eL), Double.longBitsToDouble(0x3fe452a5d6e70a99L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.reflection.GenericMaster:@?\0121=new org.mockito.internal.util.reflection.GenericMaster:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud85c\udc68\udb22\uddc0\ud9bc\udce8\ud8fa\udf24\udbee\uddf2\udbab\udd56\udaa8\udd92\ud879\udc8b\ud84b\udcdf\ud8f8\udd6b\ud845\udf73\ud83f\uddf3\udb5f\ude2f\u8c97\uda45\udd10\udad9\ude5f\ud8f3\udc64\udbd3\udd55\udbcb\ude8e\ud840\udc28\udb51\udcde\ud8a8\uddc3\ud879\uddb6\uda8e\uddbf\u4b91\udb0b\udd1a\udbb2\udf6a\uda93\udd7e\u94d7\uda69\ude9a\ud8ed\udca3\ud9f0\udf77", "\u0fc9\uc009\u3a89\uad36", "\ud9af\ude0f\ud859\ude39\ud9c8\udfcd\udb86\udd47",
        17, 22086, -117590203, 5465671474353650937L, -99673L, false, false, (char) 47285, (char) 49061,
        Double.longBitsToDouble(0x3fbd8dbdab92e1a0L), Double.longBitsToDouble(0x3fe2359b8cfc412cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.reflection.GenericMaster:@?\012",
        Z.run(T, 1, 1, 0, 1, "\ud85c\udc68\udb22\uddc0\ud9ce\udcf1\ud8fa\udf24\udbee\uddf2\ud8a2\ude9a\uda9b\ude83\ud9ee\ude84\ud84b\udcdf\udbcf\udc15\ud86a\udc6f\ud83f\uddf3\udb5f\ude2f\udaa1\udd98\u11f1\uda89\udd2e\uda71\udcaa\ud92f\udf4a\uda69\uddc7\ud831\udef2\udb51\udcde\ud9e7\udfc9\ud879\uddb6\uda8e\uddbf\u4b91\uda53\udd1e\udbb2\udf6a\uda93\udd7e\u94d7\uda69\ude9a\uda5d\udca7\ud9f0\udf77", "\u0fc9\u7762\u3a89\u04ea", "\ud87e\udebc\udaf5\udd45\ud9d9\ude67\udb86\udd47\ud9d5\udf70\ud887\ude9a\ud8db\udeb5",
        17, 23065, 1530406411, 6620292858215716340L, -52709L, false, false, (char) 20255, (char) 46544,
        Double.longBitsToDouble(0x3fcf8822b5f31f0cL), Double.longBitsToDouble(0x3fe12bf92516ad1fL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.reflection.GenericMaster:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 0, "\ud85c\udc68\udb22\uddc0\uda93\ude09\ud8fa\udf24\udbee\uddf2\udafc\uddfe\udaa8\udd92\ud879\udc8b\ud84b\udcdf\udbcf\udc15\ud86a\udc6f\ud83f\uddf3\udb5f\ude2f\u8c97\uda45\udd10\udad9\ude5f\ud8f3\udc64\udbd3\udd55\udbcb\ude8e\ud840\udc28\udb51\udcde\ud8a8\uddc3\ud879\uddb6\uda8e\uddbf\u4b91\udb0b\udd1a\udbb2\udf6a\uda93\udd7e\u94d7\uda6d\udd9a\uda8d\udc9b\uda40\udd7a", "\u0fc9\u1b88\u3a89\uad36", "\uf9ca\udb11\udf35\ud9d9\uddb4\udb86\udd47",
        17, 79246, -117590026, 5465671474353650937L, -53734L, false, false, (char) 47285, (char) 49061,
        Double.longBitsToDouble(0x3fbd8dbdab92e1a0L), Double.longBitsToDouble(0x3fe2359b8cfc412cL)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud85c\udc68\udb22\uddc0\ud9bc\udce8\ud8b3\udeee\ud851\uddf9\uda2c\uded7\uda76\udd95\ud879\udc8b\ud84b\udcdf\udbcf\udc15\ud86a\udc6f\udb8e\uddff\udb5f\ude2f\u8c97\uda45\udd10\udad9\ude5f\ud8f3\udc64\udbd3\udd55\ud841\ude89", "\ubf09\u973a\ua5be\u488a\u4140\u4539\u59a3\ub9e6\u4ef2\ub192\u3452", "\ud8fe\udf8a\ud911\udcc0\ud833\udd78\ud942\udf2b\ud861\udc84\ud92b\udc71",
        25, 30313, 731173667, -3740357865510860940L, 49634L, true, true, (char) 2258, (char) 34272,
        Double.longBitsToDouble(0x3fd475b3818c19c0L), Double.longBitsToDouble(0x3feb6af1ae67af3eL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.reflection.GenericMaster:@?\0121=new org.mockito.internal.util.reflection.GenericMaster:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud85c\udc68\udb22\uddc0\ud9bc\udce8\ud8fa\udf24", "\u5a97\u8b4f\u7572\u19b8\u2c99", "\udaf2\udf9e\udb85\udf94\udad9\ude5f\ud8f3\udc64\udacf\udf48\ud947\udd4c\ud815\udf45\udb51\udcbe\ud8a8\uddc3\ud879\uddb6",
        50, 61030, -1249097346, 8816662913554637020L, -73657L, false, true, (char) 41965, (char) 33385,
        Double.longBitsToDouble(0x3fe8fe0baa0475eaL), Double.longBitsToDouble(0x3fa2490f1051b460L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.reflection.GenericMaster:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 1, 0, 1, "\ud85c\udc68\udb22\uddc0\ud9bc\udce8\ud8fa\udf24\udbee\uddf2\udbab\udd56\udaa8\uddfb\u5495\udaea\udd02\ud8f8\udca6\ud845\udf73\ud83f\uddf3\udb5f\ude2f\u8c97\uda45\udd10\udad9\ude5f\ud8f3\udc64\udbd3\udd55\udbcb\ude8e\ud840\udc28\udb51\udcde\ud8a8\uddc3\ud9b7\ude07\uda8e\uddbf\u4b91\ud95f\udfd4\ud80b\ude86\uda93\udd7e\u94d7\uda69\ude9a\ud832\udf66\ud9d2\udde0", "\u0fc9\uc009\u3a89\uad36", "\ud9af\ude0f\ud859\ude39\ud9a6\ude45\udb86\udd87",
        17, 22086, -1124223163, 5452149242268597497L, -99673L, false, false, (char) 47285, (char) 49061,
        Double.longBitsToDouble(0x3fbd8dbdab92e1a0L), Double.longBitsToDouble(0x3fe2359b8a10412cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.reflection.GenericMaster:@?\012",
        Z.run(T, 1, 1, 0, 1, "\ud85c\udc68\ub2c5\ud9ce\udcf1\ud8fa\udf24\udacd\ude62\ud8e9\uddaa\uda9b\ude83\ud9ee\ude84\ud84b\udcdf\udbcf\udc15\ud86a\udc6f\ud83f\uddf3\udb5f\ude2f\udaa1\udd98\u11f1\udb10\uddf3\uda46\udf75\ud92f\udf4a\ud912\udd13\ud86d\udc48\udb51\udcde\udb90\udfdf\uda16\udc4f\udbf1\ude31\udb54\uddb5\udb5b\udedb\udb74\udee1\uda93\udd7e\u94d7\uda69\ude9a\uda5d\udca7\ud9f0\udf77", "\u0fc9\u7762\u3a89\u04ea", "\ud940\udf5e\ud949\ude31\udae9\udca0\udb86\udd47\ud9d5\udf70\ud887\ude9a\ud8db\udeb5\ud930\udfb7\ua3f6\ud88c\udf6b\ud986\udc89\udbd6\uddd6\uda95\ude11\udaa7\ude56\ud88e\udf2a\udb20\udfbd\udb84\uddc4\uda54\uddab\ud85b\udcfa",
        24, 90662, 34266148, -9085664944647434173L, -46871L, true, false, (char) 64870, (char) 10585,
        Double.longBitsToDouble(0x3fe1cade453d77abL), Double.longBitsToDouble(0x3feca39cf67f1ed4L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 2, 0, 1, 1, "\ud85c\udc68\udb22\uddc0\udbf4\udce6\ud8f1\udeed\udbee\uddf2\udbab\udd56\udaa8\udd92\ud879\udc8b\ud84b\udcdf\udb7e\uded9\ud86a\udc6f\ud8fb\ude11\udb5f\ude2f\uda77\udd00\uda45\udd0c\ud94e\udcd9\ud8f3\udcd8\udbd3\udd55\udbcb\ude8e\ud840\udc28\ud9e8\udfcb\ud8a8\uddc3\ud879\uddb6\udaa7\udebf\u4b91\udb0b\udd1a\udbb2\udf6a\udac0\udd29\u94d7\udae2\udc36\uda14\udc74\ud9f0\udfc6", "\u6bc8\u1b88\u3a89\uad36", "\ud9af\ude0f\udb11\udf35\ud9d9\uddb4\udb86\udd47",
        17, 22086, -117590203, 5465671474353650937L, -99673L, false, false, (char) 47285, (char) 30620,
        Double.longBitsToDouble(0x3fbd8dbdab92e1a0L), Double.longBitsToDouble(0x3fe2359b8cfc412cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.mockito.internal.util.reflection.GenericMaster:@?\0121=new org.mockito.internal.util.reflection.GenericMaster:@?\012",
        Z.run(T, 2, 1, 1, 1, "\ud85c\udc68\udb22\uddc0\ud889\udf68\ud8fa\udf53\ud8fa\ude8e\uda65\udcff\ud919\ude47\ud879\udc8b\ud84b\udcdf\udbcf\udc15\ud86a\udc6f\ud83f\uddf3\udb5f\ude2f\u8c97\uda45\udd10\udad9\ude5f\ud8f3\udc64\udbd5\udd55\udbcb\ude8e\ud840\udc28\udb51\udcde\ud8a8\uddc3\ud857\udcb6\uda8e\uddbf\u4b91\uda13\udc7d\udbb2\udf56\uda93\udd7e\u94d7\uda69\ude9a\ud8ed\udca3\ud9f0\udf77", "\u0fc9\u1b88\u3a89\uad36", "\ud9c8\udf23\udb11\udf35\ud9d9\uddb4\udb86\udd47",
        17, 22086, -117590203, 5465671474353650937L, -99673L, false, false, (char) 47285, (char) 49061,
        Double.longBitsToDouble(0x3fbd8dbdab9591a0L), Double.longBitsToDouble(0x3fe2359b8c2c832cL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.util.reflection.GenericMaster|getGenericType|java.lang.reflect.Field|new:org.mockito.internal.util.reflection.GenericMaster:",
    "C|org.mockito.internal.util.reflection.GenericMaster|<init>|",
    "M|org.mockito.internal.util.reflection.GenericMaster|getGenericType|java.lang.reflect.Field|new:org.mockito.internal.util.reflection.GenericMaster:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
