package org.mockito.internal.invocation;
import org.junit.Test;
import static org.junit.Assert.*;
public class Invocation_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 12, 1, "\uda58\udd0b\uda4a\udeec\udb17\ude3c\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\ud94d\ude70\ud8ec\ude85\udbdf\uddc8\uda96\udc5b\ud9bc\ude7a\udb13\udc9b\ub7c7\udaa2\uddf0\ud8b4\udc88\udb75\udeb6", "\ua70e\u0a18\u10c0\ubf6d\u8ae2\u885d\u5a49\u9072", "\ud8b1\udefa\ud94d\udc17\uea1c\uf939\udaaa\udc6f\ud8b1\udcb9\udbe3\udef6\udb52\udddd\ua32d",
        58, 7036, 575180762, 4184620316549912134L, -28592L, false, true, (char) 40426, (char) 9873,
        Double.longBitsToDouble(0x3fe1404946533455L), Double.longBitsToDouble(0x3feab720830734a4L)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 12, 14, "\uda58\udd0b\uda4a\udeec\ud809\udfaf", "\ua555\u67cf\ub8f7\ub34d\u4045\u062d\ub95e\ud513\u538b\u0246\u32a5\u4ccb", "\udb96\udd5e\ud9e7\udc93\udbc9\uddce\ud821\udc55\uda95\udd84\uda2e\udeec\ub441\ud8da\uddaa",
        13, 62558, -1522929606, -5357925264105012622L, -53070L, false, true, (char) 40509, (char) 51733,
        Double.longBitsToDouble(0x3fc7f0e523595b8cL), Double.longBitsToDouble(0x3feba4ffa1fc70a2L)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 12, 1, "\uda58\udd0b\uda4a\udeec\udb17\ude3c\udaeb\udefb\ud8b3\udd8d", "\u9f7e\ub34d\u4045\u062d\ub95e", "\ub7c7\udaa2\uddf0\ud8b4\udc88\udb75\udeb6\ud947\udf1f\udbcc\udc5e\ud9e7\udc93\ud8c1\udeab\ud821\udc53\uda95\udd38\uda2e\udeec",
        39, 45668, 1723913898, 5004277088968359298L, 30446L, false, true, (char) 63253, (char) 34320,
        Double.longBitsToDouble(0x3fd302d0dc599a00L), Double.longBitsToDouble(0x3fc7f0e523595b8cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 3, 5, 1, "\uda58\udd0b\uda4a\udeec\udb17\ude3c\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\ud94d\ude70\ud8ec\ude85\udbdf\uddc8\uda96\udc5b\ud9bc\ude7a\udb13\udc9b\ub7c7\udaa2\uddf0\ud8b4\udc88\udb75\udeb6", "\ua70e\u0a18\u10c0\ubf6d\u8ae2\u885d\u5a49\u9072", "\ud8b1\udefa\ud94d\udc17\uea1c\uf939\udaaa\udc6f\ud8b1\udcb9\udbe3\udef6\udb52\udddd\ua32d",
        58, 7036, 575180762, 4184620316549912134L, -28592L, false, true, (char) 40426, (char) 9873,
        Double.longBitsToDouble(0x3fe1404946533455L), Double.longBitsToDouble(0x3feab628830734a4L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 14, 2, 7, "\uda58\udd0b\uda4a\udeec\uda75\udfaa\uda82\ude91\uda1e\udd03\u3ae6\ud8a9\udd96\udbba\udf37\ud94d\ude70\ud8ec\ude85\uda6f\uddd0\uda96\udc5b\ud9c4\ude7e\udb13\udc9b\ud999\udfeb\udb28\udca6\ud8b4\udc88\udbf4\udcd5", "\u6efe\u2817\u10c0\ubf6d", "\udb96\udec8\udbd9\ude97\ud87a\udf8e\uda70\udcd7\ud9e0\ude3a\udb00\ude61",
        39, 73434, 755852744, 4323580567962095126L, -38346L, false, true, (char) 20894, (char) 46895,
        Double.longBitsToDouble(0x3fe01115de463a12L), Double.longBitsToDouble(0x3fe9edfebef020a6L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud824\udcb1\ud94c\ude0a\udaf3\uddf0\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda83\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud89b\uddde]] |a1=[Ljava.lang.Object;:[[\ud824\udcb1\ud94c\ude0a\udaf3\uddf0\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda83\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud89b\uddde]]\012",
        Z.run(T, 1, 4, 14, 1, "\ud824\udcb1\ud94c\ude0a\udaf3\uddf0\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda83\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud89b\uddde", "\ua754\u0a18\ub3b6\ubf6d\u8ae2\u0a1f\u0be7\u4151", "\ud8b1\udefa\ud8a7\udc64\uea1c\uf939\udaaa\udc6f\ud8b1\udcb9\udbe3\udef6\uda41\udda7\ud9cb\udcd5",
        58, 7036, 575180762, 4184620316549912134L, -28592L, false, true, (char) 40426, (char) 9873,
        Double.longBitsToDouble(0x3fe1404946533455L), Double.longBitsToDouble(0x3fd56e41060e6948L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\uda58\udd0b\uda4a\udeec\udb17\ude3c\ud91b\udf34\udb82\udfdd\udb3e\udcfd\ud8a9\ude3a\udb03\udde3\ud94d\ude70\ud8ec\ude85\u1242\uda96\udc5b\ud9bc\ude7a\udb13\udc9b\ud891\ude3d\udacc\udfe7\ud8b4\udc88\udb75\udeb6\ud947\udf1f\udb96\udd5e\ud9e7\udc93\ud8c1\udeab\ud8e9\udc57\udb7a\udeec\uda3c\udd82\ub441]] |a1=[Ljava.lang.Object;:[[\uda58\udd0b\uda4a\udeec\udb17\ude3c\ud91b\udf34\udb82\udfdd\udb3e\udcfd\ud8a9\ude3a\udb03\udde3\ud94d\ude70\ud8ec\ude85\u1242\uda96\udc5b\ud9bc\ude7a\udb13\udc9b\ud891\ude3d\udacc\udfe7\ud8b4\udc88\udb75\udeb6\ud947\udf1f\udb96\udd5e\ud9e7\udc93\ud8c1\udeab\ud8e9\udc57\udb7a\udeec\uda3c\udd82\ub441]]\012",
        Z.run(T, 1, 4, 12, 7, "\uda58\udd0b\uda4a\udeec\udb17\ude3c\ud91b\udf34\udb82\udfdd\udb3e\udcfd\ud8a9\ude3a\udb03\udde3\ud94d\ude70\ud8ec\ude85\u1242\uda96\udc5b\ud9bc\ude7a\udb13\udc9b\ud891\ude3d\udacc\udfe7\ud8b4\udc88\udb75\udeb6\ud947\udf1f\udb96\udd5e\ud9e7\udc93\ud8c1\udeab\ud8e9\udc57\udb7a\udeec\uda3c\udd82\ub441", "\u955e\u14cb\u533b\u338c\u39ee\u5595", "\udbe3\udef6\udb52\udddd\ua32d",
        58, 7036, 575180762, 4184620316549912134L, -28592L, true, true, (char) 43015, (char) 23203,
        Double.longBitsToDouble(0x3fe1404946533455L), Double.longBitsToDouble(0x3feab720830734a4L)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[]]\012",
        Z.run(T, 1, 4, 1, 1, "\ud880\udc68\uda4a\udeec\udb17\ude3c\udaeb\udefb\ud8b3\udd8d", "\u9f7e\uc856\uc740\u062d\ub95e", "\ub7c7\udac0\udef0\ud8b4\udc88\udb75\udeb6\ud947\udf1f\udbcc\udc5e\ud986\ude21\ud90e\udf39\ud821\udd27\uda95\udd38\uda2e\udeec",
        39, 45668, 1723913898, 5004277088968359298L, 30446L, false, true, (char) 63253, (char) 34320,
        Double.longBitsToDouble(0x3fd302d0dc599a00L), Double.longBitsToDouble(0x3fc7f0e523595b8cL)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud824\udcb1\ud81a\ude47\ud8f1\udfbd\udaeb\udf04\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda83\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud89b\uddde]] |a1=[Ljava.lang.Object;:[[\ud824\udcb1\ud81a\ude47\ud8f1\udfbd\udaeb\udf04\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda83\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud89b\uddde]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 14, 1, "\ud824\udcb1\ud81a\ude47\ud8f1\udfbd\udaeb\udf04\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda83\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud89b\uddde", "\ua754\u1617\ub3b6\ubf6d\u8ae2\u0a1f\u0be7\u4151", "\ud8b1\udefa\ud8a7\udc64\uda6c\udcbc\uf939\udaaa\udc6f\ud8b1\udcb9\udbe3\udef6\uda41\udda7\ud9cb\udcd5",
        58, 7036, 575180762, 6994866485140201125L, -72040L, true, true, (char) 64335, (char) 53927,
        Double.longBitsToDouble(0x3fd56e41060e6948L), Double.longBitsToDouble(0x3fe3388afc0bc1b9L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud824\udcb1\ud94c\ude0a\udaf3\uddf0\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda4e\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\udb57\udfce]] |a1=[Ljava.lang.Object;:[[\ud824\udcb1\ud94c\ude0a\udaf3\uddf0\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda4e\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\udb57\udfce]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 1, "\ud824\udcb1\ud94c\ude0a\udaf3\uddf0\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\uda4e\udd6b\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\udb57\udfce", "\ua754\u0a18\ub3b6\ubf6d\u8ae2\u0a1f\u0be7\u4151", "\ud8b1\udefa\ud8a7\udc64\uea1c\uf939\udaaa\udc6f\ud8b1\udcb9\udbe3\udef6\ud800\udeb3\ud9cb\udd0b",
        58, 7036, 575180762, 4184620316549912134L, -28592L, false, true, (char) 40426, (char) 9873,
        Double.longBitsToDouble(0x3fa4049465334550L), Double.longBitsToDouble(0x3fd56e41060e6948L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud824\udcb1\udb46\udcb6\udba1\ude04\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\udab9\udc38\udb6e\ude6c\udbdf\uddc8\uda96\udc5b\ud859\ude84\uda1b\udf71\udb4a\udd0f\udaa2\uddf0\ud9c3\udd43\ud8b6\ude25]] |a1=[Ljava.lang.Object;:[[\ud824\udcb1\udb46\udcb6\udba1\ude04\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\udab9\udc38\udb6e\ude6c\udbdf\uddc8\uda96\udc5b\ud859\ude84\uda1b\udf71\udb4a\udd0f\udaa2\uddf0\ud9c3\udd43\ud8b6\ude25]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 2, 13, "\ud824\udcb1\udb46\udcb6\udba1\ude04\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\udab9\udc38\udb6e\ude6c\udbdf\uddc8\uda96\udc5b\ud859\ude84\uda1b\udf71\udb4a\udd0f\udaa2\uddf0\ud9c3\udd43\ud8b6\ude25", "\u2b2d\uadd5\u3765\u4d5e\u071d\u673f\u0be7\u4151", "\ud8b1\udefa\ud8df\udc64\uea1c\uf939\uda35\udcf5\ud8c4\udfd5\udbe3\udef6\uda41\udda7\uda9b\udd32",
        56, 89860, 575180762, 4184620316549912134L, 45523L, true, false, (char) 40342, (char) 9873,
        Double.longBitsToDouble(0x3fe1404946533455L), Double.longBitsToDouble(0x3fd56e4100c66948L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[]]\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 1, 1, "\ud880\udc68\ud913\udf9d\udb17\ude3c\udaeb\udefb\ud8b3\udd8d", "\u9f7e\uc856\uc740\u062d\ub95e", "\ub7c7\udac0\udef0\ud8b4\udc88\udb75\udeb6\ud9a9\udf51\uda82\udf0a\ud986\ude21\ud90e\udf39\ud821\udd27\uda95\udd38\uda2e\udeec",
        26, 58973, 1723913898, 5004277088968359298L, 30446L, false, true, (char) 63253, (char) 34320,
        Double.longBitsToDouble(0x3fd302d0dc599a00L), Double.longBitsToDouble(0x3fc7f0e523595b8cL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\uda26\uddd7\uda14\udea7\uda76\uddb8\ud880\udf16\ud88b\udf2d\u85a6\uda7c\udf44\ud9e6\udf0d\uda4b\ude51\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud842\udcd2]] |a1=[Ljava.lang.Object;:[[\uda26\uddd7\uda14\udea7\uda76\uddb8\ud880\udf16\ud88b\udf2d\u85a6\uda7c\udf44\ud9e6\udf0d\uda4b\ude51\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud842\udcd2]]\0121=[Ljava.lang.Object;:[[\uda26\uddd7\uda14\udea7\uda76\uddb8\ud880\udf16\ud88b\udf2d\u85a6\uda7c\udf44\ud9e6\udf0d\uda4b\ude51\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud842\udcd2]] |a1=[Ljava.lang.Object;:[[\uda26\uddd7\uda14\udea7\uda76\uddb8\ud880\udf16\ud88b\udf2d\u85a6\uda7c\udf44\ud9e6\udf0d\uda4b\ude51\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud842\udcd2]]\012",
        Z.run(T, 2, 4, 4, 10, "\uda26\uddd7\uda14\udea7\uda76\uddb8\ud880\udf16\ud88b\udf2d\u85a6\uda7c\udf44\ud9e6\udf0d\uda4b\ude51\udb54\udf70\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\udaa2\uddf0\uda33\udc22\ud842\udcd2", "\ua754\u1617\ub3b6\ubf6d\u7315", "\udbfc\udd7b",
        23, 48433, -1247489188, 2379592143824860923L, -8408L, false, true, (char) 51733, (char) 53593,
        Double.longBitsToDouble(0x3fd4bb315324138cL), Double.longBitsToDouble(0x3f82d1a1f68643c0L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud824\udcb1\ud81a\ude47\ud8f1\udfbd\udaeb\udf04\ud8b3\udd8d\u85a6\uda76\udc5b\uda7d\ude2e\ud8d0\udd3a\udb54\udf3b\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ud8f0\udcb1\ud869\ude9b\uda33\udc22\ud89b\uddde]] |a1=[Ljava.lang.Object;:[[\ud824\udcb1\ud81a\ude47\ud8f1\udfbd\udaeb\udf04\ud8b3\udd8d\u85a6\uda76\udc5b\uda7d\ude2e\ud8d0\udd3a\udb54\udf3b\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ud8f0\udcb1\ud869\ude9b\uda33\udc22\ud89b\uddde]]\0121=[Ljava.lang.Object;:[[\ud824\udcb1\ud81a\ude47\ud8f1\udfbd\udaeb\udf04\ud8b3\udd8d\u85a6\uda76\udc5b\uda7d\ude2e\ud8d0\udd3a\udb54\udf3b\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ud8f0\udcb1\ud869\ude9b\uda33\udc22\ud89b\uddde]] |a1=[Ljava.lang.Object;:[[\ud824\udcb1\ud81a\ude47\ud8f1\udfbd\udaeb\udf04\ud8b3\udd8d\u85a6\uda76\udc5b\uda7d\ude2e\ud8d0\udd3a\udb54\udf3b\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ud8f0\udcb1\ud869\ude9b\uda33\udc22\ud89b\uddde]]\012",
        Z.run(T, 2, 4, 4, 1, "\ud824\udcb1\ud81a\ude47\ud8f1\udfbd\udaeb\udf04\ud8b3\udd8d\u85a6\uda76\udc5b\uda7d\ude2e\ud8d0\udd3a\udb54\udf3b\udbdf\uddc8\uda96\udc5b\uda7a\ude75\udb13\udc9b\ud8f0\udcb1\ud869\ude9b\uda33\udc22\ud89b\uddde", "\ua754\u1617\ub3b6\ubf6d\u8ae2\u0a1f\u0be7\u4151", "\ud8b1\udefa\ud8a7\udc64\uda6c\udcbc\uf939\udaaa\udc6f\ud8b1\udcb9\udbe3\udef6\uda41\udda7\ud9cb\udcd5",
        58, 7036, 575180762, 6994866485140201125L, -6504L, true, false, (char) 60763, (char) 53927,
        Double.longBitsToDouble(0x3fd56e41060e6948L), Double.longBitsToDouble(0x3fe3388afc0bc1b9L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[]]\0121=[Ljava.lang.Object;:[[]]\012",
        Z.run(T, 2, 4, 4, 0, "\uda26\uddd7\000\uda76\uddb8\ud880\udf16\ud88b\udf2d\u85a6\uda72\udd44\u270c\uda4b\ude51\000\ud9c5\udf21\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\ud995\ude89\000\udb90\udc07", "\000", "\ud9ff\udfae",
        26, 76244, 0, -1706144512L, 12379L, false, true, (char) 34248, (char) 11581,
        Double.longBitsToDouble(0x3d90e52000000000L), Double.longBitsToDouble(0x3fd4bb315000138cL)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 0, 12, 1, "\uda58\udd0b\uda4a\udeec\udb17\ude3c\udaeb\udefb\ud8b3\udd8d\u85a6\ud8a9\udd96\udbbd\udde0\ud94d\ude70\ud8ec\ude85\udbdf\uddc8\uda96\udc5b\ud9bc\ude7a\udb13\udc9b\ub7c7\udaa2\uddf0\u00db\udac8\udfe3", "\ua70e\u0a18\u10c0\ubf6d\u8ae2\u885d\u5a49\u9072", "\ud8b1\udefa\ud94d\udc17\uea1c\ub752\uda90\udea7\ud8b1\udcb9\udbe3\udef6\udb52\udddd\ua32d",
        58, 7036, 575180762, 4184620316549912134L, -28592L, false, false, (char) 0, (char) 9873,
        Double.longBitsToDouble(0x3fe1404946533455L), Double.longBitsToDouble(0x3feab720830734a4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[Ljava.lang.Object;:[[\ud8bc\uddd2, \uda72\udefe\ud880\udf5b\ud88b\udf2d\ud87c\udca3\ud993\udcab\udb0f\uddee\uda67\ude51\000\ud9f6\udc5a\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\ud995\ude89\udbb9\ude21\uda64\udf28]] |a1=[Ljava.lang.Object;:[[\ud8bc\uddd2, \uda72\udefe\ud880\udf5b\ud88b\udf2d\ud87c\udca3\ud993\udcab\udb0f\uddee\uda67\ude51\000\ud9f6\udc5a\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\ud995\ude89\udbb9\ude21\uda64\udf28]]\0121=[Ljava.lang.Object;:[[\ud8bc\uddd2, \uda72\udefe\ud880\udf5b\ud88b\udf2d\ud87c\udca3\ud993\udcab\udb0f\uddee\uda67\ude51\000\ud9f6\udc5a\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\ud995\ude89\udbb9\ude21\uda64\udf28]] |a1=[Ljava.lang.Object;:[[\ud8bc\uddd2, \uda72\udefe\ud880\udf5b\ud88b\udf2d\ud87c\udca3\ud993\udcab\udb0f\uddee\uda67\ude51\000\ud9f6\udc5a\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\ud995\ude89\udbb9\ude21\uda64\udf28]]\012",
        Z.run(T, 2, 4, 4, 0, "\ud8bc\uddd2,\uda72\udefe\ud880\udf5b\ud88b\udf2d\ud87c\udca3\ud993\udcab\udb0f\uddee\uda67\ude51\000\ud9f6\udc5a\uda96\udc5b\uda7a\ude75\udb13\udc9b\ub7c7\ud995\ude89\udbb9\ude21\uda64\udf28", "\000", "\ud9ff\udfae\uda80\udd1f\ud934\uddff\uda84\udf5d\ud8bd\udc5e\udb15\udf14\uda08\udf07\ud8a6\udc6c\ud8a7\udc64\ud8db\udf31\udb1e\udc0c",
        12, 72906, 799610703, 3104475114163804491L, -25771L, true, false, (char) 61809, (char) 54097,
        Double.longBitsToDouble(0x3fea39db15723414L), Double.longBitsToDouble(0x3fe094adb2cb67b9L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.invocation.Invocation|callRealMethod||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|argumentsToMatchers||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|equalArguments|[Ljava.lang.Object;|new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|equals|java.lang.Object|new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|expandVarArgs|boolean,[Ljava.lang.Object;|static",
    "M|org.mockito.internal.invocation.Invocation|getArguments||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|getArgumentsCount||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|getLocation||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|getMethod||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|getMethodName||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|getMock||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|getRawArguments||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|getSequenceNumber||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|hashCode||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|isToString|org.mockito.invocation.InvocationOnMock|static",
    "M|org.mockito.internal.invocation.Invocation|isValidException|java.lang.Throwable|new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
    "M|org.mockito.internal.invocation.Invocation|callRealMethod||new:org.mockito.internal.invocation.Invocation:java.lang.Object,org.mockito.internal.invocation.MockitoMethod,[Ljava.lang.Object;,int,org.mockito.internal.invocation.realmethod.RealMethod",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
