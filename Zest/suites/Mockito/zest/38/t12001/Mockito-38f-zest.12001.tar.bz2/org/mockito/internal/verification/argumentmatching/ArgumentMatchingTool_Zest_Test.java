package org.mockito.internal.verification.argumentmatching;
import org.junit.Test;
import static org.junit.Assert.*;
public class ArgumentMatchingTool_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 1, 2, "\ud85b\ude94\ud854\udf6e", "\u24eb", "\ud861\udd41",
        11, 88888, -574771832, -2958054823262957824L, 20899L, true, true, (char) 44816, (char) 46762,
        Double.longBitsToDouble(0x3fd60dfd43ae32feL), Double.longBitsToDouble(0x3fe8ae106fc307aeL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 1, 2, "\ud85b\ude94\ud854\udf6e", "\u24eb", "\ud861\udd41",
        11, 88888, 12430728, -2958054823262957824L, 20899L, true, true, (char) 44816, (char) 46762,
        Double.longBitsToDouble(0x3fd60dfd43ae32feL), Double.longBitsToDouble(0x3fe8ae106fc307aeL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=new org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 1, 3, 1, 2, "\udb48\udd8e\udaf6\udf13", "\u2522\u154b\u0606\u818b\ubf9a\u5706\u4ced\u7028\u21a0\ua80b\u54e6\u0cd6\u246f\u52ae\u9054\u9a1c\ud7d3", "\ud8da\udc28\ud805\uddd4\udbae\udd96\uda52\udda4\udb81\udfc5\ud836\ude57\ud97e\udc9d\udbf7\ude83",
        13, 74379, -849330217, -2699863400167048400L, 64467L, true, false, (char) 45144, (char) 65,
        Double.longBitsToDouble(0x3fe51619c3b097fbL), Double.longBitsToDouble(0x3f033f7d40ff4000L)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 2, "\ud85b\ude94\ud854\udf6e", "\u24eb", "\ud861\udca3",
        11, 88888, -534856931, -2958055398788575488L, -63688L, false, true, (char) 63339, (char) 22262,
        Double.longBitsToDouble(0x3fe55fc32ec387e7L), Double.longBitsToDouble(0x3fd60dfd43ae32feL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 1, 2, 0, 2, "\udb4d\udeec\uda6e\udd5a\uda4a\udd11\ud938\udfbc\ud846\udde4\udaec\udcf1\uda51\ude51\ud84e\udd98\ud895\udf03", "\u7028\ud24a", "\ud845\udf88\ud902\udce9\ud910\udf3e",
        23, 475, 2015630493, -4463672468796725483L, -88558L, false, false, (char) 22640, (char) 39137,
        Double.longBitsToDouble(0x3fe5ee1cfa2b27faL), Double.longBitsToDouble(0x3fee6ade9fae2fa1L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 1, 2, 1, 2, "\ud8b3\ude1f\uda45\udf18", "\u24eb\u69ec\u1976\ua481\u0146\u5706\u4ced\u7028\ud24a\ud5ee\u737c\ub2a0\u246f\u52ae\u9054\ub8a1\u8b98\ub06b\u50d3\u6700\ud141\u9370\u573a\u033d\u09d1\u4647\u8908\u5e1e\uc515\u4548\u3a5d\ub5ea", "\udb3a\ude58\ud9bc\udd1a\ud89a\udc00\udb05\udcf1\u08d7\uda62\udc9d\udba0\udc39\udbed\udee6\uda41\udd3a\udab3\udf2b\ud8a7\udf05\ud814\udf3e\ud9c4\udf44\uda68\udd1e",
        58, 16629, -1240715574, 7412719753016239068L, -25835L, true, false, (char) 41360, (char) 4671,
        Double.longBitsToDouble(0x3f9c06d8360b1660L), Double.longBitsToDouble(0x3fe72c481b7f2cfeL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 1, 3, 1, 2, "\ud85b\ude94\ud854\udf6e", "\u24eb", "\uda5c\udd56\ud861\udd6a\ud8e9\ude51\ud85d\udd9a\udaa1\ude64",
        54, 97976, -1101765602, 8094973174212843594L, -78848L, true, true, (char) 59682, (char) 30577,
        Double.longBitsToDouble(0x3fdce1ef042d2e60L), Double.longBitsToDouble(0x3fe119479c63b5bdL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=new org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 3, 1, 0, "\ud85b\ude94\ud854\udf6e\ud959\uded9\ud9d5\udd9e\ud846\ude25\udb03\udda8\udb68\udc5d\ud861\udd41\udb4b\udf9d\ud873\udcb2\ud862\udf83", "\ud5ee\u737c\ub2a0\u246f\u52ae\u9054\ub8a1\u8b98\ub06b\u402f\u58ef\u0e0b\u2831", "\ud930\udd95\udb3a\udde5",
        -5, 38891, -993593084, 149753475271959598L, 89743L, true, false, (char) 57673, (char) 20938,
        Double.longBitsToDouble(0x3fa29a25b5acd8d0L), Double.longBitsToDouble(0x3fba3f1721c5ffe0L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 2, 1, 2, "\ud85b\udebf\ud854\udf6e", "\u24eb", "\ud861\udd41\ud895\udf03\ud873\udcb2\ud862\udf83\udaa1\ude64\ud82b\udf33\ud8ab\udde6\udbd4\udd88\ud845\udf88",
        47, 17601, -2014857557, -2318176492702225056L, 21067L, true, true, (char) 1135, (char) 58988,
        Double.longBitsToDouble(0x3f9ccaa037046f80L), Double.longBitsToDouble(0x3fe07528ed57ee88L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 3, 0, 3, "\udbd7\udc11\ud854\udfa6", "\u24eb", "\ud861\udd41",
        11, 88888, -574771848, -2958054823262957824L, 20899L, true, true, (char) 44816, (char) 46762,
        Double.longBitsToDouble(0x3fd60dfd43ae32feL), Double.longBitsToDouble(0x3fe8ae106fc307aeL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 1, 2, "\ud94a\udeca\uda48\ude0c", "\ubc19\u065e", "\ud9ac\udeab\udab3\udf4d\udaaa\udf96\udb86\ude38\udbb4\udc00\udb4f\uded9\udbd9\uddec\ud845\udf88\ud96c\ude8e",
        2, 91443, -539742525, 8657067047216077224L, -29783L, true, true, (char) 7279, (char) 22640,
        Double.longBitsToDouble(0x3fe99bcd76bdc39fL), Double.longBitsToDouble(0x3f9827faf9a6e8c0L)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 2, 0, 2, "\ud96f\udee1\ud9be\udc09\udaac\udfcd\ud938\udfbc\ud846\udde4\udb9a\udf68\ud95d\udf65\ud84e\udd83\ud8c4\ude52\udafc\udc70", "\u61fc\ud5ee\uc8c6\u5f96\ub4de\uc66f\u9054\ub8a1\u2b02\ub01e\u6a0a\u0644\ud052\u3ccd\ud7d3\u57a3\u9b31\u9b91\u1841\u8e54\u34a7\u428f\u22d6\uc346\u3684\uc5b1\u9ba6", "\udae5\ude38",
        47, 99511, 1219988198, 7539318289612614958L, 96117L, true, false, (char) 63629, (char) 58218,
        Double.longBitsToDouble(0x3fdc6f478f9fe530L), Double.longBitsToDouble(0x3fe086afa1c3a387L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 2, 2, 2, 2, "\ud97c\ude27\ud8cd\udf20\udbe2\udf5d", "\u29f7\u78fc\u65ef\u6b35", "\udbdd\uddc3\udba4\uddb7",
        -1, 53749, 532410864, -8988910789525711951L, -75983L, true, true, (char) 6647, (char) 42951,
        Double.longBitsToDouble(0x3fe392babfef2d84L), Double.longBitsToDouble(0x3fefbfd706bd2803L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=new org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=new org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 2, 3, 3, 3, "\ud85b\ude94\ud854\udf6e\ud959\uded9\ud9d5\udd9e\ud846\ude25\udb03\udda8\udb68\udc5d\ud861\udd41\uda71\udf7c\ud873\udd11\ud862\udf83", "\ud5ee\u75e0\ub2a0\u246f\u52ae\u9054\ub8a1\ua7bd\u3630\u7506\ucb11\u0e53", "\udacd\udd8a\ud995\udf83",
        16, 3043, 1472821933, 920696969453897726L, 21715L, true, true, (char) 23767, (char) 44776,
        Double.longBitsToDouble(0x3fd9919fb5a36092L), Double.longBitsToDouble(0x3fc22eaeb461a000L)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 2, 2, 2, 3, "\ud85b\udebf\udabd\ude22\udaa0\ude1b\uda92\ude31\ud9af\udf85\uda02\udd77\udb68\udc44\ud861\udd41\ud895\udf03\ud873\udcb2\ud918\udf1d\u9263\ud82b\udf33\ud8ab\udde6\udbd4\udd88\ud845\udf88\ud902\udce9\ud910\udf3e\ud885\udf97\ud9ef\udcd4\uda37\udee5\ud8ed\udd3c\udb71\udf88\ud8c3\udc35\ud982\udde6\udb2a\udfcf\ud939\ude33\udb6d\udc5c\ud9ba\udd06\udb6d\udc29\ud855\udd1a\udab7\udf55\ud960\udf09\uda0c\ude59\uda7b\udea7\ud89e\ude2c\ud87c\udc74\udb08\udc0e\ud95b\udcdd\uda61\udfae\udb14\udd24\ud901\udfd2", "\uab53\u2c60\ucea8\ua62f\u3d5b\u820c\u495f\u0956\u5ff4\ubb67\u50b3\u91c7\ua31a\u51a1\uab7c", "\uda20\udf37\udba0\udff9\udb0a\udf15\udb5b\ude40\udb25\udd83\ud9f6\udff5\ud827\uddef",
        36, 65730, -964691749, 7238053801219453007L, -96024L, false, false, (char) 1999, (char) 51973,
        Double.longBitsToDouble(0x3fde52466e74c60eL), Double.longBitsToDouble(0x3fd73cd9a78064d2L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=java.lang.Boolean:false |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=[Ljava.lang.Integer;:[[]] |a1=[Ljava.lang.Object;:[[\u3a90\u2183\u9cad\u4a19\u2877\u158f\u06a7\u5778, ]] |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 2, 2, 1, 2, "\ud85b\udebf\udb43\udd41\ud9d8\udf4c", "\u3a90\u2183\u9cad\u4a19\u2877\u158f\u06a7\u5778,", "\ud902\udce9",
        49, 27014, -540613949, 1860740222859774167L, 59683L, false, true, (char) 33272, (char) 61116,
        Double.longBitsToDouble(0x3fdb8237c41d4a3aL), Double.longBitsToDouble(0x3fd57ee88361f500L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=[Ljava.lang.Integer;:[[]] |a1=[Ljava.lang.Object;:[[\u3a90\u2183\u9cad\u4a19\u6ff3\u4838\u9903\u5778, ]] |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\0121=[Ljava.lang.Integer;:[[]] |a1=[Ljava.lang.Object;:[[\u3a90\u2183\u9cad\u4a19\u6ff3\u4838\u9903\u5778, ]] |this=org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:@?\012",
        Z.run(T, 2, 1, 1, 2, "\ud85b\udebf\udb15\udf41\ud9d8\udf4c", "\u3a90\u2183\u9cad\u4a19\u6ff3\u4838\u9903\u5778,", "\ud902\udce9",
        12, 27014, -926490034, 1860740222859774167L, 59683L, false, true, (char) 33272, (char) 61116,
        Double.longBitsToDouble(0x3fdb8237c41d4a3aL), Double.longBitsToDouble(0x3fd57ee88361f500L)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 1, 1, 1, "\ud85b\ude94\ud854\udf6e\ud959\uded9\ud885\udf13\ud846\uddb6", "\u0f2d", "\ud839\udf69\udaa1\ude64\udb8e\ude00\udb4f\uded9\udbd6\udcdb\ud845\udf88\ud902\udce9",
        9, 91443, -1294717245, 1818390951954864599L, 59683L, false, true, (char) 56360, (char) 11826,
        Double.longBitsToDouble(0x3feb2457e0bd9399L), Double.longBitsToDouble(0x3fc5da084c234000L)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool|toStringEquals|org.hamcrest.Matcher,java.lang.Object|new:org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:",
    "M|org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool|getSuspiciouslyNotMatchingArgsIndexes|java.util.List,[Ljava.lang.Object;|new:org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:",
    "M|org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool|safelyMatches|org.hamcrest.Matcher,java.lang.Object|new:org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:",
    "C|org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool|<init>|",
    "M|org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool|toStringEquals|org.hamcrest.Matcher,java.lang.Object|new:org.mockito.internal.verification.argumentmatching.ArgumentMatchingTool:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
