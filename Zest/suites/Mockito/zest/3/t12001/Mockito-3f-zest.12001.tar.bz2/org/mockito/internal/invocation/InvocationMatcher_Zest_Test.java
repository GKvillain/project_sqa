package org.mockito.internal.invocation;
import org.junit.Test;
import static org.junit.Assert.*;
public class InvocationMatcher_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 13, 4, "\ud924\udf41\udbfa\ude8f\ud829\udef7\ud849\udea9\udaf0\ude4d\uda4e\udcfa\ud92a\uddf4\ud96c\uddb7\uda60\udf89", "\u6c9b\u4d03\u1bda\u8c81\u9503\ub430\ua137\u3e8f\u2dc2", "\uda8c\udfd1\udbeb\ude76\uda23\udeba\udbd6\udcb3\udaea\udd30\ud95e\udc66\u9385\ud977\udcf7\ud844\udd73\udb74\udddc\udb00\ude69\ud9de\udf89\ud8b3\udef8",
        44, 16590, -86440994, 6376336233195225446L, -21468L, false, true, (char) 39627, (char) 20924,
        Double.longBitsToDouble(0x3fc538e77d50f9bcL), Double.longBitsToDouble(0x3fd395e1e2e2acacL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 13, 4, "\ud8af\udfc7\udb11\udedd\ud829\uded7\ud849\udea9\udaf0\ude4d\uda4e\udcfa\ud92a\uddf4\ud96c\uddb7\uda60\udf89", "\u6c9b\u4d03\u1bda\u8c81", "\ud841\udf18\ud966\udf24\udb30\udc70\udb0d\udc71\udbce\udc01\uda8c\udfd1\udbeb\ude76\uda23\udeba\udbd6\udcb3\udaea\udd30",
        33, 38606, 761098827, -7856071993675470791L, -52462L, false, false, (char) 11457, (char) 45306,
        Double.longBitsToDouble(0x3fe5a1ba2121c8b4L), Double.longBitsToDouble(0x3fd66fd82644a81aL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 12, 13, 4, "\ud924\udf41\udbfa\ude8f\ud829\udef7\ud849\udea9\udaf0\ude4d\uda4e\udcfa\ud92a\uddf4\ud96c\uddb7\uda60\udf89\udb7e\ude16\udb94\udd1f\udbcf\udd9c\ud826\ude4a\udb62\udde5\udba4\ude7d\udab8\udc17\ud84d\udfa9", "\u2dc2\u75b8\ucfeb\u9eb2\ud4f3\ud33d\u7dd8\u1dc1\u1a07\u126c\u480f\u5180\u94dd\u4780\u6ebc\u06ea\u6cce", "\u093c\ud81b\ude5a",
        -2, 50596, -852639956, 8378610234305535350L, 45236L, true, true, (char) 42951, (char) 47759,
        Double.longBitsToDouble(0x3fe06f89cae4a2eeL), Double.longBitsToDouble(0x3fd21e620650e95cL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 5, 13, 13, "\ud817\udfda\u6190\ud829\udef7\ud849\udea9\udaf0\ude4d\uda4e\udcac\ud92a\uddf4\ud96c\uddb7\ud9d0\udc0b", "\u6c9b\u2e20\u2e8a\ua9bb\u94ef\ub430\ua137\ub8a4\u8fc5", "\uda8c\udfc9\udbeb\ude76\ud8d3\udcd0\ud96b\udd0c\udab1\udea4\ud95e\udc66\u9385\ud9b3\udff5\udab3\udf93\udb74\udddc\ud8fe\uded3\ud9f0\udcbc\ud8b3\udef8\udb59\udebc\ud960\udc14\ud8e6\udf90\ud8a6\udfee\udb9b\udd54\udaa3\udd5a\ud876\uddc8\ud898\ude3f",
        27, 82515, -647003991, 6781918924227722553L, 83577L, true, true, (char) 31466, (char) 6877,
        Double.longBitsToDouble(0x3fa423cf199624c0L), Double.longBitsToDouble(0x3feea631d199f0a0L)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!java.lang.ClassCastException\012",
        Z.run(T, 1, 2, 7, 10, "\ud928\ude74\udbfa\ude8f", "\u98d1\u3581\u7cba\u5006\u0357\u0217\ua6ad\u55a5\u4be3\u7d68\u8c81\u9503\u234d\u6c4b\u25d9\u1cfd\u7488\u76fa\u9ed0\ud4f3\ud33d\u7dd8\u52f3\u1a07\u934f\u4862\u5180\u1903", "\ud8b3\udef8\udb59\udebc\ud960\udc49\ud8e6\udf90\u093c\ud81b\ude5a\udb41\ude89\uda9c\udd0f\ud9f4\udd4c\ud8ab\udc4a\uda46\ude6f\udaf3\ude52\ud9a0\udffc\uda1e\ude4f\u2aec\udbe6\udf0b\ud865\udee6\ud889\udc97\ud9b6\ude49\uda19\udd59\uda31\ude1e",
        37, 73598, -254183323, 6303641139328194626L, -65840L, false, false, (char) 26466, (char) 8535,
        Double.longBitsToDouble(0x3fd5da650e860d48L), Double.longBitsToDouble(0x3fedfc8f877eeb46L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 10, 11, 4, "\u2786\uda43\udfee\ud828\udfb1\ud849\udea9\udada\ude42\uda4e\udcfa\ud92a\uddf4\ud96c\uddb7\uda60\udf89", "\ua19b\u4d03\u1bda\u8c81\u9f4b\u24d3\ua137\u3e8f\u2dc2", "\uda8c\udfd1\udbeb\ude76\uda23\udeba\ud9ec\udf1e\udaea\udd6a\ud95e\udc66\ud8ac\udf7a\ud977\udcf7\ud844\udd73\udb74\udddc\udb00\ude69\ud9de\udf89\ud925\udc51",
        23, 16590, 572916702, 6752721695344017896L, -55508L, false, true, (char) 39627, (char) 20924,
        Double.longBitsToDouble(0x3fc538e77d50f9bcL), Double.longBitsToDouble(0x3fd395e1e2e2acacL)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 13, 4, "\ud970\udf1f\uda9f\udf2d\ud840\udca2\ud849\udea9\udaf0\ude4d\uda4e\udcfa\ud92a\uddf4\ud96c\uddb7\uda60\udf89", "\u6c9b\u4d03\u1bda\uc0ee\u9503\ub430\ua137\u3e8f\u2dc2", "\uda8c\udfd1\udbeb\ude76\uda23\udeba\udbd6\udcb3\udaea\udd30\ud95e\udc66\u9385\uda60\ude7a\ud844\ude11\udb74\udddc\udb00\ude69\ud9de\udf89\ud8b3\udef8",
        44, 66078, -86440994, 6376336233195225446L, -21468L, false, true, (char) 39627, (char) 20924,
        Double.longBitsToDouble(0x3fc538e77d50f9bcL), Double.longBitsToDouble(0x3fd395e1e2e2acacL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 1, 1, 4, "\ud924\udf41\udac9\udef7\u6fdd\ud849\udea9\udac0\udd14\ud9df\udfbf\ud92e\udd1a\ud96c\uddb7\ud83b\uddb6", "\u5822\u4d03\ub745\ua91d\uc938\ub430\ua137\uc1d0\u9189\uaba0\ucfeb\u8807\u0fc5\ub409\u7dd8\u1dc1\u1a07\u126c\u426e\u9dec\u9969\u2206", "\udb59\udebc\ud987\udf31\ud903\ude83\ud879\udd18\ud829\udd81\udb41\ude89\ud97e\udf61\ud8f3\udc2d\udae8\udfd7\ud87f\udc49\uda0d\udce4\uda73\udcad\udbed\udc62\udb1d\udee6\u8c92\ud8a5\udef0",
        28, 26776, 279948632, -2499281960578678965L, 38008L, false, true, (char) 24192, (char) 18535,
        Double.longBitsToDouble(0x3fc25a6b287ae784L), Double.longBitsToDouble(0x3fdf3ea79dc8da46L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 1, 12, "\ud924\udf41\udbfa\ude8f\ud829\udef7\ud849\udea9\udaf0\ude4d\uda4e\udcfa\ud92a\uddf4", "\u0217\u7e16\u6c9b\u481e", "\ud85f\udc6b\uda11\udea6\udb11\ude22\ud966\udf24\udb30\udc70\udb0d\udc71\u2cfd\uda88\ude2e\udbeb\ude76\uda23\udeba\udbd6\udcb3\udaea\udd30\ud95e\udc66\u9385\ud977\udcf7\ud844\udd73\udb74\udddc\udb00\ude69\ud9de\udf89\ud8b3\udef8\udb59\udebc",
        35, 14006, 1484606469, 6056709716406029090L, 47668L, false, false, (char) 20924, (char) 18404,
        Double.longBitsToDouble(0x3feaa1f37d395e1eL), Double.longBitsToDouble(0x3fd715656007723cL)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 11, 14, "\ud970\udf1f\uda9f\udf2d\udb3a\udcf4\ud849\udea9\udaf0\ude4d\uda4e\udcfa\ud92a\uddf4\udaee\udf83\uda60\udf89\udb7e\ude16\udb94\udd1f\udbcf\udd9c\ud826\ude4a\udb62\udde5\udb17\udff8\udab8\udc17\ud84d\udfa9", "\u7dc1\u75b8\u02d5\uadb4\u3b7a\ud33d\u7dd8\u1dc1\u1a07\u126c\u1aec\u521e\ua0e8\uc917\u6ebc\u06ea\u6cce", "\u093c",
        7, 68978, -527774404, -3662060724332081762L, -67401L, false, true, (char) 6999, (char) 42951,
        Double.longBitsToDouble(0x3fea62f721259749L), Double.longBitsToDouble(0x3fe9633a17a77c9cL)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\012",
        Z.run(T, 2, 12, 12, 4, "\ud970\udf1f\uda9f\udf2d\ud840\udca2\uda66\udf98\udaf0\ude12\uda4e\udcfa\ud92a\uddf4\ud96c\uddb7\uda60\udf89", "\u6c9b\u4d03\u1bda\uc0ee\u9503\ub430\ua137\u3e8f\u2dc2", "\uda8c\udfd1\udbeb\ude76\uda23\udeba\udbd6\udcb3\ua1fe\ud95e\udc66\u9385\uda60\ude7a\ud844\ude11\ud8d9\udf8e\ud821\ude6c\udb99\udcc6\ud8b3\udf2e",
        44, 66078, -86440994, 3998435629943603558L, -21468L, false, true, (char) 39627, (char) 20924,
        Double.longBitsToDouble(0x3fc538e77d50f9bcL), Double.longBitsToDouble(0x3fd395e1e2e2acacL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=new org.mockito.internal.invocation.InvocationMatcher:!toString:java.lang.NullPointerException\0121=!java.lang.ClassCastException\012",
        Z.run(T, 2, 12, 2, 6, "\ud9c8\ude0b\uda9f\udf2d\ud840\udca2\ud849\udea9\udaf0\ude4d\uda4e\udcfa\ud92a\uddf4\ud96c\uddb7\uda60\udf89", "\u4b5f\ud2b2\u1bda\uc0ee\u9503\ub430\ua137\u3e8f\u2dc2", "\uda8c\udfd1\udbeb\ude76\uda23\udeba\udbd6\udcb3\udaea\udd30\ud95e\udc66\u9385\uda60\ude7a\ud844\ude11\udb74\udddc\udb00\ude69\udb66\ude15\udad2\udc4b",
        44, 66078, -86440994, 6376336230236004561L, 54294L, false, true, (char) 35019, (char) 61744,
        Double.longBitsToDouble(0x3fc538e77d50f9bcL), Double.longBitsToDouble(0x3fd395e1e2e2acacL)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 7, 13, 4, "\ud919\ude41\udbfa\ude8f\ud829\udef7\ud849\udea9\udaf0\ude4d\uda4e\udcfa\ud92a\uddf4\ud96c\uddb7\uda60\udf89", "\u6c9b\u4d03\u1bda\u8c81\u9f02\ub430\ua137\u3e8f\u2dc2", "\uda8c\udfd1\udbeb\ude76\uda23\udeba\udbd6\udcb3\udaea\udd30\ud95e\udc66\u9385\ud977\udcf7\ud844\udd73\u3feb\ud963\udde7\ud9de\udf30\uda85\uddd2",
        56, 16590, -86440994, 6376337049239011686L, -21468L, false, true, (char) 39627, (char) 20924,
        Double.longBitsToDouble(0x3fc538e76950f9bcL), Double.longBitsToDouble(0x3fd395efc2e2acacL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.invocation.InvocationMatcher|captureArgumentsFrom|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|uniqueMatcherSet|int|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|createFrom|java.util.List|static",
    "M|org.mockito.internal.invocation.InvocationMatcher|getInvocation||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getLocation||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getMatchers||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|getMethod||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSameMethod|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|hasSimilarMethod|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|matches|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|safelyArgumentsMatch|[Ljava.lang.Object;|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|toString||new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "C|org.mockito.internal.invocation.InvocationMatcher|<init>|org.mockito.invocation.Invocation,java.util.List",
    "C|org.mockito.internal.invocation.InvocationMatcher|<init>|org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|captureArgumentsFrom|org.mockito.invocation.Invocation|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
    "M|org.mockito.internal.invocation.InvocationMatcher|uniqueMatcherSet|int|new:org.mockito.internal.invocation.InvocationMatcher:org.mockito.invocation.Invocation",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
