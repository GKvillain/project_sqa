package org.mockito.internal;
import org.junit.Test;
import static org.junit.Assert.*;
public class MockHandler_Zest_Test {
  @Test(timeout = 4000)
  public void test0() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 2, 7, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1ed2", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udaa8\udc4f\udb1b\udcf9",
        1, 62311, -2037785584, 5966770024800874598L, 85706L, true, true, (char) 25676, (char) 15397,
        Double.longBitsToDouble(0x3feef8ff6f95bdd7L), Double.longBitsToDouble(0x3fe79f63f7c2f47eL)));
  }
  @Test(timeout = 4000)
  public void test1() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 16, 2, 7, "\ud8a4\udff8\ud934\udf0b", "\u4738\u2b44", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udaa8\udc4f\udb1b\udcf9\ud804\udf7f\ud991\udeda\uda25\udce7\ud8d3\ude9a\uda75\ude91\ud893\udfe7",
        42, 97077, 931224686, -3937114514589181200L, -13715L, false, true, (char) 63866, (char) 33562,
        Double.longBitsToDouble(0x3fdf6f165bd438b2L), Double.longBitsToDouble(0x3febc4e4de2546ebL)));
  }
  @Test(timeout = 4000)
  public void test2() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 6, 2, 7, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1ed2", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\ud869\ude11\ud919\udf22",
        42, 20269, -2037785584, 5966770024800874598L, 85706L, true, true, (char) 25676, (char) 15397,
        Double.longBitsToDouble(0x3feef8ff6f95bdd7L), Double.longBitsToDouble(0x3fe79f63f7c2f47eL)));
  }
  @Test(timeout = 4000)
  public void test3() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 14, 2, 7, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1ed2", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udaa8\udc4b\udb1b\udcf9",
        1, 40607, 1162878170, 5966769672613556326L, 85706L, true, true, (char) 15555, (char) 36855,
        Double.longBitsToDouble(0x3fed1382f795bdd7L), Double.longBitsToDouble(0x3fe79f63f7c2f47eL)));
  }
  @Test(timeout = 4000)
  public void test4() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 12, 1, 7, "\ud8a4\udff8\uda1c\ude19", "\u55d9\u2162", "\ud978\uddad\uda63\ude93\udafd\udde9\ud87f\udcfb\udaa8\udc4f\udb1b\udcf9\ud804\udf7f\ud991\udeda\uda25\udce7\udb03\ude92\uda75\ude91\ud893\udfe7\udbf0\uddbb\ud861\ude5b\ud957\udddb\udab2\udffc\uda9c\udd69\udab8\udc26\ud836\udc9b",
        57, 86731, -937207358, -2703709802824860536L, -94070L, false, true, (char) 41446, (char) 40603,
        Double.longBitsToDouble(0x3fe9c08681792f3fL), Double.longBitsToDouble(0x3fc8abe0bc27c704L)));
  }
  @Test(timeout = 4000)
  public void test5() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 7, 5, 16, "\ud985\udde7\uda0f\uddca\udac8\udc94\uda39\ude1a\udbb1\udd7b\udb3e\udeb2\ud9b2\udcbb\uda70\udfb9\ud9a2\udc4c\uda63\udeda\uda78\udf46\ud9de\udf7b", "\u35f8\u48ea\u041b", "\ud893\udfe7\udbf0\uddbb\ud861\ude5b\udb7a\udf4e\udab3\uddd3\uda9c\udd69\udab8\udf26\udbce\uddb0\ud858\udcd3\ud9cc\udda7\ud9d6\udd6a\uda18\udef0",
        49, 71247, -73377271, -2118077601485926630L, -69349L, false, true, (char) 3754, (char) 62008,
        Double.longBitsToDouble(0x3fe6ac5f13c2fe3cL), Double.longBitsToDouble(0x3fd1c6412d89ebb0L)));
  }
  @Test(timeout = 4000)
  public void test6() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 11, 8, 7, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1ed2", "\ud978\ude1e\ud859\udeee\ud83b\udc5e\udb4b\udd93\udaa8\udc4f\udb1b\udcf9",
        1, 62311, -2037785584, 5966770024800874598L, 85706L, true, true, (char) 25676, (char) 15397,
        Double.longBitsToDouble(0x3feef8ff6f95bdd7L), Double.longBitsToDouble(0x3fe79f63f7c2f47eL)));
  }
  @Test(timeout = 4000)
  public void test7() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\ud8a4\udff8\uda1c\ude19]] |this=org.mockito.internal.MockitoCore:@?\012",
        Z.run(T, 1, 9, 7, 7, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1e9b", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udaa8\udc4f\udb1b\udcf9\ud804\udf7f\ud991\udeda\uda25\udce7\ud8d3\ude9a\uda75\ude91\ud893\udfe7\udbf0\uddbb\ud861\ude5b\ud957\udddb\udab2\udffc\uda9c\udd69\udab8\udc26\udb9c\udff8\udab9\ude6e\ud991\ude45\uda4b\udca4\ud9a1\udfe0\ud913\udfab\udab4\uddaf\ud987\udeb2\ud837\udefe\ud81d\ude16\udab6\udcf9",
        8, 40817, -1910492776, 8635202780063765014L, -39823L, true, false, (char) 11391, (char) 16966,
        Double.longBitsToDouble(0x3f5ea5b52b02b400L), Double.longBitsToDouble(0x3fd63776c04e8232L)));
  }
  @Test(timeout = 4000)
  public void test8() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 5, 3, 4, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1ed2", "\ud978\ude1e\uda63\ude93\ud83b\udc69\udb4b\udd93\udaa8\udc4f\udb1b\udcf9",
        1, 25967, -2037824230, 5966770024800874598L, -30778L, false, false, (char) 9649, (char) 50869,
        Double.longBitsToDouble(0x3fe7864ae5546de0L), Double.longBitsToDouble(0x3fedcf1c9795e7d7L)));
  }
  @Test(timeout = 4000)
  public void test9() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 2, 16, 7, "\uda06\udf29\uda1c\ude19", "\u4738\u1ed2\u6733\ubc96\u1cd4", "\udb4b\udd93\udaa8\udc4f\uda1b\udcf9\ud804\udf7f\ud991\udeda\ud81e\udf63\ud873\udc9b\uda6e\uded8\ud893\udfe7\udbf0\uddbb\ud861\ude5b",
        16, 95093, 1843436272, 2300721779294316511L, -13715L, false, true, (char) 31838, (char) 11312,
        Double.longBitsToDouble(0x3fca950cfc5fb874L), Double.longBitsToDouble(0x3fcb7bc30ea2fe64L)));
  }
  @Test(timeout = 4000)
  public void test10() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 4, 2, 7, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1ed2", "\ud978\ude1e\uda63\ude93\ud866\udc73\udb4b\udd93\udaa8\udc4f\udb1b\udcf9",
        1, 62311, -2037785584, 5966770021560676761L, 11196L, true, true, (char) 25676, (char) 15397,
        Double.longBitsToDouble(0x3feef8ff6f95bdd7L), Double.longBitsToDouble(0x3fe79f63f7c2f47eL)));
  }
  @Test(timeout = 4000)
  public void test11() throws Throwable {
    assertEquals("0=!java.lang.NullPointerException\012",
        Z.run(T, 1, 13, 4, 7, "\ud838\udef7\uda1c\ude19", "\u47fb\u9ad2", "\ud978\ude1e\uda63\ude93\ud83b\ude29\udb4b\udd93\udaa8\udc4f\udb1b\udcf9",
        46, 74311, -2037785584, 5966770024800874598L, -87179L, false, false, (char) 61914, (char) 28316,
        Double.longBitsToDouble(0x3fdf43e1c8e20164L), Double.longBitsToDouble(0x3fc4343f9f8522d0L)));
  }
  @Test(timeout = 4000)
  public void test12() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 1, 15, 2, 5, "n\000", "", "\udb13\udf92",
        53, -1000, 1788887115, 7914818844634382531L, -100000L, false, false, (char) 64532, (char) 360,
        Double.longBitsToDouble(0x3fdb986890cca59cL), Double.longBitsToDouble(0x3fd6568b4ccc5522L)));
  }
  @Test(timeout = 4000)
  public void test13() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 1, 1, 1, 7, "\ud8c2\ude0a\uda1c\ude19\ud9cb\udc56\uda6f\uddcf\ud865\udc07\uda6c\udd60", "\u1cd4\u35ab\u212b\u7774\ua463\u9a8c", "\uda25\udce7\ud8d3\ude9a\uda75\ude91\ud893\udfe7\udbf0\ude2a\ud861\ude5b\ud957\udddb\udab2\udffc\uda9c\udd69\udaa8\udfbf\udb9c\udff8\udab9\ude6e\ud9f8\ude43\ud8f9\udde2\ud830\udd6b\uda52\udc65\ud949\udcb9\ud989\udfb8\udb6b\udd4e",
        1, 87130, -891651842, -4423112989504639356L, 66470L, false, false, (char) 36468, (char) 65135,
        Double.longBitsToDouble(0x3fad020e7169bb80L), Double.longBitsToDouble(0x3fedd9083122ba6bL)));
  }
  @Test(timeout = 4000)
  public void test14() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 16, 1, "\udbcd\udd2c\udbd5\udf7f\ud9bf\ude14\uda6f\uddcf\ud865\udc07\uda6c\udd60", "\u1cd4\uc76b\u078b\u8852\ua42a\u6d11", "\uda25\udce7",
        15, 62718, 262816358, -2936911028067578182L, -13303L, true, false, (char) 969, (char) 55108,
        Double.longBitsToDouble(0x3feff6852af9fba1L), Double.longBitsToDouble(0x3f8ae19a41d84340L)));
  }
  @Test(timeout = 4000)
  public void test15() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 2, 15, 15, 0, "\ud8a4\udff8\uda1c\ude19", "\u42c7\u1ed2", "\ud829\ude8c\u4e5e\udb0c\udde3\ud900\ude0b\ud819\udf14\ud897\udc45",
        31, 62311, -2037793520, 4350748514922377280L, 20887L, true, true, (char) 25795, (char) 15397,
        Double.longBitsToDouble(0x3feef8ff6917bdd7L), Double.longBitsToDouble(0x3fd290a9e3c73eb4L)));
  }
  @Test(timeout = 4000)
  public void test16() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 13, 15, 8, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1ed2", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udaa8\udc4f\udb1b\udcf9",
        1, 62311, -2037785584, 5966770024800874598L, 85706L, true, true, (char) 25676, (char) 15397,
        Double.longBitsToDouble(0x3feef8ff6f95bdd7L), Double.longBitsToDouble(0x3fe79f63f7c2f47eL)));
  }
  @Test(timeout = 4000)
  public void test17() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=new org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 7, 8, 7, "\ud8ae\udf14\ud910\udd73", "\u287c\u0c04\u466d\ubc31\u1cd4\u96aa\uc7fc", "\ud82f\udc37\ud80d\udcbb\udaa8\udca5\ud982\udd34\ud81d\udf00\uda75\ude5d\ud893\udfe7\udbf0\uddbb\uda20\udf3b\ud9c3\ude55\udbd4\udd8a\uda9c\udcf5\udab8\udc26\udb9c\udff8\udadd\udcff",
        51, 43003, 1421743900, -3301898238584346758L, -40598L, false, true, (char) 7518, (char) 55467,
        Double.longBitsToDouble(0x3fe978790061ad57L), Double.longBitsToDouble(0x3fe04e7e852edca8L)));
  }
  @Test(timeout = 4000)
  public void test18() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 13, 7, 7, "\udb64\uded8\ud914\udfc5", "\u9849\u7b39\u330b", "\udaed\udef9\uda52\ude37\uda52\udfbe\ud8cb\udcf9\udb3b\udeb2\u4492\ud985\udcda\uda35\ude2e\ud8d3\ude9a\uda75\ude91\ud893\udfe7\ud80c\ude09\ud861\ude48\ud957\ude05\udaf5\ude30\udb59\udec9",
        -1, 54075, -327280747, 4227803572195017956L, 95236L, false, true, (char) 21675, (char) 4447,
        Double.longBitsToDouble(0x3fb5442a0590f8d8L), Double.longBitsToDouble(0x3fedfdc350f6bfc1L)));
  }
  @Test(timeout = 4000)
  public void test19() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 2, 8, 15, 7, "\ud8a4\udff8\ud934\udf0b", "\u68ee\u0f08", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udaa8\udc4f\udb1b\udcf9\uda5a\udea2\ud991\udeda\uda25\udce7\ud8d3\ude9a\uda75\ude91\ud893\udfe7",
        42, 97077, 931224686, -3937114514589181200L, -77439L, false, true, (char) 1280, (char) 1179,
        Double.longBitsToDouble(0x3fef80cc5ec1e459L), Double.longBitsToDouble(0x3fdf6f165bd438b2L)));
  }
  @Test(timeout = 4000)
  public void test20() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 1, 7, 16, 7, "\ud8a4\udff8\ud934\udf0b", "\u4738\u2b44", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udac0\udd4f\udb1b\udcf9\ud804\udf7f\ud991\udeda\uda25\udce7\ud8d3\ude89\uda75\ude91\ud893\udfe7",
        42, 97077, 931224686, 2865045536793188254L, -13715L, false, true, (char) 63866, (char) 33562,
        Double.longBitsToDouble(0x3fdf6f165bd438b2L), Double.longBitsToDouble(0x3febc4e4de2546ebL)));
  }
  @Test(timeout = 4000)
  public void test21() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 9, 4, 1, "\ud8ae\ude73\ud97d\udc0c", "\u4dd4\u2ba7\u26b4\ua49d\u1cd4\u96aa\uc7fc\u9446\ua42a\u9a8c", "\uda25\udce7\ud99f\udde1\udb3d\udd43\ud8b9\ude9f\udbf0\uddbb\ud888\udd6f\ud963\udfb3\udab2\udffc\uda9c\udd69\udab8\udc26\ud8da\udff7\udab9\uddfd\ud991\ude45\ud948\udd43\udb75\ude4e\udaaf\udde4\ud887\ude09\ud1bd\uda9d\udcc1",
        39, 93620, 831919508, -5171289744084845774L, 7288L, true, false, (char) 28870, (char) 41142,
        Double.longBitsToDouble(0x3fedb292760d2966L), Double.longBitsToDouble(0x3fd7034bb38398fcL)));
  }
  @Test(timeout = 4000)
  public void test22() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 7, 3, 4, "\ucc97\ud90a\udd00", "\u4738\u2b44", "\ud99f\udccf",
        10, 66366, -2045268797, -2824290645195382335L, -57849L, false, false, (char) 49218, (char) 49972,
        Double.longBitsToDouble(0x3fd6568b4ccc5522L), Double.longBitsToDouble(0x3fe529c0c46ea796L)));
  }
  @Test(timeout = 4000)
  public void test23() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 1, 12, 15, 7, "\ud8a4\udff8\ud934\udf0b", "\u4738\u9fa8", "\ud978\ude1e\udb8d\udde9\ud925\ude49\udb4b\udd15\udaa8\udc4f\udb1b\udcf9\ud804\udf7f\ud991\udeda\uda25\udce7\ud9a7\ude24\uda75\ude91\ud893\udfe7",
        42, 97077, 931224686, -3937114514589181200L, -8730L, false, true, (char) 46630, (char) 56829,
        Double.longBitsToDouble(0x3fd7b6ccdd82d79cL), Double.longBitsToDouble(0x3fcede2cb7a87078L)));
  }
  @Test(timeout = 4000)
  public void test24() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 3, 2, 7, "\ud8a4\udfc2\uda30\ude65", "\u4828", "\ud837\udf30\uecfa\ud8df\udee8\ud80a\udd6f\udb4b\udd93\udaa8\udc2d\ud990\ude4d\uec6e\udaf1\ude23\uda25\udce7\ud8d3\ude9a\ud996\udc22\udbde\ude00\u76be\udb24\udc7d\udadf\udd41\uda13\udf51\uda9c\udcb9\udb36\uddfe\ud985\ude40\udb7f\udd84",
        36, 55682, -427127623, -1052260385679639050L, -84504L, false, false, (char) 54058, (char) 62303,
        Double.longBitsToDouble(0x3fe016c84b085e8cL), Double.longBitsToDouble(0x3fdbc8a86452b75aL)));
  }
  @Test(timeout = 4000)
  public void test25() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 4, 1, 7, "\ud8a4\udff8\uda1c\ude19\ud9cb\udc56\uda69\udf0b", "\u8d2d\ubc96\u9c7f\u96e6\u00c9\u5c3a", "\udbd0\uded5\ud968\ude64\uda25\udce7\ud8d3\ude9a\ud89e\udfde\ud8ac\udfbc\ud8a0\udd22\ud8a5\udd88\ud8ea\ude07\udaa8\udc59",
        58, 74533, -203970593, -1405487915634639117L, 13085L, true, false, (char) 38977, (char) 50617,
        Double.longBitsToDouble(0x3fd0202dfd41f536L), Double.longBitsToDouble(0x3faa8fb28d760170L)));
  }
  @Test(timeout = 4000)
  public void test26() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 2, 10, 15, 1, "\ud908\udf88", "\ubaf8\ud37b", "\ud8fe\udf70",
        0, 8727, -341800221, -4677142145309730155L, 83896L, true, false, (char) 52367, (char) 49218,
        Double.longBitsToDouble(0x3fe50f8d17a5f8a0L), Double.longBitsToDouble(0x3fe331548f24389bL)));
  }
  @Test(timeout = 4000)
  public void test27() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 3, 12, 7, "\ud8a4\udff8\uda1c\udeaf", "\u4738\u1ed2", "\ud978\ude1e\ud859\udeee\ud83b\udc5e\udb4b\udd93\udaa8\udc4f\uda44\udf4f",
        31, 49242, -1028301101, -5163450071482109993L, 85706L, true, true, (char) 25676, (char) 15397,
        Double.longBitsToDouble(0x3fe378ff6c2f456aL), Double.longBitsToDouble(0x3fe109ba7798ee21L)));
  }
  @Test(timeout = 4000)
  public void test28() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 4, 5, 7, "\ud8a4\udff8\uda1c\ude19", "\u4738\u1e9b", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udaa8\udc4f\udb1b\udcf9\ud804\udf7f\ud991\udeda\uda25\udce7\ud8d3\ude9a\uda75\ude91\ud893\udfe7\udbf0\uddbb\ud861\ude5b\ud957\udddb\udab2\udffc\uda9c\udd69\ud900\udc8b\udbd1\uddea\udab9\ude6e\ud991\ude45\uda4b\udca4\ud9a1\udfe0\ud913\udfab\udab4\uddaf\ud987\udeb2\ud837\udefe\ud81d\ude16\udab6\udcf9",
        8, 40817, -1910492776, 8635202780063765014L, -39823L, true, false, (char) 11391, (char) 16966,
        Double.longBitsToDouble(0x3f5ea5b52b02b400L), Double.longBitsToDouble(0x3fd63776c04e8232L)));
  }
  @Test(timeout = 4000)
  public void test29() throws Throwable {
    assertEquals("0=void |a0=[Ljava.lang.Object;:[[\ud89c\udef8\uda1c\ude19]] |this=org.mockito.internal.MockitoCore:@?\0121=void |a0=[Ljava.lang.Object;:[[\ud89c\udef8\uda1c\ude19]] |this=org.mockito.internal.MockitoCore:@?\012",
        Z.run(T, 2, 9, 9, 0, "\ud89c\udef8\uda1c\ude19", "\u4738\u1e9b", "\ud978\ude1e\uda63\ude93\ud887\udcae\udb4b\udd4f\udaa8\udc4f\udb1b\udcf9\ud804\udf7f\ud991\udeda\uda25\udce7\ud8d3\ude9a\uda75\ude91\ud893\udfe7\udbf0\uddbb\ud861\ude5b\ud957\udddb\udab2\udffc\uda9c\udd69\udab8\udc26\udb9c\udff8\udab9\ude6e\ud991\ude45\uda4b\udca4\ud9a1\udfe0\ud913\udfab\udab4\uddaf\ud987\udeb2\ud837\udefe\ud81d\ude16\udab6\udcf9",
        8, 40817, -1910492776, 8635202780063765014L, 25713L, false, false, (char) 48500, (char) 16966,
        Double.longBitsToDouble(0x3f5ea5b52b02b400L), Double.longBitsToDouble(0x3fd63776c41c8232L)));
  }
  @Test(timeout = 4000)
  public void test30() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 5, 3, 4, "\ud892\udc12\ucf11", "\u4738\u1ed2", "\ud8cb\udd3e\uda1a\udc13\ud87e\udf6e\uda24\udfdf\ud990\udc48\udb04\udf80\ud804\udf7f\ud80e\ude57\ud9ff\uddf1\ud8d3\ude9a\uda75\ude91\ud893\udfe7",
        44, 83724, 931211926, -3937114514589181200L, -77401L, true, true, (char) 21312, (char) 22184,
        Double.longBitsToDouble(0x3fe550aac4d52d05L), Double.longBitsToDouble(0x3fc804a351df67e4L)));
  }
  @Test(timeout = 4000)
  public void test31() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 2, 2, 4, "\ud8a4\udff8\uda1c\ude19", "\u4738\u8689", "\ud978\ude1e",
        10, 66400, -2045268797, 1066819431615566034L, 16295L, false, false, (char) 40473, (char) 14583,
        Double.longBitsToDouble(0x3fe423e90a96fb1aL), Double.longBitsToDouble(0x3fe7102c0af0c961L)));
  }
  @Test(timeout = 4000)
  public void test32() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.InvocationContainerImpl:invocationForStubbing: null |this=org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 2, 14, 7, "\ud8a4\udff8\uda1c\ude19", "\ub4ca\u1ed2", "\ud978\ude1e\uda63\ude93\ud866\udc73\udb4b\udd93\udaa8\udc4f\udb1b\udcf9",
        1, 62311, -2037785584, 5966770021560676761L, 11196L, true, true, (char) 25676, (char) 15397,
        Double.longBitsToDouble(0x3feef8ff6f95bdd7L), Double.longBitsToDouble(0x3fe79f63f7c2f47eL)));
  }
  @Test(timeout = 4000)
  public void test33() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 2, 3, 15, 14, "\udadc\udead\ud9d2\ude2c\ud8fd\udde4", "\u1ed2\uc204\u59ca\u0cad\u96ea\uc7fc\u606f\u3732\u9a8c\u35f8\u48ea\u041b\u3bdd\uac7e\u052e\u333b\u7480\uac5e\ud672\u2d2a", "\udae4\udce4\ud991\udd5c\uda38\udc9c\ud8b4\udf8e\ud836\udc17\ud8e7\udde5\udb29\udfd6\ud9fe\udfbe\ud943\udf1b\udb50\udd14\udaf0\udcd7\ud866\ude5a\uda52\udc4a\ud834\uddd2\ud8ea\ude42\ud97e\udf7f\ud8a9\uddcb\ud911\udea9\ue03a\uda84\uddd5\udaeb\udd29\ud866\udf67\udb45\udfb8\udacf\udd3d\udb3d\udf52\ud99e\uddb8\ud9fc\ude18\ud896\uddbc\udbe6\ude98\ud88f\udf8b\ud96c\ude4c\uda6d\udecf\udb3d\udf68\ud948\udc9a\uda0c\udc18\uda90\ude2f\udbb8\udc64\ud9d6\uddef\ud968\udcea",
        35, 23371, -744308537, -1069462168516027862L, 40838L, true, true, (char) 52981, (char) 830,
        Double.longBitsToDouble(0x3fe8958a8d6e42caL), Double.longBitsToDouble(0x3fdf883afa553f56L)));
  }
  @Test(timeout = 4000)
  public void test34() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 7, 13, 9, "\ud944\udf68\udb37\udf7e\ud9dc\udde6\uda6f\uddcf\ud865\udc07\uda83\udccb", "\uaf49\u430e\u078b\u8852\ua42a\u6d11\u47e8\uc2e7\u041b\u3bdd\uac7e\ud4f6\u1661\u98d2", "\ud9de\udfc3\ud95f\udc11\udb1d\udf2c\udadf\udc30\ud943\ude3e\ud892\udec9\uda36\udcd7\udbc4\udfba\udb36\udd9e\ud970\udeee\udb0a\udc2e\ud855\ude3e\ud90d\ude04\udb57\udc89\ud9fa\udc89\udbbb\udd39\ud883\udf97\ud98c\ude30\udbe6\udf93",
        27, 71626, 1249122079, 38565374587256991L, 7820L, false, false, (char) 23808, (char) 16498,
        Double.longBitsToDouble(0x3fc949498953ba54L), Double.longBitsToDouble(0x3feb876adecf25abL)));
  }
  @Test(timeout = 4000)
  public void test35() throws Throwable {
    assertEquals("0=org.mockito.internal.creation.MockSettingsImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 3, 13, 8, "\udbcd\udd2c\udbd5\udf7f\ud9bf\ude14\uda6f\uddcf\ud865\udc07\uda6c\udd60", "\u1cd4\uc76b\u078b\u8852\ua42a\u6d11", "\uda25\udce7",
        15, 54643, 262861167, -2936911028067578182L, -13303L, true, false, (char) 969, (char) 55108,
        Double.longBitsToDouble(0x3feff6852af9fba1L), Double.longBitsToDouble(0x3f8ae19a41d84340L)));
  }
  @Test(timeout = 4000)
  public void test36() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 8, 12, 1, "\udbcd\udd2c\udbd5\udf7f\ud9bf\ude14\uda6f\uddcf\ud8a7\ude65\ud97f\udefc", "\u1cd4\uc76b\u078b\u8852", "\ud940\udc3c\ud872\udc44\ud8fb\udee6",
        15, 62718, 262816358, -2937018780192757172L, 33155L, false, true, (char) 17864, (char) 52394,
        Double.longBitsToDouble(0x3fd57b307de7d8fcL), Double.longBitsToDouble(0x3fee17a033a2aba2L)));
  }
  @Test(timeout = 4000)
  public void test37() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.UnfinishedStubbingException\012",
        Z.run(T, 2, 10, 14, 5, "\udbcd\udd2c\udbd5\udf7f\ud9bf\udeb5\uda6f\uddcf\udbd3\udc9d\ud894\ude6f", "\u1cd4\uc76b\u078b\u8852\ua42a\u6d11", "\uda25\udce7",
        15, 62718, 262816358, -2936911028067578182L, 75447L, true, false, (char) 969, (char) 55108,
        Double.longBitsToDouble(0x3feff6852af9fba1L), Double.longBitsToDouble(0x3f8ae19a41d84340L)));
  }
  @Test(timeout = 4000)
  public void test38() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 4, 16, 1, "\udbcd\udd2c\udbd5\udf7f\ud9bf\ude14\uda6f\uddcf\ud868\udf01\uda6c\udd60", "\u1cd4\uc76b\u078b\u8852\ua42a\u6d11", "\uda25\udce7",
        15, 28934, 262826355, -2936911028067578182L, -13303L, true, false, (char) 969, (char) 55108,
        Double.longBitsToDouble(0x3feff6852af9fba1L), Double.longBitsToDouble(0x3f8ae19a41d84340L)));
  }
  @Test(timeout = 4000)
  public void test39() throws Throwable {
    assertEquals("0=new org.mockito.internal.MockHandler:@?\0121=!java.lang.NullPointerException\012",
        Z.run(T, 2, 8, 13, 16, "\udbcd\udd2c\udb0e\udecc\ud81a\ude46\uda6f\ude79", "\u6f23\u1f1e\u9d70\uc76b\u078b\u88d8\ua42a\u6d11\u5c92\uc2e7\u22cf\u3b7e\uac7e\ud4f6\u9eab\u98ec\uae51\ud672\u7aed\ubf45\u57d9\u7e5b\u2097\ub7b8\u2b57\ucecf\ud0aa\u3f14\uabdb", "\udafd\udf30",
        8, 76712, -1242509182, 4871769765963172583L, 90839L, true, false, (char) 35228, (char) 37341,
        Double.longBitsToDouble(0x3fe47ec1ec5dde41L), Double.longBitsToDouble(0x3fdf4d9c4ec3b6aeL)));
  }
  @Test(timeout = 4000)
  public void test40() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.StubberImpl:@? |this=org.mockito.internal.MockitoCore:@?\0121=!org.mockito.exceptions.misusing.UnfinishedStubbingException\012",
        Z.run(T, 2, 10, 10, 0, "\ud9a5\ude25\uda1c\ude19", "\u18c4\u1ed2", "\ud829\ude8c\u4e5e\udb0c\udde3\ud900\ude0b\ud819\udf14\ud897\udc45",
        31, 62311, -2037793520, 5665378494831934230L, 20887L, false, false, (char) 19035, (char) 15168,
        Double.longBitsToDouble(0x3feef8ff6917bdd7L), Double.longBitsToDouble(0x3fd290a9e3c73eb4L)));
  }
  @Test(timeout = 4000)
  public void test41() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.misusing.NotAMockException\012",
        Z.run(T, 2, 5, 1, 1, "\ud8a4\udff8\ud934\udf0b", "\u68ee\u10bc\u26b4\ua49d\u1cd4\u96aa\uc7fc\u9446\u1577\u62cb\u08bf\u48ea\u041b\u3bdd\u0c9f\u4727\u8867\ud5db\u0637\u43c9\uc5d2\u2968\ua154\uaa20\ua012\u1e08\ucf2a\u96ed\u872d\u8282", "\udaf2\udfcb\ud831\ude69\ud835\udf81\ud98a\ude24\udbea\udecd\udbab\udc01\udb9b\ude45\ud959\udc13\udb8f\udd66\ud94e\udc44\ud940\ude1b\ud8ac\udffe\uda8a\udd84\ud9e1\udeda\ud812\udc1c\ud98e\udc5b\udbe1\udde7\ud952\udf2a\ud9b1\udca3\ud9ef\udc9c\ud95f\udf28\uda58\udc07\udafb\udc87\udb6c\udde6",
        3, 98266, -1670219709, 1498302967967865482L, -61967L, true, false, (char) 27028, (char) 29252,
        Double.longBitsToDouble(0x3feb0ab05d3ee5e9L), Double.longBitsToDouble(0x3fe4dae206158542L)));
  }
  @Test(timeout = 4000)
  public void test42() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=!org.mockito.exceptions.base.MockitoException\012",
        Z.run(T, 2, 5, 9, 7, "\udbd6\udefd\ud934\udf0b", "\ub4c1\uacaa", "\ud9a4\udeca\uda63\ude93\ud81a\ude37\ud8e5\uded8\uda98\udecb\udaa6\udcd7\ud99b\udd20\udaa7\udcc2\uf103\ud8e3\udc9a\ud9fa\udee9\ud893\udfe7",
        25, 44057, 931224686, 2115723380682740124L, -59056L, false, true, (char) 1280, (char) 1179,
        Double.longBitsToDouble(0x3fef80cc5e99e459L), Double.longBitsToDouble(0x3fdf6f165bd438b2L)));
  }
  @Test(timeout = 4000)
  public void test43() throws Throwable {
    assertEquals("0=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\0121=org.mockito.internal.stubbing.VoidMethodStubbableImpl:@? |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 5, 5, 15, "\ud8a4\udff8\uda1c\ude19\ud9cb\udc56\uda69\udf0b", "\u8d2d\u36aa\u837e\u9755\u00c9", "\ud984\udce4",
        -1, 20209, -2037785584, 5966770021957959599L, -95115L, false, true, (char) 38160, (char) 52350,
        Double.longBitsToDouble(0x3fe7bf9144ec55f4L), Double.longBitsToDouble(0x3fe6c6fba430f3d7L)));
  }
  @Test(timeout = 4000)
  public void test44() throws Throwable {
    assertEquals("0=void |this=org.mockito.internal.MockHandler:@?\0121=void |this=org.mockito.internal.MockHandler:@?\012",
        Z.run(T, 2, 4, 4, 1, "\ud8a4\udff8\uda1c\ude19\ud9cb\udc56\uda69\udf0b", "\ucd2c", "\uda63\udecf\udb32\udc58",
        30, 11092, -1708225780, -5483370787532963791L, 57382L, false, false, (char) 4685, (char) 5184,
        Double.longBitsToDouble(0x3fd78a973556e98aL), Double.longBitsToDouble(0x3ecc1f7c7fb40000L)));
  }
  @Test(timeout = 4000)
  public void test45() throws Throwable {
    assertEquals("0=!org.mockito.exceptions.misusing.MissingMethodInvocationException\012",
        Z.run(T, 1, 15, 2, 7, "\ud8a4\udff8\uda1c\ude19", "\u4738\u3b18", "\ud978\ude1e\uda63\ude93\ud83b\udc47\udb4b\udd93\udab0\udc22\udb1b\udcf9",
        1, 62311, -2037785584, 5966749099720208486L, 85706L, true, true, (char) 25676, (char) 15397,
        Double.longBitsToDouble(0x3feef8ff6f95bdd7L), Double.longBitsToDouble(0x3fe79f63f7c2f47eL)));
  }

  // ZEST-HARNESS (support code below: not test statements)
  static final String[] T = {
    "M|org.mockito.internal.MockHandler|handle|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockitoCore|verify|java.lang.Object,org.mockito.verification.VerificationMode|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockHandler|getInvocationContainer||new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockHandler|getMockSettings||new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockHandler|setAnswersForStubbing|java.util.List|new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockHandler|voidMethodStubbable|java.lang.Object|new:org.mockito.internal.MockHandler:",
    "C|org.mockito.internal.MockHandler|<init>|org.mockito.internal.MockHandlerInterface",
    "C|org.mockito.internal.MockHandler|<init>|",
    "C|org.mockito.internal.MockHandler|<init>|org.mockito.internal.creation.MockSettingsImpl",
    "M|org.mockito.internal.MockitoCore|assertMocksNotEmpty|[Ljava.lang.Object;|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|doAnswer|org.mockito.stubbing.Answer|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|getLastInvocation||new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|inOrder|[Ljava.lang.Object;|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|mock|java.lang.Class,org.mockito.MockSettings|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|reset|[Ljava.lang.Object;|new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockitoCore|stub||new:org.mockito.internal.MockitoCore:",
    "M|org.mockito.internal.MockHandler|handle|org.mockito.internal.invocation.Invocation|new:org.mockito.internal.MockHandler:",
    "M|org.mockito.internal.MockitoCore|verify|java.lang.Object,org.mockito.verification.VerificationMode|new:org.mockito.internal.MockitoCore:",
  };

  static class Z {
      public static boolean invalid;
      static final int MAXS = 300;
  
      public static String run(String[] targets, int n, int w0, int w1, int w2,
                               String s0, String s1, String s2, int i0, int i1, int i2, long l0, long l1,
                               boolean b0, boolean b1, char c0, char c1, double d0, double d1) throws Throwable {
          Pool p = new Pool(new String[]{s0, s1, s2}, new int[]{i0, i1, i2}, new long[]{l0, l1},
                            new boolean[]{b0, b1}, new char[]{c0, c1}, new double[]{d0, d1});
          int[] ws = {w0, w1, w2};
          java.util.Map<String, Object> recv = new java.util.HashMap<String, Object>();
          StringBuilder obs = new StringBuilder();
          invalid = false;
          if (n < 1) n = 1;
          if (n > 3) n = 3;
          for (int k = 0; k < n; k++) {
              String desc = targets[idx(ws[k], targets.length)];
              p.reset();
              String r;
              try {
                  r = call(desc, p, recv);
              } catch (java.lang.reflect.InvocationTargetException e) {
                  Throwable t = e.getCause() == null ? e : e.getCause();
                  if (t instanceof Error) throw t;
                  if (k == 0 && t instanceof RuntimeException) invalid = true;
                  r = "!" + t.getClass().getName();
              }
              obs.append(k).append('=').append(r).append('\n');
              if (r.startsWith("!")) break;
          }
          return obs.toString();
      }
  
      static String call(String desc, Pool p, java.util.Map<String, Object> recv) throws Throwable {
          String[] f = desc.split("\\|", -1);
          Class<?> c;
          Class<?>[] ts;
          try {
              c = cls(f[1]);
              ts = types(f[3]);
          } catch (Exception e) {
              return "!H:" + e.getClass().getName();
          }
          try {
              if (f[0].equals("C")) {
                  java.lang.reflect.Constructor<?> k = c.getDeclaredConstructor(ts);
                  k.setAccessible(true);
                  Object[] a = args(ts, p);
                  Object o = k.newInstance(a);
                  return "new " + show(o) + mut(a);
              }
              java.lang.reflect.Method m = c.getDeclaredMethod(f[2], ts);
              m.setAccessible(true);
              Object target = null;
              if (!java.lang.reflect.Modifier.isStatic(m.getModifiers())) {
                  target = recv.get(f[4]);
                  if (target == null) {
                      target = receiver(f[4], p);
                      if (target == null) return "!H:norecv";
                      recv.put(f[4], target);
                  }
              }
              Object[] a = args(ts, p);
              Object r = m.invoke(target, a);
              return (m.getReturnType() == void.class ? "void" : show(r)) + mut(a)
                     + (target == null ? "" : " |this=" + show(target));
          } catch (java.lang.reflect.InvocationTargetException e) {
              throw e;
          } catch (Error e) {
              throw e;
          } catch (Exception e) {   // reflection problems: wrong arg type, abstract class, ...
              return "!H:" + e.getClass().getName();
          }
      }
  
      static Object receiver(String spec, Pool p) throws Exception {
          String[] r = spec.split(":", -1);
          if (r[0].equals("new")) {
              Class<?>[] ts = types(r[2]);
              java.lang.reflect.Constructor<?> k = cls(r[1]).getDeclaredConstructor(ts);
              k.setAccessible(true);
              return k.newInstance(args(ts, p));
          }
          if (r[0].equals("fac")) {
              Class<?>[] ts = types(r[3]);
              java.lang.reflect.Method m = cls(r[1]).getDeclaredMethod(r[2], ts);
              m.setAccessible(true);
              return m.invoke(null, args(ts, p));
          }
          if (r[0].equals("fld")) {
              java.lang.reflect.Field fl = cls(r[1]).getDeclaredField(r[2]);
              fl.setAccessible(true);
              return fl.get(null);
          }
          return null;
      }
  
      // ---------------------------------------------------------------- arguments
      static final class Pool {
          String[] s; int[] i; long[] l; boolean[] b; char[] c; double[] d;
          int si, ii, li, bi, ci, di;
          Pool(String[] s, int[] i, long[] l, boolean[] b, char[] c, double[] d) {
              this.s = s; this.i = i; this.l = l; this.b = b; this.c = c; this.d = d;
          }
          void reset() { si = ii = li = bi = ci = di = 0; }
          String s() { return s[si++ % s.length]; }
          int i() { return i[ii++ % i.length]; }
          long l() { return l[li++ % l.length]; }
          boolean b() { return b[bi++ % b.length]; }
          char c() { return c[ci++ % c.length]; }
          double d() { return d[di++ % d.length]; }
      }
  
      static final java.util.Locale[] LOCALES = {
          java.util.Locale.US, java.util.Locale.FRANCE, java.util.Locale.GERMANY, java.util.Locale.JAPAN,
          java.util.Locale.CHINA, new java.util.Locale("th", "TH"), new java.util.Locale("en", "GB"), new java.util.Locale("")};
      static final String[] TZS = {"UTC", "GMT", "America/Los_Angeles", "Asia/Bangkok", "Europe/London",
          "GMT+05:30", "Australia/Sydney"};
      static final Class<?>[] CLASSES = {String.class, Integer.class, int.class, Object.class, java.util.List.class,
          int[].class, String[].class, Number.class, Comparable.class, java.util.ArrayList.class,
          java.util.Date.class, Thread.State.class, Long.class, char.class};
  
      static int idx(int x, int n) { return n <= 0 ? 0 : ((x % n) + n) % n; }
  
      static Class<?>[] types(String s) throws ClassNotFoundException {
          if (s == null || s.length() == 0) return new Class<?>[0];
          String[] parts = s.split(",");
          Class<?>[] r = new Class<?>[parts.length];
          for (int j = 0; j < parts.length; j++) r[j] = cls(parts[j]);
          return r;
      }
  
      static Class<?> cls(String n) throws ClassNotFoundException {
          if (n.equals("int")) return int.class;
          if (n.equals("long")) return long.class;
          if (n.equals("boolean")) return boolean.class;
          if (n.equals("char")) return char.class;
          if (n.equals("double")) return double.class;
          if (n.equals("float")) return float.class;
          if (n.equals("short")) return short.class;
          if (n.equals("byte")) return byte.class;
          return Class.forName(n, false, Z.class.getClassLoader());
      }
  
      static Object[] args(Class<?>[] ts, Pool p) {
          Object[] a = new Object[ts.length];
          for (int j = 0; j < ts.length; j++) a[j] = arg(ts[j], p);
          // ~1/7 of calls: pass null for the last reference parameter (null-handling bugs)
          if (idx(p.i[2], 7) == 0) {
              for (int j = ts.length - 1; j >= 0; j--) if (!ts[j].isPrimitive()) { a[j] = null; break; }
          }
          return a;
      }
  
      static String[] split(String s) {
          String[] parts = s.split(",", -1);
          if (parts.length > 8) {
              String[] r = new String[8];
              System.arraycopy(parts, 0, r, 0, 8);
              return r;
          }
          return parts;
      }
  
      static Object arg(Class<?> t, Pool p) {
          if (t == String.class || t == CharSequence.class || t == Object.class || t == Comparable.class
              || t == java.io.Serializable.class) return p.s();
          if (t == int.class || t == Integer.class) return Integer.valueOf(p.i());
          if (t == long.class || t == Long.class) return Long.valueOf(p.l());
          if (t == boolean.class || t == Boolean.class) return Boolean.valueOf(p.b());
          if (t == char.class || t == Character.class) return Character.valueOf(p.c());
          if (t == double.class || t == Double.class) return Double.valueOf(p.d());
          if (t == float.class || t == Float.class) return Float.valueOf((float) p.d());
          if (t == short.class || t == Short.class) return Short.valueOf((short) p.i());
          if (t == byte.class || t == Byte.class) return Byte.valueOf((byte) p.i());
          if (t == Number.class) return p.b() ? (Object) Integer.valueOf(p.i()) : (Object) Double.valueOf(p.d());
          if (t == StringBuffer.class) return new StringBuffer(p.s());
          if (t == StringBuilder.class) return new StringBuilder(p.s());
          if (t == java.io.Writer.class || t == java.io.StringWriter.class) return new java.io.StringWriter();
          if (t == java.util.Random.class) return new java.util.Random(p.l());
          if (t == java.util.Locale.class) return LOCALES[idx(p.i(), LOCALES.length)];
          if (t == java.util.TimeZone.class) return java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]);
          if (t == java.util.Date.class) return new java.util.Date(p.l());
          if (t == java.util.Calendar.class || t == java.util.GregorianCalendar.class) {
              java.util.Calendar cal = new java.util.GregorianCalendar(
                  java.util.TimeZone.getTimeZone(TZS[idx(p.i(), TZS.length)]), java.util.Locale.US);
              cal.setTimeInMillis(p.l());
              return cal;
          }
          if (t == Class.class || t == java.lang.reflect.Type.class) return CLASSES[idx(p.i(), CLASSES.length)];
          if (t.isEnum()) {
              Object[] v = t.getEnumConstants();
              return v == null || v.length == 0 ? null : v[idx(p.i(), v.length)];
          }
          if (t == java.util.List.class || t == java.util.Collection.class || t == Iterable.class
              || t == java.util.ArrayList.class)
              return new java.util.ArrayList<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Set.class || t == java.util.SortedSet.class || t == java.util.TreeSet.class)
              return new java.util.TreeSet<Object>(java.util.Arrays.asList((Object[]) split(p.s())));
          if (t == java.util.Iterator.class)
              return java.util.Arrays.asList((Object[]) split(p.s())).iterator();
          if (t == java.util.Map.class || t == java.util.HashMap.class) {
              java.util.Map<Object, Object> m = new java.util.HashMap<Object, Object>();
              if (p.b()) {
                  String[] parts = split(p.s());
                  for (int j = 0; j + 1 < parts.length; j += 2) m.put(parts[j], parts[j + 1]);
              }
              return m;
          }
          if (t.isArray()) return arrayFrom(t.getComponentType(), p.s(), p);
          return null;   // unsupported type: null
      }
  
      static Object arrayFrom(Class<?> ct, String s, Pool p) {
          if (ct == char.class) return s.toCharArray();
          if (ct == String.class || ct == CharSequence.class || ct == Object.class) {
              String[] parts = split(s);
              Object arr = java.lang.reflect.Array.newInstance(ct, parts.length);
              for (int j = 0; j < parts.length; j++) java.lang.reflect.Array.set(arr, j, parts[j]);
              return arr;
          }
          if (ct.isPrimitive()) {
              int len = Math.min(s.length(), 8);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) {
                  int x = s.charAt(j) - '0';
                  if (ct == int.class) java.lang.reflect.Array.setInt(arr, j, x);
                  else if (ct == long.class) java.lang.reflect.Array.setLong(arr, j, x);
                  else if (ct == short.class) java.lang.reflect.Array.setShort(arr, j, (short) x);
                  else if (ct == byte.class) java.lang.reflect.Array.setByte(arr, j, (byte) x);
                  else if (ct == double.class) java.lang.reflect.Array.setDouble(arr, j, x / 2.0);
                  else if (ct == float.class) java.lang.reflect.Array.setFloat(arr, j, x / 2.0f);
                  else if (ct == boolean.class) java.lang.reflect.Array.setBoolean(arr, j, (x & 1) == 1);
              }
              return arr;
          }
          if (ct.isArray()) {                       // 2-D: rows separated by ';'
              String[] rows = s.split(";", -1);
              int len = Math.min(rows.length, 6);
              Object arr = java.lang.reflect.Array.newInstance(ct, len);
              for (int j = 0; j < len; j++) java.lang.reflect.Array.set(arr, j, arrayFrom(ct.getComponentType(), rows[j], p));
              return arr;
          }
          int len = idx(p.i(), 4);
          Object arr = java.lang.reflect.Array.newInstance(ct, len);
          for (int j = 0; j < len; j++) {
              Object v = arg(ct, p);
              if (v != null && !ct.isInstance(v)) v = null;
              java.lang.reflect.Array.set(arr, j, v);
          }
          return arr;
      }
  
      // ---------------------------------------------------------------- observation
      static String show(Object o) {
          if (o == null) return "null";
          String s;
          try {
              if (o.getClass().isArray()) s = java.util.Arrays.deepToString(new Object[]{o});
              else if (o instanceof Class) s = ((Class<?>) o).getName();
              else s = String.valueOf(o);
          } catch (Throwable t) {
              s = "!toString:" + t.getClass().getName();
          }
          if (s.matches("(?s).*@[0-9a-f]{4,8}.*")) s = "@?";          // identity hash: not stable
          if (s.length() > MAXS) s = s.substring(0, MAXS) + "...";
          return o.getClass().getName() + ":" + s;
      }
  
      static String mut(Object[] a) {
          StringBuilder b = new StringBuilder();
          for (int j = 0; j < a.length; j++) {
              Object o = a[j];
              if (o instanceof java.io.StringWriter || o instanceof StringBuffer || o instanceof StringBuilder
                  || (o != null && o.getClass().isArray()))
                  b.append(" |a").append(j).append('=').append(show(o));
          }
          return b.toString();
      }
  }
}
